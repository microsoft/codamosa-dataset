

# Generated at 2022-06-21 17:35:22.450470
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer(None)

# Generated at 2022-06-21 17:35:23.376919
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = ""

# Generated at 2022-06-21 17:35:24.246795
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    ...



# Generated at 2022-06-21 17:35:27.730384
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = '{1: 1, **{2: 2}}'
    expected = '_py_backwards_merge_dicts([{1: 1}], {2: 2})'
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-21 17:35:34.530589
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.tree import test_ast

    dict_stmt = '{1: 1, **dict_a}'
    target = '_py_backwards_merge_dicts([{1: 1}], dict_a)'

    test_ast(DictUnpackingTransformer, dict_stmt, target)

# Generated at 2022-06-21 17:35:37.363425
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = '{1: 2, 3: 4, **dict_a}'

# Generated at 2022-06-21 17:35:45.146728
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.ast import compare_ast, dump_ast

    source = """\
        {
            1: 1,
            **dict_a,
            2: 2,
            **dict_b,
            3: 3,
        }
    """
    expected = """\
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    tree = source_to_ast(source)
    tree = DictUnpackingTransformer().visit(tree)  # type: ignore
    expected = source_to_ast(expected)
    assert compare_ast(tree, expected)

# Generated at 2022-06-21 17:35:52.172369
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    trans = DictUnpackingTransformer()
    trans._split_by_None([(None, 1), (1, 1)]) == [1, [(1, 1)]]
    assert trans._merge_dicts([1, ast.Dict(keys=[1], values=[1])]) == \
        ast.Call(
            func=ast.Name(id='_py_backwards_merge_dicts'),
            args=[ast.List(elts=[1, ast.Dict(keys=[1], values=[1])])],
            keywords=[])

# Generated at 2022-06-21 17:36:00.865098
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast  # type: ignore
    from ..utils.symbols import SymbolTable  # type: ignore
    from ..utils.source import get_source
    from ..utils.tree import print_ast
    from ..py2.symbols import SymbolTable as SymbolTable2  # type: ignore
    from ..py2.source import get_source as get_source2  # type: ignore

    transformer = DictUnpackingTransformer()
    tree = ast.parse('{1: 1, 2: 2, **dict_a}', '', 'eval')
    tree = transformer.visit(tree)  # type: ignore
    print_ast(tree)
    symbols = SymbolTable2.from_tree(tree)
    assert get_source(tree, symbols) == get_source2(tree, symbols)

# Generated at 2022-06-21 17:36:09.309635
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    with open('test.py', 'r') as file:
        src = file.read()
        module = ast.parse(src)
    print(ast.dump(module))
    _ = DictUnpackingTransformer()(module)
    print(ast.dump(_))
    _ = ast.fix_missing_locations(_)
    print(compile(module, '', 'exec'))


if __name__ == "__main__":
    test_DictUnpackingTransformer()

# Generated at 2022-06-21 17:36:21.919105
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    src = dedent("""\
        def func(a, b, c):
            return {1: 1, **a} + {**b, **c}
        """)

    expected = dedent("""\
        def func(a, b, c):
            return _py_backwards_merge_dicts([{1: 1}], a) + _py_backwards_merge_dicts([], b, c)
    """)

    tree = ast.parse(src)
    DictUnpackingTransformer().visit(tree)

    assert ast.dump(tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-21 17:36:24.311170
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer


# Generated at 2022-06-21 17:36:25.063931
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None



# Generated at 2022-06-21 17:36:33.771798
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:36:42.711802
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    # Function to test
    def transform_ast(ast_tree):
        visitor = DictUnpackingTransformer()
        return visitor.visit(ast_tree)

    source = '''
        {1: 1, **{2: 2}, 3: 3, **{4: 4}, 5: 5, **{6: 6}}
    '''

# Generated at 2022-06-21 17:36:49.235083
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('{1: 2, **{2: 3, 3: 4}}')
    t = DictUnpackingTransformer()
    res = DictUnpackingTransformer().visit(node)
    expected = ast.parse('_py_backwards_merge_dicts([{1: 2}], {2: 3, 3: 4})')
    assert ast.dump(res) == ast.dump(expected)

# Generated at 2022-06-21 17:36:53.956541
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    # If this runs without failure, the test has passed
    t.visit(
        ast.parse(
            "a = {'a':1, 'b':2, **d}"
        )
    )

# Generated at 2022-06-21 17:37:00.961567
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..tests.utils import make_call, parse
    from ..core import transform
    from ..core.legacy import patch

    patcher = patch(DictUnpackingTransformer, globals())

    node = parse("{1: 1, **{'a': 2}, 2: 2, **{'b': 3}}")
    expected = make_call(
        '_py_backwards_merge_dicts',
        [
            make_call('dict', [1]),
            {'a': 2},
            make_call('dict', [2]),
            {'b': 3}
        ]
    )
    transformed = transform(node)
    assert transformed == expected

# Generated at 2022-06-21 17:37:07.425113
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('{1: 1, **dict_a}', mode='eval')
    DictUnpackingTransformer(node).visit(node)
    assert ast.dump(node) == \
        "Module(body=[Expr(_py_backwards_merge_dicts([dict([(1, 1)])], dict_a))])"

# Generated at 2022-06-21 17:37:16.070880
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import parse
    from ..utils.tree import dump
    import unittest

    class TestCase(unittest.TestCase):
        def test(self):
            x = ast.parse('{1: 1, 2: 2, **a, 3: 3, **b, 4: 4, 5: 5, **c}')
            transformer = DictUnpackingTransformer()
            transformer.visit(x)

# Generated at 2022-06-21 17:37:29.393626
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    t._split_by_None([(None, ast.Call(
        func=ast.Name(id='dict'),
        args=[ast.Str(s='')],
        keywords=[])), (ast.Str(s=''), ast.Num(n=1)), (None, ast.Dict()),
        (ast.Str(s=''), ast.Num(n=2))]) == [[(ast.Str(s=''), ast.Num(n=1))],
        # type: ignore
        ast.Call(
            func=ast.Name(id='dict'),
            args=[ast.Str(s='')],
            keywords=[]),
        [(ast.Str(s=''), ast.Num(n=2))]]

# Generated at 2022-06-21 17:37:37.211785
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer
    from astunparse import unparse
    from ..utils.tree import insert_at
    """Unit test for method visit_Module of class DictUnpackingTransformer"""
    TRANSFORMER = DictUnpackingTransformer()
    CODE = '''\
{1: 1, None: 2, **{3: 3, 4: 4}}
'''
    AST = ast.parse(CODE)
    insert_at(0, AST, MERGE_DICTS)
    result = unparse(TRANSFORMER.visit(AST)).rstrip()

# Generated at 2022-06-21 17:37:38.178534
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    return DictUnpackingTransformer


# Generated at 2022-06-21 17:37:39.471108
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = [
    ]


# Generated at 2022-06-21 17:37:48.527049
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import Any, Dict
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str

    def make_test_dict(keys: Dict[Any, Any]) -> ast.Dict:
        keys_, values_ = [], []
        for key, value in sorted(keys.items()):
            if key == None:
                key = ast.Name(id='None', ctx=ast.Load())
            if isinstance(value, str):
                value = ast.Constant(value=value, kind=None)
            keys_.append(key), values_.append(value)
        return ast.Dict(keys=keys_, values=values_)

    def check(source: Dict[Any, Any], expected: Dict[Any, Any]) -> None:
        result = DictUn

# Generated at 2022-06-21 17:37:58.920291
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    snippet_ = snippet('''
        x = {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c, **dict_d}
    ''')


# Generated at 2022-06-21 17:37:59.448935
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a = DictUnpackingTransformer()

# Generated at 2022-06-21 17:38:04.286837
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('''a, *b = range(5)''')
    assert str(tree) == '''Module(body=[Assign(targets=[Name(id='a', ctx=Store()), Starred(value=Name(id='b', ctx=Store()), ctx=Store())], value=Call(func=Name(id='range', ctx=Load()), args=[Num(n=5)], keywords=[]))])'''
    tree = DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-21 17:38:06.504807
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:38:11.932088
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    t = DictUnpackingTransformer()

    s = ast.parse('')
    node = t.visit(s)  # type: ignore

# Generated at 2022-06-21 17:38:25.138016
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    t = DictUnpackingTransformer()
    assert t.visit(ast.parse('''{'key': None, **dict_a}''')) == \
        ast.parse('''_py_backwards_merge_dicts(
            [{'key': None}], dict_a)''')
    assert t.visit(ast.parse('''{}''')) == ast.parse('''{}''')
    assert t.visit(ast.parse('''{key: None}''')) == \
        ast.parse('''dict({})''')

# Generated at 2022-06-21 17:38:32.936069
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest
    import typed_astunparse

    class TestVisitDict(unittest.TestCase):

        def test_no_unpack(self):
            node = ast.parse("{'a': 1, 'b': 2}").body[0]  # type: ast.Expr
            assert isinstance(node.value, ast.Dict)
            transformer = DictUnpackingTransformer()
            assert transformer.visit(node) is node

        def test_unpack(self):
            node = ast.parse("{'a': 1, **dict_a}").body[0]  # type: ast.Expr
            assert isinstance(node.value, ast.Dict)
            transformer = DictUnpackingTransformer()
            transformed = transformer.visit(node)

# Generated at 2022-06-21 17:38:33.928635
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer.__name__ == "DictUnpackingTransformer"

# Generated at 2022-06-21 17:38:36.596646
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(_tree_changed=True)
    assert not DictUnpackingTransformer()

# Generated at 2022-06-21 17:38:42.983864
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    text = '''{
        1: 1,
        None: dict_a,
        2: 2,
        None: dict_b,
        3: 3,
    }'''
    expected = '''
_py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b, {3: 3}])'''

    assert DictUnpackingTransformer(text).result == expected

# Generated at 2022-06-21 17:38:47.760206
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('''{1: 1, **dict_a}''')
    assert isinstance(tree, ast.Module)
    result = DictUnpackingTransformer().visit(tree).body

# Generated at 2022-06-21 17:38:57.845831
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("{1: 1, 2: 2}")
    DictUnpackingTransformer().visit(module)
    result = ast.dump(module)

# Generated at 2022-06-21 17:39:00.787128
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """\
d = {1: 1, **a}
b = {**c, **d}
    """

# Generated at 2022-06-21 17:39:10.129380
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor  # type: ignore
    import textwrap
    in_text = textwrap.dedent('''
        {1: 2, **dict_a, 3: 4, **dict_b, 5: 6, **dict_c}
    ''')
    expected = textwrap.dedent('''
        _py_backwards_merge_dicts([{1: 2, 3: 4, 5: 6}], dict_a, dict_b, dict_c)
    ''')
    tree = ast.parse(in_text)
    DictUnpackingTransformer().visit(tree)
    actual = astor.to_source(tree)
    assert expected == actual  # type: ignore

# Generated at 2022-06-21 17:39:19.619788
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    before = """
    class Foo:
        def __init__(self, x: int, y: int = 5) -> None:
            self.x = x + y
            self.y = y
    """

    after = """
    import _typing

    def _merge_dicts(*dicts):
        result = dict()
        for dict in dicts:
            result.update(dict)
        return result

    __all__ = [
        "Foo"
    ]
    class Foo:
        def __init__(self, x: int, y: int = 5) -> None:
            self.x = x + y
            self.y = y
    """

    assert after == str(DictUnpackingTransformer().visit(ast.parse(before)))



# Generated at 2022-06-21 17:39:37.746269
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.tree import print_tree
    from .unparser import Unparser

    # Expected
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    # Before
    before = """
    {1: 1, **dict_a}
    """

    # After
    after = """
    _py_backwards_merge_dicts([dict({1: 1})], dict_a)
    """

    # Test
    node_before = ast.parse(before)  # type: ast.Module
    node_after = DictUnpackingTransformer().visit(node_before)

    Unparser(node_after)
    print_tree(node_after)
    assert Unparser(node_after) == after  # type: ignore

# Generated at 2022-06-21 17:39:38.778563
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)

# Generated at 2022-06-21 17:39:44.470647
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import fix

    def transform(code):
        return fix(DictUnpackingTransformer, code)

    b = "x = {1: 1, **a, 2: 2, **b, 3: 3, **c}"
    a = """x = _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], a, b, c)"""
    assert transform(b) == a

# Generated at 2022-06-21 17:39:45.006990
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): assert DictUnpackingTransformer



# Generated at 2022-06-21 17:39:54.532242
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.testing_utils import assert_source_equal, compile_ast
    a = DictUnpackingTransformer()
    source = """
        class X:
            def f(self):
                {1: 1, **a}
                {1: 1, **a, 2: 2, **b}
        """
    result = compile_ast(source, a)
    expected = """
        class X:
            def f(self):
                _py_backwards_merge_dicts([{1: 1}], a)
                _py_backwards_merge_dicts([{1: 1}, {2: 2}], a, b)
        """
    assert_source_equal(expected, result)



# Generated at 2022-06-21 17:39:55.716082
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:39:58.846436
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    class DictUnpackingTransformerTest(DictUnpackingTransformer):
        node = ast.Dict()

    DictUnpackingTransformerTest()

# Generated at 2022-06-21 17:40:08.292323
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    source = '''
    d = {}
    e = {**d}
    f = {'a': 1, **e}
    g = {'b': 2, **f}
    h = {**d, 'a': 1}
    j = {**e, 'b': 2}
    k = {**f, 'c': 3}
    l = {**g, 'c': 3}
    '''

# Generated at 2022-06-21 17:40:11.341170
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    assert isinstance(x, DictUnpackingTransformer)

# Generated at 2022-06-21 17:40:18.998453
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3, parse
    from ..mutators.dict_unpacking import DictUnpackingTransformer

    ts = DictUnpackingTransformer()

    before = ast3.parse("""
{
    1: 1,
    **{2: 2},
    3: 3,
    **{4: 4},
}
""")

    after = ast3.parse("""
_py_backwards_merge_dicts([{1: 1}, {3: 3}], {2: 2}, {4: 4})
""")

    assert ts.visit(before) == after



# Generated at 2022-06-21 17:40:41.411428
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import astunparse


# Generated at 2022-06-21 17:40:51.133343
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astunparse import unparse
    from astpretty import pprint

    x = {1: 1, 2: 2, **{3: 3}}
    source = f"""\
        y = {x}
    """
    expected_source = f"""\
        y = _py_backwards_merge_dicts([{x}], {3: 3})
    """
    py_ast = ast.parse(source)
    tree_ex_trans = DictUnpackingTransformer()
    tree_ex_trans.visit(py_ast)
    result_source = unparse(py_ast)
    print(pprint(source))
    print('==>')
    print(pprint(result_source))
    print('==>')
    print(pprint(expected_source))
    assert result_source == expected_source

# Generated at 2022-06-21 17:41:00.909424
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.example import Example
    from .base import TransformerTestCase
    from typing import Dict
    
    class DictUnpackingTransformerCase(TransformerTestCase[Dict[str, str]]):
        transformer = DictUnpackingTransformer
        code = Example("""
        d = {1: 1, **d2}
        """)
        expected = Example("""
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        d = _py_backwards_merge_dicts([{1: 1}], d2)
        """)
    
    DictUnpackingTransformerCase.test_equal()

# Generated at 2022-06-21 17:41:06.267879
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('''
        def f(dict_a):
            return {1: 1, **dict_a}
    ''')
    assert len(list(module.body[0].body[0].value.keys)) == 2
    assert isinstance(module.body[0].body[0].value.values[-1], ast.Name)


# Generated at 2022-06-21 17:41:17.948169
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from functools import partial
    from ..compile import compile as macro_compile
    from ..utils.compile import compile as standard_compile

    module = ast.parse("{{1: 1}}")
    node = module.body[0]

    trans = DictUnpackingTransformer()
    compiled = macro_compile(node, trans)

    our_func = partial(eval(compiled), {})
    their_func = partial(eval(standard_compile(node)), {})
    assert their_func() == {1: 1} == our_func()

    module = ast.parse("{1: 1, **{}, 2: 2}")
    node = module.body[0]

    trans = DictUnpackingTransformer()
    compiled = macro_compile(node, trans)


# Generated at 2022-06-21 17:41:24.536826
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_code = '''
        x = {1: 1, **dict_a}
    '''
    expected_code = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    test_node = ast.parse(test_code)
    expected_node = ast.parse(expected_code)

    transformer = DictUnpackingTransformer()
    transformer.visit(test_node)
    assert transformer._tree_changed is True
    assert expected_node.body == test_node.body



# Generated at 2022-06-21 17:41:30.370750
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_transformer import run_test
    dict_unpacking_transformer = DictUnpackingTransformer()
    snippet = """\
{1: 1, None: dict_a, **dict_b}
{1: 1, **dict_a}
    """
    expected = """\
_py_backwards_merge_dicts([{1: 1}, dict_a], dict_b)
_py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    run_test(dict_unpacking_transformer, snippet, expected)

# Generated at 2022-06-21 17:41:39.800155
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTestCase

    class DictUnpackingTransformerTestCase(BaseNodeTransformerTestCase):
        transformer = DictUnpackingTransformer

    DictUnpackingTransformerTestCase.test_case(
    '{1: 2, 3: 4, **{5: 6, 7: 8}}',
    '_py_backwards_merge_dicts([{1: 2, 3: 4}], {5: 6, 7: 8})')


# Generated at 2022-06-21 17:41:47.854302
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """
    {1: 1, 2: 2, 3: 3, **dict_a}
    {1: 1, 2: 2, 3: 3, **dict_a, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a)
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    result = DictUnpackingTransformer().run_pipeline(code)
    assert result == expected

# Generated at 2022-06-21 17:41:59.763266
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import Optional

    class TestCase(object):
        def __init__(self, source, expected):
            source_tokens = [tok for tok in tokenize.tokenize(BytesIO(
                source.encode('utf-8')).readline)]
            self.source = ast.parse(source)
            self.expected = list(tokenize.tokenize(BytesIO(
                expected.encode('utf-8')).readline))
            self.output = []  # type: List[tokenize.TokenInfo]

        def run(self):
            transformer = DictUnpackingTransformer()
            transformer.visit(self.source)
            if not transformer._tree_changed:
                self.output = []

# Generated at 2022-06-21 17:42:41.210471
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    a = ast.Name(id='a')
    b = ast.Name(id='b')
    d = ast.Dict(keys=[None, ast.Num(1), None, None, None, None])

    assert transformer._split_by_None([]) == [[]]
    assert transformer._split_by_None([(None, a)]) == [None, a, []]
    assert transformer._split_by_None([(a, b), (None, a), (a, b)]) == [
        [(a, b)], None, a, [(a, b)], []]

    assert transformer._prepare_splitted([]) == []

# Generated at 2022-06-21 17:42:52.244821
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    code = """
    {1: 1, **dict_a}
    {1: 1, **dict_a, 2: 2, 3: 3, **dict_b, 4: 4, 5: 5}
    {1: 1, **dict_a, 2: 2, 3: 3, 4: 4, 5: 5}
    {}
    {1: 1, **dict_a, **dict_b, 2: 2}
    """

# Generated at 2022-06-21 17:43:03.402968
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # type: () -> None

    from ..compiler import compile_

    assert compile_('{1: 1, 2: 2, **{3: 3}}') == set([
        '_py_backwards_merge_dicts([{2: 2}, {3: 3}], {1: 1})',
        '_py_backwards_merge_dicts([{1: 1}, {3: 3}], {2: 2})',
        '_py_backwards_merge_dicts([{1: 1}, {2: 2}], {3: 3})',
    ])


# Generated at 2022-06-21 17:43:12.664559
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .transform import Transform
    from .tests.utils import make_module
    from textwrap import dedent

    module = '''
    {**{}}
    '''

    module = make_module("""
        def f():
            pass

        def g():
            {}
        """.format(module))

    result = str(Transform().visit(module))
    expected = dedent("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    def f():
        pass

    def g():
        _py_backwards_merge_dicts([dict()], {})
    """)

    assert result == expected



# Generated at 2022-06-21 17:43:17.542877
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_converted_code

    assert_converted_code(
        """
        _py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3, 4: 4}, 5])
        """,
        """
        {1: 1, 2: 2, **{3: 3, 4: 4}, **5}
        """,
        DictUnpackingTransformer
    )

# Generated at 2022-06-21 17:43:25.796807
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .transform import TransformManager
    from .multi_stmt_assignment import MultiStmtAssignmentTransformer
    from .module_level_constants import ModuleLevelConstantTransformer

    manager = TransformManager(
        DictUnpackingTransformer,
        MultiStmtAssignmentTransformer,
        ModuleLevelConstantTransformer)

    t = manager.transform

    assert t('{1: 2, **{3: 4}}') == '_py_backwards_merge_dicts([{1: 2}], {3: 4})'
    assert t('{1: 2, 3: 4, **{5: 6, 7: 8}}') == '_py_backwards_merge_dicts([{1: 2, 3: 4}], {5: 6, 7: 8})'

# Generated at 2022-06-21 17:43:32.178840
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    ast_expected = ast.parse(
        """_py_backwards_merge_dicts([dict(a=1, c=3), dict(b=2)], dict_a)""")
    ast_actual = transformer.visit(
        ast.parse("""{a: 1, **dict(b=2), c: 3, **dict_a}"""))
    assert ast_expected.body == ast_actual.body

# Generated at 2022-06-21 17:43:44.432991
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import make_call, make_attribute
    from .test_utils import parse_str, compare_ast, transform

    source1 = '''\
        {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4, **dict_c, 5: 5}'''
    expected1 = '''\
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4, 5: 5}], dict_a, dict_b, dict_c)'''

    source2 = '''\
        {1: 1, **dict_a, **dict_b}'''

# Generated at 2022-06-21 17:43:47.152957
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    return '''
    _py_backwards_merge_dicts = None
    
    def f():
        return {1, **a}
    '''



# Generated at 2022-06-21 17:43:50.729544
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .. import compile
    source = """\
dictionary = {None: 5, 1: 2, None: 5}
"""

# Generated at 2022-06-21 17:45:05.731287
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    result = DictUnpackingTransformer().visit_Module(None)
    assert result.body[0].as_string() == merge_dicts().get_body()[0].as_string()


# Generated at 2022-06-21 17:45:10.743850
# Unit test for method visit_Module of class DictUnpackingTransformer