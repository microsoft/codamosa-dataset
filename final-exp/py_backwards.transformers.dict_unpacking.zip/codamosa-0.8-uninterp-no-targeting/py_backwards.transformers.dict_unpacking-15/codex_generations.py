

# Generated at 2022-06-21 17:35:15.100617
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
  """Tests visit_Module method of DictUnpackingTransformer."""
  s = """
{1: 1, **dict_a}
"""

# Generated at 2022-06-21 17:35:19.714538
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree_to_test = ast.parse('{1: 1, **\n{"1": 1}, 2 : 2}')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree_to_test)  # type: ignore
    print(ast.dump(result, annotate_fields=False, include_attributes=False))
    # test_transform_tree.DictUnpackingTransformer_visit_Module.<locals>.<lambda>
    # (test_transform_tree.py:68)

# Generated at 2022-06-21 17:35:24.306872
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dut = DictUnpackingTransformer()
    assert isinstance(dut, DictUnpackingTransformer)
    assert '_py_backwards_merge_dicts' in dut.__dict__


# Generated at 2022-06-21 17:35:30.668251
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transform = DictUnpackingTransformer()

    source = """
    {1: 1, **dict_a}
    """
    result = transform(source)
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert result == expected

    source = """
    {1: 1, **{}, 2: 2, **dict_a}
    """
    result = transform(source)
    expected = """
    _py_backwards_merge_dicts([{1: 1}, dict(), {2: 2}], dict_a)
    """
    assert result == expected

    source = """
    {1: 1, **{}, 2: 2, 3: 3}
    """
    result = transform(source)

# Generated at 2022-06-21 17:35:31.131579
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    ...

# Generated at 2022-06-21 17:35:40.439815
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import AST, Module, Expr
    from typed_ast.ast3 import Store, Name, Call, List, Num
    from typed_ast.ast3 import FunctionDef, Load, keyword, arg
    from typed_ast import util
    import types
    import astor

    def run(self, node: AST) -> AST:
        tree = DictUnpackingTransformer().visit(node)  # type: ignore
        module = ast.Module(body=tree.body)  # type: ignore
        # log.debug(astor.to_source(module))
        c = compile(module, '<test>', 'exec')
        code = util.decode_utf8(c.co_code)
        # log.debug(dis.code_info(code))

# Generated at 2022-06-21 17:35:52.297194
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    l = ast.parse("_d = {'a': 1, **_b, **_c}").body[0]  # type: ignore
    l = DictUnpackingTransformer().visit(l)  # type: ignore

# Generated at 2022-06-21 17:35:59.826117
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from compiler.ast import Module
    from compiler.visitor import ASTVisitor

    from ..visitors import visitor_factory

    DUT = DictUnpackingTransformer()

    # Test for visiting module
    class TestVisitor(ASTVisitor):
        def __init__(self, tree):
            self.tree = tree
            self.path = []
            self.visitor = visitor_factory(tree)
            self.generic_visit = self.visitor.generic_visit

    test_tree = Module('''
{
    'a': 1,
    **{
        'b': 2,
        'c': 3,
    },
    'd': 4,
    **{
        'e': 5,
        'f': 6,
    }
}
''')


# Generated at 2022-06-21 17:36:01.864259
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    tr = DictUnpackingTransformer()
    print(tr)

# Generated at 2022-06-21 17:36:07.480861
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_in, assert_not_in
    from ..utils.ast import convert_to_ast
    transformer = DictUnpackingTransformer()
    # OrderedDict check
    module_str, expected_str = """\
        {1: 1, **dict_a, **dict_b, 2: 2, **dict_c}
    """, """\
        _py_backwards_merge_dicts(
            [{1: 1}],
            dict_a,
            dict_b,
            {2: 2}],
            dict_c)
    """
    tree = transformer.visit(convert_to_ast(module_str))
    assert_in(expected_str, tree)
    # Dict check

# Generated at 2022-06-21 17:36:18.997463
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    
    source = """{1: 1, **dict_a}"""
    expected = """dict()
# -
_py_backwards_merge_dicts(
    [{1: 1}, dict_a])"""
    
    assert transform(DictUnpackingTransformer, source) == expected


# Generated at 2022-06-21 17:36:30.864839
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.pygram import compile_
    from ..utils.source import assign

    source = '''
        dict_a = {1: 1, 2: 2}
        dict_b = {**dict_a, 3: 3}
    '''
    node = compile_(source)
    transformer = DictUnpackingTransformer()
    node = transformer.visit(node)  # type: ignore

    assert '_py_backwards_merge_dicts(' in assign(node, 'dict_b').value.func.id
    assert 3 == len(assign(node, 'dict_b').value.args[0].elts)
    assert 1 == len(assign(node, 'dict_b').value.keywords)

# Generated at 2022-06-21 17:36:40.978024
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-21 17:36:42.557694
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import parse


# Generated at 2022-06-21 17:36:48.696939
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from test_transformer import transform_function
    from ..utils.test_utils import assert_python_source_equal

    def test_function():
        assert _py_backwards_merge_dicts([{1: 2}, {2: 3}, {4: 5}, {7: 9}]) == \
               {1: 2, 2: 3, 4: 5, 7: 9}


    assert_python_source_equal(
        transform_function(test_function, DictUnpackingTransformer),
        """
        def test_function():
            assert _py_backwards_merge_dicts([{1: 2}, {2: 3}, {4: 5}, {7: 9}]) == \
                   {1: 2, 2: 3, 4: 5, 7: 9}
        """.lstrip()
    )


#

# Generated at 2022-06-21 17:36:50.543172
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:37:01.884231
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:37:09.007347
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse("""{1: 1, **dict_a}""")
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    expected = ast.parse("""def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n{1: 1, **dict_a}""")
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-21 17:37:10.917272
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert isinstance(t, BaseNodeTransformer)



# Generated at 2022-06-21 17:37:22.731331
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse("""
        {1: 1, None: dict_a, 2: 2, None: dict_c, 3: None}
    """)
    DictUnpackingTransformer().visit(module)  # type: ignore
    assert ast.dump(module) == dedent("""\
        Module(body=[
            _py_backwards_merge_dicts([
                Dict(keys=[
                    Num(n=1),
                    Num(n=2),
                    Num(n=3)],
                values=[
                    Num(n=1),
                    Num(n=2),
                    None()]),
                dict_a,
                dict_c
            ])
        ])
    """)

# Generated at 2022-06-21 17:37:46.993942
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    def module0(a: int): pass

    def module1(a: int):
        return {
            'x': 1,
            **args,
        }

    def module2(a: int):
        return {
            'x': 1,
            **args,
            'y': 2,
        }

    def module3(a: int):
        return {
            'x': 1,
            **args,
            **kwargs,
            'y': 2,
        }

    def module4(
            a: int,
            b: str,
            c: int,
            **kwargs):
        return {
            'x': 1,
            **args,
            'y': 2,
        }


# Generated at 2022-06-21 17:37:54.264532
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    ast_tree = ast.parse("""
    {1: 1, 2: 2, 3: 3}
    """)

    transformer = DictUnpackingTransformer()
    result = transformer.visit(ast_tree) # type: ignore

    assert transformer._tree_changed
    assert result != ast_tree

# Generated at 2022-06-21 17:37:57.062761
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """Constructor of class DictUnpackingTransformer must not throw
    exception.
    """

    DictUnpackingTransformer()


# Unit tests for method _split_by_None of class DictUnpackingTransformer

# Generated at 2022-06-21 17:38:03.151521
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # type: () -> None
    from .test_transformers import some_transform
    from .wrapping import ExprWrapperTransformer
    from .remove_literals import RemoveLiteralsTransformer

    source = '{1: 2, 3: 4, 5: 6, **dict_a, **dict_b, 7: 8}'
    expected = '_py_backwards_merge_dicts([{1: 2, 3: 4, 5: 6}], dict_a, dict_b, {7: 8})'
    assert some_transform(source, [
        ExprWrapperTransformer,
        RemoveLiteralsTransformer,
        DictUnpackingTransformer]) == expected

# Generated at 2022-06-21 17:38:14.929615
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseTreeTransformer
    from .base import BaseTreeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor
    from .base import TreeTransformer

    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)
    assert issubclass(DictUnpackingTransformer, NodeTransformer)
    assert issubclass(DictUnpackingTransformer, BaseNodeVisitor)
    assert issubclass(DictUnpackingTransformer, NodeVisitor)
    assert issubclass(DictUnpackingTransformer, BaseTreeTransformer)
    assert issubclass(DictUnpackingTransformer, TreeTransformer)
    assert issubclass(DictUnpackingTransformer, BaseTreeVisitor)

# Generated at 2022-06-21 17:38:16.409196
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass



# Generated at 2022-06-21 17:38:25.620606
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    expected = ast.Module(
        body=[
            merge_dicts.get_body()[0],
            ast.Dict(keys=[None, None], values=[ast.Name(id='a'), ast.Name(id='b')]),
            ast.Dict(keys=[None, None], values=[ast.Name(id='a'), ast.Name(id='b')])
        ],
        type_ignores=[])

    source = ast.Module(
        body=[
            ast.Dict(keys=[None, None], values=[ast.Name(id='a'), ast.Name(id='b')]),
            ast.Dict(keys=[None, None], values=[ast.Name(id='a'), ast.Name(id='b')])
        ],
        type_ignores=[])


# Generated at 2022-06-21 17:38:31.867735
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse('''
        d = {1: 2, **{3: 4}, **{5: 6}, 7: 8}''')  # type: ignore

# Generated at 2022-06-21 17:38:38.964955
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """\
        one = 1
        two = 2
        three = 3
        data = {one: one, **{two: two, three: three}}
        """
    expected = """\
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        one = 1
        two = 2
        three = 3
        data = _py_backwards_merge_dicts([{one: one}, {two: two}, three])
        """
    module = ast.parse(source)
    module = DictUnpackingTransformer().visit(module)  # type: ignore
    assert ast.dump(module) == expected

# Generated at 2022-06-21 17:38:40.535125
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    c = DictUnpackingTransformer(None)
    assert c is not None

# Generated at 2022-06-21 17:39:11.692935
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_with_printing
    from ..utils.test_utils import transform

    original = parse("""
    d = {1: 1, **{2: 2}, 3: 3, **{4: 4}, **{5: 5}, 6: 6}
    """)

    expected = parse("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    d = _py_backwards_merge_dicts([{1: 1}, {2: 2}, {3: 3}, {4: 4}], {5: 5}, {6: 6})
    """)


# Generated at 2022-06-21 17:39:22.865184
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = '{1: 2, **a, 3: 4, **b, 5: 6, **c}'
    compiled = '_py_backwards_merge_dicts([{1: 2, 3: 4, 5: 6}], a, b, c)'
    ast_compiled = ast.parse(compiled)
    ast_code = ast.parse(code)
    t = DictUnpackingTransformer()
    node_code = t.visit(ast_code)  # type: ignore
    assert ast.dump(node_code, include_attributes=True) == ast.dump(
        ast_compiled, include_attributes=True)
    assert isinstance(node_code, ast.Expression)
    assert isinstance(node_code.body, ast.Call)

# Generated at 2022-06-21 17:39:31.465040
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import parse
    from ..utils.testutil import check_equal, compare_ast, check_equal_stringified

    tree = parse("{1: 1, **dict_a}")
    tree = DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-21 17:39:39.430380
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import Dict, Name, Num, parse
    from .. import to_source, run_pipeline

    expected = parse('''
        _py_backwards_merge_dicts([{'abc': 3, 'def': 4}], xyz)
    ''')
    module = parse('''
        def foo(xyz): 
            {'abc': 3, 'def': 4, **xyz}
    ''')

    run_pipeline(module, [DictUnpackingTransformer])
    actual = module.body[0].body[0].value

    assert to_source(expected) == to_source(actual)


# Generated at 2022-06-21 17:39:40.129947
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:39:41.268260
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a = DictUnpackingTransformer()
    assert a is not None

# Generated at 2022-06-21 17:39:50.793217
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer._split_by_None([]) == [[]]
    assert transformer._split_by_None([(None, ast.Dict())]) == [
        [], ast.Dict(), []]
    assert transformer._split_by_None([(1, 2)]) == [[(1, 2)]]
    assert transformer._split_by_None(
        [(1, 2), (3, 4), (None, ast.Dict()), (5, 6)]) == [
            [(1, 2), (3, 4)], ast.Dict(), [(5, 6)]]



# Generated at 2022-06-21 17:39:54.451825
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import run_in_context
    from .example import dict_unpacking
    assert dict_unpacking.__doc__

    source = dict_unpacking.__doc__.strip()
    actual = run_in_context(source, DictUnpackingTransformer)

# Generated at 2022-06-21 17:40:05.884843
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..tools.testing import assert_parsed

    test_cases = [
        """{}""",
        """{1: 2, **{1: 3}}""",
        """{1: 2, **{1: 3, 2: 4}, 5: 6}"""
    ]

    for code in test_cases:
        assert_parsed(DictUnpackingTransformer, code, '''
            from_future_import_absolute_import
            from_future_import_division
            from_future_import_print_function
            def _py_backwards_merge_dicts(dicts):
                result = {}
                for dict_ in dicts:
                    result.update(dict_)
                return result
            ''' + code, fix_code=True)


# Generated at 2022-06-21 17:40:06.706625
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:40:41.869540
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-21 17:40:43.942259
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None


# Generated at 2022-06-21 17:40:50.994230
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """
    >>> trans = DictUnpackingTransformer()
    >>> expr = ast.parse('''{1: 2, **a, 1: 2}''').body[0].value
    >>> stmt = ast.parse('''a = {1: 2, **a, 1: 2}''').body[0]
    >>> expr2 = ast.parse('''{1: 2, 1: 2}''').body[0].value
    >>> assert trans.visit(expr) != expr
    >>> assert trans.visit(stmt) != stmt
    >>> assert trans.visit(expr2) == expr2
    """
    pass

# Generated at 2022-06-21 17:40:52.579857
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), BaseNodeTransformer)

# Generated at 2022-06-21 17:41:00.984349
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..minifier import minify
    assert minify('''\
    {None: 1, 2: 3, **{4: 5, 6: 7}}
    ''', transformers=(DictUnpackingTransformer)) == \
        '_py_backwards_merge_dicts([{2: 3}, {4: 5, 6: 7}])'
    assert minify('''\
    {None: 1, **{}, 2: 3, **{4: 5, **{6: 7}}}
    ''', transformers=(DictUnpackingTransformer)) == \
        '_py_backwards_merge_dicts([{2: 3}, {4: 5}, {6: 7}])'

# Generated at 2022-06-21 17:41:02.040702
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    _ = DictUnpackingTransformer()

# Generated at 2022-06-21 17:41:11.213810
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # This snippet shows the code before transformation
    @snippet
    def before():
        a = {'a': 2, **{'b': 3}}

    # This snippet shows the code after transformation
    @snippet
    def after():
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        a = _py_backwards_merge_dicts([{'a': 2}], {'b': 3})
    
    tree = DictUnpackingTransformer().visit(before.get_ast())  # type: ignore
    assert ast.dump(tree, include_attributes=True) == ast.dump(after.get_ast(), include_attributes=True)



# Generated at 2022-06-21 17:41:21.146066
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    def test_data():
        """
        Тестовые данные для теста test_DictUnpackingTransformer_visit_Module
        """
        yield """
            {}
        """.format(
            merge_dicts.get_body()
        )


# Generated at 2022-06-21 17:41:30.722010
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    def visit(source: str) -> str:
        module = parse(source)
        node = module.body[0]
        node = DictUnpackingTransformer().visit(node)  # type: ignore
        return to_source(node)

    assert visit('{1: 1, **{2: 2}}') == '_py_backwards_merge_dicts([{1: 1}], {2: 2})'
    assert visit('{**{1: 1}, 2: 2}') == '_py_backwards_merge_dicts([{1: 1}], {2: 2})'

# Generated at 2022-06-21 17:41:36.973642
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """\
    a = {1: 1}
    """
    expected = """\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    a = {1: 1}
    """
    node = ast.parse(dedent(code))
    DictUnpackingTransformer().visit(node)
    actual = astunparse.unparse(node)
    assert expected == actual



# Generated at 2022-06-21 17:43:33.596986
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    dict_ = {1: "1", 2: "2", **{3: "3", 4: "4"}}
    node = ast.parse(str(dict_)).body[0]
    merged = transformer.visit(node)
    expected = ast.parse("_py_backwards_merge_dicts([{1: '1', 2: '2'}], {3: '3', 4: '4'})")
    assert ast.dump(expected, annotation=False) == ast.dump(merged, annotation=False)

# Generated at 2022-06-21 17:43:40.923545
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3, parse

    src = """\
    def foo(a):
        return {1: 1, 2: 2, 3: 3, **a}
    """
    expected = """\
    def foo(a):
        return _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], a)
    """

    tree = parse(src)
    DictUnpackingTransformer().visit(tree)
    assert ast3.dump(tree) == expected

# Generated at 2022-06-21 17:43:52.980343
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source_to_code
    from ..utils.visitor import copy_visit
    from .remove_unused_imports import RemoveUnusedImportsTransformer

    code = """
    import os
    import sys
    import time

    def test(arg):
        return {'a': 1, 'b': 2, **arg}

    test({})
    """
    tree = source_to_code(code)
    tree = DictUnpackingTransformer().visit(tree)
    print(ast.dump(tree))
    tree = RemoveUnusedImportsTransformer().visit(tree)
    print(ast.dump(tree))
    code = copy_visit(tree)
    assert not getattr(code, '__future__', None)

# Generated at 2022-06-21 17:43:53.448774
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    pass

# Generated at 2022-06-21 17:44:04.405867
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    # Given
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module, Name, Dict, Call, List, Num

    # When

# Generated at 2022-06-21 17:44:06.806287
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    # nonsense, to satisfy code coverage
    assert transformer.__doc__
    assert transformer.__module__

# Generated at 2022-06-21 17:44:07.431836
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-21 17:44:08.475199
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:44:17.343618
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('''
    d1 = {1: 1, **dict_a}
    d2 = {**dict_a}
    d3 = {1: 1, 2: 2, **dict_a, **dict_b}
    ''')
    DictUnpackingTransformer().visit(module)
    result = ast.dump(module)

# Generated at 2022-06-21 17:44:19.025542
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().__class__.__name__ == 'DictUnpackingTransformer'
