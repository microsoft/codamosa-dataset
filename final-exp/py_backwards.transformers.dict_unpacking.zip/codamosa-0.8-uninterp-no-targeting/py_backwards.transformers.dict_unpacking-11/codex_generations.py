

# Generated at 2022-06-21 17:35:20.176853
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import parse

    transformer = DictUnpackingTransformer()

# Generated at 2022-06-21 17:35:22.601440
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert isinstance(transformer, DictUnpackingTransformer)

# Generated at 2022-06-21 17:35:25.083276
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''{1: 1, **dict_a}'''

# Generated at 2022-06-21 17:35:28.946762
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .unittest_tools import assert_changed

    input_ = '{1: 1, **dict_a}'
    expected_output = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    output, _ = assert_changed(DictUnpackingTransformer, input_)
    assert output == expected_output



# Generated at 2022-06-21 17:35:41.327188
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from .test_utils import round_trip
    node = ast3.Dict(
        keys=[None, ast3.Num(1), None, ast3.Num(2)],
        values=[ast3.Dict(keys=[], values=[]),
                ast3.Dict(keys=[ast3.Str("a")],
                          values=[ast3.Str("b")]),
                ast3.Dict(keys=[ast3.Num(3)], values=[ast3.Num(4)]),
                ast3.Dict(keys=[], values=[])])

    result = round_trip(node)
    assert isinstance(result, ast3.Call)
    args, = result.args
    assert isinstance(args, ast3.List)

# Generated at 2022-06-21 17:35:52.760311
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:36:00.143695
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    visit_Module = DictUnpackingTransformer().visit_Module

# Generated at 2022-06-21 17:36:01.641135
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    return DictUnpackingTransformer()

# Generated at 2022-06-21 17:36:03.994521
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert DictUnpackingTransformer(None).visit_Module(
        ast.Module(body=[ast.Pass()])) == \
        ast.Module(body=[merge_dicts.get_body(), ast.Pass()])


# Generated at 2022-06-21 17:36:11.225348
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor

    module = ast.parse('{1:1, **{1:1, 2:2}, 2:2}')
    expected = ast.parse(
        ''.join(
            line.lstrip()
            for line in merge_dicts().get_body() + [  # type: ignore
                '{1: 1, **_py_backwards_merge_dicts([{1: 1, 2: 2}], {2: 2})}'
            ]
        )
    )
    DictUnpackingTransformer().visit(module)
    assert astor.to_source(module) == astor.to_source(expected)

# Generated at 2022-06-21 17:36:19.862691
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse("""\
    {1: 1, **dict_a}
    """)
    DictUnpackingTransformer().visit(node)

    assert node == ast.parse("""\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a})
    """)


# Generated at 2022-06-21 17:36:28.835854
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from ..utils.dump import dump

    content = """\
{1: 1, **dict_a}
"""
    node = parse(content, mode='eval')  # type: ast.Expression
    node = DictUnpackingTransformer().visit(node)  # type: ignore
    assert dump(node) == """\
_py_backwards_merge_dicts([{1: 1}], dict_a)
"""

# Generated at 2022-06-21 17:36:40.243697
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('{1: 1, **{2: 2}}')
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-21 17:36:50.425411
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert not DictUnpackingTransformer()._split_by_None([])
    assert DictUnpackingTransformer()._split_by_None([(1, 1)]) == \
        [[(1, 1)]]
    assert DictUnpackingTransformer()._split_by_None([(1, 1), (None, 2), (3, 4)]) == \
        [[(1, 1)], 2, [(3, 4)]]
    assert DictUnpackingTransformer()._split_by_None([(None, 2), (3, 4)]) == \
        [2, [(3, 4)]]
    

# Generated at 2022-06-21 17:37:01.826549
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_utils import assert_equal_ast
    from ..utils.tree import parse

    for source in [
        '{**a}',
        '{1: 1, **a}',
        '{1: 1, 2: 2, **a}',
        '{**a, **b}',
        '{1: 1, **a, **b}',
        '{**a, 1: 1, **b}',
        '{1: 1, **a, 2: 2, **b}',
    ]:
        transpiled = DictUnpackingTransformer().visit(parse(source))
        assert_equal_ast(transpiled,
                         merge_dicts() + '\n' + source.replace('**', '_py_backwards_merge_dicts(['))

# Generated at 2022-06-21 17:37:03.199537
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None)

# Generated at 2022-06-21 17:37:04.393354
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    return DictUnpackingTransformer()



# Generated at 2022-06-21 17:37:14.471402
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTest, MultiNodeTest
    from ..utils.tree import get_ast, dump
    

# Generated at 2022-06-21 17:37:22.306929
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    t = DictUnpackingTransformer()

    dict_ = ast.parse('{1: 1, **dict_a, **dict_b, 2: 2, **dict_c}').body[0]
    assert ast.dump(t.visit(dict_), annotate_fields=False) == \
        ast.dump(ast.parse('_py_backwards_merge_dicts([{1: 1, 2: 2}], '
                           'dict_a, dict_b, dict_c)'), annotate_fields=False)


# Generated at 2022-06-21 17:37:24.454516
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import sys
    sys.exit(0)



# Generated at 2022-06-21 17:37:36.974218
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..conftest import _convert_to_ast
    from ast_tools.visitors import DictUnpackingTransformer

    tree = _convert_to_ast(
        '''
        a = {1: 1, **dict_a}
        b = {2: 2, **dict_b, **dict_c}
        c = {*list_a}
        d = {4: 4, **dict_d, **dict_e}
        ''')
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-21 17:37:37.986010
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-21 17:37:45.002631
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    src = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
    """
    expr = """
        {1: 1, **dict_a}
    """

    tree = ast.parse(expr)
    DictUnpackingTransformer().visit(tree)
    result = compile(tree, filename="<ast>", mode="exec")
    expected = compile(src + expr, filename="<ast>", mode="exec")
    assert result == expected


# Generated at 2022-06-21 17:37:51.740838
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = '''{1: 2, **{3: 4}}'''
    expected = '''def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result
{1: 2, _py_backwards_merge_dicts([{3: 4}])}'''
    node = ast.parse(source)
    node = DictUnpackingTransformer().visit(node)
    assert astor.to_source(node) == expected


# Generated at 2022-06-21 17:37:54.714466
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    visit_Module = DictUnpackingTransformer().visit_Module


# Generated at 2022-06-21 17:37:55.948243
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer.__doc__



# Generated at 2022-06-21 17:38:02.414319
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # type: () -> None
    source = """\
    {1: 1, **{2: 2}, 3: 3, **{4: 4}, 5: 5, **{6: 6}}
    """
    expected = """\
    _py_backwards_merge_dicts([{1: 1, 3: 3, 5: 5}], {2: 2}, {4:  4}, {6: 6})
    """

    from typed_ast import parse
    from ..utils.ast_tools import format_ast

    tree = parse(source)
    assert DictUnpackingTransformer().visit(tree)
    assert format_ast(tree) == expected



# Generated at 2022-06-21 17:38:14.019347
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from astunparse import unparse
    from astmonkey import transformers

    node = ast.parse("""
    {1: 1, **dict_a}
    """)
    transformer = DictUnpackingTransformer()
    output = transformer.visit(node)
    assert isinstance(output, ast.Module)
    output = transformers.ParentChildNodeTransformer().visit(output)
    assert isinstance(output, ast.Module)
    output = transformers.SyntaxErrorTransformer().visit(output)
    assert isinstance(output, ast.Module)
    result = unparse(output)
    assert result == '\n\n\n_py_backwards_merge_dicts([{1: 1}], dict_a)\n'


# Generated at 2022-06-21 17:38:14.550320
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Test constructor
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:38:20.699572
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse("""{1: 1, **dict_a, 2: 2, **dict_b}""")
    transformer = DictUnpackingTransformer()
    res = transformer.visit(node)
    assert(transformer._tree_changed)
    expected = ast.parse("""{}""").body[0]

    assert(ast.dump(expected) == ast.dump(res))


# Generated at 2022-06-21 17:38:33.275822
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    test_cases = [
        (
            '{x: 1, y: 2, **dict_a}',
            '_py_backwards_merge_dicts([{"x": 1, "y": 2}], dict_a)'
        ),
        (
            '{x: 1, **dict_a, y: 2, **dict_b, z: 3}',
            '_py_backwards_merge_dicts([{"x": 1}, dict_a, {"y": 2}, dict_b, '
            '{"z": 3}])'
        )
    ]

    for source_code, required_result in test_cases:
        source_tree = ast.parse(source_code)
        transformed_tree = transformer.visit(source_tree)
        transformed_

# Generated at 2022-06-21 17:38:33.968132
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a = DictUnpackingTransformer()
    assert a is not None


# Generated at 2022-06-21 17:38:38.289076
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import dedent
    from ..utils.validation import validate

    # 'None' unpacking
    s = """
    def f():
        return {2: 3, **{4: 5}}
    """
    expected = """
    def f():
        return _py_backwards_merge_dicts([{2: 3}], {4: 5})
    """
    validate(dedent(s), dedent(expected), [DictUnpackingTransformer])

    # 'None' and 'None' unpacking
    s = """
    def f():
        return {2: 3, **{4: 5}, **{6: 7}}
    """

# Generated at 2022-06-21 17:38:44.618160
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    result = DictUnpackingTransformer().visit(ast.parse('d = {1: 1, **a}'))
    assert ast.dump(result) == ast.dump(ast.parse('''
        import _py_backwards_merge_dicts
        d = _py_backwards_merge_dicts([{1: 1}], a)
    '''))


# Generated at 2022-06-21 17:38:46.438296
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-21 17:38:56.781089
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()

    # Tree is not changed
    removed_none, tree = ast.parse('a = 1')
    t.visit(tree)
    assert not t._tree_changed
    assert removed_none.body[0] == tree.body[0]

    # One dict unpacking
    removed_none, tree = ast.parse('a = {1: 1, **dict_a}')
    t.visit(tree)
    assert t._tree_changed
    assert removed_none.body[0] == tree.body[0]
    assert isinstance(tree.body[0].value, ast.Call)

    # Multiple dict unpacking
    removed_none, tree = ast.parse('a = {1: 1, 2: 2, **dict_a, **dict_b}')

# Generated at 2022-06-21 17:39:06.393825
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse(
        """
            {1: 1, **dict_a}
        """
    )
    expected = ast.parse(
        """
            def _py_backwards_merge_dicts(dicts):
                result = {}
                for dict_ in dicts:
                    result.update(dict_)
                return result


            _py_backwards_merge_dicts([{1: 1}], dict_a)
        """
    )
    result = DictUnpackingTransformer().visit(node)
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-21 17:39:08.469014
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ast import parse
    before = parse("""{1: 1, 2: 2}""")


# Generated at 2022-06-21 17:39:19.624395
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = [[[{1: 1}], [[[None, {'a': 2, **{'b': 2, 'c': 2}}, {'d': 2, 'e': 2}]], [['1', [{'2': 3}]], [[dict({}), None]]]]]]

# Generated at 2022-06-21 17:39:30.172887
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    from ..utils.source import put_in_module, get_module_ast
    from ..tests.test_transformers import parse_to_end_node
    from typing import Any, List, Optional

    code = '''
        {
            None: 1,
            2: 2,
            None: None,
            None: 3,
            4: 4,
        }
    '''
    expected = '''
        _py_backwards_merge_dicts(
            [
                {
                    2: 2,
                    4: 4,
                },
                None,
                {3: 3},
            ],
        )
    '''
    result = parse_to_end_node(code, DictUnpackingTransformer)
    assert isinstance(result, ast.Call)

# Generated at 2022-06-21 17:39:56.050637
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None)

# Generated at 2022-06-21 17:39:57.041321
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:40:01.407993
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{1: 2, 3: 4, **dict_a}')
    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-21 17:40:02.440739
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:40:03.888953
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().target == (3, 4)



# Generated at 2022-06-21 17:40:10.943316
# Unit test for constructor of class DictUnpackingTransformer

# Generated at 2022-06-21 17:40:13.246193
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()


# Unit tests for method _split_by_None of class DictUnpackingTransformer

# Generated at 2022-06-21 17:40:19.174763
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    result = transformer.visit(
        ast.parse('''{1: 1, **dict_a}''', mode='exec'))
    assert ast.dump(result) == \
        'Module(body=[FunctionDef(name=\'_py_backwards_merge_dicts\', ' \
        'args=arguments(args=[arg(arg=\'dicts\', annotation=None)], ' \
        'vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), ' \
        'body=[Assign(targets=[Name(id=\'result\', ctx=Store())], ' \
        'value=Dict(keys=[], values=[])), For(target=Name(id=\'dict_\', '

# Generated at 2022-06-21 17:40:25.541131
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = ast.parse("{1: 2, **dict_a}")
    node = _transform(x)
    assert _is_equal(node, ast.Call(func=ast.Name(id='_py_backwards_merge_dicts'),
                                    args=[ast.List(elts=[
                                        ast.Call(func=ast.Name(id='dict'),
                                                 args=[ast.Num(n=1)],
                                                 keywords=[]),
                                        ast.Name(id='dict_a')])],
                                    keywords=[]))



# Generated at 2022-06-21 17:40:36.033066
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
    result = {'a': 1, 'b': 2, **{'c': 3}, **{'d': 4}, **{'e': 5}}
    """
    node = ast.parse(code)
    DictUnpackingTransformer().visit(node)

    expected = """
    from typed_ast import ast3 as ast
    
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    
    
    result = _py_backwards_merge_dicts([{'a': 1, 'b': 2}, {'c': 3}, {'d': 4}, {'e': 5}])
    """
    expected = ast.parse(expected)
    assert ast.dump

# Generated at 2022-06-21 17:41:18.066486
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse(
        dedent(
            """\
            def _py_backwards_merge_dicts(dicts):
                result = {}
                for dict_ in dicts:
                    result.update(dict_)
                return result
            
            
            _py_backwards_merge_dicts([{1: 1}], dict_a)
            """))
    DictUnpackingTransformer.apply(node)
    assert ast_equivalent(node, expected)

# Generated at 2022-06-21 17:41:23.985072
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    class CaptureLineNumberVisitor(ast.NodeVisitor):
        def visit(self, node):
            super().visit(node)
            if hasattr(node, 'lineno'):
                self.line_numbers.append(node.lineno)

    tree = ast.parse(merge_dicts())
    visitor = CaptureLineNumberVisitor()
    visitor.line_numbers = []
    visitor.visit(tree)
    assert visitor.line_numbers[0] == 1

# Generated at 2022-06-21 17:41:32.312576
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ast import Module, Expr, Dict, List, Name, Call, Num

# Generated at 2022-06-21 17:41:39.185837
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3
    from ..queryset import QuerySet
    from ..utils.tree import print_tree

    code = '{x: y, **z}'

    tree = ast.parse(code)  # type: ast3.Module
    tree = QuerySet(tree).transform(DictUnpackingTransformer).get_root()

    assert '_py_backwards_merge_dicts({x: y}, z)' in print_tree(tree)


# Generated at 2022-06-21 17:41:39.800465
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:41:41.414847
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert t is not None

# Generated at 2022-06-21 17:41:48.627152
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..test.test_utils import _format

    actual = DictUnpackingTransformer().visit(_format("""\
    {1:1, **a, 2:2, **b, 3:3}
    """))
    expected = _format("""\
    _py_backwards_merge_dicts([{1: 1, 2: 2}, a, {2: 2, 3: 3}, b, {3: 3}])
    """)
    assert str(actual) == expected

# Generated at 2022-06-21 17:41:59.635829
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.tree import parse_tree, compare_trees
    from .base import NodeTransformer

    script = """
        {1: 2, 3: 4, **{5: 6}, None: 7, 8: 9, **{None: 10, 11: 12}}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 2, 3: 4}, {5: 6}, {None: 7, 8: 9}], {None: 10, 11: 12})
    """
    node_transformer = NodeTransformer.from_class(DictUnpackingTransformer)
    result = node_transformer.run(script)
    compare_trees(result, parse_tree(expected))

test_DictUnpackingTransformer()

# Generated at 2022-06-21 17:42:01.158465
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    class_ = DictUnpackingTransformer()
    assert_equal(isinstance(class_, BaseNodeTransformer), True)

# Generated at 2022-06-21 17:42:10.534834
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast as python_ast
    import textwrap
    source = textwrap.dedent("""
    def foo():
        {1: 1, **dict_a}
        {2: 2, 3: 3, **dict_b, 4: 4, **dict_c, 5: 5}
    """)
    code = compile(source, '<string>', 'exec')
    tree = python_ast.parse(code)
    tree_changed, tree = DictUnpackingTransformer().visit(tree)


# Generated at 2022-06-21 17:44:10.723408
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    x = ast.parse('{1: 1, **{2: 2}}')
    node = DictUnpackingTransformer.visit_Module(DictUnpackingTransformer(), x)
    x = ast.parse('{1: 1}')
    assert node.body[0] == x.body[0]
    assert node.body[1] == x.body[0]
    assert node.body[2] == x.body[0]


# Generated at 2022-06-21 17:44:18.532353
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    source = """
    def f(x):
        return {1: x, 2: x, **{}, **dict(a=1, b=2), 3: 3}
    """
    expected = """
    def f(x):
        return _py_backwards_merge_dicts([{1: x, 2: x}], {}, dict(a=1, b=2), {3: 3})
    """
    tree = ast.parse(source)  # type: ignore
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-21 17:44:25.399263
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = get_ast("""
# TARGET
# start
{1: 2, **a, **{3: 4}, 5: 6}
# end
    """)
    result = ast.dump(DictUnpackingTransformer().visit(tree))

# Generated at 2022-06-21 17:44:34.097796
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    d = ast.Dict(
        keys=[ast.Num(n=1), None, None, ast.Name(id='a'), ast.Name(id='b')],
        values=[ast.Num(n=1), ast.Name(id='b'), ast.Name(id='c'), ast.Num(n=2), ast.Num(n=3)])
    res = DictUnpackingTransformer().visit(d)

# Generated at 2022-06-21 17:44:39.874265
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .snippets import DictUnpackingTransformerSnippets
    from ..utils.test_utils import assert_ast
    before = DictUnpackingTransformerSnippets.variant1.before
    after = DictUnpackingTransformerSnippets.variant1.after
    assert_ast(after, DictUnpackingTransformer().visit(before))

# Generated at 2022-06-21 17:44:45.162318
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''
        {a: 1, b: 1}
        {a: 1, **b}
        {a: 1, **b, c: 1, **d}
        {a: 1, **b, c: 1, d: 1}
    '''

    expected = '''
        {a: 1, b: 1}
        _py_backwards_merge_dicts([{a: 1}], b)
        _py_backwards_merge_dicts([{a: 1, c: 1}, d], b)
        {a: 1, **b, c: 1, d: 1}
    '''

    expected_ast = ast.parse(expected)  # type: ignore
    actual_ast = DictUnpackingTransformer().visit(ast.parse(source))  # type: ignore
   

# Generated at 2022-06-21 17:44:55.303207
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def test(pre, post):
        tree = ast.parse(pre)  # type: ast.AST
        result = DictUnpackingTransformer().visit(tree)
        assert ast.dump(result) == post

    test('{**a}', '_py_backwards_merge_dicts([], a)')
    test('{1: 1, **a}', '_py_backwards_merge_dicts([{1: 1}], a)')
    test('{1: 1, 2: 2, **a}', '_py_backwards_merge_dicts([{1: 1, 2: 2}], a)')
    test('{**a, **b}', '_py_backwards_merge_dicts([], a, b)')

# Generated at 2022-06-21 17:45:07.263235
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import get_call_ast
    from ..utils.unparse import Unparser
    from ..utils.test_utils import assert_code_equal

    # Let's test the most complicated case, when the dict has a few unpacking
    # operators.
    code = """
        a = {1: 2, **b, **c, 4: 5}
    """
    compare_to = """
        _py_backwards_merge_dicts([{1:2},b,c,{4:5}])
    """
    actual_ast = DictUnpackingTransformer().visit(get_call_ast(code))
    actual_code = Unparser(actual_ast)
    assert_code_equal(actual_code, compare_to)

    # Test simple case, when there is just one unpacking operator.

# Generated at 2022-06-21 17:45:08.538581
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass


# Generated at 2022-06-21 17:45:18.405230
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from typed_ast.transforms import DictUnpackingTransformer
    from typed_ast import ast3 as ast
    node = ast.Module(body=[])