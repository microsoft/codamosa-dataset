

# Generated at 2022-06-21 17:35:17.505618
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert transform('{1: 1, **dict_a}') \
        == '_py_backwards_merge_dicts([{1: 1}], dict_a)'



# Generated at 2022-06-21 17:35:28.789609
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import load_and_compile_node

    transformer = DictUnpackingTransformer()
    node = load_and_compile_node('''{1: 1, 2: 2, 3: 3, **a, **b, 4: 4}''')
    result = transformer.visit(node)
    result = transformer.visit(result)

    assert isinstance(result.body[0].value, ast.Call)

    assert result.body[0].value.func.id == '_py_backwards_merge_dicts'
    args = result.body[0].value.args
    assert len(args) == 1 and isinstance(args[0], ast.List)
    assert len(args[0].elts) == 2


# Generated at 2022-06-21 17:35:30.814306
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    assert x


# Generated at 2022-06-21 17:35:38.516926
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """
        {1: 1, 2: **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """

    tree = ast.parse(code)
    DictUnpackingTransformer(tree).visit(tree)

    actual = ast.unparse(tree)

    assert expected == actual

# Generated at 2022-06-21 17:35:44.167352
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = textwrap.dedent('''\
        {}
    ''')
    expected = merge_dicts.dedent()

    module = ast.parse(code)
    assert DictUnpackingTransformer().visit(module) == ast.parse(expected)



# Generated at 2022-06-21 17:35:48.836022
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = ast.Dict(keys=[ast.Constant(value=1)], values=[ast.Constant(value=1)])
    assert isinstance(DictUnpackingTransformer().visit(x), ast.Dict)



# Generated at 2022-06-21 17:35:58.219873
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = \
        """
        {}
        """
    expected_tree = \
        """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        {}
        """
    assert tree_to_code(DictUnpackingTransformer().visit(parse(tree))) == tree_to_code(parse(expected_tree))


# Generated at 2022-06-21 17:36:03.884258
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transform = DictUnpackingTransformer()
    actual = transform.visit(ast.parse('{1: 1, **dict_a}'))
    assert eval(compile(actual, '', 'exec')) == {1: 1, 2: 2}

# Generated at 2022-06-21 17:36:04.843137
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer # type: ignore

# Generated at 2022-06-21 17:36:13.176883
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    ast_tree = ast.parse('''
    {x: x, **y}
    ''')

    DictUnpackingTransformer().visit(ast_tree)


# Generated at 2022-06-21 17:36:24.063194
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast.ast3 as ast
    node = ast.Module([ast.Expr(
            value=ast.Dict(
                keys=[ast.parse('''ast.Num(n=1)'''), None, ast.parse('''ast.Num(n=2)''')],
                values=[ast.parse('''ast.Num(n=1)'''), ast.parse('''ast.Dict(keys=[], values=[])'''), ast.parse('''ast.Num(n=4)''')],
                lineno=0,
                col_offset=0))])

# Generated at 2022-06-21 17:36:32.542202
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """{1: 1, **dict_a}"""
    expected = """def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result

_py_backwards_merge_dicts([{1: 1}], dict_a)
"""
    module = ast.parse(code)
    DictUnpackingTransformer().visit(module)
    print(ast.dump(module, include_attributes=True))
    assert ast.dump(module, include_attributes=True) == expected


# Generated at 2022-06-21 17:36:34.635817
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
{1: 1, 2: 2, **dict1}
"""

# Generated at 2022-06-21 17:36:42.780925
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.ast import ast_to_source
    from ..utils.snippet import get_body
    from ..utils.test_utils import parse_to_clean_tree

    def make_test(code: str, expected: str) -> None:
        tree = parse_to_clean_tree(code, mode='eval')
        DictUnpackingTransformer('').visit(tree)
        result = ast_to_source(tree)
        assert result == expected

    code = get_body(__file__, 'test_DictUnpackingTransformer_visit_Dict')
    result = get_body(__file__, 'test_DictUnpackingTransformer_visit_Dict', 'result')
    make_test(code, result)

# Generated at 2022-06-21 17:36:48.853751
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .helpers import node_changed
    import re
    import astor
    dicts = ast.parse('''
    {1: 1, **{'a': 1, 'b': 2}, **{'b': 3, 4: 1}}
    ''').body
    with node_changed():
        res = BaseNodeTransformer.visit(DictUnpackingTransformer(), dicts[0])
    assert ast.dump(res) == "Call(_py_backwards_merge_dicts, (List(Dict(), dict(a=1, b=2), dict(b=3, 4=1)),), ())"
    res = astor.to_source(res).replace('\n', '').replace(' ','')
    assert re

# Generated at 2022-06-21 17:36:50.610976
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:37:00.012995
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = ast.parse("{1: 1, 2: 2, **{3: 3, 4: 4}, 5: 5}")
    target = ast.parse("_py_backwards_merge_dicts([{1: 1, 2: 2}, {5: 5}], {3: 3, 4: 4})")

    def assert_node_equal(x: ast.AST, y: ast.AST) -> None:
        assert ast.dump(x) == ast.dump(y)

    assert_node_equal(DictUnpackingTransformer().visit(source), target)

# Generated at 2022-06-21 17:37:08.690907
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """\
    {1:2, 3:4}
    """
    expected = """\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    
    
    {1:2, 3:4}
    """
    assert expected == DictUnpackingTransformer(source).result


# Generated at 2022-06-21 17:37:16.631482
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .unpacking import UnpackingTransformer
    from ..utils.tree import dump
    from ..fix import fix
    assert fix(DictUnpackingTransformer, {}, """
    {**a, **b}""") == """
    _py_backwards_merge_dicts([], a, b)"""
    assert fix(DictUnpackingTransformer, {}, """
    {1: 2, **a, **b}""") == """
    _py_backwards_merge_dicts([{1: 2}], a, b)"""
    assert fix(DictUnpackingTransformer, {}, """
    {1: 2, **a, 3: 4, **b}""") == """
    _py_backwards_merge_dicts([{1: 2, 3: 4}], a, b)"""

# Generated at 2022-06-21 17:37:20.451462
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import annotated

    @annotated
    def fn():
        return {1: 1, 2: 2, **{3: 3}}

    assert fn() == {3: 3, 1: 1, 2: 2}

# Generated at 2022-06-21 17:37:38.237800
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    src = """\
        {1: 1, **dict_a}
        """

    expected = """\
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """

    tree = compile(src, 'test', 'exec', ast.PyCF_ONLY_AST)
    DictUnpackingTransformer().visit(tree)
    result = compile(tree, 'test', 'exec').co_consts[1]
    assert expected == result


# Generated at 2022-06-21 17:37:47.597599
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseTest
    from ..utils.ast_builder import ast_from, ast_for
    from ..utils.source import source_from
    from ..utils.transform import transform

    class Test(BaseTest):
        target_class = DictUnpackingTransformer
        transformer: DictUnpackingTransformer

        @property
        def tree(self) -> ast.AST:
            return ast_for(
                """
                {1: 1, **dict_a}
                """)

        def test_tree(self) -> None:
            self.assertEqual(
                ast_from(
                    """
                    import _py_backwards_merge_dicts
                    _py_backwards_merge_dicts([{1: 1}], dict_a})
                    """),
                self.transformer.tree)

    Test

# Generated at 2022-06-21 17:37:56.707165
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from _ast import Dict, Name, Num, Load
    from _ast import Module, Call, List, keyword, ListComp, DictComp, Tuple
    from astor.source_repr import source_repr

    node = Module(body=[Dict(keys=[Num(1), Num(2)], values=[Num(1), Num(2)])])
    expected = Module(
        body=[Dict(keys=[Num(1), Num(2)], values=[Num(1), Num(2)])])

    transformer = DictUnpackingTransformer()
    transformed = transformer.visit(node)
#    print(source_repr(transformed))
    assert expected == transformed

# Generated at 2022-06-21 17:38:03.708909
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer
    assert transformer._tree_changed is False
    assert transformer._split_by_None([(1, 2), (None, 3), (4, 5)]) == \
        [[(1, 2)], 3, [(4, 5)]]
    assert transformer._prepare_splitted([[(1, 2)], 3, [(4, 5)]]) == \
        [ast.Dict(keys=[ast.Num(n=1)], values=[ast.Num(n=2)]),
         ast.Call(
             func=ast.Name(id='dict'),
             args=[ast.Num(n=3)],
             keywords=[]),
         ast.Dict(keys=[ast.Num(n=4)], values=[ast.Num(n=5)])]

# Generated at 2022-06-21 17:38:15.271523
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import BaseNodeTransformerUnitTest
    class DictUnpackingTransformerUnitTest(BaseNodeTransformerUnitTest):
        # pylint: disable=protected-access
        def test_merge_empty_dicts(self):
            source = '{}'
            expected_source = '_py_backwards_merge_dicts([{}])'
            self._test_transformation(source, expected_source, DictUnpackingTransformer)

        def test_merge_one_dict_with_one_unpacking(self):
            source = '{1: 1, **dict_a}'
            expected_source = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
            self._test_transformation(source, expected_source, DictUnpackingTransformer)



# Generated at 2022-06-21 17:38:22.588380
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    source = """
{'a': 1, **{'b': 2}, 'c': 3}
    """
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    expected = merge_dicts.get_source() + """
_py_backwards_merge_dicts([{'a': 1}, {'c': 3}], {'b': 2})"""

    assert astor.to_source(tree).strip() == expected.strip()



# Generated at 2022-06-21 17:38:29.538386
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from astunparse import unparse
    module_ast = ast.parse('''
    _py_backwards_merge_dicts = None
    ''')

    DictUnpackingTransformer().visit_Module(module_ast)
    assert unparse(module_ast) == '\n'.join([
        'def _py_backwards_merge_dicts(dicts):',
        '    result = {}',
        '    for dict_ in dicts:',
        '        result.update(dict_)',
        '    return result',
        '',
        '_py_backwards_merge_dicts = None',
        ''])


# Generated at 2022-06-21 17:38:37.061835
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    node = ast.parse('{1: 1, **dict_a}')
    result = transformer.visit(node)
    dict_unpacking = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[ast.List(elts=[ast.Dict(keys=[ast.Num(n=1)],
                                      values=[ast.Num(n=1)]),
                             ast.Name(id='dict_a')])],
        keywords=[])
    assert result.body[0].value == dict_unpacking
    assert transformer._tree_changed

# Generated at 2022-06-21 17:38:43.555628
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_code = '{**"abc", **""}'
    expected = '''
_py_backwards_merge_dicts([dict("abc"), dict(""), {}])
'''

    module = ast.parse(test_code)
    DictUnpackingTransformer().visit(module)
    print(expected, end='')
    print(ast.dump(module))
    assert ast.dump(module) == expected



# Generated at 2022-06-21 17:38:45.827976
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer  # silence pyflakes

# Generated at 2022-06-21 17:39:11.197039
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import get_ast
    from ..utils.compat import to_tuple
    from .base import BaseNodeTransformerTest
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestSet
    from .base import NodeTest

    class DictUnpackingTransformerTestSet(BaseNodeTransformerTestSet):
        """Test set containing tests for DictUnpackingTransformer."""

    class DictUnpackingTransformerTest(BaseNodeTransformerTest):
        """Test for DictUnpackingTransformer."""
        target = DictUnpackingTransformer

    class TestDictUnpackingTransformer_visit_Module(
            BaseNodeTransformerTestCase):

        def test_empty(self):
            snippet = ""
            assert not self.snippet_changed(snippet)


# Generated at 2022-06-21 17:39:16.096605
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = '{1: 2, 3: 4, **x}'
    tree = ast.parse(code)
    transformed = DictUnpackingTransformer().visit(tree)

    expected = ast.parse('_py_backwards_merge_dicts([{1: 2, 3: 4}], x)')

    assert ast.dump(transformed) == ast.dump(expected)



# Generated at 2022-06-21 17:39:27.884548
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Actual code:
    #     {'a': 'b', 'c': 'd'}
    #
    # Expected code:
    #     {'a': 'b', 'c': 'd'}
    tree = ast.parse('{}')
    tree = DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse('{}'))

    # Actual code:
    #     {'a': 'b', **{'c': 'd'}}
    #
    # Expected code:
    #     _py_backwards_merge_dicts([{'a': 'b'}], {'c': 'd'})
    tree = ast.parse("{'a': 'b', **{'c': 'd'}}")
    tree = D

# Generated at 2022-06-21 17:39:31.391955
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    merge_dicts_in_module = DictUnpackingTransformer().visit(
        ast.parse(merge_dicts.get_text()))

    assert merge_dicts_in_module == merge_dicts.get_node()

# Generated at 2022-06-21 17:39:37.746663
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    module = ast.parse(u"""{1: 1, **d}""")
    expected = ast.parse(u"""
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        {1: 1, **d}
      """)
    assert transformer.visit(module) == expected


# Generated at 2022-06-21 17:39:41.266849
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import _ast
    node = _ast.Module(body=[])
    transformer = DictUnpackingTransformer()
    transformer.visit_Module(node)
    assert str(node.body[0]).startswith(
        'def _py_backwards_merge_dicts(dicts):')

# Generated at 2022-06-21 17:39:43.964958
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a = DictUnpackingTransformer()
    assert isinstance(a, DictUnpackingTransformer)


# Generated at 2022-06-21 17:39:50.681830
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """
        {1: 1, 2: 2, **a}
        {**b}
    """
    # run the transformer
    actual = DictUnpackingTransformer.run(code)
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2}], a)
        _py_backwards_merge_dicts([dict(b)])
    """
    assert actual.strip() == expected.strip()

# Generated at 2022-06-21 17:40:01.601199
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.ast_fixture import ASTFixture
    from ..utils.ast_transformer import transform_code
    from ..utils.compare_ast import compare_ast
    from .utils.string import dedent

    test_code = dedent('''
    func({1: 1})
    func({1: 1, 2: 2})
    func({1: 1, 2: 2, 3: 3})
    func({1: 1, 2: 2, 3: 3, **s})
    func({1: 1, 2: 2, 3: 3, **s, **d})
    func({**s, **d})
    func({1: 1, **s, **d})
    func({{**s, **d}})
    ''')


# Generated at 2022-06-21 17:40:03.360676
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = "a = {1: 2, 3: 4, **c}"

# Generated at 2022-06-21 17:40:24.249230
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from pytree_tester import run_test_on_function
    from pytree_tester.test_tree import test_tree as DictUnpackingTransformer_test_tree

    def test_function():
        def f():
            return {1: 1, **{'a': 2}}

    run_test_on_function(
        test_function,
        expected_ast=DictUnpackingTransformer_test_tree,
        transforms=[DictUnpackingTransformer])

# Generated at 2022-06-21 17:40:31.182195
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import typed_ast.ast3 as ast
    transformer = DictUnpackingTransformer()
    assert transformer.visit(ast.parse("{1: 2}")) == ast.parse("{1: 2}")
    assert transformer.visit(ast.parse("{1: 2, **{3: 4}}")) == \
        ast.parse("_py_backwards_merge_dicts([{1: 2}], {3: 4})")



# Generated at 2022-06-21 17:40:40.400978
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import sys

    import astor
    from typed_astunparse import unparse
    from typed_ast.ast3 import literal_eval
    from .. import to_source

    code = '''
    def f():
        dict_ = py_dict()
        {1: 1, 2: 2, 3: 3, **dict_}
    '''
    expected_code = '''
    def f():
        dict_ = py_dict()
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_)
    '''
    tree = DictUnpackingTransformer().visit(ast.parse(code))  # type: ignore
    print(astor.dump_tree(tree))
    assert to_source(tree) == expected_code

    # Check code roundtrip


# Generated at 2022-06-21 17:40:50.847499
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:41:01.012864
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a = 'dict_a'
    b = 'dict_b'
    c = 'dict_c'
    d = 'dict_d'
    original = "foo({1: 2, **{3: 4}, 5: 6, **{7: 8, 9: 10}, **{11: 12}})"

    @snippet
    def expected():
        foo(_py_backwards_merge_dicts([{1: 2, 5: 6}], {3: 4}, {7: 8, 9: 10}, dict_a))

    assert DictUnpackingTransformer(a).transform(original) == expected.deindent()
    assert DictUnpackingTransformer([a, b]).transform(original) == expected.deindent()


# Generated at 2022-06-21 17:41:03.264468
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from typed_ast import ast3 as ast

    # Defined type of variables:
    a: DictUnpackingTransformer = DictUnpackingTransformer()



# Generated at 2022-06-21 17:41:12.287229
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.node import node_equal
    from iterfzf import iterfzf
    from ..utils.test import transform_and_compare
    from ..utils.visitor import FileASTGenerator

    class DictUnpackingTestFinder(ast.NodeVisitor):
        def __init__(self):
            self.test_cases = []  # type: List[ast.Dict]

        def visit_Dict(self, node: ast.Dict) -> None:
            if None in node.keys:
                self.test_cases.append(node)
            self.generic_visit(node)

    with open('tests/programs/dict.py') as f:
        tree = ast.parse(f.read())

    test_finder = DictUnpackingTestFinder()

# Generated at 2022-06-21 17:41:21.630879
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    inp = [
        "MERGE_DICTS_IMPORTED = False",
        "if MERGE_DICTS_IMPORTED:",
        "  def _py_backwards_merge_dicts(dicts):",
        "      result = {}",
        "      for _dict in dicts:",
        "          result.update(_dict)",
        "      return result",
        "else:",
        "  def _py_backwards_merge_dicts(dicts):",
        "      result = {}",
        "      for _dict in dicts:",
        "          result.update(_dict)",
        "      return result",
    ]

# Generated at 2022-06-21 17:41:29.543391
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import TransformTestCase

    tests = """
    {1: 1, 2: 2}
    {1: 1, **dict_a}
    {1: 1, **dict_a, 2: 2}
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    for i, (code, output) in enumerate(TransformTestCase.parse_cases(tests)):
        tree = ast.parse(code)
        new_tree = DictUnpackingTransformer().visit(tree)
        assert TransformTestCase.compare_trees(new_tree, output) == True, '%s: %r' % (i, code)

# Generated at 2022-06-21 17:41:31.482056
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = """def test(): print(globals())"""

# Generated at 2022-06-21 17:42:01.260664
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:42:02.579506
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()  # To check constructor

# Generated at 2022-06-21 17:42:04.416870
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:42:05.718316
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()

# Generated at 2022-06-21 17:42:11.200501
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source_code = """
    {1: 1, 2: 2, **dict_a}
    """

    expected_code = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1, 2:2}], dict_a)
    """

    node = parse(source_code)
    node = DictUnpackingTransformer().visit(node)
    code = unparsed_ast(node)
    assert code == expected_code

# Generated at 2022-06-21 17:42:20.305423
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # begin
    @snippet
    def test():
        def f():
            d1 = {1: 1}
            d2 = {2: 2}
            return {**d1, **d2}

        def g():
            d1 = {1: 1}
            d2 = {2: 2}
            return {**d1, **d2, 3: 3}

        f()
        g()

    # end

    assert ast.dump(test.get_ast(), include_attributes=False) == ast.dump(
        DictUnpackingTransformer().visit(test.get_ast()),
        include_attributes=False)



# Generated at 2022-06-21 17:42:23.453405
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .unpacking import UnpackingTransformer

    code = '''\
{1: 1, "a": 2, **dict_a, **dict_b, 2: 2}
'''

# Generated at 2022-06-21 17:42:28.767384
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('{1: 1, **{1: 2}}')
    transformer = DictUnpackingTransformer()

    assert not transformer._tree_changed
    result = transformer.visit(tree)
    assert transformer._tree_changed
    assert transformer.tree_changed


# Generated at 2022-06-21 17:42:40.968218
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as ast3
    from ..utils.tree import ast_pprint


# Generated at 2022-06-21 17:42:52.166478
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import astunparse
    import textwrap
    x = """
    test = {
        'a': 1,
        'b': 2,
        **{
            'c': 3,
            'd': 4,
        },
        'e': 5,
        **{
            'f': 6,
            'g': 7,
        },
        'h': 8,
        **{
            'i': 9,
            'j': 10,
        },
    }
    """

# Generated at 2022-06-21 17:43:56.338441
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = '''
    {1: None, None: 5, **{'a': 6}, 2: 3, **{'c': 7}}
    '''

    expected_code = '''
    _py_backwards_merge_dicts([{1: None, 2: 3}], {'a': 6}, {'c': 7})
    '''

    # assert
    assert expected_code == compile_snippet(code, DictUnpackingTransformer)

# Generated at 2022-06-21 17:43:57.505737
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None)

# Generated at 2022-06-21 17:43:58.130091
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-21 17:44:05.777746
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """\
    foo = 1
    bar = 2
    """
    module = ast.parse(source)

    transformer = DictUnpackingTransformer(module)
    transformer.visit(module)

    assert transformer._tree_changed is True
    assert len(module.body) == 3
    assert module.body[0].lineno == 1
    assert isinstance(module.body[0], ast.FunctionDef)
    assert module.body[0].name == '_py_backwards_merge_dicts'
    assert len(module.body[1].body) == 3
    assert module.body[1].body[0].lineno == 1


# Generated at 2022-06-21 17:44:14.444916
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from .testing import assert_node_equal

    source = \
        """
        def f():
            pass
        """
    tree = parse(source)
    module = DictUnpackingTransformer().visit(tree)
    assert_node_equal(module,
        ast.Module(body=[
            merge_dicts.get_body(),
            ast.FunctionDef(
                name='f',
                args=ast.arguments(
                    args=[],
                    vararg=None,
                    kwonlyargs=[],
                    kw_defaults=[],
                    kwarg=None,
                    defaults=[]),
                body=[ast.Pass()],
                decorator_list=[],
                returns=None)
            ]))


# Generated at 2022-06-21 17:44:23.569730
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    from .helpers import transforms_to

    assert transforms_to(
        """{1: 1, **dict_a, 3: 3}""",
        """_py_backwards_merge_dicts([{1: 1}], dict_a, [{3: 3}])""",
    )

    assert transforms_to(
        """{1: 1, 2: 2, **dict_a, 3: 3}""",
        """_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, [{3: 3}])""",
    )


# Generated at 2022-06-21 17:44:31.800068
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_utils import round_trip

    source = '''\
        {1: 1, 2: 2, **dict1, 3: 3, **dict2}
        '''

    expected = '''\
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1, 2: 2}, dict1, {3: 3}], dict2)

        '''
    round_trip(source, expected, DictUnpackingTransformer)



# Generated at 2022-06-21 17:44:35.610238
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(target=(3, 4))

# Generated at 2022-06-21 17:44:39.569319
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{x: "x", **dct}')
    res = DictUnpackingTransformer().visit(module)
    assert res == ast.parse('_py_backwards_merge_dicts([{x: "x"}], dct)')



# Generated at 2022-06-21 17:44:40.873780
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert isinstance(transformer, DictUnpackingTransformer)