

# Generated at 2022-06-21 17:35:29.006095
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:35:30.953017
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)

# Generated at 2022-06-21 17:35:36.896783
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    module = ast.parse(
        """{1: 1, **dict_a, 2: 2, **dict_b, 3: 3}""",
        mode='exec')
    result = transformer.visit(module)

# Generated at 2022-06-21 17:35:43.269571
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import parse
    tree = parse("""
{
    1: 1,
    **{'a': 'b'},
    2: 2,
}
""")

    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed is True
    code = compile(tree, "<test>", "exec")
    exec(code, {'_py_backwards_merge_dicts': merge_dicts.compile(globals())})  # type: ignore
    assert eval(code) == {1: 1, 2: 2, 'a': 'b'}

# Generated at 2022-06-21 17:35:53.597499
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from contextlib import redirect_stdout
    class FakeStdout:
        def __init__(self):
            self.data = []
        def write(self, x: str):
            self.data.append(x)
        def read(self) -> str:
            return '\n'.join(self.data)
        def isatty(self) -> bool:
            return False

    class FakeStdout2:
        def __init__(self):
            self.data = []
        def write(self, x: str):
            self.data.append(x)
        def read(self) -> str:
            return '\n'.join(self.data)
        def isatty(self) -> bool:
            return False

    from ..utils.codegen import codegen

    # Normal case
    tree = ast

# Generated at 2022-06-21 17:35:54.529713
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer

# Generated at 2022-06-21 17:35:55.045710
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-21 17:35:55.876117
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert not DictUnpackingTransformer().tree_changed

# Generated at 2022-06-21 17:35:58.312846
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    snippet.test_snippet(DictUnpackingTransformer)

# Generated at 2022-06-21 17:36:00.240914
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:36:09.237564
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert transform(
        'x = {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}',
        [DictUnpackingTransformer]) == (
        '_py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {3: 3}, dict_b, '
        '{4: 4}])')

# Generated at 2022-06-21 17:36:18.454291
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse("""
        a = {1: 2, 3: 4}
    """)

    transformer = DictUnpackingTransformer()
    assert transformer.visit(tree) == ast.parse("""
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        a = {1: 2, 3: 4}
    """)


# Generated at 2022-06-21 17:36:31.511958
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Test for method visit_Dict of class DictUnpackingTransformer.
    """
    ep = "input.py"
    source = """\
    def foo():
        return {
            1: 2,
            **a,
            **b,
            3: 4,
            **c,
        }
    """  # NOQA

    expected_source = """\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    def foo():
        return _py_backwards_merge_dicts([{1: 2, 3: 4}], a, b, c)
    """

    source = source.splitlines()
    expected_source = expected_source.splitlines()


# Generated at 2022-06-21 17:36:33.971472
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """\
{1: 1, **dict_a}
"""

# Generated at 2022-06-21 17:36:41.051595
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import test_properties
    from .registry import register_transformer
    from .flow_control import FlowControlTransformer

    register_transformer(DictUnpackingTransformer)
    register_transformer(FlowControlTransformer)

    test_properties("""x = {1: 1, **{'a': 1}}""", """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        x = _py_backwards_merge_dicts([{1: 1}], {'a': 1})
    """)

# Generated at 2022-06-21 17:36:52.633821
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from .utils import render
    from .visitor import Visitor
    from .base import _transform

    class DumpVisitor(Visitor):
        """A visitor for dumping AST."""

        def __init__(self):
            self.nodes = []  # type: List[ast.AST]

        def generic_visit(self, node):
            """Dump node and its children to list nodes."""
            self.nodes.append(node)
            super().generic_visit(node)

    def transform(pairs: List[Tuple[Optional[ast.expr], ast.expr]],
                  *,
                  position: int = 0):
        """Transforms AST to apply DictUnpackingTransformer."""
        global DumpVisitor

# Generated at 2022-06-21 17:36:54.241817
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert(DictUnpackingTransformer())


# Generated at 2022-06-21 17:37:02.452676
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a, b, c = map(ast.parse, (
        'a = {1: 2, 3: 4, **g}',
        'b = {1: 2, **g, **f}',
        'c = {1: 2, 3: 4, **g, **f}',
    ))
    transformer = DictUnpackingTransformer()
    a = transformer.visit(a)
    b = transformer.visit(b)
    c = transformer.visit(c)
    assert '_py_backwards_merge_dicts' in a.body[0].value.func.id
    assert '_py_backwards_merge_dicts' in b.body[0].value.func.id
    assert '_py_backwards_merge_dicts' in c.body[0].value.func

# Generated at 2022-06-21 17:37:09.347663
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import parse_snippet
    from ..utils import compare_source

    source = parse_snippet('{1: 1, **dict_a}')
    expected = parse_snippet('_py_backwards_merge_dicts([{1: 1}], dict_a})')

    transformer = DictUnpackingTransformer()
    result = transformer.visit(source)

    assert compare_source(result, expected)
    assert transformer._tree_changed is True


# Generated at 2022-06-21 17:37:11.637392
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Given
    tree = """{1: 1, **{2: 2}, 3: 3, **{4: 4}}"""

# Generated at 2022-06-21 17:37:21.070350
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:37:33.534794
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from textwrap import dedent
    from ..visitor import TransformerVisitor

    visitor = TransformerVisitor([DictUnpackingTransformer])
    code = dedent('''
        def some_func(x):
            f = {
                1: 1,
                **x,
                2: 2,
                **x,
                **y,
            }
    ''')
    expected = dedent('''
        def some_func(x):
            f = _py_backwards_merge_dicts(
                [{1: 1, 2: 2}],
                x,
                x,
                y,
            )
    ''')
    tree = visitor.visit(ast.parse(code))
    assert ast.dump(tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-21 17:37:39.849726
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    instance = DictUnpackingTransformer()

    assert isinstance(instance, DictUnpackingTransformer)
    assert isinstance(instance, BaseNodeTransformer)
    assert hasattr(instance, 'visit_Dict')
    assert hasattr(instance, 'target')
    assert callable(instance.visit_Dict)


# Generated at 2022-06-21 17:37:42.246168
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dut = DictUnpackingTransformer()
    assert dut is not None


# Generated at 2022-06-21 17:37:50.539844
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import os
    import sys
    import ast
    import collections
    import typed_astunparse
    import astor

    file_name = os.path.join(os.path.dirname(__file__), "test_files", "dict_unpacking.py")
    with open(file_name, 'r') as f:
        content = f.read()
    unpr = typed_astunparse.unparse(typed_ast.ast3.parse(content))
    unpr = unpr.replace('\n', '')\
        .replace(' '*4, '')\
        .replace('{}', 'dict()')
    unpr = unpr.replace('{1:1}', 'dict(dict(),**dict_a)')

# Generated at 2022-06-21 17:38:00.190712
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .mapping import MappingTransformer
    from .imports import DictUnpackingTransformer as DUT
    
    transformer = DUT(MappingTransformer)
    
    s = """{'a': 1, **dict_a}"""
    node = ast.parse(s)
    res_node = transformer.visit(node)
    exp = """_py_backwards_merge_dicts([{'a': 1}], dict_a)"""
    assert ast.dump(res_node) == ast.dump(ast.parse(exp))
    
    s = """{'a': 1, **dict_a, **dict_b}"""
    node = ast.parse(s)
    res_node = transformer.visit(node)

# Generated at 2022-06-21 17:38:06.054791
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_unpacking import snippets

    snippet = snippets.get('DictUnpacking')
    target = (3, 4)

    node = parse(snippet, mode='eval')
    transformer = DictUnpackingTransformer(target)
    new_node = transformer.visit(node) # type: ignore
    code = unparse(new_node).strip()

    expected = snippets.get('DictUnpacking-expected')
    assert code == expected

# Generated at 2022-06-21 17:38:16.552114
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..transformers import TransformerSequence
    source = source_to_ast("""
    {1: 1, 2: 2, 3: 3, 4: 4, **{'a': 5, 'b': 6, 'c': 7}, **{}}
    """)
    transformer = TransformerSequence(DictUnpackingTransformer())
    transformer.apply(source)
    assert source.tree_repr() == source_to_ast("""
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}, {'a': 5, 'b': 6, 'c': 7}, {}])
    """).tree_repr()



# Generated at 2022-06-21 17:38:18.355867
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    src = '{1: 1, 2: 2, **dict_a}'

# Generated at 2022-06-21 17:38:24.552936
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_code_equal, transform

    AST = ast.parse('{1: 2, **{"a": 3}, 2: 4, **{"b": 5}, "c": 6}')

    assert_code_equal(transform(AST, DictUnpackingTransformer),
                      """
    _py_backwards_merge_dicts([{1: 2, 2: 4, 'c': 6}], {'a': 3}, {'b': 5})
                      """)


# Generated at 2022-06-21 17:38:51.625619
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    def test_case(src: str, *, result: Optional[str] = None) -> None:
        tr = DictUnpackingTransformer()
        module = ast.parse(src)
        tr.visit(module)
        assert tr._tree_changed is True
        if result is not None:
            result_ = ast.parse(result)
            assert module.body == result_.body
        else:
            assert merge_dicts.get_body()[0] in module.body

    test_case('')
    test_case('''
        # comment
        x + 1
    ''')

# Generated at 2022-06-21 17:38:59.913967
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast
    import astunparse

    class DictUnpackingTransformer(DictUnpackingTransformer):
        def visit_Name(self, node):
            return unmodified(ast.Name('a', ast.Store()))

    src = 'a = {1: 1}'
    correct = 'a = _py_backwards_merge_dicts([{1: 1}], {}) if True else {1: 1}'

    tree = ast.parse(src)
    tr = DictUnpackingTransformer()
    tr.visit(tree)
    assert astunparse.unparse(tree) == correct



# Generated at 2022-06-21 17:39:01.371307
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    class x(object):
        ...
    assert isinstance(x, type)

# Generated at 2022-06-21 17:39:03.185182
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    before = '''
{1: 1, **dict_a}
    '''

# Generated at 2022-06-21 17:39:12.558853
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.utils import assert_syntax_equal

    # f1({**{}, **{}})  # => f1(dict())
    node = ast.parse('f1({**{}, **{}})')
    result = DictUnpackingTransformer().visit(node)
    expected = ast.parse('f1(dict())')
    assert_syntax_equal(result, expected)

    # f2({1: 1, 2: 2, **{}, **{4: 4, 5: 5, **{}, **{6: 6, **{}}}})
    # =>
    # f2(
    #   _py_backwards_merge_dicts(
    #       [{1: 1, 2: 2}],
    #       dict(),
    #       dict(4=4, 5=5),


# Generated at 2022-06-21 17:39:17.354046
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
    {'a': value, None: 0, 'b': value}
    """
    expected = """
    _py_backwards_merge_dicts(
        [dict(
            ['a', 'b'],
            [value, value])],
        0)
    """
    assert_transform(DictUnpackingTransformer, source, expected)



# Generated at 2022-06-21 17:39:28.941939
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import List
    from typed_ast import ast3 as ast
    node = ast.Dict(keys=[ast.Num(n=1), None, ast.Name(id='k'), None, None],
                    values=[ast.Num(n=1), ast.Name(id='a'), ast.Num(n=2),
                            ast.Name(id='b'), ast.Name(id='c')])
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)

# Generated at 2022-06-21 17:39:32.874524
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse('{1: 1, **dict_a}')
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)

# Generated at 2022-06-21 17:39:40.363575
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..interface import Patch, find_and_replace, serialize

    tree = ast.parse('x')
    expected = ast.parse('''
    _py_backwards_merge_dicts = lambda xs: {1: 1}
    x
    ''')

    patch = Patch(
        'dict_unpacking_transformer',
        (3, 4),
        find_and_replace(
            DictUnpackingTransformer,
            lambda t: serialize(t, mode='exec') == serialize(expected, mode='exec')))

    patched = patch(tree)
    assert serialize(patched, mode='exec') == serialize(expected, mode='exec')


# Generated at 2022-06-21 17:39:46.892905
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import normalize_ast
    source = '{1: 1, 2: 2, 3: 3, **{1: 2, 3: 4}}'
    result = normalize_ast(ast.parse(source))
    expected = normalize_ast(ast.parse('_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], {1: 2, 3: 4})'))
    assert DictUnpackingTransformer().visit(result) == expected



# Generated at 2022-06-21 17:40:18.848113
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    node = ast.Module(body=[])
    DictUnpackingTransformer(node)


# Generated at 2022-06-21 17:40:26.748150
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_strings import DICT_UNPACKING_TRANSFORMER_CODE
    code = DICT_UNPACKING_TRANSFORMER_CODE
    expr_name = 'expr_name'
    expect_code = f'def _py_backwards_merge_dicts(dicts):\n    result = ' \
        f'{{}}\n    for dict_ in dicts:\n        result.update(dict_)\n    ' \
        f'return result\n{expr_name}'
    transformer = DictUnpackingTransformer()
    tree = ast.parse(code, '<test>')  # type: ast.Module
    node = tree.body[0]  # type: ast.Assign
    name = node.value.value.keywords[0].value.func.id  #

# Generated at 2022-06-21 17:40:28.019497
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:40:34.064172
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # given
    module = ast.parse("pass")
    transformer = DictUnpackingTransformer()

    # when
    transformed_module = transformer.visit(module)

    # then
    assert transformer._tree_changed == True



# Generated at 2022-06-21 17:40:35.570461
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:40:36.383686
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:40:49.092232
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:40:57.129148
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Example:
    #   {a: b, c: d, **e, **f, g: h} -> _py_backwards_merge_dicts([{a: b, c: d}, e, f, {g: h}])
    source = """\
{a: b, c: d, **e, **f, g: h}"""

# Generated at 2022-06-21 17:41:04.757572
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{1: 1, **dict_a}')
    result = DictUnpackingTransformer(opts=None).visit(module)
    assert(ast.dump(result) == ast.dump(ast.parse(
        'def _py_backwards_merge_dicts(dicts):\n'
        '    result = {}\n'
        '    for dict_ in dicts:\n'
        '        result.update(dict_)\n'
        '    return result\n'
        '{1: 1, _py_backwards_merge_dicts([{1: 1}], dict_a)}')))


# Generated at 2022-06-21 17:41:12.897961
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    pairs = [
        (None, ast.Lambda(args=ast.arguments(), body=ast.Num(n=3))),
        (None, ast.Lambda(args=ast.arguments(), body=ast.Num(n=4))),
        (None, ast.Lambda(args=ast.arguments(), body=ast.Num(n=5))),
    ]
    splitted = DictUnpackingTransformer._split_by_None(None, pairs)

# Generated at 2022-06-21 17:42:11.583810
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert t._split_by_None([(1, 2)]) == [[(1, 2)]]
    assert t._split_by_None([(1, 2), (None, 3), (4, 5)]) == [[(1, 2)], 3, [(4, 5)]]

    splitted = [[(1, 2)], 3, [(4, 5)]]
    assert list(t._prepare_splitted(splitted)) == [
        ast.Dict(keys=[1], values=[2]),
        ast.Call(func=ast.Name(id='dict'), args=[3], keywords=[]),
        ast.Dict(keys=[4], values=[5])
    ]


# Generated at 2022-06-21 17:42:13.068083
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert (DictUnpackingTransformer() is not None)

# Generated at 2022-06-21 17:42:21.113157
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    ast_ = source_to_ast("""\
        {
            "key": value,
            **unpack_dict
        }\
    """)

    transformer = DictUnpackingTransformer()
    result = transformer.visit(ast_)

    assert transformer._tree_changed

    from ..utils.source import ast_to_source
    expected = """\
        _py_backwards_merge_dicts([{"key": value}], unpack_dict)\
    """
    assert ast_to_source(result) == expected



# Generated at 2022-06-21 17:42:30.920700
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import sys
    from ..utils.ast_inspector import AstInspector

    inspector = AstInspector()
    source = '''
        {}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        {}
    '''
    node = ast.parse(source)
    DictUnpackingTransformer(inspector=inspector).visit(node)
    assert expected == inspector.compile_back(node)

    inspector = AstInspector()

# Generated at 2022-06-21 17:42:31.896882
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()



# Generated at 2022-06-21 17:42:37.489186
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..unparse import Unparser
    source = "def merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n"
    expected = source + "\n"
    code = ast.parse(source)
    node = DictUnpackingTransformer().visit(code)
    output = Unparser(node)
    output = str(output)
    assert output == expected


# Generated at 2022-06-21 17:42:39.495264
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('{1: 1, **{2: 2}}', '', 'eval')

# Generated at 2022-06-21 17:42:43.396535
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3

    code = """
    {1: 2, **b}
    """

# Generated at 2022-06-21 17:42:53.353907
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse(dedent('''\
        def f():
            x = {1: 1, 2: 2, **dict_a}'''))
    trans = DictUnpackingTransformer()

# Generated at 2022-06-21 17:43:03.602032
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from astunparse import unparse

# Generated at 2022-06-21 17:44:42.286110
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert True #TODO: implement your test here

# Generated at 2022-06-21 17:44:52.195037
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '{1: 1, **dict_a}'
    unit = ast.parse(code)
    expected = '''def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result

_py_backwards_merge_dicts([{1: 1}], dict_a)'''
    expected = ast.parse(expected)

    transformer = DictUnpackingTransformer()
    result = transformer.visit(unit)
    assert isinstance(result, ast.Module)
    assert ast.dump(result) == ast.dump(expected)
    assert transformer.tree_changed is True



# Generated at 2022-06-21 17:44:57.434101
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..testing.utils import test_transform

    @test_transform(DictUnpackingTransformer)
    def test():
        _py_backwards_merge_dicts([{}, {}])

    def test_output():
        yield (
            """
            def _py_backwards_merge_dicts(dicts):
                result = {}
                for dict_ in dicts:
                    result.update(dict_)
                return result


            _py_backwards_merge_dicts([{}, {}])
            """)


# Generated at 2022-06-21 17:44:58.099376
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-21 17:45:00.852999
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
{1: 1, 2: 2, None: {3: 3}, 4: 4, None: {5: 5, 6: 6}, 7: 7}
"""

# Generated at 2022-06-21 17:45:11.681312
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    # This is the source code
    source = '''
    {a: 1, **b, **c}
    '''

    # This is the expected result
    result = '''
    _py_backwards_merge_dicts(
        [{'a': 1}, b, c]
        )
    '''

    # This is the actual result
    module = ast.parse(source)
    DictUnpackingTransformer().visit(module)

    # Print the AST of the module
    #print(astunparse.unparse(module))

    # Compare with the expected result
    module = ast.parse(result)
    result = astunparse.unparse(module)
    actual_result = astunparse.unparse(module)
    assert actual_result == result