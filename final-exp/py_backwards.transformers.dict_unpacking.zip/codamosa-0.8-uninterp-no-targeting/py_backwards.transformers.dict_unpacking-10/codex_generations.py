

# Generated at 2022-06-21 17:35:28.198828
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.Module(body=[ast.Expr(value=ast.Dict(keys=[None], values=[ast.Name(id='a')]))])
    expected = ast.Module(body=[
        ast.Expr(value=merge_dicts.get_body()),
        ast.Expr(value=ast.Call(
            func=ast.Name(id='_py_backwards_merge_dicts'),
            args=[ast.List(elts=[
                ast.Dict(keys=[], values=[]),
                ast.Name(id='a')
            ])],
            keywords=[]
        ))
    ])

    actual = DictUnpackingTransformer(node)

    assert ast.dump(expected) == ast.dump(actual.node)

# Generated at 2022-06-21 17:35:29.032310
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:35:31.020718
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    src = '''{1: 1}'''

# Generated at 2022-06-21 17:35:32.970182
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer



# Generated at 2022-06-21 17:35:41.848020
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("{**a}")
    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-21 17:35:43.428839
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer.__doc__

# Generated at 2022-06-21 17:35:53.680646
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source

    mod = ast.parse(source("""\
        def merge_dicts(dicts: List[dict]) -> dict:
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        a = {1: 2, "a": "aa"}
        b = {"a": "bb", 3: 4}
        c = {1: 1, "a": "cc", **a}

        def f(d: dict) -> None:
            (1, 2 + 3)
            None

        def g(dict_: dict) -> None:
            c = {3: 4}
    """))
    DictUnpackingTransformer().visit(mod)

# Generated at 2022-06-21 17:35:57.049664
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert DictUnpackingTransformer().visit(ast.parse("""
    {}
    """)) == ast.parse("""
    _py_backwards_merge_dicts = lambda dicts: dict(dicts[-1], **dicts[-2])
    {}
    """)


# Generated at 2022-06-21 17:35:59.622371
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = merge_dicts()
    assert '_py_backwards_merge_dicts' in module.body[0].body[0].name



# Generated at 2022-06-21 17:36:02.240051
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .fixtures import DictUnpackingTransformer_visit_Dict


# Generated at 2022-06-21 17:36:11.113776
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source

    source = source(merge_dicts)

    tree = ast.parse(source)
    visitor = DictUnpackingTransformer()
    visitor.visit(tree)
    assert tree.body[0].body[0].name == '_py_backwards_merge_dicts'



# Generated at 2022-06-21 17:36:13.696480
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer  # Just to keep pytest happy.

# Generated at 2022-06-21 17:36:15.777621
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:36:17.165256
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:36:24.141723
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    class DictUnpackingTransformerTest(DictUnpackingTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            return self.generic_visit(node)  # type: ignore
    
    transformer = DictUnpackingTransformerTest()
    x = ast.parse('x = {1: 1, 2: 2, **dict_a, **{3: 3}, 4: 4}', mode='eval')
    y = transformer.visit(x)
    assert transformer._tree_changed

# Generated at 2022-06-21 17:36:25.088930
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    src = """{1: 1, 2: 2, **dict_a}"""

# Generated at 2022-06-21 17:36:33.788441
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import transform
    from ..utils.parsing import make_module

    source = '''
        {1: 2}
        {**{1: 2}}
        {1: 2, **{3: 4}}
        {1: 2, **{3: 4, 5: 6}}
        {1: 2, **{3: 4, 5: 6}, **{7: 8}}
        {**{3: 4, 5: 6}, **{7: 8}}
        {1: 2, **{3: 4, 5: 6}, **{7: 8}, 3: 4}
    '''

# Generated at 2022-06-21 17:36:39.521195
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    t = DictUnpackingTransformer()
    node = ast.parse('''\
{1: 1, 2: 2, **dict_a}''')
    expected = ast.parse('''\
_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)''')
    t.visit(node)
    assert ast.dump(node) == ast.dump(expected)



# Generated at 2022-06-21 17:36:45.869521
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from compiler.transformer import ModuleTransformer
    tree = ast.parse('{1: 1}')
    transformer = ModuleTransformer({DictUnpackingTransformer})
    tree = transformer.visit(tree)
    assert '_py_backwards_merge_dicts' in ast.dump(tree)


# Generated at 2022-06-21 17:36:50.684442
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('''
        {'a': 1, 'b': 2, **{'c': 3}, 'd': 4, **{'e': 5}}''')
    visitor = DictUnpackingTransformer()
    resulting_ast = visitor.visit(module)
    expected_ast = ast.parse('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{'b': 2, 'a': 1, 'd': 4}, {'c': 3}, {'e': 5}])''')
    assert ast.dump(resulting_ast) == ast.dump(expected_ast)

# Generated at 2022-06-21 17:37:05.877937
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert_equivalent_ast(
        merge_dicts.get_source(),
        """
        def _py_backwards_merge_dicts(dicts):
          result = {}
          for dict_ in dicts:
            result.update(dict_)
          return result
        """
    )

# Generated at 2022-06-21 17:37:14.612552
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    from ast import dump
    code_block = """
my_dict = {'a': 1, 'b': 2, **other_dict}
    """
    expected = """
from ..utils.tree import insert_at
from ..utils.snippet import snippet
my_dict = __py_backwards_merge_dicts([{'a': 1, 'b': 2}], other_dict)
    """
    transformer = DictUnpackingTransformer()
    with __py_backwards_merge_dicts():
        res = transformer.visit(ast.parse(code_block))
        assert astunparse.unparse(res) == expected

# Generated at 2022-06-21 17:37:24.172517
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.line_numbers import LinesNumbers
    from ..utils.test_helpers import compact_ast
    from ..utils.test_helpers import _fields

    source = '''
        {1: 1, 2: f(**{2: 2}), **d, 3: 3}
    '''
    test = """
        _py_backwards_merge_dicts([{1: 1, 2: f(**{2: 2})}, d], {3: 3})
    """
    ln = LinesNumbers(source)
    module, _ = compact_ast(source)
    node = ln.get_node(module.body[0].value).as_void()

# Generated at 2022-06-21 17:37:34.141908
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..unparse import unparse
    assert unparse(DictUnpackingTransformer().visit(ast.parse(
    """
    {2: 2, **{'a': 1}, 3: 3, **{'b': 1}}
    """
    ))) == """
    import typing


    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    _py_backwards_merge_dicts(
        [{2: 2}, dict({'a': 1}),
         {3: 3}, dict({'b': 1})]
    )
    """



# Generated at 2022-06-21 17:37:37.873480
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.Module(body=[merge_dicts.get_body()])
    assert DictUnpackingTransformer().visit(node) == node



# Generated at 2022-06-21 17:37:42.291879
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    tree = ast.parse('''\
{1: 2, **{2: 3}, *[{3: 4}], 4: 5, **{6: 7}}\
''')  # type: ast.Dict
    result = transformer.visit(tree)
    assert isinstance(result, ast.Call)

# Generated at 2022-06-21 17:37:45.476372
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    assert x.tree_changed is False
    assert x.source_code is ''
    assert x.dump_tree(mode='exec') is None

# Unit tests for method DictUnpackingTransformer._split_by_None

# Generated at 2022-06-21 17:37:46.289746
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-21 17:37:53.623434
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.transformer import cmp_source

    T = DictUnpackingTransformer

    cmp_source(snippet(lambda: {1: 2}), snippet(lambda: {}))
    assert not T(snippet(lambda: {1: 2})).tree_changed

    cmp_source(snippet(lambda: {1: 2, **{}}), snippet(lambda: {1: 2}))
    assert T(snippet(lambda: {1: 2, **{}})).tree_changed
    assert not T(snippet(lambda: {1: 2, **{}})).tree_changed

    cmp_source(snippet(lambda: {1: 2, **{3: 4}}),
               snippet(lambda: {1: 2, 3: 4}))

# Generated at 2022-06-21 17:38:01.670359
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from textwrap import dedent

    code = dedent('''
        {**dict_a, 1: 1, 2: 2, **dict_b, **dict_c, 3: 3, **dict_d}
    ''').strip()
    parsed = ast.parse(code, mode='eval')
    scope = {}
    scope['dict_a'] = {'a': 1}
    scope['dict_b'] = {'b': 1}
    scope['dict_c'] = {'c': 1}
    scope['dict_d'] = {'d': 1}
    node = DictUnpackingTransformer().visit(parsed)
    compiled = compile(node, '<test>', 'eval')
    result = eval(compiled, scope)

# Generated at 2022-06-21 17:38:20.830650
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:38:27.212647
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.trees import local

    tree = ast.parse("{1: 1, **dict_a, **dict_b, 2: 2, **dict_c}")
    result = DictUnpackingTransformer().visit(tree)
    expected = ast.parse("""
            _py_backwards_merge_dicts([dict(1, 1), dict_a, dict_b, dict(2, 2)], dict_c)
        """)
    assert local(result, 1) == local(expected, 1)


# Generated at 2022-06-21 17:38:33.339264
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import os
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module, AnnAssign, Assign, Name, Num, Dict, Tuple, Str, List, BinOp, Call, Load, Store, Constant, Attribute

    source =  "dictionary = {}"
    input_ast = ast.parse(source)
    expected_ast = ast.parse(source)
    expected_changed = False

    DUT = DictUnpackingTransformer()
    actual_ast = DUT.visit(input_ast)
    actual_changed = DUT.tree_changed()

    assert expected_changed == actual_changed
    assert type(expected_ast) == type(actual_ast)

# Generated at 2022-06-21 17:38:34.102064
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert(DictUnpackingTransformer())

# Generated at 2022-06-21 17:38:36.471286
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)

# Generated at 2022-06-21 17:38:48.568884
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_utils import make_call_of
    from ..utils.tree import parse
    from ..utils.source import dedent
    from ..types import Tree, TreeEvent
    from .. import main

    # Prepare test code.
    source = dedent('''
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    ''')
    tree = parse(source)
    assert isinstance(tree, ast.Module)
    # Apply transformations.
    tree = main.transform(tree)
    # Check results.
    assert isinstance(tree, Tree)

    # Assert events.
    assert (TreeEvent.ENTER, tree) in tree
    call = make_call_of('_py_backwards_merge_dicts')

# Generated at 2022-06-21 17:38:51.006032
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert isinstance(transformer, BaseNodeTransformer)


# Generated at 2022-06-21 17:39:01.324352
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import sys
    import ast as ast_module
    import astunparse
    import textwrap


# Generated at 2022-06-21 17:39:06.347349
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    snippet.test_module(DictUnpackingTransformer.visit_Module, 'a = 1')
    assert snippet.module.body[0].targets[0].id == '_py_backwards_merge_dicts'
    assert snippet.module.body[1].value == 1


# Generated at 2022-06-21 17:39:13.850432
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer._split_by_None([(1, 1), (None, 2), (3, 3)]) == [[(1, 1)], 2, [(3, 3)]]
    assert DictUnpackingTransformer._prepare_splitted([[], 2, [(3, 3)]]) == [2, ast.Dict(keys=[3], values=[3])]
    assert DictUnpackingTransformer._prepare_splitted([[(1, 1)], ast.Dict(keys=[2], values=[2])]) == [ast.Call(func=ast.Name(id='dict'), args=[ast.Dict(keys=[1], values=[1])], keywords=[]), ast.Dict(keys=[2], values=[2])]

# Generated at 2022-06-21 17:40:31.593375
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    source = """
{1: 1, **dict_a}
    """
    expected = """
_py_backwards_merge_dicts([{1: 1}], dict_a)
"""
    node = ast.parse(source)  # type: ast.Module
    actual = astunparse.dump(DictUnpackingTransformer().visit(node))
    assert expected.strip() == actual.strip()

# Generated at 2022-06-21 17:40:40.548996
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    code = """
        {1: 1, **dict_a}
        dict_b = {1: 1, **dict_a}
        dict_c = {1: 1, **dict_a, **dict_b}
        dict_d = {1: 1}
        dict_e = {**dict_a}
    """

# Generated at 2022-06-21 17:40:50.110734
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .NaiveASTUnparser import NaiveASTUnparser
    from .ExprsTransformer import ExprsTransformer

    source = '''{1: 2, None: 3, 4: 5, None: 6, 7: 8, None: 9}'''
    parsed = ast.parse(source)
    ExprsTransformer().visit(parsed)
    transformed = DictUnpackingTransformer().visit(parsed)
    unparsed = NaiveASTUnparser().visit(transformed)
    assert unparsed == '''_py_backwards_merge_dicts([{1: 2, 4: 5, 7: 8}], 3, 6, 9)'''

# Generated at 2022-06-21 17:40:52.197531
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    _ = DictUnpackingTransformer()



# Generated at 2022-06-21 17:41:01.209416
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..nodes import Module
    from ..nodes import Dict
    class Dict(Dict):
        keys = [None, None]
        values = [Dict(), Dict()]
    test_dict = Dict(keys=[None, None], values=[Dict(), Dict()])
    assert test_dict.keys == [None, None]
    assert test_dict.values == [Dict(), Dict()]
    dut = DictUnpackingTransformer()
    result = dut.visit_Module(Module(body=[test_dict]))
    assert dut._tree_changed
    assert result.body[1].func.id == '_py_backwards_merge_dicts'
    assert isinstance(result.body[1].args[0], ast.List)

# Generated at 2022-06-21 17:41:04.302835
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module
    from .common import Common

    source = """\
{1: 1, **a}
{2: 2}
"""

# Generated at 2022-06-21 17:41:05.486822
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer


# Generated at 2022-06-21 17:41:10.703192
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from py_backwards.utils.snippet import Snippet
    from ..test_utils import evaluate_single_node

    snippet = Snippet(['{1: 1, **dict_a}'], ['dict_a'])
    expected = Snippet(['_py_backwards_merge_dicts([{1: 1}], dict_a)'], [])
    assert evaluate_single_node(snippet, DictUnpackingTransformer, expected)

# Generated at 2022-06-21 17:41:20.877448
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:41:22.225582
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:42:10.013410
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    s = "a = {'a': 1, **d}"
    expected = "from typing import Dict\n\n\ndef _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n\n\na = _py_backwards_merge_dicts([{\'a\': 1}], d)"
    from ..utils.misc import parse_to_ast
    from .misc import UnparseTransformer
    t = UnparseTransformer()
    actual = t.visit(DictUnpackingTransformer().visit(parse_to_ast(s)))
    print(actual)
    assert actual == expected

# Generated at 2022-06-21 17:42:16.773202
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import create_transformer_test
    from ..utils.test_utils import assert_string

    name = 'test_DictUnpackingTransformer'
    code = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    create_transformer_test(name, code, expected, DictUnpackingTransformer)

# Generated at 2022-06-21 17:42:19.334209
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astunparse
    source = '''\
{3: 4, **{1: 2}, 5: 6, **{7: 8}}'''

# Generated at 2022-06-21 17:42:28.199301
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_transformed_in_py3

    source = "some_var = {'key': 1, **dict_a}"
    expected = "some_var = _py_backwards_merge_dicts([{'key': 1}], dict_a)"

    assert_transformed_in_py3(DictUnpackingTransformer(), source, expected)



# Generated at 2022-06-21 17:42:35.903947
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dut = DictUnpackingTransformer({})
    node = ast.parse("d = {'a': 'b', **c, 1: 2}")
    result = dut.visit(node)
    assert isinstance(result.body[0], ast.Expr)
    assert isinstance(result.body[0].value, ast.Call)
    assert (
        result.body[0].value.func.args[0].elts ==
        [ast.Dict(keys=['a'], values=['b']),
         ast.Dict(keys=[], values=['c']),
         ast.Dict(keys=[1], values=[2])]
    )



# Generated at 2022-06-21 17:42:36.710160
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:42:38.088492
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    d = DictUnpackingTransformer()
    return d


# Generated at 2022-06-21 17:42:42.506329
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    tester = DictUnpackingTransformer()
    assert tester.__str__() != ""
    assert tester.__repr__() != ""

# Generated at 2022-06-21 17:42:48.808787
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import BaseNodeTransformer

    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)

    transformer = DictUnpackingTransformer()
    assert transformer.name == 'DictUnpackingTransformer'
    assert transformer.target == (3, 4)



# Generated at 2022-06-21 17:42:57.960676
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import get_ast
    from ..utils.tree import to_src
    from ..utils.snippet import render
    from ..utils.cfg import get_cfg

    code = render("""
        assert isinstance({1: 1, **d}, dict)
    """)

    node = get_ast(code)
    result = DictUnpackingTransformer().visit(node)
    code_result = to_src(result)

    # Function should be defined
    assert '_py_backwards_merge_dicts(' in code_result
    # Function should be called
    assert '_py_backwards_merge_dicts([{1: 1}], d' in code_result
    # Graph of the code should not have any loops
    get_cfg(result)  # test will fail with assertion error on loop



# Generated at 2022-06-21 17:44:25.655396
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:44:30.148311
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast
    class visitor(ast.NodeVisitor):
        def generic_visit(self,node):
            return node
        visit_Module = DictUnpackingTransformer.visit_Module

    trans = visitor()
    trans.visit(ast.parse("{1:2, **dict_a}").body[0].value)



# Generated at 2022-06-21 17:44:35.599452
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.nodes import ast_object
    from ..utils.text import source
    from ..utils import pythran_to_python

    source_ = """
    def foo():
        return {1: 1, **dict_a}
    """
    result = source(source_)
    result = pythran_to_python(result)
    result = ast_object(result)
    expected = merge_dicts.get_body() + source(source_)
    expected = ast_object(expected)

    DictUnpackingTransformer().visit(result)

    assert result == expected



# Generated at 2022-06-21 17:44:42.802638
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from . import ast_diff
    from .unparse import unparse

    # Module is unchanged when module is empty.
    empty_module = ast.Module([])
    transformed = DictUnpackingTransformer().visit(empty_module)
    assert ast_diff(empty_module, transformed) == []

    # Module receives an import and a function definition.
    class_definition = unparse('''
        class Test:
            def method(self):
                pass
    ''')
    module = ast.parse(class_definition)
    with_symbol = DictUnpackingTransformer().visit(module)
    assert '_py_backwards_merge_dicts' in [x.name for x in with_symbol.body]



# Generated at 2022-06-21 17:44:44.071049
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), BaseNodeTransformer)

# Generated at 2022-06-21 17:44:46.963662
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    d = DictUnpackingTransformer()
    assert d


# Generated at 2022-06-21 17:44:55.738784
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .transformer_test_case import TransformerTestCase, ast3_module
    from typed_ast import ast3 as ast

    class Test(TransformerTestCase):
        transformer = DictUnpackingTransformer
        method = 'visit_Dict'

        def test_correct_result(self):
            node = ast.Dict(
                keys=[ast.Num(1), None, None, ast.Num(3)],
                values=[ast.Num(1), ast.Dict(keys=[], values=[]),
                        ast.Name(id='x', ctx=ast.Load()), ast.Num(3)]
            )
            result = self.transform(node)
            self.assertIsInstance(result, ast.Call)
            self.assertIsInstance(result.func, ast.Name)

# Generated at 2022-06-21 17:44:58.711289
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()._tree_changed is False


# Generated at 2022-06-21 17:45:08.204289
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import run_test_on_module

    code = '''
{1: 1, **{}}
{1: 1, **{2: 2}, **{3: 3}}
    '''.strip()

    lines = [
        'module = {1: 1, **{}}',
        'module = _py_backwards_merge_dicts([{1: 1}], {}])',
        'module = {1: 1, **{2: 2}, **{3: 3}}',
        'module = _py_backwards_merge_dicts([{1: 1}], {2: 2}, {3: 3}])'
    ]

    run_test_on_module(lines, code, DictUnpackingTransformer)

# Generated at 2022-06-21 17:45:18.197127
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.example import example
    from ..utils.node import n
    from ..utils.misc import equal_ast

    assert equal_ast(
        DictUnpackingTransformer.run(example.py_dict1),
        {'_py_backwards_merge_dicts': [
            n('List', elts=[
                n('Dict', keys=[
                    n('Str'),
                ], values=[
                    n('Num'),
                ]),
                n('Name', id='dict_a'),
                ]),
            ],
        })
