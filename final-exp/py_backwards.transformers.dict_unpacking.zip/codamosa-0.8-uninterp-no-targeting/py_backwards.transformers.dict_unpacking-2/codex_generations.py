

# Generated at 2022-06-21 17:35:28.167855
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    snippet = '{1: 1, **dict_a, 2: 3, **dict_b}'
    expected = '''
    {1: 1, **dict_a, 2: 3, **dict_b}
    '''

    module = ast.parse(snippet, 'snippet')
    print(astunparse.unparse(DictUnpackingTransformer().visit(module)))

# Generated at 2022-06-21 17:35:29.593332
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert merge_dicts.get_body() == DictUnpackingTransformer().visit(merge_dicts.get_ast())


# Generated at 2022-06-21 17:35:37.947884
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import UnitTestTransformer, TransformerUnitTestCase

    class DictUnpackingTransformerTest(TransformerUnitTestCase):
        transformer = DictUnpackingTransformer

        def test_transform(self):
            tree = self._run_transformer("""
                foo = bar = {1, 2}
                baz = x = y = {}
            """)

            self.assertIsInstance(tree, ast.Module)
            self.assertEqual(len(tree.body), 2)

            self.assertIsInstance(tree.body[0], ast.Assign)
            self.assertIsInstance(tree.body[0].targets[0], ast.Name)
            self.assertIsInstance(tree.body[0].targets[1], ast.Name)

# Generated at 2022-06-21 17:35:47.367380
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast, assert_tree_changed
    from ..utils.test_node_factory import node_factory
    from ..utils.test_utils import any_type

    def test(node: ast.Dict) -> None:
        before = node_factory(node)
        after = node_factory(DictUnpackingTransformer().visit(node))
        assert_equal_ast(before, after)
        assert_tree_changed(DictUnpackingTransformer, node)

    test(node_factory("{1: 1, 2: 2, 3: 3, 4: 4, 5: 5}"))
    test(node_factory("{1: 1, 2: 2, **x, **y}"))

# Generated at 2022-06-21 17:35:52.652258
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    class DummyNode:
        def __init__(self):
            self.body = []
    class Dummy:
        def get_body(self):
            return []
    node = DummyNode()
    merge_dicts = Dummy()
    dummy = DictUnpackingTransformer()
    dummy._tree_changed = False
    ret_value = dummy.visit_Module(node)
    assert ret_value == node
    assert dummy._tree_changed is True

# Generated at 2022-06-21 17:35:54.023735
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:36:01.062048
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import make_call, make_dict
    result = DictUnpackingTransformer().visit_Dict(make_dict(
        [('a', 1), (None, make_call(
            'dict', [make_dict(
                [('b', 2)])], [])), ('c', 3)]))
    assert result == make_call(
        '_py_backwards_merge_dicts', [
            make_call('dict', [make_dict(
                [('a', 1)])], []),
            make_call('dict', [make_dict(
                [('b', 2)])], []),
            make_dict([('c', 3)])], [])



# Generated at 2022-06-21 17:36:10.569403
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ... import compile
    from .base import BaseNodeTransformerTestCase, SourceTestCase

    class Test(SourceTestCase, BaseNodeTransformerTestCase):
        transformer = DictUnpackingTransformer
        code = """x = {1: 1, **{'a': 1}}"""
        expected_ast = ast.parse(
            """\
from _py_backwards_dict_unpacking import _py_backwards_merge_dicts
x = _py_backwards_merge_dicts([{1: 1}], {'a': 1})
"""
        ).body

    Test().test()



# Generated at 2022-06-21 17:36:21.854429
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer._split_by_None(
        []) == [[]]
    assert DictUnpackingTransformer._split_by_None(
        [(ast.Num(n=1), ast.Num(n=1)), (None, ast.Num(n=2))]) == [[
            (ast.Num(n=1), ast.Num(n=1))], ast.Num(n=2), []]
    assert DictUnpackingTransformer._split_by_None(
        [(None, ast.Num(n=2))]) == [
            ast.Num(n=2), []]

# Generated at 2022-06-21 17:36:29.267690
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from .nodes import Dict

    DUT = DictUnpackingTransformer()

    result = DUT.visit(Dict({1: 2, None: [{3: 4}]}))
    assert astor.to_source(result) == '_py_backwards_merge_dicts([{1: 2}], [dict({3: 4})])'



# Generated at 2022-06-21 17:36:42.505638
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    # This is the input code
    code = """
        {1: 1, **dict_a}
    """

    # Desired output for input code
    expected_code = """
        _py_backwards_merge_dicts([{1: 1}], dict_a})
    """

    # Construct an instance of our visitor from 3.4
    visitor = DictUnpackingTransformer.get_visitor(34)

    # Parse the input code, and give it to the visitor
    node = ast.parse(code)
    visitor.visit(node)

    # Get the output from the visitor
    output = astor.to_source(node).strip()

    # Test
    assert output == expected_code

# Generated at 2022-06-21 17:36:53.883307
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import Module
    from .test_util import check_transformation

    source = """\
{1:1, **{2:2}, **{3:3, **{4:4, **{5:5, **{6:6, **{7:7, **{8:8}}}}}}}
"""
    expected = """\
_py_backwards_merge_dicts([{1: 1}, {2: 2}, {3: 3}, {4: 4}, {5: 5}, {6: 6}, {7: 7}, {8: 8}])
"""

    tree = Module(body=[ast.Expr(value=ast.Dict())])
    tree = DictUnpackingTransformer().visit(tree)
    check_transformation(tree, expected, source)

# Generated at 2022-06-21 17:37:01.439208
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """{a: a, **b, **c, d: d}"""
    expected = """
    dict_ = dict()
    dict_.update(b)
    dict_.update(c)
    _py_backwards_merge_dicts([{'a': a}, dict_, {'d': d}])
    """
    m = ast.parse(source).body[0]
    n = DictUnpackingTransformer().visit(m)  # type: ignore
    assert ast.dump(n) == expected



# Generated at 2022-06-21 17:37:11.799127
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def assert_transform(before, after):
        module = ast.parse(before)
        assert ast.dump(module) == ast.dump(ast.parse(after))

    assert_transform('''
{
    1: 1,
    **{2: 2, 3: 3}
}
''', '''

_py_backwards_merge_dicts([{1:1}], {2:2, 3:3})
''')

    assert_transform('''
{
    1: 1,
    **{2: 2, 3: 3},
    **{4: 4, 5: 5}
}
''',
    '''
_py_backwards_merge_dicts([{1:1}], {2:2, 3:3}, {4:4, 5:5})
''')


# Generated at 2022-06-21 17:37:20.883444
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    expected_output='def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n'
    tree = ast.parse('{}')
    actual = DictUnpackingTransformer().visit(tree).body[0]
    expected = ast.parse(expected_output)
    assert ast.dump(actual) == ast.dump(expected)


# Generated at 2022-06-21 17:37:22.935515
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    obj = DictUnpackingTransformer()
    assert obj is not None

# Generated at 2022-06-21 17:37:31.536152
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.checker import compare_ast
    source_ = ('''
{1: 1, **a}
''')

    expected_ast = source('''
_py_backwards_merge_dicts([{1: 1}], a)
''')
    source_ast = source(source_)

    DictUnpackingTransformer().visit(source_ast)
    compare_ast(expected_ast, source_ast)



# Generated at 2022-06-21 17:37:38.884835
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('{1: 1, **a}')
    node2 = DictUnpackingTransformer().visit(node)
    assert node2.body[0].value.args[0] == ast.Dict(keys=[], values=[])
    assert node2.body[0].value.args[1] == ast.Name(id='a')



# Generated at 2022-06-21 17:37:48.127130
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import parse

    # This test covers only the case when dict unpacking is in the beginning
    # of dictionary
    unpacked_dict = parse("""
        mydict = {**dict_a, 1: 1}
    """)
    assert isinstance(unpacked_dict.body[0], ast.Assign)
    ids = unpacked_dict.body[0].targets
    assert isinstance(ids[0], ast.Name)
    assert isinstance(unpacked_dict.body[0].value, ast.Call)

    # This test covers only the case when dict unpacking is in the end
    # of dictionary
    unpacked_dict = parse("""
        mydict = {1: 1, **dict_a}
    """)

# Generated at 2022-06-21 17:37:57.237024
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    source = '{1: 1}'
    expected_source = '\n'.join([
        '_py_backwards_merge_dicts = lambda *dicts: {}',
        'result = {}',
        'for dict_ in dicts:',
        '    result.update(dict_)',
        'return result',
        '{1: 1}'
    ])
    node = ast.parse(source)
    node = DictUnpackingTransformer().visit_Module(node)
    source = astor.to_source(node)
    print(source)
    assert source == expected_source


# Generated at 2022-06-21 17:38:14.930812
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_astunparse
    from .unpackingbase import UnpackingBaseTransformer

    code = """
        d = {1: 2, **i, }
        d = {1: 2, **i, 3: 4}
        d = {**i, 1: 2}
        d = {**i, 1: 2, 3: 4}
        d = {**i, 1: 2, **j, 3: 4}
        d = {1: 2, **i, **j, 3: 4}
        """
    tree = ast.parse(code)  # type: ignore
    a = UnpackingBaseTransformer()
    a.visit(tree)
    b = DictUnpackingTransformer()
    b.visit(tree)

# Generated at 2022-06-21 17:38:16.796060
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:38:25.854113
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from .base import BaseNodeTransformer

    class DummyTransformer(BaseNodeTransformer):
        def visit(self, node):
            return node

    source = '''
    {
        1: 1,
        **a,
        'str': 'str',
        None: None
    }
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}, 'str'], a, {None: None})
    '''

    module = ast3.parse(source)
    transformer = DictUnpackingTransformer(module)
    transformer.visit(module)
    assert module is not None

    dummy = DummyTransformer(module)
    module = dummy.visit(module)

    result = ast3.unparse(module)


# Generated at 2022-06-21 17:38:27.014563
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    class_ = DictUnpackingTransformer
    assert class_ is not None

# Generated at 2022-06-21 17:38:29.704782
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse('''
        dict_a = {'a': 1}
        dict_b = {**dict_a}
    ''')
    DictUnpackingTransformer().visit(module)
    assert '' == ast.unparse(module)

# Generated at 2022-06-21 17:38:31.647351
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    o = DictUnpackingTransformer()

# Generated at 2022-06-21 17:38:32.541905
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:38:39.651885
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from astor.codegen import to_source
    snippet = """
    # this is a comment
    result = {1: 2, 3: 4, **{5: 6, **{7: 8}}}
    """
    expected_snippet = """
    # this is a comment
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    result = _py_backwards_merge_dicts(
        [{3: 4, 1: 2}],
        {5: 6},
        {7: 8})
    """
    from .utilities import assert_equal_code
    from typed_astunparse import unparse
    from mind_boggle.test.test_common import data_path


# Generated at 2022-06-21 17:38:40.257783
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-21 17:38:52.691087
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:38:59.970855
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    x


# Generated at 2022-06-21 17:39:04.506270
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import generic_visit
    s = """{1:2}"""
    tree = ast.parse(s)
    t = DictUnpackingTransformer()
    generic_visit(tree, t)

# Generated at 2022-06-21 17:39:11.332062
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    example = '''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c, 4: 4, **dict_d, 5: 5}
        '''

    expected = '''
        _py_backwards_merge_dicts(
            [{1: 1, 2: 2, 3: 3, 4: 4, 5: 5}],
            dict_a,
            dict_b,
            dict_c,
            dict_d)
        '''

    ...

# Generated at 2022-06-21 17:39:22.072645
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing_utils import assert_equal
    from .. import parse, dump

    # Simple case
    code = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    transformed = parse(code)
    DictUnpackingTransformer().visit(transformed)
    assert_equal(dump(transformed), expected)

    # Test merge
    code = '''
    {1: 1, **{2: 2}}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], {2: 2})
    '''
    transformed = parse(code)

# Generated at 2022-06-21 17:39:25.605876
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """{1: 1, **dict_a}"""
    expected = """{1: 1, **dict_a}"""
    assert DictUnpackingTransformer.run_and_get_changed(source) == expected



# Generated at 2022-06-21 17:39:31.279502
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import parse
    tree = parse('{1: 2}')
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == (
        'Module(body=[Expr(value=Call(func=Name(id="_py_backwards_merge_d'
        'icts", ctx=Load()), args=[List(elts=[Dict(keys=[Num(n=1)], values=[Num'
        '(n=2)])])], keywords=[]))])')


# Generated at 2022-06-21 17:39:36.828347
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected.strip()



# Generated at 2022-06-21 17:39:41.587610
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import compile
    
    tree = ast.parse("""
        {1: 1, **dict_a}
    """)
    
    node = DictUnpackingTransformer().visit(tree)
    assert compile(node, '<test>', 'exec') == \
        """_py_backwards_merge_dicts([{1: 1}], dict_a)\n"""

# Generated at 2022-06-21 17:39:52.917768
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import itertools
    import ast
    from pprint import pprint
    from ..utils.tree import to_string
    transformer = DictUnpackingTransformer()

    def visit(pairs):
        node = ast.Dict(keys=[key for key, _ in pairs],
                        values=[value for _, value in pairs])
        return transformer.visit(node)  # type: ignore

    def test(pairs, expected):
        result = visit(pairs)
        assert to_string(result) == expected

    # No unpacking
    test([(None, ast.Num(n=1)), (ast.Num(n=2), ast.Num(n=2))],
         '{None: 1, 2: 2}')

    # Simple example

# Generated at 2022-06-21 17:39:59.598169
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('{1:1, 2:2, **x}', mode='eval')
    assert str(node) == '{1: 1, 2: 2, **x}'

    actual = DictUnpackingTransformer().visit(node)
    expected = '_py_backwards_merge_dicts([{1: 1, 2: 2}], x)'
    assert str(actual) == expected


# Generated at 2022-06-21 17:40:10.702410
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-21 17:40:13.390268
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils import testing
    p = testing.normalize(__name__ + '.DictUnpackingTransformer',
                          'DictUnpackingTransformer')
    assert p

# Generated at 2022-06-21 17:40:15.935658
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("{1: 1, **dict_a}")
    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-21 17:40:16.916670
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()

# Generated at 2022-06-21 17:40:25.810462
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source, dump
    from .. import transformer
    from ..utils.tree import node

    source = source('''
    {1: 1, **dict_a}
    {1: 1, 2: 1, **dict_a}
    {1: 1, 2: 1, **dict_a, 3: 1, **dict_b}
    ''')


# Generated at 2022-06-21 17:40:33.079550
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """\
{1: 2, **{3: 4}, 5: 6, **{7: 8}, 9: 10}
"""
    expected = """\
_py_backwards_merge_dicts([dict({1: 2, 5: 6, 9: 10}), {3: 4}, {7: 8}])
"""
    tree = ast.parse(source)
    DictUnpackingTransformer().generic_visit(tree)
    new_source = ast.unparse(tree)
    assert new_source == expected

# Generated at 2022-06-21 17:40:35.487135
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

if __name__ == '__main__':
    test_DictUnpackingTransformer()

# Generated at 2022-06-21 17:40:36.310764
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:40:49.057605
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    from .base import BaseNodeTransformerTestCase

    class Tester(BaseNodeTransformerTestCase):
        transformer = DictUnpackingTransformer
        code = """
            {1: 2, None: foo(a=b, c=d), 3: 4, None: bar(), 5: 6}
        """
        result = """
            _py_backwards_merge_dicts(
              [{1: 2}, bar(), {3: 4}],
              foo(
                a=b,
                c=d))
        """

    tester = Tester()
    result_node = Tester.transformer.run(Tester.node)
    result = astunparse.unparse(result_node)
    tester.assertMultiLineEqual(result, tester.result)

# Generated at 2022-06-21 17:40:50.830289
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer

# Generated at 2022-06-21 17:41:31.851189
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    @snippet
    def target():
        a, b = 1, 2
        d = {a: b, **{'key': 'value'}}

    tree = ast.parse(target.dedent())
    tree = transformer.visit(tree)

    @snippet
    def expected():
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        a, b = 1, 2
        d = _py_backwards_merge_dicts([{a: b}], {'key': 'value'})

    expected_tree = ast.parse(expected.dedent())

# Generated at 2022-06-21 17:41:37.208651
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_astunparse import unparse
    
    code = merge_dicts.get_code()
    tree = ast.parse(code)
    new_tree = DictUnpackingTransformer().visit(tree)
    new_code = unparse(new_tree)

    assert new_code == code

# Generated at 2022-06-21 17:41:49.636093
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from lark import Tree
    from .base import BaseTransformer

    class DummyTransformer(BaseTransformer):
        def __init__(self):
            self._tree_changed = False
        def visit_Dict(self, node: Tree) -> Tree:
            return "12345"
    
    class MainTransformer:
        def __init__(self):
            self.transformer = DictUnpackingTransformer()
            self.dummy_transformer = DummyTransformer()
        def transform(self, root: Tree) -> Tuple[Tree, bool]:
            root = self.transformer.transform(self.dummy_transformer.transform(root))
            return root, self.transformer._tree_changed
    
    # testing
    src = "{1: 2, **dict_a}"

# Generated at 2022-06-21 17:41:58.607296
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{1: 1, **dict_a}')
    DictUnpackingTransformer().visit(module)

    module_code = compile(module, '<string>', mode='exec')
    locals_ = {}
    exec(module_code, {}, locals_)

    assert locals_['_py_backwards_merge_dicts'] is locals_['_py_backwards_merge_dicts']
    assert locals_['_py_backwards_merge_dicts']({1: 1}, dict_a={1: 2}) == {1: 2}


# Generated at 2022-06-21 17:42:07.764759
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astunparse
    from .unpack import UnpackTransformer

    @snippet
    def program():
        _py_backwards_merge_dicts = None
        res = ({1: 1, **dict_a})

    tree = ast.parse(program())
    UnpackTransformer().visit(tree)
    DictUnpackingTransformer().visit(tree)

    astunparse.dump(tree)
    assert astunparse.unparse(tree).strip() == program.strip()

# Generated at 2022-06-21 17:42:20.956482
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case = (
        "a = {4: 4, **b, **c}"
        "\n"
        "def _py_backwards_merge_dicts(dicts):\n"
        "    result = {}\n"
        "    for dict_ in dicts:\n"
        "        result.update(dict_)\n"
        "    return result")

    expected_result = (
        "def _py_backwards_merge_dicts(dicts):\n"
        "    result = {}\n"
        "    for dict_ in dicts:\n"
        "        result.update(dict_)\n"
        "    return result\n"
        "\n"
        "a = _py_backwards_merge_dicts([{4: 4}], b, c)")

# Generated at 2022-06-21 17:42:28.135217
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    snippet = "def f():\n  {**a}\n"
    expected = "def f():\n\n  _py_backwards_merge_dicts([{}], a)\n"
    node = ast.parse(snippet)
    result = str(DictUnpackingTransformer().visit(node))
    assert result == expected



# Generated at 2022-06-21 17:42:35.820279
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()

    pairs = [(None, ast.AST()), (ast.AST(), ast.AST()), (ast.AST(), ast.AST())]
    assert transformer._split_by_None(pairs) == [
        [],
        ast.AST(),
        [],
        [
            (ast.AST(), ast.AST()),
            (ast.AST(), ast.AST()),
        ],
    ]

    prepared = [ast.AST(), ast.AST(), ast.AST()]
    assert transformer._merge_dicts(prepared) == \
        ast.Call('_py_backwards_merge_dicts', [ast.AST(), ast.AST(), ast.AST()])

# Generated at 2022-06-21 17:42:41.897901
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    snippet_1 = """
    def f():
        return {
            1: 2,
            **{3: 4},
            # **{5: 6}  # Disabled
            **{7: 8},
            **{9: 10},
        }
    """
    expected_1 = """
    def f():
        return _py_backwards_merge_dicts(
            [{1: 2}, {7: 8}, {9: 10}],
            {3: 4}
        )
    """
    assert expected_1 == transform_snippet(snippet_1, [DictUnpackingTransformer])



# Generated at 2022-06-21 17:42:52.318525
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    assert transformer.visit(ast.parse('{1: 1, **{}}')) == \
        ast.parse('_py_backwards_merge_dicts([{1: 1}], {})\n')
    assert transformer.visit(ast.parse('{1: 1, **a}')) == \
        ast.parse('_py_backwards_merge_dicts([{1: 1}], a)\n')
    assert transformer.visit(ast.parse('{1: 1, **{2: 2}, 3: 3}')) == \
        ast.parse('_py_backwards_merge_dicts([{1: 1}, {2: 2}, {3: 3}])\n')

# Generated at 2022-06-21 17:43:33.194716
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_base import check_transformer
    from .test_base import assert_removed, assert_added

    class X:
        pass

    x = X()
    x.a = {1:1}
    x.b = {}
    x.c = [{2:2}]
    x.d = {3:3}
    x.e = {}
    x.f = [{4:4}]
    x.g = {5:5, **{6:6}}
    x.h = {7:7, **{8:8}, **{9:9}}
    x.i = {}

    x.j = [{10:10}]
    x.k = {11:11, **{12:12}}
    x.l = {13:13, **{14:14}}
   

# Generated at 2022-06-21 17:43:45.091831
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:43:55.766676
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    node = ast.parse("""\
{1: 1, 2: 2, 3: 3, **kwargs}
""")
    DictUnpackingTransformer().visit(node)
    expected = """\
_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], kwargs)
"""
    result = astor.to_source(node)
    assert result == expected

    node = ast.parse("""\
{1: 1, **kwargs, **{2: 2}}
""")
    DictUnpackingTransformer().visit(node)
    expected = """\
_py_backwards_merge_dicts([{1: 1}, {2: 2}], kwargs)
"""
    result = astor.to_source(node)

# Generated at 2022-06-21 17:44:00.109308
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.fixtures import sample_code
    from . import PythonCode
    
    code = sample_code('DictUnpackingTransformer_visit_Dict')
    expected = sample_code('DictUnpackingTransformer_visit_Dict_expected')
    result = PythonCode(code).transformed(DictUnpackingTransformer)
    
    assert str(result) == expected

# Generated at 2022-06-21 17:44:08.975993
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse(
        """{1: '1', 2: '2', **a, **b, 3: '3', 4: '4', **c}"""
    )  # type: ast.AST
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    expected = ast.parse(
        """_py_backwards_merge_dicts([{1: '1', 2: '2'}, {3: '3', 4: '4'}], a, b, c)"""
    )
    assert ast.dump(tree) == ast.dump(expected)


# Generated at 2022-06-21 17:44:21.015726
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-21 17:44:26.246029
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''
    a = {1: 1, **{2: 2}}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], {2: 2})
    '''
    assert DictUnpackingTransformer().visit(code) == expected


# Generated at 2022-06-21 17:44:30.510622
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '{1: 1, **dict_a, 2: 2, **dict_b}'
    expected = """_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)"""
    assert_compiled_and_back(DictUnpackingTransformer, source, expected)

# Generated at 2022-06-21 17:44:35.152139
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    c = DictUnpackingTransformer()
    node = ast.parse("{1: 1, **dict_a}")
    c.visit(node)
    assert str(node) == "def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n_py_backwards_merge_dicts([{1: 1}], dict_a)"


# Generated at 2022-06-21 17:44:36.314461
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer((1, 2))