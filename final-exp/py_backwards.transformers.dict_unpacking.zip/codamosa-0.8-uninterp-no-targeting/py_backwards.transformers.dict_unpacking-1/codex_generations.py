

# Generated at 2022-06-21 17:35:28.167856
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    class_name = 'DictUnpackingTransformer'
    class_obj = globals()[class_name]
    assert class_obj.__name__ == class_name

# Generated at 2022-06-21 17:35:32.306848
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    def _test(input, expected_output):
        node = ast.parse(input)
        transformer = DictUnpackingTransformer()
        output = transformer.visit(node)
        assert ast.dump(output) == expected_output


# Generated at 2022-06-21 17:35:36.248667
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ...testing import assert_transformation

    assert_transformation(
        DictUnpackingTransformer,
        merge_dicts,
        '{1: 2, **{3: 4}}',
        '_py_backwards_merge_dicts([{1: 2}], {3: 4})'
    )

# Generated at 2022-06-21 17:35:39.337188
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('{1: 1, **dict_a}')
    assert isinstance(node.body[0].value, ast.Dict)
    DictUnpackingTransformer().visit(node)
    assert isinstance(node.body[0].value, ast.Call)



# Generated at 2022-06-21 17:35:45.141024
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from textwrap import dedent

    source_code = """\
    if __name__ == '__main__':
        assert {1: 1, **{2: 2}} == {1: 1, 2: 2}
    """
    expected = """\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    if __name__ == '__main__':
        assert _py_backwards_merge_dicts([{1: 1}], {2: 2}) == {1: 1, 2: 2}
    """

    tree = ast.parse(source_code)
    transformer = DictUnpackingTransformer()
    transformed = transformer.visit(tree)

# Generated at 2022-06-21 17:35:54.688421
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    @snippet
    def before():
        {1: 1, **{'a': 'b', }, 2: 2, }

    program = before.get_ast()
    transformer = DictUnpackingTransformer()
    transformer.visit(program)
    assert transformer.tree_changed is True

# Generated at 2022-06-21 17:35:57.579426
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_source
    assert_source(DictUnpackingTransformer, '{1: 1, **dict_a}', """
        _py_backwards_merge_dicts([{1: 1}, dict_a])
    """)



# Generated at 2022-06-21 17:35:59.663412
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_utils import bulk_test_transformer
    bulk_test_transformer(DictUnpackingTransformer)



# Generated at 2022-06-21 17:36:01.120651
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:36:02.377494
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    transformer.visit_Module(ast.parse('{}'))



# Generated at 2022-06-21 17:36:14.562590
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
{1, **{"a": 1}}
"""
    expected = """
_py_backwards_merge_dicts([{}, dict({'a': 1})])
"""
    assert expected == compile_and_run(source, 'merge_dicts')


# Generated at 2022-06-21 17:36:23.349450
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Given
    code = '''
dict_a = {'a': 'a'}
dict_b = {'b': 'b'}
dict_c = {'c': 'c'}
dict_d = {'d': 'd'}
d = {1: 1, 2: 2, 3: 3, 4: 4, **dict_a, **dict_b, 5: 5, **dict_c, 6: 6, 7: 7,
     **dict_d, 8: 8}
    '''

# Generated at 2022-06-21 17:36:33.301834
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:36:35.007565
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass
# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-21 17:36:42.216622
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from typing import Any, List

    from typed_ast import ast3 as ast

    from ..utils.tree import get_positions_of_nodes
    from ..utils.tree import get_node_by_pos
    from ..utils.tree import get_nodes_by_pos


# Generated at 2022-06-21 17:36:52.633906
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astunparse as unparse
    from ..utils.ast_node import ast_node

    # Before
    input = '''\
    x = {1: 2, 3: 4}
    '''

    # After
    output = '''\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    
    
    
    
    
    
    x = {1: 2, 3: 4}
    '''

    # Eval
    result = unparse.unparse(ast_node(input, 3, 4))
    print(result)
    assert result == output



# Generated at 2022-06-21 17:37:01.300538
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    t = DictUnpackingTransformer()
    m = ast.parse('''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        
        return result

    ''')
    n = t.visit(m)
    assert n != m
    assert n.body[0].body == m.body[0].body

    # test insertion of an empty module
    t = DictUnpackingTransformer()
    m = ast.parse('')
    n = t.visit(m)
    assert n != m
    assert len(n.body) == 1
    assert isinstance(n.body[0], ast.Expr)

# Generated at 2022-06-21 17:37:11.115725
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse(
        textwrap.dedent("""\
        {1: 1, **dict_a}
        """),
        filename='<unknown>'
    )

    expected = ast.parse(
        textwrap.dedent("""\
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """),
        filename='<unknown>'
    )

    DictUnpackingTransformer().visit(tree)
    assert_equal(tree, expected)

# Generated at 2022-06-21 17:37:23.510331
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    class TestTransformer(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            args = node.args
            if node.func.id not in ('len', 'dict') and args:
                node.args = [args[-1], args[-2]]
            return node

    source = '''
    class C:
        def __new__(cls, **kwargs):
            return super().__new__(cls, **kwargs)
        def __init__(self, **kwargs) -> None:
            print(f"__init__({kwargs=})")
            
    len(dict(a=1, b=2))
    '''
    node = ast.parse(source)

# Generated at 2022-06-21 17:37:26.713904
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse("{1: 1, 2: 2, **{}, 3: 3}")

# Generated at 2022-06-21 17:37:47.979250
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    assert transformer.visit(ast.parse('{**dict_a, 1: 2}')) == \
        ast.parse('_py_backwards_merge_dicts([dict_a], {1: 2})')
    assert transformer.visit(ast.parse('{1: 1, **dict_a, 2: 2}')) == \
        ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a, {2: 2})')

# Generated at 2022-06-21 17:37:58.424103
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from ..utils.ast_tools import equal_asts
    from .base import BaseNodeTransformer

    class DictUnpackingTransformer(BaseNodeTransformer):
        """Compiles:
        
            {1: 1, **dict_a}
            
        To:
        
            _py_backwards_merge_dicts([{1: 1}], dict_a})
        
        """
        target = (3, 4)

        def _split_by_None(self, pairs: Iterable[Pair]) -> Splitted:
            """Splits pairs to lists separated by dict unpacking statements."""
            result = [[]]  # type: Splitted
            for key, value in pairs:
                if key is None:
                    result.append(value)
                    result.append([])
               

# Generated at 2022-06-21 17:38:03.230739
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_base import BaseTestTransformer
    from ..utils.source_helpers import source
    from ..utils.tree_helpers import find_node_by_type

    class Test(BaseTestTransformer):
        transformer = DictUnpackingTransformer

    @source
    def test_DictUnpackingTransformer_visit_Module():
        def func():
            x = {1: 1, **{2: 2}}

    node = find_node_by_type(
        Test(test_DictUnpackingTransformer_visit_Module).tree,
        ast.Assign)

    assert isinstance(node.value, ast.Call)
    # _py_backwards_merge_dicts([{1: 1}], {2: 2})
    assert isinstance(node.value.func, ast.Name)
   

# Generated at 2022-06-21 17:38:15.006540
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.matcher import match
    from ..utils.source import source
    
    transformer = DictUnpackingTransformer()
    
    ast_module = transformer.run(source("""\
        def test():
            my_dict = {1: 1, **dict_a}
        """))

# Generated at 2022-06-21 17:38:24.972343
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import compile_string
    from .asserts import complete_ast
    from .asserts import List
    from .asserts import Call
    assert_call = complete_ast(Call)

    code1 = """{'a': 1, **{'b': 2}}"""
    assert_call(code1, compile_string(code1)) == """_py_backwards_merge_dicts([dict({'a': 1})], {'b': 2})"""

    code2 = """{'a': 1, 'b': 2, **{'c': 3, 'd': 4}}"""
    assert_call(code2, compile_string(code2)) == """_py_backwards_merge_dicts([dict({'a': 1, 'b': 2})], {'c': 3, 'd': 4})"""

    code3

# Generated at 2022-06-21 17:38:30.851118
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-21 17:38:37.466725
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    source = "x = {1: 2, 3: 4, **y, 5: 6, **z, 7: 8}"
    expected = """\
x = _py_backwards_merge_dicts([{1: 2, 3: 4, 5: 6, 7: 8}], y, z)"""
    code = DictUnpackingTransformer().visit(ast.parse(source))
    assert ast.unparse(code).strip() == expected


__all__ = ['DictUnpackingTransformer']

# Generated at 2022-06-21 17:38:50.009405
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..tests.utils import build_and_run_and_compare
    from .output_tester import OutputTester
    from .optimise_empty_dicts import OptimiseEmptyDictsTransformer

    class OutputTester2(OutputTester):
        def __init__(self):
            super().__init__()

        def test(self, func):
            self.run(func)
            self.assertEqual(self.output, {2})
            self.reset()

            self.run(func, {1})
            self.assertEqual(self.output, {1, 2})
            self.reset()

            self.run(func, {3: 3})

# Generated at 2022-06-21 17:38:51.290657
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:39:01.618722
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = ast.parse(source)
    transformer = DictUnpackingTransformer()
    new_node = transformer.visit(node)
    result = compile(new_node, '<string>', mode='exec')
    context = {}
    exec(result, context, context)
    assert transformer._tree_changed
    assert ast.dump(new_node) == ast.dump(ast.parse(expected))
    assert context

# Generated at 2022-06-21 17:39:30.402185
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    try:
        code = """
        _py_backwards_merge_dicts = None
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        """
        assert merge_dicts.get_body() == code
    except Exception as e:
        raise e
    else:
        pass


# Generated at 2022-06-21 17:39:39.816698
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast.ast3 as ast


# Generated at 2022-06-21 17:39:40.951056
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()
    

# Generated at 2022-06-21 17:39:46.522969
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.sample import create_module
    expected = create_module(['def _py_backwards_merge_dicts(dicts):', '  result = {}', '  for dict_ in dicts:', '    result.update(dict_)', '  return result'])
    transformer = DictUnpackingTransformer()
    assert transformer.visit_Module(create_module([])) == expected


# Generated at 2022-06-21 17:39:57.235808
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class A(ast.Dict):
        """This class is used for creating test instance."""
        def __init__(self, keys, values):
            self.keys = keys
            self.values = values

    class B(ast.Name):
        """This class is used for creating test instance."""
        def __init__(self, id):
            self.id = id

    class C(ast.Call):
        """This class is used for creating test instance."""
        def __init__(self, keywords):
            self.keywords = keywords

    expected_keys = [B('a'), B('b'), B('c'), None, B('d'), None, B('e')]
    expected_values = [B('1'), B('2'), B('3'), None, B('4'), None, B('5')]
    expected_args

# Generated at 2022-06-21 17:39:59.406874
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:40:08.553440
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    src = """
        {1: 1, 2: 2, 3: 3, **a, 4: 4, **b, 5: 5}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}, a, {4: 4}, b, {5: 5}])
    """
    node = ast.parse(src)
    result = DictUnpackingTransformer().visit(node)
    assert to_source(result) == expected

    src = """
        {1: 1}
    """
    expected = """
        {1: 1}
    """
    node = ast.parse(src)
    result = DictUnpackingTransformer().visit(node)
    assert to_source(result) == expected


# Generated at 2022-06-21 17:40:11.701314
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:40:14.282918
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_transformer import process_and_compare_ast
    code = '{1: 1, **{2: 2}}'

# Generated at 2022-06-21 17:40:24.177784
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('''def f():\n{1: 2, **{3: 4}}\n{**{}}\n{1: 2}''')
    tr = DictUnpackingTransformer()
    node = tr.visit(tree)
    assert len(node.body) == 2
    assert isinstance(node.body[0], ast.Expr)
    assert isinstance(node.body[1], ast.FunctionDef)
    assert isinstance(node.body[1].body[0], ast.Expr)
    assert isinstance(node.body[1].body[0].value, ast.Call)
    assert isinstance(node.body[1].body[1], ast.Expr)
    assert isinstance(node.body[1].body[1].value, ast.List)

# Generated at 2022-06-21 17:41:21.816086
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import Dict, Call, Name, List, Load, Attribute, Module, \
        Str, Constant, Num, Tuple, Subscript, Index, BinOp, Compare, Eq

    assert DictUnpackingTransformer(None)._split_by_None([(Constant(42),)]) == [[(Constant(42),)]]
    assert DictUnpackingTransformer(None)._split_by_None([(None, Constant(42))]) == [Constant(42)]
    assert DictUnpackingTransformer(None)._split_by_None(
        [(Constant(42),), (None, Constant(43)), (Constant(44),)]) == [
        [(Constant(42),)], Constant(43), [(Constant(44),)]
    ]


# Generated at 2022-06-21 17:41:31.244014
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..visitor import visitor
    from ..utils.ast_helpers.add_keyword_arguments import add_keyword_arguments
    from ..utils.ast_helpers.inline_function_calls import inline_function_calls
    from ..utils.ast_helpers.remove_unused_function import remove_unused_function

    tree = ast.parse(
        """
        """ + merge_dicts.snippet + """
        def extends(x, y):
            return {**x, **y}
        
        def uses_extends(dict_a):
            return extends(x={1: 1}, y=dict_a)
        """
    )
    visitor(tree, DictUnpackingTransformer)
    visitor(tree, add_keyword_arguments)

# Generated at 2022-06-21 17:41:32.627766
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-21 17:41:34.026349
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    raise NotImplementedError

# Generated at 2022-06-21 17:41:41.551906
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astmonkey import transformers, visitors, traversal
    from astmonkey.visitors import NodeVisitor
    import ast

    source = """
        {
            'a': 1,
            **a,
            'b': 2,
        }
    """

    tree = ast.parse(source)
    transformer = transformers.DictUnpackingTransformer()
    transformer.visit(tree)

    expected = """
        _py_backwards_merge_dicts([{'a': 1}, 'b': 2], a)
    """

    visitor = NodeVisitor()
    visitor.visit(tree)

    assert ast.dump(tree).strip() == expected.strip()

# Generated at 2022-06-21 17:41:49.532302
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_code = """\
        print({1: 2, 3: 4})
        """
    expected_code = """\
        _py_backwards_merge_dicts = globals().__getitem__('_py_backwards_merge_dicts')

        print(_py_backwards_merge_dicts([{1: 2, 3: 4}]))
        """
    tree = ast.parse(test_code)
    DictUnpackingTransformer.run(tree)
    assert ast.dump(tree) == expected_code



# Generated at 2022-06-21 17:41:50.277883
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-21 17:41:53.973436
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast.ast3 import Dict
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import Num
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import dump
    import astunparse


# Generated at 2022-06-21 17:42:01.141279
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.test_utils import assert_tree_unchanged
    from .test_base import assert_node_transformed
    from .test_base import apply_to_single_node
    from .test_base import parse_code_as_module
    from .test_base import parse_code_as_suite
    from .test_base import transform_and_run
    from .test_base import transform_to_source

    def assert_merged(input_str, expected_str):
        assert_tree_unchanged(
            parse_code_as_module, transform_to_source, input_str)

    # In Python 3.5 this merge is not allowed.
    transform_and_run(
        parse_code_as_module, transform_to_source,
        "assert {**{}} == {}")

    # Empty

# Generated at 2022-06-21 17:42:02.932044
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert repr(DictUnpackingTransformer()) == "DictUnpackingTransformer()"



# Generated at 2022-06-21 17:43:51.548442
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): assert DictUnpackingTransformer()


# Generated at 2022-06-21 17:43:54.089727
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..preprocessor import Preprocessor
    Preprocessor(*DictUnpackingTransformer.get_transformer_classes())(
        merge_dicts.get_source_code()
    )



# Generated at 2022-06-21 17:44:04.472294
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from copy import deepcopy
    from textwrap import dedent
    from ..utils.source import source
    from ..utils.ast import get_node, node_to_source
    from ..utils.tree_equal import tree_equal

    base_code = dedent("""
    {'a': 1, 'b': 2, **{'c': 3, 'd': None}, **{'e': 5, 'f': 6}}
    """)

    expected_code = dedent("""
    _py_backwards_merge_dicts(
        [{'a': 1, 'b': 2, 'e': 5, 'f': 6}], 
        {'c': 3, 'd': None}
    )
    """)

    node = get_node(source(base_code))

# Generated at 2022-06-21 17:44:14.018511
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor

    # Prepare dummy nodes
    module = ast.Module(
        body=[
            ast.FunctionDef(
                name='f',
                args=ast.arguments(
                    args=[
                        ast.arg(
                            arg='a',
                            annotation=None),
                        ast.arg(
                            arg='b',
                            annotation=None)
                    ],
                    vararg=None,
                    kwonlyargs=[],
                    kw_defaults=[],
                    kwarg=None,
                    defaults=[])
            )])
    transformer = DictUnpackingTransformer()

    # Check
    assert transformer.visit_Module(module) == module
    assert astor.to_source(module) == 'def f(a, b):\n    pass\n'



# Generated at 2022-06-21 17:44:23.372850
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..types import PythonVersion
    from ..utils.testing import transform_visit
    from ..utils.source import source2ast, source2ast_str
    from .base import TransformerError

    source = '{1: 1}'
    node = source2ast(source)

    result = transform_visit(DictUnpackingTransformer, PythonVersion(3, 4), node)
    assert source == source2ast_str(result)

    source = '{1: 1, **dict_a}'
    node = source2ast(source)

    result = transform_visit(DictUnpackingTransformer, PythonVersion(3, 4), node)
    assert result == source2ast('_py_backwards_merge_dicts([{1: 1}], dict_a)')


# Generated at 2022-06-21 17:44:24.279872
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    print(DictUnpackingTransformer)

# Generated at 2022-06-21 17:44:29.449024
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    result = ast.parse("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    """)
    assert result == DictUnpackingTransformer().visit_Module(ast.Module())



# Generated at 2022-06-21 17:44:31.646231
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import parse

    source = '{1: 2, None: dict_a, 2: [1,2,3]}'


# Generated at 2022-06-21 17:44:42.276966
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import get_ast

    s = '''{1:2, 3:4}'''
    expected = '''{1:2, 3:4}'''

    assert get_ast(s) == get_ast(expected)

    s = '''{1:2, **dict_a}'''
    expected = '''_py_backwards_merge_dicts([{1: 2}], dict_a)'''

    assert get_ast(s) == get_ast(expected)

    s = '''{1:2, 3:4, **dict_a}'''
    expected = '''_py_backwards_merge_dicts([{1: 2, 3: 4}], dict_a)'''

    assert get_ast(s) == get_ast(expected)


# Generated at 2022-06-21 17:44:48.722538
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """\
    {
        **dict_a,
        1: 1,
        **dict_b,
        **dict_c
    }"""
    expected = """\
    _py_backwards_merge_dicts([], dict_a, dict({1: 1}), dict_b, dict_c)"""
    assert expected == DictUnpackingTransformer().transform(source)