

# Generated at 2022-06-21 17:35:18.878831
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import cst_to_ast

    xs = [
        None, None, None,
        ("key", "value")
    ]
    n = len(xs)

    def test(i):
        node = cst_to_ast({"": xs[:i]})
        t = DictUnpackingTransformer()
        result = t.visit(node)
        assert isinstance(result, ast.Dict)
        assert node != result
        assert result.keys == [None] * i

    for i in range(n):
        test(i)


# Generated at 2022-06-21 17:35:26.558415
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''\
{1: 2, None: dict_a, 2: 3, None: dict_b, 3: 4}
'''
    tree = ast.parse(source)
    node = tree.body[0].value
    assert isinstance(node, ast.Dict)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert transformer._tree_changed
    print(ast.dump(result))

# Generated at 2022-06-21 17:35:33.110159
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.ast_builder import build_ast
    from ..utils.transformer import transform
    from ..utils.tokenizer import tokenize
    from ..utils.source_printer import print_node


# Generated at 2022-06-21 17:35:35.660085
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert isinstance(transformer, BaseNodeTransformer)


# Generated at 2022-06-21 17:35:43.954326
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astunparse import dump
    from ..utils.graph import show_graph
    from ..utils.tree import to_dot
    import astor

    def assert_result(src, expected_src):
        node = ast.parse(src)
        DictUnpackingTransformer().visit(node)
        # to_dot(node, 'visit_Dict')
        # show_graph(node, 'visit_Dict')
        expected_node = ast.parse(expected_src)
        assert astor.to_source(node) == astor.to_source(expected_node)

    assert_result(
        '{}',
        '{}'
    )


# Generated at 2022-06-21 17:35:51.912100
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transpiler = DictUnpackingTransformer()
    result = transpiler.visit(ast.parse('{1: 1, **dict_a}'))
    assert ast.dump(result) == "Call(func=Name(id='_py_backwards_merge_dicts', ctx=Load()), " \
                               "args=[List(elts=[Dict(keys=[Num(n=1)], values=[Num(n=1)]), " \
                               "Name(id='dict_a', ctx=Load())], ctx=Load())], keywords=[])"

# Generated at 2022-06-21 17:35:57.591475
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed

    assert_transformed(
        DictUnpackingTransformer,
        {1: 1, **{2: 2}},
        '_py_backwards_merge_dicts([{1: 1}], {2: 2})')



# Generated at 2022-06-21 17:36:08.676091
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as pyast

    example = pyast.parse('''{1: 1, **dict_a}''')
    expected = pyast.parse('''_py_backwards_merge_dicts([{1: 1}], dict_a)''')
    executed = DictUnpackingTransformer().visit(example)
    assert isinstance(executed, pyast.Call)
    assert isinstance(executed.func, pyast.Name)
    assert executed.func.id == '_py_backwards_merge_dicts'
    assert isinstance(executed.args[0], pyast.List)
    assert len(executed.args[0].elts) == 1
    assert isinstance(executed.args[1], pyast.Name)

# Generated at 2022-06-21 17:36:19.162091
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """{1: 1, 2: 2, **a, **b, 3: 3}"""
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    result = ast.dump(tree)
    expected = """Module(body=[_py_backwards_merge_dicts(args=[List(elts=[Dict(keys=[Constant(value=1), Constant(value=2), Constant(value=3)], values=[Constant(value=1), Constant(value=2), Constant(value=3)]), a, b])])])"""

    assert result == expected

# Generated at 2022-06-21 17:36:21.115200
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # type: () -> None
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-21 17:36:30.226000
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .base import BaseNodeTransformer
    from typing import Union, Iterable, Optional, List, Tuple
    from typed_ast import ast3 as ast
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    code = '''
        class Foo(object):
            def __init__(self, foo: object = None, **kwargs: object) -> None:
                self._foo = foo
                self._bar = kwargs.get('bar', 2)
    '''

# Generated at 2022-06-21 17:36:32.176346
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # type: () -> None
    instance = DictUnpackingTransformer()

# Generated at 2022-06-21 17:36:41.398044
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Test for method visit_Dict of class DictUnpackingTransformer."""
    import ast as ast_
    from typed_astunparse import unparse

    # Without None
    code = "d1 = {0: '0'}"
    tree = ast_.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert unparse(tree) == code

    # With None
    code = "d2 = {0: '0', 1: '1', **{2: '2'}}"
    tree = ast_.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert unparse(tree) == "_py_backwards_merge_dicts([{0: '0', 1: '1'}], {2: '2'})"

    # With None in the end of

# Generated at 2022-06-21 17:36:52.822236
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    assert transformer.visit_Module(ast.parse('something', '<string>')) ==\
            ast.parse('something', '<string>')
    assert transformer.visit_Module(ast.parse('{1: 1, **{2: 2}}', '<string>')) ==\
            ast.parse(
                '_py_backwards_merge_dicts([{1: 1}], {2: 2})', '<string>')

# Generated at 2022-06-21 17:37:01.461704
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typing import Tuple, Callable, List
    from typed_ast import ast3
    from typepy.type import DictType
    from ._common import is_type_instance, is_type_type

    source = """
        a = {'a': 1, b: 2}
        {1: 1, 2: 2, **a, **b, **c}
        {**d}
        {1: 2}
        {1: 1, *g}
    """

    Module = ast3.Module
    FunctionDef = ast3.FunctionDef
    Load = ast3.Load
    Call = ast3.Call
    Name = ast3.Name
    Dict = ast3.Dict
    Str = ast3.Str
    Num = ast3.Num
    List = ast3.List
    Starred = ast3.Starred

# Generated at 2022-06-21 17:37:02.634014
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:37:05.179398
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.benchmarking import assert_converted_tree
    assert_converted_tree(DictUnpackingTransformer, '{1: 1}')



# Generated at 2022-06-21 17:37:15.064091
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
  class Test(unittest.TestCase):
    def test_one_None_in_keys(self):
      class FakeNodeTransformer:
        def __init__(self, node):
          self.node = node
        def generic_visit(self, node):
          ret = FakeNodeTransformer(node)
          return ret
      class FakeNode:
        def __init__(self, keys, values):
          self.keys = keys
          self.values = values
      node = FakeNode([1, 2, None, 5], [6, 7, 8, 9])
      dut = DictUnpackingTransformer()
      dut._generic_visit = lambda node: FakeNodeTransformer(node)
      ret = dut.visit_Dict(FakeNodeTransformer(node))

# Generated at 2022-06-21 17:37:16.978122
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    assert x is not None

# Generated at 2022-06-21 17:37:24.873918
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .base import BaseNodeTransformerTestCase

    class DictUnpackingTransformerTestCase(BaseNodeTransformerTestCase):
        transformer = DictUnpackingTransformer


# Generated at 2022-06-21 17:37:34.965229
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """No test cases."""
    assert True

# Generated at 2022-06-21 17:37:36.366263
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()



# Generated at 2022-06-21 17:37:41.544378
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """
    {1: 1, **dict_a}
    """

    res = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == res  # type: ignore

# Generated at 2022-06-21 17:37:50.012006
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-21 17:38:00.002910
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse("{1: 2, 3: 4, **{5: 6}, **{7: 8}, 9: 10}")
    DictUnpackingTransformer(tree).visit(tree)

# Generated at 2022-06-21 17:38:06.793306
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astunparse import unparse
    from ..utils.serialization import Block

    source = Block(r"""
    {a: x, b: y, z: z, **kwargs}
    """)

    expected = Block(r"""
    _py_backwards_merge_dicts([{a: x, b: y, z: z}], kwargs)
    """)

    actual = DictUnpackingTransformer().transform(source.root)
    assert unparse(actual) == expected

# Generated at 2022-06-21 17:38:17.616191
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import json
    from ..utils.create_module import create_module
    node = create_module(
        parse_body='''
            {1: 1, 2: 2, 3: 3, 4: 4, **dict_a}
        ''',
        parse_source='''
            from typing import Dict
            def f(dict_a: Dict):
                pass
        '''
    )
    result = DictUnpackingTransformer().visit(node)

# Generated at 2022-06-21 17:38:18.612627
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:38:26.848921
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    input = '''
        a = {1: 1, **d}
        b = {1: 1, **e}
        c = {1: 2, **f}
        d = {1: 2, **g}
        e = {1: 2, **h}
    '''

# Generated at 2022-06-21 17:38:31.412610
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import astor

    source = """
{1: 1, 2: 2, **a, **b, 3: 3, **c, **d}
"""
    expected = """
_py_backwards_merge_dicts([dict(3), dict(1: 1, 2: 2)], a, b, dict(3: 3), c, d)
"""
    tree = ast.parse(source)
    result = DictUnpackingTransformer().visit(tree)
    assert astor.to_source(result) == expected

# Generated at 2022-06-21 17:38:39.836481
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    code = """
        {1: 1, 2: 2, **a, 3: 3}
    """
    expected = """
        _py_backwards_merge_dicts([dict({1: 1, 2: 2}), a, dict({3: 3})])
    """
    tree = ast.parse(code)
    new_tree = transformer.visit(tree)
    to_source = astor.to_source  # type: ignore
    assert to_source(new_tree) == expected

# Generated at 2022-06-21 17:38:52.404284
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer0 = DictUnpackingTransformer()
    transformer1 = DictUnpackingTransformer()
    transformer2 = DictUnpackingTransformer()
    transformer3 = DictUnpackingTransformer()
    transformer4 = DictUnpackingTransformer()

    tr.run(transformer0, tr.load('{**a, **b, **c, **d}'))
    tr.run(transformer1, tr.load('{1: 1, **b}'))
    tr.run(transformer2, tr.load('{1: 1, **b, 2: 2}'))
    tr.run(transformer3, tr.load('{1: 1, **b, 2: 2, **c, 3: 3}'))

# Generated at 2022-06-21 17:38:53.829934
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None


# Generated at 2022-06-21 17:38:54.774339
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    data = DictUnpackingTransformer()

# Generated at 2022-06-21 17:39:00.020192
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('{1:1,2:2,**a}')
    result = DictUnpackingTransformer().visit(node)
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1, 2: 2}], a)')
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-21 17:39:10.459257
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def do_test(before, after, **kwargs):
        before_tree = ast.parse(before, **kwargs)
        after_tree = ast.parse(after, **kwargs)
        transformer = DictUnpackingTransformer()
        result = transformer.visit(before_tree)
        assert ast.dump(after_tree, **kwargs) == ast.dump(result, **kwargs)


# Generated at 2022-06-21 17:39:11.708817
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    _ = DictUnpackingTransformer()



# Generated at 2022-06-21 17:39:22.909713
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.test_utils import assert_tree_nodes

    tree = ast.parse('a = {1: 2, **a}')
    result = DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-21 17:39:31.489373
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_utils import compile_
    from .test_utils import assert_equivalent_bytecode
    from .test_utils import get_bytecode
    from .test_utils import make_Function_of
    from .test_utils import make_Module_of
    from .test_utils import make_Call_with

    # TODO: Use make_Module_of and make_Function_of

    result = compile_(
        make_Module_of(
            'a = {1: 2, **{"a": 1}}', 'b = {1: 2, **{"a": 1}, 3: 4}'),
        make_Call_with(DictUnpackingTransformer))


# Generated at 2022-06-21 17:39:32.274992
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-21 17:39:40.445567
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None, None)

# Generated at 2022-06-21 17:39:45.335144
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('''
{**dict_a}
''')
    expected = ast.parse(merge_dicts() + '''
{**dict_a}
''')
    result = DictUnpackingTransformer().visit(tree)
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-21 17:39:52.641841
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.utils import run_tb, assert_code_equal
    from textwrap import dedent

    code = dedent("""
    a = {1: 'a', **{'b': 'c'}}
    """)
    expected = dedent('''\
        a = _py_backwards_merge_dicts([{1: 'a'}], {'b': 'c'})''')
    assert_code_equal(run_tb(code, DictUnpackingTransformer), expected)

# Generated at 2022-06-21 17:40:02.217264
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = inspect.cleandoc(
        '''
        {1: 1, **a}
        ''')
    tree = ast.parse(source)
    result = DictUnpackingTransformer().visit(tree)
    expected = ast.parse(inspect.cleandoc(
        '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1}, a])
        '''))
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-21 17:40:05.883805
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer.tree_changed is False
    assert transformer.target == (3, 4)
    assert transformer.visit_Module is not None
    assert transformer.visit_Dict is not None
    assert transformer.generic_visit is not None

# Generated at 2022-06-21 17:40:12.143863
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.test import transform
    thr, out = transform(DictUnpackingTransformer, """
        {1: 1, **dict_a}
    """)
    expected = ast.parse("""
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)
    assert out == expected

# Generated at 2022-06-21 17:40:13.158528
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:40:23.330654
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.conftest import j
    from ..utils.tree import to_str
    from ..codegen import to_source
    from .base import BaseNodeTransformer
    transformer = DictUnpackingTransformer()
    tree = ast.parse(j('''
        a = {1: 1, **dict_a}
        {3: 3, **dict_b}
    '''))
    transformed = transformer.visit(tree)
    assert transformer._tree_changed

# Generated at 2022-06-21 17:40:34.866960
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{**{}, **{}, }')
    module = DictUnpackingTransformer().visit_Module(module)

# Generated at 2022-06-21 17:40:35.448060
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-21 17:40:57.608737
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """\
{**{}}\
"""
    tree = ast.parse(source)
    node = tree.body[0]
    assert isinstance(node, ast.Expr)
    node = node.value
    assert isinstance(node, ast.Dict)  # sanity check
    DictUnpackingTransformer().visit(tree)  # type: ignore

# Generated at 2022-06-21 17:41:06.206920
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import context, assert_code_equal
    from ..utils.parse import parse
    from_, to_ = context(__file__, 'test_DictUnpackingTransformer_visit_Dict')
    assert_code_equal(to_, DictUnpackingTransformer.run(parse(from_)))


__all__ = [
    'DictUnpackingTransformer',
    'test_DictUnpackingTransformer_visit_Dict',
]

# Generated at 2022-06-21 17:41:13.562319
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    source = """{1: 2, 3: 4, **{5: 6}, **{7: 8}, 9: 10, **{11: 12}}"""

# Generated at 2022-06-21 17:41:21.209742
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import parse, compare_source
    source = '{1: 1, 2: 2, 3: 3, **dict_a, 4: 4, 5: 5, **dict_b}'
    module = parse(source)
    visitor = DictUnpackingTransformer()
    module = visitor.visit(module)  # type: ignore
    expected = '_py_backwards_merge_dicts([dict([(1, 1), (2, 2), (3, 3)]), ' \
               'dict_a, dict([(4, 4), (5, 5)]), dict_b])'
    compare_source(module, expected)



# Generated at 2022-06-21 17:41:30.766952
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Unit test for method visit_Dict of class DictUnpackingTransformer."""
    node = ast.parse('{}')
    DictUnpackingTransformer().visit(node)
    assert ast.unparse(node) == '{}\n'

    node = ast.parse('{1}')
    DictUnpackingTransformer().visit(node)
    assert ast.unparse(node) == '{1}\n'

    node = ast.parse('{1: 2}')
    DictUnpackingTransformer().visit(node)
    assert ast.unparse(node) == '{1: 2}\n'

    node = ast.parse('{1: 2, 3: 4}')
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-21 17:41:37.229364
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    code = r"""
dict_a = {1: 3},
{1: 1, **dict_a}
"""
    tree = ast.parse(code, mode='exec')
    DictUnpackingTransformer(tree=tree).setup().visit()
    expected = '\n'.join([
        'dict_a = {1: 3},',
        '_py_backwards_merge_dicts([{1: 1}], dict_a}'
    ])  # noqa
    assert astor.to_source(tree).strip() == expected



# Generated at 2022-06-21 17:41:49.646609
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    assert astor.to_source(DictUnpackingTransformer()(parse('''
        {1: 1, **dict_a, 2: 2}
    '''))) == '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)\n'

    assert astor.to_source(DictUnpackingTransformer()(parse('''
        {**dict_a, 1: 1, 2: 2, **dict_b, **dict_c}
    '''))) == '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b, ' \
              'dict_c)\n'


# Generated at 2022-06-21 17:41:55.148140
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Asserts that:
    #   {1: 1, **dict_a}
    # is compiled to:
    #   _py_backwards_merge_dicts([{1: 1}], dict_a})
    import astor
    module = ast.parse("{1: 1, **dict_a, 2: 2}")
    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-21 17:41:59.559032
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import sys
    import unittest
    import ast as pyast

    class Test(unittest.TestCase):
        def test_ctor(self):
            _ = DictUnpackingTransformer()

    suite = unittest.TestLoader().loadTestsFromModule(sys.modules[__name__])
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-21 17:42:00.450356
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:42:38.626164
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.Module([
        ast.Dict(
            keys=[ast.Num(1), ast.Name(id='a')],
            values=[ast.Num(2), ast.Num(3)])
    ])

    print(ast.dump(node))
    DictUnpackingTransformer().visit(node)  # type: ignore
    print(ast.dump(node))

# Generated at 2022-06-21 17:42:40.280905
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:42:51.897333
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def check(body: ast.Dict, expected: ast.Module) -> None:
        node = ast.Module([body])
        node = DictUnpackingTransformer().visit(node)  # type: ignore
        assert node == expected

    body = ast.Dict(keys=[], values=[])
    expected = ast.Module([ast.Dict(keys=[], values=[]),
                           merge_dicts.get_body()])  # type: ignore
    check(body, expected)

    body = ast.Dict(keys=[None, None], values=[ast.Num(1), ast.Num(2)])

# Generated at 2022-06-21 17:42:52.711267
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:42:57.837009
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module = ast.parse('{}')
    transformer = DictUnpackingTransformer()
    transformer.visit(module)
    assert module
    assert isinstance(module, ast.Module)



# Generated at 2022-06-21 17:43:00.014645
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None


# Generated at 2022-06-21 17:43:01.557932
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:43:12.456858
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import Dict
    from typed_ast.ast3 import Name as Variable
    from typed_ast.ast3 import NameConstant
    from typed_ast.ast3 import Attribute

    test_case = Dict

# Generated at 2022-06-21 17:43:24.375309
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class Visitor(ast.NodeVisitor):
        def generic_visit(self, node):
            assert False, f'Node "{node}" is not supported by this test'


# Generated at 2022-06-21 17:43:31.686983
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from compiler import parse

    source = """{1: 1, **dict_a}"""
    expected = """def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result\n{1: 1, **dict_a}"""

    module = parse(source)
    node = DictUnpackingTransformer()(module)
    assert node == parse(expected)

# Generated at 2022-06-21 17:44:51.160792
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast

    node = ast.Module(body=[])
    transformer = DictUnpackingTransformer()
    node = transformer.visit_Module(node)
    assert len(node.body) == 1
    assert isinstance(node.body[0], ast.FunctionDef)
    merge_dicts_body = merge_dicts.get_body()

    def strip_newlines(x):
        return "\n".join([line.strip() for line in x.split("\n")])

    assert strip_newlines(merge_dicts_body) == strip_newlines(ast.dump(node))


# Generated at 2022-06-21 17:44:56.156955
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor  # type: ignore
    in_data = astor.to_source(ast.parse('{1: 1, 2: 2, **a, **b, 3: 3}'))
    out_data = astor.to_source(DictUnpackingTransformer().visit(ast.parse(in_data)))
    assert out_data == '_py_backwards_merge_dicts([{1: 1, 2: 2}, a, b, {3: 3}])'

# Generated at 2022-06-21 17:45:07.308248
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Proxy class of static type checker
    class DictUnpackingTransformerProxy(DictUnpackingTransformer):
        def __init__(self):
            super().__init__()
            self.tree_changed = 0

        @property
        def tree_changed(self):
            return self._tree_changed

        @tree_changed.setter
        def tree_changed(self, value):
            self._tree_changed = value
    my_DictUnpackingTransformer = DictUnpackingTransformerProxy()
    my_dict_unpacking_transformer_instance = ast.parse("""{1: 1, **dict_a}""")
    my_DictUnpackingTransformer.visit(my_dict_unpacking_transformer_instance)
    assert my_DictUnpackingTransformer.tree_changed == 1
    my

# Generated at 2022-06-21 17:45:09.392141
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    assert isinstance(x, BaseNodeTransformer)