

# Generated at 2022-06-21 17:35:17.120198
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
    {1: 1, **dict_a, None: None, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}, dict_a, dict_b])
    """
    assert DictUnpackingTransformer(source).code == expected



# Generated at 2022-06-21 17:35:20.991716
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    trans = DictUnpackingTransformer()
    ast.parse('{}')
    assert trans is not None, 'Cannot instantiate DictUnpackingTransformer'

# Generated at 2022-06-21 17:35:29.142499
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3
    node = ast3.parse('{**dict_a}')

    # Original AST
    assert repr(node) == repr(
        ast3.Module(
            body=[ast3.Expr(value=ast3.Dict(
                keys=[ast3.DictUnpack()],
                values=[ast3.Name(id='dict_a')]))]))

    # Transformed AST

# Generated at 2022-06-21 17:35:41.380383
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 17:35:42.981029
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    print(DictUnpackingTransformer)

# Generated at 2022-06-21 17:35:46.922814
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert DictUnpackingTransformer().visit(
        ast.parse(merge_dicts.src())) == ast.parse(merge_dicts.src())


# Generated at 2022-06-21 17:35:55.221603
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # nesting is supported
    expr = '{1: 1, **dict_a, 2: 2}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a, {2: 2})'

    assert DictUnpackingTransformer().visit(ast.parse(expr)) \
           == ast.parse(expected)

    # Dict without unpacking is unaffected
    assert DictUnpackingTransformer().visit(ast.Dict(keys=[], values=[])) \
           == ast.Dict(keys=[], values=[])

    # nothing to process
    assert DictUnpackingTransformer().visit(ast.parse('{**dict_a}')) \
           == ast.parse('{**dict_a}')

# Generated at 2022-06-21 17:35:57.618644
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None


# Generated at 2022-06-21 17:36:00.285796
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():  # noqa: F811
    """Tests that constructor of class DictUnpackingTransformer works fine."""
    transformer = DictUnpackingTransformer()
    assert transformer.tree_changed is False



# Generated at 2022-06-21 17:36:11.696614
# Unit test for constructor of class DictUnpackingTransformer

# Generated at 2022-06-21 17:36:22.970937
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    source = """\
        {'a': 2, 'b': {'e': 1, **{'d': 0}}, **{'c': 3}}
        """
    source = source.replace('\n', '')
    tree = ast.parse(source)
    tree = DictUnpackingTransformer().visit(tree)
    expected = """\
        MergeDicts()
        {'a': 2, 'b': {'e': 1, **{'d': 0}}, **{'c': 3}}
        """
    expected = expected.replace('\n', '')
    assert expected == ast.dump(tree)

# Generated at 2022-06-21 17:36:31.772998
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_astunparse import unparse
    import ast
    
    tree = ast.parse("{1: 2, None: None, 5: 6}")
    tree = DictUnpackingTransformer().visit(tree)
    assert unparse(tree) == "def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n\n_py_backwards_merge_dicts([{}, {1: 2}, {5: 6}])"


# Generated at 2022-06-21 17:36:39.268782
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    body = [ast.Expr(value=ast.Dict(keys=[], values=[]))]
    node = ast.Module(body=body)
    module = DictUnpackingTransformer().visit(node)  # type: ignore
    
    assert module.body[0].value.id == '_py_backwards_merge_dicts'
    assert module.body[1].value.id == '_py_backwards_merge_dicts'
    
    

# Generated at 2022-06-21 17:36:51.800154
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.unparse import unparse  # type: ignore

    tree = ast.parse('''
    {1: 2, **dict_a, 3: 4}
    ''')
    tree1 = ast.parse('''
    _py_backwards_merge_dicts([{1: 2}, dict_a, {3: 4}])
    ''')

    tree2 = ast.parse('''
    _py_backwards_merge_dicts([{1: 2}, {'a': 'b'}, {3: 4}])
    ''')

    transformer = DictUnpackingTransformer()
    # tree from example
    result1 = transformer.visit(tree)  # type: ignore
    assert unparse(result1) == unparse(tree1)
    # tree with const dict
   

# Generated at 2022-06-21 17:37:01.471255
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''\
{a: 1, b: 2}
{a: 1, **{b: 2}}
{a: 1, **{b: 2, **{c: 3}}}
'''
    expected = '''\
{a: 1, b: 2}
_py_backwards_merge_dicts([{a: 1}], {b: 2})
_py_backwards_merge_dicts([{a: 1}], {b: 2}, {c: 3})
'''
    result = DictUnpackingTransformer().visit(ast.parse(source))
    assert ast.dump(result) == ast.dump(ast.parse(expected))

# Generated at 2022-06-21 17:37:03.407462
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()
    return


# Generated at 2022-06-21 17:37:12.410734
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.snippet import as_tuple
    
    assert as_tuple(ast.Module()) == (
        ast.Module([], []),
    )

# Generated at 2022-06-21 17:37:23.580549
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    from ..utils.tree import DictUnpackingNodeFinder, DictUnpackingFinder
    from ..utils.test_utils import assert_source_equal
    from .dict_unpacking import DictUnpackingTransformer

    node = ast.parse("""
    def f():
        {**{1: 2}, **{3: 4}, 4: 5}
    """)
    DictUnpackingNodeFinder().visit(node)

    result = DictUnpackingTransformer().visit(node)
    DictUnpackingFinder().visit(result)
    assert_source_equal("""
    def f():
        _py_backwards_merge_dicts([{1: 2}, {3: 4}, {4: 5}])
    """, astor.to_source(result))

# Generated at 2022-06-21 17:37:26.786060
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .transpiler import Transpiler
    assert '_py_backwards_merge_dicts' in Transformer.get_snippets()

# Generated at 2022-06-21 17:37:30.024045
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:37:44.431593
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse

    code = '{True: None, None, "key": "value"}'
    expected = '_py_backwards_merge_dicts([{True: None}, "key"], "key")'

    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)

    assert astunparse.unparse(tree) == expected

# Generated at 2022-06-21 17:37:53.195018
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    # 1. Positive case
    source_ = '''
        d = {1: 1, **d1}
    '''

    expected_ = '''
        d = _py_backwards_merge_dicts([{1: 1}], d1)
    '''

    assert DictUnpackingTransformer().visit(source(source_)) == \
        source(expected_)

    # 2. Positive case
    source_ = '''
        d = {1: 1, **d1, **d2, 3: 3}
    '''

    expected_ = '''
        d = _py_backwards_merge_dicts([{1: 1}], d1, d2, {3: 3})
    '''


# Generated at 2022-06-21 17:37:54.795885
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    pairs = [(1, 2), (None, 3), (4, 5)]

# Generated at 2022-06-21 17:38:02.528898
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    class C:
        x: int
        y: int
        d: {str: str}
        def __init__(self):
            self.x = 1
            self.y = 4
            self.d = {'a': 'b', **{'c': 'd'}}

    node = ast.parse(inspect.getsource(C))
    expected = ast.parse(textwrap.dedent("""\
    class C:
    \tx: int
    \ty: int
    \td: {str: str}
    
    \tdef __init__(self):
    \t\tx = 1
    \t\ty = 4
    \t\td = _py_backwards_merge_dicts([{'a': 'b'}], {'c': 'd'})
    """))

# Generated at 2022-06-21 17:38:10.321125
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..parser import parse
    from ..unparser import Unparser

    source = """
        {1: 1, **c}
    """

    expected = """
        _py_backwards_merge_dicts([dict({1: 1})], c)
    """

    tree = parse(source)
    trans = DictUnpackingTransformer()
    trans.visit(tree)
    result = Unparser(tree).unparse()
    assert result == expected, result



# Generated at 2022-06-21 17:38:11.503970
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:38:21.584595
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    import textwrap

    code = textwrap.dedent("""
        {1: 10, **other_dict, 2: 20}
        {1: 10, **other_dict}
        {**other_dict, 2: 20}
        """).strip()

    expected_code = textwrap.dedent("""
        _py_backwards_merge_dicts([{1: 10}, other_dict], {2: 20})
        _py_backwards_merge_dicts([{1: 10}, other_dict])
        _py_backwards_merge_dicts([other_dict], {2: 20})
        """).strip()

    expected_tree = ast.parse(expected_code)
    transformed_tree = DictUnpackingTransformer().visit(ast.parse(code))

# Generated at 2022-06-21 17:38:22.487833
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:38:28.080357
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # pylint: disable=unused-variable
    @compile_to_python(DictUnpackingTransformer)
    def main():
        return {1: 1, 2: 2, **{3: 3, 4: 4, 5: 5}, 6: 6, **{7: 7, 8: 8}}
    print(main())
    assert main() == {1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8}

# Generated at 2022-06-21 17:38:28.558775
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-21 17:38:49.523967
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None)

# Generated at 2022-06-21 17:38:50.819478
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:38:52.208749
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Nothing to assert here
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:38:57.443888
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("{a: b, **c, 1: 2}")
    expected = ast.parse("{a: b, 1: 2}")

    transformer = DictUnpackingTransformer()
    actual = transformer.visit(module)

    actual = ast.fix_missing_locations(actual)
    expected = ast.fix_missing_locations(expected)
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-21 17:39:09.045358
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-21 17:39:17.271723
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_code_equal

    example = ast.parse(
        "a = {1: 2, 3: 4, 5: 6, **{7: 8, 9: 10}, 11: 12, 13: 14, **{15: 16}}")
    expected = ast.parse(
        """
a = _py_backwards_merge_dicts(
        [dict({1: 2, 3: 4, 5: 6}), {7: 8, 9: 10}, {11: 12, 13: 14}],
        {15: 16})
"""
    )

    assert_code_equal(expected, DictUnpackingTransformer().visit(example))

# Generated at 2022-06-21 17:39:25.731253
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import parse
    from ._testutils import roundtrip

    code = """
        {1: 1, None: {2: 2}, 3: 3}
        """
    expect = """
        _py_backwards_merge_dicts([{1: 1}, {3: 3}], {2: 2})
        """
    tree = parse(code)
    tr = DictUnpackingTransformer()
    tr.visit(tree)
    result = roundtrip(tree)
    assert result == expect
    


# Generated at 2022-06-21 17:39:29.660664
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import cst
    cst.inline_module(__name__, globals())

    node = ast.parse('''{1: 1, **dict_a}''').body[0]

    transformer = DictUnpackingTransformer()
    assert isinstance(transformer.visit(node), ast.Call)

# Generated at 2022-06-21 17:39:33.946059
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    code = r"""{1: 2, **dict_a}"""
    module = ast.parse(code)
    result = astor.to_source(DictUnpackingTransformer().visit(module))

# Generated at 2022-06-21 17:39:41.382412
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    t = DictUnpackingTransformer()
    x = ast.parse('''{1:1, **foo.bar}''')
    t.visit(x)
    assert isinstance(x.body[0], ast.Expr)
    assert isinstance(x.body[0].value, ast.Call)
    assert isinstance(x.body[0].value.func, ast.Name)
    assert x.body[0].value.func.id == '_py_backwards_merge_dicts'
    assert isinstance(x.body[0].value.args[0], ast.List)
    assert x.body[0].value.args[0].elts[0].keys[0].n == 1

# Generated at 2022-06-21 17:40:32.709938
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .visitor_test_mixin import _VisitorTestMixin, run_visitor_test
    from ..utils.tree import node_to_list

    class DictUnpackingTransformerTest(_VisitorTestMixin):
        TRANSFORMER = DictUnpackingTransformer
        NODE = ast.Dict

        @property
        def node(self):
            return self.NODE(keys=[None, ast.Constant(1), None],
                             values=[ast.Dict(keys=[], values=[]),
                                     ast.Constant(2),
                                     ast.Dict(keys=[ast.Constant(3)],
                                              values=[ast.Constant(4)])])


# Generated at 2022-06-21 17:40:34.221930
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    obj = DictUnpackingTransformer()
    assert obj is not None

# Generated at 2022-06-21 17:40:41.876866
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    source = """
x = {**{}}
a = {1: 2, **{3: 4}, 5: 6, **{7: 8}}
x = {**f()}
x = {**a, **b, **c}
"""
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    expected_source = """
_py_backwards_merge_dicts([dict([])])
_py_backwards_merge_dicts([dict([(1, 2)]), dict([(3, 4)]), dict([(5, 6)]), dict([(7, 8)])])
x = _py_backwards_merge_dicts([f()])
x = _py_backwards_merge_dicts([a, b, c])
"""


# Generated at 2022-06-21 17:40:42.326883
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-21 17:40:48.844667
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import source

    src = source('''
        foo = {1: 2, **bar}
    ''')
    result = source('''
        foo = _py_backwards_merge_dicts([{1: 2}], bar)
    ''')
    tr = DictUnpackingTransformer()
    assert tr.visit(src) == result



# Generated at 2022-06-21 17:40:52.970362
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''\
    def f(a, b):
        return {1: a, **b}
    '''

# Generated at 2022-06-21 17:40:57.489733
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = 3
    y = 5
    d = {'x': x, **{'y': y}}

    t = DictUnpackingTransformer()
    t.visit(d)

    assert t._tree_changed == True

# Generated at 2022-06-21 17:41:06.138797
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    f = ast.parse("""
{1: 1, **dict_a}
""")
    transformer = DictUnpackingTransformer()
    r = transformer.visit(f)
    assert transformer._tree_changed

    f = ast.parse("""
{1: 1, **dict_a, 2: 2, 3: 3}
""")
    transformer = DictUnpackingTransformer()
    r = transformer.visit(f)
    assert transformer._tree_changed

# Generated at 2022-06-21 17:41:10.893971
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    '''
    >>> import typed_ast.ast3 as ast
    >>> import compile_time_dynamic as ctd
    >>> src = '''

# Generated at 2022-06-21 17:41:20.979411
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()

# Generated at 2022-06-21 17:42:51.575869
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    (transformer, node) = snippet_to_ast(
        '{1: 1, **dict_a}',
        extra_imports=[DictUnpackingTransformer])

    expected = snippet_to_ast(
        """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """,
        extra_imports=[DictUnpackingTransformer])

    assert transformer.tree_changed
    assert expected.body[0].value == transformer.visit(node)

# Generated at 2022-06-21 17:42:54.014563
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)

# Generated at 2022-06-21 17:43:00.305394
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor  # type: ignore
    source = '''\
target = {'a': 1, **{'b': 2}, 'c': 3, **{}, **{'d': 4}, **{}}
'''
    result = DictUnpackingTransformer.run(source)

# Generated at 2022-06-21 17:43:11.369953
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dut = DictUnpackingTransformer()
    module = ast.parse('{1: 1, **dict_a}', 'str', 'eval')
    returned = dut.visit_Module(module)
    expected = ast.parse('""""""""\ndef _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n\n""""""""\n_py_backwards_merge_dicts([{1: 1}], dict_a})', 'str', 'exec')
    ast.fix_missing_locations(expected)
    assert_equal_ast(expected, returned)

# Generated at 2022-06-21 17:43:23.620182
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    from ast_compat import parse

    source = '''
        dict_a = dict(x=17)
        dict_b = {1: 1, **dict_a}
        '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        dict_a = dict(x=17)
        dict_b = _py_backwards_merge_dicts([{1: 1}], dict_a)
        '''

    module = parse(source)
    DictUnpackingTransformer().visit(module)
    assert astor.to_source(module).strip() == expected.strip()

# Generated at 2022-06-21 17:43:25.650261
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:43:32.604431
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    source = '''
{**a, b: 1}
'''
    expected = '''
_py_backwards_merge_dicts([b], a, {'b': 1})
'''
    tree = ast.parse(source)
    new_tree = transformer.visit(tree)
    result = compile(new_tree, '', 'exec')
    context = {}
    exec(result, context)
    assert context['_py_backwards_merge_dicts']



# Generated at 2022-06-21 17:43:44.834881
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''
            def merge_dicts1(dicts):
                result = {}
                for dict_ in dicts:
                    result.update(dict_)
                return result
            dict1 = {1: 2, **{3: 4, 5: 6}}
            '''  # noqa

# Generated at 2022-06-21 17:43:50.483935
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    result = transform(
        'x = {1: 1, **y["_"]}',
        3,
        4,
        [DictUnpackingTransformer])
    assert result == 'x = _py_backwards_merge_dicts([{1: 1}], y["_"])'

# Generated at 2022-06-21 17:43:58.731066
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.testing import dump_tree, load_tree
    from ..utils.testing import assert_trees_equal
    transformer = DictUnpackingTransformer(3.4)
    tree = load_tree('''
    {0: 1, 2: 3, **{4: 5, 6: 7}, 8: 9}
    ''')
    result = transformer.visit(tree)
    assert transformer.tree_changed
    assert_trees_equal(result, '''
    _py_backwards_merge_dicts([{0: 1}, {2: 3}], {4: 5, 6: 7}, {8: 9})
    ''')

# Generated at 2022-06-21 17:44:58.360680
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:45:05.329313
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """\
    a = {1: 1, **d}
    """
    expected = """\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    a = _py_backwards_merge_dicts([{1: 1}], d)
    """
    node = ast.parse(code)
    DictUnpackingTransformer().visit(node)
    assert expected == astunparse.unparse(node)
