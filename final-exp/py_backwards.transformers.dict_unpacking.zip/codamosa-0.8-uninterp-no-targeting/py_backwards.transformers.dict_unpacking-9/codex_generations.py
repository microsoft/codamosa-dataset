

# Generated at 2022-06-21 17:35:28.662508
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .test_utils import check_transformer
    from .test_utils import assert_equal_source

    @check_transformer
    def test_empty_dict():
        input = '''{}'''
        expect = '''{}'''
        assert_equal_source(expect, input)

    @check_transformer
    def test_dict_without_unpacking():
        input = '''{1: 1}'''
        expect = '''{1: 1}'''
        assert_equal_source(expect, input)

    @check_transformer
    def test_dict_with_one_unpacking():
        input = '''{1: 1, **dict_a}'''

# Generated at 2022-06-21 17:35:29.673742
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """
    Checks dictionary unpacking transform.
    """
    assert DictUnpackingTransformer != DictUnpackingTransformer

# Generated at 2022-06-21 17:35:38.083268
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import NodeTestCase

    class Test(NodeTestCase):
        target = ast.Dict
        transformer = DictUnpackingTransformer

# Generated at 2022-06-21 17:35:43.093942
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    sample_code = """
    original = {1: 1}
    dict_ = {2: 2}
    new = {3: 3, **dict_, **original}
    """
    expected_code = """
    original = {1: 1}
    dict_ = {2: 2}
    new = _py_backwards_merge_dicts([{3: 3}, dict_, original])
    """
    assert DictUnpackingTransformer(source=sample_code,
                                    filename='<test>').run() == expected_code

# Generated at 2022-06-21 17:35:44.537645
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:35:54.286135
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    isinstance(transformer, BaseNodeTransformer)
    assert transformer.target == (3, 4)

    assert transformer._split_by_None([]) == [[]]
    assert transformer._split_by_None([(None, '{}')]) == ['{}']
    assert transformer._split_by_None(
        [(None, '{}'), (1, 'a'), (None, '{}')]) == ['{}', [(1, 'a')], '{}']


# Generated at 2022-06-21 17:35:59.670760
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tr = DictUnpackingTransformer()
    code = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a})
    """
    assert expected == astor.to_source(tr.visit(astor.parse_file(StringIO(code))))


# Generated at 2022-06-21 17:36:10.735157
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    s = """{1: 2, **a}"""
    node = ast.parse(s)
    result = ast.dump_with_indent(DictUnpackingTransformer().visit(node))
    expected = "\n".join([
        "Module(body=[",
        "  Expr(value=Call(func=Name(id='_py_backwards_merge_dicts', ctx=Load()), args=[List(elts=[Dict(keys=[Num(n=1)], values=[Num(n=2)]), Name(id='a', ctx=Load())], ctx=Load())], keywords=[]),",
        ")])"])
    assert result == expected



# Generated at 2022-06-21 17:36:19.038963
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import transform, compare_asts

    transformer = DictUnpackingTransformer('test')
    compare_asts(
        transform(
            transformer,
            """{1: 1, **dict_a, 2: 2, **dict_b, **dict_c}""",
            "<test>"),
        """_py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, dict_b, dict_c])""")

# Generated at 2022-06-21 17:36:31.811856
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().visit(
        ast.parse('{1:1}')) == ast.parse('{1:1}')

    node = ast.parse('{1:1, **kwargs}')
    node_new = ast.parse(
        '_py_backwards_merge_dicts([d1], kwargs)')
    assert DictUnpackingTransformer().visit(node) == node_new

    node = ast.parse('{**kwargs, **xkwargs}')
    node_new = ast.parse(
        '_py_backwards_merge_dicts([kwargs, xkwargs])')
    assert DictUnpackingTransformer().visit(node) == node_new


# Generated at 2022-06-21 17:36:53.201207
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    pairs = [
        (None, ast.Name(id='dict_a')),
        (None, ast.Name(id='dict_b')),
        (ast.Num(n=1), ast.Num(n=1)),
        (ast.Str(s='two'), ast.Num(n=2)),
        (None, ast.Name(id='dict_c'))
    ]


# Generated at 2022-06-21 17:36:59.514508
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    import ast
    import astunparse

    code = """\
        {**a, **b, **c, **d}
        """
    parsed = ast.parse(dedent(code))

    expected = """\
        _py_backwards_merge_dicts([], a, b, c, d)
        """
    transformed = DictUnpackingTransformer().visit(parsed)
    assert astunparse.unparse(transformed) == dedent(expected)



# Generated at 2022-06-21 17:37:05.907637
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from pysemantic.utils.tree import ast_to_dict

    ast_dict = ast_to_dict({**{1: 1}, **{2: 2}})
    excepted = ast_to_dict({1: 1, 2: 2})
    assert excepted == ast_dict

# Generated at 2022-06-21 17:37:15.555268
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    x = '{1: 1, **d}'.strip()
    node = ast.parse(x)
    transformer = DictUnpackingTransformer()
    node = transformer.visit(node)
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[1], ast.Expr)
    assert isinstance(node.body[1].value, ast.Call)
    func = node.body[1].value.func
    assert isinstance(func, ast.Name)
    assert func.id == '_py_backwards_merge_dicts'
    a, b = node.body[1].value.args
    assert isinstance(a, ast.List)
    assert isinstance(b, ast.Name)
    assert len(node.body[1].value.args) == 2
    assert len

# Generated at 2022-06-21 17:37:24.489734
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.compat import print
    from .unparse import unparse

    empty_dict = ast.Dict(keys=[], values=[])
    print(unparse(empty_dict))  # {}

    singleton_dict = ast.Dict(keys=[ast.Constant(value='a')],
                              values=[ast.Constant(value=1)])
    print(unparse(singleton_dict))  # {'a': 1}

    unpacking_dict = ast.Dict(keys=[None, ast.Constant(value='c')],
                              values=[ast.Constant(value='b'),
                                      ast.Constant(value=2)])
    print(unparse(unpacking_dict))  # {**'b', 'c': 2}


# Generated at 2022-06-21 17:37:35.301576
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Test for method visit_Dict of class DictUnpackingTransformer."""
    import unittest
    import astor

    class TestCase(unittest.TestCase):

        def setUp(self) -> None:
            self.transformer = DictUnpackingTransformer()

        def run_test(self, expected: str, program: str):
            tree = ast.parse(program)
            self.transformer.visit(tree)
            assert astor.to_source(tree).strip() == expected.strip()

    test_case = TestCase()
    test_case.run_test(expected=merge_dicts.get_source() + '\n{1: 1}', program='{1: 1}')

# Generated at 2022-06-21 17:37:37.561671
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer is not None

# Generated at 2022-06-21 17:37:38.543388
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer

# Generated at 2022-06-21 17:37:39.471036
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:37:50.710784
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('''
    {1: 1, **dict_a} 
    ''')
    assert ast.dump(node, annotate_fields=False) == \
           'Module(body=[Dict(keys=[Num(n=1), None], values=[Num(n=1), Name(id="dict_a", ctx=Load())])])'

# Generated at 2022-06-21 17:37:58.369558
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None, None)

# Generated at 2022-06-21 17:38:00.672910
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3
    node = ast3.Module()
    for stmts in merge_dicts.stmts():
        stmt = ast3.parse(stmts)
        node.body.append(stmt)

    t = DictUnpackingTransformer()
    assert node == t.visit(node)


# Generated at 2022-06-21 17:38:02.383577
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast
    from untokenize import untokenize
    from asttokens import ASTTokens
    from pprint import pprint

# Generated at 2022-06-21 17:38:03.558292
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:38:10.935817
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import round_trip
    
    code = """
    dict(a=1, **y, **z)
    """
    expected = """
    _py_backwards_merge_dicts([dict(a=1)], y, z)
    """
    module, _ = round_trip(code, transform=DictUnpackingTransformer)
    assert expected.strip() == ast.dump(module).strip()


# Generated at 2022-06-21 17:38:20.291795
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:38:27.175188
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..tools.helpers import get_ast
    from ..tools.visitor import PrintAstVisitor

    code = """
        {None: None, **{1: 2}}
    """

    expected = """
        _py_backwards_merge_dicts([dict(None), {1: 2}])
    """

    module = get_ast(code)
    transformer = DictUnpackingTransformer()
    transformer.visit(module)
    transformed = module

    assert PrintAstVisitor().visit(transformed) == expected



# Generated at 2022-06-21 17:38:33.314649
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    x = {1: 1, 2: 2, 3: 3, **dict_a}  # type: ignore


# Generated at 2022-06-21 17:38:39.751410
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3
    from .utils import print_ast
    from _ast_transformer_tests.utils import assert_transformed
    from _ast_transformer_tests.transformer_tests.test_dict_unpacking_transformer import DictUnpackingTransformer
    code = """
    a = {1: 1, 2: 2, **D}
    """
    module = ast3.parse(code)

# Generated at 2022-06-21 17:38:46.177953
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert merge_dicts.get_body() == "def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n"

# Generated at 2022-06-21 17:39:00.531607
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(target=(3, 4)) # noqa

# Generated at 2022-06-21 17:39:09.939424
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .visitors import CodeVisitor
    from .visitors import PrintAstVisitor

    code = '{1: 2, None: {3: 4, None: dict(a=5, b=6)}}'
    ast_node = compile(code, filename=None, mode='eval',
                       flags=ast.PyCF_ONLY_AST)

    x = DictUnpackingTransformer()
    node = x.visit(ast_node)

    assert CodeVisitor.code(node) ==\
        "_py_backwards_merge_dicts([{1: 2}], dict({3: 4}), dict(a=5, b=6))"
    assert x._tree_changed is True


# Generated at 2022-06-21 17:39:20.046688
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    v = DictUnpackingTransformer()
    v.visit(ast.parse("""
        def foo(x, y):
            z = {1: 1, **y}
        """))

    # This is a test for the constructor of class DictUnpackingTransformer.
    # pylint: disable=unused-variable
    # class v:
    #     def visit_Module(self, node):
    #         print(node)
    #         print(node.body[0].args.args)
    #         print(node.body[0].args.args[0].keys)
    #         print(node.body[0].body[0].value.func)
    #         print(node.body[0].body[0].value.args[0])
    #         print(node.body[0].body[0

# Generated at 2022-06-21 17:39:30.497322
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import textwrap
    import itertools
    
    from typish.utils.tree import to_source
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import Dict
    from typed_ast.ast3 import Name
    
    from typed_astunparse import unparse
    
    from .class_member_visibility import ClassMemberVisibilityTransformer
    from .class_property_transformer import ClassPropertyTransformer

    # Define a fixture for testing
    @snippet
    def dict_unpacking_snippet():
        dict_a = {2:2, 3:3}
        x = {1:1, 2:2, **dict_a}
        class X:
            z = {1:1, **dict_a}
    

# Generated at 2022-06-21 17:39:39.848264
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    ast_ = ast.parse("{1: 1, **dict_a}")
    DictUnpackingTransformer().visit(ast_)
    print(ast.dump(ast_))

# Generated at 2022-06-21 17:39:48.708614
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().__class__.__name__ == 'DictUnpackingTransformer'
    assert DictUnpackingTransformer.__doc__ == """Compiles:\n    \n        {1: 1, **dict_a}\n        \n    To:\n    \n        _py_backwards_merge_dicts([{1: 1}], dict_a})"""
    assert DictUnpackingTransformer.__module__ == 'pythran.passmanager.transformations.DictUnpackingTransformer'
    assert DictUnpackingTransformer.target == (3, 4)


# Generated at 2022-06-21 17:39:52.392377
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse("{1: 1, 2: 2, **dict_a, 3: 3, **dict_b}")
    assert isinstance(node.body[0], ast.Expr)
    result = DictUnpackingTransformer(None).visit(node)
    assert isinstance(result, ast.Call)
    assert result.func.id == '_py_backwards_merge_dicts'
    assert result.args[0].elts[0].keys == [ast.Num(1), ast.Num(2)]
    assert result.args[0].elts[1].id == 'dict_a'
    assert result.args[0].elts[2].keys == [ast.Num(3)]
    assert result.args[0].elts[3].id == 'dict_b'


# Unit test

# Generated at 2022-06-21 17:39:55.426164
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert not hasattr(DictUnpackingTransformer, 'visit_Dict')  # type: ignore
    assert hasattr(DictUnpackingTransformer, '_visit_Dict')  # type: ignore
    transformer = DictUnpackingTransformer()

# Generated at 2022-06-21 17:39:56.768119
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)

# Generated at 2022-06-21 17:39:58.753866
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-21 17:40:10.989845
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..testing.common import generate_fixture
    from ..testing.transformers import TreeComparison
    from ..testing.types import UnitTest, UnitTestGroup
    from ..testing.utils import compile_source, ast_equal

    def assert_transformed(source: str, expected: str) -> None:
        actual = compile_source(source, DictUnpackingTransformer)
        ast_equal(actual, expected)

    test_group = UnitTestGroup('DictUnpackingTransformer',
                               init_params=[DictUnpackingTransformer])
    test_group.add_test(UnitTest(
        actual=DictUnpackingTransformer().visit_Dict(
            ast.parse('{}').body[0].value),
        expected=ast.parse('dict()').body[0].value))
    test_group.add_

# Generated at 2022-06-21 17:40:21.555851
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import unittest

    class TestDictUnpackingTransformer(unittest.TestCase):
        def test_split_by_None(self):
            self.assertEqual(
                DictUnpackingTransformer()._split_by_None([
                    ('a', 'b'), ('c', None), ('d', 'e'), (None, 'f'),
                    ('g', 'h')]),
                [[('a', 'b')], 'f', [('d', 'e'), ('g', 'h')]])


# Generated at 2022-06-21 17:40:32.631446
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ...utils import dump
    from . import ast_compare

    def test(node, expected):
        result = DictUnpackingTransformer().visit(node)
        assert ast_compare(result, expected)


# Generated at 2022-06-21 17:40:33.806168
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None)

# Generated at 2022-06-21 17:40:41.053587
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    dut = DictUnpackingTransformer()
    code = '''\
{**dict_a, 1: 1}
{1: 1, **dict_a}
{1: 1, 2: 2, **dict_a}
{1: 1, None: 2, **dict_a}
{1: 1, 2: 2, None: 3, **dict_a}
{1: 1, 2: 2, None: 3, None: 4, **dict_a}
{1: 1, 2: 2, None: 3, None: 4, 5: 5, **dict_a}
'''

# Generated at 2022-06-21 17:40:43.058401
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer.target == (3, 4)

# Generated at 2022-06-21 17:40:46.874719
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # GIVEN
    None
    # WHEN
    transformer = DictUnpackingTransformer()
    # THEN
    assert transformer
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:40:59.451011
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    from ..utils.source import source_to_ast

    def test(code: str, expected: str) -> None:
        ast_ = source_to_ast(dedent(code))
        ast_ = DictUnpackingTransformer().visit(ast_)  # type: ignore
        result = ast.dump(ast_)
        assert result == dedent(expected)

    test('{**a}', '_py_backwards_merge_dicts([], a)')

    code = """
    {**a, **b, **c}
    """
    expected = """
    _py_backwards_merge_dicts([_py_backwards_merge_dicts([], a), b], c)
    """
    test(code, expected)


# Generated at 2022-06-21 17:41:07.997844
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dct = ast.parse("""{1: 1, **dict_a, 2:2}""").body[0].value
    transformer = DictUnpackingTransformer()
    returned = transformer.visit(dct)
    assert transformer._tree_changed

    expected = ast.parse("""
_py_backwards_merge_dicts(
    [
        {1: 1},
        dict_a
    ],
    {2: 2}
)""")
    assert_equal_ignore_linenos(expected, returned.body[0].value)



# Generated at 2022-06-21 17:41:09.056597
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-21 17:41:27.294767
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = \
    """
    {1: 1}
    """
    expected = \
    """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    
    {1: 1}
    """
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    actual = ast.unparse(tree)
    print(actual)
    assert actual == expected



# Generated at 2022-06-21 17:41:39.540648
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def test(code, expected):
        tree = ast.parse(code)
        transformer = DictUnpackingTransformer()
        tree = transformer.visit(tree)
        assert ast.dump(tree) == expected
        assert transformer._tree_changed is True

    code = """\
        {1: 1, **dict_a}
    """
    expected = """\
        {
            _py_backwards_merge_dicts([{1: 1}], dict_a);
        }
    """
    test(code, expected)

    code = """\
        {1: 1, 2: 2, **{'a': 'b'}, **dict_b}
    """

# Generated at 2022-06-21 17:41:40.328872
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer

# Generated at 2022-06-21 17:41:51.033786
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    f = ast.parse('{1: 1, **dict_a}')
    node = DictUnpackingTransformer().visit(f)
    print(ast.dump(node))


# Generated at 2022-06-21 17:41:52.941554
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
{**dict_a}
"""

# Generated at 2022-06-21 17:42:00.916911
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..message import Message
    from ..transformer.ast_transformer import Transformer
    from ..utils.tree import ast_tree
    from ..utils.file_io import create_tempfile

    with create_tempfile(  # type: ignore
            '''
            import collections
            import typing
            
            def foo(bar: None = ...) -> typing.Dict[str, typing.Any]:
                return {"baz": 1}
            '''
    ) as src_py, create_tempfile(  # type: ignore
    ) as dst_py:
        src_py.write_text('{**foo(), "zoo": 2}')
        transformer = Transformer(src_py.as_posix(), [])

        messages = transformer.run(transformer_class=DictUnpackingTransformer)  # type: ignore


# Generated at 2022-06-21 17:42:02.970979
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    trans = DictUnpackingTransformer()
    assert trans.__class__.__name__ == 'DictUnpackingTransformer'

# Generated at 2022-06-21 17:42:07.934356
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_utils import make_call_test

    make_call_test(
        DictUnpackingTransformer,
        '{1: 1, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')



# Generated at 2022-06-21 17:42:18.824310
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_block

    src = """
x = {1, 2, **a, 3, 4}
y = {5, 6, **b, 7, 8}
    """

    expected = """
x = _py_backwards_merge_dicts([{1, 2}, a, {3, 4}])
y = _py_backwards_merge_dicts([{5, 6}, b, {7, 8}])
    """
    assert_block(expected, src, transformer=DictUnpackingTransformer)

# Generated at 2022-06-21 17:42:29.899274
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import parse
    from astunparse import unparse

    code = '''
some_dict = {1: 1, 2: 2, **dict_a,
             **dict_c,
             **dict_b,
             3: 3}
    '''
    ast_node = parse(code).body[0]
    transformed_ast_node = DictUnpackingTransformer().visit(ast_node)
    assert unparse(transformed_ast_node) == '''
some_dict = _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_c, dict_b, {3: 3})
    '''

# Generated at 2022-06-21 17:42:53.577834
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:43:02.696183
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''
        {1: 1, 2: 2, 3: 3, **x, **y, **z}
    '''
    transformed_code = transform(code, DictUnpackingTransformer)
    merged = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}, {2: 2}, {3: 3}, dict(x), dict(y), dict(z)])
    '''
    assert transformed_code == merged

# Generated at 2022-06-21 17:43:12.405085
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..compiler import compile_snippet
    from .cls_renamer import ClassRenamer
    from .check_syntax import CheckSyntax
    expected = compile_snippet(merge_dicts.get_body())
    code = compile_snippet("""
        class A(object):
            def m(self):
                {1:1, **{2:2}}
    """)
    module = DictUnpackingTransformer().visit(code)
    module = ClassRenamer().visit(module)
    module = CheckSyntax().visit(module)  # type: ignore
    actual = compile_snippet(module)
    print(expected)
    print(actual)
    assert actual == expected


# Generated at 2022-06-21 17:43:14.261568
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:43:15.624155
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:43:19.702247
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # assert isinstance(DictUnpackingTransformer(), BaseNodeTransformer)
    assert isinstance(DictUnpackingTransformer(), NodeTransformer)

# Generated at 2022-06-21 17:43:24.900442
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:43:32.714702
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import round_trip_load
    tree1 = ast.parse('{1: 1, 2: 2, **DICT}')
    tree2 = round_trip_load(tree1)
    assert tree2.body[0].value.func.id == '_py_backwards_merge_dicts'

    tree1 = ast.parse('{1: 1, 2: 2, **DICT1, **DICT2}')
    tree2 = round_trip_load(tree1)
    assert tree2.body[0].value.func.id == '_py_backwards_merge_dicts'

# Generated at 2022-06-21 17:43:44.927763
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import parse, compare_ast
    from .check import CheckVisitor
    from ..utils.testing import local_import
    local_import('typed_astunparse')

    code_before = """
a = {1: 1, **dict_a}
"""
    code_after = """
a = _py_backwards_merge_dicts([{1: 1}], dict_a)
"""
    tree_before = parse(code_before)
    CheckVisitor().visit(tree_before)
    tree_after = parse(code_after)
    CheckVisitor().visit(tree_after)

    transformer = DictUnpackingTransformer()
    tree_transformed = transformer.visit(tree_before)
    assert transformer.tree_changed

# Generated at 2022-06-21 17:43:46.404896
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    d = DictUnpackingTransformer()
    assert d is not None

# Generated at 2022-06-21 17:44:33.372348
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    program = ast.parse('''
{1: 1, 2: 2, **{3: 3}}
    ''')
    expected_program = ast.parse('''
_py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3}])
    ''')
    program = DictUnpackingTransformer().visit(program)  # type: ignore
    assert ast.dump(expected_program, False) == ast.dump(program, False)



# Generated at 2022-06-21 17:44:42.854706
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTransformerTest

    source = '{1: 1, **{2: 2}, 3: 3, 4: 4, **{5: 5}, **{6: 6}}'
    expected = 'dict(**_py_backwards_merge_dicts([dict({1: 1}, {3: 3}, {4: 4}), {2: 2}, {5: 5}, {6: 6}))'

    transformer = DictUnpackingTransformer()
    passed, result = BaseNodeTransformerTest.test(transformer, source, expected)
    print(BaseNodeTransformerTest.format_test_result(
        source, expected, 'DictUnpackingTransformer.visit_Dict', passed, result))
    return passed
test_DictUnpackingTransformer_visit_Dict()



# Generated at 2022-06-21 17:44:52.903987
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''{1: 1, 2: 2, 3: 3, **dict_a, 4: 4, 5: 5}'''
    source = ast.parse(code)  # type: ignore
    node = \
        ast.parse('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        ''').body[0]  # type: ignore
    transformer = DictUnpackingTransformer()
    transformer.visit(source)
    assert len(source.body) == 1  # type: ignore
    assert node == source.body[0]  # type: ignore


# Generated at 2022-06-21 17:44:54.082482
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(tree=None) is not None

# Generated at 2022-06-21 17:45:04.513833
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    import astor
    class_ = ast.ClassDef(name='Foo', body=[ast.FunctionDef(name='bar', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Expr(value=ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=2)], values=[ast.Num(n=1), ast.Dict(keys=[ast.Num(n=3)], values=[ast.Num(n=4)]), ast.Num(n=3)]))], decorator_list=[], returns=None)])
    result = DictUnpackingTransformer(ast.Module(body=[class_])).result()

# Generated at 2022-06-21 17:45:15.906168
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import parse

    source = """
    {1: 1, 2: 2, 3: 3, **a, 4: 4, 5: 5, **b, 6: 6, **c}
    """

    module = parse(source)

    tree = DictUnpackingTransformer().visit(module)
    lines = [line.strip() for line in ast.dump(tree).splitlines()
             if line.strip()]
