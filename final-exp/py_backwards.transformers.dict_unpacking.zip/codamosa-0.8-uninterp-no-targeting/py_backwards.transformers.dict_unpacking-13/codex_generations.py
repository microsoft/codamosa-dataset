

# Generated at 2022-06-21 17:35:19.387096
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """
        Code:
            {
                **a,
                1: 2,
                **b,
                **c
            }

        Should compile to:
            _py_backwards_merge_dicts(
                dict(1=2),
                a, b, c
            )
    """

    import astor
    module = ast.parse("""{
                **a,
                1: 2,
                **b,
                **c
            }""")

    from . import templated_transformer
    transformer = templated_transformer(DictUnpackingTransformer)
    module = transformer.visit(module)

# Generated at 2022-06-21 17:35:21.261855
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from astunparse import unparse

# Generated at 2022-06-21 17:35:30.063127
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .utils import assert_equal, transform

# Generated at 2022-06-21 17:35:32.735968
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_astunparse
    tree = ast.parse("""
    def foo():
        pass

    def bar():
        pass
    """)
    result = DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-21 17:35:41.735000
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.lark import get_node_from_text
    from .base import BaseNodeTransformer
    from .unparse import UnparseTransformer

    class CombineTransformer(BaseNodeTransformer):
        def __init__(self):
            self.transformers = [
                DictUnpackingTransformer(),
                UnparseTransformer(),
            ]

    class_def = get_node_from_text(
        """
        class Foo(object):
            def bar(self):
                foo = {1: None, **bar, 2: 3}
        """
    )

# Generated at 2022-06-21 17:35:53.163932
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3, parse
    from .base import BaseNodeTransformer_repr
    class T(BaseNodeTransformer):
        target = (3, 4)
        def visit_Dict(self, node):
            return ast3.parse('True').body[0]
    T = DictUnpackingTransformer()
    examples = [
"""
x = {1: 1}
""",
"""
x = {**{1: 1}}
""",
"""
x = {1: 1, **{2: 2}}
""",
"""
x = {1: 1, **{2: 2}, 3: 3, **{4: 4}}
""",
    ]
    for ex in examples:
        print('-'*10+'Source')
        print(ex)
        tree = ast3.parse(ex)


# Generated at 2022-06-21 17:35:58.754362
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
{
    'a': 1,
    None: {'b': 2, 'c': 3},
    'd': 4,
    None: {'e': 5, 'f': 6},
}
    """
    excepted = """
_py_backwards_merge_dicts([{'a': 1, 'd': 4}], {'b': 2, 'c': 3}, {'e': 5, 'f': 6})
    """

    result = DictUnpackingTransformer().__call__(source)
    assert result.strip() == excepted.strip()

# Generated at 2022-06-21 17:36:11.326129
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import test_transformer
    from ..utils.test_utils import can_compile_snippet

    if can_compile_snippet():

        def transform(module, **kwargs):
            DictUnpackingTransformer(**kwargs).visit(module)

        def test_module(src, expected):
            test_transformer(src, expected, transform)


# Generated at 2022-06-21 17:36:15.233922
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from . import run_transformer
    tree = ast.parse('d = {1:1, **{2: 2}}')
    actual = run_transformer(tree, DictUnpackingTransformer)
    expected = source(merge_dicts) + 'd = _py_backwards_merge_dicts([{1: 1}, {2: 2}])'
    assert expected == source(actual)



# Generated at 2022-06-21 17:36:23.598003
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module, Dict, DictComp, Expr, binop, Call, Name
    from typed_ast.ast3 import Load, Str, keyword, List, Attribute, Store
    from .base import BaseNodeTransformer
    from . import dict_unpacking
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet
    from . import macro

    @snippet
    def macro_dict_unpacking():
        def macro_dict_unpacking(
            dicts: Iterable[Union[dict, "ast.Callable"]],
            *,
            macros: Optional[Iterable[str]] = None,
            debug: bool = False
        ) -> Union[dict, list]:
            pass


# Generated at 2022-06-21 17:36:37.820576
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
        {
            1: 1,
            **a
        }
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], a)
    """
    tree = ast.parse(code)  # type: ignore
    DictUnpackingTransformer().visit(tree)  # type: ignore
    assert_equals(ast.dump(tree).strip(), expected.strip())


# Generated at 2022-06-21 17:36:39.270797
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-21 17:36:45.645087
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ast import parse
    from .transformers import DictUnpackingTransformer
    module = parse("""""")
    transformer = DictUnpackingTransformer()
    transformer.visit(module)
    assert transformer.tree_changed == False
    assert module == parse("""""")


# Generated at 2022-06-21 17:36:50.523265
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    from ..utils.test import assert_transformed_code, assert_unchanged_code

    code = dedent('''
    {
        1: 1,
        **a,
        2: 2,
        **b,
        3: 3,
        **c,
        4: 4
    }
    ''')
    expected = dedent('''
    _py_backwards_merge_dicts([
        {1: 1,
         2: 2,
         3: 3,
         4: 4},
        a,
        b,
        c])
    ''')
    assert_transformed_code(code, expected, DictUnpackingTransformer)


# Generated at 2022-06-21 17:37:01.852590
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast.ast3 import Module, Expr, FunctionDef
    from tree_sitter import Language

    from ...utils.tree import parse_module
    from ...utils.snippet import snippet

    language = Language()
    with open('snippets/python_sample.tree-sitter.wasm', 'rb') as f:
        language.load(f.read())


# Generated at 2022-06-21 17:37:12.247341
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3 as ast

    tree = ast.parse(textwrap.dedent('''
        {1: 1, **dict_a}
    '''))

    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)

    # Преобразовываем дерево в строку и проверяем результат

# Generated at 2022-06-21 17:37:17.047038
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse(
        """\
{**a, 2: "b", 1: None, **c}\
""")  # noqa: E501


# Generated at 2022-06-21 17:37:24.873321
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from libmodernize.utils.test_utils import assert_equal_with_printing

    code = '''
    def f():
        {1: 1, **{2: 2}}
        {1: 1, **a, **{2: 2}}
        {1: 1, **{2: 2}, **a}
        {1: 1, **a, **b}
    '''

# Generated at 2022-06-21 17:37:35.478431
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_python import ast3
    from typed_python.compiler.type_wrappers.wrapper import Wrapper
    from typed_python.compiler.conversion_level import ConversionLevel
    from typed_python.compiler.type_wrappers.bound_method_wrapper import BoundMethodWrapper

    for source in [
        "def f():\n    return {1: 1, **x}"
    ]:
        module = ast3.parse(source)
        module = DictUnpackingTransformer().visit(module)

        assert isinstance(module.body[1], ast3.FunctionDef)
        assert isinstance(module.body[1].body[0], ast3.Return)
        assert isinstance(module.body[1].body[0].value, ast3.Call)

# Generated at 2022-06-21 17:37:45.784125
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Test merge_dicts function
    assert merge_dicts.get_body() == \
        ['\n',
         'def _py_backwards_merge_dicts(dicts):\n',
         '    result = {}\n',
         '    for dict_ in dicts:\n',
         '        result.update(dict_)\n',
         '    return result\n']
    # Test merge_dicts function
    assert merge_dicts.run_funcs_in_module('_py_backwards_merge_dicts',
                                           {'dicts': []}) == \
        {}
    # Test merge_dicts function

# Generated at 2022-06-21 17:37:53.899171
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:37:55.435506
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert type(t) == DictUnpackingTransformer


# Generated at 2022-06-21 17:38:02.953944
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    import textwrap

    def t(x: str) -> ast.AST:
        return DictUnpackingTransformer().visit(ast.parse(textwrap.dedent(x))).body[0]

    source = """
        {
            'a': a,
            **foo, 
        }
    """
    result = t(source)
    assert astunparse.unparse(result) == """
        _py_backwards_merge_dicts([{'a': a}], foo)
    """

    source = """
        {
            'a': a,
            **foo, 
            **bar,
            'b': b,
        }
    """
    result = t(source)

# Generated at 2022-06-21 17:38:14.892138
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import evaluate

    T = DictUnpackingTransformer()

    def check_transformation(code: str, values: Optional[dict] = None) -> None:
        tree = ast.parse(code)
        T.visit(tree)
        if values is not None:
            assert evaluate(tree, globals_=values) == {1: 1, 2: 1, 3: 3, 4: 4}
        else:
            assert evaluate(tree) == {1: 1, 2: 2}

    # Check leaves as is
    code = '{1: 1, 2: 2}'
    check_transformation(code)

    # Check simple case
    code = '{1: 1, **{2: 2}}'
    check_transformation(code)

    # Check case with simple unpacking

# Generated at 2022-06-21 17:38:17.191294
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None, None) is not None, 'Test DictUnpackingTransformer constructor'

# Generated at 2022-06-21 17:38:18.225814
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-21 17:38:25.525559
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert DictUnpackingTransformer().visit_Module(ast.parse("""
            X = {1: 1, **dict_a}
            Y = {1: 1}
            """)) == ast.parse("""
            from typed_ast import ast3 as ast

            def _py_backwards_merge_dicts(dicts):
                result = {}
                for dict_ in dicts:
                    result.update(dict_)
                return result

            X = _py_backwards_merge_dicts([{1: 1}], dict_a)
            Y = {1: 1}
            """)


# Generated at 2022-06-21 17:38:30.602551
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_astunparse import unparse
    from astor import parse

    code = """
        {1: 1, **dict_a}
    """

    expected = """
        _py_backwards_merge_dicts([dict({1: 1})], dict_a)
    """

    node = parse(code).body[0].value
    transformer = DictUnpackingTransformer()
    result = unparse(transformer.visit(node))
    assert transformer._tree_changed is True

    assert result == expected


# Generated at 2022-06-21 17:38:38.788777
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_source
    from .. import fix_missing_locations

    source = (
        'fixed = {1:1}')
    node = ast.parse(source)  # type: ignore
    expected = (
        'def _py_backwards_merge_dicts(dicts):\n'
        '    result = {}\n'
        '    for dict_ in dicts:\n'
        '        result.update(dict_)\n'
        '    return result\n'
        '\n'
        'fixed = {1:1}')
    new_node = DictUnpackingTransformer().visit(node)
    assert_equal_source(expected, new_node)

    # No change

# Generated at 2022-06-21 17:38:46.949180
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.sample_code import code_dict_unpacking

    expected = """
    def foo():
        a = {}
        b = _py_backwards_merge_dicts([{'b': 1}, {'c': 2}, {'d': 3}], {})

    """

    tr = DictUnpackingTransformer()
    tr.visit(code_dict_unpacking)
    result = tr.dump()

    assert expected == result

# Generated at 2022-06-21 17:38:56.538125
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:38:59.651439
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Test for DictUnpackingTransformer.visit_Module"""

# Generated at 2022-06-21 17:39:10.205030
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-21 17:39:13.709783
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Test for method visit_Module of class DictUnpackingTransformer"""
    source = '''\
{a: b, **c, d: e}
    '''


# Generated at 2022-06-21 17:39:23.744767
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    import ast

    trans = DictUnpackingTransformer()
    node = ast.Dict(keys=[None, ast.Dict(keys=[None, None], values=[])],
                    values=[ast.Dict(keys=[ast.Constant(1), ast.Constant(2)],
                                     values=[ast.Constant(1), ast.Constant(2)])],
                    ctx=ast.Load())
    assert astunparse.unparse(trans.visit(node)) == "("

# Generated at 2022-06-21 17:39:32.293312
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from pickle import dumps
    import astor
    snippet = """
    class A:
        def f(x):
            return {1: 2, **x}
    """
    snippet_tree = ast.parse(snippet)
    DictUnpackingTransformer().visit(snippet_tree)
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    class A:
        def f(x):
            return _py_backwards_merge_dicts([{1: 2}], x)
    """
    assert dumps(snippet_tree) == dumps(ast.parse(expected))

# Generated at 2022-06-21 17:39:36.579100
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse("""
foo = {1: 1, **bar}
baz = {2: 2}
""")
    DictUnpackingTransformer().visit(node)
    function, = node.body  # type: ast.Assign
    expr, = function.value.args  # type: ast.List

# Generated at 2022-06-21 17:39:37.902778
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer is not None



# Generated at 2022-06-21 17:39:48.707083
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    # Example: {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    def code_before():
        return {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}

    # Example: _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    def code_after():
        return _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)

    def get_ast(code):
        c = compile(code, '?', 'eval')
        return ast.parse(c.co_consts[0])


# Generated at 2022-06-21 17:39:54.498932
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('{1: 2, **x}')
    expected_result = ast.parse('import ast_extensions\n\n'
                                '\n\n'
                                'def _py_backwards_merge_dicts(dicts):\n'
                                '    result = {}\n'
                                '    for dict_ in dicts:\n'
                                '        result.update(dict_)\n'
                                '    return result\n'
                                '\n'
                                '\n'
                                '\n'
                                '{1: 2, **x}')
    t = DictUnpackingTransformer()
    t.visit(node)
    assert ast.dump(node) == ast.dump(expected_result)


# Generated at 2022-06-21 17:40:23.145320
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3
    transformer = DictUnpackingTransformer()
    assert transformer._tree_changed is False
    tree = ast3.parse('''\
a = {'a': {'b': {}, **c}}
''')
    tree = transformer.visit(tree)
    assert transformer._tree_changed is True

# Generated at 2022-06-21 17:40:33.467727
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .transformer_test import TransformerTestCase
    import ast as ast_stdlib

    class Test(TransformerTestCase):
        transformer = DictUnpackingTransformer

        def test_transformer_usage(self):
            node = ast_stdlib.parse('{a: "a", **dict_a}')
            got = self._transform(node, 'a', 'dict_a')
            expected = ast_stdlib.parse(
                '\n'.join([
                    '_py_backwards_merge_dicts([{a: "a"}], dict_a)',
                    ''
                ])
            )
            self.assertEqualAst(got, expected)

    Test().run()



# Generated at 2022-06-21 17:40:41.411855
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    node = ast.parse('a={1: 1, **{2: 2}}')
    node = transformer.visit(node)
    assert transformer._tree_changed

# Generated at 2022-06-21 17:40:50.622549
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse('{1: 1, **a}')
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)

    expected_tree = ast.parse(
        'from typing import Any\n'
        'def _py_backwards_merge_dicts(dicts):\n'
        '    result = {}\n'
        '    for dict_ in dicts:\n'
        '        result.update(dict_)\n'
        '    return result\n'
        '_py_backwards_merge_dicts([{1: 1}], a)')
    expected_tree.body.extend(tree.body)
    assert expected_tree == tree

# Generated at 2022-06-21 17:40:53.250773
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): # type: ignore
    dict_unpacking_transformer = DictUnpackingTransformer()
    assert dict_unpacking_transformer

# Generated at 2022-06-21 17:41:01.187425
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = "dict(a=1, **{'b': 2, **d})[None] = 3"
    x = source_to_ast(source)
    t = DictUnpackingTransformer()
    x = t.visit(x)

    assert t._tree_changed
    assert x.body[0].value.value in (
        "_py_backwards_merge_dicts([dict(a=1)], {'b': 2}, d)[None] = 3",
        "_py_backwards_merge_dicts([dict(a=1)], {'b': 2, **d})[None] = 3"
    )



# Generated at 2022-06-21 17:41:02.040854
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:41:11.260285
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    code = '''\
{1: 1, **dict_a}
{1: 1, **dict_a, **dict_b}
{1: 1, **dict_a, **dict_b, **dict_c}
{1: 1, **dict_a, **dict_b, 2: 2, 3: 3, **dict_c}
{1: [1], 2: [2], **dict_c}
'''

# Generated at 2022-06-21 17:41:20.013828
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse

    code = '''
    if True:
        a = {
            'a': 0,
            5: 2,
            **{
                'b': 1
            },
            1: 1,
            **{
                'c': 1
            }
        }
    '''
    expected = '''
    if True:
        a = _py_backwards_merge_dicts([{'a': 0, 5: 2, 1: 1}], {'b': 1}, {'c': 1})
    '''

    result = astunparse.unparse(DictUnpackingTransformer().visit(ast.parse(code)))
    assert result == expected

# Generated at 2022-06-21 17:41:29.925461
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    from typed_ast import ast3
    source = '''
x = {1: 1, **{10: 20, 30: 40}}
'''
    expected_source = '''
x = _py_backwards_merge_dicts([{1: 1}, {10: 20, 30: 40}])
'''
    source = source.strip('\n').replace('\n', ' ').replace('\r', ' ')
    expected_source = expected_source.strip('\n').replace('\n', ' ').replace('\r', ' ')

    tree = ast3.parse(source)
    t = DictUnpackingTransformer()
    t.visit(tree)


# Generated at 2022-06-21 17:42:11.709089
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert astunparse(DictUnpackingTransformer().visit(
        ast.parse('{1: 2}'))) == '{1: 2}'
    assert astunparse(DictUnpackingTransformer().visit(
        ast.parse('{1: 2, 3: 4}'))) == '{1: 2, 3: 4}'
    assert astunparse(DictUnpackingTransformer().visit(
        ast.parse('{1: 2, **{}}'))) == '_py_backwards_merge_dicts([{1: 2}], {})'

# Generated at 2022-06-21 17:42:18.697473
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import sys, os
    sys.path.append(os.path.abspath(os.pardir))
    import astor
    transformer = DictUnpackingTransformer()
    tree = ast.parse("{1: 1, **{2: 2}, 3: 3, **{4: 4}, 5: 5}")
    transformer.visit(tree)
    print(''.join(astor.to_source(tree).split('\n')[2:]))

# Generated at 2022-06-21 17:42:25.469995
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast

    tree = ast.parse("""{1: 1, **dict_a}""")
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)

# Generated at 2022-06-21 17:42:30.667119
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .codegen import to_source
    from .visitor import NodeTransformerVisitor
    source = """{1: 2, **{1: 1, 2: 2}}"""
    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer)
    visitor.visit(tree)
    assert to_source(tree) == """\
_py_backwards_merge_dicts([{1: 2}], {1: 1, 2: 2})"""


# Generated at 2022-06-21 17:42:41.368596
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    expected = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[ast.List(elts=[
            ast.Dict(keys=[
                ast.Num(n=1),
                ast.Num(n=2),
                ast.Name(id='a')],
                values=[
                    ast.Num(n=1),
                    ast.Num(n=2),
                    ast.Name(id='b')]),
            ast.Call(
                func=ast.Name(id='dict'),
                args=[ast.Name(id='dict_a')],
                keywords=[]),
            ast.Dict(keys=[], values=[])])],
            keywords=[])

# Generated at 2022-06-21 17:42:42.377028
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert t is not None

# Generated at 2022-06-21 17:42:49.690422
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_utils import make_call
    from ..utils.tree import get_ast

    tree = make_call()
    DictUnpackingTransformer().visit(tree)

    for name in merge_dicts.get_names():
        get_ast(tree).body[0].body[0].body[0].value.args[0].elts  # type: ignore



# Generated at 2022-06-21 17:42:50.922381
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-21 17:42:52.103925
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # TODO: work on the test
    pass

# Generated at 2022-06-21 17:42:58.512510
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from . import DictUnpackingTransformer

    transform = DictUnpackingTransformer()
    tree = ast.Module([])
    transform.visit(tree)
    assert tree.body[0].value.keywords == []  # type: ignore

# Generated at 2022-06-21 17:44:24.767856
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.visitor import dump

    # Dict unpacking
    source = '{1: 1, **dict_a}'
    expected = "{'_py_backwards_merge_dicts': _py_backwards_merge_dicts, 'dict': {}}"
    tree_changed, new_tree = DictUnpackingTransformer().visit(source_to_ast(source))
    assert dump(new_tree) == expected
    # Dict unpacking with new key
    source = '{1: 1, **{2: 2}}'
    expected = "{'_py_backwards_merge_dicts': _py_backwards_merge_dicts, 'dict': {}}"
    tree_changed, new_tree = DictUnpackingTransformer

# Generated at 2022-06-21 17:44:33.788321
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    from ..utils.source import source_to_ast

    def run_test(source: str, expected: str) -> None:
        actual = DictUnpackingTransformer(source).get_result_as_code()
        assert actual == dedent(expected)

    run_test(
        source=dedent('''\
            {1:2}
        '''),
        expected=dedent('''\
            {1: 2}
        '''))

    run_test(
        source=dedent('''\
            {1:2, **{'a': 3}}
        '''),
        expected=dedent('''\
            _py_backwards_merge_dicts([{1: 2}], {'a': 3})
        '''))

    run_

# Generated at 2022-06-21 17:44:42.828226
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from .. import pytree

    source_ = \
'''
a = {4: 5}
b = {1: 2, **a}
'''
    tree = pytree.from_str(source_)
    DictUnpackingTransformer().transform(tree)
    assert source(tree) == \
'''
_py_backwards_merge_dicts = (lambda dicts:
                             (lambda result:
                              ((lambda dict_: result.update(dict_))
                               (dicts.pop()))
                              or result)
                             (dicts.pop()))
a = {4: 5}
b = _py_backwards_merge_dicts([{1: 2}, a])
'''


# Generated at 2022-06-21 17:44:44.116685
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer


# Generated at 2022-06-21 17:44:54.725205
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTest, BaseNodeTransformerUnitTest
    from .base import add_method
    from .base import create_fake_module

    import astor
    from ast import Module, Dict, Name, List, BinOp, Add, Str, Num, Call

    import textwrap
    from inspect import isclass

    from .base import BaseNodeTransformerTest, BaseNodeTransformerUnitTest
    from .base import add_method, create_fake_module, create_fake_func
    from .base import tested_function_name

    # Unit tests for constructor of class DictUnpackingTransformer

# Generated at 2022-06-21 17:44:59.890035
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-21 17:45:09.071518
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)
    assert DictUnpackingTransformer._split_by_None([]) == [[]]
    assert DictUnpackingTransformer._split_by_None([(None, 1)]) == [[1]]
    assert DictUnpackingTransformer._split_by_None([(None, 1), (None, 2)]) == [1, 2]
    assert DictUnpackingTransformer._split_by_None([(None, 1), (None, 2), (None, 3)]) == [1, 2, 3]
    assert DictUnpackingTransformer._split_by_None([(1, 2), (None, 3)]) == [[(1, 2)], 3]