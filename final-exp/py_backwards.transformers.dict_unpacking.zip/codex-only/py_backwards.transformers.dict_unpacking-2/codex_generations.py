

# Generated at 2022-06-23 22:37:38.188212
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    source_code = """\
{**a, **b, 1: 2}
{1: 2}
{1: 2, 3: 4, 5: 6}
"""
    nodes = list(ast.parse(source_code).body)
    expected_source_code = """\
_py_backwards_merge_dicts([dict(a), dict(b), {1: 2}])
{1: 2}
{1: 2, 3: 4, 5: 6}
"""
    expected_nodes = list(ast.parse(expected_source_code).body)
    for node, expected in zip(nodes, expected_nodes):
        transformer.visit(node)
        assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-23 22:37:44.772356
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    program = ast.parse("""
_py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result

foo({1: 1, **dict_a})
""")
    result = DictUnpackingTransformer().visit(program)
    expected = ast.parse("""
foo(_py_backwards_merge_dicts([{1: 1}], dict_a))
""")
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-23 22:37:55.340741
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # type: () -> None

    node = ast.Module(
        body=[
            ast.Expr(value=ast.Dict(
                keys=[ast.Num(n=1), None, None, ast.Str(s='a')],
                values=[ast.Num(n=1), ast.Num(n=2), ast.Dict(keys=[], values=[]), ast.Str(s='b')]))
        ])


# Generated at 2022-06-23 22:38:01.210643
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..visitor import Visitor
    from ..utils.snippet import transform
    from .base import BaseNodeTransformer
    node, expected_node = transform("""
    {1: 1, **dict_a}
    """, DictUnpackingTransformer)
    assert Visitor(BaseNodeTransformer).visit(node) == expected_node


# Generated at 2022-06-23 22:38:09.128860
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.environment import Environment

    env = Environment()


# Generated at 2022-06-23 22:38:14.141683
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('''
        {
            1: 1,
            2: 2,
            **{
                3: 3,
                4: 4
            },
            5: 5,
            6: 6,
            **{
                7: 7,
                8: 8
            }
        }''')

    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-23 22:38:23.417752
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.codegen import to_source
    from ..utils.testing import assert_text_equal

    transformer = DictUnpackingTransformer()
    node = ast.parse('{1: 1, **{2: 2}}')
    transformer.visit(node)
    source = to_source(node).strip()
    destination = (
        "import ast\n"
        "def _py_backwards_merge_dicts(*dict_args):\n"
        "    result = {}\n"
        "    for dictionary in dict_args:\n"
        "        result.update(dictionary)\n"
        "    return result\n"
        "_py_backwards_merge_dicts([{1: 1}], {2: 2})"
    ).strip()

# Generated at 2022-06-23 22:38:28.820668
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import ast_parse
    from ..utils.helpers import try_to_compile_and_run
    import astor

    code_text = """
    if __name__ == '__main__':
        d = {1: 1, **{2: 2, **{3: 3}, 4: 4}, 5: 5}
        assert d == {1: 1, 2: 2, 3: 3, 4: 4, 5: 5}
    """
    code = ast_parse(code_text)
    transpiled = DictUnpackingTransformer().visit(code)


# Generated at 2022-06-23 22:38:30.569708
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer.target == (3, 4)

# Generated at 2022-06-23 22:38:41.570826
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Tests that ``DictUnpackingTransformer.visit_Dict``
    compiles dictionary with unpacking to function call.

    """
    source = """
    {1: 1, 2: 2, 3: 3, **dict_a, 4: 4, 5: 5, **dict_b, 6: 6, 7: 7}
    """
    expected_code = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}, dict_a, {4: 4, 5: 5}, dict_b, {6: 6, 7: 7}])
    """
    node = parse(source)
    transformed = DictUnpackingTransformer().visit(node)
    compiled = compile(transformed, filename='tmp', mode='exec')

    module = {}

# Generated at 2022-06-23 22:38:50.852741
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    from typed_ast import ast3
    class DictUnpackingTransformer(BaseNodeTransformer):
        target = (3, 4)
        def visit_Dict(self, node):
            self._tree_changed = True
            pairs = zip(node.keys, node.values)
            splitted = self._split_by_None(pairs)
            prepared = self._prepare_splitted(splitted)
            return self._merge_dicts(prepared)

        def _split_by_None(self, pairs):
            result = [[]]
            for key, value in pairs:
                if key is None:
                    result.append(value)
                    result.append([])
                else:
                    result[-1].append((key, value))
            return result


# Generated at 2022-06-23 22:39:00.367139
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse
    tree = parse("result = {1: 1}")
    DictUnpackingTransformer().visit(tree)
    assert isinstance(tree.body[0].value, ast.Dict)

    tree = parse("result = {1: 1, **dict_a}")
    DictUnpackingTransformer().visit(tree)
    assert isinstance(tree.body[0].value, ast.Call)

    tree = parse("result = {1: 1, **dict_a, 3: 3}")
    DictUnpackingTransformer().visit(tree)
    assert isinstance(tree.body[0].value, ast.Call)

# Generated at 2022-06-23 22:39:10.282420
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''
    a = {1: 1, **{"foo": 'bar'}}
    b = {**a, **dict(b="hello")}
    '''
    output = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    a = _py_backwards_merge_dicts([{1: 1}], {"foo": 'bar'})
    b = _py_backwards_merge_dicts([a], dict(b="hello"))
    '''
    result = DictUnpackingTransformer().visit(ast.parse(code))
    assert ast.unparse(result) == output

# Generated at 2022-06-23 22:39:14.233284
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from . import ctx as ctx
    from . import templating as templating
    from .ast_toolbox import to_source
    source = 'target'

# Generated at 2022-06-23 22:39:15.247192
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-23 22:39:22.127074
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
        assert ast.dump(DictUnpackingTransformer().visit(ast.parse("{1: 2, 3: 4}"))) == \
            "Module(body=[Expr(value=Dict(keys=[Num(n=1), Num(n=3)], values=[Num(n=2), Num(n=4)]))])"


# Generated at 2022-06-23 22:39:28.703613
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    class X:
        pass
    dict_unpacking_transformer = DictUnpackingTransformer(X)
    with DictUnpackingTransformer._tree_changed.assigned_to(False):
        assert dict_unpacking_transformer._tree_changed == False
    with DictUnpackingTransformer._tree_changed.assigned_to(True):
        assert dict_unpacking_transformer._tree_changed == True
# Unit tests for function _split_by_None() of class DictUnpackingTransformer

# Generated at 2022-06-23 22:39:38.803715
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:39:40.843299
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():  # noqa: D103
    obj = DictUnpackingTransformer()
    assert obj._tree_changed is None


# Unit tests for constructor of class DictUnpackingTransformer

# Generated at 2022-06-23 22:39:42.525892
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import run_transformer__visit_Dict
    run_transformer__visit_Dict(DictUnpackingTransformer)

# Generated at 2022-06-23 22:39:52.085966
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Testing of _split_by_None
    splitted = DictUnpackingTransformer()._split_by_None([
        (None, ast.Num(1)),
        (None, ast.Num(2)),
        (ast.Name('x', ast.Load()), ast.Num(3)),
        (None, ast.Num(4)),
        (ast.Name('y', ast.Load()), ast.Num(5)),
        (None, ast.Num(6))])

# Generated at 2022-06-23 22:39:58.996803
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    d = {1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, 10: 10,
         11: 11, 12: 12, 13: 13, 14: 14, 15: 15, 16: 16, 17: 17, 18: 18,
         19: 19, 20: 20, 21: 21, 22: 22, 23: 23, 24: 24, 25: 25, 26: 26,
         27: 27, 28: 28, 29: 29, 30: 30}
    from collections import OrderedDict
    d = OrderedDict(d)
    d[None] = ast.Num(n=0)
    node = ast.parse(astor.to_source(d))

# Generated at 2022-06-23 22:39:59.908923
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:06.183419
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from testing.utils import single_file_transformation_test
    from testing.codegen import codegen
    from .dict_unpacking import DictUnpackingTransformer
    codegen(source='''
        {1: 1, **dict_a}
    ''',
            transformer=DictUnpackingTransformer)
    single_file_transformation_test('dict_unpacking',
                                    'dict_unpacking_visit_dict.test')

# Generated at 2022-06-23 22:40:10.504026
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('1')
    t = DictUnpackingTransformer()
    result = t.visit(tree)
    assert str(result).split('\n')[0] == 'def _py_backwards_merge_dicts(dicts):', repr(result)


# Generated at 2022-06-23 22:40:11.835476
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    d = DictUnpackingTransformer()
    assert d is not None

# Generated at 2022-06-23 22:40:12.452657
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert 3 == 3

# Generated at 2022-06-23 22:40:21.285147
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    d = ast.Dict(keys=[ast.Constant(1), None, ast.Constant('foo')],
                 values=[ast.Constant(1), ast.Name(id='a'), ast.List(elts=[])])
    n = DictUnpackingTransformer().visit(d)
    # n: Call = _py_backwards_merge_dicts(
    #        [{
    #            1: 1,
    #        }],
    #        a,
    #        dict()
    #    )
    assert isinstance(n, ast.Call)
    assert n.args[0].elts[0].keys == [ast.Constant(1)]  # type: ignore
    assert n.args[1].id == 'a'  # type: ignore


# Generated at 2022-06-23 22:40:29.855093
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from _ast import Module, Dict
    from astpretty import pprint

    text = '''\
    a = {1: 1, **{2: 2}}
    '''

    expected = '''\
    a = _py_backwards_merge_dicts([{1: 1}], {2: 2})
    '''

    module = ast.parse(text)  # type: Module
    assert isinstance(module.body[0].value, Dict)
    module = DictUnpackingTransformer().visit(module)  # type: ignore
    pprint(module, indent='    ', sort_keys=True)
    assert ast.dump(module) == expected

# Generated at 2022-06-23 22:40:31.464718
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-23 22:40:42.309112
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pair = tuple, tuple
    splitted = list, list
    pairs = pair, pair

    DictUnpackingTransformer._split_by_None([]) == []
    DictUnpackingTransformer._split_by_None([None]) == []
    DictUnpackingTransformer._split_by_None([pair(None, 1)]) == [1]
    DictUnpackingTransformer._split_by_None([pair(None, 1), None]) == [1]
    DictUnpackingTransformer._split_by_None([pair(None, 1), pair(None, 2)]) \
        == [1, 2]
    DictUnpackingTransformer._split_by_None([pair(1, 2), pair(None, 3)]) \
        == [pairs, 3]
    DictUnpackingTransformer._split_by_

# Generated at 2022-06-23 22:40:47.468820
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    t.visit_Module(  # type: ignore
        ast.Module(body=[ast.Expr(value=ast.Num(n=1))]))
    assert t._tree_changed



# Generated at 2022-06-23 22:40:52.954849
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .transpile import transpile
    from .signature_unpacking_transformer import SignatureUnpackingTransformer

    original_ast = ast.parse('{1: 1, **dict_a}', mode='eval')
    transformed_ast = DictUnpackingTransformer.run(original_ast)
    SignatureUnpackingTransformer.run(transformed_ast)
    transpiled = transpile(transformed_ast)
    assert '_py_backwards_merge_dicts([{1: 1}], dict_a)' in transpiled

# Generated at 2022-06-23 22:40:55.806931
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from . import transform

    result = transform(DictUnpackingTransformer, '{"a": 1, **{"b": 2}}')
    assert result == '_py_backwards_merge_dicts([{"a": 1}], {"b": 2})'



# Generated at 2022-06-23 22:40:57.322663
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:01.862120
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import transform
    from typed_ast import ast3 as ast
    module = ast.parse('{**{}}')
    transform(module, DictUnpackingTransformer())
    assert module.body[0] == merge_dicts.get_body()



# Generated at 2022-06-23 22:41:12.403068
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    def assert_equal(code: str, expected: str) -> None:
        mod = compile(code, '<unknown>', 'exec', ast.PyCF_ONLY_AST)
        DictUnpackingTransformer().visit(mod)  # type: ignore
        assert ast.dump(mod) == expected


# Generated at 2022-06-23 22:41:13.328409
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:19.432628
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_unicode, source_to_ast

    source = """
    {'a': 1, **{'b': 2}}
    
    {'a': 1, 'b': 2}
    """
    result = source_to_unicode(DictUnpackingTransformer().visit(source_to_ast(source)))
    expected = u"""{'a': 1, 'b': 2}

{'a': 1, 'b': 2}
"""
    assert result == expected

# Generated at 2022-06-23 22:41:29.237584
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.dump_ast import dump_ast

    source = """
    def foo(bar, **kwargs):
        return {1, 1, **kwargs}
    """

    tree = ast.parse(source)
    DictUnpackingTransformer(remove_annotations=True)\
        .visit(tree)

# Generated at 2022-06-23 22:41:31.656051
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse(
        '{1: 1, 2: 2, *a, **b, **c}', '<test>', 'eval')
    expected = ast.parse(
        '_py_backwards_merge_dicts([{1: 1, 2: 2}], a, b, c)')
    assert DictUnpackingTransformer().visit(tree) == expected

# Generated at 2022-06-23 22:41:33.116102
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:40.892467
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    pairs = [
        (None, ast.Dict(keys=[], values=[])),
        (ast.Num(1), ast.Num(2)),
        (ast.Num(1), ast.Num(2)),
        (ast.Num(1), ast.Num(2)),
        (None, ast.Dict(keys=[], values=[])),
        (ast.Num(3), ast.Num(4)),
        (ast.Num(3), ast.Num(4)),
        (None, ast.Dict(keys=[], values=[])),
        (None, ast.Dict(keys=[], values=[])),
    ]


# Generated at 2022-06-23 22:41:47.649094
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_setup import setup_transformer_test
    from typing import List
    from typed_ast import ast3 as ast

    wrapper = setup_transformer_test(DictUnpackingTransformer, """
        def func():
            a = {1: 1, **{2: 2}, 3: 3, **{4: 4}}
    """)
    assert isinstance(wrapper, ast.Module)
    assert wrapper.body[0].name == 'func'
    func = wrapper.body[0]
    assert isinstance(func, ast.FunctionDef)
    assert func.body[0].value.func.id == '_py_backwards_merge_dicts'



# Generated at 2022-06-23 22:41:56.980614
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('x = {1: 1, **dict_a}')
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 22:41:57.628711
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()



# Generated at 2022-06-23 22:41:59.665978
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert t.__class__ is DictUnpackingTransformer


# Generated at 2022-06-23 22:42:06.684711
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ast import parse, dump
    from . import make_transformed_ast

    transformer = DictUnpackingTransformer()
    tree = make_transformed_ast(transformer, parse('{1: 1, **{2: 2}}'))

# Generated at 2022-06-23 22:42:07.421186
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:09.172980
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    at = DictUnpackingTransformer()
    assert at
    assert at.target == (3, 4)


# Generated at 2022-06-23 22:42:10.249836
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:42:17.781602
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree

    node = ast.Module(
        body=[
            ast.Dict(keys=[ast.Num(n=1), None], values=[ast.Num(n=1), ast.Call(func=ast.Name(id="dict_a", ctx=ast.Load()), args=[], keywords=[])])
        ]
    )
    tree.dump(node)

    result = DictUnpackingTransformer().visit(node)
    tree.dump(result)


# Generated at 2022-06-23 22:42:24.958204
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Tests for method visit_Dict of class DictUnpackingTransformer."""
    import textwrap
    from ..utils.code_gen import generate_code
    from ..utils.python import assert_equal_code, load_ast

    trans = DictUnpackingTransformer()
    source = textwrap.dedent('''
        {1: 'a', **{2: 'b', 3: 'c'}, 'd': 4, 5: 6, **{'f': 7}, 'g': 8,
         **{'h': 9}}
    ''')
    expected = textwrap.dedent('''
        {'d': 4, 'h': 9, 'g': 8, 'f': 7, 5: 6, 2: 'b', 1: 'a', 3: 'c'}
    ''')

    tree = load

# Generated at 2022-06-23 22:42:34.876165
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('def f():\n    return {1: 1, 2: 2, None: 3, **{1: 2}}')
    expected = ast.parse(
        'def _py_backwards_merge_dicts(dicts):\n    result = {}\n'
        '    for dict_ in dicts:\n        result.update(dict_)\n    return result\n\n'
        'def f():\n    return _py_backwards_merge_dicts('
        '[{1: 1, 2: 2}, 3], {1: 2})')
    DictUnpackingTransformer.run(module)
    assert ast.dump(module) == ast.dump(expected)



# Generated at 2022-06-23 22:42:45.181535
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    from ..utils.codegen import to_source

    transformer = DictUnpackingTransformer()
    source = '{1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}'
    result = to_source(transformer.run(source))
    expected = '\n'.join([
        'def _py_backwards_merge_dicts(dicts):',
        '    result = {}',
        '    for dict_ in dicts:',
        '        result.update(dict_)',
        '    return result',
        '_py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {3: 3}, dict_b, {4: 4}])',
        ''])

    assert expected == result

# Generated at 2022-06-23 22:42:45.696761
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-23 22:42:46.784818
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:42:51.103568
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    result = visitor_transformer_test([DictUnpackingTransformer], '''{1: 1, None: 2, 3: 3, 4: 4, None: {5: 5}, 6: 6}''')

# Generated at 2022-06-23 22:42:55.544607
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    node = ast.Module(body=[])
    actual = transformer.visit(node)
    assert transformer._tree_changed
    assert actual.body[0:2] == merge_dicts().get_body()  # type: ignore


# Generated at 2022-06-23 22:42:56.563138
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:57.347230
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(*DictUnpackingTransformer.target) is not None

# Generated at 2022-06-23 22:43:00.681865
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    t1 = transformer.visit(
        ast.parse("{1: 2, 3: 4, 5: None, **a}"))


# Generated at 2022-06-23 22:43:03.716679
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse("""
{1: 1, 2: 2, **dict_a}
    """)
    res_tree = ast.parse("""
_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(res_tree)

# Generated at 2022-06-23 22:43:13.462827
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_setup import setup_test, assert_equal_ignore_linenos

    def test_snippet(code: str) -> str:
        node = setup_test(code, DictUnpackingTransformer)
        return node.body[0].value.args[0].elts[0]


    assert_equal_ignore_linenos(test_snippet('''
    {**{}}
    '''), '''
    _py_backwards_merge_dicts([{}])
    ''')

    assert_equal_ignore_linenos(test_snippet('''
    {**dict_}
    '''), '''
    _py_backwards_merge_dicts([dict_])
    ''')


# Generated at 2022-06-23 22:43:15.313150
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): # type: () -> None
    assert DictUnpackingTransformer() is not None


# Generated at 2022-06-23 22:43:23.692852
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import dump_ast
    from ..utils.tree import tree_to_str
    from ..utils.codegen import codegen
    tree = dump_ast("{**b}")
    tree = DictUnpackingTransformer().visit(tree)
    tree = tree_to_str(tree)
    expected = tree_to_str(merge_dicts.get_body()) + '\n' + "Call(Name(id='_py_backwards_merge_dicts', ctx=Load()), [List(elts=[Dict(keys=[], values=[Name(id='b', ctx=Load())])], ctx=Load())], keywords=[])\n"
    assert codegen(tree) == codegen(expected)


# Generated at 2022-06-23 22:43:29.838688
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.fake import FakeFile
    from ..utils.transform import transform

    code = '''
        d = {1: 1, **{2: 2}}
    '''
    module = ast.parse(code)
    assert code == FakeFile(module).as_string()

    transform(module, DictUnpackingTransformer)
    actual = FakeFile(module).as_string()
    expected = '''\
        def _py_backwards_merge_dicts(a):
            result = {}
            for b in a:
                result.update(b)
            return result

        d = _py_backwards_merge_dicts(
            [{1: 1}], {2: 2})
    '''
    assert actual == expected

# Generated at 2022-06-23 22:43:35.392707
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse('set()\n{1: 1, **dict_a}\nset()')
    expected_tree = ast.parse('set()\n_py_backwards_merge_dicts([{1: 1}], dict_a)\nset()')
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)



# Generated at 2022-06-23 22:43:45.250296
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..transpile_testing import test_transpile
    from ..utils.ast_helper import get_ast
    from .base import PythonNodeTransformer

    def test(s, expected, *, check_ast=False):
        class DUT(DictUnpackingTransformer):
            pass

        transformer = DUT()
        assert transformer.visit(get_ast(s)) == get_ast(expected)
        assert test_transpile(s) == expected
        if check_ast:
            assert transformer.visit(get_ast(s)) == get_ast(expected)


# Generated at 2022-06-23 22:43:50.598316
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)
    assert DictUnpackingTransformer.__name__ == 'DictUnpackingTransformer'
    assert DictUnpackingTransformer.__doc__ is not None

    x = DictUnpackingTransformer()
    assert isinstance(x, BaseNodeTransformer)


# Generated at 2022-06-23 22:43:54.620404
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_equal
    node = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')
    actual = DictUnpackingTransformer().visit(node)
    assert_tree_equal(actual, expected)

# Generated at 2022-06-23 22:44:00.945237
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .util import parse
    from .util import compare_ast
    parser = parse(F"""
    {merge_dicts}
    
    {'''
    {1: 1, **{1: 2}, None: 1, **{3: 4}, 2: 2}
    '''}
    """)
    compare_ast(parser, DictUnpackingTransformer)



# Generated at 2022-06-23 22:44:04.724480
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.mock_module import MockModule
    
    module = MockModule(
        None,
        """
        class A:
            def m(self):
                return {**a, **b}
        """)
    
    t = DictUnpackingTransformer()
    module.visit(t)
    
    expected = \
        """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        class A:
            def m(self):
                return _py_backwards_merge_dicts([], a, b)
        """
    
    assert str(module) == expected

# Generated at 2022-06-23 22:44:10.463593
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    snippet = merge_dicts.get_body()

    assert snippet[0] == ast.parse('def _py_backwards_merge_dicts(dicts):').body[0]
    assert snippet[1] == ast.parse(
        '    result = {}').body[0]
    assert snippet[2] == ast.parse(
        '    for dict_ in dicts:').body[0]
    assert snippet[3] == ast.parse(
        '        result.update(dict_)').body[0]
    assert snippet[4] == ast.parse(
        '    return result').body[0]

    transformer = DictUnpackingTransformer()
    tree = ast.parse('{1: 1, 2: 2, 3: 3, **d1, 4: 4, 5: 5, **d2}')
   

# Generated at 2022-06-23 22:44:12.293144
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:22.234860
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    assert transformer.visit(transformer.parse_expr('{1: 1}')) == transformer.parse_expr('{1: 1}')
    assert transformer.visit(transformer.parse_expr('{1: 1, **{2: 2}}')) == transformer.parse_expr('_py_backwards_merge_dicts([{1: 1}], {2: 2})')
    assert transformer.visit(transformer.parse_expr('{1: 1, 2: 2, **{3: 3}, 4: 4, **{5: 5}}')) == transformer.parse_expr('_py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3}, {4: 4, 5: 5}])')

# Generated at 2022-06-23 22:44:31.007875
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import CompilationError
    from .base import NodeTransformerTestCase
    from ..utils.source import source

    class DictUnpackingTransformerTest(NodeTransformerTestCase):
        transformer = DictUnpackingTransformer

        def test_simple_dicts(self):
            with self.subTest('with unpacking'):
                code = '{1: 1, 2: 2, **a, **b}'
                expected = '_py_backwards_merge_dicts([{1: 1, 2: 2}], a, b)'
                self.assertEqual(expected, self.transform(code))

            with self.subTest('without unpacking'):
                code = '{1: 1, 2: 2}'
                expected = '{1: 1, 2: 2}'

# Generated at 2022-06-23 22:44:40.307112
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    def transform_Dict(s):
        module = ast.parse(s)
        return DictUnpackingTransformer().visit(module)

    @assert_equal(transform_Dict)
    def test_basic():
        return {1: 1, **{2: 2}}

    @assert_equal(transform_Dict)
    def test_nested():
        return {1: 1, **{2: 2, **{3: 3}}}

    @assert_equal(transform_Dict)
    def test_with_dict_unpackings_in_the_middle():
        return {1: 1, **{2: 2}, 3: 3, **{4: 4}}


# Generated at 2022-06-23 22:44:41.204510
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-23 22:44:42.372011
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)

# Generated at 2022-06-23 22:44:49.884567
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    expected = ast.Dict(
        keys=[ast.Constant(value=1)],
        values=[ast.Constant(value=1)]
    )
    actual = transformer.visit(ast.Dict(
        keys=[ast.Constant(value=1)],
        values=[ast.Constant(value=1)]
    ))
    assert expected == actual, 'no changes'

    expected = ast.Dict(
        keys=[ast.Constant(value=1)],
        values=[
            ast.Dict(
                keys=[ast.Constant(value=2)],
                values=[ast.Constant(value=3)]
            )
        ]
    )

# Generated at 2022-06-23 22:44:56.407530
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .test_utils import get_test_cases
    from .test_utils import run_transformer

    # Arrange
    transformer_name = DictUnpackingTransformer.__name__
    transformer_cases = get_test_cases(transformer_name)

    # Act and Assert
    for inputs, expected in transformer_cases:
        actual = run_transformer(DictUnpackingTransformer, inputs)
        assert expected == actual, f'<{inputs}> != <{actual}>'

# Generated at 2022-06-23 22:45:07.309105
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    class DictUnpackingTransformerTestCase(object):
        @staticmethod
        def test():
            return {1: 1, **{2: 2}}
    test_case = DictUnpackingTransformerTestCase()
    assert test_case.test() == {1: 1, 2: 2}

    # Test that transformer still works after merge_dicts() call

# Generated at 2022-06-23 22:45:11.375634
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from tests.utils import roundtrip
    from .test_DictUnpackingTransformer_visit_Dict \
        import DictUnpackingTransformer as DUT

    actual = merge_dicts.get_body()
    expected = roundtrip(actual, DUT, DUT)

    assert actual == expected

# Generated at 2022-06-23 22:45:13.111693
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    transformer.visit(None)
    return transformer

# Generated at 2022-06-23 22:45:14.316337
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().__name__ == 'DictUnpackingTransformer'

# Generated at 2022-06-23 22:45:20.408606
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    class TestTransformer(BaseNodeTransformer):
        pass

    visitor = TestTransformer()
    module = ast.parse(
        """
        {**a, **b}
        """
    )
    visitor.visit(module)
    assert (
        str(module) ==
        '''\
# <stdin>:2
_py_backwards_merge_dicts([], a, b)
'''
        )

# Generated at 2022-06-23 22:45:30.658383
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast, source_to_code
    from .method_calls_debundler import MethodCallsDebundlerTransformer

    initial = "{a: b, **c,} # comment"
    expected = "_py_backwards_merge_dicts([{'a': b}], c,)"

    tree = source_to_ast(initial)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(result) == ast.dump(source_to_ast(expected))

    tree = source_to_ast(expected)
    transformer = MethodCallsDebundlerTransformer()
    result = transformer.visit(tree)
    assert not transformer._tree_changed

# Generated at 2022-06-23 22:45:33.875340
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("""{1: 1, **dict_a}""")
    assert DictUnpackingTransformer.parse(module) == \
           ast.parse("_py_backwards_merge_dicts([{1: 1}], dict_a)")



# Generated at 2022-06-23 22:45:40.019518
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse("""\
{1: 1, **{2:2}, 3:3, 5:5, ** {} }
""")

    transformer = DictUnpackingTransformer()
    transformer.visit(tree)

    expected_tree = ast.parse("""\
_py_backwards_merge_dicts([{1: 1, 3:3, 5:5}, {2:2}, {}])
""")

    assert tree == expected_tree


# Generated at 2022-06-23 22:45:46.329265
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source

    nt = DictUnpackingTransformer()
    nt.visit(source('{1: 1, **dict_a}').tree)

    assert nt._tree_changed
    assert source(nt.root).code == 'import sys; def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result; {1: 1, **dict_a}'

# Generated at 2022-06-23 22:45:48.493027
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''\
d = {1: 1, **dict_a}
'''

# Generated at 2022-06-23 22:45:49.312131
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None)

# Generated at 2022-06-23 22:46:00.110717
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ._test_utils import dedent
    from .base import BaseNodeTransformer
    from .swap_args import ArgumentSwapTransformer
    from ..utils.source import source_to_ast

    source = dedent('''
    {'a': 1, None: {}, None: {3: 3}, **dict_}
    ''')
    ast_ = source_to_ast(source)
    tr = BaseNodeTransformer.chain(
        ArgumentSwapTransformer,
        DictUnpackingTransformer)
    transformed = tr(ast_)
    expected = dedent('''
    _py_backwards_merge_dicts(
        [{'a': 1}, {}],
        _py_backwards_merge_dicts([{3: 3}], dict_)
    )
    ''')


# Generated at 2022-06-23 22:46:08.205722
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_unchanged
    from ..utils.testing import parse_compile_and_get_tree
    from ..utils.testing import parse_compile_and_get_tree_and_run

    def assert_transformed(input_code: str, expected_code: str):
        tree = parse_compile_and_get_tree(input_code)
        transformer = DictUnpackingTransformer()
        result = transformer.visit(tree)
        tree = result.tree()
        assert_tree_unchanged(tree, expected_code)

        module = parse_compile_and_get_tree_and_run(input_code)
        expected_module = parse_compile_and_get_tree_and_run(expected_code)
        assert module.dict_ == expected_module.dict_

# Generated at 2022-06-23 22:46:09.990630
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer is not None

# Generated at 2022-06-23 22:46:11.486142
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert not hasattr(DictUnpackingTransformer(), '_tree_changed')

# Generated at 2022-06-23 22:46:20.347300
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from functools import reduce
    call = """{
        **{1: 1},
        'key': 'value',
        **{**{}, 1: 2},
        **{1: 2, **{1: 3, **{1: 4}}},
        **{**{}, **{1: 5}},
        **{}
    }"""
    with_keywords = """{
        **{1: 1},
        'key': 'value',
        **{**{}, 1: 2},
        **{1: 2, **{1: 3, **{1: 4}}},
        **{**{}, **{1: 5}},
        **{}
    }"""

# Generated at 2022-06-23 22:46:30.819449
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:46:38.425996
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    formatter = lambda x: ast.fix_missing_locations(ast.parse(x)).body[0]
    trans = DictUnpackingTransformer()
    assert trans.visit(formatter("{1: 1}")) == formatter("{1: 1}")
    assert trans.visit(formatter("{**a}")) == formatter("dict(a)")
    assert trans.visit(formatter("{1: 1, **a}")) == formatter("_py_backwards_merge_dicts([{1: 1}], a)")
    assert trans.visit(formatter("{1: 1, **a, 2: 2}")) == formatter("_py_backwards_merge_dicts([{1: 1, 2: 2}], a)")

# Generated at 2022-06-23 22:46:39.388643
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    return DictUnpackingTransformer()

# Generated at 2022-06-23 22:46:40.392301
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:46:46.861185
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # type: () -> None
    _dict = ast.parse('{1: 1, **dict_a}').body[0]
    _expected = ast.parse('''\
_py_backwards_merge_dicts([{
    1: 1
}], dict_a)
''').body[0]
    assert DictUnpackingTransformer().visit(_dict) == _expected



# Generated at 2022-06-23 22:46:47.852864
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None) is not None

# Generated at 2022-06-23 22:46:48.768173
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
d = {1: 2}
"""

# Generated at 2022-06-23 22:46:55.585933
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from unittest import TestCase, main
    from typed_astunparse import unparse
    from ..utils.snippet import normalize_py

    class Test(TestCase):
        def test(self):
            node = ast.parse(dictexp)
            node = DictUnpackingTransformer().visit(node)
            self.assertEqual(normalize_py(unparse(node)), normalize_py(after))

    main()



# Generated at 2022-06-23 22:46:58.075054
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    trans = DictUnpackingTransformer()
    trans._merge_dicts(['a', 'b'])
    trans.visit_Module(None)

# Generated at 2022-06-23 22:47:00.937090
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    def assert_compile(text):
        assert DictUnpackingTransformer().visit(ast.parse(text))

    assert_compile('{1: 1, **{2: 2}, 3: 3}')

# Generated at 2022-06-23 22:47:01.932443
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:47:02.934524
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:47:07.522193
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import parse
    from ...test.test_utils import transform_test
    from .base import BaseNodeTransformer
    module = parse('1 + 1')
    transform_test(module, DictUnpackingTransformer, '_py_backwards_merge_dicts')

# Generated at 2022-06-23 22:47:12.880108
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..test_utils import make_test_transformer


# Generated at 2022-06-23 22:47:17.677857
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('{1: 1, **dict_a}')
    DictUnpackingTransformer().visit(node)  # type: ignore

    assert node.body[0].body[0].value.id == '_py_backwards_merge_dicts'



# Generated at 2022-06-23 22:47:26.681159
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('''
x = {1: 1, 2: 2, **{3: 3}, 4: 4, **{5: 5}}
''')
    transformed = DictUnpackingTransformer().visit(node)


# Generated at 2022-06-23 22:47:36.329202
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    ast_tree = ast.parse(u"{1:1, **dict_a}")
    DictUnpackingTransformer().visit(ast_tree)