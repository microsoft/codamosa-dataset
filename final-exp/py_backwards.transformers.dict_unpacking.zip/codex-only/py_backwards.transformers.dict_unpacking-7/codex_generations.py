

# Generated at 2022-06-23 22:37:31.464857
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): pass

# Generated at 2022-06-23 22:37:41.294173
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import textwrap
    from typed_ast.ast3 import parse
    from ..utils.examples import EXAMPLES
    from ..utils.compare import compare_ast
    from .util import run_transformer_on_file_content

    code = textwrap.dedent("""\
    {
        1: 1,
        **dict_a,
        **dict_b,
        2: 2,
        **dict_c,
    }
    """)

    node = parse(code)
    DictUnpackingTransformer().visit(node)
    result = EXAMPLES['_py_backwards_merge_dicts.py'] + '\n' + code
    result = textwrap.dedent(result).strip() + '\n'
    result_node = parse(result)


# Generated at 2022-06-23 22:37:49.843696
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class Dummy:
        pass

    pairs = [
        (None, Dummy()),
        (ast.Str('a'), ast.Num(1)),
        (ast.Str('b'), ast.Num(2)),
        (None, Dummy()),
        (ast.Str('b'), ast.Num(3)),
        (ast.Str('c'), ast.Num(4)),
        (ast.Str('d'), ast.Num(5))]

    node = ast.Dict(  # type: ignore
        keys=[key for key, _ in pairs],
        values=[value for _, value in pairs])


# Generated at 2022-06-23 22:37:51.643056
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert type(t) == DictUnpackingTransformer


# Generated at 2022-06-23 22:38:02.729891
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    src = {
        '1': 1,
        **{'2': 2},
        3: 3,
        **{4: 4},
        5: 5,
    }

    res = DictUnpackingTransformer().visit(
        ast.parse(dedent(src)))


# Generated at 2022-06-23 22:38:08.814088
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = '{1: 2, **dict_a}'
    result = '{}'.format(merge_dicts.get_source()) + source
    tree = ast.parse(source)
    node = tree.body[0]
    assert isinstance(node, ast.Expr)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    source = source = '{}'.format(merge_dicts.get_source())
    source += '{1: 2, **dict_a}'
    assert astor.to_source(tree) == result


# Generated at 2022-06-23 22:38:13.948974
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    D = DictUnpackingTransformer
    def check(input_, expected):
        assert D._split_by_None(input_) == expected

    check([(None, 1)],
          [[], 1, []])
    check([(1, 1), (2, 2), (None, 3)],
          [[(1, 1), (2, 2)], 3, []])
    check([(None, 1), (None, 2), (None, 3)],
          [[], 1, [], 2, [], 3, []])
    check([(1, 1), (None, 2), (3, 3)],
          [[(1, 1)], 2, [(3, 3)]])
    check([(None, 1), (2, 2)],
          [[], 1, [(2, 2)]])
    check

# Generated at 2022-06-23 22:38:23.238142
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
    {1: 1, None: dict_a, 2: 2, None: dict_b, 3: 3, None: dict_c, 4: 4}
    {None: dict_a, 1: 1}
    {1: 1, None: dict_a, None: dict_b, None: dict_c}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b, dict_c)
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    _py_backwards_merge_dicts([{1: 1}], dict_a, dict_b, dict_c)
    """
    transformer = DictUnpackingTrans

# Generated at 2022-06-23 22:38:27.008011
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from libcst import parse_statement

    x = parse_statement('{1: 1, **dict_a}')
    assert isinstance(x, ast.Dict)

    t = DictUnpackingTransformer()
    result = t.visit(x)

    assert result == ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')

# Generated at 2022-06-23 22:38:37.706222
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import parse
    from .test_base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target_class = DictUnpackingTransformer
        target_version = (3, 4)

        def test_simple_skipped_case(self):
            code = """
            def foo():
                return {1: 1}
            """
            node = parse(code)
            self.check_unchanged(node)

        def test_simple_case(self):
            code = """
            def foo():
                return {1: 1, **dict_a}
            """
            node = parse(code)
            expected_code = """
            def foo():
                return _py_backwards_merge_dicts([{1: 1}], dict_a})
            """
            expected_

# Generated at 2022-06-23 22:38:38.570428
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    return DictUnpackingTransformer()

# Generated at 2022-06-23 22:38:45.149351
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.utils import transform_and_compare_ast
    transform_and_compare_ast(
        DictUnpackingTransformer,
        """
        {1: 1, **dict_a, **dict_b}
        dict_a
        dict_b
        dict_c
        {1: 1, **dict_a, **dict_b, **dict_c}
        """,
        """
        _py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)
        dict_a
        dict_b
        dict_c
        _py_backwards_merge_dicts([{1: 1}], dict_a, dict_b, dict_c)
        """
    )

# Generated at 2022-06-23 22:38:53.060887
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("""
    {1: 1, **dict_a}
    """)

    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-23 22:39:04.320742
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from copy import deepcopy
    t = DictUnpackingTransformer()
    mod = ast.parse("{1: 1, **dict_a}")

# Generated at 2022-06-23 22:39:11.946382
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from astunparse import unparse
    tree = ast.parse('''
    {1: 1, **dict_a}
    ''')
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert unparse(tree) == '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''


# Generated at 2022-06-23 22:39:16.864464
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import transform

    tree = transform(
        """{1: 1, 2: 2, **a}""",
        DictUnpackingTransformer)

    assert tree == """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], a)
"""

# Generated at 2022-06-23 22:39:23.526754
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..transforms import DictUnpackingTransformer as Class
    from ..transforms import AutoNumberingTransformer as Auto
    from ..transforms import head_tail_transformer as head_tail
    from ..utils.snippet import snippet
    from ..utils.ast import parse
    from ..utils.testing import assert_equal_code
    from ..utils.source import dedent

    source = dedent("""
    x = {1: None}
    y = {2: None, **x}
    """)


# Generated at 2022-06-23 22:39:24.270473
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer([])

# Generated at 2022-06-23 22:39:27.101885
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert inspect.isclass(DictUnpackingTransformer)

    result = DictUnpackingTransformer()
    assert isinstance(result, DictUnpackingTransformer)


# Generated at 2022-06-23 22:39:33.794136
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse

    statement = ast.parse('''a = {1: 2, 3: 4, **{5:8, 6: 7}}''')
    expected = '''a = _py_backwards_merge_dicts([{1: 2, 3: 4}], {5:8, 6: 7})'''
    transformer = DictUnpackingTransformer()
    output = astunparse.unparse(transformer.visit(statement))
    assert output == expected

# Generated at 2022-06-23 22:39:38.481732
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    assert transformer.visit(  # type: ignore
        ast.parse('{1: 2, None: 3, 4: 5, None: 6, 7: 8}')) == ast.parse(
        '_py_backwards_merge_dicts([{1: 2, 4: 5, 7: 8}], 3, 6)')

# Generated at 2022-06-23 22:39:39.403671
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:39:44.961135
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from pickle import loads, dumps
    from astunparse import unparse

    source = ('{1: 1, **x, 2: 2, **y, **z, 3: 3}')
    expected = ("_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], x, y, z)")
    tree = ast.parse(source)  # type: ignore

    DictUnpackingTransformer().visit(tree)
    assert unparse(tree) == expected

    roundtrip = loads(dumps(tree))
    assert unparse(roundtrip) == expected



# Generated at 2022-06-23 22:39:53.865850
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Test that transformed code works correctly (for unit test)."""
    tree = ast.parse('''{1: 1, **{'a': 2}}''')
    transformed = DictUnpackingTransformer().visit(tree)

    assert transformed is not tree
    assert ast.dump(transformed) == '''\
Module(body=[Expr(value=Call(func=Name(id='_py_backwards_merge_dicts', \
ctx=Load()), args=[List(elts=[Dict(keys=[Num(n=1)], values=[Num(n=1)]), \
Name(id='{a: 2}', ctx=Load())], ctx=Load())], keywords=[], starargs=None, \
kwargs=None))], type_ignores=[])'''

    # Test that transformed code works correctly (for

# Generated at 2022-06-23 22:39:59.896009
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast

    a = ast.Constant(value=1)
    b = ast.Constant(value=2)
    c = ast.Constant(value=3)
    d = ast.Constant(value=4)
    expected = ast.Module(
        body=[
            merge_dicts.get_body(),  # type: ignore
            ast.Dict(
                keys=[None, None, a, b],
                values=[c, d, d, c],
                ctx=ast.Load()
            )
        ]
    )
    source = ast.Module(
        body=[
            ast.Dict(
                keys=[None, None, a, b],
                values=[c, d, d, c],
                ctx=ast.Load()
            )
        ]
    )

    print(expected)

# Generated at 2022-06-23 22:40:10.602606
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from .testutil import parse
    from .testutil import roundtrip

    code = """
    {1: 1, **{2: 2}}
    """

    expected_code = """
    _py_backwards_merge_dicts([{1: 1}], {2: 2})
    """

    module = parse(code)

    dict_unpacking_transformer = DictUnpackingTransformer()
    dict_unpacking_transformer.visit(module)

    actual_code = astor.to_source(module)
    assert actual_code == expected_code

    module = roundtrip(code)

    dict_unpacking_transformer = DictUnpackingTransformer()
    dict_unpacking_transformer.visit(module)

    actual_code = astor.to_source(module)


# Generated at 2022-06-23 22:40:17.047995
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''
    {1: 1, 2: 2, **{3:3}}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    
    _py_backwards_merge_dicts([{1: 1, 2: 2}], {3:3})
    '''
    assert DictUnpackingTransformer().visit(ast.parse(code)) == expected


# Generated at 2022-06-23 22:40:18.231600
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    obj = DictUnpackingTransformer()
    assert obj is not None

# Generated at 2022-06-23 22:40:19.401557
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:25.036451
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Test for DictUnpackingTransformer.visit_Module."""
    code = """{1: 2, 3: 4, **{5: 6}}"""
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 22:40:29.339020
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer({})
    tree = ast.parse('{1: 1, **dict_a}')

    assert transformer.visit(tree) == ast.parse(merge_dicts.get_body() +
                                                '{1: 1, **dict_a}')


# Generated at 2022-06-23 22:40:32.610757
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_astunparse
    from .test_setup import setup
    code = '''{1: 1, **dict_a}'''
    expected_code = '''\
_py_backwards_merge_dicts([{1: 1}], dict_a)'''

    module, = DictUnpackingTransformer(setup(code)).run()
    assert typed_astunparse.dump(module) == expected_code

    module, = DictUnpackingTransformer(setup(expected_code)).run()
    assert typed_astunparse.dump(module) == expected_code



# Generated at 2022-06-23 22:40:35.645487
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    sample = DictUnpackingTransformer()
    input_ = """{
        1: 2,
        3: 4,
        **a
    }"""

# Generated at 2022-06-23 22:40:45.320532
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse("""
    {1: 2, None: 3, 4: 5}
    """)
    tree = DictUnpackingTransformer().visit(tree)  # type: ignore

# Generated at 2022-06-23 22:40:51.138587
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .main import get_transformer
    from inspect import getmro

    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)
    assert DictUnpackingTransformer in get_transformer(3, 4)
    assert DictUnpackingTransformer.__name__ == 'DictUnpackingTransformer'
    assert DictUnpackingTransformer.__module__ == __name__


# Generated at 2022-06-23 22:40:54.247669
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()

    assert transformer._split_by_None([(1, 2), (None, 3), (4, 5)]) == [
        [(1, 2)],
        3,
        [(4, 5)]]

# Generated at 2022-06-23 22:41:00.908253
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # define the function to transform
    def f():
        {
            **a,
            1: 2
        }

    # unit test converted into a function
    def unit_test(self):
        # define the function to test
        def f():
            {
                **a,
                1: 2
            }

        # make the transformation
        module = ast.parse(f.__code__)
        transformer = DictUnpackingTransformer()
        transformer.visit(module)  # type: ignore

        # test results
        assert module.body[0].body == merge_dicts.get_body()[0].body
        assert module.body[1].value.keys[0].value == 1
        assert module.body[1].value.keys[1] is None

# Generated at 2022-06-23 22:41:01.907816
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:03.256760
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), BaseNodeTransformer)



# Generated at 2022-06-23 22:41:11.374188
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    input = '{1: 1, 2: 2, 3: 3, **dict_a, **dict_b, 4: 4, **dict_c, 5: 5}'
    expected = '_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}, {4: 4}, {5: 5}], '\
               'dict_a, dict_b, dict_c)'
    actual = DictUnpackingTransformer(min_python_version=(3, 5)).visit(
        ast.parse(input))

    assert ast.dump(actual) == expected



# Generated at 2022-06-23 22:41:16.325041
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    xs = """\
d = {'a':2, 3:4, 'b':{'a':1, **{'c':2}}}
e = {'a':2, 3:4, 'b':{'a':1, **{'c':2}}, **z}
f = {}
"""

# Generated at 2022-06-23 22:41:17.267579
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:24.418029
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Unit test for method __init__ of class DictUnpackingTransformer
    def test_init():
        transformer = DictUnpackingTransformer()
        assert transformer.tree_changed is False

    # Unit test for method visit_Module of class DictUnpackingTransformer
    def test_visit_Module():
        transformer = DictUnpackingTransformer()
        module = ast.parse('{1: 1, **dict_a}')

        module_1 = transformer.visit(module)

        code = ast.unparse(module_1)

# Generated at 2022-06-23 22:41:34.483065
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    r'''
    make_test_ctree: SETUP = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    """
    make_test_ctree: INPUT = """
    {1: 1, **{2: 2}}
    """
    make_test_ctree: EXPECTED = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}, {2: 2}])
    """
    '''



# Generated at 2022-06-23 22:41:35.894640
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer is DictUnpackingTransformer

# Generated at 2022-06-23 22:41:37.516139
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:45.999676
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from . import assert_transform

    # No None in keys
    assert_transform(
        DictUnpackingTransformer,
        """
        {1: 2}
        """,
        """
        {1: 2}
        """)

    # Dict with unpacking
    assert_transform(
        DictUnpackingTransformer,
        """
        {1: 2, **a}
        """,
        """
        _py_backwards_merge_dicts([{1: 2}], a)
        """)

    # Dict with unpacking after other keys

# Generated at 2022-06-23 22:41:50.874438
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transform = DictUnpackingTransformer()
    src = raw_parse('x = {**dict_a}')
    result = transform(src)
    assert result == raw_parse(merge_dicts() + '\nx = _py_backwards_merge_dicts([], dict_a)')


# Generated at 2022-06-23 22:41:52.386002
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer  # Avoid warning about no usage

# Generated at 2022-06-23 22:41:54.033661
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    instance = DictUnpackingTransformer()

# This test shows examples of usage of the DictUnpackingTransformer

# Generated at 2022-06-23 22:41:54.599150
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:55.459964
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:03.098587
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = ast.parse("""
        {1: 2, None: None, 3: 4}
    """)
    expected = ast.parse("""
        _py_backwards_merge_dicts([{1: 2, 3: 4}], None)
    """)
    actual = DictUnpackingTransformer().visit(source)
    assert ast.dump(expected) == ast.dump(actual)

    source = ast.parse("""
        {1: 2, None: None, None: None, 3: 4}
    """)
    expected = ast.parse("""
        _py_backwards_merge_dicts([{1: 2, 3: 4}], None, None)
    """)
    actual = DictUnpackingTransformer().visit(source)

# Generated at 2022-06-23 22:42:05.639486
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    d = DictUnpackingTransformer()
    # assert d.target == (3, 4)
    assert d._tree_changed is False

# Generated at 2022-06-23 22:42:13.245324
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor  # type: ignore

    # Merging empty dicts
    output = astor.to_source(DictUnpackingTransformer().visit(ast.parse("{**{}}")))
    assert output == "_py_backwards_merge_dicts([{}])"
    output = astor.to_source(DictUnpackingTransformer().visit(ast.parse("{**{}, **{}}")))
    assert output == "_py_backwards_merge_dicts([{}])"

    # Merging dicts
    output = astor.to_source(DictUnpackingTransformer().visit(ast.parse("{**{'a': 1}}")))
    assert output == "_py_backwards_merge_dicts([{'a': 1}])"
    output = astor.to

# Generated at 2022-06-23 22:42:14.304976
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:16.101625
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:42:22.658763
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
    def f(x):
    	return {**x}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    def f(x):
    	return _py_backwards_merge_dicts([x])
    """
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    tree = ast.fix_missing_locations(tree)
    assert ast.unparse(tree).strip() == expected.strip()



# Generated at 2022-06-23 22:42:24.705976
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert DictUnpackingTransformer().visit(ast.parse("""
        {}
    """)) == ast.parse("""
        _py_backwards_merge_dicts([{}])
    """)


# Generated at 2022-06-23 22:42:32.165645
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_astunparse

    code = '''\
        {1: 1, **dict_a}
        '''

    # We can't use typed_ast.ast3.parse since it doesn't support PEP 448
    root = ast.parse(code)
    DictUnpackingTransformer().visit(root)

    unparsed = typed_astunparse.unparse(root)
    assert unparsed == '''\
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        '''

# Generated at 2022-06-23 22:42:38.310019
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astunparse import unparse
    from ..utils.test import get_test_cases

    get_test_cases(
        __file__, 'DictUnpackingTransformer-visit_Dict-input', 'DictUnpackingTransformer-visit_Dict-output',
        lambda x: ast.parse(x).body[0],
        lambda x: unparse(DictUnpackingTransformer().visit(x)).strip()
    )

# Generated at 2022-06-23 22:42:40.985332
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse('{1: 2, **{3: 4, 5: 6}}')
    result = DictUnpackingTransformer().visit(tree)
    assert result.body[0].value.value.func.id == '_py_backwards_merge_dicts'

# Generated at 2022-06-23 22:42:45.741702
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
{1: 2, **dict_a, 3: 4}
"""
    result = """
_py_backwards_merge_dicts([{1: 2, 3: 4}], dict_a)
"""
    update_test_data(
        DictUnpackingTransformer, 'test_DictUnpackingTransformer',
        'visit_Module', source, result)


# Generated at 2022-06-23 22:42:46.789836
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:58.011803
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:43:04.715057
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    import ast

    transformer = DictUnpackingTransformer()
    node = ast.Dict(keys=[None, ast.Num(1), ast.Num(3)],
                    values=[ast.Dict(keys=[None, ast.Str('a')],
                                     values=[ast.Name(id='d'),
                                             ast.List()]),
                            ast.Name(id='b'),
                            ast.Dict(keys=[ast.Name(id='c')],
                                     values=[ast.Tuple()])])

    new_node = transformer.visit(node)

# Generated at 2022-06-23 22:43:13.900925
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source1
    from ..utils.source import source

    # test_DictUnpackingTransformer_visit_Module_1
    s = source1('''
    {1: 1, **dict_a}
    ''')
    module = s.get_ast()
    transformer = DictUnpackingTransformer()
    transformer.visit(module)
    s = module.get_source()
    assert s == source('''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    
    
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-23 22:43:15.103242
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:43:20.176437
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """
        {a: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([dict(a=1)], dict_a)
    """

    node, _ = parse(code, mode='eval')
    transformed = DictUnpackingTransformer().visit(node)
    transformed_code = unparse(transformed)

    compare_source(expected, transformed_code)

# Generated at 2022-06-23 22:43:25.588602
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def f():
        return {'a': 'a', 'b': 'b', **{'c': 'c', 'd': 'd'}, 'e': 'e'}

    tree = ast.parse(f.__code__.co_consts[0])
    DictUnpackingTransformer().visit(tree)
    func = compile(tree, pathlib.Path(__file__).parent.as_posix(), 'exec')
    globals_ = {}
    locals_ = {}
    exec(func, globals_, locals_)
    assert locals_['f']() == f()

# Generated at 2022-06-23 22:43:27.849009
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:43:29.459477
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer is DictUnpackingTransformer

# Generated at 2022-06-23 22:43:33.810675
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .. import compile_restricted
    module = compile_restricted('''
    {**{1: 1}, **dict_a}
    ''')
    assert len(module.body) == 1
    expr = module.body[0]
    assert isinstance(expr.value, ast.Call)



# Generated at 2022-06-23 22:43:35.198167
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:43:45.028991
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import assert_equal_ASTs
    src = """
{1: 1, 2: 2, 3: 3, None: {1: 1, 2: 2, 3: 3}, 5: 5, 6: 6, None: {1: 1, 2: 2, 3: 3, 4: 4, 5: 5}, 8: 8, None: {}}
    """
    expected = """
_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}, {1: 1, 2: 2, 3: 3}, {1: 1, 2: 2, 3: 3, 4: 4, 5: 5}, {}], {5: 5, 6: 6}, 8)
    """


# Generated at 2022-06-23 22:43:54.772219
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .split import SplitTransformer
    from ..utils.tree import parse
    from ..utils.codegen import to_source

    src = """
        from __future__ import annotations

        d = {1: 2, **{3: 4, 5: 6}, 7: 8, 10: 11, **{12: 13}}
        d = {None: 2, 3: 2, None: {4: 7}, **{None: None}}
    """


# Generated at 2022-06-23 22:43:55.915161
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:44:05.235039
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    tree = ast.Dict([ast.Num(1), ast.Name(id='a')],
                    [ast.Num(1), ast.Name(id='a')])
    node = DictUnpackingTransformer().visit(tree)
    assert isinstance(node, ast.Call)
    expected = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[ast.List(elts=[ast.Dict(keys=[ast.Num(1)],
                                      values=[ast.Num(1)]),
                             ast.Name(id='a')])],
        keywords=[])
    assert ast.dump(node) == ast.dump(expected)



# Generated at 2022-06-23 22:44:08.431484
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    d = DictUnpackingTransformer()


# Unit tests for instance method DictUnpackingTransformer.visit_Dict

# Generated at 2022-06-23 22:44:19.694202
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dut = DictUnpackingTransformer()

    code = """
        {1: 1, **dict_a}
    """
    node = ast.parse(code)
    new_node = dut.visit(node)
    assert_equal(ast.dump(new_node, include_attributes=False), """
        Module(body=[
            Expr(value=Call(
                func=Name(id='_py_backwards_merge_dicts', ctx=Load()),
                args=[List(elts=[
                    Dict(keys=[
                        Num(n=1),
                        ], values=[
                        Num(n=1),
                        ]),
                    Name(id='dict_a', ctx=Load())
                    ], ctx=Load()),
                keywords=[])),
            ])
        """)


#

# Generated at 2022-06-23 22:44:21.247331
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer = DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:22.703263
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:26.737413
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    assert bytes(transformer.visit(ast.parse(
        '{1: 1, **dict_a}'))) == \
        b'_py_backwards_merge_dicts([{1: 1}], dict_a);'

# Generated at 2022-06-23 22:44:37.007623
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    t = DictUnpackingTransformer()

    def test(before):
        node = ast.parse(before)
        new_node = t.visit(node)
        return ast.unparse(new_node)

    assert test('{1: 1}') == '{1: 1}'
    assert test('{1: 1, **{}}') == '_py_backwards_merge_dicts([{1: 1}], {})'
    assert test('{1: 1, **{1: 1}}') == '_py_backwards_merge_dicts([{1: 1}], {1: 1})'
    assert test('{1: 1, 2: 2, **{}}') == '_py_backwards_merge_dicts([{1: 1, 2: 2}], {})'

# Generated at 2022-06-23 22:44:46.629620
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    class AssignBack(ast.NodeTransformer):
        def visit_Assign(self, node):
            node.value = node.value.args[0]
            return node

    code = """\
{1: 1, **dict_a}
{2: 2, **x(), **dict_a}
{1: 1, **dict_a, 2: 2}
{4: 4, **x(), 3: 3, **dict_a}
{1: 1, **dict_a, 2: 2, 3: 3, **dict_b}
{1: 1, **dict_a, 2: 2, 3: 3, **dict_b, **x()}
{1: 1, **dict_a, 2: 2, 3: 3, **dict_b}
    """

# Generated at 2022-06-23 22:44:48.267161
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # type: () -> None
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:57.622416
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astunparse import unparse
    from ..utils.testing_utils import transform
    from ..utils.ast_utils import equal_ast


    def check(code: str, expected: str):
        assert equal_ast(transform(DictUnpackingTransformer, code), expected)
        assert equal_ast(transform(DictUnpackingTransformer, expected), expected)

    def check_error(code: str):
        err_msg = 'must be a mapping'
        with pytest.raises(TypeError, match=err_msg):
            transform(DictUnpackingTransformer, code)


# Generated at 2022-06-23 22:45:04.199179
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import Tuple
    import ast

    node = ast.parse('''
    dict([
        (1, 2),
        (2, 3),
        **{3: 4},
        **{4: 5}
    ])
    ''')
    expected = str(ast.parse(
        '_py_backwards_merge_dicts([dict([(1, 2), (2, 3)]), {3: 4}, {4: 5}])'))

    # Test: Compiles dict unpacking in literal dictionaries.
    transformer = DictUnpackingTransformer()
    transformer.visit(node)
    assert str(node) == expected

    # Test: Returns node when unpacking is not present.
    transformer = DictUnpackingTransformer()

# Generated at 2022-06-23 22:45:10.301565
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest

    class TestCase(unittest.TestCase):
        maxDiff = None

        def setUp(self):
            self.assertIsNotNone(DictUnpackingTransformer)


# Generated at 2022-06-23 22:45:11.355027
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-23 22:45:11.933239
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    pass

# Generated at 2022-06-23 22:45:19.657193
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()

    pairs = [(None, ast.Num(1)),
             (ast.Str('a'), ast.Num(1)),
             (ast.Num(5), ast.Num(5)),
             (ast.Str('b'), ast.Num(2)),
             (None, ast.Num(2))
             ]

    splitted = t._split_by_None(pairs)

# Generated at 2022-06-23 22:45:30.020612
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..pretty_print import pretty
    from ..compile import compile
    from ..test_utils.test_fixtures import typed_nodes
    

# Generated at 2022-06-23 22:45:38.911089
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ...actions.registration import register_transformer_under_name
    snippet = merge_dicts().get_snippet()
    assert isinstance(snippet, ast.Module)
    register_transformer_under_name(DictUnpackingTransformer)
    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)
    result = DictUnpackingTransformer.apply_on_module(snippet)
    assert isinstance(result, ast.Module)
    assert isinstance(result.body[0], ast.FunctionDef)
    assert isinstance(result.body[1], ast.FunctionDef)
    assert result.body[0] == result.body[1]


# Generated at 2022-06-23 22:45:44.838121
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:45:49.803362
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.tree import build_tree
    from ..utils.tree_compare import tree_compare
    
    source = \
"""{**a, **b}"""
    
    expected = \
"""
# coding: utf-8
_py_backwards_merge_dicts([{}], a, b)
"""

    tree = build_tree(source)
    assert tree_compare(DictUnpackingTransformer().visit(tree), expected)



# Generated at 2022-06-23 22:45:51.023746
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), BaseNodeTransformer)

# Generated at 2022-06-23 22:45:51.961711
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:45:59.594643
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast
    import astunparse

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    root = ast.parse(source)
    DictUnpackingTransformer(3.4).visit(root)
    result = astunparse.unparse(root)
    print(result)
    assert expected == result



# Generated at 2022-06-23 22:46:07.914413
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from itertools import chain
    from typed_astunparse import unparse
    from ..utils.source_visitor import SourceVisitor

    visitor = SourceVisitor(
        DictUnpackingTransformer,
        fixtures_dir=os.path.join(
            os.path.dirname(__file__), 'examples'))
    fnames = visitor.run(['dict_unpacking.py'])

    for name in chain(fnames):
        with open(name) as f:
            tree = ast.parse(f.read())
        produced = unparse(tree).strip()

        expected_fname = os.path.join(os.path.dirname(__file__),
                                      'expected',
                                      os.path.basename(name))

# Generated at 2022-06-23 22:46:18.462038
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.utils import transform

    assert transform(DictUnpackingTransformer, "{**{}, **{}}") == "{}"
    assert transform(
        DictUnpackingTransformer,
        "{**{3: 4}}") == "dict({3: 4})"
    assert transform(
        DictUnpackingTransformer,
        "{**{**{}}, **[]}") == "_py_backwards_merge_dicts([], [])"
    assert transform(
        DictUnpackingTransformer,
        "{**{3: 4}, **{5: 6}}") == "_py_backwards_merge_dicts([{3: 4}], {5: 6})"

# Generated at 2022-06-23 22:46:29.184965
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse("""
    import ast
    import typed_ast
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    def example():
        print({1: 2, 3: 4, **{5: 6}})
    """)
    DictUnpackingTransformer.run_visitor(node)

# Generated at 2022-06-23 22:46:30.286416
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()



# Generated at 2022-06-23 22:46:38.011147
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .testutils import assert_equal_ast
    from .testutils import compile_and_run
    from .testutils import parse

    # Test unit for visit_Dict method of class DictUnpackingTransformer
    # by comparing outputs of ASTs before and after transformation
    # Test with single unpacking argument
    code = """
    {1: 1, **single_a}
    """
    tree = parse(code)
    assert_equal_ast(tree, compile_and_run(code))

    # Test with multiple unpacking arguments
    code = """
    {1: 1, **a, **b}
    """
    tree = parse(code)
    assert_equal_ast(tree, compile_and_run(code))

    # Test with explicit unpacking arguments

# Generated at 2022-06-23 22:46:42.731346
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a})'

    actual = DictUnpackingTransformer().visit_Module(ast.parse(source))
    actual = ast.unparse(actual)

    assert expected in actual

# Generated at 2022-06-23 22:46:52.400003
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source

    src = """
        x = {**a, 23: b, **c, **d}
        y = 23
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        x = _py_backwards_merge_dicts([{}, {23: b}], a, c, d)
        y = 23
    """
    tree = source_to_ast(src)
    tr = DictUnpackingTransformer()
    assert source(tr.visit(tree)) == source(expected)



# Generated at 2022-06-23 22:47:02.095705
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import Assign, Name, parse
    from ..utils import pretty
    from .testing_utils import assert_transformation_result

    code_before = """
{1: 2, 3: 4, **{4: 5}}
    """
    code_after = """
_py_backwards_merge_dicts([{1: 2, 3: 4}], {4: 5})
    """
    tree_before = parse(code_before)
    tree_after = parse(code_after)
    tree_after.body[0].body[0].lineno = 1
    tree_after.body[0].body[0].col_offset = 4
    transformer = DictUnpackingTransformer()
    tree_after = transformer.visit(tree_before)

# Generated at 2022-06-23 22:47:07.233326
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTestCase
    
    class _Case(BaseNodeTestCase):
        target_class = DictUnpackingTransformer
        transformer_module = __name__
        fixture_name = 'DictUnpackingTransformer'
    
    _Case.check_module_method('visit_Dict')


# Generated at 2022-06-23 22:47:09.990178
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().__class__ == DictUnpackingTransformer
    assert type(DictUnpackingTransformer()) == DictUnpackingTransformer


# Generated at 2022-06-23 22:47:10.502133
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:47:13.472867
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import astor

    self = DictUnpackingTransformer()
    assert astor.to_source(self.visit(
        ast.parse('{1: 1, **dict_a}', mode='eval'))) == \
           '_py_backwards_merge_dicts([{1: 1}], dict_a)'

# Generated at 2022-06-23 22:47:17.923540
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    unpacking_transformer = DictUnpackingTransformer()
    unpacking_transformer.visit_Dict(ast.parse('{1: 2, **dict_a}').body[0]) == \
        '_py_backwards_merge_dicts([{1: 2}], dict_a)'


# Generated at 2022-06-23 22:47:26.047075
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_code_equal
    dut = DictUnpackingTransformer()
    tree = ast.parse('{1: 1, **d1}\n')
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1}], d1)\n'
                         '\n'
                         '\n'
                         'def _py_backwards_merge_dicts(dicts):\n'
                         '    result = {}\n'
                         '    for dict_ in dicts:\n'
                         '        result.update(dict_)\n'
                         '    return result\n')
    assert_code_equal(dut.visit(tree), expected)

# Generated at 2022-06-23 22:47:26.911244
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:47:35.400023
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_visitor import TestVisitor
    from ..utils.test_utils import parse_string_as_module, assert_source_equal
    module = parse_string_as_module(
        """
        magic = {1: 2, None: dict, 3: 4}
        """)
    TestVisitor.visit(module, DictUnpackingTransformer)
    assert_source_equal(module, """
    magic = _py_backwards_merge_dicts([{1: 2, 3: 4}], dict)
    """)
