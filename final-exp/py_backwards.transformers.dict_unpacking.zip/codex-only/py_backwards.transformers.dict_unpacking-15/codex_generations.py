

# Generated at 2022-06-23 22:37:27.111924
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    src = """
        {**a, 1: 1, **b, **c, 2: 2}
    """
    expected = """
        _py_backwards_merge_dicts([dict(a), {1: 1}, dict(b), dict(c), {2: 2}])
    """
    tf = DictUnpackingTransformer()
    result = tf.transform_source(src)
    print(result)
    assert result.strip() == expected.strip()

# Generated at 2022-06-23 22:37:36.767426
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    import textwrap


# Generated at 2022-06-23 22:37:44.154257
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import get_node
    from ..utils.tree import dump
    from .meta import ModuleTransformer

    class DictUnpackingModuleTransformer(ModuleTransformer):
        def do_transform(self):
            self._tree_changed = True
            return DictUnpackingTransformer().transform(self._module)

    module = get_node('''
        left = {1: 1, 2: 2}
        center = {**left, 3: 3}
        right = {4: 4, **center}
        ''')

    transformed = DictUnpackingModuleTransformer(module).transform()
    dump(transformed, open('test-results/test_DictUnpackingTransformer_visit_Dict', 'w'))


# Generated at 2022-06-23 22:37:49.743181
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
    {1: 1, **{key: param}}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}, dict(param)])
    """

    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)  # type: ignore
    assert ast.dump(tree) == expected

# Generated at 2022-06-23 22:37:58.390874
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.ast_builder import ast_call, ast_dict, ast_name, ast_list, ast_num
    import astor
    foo = "foo"
    expr = ast_dict(keys=[None, ast_num(1), None], values=[
        ast_call(func="bar", args=[], keywords=[]),
        ast_num(1),
        ast_dict(keys=[ast_num(2), ast_num(3)], values=[
            ast_num(2),
            ast_num(3)])
    ])

# Generated at 2022-06-23 22:38:08.608987
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .transformers import TransformationsManager
    from .transforms import DictUnpackingTransformer
    from ..utils.source import source

    code = '''
            def f(a, b, c):
                d = {
                    b: a,
                    **c,
                    1: 2,
                    **{
                        3: 6,
                        4: 8
                    },
                    a: 4
                }
                return d
            '''
    tree = ast.parse(code)
    manager = TransformationsManager()
    manager.register(DictUnpackingTransformer)
    new_tree = manager.transform(tree)
    result = source(new_tree)


# Generated at 2022-06-23 22:38:13.792550
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from unittest import TestCase
    from typed_astunparse import unparse
    from .utils import roundtrip

    class DictUnpackingTransformerTestCase(TestCase):
        def test(self):
            def source():
                a, b, c = 1, 2, 3
                return {1: 1, b: a, c: b}

            def expected():
                a, b, c = 1, 2, 3
                return _py_backwards_merge_dicts([{1: 1, b: a}], {c: b})

            def expected_merged():
                a, b, c = 1, 2, 3
                return _py_backwards_merge_dicts(
                    [{1: 1, b: a}, {c: b}])


# Generated at 2022-06-23 22:38:19.903558
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    statement = """
    {1: 1, None: {2, 3}, **dict_a}
    """.strip()

    node = ast.parse(statement)
    xformer = DictUnpackingTransformer()
    xformer.visit(node)
    expected = """
    _py_backwards_merge_dicts([{1: 1}, {2, 3}], dict_a)
    """.strip()
    actual = ast.unparse(node)
    assert actual == expected

# Generated at 2022-06-23 22:38:27.096790
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from .utils import transform_and_compare

    transform_and_compare(
        source="""
        {'a': 1, 2: {'a': f, 'b': 'abc'}, **{'b': 2, 'c': 3}, 'c': 4, None: {'d': 5}}
        """,
        transformer=DictUnpackingTransformer,
        result="""
        _py_backwards_merge_dicts([{'a': 1, 2: _py_backwards_merge_dicts([{'a': f, 'b': 'abc'}], {'b': 2, 'c': 3}), 'c': 4}], {'d': 5})
        """,
        result_ast=ast3,
    )

# Generated at 2022-06-23 22:38:35.095264
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from textwrap import dedent

    node = ast.parse(dedent('''
    def foo():
        pass
    '''))

    transformed = DictUnpackingTransformer().visit(node)
    assert isinstance(transformed, ast.Module)

    assert len(transformed.body) == 2
    body = transformed.body
    assert "def _py_backwards_merge_dicts(dicts):" in type(body[0]).__qualname__
    assert "def foo():" in type(body[1]).__qualname__



# Generated at 2022-06-23 22:38:39.276551
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    nodes = transformer.visit(merge_dicts.get_ast())
    expected = merge_dicts.get_ast()
    assert ast.dump(nodes) == ast.dump(expected)


# Generated at 2022-06-23 22:38:46.719284
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:38:50.516906
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    merged_dicts = merge_dicts.get_body()
    new_module = transformer.visit(merged_dicts)  # type: ignore
    assert new_module == ast.Module(body=[merged_dicts])  # type: ignore


# Generated at 2022-06-23 22:38:52.790686
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    unpacking = DictUnpackingTransformer()
    unpacking.visit(merge_dicts.get_ast())

# Generated at 2022-06-23 22:39:04.052742
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.sample import get_random_ast
    from ..utils.tree import find_all_any
    from .converter import from_source
    from .unlambda import UnlambdaTransformer
    from .merge_dicts import MergeDictUnpackingTransformer

    for i in range(100):
        ast_ = get_random_ast()
        ast_.body.append(from_source('_py_backwards_merge_dicts = dict'))
        all_Dict = find_all_any(ast_, ast.Dict)
        transformer = UnlambdaTransformer()
        ast_ = transformer.visit(ast_)
        transformer = MergeDictUnpackingTransformer()
        ast_ = transformer.visit(ast_)

# Generated at 2022-06-23 22:39:13.403334
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.py_ast_parse import parse


# Generated at 2022-06-23 22:39:15.041331
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:39:21.930520
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    from typing import Union
    from typed_ast import ast3 as ast
    from ..utils.tree import dict_to_str
    from ..transformations import DictUnpackingTransformer


# Generated at 2022-06-23 22:39:32.284402
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Unit test for method visit_Dict of class DictUnpackingTransformer"""

    # Main
    transformer = DictUnpackingTransformer()
    source_code = '''
        {
            'a': 1,
            **{'b': 2, 'c': 3},
            'd': 4,
            **{'e': 5, 'f': 6},
            'g': 7
        }
    '''
    source_code_tree = ast.parse(source_code)
    result = transformer.visit(source_code_tree)
    result_code = result.body[0].body[0].value

    # Asserts

# Generated at 2022-06-23 22:39:39.245684
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..tests.utils import assert_files_equal
    from ..main import transform
    from ..utils.context import Context
    from pathlib import Path
    assert_files_equal(
        Path(__file__).parent,
        Path(__file__).with_name('test_DictUnpackingTransformer_visit_Module.py'),
        Path(__file__).with_name('test_DictUnpackingTransformer_visit_Module.py.expected'),
        transform,
        Context(),
        {
            'DictUnpackingTransformer': DictUnpackingTransformer,
        })

# Generated at 2022-06-23 22:39:40.074060
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:39:49.903108
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    node = ast.parse(textwrap.dedent('''\
        {1: 2, **{3: 4}}
    '''))
    node = transformer.visit(node)  # type: ignore

# Generated at 2022-06-23 22:39:51.362887
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().__class__.__name__ == 'DictUnpackingTransformer'

# Generated at 2022-06-23 22:39:54.920139
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """{1: 1, **dict_a, 2: 2, **dict_b, 3: 3}"""
    expected = """
_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    assert DictUnpackingTransformer().transform(source) == expected

# Generated at 2022-06-23 22:39:55.612692
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-23 22:40:00.331069
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.normalize import normalize_result

    tree = ast.parse("""
    {1: 1, 2: 2, 3: 3, **dict_a, None: 4, None, **dict_b, 5: 5}
    """)
    result = DictUnpackingTransformer(debug=True).visit(tree)
    assert result == normalize_result("""
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, {4: None}, dict_b, {5: 5})
    """)

# Generated at 2022-06-23 22:40:10.882040
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """
    import ast
    import pytest
    from typed_ast import ast3 as ast
    from mypy_extensions import DefaultArg
    from pyree.transforms import DictUnpackingTransformer
    """

    def check(in_, expected):
        result = DictUnpackingTransformer().visit(in_)
        assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-23 22:40:18.611253
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import astor
    
    # Test:
    # node = ast.parse('''{**b, **c, 1: 2, 3: 3}''')
    node = ast.Dict(keys=[None, None, ast.Num(1), ast.Num(3)],
                    values=[ast.Name(id='b'), ast.Name(id='c'), ast.Num(2), ast.Num(3)])

    new_node = node.copy()
    trans = DictUnpackingTransformer()
    trans.visit(new_node)

    assert astor.to_source(new_node) == '_py_backwards_merge_dicts([{3: 3, 1: 2}], c, b)'

# Generated at 2022-06-23 22:40:19.499551
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-23 22:40:21.326182
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert t.__class__.__name__ == 'DictUnpackingTransformer'


# Generated at 2022-06-23 22:40:31.571884
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def test(ast_s: str, expected: str) -> ast.AST:
        node = ast.parse(ast_s)
        transformer = DictUnpackingTransformer()
        transformed = transformer.visit(node)
        expected_node = ast.parse(expected)
        assert transformer._tree_changed
        assert ast.dump(expected_node) == ast.dump(transformed)
        return expected_node

    test(
        '{1: 1, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1}], dict_a)',
    )

    test(
        '{"b": {"b": "b"}, **a}',
        '_py_backwards_merge_dicts([{"b": {"b": "b"}}], a)',
    )

   

# Generated at 2022-06-23 22:40:32.736271
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:36.199414
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    instantiate(
        """
        assert(isinstance(DictUnpackingTransformer(), Transformer))""",
        setup="""from py_backwards.transformers.dict_unpacking import DictUnpackingTransformer""")

# Generated at 2022-06-23 22:40:42.293483
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    source = {
        '{**x, "a": y, z, **None}':
            '_py_backwards_merge_dicts([], {"a": y}, z, x)',
        '{**None, **x}':
            '_py_backwards_merge_dicts([], x)',
    }
    for target, result in source.items():
        target = ast.parse(target)
        result = ast.parse(result).body[0]
        assert transformer.visit(target) == result

# Generated at 2022-06-23 22:40:53.059045
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as pyast
    from . import dump

    node = pyast.parse("{**{}, 1: 2, **{1: 1}}")
    DictUnpackingTransformer().visit(node)
    assert dump(node) == "[Expr(value=Call(func=Name(id='_py_backwards_merge_dicts', ctx=Load()), args=[List(elts=[Dict(keys=[], values=[]), Call(func=Name(id='dict', ctx=Load()), args=[Dict(keys=[Str(s='1')], values=[Num(n=2)])], keywords=[]), Dict(keys=[Num(n=1)], values=[Num(n=1)])], ctx=Load()), keywords=[]))]"

# Generated at 2022-06-23 22:40:59.858108
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    ast_dict = ast.parse("{**dict_a, 'b': 2, **dict_c, 'd': 4}")
    transformer = DictUnpackingTransformer()

    result = transformer.visit(ast_dict)

    assert isinstance(result, ast.Call)
    assert isinstance(result.args[0].elts[0], ast.Dict)
    assert isinstance(result.args[0].elts[1], ast.Call)
    assert len(result.args[0].elts) == 2
    assert len(result.args[0].elts[0].keys) == 1
    assert result.args[0].elts[0].keys[0].s == 'b'
    assert isinstance(result.args[0].elts[1], ast.Call)

# Generated at 2022-06-23 22:41:07.736563
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    dict_ = ast.Dict(keys=[None, ast.Name(id='a'), ast.Name(id='b')],
                     values=[ast.Dict(keys=[ast.Num(n=1)],
                                      values=[ast.Num(n=1)]),
                             ast.Name(id='dict_a'),
                             ast.Name(id='dict_b')])
    expected = ast.ast3.parse('_py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)')
    assert transformer.visit(dict_) == expected

# Generated at 2022-06-23 22:41:09.434182
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:41:11.419007
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():  # type: ignore
    x = DictUnpackingTransformer()
    assert x  # Just needed to pass the test

# Generated at 2022-06-23 22:41:20.831020
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()

    pairs = [(ast.Str(s='bar'), ast.Constant(value=1)),
             (None, ast.Name(id='foo')),
             (ast.Str(s='baz'), ast.Constant(value=2)),
             (None, ast.Name(id='bar')),
             (ast.Str(s='foo'), ast.Constant(value=3))]


# Generated at 2022-06-23 22:41:31.402535
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_resource import get_test_ast

    # 1. Test that no merging if unpacking is not used
    ast_node = get_test_ast("""{1: 1, 2: 2}""")
    DictUnpackingTransformer().visit(ast_node)
    assert ast_node == get_test_ast("""{1: 1, 2: 2}""")

    # 2. Test that merging is possible
    ast_node = get_test_ast("""{1: 1, **dict_a}""")
    transformer = DictUnpackingTransformer()
    transformer.visit(ast_node)
    assert ast_node == get_test_ast("""_py_backwards_merge_dicts([{1: 1}],
                                                                   dict_a)""")
    assert transformer._

# Generated at 2022-06-23 22:41:33.110671
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    _ = DictUnpackingTransformer()


__transformer__ = DictUnpackingTransformer

# Generated at 2022-06-23 22:41:35.672769
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    node = ast.Module()
    assert isinstance(node, ast.Module)
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)

# Generated at 2022-06-23 22:41:44.790655
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert compile_pystr("{1 : 1, **{2 : 2}}",
                         mode='exec',
                         flags=ast.PyCF_ONLY_AST) == \
            compile_pystr("""
                import sys
                if sys.version_info < (3, 4):
                    def _py_backwards_merge_dicts(dicts):
                        result = {}
                        for dict_ in dicts:
                            result.update(dict_)
                        return result
                else:
                    _py_backwards_merge_dicts = NotImplemented
                _py_backwards_merge_dicts(
                    [{1 : 1}], {2 : 2})""",
                         mode='exec',
                         flags=ast.PyCF_ONLY_AST)



# Generated at 2022-06-23 22:41:48.730725
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.test_utils import make_test_fixture
    test_fixture = make_test_fixture(__file__, DictUnpackingTransformer)
    test_fixture.test_transform_file('dict_unpacking_transform_test.py')

# Generated at 2022-06-23 22:41:54.680099
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse("""
{1: 1, 2: 2, 3: 3, **x, 4: 4, 5: 5, 6: 6, **y}
    """)
    res = ast.parse("""
_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}, x, {4: 4, 5: 5, 6: 6}], y)
    """)
    assert DictUnpackingTransformer().visit(tree) == res

# Generated at 2022-06-23 22:41:56.217770
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert 'test' in repr(DictUnpackingTransformer)
    assert 'test' in str(DictUnpackingTransformer)

# Generated at 2022-06-23 22:41:57.429924
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:42:05.525145
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Arrange
    splitted = [
        [
            (ast.Num(1), ast.Num(1)),
            (ast.Num(2), ast.Num(2)),
        ],
        ast.Name(id='dict_a'),
        [
            (ast.Num(3), ast.Num(3)),
            (ast.Num(4), ast.Num(4)),
        ]
    ]

    # Act
    result = DictUnpackingTransformer()._prepare_splitted(splitted)

    # Assert

# Generated at 2022-06-23 22:42:15.977594
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def _assert(input_, output):
        input_ = ast.parse(input_)
        transformer = DictUnpackingTransformer()
        output = transformer.visit(input_)
        assert ast.dump(output) == ast.dump(ast.parse(output))

    _assert(
        "a = {1: 1, **dict_a}",
        "a = _py_backwards_merge_dicts([{1: 1}], dict_a)")

    _assert(
        "a = {1: 1, 2: 2, **dict_a, 3: 3}",
        "a = _py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {3: 3}])")


# Generated at 2022-06-23 22:42:17.821388
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    input = """{1: 2, **{3: 4, **{5: 6}}}"""

# Generated at 2022-06-23 22:42:22.407133
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import _ast
    node = ast.parse('{None, None, 1: 1, 2:2, None, 3: 3, None, 4:4, None}')
    node_new = DictUnpackingTransformer().visit(node)
    expected = ast.parse(
        '_py_backwards_merge_dicts([{1: 1, 2: 2}, 3, {4: 4}])')
    assert ast.dump(node_new) == ast.dump(expected)

# Generated at 2022-06-23 22:42:23.109885
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer is not None

# Generated at 2022-06-23 22:42:32.268816
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_base import assert_equal_source
    from ..utils.source import source

    node = ast.parse(source(
        """from typing import Dict
        Dict[str, str]"""
    ))
    transform = DictUnpackingTransformer()
    transformed = transform.visit(node)
    assert transform._tree_changed
    assert_equal_source(
        transformed,
        """from typing import Dict
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        Dict[str, str]""")


# Unit tests for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:42:42.011200
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.source import source
    from ..utils.ast import parse
    from ..utils.tree import assert_tree_equal

    source_ = """
        {1: 1, **dict_a}
    """

    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = parse(source_)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert_tree_equal(tree, parse(source(expected)))

# Generated at 2022-06-23 22:42:46.784887
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse("{1: 1, **dict_a}")
    transformer = DictUnpackingTransformer()
    transformed = transformer.visit(node)
    expected = ast.parse("""
_py_backwards_merge_dicts([{1: 1}], dict_a)
""".lstrip())
    ast.fix_missing_locations(expected)
    assert ast.dump(transformed) == ast.dump(expected)

# Generated at 2022-06-23 22:42:54.075612
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astunparse
    source = """
    {**{1: 2}, 3: 3, 4: 4}
    """
    expected = """
    _py_backwards_merge_dicts([{3: 3, 4: 4}], {1: 2})
    """

    node = ast.parse(source)
    node = DictUnpackingTransformer().visit(node)  # type: ignore
    assert astunparse.unparse(node) == expected

# Generated at 2022-06-23 22:43:03.720438
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """{1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4, **dict_c}"""
    module = ast.parse(code)
    result = DictUnpackingTransformer().visit(module)

# Generated at 2022-06-23 22:43:13.463558
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('{1: 1, **{2: 2}, 3: 3}')
    instance = DictUnpackingTransformer()
    node = instance.visit(node)
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.FunctionDef)
    assert isinstance(node.body[1], ast.Expr)
    node = node.body[1].value
    assert isinstance(node, ast.Call)
    assert isinstance(node.args[0], ast.List)
    assert isinstance(node.args[0].elts[0], ast.Dict)
    assert isinstance(node.args[0].elts[1], ast.Call)
    assert isinstance(node.args[0].elts[2], ast.Dict)
    assert node

# Generated at 2022-06-23 22:43:16.328769
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    _ = DictUnpackingTransformer()
    assert _.visit_Module(ast.Module([merge_dicts.get_body()])) == ast.Module([])


# Generated at 2022-06-23 22:43:23.376772
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    d = ast.parse('m = {1, 2, 3}')
    x = DictUnpackingTransformer(d).visit(d)
    assert ast.dump(x) == 'Module(body=[Assign(targets=[Name(id=\'m\', ctx=Store())], value=Dict(keys=[Constant(value=1), Constant(value=2), Constant(value=3)], values=[Constant(value=1), Constant(value=2), Constant(value=3)])), ImportFrom(module=\'typed_ast\', names=[alias(name=\'ast3\', asname=None)], level=0)])'

# Generated at 2022-06-23 22:43:25.975059
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_utils import make_call
    node = make_call('foo', kwonlyargs=[('x', 1), ('y', 2)])
    visitor = DictUnpackingTransformer()
    visitor.visit(node)

# Generated at 2022-06-23 22:43:32.527450
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from mypy import build
    from os.path import dirname

    code = """
    def f():
        return {1: 2, **{3: 4}, 5: 6}
    """
    result = """
    def f():
        return _py_backwards_merge_dicts([{1: 2}, 5: 6}, {3: 4})
    """
    assert DictUnpackingTransformer().visit(build.parse(code)) == build.parse(result)

# Generated at 2022-06-23 22:43:42.136971
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from typed_astunparse import unparse

    test_code = '''
    {
        1: 2,
        **a,
        3: 4,
        **b,
        c: 5,
        **d,
        6: 7,
        **e
    }
    '''
    tree = ast.parse(test_code)
    node = tree.body[0].value
    assert isinstance(node, ast.Dict)

    result_node = DictUnpackingTransformer().visit(node)

    expected_result = '''
    _py_backwards_merge_dicts([{1: 2, 3: 4, c: 5, 6: 7}], a, b, d, e)
    '''

# Generated at 2022-06-23 22:43:43.397440
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()



# Generated at 2022-06-23 22:43:45.566182
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:43:55.031601
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .util import parse
    from .util import dump
    from .util import equal
    from .util import roundtrip_unparse
    
    print('*************** Original *****************')
    original = '{1: 1, **dict_a}'
    print(original)
    print('************* Transformed ****************')
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    node = parse(original)
    new_node = DictUnpackingTransformer().visit(node)
    print(dump(new_node))
    print('************** Expected *****************')
    print(expected)
    print('**************** Result *****************')
    assert equal(dump(new_node), expected)
    print('>>>>> OK')
    print()


# Generated at 2022-06-23 22:44:05.270872
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.codegen import ast_code_for
    code = ast_code_for(
        '{1: 1, 2: 2, 3: 3, **{4: 4, 5: 5, **{6: 6, 7: 7, **{8: 8}}}}')
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)

    expected = ast_code_for(
        '_py_backwards_merge_dicts([dict([(1, 1), (2, 2), (3, 3)])], '
        'dict([(4, 4), (5, 5)]), dict([(6, 6), (7, 7)]), dict([(8, 8)]))')
    assert ast_code_for(tree) == expected



# Generated at 2022-06-23 22:44:13.110256
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:44:19.335179
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .builders import Module, Dict, List, Name, Call
    from .build_ast import build_ast
    node = Module([
        Dict([1, 2]),
        Dict([(None, List([Dict([3, 4])])), (1, 2)]),
        Dict([(None, Dict([3, 4])), (1, 2)])
    ])

# Generated at 2022-06-23 22:44:28.263797
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert '''def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result
''' == merge_dicts.get_body()

    assert '''def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result

a = {1: 1, **dict_a}
''' == compile_code(
    source='''a = {1: 1, **dict_a}''',
    transformers=[DictUnpackingTransformer])



# Generated at 2022-06-23 22:44:38.202108
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Given
    node = ast.parse('{}')

    # When
    transformer = DictUnpackingTransformer()
    new_node = transformer.visit(node)

    # Then
    assert transformer._tree_changed is True


# Generated at 2022-06-23 22:44:39.742488
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(updating_globals=False)

# Generated at 2022-06-23 22:44:47.490584
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from .test_base import NodeTestCase

    source_code = '{1: 1, **dict_a}'
    expected_output = '_py_backwards_merge_dicts([{1: 1}], dict_a})'

    class TestVisitor(NodeTestCase):
        transformer = DictUnpackingTransformer

        def generic_visit(self, node):  # type: ignore
            self.assertSourceEqual(source_code, node)
            return super().generic_visit(node)

        def visit_Dict(self, node: ast.Dict):
            self.assertSourceEqual(expected_output, node)

    TestVisitor().run_test(source_code)

# Generated at 2022-06-23 22:44:54.703069
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """dict_b = {1: 'a', 2: 'b', **dict_a}"""
    tree = ast.parse(code)
    transformer = DictUnpackingTransformer()
    fixed_tree = transformer.visit(tree)
    fixed_code = ast.unparse(fixed_tree)

    assert fixed_code == """\
_py_backwards_merge_dicts([dict({1: 'a', 2: 'b'})], dict_a)
dict_b = dict({1: 'a', 2: 'b'})
"""

# Generated at 2022-06-23 22:45:05.444683
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()
    assert DictUnpackingTransformer.target == (3, 4)
    dict_unpacking_transformer = DictUnpackingTransformer()
    assert dict_unpacking_transformer._tree_changed == False
    assert dict_unpacking_transformer.visit_Module(
    ast.Module(body=[merge_dicts.get_body(), ast.Expr(value=ast.Dict(keys=[
        ast.Name(id='a')], values=[ast.Num(n=5)]))])).body[0] == merge_dicts.get_body()

# Generated at 2022-06-23 22:45:15.166973
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from unittest import TestCase

    class _Case(TestCase):
        def _test_same(self, expr, expected):
            transformer = DictUnpackingTransformer()
            expr_ = transformer.visit(expr)
            self.assertEqual(expr_, expected)
            self.assertFalse(transformer._tree_changed)

        def _test_changed(self, expr, expected):
            transformer = DictUnpackingTransformer()
            expr_ = transformer.visit(expr)
            self.assertEqual(expr_, expected)
            self.assertTrue(transformer._tree_changed)


# Generated at 2022-06-23 22:45:26.140862
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_source
    from ..apply import apply_transforms

    # {**{}, **{}}
    node = ast.Dict(keys=[ast.Constant(value=None),
                          ast.Constant(value=None)],
                   values=[ast.Dict(keys=[], values=[]),
                           ast.Dict(keys=[], values=[])])

# Generated at 2022-06-23 22:45:33.125113
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('''{1: 1, **dict_a}''')
    result = DictUnpackingTransformer().visit(node)
    assert ast.dump(result) == \
r'''Module(body=[
  Expr(value=Call(func=Name(id='_py_backwards_merge_dicts', ctx=Load()), args=[List(elts=[Dict(keys=[
    Num(n=1),
    None], values=[
    Num(n=1),
    Name(id='dict_a', ctx=Load())])], ctx=Load())], keywords=[]))
])
'''

# Generated at 2022-06-23 22:45:43.051796
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import make_test, make_test_module

# Generated at 2022-06-23 22:45:47.867557
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """
    Code before transformation:
        {'a': 1, 'b': 2, **x}
    Expecting:
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{'a': 1, 'b': 2}], x)
    """
    # Input
    module_ = ast.parse('{1: 1, **x}')

    # Transformation
    transformer = DictUnpackingTransformer()
    module = transformer.visit(module_)

    # Test result
    expected_result = ast.parse(merge_dicts() + '{1: 1, **x}')  # type: ignore
    assert transformer._tree_changed

# Generated at 2022-06-23 22:45:48.378898
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:45:50.170952
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import run_transformer_test

    run_transformer_test(DictUnpackingTransformer())

# Generated at 2022-06-23 22:46:01.199044
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # {1: 1, **dict_a}
    py_dict_one = ast.Dict(keys=[
        ast.Num(n=1),
        None,
    ], values=[
        ast.Num(n=1),
        ast.Name(id='dict_a', ctx=ast.Load()),
    ])
    # {2: 2, **dict_b}
    py_dict_two = ast.Dict(keys=[
        ast.Num(n=2),
        None,
    ], values=[
        ast.Num(n=2),
        ast.Name(id='dict_b', ctx=ast.Load()),
    ])
    # {**d1, **d2, **d3}

# Generated at 2022-06-23 22:46:06.464896
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:46:17.330644
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.fixtures import node_or_string


# Generated at 2022-06-23 22:46:18.460662
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    global DictUnpackingTransformer
    DictUnpackingTransformer


# Generated at 2022-06-23 22:46:23.776809
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    t = DictUnpackingTransformer()
    src = "b = 5"
    tree = ast.parse(src)
    new_tree = t.visit(tree)  # type: ignore
    assert src in ast.dump(new_tree)
    assert 'def _py_backwards_merge_dicts' in ast.dump(new_tree)



# Generated at 2022-06-23 22:46:33.686854
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    import inspect
    import typing

    tree = ast3.parse("d = {1:2, 3: 4, **{5, 6}, 7:8, **{9:10, a:b}}")
    node = tree.body[0].value
    assert isinstance(node, ast3.Dict)

    transformer = DictUnpackingTransformer()
    new_node = transformer.visit(node)

    assert isinstance(new_node, ast3.Call)
    assert isinstance(new_node.func, ast3.Name)
    assert new_node.func.id == '_py_backwards_merge_dicts'

    assert isinstance(new_node.args[0], ast3.List)
    assert len(new_node.args[0].elts) == 3

# Generated at 2022-06-23 22:46:37.382591
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    from ..debug import from_statement
    from ..utils.source import source

    def check(stmt):
        t = DictUnpackingTransformer()
        assert from_statement(stmt).visit(t) is not None
        return t._tree_changed

    assert check('X') is False
    assert check('{1: 1, **dict_a}') is True

# Generated at 2022-06-23 22:46:40.058420
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():  # noqa
    transformer = DictUnpackingTransformer()
    source = """
        {1: 1, 2: 2, **dict_a, 3: 3, **dict_b}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}, dict_a, dict_b])
    """
    tree = ast.parse(source)

    assert transformer.visit(tree).to_source().strip() == expected.strip()

# Generated at 2022-06-23 22:46:51.225692
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTest
    class Test(BaseNodeTest):
        target = DictUnpackingTransformer

# Generated at 2022-06-23 22:47:01.103517
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transform


# Generated at 2022-06-23 22:47:12.451163
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import assert_tree
    from ..utils.code_gen import assert_code_equal

    def _get_tree():
        node = ast.Dict(keys=None, values=ast.Name(id='dict_a'))  # type: ignore
        return ast.Dict(keys=[ast.Num(1)], values=[ast.Num(1)],
                        ctx=ast.Load()), node


# Generated at 2022-06-23 22:47:20.787309
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_transformed_ast
    from ..utils.testing import load_node

    node = load_node(
        """
        {1: 1}
        """
    )
    expected = load_node(
        """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
            
        {1: 1}
        """
    )
    assert_transformed_ast(node, expected, DictUnpackingTransformer)



# Generated at 2022-06-23 22:47:25.721951
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = "a = {1: 1, **{2: 2}}\n"