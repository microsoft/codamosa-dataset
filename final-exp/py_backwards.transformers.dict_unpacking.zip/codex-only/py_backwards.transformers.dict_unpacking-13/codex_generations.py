

# Generated at 2022-06-23 22:37:29.671548
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:37:30.608870
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None)

# Generated at 2022-06-23 22:37:31.559834
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-23 22:37:32.422786
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:37:42.162128
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    dict_a = ast.Name(id='a')
    dict_b = ast.Name(id='b')

    stmt = ast.Expr(ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=2), None],
                             values=[ast.Num(n=2), dict_a, ast.Num(n=3),
                                     dict_b]))

    result = transformer.visit(stmt)
    assert isinstance(result.value, ast.Call)


# Generated at 2022-06-23 22:37:46.559403
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    m = ast.parse("")

    tr = DictUnpackingTransformer()
    tr.visit(m)

    assert m == ast.parse("def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result")


# Generated at 2022-06-23 22:37:55.577105
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..transformer import BackwardsImportTransformer, ModuleTransformer
    from ..refactor import RefactoringTool
    from ..utils.source import source_to_unicode

    refactoring_tool = RefactoringTool([
        ('renames', BackwardsImportTransformer),
        ('dict_unpacking', DictUnpackingTransformer),
        ('module', ModuleTransformer)
    ])

    source = """
        result = {
            'key_a': a, 
            **{
                'key_b': b
            },
            'key_c': c,
            **{
                'key_d': d,
                'key_e': e
            }
        }
    """

    tree = refactoring_tool.refactor_string(source, 'path')


# Generated at 2022-06-23 22:38:06.590524
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.run_on_samples import run_on_samples
    from .test_base import TestBase
    from .test_imports import merge_classes
    from ..utils.test_utils import compare_ast


# Generated at 2022-06-23 22:38:07.979140
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert DictUnpackingTransformer(3, 4, None).visit_Module(ast.Module(body=[])) == ast.Module(body=[])


# Generated at 2022-06-23 22:38:13.087333
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import transforms_to

    transforms_to(
        """{1: 'a', **dict_a}""",
        """_py_backwards_merge_dicts([{1: 'a'}], dict_a)""")

    transforms_to(
        """{None: 1, **dict_a}""",
        """_py_backwards_merge_dicts([dict(None, 1)], dict_a)""")

    transforms_to(
        """{1: 1, 2: 2, **dict_a}""",
        """_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)""")


# Generated at 2022-06-23 22:38:17.998322
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .testing_utils import assert_transformed

    assert_transformed(
        DictUnpackingTransformer,
        """
        {1: 1, **dict_a, 2: 2}
        """,
        """
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
        """
    )



# Generated at 2022-06-23 22:38:20.824079
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    mod = ast.parse('{}')
    ast.fix_missing_locations(mod)

# Generated at 2022-06-23 22:38:26.264730
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """
        {1: 2, **dict_a, 3: 4, **dict_b, **dict_c, 5: 6}
    """
    node = ast.parse(dedent(code))
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    expected = ast.parse("""
        _py_backwards_merge_dicts([{1: 2, 3: 4, 5: 6}], dict_a, dict_b, dict_c)
    """)
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-23 22:38:31.437573
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    module = ast.parse('{}')
    assert transformer.visit(module) is module
    module = ast.parse('{1:1, **{1:1}}')
    assert transformer.visit(module) is module


# Generated at 2022-06-23 22:38:38.089512
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ast import parse, dump
    from ..utils.env import env
    from ..transforms import DictUnpackingTransformer, DictUnpacking

    source = """\
{1: 1, **dict_a}"""
    tree = parse(source)  # type: ast.AST

    transformer = DictUnpackingTransformer(env)
    transformer.visit(tree)

# Generated at 2022-06-23 22:38:39.778330
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer is not None


# Generated at 2022-06-23 22:38:49.996155
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_transformer import transform_code, f

    result = transform_code(f('{a: 1, b: 2, **c, **d, e: 3}'),
                            DictUnpackingTransformer)


# Generated at 2022-06-23 22:39:01.484408
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:39:07.105448
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source, to_source
    from .base import CompilerTestCase

    class Test(CompilerTestCase):
        def generate(self, source: str) -> ast.AST:
            node = source_to_ast(source)
            node = DictUnpackingTransformer().visit(node)
            node = ast.fix_missing_locations(node)

            return node

        def test_1(self):
            code = """
            {'a': 'b', None: 'c'}
            """

            expect = """
            _py_backwards_merge_dicts([{'a': 'b'}], 'c')
            """

            self.check(code, expect)


# Generated at 2022-06-23 22:39:07.933416
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-23 22:39:14.025295
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    import _ast
    test_code = '''
    def f(d):
        return {1: 2, **d}
    '''
    expected_code = '''
    def f(d):
        return _py_backwards_merge_dicts([{1: 2}], d)
    '''

    expected_tree = _ast.parse(expected_code)
    result_tree = ast.parse(test_code)
    DictUnpackingTransformer().visit(result_tree)

    assert astor.to_source(expected_tree) == astor.to_source(result_tree)



# Generated at 2022-06-23 22:39:18.383136
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    program = ast.parse(open('tests/samples/all_dicts.py').read())
    DictUnpackingTransformer().visit(program)
    # TODO: find better way to compare ASTs
    assert astor.to_source(program) == open('tests/samples/all_dicts_merged.py').read()

# Generated at 2022-06-23 22:39:26.244180
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
        def f(**kwargs):
            return {1: 1, **kwargs}
    """
    expected_code = """
        def _py_backwards_merge_dicts(dicts, dict_):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        def f(**kwargs):
            return _py_backwards_merge_dicts([dict({1: 1})], kwargs)
    """

    from ..utils.context import Context
    from ..utils.ast_builder import ASTBuilder
    from ..utils.ast_source import ASTSource

    astsrc = ASTSource(code)
    built = ASTBuilder().build(astsrc)

    ctx = Context()
    from .base import NodeTransformerPass

# Generated at 2022-06-23 22:39:33.134241
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import as_line
    from .. import core

    source = as_line("""
    {
        **a,
        1: 2,
        **b,
        3: 4,
        **c,
    }
    """)
    expected = as_line("""
    _py_backwards_merge_dicts([{1: 2, 3: 4}], a, b, c)
    """)

    assert expected == core.transpile(source, DictUnpackingTransformer)

# Generated at 2022-06-23 22:39:38.602664
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert '_py_backwards_merge_dicts' not in globals()
    assert '_py_backwards_merge_dicts' not in locals()
    transpile_file('DictUnpackingTransformer.visit_Module.py')
    assert '_py_backwards_merge_dicts' in globals()
    assert '_py_backwards_merge_dicts' in locals()



# Generated at 2022-06-23 22:39:40.879912
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    obj = DictUnpackingTransformer()
    assert obj.target == (3, 4)
    assert obj._tree_changed == False
    assert isinstance(obj, BaseNodeTransformer)



# Generated at 2022-06-23 22:39:48.900540
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing_utils.visitor import visit_and_compare_trees
    # no dict unpacking
    node = ast.Dict(keys=[ast.Num(1), ast.Num(2)], values=[ast.Num(2), ast.Num(3)])
    # result = ast.Dict(keys=[ast.Num(1), ast.Num(2)], values=[ast.Num(2), ast.Num(3)])
    visited = visit_and_compare_trees(node, DictUnpackingTransformer)
    assert isinstance(visited, ast.Dict)

    # one dict unpacking, not at the end

# Generated at 2022-06-23 22:39:56.166815
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import pytest
    from typed_ast import parse
    transpiler = DictUnpackingTransformer()

    dictionary = parse("{1: 1, 2: 2, **a}").body[0].value
    assert isinstance(dictionary, ast.Dict)

    splitted = transpiler._split_by_None(zip(dictionary.keys, dictionary.values))
    assert splitted == [[(ast.Num(1), ast.Num(1)), (ast.Num(2), ast.Num(2))],
                        parse('a').body[0].value, []]

    prepared = list(transpiler._prepare_splitted(splitted))

# Generated at 2022-06-23 22:39:58.067566
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3 as ast
    return ast.Module(body=[ast.Expr(value=ast.Name(id="_py_backwards_merge_dicts"))])


# Generated at 2022-06-23 22:40:01.481398
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert hasattr(DictUnpackingTransformer, 'target')
    assert hasattr(DictUnpackingTransformer, 'visit_Dict')
    DictUnpackingTransformer().visit(ast.parse(""))
    DictUnpackingTransformer().visit(
        ast.parse("x = {1: 1, 2: 2, None: x, None: y}"))
    assert DictUnpackingTransformer._tree_changed

# Generated at 2022-06-23 22:40:02.417523
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:05.248618
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('{1: 1, **dict_a}')
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-23 22:40:15.206768
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import textwrap
    import astor
    source = textwrap.dedent('''\
        a = {1: 1, **{2: 2, 3: 3}, 4: 4,  **{5: 5}, 6: 6, **{7: 7, 8: 8}, 9: 9}
        ''')

# Generated at 2022-06-23 22:40:20.623399
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    tree = ast.parse('''
{1: 1, **dict_a}
{**dict_a, 1: 1}
{1: 1, **dict_a, 2: 2}
{**dict_a, **dict_b}
{**dict_a, **dict_b, **dict_c}
    ''')

# Generated at 2022-06-23 22:40:21.211018
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:22.706840
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    d = DictUnpackingTransformer()
    assert isinstance(d, BaseNodeTransformer)

# Generated at 2022-06-23 22:40:23.620913
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-23 22:40:24.585587
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:28.842865
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_utils import round_trip_check
    input_ = """{1: 1, 2: 2, **{3: 3, 4: 4}, **{5: 5, 6: 6}, 7: 7}"""
    round_trip_check(input_, DictUnpackingTransformer)



# Generated at 2022-06-23 22:40:39.799437
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:40:48.387458
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class TestVisitor(ast.NodeVisitor):
        def __init__(self):
            self.was_called = False

        def visit_Dict(self, node: ast.Dict) -> None:
            self.was_called = True

    code = """{1: 1, **{'a': 'a'}, 2: 2}"""
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)

    visitor = TestVisitor()
    visitor.visit(tree)
    assert visitor.was_called

# Generated at 2022-06-23 22:40:49.061212
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert True

# Generated at 2022-06-23 22:40:52.140768
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_code = """
{1: 1, **dict_a}
"""
    module = ast.parse(dedent(module_code))
    DictUnpackingTransformer().visit(module)


# Generated at 2022-06-23 22:40:59.672378
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    pairs = [(ast.Num(1), ast.Num(2))] * 3 + [None] * 2 + [(ast.Num(1), ast.Num(2))] * 3
    splitted = transformer._split_by_None(pairs)
    assert len(splitted) == 4
    assert len(splitted[0]) == 3
    assert isinstance(splitted[1], ast.expr)
    assert len(splitted[2]) == 3
    assert isinstance(splitted[3], list)
    assert splitted[3] == []
    prepared = transformer._prepare_splitted(splitted)
    for group in prepared:
        assert isinstance(group, (ast.Call, ast.Dict))
    merge = transformer._merge_dicts(prepared)

# Generated at 2022-06-23 22:41:09.933690
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:41:11.464954
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer is DictUnpackingTransformer

# Generated at 2022-06-23 22:41:19.598647
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from astunparse import unparse as unpars
    from ..utils import dump_ast_to_str
    from ..utils import tests as uttests
    from ..utils.ast import compile_ast

    for ast_str in uttests.load_tests(__name__, 'visit_Dict'):
        tree = compile_ast(ast_str)
        transformer = DictUnpackingTransformer()
        tree = transformer.visit(tree)
        assert tree is not None
        assert isinstance(tree, ast.Module), dump_ast_to_str(tree)
        result = unpars(tree).replace('\r', '')
        assert result.strip() == ast_str.strip()

# Generated at 2022-06-23 22:41:29.538275
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    
    def assert_equal(code: str) -> None:
        tree = ast.parse(code)
        DictUnpackingTransformer().visit(tree)
        assert code == ast.unparse(tree)
    
    assert_equal('{1: 1}')
    assert_equal('{1: 1, **a}')
    assert_equal('{1: 1, 2: 2, 3: 3, **a, **b}')
    assert_equal('{1: 1, **a, 2: 2, **b, 3: 3}')
    assert_equal('{1: 1, 2: 2, 3: 3, 4: 4}')
    assert_equal('{1: 1, 2: 2, 3: 3, 4: 4, **dict_a}')
    
    

# Generated at 2022-06-23 22:41:38.458240
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer._split_by_None([(None, None)]) == [None]
    assert transformer._split_by_None(
        [(None, None), (1, 2), (None, None), (3, 4), (None, None)]) == [
            None, [(1, 2)], None, [(3, 4)], None]
    module = ast.parse('{1: 1, 2: 2, 3: 3, 4: 4}')
    assert transformer.visit(module).body[0] == ast.Dict(keys=[1, 2, 3, 4],
                                                        values=[1, 2, 3, 4])
    module = ast.parse('{1: 1, **{2: 2}}')

# Generated at 2022-06-23 22:41:46.798974
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import pytest
    from ..utils.test_utils import assert_ast_err

    DUT = DictUnpackingTransformer
    d = ast.Dict(keys=[None, ast.Num(1), None, ast.Str('2'), None],
                values=[ast.Str('3'), ast.Str('4'), ast.Str('5'),
                        ast.List(elts=[ast.Num(6), ast.Num(7)]),
                        ast.Dict(keys=[ast.Num(8), ast.Num(9)],
                                 values=[ast.Str('10'), ast.Str('11')])])

# Generated at 2022-06-23 22:41:56.355856
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_node = ast.parse("{1:1, **dict_a}")
    DictUnpackingTransformer().visit(module_node)

# Generated at 2022-06-23 22:41:56.897440
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-23 22:41:58.254551
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

if __name__ == '__main__':
    import doctest
    print(doctest.testmod())

# Generated at 2022-06-23 22:41:59.703082
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer is not None

# Generated at 2022-06-23 22:42:06.706870
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    local_dicts = [
        {'value': 1},
        {'value': 2},
        {'value': 3},
        {'value': 4},
    ]
    splitted1 = [
        [('value', 1), ('value', 1)],
        local_dicts[0],
        [('value', 1), ('value', 1), ('value', 1)],
        local_dicts[1],
        [('value', 1), ('value', 1), ('value', 1)],
        local_dicts[2],
        [('value', 1), ('value', 1), ('value', 1)],
        local_dicts[3],
        [('value', 1), ('value', 1), ('value', 1)],
        [('value', 1), ('value', 1), ('value', 1)],
    ]
   

# Generated at 2022-06-23 22:42:14.308861
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor, typed_astunparse
    tree = """
    {1: 1, 2: "a", 3.14: False, **dict_a, None: None, (1, 2, 3): [4, 5, 6], **dict_b}
    """.strip()
    
    expected = """
    _py_backwards_merge_dicts(
        [
            {1: 1, 2: "a", 3.14: False},
            dict(None=None, (1, 2, 3)=[4, 5, 6]),
        ],
        dict_a,
        dict_b,
    )
    """.strip()
    
    tree = ast.parse(tree)
    expected = ast.parse(expected)
    result = DictUnpackingTransformer().visit(tree)
    assert typed_ast

# Generated at 2022-06-23 22:42:20.345056
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast
    import astor
    from typing import Any

    from .types import Snippet

    snippet = Snippet(DictUnpackingTransformer, # type: ignore
                      source='''
                          {1: 1, **dict_a}
                      '''
                      )

    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''

    assert astor.to_source(snippet.tree) == expected


# Generated at 2022-06-23 22:42:21.602958
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer is not None


# Generated at 2022-06-23 22:42:25.568018
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .base import process_snippet
    from ..utils.code_gen import code_gen
    from ..utils.method import get_method_by_name_and_type

    code = """
        {1: 1, **dict_a}
    """
    assert DictUnpackingTransformer.target == (3, 4)
    module = process_snippet(code, DictUnpackingTransformer)
    lines = code_gen(module)

# Generated at 2022-06-23 22:42:36.433713
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()

    pairs = [
        (None, ast.Num(n=1)),
        (ast.Num(n=2), ast.Num(n=3)),
        (None, ast.Num(n=5))
    ]
    splitted = transformer._split_by_None(pairs)
    assert splitted == [
        [(ast.Num(n=2), ast.Num(n=3))],
        ast.Num(n=1),
        [],
        ast.Num(n=5),
        []
    ]

    prepared = transformer._prepare_splitted(splitted)

# Generated at 2022-06-23 22:42:46.377473
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import parse, compare_samples
    from .node_utils import NodeCollector

    # Samples for unittesting

# Generated at 2022-06-23 22:42:57.489455
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    src = """
    a = {1:1, **{}, **{}}
    b = {1:1, **{}, **{}, 2:2}
    c = {1:1, **{}, 2:2, **{}, **{}}
    d = {1:1, **{}, 2:2, **{}, 3:3, **{}}
    """

# Generated at 2022-06-23 22:43:01.962355
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("""\
        {1: 1, **dict_a}
    """)
    module_expected = ast.parse("""\
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)
    DictUnpackingTransformer(module).visit(module)
    assert module == module_expected



# Generated at 2022-06-23 22:43:10.045079
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import sema_eval
    input = '''{1: 1, **{2: 2}}'''
    expected = '''def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result


_py_backwards_merge_dicts([{1: 1}], {2: 2})
'''
    x = DictUnpackingTransformer()
    output = x.visit(sema_eval(input))
    assert sema_eval(expected) == output


# Generated at 2022-06-23 22:43:11.310672
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): # type: () -> None
    assert hasattr(DictUnpackingTransformer, 'transform')

# Generated at 2022-06-23 22:43:14.139988
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('{1: 1, **dict_a}')
    DictUnpackingTransformer().visit(tree)
    assert "def _py_backwards_merge_dicts" in ast.dump(tree)

# Generated at 2022-06-23 22:43:18.251524
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("{None: 1, 2: None}")
    d = DictUnpackingTransformer()
    d.visit(module)
    assert ast.dump(module) == "import ast\n_py_backwards_merge_dicts([dict(None, 1)], {2: None})"



# Generated at 2022-06-23 22:43:24.859141
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import ast
    fr = ast.parse('''{**{}, **{1: 1, **{2:2}, 3: 3, **{4: 4}}}''')
    ar = ast.parse('''_py_backwards_merge_dicts(
[dict()], dict(1=1, **dict(2=2), **_py_backwards_merge_dicts(
[dict()], dict(3=3, **dict(4=4)))))''')
    DictUnpackingTransformer().visit(fr)
    assert ast.dump(fr) == ast.dump(ar)
test_DictUnpackingTransformer()

# Generated at 2022-06-23 22:43:26.514268
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass


# Generated at 2022-06-23 22:43:33.410977
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_code_equal
    from . import standard_transformer

    assert_code_equal(
        DictUnpackingTransformer(standard_transformer()).visit(
            ast.parse('''
            {1: 2, **{3: 4, 5: 6}}
            ''')),
        ast.parse('''
        _py_backwards_merge_dicts([{1: 2}], {3: 4, 5: 6})
        '''))



# Generated at 2022-06-23 22:43:36.754788
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.transformer import assert_transform
    dut = DictUnpackingTransformer()

# Generated at 2022-06-23 22:43:44.974679
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast.ast3 import parse
    import sys
    import ast as pyast
    
    DUT = DictUnpackingTransformer()
    code = "a = 1\n"
    expected_code = "def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\na = 1\n"
    expected_ast = parse(expected_code)
    expected_ast.body[0].lineno = 1
    expected_ast.body[0].col_offset = 0
    expected_ast.body[1].lineno = 6
    expected_ast.body[1].col_offset = 0
    assert (expected_ast == DUT.visit(parse(code)))


# Generated at 2022-06-23 22:43:46.998369
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():  # noqa: D103
    tr = DictUnpackingTransformer()
    assert tr


# Generated at 2022-06-23 22:43:54.447955
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..transpile import transpile

    assert transpile('{1: 1, **dict_a}', target_versions={(3, 8): (3, 7)}) == \
           '_py_backwards_merge_dicts([{1: 1}], dict_a)\n'

    assert transpile('{1: 1, **dict_a, 2: 2}', target_versions={(3, 8): (3, 7)}) == \
           '_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a)\n'

# Generated at 2022-06-23 22:44:04.383863
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """
x = {1: 1, 2: 2, 3: 3, **dict_a, 4: 4}
b = {}
d = {1: 1, **b}
"""
    tree = ast.parse(code)
    expected = """
_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}, dict_a, {4: 4}])
b = {}
_py_backwards_merge_dicts([{1: 1}, b])
"""
    expected_tree = ast.parse(expected)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    assert_equal(ast.dump(result), ast.dump(expected_tree))

# Generated at 2022-06-23 22:44:12.869342
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    import pytest
    from typed_astunparse import unparse
    from .test_grammar import assert_equal

    code = '''
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    '''
    tree = ast.parse(code)
    DictUnpackingTransformer(verbose=True).visit(tree)
    expected = unparse('''{}
    __builtins__.dict({1:1, 2:2}).update(dict_a).update(
        {3:3}).update(dict_b).update({4:4})
    ''')
    assert_equal(unparse(tree), expected)



# Generated at 2022-06-23 22:44:13.900570
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:15.424668
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import _NodeTransformerTester
    _NodeTransformerTester(DictUnpackingTransformer)

# Generated at 2022-06-23 22:44:19.509040
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Unit test for `DictUnpackingTransformer.visit_Module`"""
    module = ast.parse("""
        {}
    """)
    assert not DictUnpackingTransformer().visit(module).body  # type: ignore
    assert len(module.body) == 2



# Generated at 2022-06-23 22:44:24.293187
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as oldast
    node = oldast.parse("{1: 1, **dict_a}")
    DictUnpackingTransformer().visit(node)
    assert oldast.dump(node) == '_py_backwards_merge_dicts([{1: 1}], dict_a)\n'

# Generated at 2022-06-23 22:44:26.485721
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert hasattr(DictUnpackingTransformer, 'visit_Dict')


# Generated at 2022-06-23 22:44:30.375480
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("""
    def foo():
        {1: 1, **{'a': 2}}
    """)
    module = ast.fix_missing_locations(module)
    mod = DictUnpackingTransformer().visit(module)
    assert mod is not None

# Generated at 2022-06-23 22:44:34.567323
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from astmonkey import transformers
    from .dict_unpacking import DictUnpackingTransformer

    class Test(ast.AST):
        body = [
            ast.Expr(value=ast.Dict(keys=[None], values=[ast.Name(id='dict_a')])),
        ]


# Generated at 2022-06-23 22:44:37.485171
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert not merge_dicts.is_pasted()
    DictUnpackingTransformer().visit(ast.parse(''))
    assert merge_dicts.is_pasted()



# Generated at 2022-06-23 22:44:44.620486
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse("""
    a = {1: 2, **a, 3: 4}""")  # type: ast.Module
    result = DictUnpackingTransformer().visit(node)
    expected = ast.parse("""
    _py_backwards_merge_dicts([{1: 2},{3: 4}], a)
    a = _py_backwards_merge_dicts([{1: 2},{3: 4}], a)
""")  # type: ast.Module
    assert ast.dump(expected) == ast.dump(result)

# Generated at 2022-06-23 22:44:49.346781
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Setup
    tree = ast.parse("""\
{1: 1}
x = 1
""")

    # Exercise
    node = DictUnpackingTransformer.run(tree)

    # Verify
    lines = [line.strip() for line in node.body[2].body]
    expected_lines = [
        '_py_backwards_merge_dicts([{1: 1}], dict_a)',
        'x = 1',
    ]
    assert lines == expected_lines



# Generated at 2022-06-23 22:44:51.475038
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    import astor
    s = astor.dump_tree(merge_dicts.get_body())

# Generated at 2022-06-23 22:44:53.235087
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer

# Generated at 2022-06-23 22:44:54.195721
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()  # Does not raise

# Generated at 2022-06-23 22:44:55.480463
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()  # Just for pytest test coverage

# Generated at 2022-06-23 22:45:06.313192
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.pyimports import get_import_context
    from ..utils.snippet import print_ast
    from ..utils.pyimports import get_import_context
    from ..utils.config import Config

    config = Config()
    import_context = get_import_context(config)
    transformer = DictUnpackingTransformer(import_context)


# Generated at 2022-06-23 22:45:15.998932
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3

    target1 = ast3.parse('{1: 1, **dict_a, **dict_b, **dict_c, 2: 2}')
    from .type_annotations import TypeAnnotatedTransformer
    transformed1 = DictUnpackingTransformer(TypeAnnotatedTransformer).visit(
        target1)
    expected1 = ast3.parse(
        """_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b, dict_c)""")
    assert ast3.dump(expected1) == ast3.dump(transformed1)

    # Test case with no unpacking statements
    target2 = ast3.parse('{1: 1, 2: 2}')
    transformed2 = DictUnpackingTransformer().visit

# Generated at 2022-06-23 22:45:17.833835
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(None), DictUnpackingTransformer)

# Generated at 2022-06-23 22:45:22.969571
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Test function to check visit_Module of class DictUnpackingTransformer
    program_in = """
{
    1: 1, 
    2: 2, 
    **{
        i: i
        for i in range(10)
    },
    3: 3
}
"""

# Generated at 2022-06-23 22:45:32.278081
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest

    from typed_ast import ast3, ast27

    class TestDictUnpackingTransformer(unittest.TestCase):
        def test_normal(self):
            code = '{1: 2, 3: 4}'
            ast_tree = ast27.parse(code, mode='eval')
            node = DictUnpackingTransformer().visit(ast_tree)
            self.assertEqual(node.keys, [ast3.Num(1), ast3.Num(3)])
            self.assertEqual(node.values, [ast3.Num(2), ast3.Num(4)])

        def test_unpacking(self):
            code = '{1: 2, **dict_a}'
            ast_tree = ast27.parse(code, mode='eval')
            node = Dict

# Generated at 2022-06-23 22:45:41.815623
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ...tests import test_utils
    from ...tests.test_utils import to_source
    from ...tests.test_utils import extract_node
    from ...tests.test_utils import assert_source_equal

    code = """
    {1: 2, **{3 : 4}, **{3 : 5}, 6:7, **{8:9, 10: 11}}
    """

    root = test_utils.build_ast(code)

    extract_node(root)

    node = root.body[0].value

    trans = DictUnpackingTransformer()
    new_node = trans.visit(node)
    assert trans._tree_changed


# Generated at 2022-06-23 22:45:48.611288
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("{\"foo\": \"bar\", **baz}")
    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-23 22:45:49.435262
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:45:50.977679
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    unpacking = DictUnpackingTransformer()
    assert isinstance(unpacking, BaseNodeTransformer)

# Generated at 2022-06-23 22:46:02.014802
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.Dict(keys=[ast.Constant(1), None, ast.Constant('a')],
                    values=[ast.Constant(2), ast.Constant({1: 2}), ast.Constant('b')])
    expected = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[ast.List(elts=[ast.Dict(keys=[ast.Constant(1)], values=[ast.Constant(2)]),
                             ast.Call(func=ast.Name(id='dict'),
                                      args=[ast.Constant({1: 2})],
                                      keywords=[]),
                             ast.Dict(keys=[ast.Constant('a')], values=[ast.Constant('b')])])],
        keywords=[])
    transformed

# Generated at 2022-06-23 22:46:03.560310
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """Asserts that constructor of class DictUnpackingTransformer raises no
    errors.
    
    """
    DictUnpackingTransformer()



# Generated at 2022-06-23 22:46:11.137804
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = '{1: 2, **a, 1: 3}'
    expected = '_py_backwards_merge_dicts([{1: 2}, {1: 3}], a)'
    assert compile_snippet(code, DictUnpackingTransformer) == expected
    code = '{1: 2, **{1: 7}, 1: 3}'
    expected = '_py_backwards_merge_dicts([{1: 2}, {1: 7}, {1: 3}])'
    assert compile_snippet(code, DictUnpackingTransformer) == expected

# Generated at 2022-06-23 22:46:12.518201
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass


# Integration test for DictUnpackingTransformer

# Generated at 2022-06-23 22:46:21.020228
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Setup
    expected = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[
            ast.List(
                elts=[
                    ast.Dict(
                        keys=[ast.Constant(value=1)],
                        values=[ast.Constant(value=1)]),
                    ast.Dict(
                        keys=[ast.Constant(value=2)],
                        values=[ast.Constant(value=2)])])],
        keywords=[])


# Generated at 2022-06-23 22:46:21.669454
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:46:27.245934
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    obj = DictUnpackingTransformer()
    assert obj.name() == 'DictUnpackingTransformer'
    assert obj.target == (3, 4)
    assert obj._tree_changed == False
    assert obj.generic_visit(1) == 1
    assert obj.generic_visit_Module(1) == 1
    assert obj.generic_visit_Dict(1) == 1

# Generated at 2022-06-23 22:46:36.278891
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:46:43.351435
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    p = ast.parse('a = {2: 3, **x}')
    actual = DictUnpackingTransformer().visit(p)
    expected = ast.parse('_py_backwards_merge_dicts = _py_backwards_merge_dicts\na = _py_backwards_merge_dicts([{2: 3}], x)')
    assert ast.unparse(actual) == ast.unparse(expected)


# Generated at 2022-06-23 22:46:52.659813
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..dump import dump
    from textwrap import dedent
    source = dedent("""
        a = {}
        b = {1: 1, **a}
    """)

    expected = dedent("""
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
    
    
        a = {}
        b = _py_backwards_merge_dicts([{1: 1}], a)
    """)

    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == expected

# Generated at 2022-06-23 22:47:02.246412
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    pairs = [(None, ast.Num(n=1)), (ast.Str(s='a'), ast.Num(n=2))]
    splitted = transformer._split_by_None(pairs)
    assert splitted == [[], ast.Num(n=1), [(ast.Str(s='a'), ast.Num(n=2))]]

    prepared = transformer._prepare_splitted(splitted)
    assert ast.dump(ast.List(elts=list(prepared))) == '[Dict(keys=[], values=[]), Num(n=1), Dict(keys=[Str(s="a")], values=[Num(n=2)])]'

    merged = transformer._merge_dicts(prepared)

# Generated at 2022-06-23 22:47:13.686396
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast as _ast


# Generated at 2022-06-23 22:47:19.897395
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    program = """a = {1: 2, 3: 4, **c}"""

    expected = """def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result

a = _py_backwards_merge_dicts([{1: 2, 3: 4}], c)"""

    actual, _ = DictUnpackingTransformer().transform(program)
    assert actual == expected

# Generated at 2022-06-23 22:47:28.218704
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from libcst.testing.utils import UnitTest

    class Test(UnitTest):
        TRANSFORMER_CLASS = DictUnpackingTransformer
        PARSE_METHOD = 'parse_ast3'

        @property
        def _tree_changed(self) -> bool:
            return self.transformer._tree_changed

        def _get_transformed_tree(self) -> ast.AST:
            return self.transformer.visit(self.input_ast)

        def test_no_change(self):
            module = """
            a = 1
            b = 2
            """
            tree = self.get_ast(module)
            transformed = self._get_transformed_tree()
            self.assertEqual(ast.dump(tree), ast.dump(transformed))
            self

# Generated at 2022-06-23 22:47:32.384839
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """{42: 10, 1: 2, 3: 4, **{42: 11, 43: 12, 44: None}, **{45: 13}}"""
    expected = """{43: 12, 44: None, 42: 11, 1: 2, 3: 4, 45: 13}"""

    module = ast.parse(source)
    transformer = DictUnpackingTransformer()
    module = transformer.visit(module)  # type: ignore
    assert expected == ast_to_source(module.body[-1])