

# Generated at 2022-06-23 22:37:39.757840
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast.ast3 as ast
    t = DictUnpackingTransformer()
    dict_ = ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=2), ast.Num(n=3)],
                     values=[ast.Num(n=1), ast.Name(id='a'),
                             ast.Name(id='b'), ast.Name(id='c')])
    result = t.visit(dict_)
    merge = '_py_backwards_merge_dicts([{1: 1, 2: b, 3: c}], a)'
    assert merge.replace(' ', '') == ast.unparse(result).replace(' ', '')

# Generated at 2022-06-23 22:37:41.240112
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    DictUnpackingTransformer().visit(ast.parse('{1: 1}'))



# Generated at 2022-06-23 22:37:49.806325
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astunparse
    import textwrap
    module_text = textwrap.dedent("""
    def f(x):
        return {1: 1, **x}
    
    def g():
        return {1: 1, **x}
    """)
    module_expected_text = textwrap.dedent("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    
    
    def f(x):
        return _py_backwards_merge_dicts([{1: 1}], x)
    
    def g():
        return _py_backwards_merge_dicts([{1: 1}], x)
    """)

# Generated at 2022-06-23 22:37:57.112601
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    code = """\
        a = {'a': 1, **{'b': 2}}
        """

    expected = """\
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        a = _py_backwards_merge_dicts([{'a': 1}], {'b': 2})
        """

    expected_tree = ast.parse(expected)
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)  
    assert ast_equal(expected_tree, tree)



# Generated at 2022-06-23 22:38:05.251047
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Arrange
    transformer = DictUnpackingTransformer()

    # Act
    actual = transformer.visit(ast.parse("a + 2"))  # type: ignore

    # Assert
    assert actual.body[0].body[0].value.args[0].elts[0].keys[0].n == 1, \
        "Keys in dict are not correct"
    assert actual.body[0].body[0].value.args[0].elts[0].values[0].n == 1, \
        "Values in dict are not correct"


# Generated at 2022-06-23 22:38:10.704210
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    module = test_utils.build_module(source)
    actual = module.ast()

    expected_module = test_utils.build_module(expected)
    expected_ast = expected_module.body[-1]

    assert actual == expected_ast


# Generated at 2022-06-23 22:38:11.505181
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:38:21.799496
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .inject_locations import InjectLocationsTransformer

    class DummyNode(ast.AST):
        _fields = () # type: ignore

    tree = ast.Module([
        DummyNode(),
        ast.Dict(
            keys=[None, None],
            values=[
                ast.Dict(keys=[ast.Constant(value=1)],
                         values=[ast.Constant(value=1)]),
                ast.Dict(keys=[ast.Constant(value=2)],
                         values=[ast.Constant(value=2)]),
                ast.Constant(value=None),
            ]),
        DummyNode(),
    ])

    tree = InjectLocationsTransformer().visit(tree)
    result = DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 22:38:30.772374
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import literal_eval
    from ..utils.test_utils import AssertNoException
    
    tree = literal_eval("""\
    def f():
        return {1: 1, **dict_a}
    """)
    compiled = literal_eval("""\
    def f():
        return _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)
    with AssertNoException():
        DictUnpackingTransformer.run_on(tree)
    assert tree == compiled


# Generated at 2022-06-23 22:38:35.736291
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    source = """\
x = {1: 1, **dict_a}
"""

    expected = """\
_py_backwards_merge_dicts([{1: 1}], dict_a)
"""

    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert str(tree) == expected

# Generated at 2022-06-23 22:38:37.825917
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = '''{1: 1, **dict_a}'''

# Generated at 2022-06-23 22:38:38.380547
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass

# Generated at 2022-06-23 22:38:40.442947
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Method visit_Module of class DictUnpackingTransformer"""

# Generated at 2022-06-23 22:38:48.657991
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse
    import asttyped
    code = """
    def foo(dict_a):
        return {1: 1, **dict_a}
    """
    expected_code = """
    def foo(dict_a):
        return _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse(code)
    transformer = asttyped.compat.DictUnpackingTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(tree) == expected_code

# Generated at 2022-06-23 22:38:49.641316
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:38:57.579537
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    try:
        import magic  # noqa
    except ImportError:
        return None

    source = r"""
    {'key': 'value', **dict_a, **dict_b, **dict_c}
    """
    expected = """
    _py_backwards_merge_dicts([{'key': 'value'}, dict_a, dict_b, dict_c])
    """
    node = ast.parse(source)
    node = DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == expected

# Generated at 2022-06-23 22:39:08.494181
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .. import compile_isolated
    from .test_setup import assert_equal

# Generated at 2022-06-23 22:39:10.989454
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): #pylint: disable=invalid-name
    assert DictUnpackingTransformer.__name__ == 'DictUnpackingTransformer'
    assert DictUnpackingTransformer.__qualname__ == 'DictUnpackingTransformer'

# Generated at 2022-06-23 22:39:21.820890
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    t = DictUnpackingTransformer()
    module = ast.parse(
        "a = {'a': 1}\n"
        "b = {'b': 'b'}\n"
        "c = {'c': 'c'}\n"
        "d = {**a, **b, **c, 'd': 1}\n"
    )

    expected = ast.parse(
        "_py_backwards_merge_dicts = (lambda dicts: {**dicts[0], **dicts[1]})\n"
        "d = _py_backwards_merge_dicts([a, b, c, {'d': 1}])\n"
    )

    transformed = t.visit(module)

    assert ast.dump(expected, annotate_fields=False) \
        == ast.dump

# Generated at 2022-06-23 22:39:25.179867
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    import astor

    code = """{1: 1, 2: 2, None: {}, 4: 4}"""
    expected_code = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], {4: 4})
    """

    module = ast.parse(code)
    DictUnpackingTransformer().visit(module)
    assert astor.to_source(module) == expected_code



# Generated at 2022-06-23 22:39:35.929369
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Normal case
    x = ast.Dict(keys=None, values=None)
    node = DictUnpackingTransformer().visit(x)
    assert node == x
    assert node is not x

    # Nones
    x = ast.Dict(
        keys=[None, ast.Name(id='a'), None, ast.Name(id='b')],
        values=[
            ast.Dict(keys=[ast.Name(id='c')], values=[ast.Name(id='d')]),
            ast.Dict(keys=[ast.Name(id='e')], values=[ast.Name(id='f')]),
            ast.Name(id='g'),
        ]
    )
    node = DictUnpackingTransformer().visit(x)

# Generated at 2022-06-23 22:39:37.589521
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    program = """
    {'a': 1, **{'b': 2}}
    """

# Generated at 2022-06-23 22:39:45.137087
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.example import DictUnpackingExample
    from ..utils.tree import get_ast

    source = '\n'.join([
        'from typing import Dict',
        'from random import random',
        '',
        'def f(x: Dict[str, float], y: float):',
        '    return {1: 1, **x}',
        '',
    ])


# Generated at 2022-06-23 22:39:54.007620
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    ast_node = ast.Module([
        ast.Assign(
            targets=[
                ast.Name(id='x', ctx=ast.Store())
            ],
            value=ast.Dict(
                keys=[
                    ast.Name(id='a', ctx=ast.Load()),
                    ast.Name(id='b', ctx=ast.Load())
                ],
                values=[
                    ast.Name(id='c', ctx=ast.Load()),
                    ast.Name(id='d', ctx=ast.Load())
                ]
            )
        )
    ])


# Generated at 2022-06-23 22:40:00.501766
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .test_transformer import assert_transform
    # Empty dicts
    assert_transform(DictUnpackingTransformer, '{}')
    # Empty dict unpacking
    assert_transform(DictUnpackingTransformer, '{1: 1, **{}}')
    # No dict unpacking
    assert_transform(DictUnpackingTransformer, '{1: 1}')
    # Single dict unpacking
    assert_transform(DictUnpackingTransformer, '{**{2: 2}}',
                     '_py_backwards_merge_dicts([{}], {2: 2})')
    # Single dict unpacking 2

# Generated at 2022-06-23 22:40:11.073886
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .. import compile_restricted
    from ..compiler import RestrictingNodeTransformer
    from ..utils.source import source

    # The following class is to inherit from RestrictingNodeTransformer
    # and we can test visit_Module() method in DictUnpackingTransformer.
    # This is because we could not multiple-inherit from two
    # RestrictingNodeTransformer.
    class DictUnpackingTransformerWithRestrictions(
            DictUnpackingTransformer, RestrictingNodeTransformer):
        pass

    src = """
        {1: 1, 3: 3, 4: 4}
        {1: 1, **{2: 2}, 3: 3}
        {1: 1, {2: 2}, 3: 3}
    """

# Generated at 2022-06-23 22:40:12.944750
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = '''
{1: 1, **dict_a}
print('Hello, World!')
'''
    ast_ = ast.parse(source)
    DictUnpackingTransformer().visit(ast_)

# Generated at 2022-06-23 22:40:16.721602
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    program = ast.parse("""
{1: 1, **dict_a}
""")
    DictUnpackingTransformer().visit(program)
    assert program == ast.parse("""
_py_backwards_merge_dicts([{1: 1}], dict_a})
""")


# Generated at 2022-06-23 22:40:17.631939
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-23 22:40:25.157990
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test import run_test_on_input

    def run(code: str) -> str:
        return run_test_on_input(code, DictUnpackingTransformer.visit_Dict)

    def check(input_, output):
        assert run(input_) == output

    # Check that transformer doesn't touch dictionary literal not containing
    # unpacking
    check("{1: 1}", "{1: 1}")

    # Check that transformer correctly splits dictionary literal containing
    # unpacking
    check("{1: 1, **dict_a, **dict_b}",  # type: ignore
          "_py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)")

# Generated at 2022-06-23 22:40:36.059066
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..unparse.unparser import Unparser
    from .helper import assert_transform

    Unparser.opts.indent_tabs = False
    Unparser.opts.tabsize = 4
    Unparser.opts.wrap_tokens = {Unparser.opts.wrap_tokens.DICT_INIT}

    assert_transform(
        DictUnpackingTransformer,
        """
        {**{'a': 'b'}}
        """,
        b"""
        _py_backwards_merge_dicts([{}], {'a': 'b'})
        """,
        """
        {**{'a': 'b'}}
        """
    )


# Generated at 2022-06-23 22:40:37.141732
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from doctest import testmod
    testmod()

# Generated at 2022-06-23 22:40:38.984975
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)


# Generated at 2022-06-23 22:40:43.041600
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = """{1: 1, 'a': 2, **dict1}"""
    y = """_py_backwards_merge_dicts([{1: 1, 'a': 2}], dict1)"""
    assert DictUnpackingTransformer().transform(x) == y


# Generated at 2022-06-23 22:40:44.619569
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    instance = DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:51.617632
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
        {1: 1}
        """
    expected_code = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        {1: 1}
        """
    module = ast.parse(code)
    DictUnpackingTransformer().visit(module)
    assert ast.dump(module) == ast.dump(ast.parse(expected_code))



# Generated at 2022-06-23 22:40:55.619781
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    to_test = [
        (dict(), dict()),
        ({1: 1}, {1: 1}),
        # {1: 1, **{2: 2}},
    ]
    for node, expected in to_test:
        result = DictUnpackingTransformer().visit_Dict(node)  # type: ignore
        assert result == expected

# Generated at 2022-06-23 22:40:59.727099
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    ast_ = ast.parse("{*{'a': 'b'}, **{'c': 'd'}}")
    node = DictUnpackingTransformer().visit(ast_)
    assert node == ast.parse("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{'a': 'b'}, {'c': 'd'}])
    """)

# Generated at 2022-06-23 22:41:01.582718
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert isinstance(DictUnpackingTransformer.visit_Module, Callable)


# Generated at 2022-06-23 22:41:07.889342
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # pylint: disable=unused-variable
    from ..utils.testing import XTransformerTestCase
    from ..utils.tree import tree_to_str

    class DictUnpackingTransformerTestCase(XTransformerTestCase):
        transformer = DictUnpackingTransformer

        def test_basic(self):
            self.assertTreeEqual(
                '{1: 1, **dict_a}',
                '_py_backwards_merge_dicts(dict(1=1), dict_a)')

        def test_multiple(self):
            self.assertTreeEqual(
                '{1: 1, **dict_a, 2: 2, **dict_b}',
                '_py_backwards_merge_dicts(dict(1=1, 2=2), dict_a, dict_b)')

# Generated at 2022-06-23 22:41:09.932900
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert isinstance(t, BaseNodeTransformer)



# Generated at 2022-06-23 22:41:11.060547
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:20.541136
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from typed_ast.ast3 import Module
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformerTestCase

    source = """\
x = 1
y = {1: 2}
z = y
    """

# Generated at 2022-06-23 22:41:24.364850
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_transformer import assert_equal

    tree = ast.parse('''\
{1: 1, **{2: 2}}
''')


# Generated at 2022-06-23 22:41:25.336046
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:26.856714
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:41:30.443381
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from py2py3.utils.testing import test_string
    source = """
    {**a, 1: 2, 3: 4, **b}
    """
    # The result should match with this
    result = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 2, 3: 4}], a, b)
    """
    assert test_string(source, DictUnpackingTransformer) == result

# Generated at 2022-06-23 22:41:31.250436
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), BaseNodeTransformer)


# Generated at 2022-06-23 22:41:39.054941
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    import ast
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        transformer = DictUnpackingTransformer
        method = 'visit_Dict'

        def _test(self, node: ast.Dict, expected: str):
            result = self.transform(node)
            self.assertEqual(astunparse.unparse(result), expected)

    test = Test()
    test._test(
        ast.Dict(keys=[None, ast.Str(s='key')],
                 values=[ast.Dict(keys=[], values=[]), ast.Name(id='value')]),
        '_py_backwards_merge_dicts([{}, value])')

# Generated at 2022-06-23 22:41:46.099049
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import inspect
    import textwrap
    import astor
    code = inspect.cleandoc(textwrap.dedent(r'''
    {1: 1, 2: 2, **a, 3: 3, **b}
    '''))
    expected_code = inspect.cleandoc(textwrap.dedent(r'''
    _py_backwards_merge_dicts([{1: 1, 2: 2}, a, {3: 3}], b)
    '''))
    node = ast.parse(code)
    DictUnpackingTransformer().visit(node)
    assert astor.to_source(node) == expected_code

# Generated at 2022-06-23 22:41:51.248161
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast

    tree = ast.Module(body=[])
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)

    assert isinstance(result.body[0], ast.FunctionDef)
    assert result.body[-1] == merge_dicts.get_body()[-1]


# Generated at 2022-06-23 22:41:59.948564
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..main import compile
    from .TestCase import TestCase

    module = compile("""{1: 1, 2: 2, **dict_a, **dict_b}""")

# Generated at 2022-06-23 22:42:06.831618
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    class Opts(object):
        def __init__(self, tree_changed=False):
            self.tree_changed = tree_changed

    opts = Opts()

    class Visitor(ast.NodeVisitor):
        def visit(self, node: ast.Node) -> None:
            if isinstance(node, ast.Call):
                return
            return super(Visitor, self).visit(node)

        def visit_Dict(self, node: ast.Dict) -> None:
            opts.tree_changed = True
            for key, value in zip(node.keys, node.values):
                if key is None:
                    return
            return super(Visitor, self).visit(node)

    tree = ast.parse('{1: 2, 3: 4}')

# Generated at 2022-06-23 22:42:14.396732
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import (
        assert_equal_code,
        assert_equal_ast,
        tree_from_code
    )

    code = """\
    def foo(x, y, z):
        if x:
            return {1: 1}
        elif y:
            return {2: 2}
        else:
            return {3: 3}
    """


# Generated at 2022-06-23 22:42:20.861703
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = """
        {**dict_a, **{}, **{1: 1, 2: 2}, 3: 3, **dict_b}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
              result.update(dict_)
            return result
        _py_backwards_merge_dicts([{3: 3}, dict_b, {1: 1, 2: 2}, dict_a])
    """
    node = ast.parse(module)
    DictUnpackingTransformer().visit(node)  # type: ignore
    assert ast.dump(node) == expected

# Generated at 2022-06-23 22:42:22.760621
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    assert repr(x) == '<DictUnpackingTransformer>'



# Generated at 2022-06-23 22:42:26.544274
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tester import assert_code_equal
    from .unpacking_transformer import UnpackingTransformer

    source = """
        {1: 1, 2: 2, 3: 3, **a, 4: 4, **b, **c}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], a, b, c)
    """
    assert_code_equal(expected, source, transformers=[UnpackingTransformer,
                      DictUnpackingTransformer])

# Generated at 2022-06-23 22:42:37.686507
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a = DictUnpackingTransformer()
    t1 = []
    t2 = [('a', 'b')]
    t3 = [('c', 'd'), ('g', 'h')]
    # print(a._split_by_None(t1))
    # print(a._split_by_None(t2))
    # print(a._split_by_None(t3))
    if True:
        assert a._split_by_None(t1) == [[]]      # type: ignore
        assert a._split_by_None(t2) == [[('a', 'b')]]  # type: ignore
        assert a._split_by_None(t3) == [[('c', 'd'), ('g', 'h')]]  # type: ignore

# Generated at 2022-06-23 22:42:42.799699
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .. import transform
    from ..utils.codegen import to_source

    transpiled = transform(
        DictUnpackingTransformer,
        "print(1)")
    assert transpiled == to_source(merge_dicts) + to_source(
        "print(1)").replace('\n', '')



# Generated at 2022-06-23 22:42:44.367517
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    d = DictUnpackingTransformer()
    assert isinstance(d, ast.NodeTransformer)

# Generated at 2022-06-23 22:42:51.452894
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astpretty


# Generated at 2022-06-23 22:42:53.910115
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '{1: 1, **dict_a}'

# Generated at 2022-06-23 22:42:54.968056
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer

# Generated at 2022-06-23 22:42:59.363528
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert repr(DictUnpackingTransformer()) == repr(DictUnpackingTransformer())
    transformer1 = DictUnpackingTransformer()
    transformer1._tree_changed = True
    transformer2 = DictUnpackingTransformer()
    transformer2._tree_changed = False
    assert repr(transformer1) != repr(transformer2)

# Generated at 2022-06-23 22:43:05.287664
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    class DictUnpackingTransformer_(DictUnpackingTransformer):
        def visit_BinOp(self, node):
            print(self._tree_changed)
            return self.generic_visit(node)

    module = """{1: 1, 2: 2, **dict_a, 5: 5, 6: 6}"""
    expected = """_py_backwards_merge_dicts([{1: 1, 5: 5}, dict_a])"""
    actual = ast3.parse(module)
    actual = DictUnpackingTransformer_().visit(actual)
    actual = ast3.dump(actual)
    assert actual == expected


# Generated at 2022-06-23 22:43:06.318825
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    return DictUnpackingTransformer()

# Generated at 2022-06-23 22:43:07.752433
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import generate_block


# Generated at 2022-06-23 22:43:08.734161
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    ast.parse("{x: 1, **y}")

# Generated at 2022-06-23 22:43:11.819960
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert id(transformer.visit_dummy) == id(transformer.generic_visit)
    assert transformer.target == (3, 4)
    assert not transformer._tree_changed


# Generated at 2022-06-23 22:43:18.737413
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .. import compile_restricted as crab
    src = {1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, 10: 10,
           11: 11, 12: 12, 13: 13, 14: 14, 15: 15, 16: 16, 17: 17, 18: 18,
           19: 19, 20: 20, 21: 21, 22: 22, 23: 23, 24: 24}
    code = crab.compile(src, filename='<DictUnpackingTransformer>', mode=crab.Mode.SAFE, 
                        transformation_pipeline=[DictUnpackingTransformer])
    assert '_py_backwards_merge_dicts' in code

# Generated at 2022-06-23 22:43:20.698057
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import sys
    sys.modules['_py_backwards_merge_dicts'] = None

# Generated at 2022-06-23 22:43:27.067836
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse(
        """{1: 1, 2: 2, **{3: 3}, **{4: 4, 5: 5}}
        """)
    result = DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 22:43:37.452985
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    module = parse('{1: 2}')
    result = transformer.visit(module)
    assert result == module

    module = parse('{1: 2, 3: 4, 5: 6}')
    result = transformer.visit(module)
    assert result == module

    module = parse('{1: 2, **{5: 6}}')
    result = transformer.visit(module)
    assert dump(result) == dump(parse('_py_backwards_merge_dicts([{1: 2}], {5: 6})'))

    module = parse('{1: 2, 3: 4, **{5: 6}}')
    result = transformer.visit(module)

# Generated at 2022-06-23 22:43:41.376613
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    transformer = DictUnpackingTransformer()
    result = transformer.visit(ast.parse('{1: 1, **{2: 2}}'))
    assert astor.to_source(result)

# Generated at 2022-06-23 22:43:52.090360
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    source = """
    {KEY: VALUE, None: {KEY2: VALUE2}, **DICT}
    """
    expected = """
    _py_backwards_merge_dicts([{KEY: VALUE}, {KEY2: VALUE2}], DICT)
    """
    module, = ast.parse(source).body
    node = next(module.body)
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Dict)
    assert isinstance(DictUnpackingTransformer().visit(node).value, ast.Call)
    assert astor.to_source(DictUnpackingTransformer().visit(node)).strip()\
           == expected.strip()

# Generated at 2022-06-23 22:43:53.340933
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:43:59.813622
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from ..utils.method_call_transform import MethodCallTransformer
    from ..utils.ast_helpers import dump

    module_node = parse("""
        a = {1: 1}
        """)
    DictUnpackingTransformer(MethodCallTransformer(), {}).visit(module_node)

# Generated at 2022-06-23 22:44:07.790521
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:44:11.626592
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    given = """\
{1: 1}
{**{3: 3}}
{2: 2, **{3: 3}}
{2: 2, **{3: 3}, 4: 4}
{**{5: 5}, 2: 2, **{3: 3}, 4: 4}
{**{5: 5}, **{1: 1}, 2: 2, **{3: 3}, 4: 4}
"""

# Generated at 2022-06-23 22:44:22.035228
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import create_module_from_snippet
    mod = create_module_from_snippet(
        """
        {1: 2, **{"a": 3}, None, **{"b": 4}, 5: 6}
        """)
    DictUnpackingTransformer().visit(mod)
    assert mod.body[0].value.value.args[0].body[0].value.value.value == 3
    assert mod.body[0].value.value.args[0].body[0].value.keys[0].s == 'a'
    assert mod.body[0].value.value.args[0].body[0].value.keys[0].s == 'a'
    assert mod.body[0].value.value.args[1].args[0].s == 'b'

# Generated at 2022-06-23 22:44:29.429218
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Given
    class test_object(object):
        def _visit_Dict(self, node):
            return node
        def _split_by_None(self, items):
            return items
        def _prepare_splitted(self, splitted):
            return splitted
        def _merge_dicts(self, items):
            return items

    node_ = ast.Dict(keys=[None], values=[])
    expected = ([], )

    # When
    actual = test_object()._visit_Dict(node_)  # type: ignore

    # Then
    assert actual == expected



# Generated at 2022-06-23 22:44:30.765312
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass
# vim: set foldmethod=indent foldnestmax=2 ft=python:

# Generated at 2022-06-23 22:44:38.605541
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    from ..utils.astdiff import diff_ast

    transformer = DictUnpackingTransformer()

    code = """{
        1: 2,
        **{3: 4},
        5: 6
    }"""
    expected = """_py_backwards_merge_dicts([dict({1: 2}), dict({5: 6})], {3: 4})"""

    parsed = ast.parse(code)
    transformed = transformer.visit(parsed)
    transformed_code = astunparse.unparse(transformed)
    diff_ast(expected, transformed_code)
    assert expected == transformed_code

# Generated at 2022-06-23 22:44:47.309482
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    expected = ast.parse('a = {1: 1, **{}}')

    def run(code):
        node = ast.parse(code)
        transformer = DictUnpackingTransformer()
        transformer.visit(node)
        assert transformer._tree_changed is True
        return node

    node = run('a = {1: 1}')
    assert ast.dump(node) == ast.dump(expected)

    node = run('a = {1: 1, **{}}')
    assert ast.dump(node) == ast.dump(expected)

    node = run('a = {1: 1, a: 2}')
    assert ast.dump(node) == ast.dump(expected)

    node = run('a = {1: 1, **{}, a: 2}')

# Generated at 2022-06-23 22:44:57.240738
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse(textwrap.dedent('''\
        x = {1: 2, **dict_a}
        
        def f(a: str, **kwargs):
            return a
        
        f(a="test", **dict_b)
        '''))  # type: ast.Module

    transformer = DictUnpackingTransformer()
    result = transformer.visit(module)


# Generated at 2022-06-23 22:44:59.361627
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('{1: 1, **dict_a}')
    DictUnpackingTransformer().visit(tree)
    assert tree == merge_dicts() + ast.parse('{1: 1, **dict_a}')


# Generated at 2022-06-23 22:45:03.561061
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    text = '''
{
    1: 1,
    **dict_a,
    **dict_b
}
    '''
    expected = '''_py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)'''
    code = compile(text, '', mode='exec')
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert expected in ast.dump(tree)

# Generated at 2022-06-23 22:45:07.573612
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    d = {
        '_py_backwards_merge_dicts': _py_backwards_merge_dicts
    }
    module = ast.parse("""{1: 1, **dict_a}""")
    with patch.dict(d, clear=True):
        result = ast.fix_missing_locations(DictUnpackingTransformer().visit(module))
    assert result.body[0].name == '_py_backwards_merge_dicts'



# Generated at 2022-06-23 22:45:13.572260
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """\
{
    None,
    1: 2,
    **a
}"""
    expected = """\
_py_backwards_merge_dicts([dict(None), {1: 2}], a)"""

    expected_ast = ast.parse(expected)
    result_ast = DictUnpackingTransformer().visit(ast.parse(code))
    assert ast.dump(expected_ast) == ast.dump(result_ast)

# Generated at 2022-06-23 22:45:24.378239
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    mod = ast.parse('{1:2, 3: 4, **a}')
    tr = DictUnpackingTransformer()
    node = tr.visit(mod)
    result = ast.dump(node)

# Generated at 2022-06-23 22:45:33.250139
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from textwrap import dedent
    from ..utils.source import Source
    from ..transformer import SequenceTransformer

    source = Source("""
    def f():
        a = {1: 1, 2: 2, 3: 3}
        b = {2: 3, 3: 2, 4: 1, **a}
    """)

    # Expected result
    expected = dedent("""
    def f():
        a = _py_backwards_merge_dicts([{1: 1}], {1: 1, 2: 2, 3: 3})
        b = _py_backwards_merge_dicts([{2: 3, 3: 2, 4: 1}], {1: 1, 2: 2, 3: 3})
    """)

    result = SequenceTransformer([DictUnpackingTransformer()]).transform_source

# Generated at 2022-06-23 22:45:43.280187
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_code = """
        dict_a = {2: 2}
        dict_b = {3: 3}
        dict_c = {1: 1, **dict_a, **dict_b}

        print(dict_c)
    """

    expected_code = """
        dict_a = {2: 2}
        dict_b = {3: 3}
        dict_c = _py_backwards_merge_dicts([{1: 1}, dict_a, dict_b])

        print(dict_c)
    """

    program = ast.parse(test_code)
    transformer = DictUnpackingTransformer()
    program = transformer.visit(program)
    code = astor.to_source(program)
    assert code == expected_code



# Generated at 2022-06-23 22:45:45.062862
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    obj = DictUnpackingTransformer(target=(3, 4))
    assert type(obj) == DictUnpackingTransformer

# Generated at 2022-06-23 22:45:49.589333
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().visit(ast.Dict(
        keys=[ast.Str(s='foo'), ast.Str(s='bar')],
        values=[ast.Num(n=1), ast.Num(n=2)])) == ast.Dict(
        keys=[ast.Str(s='foo'), ast.Str(s='bar')],
        values=[ast.Num(n=1), ast.Num(n=2)])


# Generated at 2022-06-23 22:45:55.779864
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing_utils import assert_program_equal

    transformer = DictUnpackingTransformer()
    program = '''
        {1: 1, 2: 2, **a}'''

    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], a)'''

    new_program = transformer.visit(ast.parse(program))
    assert_program_equal(new_program, expected)



# Generated at 2022-06-23 22:46:02.537696
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # type: () -> None
    code = """\
    {1: 1, **dict_a}
    """
    expected_code = """\
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    expected_ast = ast.parse(expected_code).body[0]
    actual_ast = DictUnpackingTransformer.run(code)
    assert ast.dump(actual_ast) == ast.dump(expected_ast)

# Generated at 2022-06-23 22:46:12.176919
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import jsonschema

    from ..utils.tree import parse_to_ast
    from ..utils.output import dump
    from ..utils.compare import compare_ast
    from ..utils.schema import validate_ast_schema

    cases = [
        '{1: 1}',
        '{1: 1, 2: 2}',
        '{1: 1, **{2: 2}}',
        '{1: 1, **{2: 2}, **{3: 3, **{4: 4}}}',
        '{1: 1, **{2: 2}, 3: 3, **{4: 4}, 5: 5}',
        '{1: 1, 2: 2, **{3: 3}, **{4: 4}, 5: 5}',
    ]
    for case in cases:
        
        tree = parse

# Generated at 2022-06-23 22:46:20.814487
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from io import StringIO
    import astor
    from .base import BaseNodeTransformer

    code = """
    a = {1: 1, 2: 2, **dict_a}
    b = {**dict_b, 3: 3, 4: 4}
    c = {1: 1, **dict_c, **dict_d}
    d = {1: 1, 2: 2, **dict_e, 3: 3}
    """

    tree = ast.parse(code)
    node_transformer = DictUnpackingTransformer()
    node_transformer.visit(tree)
    output = StringIO()
    astor.to_source(tree, output)
    actual = output.getvalue()

# Generated at 2022-06-23 22:46:27.225989
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import test_utils
    from ..utils import test_utils_ast as ast

    transformer = DictUnpackingTransformer()
    actual = transformer.visit(ast.parse('{1: 1, 2: 2, **dict_a}'))
    expected = ast.parse('''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    ''')
    test_utils.assert_equal(expected, actual)

# Generated at 2022-06-23 22:46:32.770118
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    t2 = DictUnpackingTransformer()
    assert t != t2
    assert t.target == (3, 4)
    assert t.target == t2.target
    assert t.generic_visit == t2.generic_visit
    assert t.visit_Module != t2.visit_Module
    assert t.visit_Dict != t2.visit_Dict

# Generated at 2022-06-23 22:46:39.969729
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    from ..utils.source import source_to_ast

    class Dummy:
        __module__ = 'module'

    source1 = dedent('''
        {1: 1, **dict_a}''')

    transformer = DictUnpackingTransformer(tree=source_to_ast(source1))
    tree1 = transformer.visit(source_to_ast(source1))
    tree2 = source_to_ast(dedent('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)'''))
    assert ast.dump(tree1) == ast.dump(tree2)

    source2 = dedent('''
        {**{**dict_a}}''')


# Generated at 2022-06-23 22:46:43.299312
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = '''\
dict_a = {'a': 1, 'b': 2}
dict_b = {**dict_a}
'''

# Generated at 2022-06-23 22:46:52.993666
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert DictUnpackingTransformer().visit(ast.parse('''
        a = {1: 1, **dict_a}
    ''')) == ast.Module(body=[
        ast.Assign(
            targets=[ast.Name(id='a')],
            value=ast.Call(
                func=ast.Name(id='_py_backwards_merge_dicts'),
                args=[ast.List(elts=[
                    ast.Dict(keys=[ast.Num(n=1)], values=[ast.Num(n=1)]),
                    ast.Name(id='dict_a'),
                ])],
                keywords=[]
            )
        ),
    ])


# Generated at 2022-06-23 22:46:57.043451
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    x = transformer.visit(ast.parse('{1: 1, **dict_a}'))
    assert transformer._tree_changed
    assert x == ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')

# Generated at 2022-06-23 22:47:05.111353
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """\
{1: 1, **a, 2: 2, **b, 3: 3, **c, 4: 4, **d, 5: 5, **e, 6: 6, **f, 7: 7, **g, 8: 8,
 **h, 9: 9, **i, **z}
"""

# Generated at 2022-06-23 22:47:15.718289
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    class Visitor(ast.NodeVisitor):
        def visit_Dict(self, node):
            return node
    
    visitor = DictUnpackingTransformer(Visitor())
    node = ast.Dict(keys=[ast.Num(n=1), None, ast.Str(s='str')],
                    values=[ast.Num(n=1), ast.Dict(keys=[], values=[]),
                            ast.Str(s='str')])
    result = visitor.visit(node)
    assert isinstance(result, ast.Call)
    assert result.func.id == '_py_backwards_merge_dicts'
    assert len(result.args) == 1
    assert len(result.args[0].elts) == 3

# Generated at 2022-06-23 22:47:22.276374
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astor import codegen, parse

    code = """
    d = {1, 2, **{3, 4, 5}, 3: 4, **{5: 6}}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    d = _py_backwards_merge_dicts([{1, 2}, {3, 4, 5}, {3: 4}, {5: 6}])
    """
    source = parse(code)
    actual = codegen.to_source(DictUnpackingTransformer().visit(source))
    assert actual == expected

# Generated at 2022-06-23 22:47:27.201082
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
        {1: 1}
    """
    expected = """
        _py_backwards_merge_dicts = lambda xs: dict(xs[0]).update(**xs[1])
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tr = DictUnpackingTransformer()
    assert tr.visit(ast.parse(code)) == ast.parse(expected)


# Generated at 2022-06-23 22:47:32.012361
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse("""{1: 2, 3: None if 4 else 5, **a}.copy()""")
    module = DictUnpackingTransformer().visit(module)  # type: ignore

    expected_module = ast.parse("""
        _py_backwards_merge_dicts(
            [{1: 2, 3: None if 4 else 5}],
            a,
        ).copy()
    """)

    assert module == expected_module
