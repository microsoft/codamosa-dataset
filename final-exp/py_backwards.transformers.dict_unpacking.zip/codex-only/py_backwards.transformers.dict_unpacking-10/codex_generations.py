

# Generated at 2022-06-23 22:37:40.735399
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # defines,
    Dict = ast.Dict
    Call = ast.Call
    List = ast.List
    Name = ast.Name
    dict_ = Dict(
        keys=[],
        values=[])

    assert DictUnpackingTransformer(3, 4).visit(dict_) == dict_

    dict_ = Dict(
        keys=[None],
        values=[Dict(keys=[], values=[])])

    assert DictUnpackingTransformer(3, 4).visit(dict_) == dict_

    dict_ = Dict(
        keys=[None, None],
        values=[Dict(keys=[], values=[]),
                Dict(keys=[], values=[])])

    assert DictUnpackingTransformer(3, 4).visit(dict_) == dict_


# Generated at 2022-06-23 22:37:48.695207
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse
    from ..utils import compare_nodes

    source = """
    {
        'a': 1,
        **d,
        2: 2,
        'b': 3,
        **e
    }
    """
    root = parse(source)
    expected = """
    _py_backwards_merge_dicts([
        dict([(AST_Str('a'), AST_Num(1)), (AST_Num(2), AST_Num(2)), (AST_Str('b'), AST_Num(3))]),
        d,
        e
    ])
    """
    transform = DictUnpackingTransformer()
    result = transform(root)
    compare_nodes(result, expected)

# Generated at 2022-06-23 22:37:50.749507
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer



# Generated at 2022-06-23 22:37:53.302263
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import ast
    class Transform:
        def __init__(self, module):
            self.module = module
    

# Generated at 2022-06-23 22:37:55.099169
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('{1: 1, **dict_a}')

# Generated at 2022-06-23 22:38:02.629334
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import transforms_to
    transforms_to(
        """
            {1: 1, 2: 2, 3: 3, 4: 4, **a, **b, 5: 5, **c, 6: 6}
        """,
        """
            _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}, a, b, {5: 5}, c, {6: 6}])
        """,
        DictUnpackingTransformer)

# Generated at 2022-06-23 22:38:05.605560
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .example import example_dict_unpacking
    x = DictUnpackingTransformer()
    source = example_dict_unpacking
    result = x.visit(source)

# Generated at 2022-06-23 22:38:08.784081
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Test for DictUnpackingTransformer.visit_Module
    assert compile(
        '{1: 1, **dict_a}', '<test>', mode='eval',
        flags=0, dont_inherit=False
    ) is not None



# Generated at 2022-06-23 22:38:11.608876
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse('{1: 1, **dict_a}')
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-23 22:38:14.694080
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Unit test for method visit_Module of class DictUnpackingTransformer"""
    source = '''a = {0: 0, **dict_a}'''

# Generated at 2022-06-23 22:38:17.066859
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    input = """
{1: 1, **dict_a}
    """


# Generated at 2022-06-23 22:38:17.646306
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-23 22:38:25.833574
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:38:37.516870
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTransformerTestCase
    from ..utils.tree import transforms_to

    with BaseNodeTransformerTestCase(
            DictUnpackingTransformer,
            expected_to_source='''
            _py_backwards_merge_dicts([{1: 1}, dict_a])
            ''',
            original_source='''
            {1: 1, **dict_a}
            ''') as testcase:
        assert transforms_to(testcase)


# Generated at 2022-06-23 22:38:45.034262
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse('{**a, **b, 1: a, 2: b}')
    node = tree.body[0].value
    assert isinstance(node, ast.Dict)
    assert None in node.keys

    expected = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[
            ast.List(
                elts=[
                    ast.Dict(
                        keys=[ast.Num(n=k) for k in (1, 2)],
                        values=[ast.Name(id='a'), ast.Name(id='b')]),
                    ast.Name(id='a'),
                    ast.Name(id='b')])],
        keywords=[])

    transformed = DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 22:38:46.642985
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-23 22:38:47.568835
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None)

# Generated at 2022-06-23 22:38:56.114546
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from .common import transform

    node = ast.Dict(keys=[None, ast.Str(s='a'), None],
                    values=[
                        ast.Dict(keys=[ast.Str(s='b'), ast.Str(s='c')],
                                 values=[ast.Str(s='B'), ast.Str(s='C')]),
                        ast.Dict(keys=[ast.Str(s='d'), ast.Str(s='e')],
                                 values=[ast.Str(s='D'), ast.Str(s='E')]),
                        ast.Dict(keys=[ast.Str(s='f'), ast.Str(s='g')],
                                 values=[ast.Str(s='F'), ast.Str(s='G')])
                    ])

# Generated at 2022-06-23 22:39:01.144107
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse(
        'd1 = {1: 10, **{2: 20, 3: 30}, **{3: 33, 4: 44}, **{"a": "A"}}')
    # Assert that tree has unpacking
    assert [node.value.func.id for node in ast.walk(tree)
            if isinstance(node, ast.Assign)] == ['_py_backwards_merge_dicts']

# Generated at 2022-06-23 22:39:11.644135
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.functools_patcher import patch
    from ..utils.tree import tree
    from ..utils.visitor import ExampleASTVisitor
    from ..utils.source import source
    from textwrap import dedent
    import sys  # for version

    patch()
    sys.modules['_ast_unparsing'] = sys.modules[__name__]

    ref = ast.parse(dedent("""\
        def f():
            x = {'a': 1, **{'b': 2}, **{'c': 3, 'd': 4}, 'e': 5}"""))

# Generated at 2022-06-23 22:39:13.072159
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:39:23.194665
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent

    from ..annotation import AnnotatedNode, AnnotationVisitor
    from ..utils.tree import ast_from_str, ast_to_str
    from .annotations import annotations_for_visitors

    source = dedent("""\
        def foo():
            a = {1: 1, 2: 2}  # type: Dict[int, int]
        """)
    tree = ast_from_str(source)
    node = AnnotatedNode(source, tree)
    tree = AnnotationVisitor(annotations_for_visitors([])).visit(node)
    before = ast_to_str(tree)
    node = DictUnpackingTransformer().visit(tree)
    after = ast_to_str(node)


# Generated at 2022-06-23 22:39:26.645983
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transpiled_code = compile(
        """
        def foo():
            return {1:1,**dict_a}
        """,
        '<string>',
        'exec')

    exec(transpiled_code)
    assert foo() == {1: 1, 'q': 'w'}



# Generated at 2022-06-23 22:39:31.712425
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
        {
            1: None,
            2: 2,
            None: 3,
            4: 4,
            **a
        }
    """
    compiled = ast.parse(source)
    DictUnpackingTransformer().visit(compiled)

# Generated at 2022-06-23 22:39:32.713418
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-23 22:39:38.966298
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .tr import parse
    from .utils import normalize_statement

    code = '{1: 1, 2: 2, **dict_a, **dict_b, 3: 3}'
    parsed = parse(code)
    DictUnpackingTransformer().visit(parsed)
    assert ''.join(normalize_statement(line) for line in code.splitlines()) == \
           ''.join(normalize_statement(line) for line in ast.dump(parsed).splitlines())

# Generated at 2022-06-23 22:39:45.921133
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class _DummyNode(ast.AST):
        _fields = ()

    x = ast.Module([
        _DummyNode(),
        ast.Expr(
            ast.Call(
                func=ast.Name(id='_py_backwards_merge_dicts'),
                args=[ast.List(elts=[])],
                keywords=[],
        )),
        _DummyNode(),
        ast.Expr(
            ast.Call(
                func=ast.Name(id='_py_backwards_merge_dicts'),
                args=[ast.List(elts=[])],
                keywords=[],
        ))
    ])

    transformer = DictUnpackingTransformer()
    r0 = transformer.visit(x)


# Generated at 2022-06-23 22:39:54.540473
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor

    module = astor.parse_file("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    """)

    node = astor.parse_file("""
    def f(a):
        return {
            'x': 1,
            **a,
            'y': 2,
            **b,
            'z': 3
        }
    """)
    assert isinstance(node, ast.Module)
    expected = """
    def f(a):
        return _py_backwards_merge_dicts([{'x': 1}, a, {'y': 2}, b, {'z': 3}])
    """

    t = DictUnpackingTrans

# Generated at 2022-06-23 22:39:55.311076
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:00.333440
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from ..utils.tree_visitor import NodeWalker
    from ..utils.annotation import annotate

    node = ast3.parse('''
x = {
    None: dict(**{'a': 1, 'c': 2}),
    **{"b": 2},
    **{'b': 4},
    None: [1, 2, 3],
}
    ''')

    transformer = DictUnpackingTransformer()
    walker = NodeWalker()

    walker.walk(node, transformer)
    walker.walk(node, annotate(errors=False))
    print(ast3.dump(node))
    assert eval(ast3.dump(node)) == {'b': 4, 'c': 2, 'a': 1, 'x': [1, 2, 3]}

# Generated at 2022-06-23 22:40:09.731205
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict(): # type: ignore
    source = '''
    x = {1:2, 3:4, **{}}
    y = {}
    z = {}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    
    x = _py_backwards_merge_dicts([{1: 2, 3: 4}, {}])
    y = {}
    z = {}
    '''
    tree = get_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert expected == get_source(tree)



# Generated at 2022-06-23 22:40:18.608582
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    actual = ast.dump(
        DictUnpackingTransformer().visit(ast.parse("{**a, 1: 2, **b, 2: 3}")))

# Generated at 2022-06-23 22:40:24.111824
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    expected_ast = ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a);')
    node = ast.parse('{1: 1, **dict_a};')
    actual_ast = DictUnpackingTransformer.apply_to_ast(node)
    # print(ast.dump(expected_ast))
    # print(ast.dump(actual_ast))
    assert ast.dump(expected_ast) == ast.dump(actual_ast)


# Generated at 2022-06-23 22:40:33.785381
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source

    code = '''
    a = {1: 2, 3: 4}
    '''

    case = source(code)
    expected = source('''
    import collections.abc

    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    a = {1: 2, 3: 4}
    ''')
    module = ast.parse(case.code)
    new_module = DictUnpackingTransformer().visit(module)
    assert new_module is not None
    assert source.from_ast(new_module) == expected



# Generated at 2022-06-23 22:40:39.650647
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    print("\nTesting method visit_Module of class DictUnpackingTransformer")
    t = DictUnpackingTransformer()
    node = ast.parse("{1:2}")
    result = t.visit(node)
    assert result is not node
    assert result.body[0].body[0].name == '_py_backwards_merge_dicts'



# Generated at 2022-06-23 22:40:41.315806
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.utils import expect_equal_source
    from ..testing.files import files
    expect_equal_source(files.dict_unpacking,
                        DictUnpackingTransformer)

# Generated at 2022-06-23 22:40:42.601815
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:47.622011
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    src = """{**{1:1}, **{}}"""
    exp = """dict([(1, 1), ({}, {})])"""
    assert DictUnpackingTransformer().visit(ast.parse(src)) == ast.parse(exp)  # type: ignore

# Generated at 2022-06-23 22:40:55.736004
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    assert transformer.visit(ast.parse('{None: 1}')).body[0].value == \
        ast.Call(
            func=ast.Name(id='dict'),
            args=[ast.Num(1)],
            keywords=[])
    assert transformer.visit(ast.parse('{1: None}')).body[0].value == \
        ast.Call(
            func=ast.Name(id='dict'),
            args=[],
            keywords=[])

# Generated at 2022-06-23 22:41:06.777741
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    import sys

    # Test code:
    code = '''\
{1: 1, 2: 2, 3: 3,
 **a,
 9: 9,
 **b,
 **c,
 8: 8,
}'''

    # Expected output:
    expected = '''\
_py_backwards_merge_dicts(
    [
        {1: 1, 2: 2, 3: 3},
    ],
    a,
    {9: 9},
    b,
    c,
    {8: 8},
)'''

    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    output = astunparse.unparse(tree)

    assert output == expected, "Unexpected output:\n{0}".format(output)



# Generated at 2022-06-23 22:41:14.291416
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a})
    """
    assert DictUnpackingTransformer(recursive=False).visit_and_transform(code) == expected



# Generated at 2022-06-23 22:41:18.913532
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = '''
    def my_func(a):
        {1: 1, **a}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    def my_func(a):
        _py_backwards_merge_dicts([{1: 1}], a})
    '''
    tree = ast.parse(source)
    mod_transformer = DictUnpackingTransformer()
    new_tree = mod_transformer.visit(tree)
    assert ast.dump(new_tree) == expected



# Generated at 2022-06-23 22:41:23.763349
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..tests.toolbox import generate_code
    from ..tests.tree_builder import build
    from ..utils.source import Code
    
    code = Code('''''')
    tree = build(code)
    DictUnpackingTransformer().visit(tree)
    result = generate_code(tree)
    
    assert "# START: merge_dicts" in result
    assert "# END: merge_dicts" in result


# Generated at 2022-06-23 22:41:34.263045
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    merge_dicts_node = merge_dicts.get_body()
    code = '''def f(a):
    return {1: 2, **a}'''
    node = ast.parse(code)
    merge_dicts_node[0].lineno = 4  # type: ignore
    merge_dicts_node[0].col_offset = 4  # type: ignore
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-23 22:41:41.456086
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .constructor import TestingTransformerConstructor
    from .testing import assert_equal
    from .testing import eval_eq, compile_to_eval
    from .testing import eval_ast_module

    tested_classes = (
        DictUnpackingTransformer,
    )

    with TestingTransformerConstructor(tested_classes) as constructor:
        constructor.add_test(
            input_ast=ast.parse('a = {1: 1, 2: 2, 3: 3}'),
            expected_source='a = {1: 1, 2: 2, 3: 3}',
            eval_eq=eval_eq,
        )


# Generated at 2022-06-23 22:41:48.925543
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    snippet_1 = """\
    foo = {"asd": 1, **bar}
    """
    snippet_2 = """\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    """

    body_1, = ast.parse(snippet_1).body
    body_2, = ast.parse(snippet_2).body

    mod_1 = ast.Module(body=[body_1])
    mod_2 = ast.Module(body=[body_2, body_1])
    DictUnpackingTransformer().visit(mod_1)
    assert ast.dump(mod_1) == ast.dump(mod_2)


# Generated at 2022-06-23 22:41:54.508283
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    tree = ast.parse("""\
        a = {1: 2, **{3: 4}}
    """)
    assert '_py_backwards_merge_dicts' not in dir(tree.body[0].value)

    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert '_py_backwards_merge_dicts' in dir(tree.body[0].value)


# Generated at 2022-06-23 22:42:00.207805
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    expr = ast.parse('{1: 1, **dict_a}').body[0]
    transformer = DictUnpackingTransformer()
    assert transformer.visit(expr).body[0] == ast.Expr(value=ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[ast.List(elts=[
            ast.Call(func=ast.Name(id='dict'),
                     args=[],
                     keywords=[]),
            ast.Name(id='dict_a')])],
        keywords=[]))

# Generated at 2022-06-23 22:42:01.945861
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    meta = type('Meta', (object,), {})
    transformer = DictUnpackingTransformer(meta)
    assert transformer



# Generated at 2022-06-23 22:42:12.567183
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Test with dict unpacking
    node = ast.parse('{1: 1, **dict_a}')
    DictUnpackingTransformer().visit(node)  # type: ignore

# Generated at 2022-06-23 22:42:13.583264
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer({}, None)

# Generated at 2022-06-23 22:42:20.080339
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    snippet = '{1: 1, **dict_a}'
    expected = 'dict(((1, 1),))'
    merged = 'def _py_backwards_merge_dicts(dicts): result = {}\nfor dict_ in dicts:\n result.update(dict_)\nreturn result'

    tr = DictUnpackingTransformer()
    assert str(tr.visit(ast.parse(snippet))) == f'{merged}\n{expected}'



# Generated at 2022-06-23 22:42:21.637809
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer = DictUnpackingTransformer()
    assert dict_unpacking_transformer is not None

# Generated at 2022-06-23 22:42:25.593770
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert DictUnpackingTransformer().visit(source) == expected

# Generated at 2022-06-23 22:42:34.078416
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .test_utils import compile_to_ast
    from ast import parse, Module, Dict
    from astunparse import unparse

    expr = parse("{1: 2, 3: 4, **c, 5: 6, **d}")
    result = DictUnpackingTransformer().visit(expr)  # type: ignore

    expected = compile_to_ast("""
    _py_backwards_merge_dicts([{1: 2, 3: 4}, dict(5=6)], c, d)
    """)
    assert unparse(result) == unparse(expected)



# Generated at 2022-06-23 22:42:44.535846
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Simple case
    node = ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=3)],
                    values=[ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)])

    # noinspection PyTypeChecker
    transformed = DictUnpackingTransformer().visit(node)  # type: ignore
    assert '_py_backwards_merge_dicts' in astor.to_source(transformed)

    # Check that transform is idempotent
    # noinspection PyTypeChecker
    transformed = DictUnpackingTransformer().visit(transformed)  # type: ignore
    assert '_py_backwards_merge_dicts' not in astor.to_source(transformed)

# Generated at 2022-06-23 22:42:48.311217
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..compiler import compile_function
    result = compile_function('''
    def f():
        return {0: 0, **{1: 1}, 2: 2, **{3: 3}, 4: 4, **{5: 5}}
    ''')
    assert result.__code__.co_consts[0] == _py_backwards_merge_dicts

# Generated at 2022-06-23 22:42:52.539160
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert evaluate(compile_snippet(merge_dicts.get_source(), 3)) == {1: 1}
    assert evaluate(compile_snippet(merge_dicts.get_source(), 4)) == {1: 1}



# Generated at 2022-06-23 22:43:02.362404
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:43:12.445325
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():  # noqa
    visitor = DictUnpackingTransformer()
    dict_ = ast.parse('{1: 1, **dict_a}').body[0].value
    converted = visitor.visit(dict_)

    assert converted.func.id == '_py_backwards_merge_dicts'
    assert len(converted.args) == 1
    assert len(converted.args[0].elts) == 3
    assert converted.args[0].elts[0].keys == [ast.Num(1)]
    assert converted.args[0].elts[0].values == [ast.Num(1)]
    assert converted.args[0].elts[1].keys == [ast.Name('dict_a')]
    assert converted.args[0].elts[2].keys == []

# Generated at 2022-06-23 22:43:17.038146
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert DictUnpackingTransformer().visit(
        ast.parse('{1: 1, 2: 2, **dict_a, **dict_b}')  # type: ignore
    ) == ast.parse('_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)')  # type: ignore

# Generated at 2022-06-23 22:43:18.294162
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert(isinstance(DictUnpackingTransformer(), BaseNodeTransformer))

# Generated at 2022-06-23 22:43:25.903961
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''
        def func(a, b=None, **c):
            var = {
                1: 1,
                **a,
                2: 2,
                **b
            }
            print(var)
    '''
    expect = '''
        def _py_backwards_merge_dicts(dicts, base=None):
            result = {}
            if base:
                result.update(base)
            for dict_ in dicts:
                result.update(dict_)
            return result
        def func(a, b=None, **c):
            var = _py_backwards_merge_dicts(
                [{1: 1, 2: 2}], a)
            print(var)
    '''
    subtransformer = DictUnpackingTransformer(None)
    result

# Generated at 2022-06-23 22:43:26.946954
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:43:33.079328
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    assert transformer.visit(parse('''{1: 1, 2: 2}''')) == \
        parse('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        {1: 1, 2: 2}
        ''')



# Generated at 2022-06-23 22:43:39.582976
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import subprocess
    note_compiler = 'compilest'
    note_compiled = 'compiledst'
    subprocess.check_output(
        ['python3', '-m', note_compiler, 'dict_unpacking'])
    subprocess.check_output(
        ['python3', '-m', note_compiled, 'dict_unpacking'])
    with open('dict_unpacking.py') as f:
        code = f.read()

# Generated at 2022-06-23 22:43:40.508657
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:43:44.484635
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3 as ast
    
    node = ast.Module([ast.Pass()])
    DictUnpackingTransformer.run_test(node, expected_tree=merge_dicts.get_body())
    

# Generated at 2022-06-23 22:43:54.447351
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        def create_transformer(self) -> DictUnpackingTransformer:
            return DictUnpackingTransformer()

        def test_basic(self):
            input = """\
            {1: 1, **{2: 2}, 3: 3, **{4: 4}, 5: 5}
            """
            expected = """\
            _py_backwards_merge_dicts([{1: 1}, dict({2: 2}), {3: 3}, dict({4: 4}), {5: 5}])
            """
            self.assertCodeEqual(input, expected)


# Generated at 2022-06-23 22:44:03.428094
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class DummyTransformer(DictUnpackingTransformer):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return super().visit_Dict(node)

    node = ast.parse('''\
{
    1: 2,
    **{3: 4, 5: 6},
    7: 8,
}
''')
    assert DummyTransformer().visit(node) == ast.parse('''\
{
    _py_backwards_merge_dicts([{1:2}, {7:8}], {3:4, 5:6})
}
''')

# Generated at 2022-06-23 22:44:11.680883
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..run import compile_str
    from ..node_tools import clean_node
    from ..utils import SourceCode
    test_cases = {
        "def func(): {1: 1, **dict_a}":
            SourceCode('''
                def func():
                    return _py_backwards_merge_dicts([{1: 1}], dict_a)
            ''', globals_=None)
    }
    for code, expected in test_cases.items():
        clean_tree = clean_node(compile_str(code, 3))
        actual = SourceCode.from_node(clean_tree)
        assert expected == actual

# Generated at 2022-06-23 22:44:13.209921
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:44:16.416105
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''
    {}
    '''
    tree = ast.parse(code)
    expected = ast.parse(merge_dicts() + code)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-23 22:44:17.614647
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer(None)
    assert isinstance(t, BaseNodeTransformer)

# Generated at 2022-06-23 22:44:19.376857
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert '3' == generate_source(
        DictUnpackingTransformer().visit(
            ast.parse('{1: 1, 2: 2, None: {3: 3}, 4: 4}')
        )
    )

# Generated at 2022-06-23 22:44:20.183718
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    obj = DictUnpackingTransformer(None)

# Generated at 2022-06-23 22:44:23.052486
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')

# Generated at 2022-06-23 22:44:33.536292
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dut = DictUnpackingTransformer()
    toplevel = ast.parse(
        '''
        a = {1: 2, **{3: 4}, 5: 6}
        b = {1: 2, '3': 4, 5: 6}
        c = {1: 2, **dict_a, **dict_b}
        d = {1: 2}
        e = {**dict_a}
        ''')
    dut.visit(toplevel)

# Generated at 2022-06-23 22:44:41.997199
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typing import cast
    from typed_ast import ast3
    from ...engine import create_module
    engine = create_module(['typing', 'typed_ast', '_py_backwards_merge_dicts'])
    transformer = ast3.parse('''
    def func(a, b, c):
        return {a: 1, **b, **c}
    ''')
    engine.global_namespace.update(ast3.get_global_namespace(transformer))
    transformer = cast(ast3.Module, transformer)

    engine.transformer = DictUnpackingTransformer()
    engine.run_module(transformer)

    assert transformer.body[0].name == '_py_backwards_merge_dicts'  # type: ignore

# Generated at 2022-06-23 22:44:44.295308
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    result = "'_py_backwards_merge_dicts' in locals()"
    assert result in str(DictUnpackingTransformer().visit_Module(ast.parse('')))

# Generated at 2022-06-23 22:44:45.134621
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:44:51.346885
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as python_ast

    def parse(string):
        return python_ast.parse(string, '<string>', 'eval')

    def get_dict_elements(node):
        """
        Returns list of elements of Dict.
        For ordinary Dict it is pairs of key and value.
        For merged Dict it is Calls of merged Dicts.
        """
        assert isinstance(node, python_ast.Dict)
        if len(node.keys) == 0:
            return [node.values[0]]
        else:
            return list(zip(node.keys, node.values))

    def correct(node):
        """
        Returns True if node is correct Call of _py_merge_dicts.
        """
        assert isinstance(node, python_ast.Call)

# Generated at 2022-06-23 22:44:53.557631
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert t is not None


# Generated at 2022-06-23 22:44:59.007825
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .helpers import check_unittest, get_ast

    code = get_ast("""
        {1: a, **dict_a}
        {1: a, **{'a': b}, **dict_a}
    """)

    make_visitor = check_unittest(DictUnpackingTransformer)
    make_visitor(code, """
        _py_backwards_merge_dicts([{1: a}], dict_a)
        _py_backwards_merge_dicts([{1: a}, {'a': b}], dict_a)
    """)

# Generated at 2022-06-23 22:45:08.222588
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .. import ast3 as ast3
    source = """
    dict_a = {2: 2}
    dict_b = {4: 4, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    dict_a = {2: 2}
    dict_b = _py_backwards_merge_dicts([{4: 4}], dict_a)
    """
    tree = ast3.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert ast3.dump(tree) == expected



# Generated at 2022-06-23 22:45:09.254591
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-23 22:45:12.853094
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    @test_utils.assert_ast_equal
    def test():
        x = {**d}

    result = DictUnpackingTransformer().visit(test.__ast__)  # type: ignore
    return result


# Generated at 2022-06-23 22:45:17.830155
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert isinstance(DictUnpackingTransformer.visit_Module(DictUnpackingTransformer, ast.Module([ast.Expr(value=ast.Dict(keys=[None, ast.Num(n=1)], values=[ast.Num(n=1), ast.Num(n=2)]))], type_ignores=[])), ast.Module)


# Generated at 2022-06-23 22:45:19.392150
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().target == (3, 4)


# Generated at 2022-06-23 22:45:20.728334
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:45:30.855713
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("""
a = {1: 1, **dict_a}
{**dict_b, 2: 2}
""")
    transformed = DictUnpackingTransformer().visit(module)


# Generated at 2022-06-23 22:45:40.297167
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    prepared_code = merge_dicts.get_code()
    module_node = ast.parse('''
        dict_a = {'a': 100}
        dict_b = {'b': 200}
        dict_c = {'c': 300}
        dict_d = {'d': 400}
        dict_e = {'e': 500}
        assert {'a': 1, 'b': 2, **dict_a, **dict_b, **dict_c, **dict_d, **dict_e} == {'e': 500, 'd': 400, 'c': 300, 'b': 200, 'a': 100, 'b': 2, 'a': 1}
    ''')
    transformer.visit(module_node)

# Generated at 2022-06-23 22:45:49.125545
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .tree import get_tree
    from ..utils.node import to_source
    import textwrap

    source = textwrap.dedent('''\
        {1: 1, **{2: 2}, 3: 3, **{4: 4}}
        ''')
    node = get_tree(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(node)
    expected = textwrap.dedent('''\
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        _py_backwards_merge_dicts([{1: 1}, {2: 2}, {3: 3}, {4: 4}])
        ''')

# Generated at 2022-06-23 22:45:59.889691
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import assert_equal_source
    from ..node_visitor import CompoundNodeVisitor
    from ..node_replacers import CompatNodeTransformer
    from ..utils.tree import merge_dicts

    visitor = CompoundNodeVisitor(
        DictUnpackingTransformer
    )

    code = """\
{1: 1, **dict_a}
"""

    expected = """\
{1: 1}
"""

    code = merge_dicts(code, 'dict_a')
    expected = merge_dicts(expected, 'dict_a')

    tree = ast.parse(code)
    tree = visitor.visit(tree)  # type: ignore
    tree = CompatNodeTransformer().visit(tree)  # type: ignore
    assert_equal_source(tree, expected)


# Generated at 2022-06-23 22:46:08.092049
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = \
        "a = {1: 1, **dict_1}\n" \
        "b = {1: 1, 2: 2, **dict_1, **dict_2}\n" \
        "c = {'a': 'a', 'b': 'b', **dict_1, **dict_2}\n" \
        "d = {*list_1}\n" \
        "e = {*list_1, 2, **dict_1}\n" \
        "f = {2, **dict_1, *list_1}\n" \
        "g = {2, *list_1, **dict_1}\n" \
        "h = {*list_1, **dict_1, *list_2}"


# Generated at 2022-06-23 22:46:18.610810
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    tree = ast.parse("""\
    class A:
        a = {1: 2, 3: 5}
        c = {1: 2, **{3: 5}}
        d = {1: 2, **{3: 5}, **{6: 8}, **{1: 9}, **{9: 2}}
    """)


# Generated at 2022-06-23 22:46:20.550616
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert(isinstance(DictUnpackingTransformer(), BaseNodeTransformer))


# Generated at 2022-06-23 22:46:29.778627
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_base import BaseNodeTest
    from ..utils.source import source
    from ..utils.chain import chain
    BaseNodeTest.test_generic_visit(
        source('''
                x = {1: 1, 2: 2, 3: x, **dictA, 4: 4, 5: 5, **dictB, 6: 6}
            '''),
        chain(
            DictUnpackingTransformer(),
        ),
        source('''
                _py_backwards_merge_dicts(
                    [{1: 1, 2: 2, 3: x, 4: 4, 5: 5}, dictB, {6: 6}], dictA)
            '''))



# Generated at 2022-06-23 22:46:37.932736
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Create dict node for testing
    dict_node = ast.Dict(keys=[None, ast.Constant(123)],
                         values=[ast.Constant(456), ast.Constant(789)])
    # Compiles dict to function call
    dict_unpacking_transformer = DictUnpackingTransformer()
    result = dict_unpacking_transformer.visit(dict_node)

    # Assert that call of function for merging dicts is created
    assert isinstance(result, ast.Call)
    assert result.func.id == '_py_backwards_merge_dicts'
    assert len(result.args) == 1
    assert isinstance(result.args[0], ast.List)
    assert len(result.args[0].elts) == 2
    first_arg, second_arg = result.args

# Generated at 2022-06-23 22:46:48.852725
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Unit test for DictUnpackingTransformer.visit_Dict
    
    Setup:
        * Construct ast.Dict node with None in keys;
        * Create DictUnpackingTransformer instance.
    
    Expected:
        * Call method _merge_dicts
    """
    def test(node: ast.Dict):
        assert not hasattr(node, 'keys')
        assert not hasattr(node, 'values')
        node = ast.copy_location(node, target)
        assert isinstance(node, ast.Call)
        assert isinstance(node.func, ast.Name)
        assert node.func.id == '_py_backwards_merge_dicts'
        assert isinstance(node.args[0], ast.List)

# Generated at 2022-06-23 22:46:59.052784
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def check(visitor, code, expected):
        tree = ast.parse(code)
        visitor.visit(tree)  # type: ignore
        actual_code = compile(tree, filename='test', mode='exec')
        expected_code = compile(expected, filename='test', mode='exec')
        exec(actual_code)
        exec(expected_code)
        assert test_DictUnpackingTransformer_visit_Dict.actual == test_DictUnpackingTransformer_visit_Dict.expected

    # case_0
    code_0 = """
        {1: 2, 3: 4, **a, **b, 5: 6}
        """

# Generated at 2022-06-23 22:47:00.034876
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:47:02.138717
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer(None)



# Generated at 2022-06-23 22:47:10.182050
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source, sourcify
    from ..utils import json
    import astor
    from .transformer import Transformer
    from .dict_unpacking import DictUnpackingTransformer

    source = source('''
        def func():
            return {1: 1, **{1: 1}, **dict()}
    ''')
    tree = ast.parse(source)

    transformer = Transformer([DictUnpackingTransformer])
    result = transformer.visit(tree)
    print(astor.to_source(result))



# Generated at 2022-06-23 22:47:17.545273
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .. import code_to_ast, ast_to_code
    from astunparse import unparse
    source = '''
    {1: 1, 2: 2}
    '''
    expected_source = '''
    _py_backwards_merge_dicts([dict({1: 1, 2: 2})])
    '''
    module = code_to_ast.parse_module(source)
    module = DictUnpackingTransformer().visit(module)
    code = unparse(module).strip()
    assert code == expected_source


# Generated at 2022-06-23 22:47:18.429071
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:47:19.331744
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:47:20.490189
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:47:27.813942
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import _transform_source
    from ..utils.source import source

    transformer = DictUnpackingTransformer()
    src = source('''
    def foo(a):
        return {1: 1, **a}
    ''')
    res = _transform_source(src, transformer)
    assert res == source('''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    def foo(a):
        return _py_backwards_merge_dicts([{1: 1}], a)
    ''')



# Generated at 2022-06-23 22:47:31.964025
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = '''
    {1: 1, **dict_a, 2: 2, 3: 3, **dict_b}
    '''

    result = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    '''

    transformer = DictUnpackingTransformer()
    node = ast.parse(code)
    transformed = transformer.visit(node)
    transformed = ast.fix_missing_locations(transformed)

    assert ast.dump(transformed) == result

