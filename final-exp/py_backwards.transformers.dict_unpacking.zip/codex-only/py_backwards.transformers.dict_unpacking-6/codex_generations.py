

# Generated at 2022-06-23 22:37:33.122794
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer



# Generated at 2022-06-23 22:37:35.253247
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():

    def test():
        assert 3 == 3

    DictUnpackingTransformer().visit(test.__code__)

# Generated at 2022-06-23 22:37:40.923364
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    a = ast.parse("{1: 2, **{3: 4, 5: 6}, 'str': 7, **{8: 9}}")
    b = ast.parse("{1: 2, 3: 4, 5: 6, 'str': 7, 8: 9}")
    assert astor.to_source(DictUnpackingTransformer().visit(a)) == astor.to_source(
        b)

# Generated at 2022-06-23 22:37:44.370478
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """Ensures that constructor properly sets self.node_type."""
    transformer = DictUnpackingTransformer(
        ast.Module(),
        '_py_backwards_merge_dicts',
        target=(3, 4))
    assert transformer.node_type == ast.Dict

# Generated at 2022-06-23 22:37:48.250111
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Construct the input code
    import astor
    
    in_code = '''\
d = {1: 1, **{2: 2}, 3: 3}
'''
    # Expect the output code

# Generated at 2022-06-23 22:37:56.836248
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..compiler import compile_isolated, CompilerError
    import sys
    
    assert '_py_backwards_merge_dicts' not in globals()
    compile_isolated(
        source='{a: 1, **b, **c}',
        mode='exec',
        flags=ast.PyCF_ONLY_AST,
        process_tree=DictUnpackingTransformer(),
    )
    assert '_py_backwards_merge_dicts' in globals()

    # Test exception
    class Free(BaseNodeTransformer):
        def visit_Name(self, node):
            return ast.Name()


# Generated at 2022-06-23 22:38:03.390191
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """{1: 1, **dict_a}"""
    expected = """{1: 1, **dict_a}"""
    module = ast.parse(code)  # type: Union[ast.Module, ast.Call]

    original = ast.dump(module)
    module = DictUnpackingTransformer().visit(module)
    transformed = ast.dump(module)

    assert original != transformed
    assert transformed == expected

# Generated at 2022-06-23 22:38:07.793735
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''\
    {1: 1, **dict_a}
    '''
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    print(ast.dump(tree))
    assert [stmt.name for stmt in tree.body] == ['_py_backwards_merge_dicts']
    assert stmt.body[0].name == '_py_backwards_merge_dicts'

# Generated at 2022-06-23 22:38:08.358189
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:38:09.144377
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert 'None' not in dir(DictUnpackingTransformer)

# Generated at 2022-06-23 22:38:10.073667
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:38:20.389270
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    #
    # test for adding merge_dicts to a module
    #
    body = [
        ast.Expr(value=ast.Dict(keys=[ast.Constant(value=i) for i in range(5)],
                                values=[ast.Constant(value=i) for i in range(5)])),
        ast.Expr(value=ast.Dict(keys=[ast.Constant(value=i) for i in range(5)],
                                values=[ast.Constant(value=i) for i in range(5)],
                                keys_value=[None, None, None]))
    ]
    module = ast.Module(body=body)

    result = DictUnpackingTransformer().visit(module)
    assert isinstance(result, ast.Module)

# Generated at 2022-06-23 22:38:22.802030
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Testcase 1
    src = merge_dicts()
    expected = ""
    actual = print_node(src)
    assert actual == expected, print_error(actual, expected)


# Generated at 2022-06-23 22:38:25.671875
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    def expected(x): return str(ast.parse(x).body[0].value)

    assert expected('DictUnpackingTransformer()') == \
        'DictUnpackingTransformer()'


# Test function _split_by_None

# Generated at 2022-06-23 22:38:34.843118
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse("""\
    a = {**{1: 2, 3: 4}, **{5: 6, 7: 8}}
    """)  # type: ast.Module
    assert isinstance(module, ast.Module)

    transformer = DictUnpackingTransformer()
    new_module = transformer.visit(module)
    assert isinstance(new_module, ast.Module)

    assert "(1, 2), (3, 4), None, {5: 6, 7: 8}]" in str(new_module)[len('Module(body=[')+1:-1]

# Generated at 2022-06-23 22:38:36.185201
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


__transformer__ = DictUnpackingTransformer

# Generated at 2022-06-23 22:38:37.705016
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert DictUnpackingTransformer(None).visit_Module(None) is None


# Generated at 2022-06-23 22:38:38.257009
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-23 22:38:39.977826
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from xml.dom import minidom


# Generated at 2022-06-23 22:38:50.031662
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('''
        {1: 1, **dict_a}
        ''')
    transformer = DictUnpackingTransformer()
    transformer.visit(module)
    assert transformer._tree_changed == True

# Generated at 2022-06-23 22:38:51.340663
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:38:56.848481
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .utils import do_test

    test_snippet = """
        {0: 2, **{1: 3, 2: 4}}
        """
    expected_result = """
        _py_backwards_merge_dicts([{0: 2}], dict({1: 3, 2: 4}))
        """

    do_test(test_snippet, expected_result)

# Generated at 2022-06-23 22:39:07.859371
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.ast_builder import to_ast
    from ..utils.examples import DICT_UNPACKING_EXAMPLE
    from ..utils.ast_visitor import ASTPrintVisitor
    from ..utils.ast_transformer import ASTTransformer
    from ..utils.ast_visitor import apply_visitor_recursively
    from ..utils.generic_ast_unwrapper import GenericASTUnwrapper
    from ..utils.generic_ast_compare import compare_asts

    initial_ast = to_ast(DICT_UNPACKING_EXAMPLE)
    resulting_ast = ASTTransformer(DictUnpackingTransformer).visit(initial_ast)

    result_visitor = apply_visitor_recursively(GenericASTUnwrapper, resulting_ast)
    expected_visitor = apply_visitor_recursively

# Generated at 2022-06-23 22:39:10.252623
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    assert hasattr(x, "_py_backwards_merge_dicts")
    assert "DictUnpackingTransformer" in str(x)


# Generated at 2022-06-23 22:39:13.659944
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    before = ast.Module([])
    after = DictUnpackingTransformer().visit(before)
    assert isinstance(after, ast.Module)


# Generated at 2022-06-23 22:39:23.628589
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import MetaAst


# Generated at 2022-06-23 22:39:24.416288
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:39:35.318245
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import compare_nodes

    class1='''{1: 1, **dict_a}'''
    class2='''{1: 1, **{2: 2}, **{3: 3}}'''

    class1_expected = '''def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result

{1: 1, _py_backwards_merge_dicts([{1: 1}], dict_a)}'''

# Generated at 2022-06-23 22:39:43.540795
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.converter import generate_code
    from ..utils.serialize import serialize_ast

    node = ast.Dict(
        keys=[ast.Num(n=1), ast.Num(n=2), None, ast.Num(n=3)],
        values=[ast.Num(n=1), ast.Num(n=1), ast.Name(id='a'), ast.Num(n=1)])


# Generated at 2022-06-23 22:39:52.814222
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import compile_snippet

    snippet.get_snippets()[1].set_implementation(b'lambda x: x')
    module = compile_snippet(
        '{1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}',
        transformer=DictUnpackingTransformer)
    assert module.__dict__['dict_a'] == {2: 2}
    assert module.__dict__['dict_b'] == {3: 3}
    assert module.__name__ == '<module>'
    assert module.__dict__['_py_backwards_merge_dicts'].__name__ == '_py_backwards_merge_dicts'

# Generated at 2022-06-23 22:39:53.415066
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:39:58.585663
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    with open('tests/dict_unpacking/example_1.py') as fd:
        node = ast.parse(fd.read())

    transformer = DictUnpackingTransformer()
    node = transformer.visit(node)
    assert transformer._tree_changed is True

    with open('tests/dict_unpacking/example_1_expected.py') as fd:
        expected = ast.parse(fd.read())

    assert ast.dump(node, include_attributes=False) \
        == ast.dump(expected, include_attributes=False)



# Generated at 2022-06-23 22:40:02.983672
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import run_program

    run_program(
        """
        a, b, c = 1, 2, 3
        d = {1: 2, 'a': a, **{'b': b, 'c': c}}
        """,
        """
        d = {1: 2, 'a': a, **{'b': b, 'c': c}}
        d = _py_backwards_merge_dicts([{1: 2, 'a': a}], {'b': b, 'c': c})
        """
    )

# Generated at 2022-06-23 22:40:06.980800
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """
    Tests that visit_Module works correctly.
    """
    assert eval(compile(
        ast.parse("{1: 1, **{2: 2}}"),
        "<ast>",
        "exec")) == {1: 1, 2: 2}

# Generated at 2022-06-23 22:40:13.013850
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test import expected, get_ast
    from .test import get_actual_output, generate_code

    ast_tree = get_ast('{1: 1, **dict_a}')
    transformer = DictUnpackingTransformer()
    transformed = transformer.visit(ast_tree)
    code = generate_code(transformed)
    actual = get_actual_output(code)
    assert expected('{1: 1}') == actual



# Generated at 2022-06-23 22:40:19.814880
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:40:23.755886
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    with DictUnpackingTransformer() as t:
        x = {1: 1, 2: 2, 3: 3, **{4: 4, 5: 5, 6: 6}}  # type: ignore
    assert x == {1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6}
    assert t.tree_changed



# Generated at 2022-06-23 22:40:25.917462
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()

# Unit tests for method DictUnpackingTransformer._split_by_None

# Generated at 2022-06-23 22:40:26.742556
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:40:33.681264
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from ..utils.tree import print_tree, to_str, transform
    tree = ast3.parse('{1: 1, **{2: 2}, 3: 3, **{4: 4}}', mode='eval')
    transform(tree, DictUnpackingTransformer)
    assert to_str(tree).strip() == '_py_backwards_merge_dicts([{1: 1}, {3: 3}], {2: 2}, {4: 4})'

# Generated at 2022-06-23 22:40:39.196279
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("")
    ir = DictUnpackingTransformer().visit(module)
    expected = ast.parse("def _py_backwards_merge_dicts(dicts): result = {} for dict_ in dicts:result.update(dict_)return result\n")
    assert ast.dump(ir) == ast.dump(expected)

# Generated at 2022-06-23 22:40:40.934267
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor

    source = """
data = {1: 2, 3: 4, **{5: 6, 7: 8}}
"""

# Generated at 2022-06-23 22:40:46.548669
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:40:50.814755
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.make_tree import make_tree
    from ..utils.check_tree import check_tree
    from ..utils.pytree import PyTree

    # Without changing tree
    tree = make_tree('''
        {1: a}
        {1: a, 2: b}
        {1: a, **{}}
        {1: a, 2: b, **{}}
    ''')
    check_tree(DictUnpackingTransformer().visit(tree), '''
        {1: a}
        {1: a, 2: b}
        {1: a, **{}}
        {1: a, 2: b, **{}}
    ''')

    # With changing tree

# Generated at 2022-06-23 22:40:52.954667
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = 'a = {1: 1, **dict_a, 2: 2, **dict_b}'

# Generated at 2022-06-23 22:40:59.971616
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import get_node, get_subnode
    from ..utils.test_utils import assert_equal_nodes
    from ..utils.test_utils import print_nodes

    node = get_node("""\
        {1: 1, 2: 2, 3: 3, **{4: 4}, **{5: 5}}
        """)

    print_nodes(node)

    result = DictUnpackingTransformer().visit(node)

    expected = get_subnode("""\
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}, {4: 4}, {5: 5}])
        """)

    print_nodes(result)

    assert_equal_nodes(result, expected)

# Generated at 2022-06-23 22:41:10.139110
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('''\
        {'a': 'a',
        **dict_a,
        'c': 'c',
         **dict_b}
        ''')

# Generated at 2022-06-23 22:41:14.807580
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Vars: Do not care
    # Methods:
    #     * __init__()
    #         * Input: nothing
    #         * Output: nothing
    #         * Side Effects: nothing
    
    transformer = DictUnpackingTransformer()
    assert isinstance(transformer, BaseNodeTransformer)



# Generated at 2022-06-23 22:41:20.080376
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Check the visit_Module method of class DictUnpackingTransformer."""
    from .utils import round_trip
    from .py34_test_data import cases as test_cases

    for source in test_cases:
        tree = round_trip(source)
        DictUnpackingTransformer().visit(tree)
        DictUnpackingTransformer().visit(tree)  # second time for testing
        assert isinstance(tree, ast.Module)

# Generated at 2022-06-23 22:41:26.383966
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse("""{**x}""")
    assert repr(DictUnpackingTransformer().visit(module)) == \
        "Module(body=(Expr(value=Call(func=Name(id='_py_backwards_merge_dicts', ctx=Load()), args=(List(elts=(Call(func=Name(id='dict', ctx=Load()), args=(Name(id='x', ctx=Load()),), keywords=()),),)), keywords=())),))"  # noqa

# Generated at 2022-06-23 22:41:31.035676
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from typed_ast.transforms import DictUnpackingTransformer as TP
    node = ast.Dict(keys=[None, None, ast.Name(id='a')],
                    values=[ast.Num(1), ast.Num(2), ast.Num(3)])

# Generated at 2022-06-23 22:41:38.515047
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from pyshared.utils.compile_source import compile_ast
    source = """
        {1: 1, **{2: 2}}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], {2: 2})
    """
    node = parse(source)
    m = DictUnpackingTransformer()
    m.visit(node)
    actual = compile_ast(node, filename="<ast>")
    assert actual.strip() == expected.strip()

# Generated at 2022-06-23 22:41:43.090818
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse(textwrap.dedent('''\
        def func():
            {1: 1, **dict_a}
    '''))
    expected = ast.parse(textwrap.dedent('''\
        def _py_backwards_merge_dicts(dicts): pass
        def func():
            _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''))
    DictUnpackingTransformer.run(tree)
    assert ast.dump(tree) == ast.dump(expected)


# Generated at 2022-06-23 22:41:49.734255
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast

    # Simple
    module = ast.parse('{1:1, **{"1": "1"}}')

# Generated at 2022-06-23 22:41:50.689086
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()



# Generated at 2022-06-23 22:41:51.671158
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:52.233007
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:57.865516
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    class MockTree:
        def insert(self, index, node):
            pass

    dummy_tree = MockTree()

    transformer = DictUnpackingTransformer(dummy_tree)
    assert transformer._split_by_None([(None, 1), (2, 3), (None, 4)]) == [[2, 3], 4]
    assert transformer._split_by_None([(1, 2), (3, 4), (None, 5)]) == [[(1, 2), (3, 4)], 5]

# Generated at 2022-06-23 22:42:05.938785
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    from ..utils.snippet import snippet
    from ..utils.ast_yield import ast_yield
    from ..transformers.dict_unpacking import DictUnpackingTransformer

    code = dedent('''
    def foo():
        {1: 2, 3: 4, **{5: 6, 7: 8}}
    ''')
    expected_code = dedent('''
    def foo():
        _py_backwards_merge_dicts([{1: 2, 3: 4}], {5: 6, 7: 8})
    ''')
    expected_ast = list(ast_yield(snippet(expected_code)))[0]
    result_ast = DictUnpackingTransformer().visit(snippet(code))
    assert result_ast == expected

# Generated at 2022-06-23 22:42:10.248889
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '{1: 1, **dict_a}'
    ast_obj = ast.parse(source, mode='eval')
    expected_ast = ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)', mode='eval')
    result_ast = DictUnpackingTransformer().visit(ast_obj)
    assert expected_ast == result_ast



# Generated at 2022-06-23 22:42:17.781832
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert DictUnpackingTransformer().visit(
        ast.parse('dict(a=1, **dict_a)')
    ) == ast.parse('_py_backwards_merge_dicts([dict(a=1)], dict_a)')
    assert DictUnpackingTransformer().visit(
        ast.parse('{a: 1, **dict_a}')
    ) == ast.parse('_py_backwards_merge_dicts([{a: 1}], dict_a)')
    assert DictUnpackingTransformer().visit(
        ast.parse('dict(a=1, **dict_a, **dict_b)')
    ) == ast.parse('_py_backwards_merge_dicts([dict(a=1)], dict_a, dict_b)')
    assert D

# Generated at 2022-06-23 22:42:19.069208
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dut = DictUnpackingTransformer()
    assert set(dut.target) == {3, 4}

# Generated at 2022-06-23 22:42:24.498446
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astor import dump
    from ..utils.testing import assert_source_equal, assert_tree_equal
    source = '''
{a: b, **c}
{**c, a: b}
{1: 2, 3: 4, **c}
{**c, 1: 2, 3: 4}
{**c}
    '''
    tree = ast.parse(source)

# Generated at 2022-06-23 22:42:35.125013
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    from typed_astunparse import unparse as astunparse
    from .test_base import BaseNodeTransformerTestCase

    class TestVisitor(BaseNodeTransformerTestCase):
        TRANSFORMER = DictUnpackingTransformer.from_version(3, 4)

        def test_simple(self):
            tree = self.parse(dedent('''\
                {1: 2, **a, **b}'''))

            self.assertTreeEqual(tree, '''\
                _py_backwards_merge_dicts([{1: 2}], a, b)''')


# Generated at 2022-06-23 22:42:36.586478
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tr = DictUnpackingTransformer()
    assert 1 == 2

# Generated at 2022-06-23 22:42:38.308750
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(())


# Generated at 2022-06-23 22:42:47.561192
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:42:58.985710
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:43:03.441575
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import ast_from_snippet

    code = '''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    '''

    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, dict_b, {3: 3}])
    '''

    expected_ast = ast_from_snippet(expected)
    actual_ast = ast_from_snippet(code, [DictUnpackingTransformer])
    assert expected_ast.body[0].value.args[0].elts == actual_ast.body[0].value.args[0].elts


# Generated at 2022-06-23 22:43:10.535871
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.transform_test_helper import transform_test_helper

    source_1 = """
    {1:1, 2:2, **{3:3}, **{4:4}, 5:5}
    """

    expected_1 = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 5: 5}], {3: 3}, {4: 4})
    """

    transform_test_helper(DictUnpackingTransformer, source_1, expected_1)

# Generated at 2022-06-23 22:43:18.339536
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = parse('{1:1}')
    tree_new = DictUnpackingTransformer().visit(tree)
    tree_compare = parse('\n'
        'from typed_ast import ast3 as ast\n'
        '\n'
        'def _py_backwards_merge_dicts(dicts):\n'
        '    result = {}\n'
        '    for dict_ in dicts:\n'
        '        result.update(dict_)\n'
        '    return result\n'
        '{1: 1}\n'
        '')
    assert compare_ast(tree_new, tree_compare) == True


# Generated at 2022-06-23 22:43:25.926950
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def transform(code: str) -> ast.AST:
        node = ast.parse(code)
        DictUnpackingTransformer().visit(node)  # type: ignore
        return node


# Generated at 2022-06-23 22:43:36.471792
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .helper import assert_transformation


# Generated at 2022-06-23 22:43:37.452028
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()

# Generated at 2022-06-23 22:43:44.915409
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    source = """
    {1: 1, **a, None, b, c, **d, e}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}, a, b, {c: c}, d, {e: e}])
    """

    node = ast.parse(source)
    result = DictUnpackingTransformer().visit(node)
    result = astor.to_source(result, indent_with=' ' * 4).strip()
    assert result == expected.strip()

# Generated at 2022-06-23 22:43:46.806466
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()

# Generated at 2022-06-23 22:43:54.064096
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse

    source = astunparse.unparse(ast.parse("""
        def test():
            {1: 2, **a, **b, 3: 4}
    """))
    expected = """
        def test():
            _py_backwards_merge_dicts([{1: 2, 3: 4}], a, b)
    """

    node = ast.parse(source)  # type: ast.Module
    DictUnpackingTransformer().visit(node)
    result = astunparse.unparse(node)

    assert result == expected

# Generated at 2022-06-23 22:43:55.317194
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-23 22:43:58.778979
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import BaseNodeTransformer
    DictUnpackingTransformer(None)
    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:43:59.392767
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert True

# Generated at 2022-06-23 22:44:00.536968
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass


# Generated at 2022-06-23 22:44:01.133991
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): pass  # For PyCharm

# Generated at 2022-06-23 22:44:08.458689
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.fake_ast import get_fake_ast

    # Check that transformer returns the same ast if there is no dict unpacking
    fake_ast = get_fake_ast()
    visitor = DictUnpackingTransformer()
    assert visitor.visit(fake_ast) == fake_ast

    # Check that transformer inserts function at the beggining of the module
    fake_ast = get_fake_ast(body=[
        ast.Expr(value=ast.Dict(keys=[None, ast.Name(id='a')], values=[
            ast.Num(n=1), ast.Num(n=2)])),
        ast.Expr(value=ast.Str(s='q'))])
    visitor = DictUnpackingTransformer()
    result = visitor.visit(fake_ast)

# Generated at 2022-06-23 22:44:17.789755
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test import assert_ast
    from . import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code, '3')
    tree = DictUnpackingTransformer().visit(tree)
    assert_ast(tree, expected)

# Generated at 2022-06-23 22:44:19.984694
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    body = merge_dicts.get_body()
    assert len(body) == 1
    module = ast.parse("{1: 2, 'a': 3, **dict_a, **dict_b}")
    DictUnpackingTransformer(module)
    assert not hasattr(DictUnpackingTransformer, '_tree_changed')

# Generated at 2022-06-23 22:44:29.584026
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree_compare import assert_ast_equal
    from ..utils.source import dedent_source
    from ..utils.snippet import snippet
    import astor

    node = ast.parse(dedent_source("""
        {1: 1, 2: 2, **a, 3: 3, 4: 4, **b}
    """)).body[0].value


# Generated at 2022-06-23 22:44:39.259738
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict1 = ast.parse("""{1: 1, 2: 2}""").body[0].value
    dict2 = ast.parse("""{3: 3, **{4: 4}}""").body[0].value
    dict3 = ast.parse("""{5: 5, **{6: 6}, 7: 7}""").body[0].value
    dict4 = ast.parse("""{8: 8, 9: 9, **{10: 10}, 11: 11, 12: 12}""").body[0].value
    transformer = DictUnpackingTransformer()
    assert transformer.visit(dict1) == ast.parse("""{1: 1, 2: 2}""").body[0].value

# Generated at 2022-06-23 22:44:47.742282
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    x = ast.parse(
        """
        {1: 1, **{1: 1, **{1: 1}}}
        """)
    DictUnpackingTransformer().visit(x)

# Generated at 2022-06-23 22:44:57.310442
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    from .base import BaseNodeTransformerTest

    code = '''
        {1: 2, **a, 3: 4, **b}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        def _py_backwards_merge_dicts([{(1, 2)}, a, {(3, 4)}, b])
    '''
    expected_ast = ast.parse(expected)  # type: ignore

    class Test(BaseNodeTransformerTest):
        TRANSFORMER = DictUnpackingTransformer
        NODE = ast.Module

    result_ast = Test().test(code)

    # We're comparing AST's

# Generated at 2022-06-23 22:45:07.450492
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Example 1:
    #     {1: 1, **{2: 2, 3: 3}}
    # ==>
    #     _py_backwards_merge_dicts([{1: 1}], {2: 2, 3: 3})
    expr = ast.parse('{1: 1, **{2: 2, 3: 3}}').body[0]
    result = ast.Call(
        func  = ast.Name(id='_py_backwards_merge_dicts'),
        args  = [ast.List(elts=[ast.Dict(keys=[ast.Num(n=1)],
                                        values=[ast.Num(n=1)])],
                          ctx=ast.Load())],
        keywords=[],
        ctx=ast.Load())
    assert DictUnpackingTransformer.vis

# Generated at 2022-06-23 22:45:14.098532
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast

    # noinspection PyUnresolvedReferences
    assert_equal_ast(
        '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        x = {1: 1, **a}
        ''',
        '''
        x = _py_backwards_merge_dicts([{1: 1}], a)
        ''')

# Generated at 2022-06-23 22:45:25.009591
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:45:28.018437
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import AstBuilder
    from .test_visitor import FakeTransformer
    builder = AstBuilder()

# Generated at 2022-06-23 22:45:34.319535
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    module = ast.parse('{1: 1, **a}')
    transformed = transformer.visit(module)
    assert transformer.tree_changed
    assert ast.dump(transformed, include_attributes=False) == textwrap.dedent('''\
    import ast
    import sys
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    {1: 1, **_py_backwards_merge_dicts([{1: 1}], a)}''')

# Generated at 2022-06-23 22:45:35.545233
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:45:36.529490
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:45:37.479849
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer((3, 4)).target == (3, 4)



# Generated at 2022-06-23 22:45:46.300833
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.fixtures import target_module
    import typed_ast.ast3 as ast
    source = """
    {1: 2, 3: 3.14, **dict_a, 5: 5.0, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 2, 3: 3.14}, dict_a, {5: 5.0}], dict_b})
    """
    tree = target_module(source, 'dict_a', 'dict_b')
    DictUnpackingTransformer.run(tree)
    assert ast.dump(tree) == expected

################################################################################
# Class DefTransformer                                                         #
################################################################################


# Generated at 2022-06-23 22:45:56.161370
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from src.compat.ast import Module
    from src.compat.typing import NamedTuple
    from .test_functions import sample_code_1, sample_code_2


# Generated at 2022-06-23 22:46:03.551326
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    d = ast.parse("""{1: 1, 2: 2, 3: 3, None: x, None: y, 4: 4}""")
    assert transformer.visit(d) == ast.parse("""
    _py_backwards_merge_dicts([
        {1: 1,
         2: 2,
         3: 3},
        x,
        y],
        {4: 4})"""
    )
    assert transformer.tree_changed is True  # type: ignore

# Generated at 2022-06-23 22:46:13.898028
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    transformer = DictUnpackingTransformer()

    code = '''a = {1: 2}'''
    module = ast.parse(code)
    module = transformer.visit(module)

# Generated at 2022-06-23 22:46:21.784971
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    node = ast.parse('{**a}')
    preprocessed_node = transformer.visit(node)
    assert transformer._tree_changed

# Generated at 2022-06-23 22:46:32.041970
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTestCase
    from ..utils.tree import ast_to_source

    class DictUnpackingTestCase(BaseNodeTestCase):
        def test_no_dict_unpack(self):
            input_code = '{1: 1, 2: 2}'
            output_code = '{1: 1, 2: 2}'

            self._test(input_code, output_code)

        def test_simple_dict_unpack(self):
            input_code = '{1: 1, **dict_a}'
            output_code = '_py_backwards_merge_dicts([{1: 1}], dict_a)'

            self._test(input_code, output_code)


# Generated at 2022-06-23 22:46:39.445874
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    mod = ast.parse('{1: 1, **dict_a}')
    result = transformer.visit(mod)
    assert transformer.tree_changed

# Generated at 2022-06-23 22:46:50.042460
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..testing import assert_textual_representation_of
    assert_textual_representation_of(DictUnpackingTransformer, '''
    def func():
        return {1: 1, 2: 2}
        return {1: 1, 2: 2, **{'x': 3}}
        return {1: 1, 2: 2, **{'x': 3}, **{'y': 4}}
        return {**{'x': 3}, **{'y': 4}}
        return {1: 1, 2: 2, **{'x': 3}}
        return {1: 1, 2: 2, **{'x': 3}, **{'y': 4}}
        return {**{'x': 3}, **{'y': 4}}
    ''')

# Generated at 2022-06-23 22:46:56.270242
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    def _test(raw_code: str, expected_code: str) -> None:
        tree = ast.parse(raw_code)
        transformer = DictUnpackingTransformer()
        transformer.visit(tree)
        actual_code = astor.to_source(tree)
        assert actual_code == expected_code
    
    _test('{1: 2}', '{1: 2}')
    _test('{1: 2, 3: 4}', '{1: 2, 3: 4}')

# Generated at 2022-06-23 22:47:04.642975
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:47:15.153439
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    iss = inspect.currentframe().f_code.co_name
    _ = """
    x = [1, 2, 3]
    y = {1, 2, 3}
    z = {'a' * 10: x, **y}
    """
    tree = ast.parse(_)
    # print(ast.dump(tree))
    assert str(tree) == _
    assert eval(compile(tree, '<test>', mode='exec')) is None
    assert hasattr(tree, '_tree_changed') is False

    tr = DictUnpackingTransformer()
    tr.visit(tree)
    # print(ast.dump(tree))

# Generated at 2022-06-23 22:47:23.007316
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    code = '''
    d = {**d1, 8: 8, **d2}
    '''
    new_module = transformer.visit(ast.parse(code))
    assert len(new_module.body) == 2
    call = new_module.body[1].value
    assert isinstance(call.args[0], ast.Call)
    assert call.args[0].func.id == 'dict'
    assert call.args[0].args == [ast.Dict(
        keys=[ast.Num(8)], values=[ast.Num(8)]
    )]

# Generated at 2022-06-23 22:47:28.156610
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import Dict, Name, List, Call, Tuple, Num, Str, Attribute, keyword, Load, Subscript, Index, Store, AugLoad, AugStore, Del, Param, parse
    node = parse('{1: 1, **x}')
    transformer = DictUnpackingTransformer()
    transformer.visit(node)
    expected = parse('''\
_py_backwards_merge_dicts([{1: 1}], x)
''')
    assert node == expected


# Generated at 2022-06-23 22:47:29.846603
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_astunparse import unparse

    new_node = DictUnpackingTransformer().visit(
        ast.parse("{1: 1, **{'a': 2}}"))


# Generated at 2022-06-23 22:47:35.553526
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    src = r"""
    {1: 1, 2: 2}
    """
    expected_src = r"""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    {1: 1, 2: 2}
    """

    node = ast.parse(src)  # type: ignore
    node = DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == ast.dump(ast.parse(expected_src))  # type: ignore

