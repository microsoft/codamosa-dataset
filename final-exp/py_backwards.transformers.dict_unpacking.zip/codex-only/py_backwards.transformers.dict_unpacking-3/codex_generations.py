

# Generated at 2022-06-23 22:37:39.958439
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .testutils import assert_converted_code
    from ..utils.string import dedent

# Generated at 2022-06-23 22:37:48.535992
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .visitor import CodeCollector

    merge_dicts_body = merge_dicts.get_body()[0]

    c = CodeCollector(DictUnpackingTransformer())
    c.collect_code('''
    {1: 1, **a}
    {1: 1}
    ''')

# Generated at 2022-06-23 22:37:52.503723
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_base import transform, run_transformer_tests

    def test_case(code: str, expected: str) -> None:
        tree = transform(code, DictUnpackingTransformer)
        assert expected == tree.body[0].name

    run_transformer_tests(DictUnpackingTransformer, 'visit_Module', test_case)



# Generated at 2022-06-23 22:38:03.636477
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    before = """
    {1: 1, **a}
    """
    after_not_changed = """
    {1: 1, **a}
    """
    after = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    _py_backwards_merge_dicts([{1: 1}], a)
    """
    before_node = ast.parse(before)
    after_node = ast.parse(after)
    after_not_changed_node = ast.parse(after_not_changed)
    
    assert transformer.visit(before_node) == after_node

# Generated at 2022-06-23 22:38:10.373952
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    result = transformer.visit(ast.parse("""{1: 1, **dict_a}"""))
    #print(ast.dump(result))
    assert ast.dump(result) == """
Module(body=[
    Assign(targets=[Name(id='_py_backwards_merge_dicts', ctx=Store())], value=<snippet>, type_comment=None),
    Expr(value=Call(func=Name(id='_py_backwards_merge_dicts', ctx=Load()), args=[List(elts=[
        Dict(keys=[Num(n=1)], values=[Num(n=1)]),
        Name(id='dict_a', ctx=Load())
    ])], keywords=[]))
])
"""

# Generated at 2022-06-23 22:38:17.952963
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    program = """{**sub_dict, 1: 1, 2: 2, **sub_dict_2}"""
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1, 2: 2}], sub_dict, sub_dict_2)
    """.lstrip()
    assert run_transformer(program, DictUnpackingTransformer) == expected

# Generated at 2022-06-23 22:38:26.066449
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.test_utils import check_same
    from .utils import get_str
    from ..version import get_unicode_literal_node

    code_before = """
        {
            1: lambda: None,
            **C.DICT_A,
            **DICT_B
        }
    """

    code_after = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{""" + get_unicode_literal_node("1") + """: lambda: None}, C.DICT_A, DICT_B])
    """

    node = get_str(code_before)
    expected = get_str

# Generated at 2022-06-23 22:38:32.997882
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import Dict

    node = ast.parse(
        """
        {'a': 'b', 1: 2, **d}
        """
    )

    assert DictUnpackingTransformer().visit(node) == ast.parse(
        """
        _py_backwards_merge_dicts([{'a': 'b', 1: 2}], d)
        """
    )

# Generated at 2022-06-23 22:38:38.984878
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    program = """
    {}
    """
    expected = """
    {}
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    """
    assert DictUnpackingTransformer().visit(ast.parse(program)) == ast.parse(expected)


# Generated at 2022-06-23 22:38:45.117111
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    node = ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=2)],
                    values=[ast.Num(n=1), ast.Dict(keys=[], values=[]), ast.Num(n=2)])
    transformer = DictUnpackingTransformer()
    call = transformer.visit(node)
    assert type(call) == ast.Call
    assert call.func.id == '_py_backwards_merge_dicts'
    assert [arg.keys[0].n for arg in call.args[0].elts] == [1, 2]
    assert call.args[1].keys == []

# Generated at 2022-06-23 22:38:50.897649
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ... import ast3 as ast
    transformer = DictUnpackingTransformer()
    result = transformer.visit(ast.parse('dict_a = {1: 1, **dict_b, 2: 2}'))
    result_src = ast.unparse(result).strip()
    expected_src = 'dict_a = _py_backwards_merge_dicts(' \
                   '[{1:1}, dict_b, {2:2}])'.strip()
    assert result_src == expected_src

# Generated at 2022-06-23 22:38:51.990820
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:38:57.074272
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    program = ast.parse('def f(): return {1: 1, 2: 2}')
    obj = DictUnpackingTransformer()
    obj.visit(program)

    assert len(program.body) == 3
    assert isinstance(program.body[1], ast.FunctionDef)
    assert isinstance(program.body[2], ast.FunctionDef)

# Generated at 2022-06-23 22:39:03.040560
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    DICT = {'a': 1, **{'b': 2, **{'c': 3}}, **{'d': 4}, 'e': 5}
    assert eval(ast.dump(DictUnpackingTransformer().visit(ast.parse(repr(DICT))))) == \
        {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}



# Generated at 2022-06-23 22:39:10.627168
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''
        {1: 1, **dict_a}
        '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
        '''
    actual = DictUnpackingTransformer().visit(ast.parse(code))
    assert_ast_equal(actual, ast.parse(expected))

# Generated at 2022-06-23 22:39:21.557353
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_syntax_tree

    code = """
        foo = {1: 1, None: _bar(), 3: (4, 5)}
        bar = 42
    """


# Generated at 2022-06-23 22:39:22.830672
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert not transformer._tree_changed
    assert transformer.target == (3, 4)

# Generated at 2022-06-23 22:39:23.624532
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)

# Generated at 2022-06-23 22:39:26.652208
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astunparse
    node = ast.parse("""
{d1['key']: 'value', **d2}
    """)

# Generated at 2022-06-23 22:39:28.025432
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): assert DictUnpackingTransformer(None)._tree_changed == False


# Generated at 2022-06-23 22:39:29.219769
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    _ = DictUnpackingTransformer()

# Generated at 2022-06-23 22:39:39.169028
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    class T(unittest.TestCase):
        def test_1(self):
            t = DictUnpackingTransformer()
            source = '''
            {1: 'a', 2:'b', **{3: 'c'}}
            '''
            tree = compile(source, '<test>', 'exec', ast.PyCF_ONLY_AST)

            t.visit(tree)

            self.assertEqual(t._tree_changed, True)
            self.assertEqual(tree.body[0].value.args[0].elts[0].keys, [])
            self.assertEqual(tree.body[0].value.args[0].elts[0].values, [])

# Generated at 2022-06-23 22:39:48.891469
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..pretty_print import to_source
    from ..transformers import TransformerSequence

    simple_dict = ast.Dict(keys=[], values=[])
    unpacked_dict = ast.Dict(keys=[None, None], values=[ast.Name(id='a'), ast.Name(id='b')])
    generated_dict = ast.Dict(keys=[ast.Num(1), ast.Num(2)], values=[ast.Name(id='a'), ast.Name(id='b')])
    unpacked_dict_with_keys = ast.Dict(keys=[ast.Num(1), None, ast.Num(2)], values=[ast.Name(id='a'), ast.Name(id='c'), ast.Name(id='b')])

    t = TransformerSequence(DictUnpackingTransformer())

# Generated at 2022-06-23 22:39:56.165151
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from ..transformer import InplaceASTCompiler
    from ..transformer_base import TransformerBase
    from ..utils.tree import print_ast
    from ..utils.type_analyzer import TypeAnalyzer
    from ..utils.type_analyzer import ensure_analyzed
    from .base import BaseNodeTransformer
    from .typing_transformer import TypingTransformer
    from .expression_unpacking_transformer import ExpressionUnpackingTransformer

    def _dict_unpacking(code: str) -> ast3.AST:
        """Compiles dict unpacking to in-place AST."""
        ast_ = ast3.parse(code)
        InplaceASTCompiler().visit(ast_)
        return ast_


# Generated at 2022-06-23 22:39:57.433376
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    s = '''\
{1: 1, **dict_a}
'''

# Generated at 2022-06-23 22:39:58.308238
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_instance = DictUnpackingTransformer()
    assert isinstance(test_instance, DictUnpackingTransformer)

# Generated at 2022-06-23 22:39:59.826586
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    unpacking = DictUnpackingTransformer()
    assert unpacking

# Generated at 2022-06-23 22:40:05.390404
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse("""
a = {1: 2}
b = {3: 4}
c = {5: 6}
""")
    DictUnpackingTransformer().visit(node)
    assert str(node) == """
_py_backwards_merge_dicts = None
a = {1: 2}
b = {3: 4}
c = {5: 6}
"""

# Generated at 2022-06-23 22:40:07.112353
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer.target == (3, 4)

# Generated at 2022-06-23 22:40:16.468533
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_node_equals, assert_tree_equals
    from ..testing import parse

    code = ("{1: 1, 2: 2, 3: 3, **{4: 4, 5: 5}, 6: 6, **{7: 7}, 8: 8, "
            "**{9: 9, 10: 10}}")
    node = parse(code, mode='eval')
    expected = ("{1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, "
                "10: 10}")

    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_node_equals(result, parse(expected, mode='eval'))

# Generated at 2022-06-23 22:40:24.786488
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_astunparse import unparse
    import ast
    import textwrap
    from .util import RoundTripChecker

    code = """\
    test = {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """

    expected = """\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    test = _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """

    tree = ast.parse(textwrap.dedent(code))
    tree = DictUnpackingTransformer().visit(tree)
    RoundTripChecker.check

# Generated at 2022-06-23 22:40:35.638668
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import run_test_function_with_compiler_quirks
    
    assert run_test_function_with_compiler_quirks(
        DictUnpackingTransformer,
        DictUnpackingTransformer._visit_Dict,
        input_src='{1:  1, **a}',
        expect_src='_py_merge_dicts([{1: 1}], a)',
        indent=False)

    assert run_test_function_with_compiler_quirks(
        DictUnpackingTransformer,
        DictUnpackingTransformer._visit_Dict,
        input_src='{**a, 1: 1}',
        expect_src='_py_merge_dicts([{1: 1}], a)',
        indent=False)


# Generated at 2022-06-23 22:40:43.374081
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    dict_ = ast.parse('{1: 1, **dict_a}', '<test>').body[0]
    result = transformer.visit(dict_)
    expected = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[
            ast.List(elts=[
                ast.Dict(keys=[]),
                ast.Name(id='dict_a')
            ])
        ],
        keywords=[])
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-23 22:40:53.588103
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typing import Any
    from .assertions import assert_node_equal

    expected_bodies = (
        [merge_dicts.get_body()],
        [merge_dicts.get_body()] * 3,
        [merge_dicts.get_body()] * 2,
    )
    for expected_body, expected in zip(expected_bodies, (
        'x = {1: 1, **dict_a, **dict_b}',
        'x = {1: 1, **dict_a, **dict_b, **dict_c}',
        'x = {**dict_a, **dict_b}',
    )):
        node = ast.parse(expected)

# Generated at 2022-06-23 22:40:56.577570
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse("{1: 1, **func(), **{2: 2}}").body[0].value
    assert isinstance(node, ast.Dict)  # type: ignore

    result = DictUnpackingTransformer().visit(node)
    assert isinstance(result, ast.Call)  # type: ignore

# Generated at 2022-06-23 22:41:02.604952
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..autofix_mapping import Mapping
    from .base import BaseNodeTransformerTest
    from .base import DEFAULT_OPTIONS

    class Test(BaseNodeTransformerTest):
        TRANSFORMER = DictUnpackingTransformer
        OPTIONS = DEFAULT_OPTIONS

    mapping, errors, _ = Test.transform_snippet(
        '''
        a = {1: 1, **d}
        ''')
    assert errors == 0


# Generated at 2022-06-23 22:41:06.645143
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils import get_targets
    class DUMaker(object):
        def __init__(self, *args):
            self.d = DictUnpackingTransformer(*args)
    targets = get_targets()
    DUMaker(targets)


test_DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:12.995957
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    module = ast.parse("{1: 2, **dict_a, 3: 4}")
    transformed = transformer.visit(module)

    assert multi_line_eq(normalize_ast(transformed), normalize_ast(
        """
        _py_backwards_merge_dicts([{1: 2}, dict_a, {3: 4}])
        """
    ))



# Generated at 2022-06-23 22:41:21.880748
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert [1, 2] == DictUnpackingTransformer()._split_by_None([(1, 2)])
    assert [[(1, 2)], 3, [(4, 5)]] \
           == DictUnpackingTransformer()._split_by_None([(1, 2), (None, 3), (4, 5)])
    assert [1, 2] == DictUnpackingTransformer()._split_by_None([(None, 1), (None, 2)])
    assert [1] == DictUnpackingTransformer()._split_by_None([(None, 1), (None, None)])
    assert [1] == DictUnpackingTransformer()._split_by_None([(None, 1), (None, None), (None, None)])

# Generated at 2022-06-23 22:41:32.767148
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast.ast3 as ast
    import astunparse
    import textwrap

    class MockVisitor(ast.NodeVisitor):
        def visit(self, node):
            if not isinstance(node, ast.AST):
                return False

            return ast.NodeVisitor.visit(self, node)

        def default_visit(self, node):
            for _, value in ast.iter_fields(node):
                self.visit(value)

    v = MockVisitor()

    for _ in DictUnpackingTransformer().visit(
            ast.parse(textwrap.dedent('''\
            {1: 1, 2: 2, **dict_a, **dict_b}
            '''))):
        v.visit(_)

    print(astunparse.unparse(_))

# Generated at 2022-06-23 22:41:34.687917
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert isinstance(transformer, BaseNodeTransformer)


# Generated at 2022-06-23 22:41:35.741960
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:37.343091
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:45.870415
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_base import transform
    from ..utils.tree import get_symbols

    @transform
    def f():
        x = {1: 1, 2: 2, **{1: 2}}

    assert not get_symbols(f)

    @transform
    def f1():
        x = {0: {1: 1, 2: 2, 3: 3}, **{1: 2}}

    assert not get_symbols(f1)

    @transform
    def f1():
        x = {0: {1: 1, **{2: 2}}, **{3: 3}}

    assert not get_symbols(f1)

    @transform
    def f2():
        x = {1: 1, **{**{1: 2}}}

    assert not get_symbols(f2)



# Generated at 2022-06-23 22:41:55.868884
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class V(DictUnpackingTransformer):
        pass

    source = '''
    {'a': 1, **{'b': 2, 'c': 3}}
    '''
    expected = '''
    _py_backwards_merge_dicts([{'a': 1}], {'b': 2, 'c': 3})
    '''
    node = ast.parse(source)
    result = V().visit(node)
    compare(result, expected)

    source = '''
    {'a': 1, **{'b': 2, 'c': 3}, **{'d': 4}}
    '''

# Generated at 2022-06-23 22:41:56.728209
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer

# Generated at 2022-06-23 22:41:57.589859
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:03.649941
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''
    def foo():
        items = [1,2,3]
        bar = {1: 2, 3: 4, **{x: x ** 2 for x in items}} # type: ignore
    '''
    expected = '''
    def foo():
        items = [1,2,3]
        bar = _py_backwards_merge_dicts([{1: 2, 3: 4}, dict((x, x ** 2) for x in items)]) # type: ignore
    '''
    module = ast.parse(source)
    module = DictUnpackingTransformer().visit(module)
    assert ast.dump(module) == expected

# Generated at 2022-06-23 22:42:04.663159
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:12.516505
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    class MockedDictUnpackingTransformer(DictUnpackingTransformer):
        def __init__(self):
            super().__init__()
            self._tree_changed = False

        def visit_Dict(self, node):
            return node

    code = """
        a = {1: 2, **{3: 4}}
        b = {1: 2, **{3: 4}}
    """
    tree = ast.parse(code)
    transformer = MockedDictUnpackingTransformer()
    transformer.visit(tree)
    assert not transformer._tree_changed

# Generated at 2022-06-23 22:42:16.426427
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_cases.test_DictUnpackingTransformer import test_DictUnpackingTransformer_visit_Module as test
    from ..test_utils import assert_programs_equal
    assert_programs_equal(DictUnpackingTransformer, test)


# Generated at 2022-06-23 22:42:24.148757
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    transformer = DictUnpackingTransformer()
    assert transformer.visit(
        ast.Dict(keys=[ast.Constant(1), None, ast.Constant(2)],
                 values=[ast.Constant(1), ast.Constant(2),
                         ast.Constant(3)])) == \
        ast.Call(func=ast.Name(id='_py_backwards_merge_dicts'),
                 args=[ast.List(elts=[
                     ast.Dict(keys=[ast.Constant(1)], values=[ast.Constant(1)]),
                     ast.Constant(2),
                     ast.Dict(keys=[ast.Constant(2)], values=[ast.Constant(3)]),
                 ])],
                 keywords=[])

# Generated at 2022-06-23 22:42:26.555280
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_astunparse
    code = """
d = {1: 2, 3: 4}
"""
    result = DictUnpackingTransformer().visit(ast.parse(code))

# Generated at 2022-06-23 22:42:33.205714
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astunparse import unparse
    from .utils import get_node

    node = get_node(
        """
        {1: 1, 2: 2, None: {1: 1}, 3: 3}
        """
    )
    node = DictUnpackingTransformer().visit(node)
    expected = (
        """\
        """
    )
    print(unparse(node))
    assert unparse(node) == expected

# Generated at 2022-06-23 22:42:39.764208
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    with TemporaryDirectory() as directory:
        filename = 'input.py'
        path_input_file = directory / filename

        input_code = \
            """
                {1: 1, 2: 2}
            """

        with path_input_file.open('w', encoding='utf-8') as file:
            file.write(input_code)

        result = transform_file(filename, directory)
        assert input_code == result



# Generated at 2022-06-23 22:42:48.212636
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module: ast.Module = ast.parse('''
    {1: 1}
    ''')
    transformer = DictUnpackingTransformer()
    module = transformer.visit(module)
    assert transformer._tree_changed

    assert isinstance(module, ast.Module)
    assert len(module.body) == 2
    assert module.body

    func_def = module.body[0]
    assert isinstance(func_def, ast.FunctionDef)
    assert func_def.name == '_py_backwards_merge_dicts'

    dict_ = module.body[1]
    assert isinstance(dict_, ast.Expr)
    assert isinstance(dict_.value, ast.Dict)
    assert len(dict_.value.keys) == 1

# Generated at 2022-06-23 22:42:58.285622
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = '''\
    x = {None: 1, "two": 2, None: 3, None: 4, "five": 5}
    '''
    expected = '''\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    x = _py_backwards_merge_dicts([{'two': 2, 'five': 5}], {1}, {3}, {4})
    '''
    tr = DictUnpackingTransformer()
    tr.visit(ast.parse(source))
    assert expected == tr.dumps()  # type: ignore

# Generated at 2022-06-23 22:43:08.193282
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('a')
    body = tree.body
    module_transformer = DictUnpackingTransformer()
    module_transformer.visit(tree)
    assert module_transformer._tree_changed == False
    assert body == tree.body
    tree = ast.parse('{1: 2, 3: 4 , **{5: 6}}')
    body = tree.body
    module_transformer = DictUnpackingTransformer()
    module_transformer.visit(tree)
    assert module_transformer._tree_changed == True
    assert body == tree.body
    tree = ast.parse('{**{1:2}, 3: 4}')
    body = tree.body
    module_transformer = DictUnpackingTransformer()
    module_transformer.visit(tree)
    assert module_

# Generated at 2022-06-23 22:43:12.503317
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    merge_dicts_body = '\n'.join(line.strip() for line in merge_dicts.get_body())
    assert DictUnpackingTransformer(None).visit_Module(
        ast.parse('''
x = {1: 1, **dict_a}
''')) == ast.parse(f'''
{merge_dicts_body}
x = _py_backwards_merge_dicts([{{1: 1}}], dict_a)
''')


# Generated at 2022-06-23 22:43:13.340773
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast as pyast


# Generated at 2022-06-23 22:43:20.288852
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from . import check_transformer
    from astor.codegen import to_source
    from .visitor_test_mixins import FunctionTypeVisitorTestMixIn
    from .visitor_test_mixins import DictUnpackingVisitorTestMixIn
    from ..utils.tree import get_assign_target
    from ..utils.tree import get_assign_value
    from ..utils.tree import make_call
    from ..utils.tree import make_kwarg
    from ..utils.tree import make_name
    from ..utils.tree import make_assign
    from ..utils.tree import make_function
    from ..utils.tree import get_function_body
    from ..utils.tree import get_function_args


# Generated at 2022-06-23 22:43:24.361589
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{}')

    DictUnpackingTransformer().visit(module)

    body = module.body
    expected_body = [
        merge_dicts.get_body(),
        ast.Expr(value=ast.Dict(
            keys=[], values=[],
        )),
    ]
    assert body == expected_body


# Generated at 2022-06-23 22:43:25.927622
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:43:33.718926
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .. import compile
    test = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    transformed = compile(test, __name__ + '.DictUnpackingTransformer')
    assert_equal(transformed, expected)

# Generated at 2022-06-23 22:43:39.452549
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..base import CompilerContext
    from ..utils.tree import ast_to_src
    from .test_assertions import assert_equivalent_asts, assert_src_in_tree

    # Setup
    cc = CompilerContext()
    cc.add_transformer(DictUnpackingTransformer())
    src = '''\
{1: 2, **{3: 4}}
'''

# Generated at 2022-06-23 22:43:44.696217
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_func as stf

    transform = DictUnpackingTransformer().visit
    source = '{1:1, 2:2, **dict_a, 3:3, **dict_b, 4:4}'
    ast_ = sta(source)
    result_ast = transform(ast_)
    result = stf(result_ast)()
    assert result == {1: 1, 2: 2, 3: 3, 4: 4}

# Generated at 2022-06-23 22:43:54.566291
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert eval(
        ast.dump(
            DictUnpackingTransformer().visit(
                ast.parse("{1: 1, **dict_a}")),
            include_attributes=True
        )
    ) == {1: 1}

    assert eval(
        ast.dump(
            DictUnpackingTransformer().visit(
                ast.parse("{1: 1, **dict_a, 3: 3}")),
            include_attributes=True
        )
    ) == {1: 1, 3: 3}

    assert eval(
        ast.dump(
            DictUnpackingTransformer().visit(
                ast.parse("{1: 1, **dict_a, **dict_b}")),
            include_attributes=True
        )
    ) == {1: 1}

    assert eval

# Generated at 2022-06-23 22:44:03.426677
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..test_utils import assert_same_ast
    from ..test_utils import parse
    from ..test_utils import dump_ast

    source = """{1: 1, 2: 2, **dict_a, 3: 3, **dict_b}"""
    expected = """\
_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
"""

    module = parse(source)
    result = DictUnpackingTransformer().visit(module)  # type: ignore
    assert_same_ast(dump_ast(result), expected)



# Generated at 2022-06-23 22:44:12.814493
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_compiled_correctly


# Generated at 2022-06-23 22:44:14.655477
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert isinstance(t, BaseNodeTransformer)

# Generated at 2022-06-23 22:44:20.318855
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def assert_transformed_to(before, after):

        after = ast.parse(after)  # type: ignore
        before = ast.parse(before, mode='exec')  # type: ignore

        transformer = DictUnpackingTransformer()
        module = transformer.visit(before)  # type: ignore
        assert transformer._tree_changed
        assert module == after

    assert_transformed_to('_ = {1: 1}', '_ = {1: 1}')
    assert_transformed_to('_ = {1: 1, **{2: 2}}', "_ = _py_backwards_merge_dicts([{1: 1}], {2: 2})")

# Generated at 2022-06-23 22:44:29.770504
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
d = {1: 1, **{2: 4}, 3: 4, **{5: 6}}
    """
    t = ast.parse(code)

# Generated at 2022-06-23 22:44:37.094992
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    merged_dicts_func = merge_dicts.get_body()  # type: ignore
    code = '''{1: 1, **dict_a}'''
    result = '''def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result

_py_backwards_merge_dicts([{1: 1}], dict_a)'''
    assert str(DictUnpackingTransformer().visit(ast.parse(code))) == result

# Generated at 2022-06-23 22:44:39.182633
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None


# Generated at 2022-06-23 22:44:47.742294
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_source = '{1: 1, **dict_a}'
    returned_module_source = 'def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n\n{1: 1, **dict_a}'
    try:
        import typed_ast.ast3 as ast
    except ImportError:
        import ast
    from typed_ast import ast3 as typed_ast

    test_module = ast.parse(module_source)

    transformer = DictUnpackingTransformer()
    transformed_module = transformer.visit(test_module)

    module_to_source = typed_ast.ast3.ASTtoSource(transformed_module)

    source = module_to_source.vis

# Generated at 2022-06-23 22:44:48.769527
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:57.921682
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    class TestDictUnpackingTransformer(DictUnpackingTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            super().visit_Module(node)
            for index, node in enumerate(self.body):
                if isinstance(node, ast.ImportFrom):
                    self.body[index] = ast.Expr(value=node)

        def _split_by_None(self, pairs: Iterable[Pair]) -> Splitted:
            """Splits pairs to lists separated by dict unpacking statements."""
            result = [[]]  # type: Splitted
            for key, value in pairs:
                if key is None:
                    result.append(value)
                    result.append([])
                else:
                    assert isinstance(result[-1], list)

# Generated at 2022-06-23 22:45:02.970274
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from pytest import raises
    from typed_ast.ast3 import parse
    
    node = parse('def f():\n    pass\n')
    x = DictUnpackingTransformer()
    try:
        x.visit(node)
    except:
        pass
    else:
        assert False
    
    # todo: check module body


# Generated at 2022-06-23 22:45:09.059702
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class MyTransformer(DictUnpackingTransformer):
        def _prepare_splitted(self, splitted: Splitted) \
                -> Iterable[Union[ast.Call, ast.Dict]]:
            for group in splitted:
                if not isinstance(group, list):
                    yield group
                else:
                    if group:
                        yield ast.Dict(keys=[key for key, _ in group],
                                       values=[value for _, value in group])
                    else:
                        yield ast.Call(
                            func=ast.Name(id='dict'),
                            args=[],
                            keywords=[])

    source = '{1: 2, 11: 2, 45: 2, None: 4, None: 5, None: 6, 4: 2}'

# Generated at 2022-06-23 22:45:14.931250
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTransformerTestCase
    from .test_visitor import assert_equal_ast

    class TestCase(BaseNodeTransformerTestCase):
        node = ast.parse('{1: 1, **dict_a}').body[0]
        expected_node = ast.parse(
            '_py_backwards_merge_dicts([{1: 1}], [dict_a])'
        ).body[0]

    assert_equal_ast(TestCase)

# Generated at 2022-06-23 22:45:23.069310
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ast import parse, dump
    from ..utils.source import source
    from ..transform import normalize_indentation

    node = parse(source('''
        {1: 1, **dict_a, **dict_b}
        ''')).body[0]
    transformed = DictUnpackingTransformer().visit(node)  # type: ignore
    assert dump(transformed) == normalize_indentation('''
        _py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)
        ''')



# Generated at 2022-06-23 22:45:24.132152
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass


# Generated at 2022-06-23 22:45:29.428957
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert DictUnpackingTransformer.__doc__
    assert DictUnpackingTransformer.visit_Module.__doc__
    assert DictUnpackingTransformer.visit_Dict.__doc__
    assert isinstance(transformer, ast.NodeTransformer)
    assert transformer.target == (3, 4)
    assert transformer._tree_changed is False

# Generated at 2022-06-23 22:45:32.078927
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse("{1: 2, **dict_a, 2: 3}")
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 22:45:38.509590
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .helpers import assert_transformed

    module_ast = ast.parse('{1: 1, **dict_a}')
    expected_1 = """{1: 1}"""
    expected_2 = """dict_a"""
    expected_3 = """_py_backwards_merge_dicts([{1: 1}], dict_a)"""

    assert_transformed(DictUnpackingTransformer, module_ast, expected_1, expected_2, expected_3)


# Generated at 2022-06-23 22:45:46.169745
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    instance = DictUnpackingTransformer()
    assert instance is not None

try:
    # Unit test for visit_Dict method of class DictUnpackingTransformer
    def test_visit_Dict():
        instance = DictUnpackingTransformer()
        parsed = ast.parse('{1: 1, **dict_a}')
        expected = ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')
        instance.visit(parsed)
        assert parsed.body[0].value.value == expected.body[0].value.value
except Exception as e:
    print(e)

# Generated at 2022-06-23 22:45:51.866198
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
    class X:
        def f(self):
            a = {1, 2, **{3, 4}}
    """
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    
    class X:
        def f(self):
            a = _py_backwards_merge_dicts([{1, 2}], {3, 4})
    """
    assert ast_equal(expected, tree)


# Generated at 2022-06-23 22:45:53.267090
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert c(DictUnpackingTransformer)

# Generated at 2022-06-23 22:46:03.757471
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3
    from .test_util import assert_testable_ast

    tree = """
    {1: 1, **dict_a}
    dict(**{1: 1, **dict_a})
    dict_z = {1: 1, **dict_a}
    dict_z.update(**{1: 1, **dict_a})
    """
    tree = typed_ast.ast3.parse(tree)
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 22:46:10.161288
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('{1: 1, **{2: 2}}')
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-23 22:46:12.808555
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    try:
        DictUnpackingTransformer()
    except:
        print('DictUnpackingTransformer is not callabe')
        raise
        

# Generated at 2022-06-23 22:46:20.991707
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3
    import textwrap
    from test_simple_transformer import tree_from_source, transform_from_source, visit_Module
    code = textwrap.dedent(
        '''\
        {1: 1, **dict_a}
        '''
    )
    module0 = tree_from_source(code)
    module1 = tree_from_source(code)
    transformer = transform_from_source(code)
    module2 = transformer.visit(module1)
    # assert module1 == module0
    assert module2 != module0
    assert module1 != module0
    assert module2 == module1
    visit_Module(transformer, module2, module0)
    assert module2 == module0


# Generated at 2022-06-23 22:46:29.030524
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    expected = ast.parse(
        '_py_backwards_merge_dicts([{1: 2}, 3], 4)')  # type: ignore

    given = ast.Dict([
        (ast.Num(1), ast.Num(2)),
        (None, ast.Num(3)),
        (None, ast.Num(4)),
    ])  # type: ignore

    transformer = DictUnpackingTransformer()
    actual = transformer.visit(given)
    assert ast.dump(expected, include_attributes=False) \
        == ast.dump(actual, include_attributes=False)

# Generated at 2022-06-23 22:46:37.460581
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    def check(before: str, after: str):
        node = ast.parse(before)
        DictUnpackingTransformer().visit(node)
        assert ast.dump(node) == after

    check('''
        {1: 1, 2: 2}
    ''', '''
        {1: 1, 2: 2}
    ''')

    check('''
        {1: 1, 2: 2, **{3: 3}}
    ''', '''
        _py_backwards_merge_dicts(
            [
                dict(
                    [
                        (1, 1),
                        (2, 2)
                    ]
                ),
                dict(
                    [
                        (3, 3)
                    ]
                )
            ]
        )
    ''')


# Generated at 2022-06-23 22:46:39.057503
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:46:42.171245
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert repr(t) in "<DictUnpackingTransformer '3.4'>"
    assert t.target == (3, 4)


# Generated at 2022-06-23 22:46:44.127258
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert isinstance(t, DictUnpackingTransformer)


# Generated at 2022-06-23 22:46:49.183477
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    d = ast.parse("{1: 1, **{'a': 2}}").body[0].value
    assert str(DictUnpackingTransformer().visit(d)) == \
           '_py_backwards_merge_dicts([{1: 1}], {\'a\': 2})'



# Generated at 2022-06-23 22:46:56.332622
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_astunparse import unparse

    INPUT = '''\
x = {a: 1, **b, **c, d: 2}
'''
    EXPECTED = '''\
_py_backwards_merge_dicts([dict((a, 1)), dict((d, 2))], b, c)
'''
    transformer = DictUnpackingTransformer()
    assert transformer.run(INPUT) == EXPECTED


# Unit tests for method _split_by_None of class DictUnpackingTransformer

# Generated at 2022-06-23 22:47:01.745116
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    source = '{1: 1, **{2: 2}}'
    root = ast.parse(source)
    node = root.body[0].value

    transformer = DictUnpackingTransformer()
    transformer.visit(root)
    result = astor.to_source(root)

    assert '_py_backwards_merge_dicts([dict({1: 1})], {2: 2})' in result

# Generated at 2022-06-23 22:47:13.088722
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from textwrap import dedent
    from ..utils.test import TestCase
    
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import FunctionDef

    class _Test(TestCase):
        TRANSFORMER = DictUnpackingTransformer
        TARGET_VERSION = (3, 4)
    

# Generated at 2022-06-23 22:47:15.511493
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer(None, None)


# Generated at 2022-06-23 22:47:22.029223
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .transformer_test_fixtures import empty_context
    transformer = DictUnpackingTransformer(context=empty_context)
    d = ast.parse('{1: 2, 3: 4}')
    result = transformer.visit_Dict(d.body[0].value)
    assert isinstance(result, ast.Dict)
    assert result.keys == [ast.Num(n=1), ast.Num(n=3)]
    assert result.values == [ast.Num(n=2), ast.Num(n=4)]

# Generated at 2022-06-23 22:47:25.677386
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:47:28.402976
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import sys
    sys.argv = [sys.argv[0], '-m']  # type: ignore
    from ..utils.tests.test_fixtures import DictUnpackingTransformFixture
    DictUnpackingTransformFixture().test()

# Generated at 2022-06-23 22:47:35.867740
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    def _compile(code: str) -> str:
        module = ast.parse(code)
        module = DictUnpackingTransformer().visit(module)
        return compile(module, '<string>', mode='exec')

    d = _compile('{1: 1, **dict_a}')
    exec(d, {'dict_a': {2: 2}})
    assert eval(d.co_consts[0], {}) == {2: 2, 1: 1}

    d = _compile('{1: 1, 2: 2, **{3: 3, 4: 4, **dict_c}, 5: 5, **dict_b, 6: 6}')
    exec(d, {'dict_b': {7: 7}, 'dict_c': {8: 8}})