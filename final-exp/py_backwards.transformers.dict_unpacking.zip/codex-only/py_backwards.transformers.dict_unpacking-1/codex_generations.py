

# Generated at 2022-06-23 22:37:41.443055
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .fake_ast import FakeAstBuilder
    from ..tree_utils.tree import get_child_nodes
    from ..utils.source import source_to_unicode
    from ..utils.verify_ast import verify_ast

    b = FakeAstBuilder()

# Generated at 2022-06-23 22:37:49.985519
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    ast1 = ast.parse('{}')
    ast2 = ast.parse('{1: 2}')
    ast3 = ast.parse('{**a}')
    ast4 = ast.parse('{1: 2, **a}')
    ast5 = ast.parse('{**a, **b}')
    ast6 = ast.parse('{1: 2, **a, **b}')
    ast7 = ast.parse('{1: 2, **a, 3: 4, **b}')

    expected1 = ast.parse('{}')
    expected2 = ast.parse('{1: 2}')
    expected3 = ast.parse('_py_backwards_merge_dicts([], a)')

# Generated at 2022-06-23 22:37:56.985068
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from unittest import TestCase
    from .base import ASTFixtureMixin

    class Test(ASTFixtureMixin, TestCase):
        TRANSFORMER = DictUnpackingTransformer

        def test_1(self):
            s = '''{1: 1, **dict_a}'''
            self.check(s, '''
                _py_backwards_merge_dicts([{1: 1}], dict_a)
            ''')

        def test_2(self):
            s = '''{1: 1, **dict_a, **dict_b}'''
            self.check(s, '''
                _py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)
            ''')


# Generated at 2022-06-23 22:38:03.931840
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
{1: 2, **{**dict1, 2: 3, **dict2}}
"""
    expected = """
_py_backwards_merge_dicts([
    {1: 2, }, dict1, {2: 3, }, dict2,
])
"""

    tree = ast.parse(code)
    tree = DictUnpackingTransformer().visit(tree)
    assert code_gen.to_source(tree) == expected



# Generated at 2022-06-23 22:38:10.045896
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_transformer import transform
    code = "{0: 1, 0: 2}"
    expected_code = "{0: 2}"
    assert expected_code == transform(DictUnpackingTransformer, code)

    code = "{0: 1, 1: 2, **dict_a}"
    expected_code = "_py_backwards_merge_dicts([{0: 1, 1: 2}], dict_a)"
    assert expected_code == transform(DictUnpackingTransformer, code)

    code = "{0: 1, **dict_a, 1: 2, **dict_b}"
    expected_code = "_py_backwards_merge_dicts([{0: 1}, dict_a, {1: 2}], dict_b)"
    assert expected_code == transform(DictUnpackingTransformer, code)

   

# Generated at 2022-06-23 22:38:10.630222
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-23 22:38:11.426507
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer


# Generated at 2022-06-23 22:38:13.420189
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): # noqa
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:38:21.914952
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Dict unpacking is transformed to `_py_backwards_merge_dicts` call."""
    from typed_astunparse import unparse
    from astunparse import dump

    source = """\
    d = {1: 2, **{3: 4}}
    """

    expected = merge_dicts + """\
    d = _py_backwards_merge_dicts([{1: 2}], {3: 4})
    """

    module = ast.parse(source)
    DictUnpackingTransformer().visit(module)
    assert unparse(module) == expected
    assert isinstance(module.body[1].value, ast.Call)
    assert dump(module) == expected

# Generated at 2022-06-23 22:38:23.794310
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert type(t) == DictUnpackingTransformer

# Generated at 2022-06-23 22:38:29.880269
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    def check(before, after):
        node = ast.parse(before)
        node_transformed = DictUnpackingTransformer().visit(node)
        assert str(node_transformed) == after

    check(
        """
        {1: 1, **dict_a}
        """
        ,
        """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """
    )

    check(
        """
        {**dict_a, 1: 1, **dict_b}
        """
        ,
        """
        _py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)
        """
    )


# Generated at 2022-06-23 22:38:34.167956
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    return b"""
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        def g():
            return {1: 1, **{2:2}}
    """



# Generated at 2022-06-23 22:38:39.672968
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast

    transformer = DictUnpackingTransformer()
    node = transformer.visit(ast.parse("{1:1}"))
    assert isinstance(node, ast.Module)
    assert hasattr(node.body[0], 'value')
    assert isinstance(node.body[0].value, ast.Call)


# Generated at 2022-06-23 22:38:47.925121
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # type: () -> None

    code = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    node = ast.parse(code)
    DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == expected


# Generated at 2022-06-23 22:38:58.791133
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():

    import typed_ast.ast3
    from typed_ast.ast3 import Module, Dict, Name, List, Call, Str

    fake = typed_ast.ast3.fake

    module = Module(
        body=[
            Dict(keys=[
                fake.Name(id='a'),
                None,
                fake.Name(id='b')],
                 values=[
                     fake.Name(id='l'),
                     fake.Name(id='r'),
                     fake.Name(id='t')])
        ])

    node_transformer = DictUnpackingTransformer()
    new_module = node_transformer.visit(module)
    src = typed_ast.ast3.unparse(new_module)


# Generated at 2022-06-23 22:39:03.776541
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.simplify import simplify
    from ..utils.source import source

    source = source('''{1: 2, **{"a": 3}, **{"b": 4}}''')
    tree = ast.parse(source)
    simplified = simplify(tree)

    expected_source = '''
_py_backwards_merge_dicts([
{1: 2, **
{'a': 3}
}, {'b': 4}])
'''

    assert source(simplified) == source(expected_source)

# Generated at 2022-06-23 22:39:04.987105
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer.__name__ == "DictUnpackingTransformer"

# Generated at 2022-06-23 22:39:14.221988
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    check = BaseNodeTransformer.check_transform
    check(DictUnpackingTransformer,
          '{1: 1}',
          '_py_backwards_merge_dicts([{1: 1}],)')
    check(DictUnpackingTransformer,
          '{1: 1, 2: 2}',
          '_py_backwards_merge_dicts([{1: 1, 2: 2}],)')
    check(DictUnpackingTransformer,
          '{1: 1, **{2: 2}}',
          '_py_backwards_merge_dicts([{1: 1}], {2: 2})')

# Generated at 2022-06-23 22:39:14.878219
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-23 22:39:18.383477
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    module = ast.parse('a = {1: 2}')
    module = DictUnpackingTransformer().visit(module)
    module = astor.to_source(module)
    print(module)

# Generated at 2022-06-23 22:39:25.100067
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import find_node

    oneline = ("{1: 2, 'A': 'B', None: {1: 3}, 3: 4, None: 'C', None: 5}"
               "{1: 2, 'A': 'B', **{1: 3}, 3: 4, **'C', **5}")

    expected = ast.parse(oneline).body

    res = DictUnpackingTransformer().visit(ast.parse(oneline).body[0])

    assert find_node(res, ast.Name)
    assert find_node(res, ast.List)
    assert find_node(res, ast.Call)
    assert res == expected

# Generated at 2022-06-23 22:39:33.083711
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    input = """\
        {1: 1, **dict_a}
        """
    expected_output = """\
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """

    tree = ast.parse(input)
    result = DictUnpackingTransformer().visit(tree)
    assert expected_output == unparse(result)

# Generated at 2022-06-23 22:39:42.023773
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dut = DictUnpackingTransformer()
    assert dut.run("{1: 2, **{3: 4}}") == "dict([(1, 2), (3, 4)])"
    assert dut.run("{1: 2, **{3: 4}, 5: 6}") == "dict([(1, 2), (3, 4), (5, 6)])"
    assert dut.run("{**{3: 4}, 1: 2}") == "dict([(3, 4), (1, 2)])"
    assert dut.run("{**{3: 4}, **{1: 2}}") == "dict([(3, 4), (1, 2)])"

# Generated at 2022-06-23 22:39:52.014528
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer

    def check(original, expected):
        node = ast.parse(original)
        transformed = transformer.visit(node)
        expected = ast.parse(expected).body[0]
        assert ast.dump(transformed, include_attributes=False) == \
            ast.dump(expected, include_attributes=False)

    check('dict({1: 1, **dict_a})',
          '_py_backwards_merge_dicts([{1: 1}], dict_a)')
    check('dict({1: 1})',
          'dict({1: 1})')

# Generated at 2022-06-23 22:39:58.904559
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.utils import run_local_tests

    class TestData(NamedTuple):
        in_dict: ast.expr
        out_dict: ast.expr


# Generated at 2022-06-23 22:40:03.279526
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    sample = ('''
{1: 2, **{**{}, **{}}, **{}}
{1: 2, **{**{}, **{}}, 3: 4}
{**{}, **{}, 1: 2, **{}}
{**{}, **{}, 1: 2, 3: 4}
''')


# Generated at 2022-06-23 22:40:12.112604
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .pd_base import PDTransformerTestMixin

    class DictUnpackingTransformer(DictUnpackingTransformer, PDTransformerTestMixin):
        pass

    source = """\
{1: 1, **{2: 2}, **dict_c}
"""
    expected = """\
_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_c)
"""
    transformer = DictUnpackingTransformer()
    transformed = transformer.visit_Module(ast.parse(source))
    assert transformer._tree_changed
    assert transformer.dump_tree(transformed) == expected



# Generated at 2022-06-23 22:40:16.064219
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    t = DictUnpackingTransformer()
    assert t.visit_Module(ast.parse('{1: 1, **a}')) == ast.parse(
        """
        _py_backwards_merge_dicts([{1: 1}], a)
        """
    )



# Generated at 2022-06-23 22:40:16.731017
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:17.631204
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-23 22:40:24.390727
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '{1: 1, 2: 2, 3: 3, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a)'

    node = ast.parse(source)
    transformer = DictUnpackingTransformer()
    new_node = transformer.visit(node)
    result = ast.unparse(new_node)

    print()
    print('source = {}'.format(source))
    print('expected = {}'.format(expected))
    print('result = {}'.format(result))

    assert result == expected


# Generated at 2022-06-23 22:40:26.167815
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None).__class__.__name__ == 'DictUnpackingTransformer'

# Generated at 2022-06-23 22:40:29.187631
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.Module([])
    node = DictUnpackingTransformer.run(node)
    assert node.body[0] == merge_dicts.get_body()[0]


# Generated at 2022-06-23 22:40:36.196538
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..test_utils import assert_result
    from ..test_utils import parse as parse_ast
    from ..test_utils import roundtrip

    module = parse_ast("""
    def f():
        {'a': 1, **dict_a, 'b': 3}
    """)
    transformer = DictUnpackingTransformer()
    result = roundtrip(transformer.visit(module))
    assert_result(result, """
    def f():
        _py_backwards_merge_dicts([{'a': 1}, {'b': 3}], dict_a)
    """)

# Generated at 2022-06-23 22:40:39.290620
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dut = DictUnpackingTransformer()
    assert isinstance(dut, DictUnpackingTransformer), (
        "Expected class, got: %r" % dut)

# Generated at 2022-06-23 22:40:42.063781
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('''\
{1: 1, **dict_a}''')
    transformed = DictUnpackingTransformer().visit(module)

# Generated at 2022-06-23 22:40:52.906825
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''{1: 1, None: 2, None: 3, **a, 4: 4, None: 5, 6: 6, **b}
    '''
    expected = '''_py_backwards_merge_dicts([{1: 1, 4: 4, 6: 6}, 2, 3, a, 5, b])
    '''
    transformer = DictUnpackingTransformer()
    expected = ast.parse(expected).body[0].value  # type: ignore
    actual = transformer.visit(ast.parse(source).body[0].value)  # type: ignore
    actual = ast.fix_missing_locations(actual)

    assert transformer._tree_changed is True
    assert ast.dump(expected) == ast.dump(actual)

# Generated at 2022-06-23 22:40:55.965154
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert_equals = assert_equals_with_unidiff_message

    node = ast.parse('{1: 1, **dict_a}')
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-23 22:40:57.643537
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """{1: 1, 2: 2, **a, 3: 3, **b, **c, 4: 4}"""

# Generated at 2022-06-23 22:40:58.924757
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3

    source = """
print(a)
"""

# Generated at 2022-06-23 22:41:09.215035
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    ast_tree = transformer.visit(ast.parse("{1: 2, **{}, 3: 4, 5: 6}"))

# Generated at 2022-06-23 22:41:19.266493
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    compare_ast("""{1: 2}""", """{1: 2}""")
    compare_ast("""{1: 2, **{}}""", """dict({1: 2})""")
    compare_ast("""{1: 2, **{}}""", """dict({1: 2})""")
    compare_ast("""{1: 2, **{3: 4}}""", """dict({1: 2, 3: 4})""")
    compare_ast("""{1: 2, **{3: 4}}""", """dict({1: 2, 3: 4})""")

    compare_ast("""{**{}}""", """dict({})""")
    compare_ast("""{**{}}""", """dict({})""")

# Generated at 2022-06-23 22:41:23.547890
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from pprint import pprint
    from astpretty import pformat

    d = ast3.parse('{1: 2, "a": 10, **x}')  # type: ast3.Dict
    transformer = DictUnpackingTransformer()
    transformer.visit(d)
    pprint(d.__dict__)



# Generated at 2022-06-23 22:41:34.009786
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_astunparse
    class Transformer(DictUnpackingTransformer):
        def __init__(self, text='', *, filename='<ast>'):
            self.text = text
            self.filename = filename

    code = """
    {1: 1, 2: 2}
    """
    assert typed_astunparse.unparse(
        Transformer(text=code).visit(ast.parse(code))) == code

    code = """
    {1: 1, **dict_a}
    """
    assert typed_astunparse.unparse(
        Transformer(text=code).visit(ast.parse(code))) == """
    _py_backwards_merge_dicts([{(1): (1)}], dict_a)
    """


# Generated at 2022-06-23 22:41:43.819032
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    item = ast.Dict(keys=[ast.Name(id="a"), None, ast.Name(id="c")],
                    values=[ast.Name(id="a"), ast.Name(id="b"), ast.Name(id="c")])
    module = ast.Module(body=[item])

    transformer = DictUnpackingTransformer()
    result = transformer.visit(module)


# Generated at 2022-06-23 22:41:48.191410
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """ Tests if code is inserted to the beginning of a module. """
    transformer = DictUnpackingTransformer()
    x = ast.Module(body=[ast.Expr(value=ast.Call(func=ast.Name(id='a'),
                                                 args=[],
                                                 keywords=[]))])
    result = transformer.visit(x)
    for a, b in zip(merge_dicts.get_body(), result.body):
        assert a == b


# Generated at 2022-06-23 22:41:57.428597
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from _typed_ast import literal_eval
    transformer = DictUnpackingTransformer()
    code_before = '''
        {1: 2, **a, 2: 3, **b, 3: 4, **c}
    '''
    expected_code = '''def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result

_py_backwards_merge_dicts([{1: 2, 2: 3, 3: 4}], a, b, c)
'''
    expected_tree = literal_eval(expected_code)
    tree_before = ast.parse(code_before)

# Generated at 2022-06-23 22:42:05.495383
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:42:07.371075
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer.target == (3, 4)



# Generated at 2022-06-23 22:42:15.778539
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
        {1: 1, 2: 2, None: {3: 3}, **a, **b}
    """
    result = """
        _py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3}], a, b)
    """

    from .. import transform
    from ..utils.source import source_to_unicode

    module = transform(source, DictUnpackingTransformer)

    assert source_to_unicode(module) == source_to_unicode(result) \
        or source_to_unicode(module) == source_to_unicode(result + '\n')

# Generated at 2022-06-23 22:42:22.587306
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    ast_ = ast.parse("""
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """)
    expected = ast.parse("""
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """)

    transformer = DictUnpackingTransformer()
    transformed = transformer.visit(ast_)  # type: ignore

    assert [transformed] == expected

# Generated at 2022-06-23 22:42:27.885219
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .sample_asts import sample_ast
    from .transformer_test_case import TransformerTestCase, run_transformer_test_cases

    class TestCase(TransformerTestCase):
        def _create_transformer(self) -> DictUnpackingTransformer:
            return DictUnpackingTransformer()

        def _get_transformer_input(self) -> ast.AST:
            return sample_ast(r"""
                {'b': None, **dict_a}
                """)

        def _get_transformer_output(self) -> ast.AST:
            return sample_ast(r"""
                _py_backwards_merge_dicts([{'b': None}], dict_a)
                """)

    run_transformer_test_cases(TestCase)

# Generated at 2022-06-23 22:42:39.277943
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
        {1: 1}
        {1: 1, **{}}
        {1: 1, **{}, 2: 2}
        {1: 1, **{}, 2: 2, **dict_a}
    """

    expected = """
        _py_backwards_merge_dicts([{1: 1}])
        _py_backwards_merge_dicts([{1: 1}, {}])
        _py_backwards_merge_dicts([{1: 1}, {2: 2}])
        _py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a)
    """

    # removed = "import typing as t\n"

    tree = ast.parse(source)
    result = DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 22:42:48.146680
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_visitor import find_call, is_call_with_func

    transformer = DictUnpackingTransformer()


# Generated at 2022-06-23 22:42:59.278710
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    @snippet
    def before():
        def test():
            {1: 2, **a}
            {**a}  # should not be transformed
            {1: 2, **a, 3: 4}
            {1: 2, **a, 3: 4, **b}
            {1: 2, 4: 5, **a}
            {1: 2, **a, 4: 5}
            {1: 2, 3: 4, **a, 5: 6}
            {1: 2, **a, 3: 4, 5: 6}
            {1: 2, 3: 4, 5: 6, **a, 7: 8}
            {1: 2, **a, 3: 4, 5: 6, 7: 8}
            {1: 2, 3: 4, 5: 6, **b, 7: 8}


# Generated at 2022-06-23 22:42:59.826984
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-23 22:43:01.843914
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = 'foo = {}'
    expected = merge_dicts() + 'foo = {}'

    module = ast.parse(source)
    trans = DictUnpackingTransformer()
    new_node = trans.visit(module)
    result = compile(new_node, '', 'exec')

    assert expected == result

# Generated at 2022-06-23 22:43:12.073243
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source


# Generated at 2022-06-23 22:43:18.465375
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer = DictUnpackingTransformer() # type: ignore
    result = dict_unpacking_transformer.visit_Module(ast.parse('{}')) # type: ignore
    expected = ast.parse('''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    ''') # type: ignore
    assert_ast_equal(result, expected)


# Generated at 2022-06-23 22:43:24.551990
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_BaseNodeTransformer import transform, assert_equal
    from ..utils.snippet import assert_snippet
    
    code = '''
        def _py_backwards_merge_dicts(dicts: Tuple[dict, ...]) -> dict:
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        def f() -> dict:
            return {1: 1, **dict_a}
    '''
    assert_snippet(DictUnpackingTransformer(), code)
    


# Generated at 2022-06-23 22:43:35.779569
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .unpacking import UnpackingTransformer, TargetUnpackingVisitor
    
    def _test(pairs: List[Pair]):
        """Test visit_Dict method"""
        source = ast.Module(
            body=[
                ast.Dict(
                    keys=[key for key, _ in pairs],
                    values=[value for _, value in pairs]
                )
            ])
        # print(ast.dump(source))

# Generated at 2022-06-23 22:43:44.362758
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse("""
dict1 = {
    **dict(a=1),
    2: 2,
    **dict(b=3),
    **dict(c=4),
}
""")
    assert isinstance(node, ast.Module)
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-23 22:43:45.030603
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():  # type: ignore
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:43:49.086454
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    try:
        exec("from typed_ast import ast3\nfrom typed_ast import ast3 as ast")
    except ImportError:
        exec("from typed_ast import ast3")
    assert globals()['ast'] is ast3

# Generated at 2022-06-23 22:43:50.926216
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    src = """{**dict_a, **dict_b, 'c': 1}"""


# Generated at 2022-06-23 22:43:57.023607
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import assert_transformed

    assert_transformed(
        DictUnpackingTransformer,
        {1: 1, **{2: 2}},
        r'''
        _py_backwards_merge_dicts([{1: 1}], {2: 2})
        '''
    )

    assert_transformed(
        DictUnpackingTransformer,
        {1: 1, **{2: 2}, 3: 3},
        r'''
        _py_backwards_merge_dicts([{1: 1}], {2: 2}, {3: 3})
        '''
    )


# Generated at 2022-06-23 22:43:58.201215
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:44:05.201533
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from asttokens import ASTTokens

    source = '{1: 1, 2: 2, **{1: 2}, **{1: 1, 2: 2}, 1: 3}'
    modified = '_py_backwards_merge_dicts([{1: 1, 2: 2}, _py_backwards_merge_dicts([{1: 2}], {1: 1, 2: 2}), {1: 3}])'

    transformer = DictUnpackingTransformer()
    transformer.visit(ASTTokens(source).parsed())
    assert ASTTokens(modified).parsed() == transformer.modified_ast

# Generated at 2022-06-23 22:44:13.089359
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_as_str
    assert_as_str(DictUnpackingTransformer().visit(ast.parse("""
        foo = {1:1}
        """))) == """
        _py_backwards_merge_dicts = (_py_backwards_merge_dicts)
        foo = dict(1=1)
        """

    assert_as_str(DictUnpackingTransformer().visit(ast.parse("""
        foo = {1:1, 2:2, **dict_a}
        """))) == """
        _py_backwards_merge_dicts = (_py_backwards_merge_dicts)
        foo = _py_backwards_merge_dicts([dict(1=1, 2=2)], dict_a)
        """


# Generated at 2022-06-23 22:44:23.391544
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import unittest

    class DictUnpackingTransformerTest(unittest.TestCase):
        def test_constructor(self):
            DictUnpackingTransformer(None)

        def test_visit_Module(self):
            module = ast.parse('''
                from collections import Mapping

                x = {}
                y = {}
                z = Mapping()
                a = x
                b = y
                c = z
                result = x
                result = 2
                result = x, y
                result = x, y, z
                result = x, y, z, a
            ''')
            transformed = DictUnpackingTransformer(None).visit(module)

# Generated at 2022-06-23 22:44:25.362515
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)

# Generated at 2022-06-23 22:44:26.529793
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:44:36.778776
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import ast_dumps

    t = DictUnpackingTransformer()
    assert ast_dumps(ast.parse("{1: 1, **dict_a}")) == ast_dumps(t.visit(ast.parse("{1: 1, **dict_a}")))
    assert ast_dumps(ast.parse("{1: 1, 2: 2, **dict_a}")) == ast_dumps(t.visit(ast.parse("{1: 1, 2: 2, **dict_a}")))
    assert ast_dumps(ast.parse("{1: 1, **dict_a, 2: 2}")) == ast_dumps(t.visit(ast.parse("{1: 1, **dict_a, 2: 2}")))

# Generated at 2022-06-23 22:44:46.438321
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import textwrap

    def test_with_unpacking(source: str) -> Optional[str]:
        tree = ast.parse(textwrap.dedent(source))
        DictUnpackingTransformer().visit(tree)
        return ast.unparse(tree)

    assert test_with_unpacking('''
        {1: 1, **dict_a}
    ''') == textwrap.dedent('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')


# Generated at 2022-06-23 22:44:47.234976
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-23 22:44:48.571185
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:57.790128
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def transform(code: str) -> str:
        module = ast.parse(code)
        transformer = DictUnpackingTransformer()
        module = transformer.visit(module)  # type: ignore
        dump = ast.dump(module)
        assert transformer._tree_changed is True
        return dump

    dump = transform("{1:1}")
    assert dump == 'Module(body=[Dict(keys=[Num(n=1)], values=[Num(n=1)])])'

    dump = transform("{1:1, **{2:2}}")

# Generated at 2022-06-23 22:45:03.991806
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    text = """\
        {}
    """
    expected = """\
        def _py_backwards_merge_dicts(*dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        {}
    """
    node = ast.parse(text)
    DictUnpackingTransformer().visit(node)
    assert astor.to_source(node) == expected


# Generated at 2022-06-23 22:45:06.122258
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer.__class__.__name__ == 'DictUnpackingTransformer'

# Generated at 2022-06-23 22:45:07.386391
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor

# Generated at 2022-06-23 22:45:11.794483
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test import assert_transform_equal
    assert_transform_equal(DictUnpackingTransformer,
                           '''
                           {1: 1, **dict_a}
                           ''',
                           '''
                           _py_backwards_merge_dicts([{1: 1}], dict_a)
                           ''')

# Generated at 2022-06-23 22:45:19.633565
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    ast_node = ast.Module([
        ast.Assign([ast.Name(id='x')], ast.Num(n=1)),
        ast.Assign([ast.Name(id='y')], ast.Num(n=2))],
        lineno=1,
        col_offset=1,
    )  # type: ast.Module
    source = """
x = 1
y = 2
"""
    assert DictUnpackingTransformer().visit(ast_node) == ast_node
    assert DictUnpackingTransformer().visit_source(source) == source


# Generated at 2022-06-23 22:45:28.557142
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import to_source
    from ..utils.ast_factory import ast_call
    src = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    result = DictUnpackingTransformer().visit_Module(ast.parse(src))
    res_src = to_source(result)
    assert res_src == expected



# Generated at 2022-06-23 22:45:29.539549
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()

# Generated at 2022-06-23 22:45:32.752756
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..test.test_utils import transform, assert_equal_ast

    def _dict_unpacking(**kwargs):
        return {1: 1, **kwargs}


# Generated at 2022-06-23 22:45:42.509142
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import transform
    from typed_ast import ast3
    result = transform(DictUnpackingTransformer, "", "class A: pass")
    assert result == ["def _py_backwards_merge_dicts(dicts):",
                      "    result = {}",
                      "    for dict_ in dicts:",
                      "        result.update(dict_)",
                      "    return result",
                      "",
                      "",
                      "class A: pass"]
    result = transform(DictUnpackingTransformer, "", [
        "a = {y: y}",
        "b = {**a}"
    ], "")

# Generated at 2022-06-23 22:45:48.755157
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..transform import transform
    assert transform(DictUnpackingTransformer, 'x = {}') == \
        '_py_backwards_merge_dicts = lambda xs: x.update(x) or x\nx = {}'
    assert transform(DictUnpackingTransformer, 'x = {**a, **b}') == \
        '_py_backwards_merge_dicts = lambda xs: x.update(x) or x\nx = _py_backwards_merge_dicts(a, b)'



# Generated at 2022-06-23 22:45:57.552254
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().visit_Dict(
        ast.parse("{1: 1, **dict_a}").body[0]) == \
        ast.Call(
            func=ast.Name(id='_py_backwards_merge_dicts'),
            args=[
                ast.List(
                    elts=[
                        ast.Dict(
                            keys=[ast.Num(n=1)],
                            values=[ast.Num(n=1)]),
                        ast.Call(
                            func=ast.Name(id='dict'),
                            args=[ast.Name(id='dict_a')],
                            keywords=[])
                    ])
            ],
            keywords=[])


# Generated at 2022-06-23 22:45:59.935167
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dut = DictUnpackingTransformer()
    assert dut.target == (3, 4)

# Generated at 2022-06-23 22:46:08.121633
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.builder import build

    visitor = DictUnpackingTransformer()
    module = build("{1: 1, **{2: 2}}")
    result = visitor.visit(module)
    module = build("{1: 1}")
    expected = visitor.visit(module)
    assert isinstance(result, ast.Call)
    assert isinstance(result.args[0], ast.List)
    assert isinstance(result.args[0].elts[0], ast.Dict)
    assert result.args[0].elts[0].keys[0].n == 1
    assert result.args[0].elts[1] == expected
    assert isinstance(result, ast.Call)
    assert isinstance(result.args[0], ast.List)

# Generated at 2022-06-23 22:46:09.394217
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass

# Generated at 2022-06-23 22:46:10.637830
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:46:19.758014
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import parse

    # type: ast.Expr
    code = parse("""
        {1: 1, 2: 2, 3: 3, **a, **{4: 4, 5: 5, **b}}""")
    node = code.body[0].value
    assert isinstance(node, ast.Dict)

    # type: ast.Call
    trans = DictUnpackingTransformer()
    actual = trans.visit(node)
    assert isinstance(actual, ast.Call)

    assert actual.func.id == '_py_backwards_merge_dicts'
    assert len(actual.args) == 3
    assert isinstance(actual.args[0], ast.Dict)
    assert len(actual.args[0].keys) == 3

# Generated at 2022-06-23 22:46:30.363099
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.text import trim


# Generated at 2022-06-23 22:46:35.774278
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .ast_checker import check_node, assert_equal
    from .utils import code, ast_wrapper

    source = code('''
    {2: 4, None: {7: 4}, 5: None, None: 8}
    ''')

    expected = code('''
    _py_backwards_merge_dicts([{2: 4}, {5: None}], {8: 8}]
    ''')

    assert_equal(expected,
                 DictUnpackingTransformer().visit(ast_wrapper(source)))

# Generated at 2022-06-23 22:46:37.286323
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:46:48.440895
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..fake import Dict, DictUnpacking, MergeDicts
    from ..utils import header
    header('Simple example')
    source = '''
    {1:1, 2:2, **{3:3}, **{4:4}}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3}, {4: 4}])
    '''
    assert (DictUnpacking(Dict(DictUnpacking(MergeDicts(Dict(), Dict())))).
            transform(source) == expected)

    header('Single empty dict')
    source = '{**{}}'
    expected = '{}'

# Generated at 2022-06-23 22:46:52.269595
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    node = ast.parse('{1: 1, **A}')
    transformer.visit(node)
    assert ast.dump(node, include_attributes=False) == (
        'Module(body=['
        '_py_backwards_merge_dicts(['
        'dict([(Num(n=1), Num(n=1))]), '
        'A'
        '])])')



# Generated at 2022-06-23 22:47:02.018619
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import round_trip
    from ..utils.helper import compare_ast_with_source

    tests = [
        '{1: 1, 2: 2, 3: 3, **a, **b, **c, 4: 4}',
        '{*a, 1: 1, *b, 2: 2, *c, 3: 3, **d, **e, **f, 4: 4}'
    ]

    for test in tests:
        assert test == round_trip(test).strip()
        assert '_py_backwards_merge_dicts' == round_trip(test).strip()

    code = """
a = {1: 1, **a, **b, **c, 4: 4}
"""
    compiled_ast = round_trip(code).strip()

# Generated at 2022-06-23 22:47:09.437604
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    expected = ast.parse('_py_backwards_merge_dicts('
    '[{1: 1}, {2: 2, 3: 3}, dict_a], dict_b)')
    code = ast.parse('{1: 1, **{2: 2, 3: 3}, **dict_a, **dict_b}')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(code)
    ast.fix_missing_locations(result)
    assert ast.dump(expected) == ast.dump(result)

# Generated at 2022-06-23 22:47:10.587050
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:47:20.571496
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # _py_backwards_merge_dicts(
    #    _py_backwards_merge_dicts(
    #        [{1: 1}], {2: 2}),
    #    dict_a})
    dut = DictUnpackingTransformer()

    node = ast.Dict(keys=[ast.Num(1), None, ast.Name(id='x', ctx=ast.Load())],
                    values=[ast.Num(1),
                            ast.Dict(keys=[ast.Num(2)],
                                     values=[ast.Num(2)]),
                            ast.Name(id='dict_a', ctx=ast.Load())])

# Generated at 2022-06-23 22:47:22.222511
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer in globals().values()

# Generated at 2022-06-23 22:47:27.470901
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    t = DictUnpackingTransformer()
    module = ast.parse('a = {1:1}')
    t.visit(module)
    assert t._tree_changed


# Generated at 2022-06-23 22:47:30.978163
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ast import parse

    example = '{**ns, 1: 1, **{1: 2, 3: 4}, 3: 6}'
    expected = '_py_backwards_merge_dicts([{1: 1}], ns, {1: 2, 3: 4}, {3: 6})'
    converted = astor.to_source(DictUnpackingTransformer().visit(parse(example)))
    assert converted.strip() == expected

# Generated at 2022-06-23 22:47:31.641883
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()