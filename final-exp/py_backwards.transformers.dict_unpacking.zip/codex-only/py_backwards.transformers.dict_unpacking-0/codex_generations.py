

# Generated at 2022-06-23 22:37:34.712601
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer

# Generated at 2022-06-23 22:37:43.652457
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typing as t

    # To get valid python code, try::
    #
    #  text = astunparse.unparse(output)
    #
    # To get valid python object, try::
    #
    #  code = compile(text, '<test>', 'exec')
    #  module = types.ModuleType('_test_')
    #  exec(code, module.__dict__)
    #
    # To get back the original AST, try::
    #
    #  output_ast = ast.fix_missing_locations(ast.parse(text))

    # Given
    source = """\
if 1:
    {}
"""

    # When
    node = ast.parse(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(node)
    output = transformer.root

# Generated at 2022-06-23 22:37:54.509271
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.codegen import to_source
    from ..utils.ast import get_ast
    from ..utils.random import random_str
    assert to_source(get_ast('''
        assert {1: 1, **{}} == {1: 1}
    ''')) == '''
        assert _py_backwards_merge_dicts([{1: 1}]) == {1: 1}
    '''
    assert to_source(get_ast('''
        assert {1: 1, **{2: 2}} == {1: 1, 2: 2}
    ''')) == '''
        assert _py_backwards_merge_dicts([{1: 1}], {2: 2}) == {1: 1, 2: 2}
    '''

# Generated at 2022-06-23 22:38:05.606136
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import typed_ast.ast3 as ast

    c = DictUnpackingTransformer(None)
    assert c._split_by_None([(ast.Num(1), ast.Num(2))]) == \
        [[(ast.Num(1), ast.Num(2))]]
    assert c._split_by_None([(None, ast.Num(1))]) == [None, ast.Num(1)]
    assert c._split_by_None([(ast.Str('a'), ast.Num(1)), (None, ast.Num(2))]) == \
        [[(ast.Str('a'), ast.Num(1))], ast.Num(2)]

# Generated at 2022-06-23 22:38:11.102722
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def check(node):
        transformer = DictUnpackingTransformer()
        transformer.visit(node)
        return node
    

# Generated at 2022-06-23 22:38:17.355847
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_astunparse import unparse
    from ..utils.checker import check_transformation

    example_source = '{1: 1, **dict_a}'
    expected_source = \
        """
_py_backwards_merge_dicts([{1: 1}], dict_a)
        """.strip()
    check_transformation(example_source, expected_source,
                         DictUnpackingTransformer)

# Generated at 2022-06-23 22:38:19.852296
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
    d = {1: 1, **a, 2: 2}
    """
    result = DictUnpackingTransformer()(source)

# Generated at 2022-06-23 22:38:27.291078
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    x = 'x'

# Generated at 2022-06-23 22:38:28.518031
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:38:34.446794
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_str1 = 'def f(x): return {**x}\n'
    expect_str1 = 'def f(x): return _py_backwards_merge_dicts([], x)\n'
    module = ast.parse(module_str1)
    module = DictUnpackingTransformer().visit(module)
    assert ast.dump(module) == ast.dump(ast.parse(expect_str1))



# Generated at 2022-06-23 22:38:43.576857
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:38:52.202710
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import get_fixture_ast
    from ..utils.testing import make_unittest, get_doctest_examples
    from ..utils.testing import assert_equal_dumps
    from ..utils.testing import transform_and_compare

    transformer_cls = DictUnpackingTransformer
    fixture_path = get_fixture_path(__file__, 'visit_Dict')
    source = get_fixture_ast(fixture_path)
    expected = get_fixture_ast(fixture_path, '.expected')

    examples = list(get_doctest_examples(transformer_cls))

    TestCase = make_unittest(transformer_cls, fixture_path)

# Generated at 2022-06-23 22:39:03.469594
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast.ast3 as ast

    # Test on initializing a variable

# Generated at 2022-06-23 22:39:12.408636
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
    {
        1: 1,
        **None,
        **dict_a,
        2: 2,
    }
    """
    expected = """
    _py_backwards_merge_dicts([dict({1: 1}, 2: 2)], dict_a)
    """
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    new_code = compile(new_tree, '<string>', 'exec')
    scope = {}
    exec(new_code, scope)
    assert scope['_py_backwards_merge_dicts'] == merge_dicts.get_body()  # type: ignore

# Generated at 2022-06-23 22:39:13.422147
# Unit test for constructor of class DictUnpackingTransformer

# Generated at 2022-06-23 22:39:23.460378
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse(
        "a = {'a': 1, **x, 'b': 2}")
    expected_tree = ast.parse(
        '''
        _py_backwards_merge_dicts([dict(a=1)], x, dict(b=2))
        ''')
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    assert tree == expected_tree

    tree = ast.parse(
        "a = {'a': 1, **x}")
    expected_tree = ast.parse(
        '''
        _py_backwards_merge_dicts([dict(a=1)], x, dict())
        ''')
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)

# Generated at 2022-06-23 22:39:24.204423
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert repr(DictUnpackingTransformer)

# Generated at 2022-06-23 22:39:25.325122
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-23 22:39:33.225173
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import astor
    assert "def x(self, a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z, *args, **kwargs):\n" in astor.to_source(DictUnpackingTransformer)

# Generated at 2022-06-23 22:39:36.554777
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from . import parse, unparse

    tree = parse(merge_dicts.get_source())  # type: ignore
    assert unparse(tree) == merge_dicts.get_source()  # type: ignore


# Generated at 2022-06-23 22:39:37.503297
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:39:40.972833
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    node = ast.parse('1\n', mode='eval')
    transformer.visit(node)
    assert transformer._tree_changed == True
    assert node.body[0].value.id == '_py_backwards_merge_dicts'



# Generated at 2022-06-23 22:39:48.979291
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()
    assert hasattr(DictUnpackingTransformer, 'visit_Dict')
    assert hasattr(DictUnpackingTransformer.visit_Dict, '__call__')
    assert hasattr(DictUnpackingTransformer, 'visit_Module')
    assert hasattr(DictUnpackingTransformer.visit_Module, '__call__')
    assert not hasattr(DictUnpackingTransformer.visit_Dict, '__self__')
    assert not hasattr(DictUnpackingTransformer.visit_Module, '__self__')


# Generated at 2022-06-23 22:39:53.836138
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .. import compile
    program_snippet = '{1:1, **{2:2, 3:3}, 4:4, **{5:5, 6:6}}'
    code = compile(program_snippet)
    assert '_py_backwards_merge_dicts' in code
    assert '{1: 1, 4: 4}' in code
    assert '{2: 2, 3: 3}' in code
    assert '{5: 5, 6: 6}' in code

# Generated at 2022-06-23 22:39:57.333133
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
    def foo():
        a = 5
    """
    module = ast.parse(code)
    p = DictUnpackingTransformer()
    transformed = p.visit(module)
    assert transformed.body[0].name == '_py_backwards_merge_dicts'
    assert transformed.body[1].name == 'foo'



# Generated at 2022-06-23 22:40:06.561619
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3
    from ..utils import tree
    from ..utils import transform
    from ..utils import codegen
    from .literal import LiteralTransformer

    class Dumper(ast3.NodeVisitor):
        def visit_Module(self, node):
            print('Module')
            self.generic_visit(node)  # visit all child nodes

        def visit_Expr(self, node):
            print('Expr')
            self.generic_visit(node)  # visit all child nodes

        def visit_Call(self, node):
            print('Call')
            self.generic_visit(node)  # visit all child nodes

        def visit_Name(self, node):
            print('Name: {0}'.format(node.id))
            self.generic_visit(node)  # visit

# Generated at 2022-06-23 22:40:16.155292
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Tests of visit_Dict
    import astor
    from ..utils.tree import to_list, split_list, get_body
    from asttokens import ASTTokens

    from .base import BaseNodeTransformer


# Generated at 2022-06-23 22:40:16.840048
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-23 22:40:17.756049
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:20.561221
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    code = """
        def foo(bar):
            baz = {1: 2, **bar}
    """
    assert code == compile_source(code, '<test>', 'exec')


# Generated at 2022-06-23 22:40:27.296236
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Arrange
    tree = ast.parse("""
{1: 1, **{2: 2, 3: 3}, 4: 4, 5: 5, **{6: 6, 7: 7}}
""")
    # Act
    result = DictUnpackingTransformer().visit(tree)
    # Assert

# Generated at 2022-06-23 22:40:27.902393
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer is not None

# Generated at 2022-06-23 22:40:33.764196
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert (
        DictUnpackingTransformer().visit(ast.parse("""\
{
    **dict_a,
    1: 1
}
            """)).body[0] ==
        ast.parse("""\
{1: 1, **dict_a}
            """).body[0])



# Generated at 2022-06-23 22:40:40.440846
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert (DictUnpackingTransformer(3, 4).visit(
        parse('a = {123: a, b: c, 1, 2, 3}, (1, 2, 3)')) ==
        parse('_py_backwards_merge_dicts = None\n'
              'a = _py_backwards_merge_dicts([{123: a, b: c}], {1, 2, 3}), (1, 2, 3)'))  # noqa



# Generated at 2022-06-23 22:40:42.146554
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """\
{1,2,3}
"""

# Generated at 2022-06-23 22:40:49.724453
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{1: 1, **dict_a}', mode='eval')
    jast.inline_import('functools', '_py_backwards_merge_dicts')
    transformer = DictUnpackingTransformer(debug=True)
    module = transformer.visit(module)
    assert jast.dump(module) == '_py_backwards_merge_dicts([{1: 1}], dict_a)'



# Generated at 2022-06-23 22:40:57.312620
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse('{foo: 1, **a}')
    node = module.body[0].value  # type: ast.Dict
    new_node = DictUnpackingTransformer().visit(node)
    assert isinstance(new_node, ast.Call)
    assert isinstance(new_node.func, ast.Name)
    assert new_node.func.id == '_py_backwards_merge_dicts'
    assert isinstance(new_node.args[0], ast.List)
    assert len(new_node.args[0].elts) == 2
    assert isinstance(new_node.args[0].elts[0], ast.Dict)



# Generated at 2022-06-23 22:41:08.094944
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_resources import assert_equal_ast
    from ..utils.tree import parse_to_ast, dump_ast

    source = '''
    {
        **dict_a,
        'c': 3,
        **dict_b,
        'e': 5,
        **dict_c,
        'g': 7,
        **dict_d
    }
    '''
    expected_source = '''
    _py_backwards_merge_dicts([
        dict_b,
        dict_a,
        {'c': 3},
        dict_c,
        {'e': 5},
        dict_d,
        {'g': 7}
    ])
    '''
    source_ast = parse_to_ast(source)

# Generated at 2022-06-23 22:41:09.640173
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None


# Generated at 2022-06-23 22:41:17.047722
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.codegen import to_source
    from ..utils.visitors import NodeCollector

    source = """
    {1: 1, **dict_a}
    """
    root = ast.parse(source)
    DictUnpackingTransformer().visit(root)

    assert to_source(root) == """\
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    # Check that visit_Module method works
    assert ast.Module in [type(node) for node in NodeCollector().visit(root)]

# Generated at 2022-06-23 22:41:17.625232
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-23 22:41:18.967018
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor

# Generated at 2022-06-23 22:41:19.628319
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:28.765299
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import transform

    tree = ast.parse('{1: 1, **dict_a, 2: 2, **dict_b, 3: 3}')
    actual = transform(tree, [DictUnpackingTransformer])
    expected = ast.parse('''\
        {
            # generated by mypyc.transform.dict_unpacking.DictUnpackingTransformer
            '_py_backwards_merge_dicts': _py_backwards_merge_dicts,
        }
        _py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {3: 3}], dict_b)
        ''')
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-23 22:41:37.896757
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import sample_code
    import astor
    from textwrap import dedent

    result = sample_code.source_2
    print(result)
    result = astor.code_to_ast(result)
    # print(astor.dump_tree(result))  # code generated by astor
    # print(astor.dump_tree(DictUnpackingTransformer().visit(result)))

    # # prints:
    # # _py_backwards_merge_dicts([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}], {'e': 5, 'f': 6})
    # # print(_py_backwards_merge_dicts([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}], {'e': 5, 'f

# Generated at 2022-06-23 22:41:39.855833
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump as dump_ast
    

# Generated at 2022-06-23 22:41:40.703416
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:48.470936
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.textwriter import TextWriter
    from ..utils.tree import parse_tre


# Generated at 2022-06-23 22:41:51.862120
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dut = DictUnpackingTransformer()
    assert dut.__class__.__name__ == 'DictUnpackingTransformer'
    assert DictUnpackingTransformer.__name__ == 'DictUnpackingTransformer'

# Generated at 2022-06-23 22:41:53.902318
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().target == (3, 4)

# Unit tests for method DictUnpackingTransformer._split_by_None

# Generated at 2022-06-23 22:41:57.745557
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = "a = {1: 1, **{2: 2}}"
    expected_code = "_py_backwards_merge_dicts([{1: 1}], {2: 2})"

    module = ast.parse(code)
    DictUnpackingTransformer().visit(module)
    assert_code(module, expected_code)

# Generated at 2022-06-23 22:41:59.488441
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    obj = DictUnpackingTransformer()
    assert obj.tree_changed == False

# Generated at 2022-06-23 22:42:06.543796
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): #pylint: disable=redefined-outer-name
    import sys
    import astor
    from textwrap import dedent
    from ..utils.meta import get_source

    # Call __init__
    transformer = DictUnpackingTransformer(sys.version_info)

    # Check that __init__ call initializes correct values
    assert transformer._tree_changed is False
    assert transformer._target == (3, 4)
    assert transformer.visit_Dict is DictUnpackingTransformer.visit_Dict
    assert transformer.visit_BinOp is BaseNodeTransformer.visit_BinOp
    assert transformer.visit_Attribute is BaseNodeTransformer.visit_Attribute
    assert transformer.visit_Break is BaseNodeTransformer.visit_Break
    assert transformer.visit_Call is BaseNodeTransformer.vis

# Generated at 2022-06-23 22:42:07.251448
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:42:11.168145
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ...utils.testing.transformer.test_transformer import get_input_output_node
    input_node, output_node = get_input_output_node(DictUnpackingTransformer)
    # compare input and output nodes
    assert input_node == output_node

# Generated at 2022-06-23 22:42:18.239974
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    dct = ast.parse("""{
        'a': 1,
        **b,
        2: 3,
        **c
    }""")
    node = transformer.visit(dct)
    assert transformer._tree_changed == True
    assert ast.dump(node) == ast.dump(ast.parse("""
        _py_backwards_merge_dicts([{'a': 1}], b, {2: 3}, c)
        """))


# Generated at 2022-06-23 22:42:19.941226
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:25.693241
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = '''
d = {1: 2, **{3: 4}, **{5: 6}}
'''
    expected = '''
from typed_ast import ast3 as ast
_py_backwards_merge_dicts = dict
d = _py_backwards_merge_dicts([{1: 2}], {3: 4}, {5: 6})
'''
    tree = ast.parse(source)
    DictUnpackingTransformer.run_on_single_file(tree)
    fixed = ast.unparse(tree)
    assert fixed == expected


# Generated at 2022-06-23 22:42:28.920555
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    """Unit test for the constructor of class DictUnpackingTransformer."""
    
    
test_DictUnpackingTransformer()


# Generated at 2022-06-23 22:42:29.652258
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): pass

# Generated at 2022-06-23 22:42:40.974227
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    from ..utils.source import source

    code = source(
        """
        {1: 1,
         2: 2,
         **a,
         **b,
         3: 3,
         **c,
         4: 4,
         }
        """
    )
    expected_code = source(
        """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([dict({1: 1, 2: 2}), a, b, dict({3: 3})], c)
        """
    )

    # noinspection PyArgumentList
    root_node = ast.parse(code)

# Generated at 2022-06-23 22:42:43.307114
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('dict(x=x, y=2, **z)')
    transformer = DictUnpackingTransformer(lambda: None)


# Generated at 2022-06-23 22:42:48.809433
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    output = ''
    expected_output = 'def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n'
    result = transformer.visit_Module(ast.parse('{1: 1, **{2: 2}}'))
    for item in result.body:
        output += str(item) + '\n'
    assert expected_output == output


# Generated at 2022-06-23 22:42:55.302359
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '{1: 2, 3: 4, **x, 5: 6, **y, **z}'
    expected = '_py_backwards_merge_dicts([{1: 2, 5: 6, 3: 4}, x, y, z])'
    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == expected

# Generated at 2022-06-23 22:43:04.948815
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.utils import MockNodeTransformer
    from ..testing.utils import assert_if_errors_raise
    from astor.code_gen import to_source

    def create_Dict(keys: List[Optional[ast.expr]],
                    values: List[ast.expr]) -> ast.Dict:
        return ast.Dict(keys=keys, values=values)


# Generated at 2022-06-23 22:43:09.674843
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_setup import setup_test_for_DictUnpackingTransformer, tree_equal
    from .test_setup import module_ast as node
    tree = setup_test_for_DictUnpackingTransformer
    result = DictUnpackingTransformer().visit_Module(node)
    assert tree_equal(result, tree)



# Generated at 2022-06-23 22:43:15.626375
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_sets import code_and_ast, module_ast
    from .test_sets import DictUnpackingTransformer_tests
    for code in DictUnpackingTransformer_tests:
        m = ast.parse(code)
        print('\nBefore:')
        print(code)
        transformed = DictUnpackingTransformer().visit(m)
        print('\nAfter:')
        print(code_and_ast(transformed))
        print('\nTransformed tree:')
        print(module_ast(transformed))



# Generated at 2022-06-23 22:43:21.728028
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse

    class TestTransformer(DictUnpackingTransformer):
        def visit(self, node):
            return ast.copy_location(self.generic_visit(node), node)

    module = ast.parse("""
{'a': 'b', **dict_a}
    """)
    transformer = TestTransformer()
    transformer.visit(module)
    assert astunparse.unparse(module) == """_py_backwards_merge_dicts([{'a': 'b', **dict_a}],)
"""

# Generated at 2022-06-23 22:43:28.774973
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import dump

    source = '''\
{
    1: 1,
    2: 2,
    **{
        3: 3,
        4: 4
    },
    5: 5,
    **{
        6: 6,
        7: 7,
    },
    8: 8,
}
'''
    expected = '''\
_py_backwards_merge_dicts(
    [
        {
            1: 1,
            2: 2
        },
        {
            3: 3,
            4: 4
        },
        {
            5: 5
        },
        {
            6: 6,
            7: 7
        },
        {
            8: 8
        }
    ]
)
'''
    node = ast.parse(source)
    DictUn

# Generated at 2022-06-23 22:43:36.757909
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import textwrap
    from astunparse import unparse

    code = textwrap.dedent("""
    {**a, 1: 2, **b, 'c': d}
    """)
    node = ast.parse(code)

    transforms = [DictUnpackingTransformer]
    node = apply_transforms(node, transforms)
    code2 = unparse(node)

    code3 = textwrap.dedent("""
    _py_backwards_merge_dicts([{'c': d}], b, {1: 2}, a)
    """)

    assert code3 == code2

# Generated at 2022-06-23 22:43:44.974065
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..transformers.unlist import UnlistTransformer
    from ..transformers.unpacking import UnpackingTransformer
    from ..utils.tree import to_tuple
    
    source = '''\
    [
        {
            1: 2,
            3: 4,
            None: {5: 6, 7: 8},
            9: 10,
            None: {11: 12, 13: 14},
            15: 16
        },
        {17: 18, 19: 20},
        {None: {21: 22, 23: 24}, 25: 26}
    ]'''

# Generated at 2022-06-23 22:43:53.503584
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .transformer import Transformer
    @snippet
    def src():
        a = {1: 1, **{2: 2}, 4: 4, **{3: 3}, 5: 5, **{}}
    node = ast.parse(src())
    Transformer.apply(DictUnpackingTransformer, node)
    @snippet
    def expected():
        a = _py_backwards_merge_dicts([{1: 1, 4: 4, 5: 5}], {2: 2}, {3: 3}, dict())
    assert ast.dump(node) == ast.dump(ast.parse(expected()))  # type: ignore

# Generated at 2022-06-23 22:43:54.572760
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():   
    pass


# Generated at 2022-06-23 22:44:00.900089
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    tree = ast.parse("""\
{1: 1, None: {2: 2, 3: 3}, **dict_a}""")
    DictUnpackingTransformer().visit(tree)
    assert codegen.to_source(tree) == """\
_py_backwards_merge_dicts([{1: 1}], {2: 2, 3: 3}, dict_a)
"""



# Generated at 2022-06-23 22:44:07.676375
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from faster_than_requests.code_gen import transform
    from .base import get_ast_from_code

    source = '''
        def foo(a):
            return {1: 1, **a}
            
        {1, 2}
    '''
    expected = '''
        def foo(a):
            return _py_backwards_merge_dicts([{1: 1}], a)
    '''

    ast1 = get_ast_from_code(source)
    ast2 = get_ast_from_code(expected)
    t = DictUnpackingTransformer()

    ast3 = t.visit(ast1)
    assert ast3 == ast2



# Generated at 2022-06-23 22:44:14.240679
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3 as ast

# Generated at 2022-06-23 22:44:24.475314
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..test_utils import round_trip_assert, round_trip_load

    # Test the presence of `merge_dicts` at the beginning of the module
    round_trip_assert(ast.parse(''), DictUnpackingTransformer)
    round_trip_assert(ast.parse('''
    d = {1, 2}
    '''), DictUnpackingTransformer)
    round_trip_assert(ast.parse('''
    e = 1
    '''), DictUnpackingTransformer)

    assert round_trip_load(merge_dicts.get_body(), DictUnpackingTransformer)

    assert round_trip_load('''
    d = {**a}
    ''', DictUnpackingTransformer) == '''
    d = a
    '''
    assert round_trip

# Generated at 2022-06-23 22:44:25.842660
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:44:35.953978
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .context import Context
    from .registry import TransformationRegistry
    from typing import Optional
    if hasattr(DictUnpackingTransformer, 'visit_Module'):
        transformation = DictUnpackingTransformer()
        module = compile('{1: 1, 2: 2, **a}', '', 'single')
        expected = compile(
            'def _py_backwards_merge_dicts(dicts):\n'
            '    result = {}\n'
            '    for dict_ in dicts:\n'
            '        result.update(dict_)\n'
            '    return result\n'
            '_py_backwards_merge_dicts([{1: 1, 2: 2}], a)', '', 'single')
        if not isinstance(module, ast.Module):
            raise

# Generated at 2022-06-23 22:44:40.312632
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    stmt = "foo = {1: 1, **dict_a}"
    assert DictUnpackingTransformer().visit(stmt) == ('foo = _py_backwards_merge_dicts([{1: 1}, dict_a])', '\n')

# Generated at 2022-06-23 22:44:48.482889
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import make_test_cases

    def check(test_case):
        node = test_case.data[0]()
        transformer = DictUnpackingTransformer()
        result = transformer.visit(node)  # type: ignore
        assert result == test_case.data[1]


# Generated at 2022-06-23 22:44:57.736048
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..ast_utils import ast_source, ast_unparse
    from ..testcase import TestCase
    from ..utils import capture_out

    source = """\
    a = {1: 1, **dict_a, **dict_b}
    """
    expected = """\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    a = _py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)
    """

    code = ast_source(source)
    expected = ast_source(expected)
    with capture_out() as out:
        actual = DictUnpackingTransformer().visit(code)
    assert actual == expected
   

# Generated at 2022-06-23 22:45:06.635869
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import BaseNodeTest

    class Test(BaseNodeTest):
        transformer = DictUnpackingTransformer
        code = '''\
            {1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, None: 8, 9: 9, 10: 10, 11: 11}
            '''
        expected = '''\
            _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7}], 8, {9: 9, 10: 10, 11: 11})
            '''

    test = Test()
    test.run_test()

# Generated at 2022-06-23 22:45:16.238569
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer(None)
    
    # Without dict unpacking
    actual = transformer.visit_Dict(ast.parse('{1:1, 2:2}').body[0].value)
    assert actual == ast.parse('{1:1, 2:2}').body[0].value
    
    # Empty dicts
    actual = transformer.visit_Dict(ast.parse('{1:1, **{}}').body[0].value)

# Generated at 2022-06-23 22:45:22.588676
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    code = astor.to_source(DictUnpackingTransformer().visit(astor.parse_file(source)))
    assert expected == code



# Generated at 2022-06-23 22:45:32.011347
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    node = ast.parse('{a: b, **c, f: g, **h}')

# Generated at 2022-06-23 22:45:32.501509
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:45:33.750232
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    

# Generated at 2022-06-23 22:45:34.653377
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()



# Generated at 2022-06-23 22:45:36.299523
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    def test():
        DictUnpackingTransformer()



# Generated at 2022-06-23 22:45:40.692223
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    m = ast.parse('1')
    assert '_py_backwards_merge_dicts' not in m.body[0].body
    m = DictUnpackingTransformer().visit(m)
    assert '_py_backwards_merge_dicts' in m.body[0].body



# Generated at 2022-06-23 22:45:49.124681
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
    {1: 2, 4: 5, **dict_a, **dict_b, **dict_c}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    _py_backwards_merge_dicts([{}, dict_a, dict_b, dict_c])
    """
    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)
    result = compile(node, filename="<ast>", mode="exec")
    code = ""
    exec(result, globals(), locals())
    assert code.strip() == expected.strip()



# Generated at 2022-06-23 22:45:54.824918
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .fixtures.dict_unpacking import before, after

    from typed_ast import ast3 as ast
    from typed_ast.ast3 import parse

    module_before = parse(before)
    module_after = parse(after)

    transformer = DictUnpackingTransformer()
    module_after_transformed = transformer.visit(module_before)

    assert ast.dump(module_after_transformed) == ast.dump(module_after)

# Generated at 2022-06-23 22:46:05.021564
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import list_to_dict
    from ..utils.ast import parse
    from . import unpack
    
    source = '''
    {1: 1, **{2: 2}}
    '''
    node = parse(source)
    result = unpack(node)
    assert result == parse('''
    _py_backwards_merge_dicts((dict((1, 1)), dict((2, 2))))
    ''')
    
    source = '''
    {**{1: 1, 2: 2}}
    '''
    node = parse(source)
    result = unpack(node)
    assert result == parse('''
    dict((1, 1), (2, 2))
    ''')
    

# Generated at 2022-06-23 22:46:16.134634
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    old = ast.parse('{1: 2, 3: 4, **a}').body[0]
    new = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[
            ast.List(
                elts=[
                    ast.Dict(
                        keys=[
                            ast.Constant(1),
                            ast.Constant(3)
                        ],
                        values=[
                            ast.Constant(2),
                            ast.Constant(4)
                        ]
                    ),
                    ast.Name(id='a')
                ]
            )
        ],
        keywords=[]
    )

    x = DictUnpackingTransformer()
    assert x.visit_Dict(old) == new



# Generated at 2022-06-23 22:46:16.676642
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:46:17.526737
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:46:23.577952
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import Source
    source = Source('{1: 1, **{2: 2}}')
    tree = source.tree
    node = tree.body[0].value  # type: ast.Dict

    assert isinstance(node, ast.Dict)
    assert len(node.keys) == 2
    assert node.keys[0] is None
    assert node.keys[1] == 1

    with DictUnpackingTransformer():
        result = tree.body[0].value

    assert isinstance(result, ast.Call)
    assert result.func.id == '_py_backwards_merge_dicts'
    assert len(result.args) == 1
    assert len(result.args[0].elts) == 2

# Generated at 2022-06-23 22:46:26.317703
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    m = ast.parse('x[**a]')
    assert ast.dump(m) == ast.dump(DictUnpackingTransformer().visit(m))



# Generated at 2022-06-23 22:46:33.732816
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class Test(unittest.TestCase):
        @snippet
        def target():
            {1: 1, **dict_a}

        @snippet
        def expected():
            _py_backwards_merge_dicts([{1: 1}], dict_a)

    module = ast.parse(Test.target.get_source())
    DictUnpackingTransformer().visit(module)
    expected = ast.parse(Test.expected.get_source())
    assert ast.dump(module, include_attributes=True) == \
           ast.dump(expected, include_attributes=True)

# Generated at 2022-06-23 22:46:38.287628
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    x = 'def a(b, c):\n    d = {1: 1, **c}\n    return b + d["a"]\n'
    tree = ast.parse(x)
    before = ast.dump(tree)
    tree = DictUnpackingTransformer().visit(tree)  # type: ignore
    after = ast.dump(tree)
    assert before != after
    assert '_py_backwards_merge_dicts' in after


# Generated at 2022-06-23 22:46:49.183489
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_function, source_to_ast

    code = """
        a_dict = {'a': 1, 'b': 2}
        a_dict2 = {'c': 3, 'd': 4}

        result = {1: 1, **a_dict, 2: 2, **a_dict2}
    """

    transformed = source_to_ast(code, DictUnpackingTransformer())
    assert transformed.body[3].value.func.id == '_py_backwards_merge_dicts'

    func = source_to_function(code, DictUnpackingTransformer)

    globals = {}
    locals = {}
    exec(func, globals, locals)


# Generated at 2022-06-23 22:46:51.225729
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    result = DictUnpackingTransformer()
    assert isinstance(result, DictUnpackingTransformer)

# Generated at 2022-06-23 22:46:51.924389
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:46:57.901872
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from textwrap import dedent
    from astor.ast_tree import dump_ast

    got = dedent('''\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    {1: 1}
    ''')
    expected = dedent('''\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    {1: 1}
    ''')

    module = ast.parse(got)
    DictUnpackingTransformer().visit(module)

    assert got == expected
    assert dump_ast(module) == dump_ast

# Generated at 2022-06-23 22:46:59.729517
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    text = '''{a: 1, **b}'''

# Generated at 2022-06-23 22:47:02.543632
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_transpiler import apply_transformations

    @apply_transformations([DictUnpackingTransformer])
    def f():
        return [1, 2, 3]

    assert f() == [1, 2, 3]


# Generated at 2022-06-23 22:47:13.878286
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    expr = ast.parse(
        "lambda: {1: 1, 2: 2, **dict_a, **{3: 3}, **dict_b, 4: 4}").body[0].body
    assert isinstance(expr, ast.Dict)
    transformer = DictUnpackingTransformer()
    splitted = transformer.visit(expr)
    assert isinstance(splitted, ast.Call)
    func = splitted.func
    assert isinstance(func, ast.Name)
    assert func.id == '_py_backwards_merge_dicts'
    args = splitted.args
    assert isinstance(args[0], ast.List)
    assert len(args[0].elts) == 5
    assert isinstance(args[1], ast.Name)

# Generated at 2022-06-23 22:47:17.955377
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    module = ast.parse('')
    result = transformer.visit(module)
    assert_equal_code(merge_dicts.get_body(),
                      result.body[0])

# Unit tests for method _split_by_None of class DictUnpackingTransformer

# Generated at 2022-06-23 22:47:18.899502
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass  # TODO



# Generated at 2022-06-23 22:47:19.464124
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass

# Generated at 2022-06-23 22:47:20.959495
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer.__doc__ is not None

# Generated at 2022-06-23 22:47:32.181461
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .compile_to_ast import compile_to_ast

    def check(code, dump):
        ast_tree = compile_to_ast(code)
        DictUnpackingTransformer().visit(ast_tree)
        assert dump == ast.dump(ast_tree)


# Generated at 2022-06-23 22:47:38.636689
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Check that nothing changes if there is no unpacking in dict.
    code = '''\
        {1: 1, 2: 2}
    '''
    expected = ast.parse(code)
    actual = DictUnpackingTransformer.run(code)

    assert ast.dump(expected) == ast.dump(actual)

    # Check that there is unpacking in dict.
    code = '''\
        {1: 1, **dict_a, 2: 2}
    '''
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)')
    actual = DictUnpackingTransformer.run(code)

    assert ast.dump(expected) == ast.dump(actual)

    # Check that there are multiple unpacking in dict.
    code