

# Generated at 2022-06-23 22:37:34.715574
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:37:39.884941
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('pass')
    node = DictUnpackingTransformer().visit(tree)
    assert len(node.body) == 2
    assert node.body[0].value.id == '_py_backwards_merge_dicts'
    assert node.body[1].value.id == 'pass'


# Generated at 2022-06-23 22:37:41.361863
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer_instance = DictUnpackingTransformer()
    assert(transformer_instance)


# Generated at 2022-06-23 22:37:45.213235
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from astunparse import unparse
    from py_mini_racer import py_mini_racer

    import ast
    import sys
    python_version = sys.version_info[0] * 10 + sys.version_info[1]

    DictUnpackingTransformer()

# Test that node is of correct type

# Generated at 2022-06-23 22:37:46.711574
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a = DictUnpackingTransformer()
    assert a is not None

# Generated at 2022-06-23 22:37:50.705258
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse(
        r"""
        def f(d):
            return {1: 1, **d}

        print(f({2: 2}))
        """)
    print(DictUnpackingTransformer().visit(node))



# Generated at 2022-06-23 22:37:57.797590
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    source = '{1: 1, **a, **b, 2: 2, **c}'
    expect = '''
_py_backwards_merge_dicts([{1: 1, 2: 2}, a, b, c])
    '''
    inline_expect = '_py_backwards_merge_dicts([{1: 1, 2: 2}, a, b, c])'

    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)  # type: ignore
    assert astor.to_source(tree) == expect
    assert astor.to_source(tree).strip() == inline_expect

# Generated at 2022-06-23 22:38:08.206419
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_outcomes
    from ..utils import source_to_ast

    def source_to_ast_and_transform(source: str) -> Optional[ast.AST]:
        transformed = source_to_ast(source)
        if transformed:
            tree_changed = False
            transformed = DictUnpackingTransformer(tree_changed).visit(
                transformed)  # type: ignore
            if tree_changed:
                transformed = DictUnpackingTransformer(tree_changed).visit(
                    transformed)  # type: ignore
        return transformed

    def merge_dicts(res, node):
        """Asserts that function merge_dicts was used to merge dicts."""
        assert isinstance(node, ast.Call)
        assert isinstance(node.func, ast.Name)
        assert node.func

# Generated at 2022-06-23 22:38:08.773216
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:38:11.410007
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('x = {1: 1, **dict_a}')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert transformer._tree_changed
    assert result.body[0].value.value == "_py_backwards_merge_dicts([{1: 1}], dict_a)"

# Generated at 2022-06-23 22:38:18.524289
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = inspect.cleandoc("""
    x = {1: 1, **dict_a}
    """)
    expected = inspect.cleandoc("""
    _py_backwards_merge_dicts([dict({1: 1})], dict_a)
    """)
    tree = ast.parse(code)
    res_tree = DictUnpackingTransformer().visit(tree)
    res = astunparse.unparse(res_tree)
    assert res == expected, res



# Generated at 2022-06-23 22:38:19.899863
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert repr(DictUnpackingTransformer()) == "DictUnpackingTransformer()"

# Generated at 2022-06-23 22:38:25.179887
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_astunparse
    import astunparse
    program = """
        def foo(bar):
            return {1: 2, 2: 3, **bar}
    """
    module = ast.parse(program)
    transformer = DictUnpackingTransformer()
    # typed_astunparse.dump(module)
    transformer.visit(module)
    # typed_astunparse.dump(module)
    result = typed_astunparse.unparse(module)

# Generated at 2022-06-23 22:38:34.128791
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''
    def foo():
        return "Hello World"
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    def foo():
        return "Hello World"
    '''
    module = ast.parse(code)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(module)

    assert expected == astor.to_source(result).strip()


# Generated at 2022-06-23 22:38:40.027679
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{1: 1}')
    assert module.body[0].value.keys == []
    DictUnpackingTransformer(module)
    assert module.body[0].value.keys == [ast.Num(n=1), ast.Num(n=1)]
    assert module.body[1].value.id == '_py_backwards_merge_dicts'



# Generated at 2022-06-23 22:38:50.068847
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.unparse import unparse
    from .base import compile_and_check


# Generated at 2022-06-23 22:38:58.515385
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from .analyzer import TreeAnalyzer

    code = """
        def f():
            return {1: 2, **{3: 4}}
    """
    tree = parse(code)
    assert TreeAnalyzer(tree).find_nodes(ast.Call) == []

    DictUnpackingTransformer().visit(tree)

    assert TreeAnalyzer(tree).find_nodes(ast.Call) == [
        {'func': {'id': '_py_backwards_merge_dicts'}}
    ]


# Generated at 2022-06-23 22:39:03.175363
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """\
    {1: 1, 2: 2, **dict_a}
    """
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert code in merge_dicts.get_body()
    assert tree.body[0].value.func.id == '_py_backwards_merge_dicts'

# Generated at 2022-06-23 22:39:12.668402
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    snippet1 = """
    {1: 2, **{'a': 3}}
    """
    expected_output_snippet1 = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    def _py_backwards_merge_dicts([{1: 2}], {'a': 3})
    """
    # FIXME: there is a bug in typed-ast
    # assert snippet1 == expected_output_snippet1

    snippet2 = """
    {1: 2, 3: 4, **{'a': 3}}
    """

# Generated at 2022-06-23 22:39:16.794451
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from untyped.types import to_source
    code = to_source(DictUnpackingTransformer().visit(merge_dicts.get_ast()))
    assert code == merge_dicts.get_source()


# Generated at 2022-06-23 22:39:20.004727
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert_equal(
        DictUnpackingTransformer().visit(ast.parse("{1: 1, **dict_a}")),
        ast.parse("\n".join(merge_dicts().get_body() + ["{1: 1, **dict_a}"])))


# Generated at 2022-06-23 22:39:27.740971
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_base import transform_test_node

# Generated at 2022-06-23 22:39:38.061316
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from pytest import raises
    transformer = DictUnpackingTransformer()
    assert transformer._split_by_None([
        (None, ast.Name(id='b')),
        (ast.Name(id='a'), ast.Name(id='b'))]) == [
        ast.Name(id='b'),
        [(ast.Name(id='a'), ast.Name(id='b'))]]

    with raises(AssertionError):
        transformer._split_by_None([(None, None)])

    node = ast.Dict(
        keys=[None, ast.Name(id='a'), None],
        values=[ast.Name(id='b'), ast.Name(id='b'), ast.Name(id='c')])
    transformer.visit_Dict(node)
    assert transformer._tree_changed is True


# Generated at 2022-06-23 22:39:43.438772
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = textwrap.dedent("""\
    {'a': 1, **{'b': 2}, 'c': 3}
    """)
    expected = textwrap.dedent("""\
    _py_backwards_merge_dicts([dict({'a': 1}), dict({'b': 2})], dict({'c': 3}))
    """)
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == expected

# Generated at 2022-06-23 22:39:52.738617
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    from ..py_to_py.compiler_constants import consts_of_compiler, consts_types
    import typed_ast

    with consts_of_compiler(consts_types.PY_PARSE_ONLY):
        import typed_ast.ast3 as typed_ast
        from ..py_to_py.compiler import compile_py_compile_mode
        from ..py_to_py.compiler_helpers import indent

    dict_unpacking_transformer = DictUnpackingTransformer()
    module = typed_ast.parse(dedent(
        '''
        {
            1: 1,
            **a,
            3: 3,
            **b,
            5: 5,
            **c
        }
        '''
    ))

# Generated at 2022-06-23 22:39:53.825984
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer.__name__ == 'DictUnpackingTransformer'

# Generated at 2022-06-23 22:39:59.871186
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    class DictUnpackingFixture(DictUnpackingTransformer):
        """"Fixture" with changed visit_Dict method, which returns node as is."""
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return node

    def assert_dict_compiling_to(src: str, expected: str) -> None:
        """Asserts that input compile to expected."""
        mod = ast.parse(src)
        actual = DictUnpackingFixture().visit(mod)
        actual = ast.fix_missing_locations(actual)
        actual = compile(actual, '', 'exec')
        exec(actual, {})

        assert_equal(expected, DictUnpackingFixture._uncompiled_code_)

    #

# Generated at 2022-06-23 22:40:10.551966
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
    def test(a, b, c):
        a = {'a': 1, 'b': 2, **b, 'c': 3, **c} 
        b = {1: 1, **c, **a, 2: 2}
    """
    expected_source = """
    def test(a, b, c):
        a = _py_backwards_merge_dicts([{'a': 1, 'b': 2}, b, {'c': 3}], c)
        b = _py_backwards_merge_dicts([{1: 1}, c, {'a': 1, 'b': 2, 'c': 3}, {2: 2}])
    """
    tree = ast.parse(source)
    res_tree = DictUnpackingTransformer().visit(tree)
    res

# Generated at 2022-06-23 22:40:19.644919
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import test_utils
    from ..utils.test_utils import ExpectedNodeAssertion

    def run_test(node, expected):
        transformer = DictUnpackingTransformer()
        result = transformer.visit(node)
        expected = ExpectedNodeAssertion(
            expected,
            [
                dict(module='typed_ast.ast3', node=result)
                for result in transformer.rewrite_module(ast.parse(merge_dicts()))
            ])
        expected.assert_(result)


# Generated at 2022-06-23 22:40:21.804493
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert isinstance(transformer, BaseNodeTransformer)
    assert transformer.target == (3, 4)


# Generated at 2022-06-23 22:40:25.671817
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    source = """
{1: 2, **{}, **{3: 4}, 5: 6}
"""
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)


# Generated at 2022-06-23 22:40:26.269825
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-23 22:40:30.307032
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.snippet import snippet
    from .unpacking import UnpackingTransformer

    with snippet('{1: 2, **a, 3: 4, **b, 5: 6, **c}'):
        dict = ast.parse(snippet.snippet).body[0].value
    dict = UnpackingTransformer().visit(dict)
    result = astor.to_source(DictUnpackingTransformer().visit(dict))

    assert (
        result ==
        "_py_backwards_merge_dicts([{1: 2, 3: 4, 5: 6}], a, b, c)"
    )

# Generated at 2022-06-23 22:40:39.576405
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    def run(src: str) -> str:
        node = ast.parse(src)
        return astor.to_source(DictUnpackingTransformer().visit(node)).rstrip()

    assert run('{1: 1, **dict_a}') == '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    assert run('{1: 1, 2: 2, **dict_a}') == '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)'
    assert run('{1: 1, 2: 2, **dict_a, 5: 5}') == '_py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {5: 5}])'
   

# Generated at 2022-06-23 22:40:46.642677
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
    [{1: 1, **dict_a}, {'x': 5, **dict_b}]
    """
    expected_code = """
    _py_backwards_merge_dicts = lambda dicts: (
    reduce(lambda x, y: dict(x, **y), dicts))
    [_py_backwards_merge_dicts([{1: 1}], dict_a), _py_backwards_merge_dicts([{'x': 5}], dict_b)]
    """
    node = ast.parse(code)
    assert node == ast.parse(expected_code)



# Generated at 2022-06-23 22:40:54.491867
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a = ast.parse('{1: 1, **{2: 2}}')  # type: ignore
    b = ast.parse('{1: 1, **{2: 2}}')  # type: ignore
    result = DictUnpackingTransformer(a).visit(b)
    assert ast.dump(result) == ast.dump(ast.parse('def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n_py_backwards_merge_dicts([{1: 1}], {2: 2})'))  # type: ignore

# Generated at 2022-06-23 22:40:58.107884
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    inp = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    node = ast.parse(inp)
    node = DictUnpackingTransformer().visit(node)
    assert expected == ast.unparse(node)



# Generated at 2022-06-23 22:41:08.972721
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_base import BaseNodeTransformerTestCase
    import astor

    class TestCase(BaseNodeTransformerTestCase):
        transformer = DictUnpackingTransformer

        def test_dict_unpacking(self):
            assert_transform(
                '{1: 2, **dict_a}',
                '_py_backwards_merge_dicts([{1: 2}], dict_a)',
            )

        def test_dict_unpacking_2(self):
            assert_transform(
                '{1: 2, **{}, **dict_a}',
                '_py_backwards_merge_dicts([{1: 2}, dict()], dict_a)',
            )


# Generated at 2022-06-23 22:41:15.070775
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_utils import roundtrip, force_ast

    code1 = """\
y, z = x
{**y, **z}
"""  # type: ignore
    code2 = """\
y, z = x
_py_backwards_merge_dicts([], y, z)
"""
    assert roundtrip(code1, force_ast(code1), DictUnpackingTransformer) == code2


# Generated at 2022-06-23 22:41:22.251437
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from astunparse import unparse

    class DUT(DictUnpackingTransformer):
        _tree_changed = False
        _int_calls = 0
        _int_visits = 0

    src = """\
{1: 1, **{2: 2}, 3: 3, **{4: 4}, **{5: 5}}
    """
    tree = ast.parse(src)
    node = tree.body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Dict)

    DUT().visit(tree)


# Generated at 2022-06-23 22:41:31.306524
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from .make_visitor import make_visitor
    from .test_utils import assert_source

    assert_source(
        DictUnpackingTransformer(make_visitor()).visit(
            ast3.parse('{1: 1, 2: 2, 3: 3, 4: 4, **{5: 5, 6: 6}}')),
        
        'new_body',
        
        '_py_backwards_merge_dicts([dict({1: 1, 2: 2, 3: 3, 4: 4}), '
        'dict({5: 5, 6: 6})])')

# Generated at 2022-06-23 22:41:32.305743
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert inspect.isclass(DictUnpackingTransformer)

# Generated at 2022-06-23 22:41:33.869247
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert t


# Generated at 2022-06-23 22:41:37.223694
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): # type: ignore
    class Mock(object):
        pass
    
    transformer = DictUnpackingTransformer(Mock())
    assert type(transformer) is DictUnpackingTransformer

# Generated at 2022-06-23 22:41:38.083019
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-23 22:41:39.052954
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:42.647442
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert ast.parse(
        dedent('''\
        x = {1: 1, **dict_a}
        ''')) == DictUnpackingTransformer().visit(ast.parse(
            dedent('''\
            from vyper.compile_lll import parser
            x = _py_backwards_merge_dicts([{1: 1}], dict_a)
            ''')))



# Generated at 2022-06-23 22:41:43.502847
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    obj = DictUnpackingTransformer()

# Generated at 2022-06-23 22:41:45.733140
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse('x = {1: 1, **a, **b, 2: 2}')
    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-23 22:41:55.705712
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3
    from typed_ast import ast27
    from typed_ast.ast3 import Module
    from ..visitor import Visitor

    class Checker(Visitor):
        def visit_Name(self, node):
            assert isinstance(node, ast3.Name)

        def visit_List(self, node):
            assert isinstance(node, ast3.List)

        def visit_Module(self, node):
            assert isinstance(node, Module)

        def visit_FunctionDef(self, node):
            assert isinstance(node, ast3.FunctionDef)

        def visit_arguments(self, node):
            assert isinstance(node, ast3.arguments)

        def visit_arg(self, node):
            assert isinstance(node, ast3.arg)


# Generated at 2022-06-23 22:42:02.801651
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    expected = ast.Module(body=[
        merge_dicts.get_body(),  # type: ignore
        ast.Expr(value=ast.Dict(keys=[None, None], # type: ignore
                                values=[
                                    ast.Dict(keys=[], values=[]),
                                    ast.Dict(keys=[], values=[]),
                                    ast.Dict(keys=[], values=[]),
                                ]))
    ])
    assert DictUnpackingTransformer()(
        ast.parse('{\n'
                  '    1: 2,\n'
                  '    **{},\n'
                  '    **{},\n'
                  '    **{},\n'
                  '}')
    ) == expected

# Generated at 2022-06-23 22:42:13.535365
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .transformer_test_case import TrasformerTestCase, make_suite

    class DictUnpackingTransformerTestCase(TrasformerTestCase):
        transformer = DictUnpackingTransformer

        def test_0001(self):
            src = """
            d = {1: 2, **{3: 4}}
            d = {1: 2, **{3: 4}, 5: 6}
            d = {1: 2, **{3: 4}, 5: 6, **{7: 8}}
            d = {1: 2, **{3: 4}, 5: 6, **{7: 8}, 9: 10}
            """

# Generated at 2022-06-23 22:42:20.032800
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    from ..utils.ast_helpers import dump
    transformer = DictUnpackingTransformer()
    code = '{1:2, 3:4, **dict_a}'
    expected_code = '_py_backwards_merge_dicts([{1: 2, 3: 4}], dict_a)'
    module = ast.parse(code)
    transformer.visit(module)
    assert astunparse.unparse(module) == dump(expected_code, mode='exec')

# Generated at 2022-06-23 22:42:26.619286
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import parse, dump
    from ..utils.source import dedent
    from . import run_transformer_on_single_node, SingleNodeTransformer

    source = dedent("""
    def a():
        b = {1: 2, **c, **d, 4: d, 5: e}
    """)
    expected = dedent("""\
    def a():
        b = _py_backwards_merge_dicts([{1: 2}, None, None, {4: d}], c, d, {5: e})
    """)

    tree = parse(source)
    node = run_transformer_on_single_node(SingleNodeTransformer(DictUnpackingTransformer), tree)
    assert dump(node) == expected

# Generated at 2022-06-23 22:42:30.810721
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert 'class' in str(DictUnpackingTransformer)
    assert 'BaseNodeTransformer' in str(DictUnpackingTransformer)
    assert '__init__' in str(DictUnpackingTransformer)


# Generated at 2022-06-23 22:42:41.836091
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    from .test_helpers import assert_no_difference, assert_transformed

    # Case no unpacking
    code = dedent('''\
    {True: 1, False: 2}''')
    expected = dedent('''\
    {True: 1, False: 2}''')
    assert_no_difference(DictUnpackingTransformer, code, expected)

    # Case one unpacking
    code = dedent('''\
    {
        True: 1,
        **dict_a
    }''')
    expected = dedent('''\
    _py_backwards_merge_dicts([{True: 1}], dict_a)''')
    assert_transformed(DictUnpackingTransformer, code, expected)

    # Case three unpacking


# Generated at 2022-06-23 22:42:48.678090
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import check
    from ..utils.test_utils import assert_in
    from ..utils.test_utils import assert_not_in
    from ..utils.test_utils import get_ast_node_at_line
    from ..utils.test_utils import get_function_body_lines

    code = """
        def f():
            return {'a': 1, 'b': 2}
    """
    expected_body = """
        def f():
            return _py_backwards_merge_dicts([{'a': 1, 'b': 2}])
    """
    check(code, expected_body, DictUnpackingTransformer)



# Generated at 2022-06-23 22:42:52.455029
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse('{1: 2, **d}')
    assert DictUnpackingTransformer().visit(module) == '_py_backwards_merge_dicts([{1: 2}], d)'

# Generated at 2022-06-23 22:42:53.868875
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:58.374474
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.codegen import to_source
    from typed_ast import ast3 as ast
    
    definition = ast.parse('''{1: 1, **dict_a}''')
    transformer = DictUnpackingTransformer()
    transformed = transformer.visit(definition)

# Generated at 2022-06-23 22:42:58.985842
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass


# Generated at 2022-06-23 22:43:05.530199
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest
    import typed_ast.ast3 as ast
    from dffml.util.test import TestCase

    class TestDictUnpackingTransformer_visit_Dict(TestCase):
        def test_no_unpacking(self):
            class MyVisitor(ast.NodeVisitor):
                def visit_Keyword(self, node):
                    return "keyword"

            class DUT(DictUnpackingTransformer):
                def visit_Keyword(self, node):
                    return self.generic_visit(node)

            node = ast.parse(
                "{1: 1, 'a': 'a', 'b': 'b', **{'c': 'c'}}"
            )

            v = MyVisitor()
            self.assertNotIn("keyword", ast.dump(node))

# Generated at 2022-06-23 22:43:14.750883
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Arrange
    from typed_ast import ast3
    from .base import BaseNodeTransformer
    from ..utils.tree import find_subclasses
    a_dict = ast3.Dict(keys=[
        ast3.Num(n=1),
        None,
        ast3.Name(id='b', ctx=ast3.Load())
        ], values=[
        ast3.Num(n=1),
        ast3.Name(id='dict_a', ctx=ast3.Load()),
        ast3.Num(n=2)
    ])

# Generated at 2022-06-23 22:43:15.730983
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()

# Generated at 2022-06-23 22:43:24.329806
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .unparse import Unparser
    from .parse import parse
    from .transforms import ParentNodeTransformer

    # noinspection PyProtectedMember
    code = DictUnpackingTransformer._simplify_dict(
        "{1: 1, **{2: 2, 3: 3}, 4: 4, **{5: 5, 6: 6}}")

# Generated at 2022-06-23 22:43:35.341913
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

# Generated at 2022-06-23 22:43:44.031166
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('{1: 1, **{2: 2}, 3: 3, **{4: 4}, **{5: 5}}')
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 22:43:52.595033
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = '{1: 1, **dict_a}'
    expected = 'def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n\ndict({1: 1}, **dict_a)'
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    actual = ''.join(compile(tree, '', 'exec').co_code.decode()[1:])  # type: ignore
    assert expected == actual

# Generated at 2022-06-23 22:44:03.723084
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:44:05.954468
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:11.225376
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Because testing visit_Call too
    class DictUnpackingTransformer(DictUnpackingTransformer):
        def __call__(self, source: str) -> str:
            tree = ast.parse(source)
            tree = self.visit(tree)
            return ast.unparse(tree)

    transformer = DictUnpackingTransformer()

    assert transformer('{1: 1, **dict_a}') == '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    assert transformer('{1: 1, 2: 2, **dict_a}') == '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)'

    # with double **

# Generated at 2022-06-23 22:44:21.986600
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from _ast import parse
    from ..utils.transformer import transform

    transform_ = transform(DictUnpackingTransformer)


# Generated at 2022-06-23 22:44:29.806329
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = '''\
    {1: 1, 2: 2, **dict_a}
    '''
    expected = '''\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    '''
    actual = DictUnpackingTransformer().visit(ast.parse(source))
    assert ast.dump(actual) == expected

# Generated at 2022-06-23 22:44:38.487897
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .transforms.unparse import unparse
    from .transforms.parse import parse
    from .transforms.to_source import to_source
    if sys.version_info < (3, 4):
        return
    program = '''
{1: 1}
'''
    expected = '''
_py_backwards_merge_dicts([{1: 1}])
'''
    tree = parse(program)
    expected_tree = parse(expected)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    assert unparse(result) == unparse(expected_tree)
    assert to_source(result) == expected


# Generated at 2022-06-23 22:44:41.697741
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.asserts import assert_expression

    assert_expression(DictUnpackingTransformer, '{1: 2, **x}', '_py_backwards_merge_dicts([{1: 2}], x)')

# Generated at 2022-06-23 22:44:43.156730
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dut = DictUnpackingTransformer()
    assert isinstance(dut, BaseNodeTransformer)


# Generated at 2022-06-23 22:44:50.747149
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..testing.utils import expect_tree
    from ..testing.transformations import assert_equal_modules
    from .utils.test_utils import assert_tree_unchanged
    from .utils.test_utils import make_tree

    test_case = "__builtin__.dict()"
    expect_tree(test_case, {'_py_backwards_merge_dicts': "import builtins"})
    test_case = "__builtin__.dict()\n__builtin__.dict()"
    expect_tree(test_case, {'_py_backwards_merge_dicts': "import builtins"})

    test_case = "def f():\n    __builtin__.dict()\n    __builtin__.dict()"

# Generated at 2022-06-23 22:44:59.050855
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..ast_utils import module_to_str
    from ..utils.tree import find_all_subclasses
    from itertools import chain

    nodes = {
        'Dict': ast.Dict,
        'Str': ast.Str,
        'Name': ast.Name,
        'Call': ast.Call,
        'List': ast.List,
    }

# Generated at 2022-06-23 22:45:05.034176
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    text = """{1: 1, **dict_a}"""
    tree = ast.parse(text)
    tree = transformer.visit(tree)
    expected = (
        "def _py_backwards_merge_dicts(dicts):\n"
        "    result = {}\n"
        "    for dict_ in dicts:\n"
        "        result.update(dict_)\n"
        "    return result\n\n"
        "_py_backwards_merge_dicts([{1: 1}], dict_a)\n"
    )
    actual = ast.unparse(tree)
    assert actual == expected


# Generated at 2022-06-23 22:45:15.935062
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """{
        # comment
        1: 1,
        # comment
        [2, 3, 4]: 3,
        # comment
        None: 2,
        # comment
        2: 2,
        # comment
        **dict_a
    }
    """
    expected = """{# comment
    1: 1,
    # comment
    [
        2,
        3,
        4
    ]: 3,
    # comment
    None: 2,
    # comment
    2: 2}

# comment
_py_backwards_merge_dicts([{1: 1, [2, 3, 4]: 3, None: 2, 2: 2}], dict_a))
    """
    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)
    assert ast

# Generated at 2022-06-23 22:45:23.018509
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Test for DictUnpackingTransformer.visit_Module()."""
    transformer = DictUnpackingTransformer()
    result = transformer.visit(ast.parse('{1: 1, 2: 2}.get(42)'))
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1, 2: 2}]).get(42)')
    assert ast.dump(result) == ast.dump(expected)
    assert transformer._tree_changed

# Generated at 2022-06-23 22:45:27.223214
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    example = """\
{'this':1, 'is': 2, **k, None: 42}
"""

    expected = """\
_py_backwards_merge_dicts([{'this': 1, 'is': 2}, k, {None: 42}])
"""


# Generated at 2022-06-23 22:45:29.686128
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    class Foo:
        def __init__(self, a: int) -> None:
            pass
    foo = Foo(a=3)
    print({3: 3, **foo})

# Generated at 2022-06-23 22:45:33.624833
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from . import do_transform

    do_transform(DictUnpackingTransformer,
                 expected_source=merge_dicts.get_source(),
                 source="""
    {1:1, **{2:2}}
    """)


# Generated at 2022-06-23 22:45:34.518987
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:45:35.781330
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:45:45.642793
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Unit test for method visit_Module of class DictUnpackingTransformer."""

    tree = ast.parse(
        '''
        {
            **dict(
                a=1,
            ),
            **dict(
                b=2,
            ),
        }
        ''')
    tree_ = ast.parse(
        '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([
            dict(
                a=1,
            ),
            dict(
                b=2,
            )
        ])
        ''')

# Generated at 2022-06-23 22:45:46.488121
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:45:53.268724
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import sys
    module = ast.parse('''
{1: 2, None: {3: 4}, 5: 6, **a, 7: 8}
    ''', filename='', mode='exec')
    transformer = DictUnpackingTransformer()
    transformer.visit(module)
    assert str(module) == '''
_py_backwards_merge_dicts([dict({1: 2}), {3: 4}, dict({5: 6}), a, dict({7: 8})])
'''



# Generated at 2022-06-23 22:46:03.426349
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3
    ...  # type: ignore
    code = '{1: 1, **a, 2: 2, **b, 3: 3}'
    module = ast3.parse(code)
    transformed = DictUnpackingTransformer().visit(module)
    expected = ast3.parse("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{
        1: 1,
        2: 2,
        3: 3,
    }], a, b)
    """)
    assert ast3.dump(transformed) == ast3.dump(expected)

# Generated at 2022-06-23 22:46:13.722684
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .fake_ast import fake_ast_Module

    # from mypy.test.helpers import assert_string_arrays_equal
    # from typed_ast import ast3 as ast

    # from ..transforms.dict_unpacking import DictUnpackingTransformer
    dut = DictUnpackingTransformer()

    lhs = fake_ast_Module()

    # lhs

# Generated at 2022-06-23 22:46:21.710110
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:46:27.274031
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import parse_snippet

    # noinspection PyUnresolvedReferences
    globals().update(locals())

    _result = DictUnpackingTransformer().visit(parse_snippet('a **b'))
    # noinspection PyUnresolvedReferences
    # assert _result == _py_backwards_merge_dicts([{}], a, b), repr(_result)

# Generated at 2022-06-23 22:46:28.761011
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    assert x is not None

# Generated at 2022-06-23 22:46:37.297433
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.tree import tree_to_str
    from . import transform

    tree_str = """
        {**dict_c, 2: 2, **dict_a, 1: 1, **dict_b}
    """
    expected_tree_str = """
        _py_backwards_merge_dicts([
            dict(dict_c),
            {2: 2},
            dict(dict_a),
            {1: 1},
            dict(dict_b)
        ])
    """

    tree = ast.parse(tree_str)
    expected_tree = ast.parse(expected_tree_str)
    tree_to_str.__config__['indent'] = '    '
    tree = transform(tree, DictUnpackingTransformer)
    tree_str = tree_to_str(tree)
   

# Generated at 2022-06-23 22:46:38.496831
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass


# Generated at 2022-06-23 22:46:49.400802
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    transformer = DictUnpackingTransformer()

# Generated at 2022-06-23 22:46:52.150830
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():  # noqa: F811
    """Test constructor of class DictUnpackingTransformer"""
    transformer = DictUnpackingTransformer()
    assert transformer.target == (3, 4)

# Generated at 2022-06-23 22:46:56.186071
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    input_ast = ast.parse('''
{1: 2, **{3: 4}}
''')
    expected_ast = ast.parse('''
_py_backwards_merge_dicts([{1: 2}], {3: 4})
''')
    transformer = DictUnpackingTransformer()
    actual_ast = transformer.visit(input_ast)
    assert ast.dump(actual_ast) == ast.dump(expected_ast)
    assert transformer._tree_changed is True



# Generated at 2022-06-23 22:47:02.825829
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_in = """
        {'a': 1, **dict_a}
        """

    test_out = """
        _py_backwards_merge_dicts([{'a':1}], dict_a)
        """

    linter, ctx = compile_snippet(
        DictUnpackingTransformer,
        test_in,
        additional_imports=['typed_ast.ast3'])

    linter.visit(ctx['node'])
    assert str(ctx['node']) == test_out



# Generated at 2022-06-23 22:47:14.110319
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_ast_tree = '''
Module(body=[
    Dict(keys=[Str(s='STRING')], values=[Num(n=10)]),
    Expr(value=Dict(keys=[Str(s='STRING2'), None], values=[Num(n=10), Call(func=Name(id='DICT', ctx=Load()), args=[], keywords=[])]))])
    '''

# Generated at 2022-06-23 22:47:15.577871
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer



# Generated at 2022-06-23 22:47:24.915112
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import loads
    from ..utils.method import get_method_values

    class test:

        def function(self):
            return {
                'a': 1,
                **{'b': 2, 'c': 3},
                'd': 4,
                **{'e': 5, 'f': 6, 'g': 7,
                   **{'h': 8, 'i': 9}},
                'j': 10,
            }


# Generated at 2022-06-23 22:47:30.663797
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast_transformer
    transformer = ast_transformer.create_transformer(DictUnpackingTransformer)

    node = ast.parse('''
        {1: 2, **{3: 4}}
    ''')
    assert transformer.visit(node) == ast.parse('''
        _py_backwards_merge_dicts([{1: 2}], {3: 4})
    ''')

    node = ast.parse('''
        {1: 2, 3: 4, **{5: 6}}
    ''')
    assert transformer.visit(node) == ast.parse('''
        _py_backwards_merge_dicts([{1: 2, 3: 4}], {5: 6})
    ''')


# Generated at 2022-06-23 22:47:31.372240
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:47:32.845178
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = 'x = {1: 0, 2: 1}'

# Generated at 2022-06-23 22:47:39.137012
# Unit test for method visit_Dict of class DictUnpackingTransformer