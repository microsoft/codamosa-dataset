

# Generated at 2022-06-23 22:37:43.388590
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    expected = _py_backwards_merge_dicts([{1: 1}, {2: 2}, {3: 3}, {4: 4}],
                                         {5: 5, 6: 6})

    @snippet
    def program():
        a = {1: 1, **{2: 2, **{3: 3, **{4: 4}}}, 5: 5, 6: 6}

    module = ast.parse(program.get_body())
    DictUnpackingTransformer(None).visit(module)
    result = module.body[-1].value.value

    assert isinstance(result, ast.Call)
    assert isinstance(result.func, ast.Name)
    assert ast.dump(result.func) == ast.dump(expected.__code__.co_consts[0])

# Generated at 2022-06-23 22:37:45.129527
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer.__name__ == 'DictUnpackingTransformer'

# Generated at 2022-06-23 22:37:55.587412
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """Test snippet"""
    transformer = DictUnpackingTransformer()
    source = """
        { 1, 2, **dict1, 3, 4, **dict2 }
    """
    expected = """
        _py_backwards_merge_dicts([{1, 2}, {3, 4}], dict1, dict2)
    """
    tree = ast.parse(source)
    transformer.visit(tree)
    code = compile(tree, filename='<ast>', mode='exec')
    ns = {}
    exec(code, ns, ns)
    assert ns['_py_backwards_merge_dicts'] == merge_dicts.get_body()
    result = tree.body[0].value
    assert ast.dump(result) == ast.dump(ast.parse(expected).body[0].value)

# Generated at 2022-06-23 22:37:59.255297
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    check_transform([DictUnpackingTransformer], ['{1: 2, **{3: 4}']),

# Generated at 2022-06-23 22:38:08.925329
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class TestTransformer(DictUnpackingTransformer):
        def visit_Dict(self, node: ast.Dict) -> Union[ast.Dict, ast.Call]:
            return super().visit_Dict(node)

    assert TestTransformer().visit(ast.parse(dedent(
        """\
        {1: 1, **dict_a}
        """))) == ast.parse(dedent(
        """\
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """))


# Generated at 2022-06-23 22:38:12.356001
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import compile, unpythonize
    from ..utils.testing import assert_unpythonized

    unpythonized = unpythonize(compile(DictUnpackingTransformer, {
        'a': 1,
        **{'b': 2}
    }))

    expected = unpythonize("""
    {
        'a': 1,
        **{
            'b': 2
        }
    }
    """)

    assert_unpythonized(expected, unpythonized)

# Generated at 2022-06-23 22:38:13.811342
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:38:16.103277
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """Make sure that constructor of class DictUnpackingTransformer"""
    """doesn't throw errors"""
    assert str(DictUnpackingTransformer())

# Generated at 2022-06-23 22:38:24.710116
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:38:25.489221
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()

# Generated at 2022-06-23 22:38:31.954864
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('{1:1, **a}\nclass A:pass\n{1:1, **a}')
    DictUnpackingTransformer().visit(tree)
    assert 'def _py_backwards_merge_dicts:' in tree.body[0].body[0].decorator_list[0].id

# Generated at 2022-06-23 22:38:33.380266
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    ast.parse('{1: 1, **{2: 2}}')


# Generated at 2022-06-23 22:38:38.913101
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ...compile import make_function

    def test(n: int) -> dict:
        return {
            1: 1,
            2: 2,
            **{n: n},
            3: 3,
            **{n + 1: n + 1},
            4: 4,
        }

    f = make_function(test)

    assert f(10) == {1: 1, 2: 2, 10: 10, 3: 3, 11: 11, 4: 4}



# Generated at 2022-06-23 22:38:46.536874
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import HumanReadable
    from ..utils import print_ast
    from .type_checking import TypeCheckingTransformer

    code = '''\
    x = {1: 2}
    y = {"a": "b", **x}
    '''
    module = ast.parse(code)
    new_module = DictUnpackingTransformer().visit(module)  # type: ignore
    TypeCheckingTransformer().visit(new_module)  # type: ignore

# Generated at 2022-06-23 22:38:54.627928
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert get_node(DictUnpackingTransformer, '''
        {1: 1}
    ''') == '''
        dict((1, 1))
    '''

    assert get_node(DictUnpackingTransformer, '''
        {1: 1, 2: 2}
    ''') == '''
        {1: 1, 2: 2}
    '''

    assert get_node(DictUnpackingTransformer, '''
        {1: 1, **a}
    ''') == '''
        _py_backwards_merge_dicts([{1: 1}], a)
    '''

    assert get_node(DictUnpackingTransformer, '''
        {**a}
    ''') == '''
        a
    '''


# Generated at 2022-06-23 22:39:03.306414
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..parser import parse
    from ..utils.tests import generate_tests, simulate_ast_walk
    from .base import NodeTransformerTestCase

    class DictUnpackingTransformerTestCase(NodeTransformerTestCase):
        transformer = DictUnpackingTransformer

    generate_tests(DictUnpackingTransformerTestCase,
                   globals(),
                   [
                       '_py_backwards_merge_dicts = lambda: None',
                       '{a: 1, **dict_a}',
                   ],
                   parse=parse,
                   simulate_walk=simulate_ast_walk)



# Generated at 2022-06-23 22:39:04.127570
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:39:05.369746
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None


# Generated at 2022-06-23 22:39:14.477720
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:39:15.126140
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass

# Generated at 2022-06-23 22:39:16.729322
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    _ = DictUnpackingTransformer()

# Generated at 2022-06-23 22:39:21.486745
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    node = ast.parse(r"""{1: 2, **{1: 2}, 2: 3, **{2: 3}}""")
    expected = """
dict_a = {1: 2}
dict_b = {2: 3}
merge_dicts(dict(), dict_a, dict_b)
"""

    transformed = DictUnpackingTransformer().visit(node)
    result = astor.to_source(transformed).strip()
    assert result == expected, result



# Generated at 2022-06-23 22:39:28.696268
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .. import compile_isolated
    from .. import parse

    source = merge_dicts.get_source()
    module = parse(source)
    tree = DictUnpackingTransformer().visit(module)  # type: ignore
    assert isinstance(tree, ast.Module)
    code = compile_isolated(tree, {'typing'})
    assert _py_backwards_merge_dicts([], {}) == {}
    assert _py_backwards_merge_dicts([{1: 2}, {1: 0}], {}) == {1: 0}
    assert _py_backwards_merge_dicts([{1: 2}, {1: 0}], {2: 3}) == {1: 0, 2: 3}

# Generated at 2022-06-23 22:39:37.374705
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from .dict_unpacking_transformer import DictUnpackingTransformer
    from .codegen import to_source
    
    code = '{1: 1, **dict_a, **dict_b, 2: 2}'
    expected_code = '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)'
    ast_tree = ast.parse(code)
    transformer = DictUnpackingTransformer()
    actual_ast = transformer.visit(ast_tree)
    actual_code = to_source(actual_ast)
    assert actual_code == expected_code

# Generated at 2022-06-23 22:39:38.272305
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:39:39.520538
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer



# Generated at 2022-06-23 22:39:47.390296
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_utils import make_test, get_test_ast


# Generated at 2022-06-23 22:39:48.134876
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:39:55.753218
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import assign_positions
    from ..utils.unparser import Unparser
    from typed_astunparse import unparse as unparse_typed_ast

    unparse = Unparser(single_newline_nodes=('Module', ))
    unparse_typed_ast = Unparser(single_newline_nodes=('Module', ),
                                 include_encoding_declaration=False)

    class FakeTransformer(DictUnpackingTransformer):
        def visit_Dict(self, node):
            return node

    def test(code, expected):
        unparse_expected = unparse(expected)
        unparse_expected_typed = unparse_typed_ast(expected)
        tree = ast.parse(code, mode='eval')
        assign_positions(tree)
        transformer = FakeTrans

# Generated at 2022-06-23 22:40:00.462829
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from compilation.visitors import DictUnpackingTransformer
    from compiled import DictUnpackingTransformer as DictUnpackingTransformer_out
    from compilation import ModuleTransformer
    from .fixtures import DictUnpackingTransformer as DictUnpackingTransformer_in

    m_in = ModuleTransformer(DictUnpackingTransformer_in)
    m_in.transform()  # type: ignore
    m_out = ModuleTransformer(DictUnpackingTransformer_out)
    m_out.transform()  # type: ignore

    assert m_in.module == m_out.module

# Generated at 2022-06-23 22:40:11.027300
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import sys
    from ast import parse

    t = DictUnpackingTransformer()

    module = parse('''\
        a = {**foo, 1: 1, 2: 2}
        ''')
    assert t.visit(module) == parse('''\
        from __future__ import annotations
        a = _py_backwards_merge_dicts([{2: 2}], foo, {1: 1})''')
    assert module == parse('''\
        a = {**foo, 1: 1, 2: 2}
        ''')

    module = parse('''\
        a = {**foo, 1: 1, **bar, 2: 2}
        ''')

# Generated at 2022-06-23 22:40:12.017040
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:20.926506
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse(
        '''\
{1: 1, **dict_a}
{2: 2, **dict_a, **dict_b}
{3: 3, **dict_a, **dict_b, 4: 4, **dict_c}
{5: 5, 6: 6, **dict_a, 7: 7, **dict_b, 8: 8, **dict_c}
        ''')

    result = DictUnpackingTransformer().visit(module)


# Generated at 2022-06-23 22:40:22.988821
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    input_source = '''\
{1: 1, **dict_a}
'''

# Generated at 2022-06-23 22:40:29.892858
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    imports = ast.parse('from typed_ast import ast3')
    code = ast.parse(
        '{1: 1, **dict_a}'
    )
    code.body.insert(0, imports)
    actual = compile(DictUnpackingTransformer().visit(code), '', 'eval')  # type: ignore
    expected = eval(
        '_py_backwards_merge_dicts([dict([(1, 1)])], dict_a)'
    )  # type: ignore
    assert expected == actual

# Generated at 2022-06-23 22:40:37.499807
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    snippet.prepare(DictUnpackingTransformer)

    node = ast.parse('''
        a = {1: 1, **x}
    ''')

    result = snippet.apply(DictUnpackingTransformer, node)
    expected = ast.parse('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        a = _py_backwards_merge_dicts([{1: 1}], x)
    ''')

    assert result == expected, 'Wrong result of applying DictUnpackingTransformer, function visit_Module'


# Generated at 2022-06-23 22:40:43.498975
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test1 import CompileTest as TestCase

    tests = [
        [[], '{1: 1}', '{1: 1}'],
        [[], '{1: 1, **dict_a}', '_py_backwards_merge_dicts([{1: 1}], dict_a)'],
    ]

    for backend, input, expected in tests:
        with TestCase(backend=backend):
            tree = parse(input)
            expected_tree = parse(expected)
            new_tree = DictUnpackingTransformer().visit(tree)
            assert compare_ast(new_tree, expected_tree)

# Generated at 2022-06-23 22:40:44.719301
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:48.718095
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse('{1: 1, **dict_a, 2: 2, **dict_b, **dict_c}')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)

# Generated at 2022-06-23 22:40:50.008205
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:40:50.992277
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:59.107237
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    original_code = """\
        a = {1: 2}
        b = {**a}
        c = {5: 6, **b}
        d = {5: 6, **b, **a}
    """
    transformed_code = """\
        a = {1: 2}
        b = _py_backwards_merge_dicts((a,))
        c = _py_backwards_merge_dicts((dict(5, 6), b))
        d = _py_backwards_merge_dicts((dict(5, 6), b, a))
    """
    transformer = DictUnpackingTransformer()
    original_ast = ast.parse(original_code)
    output_ast = transformer.visit(original_ast)

# Generated at 2022-06-23 22:41:01.429152
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert not transformer._tree_changed
    assert transformer._level == 0


# Generated at 2022-06-23 22:41:06.149030
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('{1: 1, **{2: 2}, **dict_a}')
    expected = 'result = _py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a)'
    result = ast.dump(DictUnpackingTransformer().visit(node))
    assert result == expected



# Generated at 2022-06-23 22:41:08.441012
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .decorator_transformer import DecoratorTransformer

# Generated at 2022-06-23 22:41:15.691111
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    visitor = DictUnpackingTransformer()
    result = visitor.visit(ast.parse('{1: 1, **dict_a, 4: 4, **dict_b}'))
    expected = ast.parse('''
    dict_b = {4: 4, **dict_b}
    dict_a = {1: 1, **dict_a}
    result = _py_backwards_merge_dicts([dict_a, dict_b])
    ''')
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-23 22:41:23.490150
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .visitor import StandardVisitor
    from astor import dump_tree

    class ResultViewer(StandardVisitor):
        def visit_Call(self, node):
            assert '_py_backwards_merge_dicts' == node.func.id
            args = list(node.args)
            assert 3 == len(args)
            assert ast.Dict(keys=[ast.Num(n=0)], values=[ast.Num(n=1)]) == \
                args[0]
            assert 'a' == args[1].id
            assert 'b' == args[2].id


# Generated at 2022-06-23 22:41:26.382918
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    result = transformer.visit(merge_dicts.get_ast())
    assert isinstance(result, ast.Module)
    assert transformer.tree_changed



# Generated at 2022-06-23 22:41:35.471080
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert {1: 1, **{2: 2}} == eval(
        DictUnpackingTransformer().transform(ast.parse('{1: 1, **{2: 2}}'))
    )
    assert {1: 1, **{2: 2}, 3: 3} == eval(
        DictUnpackingTransformer().transform(ast.parse('{1: 1, **{2: 2}, 3: 3}'))
    )
    assert {1: 1, **{2: 2}, 3: 3, **{4: 4}} == eval(
        DictUnpackingTransformer().transform(ast.parse('{1: 1, **{2: 2}, 3: 3, **{4: 4}}'))
    )

# Generated at 2022-06-23 22:41:42.111379
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    import astor

    source = dedent("""
    x = {a: b, **c}
    """)

    t = DictUnpackingTransformer()
    tree = ast.parse(source)
    tree = t.visit(tree)

    expected = dedent("""
    _py_backwards_merge_dicts([{a: b}], c)
    """)

    assert astor.to_source(tree.body[0].value) == expected

# Generated at 2022-06-23 22:41:45.966107
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('{1: 1, **dict_a}')
    assert isinstance(tree, ast.Module)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == \
        "Module(body=[_py_backwards_merge_dicts([{1: 1}], dict_a))])"


# Generated at 2022-06-23 22:41:55.949768
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def compare(before, after):
        assert DictUnpackingTransformer().visit(before) == after

    compare({1: 1}, {1: 1})
    compare({1: 1, 2: 2}, {1: 1, 2: 2})
    compare({1: 1, **{2: 2}}, _py_backwards_merge_dicts([{1: 1}, {2: 2}]))
    compare({1: 1, **{2: 2}, 3: 3}, _py_backwards_merge_dicts([{1: 1}, {2: 2}, {3: 3}]))
    compare({1: 1, **{2: 2}, **{3: 3}}, _py_backwards_merge_dicts([{1: 1}, {2: 2}, {3: 3}]))


# Unit

# Generated at 2022-06-23 22:42:03.437698
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('{1: 1, **dict_a}')
    tree = DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 22:42:06.046912
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import BaseNodeTransformer
    obj = DictUnpackingTransformer()
    assert isinstance(obj, BaseNodeTransformer)


# Generated at 2022-06-23 22:42:13.658655
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    module = ast.parse('''
    def foo(a):
        d = {1: 1, **a}
        return d
    ''')
    module = transformer.visit(module)
    assert transformer.tree_changed

# Generated at 2022-06-23 22:42:15.527817
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    _ = DictUnpackingTransformer()


__transformer__ = DictUnpackingTransformer

# Generated at 2022-06-23 22:42:16.901138
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().target == (3, 4)


# Generated at 2022-06-23 22:42:22.962517
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.fake_ast import parse

    cases = ("{2: 3}",
             "{2: 3, None: 4}",
             "{2: 3, None: 4, 4: None, None: 4}",
             "{2: 3, None: {}, None: 4}",
             "{2: 3, None: 4, 4: None}",
             "{2: 3, None: {1:2, 3:4}, None: 4, 4: None}",
             "{2: 3, None: {1:2, None: {4: 5}, 3:4}, None: 4, 4: None}",
             "{2: 3, None: {1:2, None: {4: 5}, 3:4}, None: 4, 4: None, **dict_a}")

# Generated at 2022-06-23 22:42:25.440562
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    expected = ast.parse(merge_dicts.get_body())
    # Tastes better with ASTOR-generated code
    expected = expected.body[0]
    actual = DictUnpackingTransformer(3).visit_Module(ast.Module(body=[]))
    assert actual.body[0] == expected



# Generated at 2022-06-23 22:42:26.974040
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    obj = DictUnpackingTransformer()
    assert repr(obj) == '<DictUnpackingTransformer>'

# Generated at 2022-06-23 22:42:28.157673
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass


# Generated at 2022-06-23 22:42:36.310967
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Given
    code = """
        {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}], dict_b)
    """

    transformer = DictUnpackingTransformer()

    # When
    source = ast.parse(code)  # type: ignore
    transformed = transformer.visit(source)  # type: ignore

    # Then
    assert transformer._tree_changed



# Generated at 2022-06-23 22:42:37.385743
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:44.575805
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import build_ast
    
    dict_t = '{1: [1], None: None, **{1: 1, 2: 2}}'
    expected = '_py_backwards_merge_dicts([{1: [1], 2: 2}], {1: 1})'
    
    dict_ = build_ast(dict_t)
    expected = build_ast(expected)
    
    transformer = DictUnpackingTransformer()
    actual = transformer.visit(dict_)
    assert expected == actual

# Generated at 2022-06-23 22:42:51.766030
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import random
    random.seed(42)

    import textwrap
    from ..common import Seq

    from trampoline.compiler.compiler import compile_src, compile_tree
    from trampoline.compiler.ast_utils import dump, dump_tree

    src_minimal = """\
        {1: 1, **a, 2: 2}
    """
    src_multiplication = """\
        {1: 1, **a, 2: 2, **b}
        {1: 1, **a, 2: 2, **{3: 3}}
    """

# Generated at 2022-06-23 22:43:01.590793
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.ast_factory import ast_call, ast_list, ast_dict, ast_name

    def get_body(code):
        return DictUnpackingTransformer().visit(ast.parse(code).body[0])

    assert isinstance(get_body('{1: 1, **{2: 2}}'), ast.Call)

    assert isinstance(get_body('{1: 1, **{2: 2, 3: 3}}'), ast.Call)

    # Result is not a Call
    assert isinstance(get_body('{1: 1}'), ast.Dict)

    # Result is not a Call
    assert isinstance(get_body('{1: 1, 2: 2}'), ast.Dict)

    # Result is not a Call

# Generated at 2022-06-23 22:43:11.820604
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.Module(body=[
        ast.Dict(keys=[ast.Num(1), None, ast.Num(2)],
                 values=[ast.Str('a'), ast.Name(id='dict_a'), ast.Str('b')])
    ])

# Generated at 2022-06-23 22:43:21.263315
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.mock_ast import parse

    source = '{1: 1, 2: 2}'
    expected = '{1: 1, 2: 2}'
    actual = DictUnpackingTransformer().visit(parse(source))
    assert ast.dump(parse(expected)) == ast.dump(actual)

    source = '{1: 1, **{2: 2}}'
    expected = '_py_backwards_merge_dicts([{1: 1}], {2: 2})'
    actual = DictUnpackingTransformer().visit(parse(source))
    assert ast.dump(parse(expected)) == ast.dump(actual)

    source = '{1: 1, **{2: 2}, 3: 3}'

# Generated at 2022-06-23 22:43:25.515829
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    node = ast.Dict(keys=[ast.Constant(1), None, ast.Constant(2)], 
                    values=[ast.Constant(1), 
                            ast.Dict(keys=[ast.Constant(2)], values=[ast.Constant(3)]),
                            ast.Constant(1)])
    trans = DictUnpackingTransformer()
    trans.visit(node)
    assert trans._tree_changed

# Generated at 2022-06-23 22:43:30.402235
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    transformer = DictUnpackingTransformer()
    code = "{1: 1, **dict_a}"
    assert_equal_ast(transformer(code), """\
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)

# Generated at 2022-06-23 22:43:37.452445
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from textwrap import dedent
    from ..testing import compare, assert_equal

    t = DictUnpackingTransformer()
    compare(
        dedent("""\
            def func():
                {1: 2, **l}
        """),
        dedent("""\
            def func():
                _py_backwards_merge_dicts([{1: 2}], l)
        """),
        lambda x: t.visit(x),  # type: ignore
        assert_equal,
    )


# Generated at 2022-06-23 22:43:41.262950
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("""
{1: 1, **{2: 2}}
""")
    new_module = DictUnpackingTransformer(
        module,
    ).visit(module)

# Generated at 2022-06-23 22:43:52.635263
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()

    assert transformer._split_by_None([
        (None, ast.Name(id='a')),
        (None, ast.Name(id='b')),
        (ast.Constant(value=1), ast.Name(id='c')),
    ]) == [
        [],
        ast.Name(id='a'),
        [],
        ast.Name(id='b'),
        [
            (ast.Constant(value=1), ast.Name(id='c')),
        ]
    ]


# Generated at 2022-06-23 22:43:55.135201
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .method_transformer import MethodTransformer
    from ..utils.dump import dump_ast, dump_code


# Generated at 2022-06-23 22:44:01.357374
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """\
        {1: 2, 'a': 1, **{3: 4}, 'b': 2}
        """
    expected = """\
        _py_backwards_merge_dicts([{1: 2, 'a': 1}, {3: 4}], {'b': 2})
        """
    assert transform(DictUnpackingTransformer, source) == expected


# Generated at 2022-06-23 22:44:08.583928
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as pyast
    import typed_ast.ast3 as ast3

    func_source = \
        'def func(a):\n' \
        '    return {1: 1, **a}\n'
    func_tree = pyast.parse(func_source)
    func_ast = ast3.parse(func_source)

    expected_source = \
        'def func(a):\n' \
        '    return _py_backwards_merge_dicts([{1: 1}], a)\n'
    expected_tree = pyast.parse(expected_source)
    expected_ast = ast3.parse(expected_source)

    transformer = DictUnpackingTransformer()
    transformer.visit(func_ast)


# Generated at 2022-06-23 22:44:16.224950
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1}], dict_a
    )
    """
    actual = DictUnpackingTransformer().run_string(code)
    assert code == expected

# Generated at 2022-06-23 22:44:21.704031
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.tree import parse
    from .base import BaseNodeTransformer
    from .comments import CommentsTransformer
    from .floordiv import FloorDivTransformer
    from .unpacking import UnpackingTransformer


# Generated at 2022-06-23 22:44:22.336453
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:44:32.981492
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # given
    import typed_astunparse
    code = 'x = {1: 1, **dict_a}'

    # when
    node = typed_ast.ast3.parse(code)
    DictUnpackingTransformer().visit(node)
    result = typed_astunparse.unparse(node)

    # then
    assert result == '\n'.join((
        'def _py_backwards_merge_dicts(dicts):',
        '    result = {}',
        '    for dict_ in dicts:',
        '        result.update(dict_)',
        '    return result',
        '',
        'x = _py_backwards_merge_dicts([{1: 1}], dict_a)',
        ''
    ))



# Generated at 2022-06-23 22:44:41.105696
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.snippet import assert_equal_ast
    from ..utils.visitor import serialize
    ast_tree = ast.parse("""
    def f(a):
        return {1: 2, **a}
    """)
    actual = serialize(DictUnpackingTransformer().visit(ast_tree))
    expect = serialize(ast.parse("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    def f(a):
        return _py_backwards_merge_dicts([{1: 2}], a)
    """))
    assert_equal_ast(actual, expect)

# Generated at 2022-06-23 22:44:49.012985
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import compare
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:44:49.565361
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-23 22:44:54.008736
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    data = """{1: 1, **dict_a}"""

    node = ast.parse(data)
    DictUnpackingTransformer().visit(node)

    assert merge_dicts.get_body()[0] in ast.dump(node).split('\n')



# Generated at 2022-06-23 22:44:58.521362
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    t = DictUnpackingTransformer()
    source = '''{1: 1, **dict_a}'''
    source_without_merge_func = '''
    dict1 = {1: 1}
    merged_dict = _py_backwards_merge_dicts([dict1], dict_a)
    '''
    assert t.visit(ast.parse(source)) == ast.parse(source_without_merge_func)


# Generated at 2022-06-23 22:45:05.163832
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump

    # Works with multiple dicts
    module_str = source('''
        {
            1: 1,
            **dict_a
        }
        {
            **dict_b
        }
    ''')  # noqa: E501

# Generated at 2022-06-23 22:45:10.972982
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert \
        str(DictUnpackingTransformer()) == \
        "DictUnpackingTransformer(data=((<lambda>),), target=(3, 4), " + \
        "propagate_parent=None, apply_before_children=False, " + \
        "apply_after_children=False)"


# Generated at 2022-06-23 22:45:17.876682
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = '{1: 1, 2: 2, **dict_a, **dict_b, 3: 3}'
    expected = '_py_backwards_merge_dicts([{1:1,2:2,3:3}], dict_a, dict_b)'
    tree = ast.parse(code) # type: ignore
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert expected == to_source(tree)
    print('test_DictUnpackingTransformer_visit_Dict passed')

# Generated at 2022-06-23 22:45:28.555408
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tests import compile_and_run, compile_and_run_in_target


# Generated at 2022-06-23 22:45:38.873241
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import pprint
    from .base import BaseNodeTransformer
    from ..transforms.dict_unpacking import DictUnpackingTransformer
    from ..utils.source import split_module_statements
    from ..utils.tree import print_tree

    source = '''
x = {
    'a': 1,
    'b': 2,
    **{'c': 3},
    'd': 4,
    **{'e': 5, 'f': 6},
    'g': 7,
    **{'h': 8},
    'i': 9
}
'''

    module = ast.parse(source)
    assert print_tree(module) == source

    transformed = DictUnpackingTransformer().visit(module)


# Generated at 2022-06-23 22:45:43.075267
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    code_in = '''
{1: 1, 2: 2, 3: 3, **dict(), **dict(x=1, y=2)}
'''
    expected_out = '''
_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}, dict(), dict(x=1, y=2)])
'''
    result = astunparse.unparse(DictUnpackingTransformer().visit(ast.parse(code_in)))
    assert result == expected_out

# Generated at 2022-06-23 22:45:44.222115
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:45:45.146457
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:45:54.349366
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import get_node
    result = get_node("""
        x = {1: 2, 3: 4, None: {5: 6}, 'a': 'b'}
        """).body[0]


# Generated at 2022-06-23 22:45:59.643666
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    actual = transformer.visit_Module(ast.parse("{1: 1}"))

# Generated at 2022-06-23 22:46:07.914903
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from copy import deepcopy

    from ..utils.tree import compare_ast

    from typed_ast.ast3 import Dict, Call, List, Name, Num

    # Checking that method visit_Dict leaves its input untouched
    _dict_without_unpacking = Dict(
        keys=[Num(n=1), Num(n=2)],
        values=[Num(n=1), Num(n=2)])
    assert DictUnpackingTransformer().visit(
        deepcopy(_dict_without_unpacking)) == _dict_without_unpacking

    _dict_with_unpacking = Dict(
        keys=[Num(n=1), None, Num(n=3)],
        values=[Num(n=1), Num(n=2), Num(n=3)])


# Generated at 2022-06-23 22:46:18.460750
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    import astunparse
    module = ast.parse("""
assert {
    'key1': 1,
    **{'key2': 2},
    'key3': 3,
    **{'key4': 4},
    **{'key5': 5},
    'key6': 6
} == {'key1': 1, 'key2': 2, 'key3': 3, 'key4': 4, 'key5': 5, 'key6': 6}
""")

# Generated at 2022-06-23 22:46:19.648499
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:46:28.594493
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import node_to_str, diff_trees
    from ..utils.transform import transform

    source = """\
    {1: 1, 2: 2, 3: 3, **{}}
    """
    compiled = """\
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], {})
    """

    tree = ast.parse(source)
    compiled_tree = ast.parse(compiled)
    transformed = transform(tree, DictUnpackingTransformer)
    assert node_to_str(transformed) == node_to_str(compiled_tree)



# Generated at 2022-06-23 22:46:32.898416
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3
    assert ast.dump(DictUnpackingTransformer().visit(ast3.parse("{1: 1, **dict_a}"))) == ast.dump(ast3.parse("""\
_py_backwards_merge_dicts([{1: 1}], dict_a)"""))

# Generated at 2022-06-23 22:46:40.083125
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class DictUnpackingTransformer:
        def _split_by_None(self, pairs):
            return [
                [(1, 2), (3, 4), (5, 6)],
                [(None, 7), (8, 9), (10, 11)],
                [(12, 13), (14, 15), (16, 17)],
                [(None, 18), (19, 20)],
            ]


# Generated at 2022-06-23 22:46:51.266847
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .fixtures import prepare_module

    program_source = '''
    {1: 1, 2: None, None, **{1: 1}, 3: 4}
    {1: 1, 2: None, 3: 4}
    {1: 1, **{1: 1}, 2: None, 3: 4}
    {1: 1, 2: None, 3: 4, **{1: 1}}
    '''
    program = prepare_module(program_source, 'dict_unpacking')

# Generated at 2022-06-23 22:47:01.145685
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from copy import deepcopy

    from typed_ast import ast3

    from mypy_extensions import TypedDict

    from .test_transformers_base import do_test

    class Data(TypedDict, total = False):
        a: ast3.Call
        b: ast3.Call
        result: ast3.Call


# Generated at 2022-06-23 22:47:10.541944
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast as pyast
    x = {}
    source = '{1: 1, **{}}'
    tree = ast.parse(source)
    assert not isinstance(tree.body[0].value, pyast.Call)
    assert isinstance(tree.body[0].value, pyast.Dict)
    ty_tree = ast.parse(ty.to_source(tree))
    assert isinstance(ty_tree.body[0].value, pyast.Call)
    assert not isinstance(ty_tree.body[0].value, pyast.Dict)
    exec(compile(ty_tree, filename='<tyast>', mode='exec'))
    assert x[1] == 1



# Generated at 2022-06-23 22:47:17.886332
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''\
lambda: {1: 1, **{2: 1}, **{}, 3: 3, 4: 4, **dict_a}'''
    expected_code = '''\
lambda: _py_backwards_merge_dicts([{1: 1}, {2: 1}, dict(), {3: 3, 4: 4}], dict_a)'''
    tree = ast.parse(code)  # type: ast.Module
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected_code
    
    

# Generated at 2022-06-23 22:47:19.504336
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """The class DictUnpackingTransformer should be called op."""
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:47:26.168351
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import Dict, Name

    transformer = DictUnpackingTransformer()
    dict_ = Dict(keys=[None, None, None], values=[Name(id='a'),
        Name(id='b'), Name(id='c')])
    result = transformer.visit(dict_)

    assert isinstance(result, Call)
    assert result.func.id == '_py_backwards_merge_dicts'
    assert result.args[0].elts == [Name(id='a'), Name(id='b'), Name(id='c')]

# Generated at 2022-06-23 22:47:30.205946
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import transform

    code = """\
    {1: 1, **dict_a, 2: 3}
    """

    expected_code = """\
    _py_backwards_merge_dicts([{1: 1, 2: 3}], dict_a)
    """

    assert expected_code == transform(code, DictUnpackingTransformer)

# Generated at 2022-06-23 22:47:31.517607
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:47:40.574166
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Checks unpacking of dict when it is the only argument
    orig_tree = ast.parse(
        "_put_request('/posts/1', {'id': 1, 'content': 'Test', **data})")
    expected_tree = ast.parse(
        "_put_request('/posts/1', _py_backwards_merge_dicts([{'id': 1, 'content': 'Test'}], data))")
    assert (DictUnpackingTransformer().visit(orig_tree) ==
            expected_tree)

    # Checks unpacking of dict when it is the first argument
    orig_tree = ast.parse(
        "_put_request('/posts/1', {'content': 'Test', **data}, user=user)")