

# Generated at 2022-06-23 22:37:39.309752
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from pprint import pprint
    from .base import _test_ast, _test_tree
    from ..utils.test_utils import assert_source

    _test_ast(DictUnpackingTransformer, """
        {'a': 1, **{'b': 2}}
    """)

    transformed = DictUnpackingTransformer().visit(_test_tree("""
        {'a': 1, **{'b': 2}}
    """))
    pprint(transformed)
    assert_source(transformed, """
        _py_backwards_merge_dicts([{'a': 1}], {'b': 2})
    """)

# Generated at 2022-06-23 22:37:45.658477
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..compiler import compile
    from .utils import TODO

    code = """
    {1: 1, **dict_a}
    """

    result = compile(code, DictUnpackingTransformer, TODO)
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([dict({1: 1})], dict_a)
    """
    assert result == expected

# Generated at 2022-06-23 22:37:50.962015
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_astunparse
    from ..utils.test_visit_module import dump
    a = """
    {1: 1, **dict_a}
    """
    b = """_py_backwards_merge_dicts([{1: 1}], dict_a})
    """
    assert dump(ast.parse(a)) == dump(ast.parse(b))

# Generated at 2022-06-23 22:37:58.256983
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse(
        """{1: 1, **a1, 2: 2, **a2, 3: 3, **a3, **a4, 4: 4}""",
        mode='eval')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(module)
    assert str(result) == '_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], a1, a2, a3, a4)'


# Generated at 2022-06-23 22:38:08.516806
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .verify import verify
    from .verify import verify_eval
    from ..utils.run_python import run_python

    with verify_eval(3.6, [3, 4]):
        assert run_python('{1: 2, **{2: 3}, 3: 4}').strip() == '{1: 2, 2: 3, 3: 4}'
    with verify(3.6, [3, 4]):
        assert run_python('{1: 2, **{2: 3}, 3: 4}', transform=DictUnpackingTransformer).strip() == '{1: 2, 3: 4}'


# Generated at 2022-06-23 22:38:09.115385
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:38:14.126026
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    parse = ast.parse
    t = DictUnpackingTransformer()

    t.visit(parse("""
    {1: 1, **dict_a}
    """))

    t.visit(parse("""
    {1: 1, 2: 2, **dict_a}
    """))

    t.visit(parse("""
    {**dict_a, 1: 1}
    """))

    t.visit(parse("""
    {1: 1, **dict_a, **dict_b, 2: 2}
    """))

    t.visit(parse("""
    {**dict_a, **{1: 1, 2: 2}}
    """))

    t.visit(parse("""
    {**{1: 1, 2: 2}, **dict_a}
    """))



# Generated at 2022-06-23 22:38:17.594619
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)
    assert DictUnpackingTransformer.__module__ == __name__
    assert hasattr(DictUnpackingTransformer, 'target')



# Generated at 2022-06-23 22:38:21.440539
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_before = ast.parse("""
{1: 1, **dict_a}
    """)
    module_after = ast.parse("""
{1: 1, **dict_a}
    """)
    assert DictUnpackingTransformer().visit(module_before) == module_after

# Generated at 2022-06-23 22:38:33.383226
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..tests.utils import TreeInstanceTestCase
    from ..utils.source import source

    class TestDictUnpacking(TreeInstanceTestCase):
        def test_get_tree(self, get_node: ast.AST) -> None:
            node = get_node('''
                {1: 1, **{2: 2}, **{3: 3}}
                ''')
            expected = get_node('''
                _py_backwards_merge_dicts([{1: 1}, {2: 2}, {3: 3}])
                ''')
            self.assert_tree(DictUnpackingTransformer().visit(node), expected)


# Generated at 2022-06-23 22:38:34.145178
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-23 22:38:42.356862
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from pathlib import Path
    from astunparse import dump
    from ..normalize import Normalizer
    from ..utils.tree import to_tuple

    class Dumper(ast.NodeVisitor):
        def generic_visit(self, node):
            """Added for pytest.raises."""

    with Path('tests/snippets/dict_unpacking.py').open('r') as f:
        source = f.read()

    tree = ast.parse(source)
    Normalizer.run(tree)

    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)

    test = dump(tree)


# Generated at 2022-06-23 22:38:51.398253
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import transform, assert_tree
    from ..utils.snippet import snippet

    assert_tree(
        DictUnpackingTransformer,
        """
        {1: 1, **dict_a}
        """,
        """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """)

    assert_tree(
        DictUnpackingTransformer,
        """
        {1: 2, 3: 4, **dict_a, **dict_b, 5: 6}
        """,
        """
        _py_backwards_merge_dicts(\
    [{1: 2, 3: 4}, dict_a, dict_b], {5: 6})
        """)


# Generated at 2022-06-23 22:38:52.896578
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert t is not None

# Generated at 2022-06-23 22:39:04.161258
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import TestTransformer
    
    trans = TestTransformer(DictUnpackingTransformer)

    eq = trans.assert_equal  # type: ignore


# Generated at 2022-06-23 22:39:13.495787
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.test_utils import assert_each_line_contains
    from ..utils.test_utils import parse_to_node
    from ..utils.test_utils import print_ast_tree
    from ..utils.test_utils import assert_new_text_equals
    from textwrap import dedent

    t = DictUnpackingTransformer()
    node = parse_to_node("""\
    {
        1: 1,
        **a,
        **b,
        3: 3,
        4: 4,
        **c,
    }""")
    transformed_node = t.visit(node)  # type: ignore

# Generated at 2022-06-23 22:39:18.053385
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.ast_builder import ast_from, ast_to_text

    src = """
{1: 2, 3: 4, **{5: 6, 7: 8}, 9: 10, **{11: 12, 13: 14}}
    """.strip()

    expected = """
_py_backwards_merge_dicts([{1: 2, 3: 4}, {9: 10}], {5: 6, 7: 8}, {11: 12, 13: 14})
    """.strip()

    tree = ast_from(src)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert ast_to_text(tree) == expected

# Generated at 2022-06-23 22:39:23.501116
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Tests that:
    
        {1: 1, **dict_a}
        
    is compiled to:
    
        _py_backwards_merge_dicts([{1: 1}], dict_a})
    
    """
    node = ast.parse("""
    {
        1: 1,
        **dict_a
    }
    """)
    actual = DictUnpackingTransformer().visit(node)
    expected = ast.parse("""
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)

    assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-23 22:39:28.599684
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.test_utils import make_test_fixture, run_test

    make_test_fixture(__file__,
                      lambda: DictUnpackingTransformer().visit(ast.parse(source(__file__))),
                      locals())
    assert run_test(__file__, create_target=True) is None

# Generated at 2022-06-23 22:39:38.602529
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    snippet = """
        {None: 'a', 1: 2}
    """
    expected = snippet_to_object(snippet)().body[0]
    expected_ast = expected.value
    result_ast = snippet_to_object(snippet)(DictUnpackingTransformer).body[0]
    assert type(result_ast) == type(expected_ast)
    assert ast.dump(result_ast) == ast.dump(expected_ast)

    snippet = """
        {1: 2, None: 1}
    """
    expected = snippet_to_object(snippet)().body[0]
    expected_ast = expected.value
    result_ast = snippet_to_object(snippet)(DictUnpackingTransformer).body[0]

# Generated at 2022-06-23 22:39:46.601930
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import fuzzy_with_async
    from typed_ast.ast3 import parse

    tree = parse("{1: 1, **{2: 2, 3: 3}, 4: 4, **{5: 5}}")
    DictUnpackingTransformer().visit(tree)
    result = fuzzy_with_async.compile(tree)

    dict_one = {"1": 1, "4": 4}
    dict_two = {"2": 2, "3": 3}
    dict_three = {"5": 5}
    python_result = _py_backwards_merge_dicts([dict_one, dict_two, dict_three])

    assert python_result == result

# Generated at 2022-06-23 22:39:53.527380
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''\
    {1: 1, **dict_a, 2: 2}
    '''
    expected = '''\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}])
    '''
    node = ast.parse(code)
    t = DictUnpackingTransformer()
    t.visit_Module(node)
    assert expected == t.result()

# Generated at 2022-06-23 22:40:00.518864
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import compare_same_ast, compare_same_source


# Generated at 2022-06-23 22:40:11.070896
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_astunparse import dump, unparse
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:40:20.116537
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_support import assert_equal_expr
    from ..utils.testing import assert_equal
    from ..utils.tree_nodes import format_ast
    from textwrap import dedent
    import astor

    code = dedent("""
        a = {1: 2, 2: 4, None: a, 5: 4}
        b = {None: a, 4: 5}
    """)
    exp_code = dedent("""
        a = _py_backwards_merge_dicts([{1: 2, 2: 4}], a, {5: 4})
        b = _py_backwards_merge_dicts([}, a, {4: 5})
    """)

    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    act_code = astor

# Generated at 2022-06-23 22:40:22.236249
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.test_utils import assert_equal_code


# Generated at 2022-06-23 22:40:32.639189
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import test_node_transform

    ex = ast.parse(
        """
{1: 1, 2: 2, **a}
{1: 1, **a}
{**a}
{**a, **b}
{
    'a': 1,
    'b': 2,
    **c,
    'c': 3,
}
        """
    )


# Generated at 2022-06-23 22:40:34.467664
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    d = DictUnpackingTransformer()


# Generated at 2022-06-23 22:40:42.361000
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    source = """\
    {1: 1, **{2: 2}, 3: 3, **{4: 4}, 5: 5}
    """

    expected = """\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}, {3: 3}, {5: 5}], {2: 2}, {4: 4})
    """
    assert DictUnpackingTransformer(source).code == expected

# Generated at 2022-06-23 22:40:51.342113
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import to_source
    from ..tests.utils.property import Property
    from .base_test import BaseNodeTransformerTest
    from .examples import DICT_UNPACKING_TRANSFORMER_EXAMPLES

    class Test(BaseNodeTransformerTest, Property):
        transformer = DictUnpackingTransformer()
        examples = DICT_UNPACKING_TRANSFORMER_EXAMPLES

        @classmethod
        def expected(cls, node):
            return to_source(node).lstrip('\n')

    test = Test()
    test.run_doctests()

# Generated at 2022-06-23 22:40:54.447621
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from astor.source_repr import dump_tree
    from .test_transformer import run_transformer_test
    run_transformer_test(DictUnpackingTransformer, 'merge_dicts', dump_tree)

# Generated at 2022-06-23 22:40:56.803429
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse("{**d}")
    DictUnpackingTransformer().visit(tree)
    assert compile(tree, '', 'exec').co_consts[0] == _py_backwards_merge_dicts

# Generated at 2022-06-23 22:41:01.373909
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor  # type: ignore

# Generated at 2022-06-23 22:41:02.335605
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-23 22:41:03.658122
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:41:08.884892
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = dedent(u'''
        {1: 1, **dict_a}
        ''').strip()
    expected = dedent(u'''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1}], dict_a)
        ''').strip()
    actual = DictUnpackingTransformer().visit(ast.parse(source))
    assert astunparse.unparse(actual) == expected



# Generated at 2022-06-23 22:41:17.965409
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    node = ast.parse('''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    ''')

    before = str(node).strip()
    expected = str(ast.parse('''
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    ''')).strip()

    transformer = DictUnpackingTransformer()
    call = transformer.visit(node)
    after = astor.to_source(call).strip()

    assert before == expected, (before, expected)
    assert after == expected, (after, expected)

# Generated at 2022-06-23 22:41:19.960155
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer.tree_changed is False
    assert transformer.target == (3, 4)


# Generated at 2022-06-23 22:41:22.145831
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import generate_code
    code = generate_code(DictUnpackingTransformer, '''{1:1, **foo}''')

# Generated at 2022-06-23 22:41:24.113881
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_fixtures import module


# Generated at 2022-06-23 22:41:25.883457
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()

    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:41:30.429683
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('a = 1')  # type: ast.Module
    result = DictUnpackingTransformer(3,4).visit(module)
    assert ast.dump(result) == ast.dump(ast.parse(merge_dicts() + 'a = 1'))

# Generated at 2022-06-23 22:41:35.979756
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse

    s = """\
    {1: 1, 2: 2, **dict_a}
    
    """
    expected = """\
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    
    """
    node = parse(s)
    assert DictUnpackingTransformer.run_single(node) == parse(expected)

# Generated at 2022-06-23 22:41:37.587965
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None) is not None

# Generated at 2022-06-23 22:41:39.530477
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """\
{1:1, 2:2, 3:3, **a, **b}"""

# Generated at 2022-06-23 22:41:45.734065
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    expr = ast.Dict(
        keys=[ast.Num(n=1), ast.Num(n=2), None, ast.Num(n=3), None],
        values=[ast.Num(n=1), ast.Num(n=2), ast.Name(id='a'),
                ast.Num(n=3), ast.Name(id='b')])

    result = transformer.visit(expr)

# Generated at 2022-06-23 22:41:49.020583
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    print(astor.to_source(DictUnpackingTransformer().visit(
        ast.parse('{1: 2, **{3: 4}, 5: 6}'))))


# Generated at 2022-06-23 22:41:57.865391
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor

    module_string = merge_dicts.get_body().lstrip()
    main_string = ('{1: 1, **{2: 2}, 3: 3, **[4]}')

    transformer = DictUnpackingTransformer()
    tree = ast.parse(f'{module_string}\n{main_string}')
    tree = transformer.visit(tree)

    stringified = astor.to_source(tree)
    expected = (f'{module_string}\n'
                f'_py_backwards_merge_dicts(\n'
                f'    [dict({{1: 1}}), {{2: 2}}],\n'
                f'    [4]\n'
                f')')
    assert stringified == expected

# Generated at 2022-06-23 22:42:05.938813
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """\
    {1: 2, **{'b': 1}}
    """
    expected = """\
    def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
    
    
    
    
    
    
    
    
    
    
    
    
    _py_backwards_merge_dicts([{1: 2}], {'b': 1})
    """
    tree = ast.parse(source)
    node = tree.body[-1]
    assert isinstance(node, ast.Expr)

    actual = DictUnpackingTransformer().visit(tree)
    actual = ast.dump(actual)
    assert actual == expected  # type: ignore



# Generated at 2022-06-23 22:42:14.836596
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.Module((ast.parse('{1: 1, **dict_a}',
                                 mode='eval').body))
    assert (
        DictUnpackingTransformer().visit(node)
        == ast.Module((ast.parse('\n'.join([
            'def _py_backwards_merge_dicts(dicts):',
            '    result = {}',
            '    for dict_ in dicts:',
            '        result.update(dict_)',
            '    return result',
            '_py_backwards_merge_dicts([{1: 1}], dict_a)',
        ]), mode='eval').body)))

# Generated at 2022-06-23 22:42:24.219155
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ast_pprint.pprint import pprint
    from typed_ast import ast3 as ast

    node = ast.Module(
        body=[
            ast.Dict(keys=[ast.Constant(value=None),
                           ast.Constant(value=1)],
                    values=[ast.Constant(value=1),
                            ast.Constant(value=2)])
        ])


# Generated at 2022-06-23 22:42:34.680286
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    dictionary = {
        'a': 1,
        '**b': 2,
        'c': 3
    }

    class Dummy:
        pass

    dummy = Dummy()

# Generated at 2022-06-23 22:42:43.018225
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse("""{**a, 1: 1, **b}""")
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    expected = ast.parse("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([dict(1=1), a, b])
    """)
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-23 22:42:48.577605
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert DictUnpackingTransformer()(ast.parse('''
{1: 1}
{1: 1, **{2: 2}}
{1: 1, **{2: 2}, **{3: 3}}
    ''')) == ast.parse('''
{1: 1}
_py_backwards_merge_dicts([{1: 1}], {2: 2})
_py_backwards_merge_dicts([{1: 1}, {2: 2}], {3: 3})
    ''')

# Generated at 2022-06-23 22:42:57.441692
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    assert transformer.visit(ast.parse('{1: 1, **{2: 2, 3: 3}, 4: 4}')) \
        == ast.parse('_py_backwards_merge_dicts([{1: 1}, {4: 4}], {2: 2, 3: 3})')

    assert transformer.visit(ast.parse('{1: 1, 2: 2, 3: 3, 4: 4}')) \
        == ast.parse('{1: 1, 2: 2, 3: 3, 4: 4}')

# Generated at 2022-06-23 22:43:07.302554
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import compile
    assert compile('''{1: 2, **d}''', transformer=DictUnpackingTransformer) \
           == '_py_backwards_merge_dicts([{1: 2}], d)'
    assert compile('''{1: 2, *[{3: 4}, {5: 6}]}''', transformer=DictUnpackingTransformer) \
           == '_py_backwards_merge_dicts([{1: 2}], dict({3: 4}), dict({5: 6}))'
    assert compile('''{1: 2, **d, 3: 3, **e}''', transformer=DictUnpackingTransformer) \
           == '_py_backwards_merge_dicts([{1: 2}], d, {3: 3}, e)'
    assert compile

# Generated at 2022-06-23 22:43:14.261463
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
    {**a, **b, c: d, c: d, c: d}
    {**a, **b, **c}
    {**a, **b, **c, **d}
    """

    expected = """
    _py_backwards_merge_dicts([dict({c: d, c: d, c: d})], a, b)
    _py_backwards_merge_dicts([dict()], a, b, c)
    _py_backwards_merge_dicts([dict()], a, b, c, d)
    """

    transformer = DictUnpackingTransformer()
    assert transformer.visit(ast.parse(code)) == ast.parse(expected)

# Generated at 2022-06-23 22:43:23.184829
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.tests import assert_node_equals
    from typed_ast import ast3
    from ..utils.snippet import snippet
    from ..utils.parse import parse

    snippet.global_name_scope = True
    merge_dicts_code = merge_dicts.get_body()
    del merge_dicts_code.body[0].body[0].value.args[1].ctx
    assert_node_equals(merge_dicts_code, parse(merge_dicts.get_code()))

    node = parse('{1: 1, **dict_a, 2: 2, **dict_b}').body[0]
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)

# Generated at 2022-06-23 22:43:29.892878
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import astor
    from .dummy_transformer import DummyTransformer
    from ..utils.tree import ast_to_text

    tree = ast.parse("{1:1, **{2:2}}")
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert ast_to_text(tree) == textwrap.dedent("""\
    _py_backwards_merge_dicts(dicts=[{1: 1}, {2: 2}])
    """)

    tree = ast.parse("{**{1:1}, **{2:2}, 3:3, **{4:4}}")
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)

# Generated at 2022-06-23 22:43:40.062134
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import check_eval, check_tree
    from ..utils.test_utils import parse

    for py_version in (3, 4):
        check_eval(
            DictUnpackingTransformer,
            '{1: 2}',
            version=py_version)
        check_eval(
            DictUnpackingTransformer,
            '{1: 2, **{"a": 3, "b": 4}}',
            {'a': 3, 'b': 4})
    check_eval(
        DictUnpackingTransformer,
        '{1: 2, **{"a": 3, "b": 4}, **{"c": 5}, 5: 6}',
        {'a': 3, 'b': 4, 'c': 5, 1: 2, 5: 6},
        version=3)

    # Check AST

# Generated at 2022-06-23 22:43:45.947841
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..context import context
    node = ast.parse("{'a': 1, **{'b': 2}}")
    DictUnpackingTransformer(context).visit(node)
    expected_node = ast.parse("def _py_backwards_merge_dicts(dicts):\n"
                              "    result = {}\n"
                              "    for dict_ in dicts:\n"
                              "        result.update(dict_)\n"
                              "    return result\n\n"
                              "{'a': 1, **{'b': 2}}")
    assert ast.dump(node) == ast.dump(expected_node)

# Generated at 2022-06-23 22:43:47.041381
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass


# Generated at 2022-06-23 22:43:55.614358
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tr = DictUnpackingTransformer()
    i_dict = ast.Dict(
        keys=[ast.Num(n=1), None, ast.Num(n=2)],
        values=[ast.Num(n=1), ast.Dict(keys=[None], values=[ast.num(3)]),
                ast.Num(n=4)]
    )
    result = tr.visit_Dict(i_dict)
    assert isinstance(result, ast.Call)
    assert isinstance(result.args[0], ast.List)
    assert isinstance(result.args[0].elts[0], ast.Dict)
    assert isinstance(result.args[0].elts[1], ast.Call)
    assert isinstance(result.args[0].elts[2], ast.Dict)

# Generated at 2022-06-23 22:43:57.849144
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()



# Generated at 2022-06-23 22:44:06.524215
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..registry import Registry
    from textwrap import dedent
    import typing
    import enum

    # dict unpacking: {1: 1, **a}
    source = dedent("""\
        def f(_: typing.Dict[str, str]):
            return {1: 1, **a}
        """)
    
    # dict unpacking: {1: 1, **a, **b}
    source += dedent("""\
        def g(_: typing.Dict[str, str]):
            return {1: 1, **a, **b}
        """)

    # dict unpacking: {1: 1, **a, **b, **c}

# Generated at 2022-06-23 22:44:11.813374
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """
    class A:
        def f(self):
            d = {1: 2, **{3: 4, **{5: 6}, 7: 8}}
    """
    expected = """
    class A:
        def f(self):
            d = _py_backwards_merge_dicts([{1: 2}, {3: 4}, {5: 6}, {7: 8}])
    """
    tree = ast.parse(code)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert expected == transformer.output()

# Generated at 2022-06-23 22:44:16.518614
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse("{1: 1, **dict_a}")
    new_node = DictUnpackingTransformer().visit(node)
    assert ast.dump(new_node) == ast.dump(
        ast.parse("_py_backwards_merge_dicts([{1: 1}], dict_a"))

# Generated at 2022-06-23 22:44:21.194432
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """
    Unit test for method visit_Dict of class DictUnpackingTransformer.
    
    Corresponds to test case "test_dict_unpacking_visitor".
    """
    from ..utils.source import Source
    source = Source("{1: 1, **dict_a}")

# Generated at 2022-06-23 22:44:26.869996
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''\
    {}
    '''

    expected = '''\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
    {}
    '''

    tree = ast.parse(code)  # type: ignore
    node = DictUnpackingTransformer()(tree)
    assert ast.dump(node) == expected

# Generated at 2022-06-23 22:44:37.146510
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:44:46.783321
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    from ..utils.source import source

    code = source("""
    from typing import Dict

    def f(a: Dict[int, int], b: Dict[int, int], c: Dict[int, int]) -> Dict[int, int]:
        return {1: 1, **a, 2: 2, 3: 3, **b, 4: 4, 5: 5, **c, **{6: 6, 7: 7}}
    """)


# Generated at 2022-06-23 22:44:56.716811
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_transformer import transform
    from ..utils.source import source
    from ..utils.tree import parse
    from ..compat import StringIO
    
    input_  = StringIO(source('''
    x = {1: 2, 3: 5, **d}
    '''))
    output_ = StringIO()
    
    transform(DictUnpackingTransformer, input_, output_)
    

# Generated at 2022-06-23 22:44:59.917407
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import tool

    code = '{1: 1, 2: 2, **a, **b, **{4: 4, 5: 5}, 3: 3}'
    result = tool.transform_snippet(code, DictUnpackingTransformer)
    assert result == '_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], a, b, {4: 4, 5: 5})'

# Generated at 2022-06-23 22:45:06.388268
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from textwrap import dedent
    from typed_astunparse import unparse

    with open('./tests/fixtures/dict_unpacking.py', 'r') as f:
        source = f.read()

    node = ast.parse(dedent(source))
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-23 22:45:07.783946
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()


# Generated at 2022-06-23 22:45:12.074478
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    source = '''{1: 1, **dict_a}'''
    expected = '''
_py_backwards_merge_dicts([{1: 1}], dict_a})'''

    result = DictUnpackingTransformer().transform(source)
    assert expected == result

# Generated at 2022-06-23 22:45:13.065998
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass


# Generated at 2022-06-23 22:45:13.940783
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:45:18.906587
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    example_input = """
    a = {1: 1, **dict_a}
    """

    example_output = """
    a = _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    assert DictUnpackingTransformer().transform(example_input) == example_output

# Generated at 2022-06-23 22:45:29.343527
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:45:31.334883
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_transform_module(DictUnpackingTransformer.run)

# Generated at 2022-06-23 22:45:37.084402
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class TestTransformer(DictUnpackingTransformer):
        def visit_for_testing(self, node):
            return self.visit_Dict(node)

    source = '{1: 1, **a, 2: 2}'
    expected = '_py_backwards_merge_dicts([{1: 1, 2: 2}], a)'
    result = TestTransformer().visit(ast.parse(source))
    assert expected == astunparse.unparse(result)

# Generated at 2022-06-23 22:45:46.646313
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_utils import make_module
    from .test_utils import to_source

    source = '''
    d = {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c, 4: 4}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    d = _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b, dict_c)
    '''

    module = make_module(source)
    module = DictUnpackingTransformer(module).visit(module)

# Generated at 2022-06-23 22:45:52.099183
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..test_utils import run_local_tests
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        def test_transform(self):
            self.assertTransformedAST(
                DictUnpackingTransformer(),
                self.load_example('dict_unpacking.py'),
                self.load_example('dict_unpacking_after.py'))

    run_local_tests(TestCase)


# Generated at 2022-06-23 22:46:03.087628
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_astunparse
    import astunparse
    import sys
    import textwrap
    ast_dict = astunparse.parse(
        textwrap.dedent('''
            {
                1: 2,
                **{},
                2: 3,
                **x,
                y: 3,
                4: 5,
                **z,
                **{'a': 6, 'b': 7},
                **{'c': 8, 'd': 9},
                **w,
                'a': 6,
                **x,
                y: 6,
                **z,
                **w,
            }
        ''')).body[0].value
    sys.modules[__name__].__dict__['typed_ast'] = typed_ast
    sys.modules['_ast'] = None
    sys.modules

# Generated at 2022-06-23 22:46:09.769534
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..snippet import visit

    snippet = """
    {
        None: 0,  # -> keep
        1: 2, 3: 4,  # -> keep
        None: 0,  # -> throw
        5: 6, 7: 8,  # -> keep
    }
    """
    with visit(snippet, DictUnpackingTransformer):
        assert snippet == """
        _py_backwards_merge_dicts([{1: 2, 3: 4}, dict({5: 6, 7: 8})])
        """

# Generated at 2022-06-23 22:46:10.941127
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer



# Generated at 2022-06-23 22:46:16.279778
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    expected = """_py_backwards_merge_dicts([{b: {c: 3}, d: 4}, {e: 5, f: 6}], a)"""
    node = parse_expr("{**a, b: {c: 3}, d: 4, **{e: 5, f: 6}}")
    assert DictUnpackingTransformer().visit(node) == parse_expr(expected)


# Generated at 2022-06-23 22:46:22.003680
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .testutils import transform, dedent

    source = dedent('''
    def f():
        {**{'a': 1}, **{'b': 2}}
    ''')
    expected_source = dedent('''
    def f():
        _py_backwards_merge_dicts([{'a': 1}], {'b': 2})
    ''')

    tree = ast.parse(source)
    expected_tree = ast.parse(expected_source)
    tree = transform(tree, [DictUnpackingTransformer])
    assert tree == expected_tree

# Generated at 2022-06-23 22:46:23.431107
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert repr(transformer)

# Generated at 2022-06-23 22:46:30.636486
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    expected_src = '_py_backwards_merge_dicts([{1: 1}], dict_a,)\n'
    actual_src = DictUnpackingTransformer().visit(ast.parse(source)).dump()
    assert expected_src == actual_src
    assert expected == compile(actual_src, '', 'eval').strip()


# Generated at 2022-06-23 22:46:35.955808
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .. import compile_isolated, Future
    from ..crash_on_exception import test_fail_on_exception

    exec_code = compile_isolated(
        """
        for k in [{1: 1, **{'a': 2}, **{'b': 3}}]:
            print(k)
        """,
        flags=Future.from_flag_set({'3': True, '4': True}),
        stage=1).exec_code

    test_fail_on_exception(exec_code)


# Generated at 2022-06-23 22:46:40.367399
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_astunparse import unparse
    from .expect import Expect
    from .typeshed import typeshed

    expect = Expect(
        original=typeshed('Module', 'typed_ast.ast3'),
        transformed=typeshed('Module', 'typed_ast.ast3'),
        result={
            '_py_backwards_merge_dicts': merge_dicts.get_body()
        },
    )


# Generated at 2022-06-23 22:46:41.353290
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:46:43.139039
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():  # noqa
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:46:54.015883
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import make_call_test
    from .test_utils import check_visitor_node
    from .test_utils import check_preserving_fields
    from .test_utils import check_preserving_literals
    import astor

    def test_call(s):
        make_call_test(s, DictUnpackingTransformer)

    test_call('{1: 2, **{}}')
    test_call('{1: 2, **a}')
    test_call('{1: 2, 3: 4, **a}')
    test_call('{1: 2, 3: 4, **b, 5: 6}')
    test_call('{1: 2, 3: 4, **b, **c, 5: 6}')

# Generated at 2022-06-23 22:47:00.077448
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.utils import assert_equal_ast 
    from ..testing.generate import generate_visit_test_snippet
    code = generate_visit_test_snippet(DictUnpackingTransformer, 'visit_Dict')
    expected = generate_visit_test_snippet(DictUnpackingTransformer,
                                           'visit_Dict',
                                           ast_type=ast.Module)
    assert_equal_ast(code, expected)

# Generated at 2022-06-23 22:47:06.475361
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from parso.python.tree import Module
    from typed_ast.ast3 import parse

    source = """
    {
        1: 2,
        3: 4,
        **dict_a,
        **dict_b,
        5: 6,
        **dict_c,
        **dict_d,
        7: 8,
        **dict_e,
        9: 10
    }
    """
    ast_node = parse(source)
    node = Module(body=ast_node.body)

    # Call visitor
    result = DictUnpackingTransformer().visit(node)  # type: ignore
    # Method visit_Dict should be called at least once
    assert DictUnpackingTransformer()._tree_changed


# Generated at 2022-06-23 22:47:16.994100
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.Module(body=[
        ast.Dict(keys=[None, ast.Num(n=1), None], values=[
            ast.Dict(keys=[], values=[]),
            ast.Num(n=2),
            ast.Dict(keys=[ast.Num(n=1)], values=[ast.Num(n=2)]),
        ]),
    ])

    node = DictUnpackingTransformer().visit(node)


# Generated at 2022-06-23 22:47:18.899878
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dut = DictUnpackingTransformer()
    assert repr(dut) == '<DictUnpackingTransformer target=3.4>'

# Generated at 2022-06-23 22:47:21.537957
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = compile('', '<test>', 'exec')
    assert module.co_consts == (None, '_py_backwards_merge_dicts')



# Generated at 2022-06-23 22:47:24.378634
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:47:26.593078
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse("""{1: 1, **dict_a}""")
    
    transf = DictUnpackingTransformer()
    transf.visit(tree)


# Generated at 2022-06-23 22:47:31.148700
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source1, source2
    from ..utils.ast import ast_equals
    from .base import ExprTransformer
    expr = ast.parse('{1: 2, **x, "abc": 2, **y, "aaa": 2}')
    transformer = ExprTransformer(DictUnpackingTransformer())
    result = transformer.visit(expr)
    assert ast_equals(result, source2)

