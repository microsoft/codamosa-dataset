

# Generated at 2022-06-23 22:37:43.078534
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse('{1: 2, **{3: 4}}')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    merged = ast.parse('_py_backwards_merge_dicts([{1: 2}], {3: 4})')
    try:
        # Python 3.8
        merged.body[0].value.args[0].ctx
        merged.body[0].value.args[1].ctx
    except AttributeError:
        pass
    else:
        merged.body[0].value.args[0].ctx = ast.Load()
        merged.body[0].value.args[1].ctx = ast.Load()
    assert ast.dump(result.body[0]) == ast.dump(merged.body[0])

# Generated at 2022-06-23 22:37:54.076961
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..transpiler import Transpiler
    from ..literals import DictComprehensions, DictUnpacking

    def test(code_in, code_out):
        tree_in = ast.parse(code_in)
        tree_out = ast.parse(code_out)
        Transpiler([DictUnpacking()]).setup(tree_in)
        Transpiler([DictComprehensions()]).setup(tree_out)
        transformer = DictUnpackingTransformer()
        transformer.setup(tree_in)
        assert transformer.tree == tree_out

    test("{1: 1}", "{1: 1}")
    test("{**{}}", "_py_backwards_merge_dicts([{}])")

# Generated at 2022-06-23 22:38:05.207872
# Unit test for constructor of class DictUnpackingTransformer

# Generated at 2022-06-23 22:38:06.202425
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert 3 == 3

# Generated at 2022-06-23 22:38:11.447902
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    f = """
    import collections.abc as abc
    class X(abc.MutableMapping):
        def __init__(self, **kwargs):
            self._x = {}

        def __getitem__(self, key):
            return self._x[key]

        def __setitem__(self, key, value):
            self._x[key] = value

        def __delitem__(self, key):
            del self._x[key]

        def __iter__(self):
            return iter(self._x)

        def __len__(self):
            return len(self._x)
    x = X({**{}, 1: 1})
    """

    c = compile(f, '', 'exec', flags=ast.PyCF_ONLY_AST)

# Generated at 2022-06-23 22:38:17.402033
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    source = '''
    a = {1: 1, **a}
    '''
    expected = '''
    _py_backwards_merge_dicts([dict({1: 1})], a)
    '''
    assert compile_snippet(source, '<test>', 'exec') == compile_snippet(
        expected, '<test>', 'exec')



# Generated at 2022-06-23 22:38:18.761608
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer(None)



# Generated at 2022-06-23 22:38:26.066212
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.test_utils import expect_tree
    from typed_ast.ast3 import Module, Dict, Name, Tuple, List, Call

    expect_tree(DictUnpackingTransformer(),
                """
                {1: 1, **dict_a}
                """,
                Module(body=[
                    Call(
                        func=Name(id='_py_backwards_merge_dicts'),
                        args=[List(elts=[
                            Dict(keys=[],
                                 values=[Tuple(elts=[
                                     Name(id='1'),
                                     Name(id='1')
                                 ], ctx=Load())]),
                            Name(id='dict_a')
                        ])],
                        keywords=[])
                ]))

# Generated at 2022-06-23 22:38:36.895715
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    def do_test(
            code: str,
            expected_code: str,
            expected_tree: Optional[ast.Module] = None,
    ):
        transformer_cls = DictUnpackingTransformer
        node = ast.parse(code)
        transformer = transformer_cls()
        transformer.visit(node)
        actual_code = compiler.ast_to_source(node)
        assert actual_code == expected_code
        if expected_tree is not None:
            assert transformer.tree_changed
            assert node == expected_tree

    code = '{**a, **b}'
    expected_code = '_py_backwards_merge_dicts([], a, b)'

# Generated at 2022-06-23 22:38:44.839057
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse
    from ..utils import dump

    with DictUnpackingTransformer() as t:
        dump(t.visit(parse('{a: 1}')))
        dump(t.visit(parse('{a: 1, **{b: 2, c: 3}}')))
        dump(t.visit(parse('{a: 1, **{b: 2, c: 3}, **{d: 4}}')))
        dump(t.visit(parse('{a: 1, **{b: 2, c: 3}, **{"d": 4}}')))
        dump(t.visit(parse('{a: 1, **{b: 2, c: 3}, **{"d": 4}, e: 5}')))

# Generated at 2022-06-23 22:38:52.274922
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.source import source
    from .meta import compile_to_ast as to_ast

    node = to_ast(source('''
        {a: a, b: b, c: c, **d, **e, f: f, **g, h: h, **i, j: j, **k, **l, m: m}
    '''))
    assert isinstance(node, ast.Module)
    assert len(node.body) == 1
    assert isinstance(node.body[0], ast.Expr)
    node = node.body[0].value
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)



# Generated at 2022-06-23 22:38:56.516432
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.inputs import inputs
    from ..utils.compiler import compile_func
    from ..utils.testing import run_in_function
    func, = compile_func([inputs['dict-unpacking']])
    run_in_function(func)

# Generated at 2022-06-23 22:39:05.247123
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equivalent_code
    from ..utils.testing import assert_ast_equivalent
    from typed_astunparse import unparse
    code = """
    a = {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected_code = """
    a = _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)
    """
    tree = ast.parse(code)  # type: ignore
    expected_tree = ast.parse(expected_code)  # type: ignore
    transformer = DictUnpackingTransformer()
    transformed_tree = transformer.visit(tree)  # type: ignore
    assert_ast_equivalent(transformed_tree, expected_tree)
    assert_equ

# Generated at 2022-06-23 22:39:13.887374
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import dump, loads

    expr_str = '{"a": "b", **c, "d": "e", f: "g", **h}'
    code_str = '{}'.format(expr_str)
    expr = loads(expr_str)

    transformed = DictUnpackingTransformer().visit(expr)
    merged_str = '_py_backwards_merge_dicts([{"a": "b", "d": "e", f: "g"}], c, h)'
    assert dump(transformed) == merged_str

    code = loads(code_str)
    transformed = DictUnpackingTransformer().visit(code)
    assert dump(transformed) == '{}'.format(merged_str)

# Generated at 2022-06-23 22:39:23.731591
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    merge_dicts_code = merge_dicts.get_code().replace('\n', ' ')

# Generated at 2022-06-23 22:39:34.327907
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTransformerTestCase
    module = compile("{}", "<?>", "exec")
    module = ast.parse(module)
    assert isinstance(module, ast.Module)
    # Passes if _visit_Dict doesn't change the tree
    BaseNodeTransformerTestCase(DictUnpackingTransformer).assert_transformed_ast_is(module, module)
    # Passes if _visit_Dict doesn't change the tree
    module = compile("{1: 1}", "<?>", "exec")
    module = ast.parse(module)
    assert isinstance(module, ast.Module)
    BaseNodeTransformerTestCase(DictUnpackingTransformer).assert_transformed_ast_is(module, module)


# Generated at 2022-06-23 22:39:41.163354
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()._split_by_None([
        (None, ast.Num(1)),
        (ast.Str('a'), ast.Str('b')),
        (None, ast.Num(2)),
        (ast.Str('c'), ast.Str('d')),
    ]) == [
        [],
        ast.Num(1),
        [
            (ast.Str('a'), ast.Str('b')),
        ],
        ast.Num(2),
        [
            (ast.Str('c'), ast.Str('d')),
        ],
        [],
    ]

# Generated at 2022-06-23 22:39:48.409223
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Example 1
    input = """\
    {1: 1, 3: 3}
    """
    expected = """\
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    {1: 1, 3: 3}
    """
    actual = DictUnpackingTransformer().visit(ast.parse(input))
    assert astor.to_source(actual) == expected


# Generated at 2022-06-23 22:39:49.818796
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    assert x is not None


# Generated at 2022-06-23 22:39:50.600744
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:39:57.498893
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    # test with single unpacking
    node = ast.parse("{'a':1, **{'b': 2}}")
    DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == dedent("""
        _py_backwards_merge_dicts([{'a': 1}], {'b': 2})
    """)

    # test with multiple unpacking
    node = ast.parse("{'a':1, **{'b': 2, **{'c': 3}}}")
    DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == dedent("""
        _py_backwards_merge_dicts([{'a': 1}], {'b': 2}, {'c': 3})
    """)

    # test with unpacking before


# Generated at 2022-06-23 22:40:03.214200
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    source = '''\
            def f(a, b, c, d, e):
                return {
                    a: b,
                    c: d,
                    **e
                }
            '''
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    exec(compile(tree, '<ast>', mode='exec'))
    f = locals()['f']
    assert f(1, 2, 3, 4, {5: 6}) == {1: 2, 3: 4, 5: 6}

# Generated at 2022-06-23 22:40:05.059393
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    with DictUnpackingTransformer() as d:
        pass

# Generated at 2022-06-23 22:40:06.325392
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None)

# Generated at 2022-06-23 22:40:08.653989
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

if __name__ == '__main__':
    test_DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:17.754799
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:40:21.525893
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    node = ast.parse("{1: 1, 2: 2, **a}")
    DictUnpackingTransformer().visit(node)
    assert astor.to_source(node) == '_py_backwards_merge_dicts([{1: 1, 2: 2}], a)'

# Generated at 2022-06-23 22:40:23.254991
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    with pytest.raises(TypeError):
        DictUnpackingTransformer(None)

# Generated at 2022-06-23 22:40:32.217815
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..node_transformer import NodeTransformer
    # import typed_astunparse
    import astunparse

    source = """
    def f(a, b, c=None, d=None):
        return {a: a, b: b, c: c, d: d}
    """

    expected = """
    import builtins
    def f(a, b, c=None, d=None):
        return _py_backwards_merge_dicts([{a: a}, {b: b}], c, d)
    """

    tree = ast.parse(source)
    NodeTransformer.apply(tree, DictUnpackingTransformer)

    assert astunparse.unparse(tree) == expected

# Generated at 2022-06-23 22:40:33.481203
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-23 22:40:43.800632
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import round_trip

    def _test_one(before: str, after: str) -> None:
        actual = round_trip(before, DictUnpackingTransformer)
        assert actual == after

    _test_one('{}', '{}')
    _test_one('{1: 1}', '{1: 1}')
    _test_one('{1: 1, 2: 2}', '{1: 1, 2: 2}')
    _test_one('{1: 1, 2: 2, **dict_a}', '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)')

# Generated at 2022-06-23 22:40:47.163959
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from pytest import raises
    import ast
    from ast_tools.transforms import DictUnpackingTransformer

    code = '''
    a = 1
    '''

# Generated at 2022-06-23 22:40:53.639309
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # pylint: disable=unused-variable, expression-not-assigned

    # Original code:
    module: ast.Module = ast.parse("""
    {1: 1, **dict_a}
    """)

    # Transformed code:
    transformed_module: ast.Module = ast.parse("""
    _py_backwards_merge_dicts([{1: 1}], dict_a})
    """)

    DictUnpackingTransformer(module).visit(module)

    assert module == transformed_module


# Generated at 2022-06-23 22:40:57.823390
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    obj = DictUnpackingTransformer()
    assert(obj.visit_Dict)
    assert(obj.visit_Module)
    assert(obj.generic_visit)
    assert(obj.target)
    assert(obj._tree_changed)
    assert(obj._split_by_None)
    assert(obj._merge_dicts)
    assert(obj._prepare_splitted)

# Generated at 2022-06-23 22:40:59.522710
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass #TODO: implement

# Generated at 2022-06-23 22:41:04.315364
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    with open(__file__[:-2] + 'dict.py', 'rt') as f:
        code = f.read()
        module = ast.parse(code)

    DictUnpackingTransformer().visit(module)  # type: ignore

    with open('result.py', 'wt') as f:
        f.write(astor.to_source(module))

# Generated at 2022-06-23 22:41:14.939817
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from asttokens.asttokens import ASTTokens
    from ..utils.transform import transform
    from ..utils.compile import compile

    source = """
    D = {'a': 'a', **{}}
    """
    expected = """
    D = _py_backwards_merge_dicts([{'a': 'a'}, {}])
    """
    actual, _ = transform(DictUnpackingTransformer, source)
    assert compile(expected) == compile(actual)

    source = """
    D = {'a': 'a', **{'b': 'b'}}
    """
    expected = """
    D = _py_backwards_merge_dicts([{'a': 'a'}, {'b': 'b'}])
    """

# Generated at 2022-06-23 22:41:20.201331
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import check_expected

    source = """\
    {1: 1, **dict_a}
    """
    expected = """\
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source)

    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)

    check_expected(tree, expected)

# Generated at 2022-06-23 22:41:21.515008
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import TEST_MODULE_CODE
    from ..utils.tree import parse


# Generated at 2022-06-23 22:41:23.378355
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''
{1: 1}
'''

# Generated at 2022-06-23 22:41:29.775894
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    expr = ast.parse("assert True")
    expr = DictUnpackingTransformer().visit(expr)
    assert isinstance(expr, ast.Module)
    assert isinstance(expr.body[0], ast.Expr)
    assert isinstance(expr.body[0].value, ast.Str)
    assert expr.body[0].value.s == merge_dicts.get_body()
    assert isinstance(expr.body[1], ast.Assert)

# Generated at 2022-06-23 22:41:38.620519
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    from ..utils.tree import parse

    # Test case 1
    test_str = "d = {1: 1, **dict_a}"
    expected_str = "_py_backwards_merge_dicts([{1: 1}], dict_a,)"
    src_ast = parse(test_str)
    expected_ast = parse(expected_str)

    result_ast = DictUnpackingTransformer().visit(src_ast)
    assert result_ast == expected_ast

    # Test case 2
    test_str = "{1: 1, 5: 5, **dict_a, **dict_b, 3: 3, 4: 4, **dict_c, **dict_d}"

# Generated at 2022-06-23 22:41:40.392654
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """\
{1, **dict_a, 2: 3, 4: 5, **dict_b, 6: 7, **dict_c}
"""

# Generated at 2022-06-23 22:41:44.715271
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    text = '{1: 1, 2: 2, **a, **b}'
    transformed = '''_py_backwards_merge_dicts(
        [
            {1: 1, 2: 2},
            a,
            b
        ]
    )'''
    assert code_to_tree(text) == code_to_tree(transformed)



# Generated at 2022-06-23 22:41:54.723225
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Given
    node = ast.Module(
        body=[
            ast.Expr(value=ast.Dict(
                keys=[
                    ast.NameConstant(value=None),
                    ast.NameConstant(value=None),
                    ast.NameConstant(value=None)
                ],
                values=[
                    ast.Dict(keys=[], values=[]),
                    ast.Call(
                        func=ast.Name(id='dict'),
                        args=[],
                        keywords=[]),
                    ast.Dict(keys=[
                        ast.Num(n=1),
                        ast.Num(n=2),
                    ], values=[
                        ast.Str(s='one'),
                        ast.Str(s='two'),
                    ])
                ]
            ))
        ])

    # When
    transformer = DictUnpackingTransformer

# Generated at 2022-06-23 22:42:02.587175
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    pairs = [
        (ast.Constant(1), ast.Constant(1)),
        (None, ast.NameConstant(None)),
        (ast.Constant(2), ast.Constant(2)),
    ]

    assert transformer._split_by_None(pairs) == [
        [(ast.Constant(1), ast.Constant(1))],
        ast.NameConstant(None),
        [(ast.Constant(2), ast.Constant(2))],
    ]

    splitted = transformer._split_by_None(pairs)
    prepared = transformer._prepare_splitted(splitted)
    out = transformer._merge_dicts(prepared)

    assert isinstance(out, ast.Call)


# Generated at 2022-06-23 22:42:03.516003
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:14.355905
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import sys
    import inspect
    import ast as pyast
    from typed_ast import ast3 as ast

    class DictUnpackingTransformer(DictUnpackingTransformer):
        def __init__(self, tree):
            self._tree = tree
            self._tree_changed = False
            self.visit(self._tree)

        def _tree_changed(self):
            pass

        def visit(self, node):
            self._tree_changed = True
            super().visit(node)
            if self._tree_changed:
                self._tree_changed = False
                self.visit(self._tree)

    tree = pyast.parse("{1: 1}")
    transpiled = ast.parse(inspect.getsource(DictUnpackingTransformer.visit_Module))
    DictUnpackingTrans

# Generated at 2022-06-23 22:42:22.225647
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astor.code_gen import to_source
    from .base import BaseNodeTransformerTestCase
    from astunparse import unparse

    class Test(BaseNodeTransformerTestCase):
        transformer = DictUnpackingTransformer
        filename = __file__

        def test_empty_dict(self):
            src = '{}'
            expected = '{}'
            self._test(src, expected)

        def test_simple(self):
            src = '{1: 1, **dict_a}'
            expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
            self._test(src, expected)
    
    test = Test()
    test.test_empty_dict()
    test.test_simple()
    print('ok')



# Generated at 2022-06-23 22:42:26.774918
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import check_results, make_example_pyfile
    from .test_base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        target_node = ast.Module
        transformer = DictUnpackingTransformer

        def make_example_tree(self):
            src = """
            def f():
                {1: 1, **dict_a}
            """
            tree = make_example_pyfile(src)
            return tree

        def check(self, result_tree):
            def_node = result_tree.body[0]
            result = def_node.body[0]

# Generated at 2022-06-23 22:42:27.894769
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:39.278614
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.source import source
    from .make_visitor import make_visitor

    # noinspection PyUnusedLocal
    def assert_visit(node, expected_node=None, **kw):
        visitor = make_visitor(DictUnpackingTransformer)
        transformed = visitor.visit(node)
        printed = source(transformed)
        assert printed == expected_node, (printed, expected_node)

    d = ast.Dict()

    assert_visit(d, '{}')
    assert_visit(d, '{}', keys=[], values=[])

    assert_visit(d, '{0: 0}', keys=[ast.Num(0)], values=[ast.Num(0)])


# Generated at 2022-06-23 22:42:42.509509
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("{1: 1, **{2: 2, **{3: 3}}}")
    DictUnpackingTransformer().visit(module)
    print(module.body[0])
    

# Generated at 2022-06-23 22:42:49.699796
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import create_module as m
    from .base import assert_transformed

    t = DictUnpackingTransformer()
    assert_transformed(t,
                       m("{'a': 0, **d}"),
                       m("_py_backwards_merge_dicts([{'a': 0}], d)"))

    # assert_transformed(t,
    #                    m("{**{}, **d}"),
    #                    m("_py_backwards_merge_dicts([{}], d)"))
    # assert_transformed(t,
    #                    m("{**{}, **{}}"),
    #                    m("_py_backwards_merge_dicts([{}], {})"))

# Generated at 2022-06-23 22:42:56.562150
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    t = DictUnpackingTransformer()
    assert t.visit_Module(ast.parse("{2: 3}")) == ast.parse("{2: 3}")

    x = t.visit_Module(ast.parse("{1: 1, **{2: 3}}"))
    assert ast.dump(x) == ast.dump(ast.parse("_py_backwards_merge_dicts([{1: 1}], {2: 3})"))



# Generated at 2022-06-23 22:42:57.963540
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): # type: ignore
    assert DictUnpackingTransformer()


# Generated at 2022-06-23 22:43:07.850379
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .base import code_to_ast

    def prepare(code: str) -> ast.Module:
        node = code_to_ast(DictUnpackingTransformer, code)
        DictUnpackingTransformer().visit(node)
        return node

    assert str(prepare('{1: 1, **a}')).strip() == '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], a)
    '''


# Generated at 2022-06-23 22:43:08.830439
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer



# Generated at 2022-06-23 22:43:12.742534
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse(
        """
        {1: 1, **dict_a, 2: 2, **dict_b}
        """)
    # Compile a snippet in the same way as typed_ast_converter does
    merged_module = DictUnpackingTransformer().visit(module)
    result = ast.fix_missing_locations(merged_module)
    assert str(result).count('\n') == 3



# Generated at 2022-06-23 22:43:21.982355
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    def to_ast(code):
        return ast.parse(code).body[0].value

    assert to_ast('{1:2}') == to_ast('{1: 2}')
    assert to_ast('{1:2, 3:4}') == to_ast('{1: 2, 3: 4}')
    assert to_ast('{1:2, 3:4, **dict_a}') == to_ast(
        '_py_backwards_merge_dicts([{1: 2, 3: 4}], dict_a)')
    assert to_ast('{1:2, **dict_a, 3:4}') == to_ast(
        '_py_backwards_merge_dicts([{1: 2}, dict_a, {3: 4}])')
    assert to_ast

# Generated at 2022-06-23 22:43:28.959972
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''
        {
            'a': 1,
            **d1,
            **d2,
            'b': 2
        }
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{'a': 1}, {'b': 2}], d1, d2)
    '''
    module, _ = compile_source(code, mode='exec')
    module_expected, _ = compile_source(expected, mode='exec')
    assert isinstance(module, ast.Module)
    assert isinstance(module_expected, ast.Module)

# Generated at 2022-06-23 22:43:39.167070
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    @typechecked
    def test_impl(code_in: str, code_out: str) -> None:
        tree_in = ast.parse(code_in, mode='eval')
        tree_out = ast.parse(code_out, mode='eval')
        DictUnpackingTransformer().visit(tree_in)
        assert tree_in == tree_out

    test_impl("""\
{1: 1, **aa}""", """\
{1: 1, **aa}""")
    test_impl("""\
{1: 1, **aa, **bb}""", """\
_py_backwards_merge_dicts([{1: 1}, aa], bb)""")


# Generated at 2022-06-23 22:43:50.599287
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from ..utils.tree_to_str import tree_to_str

    node = ast.parse("""
        {1: 1, **dict_a, 2: 2}
        {1: 1, 2: 2}
    """)

    DictUnpackingTransformer().visit(node)
    result = tree_to_str(node)

    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
        _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}])
        {1: 1, 2: 2}
    """
    assert result == expected

# Generated at 2022-06-23 22:43:51.345336
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:43:52.634968
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)

# Generated at 2022-06-23 22:44:03.723554
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import ast_to_tuple
    from .. import compile_and_transforms

    module = compile_and_transforms('''
    {1:1, 2:2, **{3:3, 4:4}, 5:5}
    ''', [DictUnpackingTransformer])

# Generated at 2022-06-23 22:44:11.858986
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # GIVEN
    from ..utils.source import source
    from .base import NodeTransformerDict

    # WHEN
    transformer = NodeTransformerDict({
        3: [DictUnpackingTransformer],
        4: [DictUnpackingTransformer]
    })

    # THEN
    tree = transformer.visit(source("{1: 1, **{'a': 1}}").tree)
    assert compile(tree, filename='<test>', mode='eval') == \
        compile("_py_backwards_merge_dicts([{1: 1}], {'a': 1})",
                filename='<test>',
                mode='eval')

# Generated at 2022-06-23 22:44:16.958921
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = '''
        {1: 1, **dict_a}
        '''

    expect = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        '''

    from . import inplace_transformer_test
    inplace_transformer_test(DictUnpackingTransformer, code, expect)

# Generated at 2022-06-23 22:44:26.979240
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    splitted = [([('a', 1)], None, [('b', 2), ('c', 3)], None),
                ([('d', 4), ('e', 5)], None),
                ([('f', 6), ('g', 7)]),
                ([('h', 8)])]

# Generated at 2022-06-23 22:44:37.270512
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    inst = DictUnpackingTransformer()
    
    class Dummy:
        pass
    
    class DummyModule(ast.Module):
        pass
    
    class DummyFunctionDef(ast.FunctionDef):
        pass
    
    dummy_node = Dummy()
    dummy_node.__class__ = DummyModule
    
    def test_visit_Module():
        inst.visit(dummy_node)
        assert dummy_node.body[0].__class__ == ast.FunctionDef
        assert dummy_node.body[0].name == '_py_backwards_merge_dicts'
        
    def test_visit_Dict():
        pass
    
    def test_visit_FunctionDef():
        pass
    
    def test_visit_ClassDef():
        pass
    


# Generated at 2022-06-23 22:44:43.944715
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    import textwrap

    transformer = DictUnpackingTransformer()
    code = textwrap.dedent("""\
        {
            'a': 1,
            **a
        }
    """)
    node = ast.parse(code)
    transformer.visit(node)

    assert astunparse.unparse(node).strip() == textwrap.dedent("""\
        _py_backwards_merge_dicts([{'a': 1}], a)
    """).strip()

# Generated at 2022-06-23 22:44:48.897978
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import NodeTransformerVisitor

    visitor = NodeTransformerVisitor(DictUnpackingTransformer())
    code = '{1: 1, **a, 2: 2, **b}'
    expected = '_py_backwards_merge_dicts([{1: 1, 2: 2}], a, b)'
    tree = ast.parse(code)
    visitor.visit(tree)
    assert source(tree) == expected



# Generated at 2022-06-23 22:44:50.419860
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)



# Generated at 2022-06-23 22:44:54.972255
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():  # type: () -> None
    from .. import tree

    code = """
    x = {1: 2, **{3:4}}
    """
    module = tree.build(code, 3)
    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-23 22:45:03.457453
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.codegen import ast_to_code

    transform = DictUnpackingTransformer()
    source = source_to_ast("""
        {1: 1, **dict_a, **dict_b}
    """)
    result = transform.visit(source)
    expected = source_to_ast("""
        _py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)
    """)

    assert ast_to_code(result) == ast_to_code(expected)

# Generated at 2022-06-23 22:45:04.478537
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-23 22:45:08.931199
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = parse("{1: 1, **a}")
    expected = parse("""
        _py_backwards_merge_dicts([{1: 1}], a)
    """)

    assert DictUnpackingTransformer().visit(node) == expected


# Generated at 2022-06-23 22:45:18.903391
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse

    node = ast.Dict(keys=[None, ast.Num(n=1), None, ast.Str(s='a')],
                    values=[ast.Dict(keys=[], values=[]),
                            ast.Num(n=1),
                            ast.Dict(keys=[ast.Str(s='a')], values=[ast.Num(n=1)]),
                            ast.Str(s='b')])
    expected = """
_py_backwards_merge_dicts([{}, {1: 1}, {'a': 1}, {'a': 'b'}])
"""

    transformer = DictUnpackingTransformer()
    result = transformer.visit_Dict(node)

    assert astunparse.unparse(result) == expected

# Generated at 2022-06-23 22:45:21.074035
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    init = '{\n  "key1": 1,\n  **dict_a\n}'

# Generated at 2022-06-23 22:45:29.896000
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import astunparse
    from ..utils.fake_module import FakeModule
    from ..utils.fake_module import replace_module_name

    source = """
x = {1: 1, **Dict()}
"""

    expected = """
_py_backwards_merge_dicts([{1: 1}], Dict())
"""

    expected = expected.strip()  # type: ignore
    tree = ast.parse(source)

    with FakeModule('test_module', tree) as module:
        with replace_module_name('test_module', module):
            result = astunparse.unparse(DictUnpackingTransformer().visit(tree))
            assert expected == result.strip()

# Generated at 2022-06-23 22:45:36.438683
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '{1: 1, **dict1, 2: 2, 3: 3, **dict2, 4: 4}'
    expected = (
        '_py_backwards_merge_dicts([dict()], dict1, '
        '_py_backwards_merge_dicts([dict()], dict2)')

    from . import standard_transformer_unit_test as test
    test.transformer_unit_test(DictUnpackingTransformer, source, expected)

# Generated at 2022-06-23 22:45:44.179598
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    module = ast.parse('{1: 1, **a}')
    DictUnpackingTransformer().visit(module)
    assert astor.to_source(module) == (
        'def _py_backwards_merge_dicts(dicts):\n'
        '    result = {}\n'
        '    for dict_ in dicts:\n'
        '        result.update(dict_)\n'
        '    return result\n'
        '\n'
        '_py_backwards_merge_dicts([{1: 1}], a)\n')

# Generated at 2022-06-23 22:45:49.707404
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_astunparse
    tree = ast.parse('{**a}')
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert typed_astunparse.unparse(new_tree) == '\ndef _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n\n_py_backwards_merge_dicts([{}], a)\n'


# Generated at 2022-06-23 22:46:00.614888
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typing import Dict

    source = """
        {1: 1, 2: 2, None: {3: 3, 4: 4}, 5: 5, None: {6: 6, 7: 7}}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3, 4: 4}, {5: 5}, {6: 6, 7: 7}])
    """

    @snippet
    def _prepare_merge_dicts():
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

    expected_tree = ast.parse(expected).body[0].value  # type: ignore
    tree = ast.parse

# Generated at 2022-06-23 22:46:01.585203
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:46:02.494731
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()



# Generated at 2022-06-23 22:46:05.208432
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('1')
    module = DictUnpackingTransformer(verbose=False).visit(module)
    exec(compile(module, '<test>', 'exec'))
    assert '_py_backwards_merge_dicts' in globals()


# Generated at 2022-06-23 22:46:13.623486
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import dedent
    from ..visitor import Visitor, TreeChanger
    from ..utils.tree import tree, ParentVisitor

    code = dedent('''\
        {1: 1, **dict_a}
    ''')
    tree_ = tree(code, 'test.py')
    Visitor.debug = True
    TreeChanger.debug = True
    ParentVisitor.debug = True
    transformed = Visitor.visit(tree_, DictUnpackingTransformer)
    print(tree(transformed))

    assert 1 == 2

# Generated at 2022-06-23 22:46:18.190583
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_decompile_equal
    assert_decompile_equal(
        DictUnpackingTransformer,
        """
        {1: 1, **dict_a}
        """,
        """
        _py_backwards_merge_dicts([dict({1: 1})], dict_a)
        """)


# Generated at 2022-06-23 22:46:19.608490
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:46:26.076138
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    source = dedent("""
        {1: 1, **dict_a, 2: 2}
        """)
    expected = dedent("""
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
        """)

    from ..utils.test_utils import generate_single_test
    generate_single_test(DictUnpackingTransformer,
                         source, expected, target=(3, 4))

# Generated at 2022-06-23 22:46:32.171091
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """\
{a: b, None: c, d: e, None: f}"""
    expected = """\
_py_backwards_merge_dicts([dict(a=b), c, dict(d=e), f])"""
    transpiled = ast.fix_missing_locations(
        DictUnpackingTransformer().visit(ast.parse(source)))
    assert expected == transpiled.body[-1].body[0].value.s

# Generated at 2022-06-23 22:46:33.042451
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass


# Generated at 2022-06-23 22:46:36.493504
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = '''\
{1: 1, **dict_a}
'''
    expected = '''\
_py_backwards_merge_dicts((dict({1: 1}), dict_a))
'''
    transformer = DictUnpackingTransformer()
    assert transformer(code) == expected



# Generated at 2022-06-23 22:46:41.153412
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ...utils.testing import assert_in, assert_not_in
    """Test for method visit_Module of class DictUnpackingTransformer."""
    code = """
data = 1
"""
    node = ast.parse(code)
    transformer = DictUnpackingTransformer()
    actual = transformer.visit(node)  # type: ignore

    assert_in(actual.body, '_py_backwards_merge_dicts')
    assert_in(actual.body, 'merge_dicts')
    assert_not_in(actual.body, '_py_merge_dicts')



# Generated at 2022-06-23 22:46:52.275275
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_node = ast.parse('{1: 2, 3: 3, 4: 4, **a, **b}')
    result_node = DictUnpackingTransformer().visit(module_node)
    # {1: 2, 3: 3, 4: 4, **a, **b} =>
    #   _py_backwards_merge_dicts([{1: 2, 3: 3, 4: 4}], a, b)
    assert result_node.body[-1].value.func.id == '_py_backwards_merge_dicts'
    assert len(result_node.body[-1].value.args) == 3
    assert result_node.body[-1].value.args[0].keys[0].n == 1


__all__ = ['DictUnpackingTransformer']

# Generated at 2022-06-23 22:46:53.422719
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:47:02.796033
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = '''
{1: 1, **{2: 2}, 3: 3, **{4: 4, 5: 5}, 6: 6}
    '''

    tree = ast.parse(code)    # type: ignore
    DictUnpackingTransformer().visit(tree)  # type: ignore
    expected_code = '''
_py_backwards_merge_dicts(
    [
        {1: 1, 3: 3, 6: 6},
        dict({2: 2}),
        dict({4: 4, 5: 5})
    ]
)
    '''
    expected_tree = ast.parse(expected_code)  # type: ignore
    assert ast.dump(tree, include_attributes=False) == \
           ast.dump(expected_tree, include_attributes=False)


#

# Generated at 2022-06-23 22:47:04.394005
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:47:14.918249
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    assert transformer.visit(ast.parse('{}')).body[0].value == \
        ast.Dict()

    assert transformer.visit(ast.parse('{1: 1}')).body[0].value == \
        ast.Dict(
            keys=[ast.Num(1)],
            values=[ast.Num(1)])

    assert isinstance(transformer.visit(ast.parse('{1: 1, **{}}')).body[0].value,
                      ast.Call)
    assert isinstance(transformer.visit(ast.parse('{1: 1, **foo}')).body[0].value,
                      ast.Call)

# Generated at 2022-06-23 22:47:24.401975
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_same_asts
    from ..utils.parser import parse_str
    from .unparser import Unparser

    # Make sure that the test code is valid:
    assert_same_asts(DictUnpackingTransformer, parse_str, Unparser)

    # Test recursive cases:
    assert_same_asts(DictUnpackingTransformer, parse_str, Unparser,
    '''
    {1: 1}
    ''')

    assert_same_asts(DictUnpackingTransformer, parse_str, Unparser,
    '''
    {**{}}
    ''')

    assert_same_asts(DictUnpackingTransformer, parse_str, Unparser,
    '''
    {**{1: 1}}
    ''')


# Generated at 2022-06-23 22:47:25.411843
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .test_utils import get_test_case_as_transformer_args
    DictUnpackingTransformer(*get_test_case_as_transformer_args(__file__))

# Generated at 2022-06-23 22:47:31.137621
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .. import compile_snippet
    from . import remove_comments_and_docstrings, StringTransformer


# Generated at 2022-06-23 22:47:35.839574
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.trees import ast_from, ast_to
    code = '{**a, 1: 2, 3: 4, **b}'
    expected = '_py_backwards_merge_dicts([dict(a), dict(1=2, 3=4), dict(b)])'
    tree = ast_from(code)
    DictUnpackingTransformer().visit(tree)
    assert ast_to(tree) == expected
    assert ast.dump(tree) == expected
