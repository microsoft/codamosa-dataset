

# Generated at 2022-06-23 22:37:43.362154
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    import textwrap

    transformer = DictUnpackingTransformer()

    def t(source: str, *, expected: str) -> None:
        tree = ast.parse(textwrap.dedent(source))
        transformed = transformer.visit(tree)
        # TODO: do not print trailing whitespaces
        assert astunparse.unparse(transformed) == expected

    t(source='''
        foo = {1: 1}
    ''',
       expected='''
        _py_backwards_merge_dicts([{1: 1}])
        foo = _py_backwards_merge_dicts([{1: 1}])
    ''')


# Generated at 2022-06-23 22:37:54.172853
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Test that method visit_Module of class DictUnpackingTransformer works good.
    """
    import astor
    from src.python.dict_unpack.dict_unpack import DictUnpackingTransformer
    x = "a = {1:2, 3:4, **y, 5:6, **z, 7:8}"
    tree = ast.parse(x)
    DictUnpackingTransformer().visit(tree)
    expected_result = \
        """def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result

a = _py_backwards_merge_dicts([{1: 2, 3: 4}, 5: 6, 7: 8], y, z)"""
    assert ast

# Generated at 2022-06-23 22:37:57.991903
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Arrange
    # Act
    dict_unpacking_transformer \
        = DictUnpackingTransformer()

    # Assert
    assert isinstance(dict_unpacking_transformer,
                      DictUnpackingTransformer)

# Generated at 2022-06-23 22:37:59.255974
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:38:00.893079
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:38:01.944958
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-23 22:38:08.102400
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    snippet = """
    {1: 1, 2: 2, **{3: 4, **{5: 6, 7: 7}, 8: 8}, 9: 9}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 4, 8: 8}, {5: 6, 7: 7}, {9: 9}])
    """
    DictUnpackingTransformer().assertTransform(snippet, expected)

################################################################################
# Do not modify the code below

__all__ = [DictUnpackingTransformer]

# Generated at 2022-06-23 22:38:08.672413
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()



# Generated at 2022-06-23 22:38:13.833671
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from .transformers import DictUnpackingTransformer

    try:
        from ast import DictComp
    except ImportError:
        DictComp = None

    def transform(stmt):
        src = 'x = ' + stmt
        tree = ast.parse(src)
        tree = DictUnpackingTransformer().visit(tree)
        node = tree.body[0].value
        return astor.to_source(node).strip()


# Generated at 2022-06-23 22:38:18.809649
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse("{1: 1, **{2: 2}, 3: 3}")
    node = tree.body[0].value
    assert isinstance(node, ast.Dict)
    with DictUnpackingTransformer(tree) as t:
        new_node = t.visit(node)
    assert isinstance(new_node, ast.Call)

# Generated at 2022-06-23 22:38:23.853566
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import parse, dump
    from ..fixers.dict_unpacking import DictUnpackingTransformer

    code = source('''
        {1: 1, **dict_a, None, **dict_b, 2: 2, **dict_c}''')
    node = parse(code)
    DictUnpackingTransformer().visit(node)
    print(dump(node))
    #assert False



# Generated at 2022-06-23 22:38:29.890507
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import Source
    source = Source("""
        {1:2, **c}
        """)
    module = source.parse()
    transformed = DictUnpackingTransformer().visit(module)

    assert transformed.body[0].body[0].value.func.id \
        == '_py_backwards_merge_dicts'



# Generated at 2022-06-23 22:38:37.014755
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from . import finalize_ast
    from . import transform_v3
    from ..utils.tree import ast_to_str
    from ..utils.examples import DictUnpacking

    source = DictUnpacking.source
    expected = DictUnpacking.expected

    tree = transform_v3(ast.parse(source)) # type: ignore
    tree = finalize_ast(tree)
    tree = DictUnpackingTransformer().visit(tree)
    assert ast_to_str(tree) == expected  # type: ignore

# Generated at 2022-06-23 22:38:44.862850
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import Dict
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import Arg
    from typed_ast.ast3 import Num
    from typed_ast.ast3 import Call
    from typed_ast.ast3 import List

    transformer = DictUnpackingTransformer()
    node = Module(body=[Dict(keys=[None, Name(id='a', ctx=Name.Load())],
                             values=[Dict(keys=[Num(n=1)], values=[Num(n=1)]),
                                     Name(id='a', ctx=Name.Load())])])

# Generated at 2022-06-23 22:38:48.272579
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.example import example

    result = example(DictUnpackingTransformer)
    assert result.body[0].value.args[1].keys[1].id == '_py_backwards_merge_dicts'

# Generated at 2022-06-23 22:38:59.328310
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    transformer = DictUnpackingTransformer()

    node = ast.Dict(keys=[None, ast.Num(n=1)], values=[ast.Name(id='a'),
                                                       ast.Num(n=2)])
    result = transformer.visit(node)
    assert isinstance(result, ast.Call)
    assert isinstance(result.func, ast.Name)
    assert result.func.id == '_py_backwards_merge_dicts'
    assert len(result.args) == 1
    assert isinstance(result.args[0], ast.List)
    assert len(result.args[0].elts) == 2
    assert isinstance(result.args[0].elts[0], ast.Call)

# Generated at 2022-06-23 22:39:01.765098
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    obj = DictUnpackingTransformer()
    assert isinstance(obj, BaseNodeTransformer)
    assert obj._tree_changed == False


# Generated at 2022-06-23 22:39:11.931924
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Regular dict without unpacking should be passed through without changes
    before = ast.parse('{1: 1}')
    after = ast.parse('{1: 1}')
    assert DictUnpackingTransformer().visit(before) == after

    # Dict with unpacking should be replaced for backwards_merge_function call
    before = ast.parse('{1: 1, **dict_a}')
    after = ast.parse('_py_backwards_merge_dicts(([{1: 1}], dict_a))')
    assert DictUnpackingTransformer().visit(before) == after

    # Dict with multiple unpacking calls should be replaced with
    # backwards_merge_function call
    before = ast.parse('{1: 1, **dict_a, **dict_b}')

# Generated at 2022-06-23 22:39:22.107008
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .common import assert_transformation

    import mypy.api

    i = """
    a = {1: 2, **{3: None}}
    b = {4: 2, **a, **{3: 4, 'foo': 'bar'}}
    """
    o = """
    import py_backwards.utils.tree

    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    a = _py_backwards_merge_dicts([{1: 2}], dict_a)
    b = _py_backwards_merge_dicts([{4: 2}], a, dict_a, {3: 4, 'foo': 'bar'})
    """
    assert_

# Generated at 2022-06-23 22:39:23.119038
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Unit tests for method DictUnpackingTransformer._split_by_None

# Generated at 2022-06-23 22:39:28.778790
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(*args):
        result = {}
        for dict_ in args:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts({1: 1}, dict_a)
    """
    tree = ast.parse(dedent(code))
    DictUnpackingTransformer().visit(tree)
    result = astor.to_source(tree).strip()
    assert result == dedent(expected).strip()


# Generated at 2022-06-23 22:39:30.034276
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-23 22:39:35.830284
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Arrange
    tree = ast.parse("""{1: 1, **{2: 2}}""")
    expected = ast.parse("""_py_backwards_merge_dicts([{1: 1}], {2: 2})""")
    transformer = DictUnpackingTransformer()

    # Act
    result = transformer.visit(tree)

    # Assert
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-23 22:39:42.276582
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Tests if all methods are called, at least.
    dut = DictUnpackingTransformer()
    dut.visit_Dict = Mock()
    dut.visit_Module = Mock()
    dut.generic_visit = Mock()

    pair = (ast.Name(id='a'), ast.Name(id='b'))
    node = ast.Dict(keys=(None,) + pair)

    dut.visit(node)
    assert dut.visit_Dict.called
    assert dut.visit_Module.called
    assert dut.generic_visit.called

# Generated at 2022-06-23 22:39:44.334752
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    from .constants import print_function

# Generated at 2022-06-23 22:39:53.490287
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    node = ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=2)],
                    values=[ast.Num(n=10), ast.Name(id='a'), ast.Num(n=20)])
    new_node = transformer(node)
    assert isinstance(new_node, ast.Call)
    assert isinstance(new_node.func, ast.Name)
    assert new_node.func.id == '_py_backwards_merge_dicts'
    assert isinstance(new_node.args[0], ast.List)
    assert len(new_node.args[0].elts) == 2
    assert isinstance(new_node.args[0].elts[0], ast.Dict)
    assert new_node

# Generated at 2022-06-23 22:39:57.871893
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import compile_isolated

    code = '{1: 1, 2: 2, **{3: 3, 4: 4}, 5: 5, **{6: 6, 7: 7}}'
    result = compile_isolated(code, mode='exec')

    # from dis import dis
    #
    # dis(result)
    eval(result.to_code(), {'_py_backwards_merge_dicts': merge_dicts.get_code()})

# Generated at 2022-06-23 22:39:58.609530
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:39:59.826585
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:10.504762
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.Module([ast.Expr(value=ast.Name(id='foo'))])

# Generated at 2022-06-23 22:40:18.610104
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ast import parse
    from .transformer import BackwardsCompatibleTransformer
    node = parse("""{1: 1, **{3:4}}""")
    
    transformed = BackwardsCompatibleTransformer((3,4)).visit(node)
    
    assert transformed.body[0].body[0].value.elts[0].keys[0].n == 1
    assert transformed.body[0].body[0].value.elts[0].values[0].n == 1
    assert transformed.body[0].body[0].value.elts[1].keys[0].n == 3
    assert transformed.body[0].body[0].value.elts[1].values[0].n == 4


# Generated at 2022-06-23 22:40:26.231721
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Foo
    @snippet
    def foo():
        d = {1: 1, **{2: 2, 3: 3}, **{'a': 'a', 'b': 'b'}}

    # Bar
    @snippet
    def bar():
        def foo():
            d = {1: 1, **{2: 2, 3: 3}, **{'a': 'a', 'b': 'b'}}

    # Bar
    @snippet
    def baz():
        class Foo:
            d = {1: 1, **{2: 2, 3: 3}, **{'a': 'a', 'b': 'b'}}

    test_cases = (foo, bar, baz)

    for case in test_cases:
        node = case.get_ast()
        transformer = DictUnpackingTrans

# Generated at 2022-06-23 22:40:37.195083
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse(dedent('''
        {1: 1, 2: 2}
    '''))
    transformed = DictUnpackingTransformer().visit(node)
    assert transformed == ast.parse(dedent('''
        {1: 1, 2: 2}
    '''))

    node = ast.parse(dedent('''
        {1: 1, **dict_a}
    '''))
    transformed = DictUnpackingTransformer().visit(node)
    assert transformed == ast.parse(dedent('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''))

    node = ast.parse(dedent('''
        {1: 1, **dict_a, 2: 2}
    '''))
   

# Generated at 2022-06-23 22:40:43.289365
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("""{1: 1, 2: 2, **{4: 4}, 3: 3, **{5: 5}}""")
    DictUnpackingTransformer().visit(module)
    assert module == ast.parse("""{yield from _py_backwards_merge_dicts(
        [{1: 1, 2: 2}, {3: 3}],
        {4: 4},
        {5: 5}
    )}""")

# Generated at 2022-06-23 22:40:48.521254
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('\n'.join((
        '{\n'
        '    1: 1,\n'
        '    2: 2,\n'
        '    **dict_a,\n'
        '    "z": None,\n'
        '    3: 3,\n'
        '    **dict_b,\n'
        '    **dict_c,\n'
        '}'
    )))

    expected = ast.parse('\n'.join((
        'call = _py_backwards_merge_dicts',
        'call([dict(1, 2, 3), dict_a, dict("z", None), dict_b, dict_c])',
    )))

    DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == ast.dump

# Generated at 2022-06-23 22:40:50.198215
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert isinstance(DictUnpackingTransformer().visit(ast.parse("")), ast.Module)

# Generated at 2022-06-23 22:40:58.565089
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-23 22:41:06.687131
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3 as ast
    source = '''
b = {1:2, 3:4}
c = {1:2, 3:4,**b}
d = {1:2, 3:4,**b, 5:6}
e = {1:2, 3:4,**b, 5:6, **c}
f = {1:2, 3:4,**b, 5:6, **c, 7:8}
g = {1:2, 3:4,**b, 5:6, **c, 7:8,**d}
'''

# Generated at 2022-06-23 22:41:12.312966
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_code_equal
    node = ast.parse('{1: 1, **dict_a}')
    DictUnpackingTransformer().visit(node)
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_code_equal(node, expected)

# Generated at 2022-06-23 22:41:13.667387
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:41:22.316196
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.Module(
        body=[
            ast.Dict(
                keys=[
                    ast.Constant(1),
                    ast.Name(id='x', ctx=ast.Load()),
                    ast.Name(id='y', ctx=ast.Load()),
                    ast.Name(id='z', ctx=ast.Load()),
                    ast.Constant(2),
                    ast.Constant(3),
                ],
                values=[
                    ast.Constant(1),
                    ast.Constant(2),
                    ast.Constant(3),
                    ast.Constant(4),
                    ast.Constant(2),
                    ast.Constant(3),
                ],
            ),
        ])

# Generated at 2022-06-23 22:41:27.504902
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3

    module = ast3.parse('{1: 1}')
    module_transformed = DictUnpackingTransformer().visit(module)
    assert module_transformed.body[0].body[0].value.elts == [
        merge_dicts.get_src()
    ]



# Generated at 2022-06-23 22:41:32.306016
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    with open('tests/visit_Dict.py') as f:
        tree = ast.parse(f.read())
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 22:41:35.901538
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    m = ast.parse('a = 1')
    t = DictUnpackingTransformer()
    t.visit(m)
    assert m.body[0].value.args[1].id == '_py_backwards_merge_dicts'


# Generated at 2022-06-23 22:41:43.106177
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.transform_test_helper import transform_test_helper
    transform_test_helper(DictUnpackingTransformer, 'a', """
    {1: 2, 3: 4, **a}
    """, """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 2, 3: 4}], a)
    """)


# Generated at 2022-06-23 22:41:46.415857
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    # Given
    a = ast.parse('{1:1, **x, **y, 3:3}')
    d = DictUnpackingTransformer()

    # When
    x = d.visit(a)

    # Then

# Generated at 2022-06-23 22:41:56.113920
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    __tracebackhide__ = True
    class TestTransformer(DictUnpackingTransformer):
        def __init__(self):
            self._tree_changed = False
    node = ast.parse('{1: 1, 2: 2, 3: 3, **{4: 4, 5: 5}, 6: 6, 7: 7}')
    transformer = TestTransformer()  # type: ignore
    result = transformer.visit(node)  # type: ignore

# Generated at 2022-06-23 22:41:58.246666
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert not transformer.tree_changed()
    assert isinstance(transformer, ast.NodeTransformer)


# Generated at 2022-06-23 22:41:59.041577
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:00.801571
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert eval(compile(merge_dicts, '<test>', 'exec')) == {1: 1, 2: 2}


# Generated at 2022-06-23 22:42:08.289208
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    obj = DictUnpackingTransformer()
    source = """
result = {1: 2}
    """
    target = """
_py_backwards_merge_dicts = lambda dicts: {result: result.update(dict_) for dict_ in dicts[::-1]}

result = {1: 2}
    """
    #
    node = ast.parse(source)
    result = ast.parse(target)
    #
    obj.visit(node)
    assert ast.dump(node) == ast.dump(result)



# Generated at 2022-06-23 22:42:18.625738
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .base import CompilationUnitTransformer
    from ..utils.tree import is_equal
    from ..utils.source import source_from_ast

    unit_source = '''
    def a(b):
        c = {1: 2, **b}
    '''
    unit = ast.parse(unit_source)
    unit_transformer = CompilationUnitTransformer(DictUnpackingTransformer)
    unit2 = unit_transformer.visit(unit)

# Generated at 2022-06-23 22:42:19.373837
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None)

# Generated at 2022-06-23 22:42:21.367251
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3

# Generated at 2022-06-23 22:42:27.218992
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.testing import transform


# Generated at 2022-06-23 22:42:35.125687
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """
    >>> tree = ast.parse('''{**a, **b}''')
    >>> transformer = DictUnpackingTransformer()
    >>> new_tree = transformer.visit(tree)
    >>> print(astor.to_source(new_tree))
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([a, b])
    """

# Generated at 2022-06-23 22:42:37.385373
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    program = """\
{**d1, **d2}
_py_backwards_merge_dicts
"""

# Generated at 2022-06-23 22:42:42.186686
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """Unit test for constructor of class DictUnpackingTransformer."""
    try:
        DictUnpackingTransformer()
    except (IndentationError, SyntaxError):
        raise AssertionError("Cannot create instance of DictUnpackingTransformer")
    assert True


# Generated at 2022-06-23 22:42:43.444165
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    assert x is None



# Generated at 2022-06-23 22:42:50.768448
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = parse('''
    dic = {1: 1, **dict_a}
    d = {2: 2, '4': 4}
    ''')

    DictUnpackingTransformer().visit(node)

    result = dump_ast(node)  # noqa

# Generated at 2022-06-23 22:43:00.681762
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from ..utils.ast_builder import build_Module, build_Call, build_Name, \
        build_Dict, build_List
    from typed_astunparse import unparse
    expected = ast3.parse(
        '__py_backwards_merge_dicts([{0: 1, 1: 2}], {2: 3})')

# Generated at 2022-06-23 22:43:06.648030
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
    {}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    """
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)  # type: ignore
    assert ast.dump(tree) == expected



# Generated at 2022-06-23 22:43:08.047151
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert t is not None

# Generated at 2022-06-23 22:43:13.468420
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .utils.testing import assert_source

    assert_source(
        DictUnpackingTransformer,  # type: ignore
        """
        {1: 1, **{2: 2, 3: 3}}
        """,
        """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], {2: 2, 3: 3})
        """,
    )



# Generated at 2022-06-23 22:43:22.552825
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

# Generated at 2022-06-23 22:43:26.209312
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import BaseNodeTransformer

    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)
    assert DictUnpackingTransformer.__name__ == 'DictUnpackingTransformer'
    assert not hasattr(DictUnpackingTransformer, '__init__')
    assert DictUnpackingTransformer.__doc__



# Generated at 2022-06-23 22:43:35.152926
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    expected = ast.parse(
        'def _py_backwards_merge_dicts(dicts):\n'
        '    result = {}\n'
        '    for dict_ in dicts:\n'
        '        result.update(dict_)\n'
        '    return result\n'
        'dict({1: 1, **{2: 2}})')

    module = ast.parse('dict({1: 1, **{2: 2}})')
    DictUnpackingTransformer().visit(module)

    print(ast.dump(module))
    print(ast.dump(expected))
    assert ast.dump(module) == ast.dump(expected)

# Generated at 2022-06-23 22:43:41.986982
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """
        class A:
            def foo(self):
                {1, **d}
        """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        class A:
            def foo(self):
                _py_backwards_merge_dicts([{1,}], d)
        """
    assert expected == DictUnpackingTransformer(code).run()



# Generated at 2022-06-23 22:43:50.029779
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast
    code = '''{1: 1, 2:2, 3: 3, 4:4}'''
    expected_code = r'''{
    1: 1,
    2: 2,
    3: 3,
    4: 4
}'''
    module = ast.parse(code)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(module)
    assert transformer._tree_changed
    assert ast.dump(result) == expected_code


# Generated at 2022-06-23 22:43:55.963712
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    source = snippet("""
    {1: 1, 2: 2, 3: 3}
    """)
    tree = ast.parse(source)
    expected = snippet("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    {1: 1, 2: 2, 3: 3}
    """)
    expected_tree = ast.parse(expected)
    transformer.visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)



# Generated at 2022-06-23 22:44:05.829854
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import parse
    node = parse('{1: 1, **dict_a, 2: 2, 3: 3, **dict_b, **dict_c}')
    assert str(node).replace('\n', ' ') == \
        "Dict(keys=[Num(n=1), None, Num(n=2), Num(n=3), None, None], " \
        "values=[Num(n=1), Name(id='dict_a', ctx=Load()), Num(n=2), Num(n=3), " \
        "Name(id='dict_b', ctx=Load()), Name(id='dict_c', ctx=Load())])"
    transformer = DictUnpackingTransformer()
    transformer.visit(node)
    assert str(node).replace('\n', ' ')

# Generated at 2022-06-23 22:44:10.431976
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    node = ast.parse('{1: 1, **{2: 2}}')
    head = ast.parse(merge_dicts())
    head.body[0].body[0].body.insert(0, ast.Pass())
    DictUnpackingTransformer.run(node)  # type: ignore
    assert ast.dump(head) == ast.dump(node)  # type: ignore

# Generated at 2022-06-23 22:44:12.292978
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:13.550710
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3


# Generated at 2022-06-23 22:44:14.414269
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert True
    # TODO: Implement test



# Generated at 2022-06-23 22:44:16.399785
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor


# Generated at 2022-06-23 22:44:17.056343
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:17.717946
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:18.323186
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    return DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:19.587498
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():  # noqa: D103
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:29.235567
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    filter_list = [
        'from typing import Optional',
        'from typed_ast import ast3 as ast',
        'from pyt.transformers.dict_unpacking import DictUnpackingTransformer',
        'from pyt.utils.source_context import source_context_from_str',
    ]

    code = """
        {**dict_a}
    """
    src_ctx = source_context_from_str(code, 'test.py')
    root_node = src_ctx.root_node
    DictUnpackingTransformer().visit(root_node)

# Generated at 2022-06-23 22:44:30.229434
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:39.752517
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
x = {**dict_a}
y = {1: 1, **dict_b}
z = {1: 1, 2: 2, **dict_c}
"""
    expected = """
_py_backwards_merge_dicts =  def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result
x = _py_backwards_merge_dicts([{}], dict_a)
y = _py_backwards_merge_dicts([{1: 1}], dict_b)
z = _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_c)
"""


# Generated at 2022-06-23 22:44:48.053193
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..unparse import Unparser
    from ..visitor import NoopVisitor

    # NOTE(miskin): it is necessary to run NoopVisitor before,
    # because typed_ast module doesn't set lineno of nodes correctly.
    # (e.g. Omitted(lineno=2))
    src = """\
{1: 1, **None}
{1: 1, **{}}
{1: 1, **dict_a}
{1: 1, **dict_a, **dict_b}
{1: 1, **dict_a, 2: 2, **dict_b}
"""

# Generated at 2022-06-23 22:44:57.473757
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_setup import setup_test_module, assert_node_equals

    module = setup_test_module('''
        {1: 1, **dict_a}
    ''')

    node = DictUnpackingTransformer().visit(module)


# Generated at 2022-06-23 22:44:58.074924
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-23 22:45:01.972655
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse(merge_dicts.get_source())
    assert isinstance(tree, ast.Module)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert new_tree is tree


# Generated at 2022-06-23 22:45:09.141589
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = '''
merge_dicts = None
{1: 1, 2: 2, **dict_a, 3: 3, **dict_b}
'''

    expected = '''
_py_backwards_merge_dicts = None
_py_backwards_merge_dicts([dict({1: 1, 2: 2}), dict_a, dict({3: 3})], dict_b)
'''
    result = DictUnpackingTransformer().visit(ast.parse(source))
    assert ast.dump(result) == expected


# Generated at 2022-06-23 22:45:14.064031
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from autoflake import fix_code

    code = """\
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    fixed = """\
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)
    """

    assert fix_code(code) == fixed

# Generated at 2022-06-23 22:45:22.583432
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''
        {1: 1, **dict_a}
        '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
        '''
    tree = ast.parse(dedent(code))
    tree = DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == dedent(expected)

# Generated at 2022-06-23 22:45:24.424459
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer({3, 4})
    assert transformer



# Generated at 2022-06-23 22:45:33.249866
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dut = DictUnpackingTransformer()
    assert ast.dump(dut.visit(ast.parse('{1: 1, 2: 2}'))) == \
        ast.dump(ast.parse('{1: 1, 2: 2}'))
    assert ast.dump(dut.visit(ast.parse('{1: 1, **{2: 2}}'))) == \
        ast.dump(ast.parse('_py_backwards_merge_dicts([{1: 1}], {2: 2})'))

# Generated at 2022-06-23 22:45:43.279401
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from _ast import Dict, compiler
    from ..utils.tree import to_source


# Generated at 2022-06-23 22:45:49.193364
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
    print({None: 1})
    print(2)
    """

    tree = ast.parse(code)
    tree = DictUnpackingTransformer().visit(tree)  # type: ignore

    expected_code = """
    _py_backwards_merge_dicts([dict((None, 1))])
    print(2)
    """

    expected_tree = ast.parse(expected_code)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Unit tests for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-23 22:45:56.913210
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert_result_source_equal(merge_dicts, DictUnpackingTransformer, [
        ('a = {1: 2}', 'a = {1: 2}'),
        ('a = {1: 2, **{3: 4}}', 'a = _py_backwards_merge_dicts([{1: 2}], {3: 4})'),
        ('a = {**{1: 2}, 3: 4, **{5: 6}}', 'a = _py_backwards_merge_dicts([{1: 2}, {}, {3: 4}, {}, {5: 6}])')
    ])

# Generated at 2022-06-23 22:46:02.104185
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from astunparse import unparse
    a = DictUnpackingTransformer
    ast_tree = ast.parse("{a:1}")
    ast_tree = a().visit(ast_tree)
    assert(unparse(ast_tree) == '_py_backwards_merge_dicts([{a:1}])')


# Generated at 2022-06-23 22:46:11.437437
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # python 3.6:
    # {1: 1, **foo}
    #
    # python 3.5:
    # _py_backwards_merge_dicts([{1: 1}], foo)
    node = ast.parse('{1: 1, **foo}')
    new_node = DictUnpackingTransformer().visit(node)
    assert isinstance(new_node, ast.Module)
    new_node = new_node.body[0]
    assert isinstance(new_node, ast.Expr)
    new_node = new_node.value
    assert isinstance(new_node, ast.Call)
    assert new_node.func.id == '_py_backwards_merge_dicts'
    assert len(new_node.args) == 1

# Generated at 2022-06-23 22:46:17.681671
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse("{1:2, 3:4}")
    trans = DictUnpackingTransformer(node)
    trans.visit(node)
    assert trans.transformed == ast.parse("def _py_backwards_merge_dicts(dicts): result = {}\nfor dict_ in dicts:\n    result.update(dict_)\nreturn result\n\n_py_backwards_merge_dicts([{1: 2}, {3: 4}])")


# Generated at 2022-06-23 22:46:19.396026
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:46:29.930398
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:46:30.699408
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:46:32.145956
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert isinstance(t, DictUnpackingTransformer)

# Generated at 2022-06-23 22:46:37.808117
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.tree import parse_tree
    source = """
{1: 1, **dict_a}
"""
    expected = """
_py_backwards_merge_dicts([dict({1: 1})], dict_a)
"""
    tree = parse_tree(source)
    assert isinstance(tree, ast.Module)
    tree = DictUnpackingTransformer().visit(tree)
    assert isinstance(tree, ast.Module)
    result = astor.to_source(tree)
    assert result == expected



# Generated at 2022-06-23 22:46:39.619147
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert isinstance(t, DictUnpackingTransformer)

# Generated at 2022-06-23 22:46:45.725888
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert ast.dump(
        DictUnpackingTransformer().visit(
            ast.parse("{1: 1, **a}"))) == ast.dump(
            ast.parse("from functools import _py_backwards_merge_dicts\n"
                      "{\n    1: 1,\n    **_py_backwards_merge_dicts([], a)\n}"))



# Generated at 2022-06-23 22:46:53.731190
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{**{1:1}, 2:2}')
    DictUnpackingTransformer().visit(module)
    assert module.body[0].body[-1].value == ast.Call(
        ast.Name(id='_py_backwards_merge_dicts', ctx=ast.Load()),
        [ast.List(elts=[ast.Dict(keys=[ast.Num(1)], values=[ast.Num(1)]),
                        ast.Name(id='{1:1}', ctx=ast.Load())],
                  ctx=ast.Load())],
        [])

# Generated at 2022-06-23 22:47:03.000727
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import python_ta
    import astunparse
    from transformator.impl.dict_unpacking import DictUnpackingTransformer
    import ast

    transformer = DictUnpackingTransformer()
    python_ta.checkers.utils.register_checkers(python_ta.checkers.utils.get_global_checkers())
    python_ta.typecheck.register_typevar('Value')

    src = """
    {1: 1, **dict_a}
    """

    code = compile(src, '<test>', 'exec')
    tree = ast.parse(code)
    result = transformer.visit(tree)
    assert astunparse.unparse(result) == """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """



# Generated at 2022-06-23 22:47:14.110386
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse(r'''
{1: 1}
''')
    assert str(node) == r'''Module(body=[Dict(keys=[Num(n=1)], values=[Num(n=1)])])'''

    res = DictUnpackingTransformer().visit(node)

# Generated at 2022-06-23 22:47:15.267716
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:47:20.729305
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """{
        a: 1,
        **{},
        **b,
        c: 2,
        **{d: 22},
        **e,
        f: 3
    }"""
    expected = """_py_backwards_merge_dicts([{a: 1}, {c: 2}], {d: 22}, b, e, f=3)"""
    assert DictUnpackingTransformer(code=code).result == expected

# Generated at 2022-06-23 22:47:32.181374
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_subtree
    from ..utils.ast import get_ast, eval_ast
    from .. import ast_interpreter

    module = get_ast('''
        {1: 1, None: [{"a": 1}], 2: 2, None: {"b": 2}}
    ''')
    expected = get_ast('''
        _py_backwards_merge_dicts(
            [
                {1: 1, 2: 2}, 
                {"a": 1}, 
                {"b": 2}
            ]
        )
    ''')
    result = DictUnpackingTransformer().visit(module)
    assert_subtree(expected, result)

# Generated at 2022-06-23 22:47:37.603406
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from test_py2to3 import visit_and_assert
    from ..tests.utils import get_ast
    nodes = visit_and_assert(
        DictUnpackingTransformer,
        get_ast("{**a, 'key': 'value', **other, **dict_obj}"),
        '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{'key': 'value'}, a, other, dict_obj])
        '''
    )