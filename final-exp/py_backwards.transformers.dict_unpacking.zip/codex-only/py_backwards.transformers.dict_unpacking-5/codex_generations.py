

# Generated at 2022-06-23 22:37:37.513096
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    statement_list = ast.parse('{1:1}').body
    expected_statement_list = ast.parse(
        merge_dicts.get_body() + '{1:1}').body  # type: ignore

    transformer = DictUnpackingTransformer()
    statement_list = transformer.visit(statement_list)

    assert statement_list == expected_statement_list



# Generated at 2022-06-23 22:37:40.961110
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Tests method DictUnpackingTransformer.visit_Dict."""
    tree = ast.parse("""{1: a, 2: 'b', 3: {4: c, 5: d}, 'e': 7, **f}""")

# Generated at 2022-06-23 22:37:49.537617
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    c = DictUnpackingTransformer()

    def check(d, expected):
        node = ast.parse(d)
        c.visit(node)
        got = ast.dump(node)
        assert expected.strip() == got.strip()

    check('{None: 1}', '_py_backwards_merge_dicts((1,))')

    check('{None: 1, **None}', '_py_backwards_merge_dicts((1,), None)')

    check('{None: 1, **None, None: 2}',
          '_py_backwards_merge_dicts((1,), None, 2)')


# Generated at 2022-06-23 22:37:53.691398
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    f = ast.parse('''{1: 1, **{2: 2}}''').body[0]
    assert isinstance(f, ast.Expr)
    t = DictUnpackingTransformer()
    t.visit(f)
    assert isinstance(f.value, ast.Call)

# Generated at 2022-06-23 22:37:57.885146
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ast import Dict
    from astor import to_source
    transformer = DictUnpackingTransformer()
    assert to_source(transformer.visit(Dict(keys=[1, 2], values=[1, 2]))) == 'dict(((1, 1), (2, 2)))'

# Generated at 2022-06-23 22:38:06.877200
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    for code in [
            """
            # comment
            x = {1: 2, **dict_a}
            """,
            """
            # comment
            x = dict(1=2, **dict_a)
            """]:
        node = ast.parse(code)
        DictUnpackingTransformer().visit(node)
        assert node.body[1].value.func.id == '_py_backwards_merge_dicts'
        assert node.body[1].value.args[0].elts[0].keys == [ast.Num(1)]
        assert node.body[1].value.args[0].elts[1].id == 'dict_a'

# Generated at 2022-06-23 22:38:12.187231
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    # Base
    def test_case(dct):
        DictUnpackingTransformer().visit(ast.parse(dct))
        return ast.dump(ast.parse(dct), annotate_fields=False)

    assert test_case("{}") == "Module(body=[Dict(keys=[], values=[])])"
    assert test_case("{1: 2}") == "Module(body=[Dict(keys=[Num(n=1)], " \
                                  "values=[Num(n=2)])])"
    assert test_case("{1: 2, 3: 4}") == "Module(body=[Dict(keys=[Num(n=1), " \
                                        "Num(n=3)], values=[Num(n=2), " \
                                        "Num(n=4)])])"


# Generated at 2022-06-23 22:38:22.327512
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .transformers import Context
    from ..utils.source import source

    class DictUnpackingTransformerTest(DictUnpackingTransformer):
        def _split_by_None(self, pairs):
            return [(x,) if x is not None else y for x, y in pairs]
        def _prepare_splitted(self, splitted):
            return Splitted(x[0] if isinstance(x, list) else x for x in splitted)
        def _merge_dicts(self, xs):
            return Splitted(x for x in xs)

    node = ast.parse('{1: 2, 3: 4, 5: 6}')
    transformer = DictUnpackingTransformerTest(Context())
    result = transformer.visit(node)

# Generated at 2022-06-23 22:38:33.705429
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code_original: str = """
        

        a = {1: 1, **dict_a}
        
        

        b = {**dict_b}
    """
    refactored: str = "def _py_backwards_merge_dicts(dicts):\n\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n\na = _py_backwards_merge_dicts([{1: 1}], dict_a)\n\nb = dict(dict_b)"
    transformer = DictUnpackingTransformer()
    original_ast: ast.AST = ast.parse(code_original)
    refactored_ast: ast.AST = ast.parse(refactored)

# Generated at 2022-06-23 22:38:43.063601
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    def test_no_dict_unpacking():
        t = ast.parse("{1:1}")
        x = DictUnpackingTransformer()
        result = x.visit(t)
        assert isinstance(result, ast.Expression)
        assert isinstance(result.body, ast.Dict)

    def test_simple_dict_unpacking():
        t = ast.parse("{1:1, **{2:2}}")
        x = DictUnpackingTransformer()
        result = x.visit(t)
        expected = ast.parse("_py_backwards_merge_dicts([{1 : 1}], {2 : 2})")
        assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-23 22:38:51.867669
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse("""\
    def f(a):
        d = {1: 2}
        return {**d}
    """)
    res = ast.dump(DictUnpackingTransformer().visit(tree))

# Generated at 2022-06-23 22:38:53.379705
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), BaseNodeTransformer)



# Generated at 2022-06-23 22:38:56.292833
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    sample = """{1: 1, **a, 2: 2, **b, 3: 3, **c}"""

# Generated at 2022-06-23 22:39:07.345463
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..rewrite import RewriteImports
    from ..error import CompileError
    from ast_tools.rewrite import RewriteName
    t = DictUnpackingTransformer()
    tree = source('{1: 1, **dict_a}', '3.5').tree
    t.visit(tree)
    compiled = compile(tree, '<test>', 'eval')
    assert eval(compiled) == {1: 1, 9: 8}
    RewriteImports(3.5).visit(tree)
    RewriteName('dict_a', '{9: 8}').visit(tree)
    compiled = compile(tree, '<test>', 'eval')
    assert eval(compiled) == {1: 1, 9: 8}



# Generated at 2022-06-23 22:39:08.569312
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()



# Generated at 2022-06-23 22:39:14.158958
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    source = """
        x = {1: 2, 3: 4}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        x = {1: 2, 3: 4}
    """
    result = transformer.visit(ast.parse(source))
    assert transformer.tree_changed is False
    assert ast.dump(result) == expected



# Generated at 2022-06-23 22:39:23.907301
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    class _TestDictUnpackingTransformer(DictUnpackingTransformer):
        """Extends DictUnpackingTransformer with asserts."""
        def __init__(self):
            self._tree_changed = None
            self._original_tree = None

        def visit(self, node: ast.AST) -> ast.AST:
            self._original_tree = node
            result = super().visit(node)  # type: ignore
            assert self._tree_changed is not None
            return result

        def _split_by_None(self, pairs: Iterable[Pair]) -> Splitted:
            result = super()._split_by_None(pairs)  # type: ignore
            for group in result:
                if not isinstance(group, list):
                    assert isinstance(group, ast.expr)
            return result

       

# Generated at 2022-06-23 22:39:24.640758
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer

# Generated at 2022-06-23 22:39:29.059887
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from astor import to_source
    from .. import codegen  # noqa
    
    
    @snippet
    def module():
        {1: 1, **{'a': 2, 'b': 3}}
        

# Generated at 2022-06-23 22:39:39.047931
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    tr = DictUnpackingTransformer()

    def check(before, after=None):
        t = ast.AstGenerator()
        tree = t.parse(before)
        transformed = tr.visit(tree)

        if after is None:
            assert transformed is None
        else:
            assert after == t.to_source(transformed)

    check('''
        {'a': 'b'}
    ''')
    check('''
        {'a': 'b', **{}}
    ''')
    check('''
        {'a': 'b', **{'c': 'd'}, **{'e': 'f'}}
    ''')
    check('''
        {'a': 'b', **{'c': 'd'}, **{}}
    ''')
   

# Generated at 2022-06-23 22:39:43.509856
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_source = """
    1
    """
    expected_result = """
    1
    merge_dicts()
    """
    transformer = DictUnpackingTransformer()
    source = transformer.visit(ast.parse(test_source))
    result = ast.unparse(source)
    assert result == expected_result


# Generated at 2022-06-23 22:39:52.776723
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import textwrap
    from .test_generator import Example
    from .test_generator import tests_for_transformer

    text = textwrap.dedent("""
    def func():
        {1: 1, **dict_a}
        {1: 1, **dict_a, **dict_b}
    """)

    examples = [
        Example('def func():\n    _py_backwards_merge_dicts([{1: 1}], dict_a)\n    _py_backwards_merge_dicts([{1: 1}, dict_a], dict_b)\n', text),
    ]

    tests = tests_for_transformer(DictUnpackingTransformer, examples)

    for test in tests:
        transformer = test['transformer']
        examples = test['examples']


# Generated at 2022-06-23 22:39:53.955933
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert DictUnpackingTransformer.visit_Module.__name__ == "visit_Module"


# Generated at 2022-06-23 22:39:57.024266
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert repr(transformer.__repr__()) == "DictUnpackingTransformer"
    assert repr(transformer.__str__()) == "DictUnpackingTransformer"
    assert transformer._tree_changed == False
    assert transformer.target == (3, 4)


# Generated at 2022-06-23 22:40:02.926188
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node_ = ast.parse("""
        import this

        a = 1
        b = 2
        x = {
            a: b,
            **c,
            d: e,
            **f,
            g: h,
        }
        """)
    node = DictUnpackingTransformer().visit(node_)
    assert node == ast.parse("""
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        import this

        a = 1
        b = 2
        x = _py_backwards_merge_dicts([{a: b}, c, {d: e}, f, {g: h}])
        """)


# Generated at 2022-06-23 22:40:13.527974
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ast_toolbox.transformers import DictUnpackingTransformer
    from ast_toolbox.utils.testing import assert_equal_ast

    assert_equal_ast(
        """
{1: 1, **{a: 1}}
""", """
_py_backwards_merge_dicts([{1: 1}], dict_a})
""",
        transformers=[DictUnpackingTransformer])

    assert_equal_ast(
        """
{1: 1, 2: 2, 3: 3, **{a: 1}}
""", """
_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a})
""",
        transformers=[DictUnpackingTransformer])


# Generated at 2022-06-23 22:40:20.683872
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # type: () -> None
    from .utils import round_trip

    node = ast.parse('{1: 1, None: None}')
    assert isinstance(node.body[0].value, ast.Dict)
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1}], None)')
    assert isinstance(expected.body[0].value, ast.Call)
    transformed = DictUnpackingTransformer().visit(node)
    assert isinstance(transformed.body[0].value, ast.Call)
    assert round_trip(transformed) == round_trip(expected)


# Generated at 2022-06-23 22:40:21.332651
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor

# Generated at 2022-06-23 22:40:25.157683
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("{1: a, **b, **d, 0: c}")  # type: ast.Module
    transformer = DictUnpackingTransformer()
    out = transformer.visit(module)

# Generated at 2022-06-23 22:40:27.825540
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .fixtures.dict_unpacking import source, expected

    actual = DictUnpackingTransformer().visit(source)
    assert ast.dump(actual) == expected

# Generated at 2022-06-23 22:40:32.066163
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    input = '''{1, 2}'''
    input_ast = ast.parse(input)
    expected = '''\
{1, 2}'''
    expected_ast = ast.parse(expected)
    assert DictUnpackingTransformer().visit(input_ast) == expected_ast

# Generated at 2022-06-23 22:40:42.868398
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import compare_trees

    snippet = [
        ast.Dict(
            keys=[None, ast.Name(id='b'), None, None, ast.Name(id='e')],
            values=[
                ast.Dict(
                    keys=[ast.Name(id='a')],
                    values=[ast.Num(1)]),
                ast.Dict(
                    keys=[ast.Name(id='c')],
                    values=[ast.Num(2)]),
                dict(
                    keys=[ast.Name(id='d')],
                    values=[ast.Num(3)]),
                dict(
                    keys=[ast.Name(id='f')],
                    values=[ast.Name(id='x')]),
            ]),
    ]


# Generated at 2022-06-23 22:40:44.619667
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-23 22:40:46.115204
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None
    


# Generated at 2022-06-23 22:40:48.173837
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """Test constructor of class DictUnpackingTransformer."""
    x = DictUnpackingTransformer()


# Generated at 2022-06-23 22:40:55.497767
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    from typing import List

    source = '''{
        "a": 1,
        **kwargs,
        "b": 2,
    }'''
    expected = '''{
        "a": 1,
        "b": 2,
    }'''
    tree = ast.parse(source)

    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed is True
    assert astunparse.unparse(tree) == expected
    assert isinstance(tree.body[1], ast.Expr)
    assert isinstance(tree.body[1].value, ast.Call)

# Generated at 2022-06-23 22:40:56.739308
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = \
'''
{1: 2, 3: 4}
'''


# Generated at 2022-06-23 22:41:01.912336
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    input_value = ast.parse('''
        {1: 1, 2: 2, 3: 3, **{4: 4}, **{5: 5}, **{6: 6}}
    ''')

    expected = ast.parse('''
        _py_backwards_merge_dicts([
            {1: 1, 2: 2, 3: 3}, 
            {4: 4}, 
            {5: 5}, 
            {6: 6}
        ])
    ''')

    transformer = DictUnpackingTransformer()
    result = transformer.visit(input_value)

    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-23 22:41:08.286756
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.tree import parse_tree
    from . import unparse_ast_node

    source = '''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    '''
    tree = parse_tree(source)
    transformer = DictUnpackingTransformer()
    transformed = transformer.visit(tree)

    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b], {3: 3})
    '''
    assert unparse_ast_node(transformed) == expected

# Generated at 2022-06-23 22:41:18.457482
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    src = '''\
        {1: 1}
        
        {1: 1, **dict_a}
        
        {1: 1, **dict_a, **dict_b, 2: 2}
        
        {1: 1, 3: 3, **dict_a, **dict_b, 2: 2}
        
        {1: 1, 3: 4, **dict_a, 4: 5, **dict_b, 2: 2}
        '''

# Generated at 2022-06-23 22:41:20.812368
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast as _ast
    module = _ast.Module(
        body=[])

    assert DictUnpackingTransformer().visit(module) == _ast.Module(
        body=[merge_dicts.get_body()])


# Generated at 2022-06-23 22:41:26.810145
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    result = DictUnpackingTransformer().visit(
        ast.parse(dedent("""
            {1: 1, **dict_a}
        """)).body[0])

    expected = dedent("""
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)
    output = ast.unparse(result)
    assert output.lstrip() == expected.lstrip()

# Generated at 2022-06-23 22:41:36.682582
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class ModuleDict(Module):
        def visit(self, visitor):
            visitor.visit_Dict(self)

    class CallsDict(Module):
        x = 2

        def visit(self, visitor):
            visitor.visit_Call(self.x)

    class CallsDicts(Module):
        x = 2

        def visit(self, visitor):
            visitor.visit_Call(self.x)
            visitor.visit_Dict(self)

    class DictCalls(Module):
        x = 2

        def visit(self, visitor):
            visitor.visit_Dict(self)
            visitor.visit_Call(self.x)

    class DictCallsDicts(Module):
        x = 2


# Generated at 2022-06-23 22:41:44.715454
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_data = [
        '{1: 1, **dict_a}',
        '{1: 1, dict_a, dict_b}',
        '{1: 1, **dict_a, 2: 2, **dict_b}',
        '{1: 1, dict_a, dict_b, 2: 2, dict_c, dict_d}',
    ]

    for test in test_data:
        tree = parse(test)
        node = DictUnpackingTransformer().visit(tree)  # type: ignore
        expected_node = parse(test.replace('**', ''))
        assert mod_to_source(node) == mod_to_source(expected_node)


# Generated at 2022-06-23 22:41:45.942293
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), BaseNodeTransformer)


# Generated at 2022-06-23 22:41:46.866241
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None).target == (3, 4)



# Generated at 2022-06-23 22:41:53.182050
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import parse
    from typing import Any, Callable
    
    method = DictUnpackingTransformer.visit_Dict
    tr = DictUnpackingTransformer()
    

# Generated at 2022-06-23 22:41:58.531582
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import print_node

    # NOTE: ast.parse is not supported, because ast.List.ctx member is not able
    # to store Load value.
    #
    # Actual: Load
    # Expected: Store


# Generated at 2022-06-23 22:42:01.211803
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import UnitTestTransformer

    transformer = DictUnpackingTransformer(UnitTestTransformer())
    transformer.visit(ast.parse('x'))
    assert transformer._tree_changed == True

# Generated at 2022-06-23 22:42:02.177853
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:11.980550
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import compile_and_decompile
    from ..utils.synthesis import synthesize_ast
    from inspect import cleandoc

    class Dict(dict):
        def __missing__(self, key):
            return None

    for source in (
            '{1: 1, 2: 2, 3: 3, 4: 4, 5: 5}',
            '{1: 1, None: None, 3: 3}',
            '{1: 1, None: None, None: None, 3: 3, None: None}',
            '{None: None}'
    ):
        assert cleandoc(source) == compile_and_decompile(
            synthesize_ast(source, Dict()),
            DictUnpackingTransformer)

# Generated at 2022-06-23 22:42:21.962022
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..context import TransformationContext
    from ..transformer import Transformer

    input_code = '''{
        1: 1,
        **dict_a,
        2: "a",
        **dict_b,
        3: "b"
    }'''
    expected_code = '''{
        _py_backwards_merge_dicts(
            [{1: 1}, {2: "a"}, {3: "b"}],
            dict_a,
            dict_b
        )
    }'''

    result = Transformer(context=TransformationContext(target_version=(3, 4))).visit(
        ast.parse(input_code))

    assert ast.dump(result) == expected_code

    input_code = '''{
        1: 1
    }'''
    expected_code

# Generated at 2022-06-23 22:42:24.989448
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse("""{**a, **{*b}, c, **d}""", mode='eval')

    tree_changed, node = DictUnpackingTransformer().visit_and_replace(node)

    assert tree_changed
    assert ast.dump(node) == '_py_backwards_merge_dicts([{c: c}], a, (list(b))[0], d)'

# Generated at 2022-06-23 22:42:28.157685
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """\
dict_a = {'a': 1}
dict_b = {1: 2, **dict_a}
print(dict_a)
print(dict_b)
"""

# Generated at 2022-06-23 22:42:30.584172
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """{a: 1, **{b: 2}}"""

# Generated at 2022-06-23 22:42:31.650133
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:42:40.741534
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    src = """
        {a: a, **q, **w, **{a: a, **e}, b: b, **r}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{'a': a}, {'b': b}], q, w, {'a': a}, e, r)
    """
    check_transformation(DictUnpackingTransformer, expected, src)


# Generated at 2022-06-23 22:42:42.055432
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:42:49.784696
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as typed_ast
    from ast import parse
    from astunparse import unparse
    from ..utils import TreeMaker
    from ..tests.utils import get_node, compare_with_trees

    src = """
        {1: 1, (1, 2): [1, 2], **{1: 2}, 3: 3}
        """
    expected = """
        _py_backwards_merge_dicts([{1: 1, (1, 2): [1, 2], 3: 3}], {1: 2})
        """
    tree = parse(src)
    typed_tree = typed_ast.ast3.parse(unparse(tree))
    transformer = DictUnpackingTransformer()
    result = transformer.visit(typed_tree)
    result = unparse(result)
   

# Generated at 2022-06-23 22:42:53.090330
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = merge_dicts()
    tree = ast.parse(code)
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert tree.body[0].name == '_py_backwards_merge_dicts'
    assert tree.body[0].args.vararg == 'dicts'
    assert tree.body[0].args.defaults == []



# Generated at 2022-06-23 22:42:56.512975
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse

    body = parse('a=dict\n{1: 2, **a}').body  # type: ignore
    dict_node = body[1].value  # type: ignore

# Generated at 2022-06-23 22:43:00.511343
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import round_trip
    from .test_utils import render

    source = '{1: 1, 2: 2, **a, **b, **{1: 1}, 3: 3, **{4: 4}, 3: 3, 5: 5}'
    expected = '_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 5: 5}], a, b, ' \
               'dict({1: 1}), dict({4: 4}), 3)'

    assert rende

# Generated at 2022-06-23 22:43:10.755553
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..transformer import Transformer
    from .local_import import LocalImportTransformer
    from .inline_lambda import InlineLambdaTransformer
    from .sensitive_variables_renaming import SensitiveVariablesRenamingTransformer
    from ..optimization import RecursiveCallsOptimization
    import ast
    import logging
    
    node = ast.parse('''{1: 1, **{2: 2}}''')
    node = Transformer([
        LocalImportTransformer,
        InlineLambdaTransformer,
        SensitiveVariablesRenamingTransformer,
        RecursiveCallsOptimization,
        DictUnpackingTransformer,
    ], logger=logging.getLogger(__name__ + '.test_DictUnpackingTransformer_visit_Module'))(node)
    
    assert node.body

# Generated at 2022-06-23 22:43:18.529343
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    merge_dicts_func = \
        """def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result"""

    class_from_dict = \
        """@dataclass
        class Foo:
            value: int
            label: str
        return Foo(**{'value': 1, 'label': 1, **{'label': "label"}})"""

    source = \
        """@dataclass
        class Foo:
            value: int
            label: str"""

    expected = merge_dicts_func + "\n\n" + class_from_dict

    ast_tree = ast.parse(source)
    transformed = DictUnpackingTransformer().visit(ast_tree)
    assert expected

# Generated at 2022-06-23 22:43:24.328573
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import transform

    assert_equal(
        """
        def f():
            pass
        """,
        transform("""
        def f():
            pass
        """, [DictUnpackingTransformer]
        ))

    assert_equal(
        """
        _py_backwards_merge_dicts([dict([('a', 1)])], dict_a)
        """,
        transform("""
        {'a': 1, **dict_a}
        """, [DictUnpackingTransformer]
        ))

# Generated at 2022-06-23 22:43:25.833620
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None)

# Generated at 2022-06-23 22:43:26.517565
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-23 22:43:32.098110
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    methods = (
        '_split_by_None',
        '_prepare_splitted',
        '_merge_dicts',
    )
    for name in methods:
        method = getattr(DictUnpackingTransformer, name)
        method = getattr(DictUnpackingTransformer(), name)
        method  # type: ignore


__all__ = ('DictUnpackingTransformer',)

# Generated at 2022-06-23 22:43:33.177453
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():  # type: ignore
    DictUnpackingTransformer()

# Generated at 2022-06-23 22:43:42.573394
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .minify import UnusedAliasesRemover
    from .unzip_unpacking import UnzipUnpackingTransformer
    from ..snippets import dict_unpacking

    transformer = DictUnpackingTransformer()
    src = dict_unpacking.get_source()
    node = ast.parse(src)
    node = UnusedAliasesRemover().visit(node)
    node = UnzipUnpackingTransformer().visit(node)
    node = transformer.visit(node)
    src_ = dict_unpacking.get_source()
    node_ = ast.parse(src_)
    node_ = UnusedAliasesRemover().visit(node_)
    node_ = UnzipUnpackingTransformer().visit(node_)
    assert ast.dump(node) == ast.dump(node_)

# Generated at 2022-06-23 22:43:53.774335
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def do_test(code, expected):
        transformed = DictUnpackingTransformer.run_test(code)
        assert transformed == expected

    do_test('{1: 1, **dict_a}', '_py_backwards_merge_dicts([{1: 1}], dict_a)')
    do_test('{**dict_a}', '_py_backwards_merge_dicts([{}], dict_a)')
    do_test('{**{**dict_a}}', '_py_backwards_merge_dicts([{}], dict_a)')
    do_test('{**{**dict_a, **dict_b}}',
            '_py_backwards_merge_dicts([{}], dict_a, dict_b)')

# Generated at 2022-06-23 22:43:54.993125
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-23 22:43:58.489943
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.python import code_to_ast, ast_to_code

    ast_before = """{1: 1, **dict_a}"""

# Generated at 2022-06-23 22:43:59.125211
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer is not None

# Generated at 2022-06-23 22:44:07.356714
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # pylint: disable=unused-variable

    class _DictUnpackingTransformer(DictUnpackingTransformer):
        def generic_visit(self, node):
            return node

    @snippet
    def test_split_by_None():
        pairs = ((1, 2), (3, 4), (5, 6), (None, 7), (8, 9), (None, 10))
        s = _DictUnpackingTransformer()
        splitted = s._split_by_None(pairs)
        return splitted

    @snippet
    def test_prepare_splitted():
        splitted = ((1, 2), (3, 4), (5, 6), 7, 8, 9, 10)
        s = _DictUnpackingTransformer()

# Generated at 2022-06-23 22:44:09.464385
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    program = merge_dicts.dump_ast()
    DictUnpackingTransformer.run_opt(program, 'merge_dicts')
    assert program == merge_dicts.dump_ast()


# Generated at 2022-06-23 22:44:19.979382
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert compile(
        '{1: 1, **dict_a}',
        'test',
        'eval') == _py_backwards_merge_dicts([{1: 1}], dict_a)

    assert compile(
        '{1: 1, **dict_a, 2: 2}',
        'test',
        'eval') == _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)

    assert compile(
        '{1: 1, **dict_a, 2: 2, **dict_b}',
        'test',
        'eval') == _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)

# Generated at 2022-06-23 22:44:21.194491
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 22:44:23.839523
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('''{1: 1, **dict_a, 2: 2}''')
    tree2 = DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 22:44:29.670556
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from asttokens import ASTTokens

    source = """{1: 1, **dict_a}"""
    expected = """{2: 2, **{1: 1}}"""

    ast_ = ASTTokens(expected, parse=True).tree
    returned = DictUnpackingTransformer().visit(
        ASTTokens(source, parse=True).tree)
    assert ast.dump(ast_) == ast.dump(returned)

# Generated at 2022-06-23 22:44:35.452684
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import parse_snippet
    from ..utils.visitor import NodeVisitor

    visitor = NodeVisitor()
    visitor.add_transformer(DictUnpackingTransformer)
    visitor.visit(parse_snippet('{1: 1, **dict_a}'))

    body = merge_dicts.get_body()  # type: ignore
    assert body in visitor.imports



# Generated at 2022-06-23 22:44:43.025643
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Test for dict without unpacking
    assert DictUnpackingTransformer().visit(ast.parse('{1: 2}')).body[0].value == ast.parse('{1: 2}').body[0].value

    # Test for dict with unpacking
    assert DictUnpackingTransformer().visit(ast.parse('{1: 2, **dict_a}')).body[0].value == ast.parse(
        '_py_backwards_merge_dicts([dict(1=2)], dict_a)').body[0].value

    # Test for dict with unpacking and another key, value

# Generated at 2022-06-23 22:44:50.296555
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    
    src = '{1: 1, **{}}'
    regex = r'^(_py_backwards_merge_dicts\(\[{1: 1}, \{\}\]\))$'
    
    result = DictUnpackingTransformer().visit(ast.parse(src))
    

# Generated at 2022-06-23 22:44:51.128617
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer

# Generated at 2022-06-23 22:44:54.703289
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('{a: a, b: b, **c}')
    transformed = DictUnpackingTransformer().visit(node)

# Generated at 2022-06-23 22:45:02.731249
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = dedent('''
        def func(a, b, c, d):
            return {1: a, 2: b, **c, 3: d}''')
    expected = dedent('''
        def func(a, b, c, d):
            return _py_backwards_merge_dicts([{1: a, 2: b}], c, {3: d})''')

    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)

    assert ast.dump(tree, include_attributes=False) == expected

# Generated at 2022-06-23 22:45:04.979013
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    t = DictUnpackingTransformer()
    d = ast.parse("""{1: 1, **a, 2: 2}""", mode='eval')
    assert ast.dump(d) == ast.dump(t.visit(d))

# Generated at 2022-06-23 22:45:09.097245
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = 'd = {1: 1, **dict_a}'
    expected = """
        _py_backwards_merge_dicts([{1: 1}, dict_a])
    """
    result = transform(code, DictUnpackingTransformer)
    assert result.strip() == expected.strip()

# Generated at 2022-06-23 22:45:19.489988
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    node = ast.parse("{1: 1, **{2: 2}, 3: 3, *{'a': 'b'}, 4: 4}")
    transformer.visit(node)
    assert "".join(transformer.output) == (
        "\ndef _py_backwards_merge_dicts(dicts):\n"
        "    result = {}\n"
        "    for dict_ in dicts:\n"
        "        result.update(dict_)\n"
        "    return result\n\n"
        "_py_backwards_merge_dicts(["
        "{1: 1}, {2: 2}, {3: 3}, {'b', 'a'}, {4: 4}])")


# Generated at 2022-06-23 22:45:29.854921
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import sys, types
    import astor
    import astunparse
    import ast
    import asttokens

    t = asttokens.ASTTokens(astor.to_source(DictUnpackingTransformer), parse=True)
    t.fix_missing_locations()

    defs = [node.value for node in t.tree.body if isinstance(node, ast.Assign)]

    assert len(defs) == 1
    assert isinstance(defs[0], ast.FunctionDef)

    args, body = defs[0].args, defs[0].body
    assert len(args.args) == 2
    assert str(args.args[0]) == "self"
    assert str(args.args[1]) == "node"
    assert str(args.defaults) == "()"

# Generated at 2022-06-23 22:45:39.899751
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from textwrap import dedent
    from hypothesis import given
    from hypothesis.strategies import lists, tuples, one_of, none, characters
    from ..element_of_program.var_name import var_name_strategy

    def dict_strategy() -> ast.Dict:
        return ast.Dict(
            keys=lists(one_of(characters(blacklist_categories=['Cs']),
                              var_name_strategy),
                       max_size=100),
            values=lists(tuples(none(),
                                var_name_strategy),
                        max_size=100))


# Generated at 2022-06-23 22:45:43.978380
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..tool import transform
    from .fixtures import DICT_UNPACKING_TRANSFORMER

    source = '''
        {1: None, **dict_a, 2: 'b', **dict_b, 3: 'c'}
    '''
    result = '''
        _py_backwards_merge_dicts([{1: None, 2: 'b'}], dict_a, {3: 'c'}, dict_b)
    '''
    assert transform(DictUnpackingTransformer, source) == result

# Generated at 2022-06-23 22:45:48.532523
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import ast2tree
    from ..utils.visitor import AstPrintVisitor

    # FIXME: Add test cases
    case1 = ast.parse(
        '{1: 1, **dict_a}')
    expected_case1 = ast.parse(
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')

    case2 = ast.parse(
        '{1: 1, **dict_a, 2: 2, **dict_b}')
    expected_case2 = ast.parse(
        '_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)')


# Generated at 2022-06-23 22:45:56.455041
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from semargl.utils import tree as T
    from ..utils.compiler import compile_ast, loads
    from ..utils.snippet import snippet_location

    src = snippet_location(T.source).format(T.target)
    src += '{A: 1, **b, **c, **d}'
    ctx = loads(src) @ compile_ast
    result = ctx.transform(DictUnpackingTransformer)
    expected = '_py_backwards_merge_dicts([[(A, 1)]], b, c, d)'
    assert expected == T.source.format(result.body[-1].value)

# Generated at 2022-06-23 22:46:06.238761
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    '''
    Visit an AST node of type Dict.
    '''
    from ..unparser import Unparser
    from ..tokenize import generate_tokens, untokenize, ENDMARKER, NAME, OP

    test_code = '''\
{1: 1, **a}
'''
    expected_code = '''\
_py_backwards_merge_dicts([{1: 1}], a)
'''
    node = ast.parse(test_code)
    expected_node = ast.parse(expected_code) # type: ignore

    DictUnpackingTransformer().visit(node)

    unparser = Unparser(node)
    code = untokenize(generate_tokens(unparser.visit))

    unparser = Unparser(expected_node)

# Generated at 2022-06-23 22:46:12.124165
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from test.transpile_test import expect_correct_transpilation

    expect_correct_transpilation(
        """
        {1: 1, **dict_a}
        """,
        """
        from ..utils import _py_backwards_merge_dicts
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """)

# Generated at 2022-06-23 22:46:20.780228
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import unittest
    import astor

    class TestDictUnpackingTransformer(unittest.TestCase):
        def _transformer(self, source: str) -> ast.Module:
            tree = ast.parse(source)
            transformer = DictUnpackingTransformer()
            new_tree = transformer.visit(tree)
            return new_tree

        def _to_source(self, new_tree: ast.Module) -> str:
            return astor.to_source(new_tree)

        def test_simple(self):
            tree = self._transformer("""
            def f():
                return {'x': 1, 'y': 2, **d}
            """)
            source = self._to_source(tree)

# Generated at 2022-06-23 22:46:31.168862
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..__pkginfo__ import version
    from astunparse import unparse
    from ast import parse

    # Given
    code = """
        dict_ = dict(a=1)
        dict_2 = dict(b=2)
        dict_3 = dict(c=3)
        dict_4 = dict(d=4)
        
        {**dict_, 1: 1}
        {'one': 1, **dict_, 'two': 2}
        {1: 1, **dict_2, 2: 2, 3: 3, **dict_3}
        {1: 1, 2: 2, **dict_4, **dict_2}
        {1: 1, **dict_, **dict_3, **dict_2, 0: 0}
    """

# Generated at 2022-06-23 22:46:36.545274
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    node = ast.parse("""{1: 1, 2: 2, None: 3, 4: 4, None: 5, 6: 6}""")
    result = astor.to_source(DictUnpackingTransformer().visit(node))
    expected = """_py_backwards_merge_dicts(
    [dict({1: 1, 2: 2}), 3, dict({4: 4}), 5, dict({6: 6})],
)"""
    assert result == expected

# Generated at 2022-06-23 22:46:40.567734
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Tests method visit_Module of class DictUnpackingTransformer."""
    # import demo
    import os
    filename = os.path.join(os.path.dirname(__file__),
                            'demos', 'demo_dict.py')
    code = open(filename).read()
    tree = ast.parse(code)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    print(code)


# Generated at 2022-06-23 22:46:49.183392
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import tree
    from ..utils.source_transform import transform_source

    source = '''
        foo = {1: 1, 2: 2, **bar}
        baz = {"a": foo[1]}
        '''
    expected = '''
        foo = _py_backwards_merge_dicts([{1: 1, 2: 2}, bar})
        baz = {"a": foo[1]}
        '''
    result = transform_source(source, DictUnpackingTransformer)
    assert expected == result
    assert expected == tree(result).get_string()



# Generated at 2022-06-23 22:46:59.505753
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textx.scoping.providers import PlainName, FQN
    from ..lang import Python
    from .base import NodeTransformer

    lang = Python.lang_dict(name_registration=FQN, name_provider=PlainName)

    def to_ast(code: str) -> ast.AST:
        return lang.parser.parse(code)

    def transformer_factory(transformer_cls: NodeTransformer) -> callable:
        """For each test creates new transformer instance."""
        def transformer(code: str):
            tree = to_ast(code)
            transformer_cls().visit(tree)
            return tree

        return transformer


    def test(before: str, after: str):
        """Helper for writing test cases.
        It uses context manager for logging transformed tree.
        """


# Generated at 2022-06-23 22:47:10.861003
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''
        {1: 2, 3: 4, **foo}
        {1: 2, 3: 4, **foo, **bar, 5: 6}
        {1: 2, 3: 4, **foo, 4: 5, **bar, 5: 6}
        '''
    expected = '''
        _py_backwards_merge_dicts([{1: 2, 3: 4}], foo)
        _py_backwards_merge_dicts([{1: 2, 3: 4}], foo, bar, {5: 6})
        _py_backwards_merge_dicts([{1: 2, 3: 4}, {4: 5}], foo, bar, {5: 6})
        '''
    actual = DictUnpackingTransformer().transform_source(source)

# Generated at 2022-06-23 22:47:11.659729
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-23 22:47:17.549545
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import to_source

    source = to_source({1: 1, 2: 2, **{3: 3, 4: 4}})
    assert source == '_py_backwards_merge_dicts([{1: 1, 2: 2}], {3: 3, 4: 4})'

# Generated at 2022-06-23 22:47:18.815915
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)

# Generated at 2022-06-23 22:47:27.522533
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_source_equal

    tree = ast.parse("""
        a = {a: 1, **b, *c, **d, e: 3}
    """)

    result = DictUnpackingTransformer().visit(tree)
    assert_equal_ast(
        result,
        ast.parse("""
        _py_backwards_merge_dicts([dict({'e': 3})], a, b, c, d, {'a': 1})
    """)
    )

    assert_source_equal(
        result,
        """
        _py_backwards_merge_dicts([dict({'e': 3})], a, b, c, d, {'a': 1})
    """
    )

# Generated at 2022-06-23 22:47:27.963008
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-23 22:47:36.395001
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """Unit test of constructor of class DictUnpackingTransformer."""
    try:
        import astunparse
    except ImportError:
        print("Unable to import the astunparse module.")
        return

    # pylint: disable=unsubscriptable-object
    input_code = ast.parse("""
        d = {1: 2, **kwargs}
    """)
    expected_code = ast.parse("""
        d = _py_backwards_merge_dicts([{1: 2}], kwargs)
    """)
    # pylint: enable=unsubscriptable-object

    unparser = astunparse.Unparser(input_code)
    input_code_str = unparser.unparse().replace("\n", "")
