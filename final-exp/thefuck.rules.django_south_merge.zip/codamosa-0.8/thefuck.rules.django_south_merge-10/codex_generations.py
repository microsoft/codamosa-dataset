

# Generated at 2022-06-12 11:18:47.465347
# Unit test for function match
def test_match():
    command1 = Command('manage.py migrate', '', '--merge: will just attempt the migration')
    command2 = Command('manage.py asdf', '')

    assert not match(command2)
    assert match(command1)



# Generated at 2022-06-12 11:18:50.122308
# Unit test for function match
def test_match():
    assert True == match(Example(SCRIPT, OUTPUT))
    assert False == match(Example(SCRIPT2, OUTPUT))
    assert False == match(Example(SCRIPT, OUTPUT2))



# Generated at 2022-06-12 11:18:52.571106
# Unit test for function match
def test_match():
    assert match(Command('manage.py migrate --fake_args'))
    assert not match(Command('manage.py migrate'))
    assert not match(Command('manage.py fake_command'))



# Generated at 2022-06-12 11:18:58.934888
# Unit test for function match

# Generated at 2022-06-12 11:19:03.400966
# Unit test for function match
def test_match():
    assert match(MockCommand(script='./manage.py', output='migrate --merge: will just attempt the migration'))
    assert not match(MockCommand(script='./manage.py', output='makesmigrations'))


# Generated at 2022-06-12 11:19:05.837049
# Unit test for function match
def test_match():
    command = Command('/usr/bin/python manage.py migrate --merge: will just attempt the migration')
    assert(match(command) is True)



# Generated at 2022-06-12 11:19:13.859017
# Unit test for function match
def test_match():
    assert match(Command('/usr/bin/python manage.py migrate'))
    assert match(Command('python manage.py migrate'))
    assert match(Command('python manage.py migrate foo'))
    assert match(Command('python manage.py migrate foo bar'))
    assert match(Command('python manage.py migrate foo bar --merge: will just attempt the migration'))
    assert not match(Command('/usr/bin/python manage.py migrate foo bar --merge: will just attempt the migration',
                             '/dev/null'))
    assert not match(Command('/usr/bin/python manage.py'))
    assert not match(Command('python'))
    assert not match(Command('python manage.py migrate --merge: will just attempt the migration'))


# Generated at 2022-06-12 11:19:24.115203
# Unit test for function match

# Generated at 2022-06-12 11:19:33.084603
# Unit test for function match
def test_match():
    # No match
    command = Command(script='python3 manage.py test', output='Ran 3 tests in 2.000s\nOK')
    assert not match(command)

    command = Command(script='/data/projects/venv/bin/python manage.py runserver', output='Quit the server with CONTROL-C.')
    assert not match(command)

    command = Command(script='python3 manage.py migrate 0002_add_test_model', output='Operations to perform:\n  Apply all migrations: 0002_add_test_model')
    assert not match(command)

    # Match
    command = Command(script='python3 manage.py migrate', output='Operations to perform:\n  Apply all migrations: 0002_add_test_model')
    assert match(command)


# Generated at 2022-06-12 11:19:34.610437
# Unit test for function match
def test_match():
    assert match(Command('manage.py migrate', ''))
    assert not match(Command('manage.py makemigrations', ''))

# Generated at 2022-06-12 11:19:39.934444
# Unit test for function match
def test_match():
    assert True == match(Command('manage.py migrate --database="default" --fake-initial --noinput --merge'))
    assert False == match(Command('manage.py migrate --database="default" --fake-initial --noinput'))
    assert False == match(Command('manage.py makemigrations'))



# Generated at 2022-06-12 11:19:46.991288
# Unit test for function match
def test_match():
    assert match(Command('python manage.py migrate --merge: will just attempt the migration'))
    assert match(Command('python manage.py migrate --merge'))
    assert match(Command('python manage.py migrate --merge; will just attempt the migration'))
    assert match(Command('python manage.py migrate --merge; will just attempt the migration'))
    assert match(Command('python manage.py migrate --merge=will just attempt the migration'))

    assert not match(Command('python manage.py migrate'))
    assert not match(Command('python manage.py --merge migrate'))



# Generated at 2022-06-12 11:19:51.250323
# Unit test for function match
def test_match():
    assert match(Command(script='python manage.py migrate',
                         output='--merge: will just attempt the migration'))
    assert not match(Command(script='python manage.py migrate',
                             output='--merge: will just attempt the migration'))
    assert not match(Command(script='python manage.py',
                             output='--merge: will just attempt the migration'))
    assert not match(Command(script='python manage.py migrate',
                             output='--migrate: will just attempt the migration'))



# Generated at 2022-06-12 11:20:01.261656
# Unit test for function match
def test_match():
    assert match(Command('manage.py migrate --merge: will just attempt the migration', '', '', 0, None))
    assert match(Command('python manage.py migrate --merge: will just attempt the migration', '', '', 0, None))
    assert match(Command('/usr/bin/python manage.py migrate --merge: will just attempt the migration', '', '',
                         0, None))
    assert match(Command('python3 manage.py migrate --merge: will just attempt the migration', '', '',
                         0, None))
    assert match(Command('/usr/bin/python3 manage.py migrate --merge: will just attempt the migration', '', '',
                         0, None))

# Generated at 2022-06-12 11:20:05.104095
# Unit test for function match
def test_match():
    assert match(Command('manage.py migrate --merge'))
    assert not match(Command('manage.py migrate --noinput'))
    assert not match(Command('manage.py migrate --fake'))
    assert match(Command('python manage.py migrate --merge'))



# Generated at 2022-06-12 11:20:14.414837
# Unit test for function match
def test_match():
    # match('manage.py migrate', '--merge: will just attempt the migration')
    assert match(FakeCommand('manage.py migrate',
                             'Migrating '
                             '--merge: will just attempt the migration'))
    assert match(FakeCommand('manage.py migrate',
                             '--merge: will just attempt the migration'
                             'Migrating'))
    assert match(FakeCommand('manage.py migrate',
                             '--merge: will just attempt the migration'
                             'Migrating'))
    assert match(FakeCommand('manage.py migrate',
                             'Migrating'
                             '--merge: will just attempt the migration'))

# Generated at 2022-06-12 11:20:21.194240
# Unit test for function match
def test_match():
    # Positive match (1): match
    command = Command('manage.py migrate')
    assert match(command) == True
    command = Command('python manage.py migrate')
    assert match(command) == True
    command = Command('/usr/bin/python manage.py migrate')
    assert match(command) == True
    command = Command('/usr/bin/python3 manage.py migrate')
    assert match(command) == True
    command = Command('rm -rf ./* && python3 manage.py migrate --merge')
    assert match(command) == True
    command = Command('rm -rf ./* && manage.py migrate --merge')
    assert match(command) == True
    command = Command('python3 manage.py migrate --merge && exit')
    assert match(command) == True

    # Negative match (1): no

# Generated at 2022-06-12 11:20:24.415391
# Unit test for function match
def test_match():
    assert match(Command(script="python manage.py migrate app1"))
    assert not match(Command(script="python manage.py migrate app2"))



# Generated at 2022-06-12 11:20:29.161090
# Unit test for function match
def test_match():
    assert match(Command(script='manage.py migrate'))
    assert match(Command(script='manage.py migrate --merge'))
    assert match(Command(script='manage.py migrate --merge'))
    assert not match(Command(script='manage.py makemigrations'))
    assert not match(Command(script='manage.py makemigrations foo'))
    assert not match(Command(script='django-admin.py migrate --merge'))



# Generated at 2022-06-12 11:20:32.033658
# Unit test for function match
def test_match():
    assert match(Command('python manage.py migrate'))
    assert match(Command('python manage.py migrate --merge'))
    assert not match(Command('python manage.py'))


# Generated at 2022-06-12 11:20:43.497161
# Unit test for function match
def test_match():
    assert True == match(Command('python manage.py migrate', '', '\n Nothing to merge.\n'))
    assert True == match(Command('python manage.py migrate', '', '\n --merge: will just attempt the migration\n'))
    assert False == match(Command('python manage.py migrate', '', ''))
    assert False == match(Command('python manage.py migrate', '', '\n--merge: will just attempt the migration\n'))
    assert False == match(Command('python manage.py migrate', '', '\n --merge: will just attempt the migration \n '))
    assert False == match(Command('python manage.py migrate', '', '\n --merge: will just attempt the migration\n '))

# Generated at 2022-06-12 11:20:46.191904
# Unit test for function match
def test_match():
    assert match("manage.py migrate --merge")
    assert not match("manage.py migrate")
    assert not match("manage.py makemigrations")
    assert not match("manage.py shell")

# Generated at 2022-06-12 11:20:55.789911
# Unit test for function match
def test_match():
    assert match(Command(script='dance.py')) is False
    assert match(Command(script='dance.py', output='no --merge option')) is False
    assert match(Command(script='manage.py dance.py', output='will just attempt the migration')) is False
    assert match(Command(script='manage.py migrate', output='will just attempt the migration')) is False
    assert match(Command(script='manage.py migrate', output='--merge: will just attempt the migration')) is True
    assert match(Command(script='manage.py migrate --no-input', output='--merge: will just attempt the migration')) is True
    assert match(Command(script='python manage.py migrate', output='--merge: will just attempt the migration')) is True


# Generated at 2022-06-12 11:20:58.034768
# Unit test for function match
def test_match():
    command = Command('/usr/bin/manage.py migrate --merge: will just attempt the migration')
    assert match(command) == True


# Generated at 2022-06-12 11:21:07.360570
# Unit test for function match

# Generated at 2022-06-12 11:21:15.898061
# Unit test for function match
def test_match():
    command = Command('manage.py migrate --merge',
                      'Django will now attempt to apply the migration by '
                      'creating a model that represents the new migration, '
                      'and then creating a new migration that represents the '
                      'original state. If you would rather apply the migration '
                      'automatically without creating a merge migration, use '
                      '--merge. Note that if you use --merge, the migration will '
                      'be automatically applied next time you run migrate (unless '
                      'you specify --fake).\n')
    assert match(command)



# Generated at 2022-06-12 11:21:20.409613
# Unit test for function match
def test_match():
    # Valid test
    command = Command('/usr/bin/python manage.py migrate --merge: will just attempt the migration', '')
    assert match(command)

    # Invalid type
    command = Command(None, None)
    assert not match(command)

    # Invalid script
    command = Command('ls', '')
    assert not match(command)

    # Valid script, invalid output
    command = Command('/usr/bin/python manage.py migrate', '')
    assert not match(command)


# Generated at 2022-06-12 11:21:27.988325
# Unit test for function match
def test_match():
    command = Command()
    command.script = 'manage.py migrate'
    command.output = '--merge: will just attempt the migration'
    assert match(command) == True

    command.script = 'python manage.py migrate'
    assert match(command) == True

    command.output = '--merge: will just attempt the merge'
    assert match(command) == False

    command.script = 'python manage.py migrate'
    command.output = '--merge: will just attempt the migration'
    assert match(command) == True

    command.script = '/usr/lib/python manage.py migrate'
    assert match(command) == False

    command.script = 'python manage.py migrate'
    assert match(command) == True

    command.script = 'python manage.py mig'

# Generated at 2022-06-12 11:21:35.748702
# Unit test for function match
def test_match():
    # test 1 - the good case
    the_shell_command = shell.ShellCommand('./manage.py migrate', output='ok\n--merge: will just attempt the migration')
    assert match(the_shell_command)

    # test 2 - no migrate
    the_shell_command = shell.ShellCommand('./manage.py notmigrate', output='ok\n--merge: will just attempt the migration')
    assert not match(the_shell_command)

    # test 3 - no manage.py
    the_shell_command = shell.ShellCommand('python manage.py migrate', output='ok\n--merge: will just attempt the migration')
    assert not match(the_shell_command)

    # test 4 - empty output

# Generated at 2022-06-12 11:21:39.293600
# Unit test for function match
def test_match():
    command = Command(script='manage.py migrate')
    assert match(command) is False

    command = Command(script='manage.py migrate',
                      output='--merge: will just attempt the migration')
    assert match(command) is True



# Generated at 2022-06-12 11:21:50.558502
# Unit test for function match
def test_match():
    from os.path import abspath, dirname, join

    def create_command(script, output):
        script_path = join(dirname(abspath(__file__)), 'scripts', script)
        return Command(script=script_path, output=output)

    assert match(create_command('manage.py',
                                'command does not support migration'))
    assert match(create_command('manage.py', '--merge: will just attempt the migration'))
    assert not match(create_command('manage.py',
                                    '--merge: merge migrations instead of generating them'))
    assert not match(create_command('manage.py',
                                    'another command does not support migration'))
    assert not match(create_command('script.py',
                                    'command does not support migration'))


# Generated at 2022-06-12 11:21:57.578014
# Unit test for function match
def test_match():
    assert match(Command('python manage.py migrate',
                        'You are trying to add a non-nullable field',
                        False))
    assert not match(Command('python manage.py',
                             'You are trying to add a non-nullable field',
                             False))
    assert match(Command('python manage.py migrate',
                         '--merge: will just attempt the migration',
                         True))
    assert match(Command('python manage.py migrate',
                         '--merge: will just attempt the migration',
                         False))


# Generated at 2022-06-12 11:22:01.829318
# Unit test for function match
def test_match():
    assert match(Command('', '', '')) is False
    assert match(Command('manage.py', '', '')) is False
    assert match(Command('manage.py migrate', '', '')) is False
    assert match(Command('manage.py migrate', '', '--merge: will just attempt the migration')) is True



# Generated at 2022-06-12 11:22:10.284761
# Unit test for function match
def test_match():
    assert match(Command('', 'python manage.py --help', 'manage.py\tmigrate\t# Migrations: Synchronize unmigrated apps, make migrations for changed models\n'))
    assert match(Command('', 'python manage.py migrate/app --help', 'manage.py\tmigrate\t# Migrations: Synchronize unmigrated apps, make migrations for changed models\n'))
    assert not match(Command('', 'python manage.py --help', 'manage.py\tnew\t# Migrations: Synchronize unmigrated apps, make migrations for changed models\n'))


# Generated at 2022-06-12 11:22:12.904681
# Unit test for function match
def test_match():
    assert match(Command('python manage.py migrate'))
    assert match(Command('python manage.py migrate --fake'))
    assert not match(Command('python manage.py syncdb'))



# Generated at 2022-06-12 11:22:17.789264
# Unit test for function match
def test_match():
    # Test where the function should not match
    assert not match(Command('manage.py', '', ''))

    # Test where the function should match
    command = Command('manage.py', 'migrate', '\nLorem --merge: will just attempt the migration')
    assert match(command)



# Generated at 2022-06-12 11:22:21.947898
# Unit test for function match
def test_match():
    assert match(MockCommand(script='manage.py migrate',
                             output='--fake: this is not a merge conflict')) is False
    assert match(MockCommand(script='manage.py migrate',
                             output='--merge: will just attempt the migration')) is True



# Generated at 2022-06-12 11:22:28.608264
# Unit test for function match
def test_match():
    assert match(Command('python manage.py migrate', '', '--merge: will just attempt the migration'))
    assert match(Command('python manage.py migrate', '', '--merge'))
    assert not match(Command('python manage.py migrate', '', ''))
    assert not match(Command('python manage.py migrate', '', 'python manage.py migrate'))



# Generated at 2022-06-12 11:22:31.276941
# Unit test for function match
def test_match():
    command = Command()
    command.script = 'manage.py migrate'
    command.output = '--merge: will just attempt the migration'
    assert match(command)


# Generated at 2022-06-12 11:22:35.628332
# Unit test for function match
def test_match():
    assert match(Command('python manage.py migrate --merge: will just attempt the migration', ''))
    assert match(Command('python manage.py migrate --merge --fake-initial: will just attempt the migration', ''))
    assert not match(Command('python manage.py migrate', ''))
    assert not match(Command('python manage.py migrate', 'error'))
    assert not match(Command('python manage.py migrate --fake-initial', ''))

# Generated at 2022-06-12 11:22:44.321495
# Unit test for function match
def test_match():
    assert match('./manage.py migrate --help')
    assert match('./manage.py migrate')
    assert not match('./manage.py migrate --all')
    assert not match('./manage.py migrate --all --fake')

# Generated at 2022-06-12 11:22:49.233937
# Unit test for function match
def test_match():
    assert (match(Command('manage.py migrate --merge',
                          '',
                          'django.core.management.commands.migrate.CommandError: Your models have changes that are not yet reflected in a migration, and so won\'t be applied.')))

    assert not match(Command('manage.py migrate',
                             '',
                             ''))

    assert not match(Command(''))


# Generated at 2022-06-12 11:22:53.918536
# Unit test for function match
def test_match():
    assert match(Command('manage.py', 'manage.py migrate --merge: will just attempt the migration'))
    assert not match(Command('manage.py', 'manage.py migrateup'))
    assert not match(Command('manage.py', 'manage.py migrate --merge'))



# Generated at 2022-06-12 11:23:04.173962
# Unit test for function match
def test_match():
    assert match(Command('python manage.py db migrate'))
    assert match(Command('python manage.py db migrate;'))
    assert match(Command('python manage.py db migrate && python manage.py run'))
    assert match(Command('python manage.py db migrate '))
    assert match(Command('python manage.py db migrate: '))
    assert match(Command('python manage.py db migrate : '))
    assert match(Command('python manage.py db migrate -n '))
    assert match(Command('python manage.py db migrate --merge: will just attempt the migration'))
    assert match(Command('python manage.py db migrate && --merge'))
    assert match(Command('python manage.py db migrate && --merge --merge: will just attempt the migration'))

# Generated at 2022-06-12 11:23:07.654146
# Unit test for function match
def test_match():
    assert match(Command('python manage.py migrate'))
    assert match(Command('cd /vagrant/ && python manage.py migrate'))
    assert match(Command('/usr/bin/python manage.py migrate'))
    


# Generated at 2022-06-12 11:23:10.278127
# Unit test for function match
def test_match():
    assert match(Command('/opt/myvenv/bin/python manage.py migrate --merge'))
    assert match(Command('python manage.py migrate --merge'))
    assert not match(Command('python manage.py migrate'))



# Generated at 2022-06-12 11:23:21.714947
# Unit test for function match

# Generated at 2022-06-12 11:23:29.271678
# Unit test for function match
def test_match():
    assert match(
        Command('python manage.py migrate', '',
                '')) is True
    assert match(
        Command('python manage.py flask migrate', '',
                '')) is False
    assert match(
        Command('python manage.py migrate', '',
                '--merge: will just attempt the migration')) is True
    assert match(
        Command('python manage.py migrate', '',
                '--merge: will just attempt the migration')) is True
    assert match(
        Command('python manage.py migrate', '',
                '--merge: will just attempt the migration\n--fake: will fake the migration')) is True


# Generated at 2022-06-12 11:23:30.622718
# Unit test for function match
def test_match():
    assert match(COMMAND_NO_MERGE) is False
    assert match(COMMAND_MERGE) is True

# Generated at 2022-06-12 11:23:32.897137
# Unit test for function match

# Generated at 2022-06-12 11:23:48.097092
# Unit test for function match
def test_match():
    assert match(Command('/usr/bin/python manage.py migrate'))
    assert match(Command('python manage.py migrate'))
    assert match(Command('python manage.py migrate -m "Initial migration."'))


# Generated at 2022-06-12 11:23:56.990057
# Unit test for function match
def test_match():
    # A clean run output
    clean_command = Command('python manage.py migrate -v 0 --merge',
                            '\nNothing to migrate.\n', 0)
    assert match(clean_command) is True

    # A failing run output
    failing_command = Command('python manage.py migrate -v 0 --merge',
                              'error: --merge is not supported by South', 1)
    assert match(failing_command) is False

    # A failing run output
    failing_command = Command('python manage.py migrate -v 0 --merge',
                              'Applying admin.0001_initial... We cannot provide a migration option to merge south-created tables into the default table, as in some cases we cannot determine which fields are primary keys (not null, unique) and which are not', 1)
    assert match(failing_command)

# Generated at 2022-06-12 11:23:58.181634
# Unit test for function match

# Generated at 2022-06-12 11:24:02.920688
# Unit test for function match
def test_match():
    command = Command('/var/www/django-project/manage.py migrate --settings=dev -v 3')
    assert(match(command))

    command = Command('/var/www/django-project/manage.py migrate --settings=dev -v 3')
    assert(not match(command))

    command = Command('/var/www/django-project/manage.py migrate --settings=dev -v 3')
    assert(not match(command))



# Generated at 2022-06-12 11:24:13.856090
# Unit test for function match
def test_match():
    assert match(Command('python manage.py migrate --merge: will just attempt the migration', '', None))
    assert match(Command('manage.py migrate --merge: will just attempt the migration', '', None))
    assert match(Command(' mangage.py   migrate --merge: will just attempt the migration', '', None))
    assert match(Command('python manage.py migrate --merge: will just attempt the migration', '', None))
    assert match(Command('python manage.py migrate', '', None))
    assert match(Command('manage.py migrate', '', None))
    assert match(Command(' mangage.py   migrate', '', None))
    assert match(Command('python manage.py migrate', '', None))

# Generated at 2022-06-12 11:24:17.407882
# Unit test for function match
def test_match():
    command = get_command(example)
    assert match(command) is True
    command = get_command(example2)
    assert match(command) is False
    command = get_command(example3)
    assert match(command) is True



# Generated at 2022-06-12 11:24:23.419222
# Unit test for function match
def test_match():
    assert match(Command('python manage.py migrate'))
    assert match(Command('python manage.py migrate --merge'))
    assert match(Command('python manage.py migrate --merge: will just attempt the migration'))
    assert not match(Command('python manage.py makemigrations'))
    assert not match(Command('python manage.py m'))
    assert not match(Command('python manage.py t'))
    assert not match(Command('python manage.py --merge'))
    assert not match(Command('python --merge manage.py migrate'))
    assert not match(Command('python manage.py'))
    assert not match(Command('python manage.py '))

# Generated at 2022-06-12 11:24:25.462010
# Unit test for function match
def test_match():
    # If function match returns True
    if match(Command('/usr/bin/manage.py migrate')) is True:
        assert True


# Generated at 2022-06-12 11:24:27.692468
# Unit test for function match
def test_match():
    assert True == match(Command("C:\Python27\python.exe manage.py migrate"))
    assert False == match(Command("C:\Python27\python.exe manage.py shell"))

# Generated at 2022-06-12 11:24:37.766731
# Unit test for function match
def test_match():
    # Should match:
    assert match(Command('manage.py makemigrations'))
    assert match(Command('python manage.py migrate'))
    assert match(Command('python manage.py migrate --fake'))
    assert match(Command('python manage.py migrate --fake --fake2'))
    assert match(Command('python manage.py migrate --fake --fake2 --fake3'))

    # Shouldn't match:
    assert not match(Command('python manage.py migrate --fake --fake2 --merge'))
    assert not match(Command('python manage.py migrate --fake --fake2 --merge'))
    assert not match(Command('manage.py makemigrations --merge'))
    assert not match(Command('manage.py makemigrations --fake2 --merge'))

# Generated at 2022-06-12 11:24:53.665928
# Unit test for function match
def test_match():
    assert match("""
            /path/to/manage.py migrate --merge: will just attempt the migration 
            """)
    assert match("""
            /path/to/manage.py migrate --merge: will just attempt the migration 
            """)
    assert match("""
            /path/to/manage.py migrate --merge: will just attempt the migration 
            """)
    assert not match("""
            /path/to/manage.py migrate --merge: will just attempt the migration
            """)
    assert not match("""
            Other stuff here
            """)
    assert not match("""
            manage.py migrate -merge: will just attempt the migration
            """)


# Generated at 2022-06-12 11:25:02.560677
# Unit test for function match
def test_match():
    assert True == match(Command('karma run manage.py test'))
    assert True == match(Command('manage.py test karma'))
    assert True == match(Command('karma run manage.py migrate --merge: will just attempt the migration'))
    assert True == match(Command('manage.py migrate --merge: will just attempt the migration karma'))
    assert False == match(Command('manage.py migrate --merge'))
    assert False == match(Command('karma run'))
    assert False == match(Command('manage.py'))
    assert False == match(Command('karma'))
    assert False == match(Command(''))

# Generated at 2022-06-12 11:25:08.585235
# Unit test for function match
def test_match():
    assert match('$ python manage.py migrate')
    assert match('$ ./manage.py.migrate')
    assert match('$ go run manage.py migrate')
    assert match('$ ./django_admin.py migrate')
    assert match('$ django-admin.py migrate')
    assert not match('')
    assert not match('$ python manage.py')
    assert not match('$ manage.py migrate')


# Generated at 2022-06-12 11:25:10.876812
# Unit test for function match
def test_match():
    command = type('obj', (object,), {'script': 'python ./manage.py migrate',
                                      'output': "--merge: will just attempt the migration"})
    assert(match(command))



# Generated at 2022-06-12 11:25:18.693610
# Unit test for function match
def test_match():
    assert match(Command('/tmp/venv/bin/python manage.py migrate --merge',
        '',
        'CommandError: Conflicting migrations detected; multiple leaf nodes in the migration graph:\n\n(django_mysite)bar\n(django_mysite)foo\n\nTo fix them run \'python manage.py makemigrations --merge\' on the double-migrated app.'))

# Generated at 2022-06-12 11:25:23.352701
# Unit test for function match
def test_match():
    assert True == match(MockCommand("manage.py migrate", "--merge: will just attempt the migration"))
    assert False == match(MockCommand("manage.py makemessages", "--merge: will just attempt the migration"))
    assert False == match(MockCommand("manage.py makemessages", ""))

# Generated at 2022-06-12 11:25:29.046703
# Unit test for function match
def test_match():
    assert match(Command('', output='')) \
        == False, "1st test for function match"
    assert match(Command('manage.py asdf', output='')) \
        == False, "2nd test for function match"
    assert match(Command('asdf manage.py', output='')) \
        == False, "3rd test for function match"
    assert match(Command('manage.py migrate', output='')) \
        == False, "4th test for function match"
    assert match(Command('manage.py migrate', output='123')) \
        == False, "5th test for function match"
    assert match(Command('manage.py migrate',
                         output='--merge: will just attempt the migration')) \
        == True, "6th test for function match"


# Generated at 2022-06-12 11:25:33.333739
# Unit test for function match
def test_match():
    r = pipe_modules.DjangoMigrate()
    assert r.match('manage.py migrate --merge: will just attempt the migration blablabla')
    assert not r.match('manage.py migrate blablabla')
    assert not r.match('blablabla')

# Generated at 2022-06-12 11:25:40.517508
# Unit test for function match
def test_match():
    assert match(Command('python manage.py migrate', '', '', 0, None))
    assert not match(Command('python manage.py schemamigration', '', '', 0, None))
    assert not match(Command('python manage.py migrate', '', '', 0, None))
    assert not match(Command('python manage.py migrate --fake', '', '', 0, None))
    assert not match(Command('python manage.py migrate --fake', '', '', 0, None))
    assert not match(Command('python manage.py migrate --fake', '', '', 0, None))
    assert not match(Command('python manage.py showmigrations', '', '', 0, None))
    assert not match(Command('python manage.py showmigrations --sql', '', '', 0, None))

# Generated at 2022-06-12 11:25:44.095739
# Unit test for function match
def test_match():
    assert match(Command('python manage.py migrate'))
    assert match(Command('python manage.py migrate --merge'))
    assert not match(Command('python manage.py collectstatic'))



# Generated at 2022-06-12 11:26:11.785056
# Unit test for function match
def test_match():
    assert match(Command('manage.py migrate'))
    assert not match(Command('manage.py runserver'))
    assert not match(Command('manage.py check'))
    assert not match(Command('manage.py makemigrations'))


# Generated at 2022-06-12 11:26:18.525971
# Unit test for function match
def test_match():
    os.chdir(os.path.dirname(os.path.realpath(__file__)))
    command = Command('python manage.py migrate')
    assert match(command) == True
    command = Command('python manage.py makemigrations')
    assert match(command) == False
    command = Command('python manage.py migrate --merge')
    assert match(command) == False
    command = Command('python manage.py migrate')
    command.output = command.output + '\n--merge: will just attempt the migration\n'
    assert match(command) == True

# Generated at 2022-06-12 11:26:24.656907
# Unit test for function match
def test_match():
    assert match(Command('python manage.py migrate', """
        Operations to perform:
          ? Apply all migrations: admin, auth, bimt, contenttypes, sessions
        Running migrations:
          No migrations to apply.
          Your models have changes that are not yet reflected in a migration, and so won't be applied.
          Run 'manage.py makemigrations' to make new migrations, and then re-run 'manage.py migrate' to apply them.
          --merge: will just attempt the migration
    """))

# Generated at 2022-06-12 11:26:30.730714
# Unit test for function match
def test_match():
    #assert(match('/venv/bin/python /var/lib/jenkins/workspace/Testy/manage.py migrate --noinput'))
    #assert(match('(venv) [michal@saffron manage.py makemigrations'))
    assert(match('manage.py migrate --merge: will just attempt the migration'))
    assert(match('python3 manage.py migrate --merge'))

# Generated at 2022-06-12 11:26:37.201985
# Unit test for function match
def test_match():
    assert match(Command('python manage.py migrate --verbosity 2'))
    assert match(Command('python manage.py migrate'))
    assert match(Command('python manage.py migrate --merge'))
    assert match(Command('python manage.py migrate --fake'))
    assert not match(Command('python manage.py makemigrations'))
    assert not match(Command('python manage.py --merge'))
    assert not match(Command('python manage.py --merge migrate'))
    assert not match(Command('python --merge manage.py migrate'))
    assert not match(Command('python --merge --verbosity 2 manage.py migrate'))
    assert not match(Command('python --verbosity 2 --merge manage.py migrate'))

# Generated at 2022-06-12 11:26:41.702654
# Unit test for function match
def test_match():
    assert match(Command('manage.py migrate --merge: will just attempt the migration'))
    assert not match(Command('manage.py migrate'))
    assert not match(Command('manage.py syncdb'))
    assert not match(Command('git --merge'))


# Generated at 2022-06-12 11:26:42.993175
# Unit test for function match
def test_match():
    command = Command('manage.py migrate --database=example')
    assert match(command)



# Generated at 2022-06-12 11:26:47.224270
# Unit test for function match
def test_match():
    assert True != match("manage.py migrate --merge")
    assert True != match("python manage.py makemigrations")
    assert True != match("python manage.py migrate")
    assert True == match("python manage.py migrate --merge: will just attempt the migration")

# Generated at 2022-06-12 11:26:49.386487
# Unit test for function match
def test_match():
    assert match(Command('manage.py migrate',
                         output='--merge: will just attempt the migration'))
    assert not match(Command('manage.py migrate'))
    assert not match(Command('zsh'))

# Generated at 2022-06-12 11:26:50.877207
# Unit test for function match
def test_match():
    # I don't know how to test this function.
    pass

# Generated at 2022-06-12 11:27:53.319856
# Unit test for function match
def test_match():
    assert match(Command('manage.py migrate', '', ''))
    assert match(Command('manage.py migrate', '', '--merge: will just attempt the migration'))
    assert not match(Command('python manage.py migrate', '', ''))
    assert not match(Command('manage.py shell', '', ''))



# Generated at 2022-06-12 11:27:55.506975
# Unit test for function match
def test_match():
    command = namedtuple('command', ['script'])
    assert match(command(script='manage.py')) == False
    assert match(command(script='manage.py migrate')) == False
    assert match(command(script='manage.py migrate',
                         output='--merge: will just attempt the migration')) == True



# Generated at 2022-06-12 11:28:01.097839
# Unit test for function match
def test_match():
    command = CommandTest('manage.py migrate --merge')
    assert(match(command))

    command = CommandTest('manage.py migrate --merge --fake')
    assert(match(command))

    command = CommandTest('manage.py migrate')
    assert(not match(command))

    command = CommandTest('manage.py migrate --fake')
    assert(not match(command))

    command = CommandTest('manage.py --merge migrate')
    assert(not match(command))



# Generated at 2022-06-12 11:28:06.464173
# Unit test for function match
def test_match():
    assert match(Command('manage.py migrate'))
    assert match(Command('manage.py migrate --merge'))
    assert match(Command('python manage.py migrate'))
    assert match(Command('python manage.py migrate --merge'))
    assert not match(Command('manage.py celery'))
    assert not match(Command('python manage.py migrate --merge'))



# Generated at 2022-06-12 11:28:10.425941
# Unit test for function match
def test_match():
    command = Command('python manage.py migrate', '', '\n  merge: will just attempt the migration\n')
    assert(match(command))
    command = Command('python manage.py migrate', '', '\n  merge: will just attempt the migration\n  ')
    assert((not match(command)))



# Generated at 2022-06-12 11:28:12.643009
# Unit test for function match
def test_match():
    assert match(Command('/usr/bin/python3 manage.py migrate --merge: will just attempt the migration'))
    assert not match(Command('/usr/bin/python3 manage.py migrate'))



# Generated at 2022-06-12 11:28:21.610656
# Unit test for function match
def test_match():
    assert match(Command('python manage.py migrate', '', 'Migrating...\r\n'
                    'Whoops, that didn\'t go so well... The migration failed\r\n'
                    '--merge: will just attempt the migration\r\n'))
    assert match(Command('python manage.py migrate', '', 'Migrating...\r\n'
                    'Whoops, that didn\'t go so well... The migration failed\r\n'
                    '--merge: will just attempt the migration\r\n'))
    assert match(Command('python manage.py migrate', '', 'Another error message here\r\n'
                    '--merge: will just attempt the migration\r\n'))

# Generated at 2022-06-12 11:28:31.108206
# Unit test for function match

# Generated at 2022-06-12 11:28:36.174551
# Unit test for function match
def test_match():
    assert match({'script': 'manage.py mivate'}) is False
    assert match({'script': 'manage.py mivate', 'output': '--merge: will just attempt the migration'}) is False
    assert match({'script': 'manage.py migrate', 'output': '--merge: will just attempt the migration'}) is True
    assert match({'script': 'manage.py migrate', 'output': '--merge: will just attempt the migration', 'known_errors': ['unknown_error']}) is True


# Generated at 2022-06-12 11:28:42.087395
# Unit test for function match
def test_match():
    assert match(
        Command('python manage.py migrate -merge'))
    assert match(
        Command('python manage.py migrate --merge'))
    assert match(
        Command('python manage.py migrate -merge= True'))
    assert match(
        Command('python manage.py migrate --merge=True'))
    assert match(
        Command('python manage.py migrate --merge=False'))
    assert match(
        Command('python manage.py migrate -merge=False'))
    assert match(Command('python manage.py migrate --merge=false'))

