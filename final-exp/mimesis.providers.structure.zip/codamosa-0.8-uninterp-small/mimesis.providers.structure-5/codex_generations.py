

# Generated at 2022-06-25 21:06:39.013266
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    expected = dict()
    expected['background-color'] = '#a38434'
    expected['background'] = '#ffdcf3 url(http://www.example.com/)'
    expected['border-top'] = '1px solid #8cb742'
    expected['border-right'] = '1px solid #c0d39d'
    expected['border-bottom'] = '1px solid #d0e336'
    expected['border-left'] = '1px solid #979d48'
    expected['border'] = '1px solid #a0f532'
    expected['border-color'] = '#d072b8'
    expected['border-radius'] = '5%'
    expected['padding'] = '2em'
    expected['width'] = '85%'

# Generated at 2022-06-25 21:06:41.463216
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    structure_1 = Structure()
    assert (structure_0.css_property() == structure_1.css_property())


# Generated at 2022-06-25 21:06:53.532915
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    # Test the evaluation of: structure_0
    assert structure_0 is not None
    # Test the evaluation of: structure_0.html_attribute_value()
    temp_0 = structure_0.html_attribute_value()
    assert temp_0 is not None
    # Test the evaluation of: structure_0.html_attribute_value('h1', 'align')
    temp_1 = structure_0.html_attribute_value('h1', 'align')
    assert temp_1 is not None
    # Test the evaluation of: structure_0.html_attribute_value('h1', 'color')
    temp_2 = structure_0.html_attribute_value('h1', 'color')
    assert temp_2 is not None
    # Test the evaluation of: structure_0.html_attribute_value('h

# Generated at 2022-06-25 21:06:58.356523
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure('en')
    html_tag = 'img'
    attribute = 'alt'
    tag_and_attr = (html_tag, attribute)
    assert_startswith(structure_0.html_attribute_value(*tag_and_attr), 'alt')


# Generated at 2022-06-25 21:07:01.121476
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    unit_test = Structure()
    result_0 = unit_test.css_property()
    assert isinstance(result_0, str)


# Generated at 2022-06-25 21:07:07.078544
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    tag_0 = structure_0.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    str_0 = structure_0.html_attribute_value(tag_0)
    assert True
    attribute_0 = structure_0.random.choice(list(HTML_CONTAINER_TAGS[tag_0]))
    str_1 = structure_0.html_attribute_value(tag_0, attribute_0)
    assert True


# Generated at 2022-06-25 21:07:14.131354
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    list_0 = ['a', 'id']
    list_1 = ['a', 'id', 'href']
    assert structure_0.html_attribute_value(list_0[0], list_0[1]) is not None
    assert structure_0.html_attribute_value(list_1[0], list_1[1]) == 'word'
    assert structure_0.html_attribute_value(list_1[0], list_1[2]) == 'url'


# Generated at 2022-06-25 21:07:15.298801
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure().html_attribute_value() == 'text'


# Generated at 2022-06-25 21:07:23.963913
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.data import HTML_CONTAINER_TAGS
    from mimesis.data import CSS_SELECTORS
    from mimesis.data import CSS_PROPERTIES
    for i in range(10):
        struct_0 = Structure()
        css_property_0 = struct_0.css_property()
        assert len(css_property_0) < 30
    for i in range(10):
        struct_1 = Structure()
        css_property_1 = struct_1.css_property()
        assert not isinstance(css_property_1, dict)
    for i in range(10):
        struct_2 = Structure()
        css_property_2 = struct_2.css_property()
        assert len(css_property_2.split(':')) == 2


# Generated at 2022-06-25 21:07:26.907064
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Test for method css_property of class Structure
    list_0 = []
    structure_0 = Structure(*list_0)
    str_0 = structure_0.css_property()
    assert(str_0 is not None)
