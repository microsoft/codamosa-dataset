

# Generated at 2022-06-25 21:06:25.207100
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    assert structure_0.html_attribute_value() in HTML_CONTAINER_TAGS.keys()


# Generated at 2022-06-25 21:06:31.027624
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0_html_attribute_value = Structure().html_attribute_value()
    structure_1_html_attribute_value = Structure().html_attribute_value("a")
    structure_2_html_attribute_value = Structure().html_attribute_value("a",
                                                                        "href")

# Generated at 2022-06-25 21:06:31.810504
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    result_0 = structure_0.css_property()


# Generated at 2022-06-25 21:06:32.750656
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    prop = structure.css_property()
    assert prop


# Generated at 2022-06-25 21:06:35.012862
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    for i in range(10000):
        p0 = structure_0.css_property()


# Generated at 2022-06-25 21:06:42.966337
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    # The 'tag' param is none
    assert_for_html_attribute_value_when_tag_param_is_none(structure_0)
    # The 'tag' param is not none
    assert_for_html_attribute_value_when_tag_param_is_not_none(structure_0)
    # The 'tag' param is not in the HTML_CONTAINER_TAGS
    assert_for_html_attribute_value_when_tag_param_is_not_in_the_HTML_CONTAINER_TAGS(structure_0)

# Generated at 2022-06-25 21:06:48.998971
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()

    html_result_1 = structure_1.html_attribute_value()

    assert structure_1.random.choice(list(HTML_CONTAINER_TAGS.keys())) == 'div'
    assert structure_1.random.choice(list(HTML_CONTAINER_TAGS['div'])) == 'class'
    assert html_result_1 == 'Structure.css_property()'


# Generated at 2022-06-25 21:06:52.685816
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure().html_attribute_value('a', 'href') != None
    assert Structure(seed=42).html_attribute_value('a', 'href') != None


# Generated at 2022-06-25 21:07:03.872779
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct_0 = Structure()
    assert struct_0.html_attribute_value('a','href').startswith('http')
    struct_0_1 = Structure(seed=2000)
    assert struct_0_1.html_attribute_value('a','href') == 'http://abt.io'
    assert struct_0_1.html_attribute_value('a','href') == 'http://abt.io'
    assert struct_0_1.html_attribute_value('a','href') == 'http://abt.io'
    assert struct_0_1.html_attribute_value('a','href') == 'http://abt.io'
    assert struct_0_1.html_attribute_value('a','href') == 'http://abt.io'

# Generated at 2022-06-25 21:07:09.550152
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Parameterized test
    parameters = [
        ('span', 'id'),
        ('div', 'class'),
        ('a', 'href'),
        ('a', 'target'),
        ('a', 'title')
    ]

    for test_data in parameters:
        assert Structure().html_attribute_value(
            test_data[0], test_data[1])
