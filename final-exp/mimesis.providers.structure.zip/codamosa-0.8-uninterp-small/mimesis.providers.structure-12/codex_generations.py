

# Generated at 2022-06-25 21:06:44.972913
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_css_property = Structure().css_property()
    assert isinstance(structure_css_property, str)


# Generated at 2022-06-25 21:06:47.958096
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    value_0 = structure_0.html_attribute_value(tag='a', attribute='href')
    assert len(value_0) == 5


# Generated at 2022-06-25 21:06:51.694695
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    css_property = Structure().css_property()
    assert Structure().html_attribute_value(tag='a', attribute='href') == 'url'


# Generated at 2022-06-25 21:07:03.135668
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    html_tag = 'a'
    attr = 'href'
    assert isinstance(structure_1.html_attribute_value(html_tag, attr), str)
    assert isinstance(structure_1.html_attribute_value(), str)
    assert isinstance(structure_1.html_attribute_value(html_tag), str)
    assert isinstance(structure_1.html_attribute_value(attribute=attr), str)
 
    html_tag = 'link'
    attr = 'rel'
    assert isinstance(structure_1.html_attribute_value(html_tag, attr), str)
    assert isinstance(structure_1.html_attribute_value(), str)

# Generated at 2022-06-25 21:07:04.398657
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert len(Structure().html_attribute_value()) > 2


# Generated at 2022-06-25 21:07:06.820149
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    assert structure_1.html_attribute_value() != None
    assert isinstance(structure_1.html_attribute_value(), str)


# Generated at 2022-06-25 21:07:10.375896
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()

    result = structure_0.html_attribute_value("a", "class")
    assert type(result) == str

