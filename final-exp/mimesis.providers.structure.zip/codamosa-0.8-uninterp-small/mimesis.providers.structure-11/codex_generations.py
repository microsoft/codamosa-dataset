

# Generated at 2022-06-25 21:06:13.885557
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()

    assert structure_0.html_attribute_value(tag = None, attribute = None) is not None


# Generated at 2022-06-25 21:06:15.552584
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure0 = Structure()
    assert structure0.html_attribute_value("a", "xlink:href") == 'url://echr.coe.int/echr/en/'


# Generated at 2022-06-25 21:06:16.794540
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    str_0 = structure_0.html_attribute_value()


# Generated at 2022-06-25 21:06:27.248346
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    attr_value_0 = structure_0.html_attribute_value(tag="input", attribute="name")
    assert(type(attr_value_0) == str)
    attr_value_1 = structure_0.html_attribute_value(tag="input", attribute="form")
    assert(type(attr_value_1) == str)
    attr_value_2 = structure_0.html_attribute_value(tag="input", attribute="maxlength")
    assert(type(attr_value_2) == str)
    attr_value_3 = structure_0.html_attribute_value(tag="input", attribute="value")
    assert(type(attr_value_3) == str)

# Generated at 2022-06-25 21:06:29.814807
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    structure_1.html_attribute_value('base', 'href')

# Generated at 2022-06-25 21:06:34.386990
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = 'input'
    attr = 'checked'
    value = structure.html_attribute_value(tag, attr)
    assert value in HTML_CONTAINER_TAGS[tag][attr]

# Generated at 2022-06-25 21:06:38.656611
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    attribute_0 = structure_0.html_attribute_value()
    attribute_1 = structure_0.html_attribute_value(tag='article')
    attribute_2 = structure_0.html_attribute_value(tag='article', attribute='class')



# Generated at 2022-06-25 21:06:39.954215
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    str(Structure().css_property())


# Generated at 2022-06-25 21:06:44.884497
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = structure.random.choice(list(HTML_CONTAINER_TAGS))
    attribute = structure.random.choice(list(HTML_CONTAINER_TAGS[tag]))
    attr_value = structure.html_attribute_value(tag,attribute)
    assert isinstance(attr_value, str)

# Generated at 2022-06-25 21:06:46.029360
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    Structure.html_attribute_value()

# Generated at 2022-06-25 21:06:57.666755
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert HTML_CONTAINER_TAGS['span']['id'] == 'word'
    structure_1 = Structure()
    assert structure_1.html_attribute_value('span', 'id') != None



# Generated at 2022-06-25 21:07:00.225154
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()
    ans = structure_1.css_property()
    assert isinstance(ans,str)


# Generated at 2022-06-25 21:07:03.221727
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()
    assert(structure_1.random.choice(list(CSS_PROPERTIES.keys())) in \
    structure_1.css_property())


# Generated at 2022-06-25 21:07:10.998846
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # test case 0 of method html_attribute_value of class Structure
    structure_0 = Structure()
    tag_0 = 'h1'
    attribute_0 = 'class'
    actual_result_of_html_attribute_value_0 = structure_0.html_attribute_value(tag=tag_0, attribute=attribute_0)
    expected_result_of_html_attribute_value_0 = 'color: #e70c0e; text-align: right'
    assert actual_result_of_html_attribute_value_0 == expected_result_of_html_attribute_value_0

# Generated at 2022-06-25 21:07:19.904140
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSProperty

    structure_0 = Structure()

    css_property_0 = structure_0.css_property()
    assert isinstance(css_property_0, str)

    css_property_1 = structure_0.css_property(property=CSSProperty.MARGIN)
    assert isinstance(css_property_1, str)
    assert css_property_1.startswith('margin:')

    css_property_2 = structure_0.css_property(property=CSSProperty.BACKGROUND)
    assert isinstance(css_property_2, str)
    assert css_property_2.startswith('background:')

    css_property_3 = structure_0.css_property(property=CSSProperty.BORDER)

# Generated at 2022-06-25 21:07:22.536954
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    css_property_0 = structure_0.css_property()
    assert isinstance(css_property_0, str)
    assert css_property_0


# Generated at 2022-06-25 21:07:23.925709
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value(tag=None, attribute=None)


# Generated at 2022-06-25 21:07:25.891485
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # initialization
    structure_0 = Structure()

    # testing
    structure_0.css_property()
    


# Generated at 2022-06-25 21:07:27.982540
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure(seed=2412)
    prop = structure.html_attribute_value()
    assert prop == 'scroll'


# Generated at 2022-06-25 21:07:36.981540
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # case_0
    print(str(Structure().html_attribute_value()))

    # case_1
    print(str(Structure().html_attribute_value('form')))

    # case_2
    print(str(Structure().html_attribute_value('form', 'accept-charset')))

    # case_3
    try:
        print(str(Structure().html_attribute_value(tag="wrong_tag",
                                                   attribute="wrong_attr")))
    except NotImplementedError:
        print("test case 3: passed")



# Generated at 2022-06-25 21:07:49.603714
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    print(structure_0.html_attribute_value(tag='html',
                                           attribute='lang'))


# Generated at 2022-06-25 21:07:52.816899
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    structure_0_html_attribute_value_0 = structure_0.html_attribute_value()


# Generated at 2022-06-25 21:08:01.310515
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure(seed=10537)
    structure_0.html_attribute_value()
    structure_0.html_attribute_value(tag='a')
    structure_0.html_attribute_value(attribute='href')
    structure_0.html_attribute_value(tag='option', attribute='value')
    structure_0.html_attribute_value(tag='button', attribute='name')
    structure_0.html_attribute_value(tag='button', attribute='type')
    structure_0.html_attribute_value(tag='button', attribute='value')
    structure_0.html_attribute_value(tag='i', attribute='class')


# Generated at 2022-06-25 21:08:03.543883
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    result = structure_0.html_attribute_value()
    assert isinstance(result, str)


# Generated at 2022-06-25 21:08:05.915532
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    for i in range(10):
        structure_1 = Structure()
        result=structure_1.css_property()
        print(result)


# Generated at 2022-06-25 21:08:13.720769
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    array_0 = []
    array_1 = []
    for i in range(50):
        seed = i
        structure_0 = Structure(seed=seed)
        html_result = structure_0.html()
        array_0.append(html_result)
    file = open("structure_html.txt","w")
    for i in array_0:
        file.write(i)
        file.write("\n")
    file.close()
    for i in range(50):
        seed = i
        structure_0 = Structure(seed=seed)
        html_result = structure_0.html(attribute='class')
        array_1.append(html_result)
    file = open("structure_html_attribute_value.txt","w")

# Generated at 2022-06-25 21:08:15.885072
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    tag = 'html'
    attribute = 'version'
    assert structure_0.html_attribute_value(tag, attribute) == '5'


# Generated at 2022-06-25 21:08:24.161680
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value(tag="input", attribute="type") in ["button", "checkbox", "radio"]
    assert structure.html_attribute_value(tag="input", attribute="name") in ["word"]
    assert structure.html_attribute_value(tag="input", attribute="value") in ["css"]
    assert structure.html_attribute_value(tag="input", attribute="src") in ["url"]
    assert structure.html_attribute_value(tag="input", attribute="maxlength") in ["int"]
    assert structure.html_attribute_value(tag="input", attribute="placeholder") in ["word"]
    assert structure.html_attribute_value(tag="input", attribute="pattern") in ["regex"]

# Generated at 2022-06-25 21:08:29.878650
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    for testCase in range(0, 10):
        structure = Structure()
        tag = None
        attribute = None
        assert structure.html_attribute_value(tag, attribute)



# Generated at 2022-06-25 21:08:35.873614
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    test_cases = [
        {
            'inputs': [
            ],
            'expected_result': [
                'background',
                'font-style',
                'direction',
                'line-height',
                'font-size',
                'grid-column-end',
            ],
        },
    ]

    for case in test_cases:
        print('Running test: {}'.format(
            case.get('title', '{}_{}'.format(
                test_Structure_css_property.__name__,
                test_cases.index(case),
                ))),
            end='')

        result = Structure(*case.get('inputs', [])).css_property()

        print(' ' * (80 - len(result)), end='')
        print(' -> ', end='')


# Generated at 2022-06-25 21:08:50.388412
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    structure_0.random.seed(5)
    result = structure_0.css_property()
    assert result == 'border-right-color: #c6d5b6'


# Generated at 2022-06-25 21:08:54.338115
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    style_list = structure_0.css_property().split(': ')
    assert style_list[0] in CSS_PROPERTIES
    assert style_list[1] in CSS_PROPERTIES.values()


# Generated at 2022-06-25 21:08:56.239115
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()
    assert structure_1.css_property()


# Generated at 2022-06-25 21:09:04.492566
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    structures = []
    attributes = []
    for i in range(100):
        structure = structure_0.html_attribute_value(structure_0.random.choice(
            list(HTML_CONTAINER_TAGS.keys())))
        structures.append(structure)
        for attr in structure.split():
            if attr.find("=") == -1:
                continue
            (key, value) = attr.split("=")
            if key.find("\"") == -1:
                continue
            if key in attributes:
                raise ValueError("The attribute key is repeated")
            else:
                attributes.append(key)
    print("Number of iterations = 100")
    print("Number of unique generated attributes = %d" % len(attributes))



# Generated at 2022-06-25 21:09:12.713327
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # object creation and initialization
    structure_1 = Structure()
    tag_1 = "a"
    attribute_1 = "href"
    test_val_1 = structure_1.html_attribute_value(tag=tag_1,attribute=attribute_1)
    assert (test_val_1 == "https://www.")
    tag_2 = "a"
    attribute_2 = "class"
    test_val_2 = structure_1.html_attribute_value(tag=tag_2,attribute=attribute_2)
    assert (test_val_2 == "org")
    tag_3 = "form"
    attribute_3 = "type"
    test_val_3 = structure_1.html_attribute_value(tag=tag_3,attribute=attribute_3)

# Generated at 2022-06-25 21:09:21.206552
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    # Test HTML tag : a
    # Test attribute : class
    test_attr_1 = structure_1.html_attribute_value(tag='a', attribute='class')
    assert isinstance(test_attr_1, str)
    # Test attribute : href
    test_attr_2 = structure_1.html_attribute_value(tag='a', attribute='href')
    assert test_attr_2 == 'url'
    # Test attribute : id
    test_attr_3 = structure_1.html_attribute_value(tag='a', attribute='id')
    assert test_attr_3 == 'word'
    # Test attribute : src
    test_attr_4 = structure_1.html_attribute_value(tag='a', attribute='src')
    assert test_attr_4 == 'url'
    

# Generated at 2022-06-25 21:09:24.010664
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure().html_attribute_value(
        'a', 'href') == 'http://www.alexanderochoa.com'


# Generated at 2022-06-25 21:09:26.711805
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_ = Structure(seed=0)
    x = structure_.css_property()
    print(x)
    assert x == 'text-align: right'



# Generated at 2022-06-25 21:09:28.833146
# Unit test for method css_property of class Structure
def test_Structure_css_property():

    structure_css_property = Structure()
    element = structure_css_property.css_property()
    assert isinstance(element, str)
    assert ':' in element


# Generated at 2022-06-25 21:09:32.631010
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    structure_1 = Structure()
    assert structure_0.html_attribute_value() == structure_0.html_attribute_value()
    assert structure_0.html_attribute_value() == structure_1.html_attribute_value()


# Generated at 2022-06-25 21:09:47.413677
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    assert ['background-color'] == list(CSS_PROPERTIES.keys())
    assert structure_0.css_property() in CSS_PROPERTIES


# Generated at 2022-06-25 21:09:48.950196
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    for _ in range(1000):
        tag = structure.random.choice(list(HTML_CONTAINER_TAGS))
        attribute = structure.random.choice(list(HTML_CONTAINER_TAGS[tag]))
        assert structure.html_attribute_value(tag, attribute) != ''

# Generated at 2022-06-25 21:09:58.132833
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    structure_1 = Structure()
    structure_2 = Structure()
    structure_3 = Structure()

    # ## TEST START: should be pass ##
    assert type(structure_0.html_attribute_value('div', 'data-content-id')) == str
    assert type(structure_0.html_attribute_value(tag='div', attribute='data-content-id')) == str
    # ## TEST END: should be pass ##

    # ## TEST START: should be pass ##
    assert type(structure_1.html_attribute_value('div', 'style')) == str
    assert type(structure_1.html_attribute_value(tag='div', attribute='style')) == str
    # ## TEST END: should be pass ##

    # ## TEST START: should be pass ##

# Generated at 2022-06-25 21:10:00.088371
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    assert structure_0.html_attribute_value(tag='a', attribute='href') == 'http://www.everett-zahn.com/'


# Generated at 2022-06-25 21:10:04.918041
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()

    res = structure_0.html_attribute_value("class")
    res = structure_0.html_attribute_value("class", "background-color")
    res = structure_0.html_attribute_value("class", "size")


# Generated at 2022-06-25 21:10:09.721674
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    assert structure_0.css_property() not in (None, '')
    assert structure_0.css_property() != structure_0.css_property()
    assert len(structure_0.css_property()) > 6


# Generated at 2022-06-25 21:10:11.223580
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    assert structure_0.css_property() == 'background-color: #cb6291'


# Generated at 2022-06-25 21:10:19.306786
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()

    # Tag: a
    result_a_class = structure_0.html_attribute_value(tag='a', attribute='class')
    print(result_a_class)
    result_a_href = structure_0.html_attribute_value(tag='a', attribute='href')
    print(result_a_href)

    # Tag: button
    # result_a_class = structure_0.html_attribute_value(tag='button', attribute='class')
    # print(result_a_class)
    # result_a_href = structure_0.html_attribute_value(tag='button', attribute='href')
    # print(result_a_href)

    # Tag: div
    result_a_class = structure_0.html_attribute_value(tag='div', attribute='class')

# Generated at 2022-06-25 21:10:23.312572
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # basic case
    structure_0_attribute_value_got = Structure().html_attribute_value()
    structure_0_attribute_value_expected = Structure().html_attribute_value()

    assert structure_0_attribute_value_got == structure_0_attribute_value_expected

# Generated at 2022-06-25 21:10:28.566110
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct_instance = Structure()

    for tag in HTML_CONTAINER_TAGS.keys():
        for attr in HTML_CONTAINER_TAGS[tag]:
            assert struct_instance.html_attribute_value(tag, attr) is not None


# Generated at 2022-06-25 21:10:42.190688
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    attributes = ['type', 'src', 'content', 'disabled']
    assert structure.random.choice(attributes) in structure.html_attribute_value()

# Generated at 2022-06-25 21:10:46.762786
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    # html_attribute_value with default values of both tag and attribute
    assert structure_1.html_attribute_value()
    # html_attribute_value with only tag provided
    assert structure_1.html_attribute_value(tag="a")
    # html_attribute_value with tag as a and attribute as id
    assert structure_1.html_attribute_value(tag="a", attribute="id")


# Generated at 2022-06-25 21:10:50.854703
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    css_property_result = structure_0.css_property()
    print('******')
    print('css property')
    print(css_property_result)
    print('******')


# Generated at 2022-06-25 21:10:52.620556
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    attr_val = structure.html_attribute_value('input', 'type')

    assert type(attr_val) == str, 'structure.html_attribute_value returns wrong type'


# Generated at 2022-06-25 21:10:57.787347
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure(seed=1234567890)
    val_0 = structure_0.css_property()
    assert val_0 == 'background: #d8a2a0'
    val_1 = structure_0.css_property()
    assert val_1 == 'border-style: dotted'
    val_2 = structure_0.css_property()
    assert val_2 == 'width: 31%'
    val_3 = structure_0.css_property()
    assert val_3 == 'height: 94em'


# Generated at 2022-06-25 21:11:05.303732
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    for i in range(10):
        elem_0 = structure_0.html_attribute_value()
        print(elem_0)
        elem_1 = structure_0.html_attribute_value('link')
        print(elem_1)
        elem_2 = structure_0.html_attribute_value('link','href')
        print(elem_2)
        elem_3 = structure_0.html_attribute_value('a','class')
        print(elem_3)


# Generated at 2022-06-25 21:11:13.344698
# Unit test for method css_property of class Structure
def test_Structure_css_property():

    property_list = []

    for x in range(1000):
        structure_0 = Structure()
        property_list.append(structure_0.css_property())

    print(property_list)

    assert property_list[0] != property_list[1]
    assert property_list[1] != property_list[2]
    assert property_list[2] != property_list[3]
    assert property_list[3] != property_list[4]
    assert property_list[4] != property_list[5]
    assert property_list[5] != property_list[6]
    assert property_list[6] != property_list[7]
    assert property_list[7] != property_list[8]
    assert property_list[8] != property_list[9]

# Generated at 2022-06-25 21:11:16.659509
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('en')
    value = structure.css_property()
    assert isinstance(value, str)
    assert len(value) > 1


# Generated at 2022-06-25 21:11:18.190612
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structureTest = Structure()

    structureTest.css_property()



# Generated at 2022-06-25 21:11:29.479594
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    structure_0.random.choice = lambda x:x[0]

    assert structure_0.html_attribute_value() == '#f4d3a1'
    assert structure_0.html_attribute_value() == '1px'
    assert structure_0.html_attribute_value() == '1px'
    assert structure_0.html_attribute_value() == '#f4d3a1'
    assert structure_0.html_attribute_value() == '#f4d3a1'
    assert structure_0.html_attribute_value() == '#f4d3a1'
    assert structure_0.html_attribute_value() == '#f4d3a1'
    assert structure_0.html_attribute_value() == '#f4d3a1'
