

# Generated at 2022-06-25 21:06:38.015356
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    assert structure_1.html_attribute_value() != ''

# Generated at 2022-06-25 21:06:48.653830
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure().html_attribute_value("img", "src") == ""
    assert Structure().html_attribute_value("a", "href") == ""
    assert Structure().html_attribute_value("a", "target") == ""
    assert Structure().html_attribute_value("a", "rel") == ""
    assert Structure().html_attribute_value("img", "srcset") == ""
    assert Structure().html_attribute_value("img", "sizes") == ""
    assert Structure().html_attribute_value("audio", "src") == ""
    assert Structure().html_attribute_value("audio", "preload") == ""
    assert Structure().html_attribute_value("video", "src") == ""
    assert Structure().html_attribute_value("video", "poster") == ""

# Generated at 2022-06-25 21:06:55.760163
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSProperties
    structure_0 = Structure()
    for prop in structure_0.random.sample(list(CSSProperties), k=10):
        result = structure_0.css_property()
        if not isinstance(result, str):
            raise TypeError('Return type of method css_property must be'
                            ' <str>, not <{}>.'.format(type(result)))


# Generated at 2022-06-25 21:07:06.375244
# Unit test for method html_attribute_value of class Structure

# Generated at 2022-06-25 21:07:07.311597
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert Structure().css_property()


# Generated at 2022-06-25 21:07:12.859577
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    structure_2 = Structure()
    structure_3 = Structure()

    css_0 = structure_1.html_attribute_value('blockquote', 'style')
    url_0 = structure_2.html_attribute_value('div', 'style')
    word_0 = structure_3.html_attribute_value('a', 'href')



# Generated at 2022-06-25 21:07:21.798500
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    tag = structure_0.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    attribute = structure_0.random.choice(list(HTML_CONTAINER_TAGS[tag]))

    # The values of tag and attribute vary at each run