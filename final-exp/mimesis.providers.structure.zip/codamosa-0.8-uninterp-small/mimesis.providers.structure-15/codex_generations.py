

# Generated at 2022-06-25 21:06:33.885726
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for class Structure, method html_attribute_value."""
    structure_1 = Structure()
    structure_2 = Structure()
    structure_2.html_attribute_value('a', 'href')
    structure_1.html_attribute_value()

# Generated at 2022-06-25 21:06:36.029935
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()
    assert structure_1.css_property() == 'background-color: #f4d3a1'
    

# Generated at 2022-06-25 21:06:39.954359
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Case 0
    structure_0 = Structure()
    res_0 = structure_0.css_property()
    assert(res_0 is not None)
    assert(isinstance(res_0, str))
    assert(len(res_0) > 0)


# Generated at 2022-06-25 21:06:42.338424
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    test_value = Structure().html_attribute_value(tag="div", attribute="id")
    assert test_value is not None


# Generated at 2022-06-25 21:06:54.157616
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    list_of_attributes = list(HTML_CONTAINER_TAGS['a'])
    for tag in HTML_CONTAINER_TAGS:
        for attribute_key in HTML_CONTAINER_TAGS[tag]:
            try:
                structure.html_attribute_value(tag, attribute_key)
            except NotImplementedError:
                assert attribute_key not in list_of_attributes

    tag = 'a'
    list_of_attributes = ['href', 'hreflang', 'class', 'rel']
    for attr in list_of_attributes:
        attribute_key = attr
        try:
            structure.html_attribute_value(tag, attribute_key)
        except NotImplementedError:
            assert attribute_key not in list_of_attributes


# Generated at 2022-06-25 21:07:00.708938
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    # Test case 0
    structure_0 = Structure()
    tag_0 = structure_0.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    attribute_0 = structure_0.random.choice(list(HTML_CONTAINER_TAGS[tag_0]))
    assert isinstance(structure_0.html_attribute_value(tag_0, attribute_0), str)

# Generated at 2022-06-25 21:07:02.023078
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert len(Structure().css_property()) > 0


# Generated at 2022-06-25 21:07:05.727081
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = "input"
    attribute = "type"
    attribute_values = ["text", "number", "password", "checkbox", "radio", "file"]
    attribute_value = structure.html_attribute_value(tag, attribute)
    assert attribute_value in attribute_values


# Generated at 2022-06-25 21:07:07.838575
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # initialize the object
    struct = Structure()
    # test the case
    struct.html_attribute_value()


# Generated at 2022-06-25 21:07:10.274656
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    structure_0.css_property()
