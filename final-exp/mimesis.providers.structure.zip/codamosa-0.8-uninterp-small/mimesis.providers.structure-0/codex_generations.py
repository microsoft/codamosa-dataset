

# Generated at 2022-06-25 21:06:27.471637
# Unit test for method html_attribute_value of class Structure

# Generated at 2022-06-25 21:06:29.465500
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value("span", "class")
    assert structure.html_attribute_value("a", "href")
    assert structure.html_attribute_value("div", "id")
    assert structure.html_attribute_value("video", "autoplay")
    assert structure.html_attribute_value("div", "style")

# Generated at 2022-06-25 21:06:40.701734
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    structure_0 = Structure()

    # Test cases
    # description: Test case - All Not Null
    # input: tag = None, attribute = None
    # expected: 'Not None'
    # output: structure_0.html_attribute_value(tag = None, attribute = None)

    try:
        attribute_value = structure_0.html_attribute_value(tag = None, attribute = None)
        assert(attribute_value is not None)
    except:
        raise

    # description: Test case - tag Not Null, attribute Null
    # input: tag = 'html', attribute = None
    # expected: 'Not None'
    # output: structure_0.html_attribute_value(tag = 'html', attribute = None)


# Generated at 2022-06-25 21:06:46.213078
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    assert structure_0.html_attribute_value() == 'Scripting in Python is easy' or 'Scripting in Python is easy' == structure_0.html_attribute_value() or 'Scripting in Python is easy' == structure_0.html_attribute_value(), 'Failed for Method: html_attribute_value of class Structure'


# Generated at 2022-06-25 21:06:58.499738
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    tag = "a"

    attr = "rel"
    value = structure_0.html_attribute_value(tag, attr)
    print("value of a.rel: ", value)

    attr = "href"
    value = structure_0.html_attribute_value(tag, attr)
    print("value of a.href: ", value)

    print("")
    tag = "img"

    attr = "style"
    value = structure_0.html_attribute_value(tag, attr)
    print("value of img.style: ", value)

    attr = "src"
    value = structure_0.html_attribute_value(tag, attr)
    print("value of img.src: ", value)

    print("")
    tag = "span"



# Generated at 2022-06-25 21:07:09.548004
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # case_0 = Structure.html_attribute_value('base')
    # assert isinstance(case_0, str)
    print('This method returns str')
    structure_0 = Structure()
    assert isinstance(structure_0.html_attribute_value() , str)
    # assert isinstance(Structure.html_attribute_value(), str)
    # assert isinstance(Structure.html_attribute_value('base', 'data-id'), str)
    # assert isinstance(Structure.html_attribute_value(attribute='data-id'), str)
    assert isinstance(structure_0.html_attribute_value('base', 'data-id'), str)
    base_with_data_id = '<base data-id="{}">'.format(Structure().html_attribute_value('base', 'data-id'))

# Generated at 2022-06-25 21:07:11.873866
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    assert structure_0.html_attribute_value(tag='img', attribute='alt') == 'img'
    assert structure_0.html_attribute_v

# Generated at 2022-06-25 21:07:13.964636
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    prop = structure.css_property()
    assert isinstance(prop, str)


# Generated at 2022-06-25 21:07:17.993863
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    # This test case should be successful
    assert structure_1.html_attribute_value('a', 'href').__class__ is str
    # This test case should raise NotImplementedError
    try:
        structure_1.html_attribute_value('a', 'class')
    except NotImplementedError:
        assert True

# Generated at 2022-06-25 21:07:26.584367
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    # Testing for tag "form"
    tag = "form"
    # Testing for attribute "action"
    attribute = "action"
    structure_1 = Structure()
    structure_1.html_attribute_value()
    # Testing for attribute "accept"
    attribute = "accept"
    structure_1 = Structure()
    structure_1.html_attribute_value()
    # Testing for attribute "accept-charset"
    attribute = "accept-charset"
    structure_1 = Structure()
    structure_1.html_attribute_value()
    # Testing for attribute "enctype"
    attribute = "enctype"
    structure_1 = Structure()
    structure_1.html_attribute_value()
    # Testing for attribute "method"
    attribute = "method"
    structure_

# Generated at 2022-06-25 21:07:39.639022
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()
    assert len(structure_1.css_property()) > 0


# Generated at 2022-06-25 21:07:40.814526
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()
    structure_1.css_property()


# Generated at 2022-06-25 21:07:46.469619
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    assert structure_0.html_attribute_value()
    assert structure_0.html_attribute_value(tag='img')
    assert structure_0.html_attribute_value(attribute='download')
    assert structure_0.html_attribute_value(attribute='crossorigin')
    assert structure_0.html_attribute_value(attribute='src')
    assert structure_0.html_attribute_value(attribute='style')
    assert structure_0.html_attribute_value(tag='picture',
                                            attribute='sizes')
    assert structure_0.html_attribute_value(tag='picture',
                                            attribute='srcset')
    assert structure_0.html_attribute_value(tag='picture',
                                            attribute='type')

# Generated at 2022-06-25 21:07:52.815736
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    # Test with random choice supported tag and attribute
    result = structure.html_attribute_value()
    assert HTML_CONTAINER_TAGS['a']['href']
    # Test with random choice supported tag and attribute
    result = structure.html_attribute_value(tag='a', attribute='href')
    assert HTML_CONTAINER_TAGS['a']['href']



# Generated at 2022-06-25 21:07:55.705095
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    structure.random.seed(0)

    assert structure.css_property() == 'line-height: 1.2'

# Test for method css_property of class Structure

# Generated at 2022-06-25 21:07:57.413889
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert type(structure.css_property()) == str


# Generated at 2022-06-25 21:07:59.238944
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    cls = Structure()
    assert any(cls.css_property() for i in range(100))


# Generated at 2022-06-25 21:08:06.048461
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    # Generate a random attribute value
    tag_1 = structure_1.random.choice(
        list(HTML_CONTAINER_TAGS.keys()),
    )
    attribute_1 = structure_1.random.choice(
        list(HTML_CONTAINER_TAGS[tag_1]),  # type: ignore
    )
    attribute_value_1 = structure_1.html_attribute_value(
        tag_1, attribute_1)
    print(attribute_value_1)



# Generated at 2022-06-25 21:08:08.542577
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    result = structure_0.html_attribute_value('a', 'href')
    assert structure_0.__inet.home_page() == result


# Generated at 2022-06-25 21:08:10.905999
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_ = Structure()
    result = structure_.css_property()
    print(result)


# Generated at 2022-06-25 21:08:44.251062
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()

    tag = 'div'
    attribute = 'style'
    assert structure.html_attribute_value(tag, attribute) == structure.css_property()

    tag = 'div'
    attribute = 'id'
    assert structure.html_attribute_value(tag, attribute) == structure.html_attribute_value(tag, attribute)

    tag = 'div'
    attribute = 'class'
    assert structure.html_attribute_value(tag, attribute) == structure.html_attribute_value(tag, attribute)

    tag = 'div'
    attribute = 'title'
    assert structure.html_attribute_value(tag, attribute) == structure.html_attribute_value(tag, attribute)



# Generated at 2022-06-25 21:08:52.772196
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    ok = True
    structure_0 = Structure()
    for i in range(10):
        tag = structure_0.random.choice(list(HTML_CONTAINER_TAGS))
        attribute = structure_0.random.choice(
            list(HTML_CONTAINER_TAGS[tag]))
        try:
            value = HTML_CONTAINER_TAGS[tag][attribute]  # type: ignore
        except KeyError:
            raise NotImplementedError(
                'Tag {} or attribute {} is not supported'
                .format(tag, attribute))
        if isinstance(value, list):
            value = structure_0.random.choice(value)
            html_attribute_value = structure_0.html_attribute_value(tag,
                                                                    attribute)

# Generated at 2022-06-25 21:08:55.246135
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    p = s.css_property()
    assert p is not None


# Generated at 2022-06-25 21:09:03.858359
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert isinstance(s.html_attribute_value(), str)
    assert isinstance(s.html_attribute_value('a'), str)
    assert isinstance(s.html_attribute_value(attribute='class'), str)
    assert isinstance(s.html_attribute_value('a', 'href'), str)
    assert isinstance(s.html_attribute_value('a', 'data-foo'), str)
    assert isinstance(s.html_attribute_value('a', 'class'), str)
    assert isinstance(s.html_attribute_value('div', 'style'), str)
    assert isinstance(s.html_attribute_value('div', 'id'), str)


# Generated at 2022-06-25 21:09:12.016093
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    assert structure_0.html_attribute_value("input", "type") in ['number', 'password', 'text']
    assert structure_0.html_attribute_value(attribute='id') in ['id', 'class', 'name']
    assert structure_0.html_attribute_value("input", "class") in ['form-control']
    assert structure_0.html_attribute_value() in ['id', 'class', 'name']
    assert structure_0.html_attribute_value("input", "placeholder") in ['Enter name...']
    assert structure_0.html_attribute_value("textarea", "placeholder") in ['Type your comment...']
    assert structure_0.html_attribute_value("textarea", "autocomplete") in ['on', 'off']
    assert structure_0.html_attribute

# Generated at 2022-06-25 21:09:18.393003
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure0 = Structure()
    tag0 = 'img'
    attribute0 = 'src'
    assert structure0.html_attribute_value(tag0, attribute0) == "http://www.w3.org/2000/svg"
    tag1 = 'h1'
    attribute1 = 'id'
    assert structure0.html_attribute_value(tag1, attribute1) == "1"


# Generated at 2022-06-25 21:09:20.262739
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    assert structure_0.css_property() == 'background-color: #636b61'


# Generated at 2022-06-25 21:09:26.317706
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    tag = structure_1.random.choice(list(HTML_CONTAINER_TAGS))
    attribute = structure_1.random.choice(list(HTML_CONTAINER_TAGS[tag]))
    assert structure_1.html_attribute_value(tag=tag, attribute=attribute) != None


# Generated at 2022-06-25 21:09:29.215624
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CssAttribute as cssa
    s = Structure()
    for i in range(50):
        css = s.css_property()
        assert css.split(':')[0] in list(cssa)
        

# Generated at 2022-06-25 21:09:31.619607
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    structure_0.html_attribute_value('a', 'align')

# Generated at 2022-06-25 21:09:58.117561
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()

    assert isinstance(structure_0.css_property(), str)


# Generated at 2022-06-25 21:10:02.203795
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure(locale="en")
    assert re.match(r"(\w[-]\w[-]?\w?): (\w[-]\w[-]?\w?)$", structure.css_property())


# Generated at 2022-06-25 21:10:09.044203
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    for i in range(10):
        tag = structure_0.random.choice(list(HTML_CONTAINER_TAGS.keys()))
        attr = structure_0.random.choice(
            list(HTML_CONTAINER_TAGS[tag]),  # type: ignore
        )
        val = structure_0.html_attribute_value(tag, attr)
        assert val, 'html_attribute_value returned an empty string'



# Generated at 2022-06-25 21:10:15.094331
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    structure_1 = Structure()
    assert structure_1.html_attribute_value() == structure_1.html_attribute_value()
    assert structure_1.html_attribute_value() == structure_1.html_attribute_value()
    assert structure_1.html_attribute_value() == structure_1.html_attribute_value()
    assert structure_1.html_attribute_value() == structure_1.html_attribute_value()


# Generated at 2022-06-25 21:10:16.374110
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() in CSS_PROPERTIES


# Generated at 2022-06-25 21:10:21.872525
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    tags = list(HTML_CONTAINER_TAGS.keys())
    
    # Selection of tag
    tag = structure_0.random.choice(tags)

    # Selection of attributes
    attributes = list(HTML_CONTAINER_TAGS[tag])
    attr = structure_0.random.choice(attributes)
    
    # Execution of the tested method
    result = structure_0.html_attribute_value(tag, attr)

    # Check 1/2 if result is of type String
    if not isinstance(result, str):
        raise TypeError("Expected String, got {}".format(type(result)))

    # Check 2/2 if result is in the list of attribute values
    if not result in structure_0.HTML_CONTAINER_TAGS[tag][attr]:
        raise

# Generated at 2022-06-25 21:10:24.956244
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    print("Test Structure css_property", end = "")
    s = Structure()
    _ = s.css_property()
    print(" - ", end = "")
    assert True


# Generated at 2022-06-25 21:10:28.963770
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    for i in range(5):
        print(s.css_property())

# Generated at 2022-06-25 21:10:33.415637
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    structure_0.html_attribute_value('tag','attribute')
    structure_0.html_attribute_value()
    structure_0.html_attribute_value()
    structure_0.html_attribute_value()
    structure_0.html_attribute_value()
    structure_0.html_attribute_value()


# Generated at 2022-06-25 21:10:34.704997
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()
    assert isinstance(structure_1.css_property(), str)
