

# Generated at 2022-06-25 21:06:22.006671
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    structure_0.css_property()


# Generated at 2022-06-25 21:06:24.650553
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    for tag, attributes in HTML_CONTAINER_TAGS.items():
        for attribute in attributes:
            structure_1.html_attribute_value(tag, attribute)



# Generated at 2022-06-25 21:06:37.072848
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    assert 'background-color' in structure_0.css_property()
    assert 'background-color' in structure_0.css_property()
    assert 'background-color' in structure_0.css_property()
    assert 'background-color' in structure_0.css_property()
    assert 'background-color' in structure_0.css_property()
    assert 'background-color' in structure_0.css_property()
    assert 'background-color' in structure_0.css_property()
    assert 'background-color' in structure_0.css_property()
    assert 'background-color' in structure_0.css_property()
    assert 'background-color' in structure_0.css_property()


# Generated at 2022-06-25 21:06:41.463268
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a', 'charset') == 'word'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('div', 'style') == 'css'



# Generated at 2022-06-25 21:06:52.007091
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    assert structure_0.html_attribute_value(tag='div', attribute='id') == 'paragraph'
    assert structure_0.html_attribute_value(tag='div', attribute='class') == 'form-group'
    assert structure_0.html_attribute_value(tag='input', attribute='class') == 'btn'
    assert structure_0.html_attribute_value(tag='input', attribute='type') == 'checkbox'
    assert structure_0.html_attribute_value(tag='textarea', attribute='class') == 'form-control'
    assert structure_0.html_attribute_value(tag='textarea', attribute='style') == 'width: 100%'


# Generated at 2022-06-25 21:07:03.395620
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from random import randint
    from mimesis.builtins import CSSProperties
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text
    int_0 = Internet('de', seed=86420455)
    int_1 = Internet(seed=86420455)
    str_0 = Text(locale='ja', seed=86420455)
    str_1 = Text(seed=86420455)
    css_props = CSSProperties(seed=86420455)
    structure_0 = Structure(seed=86420455)


# Generated at 2022-06-25 21:07:07.572943
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    tag_0 = structure_0.random.choice(list(HTML_CONTAINER_TAGS))
    attribute_0 = structure_0.random.choice(HTML_CONTAINER_TAGS[tag_0])
    assert isinstance(structure_0.html_attribute_value(tag_0, attribute_0), str)


# Generated at 2022-06-25 21:07:10.702613
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    assert(structure_1.html_attribute_value("div") == "block")


# Generated at 2022-06-25 21:07:12.305865
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()
    assert structure_1.css_property() in CSS_PROPERTIES


# Generated at 2022-06-25 21:07:14.985968
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()

    try:
        assert(isinstance(structure_0.html_attribute_value(), str))
    except NotImplementedError:
        pass


# Generated at 2022-06-25 21:07:41.855373
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()
    assert(len(structure_1.css_property()) == 0)


# Generated at 2022-06-25 21:07:44.063176
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()
    structure_0 = Structure()
    assert structure_1.css_property() != structure_0.css_property()


# Generated at 2022-06-25 21:07:45.642930
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    ans = structure_0.css_property()


# Generated at 2022-06-25 21:07:47.396495
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert Structure().css_property() in CSS_PROPERTIES.keys()


# Generated at 2022-06-25 21:07:49.433049
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()

    # Testing if css_property not raises any exceptions
    assert structure_1.css_property()



# Generated at 2022-06-25 21:07:53.503170
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    tag = 'a'
    attribute = 'href'
    assert structure_0.html_attribute_value(tag=tag, attribute=attribute) == 'url'


# Generated at 2022-06-25 21:08:03.507782
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Tag: a
    structure_0 = Structure()
    test_tag_0 = structure_0.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    test_attribute_0 = structure_0.random.choice(list(
        HTML_CONTAINER_TAGS[test_tag_0]  # type: ignore
    ))
    # print('Tag = {}, Attribute = {}'.format(test_tag_0, test_attribute_0))
    test_value_0 = structure_0.html_attribute_value(test_tag_0,
                                                    test_attribute_0)
    # print(test_value_0)
    assert isinstance(test_value_0, str)


if __name__ == '__main__':
    test_case_0()
    test_Structure

# Generated at 2022-06-25 21:08:06.904556
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()

    assert structure_0.html_attribute_value('a', 'href')

    assert structure_0.html_attribute_value('h1', 'class')

    assert structure_0.html_attribute_value('h2', 'id')

# Generated at 2022-06-25 21:08:09.000989
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    css_property_0 = Structure().css_property()
    assert css_property_0 != None
    assert type(css_property_0) == str


# Generated at 2022-06-25 21:08:13.365133
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    tag_1 = 'a'
    attribute_1 = 'href'
    assert structure_1.html_attribute_value(tag_1, attribute_1) == 'http://example.com'

    tag_2 = 'link'
    attribute_2 = 'href'
    assert structure_1.html_attribute_value(tag_2, attribute_2) == 'http://example.com'
