

# Generated at 2022-06-25 21:06:22.393690
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    str_0 = '_'
    for _ in range(1000):
        str_1 = Structure().html_attribute_value(str_0, 'a')
        str_2 = str_1.replace('.', '')
        assert str_2 in str_1


# Generated at 2022-06-25 21:06:25.302891
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    seed_0 = Structure.Meta.seed
    Structure.set_seed(seed_0)
    structure_0 = Structure()
    # Test @ 100 iteration
    for _ in range(100):
        assert_css_property(structure_0.css_property())


# Generated at 2022-06-25 21:06:28.131611
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    assert structure_0.css_property() is not None


# Generated at 2022-06-25 21:06:33.608397
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    # Test for method html_attribute_value of class Structure
    assert structure_0.html_attribute_value("\x0c", '\x15') == '\x0c', 'Incorrect html_attribute_value'


# Generated at 2022-06-25 21:06:43.379637
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Set up local variables
    structure_0 = Structure()
    tag_0 = None
    attribute_0 = None
    try:
        # Call the function
        test_result = structure_0.html_attribute_value(tag_0, attribute_0)
    except NotImplementedError:
        # Get the expected exception class
        err_class = NotImplementedError
        # Check that the expected exception class is in the exception classes
        assert err_class in structure_0.exception_class, 'Exception class ' + err_class + ' is not in the exception classes'
    else:
        # If no exception was raised
        raise AssertionError('No exception was raised: structure' + structure_0.exception_msg)


# Generated at 2022-06-25 21:06:44.249530
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert Structure.css_property(...) is not None


# Generated at 2022-06-25 21:06:46.836063
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()

    result_1 = structure_1.css_property()

    assert result_1 != '\x0c'


# Generated at 2022-06-25 21:06:51.849819
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    str_0 = '\x0c'
    class_0 = Structure()
    tag_0 = str_0
    attribute_0 = str_0
    ret_0 = class_0.html_attribute_value(tag_0, attribute_0)


# Generated at 2022-06-25 21:06:53.586107
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    structure.css_property()


# Generated at 2022-06-25 21:06:58.404163
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    # Arrange
    structure_0 = Structure()
    tag = 'div'
    attribute = 'class'

    # Act
    result = structure_0.html_attribute_value(tag, attribute)

    # Assert
    assert (result is not None and result != "")


# Generated at 2022-06-25 21:07:16.359749
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = structure.random.choice(
        list(HTML_CONTAINER_TAGS.keys()),
    )
    attribute = structure.random.choice(
        list(HTML_CONTAINER_TAGS[tag]),  # type: ignore
    )
    attribute_value = structure.html_attribute_value(tag, attribute)
    assert attribute in HTML_CONTAINER_TAGS[tag]
    assert attribute_value is not None

# Generated at 2022-06-25 21:07:17.515700
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    result = structure_1.html_attribute_value()
    assert result is not None
    assert isinstance(result, str), "TypeError: result not is str"


# Generated at 2022-06-25 21:07:26.130560
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Test 1
    structure_1 = Structure()
    
    tag_1 = 'link'
    attribute_1 = 'href'
    value_1 = structure_1.html_attribute_value(tag_1, attribute_1)

# Generated at 2022-06-25 21:07:28.937027
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    tag_test_0 = "a"
    attribute_test_0 = "href"
    assert isinstance(s.html_attribute_value(tag_test_0, attribute_test_0), str)


# Generated at 2022-06-25 21:07:34.478170
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_html_attribute_value_0 = Structure().html_attribute_value("div", "id")
    print("structure_html_attribute_value_0", structure_html_attribute_value_0)
    assert structure_html_attribute_value_0


# Generated at 2022-06-25 21:07:36.049492
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()
    structure_1.css_property()


# Generated at 2022-06-25 21:07:39.878278
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    prop = structure_0.css_property()
    assert prop.count(':') == 1
    assert prop[prop.find(':') + 2:] != ''
    assert prop.count(':') == 1
    assert prop[:prop.find(':')] in CSS_PROPERTIES.keys()


# Generated at 2022-06-25 21:07:44.171049
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()

    tag_name = str(structure.random.choice(HTML_CONTAINER_TAGS))
    attributes = HTML_CONTAINER_TAGS[tag_name]
    attribute_name = str(structure.random.choice(attributes))
    if attribute_name == 'href':
        structure.html_attribute_value(tag_name, attribute_name)
    else:
        structure.html_attribute_value(tag_name)


# Generated at 2022-06-25 21:07:46.157631
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()
    for i in range(10):
        assert structure_1.css_property() is not None


# Generated at 2022-06-25 21:07:56.975404
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    t = "h1"
    a = "id"
    v = structure_0.html_attribute_value(t, a)
    assert v
    assert type(v) is str
    t = "h1"
    a = "data-*"
    v = structure_0.html_attribute_value(t, a)
    assert v
    assert type(v) is str
    t = "h1"
    a = "id"
    v = structure_0.html_attribute_value(tag=t, attribute=a)
    assert v
    assert type(v) is str
    t = "h1"
    a = "data-*"
    v = structure_0.html_attribute_value(tag=t, attribute=a)
    assert v

# Generated at 2022-06-25 21:08:14.850036
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    try:
        structure = Structure()
        tag = 'table'
        attribute = 'border'
        # assertEqual(expect, actual)
        assertEqual('1', structure.html_attribute_value(tag, attribute))
    except NotImplementedError:
        print('Attribute type {} is not implemented'.format('number'))

