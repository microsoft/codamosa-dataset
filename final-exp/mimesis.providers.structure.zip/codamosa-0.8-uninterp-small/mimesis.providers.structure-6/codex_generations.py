

# Generated at 2022-06-25 21:06:25.056783
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    tag_0 = structure_0.random.choice(list(HTML_CONTAINER_TAGS))
    attr_0 = structure_0.random.choice(list(HTML_CONTAINER_TAGS[tag_0]))
    str_0 = structure_0.html_attribute_value(tag_0, attr_0)

# Generated at 2022-06-25 21:06:28.981722
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    prop = structure_0.css_property()
    #TODO: add assertion when possible


# Generated at 2022-06-25 21:06:40.367270
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # test for one HTML tag and one attribute
    structure_0 = Structure()
    html_result_0 = '<img src="http://example.com" alt="New">'
    assert structure_0.html_attribute_value(
        tag='img', attribute='src') == 'http://example.com'
    assert structure_0.html_attribute_value(
        tag='img', attribute='alt') == 'New'
    assert structure_0.html_attribute_value(
        tag='img', attribute='foo') == ''

    # test for one HTML tag and multiple attributes
    attribute_list_0 = ['src', 'alt', 'title']
    structure_0 = Structure()
    html_result_0 = '<img src="http://example.com" alt="New" title="New">'
    assert structure_0.html_attribute

# Generated at 2022-06-25 21:06:45.294202
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Unit test for method css_property of class Structure"""
    structure_1 = Structure()
    count = 0
    while count < 10:
        string_1 = structure_1.css_property()
        list_1 = string_1.split(':')
        assert list_1[0] in CSS_PROPERTIES
        count += 1


# Generated at 2022-06-25 21:06:47.540513
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    str_0 = structure_0.css_property()
    print(str_0)


# Generated at 2022-06-25 21:06:49.810143
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()
    structure_1.css_property()
    structure_1.css_property()


# Generated at 2022-06-25 21:07:01.397813
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()

    # test for known tag
    tag_1 = 'input'
    attribute_1 = 'autocomplete'
    value_1 = ['on', 'off']
    assert structure_1.html_attribute_value(tag_1, attribute_1) in value_1

    tag_2 = 'form'
    attribute_2 = 'action'
    assert structure_1.html_attribute_value(tag_2, attribute_2) == 'url'

    # test for unknown tag
    tag_3 = 'form'
    attribute_3 = 'param'
    assert structure_1.html_attribute_value(tag_3, attribute_3) == 'word'


# Generated at 2022-06-25 21:07:03.334327
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    tag = s.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    attribute = s.random.choice(list(HTML_CONTAINER_TAGS[tag]))
    html_attribute_value = s.html_attribute_value(tag, attribute)
    assert isinstance(html_attribute_value, str)
    assert html_attribute_value != ''

# Generated at 2022-06-25 21:07:07.164352
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    assert structure_0.html_attribute_value('a', 'href') == 'url'
    assert structure_0.html_attribute_value('div', 'class') == 'word'
    assert structure_0.html_attribute_value('body', 'style') == 'css'


# Generated at 2022-06-25 21:07:14.209752
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    list_of_tags = list(HTML_CONTAINER_TAGS.keys())
    tag = structure.random.choice(list_of_tags)
    list_of_attributes = list(HTML_CONTAINER_TAGS[tag])
    attribute = structure.random.choice(list_of_attributes)
    value = structure.html_attribute_value(tag, attribute)
    prop_type = HTML_CONTAINER_TAGS[tag][attribute]


# Generated at 2022-06-25 21:07:39.414888
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()

    # Testing method css_property with parameter seed=None
    res = structure_0.css_property()
    assert isinstance(res,str) == True
    # Testing method css_property with parameter seed="a"
    res = structure_0.css_property(seed="a")
    assert isinstance(res,str) == True
    # Testing method css_property with parameter seed=1
    res = structure_0.css_property(seed=1)
    assert isinstance(res,str) == True


# Generated at 2022-06-25 21:07:43.866286
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure().html_attribute_value(tag="div", attribute="data-foo") is not None
    assert Structure().html_attribute_value(tag="input", attribute="required") is not None
    assert Structure().html_attribute_value(tag="ul", attribute="class") is not None
    assert Structure().html_attribute_value(tag="table", attribute="aria-label") is not None
    assert Structure().html_attribute_value(tag="p", attribute="class") is not None

# Generated at 2022-06-25 21:07:47.354025
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    class_0 = Structure()
    element = HTML_CONTAINER_TAGS.keys()
    attribute = HTML_CONTAINER_TAGS[class_0.random.choice(element)]
    class_0.html_attribute_value(element, attribute)


# Generated at 2022-06-25 21:07:48.940888
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert isinstance(structure.css_property(), str)


# Generated at 2022-06-25 21:07:51.919310
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert type(structure.css_property()) == str


# Generated at 2022-06-25 21:07:55.015325
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    structure_0.html_attribute_value(tag='div', attribute='class')
    structure_0.html_attribute_value(tag='a', attribute='href')


# Generated at 2022-06-25 21:07:58.288717
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    structure_1 = Structure()
    structure_2 = Structure()
    structure_3 = Structure()
    structure_4 = Structure()
    structure_5 = Structure()
    structure_6 = Structure()


# Generated at 2022-06-25 21:08:07.881029
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    structure_2 = Structure()
    structure_3 = Structure()

    # Test positive tag value
    for HTML_tag_1 in HTML_CONTAINER_TAGS:
        for HTML_tag_2 in HTML_CONTAINER_TAGS:
            for HTML_tag_3 in HTML_CONTAINER_TAGS:

                assert isinstance(structure_1.html_attribute_value(HTML_tag_1), str)
                assert isinstance(structure_2.html_attribute_value(HTML_tag_2), str)
                assert isinstance(structure_3.html_attribute_value(HTML_tag_3), str)

    # Test random tag value
    assert isinstance(structure_1.html_attribute_value(), str)

# Generated at 2022-06-25 21:08:10.906049
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'padding: 5px' or \
           structure.css_property() == 'font-style: italic' or \
           structure.css_property() == 'background-size: cover'


# Generated at 2022-06-25 21:08:13.268260
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    test_tag = "a"
    test_attribute = "href"
    assert structure_1.html_attribute_value(test_tag, test_attribute)
