

# Generated at 2022-06-25 21:06:22.941103
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    print(structure_0.css_property())


# Generated at 2022-06-25 21:06:27.470840
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()

    test_tag_a = 'a'
    test_attribute_rel = 'rel'
    test_attribute_href = 'href'

    test_value_0 = structure_1.html_attribute_value(
        tag=test_tag_a, attribute=test_attribute_rel)
    test_value_1 = structure_1.html_attribute_value(
        tag=test_tag_a, attribute=test_attribute_href)

    assert test_value_0 in ['noopener', 'noreferrer']
    assert test_value_1 in ['/', 'https://example.com/']

# Generated at 2022-06-25 21:06:30.798490
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    structure_1.html_attribute_value(tag='a', attribute='href')
    structure_1.html_attribute_value()


# Generated at 2022-06-25 21:06:36.078829
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    t = [structure_1.html_attribute_value('a'), structure_1.html_attribute_value('img'),
         structure_1.html_attribute_value('a', 'href'), structure_1.html_attribute_value('img', 'src')]


# Generated at 2022-06-25 21:06:38.898965
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # assert __name__ == '__main__'
    structure_0 = Structure()
    assert isinstance(structure_0.css_property(), str)


# Generated at 2022-06-25 21:06:40.524529
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    assert structure_0.html_attribute_value()  # type: ignore


# Generated at 2022-06-25 21:06:52.320418
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    structure_0.random.seed(0)
    class_0_list = [
        'url',
        'hex',
    ]
    attributes_0_list = [
        'href',
        'class',
        'id',
    ]
    k_0 = structure_0.random.randint(
        0,
        len(class_0_list) - 1,
    )
    selected_attrs_0 = structure_0.random.sample(class_0_list, k=k_0)

# Generated at 2022-06-25 21:06:54.104877
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    structure_0.css_property()


# Generated at 2022-06-25 21:07:01.030040
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Test 1
    structure_1 = Structure()
    assert structure_1.css_property() in CSS_PROPERTIES
    assert structure_1.css_property() != ''

    # Test 2
    structure_2 = Structure()
    structure_2.seed(0)
    assert structure_2.css_property() in CSS_PROPERTIES
    assert structure_2.css_property() == 'height: -50px'


# Generated at 2022-06-25 21:07:04.091486
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure(seed=12345678)

    # string
    structure_1_val_0 = structure_1.css_property()

    assert isinstance(structure_1_val_0, str)


# Generated at 2022-06-25 21:07:22.497428
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    assert structure_1.html_attribute_value(tag="input", attribute="type") == "color"


# Generated at 2022-06-25 21:07:31.148086
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    # Test for tag and attribute is not set
    attr_0 = structure_0.html_attribute_value()
    assert type(attr_0) == str, "Unexpected type of attr_0"
    assert len(attr_0) > 0, "Unexpected length of attr_0"

    # Test for attribute is not set but tag is set
    attr_1 = structure_0.html_attribute_value('img')
    assert type(attr_1) == str, "Unexpected type of attr_1"
    assert len(attr_1) > 0, "Unexpected length of attr_1"

    # Test for attribute is set but tag is not set
    attr_2 = structure_0.html_attribute_value(attribute='target')

# Generated at 2022-06-25 21:07:42.078242
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    structure_0_css_property = structure_0.css_property()
    print("The returned type of the function 'css_property' is ", type(structure_0_css_property))
    print("The returned value of the function 'css_property' is ", structure_0_css_property)
    print("The returned type of the attribute of the returned value of the function 'css_property' is ", type(structure_0_css_property[0]))
    print("The returned type of the attribute of the returned value of the function 'css_property' is ", type(int(structure_0_css_property[0])))
    print("The returned type of the attribute of the returned value of the function 'css_property' is ", type(structure_0_css_property[1]))

# Generated at 2022-06-25 21:07:44.062457
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    method_result = structure_0.css_property()
    print (method_result)


# Generated at 2022-06-25 21:07:48.217848
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value("input", "type") in ['hidden', 'checkbox', 'radio', 'button', 'submit', 'file', 'text', 'password', 'datetime-local', 'color', 'number', 'datetime', 'email', 'range', 'date', 'time', 'search', 'url']


# Generated at 2022-06-25 21:07:59.239625
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('p', 'lang') == 'en'
    assert structure.html_attribute_value('p', 'style') == 'css'
    assert structure.html_attribute_value('p', 'class') == 'word'
    assert structure.html_attribute_value('p', 'title') == 'word'
    assert structure.html_attribute_value('p', 'id') == 'word'
    assert structure.html_attribute_value('div', 'lang') == 'en'
    assert structure.html_attribute_value('div', 'style') == 'css'
    assert structure.html_attribute_value('div', 'class') == 'word'
    assert structure.html_attribute_value('div', 'id') == 'word'

# Generated at 2022-06-25 21:08:04.266421
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    tag = structure_0.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    attribute = structure_0.random.choice(list(HTML_CONTAINER_TAGS[tag]))
    assert isinstance(structure_0.html_attribute_value(tag, attribute), str)


# Generated at 2022-06-25 21:08:05.915344
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    css_property_0 = structure_0.css_property()


# Generated at 2022-06-25 21:08:10.906053
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure(seed=0)
    structure_1 = Structure(seed=1)
    structure_2 = Structure(seed=2)
    structure_3 = Structure(seed=3)

    assert structure_0.css_property() == "font-style: italic"
    assert structure_1.css_property() == "font-stretch: condensed"
    assert structure_2.css_property() == "content: \"\\\"\""
    assert structure_3.css_property() == "list-style-type: upper-roman"


# Generated at 2022-06-25 21:08:17.054121
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    assert structure_1.html_attribute_value('img', 'src')
    assert structure_1.html_attribute_value('img', 'alt')
    assert structure_1.html_attribute_value('script', 'src')
    assert structure_1.html_attribute_value('script', 'async')
    assert structure_1.html_attribute_value('link', 'href')
    assert structure_1.html_attribute_value('link', 'rel')
    assert structure_1.html_attribute_value('a', 'href')
    assert structure_1.html_attribute_value('a', 'target')


# Generated at 2022-06-25 21:08:36.429333
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    prop = structure.css_property()
    assert isinstance(prop, str)
    N = 1000
    num_props = []
    for _ in range(N):
        num_props.append(structure.css_property().split(':')[0])
    num_props = set(num_props)
    assert len(num_props) == len(CSS_PROPERTIES)


# Generated at 2022-06-25 21:08:38.737078
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    attribute = structure_0.css_property()
    return attribute


# Generated at 2022-06-25 21:08:40.462181
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    structure_0 = Structure()
    assert structure_0.html_attribute_value('div', 'id') is not None


# Generated at 2022-06-25 21:08:41.944188
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert 'background-color' in Structure().css_property()


# Generated at 2022-06-25 21:08:43.419783
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_1 = Structure()
    structure_1_css_property = structure_1.css_property()


# Generated at 2022-06-25 21:08:44.476094
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure().html_attribute_value(tag='img') == ''



# Generated at 2022-06-25 21:08:46.803428
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_0 = Structure()
    result = structure_0.css_property()
    assert isinstance(result, str)
    assert len(result) > 0
    assert result[0] in '._-'


# Generated at 2022-06-25 21:08:56.717916
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    test_data_1 = ('html_attribute_value', '', 'class')
    result_1 = structure_1.html_attribute_value(test_data_1[1],test_data_1[2])

    test_data_2 = ('html_attribute_value', 'div', 'class')
    result_2 = structure_1.html_attribute_value(test_data_2[1],test_data_2[2])

    test_data_3 = ('html_attribute_value', 'div', 'contenteditable')
    result_3 = structure_1.html_attribute_value(test_data_3[1],test_data_3[2])

    test_data_4 = ('html_attribute_value', 'div', 'data-*')
    result_4 = structure_1

# Generated at 2022-06-25 21:09:04.919619
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test if method html_attribute_value returns some valid value for specified HTML tag attribute.

    Cases:
        1. If tag is not specified then random tag is chosen
        2. If attribute is not specified then random attribute is chosen
        3. If tag or attribute is not supported then NotImplementedError is raised
        4. If tag is specified but attribute is not supported by this tag then NotImplementedError is raised

    """
    structure = Structure()

# Generated at 2022-06-25 21:09:05.688355
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    Structure.html_attribute_value()


# Generated at 2022-06-25 21:09:36.328017
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    tag_0 = 'tag_0'
    attribute_0 = 'attribute_0'
    try:
        result_0 = structure_0.html_attribute_value(tag_0, attribute_0)
    except NotImplementedError:
        print("Tag {:s} or attribute {:s} is not supported".format(tag_0, attribute_0))


# Generated at 2022-06-25 21:09:39.538014
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    assert structure_0.html_attribute_value('html', 'lang') == 'word'
    assert structure_0.html_attribute_value('p', 'style') == 'css'
    assert structure_0.html_attribute_value('a', 'href') == 'url'



# Generated at 2022-06-25 21:09:43.655896
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    tag = "p"
    attribute = "class"
    structure_0.html_attribute_value(tag, attribute)


# Generated at 2022-06-25 21:09:47.412522
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    assert structure_1.html_attribute_value()
    assert structure_1.html_attribute_value(tag='header', attribute='align')
    assert structure_1.html_attribute_value('header', 'align')

# Generated at 2022-06-25 21:09:56.714624
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    # html_attribute_value(tag="link", attribute="rel") == "stylesheet" returns boolean True
    assert structure_0.html_attribute_value(tag="link", attribute="rel") == "stylesheet"
    # html_attribute_value(tag="link", attribute="href") is string returns boolean True
    assert isinstance(structure_0.html_attribute_value(tag="link", attribute="href"), str)
    # html_attribute_value(tag="link", attribute="href") == "https://mimesis.name/" returns boolean True
    assert structure_0.html_attribute_value(tag="link", attribute="href") == "https://mimesis.name/"
    # html_attribute_value(tag="link", attribute="type") is string returns boolean True

# Generated at 2022-06-25 21:10:00.567254
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from hypothesis import strategies as st
    from hypothesis import given, settings
    import pytest
    @settings(max_examples=20)
    @given(st.integers(min_value=0, max_value=CSS_PROPERTIES.__len__()-1))
    def test_for_x(x):
        if x > CSS_PROPERTIES.__len__():
            pytest.raises(AssertionError)
        css_prop = Structure.css_property()
        assert css_prop
    test_for_x()


# Generated at 2022-06-25 21:10:08.973432
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    assert isinstance(structure_0.html_attribute_value(), str)
    assert isinstance(structure_0.html_attribute_value(None, None), str)
    assert isinstance(structure_0.html_attribute_value('div', 'title'), str)
    assert isinstance(structure_0.html_attribute_value(None, 'title'), str)
    assert isinstance(structure_0.html_attribute_value('div', None), str)


# Generated at 2022-06-25 21:10:11.020814
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_1 = Structure()
    tag_1, attribute_1 = "a", "href"
    assert structure_1.html_attribute_value(tag_1, attribute_1) != None


# Generated at 2022-06-25 21:10:19.111226
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_0 = Structure()
    assert structure_0.html_attribute_value(tag="div", attribute="style") == "background-color: #094706"
    assert structure_0.html_attribute_value(tag="a", attribute="rel") == "follow"
    assert structure_0.html_attribute_value(tag="a", attribute="href") == "https://www.google.com"
    assert structure_0.html_attribute_value(tag="img", attribute="id") == "73b5054d-9e99-4fe5-874d-a4ff4a33a59f"
    assert structure_0.html_attribute_value(tag="img", attribute="alt") == "ipsum"

# Generated at 2022-06-25 21:10:20.133827
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_obj = Structure()
    structure_obj.css_property()
