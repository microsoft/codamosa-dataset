

# Generated at 2022-06-23 21:40:54.292514
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    test_object = Structure()
    assert isinstance(test_object.css_property(), str)


# Generated at 2022-06-23 21:40:57.039432
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() in CSS_PROPERTIES

# Generated at 2022-06-23 21:41:00.836267
# Unit test for method css of class Structure
def test_Structure_css():
    """Unit test for method css of class Structure."""
    print ("\nTEST: Structure.css")
    structure = Structure('en')
    print (structure.css())



# Generated at 2022-06-23 21:41:04.058399
# Unit test for method css of class Structure
def test_Structure_css():
    # Create an instance of class Structure
    s = Structure()
    # Invoke method css() of class Structure
    result = s.css()
    # Check whether result is of type str
    assert(isinstance(result, str))


# Generated at 2022-06-23 21:41:05.657003
# Unit test for constructor of class Structure
def test_Structure():
    """Unit test for constructor of class Structure."""
    pass

# Generated at 2022-06-23 21:41:07.011600
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure('en')
    assert 'Structure' == structure.__class__.__name__

# Generated at 2022-06-23 21:41:18.363327
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    data_provider = Structure(seed=1)
    assert data_provider.html_attribute_value() == '#CD9095'
    assert data_provider.html_attribute_value() == '#3C8844'
    assert data_provider.html_attribute_value('html', 'lang') == 'en'
    assert data_provider.html_attribute_value('html', 'version') == 5
    assert data_provider.html_attribute_value('b') == 'bold'
    assert data_provider.html_attribute_value('div', 'align') == 'right'
    assert data_provider.html_attribute_value('head', 'profile') == '#CADEE7'
    assert data_provider.html_attribute_value('head', 'profile') == '#D81E5B'
   

# Generated at 2022-06-23 21:41:20.396110
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure(seed = 1)
    assert isinstance(structure.css_property(), str)

# Generated at 2022-06-23 21:41:24.081298
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure('en')
    tag = 'a'
    attribute = 'href'
    expected = 'http://www.douglasrussel.com/'
    assert structure.html_attribute_value(tag, attribute) == expected

# Generated at 2022-06-23 21:41:24.977991
# Unit test for method css of class Structure
def test_Structure_css():
	css_obj = Structure()
	css_obj.css()


# Generated at 2022-06-23 21:41:32.335154
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import MediaType
    from mimesis.schema import Field, Schema
    from mimesis.enums import Gender, MarkupAttribute

    class Character(Schema):
        name = Field(data_provider=Structure.html, tags=[MediaType.TEXT.value])
        color = Field(data_provider=Structure.html_attribute_value,
                      tags=[MarkupAttribute.BACKGROUND_COLOR.value, MediaType.TEXT.value])
        # If the type of value is not specified, it is expected to be a list
        # Thus, generated value is a list if the type is not specified
        city = Field(data_provider=Structure.html_attribute_value,
                      tags=[MarkupAttribute.CLASS.value, MediaType.TEXT.value])

# Generated at 2022-06-23 21:41:36.063941
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st_1 = Structure('en',seed=None)
    for i in range(0,100):
        print(st_1.css_property())


# Generated at 2022-06-23 21:41:47.204462
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    structure = Structure()

# Generated at 2022-06-23 21:41:49.902365
# Unit test for method html of class Structure
def test_Structure_html():
    """Check the method html of class Structure."""
    s = Structure()
    print(s.html())
    assert '<span>' in s.html()

# Generated at 2022-06-23 21:41:57.319763
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # test method with all attributes
    s = Structure('en')
    for tag in HTML_CONTAINER_TAGS:
        for attribute in HTML_CONTAINER_TAGS[tag]:
            assert s.html_attribute_value(tag, attribute)

    # test method with all attributes and different languages
    s = Structure('ru')
    for tag in HTML_CONTAINER_TAGS:
        for attribute in HTML_CONTAINER_TAGS[tag]:
            assert s.html_attribute_value(tag, attribute)

    # test method with specific tag
    s = Structure('en')
    tag = 'span'
    for attribute in HTML_CONTAINER_TAGS[tag]:
        assert s.html_attribute_value(tag, attribute)

    # test method with specific tag and different languages
    s = Structure('ru')
   

# Generated at 2022-06-23 21:42:01.135765
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure(seed=12345)
    print(structure.html())

if __name__ == '__main__':
    test_Structure_html_attribute_value()

# Generated at 2022-06-23 21:42:02.524296
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    struct = Structure()
    assert struct.css_property() in CSS_PROPERTIES

# Generated at 2022-06-23 21:42:03.624305
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    Structure().html_attribute_value()


# Generated at 2022-06-23 21:42:04.861816
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    result = structure.css()
    print(result)
    # TODO assert statement
    

# Generated at 2022-06-23 21:42:10.190739
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    newStructure = Structure()
    tag_list = list(HTML_CONTAINER_TAGS)
    attribute_list = list(HTML_CONTAINER_TAGS[newStructure.random.choice(tag_list)])
    assert newStructure.html_attribute_value(newStructure.random.choice(tag_list), newStructure.random.choice(attribute_list)) is not None

# Generated at 2022-06-23 21:42:12.404418
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure('en')
    assert (structure.__class__.__name__ == 'Structure')


# Generated at 2022-06-23 21:42:13.348995
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()
    assert struct


# Generated at 2022-06-23 21:42:19.114245
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Python version
    # import sys
    # print(sys.version)

    # Mimesis version
    # from mimesis import __version__
    # print(__version__)

    # Test for CSS Property
    structure = Structure()
    output = structure.css_property()
    print(output)



# Generated at 2022-06-23 21:42:20.806995
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    result = s.css_property()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:42:24.221725
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    html_result = structure.html()
    print(html_result)
    assert (type(html_result) == str) and (len(html_result)>0)


# Generated at 2022-06-23 21:42:26.072104
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    print(structure)
    assert structure is not None


# Generated at 2022-06-23 21:42:29.966961
# Unit test for method html of class Structure
def test_Structure_html():
    import random
    seed = random.randint(1, 1000)
    st = Structure(seed = seed)
    tag = st.random.choice(list(st.HTML_CONTAINER_TAGS))
    print(st.html(tag))


# Generated at 2022-06-23 21:42:36.762605
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    html_attribute_value_result = Structure().html_attribute_value(tag=list(
        HTML_CONTAINER_TAGS)[0], attribute=list(HTML_CONTAINER_TAGS[list(
            HTML_CONTAINER_TAGS)[0]])[0])
    assert isinstance(html_attribute_value_result, str) == True
    assert len(html_attribute_value_result) > 0


# Generated at 2022-06-23 21:42:39.526643
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    property = structure.css_property()
    assert isinstance(property, str)
    print('Type: {}, Value: {}'.format(type(property), property))


# Generated at 2022-06-23 21:42:41.598211
# Unit test for method html of class Structure
def test_Structure_html():
    # create the object S
    S = Structure('en')
    # call the method html and test the result
    tag_html = S.html()
    print('tag_html=',tag_html)
    assert len(tag_html)>=6


# Generated at 2022-06-23 21:42:42.549272
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    obj = Structure()
    res = obj.html_attribute_value()
    assert res

# Generated at 2022-06-23 21:42:46.194912
# Unit test for method css of class Structure
def test_Structure_css():
    """Test method Structure.css() in class Structure."""
    s = Structure(seed=1)
    assert isinstance(s.css(), str)


# Generated at 2022-06-23 21:42:48.472912
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    structure.html()
    structure.html('a')
    structure.html('a','href')

# Generated at 2022-06-23 21:42:51.142299
# Unit test for method html of class Structure
def test_Structure_html():
    test = Structure(seed=1234)
    html = test.html()
    print('HTML page is {}'.format(html))


# Generated at 2022-06-23 21:42:57.378229
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import HtmlTagAttribute as hta
    from mimesis.enums import HtmlTag as ht

    structure = Structure()
    for tag in ht:
        for attribute in hta:
            value = structure.html_attribute_value(tag.value, attribute.value)
            if not value:
                raise ValueError('Tag {} or attribute {} is not supported'.format(tag.value, attribute.value))

# Generated at 2022-06-23 21:43:01.986589
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure('en', seed=4)
    expected = '<section class="equipment_emend_reactive plant_deliver" id="constraint_determine" lang="an">Tgjfexmi yxshy ywnd.</section>'
    assert structure.html() == expected

# Generated at 2022-06-23 21:43:06.114463
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    css = Structure()
    value = 'align-content: stretch'
    print('align-content', css.html_attribute_value('style', 'css'), '',
          value)



# Generated at 2022-06-23 21:43:08.085837
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure('en')
    assert isinstance(structure.css(), str)

# Generated at 2022-06-23 21:43:11.618680
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    for i in range(100):
        actual = Structure().css_property()
        assert ":" in actual
        assert actual[::-1][0] != ":"
        assert actual[::-1][0] != " "


# Generated at 2022-06-23 21:43:14.027227
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    result = structure.html_attribute_value('span', 'style')
    assert isinstance(result, str)
    assert result



# Generated at 2022-06-23 21:43:18.053051
# Unit test for constructor of class Structure
def test_Structure():
    test = Structure()
    c = test.css()
    assert isinstance(c, str)
    print("test_Structure: ")
    print("css:", c)

    d = test.html()
    assert isinstance(d, str)
    print("html:", d)



# Generated at 2022-06-23 21:43:19.601286
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure('en')
    html_result = structure.html()
    assert structure.html() == html_result

# Generated at 2022-06-23 21:43:21.344037
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Testing"""
    struc = Structure()
    print(struc.css_property())


# Generated at 2022-06-23 21:43:24.468968
# Unit test for method html of class Structure
def test_Structure_html():
    st = Structure()
    a = st.html()
    # print(a)
    assert(True if a else False)
    assert(a.strip() != "")

# Generated at 2022-06-23 21:43:26.145628
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()
    for i in range(1,10):
        print(i)
        print(struct.css())
        print(struct.html())

test_Structure()

# Generated at 2022-06-23 21:43:31.979541
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    import mimesis.builtins
    from mimesis.providers.structure import Structure
    s = Structure(mimesis.builtins.DEFAULT_LOCALE, 10)
    assert isinstance(s.html_attribute_value(), str)
    assert isinstance(s.html_attribute_value('a', 'href'), str)
    assert isinstance(
        s.html_attribute_value('input', 'type'),
        str,
    )
    assert isinstance(
        s.html_attribute_value('input', 'formaction'),
        str,
    )



# Generated at 2022-06-23 21:43:38.224543
# Unit test for method css of class Structure
def test_Structure_css():
    # Create an instance of class Structure
    structure = Structure()
    # Create an instance of class Text in order to be able to use its method word()
    text = Text('en')
    result = structure.css()
    # Split the output string by white space
    result_split = result.split()

    # Store the first value from result_split
    css_selector = result_split[0]
    # Remove '{' from the last character of css_selector
    css_selector = css_selector[:-1]

    # Check whether css_selector is a valid css selector.
    # If it is, then css_selector will be split by '>' ,
    # otherwise it will be split by '.'
    # The results will be stored in the first element of the list called css_selector

# Generated at 2022-06-23 21:43:38.903607
# Unit test for constructor of class Structure
def test_Structure():
    pass

# Generated at 2022-06-23 21:43:40.628140
# Unit test for constructor of class Structure
def test_Structure():
    structure_1 = Structure()
    assert structure_1



# Generated at 2022-06-23 21:43:42.265657
# Unit test for method css of class Structure
def test_Structure_css():
    struct = Structure(seed=123)
    print(struct.css())


# Generated at 2022-06-23 21:43:44.588854
# Unit test for constructor of class Structure
def test_Structure():
    obj = Structure()
    assert obj.__class__.__name__ == 'Structure'


# Generated at 2022-06-23 21:43:50.906409
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    success_cases = [
        ('table', 'align', ['left', 'right', 'center', 'justify', 'char']),
        ('body', 'background', 'url'),
        ('h1', 'style', 'css'),
        ('video', 'poster', 'url'),
        ('video', 'src', 'url'),
        ('div', 'class', 'word'),
        ('div', 'id', 'word'),
    ]
    for case in success_cases:
        tag, attr, value = case
        value_type = type(value).__name__

# Generated at 2022-06-23 21:44:00.466286
# Unit test for method html of class Structure
def test_Structure_html():
    # Выбираем тег span
    tag_name = 'span'
    # Выбираем атрибут id
    attribute = 'id'
    # Вызываем метод html_attribute_value
    value = Structure().html_attribute_value(tag_name, attribute)
    # Результат должен быть непустая строка
    assert value != ''
    # Результат должен быть текстом
    assert isinstance(value, str)
    # Р

# Generated at 2022-06-23 21:44:05.368849
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    import pytest
    s = Structure()
    if (s.html_attribute_value(tag = 'a', attribute = 'href')):
        assert(True)
    else:
        assert(False)
    if (s.html_attribute_value(tag = 'tag', attribute = 'attribute')):
        assert(True)
    else:
        assert(False)


# Generated at 2022-06-23 21:44:07.936610
# Unit test for constructor of class Structure
def test_Structure():
    # The method should create an object for text data
    assert isinstance(Structure(), Structure)



# Generated at 2022-06-23 21:44:10.991803
# Unit test for method html of class Structure
def test_Structure_html():
    locale = 'en'
    seed = 10
    test_object = Structure(locale, seed)
    assert test_object.html() == '<caption class="caption">Obtainable need</caption>'

# Generated at 2022-06-23 21:44:20.411063
# Unit test for constructor of class Structure
def test_Structure():
    if __name__=="__main__": 
        from mimesis import Generic
        from mimesis.providers.internet import Internet
        from mimesis.providers.structure import Structure
        from mimesis.providers.text import Text

        data = Structure()
        data.seed(0)
        result = data.css()
        assert result == 'ul li em {margin-left: 54px; font: 14px Verdana; height: 54px; border-top: #ca3e1d 1px solid; border-bottom: #914d2e 2px solid; background-color: #b697a1}'

        data = Structure()
        data.seed(0)
        result = data.css_property()
        assert result == 'background-color: #f4d3a1'

        data = Structure()


# Generated at 2022-06-23 21:44:21.991083
# Unit test for constructor of class Structure
def test_Structure():
    st = Structure('zh')
    print(st.css_property)
    print(st.html())
    print(st.css_property())

if __name__ == "__main__":
    test_Structure()

# Generated at 2022-06-23 21:44:33.723043
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    x = Structure()
    tags = HTML_CONTAINER_TAGS
    css_prop = CSS_PROPERTIES
    txt = Text()
    inet = Internet()
    assert type(x.html_attribute_value()) == str
    assert x.html_attribute_value(
        tag='input', attribute='type') in tags['input']['type']
    assert x.html_attribute_value(
        tag='input', attribute='accept') in tags['input']['accept']
    assert x.html_attribute_value(
        tag='input', attribute='autocomplete') in tags['input']['autocomplete']

# Generated at 2022-06-23 21:44:34.742604
# Unit test for constructor of class Structure
def test_Structure():
    assert callable(Structure)


# Generated at 2022-06-23 21:44:43.607542
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    css_props = CSS_PROPERTIES
    # Check if all properties in css_props can return a string
    prop_str = []
    for prop in css_props:
        value = CSS_PROPERTIES.get(prop)
        if isinstance(value, list):
            value = random.choice(value)
        elif value == 'color':
            value = '#f4d3a1'
        elif value == 'size':
            value = '{}{}'.format(random.randint(1, 99),
                                  random.choice(CSS_SIZE_UNITS))
        prop_str.append('{}: {}'.format(prop, value))
    assert prop_str != None


# Generated at 2022-06-23 21:44:45.577469
# Unit test for method css of class Structure
def test_Structure_css():
    # Tests empty case, should return a string
    assert type(Structure().css()) == str


# Generated at 2022-06-23 21:44:47.601639
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s.__class__.__name__ == 'Structure'
    assert isinstance(s, Structure)
    assert isinstance(s, BaseDataProvider)


# Generated at 2022-06-23 21:44:48.771751
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    struct = Structure('en')
    struct.css_property()


# Generated at 2022-06-23 21:44:50.046235
# Unit test for method css of class Structure
def test_Structure_css():
    obj = Structure()
    assert type(obj.css()) == str


# Generated at 2022-06-23 21:44:52.015125
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    print(structure.css())


# Generated at 2022-06-23 21:44:59.385722
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Run the test 10 times
    for i in range(10):
        # Create a seed between 0 and 10
        seed=randint(0, 10)
        # Get a random CSS property
        provider = Structure(seed=seed)
        css_property = provider.css_property()
        assert(re.fullmatch('\S*:\s\S+',css_property) != None)


# Generated at 2022-06-23 21:45:02.580938
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    provider = Structure('es')
    tag = 'div'
    attribute = 'class'
    attr_value = provider.html_attribute_value(tag, attribute)
    assert attr_value is not None

# Generated at 2022-06-23 21:45:04.611420
# Unit test for constructor of class Structure
def test_Structure():
    _S = Structure(seed=123456)

    assert issubclass(Structure, BaseDataProvider)
    assert Structure.Meta.name == 'structure'

# Generated at 2022-06-23 21:45:07.135714
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    result = structure.html_attribute_value(tag='html', attribute='lang')
    print(result)

if __name__ == '__main__':
    test_Structure_html_attribute_value()

# Generated at 2022-06-23 21:45:10.742490
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    test_obj = Structure()
    test_obj.html_attribute_value(tag='a', attribute='href')
    result = test_obj.html_attribute_value()
    assert result == ''
    assert result != None
    

# Generated at 2022-06-23 21:45:16.019529
# Unit test for method html of class Structure
def test_Structure_html():
    stc = Structure('en')
    assert len(stc.html()) > 0
    # Case 1
    assert stc.html().count('<') == 1
    # Case 2
    assert stc.html().count('>') == 1
  
    # Case 3
    assert stc.html().count('</') == 1


# Generated at 2022-06-23 21:45:20.116642
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(seed=0)
    result = s.css()
    assert result == 'div#diagrams a {color: #f4d3a1; line-height: 72px; ' \
                     'font-family: cursive}'


# Generated at 2022-06-23 21:45:22.674579
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure('en')
    print(s.css())
    print(s.css())
    print(s.html())
    print(s.html())
    print(s.html())


# Generated at 2022-06-23 21:45:32.389816
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis.data import CSS_SELECTORS, CSS_SIZE_UNITS
    from mimesis.providers.internet import Internet
    import re
    import unittest

    class TestStructureClass(Structure):
        # Override __init__ method to remove side-effecting code which depends on random
        def __init__(self, seed=None):
            super().__init__(seed=seed)
            # Set the size of sample when selecting properties
            self.sample_size = 1

    strct = TestStructureClass(seed=4321)
    css = strct.css()
    selector = r'[^{]*{\s*'
    property = r'[-a-zA-Z]+:[#a-f0-9]+\s*;\s*'
    closing = r'}'
   

# Generated at 2022-06-23 21:45:44.293356
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    selector = s.random.choice(CSS_SELECTORS)
    css_sel = '{}{}'.format(selector, s.__text.word())
    cont_tag = s.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    mrk_tag = s.random.choice(HTML_MARKUP_TAGS)
    base = '{}'.format(s.random.choice([cont_tag, mrk_tag, css_sel]))
    props = '; '.join([s.css_property() for _ in range(s.random.randint(1, 6))])
    css = '{} {{{}}}'.format(base, props)
    assert s.css() == css


# Generated at 2022-06-23 21:45:57.110612
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.exceptions import NonEnumerableError

    s = Structure(locale='ru')
    r = RussiaSpecProvider(locale='ru')

    target = s.css_property()
    assert isinstance(target, str)
    assert target.count(': ') == 1

    assert target.split(': ')[0] in CSS_PROPERTIES
    assert target.split(': ')[1] in CSS_PROPERTIES[target.split(': ')[0]]

    target = s.css_property(prop_name='background', prop_value='#F0F8FF')
    assert target == 'background: #F0F8FF'

    target = s.css_property(prop_name='align-content', prop_value='center')

# Generated at 2022-06-23 21:45:59.119243
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure(seed=0)
    assert structure.css_property() == 'list-style: lower-roman'



# Generated at 2022-06-23 21:46:00.907827
# Unit test for method css of class Structure
def test_Structure_css():
    g = Structure()
    res = g.css()
    assert str(type(res)) == "<class 'str'>"



# Generated at 2022-06-23 21:46:07.128318
# Unit test for method html of class Structure
def test_Structure_html():
    test_Structure = Structure(seed=1)
    result = test_Structure.html()
    print(result)
    expected = '<input accept="image/png,image/gif" name="profession"' \
               ' onload="info_link(\'social_networks\')" type="radio">Over' \
               ' the years, the process of creating bundles has significantly' \
               ' advanced.\n    \n'
    assert result == expected


# Generated at 2022-06-23 21:46:08.887836
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    structure.seed(5)
    print(structure.html())

# Generated at 2022-06-23 21:46:10.863058
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    tag = 'div'
    attribute = 'id'
    s = Structure()
    print(s.html_attribute_value(tag, attribute))

# Generated at 2022-06-23 21:46:23.469919
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value()



# Generated at 2022-06-23 21:46:26.825638
# Unit test for constructor of class Structure
def test_Structure():
    structure_ = Structure('en')
    assert isinstance(structure_, Structure) is True
    assert isinstance(structure_.random, random.Random) is True
    assert isinstance(structure_.seed, int) is True
    assert structure_.seed is None


# Generated at 2022-06-23 21:46:28.024872
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    prop = Structure().css_property()
    print(prop)


# Generated at 2022-06-23 21:46:30.737594
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    assert structure.css() == 'body {\n  margin: 2px;\n}'


# Generated at 2022-06-23 21:46:34.604809
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    expected = 'http://www.example.com/'
    str = Structure()
    actual = str.html_attribute_value('a','href')
    assert actual == expected, "html_attribute_value(a,href) method is not correct"


# Generated at 2022-06-23 21:46:35.902668
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() != ''

# Generated at 2022-06-23 21:46:42.580088
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.data import HTML_CONTAINER_TAGS
    # test attributes of 'a' tag.
    test_tag = 'a'
    test_attributes = HTML_CONTAINER_TAGS[test_tag]
    structure = Structure(seed=0)
    for attribute in test_attributes:
        value = structure.html_attribute_value(test_tag, attribute)
        # test if it's type str
        assert isinstance(value, str)


# Generated at 2022-06-23 21:46:44.152361
# Unit test for method css of class Structure
def test_Structure_css():
    css = Structure()
    print(css.css())


# Generated at 2022-06-23 21:46:45.211340
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    print(structure.css())  # body {background: #b17039; color: #7e9f92;}


# Generated at 2022-06-23 21:46:47.147246
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    test = Structure()
    dat = test.html_attribute_value()
    assert dat is not None


# Generated at 2022-06-23 21:46:50.139321
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    html_tag = 'a'
    attribute = 'rel'
    expected = 'stylesheet'
    assert s.html_attribute_value(html_tag, attribute) == expected


# Generated at 2022-06-23 21:46:50.763975
# Unit test for constructor of class Structure
def test_Structure():
    Structure()

# Generated at 2022-06-23 21:46:52.106911
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    assert isinstance(s.css(), str)


# Generated at 2022-06-23 21:46:53.702206
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    str_obj = Structure()
    assert(str_obj.html_attribute_value("a", "href")) == "url"

# Generated at 2022-06-23 21:46:56.878136
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure is not None

# Unit tests for css() method

# Generated at 2022-06-23 21:46:59.405442
# Unit test for method css of class Structure
def test_Structure_css():
    data = Structure()
    result = 'a {margin: 0px; display: inline;}'
    assert result  == data.css()

# Generated at 2022-06-23 21:47:00.873723
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure(seed = 123)
    print(structure.html())

# Generated at 2022-06-23 21:47:02.821813
# Unit test for constructor of class Structure
def test_Structure():
    a = Structure()
    print(a.css())
    print(a.html())
    print(a.html_attribute_value())

if __name__ == '__main__':
    test_Structure()

# Generated at 2022-06-23 21:47:05.894437
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    mimesis.seed(42)
    m = Structure()
    assert m.css_property() == 'background-color: #f4d3a1', 'Error test_Structure_css_property'

# Generated at 2022-06-23 21:47:13.164233
# Unit test for method html of class Structure
def test_Structure_html():
    str = Structure(seed = 100)
    assert str.html() == '<input name="careers">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for  will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</input>'

# Generated at 2022-06-23 21:47:14.859698
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    print(structure.html())


# Generated at 2022-06-23 21:47:15.563300
# Unit test for method css of class Structure
def test_Structure_css():
    structure_object = Structure()
    structure_object.css()

# Generated at 2022-06-23 21:47:16.295194
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    result = s.html()
    assert result != None

# Generated at 2022-06-23 21:47:18.012162
# Unit test for constructor of class Structure
def test_Structure():
    unit = Structure("en")
    assert unit.Meta.name == 'structure'



# Generated at 2022-06-23 21:47:21.320878
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    expected_structure = {"tag": "div", "attribute": "style"}
    expected_output = 'width: 40px; height: 40px'
    assert s.html_attribute_value(tag='div', attribute='style') in expected_output

# Generated at 2022-06-23 21:47:23.544384
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    result = structure.html_attribute_value(tag='div',attribute='id')
    assert (result == 'word')

# Generated at 2022-06-23 21:47:25.251916
# Unit test for constructor of class Structure
def test_Structure():
    test = Structure("en")
    assert (test != None)


# Generated at 2022-06-23 21:47:33.006871
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure(seed=0)
    assert s.css_property() == 'color: #d8dffa'
    assert s.css_property() == 'color: #25a7d4'
    assert s.css_property() == 'color: #f3dbd1'
    assert s.css_property() == 'color: #b4b60f'
    assert s.css_property() == 'color: #9a89c2'
    assert s.css_property() == 'color: #3b86a9'
    assert s.css_property() == 'color: #d5d5c5'
    assert s.css_property() == 'color: #079079'
    assert s.css_property() == 'color: #0e5e8b'
    assert s.css_property()

# Generated at 2022-06-23 21:47:38.669564
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import HtmlTag, HtmlAttribute
    from mimesis.providers.structure import Structure
    struct = Structure('ja', seed=4)
    assert struct.html_attribute_value(HtmlTag.A, HtmlAttribute.HREF) == '#'
    assert struct.html_attribute_value(HtmlTag.A, HtmlAttribute.TARGET) == '_blank'
    assert struct.html_attribute_value(HtmlTag.A, HtmlAttribute.TITLE) == '通貨のインデックス'
    assert struct.html_attribute_value(HtmlTag.BUTTON, HtmlAttribute.DISABLED) == 'disabled'

# Generated at 2022-06-23 21:47:42.542416
# Unit test for method html of class Structure
def test_Structure_html():
    """Test for Structure.html.

    For each of 100 iterations, check that the result of method html of class Structure
    is a string and contains "<", " ", and ">"
    """
    structure = Structure('en')
    for i in range(100):
        assert isinstance(structure.html(), str)
        assert(' ' in structure.html())
        assert('<' in structure.html())
        assert('>' in structure.html())

# Generated at 2022-06-23 21:47:44.445926
# Unit test for method css of class Structure
def test_Structure_css():
    #This function is just used for test code.
    structure = Structure('en')
    print(structure.css())


# Generated at 2022-06-23 21:47:46.736625
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # for 'a' tag, attribute 'href' has value 'url'
    st = Structure()
    assert st.html_attribute_value('a', 'href').startswith('http://')
    return True


# Generated at 2022-06-23 21:47:53.479009
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import HTMLTag, HTMLAttribute

    tag = HTMLTag.DIV
    attr = HTMLAttribute.CLASS

    # invoke method html with one or two parameters
    inet = Structure()
    html_tag = inet.html(tag, attr)
    print(html_tag)

    # invoke method html with no parameter
    html_tag = inet.html()
    print(html_tag)


# Generated at 2022-06-23 21:47:55.165916
# Unit test for method html of class Structure
def test_Structure_html():
    """Test method html of class Structure."""
    concrete_str = Structure()
    assert concrete_str.html()



# Generated at 2022-06-23 21:47:57.651169
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure('en')
    structure_html = structure.html()
    assert type(structure_html) == str


# Generated at 2022-06-23 21:47:58.709085
# Unit test for method html of class Structure
def test_Structure_html():
    print(Structure().html())

# Generated at 2022-06-23 21:48:01.051798
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value("a", "href") == "https://google.com"


# Generated at 2022-06-23 21:48:02.549948
# Unit test for constructor of class Structure
def test_Structure():
    # Call constructor
    Structure()
    assert True


# Generated at 2022-06-23 21:48:06.060274
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    print(s.css())
    print(s.css_property())
    print(s.html())
    print(s.html_attribute_value())
    print(s.html_attribute_value('a','rel'))


# Generated at 2022-06-23 21:48:13.660701
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    str = Structure()

    tags = ['a', 'iframe', 'video', 'audio']
    attributes = ['style', 'onerror', 'onabort', 'onclick', 'id', 'class']

    for i in range(4):
        tag = tags[i]

        for attr in attributes:
            value = str.html_attribute_value(tag, attr)
            print("tag: {}; attr: {}; attr value: {}".format(tag, attr, value))

# Generated at 2022-06-23 21:48:16.149469
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # We know that 'lang' attribute of tag 'html' is of type 'word'
    a = Structure()
    assert a.html_attribute_value('html', 'lang').isalpha() is True

# Generated at 2022-06-23 21:48:17.902156
# Unit test for constructor of class Structure
def test_Structure():
    str = Structure()


# Generated at 2022-06-23 21:48:19.021641
# Unit test for method css of class Structure
def test_Structure_css():
    provider = Structure()
    print(provider.css())



# Generated at 2022-06-23 21:48:23.052635
# Unit test for method html of class Structure
def test_Structure_html():

    mimesis_structur = Structure(seed=1248)
    assert mimesis_structur.html() == '<div class="courses" ' \
                                      'id="buy" itemscope ' \
                                      'itemtype="https://about.html">' \
                                      'Tincture of opium, but it was ' \
                                      'opened.</div>'


# Generated at 2022-06-23 21:48:25.607710
# Unit test for method css of class Structure
def test_Structure_css():
    struct = Structure()
    css = struct.css()
    assert isinstance(css, str)
    assert css
    assert len(css) > 10
    assert css.count(';') > 0
    assert css.count(':') > 0


# Generated at 2022-06-23 21:48:29.470145
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    import mimesis
    a = mimesis.Structure()
    print(a.css_property())


# Generated at 2022-06-23 21:48:32.960162
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Test for method css_property of class Structure."""
    provider = Structure()
    result = provider.css_property()

    assert(isinstance(result, str))
    assert(len(result) > 0)


# Generated at 2022-06-23 21:48:34.476280
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    structure.html_attribute_value('a', 'href')


# Generated at 2022-06-23 21:48:46.288649
# Unit test for method html of class Structure
def test_Structure_html():
    html_result = '<{tag} {attrs}>{content}</{tag}>'
    structure = Structure()
    tag_name = structure.random.choice(list(HTML_CONTAINER_TAGS))
    tag_attributes = list(HTML_CONTAINER_TAGS[tag_name])  # type: ignore
    k = structure.random.randint(1, len(tag_attributes))
    
    selected_attrs = structure.random.sample(tag_attributes, k=k)

    attrs = []
    for attr in selected_attrs:
        attrs.append('{}="{}"'.format(
            attr, structure.html_attribute_value(tag_name, attr)))


# Generated at 2022-06-23 21:48:48.185385
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    x = s.css_property()
    assert x is str 


# Generated at 2022-06-23 21:48:48.950285
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    pass

# Generated at 2022-06-23 21:48:51.058874
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    result = structure.css()
    assert len(result) > 0
    assert isinstance(result, str)


# Generated at 2022-06-23 21:48:53.691455
# Unit test for method css of class Structure
def test_Structure_css():
    s=Structure()
    print(s.css())


# Generated at 2022-06-23 21:48:56.075782
# Unit test for method css of class Structure
def test_Structure_css():
    result = Structure.css()
    assert isinstance(result, (str))
    assert isinstance(result, (str))


# Generated at 2022-06-23 21:48:59.048069
# Unit test for method css of class Structure
def test_Structure_css():
    S = Structure('en')
    for i in range(10):
        print(S.css()) # return a random snippet of CSS



# Generated at 2022-06-23 21:49:05.936416
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()
    assert struct.__class__.__name__ == 'Structure'
    assert struct.Meta.name == 'structure'
    assert struct.seed is not None
    assert struct.random is not None
    assert struct.__text.__class__.__name__ == 'Text'
    assert struct.__inet.__class__.__name__ == 'Internet'
    assert struct.__inet.seed == struct.seed
    assert struct.__text.seed == struct.seed

# Generated at 2022-06-23 21:49:09.129747
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    assert s.html() == "<span>someone <p>nourish</p> waddle</span>"



# Generated at 2022-06-23 21:49:18.266939
# Unit test for method css of class Structure
def test_Structure_css():
    """Unit test for method css of class Structure."""
    list1 = ['p', 'span', 'div', 'body', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6']
    list2 = ['color', 'background-color', 'font-family', 'font-style',
        'font-weight', 'font-size', 'height', 'width', 'text-transform', 'text-decoration',
        'text-shadow', 'border', 'border-radius', 'text-align', 'float', 'clear']
        # 'color', 'background-color', 'font-family', 'font-style',
    #     'font-weight', 'font-size', 'height', 'width', 'text-transform', 'text-decoration',
    #     'text-shadow', 'border', 'border-

# Generated at 2022-06-23 21:49:19.666173
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    pass


# Generated at 2022-06-23 21:49:23.314559
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    result:str = s.html()
    # Test that result is a string
    assert isinstance(result, str)


# Generated at 2022-06-23 21:49:26.017365
# Unit test for method html of class Structure
def test_Structure_html():
    # Remember that the output is random, and therefore, the test may fail,
    # but it's ok
    struct = Structure()
    assert struct.html()


# Generated at 2022-06-23 21:49:27.658971
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('en')
    x = structure.css_property()
    assert isinstance(x, str)

# Generated at 2022-06-23 21:49:30.039680
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    _structure = Structure()
    _css = _structure.css_property()
    print(_css)


# Generated at 2022-06-23 21:49:34.986277
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    seed = 'mimesis'
    s1 = Structure(seed)
    assert str(s) != str(s1)
    assert s.seed != s1.seed

# Generated at 2022-06-23 21:49:39.948242
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure('en')
    assert structure.css() != None
    assert structure.css_property() != None
    assert structure.css_property != None
    assert structure.css != None
    assert structure.html != None
    assert structure.html_attribute_value != None

#unit test for function css

# Generated at 2022-06-23 21:49:43.593121
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct = Structure()
    assert struct.html_attribute_value(tag='div', attribute='class') # test on div tag
    print(struct.html_attribute_value()) # default case


# Generated at 2022-06-23 21:49:50.700079
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis.enums import CSSProperties
    from mimesis.providers import Structure
    s = Structure()
    results=[]
    for i in range(0,100):
        results.append(s.css())
    #print(results)
    assert len(results)==100
    assert results[50].split()[0] in CSSProperties.selectors.value
    assert results[51].split()[0] in CSSProperties.selectors.value


# Generated at 2022-06-23 21:49:55.098334
# Unit test for constructor of class Structure
def test_Structure():
    x = Structure('en')
    assert x.css() is not None
    assert x.css_property() is not None
    assert x.html() is not None
    assert x.html_attribute_value() is not None


# Generated at 2022-06-23 21:49:59.474257
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    tag_list = list(HTML_CONTAINER_TAGS.keys())
    for tag in tag_list:
        attribute_list = list(HTML_CONTAINER_TAGS[tag])
        for attribute in attribute_list:
            structure = Structure()
            structure.html_attribute_value(tag, attribute)

# Generated at 2022-06-23 21:50:00.803933
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure(locale='en')
    assert isinstance(s.html(), str)

# Generated at 2022-06-23 21:50:07.987010
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure(seed=123456).html_attribute_value('a') == 'right'
    assert Structure(seed=123456).html_attribute_value('input') == 'radio'
    assert Structure(seed=123456).html_attribute_value('span') == '#3d5a5f'
    assert Structure(seed=123456).html_attribute_value('span') == '1em'
    assert Structure(seed=123456).html_attribute_value('font') == 'right'
    assert Structure(seed=123456).html_attribute_value('frame') == '#3d5a5f'
    assert Structure(seed=123456).html_attribute_value('input') == 'absolute'
    assert Structure(seed=123456).html_attribute_value('area') == '#3d5a5f'

# Generated at 2022-06-23 21:50:14.369213
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    for i in range(100):
        tag_name = s.random.choice(list(HTML_CONTAINER_TAGS))
        tag_attributes = list(HTML_CONTAINER_TAGS[tag_name])  # type: ignore
        k = s.random.randint(1, len(tag_attributes))

        selected_attrs = s.random.sample(tag_attributes, k=k)

        attrs = []
        for attr in selected_attrs:
            attrs.append('{}="{}"'.format(
                attr, s.html_attribute_value(tag_name, attr)))

        html_result = '<{tag} {attrs}>{content}</{tag}>'

# Generated at 2022-06-23 21:50:16.843328
# Unit test for method css of class Structure
def test_Structure_css():
    assert isinstance(Structure().css(), str), "The result is not a string"


# Generated at 2022-06-23 21:50:26.273080
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import HTMLTag
    pseudo_random_generator = PseudoRandom()
    structure = Structure(pseudo_random_generator)
    result = structure.html()
    assert '<' in result
    assert '>' in result
    assert ' ' in result
    assert '</' in result
    assert ' </' not in result
    assert '\t</' not in result
    assert '\n</' not in result
    assert '  </' not in result

# Generated at 2022-06-23 21:50:28.089277
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    css = s.css_property()
    print(css)


# Generated at 2022-06-23 21:50:29.591186
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st = Structure()
    print(st.css_property())

# Generated at 2022-06-23 21:50:35.278578
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()

    pre_structure_css_property = structure.css_property()
    structure.random.seed(0)
    post_structure_css_property = structure.css_property()

    assert pre_structure_css_property == post_structure_css_property
    assert pre_structure_css_property == 'text-align: justify'


# Generated at 2022-06-23 21:50:40.680380
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    str = Structure('en')
    a = str.html_attribute_value('a', 'href')
    assert type(a) == str
    assert len(a) > 0
    b = str.html_attribute_value()
    assert type(b) == str
    assert len(b) > 0
    c = str.html_attribute_value('input', 'type')
    assert type(c) == str
    assert len(c) > 0

# Generated at 2022-06-23 21:50:43.106096
# Unit test for method html of class Structure
def test_Structure_html():
    html1 = Structure().html()
    print(html1)


# Generated at 2022-06-23 21:50:53.103936
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure(seed=1)
    assert structure.html() == '<a href="http://www.cora.com.au" title="dolorum" class="select" id="careers">\n            Ports are created with the built-in function open_port.\n            </a>'
    assert structure.html() == '<span class="select" id="careers">\n            Ports are created with the built-in function open_port.\n            </span>'
    assert structure.html() == '<div title="dolorum" class="select">\n            Ports are created with the built-in function open_port.\n            </div>'