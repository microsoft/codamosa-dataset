

# Generated at 2022-06-23 21:41:05.657572
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    stru = Structure()
    stru.html_attribute_value(tag='div', attribute='id')
    assert stru.html_attribute_value(tag='div', attribute='id') == 'analyst'
    assert stru.html_attribute_value(tag='div', attribute='class') == 'manager'
    assert stru.html_attribute_value(tag='div', attribute='style') == 'background-image: url(http://store.com/); font-size: 79px; text-align: left; color: #2fc2f9; font-family: Times, serif;'
    assert stru.html_attribute_value(tag='div', attribute='title') == 'worker'


# Generated at 2022-06-23 21:41:16.907403
# Unit test for constructor of class Structure
def test_Structure():
    # Create an object of class Structure
    struc = Structure()

    # Create HTML tag conteiners
    conteiner1 = struc.html()
    conteiner2 = struc.html()
    conteiner3 = struc.html()
    conteiner4 = struc.html()
    conteiner5 = struc.html()

    # Create a page
    page = '<html><head></head><body>' + conteiner1 + conteiner2 + conteiner3 \
        + conteiner4 + conteiner5 + '</body></html>'

    # Write in a HTML file
    text = open('page.html', 'w')
    text.write(page)
    text.close

    # Open a HTML file
    webbrowser.open_new_tab('page.html')

   

# Generated at 2022-06-23 21:41:27.319897
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import HTMLCSSSelectors, HTMLCSSSizeUnits
    from mimesis.enums import HTMLTagAttrs
    from mimesis.enums import HTMLTags

    random.seed(0)
    Structure.html_attribute_value(HTMLTags.SPAN, HTMLTagAttrs.CLASS)

    # test with a list
    Structure.html_attribute_value(HTMLTags.FORM, HTMLTagAttrs.METHOD)

    # test with a CSS_PROPERTIES value
    Structure.html_attribute_value(
        HTMLTags.MARK, HTMLTagAttrs.STYLE)

    # test with a random word
    Structure.html_attribute_value(HTMLTags.BODY, HTMLTagAttrs.ID)

    # test with a url

# Generated at 2022-06-23 21:41:29.350551
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    val = Structure().css_property()
    assert val in CSS_PROPERTIES.values()

# Generated at 2022-06-23 21:41:32.413066
# Unit test for method html of class Structure
def test_Structure_html():
  str_ = Structure(seed = 1)
  str = str_.html()
  assert str == '<nav class="custom" alt="point" aria-disabled="false">Furnished study determined her him veal.</nav>'


# Generated at 2022-06-23 21:41:35.391182
# Unit test for method css of class Structure
def test_Structure_css():
    x=Structure(seed=666)
    print(x.css())


# Generated at 2022-06-23 21:41:36.712451
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure(seed=0)


# Generated at 2022-06-23 21:41:47.564891
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    test = Structure('en')
    assert test.html_attribute_value('a', 'class') == \
        'button primary warning success'
    assert test.html_attribute_value('a', 'href') == \
        'https://www.zachary-whitley.info/'
    assert test.html_attribute_value('a', 'id') == \
        'request-id_homepage'
    assert test.html_attribute_value('a', 'title') == \
        'true'
    assert test.html_attribute_value('a', 'target') == \
        '_blank'
    assert test.html_attribute_value('a', 'rel') == \
        'nofollow'
    assert test.html_attribute_value('a', 'type') == \
        'text/html'

# Generated at 2022-06-23 21:41:48.435300
# Unit test for method css of class Structure
def test_Structure_css():
 str = Structure()
 str.css()


# Generated at 2022-06-23 21:41:49.984090
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st = Structure()
    assert st.css_property() == 'background-color: #f4d3a1'

# Generated at 2022-06-23 21:41:52.331737
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(seed=0)
    assert s.css() == 'select#c_s:hover{font-size: 98mm; }'



# Generated at 2022-06-23 21:41:53.138675
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    structure.html()

# Generated at 2022-06-23 21:41:54.836451
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    css = s.css()
    assert css is not None
    assert not isinstance(css, Exception)


# Generated at 2022-06-23 21:42:03.491826
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure(random=False, locale='ja', seed=123)
    assert s.html() == '<area alt="クリックすると実行されたら自動的にお客様のウェブブラウザーがアプリケーションにリダイレクトしている、どのようにするかを選択することができます" coords="各" href="http://www.chun.com/" shape="調和でない" />'

# Generated at 2022-06-23 21:42:13.842198
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.structure import Structure
    from mimesis.providers.utils import just
    from mimesis.providers.web import Web
    from mimesis.providers.internet import Internet

    css_properties = Structure.Meta.get_field('css_properties').value
    css_selectors = Structure.Meta.get_field('css_selectors').value
    html_container_tags = Structure.Meta.get_field('html_container_tags').value
    html_markup_tags = Structure.Meta.get_field('html_markup_tags').value

    rus = RussiaSpec

# Generated at 2022-06-23 21:42:14.914330
# Unit test for method css of class Structure
def test_Structure_css():
    struct = Structure()
    struct.css()

# Generated at 2022-06-23 21:42:16.064442
# Unit test for constructor of class Structure
def test_Structure():
    x = Structure()


# Generated at 2022-06-23 21:42:24.467338
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    attribute_value = Structure(seed=1).html_attribute_value(tag='a', attribute='lang')
    assert attribute_value in ['en', 'en-US', 'en-GB']
    attribute_value = Structure(seed=1).html_attribute_value(tag='a', attribute='blockquote')
    assert attribute_value == '<blockquote> </blockquote>'
    attribute_value = Structure(seed=1).html_attribute_value(tag='a', attribute='data-tooltip')
    assert any(i in attribute_value for i in ['word', 'css'])

# Generated at 2022-06-23 21:42:29.164393
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure('en')
    assert isinstance(structure.html(), str)
    assert isinstance(structure.html_attribute_value(
        'a', 'href'), str)
    # TODO: Fix tests
    # assert isinstance(structure.css_property(), str)
    # assert isinstance(structure.css(), str)

# Generated at 2022-06-23 21:42:39.356003
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis.enums import CSSProperty
    from mimesis.providers.structure import Structure
    from mimesis.utils import get_enum_value
    structure = Structure()
    css_regex = '[\w-]+:[\w-]+(;|\s{0,}$)'
    for _ in range(100):
        css = structure.css()
        print(css)
        assert re.search(css_regex, css) is not None
        props = (re.sub(r'(\w+):(\w+)', r'\1', css).split(';'))
        for prop in props:
            enum = get_enum_value(CSSProperty, prop.strip().title())
            assert enum is not None

# Generated at 2022-06-23 21:42:40.614663
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    assert s.css()


# Generated at 2022-06-23 21:42:42.673988
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('en')
    value = structure.css_property()
    print(value)
    assert value is not None
    assert isinstance(value, str)


# Generated at 2022-06-23 21:42:53.515470
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    h1 = s.html()
    assert type(h1) == str
    h2 = s.html("h3","class")
    assert type(h2) == str
    h3 = s.html("h3","href")
    assert type(h3) == str
    h4 = s.html("script","src")
    assert type(h4) == str
    h5 = s.html("h3","style")
    assert type(h5) == str
    h6 = s.html("h3","target")
    assert type(h6) == str
    h7 = s.html("h3","title")
    assert type(h7) == str
    h8 = s.html("h3","value")
    assert type(h8) == str
    h9 = s.html

# Generated at 2022-06-23 21:42:56.135095
# Unit test for constructor of class Structure
def test_Structure():
    obj = Structure()
    assert obj.seed == 42
    assert obj.locale == 'en'


# Generated at 2022-06-23 21:42:57.862675
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    temp_instance = Structure()
    result = temp_instance.css_property()
    print(result)


# Generated at 2022-06-23 21:43:06.588047
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    HTML = []
    for _ in range(10):
        HTML.append(structure.html())
    assert HTML != []
    assert HTML[0] == '<area class="hydration" target="_blank" scrolling="auto">Jobless delivery a</area>'
    assert HTML[1] == '<caption>Opportunistic disintermediate deliverables</caption>'
    assert HTML[2] == '<marquee direction="right" form="transmission">Expedite mission-critical schemas</marquee>'
    assert HTML[3] == '<meta http-equiv="refresh" name="bandwidth">Globalizing e-tailers</meta>'
    assert HTML[4] == '<acronym title="Nanometers">E-business empower</acronym>'

# Generated at 2022-06-23 21:43:09.421755
# Unit test for constructor of class Structure
def test_Structure():
    """Unit test for Structure class."""
    data1 = Structure()
    res1 = data1.css()
    assert isinstance(res1, str)


# Generated at 2022-06-23 21:43:13.403202
# Unit test for constructor of class Structure
def test_Structure():
    from mimesis.enums import Locale
    from mimesis.exceptions import InvalidLocaleError
    from mimesis.providers import Structure
    st = Structure.Structure(seed = 0)
    assert(type(st) == Structure.Structure)


# Generated at 2022-06-23 21:43:17.532696
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    x = Structure()

    assert True == isinstance(x.css_property(), str)
    assert True == isinstance(x.css_property(), str)
    assert True == isinstance(x.css_property(), str)
    assert True == isinstance(x.css_property(), str)


# Generated at 2022-06-23 21:43:19.125276
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure.__class__.__name__ == 'Structure'


# Generated at 2022-06-23 21:43:29.028389
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import Tag, Attribute
    from mimesis.providers.structure import Structure

    struc = Structure()
    tag = Tag.A
    attr = Attribute.HREF

    assert struc.html_attribute_value(tag, attr) \
        == 'http://example.com/pinkie-cat-jr'
    assert struc.html_attribute_value(tag, attr) \
        == 'http://example.com/eyes-chief-iii'
    assert struc.html_attribute_value(tag, attr) \
        == 'http://example.com/pierce-c'
    assert struc.html_attribute_value(tag, attr) \
        == 'http://example.com/regulatory-jazzy'
    assert struc.html_attribute

# Generated at 2022-06-23 21:43:31.073525
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    g = Structure()
    tag = "p"
    attribute = "class"
    value = g.html_attribute_value(tag, attribute)
    print(value)

# Generated at 2022-06-23 21:43:32.905153
# Unit test for method html of class Structure
def test_Structure_html():
  html_file = open("html_file.html","w")
  struct = Structure()
  html_file.write(struct.html())
  html_file.close()


# Generated at 2022-06-23 21:43:34.357199
# Unit test for method html of class Structure
def test_Structure_html():
    # Calling method of class Structure in unit test
    Structure().html()


# Generated at 2022-06-23 21:43:36.450313
# Unit test for method css of class Structure
def test_Structure_css():
    abstractsp = Structure(locale='abstract')
    assert abstractsp.css()

# Generated at 2022-06-23 21:43:38.677248
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure('ru')
    for i in range(10):
        print(s.html())


# Generated at 2022-06-23 21:43:40.211320
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure(seed=6)
    result='''<meta http-equiv="content-type" content="text/html; charset=utf-8"/>'''
    assert s.html() == result


# Generated at 2022-06-23 21:43:45.690769
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    tag = 'a'
    attribute = 'href'
    html_attribute_value = s.html_attribute_value(tag, attribute)
    print(html_attribute_value)
    assert type(html_attribute_value) == str
    print('test_Structure_html_attribute_value() is successful')


# Generated at 2022-06-23 21:43:51.229291
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure"""
    structure = Structure(seed=123)
    assert structure.html_attribute_value() == "#68e5"
    assert structure.html_attribute_value() == "k-xKpJ"
    assert structure.html_attribute_value() == "www.rmj.com"

# Generated at 2022-06-23 21:43:54.399417
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test method html_attribute_value of class Structure."""
    s = Structure()
    assert s.html_attribute_value('a', 'href')

# Generated at 2022-06-23 21:44:01.911907
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Test with kwargs ['tag', 'attribute']
    structure = Structure()
    assert structure.html_attribute_value(tag='button', attribute='class')
    assert structure.html_attribute_value(tag='form', attribute='action')
    assert structure.html_attribute_value(tag='button', attribute='id')
    assert structure.html_attribute_value(tag='a', attribute='href')
    assert structure.html_attribute_value(tag='input', attribute='src')
    assert structure.html_attribute_value(tag='link', attribute='href')

    # Test with None args
    assert structure.html_attribute_value()
    assert structure.html_attribute_value(tag=None)
    assert structure.html_attribute_value(attribute=None)

# Generated at 2022-06-23 21:44:10.709637
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value(tag='input', attribute='type') == 'text', "Should be 'text'"
    assert structure.html_attribute_value(tag='select', attribute='name') == 'index', "Should be 'index'"
    assert structure.html_attribute_value(tag='form', attribute='name') == 'form2', "Should be 'form2'"
    assert structure.html_attribute_value(tag='area', attribute='alt') == 'snowy', "Should be 'snowy'"
    assert structure.html_attribute_value(tag='audio', attribute='src') == 'https://sundaes.com', "Should be 'https://sundaes.com'"

# Generated at 2022-06-23 21:44:12.515260
# Unit test for constructor of class Structure
def test_Structure():
    t = Structure()
    assert t is not None


# Generated at 2022-06-23 21:44:14.426553
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    print("-------------------------")
    print("Testing html()")
    print("*************************")
    print("Below should be a valid HTML")
    print(s.html())



# Generated at 2022-06-23 21:44:16.288746
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure('en')
    res = structure.html()
    print('test_Structure_html res', res)
    assert(res != '')


# Generated at 2022-06-23 21:44:18.487988
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Unit test for method Structure.css_property."""
    data = Structure()
    result = data.css_property()
    assert isinstance(result, str)
    # TODO: add more assertions



# Generated at 2022-06-23 21:44:23.837125
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    import mimesis
    for i in range(10):
        structure = mimesis.Structure('en')
        print(structure.css_property())
# example output: 
# background-color: #00c60b
# border-color: #3b7f97
# border-bottom-color: #c2a2e3
# padding-bottom: 47px
# margin-left: 48em
# padding-left: 51em
# margin-top: 67em
# margin-left: 70em
# border-left-color: #6a80c6
# border-right: 22pt dotted #ea6e44


# Generated at 2022-06-23 21:44:28.210007
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    css_block = structure.css()
    assert css_block is not None
    assert isinstance(css_block, str)
    assert len(css_block.split(' ')) > 1


# Generated at 2022-06-23 21:44:33.153713
# Unit test for constructor of class Structure
def test_Structure():
    my_Structure = Structure('en')
    assert isinstance(my_Structure, Structure)
    assert isinstance(my_Structure._random, random.Random)
    assert isinstance(my_Structure.seed, int)
    assert isinstance(my_Structure._datetime_provider, datetime.datetime)


# Generated at 2022-06-23 21:44:34.931126
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    res = s.html()
    assert(res)
    print(res)


# Generated at 2022-06-23 21:44:36.799627
# Unit test for method html of class Structure
def test_Structure_html():
    result = Structure().html()
    assert isinstance(result, str) == True


# Generated at 2022-06-23 21:44:38.634644
# Unit test for method css of class Structure
def test_Structure_css():
    s=Structure("en")
    x = s.css()
    assert x


# Generated at 2022-06-23 21:44:39.796623
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    print(structure.html())


# Generated at 2022-06-23 21:44:49.676221
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSUnit
    s = Structure()
    css_prop = s.css_property()
    assert isinstance(css_prop, str)
    prop, value = css_prop.split(':')
    assert prop in list(CSS_PROPERTIES.keys())
    if CSS_PROPERTIES[prop] == 'color':
        assert '#' in value and len(value) == 7
    elif CSS_PROPERTIES[prop] == 'url':
        assert 'http' in value or 'www' in value
    elif CSS_PROPERTIES[prop] == 'size':
        size, unit = value.split(CSSUnit.px.value)
        assert int(size) > 0 and unit in CSS_SIZE_UNITS


# Generated at 2022-06-23 21:44:52.015836
# Unit test for method html of class Structure
def test_Structure_html():
    data = Structure.html()
    #print(data)
    assert len(data) > 0


# Generated at 2022-06-23 21:45:03.391997
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import HTMLElement
    from mimesis.providers.text import Text

    #test that all elements are created
    HtmlElements = HTMLElement.__members__.keys()
    structure = Structure('ru')
    flag = False
    for i in range(100):
        html = structure.html()
        flag = False
        for elem in HtmlElements:
            flag += elem in html
        print(flag)
    assert flag

    #test that all elements are created
    HtmlElements = HTMLElement.__members__.keys()
    structure = Structure('ru')
    text = Text('ru')
    flag = False
    for i in range(100):
        elem = text.element(tag=HtmlElements)
        html = structure.html()


# Generated at 2022-06-23 21:45:06.841712
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    css = '<p class="indent-3" id="coaching-4">'\
        '<strong>Polarizes the</strong> '\
        '<u>system</u> ever with perfect.'\
        '</p>'
    assert s.css() == css


# Generated at 2022-06-23 21:45:13.329453
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    tests = [
        ('a', 'href', 'url'), 
        ('img', 'alt', 'word'),
        ('img', 'src', 'url'),
        ('input', 'value', 'word'),
        ('ul', 'style', 'css'),
    ]

    for tag, attr, res_type in tests:
        result = Structure().html_attribute_value(tag, attr)
        if res_type == 'css':
            assert ':' in result
        elif res_type == 'word':
            assert ' ' not in result
        elif res_type == 'url':
            assert '.' in result


# Generated at 2022-06-23 21:45:15.004154
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    assert len(structure.css()) > 0


# Generated at 2022-06-23 21:45:17.655776
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure(seed=3)
    result = structure.html()
    assert result=='<img src="#" width="100" src="" align="" alt="" usemap="" ' \
                   'ismap="" style="" rel="" shape="" type="" title="" content="">' \
                   '<br> DQTbT\n<i>vx</i>\n'


# Generated at 2022-06-23 21:45:19.100724
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    assert isinstance(s.css(), str)


# Generated at 2022-06-23 21:45:22.102526
# Unit test for method css of class Structure
def test_Structure_css():
    structure_css = Structure()
    # structure_css = Structure()
    # print(structure_css.css())


# Generated at 2022-06-23 21:45:29.892811
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert isinstance(structure, Structure)
    assert isinstance(structure, BaseDataProvider)
    assert isinstance(structure, Structure.Meta)
    assert isinstance(structure.Meta, type)
    assert hasattr(structure, '__name')
    assert hasattr(structure, '__locale')
    assert hasattr(structure, '__seed')
    assert isinstance(structure._Structure__inet, Internet)
    assert isinstance(structure._Structure__text, Text)
    assert isinstance(structure.random, BaseDataProvider.random)


# Generated at 2022-06-23 21:45:36.270939
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    ##TEST1: Test result is not a list
    s = Structure()
    test_result = s.html_attribute_value(tag='body', attribute='class')
    assert type(test_result) is not type([])
    assert test_result != ''
    ##TEST2: Test result is a list
    test_result = s.html_attribute_value(tag='body', attribute='custom')
    assert type(test_result) is type([])
    assert test_result != []
    ##TEST3: Test result is a list
    test_result = s.html_attribute_value(tag='head', attribute='name')
    assert type(test_result) is type([])
    assert test_result != []


# Generated at 2022-06-23 21:45:37.051010
# Unit test for method css of class Structure
def test_Structure_css():
    stc=Structure()
    stc.css()


# Generated at 2022-06-23 21:45:39.712107
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Given
    structure = Structure()

    # When
    result = structure.css_property()

    # Then
    assert True

# Generated at 2022-06-23 21:45:41.773434
# Unit test for constructor of class Structure
def test_Structure():
    obj = Structure()
    assert obj is not None


# Generated at 2022-06-23 21:45:43.606314
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure(seed=0)
    assert structure.css_property() == 'height: 25px'

# Generated at 2022-06-23 21:45:45.697090
# Unit test for constructor of class Structure
def test_Structure():
    data_provider = Structure(locale='en')
    assert data_provider != None


# Generated at 2022-06-23 21:45:46.749473
# Unit test for method css of class Structure
def test_Structure_css():
    assert Structure().css() is not None


# Generated at 2022-06-23 21:45:55.030751
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = structure.random.choice(
        list(HTML_CONTAINER_TAGS.keys()),
    )
    attribute = structure.random.choice(
        list(HTML_CONTAINER_TAGS[tag]),
    )
    attr_value = structure.html_attribute_value(tag, attribute)
    assert isinstance(tag, str)
    assert isinstance(attribute, str)
    assert isinstance(attr_value, str)



# Generated at 2022-06-23 21:45:56.507186
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st = Structure()
    print(st.css_property())


# Generated at 2022-06-23 21:46:01.101087
# Unit test for method html of class Structure
def test_Structure_html():
    new_tag = {'tag_name': ['tag_attribute', 'tag_attribute'],
               'tag_name': ['tag_attribute', 'tag_attribute']}

    Structure.Meta.data['html']['tags'] = new_tag

    structure = Structure('en')
    output = structure.html()
    assert isinstance(output, str)

# Generated at 2022-06-23 21:46:03.590644
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    a = Structure()
    for i in range(10):
        assert a.css_property()
        print(a.css_property())


# Generated at 2022-06-23 21:46:05.106341
# Unit test for method html of class Structure
def test_Structure_html():
    # test for method html of class Structure
    structure = Structure("en")
    html = structure.html()
    assert isinstance(html, str)
    assert html != None


# Generated at 2022-06-23 21:46:14.215276
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    import mimesis.enums
    from mimesis.builtins import RussiaSpecProvider
    stc_russian_default = Structure('ru')
    stc_russian_custom = Structure('ru', mimesis.enums.Language.RU, RussiaSpecProvider)
    print(stc_russian_default.html_attribute_value())
    print(stc_russian_default.html_attribute_value())
    print(stc_russian_default.html_attribute_value())
    print(stc_russian_custom.html_attribute_value())
    print(stc_russian_custom.html_attribute_value())
    print(stc_russian_custom.html_attribute_value())
    print(stc_russian_default.html_attribute_value('a', 'href'))
   

# Generated at 2022-06-23 21:46:26.084543
# Unit test for constructor of class Structure
def test_Structure():
    # pylint: disable=no-member
    struct = Structure(seed=42)
    assert struct.random.choice([1, 2, 3]) == 3
    assert struct.css_property() == 'background-color: #f4d3a1'
    assert struct.html().startswith('<span')
    assert struct.html()[-7:] == '</span>'
    assert struct.html().find('class="') > 0
    assert struct.html().find('id="') > 0
    assert struct.html().find('<p') > 0
    assert struct.html_attribute_value(tag="img", attribute="alt").find('"') < 0
    assert struct.html_attribute_value(tag="link", attribute="rel") == "stylesheet"

# Generated at 2022-06-23 21:46:27.289183
# Unit test for method css of class Structure
def test_Structure_css():
    provider=Structure()
    css1=provider.css()

    pass

# Generated at 2022-06-23 21:46:28.441908
# Unit test for method css of class Structure
def test_Structure_css():
    obj = Structure()
    assert type(obj.css()) is str


# Generated at 2022-06-23 21:46:32.041129
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()
    struct_ = Structure()
    assert isinstance(struct, Structure)
    assert isinstance(struct_, Structure)
    assert struct._seed == struct_._seed


# Generated at 2022-06-23 21:46:33.429149
# Unit test for constructor of class Structure
def test_Structure():
    obj = Structure()
    assert obj is not None
    

# Generated at 2022-06-23 21:46:38.429053
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure(seed=42)
    result = structure.css()
    assert result == '<form>' \
                            'width: 50%; ' \
                            'flex-grow: 9; ' \
                            'border-image-repeat: round; ' \
                            'text-overflow: clip; ' \
                            'color: #b64f60' \
                            '</form>'


# Generated at 2022-06-23 21:46:49.752535
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    HTML_TAG = structure.random.choice(
        list(HTML_CONTAINER_TAGS.keys()),
    )
    HTML_ATTRIBUTE = structure.random.choice(
        list(HTML_CONTAINER_TAGS[HTML_TAG]),  # type: ignore
    )
    # Value of the attribute
    value = structure.html_attribute_value(tag=HTML_TAG,
                                           attribute=HTML_ATTRIBUTE)
    # Attribute type
    type_ = HTML_CONTAINER_TAGS[HTML_TAG][HTML_ATTRIBUTE]  # type: ignore
    if type_ == 'css':
        # Background-color: #c3d6d3
        assert value.split(':')[0] in CSS_PROPERTIES

# Generated at 2022-06-23 21:46:52.576485
# Unit test for method html of class Structure
def test_Structure_html():
    """Unit test for method html of class Structure."""
    struct = Structure()
    html_tag = struct.html()
    print(html_tag)
    assert len(html_tag) > 9


# Generated at 2022-06-23 21:46:53.888059
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert Structure.css_property(Structure('it')) != None


# Generated at 2022-06-23 21:47:05.800487
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    struct = Structure()

    # Test that method not fails if no tag tag is specified
    struct.html_attribute_value(None, "href")

    # Test that method not fails if no attribute is specified
    struct.html_attribute_value("a", None)

    # Test that method raise exception if specified tag name is unsupported
    try:
        struct.html_attribute_value("unsupported_tag", "unsupported_attr")
    except NotImplementedError:
        pass
    else:
        assert False, "Not implemented exception expected for unsupported tag"

    # Test that method raise exception if specified attribute is unsupported
    try:
        struct.html_attribute_value("a", "unsupported_attr")
    except NotImplementedError:
        pass
    else:
        assert False, "Not implemented exception expected for unsupported attr"

# Generated at 2022-06-23 21:47:07.150570
# Unit test for constructor of class Structure
def test_Structure():
    St = Structure()
    assert isinstance(St, Structure)

# Generated at 2022-06-23 21:47:07.852414
# Unit test for method html of class Structure
def test_Structure_html():
    assert Structure().html() != ''

# Generated at 2022-06-23 21:47:16.135038
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    import pytest

    s = Structure()

    for _ in range(50):
        tag = s.random.choice(s.random.choices(list(HTML_CONTAINER_TAGS)))
        attr = s.random.choice(s.random.choices(
            list(HTML_CONTAINER_TAGS[tag])))
        value = s.html_attribute_value(tag, attr)
        assert isinstance(value, str)

    with pytest.raises(NotImplementedError) as e:
        s.html_attribute_value(
            'not_existing_tag',
            s.random.choice(
                s.random.choices(list(HTML_CONTAINER_TAGS['a']))
            )
        )

# Generated at 2022-06-23 21:47:17.873900
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() in CSS_PROPERTIES

# Generated at 2022-06-23 21:47:21.201034
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    test_obj = Structure()
    test_tag = 'a'
    test_attribute = 'href'
    test_value = 'http://example.com/'
    result = test_obj.html_attribute_value(test_tag, test_attribute)
    assert result == test_value

# Generated at 2022-06-23 21:47:23.202096
# Unit test for constructor of class Structure
def test_Structure():
    obj = Structure()
    assert obj.Meta.name == "structure"


# Generated at 2022-06-23 21:47:24.855904
# Unit test for method html of class Structure
def test_Structure_html():
    assert str.startswith(Structure().html(), '<')



# Generated at 2022-06-23 21:47:26.598447
# Unit test for method css of class Structure
def test_Structure_css():
    css_provider = Structure()
    print(css_provider.css())


# Generated at 2022-06-23 21:47:29.255275
# Unit test for constructor of class Structure
def test_Structure():
    assert isinstance(Structure(), Structure)
    assert Structure.Meta.name == 'structure'


# Generated at 2022-06-23 21:47:30.359499
# Unit test for method css of class Structure
def test_Structure_css():
    structure_obj=Structure()
    # structure_obj.css()
    print(structure_obj.css())


# Generated at 2022-06-23 21:47:33.488889
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Testing css_property()
    structure = Structure()
    css_prop = structure.css_property()
    assert len(css_prop) > 0


# Generated at 2022-06-23 21:47:34.967470
# Unit test for method css_property of class Structure
def test_Structure_css_property():

    s = Structure()
    assert isinstance(s.css_property(), str)

# Generated at 2022-06-23 21:47:39.440802
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    for _ in range(1, 10):
        print(s.html_attribute_value(attribute='href'))
# Output:
# https://www
# https://www
# https:
# https://www
# https:
# https://
# https://
# https://
# https:


# Generated at 2022-06-23 21:47:41.184533
# Unit test for method css of class Structure
def test_Structure_css():
    st = Structure('en')
    result = st.css()
    if '{' in result:
        assert True
    else:
        assert False


# Generated at 2022-06-23 21:47:45.794658
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # test tag attr
    for tag in HTML_CONTAINER_TAGS:
        for attr in HTML_CONTAINER_TAGS[tag]:
            structure = Structure('en')
            result = structure.html_attribute_value(tag=tag, attribute=attr)
            assert result is not None
            assert isinstance(result, str)

    # test random tag attr
    structure = Structure('en')
    result = structure.html_attribute_value(tag=None, attribute=None)
    assert result is not None
    assert isinstance(result, str)

# Generated at 2022-06-23 21:47:47.443116
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    for i in range(1, 20):
        print(structure.css_property())
print('\n')


# Generated at 2022-06-23 21:47:54.491709
# Unit test for method html of class Structure
def test_Structure_html():
    test_obj = Structure()
    test_obj.random.choice = lambda x: 'span'
    test_obj.random.sample = lambda x, y: ['class']
    test_obj.html_attribute_value = lambda x, y: 'select'
    test_obj.__text.sentence = lambda  x=None: 'Ports are created.'

    assert test_obj.html() == '<span class="select">Ports are created.</span>'

# Generated at 2022-06-23 21:47:59.566053
# Unit test for method css of class Structure
def test_Structure_css():
    o1 = Structure(seed=12345)
    o2 = Structure(seed=12345)
    assert o1.css() == o2.css()
    assert o1.css() == 'area {font-style: normal; text-rendering: optimizelegibility; font-family: inherit; font-weight: 100;}'


# Generated at 2022-06-23 21:48:08.847962
# Unit test for method css_property of class Structure
def test_Structure_css_property():

    t1 = Structure()
    t2 = Structure()
    t3 = Structure()
    t4 = Structure()
    t5 = Structure()
    t6 = Structure()

    test1 = 'clip: auto'
    test2 = 'padding-left: 10px'
    test3 = 'border-bottom-color: #ff4b4b'
    test4 = 'text-decoration: underline'
    test5 = 'background-image: url(https://example.org/)'
    test6 = 'page-break-inside: avoid'

    t_list = [test1 , test2 , test3 , test4 , test5 , test6]

# Generated at 2022-06-23 21:48:13.746848
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    global CSS_PROPERTIES
    temp = CSS_PROPERTIES
    CSS_PROPERTIES = {'background': 'color'}
    s = Structure()
    assert s.css_property() == "background: #f4d3a1"
    CSS_PROPERTIES = temp
    return None


# Generated at 2022-06-23 21:48:15.149290
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    for _ in range(100):
        s.css_property()

# Generated at 2022-06-23 21:48:16.339805
# Unit test for constructor of class Structure
def test_Structure():
    a = Structure()
    
test_Structure()



# Generated at 2022-06-23 21:48:22.148063
# Unit test for method html of class Structure
def test_Structure_html():
    from nose.tools import assert_raise, assert_is_instance, assert_equal, assert_raises
    from mimesis.enums import Tags

    tags = Tags.HTML
    html = Structure()
    assert_equal(len(html.html()), 107)
    assert_raises(ValueError, html.html, 'value_wrong')
    assert_raise(html.html, 'tag', 'value_wrong')


# Generated at 2022-06-23 21:48:25.132056
# Unit test for method html of class Structure
def test_Structure_html():
    print('\n\n' + '-'*60)
    print('Unit test for method html of class Structure')
    structure = Structure()
    for i in range(5):
        print(structure.html())

# Generated at 2022-06-23 21:48:27.582190
# Unit test for method css of class Structure
def test_Structure_css():
    from .. import seed
    from .. import css
    s = Structure(seed)
    css = s.css()
    for i in css:
        for k,v in CSS_SELECTORS.items():
            if i == k:
                return i



# Generated at 2022-06-23 21:48:33.390651
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(seed=1)
    css = s.css()
    assert(css == 'div{width: 21px; color: #d05ea7; margin: 98px; '
                  'padding: 63px; border: 1px solid #cba7cd; font-weight: '
                  'bold; border-radius: 17px; background-color: #dc0a6f;}')


# Generated at 2022-06-23 21:48:35.601526
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Unit test for method css_property of class Structure."""
    test_obj = Structure()
    test_prop = test_obj.css_property()
    print(test_prop)


# Generated at 2022-06-23 21:48:47.207186
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.exceptions import NotImplementedError
    from mimesis.enums import Tag

    #test for Tag.SPAN
    s = Structure(seed=444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444) 
    s.html_attribute_value(tag = Tag.SPAN.value, attribute = 'class') == 'select'
    s.html_attribute_value(tag = Tag.SPAN.value, attribute = 'id') == 'careers'

    # test for Tag.IMG
    s.html_attribute

# Generated at 2022-06-23 21:48:50.099334
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    result = structure.html()
    assert result is not None
    assert isinstance(result, str)
    assert len(result) is not 0



# Generated at 2022-06-23 21:48:52.740093
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    print(structure.html())
    print(structure.html_attribute_value("a", "href"))

# Generated at 2022-06-23 21:48:55.642434
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    for _ in range(10):
        css_pro = structure.css_property()
        assert isinstance(css_pro, str)


# Generated at 2022-06-23 21:48:59.911616
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure(seed=55)
    result = structure.css()
    expected = '::placeholder {background-color: #d1e64d; margin: 37px; display: none;}'
    assert result == expected


# Generated at 2022-06-23 21:49:02.234726
# Unit test for method css of class Structure
def test_Structure_css():
    p = Structure()
    css = p.css()
    assert isinstance(css, str)


# Generated at 2022-06-23 21:49:03.761420
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    test_obj = Structure(seed=6)
    print(test_obj.css_property())

# Generated at 2022-06-23 21:49:07.755175
# Unit test for constructor of class Structure
def test_Structure():
    test_cls = Structure(seed=12345)
    result = test_cls.html()
    assert '<a href="http://www.briana.com" id="dolores">' in result

    result = test_cls.css()
    assert 'color: #991863' in result

# Generated at 2022-06-23 21:49:13.410289
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure(seed=42)
    html_result = '<a href="http://www.guard.net/" ' \
                  'style="font-size: 23px">Berries ' \
                  'are the fruit of plants in the genus Rubus ' \
                  'of the rose family, Rosaceae.</a>'
    assert s.html() == html_result


# Generated at 2022-06-23 21:49:17.509429
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    from mimesis.enums import Tag, Attribute
    from mimesis.providers.structure import Structure

    obj = Structure(seed=42)

    for tag in Tag:
        for attr in Attribute:
            if attr.name in HTML_CONTAINER_TAGS[tag.value]:
                assert obj.html_attribute_value(tag.value, attr.name)

# Generated at 2022-06-23 21:49:22.222673
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    r1 = s.css_property()
    r2 = s.css_property()
    assert isinstance(r1, str)
    assert (r1 != r2)


# Generated at 2022-06-23 21:49:25.341730
# Unit test for method html of class Structure
def test_Structure_html():
    print('------- test_Structure_html --------')
    s = Structure()
    l = []
    for _ in range(40):
        l.append(s.html())
    print(l)

# Generated at 2022-06-23 21:49:27.382926
# Unit test for method css of class Structure
def test_Structure_css():
    # Instance of class Structure
    s = Structure()
    result=s.css()
    assert result != None


# Generated at 2022-06-23 21:49:29.273855
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    for i in range(60):
        css = s.css()
        if i % 10 == 0:
            print(css)
    assert css != "ERROR"


# Generated at 2022-06-23 21:49:36.218684
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Test value = HTML_CONTAINER_TAGS[tag][attribute] and is a string
    assert Structure().html_attribute_value(tag = 'p',attribute = 'lang') in ['en', 'de', 'fr', 'zh-hans']
    assert Structure().html_attribute_value(tag = 'p',attribute = 'dir') in ['ltr', 'rtl']
    assert Structure().html_attribute_value(tag = 'p',attribute = 'class') in ['css-selector']
    assert Structure().html_attribute_value(tag = 'p',attribute = 'id') in ['css-selector']
    assert Structure().html_attribute_value(tag = 'p',attribute = 'style') in ['css']
    assert Structure().html_attribute_value(tag = 'p',attribute = 'title') in ['word']
    assert Structure

# Generated at 2022-06-23 21:49:40.663818
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    m = Structure()
    tag = 'a'
    attribute = 'href'
    value = HTML_CONTAINER_TAGS[tag][attribute]
    result = m.html_attribute_value(tag=tag, attribute=attribute)
    assert result != None
    assert isinstance(result, str)
    assert result != ''
    assert result == value

# Generated at 2022-06-23 21:49:46.008530
# Unit test for method css of class Structure
def test_Structure_css():
    import random
    import re
    s = Structure(random.randint(1, 2**32))
    assert re.match(r'^section \.\w+ \{\w+\: \w+\; \w+\: \w+\}$', s.css())


# Generated at 2022-06-23 21:49:55.371757
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    print('test_Structure_html_attribute_value')
    structure = Structure('en')
    print(structure.html_attribute_value())
    print(structure.html_attribute_value('a', 'href'))
    print(structure.html_attribute_value('a', 'target'))
    print(structure.html_attribute_value('a', 'download'))
    print(structure.html_attribute_value('a', 'href'))
    print(structure.html_attribute_value('img', 'src'))
    print(structure.html_attribute_value('img', 'srcset'))
    print(structure.html_attribute_value('img', 'alt'))
    print(structure.html_attribute_value('img', 'alt'))

# Generated at 2022-06-23 21:49:56.905941
# Unit test for method css of class Structure
def test_Structure_css():
    struct=Structure()
    struct.css()

# Generated at 2022-06-23 21:49:59.656119
# Unit test for constructor of class Structure
def test_Structure():
    # Get an instance of Structure
    from mimesis.providers.structure import Structure
    structure = Structure()
    result = structure

    assert result is not None, 'Should be truthy'

# Generated at 2022-06-23 21:50:02.552401
# Unit test for method css of class Structure
def test_Structure_css():
    x = Structure()
    print(x.css())


# Generated at 2022-06-23 21:50:05.732476
# Unit test for method html of class Structure
def test_Structure_html():
    my_provider = Structure('en')
    html_data = my_provider.html()

    assert(isinstance(html_data, str))
    assert(html_data[0] == '<')


# Generated at 2022-06-23 21:50:07.522616
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure('en')
    element = structure.html()
    print(element)

import doctest
doctest.testmod()

# Generated at 2022-06-23 21:50:11.866377
# Unit test for constructor of class Structure
def test_Structure():
    obj = Structure()
    print("\nTest testStructure:")
    print("Test of css:")
    print(obj.css())
    print("Test of css_property:")
    print(obj.css_property())
    print("Test of html:")
    print(obj.html())
    print("Test of html_attribute_value:")
    print(obj.html_attribute_value())


# Generated at 2022-06-23 21:50:14.844680
# Unit test for constructor of class Structure
def test_Structure():
    str1 = Structure('zh')
    str2 = Structure('zh', seed = 12)
    # get the attributes--the real test
    assert str1.random.choice([1, 2, 3]) in [1, 2, 3]
    assert str2.random.choice([1, 2, 3]) in [1, 2, 3]
    assert str1.random.choice([1, 2, 3]) != str2.random.choice([1, 2, 3])


# Generated at 2022-06-23 21:50:20.011917
# Unit test for method css of class Structure
def test_Structure_css():
    structuredata = Structure()
    assert structuredata.css() == 'body{font-family: "Helvetica"; font-size: 86px; padding: 10px; text-align: right; background-color: #5d5f5a}'

# Generated at 2022-06-23 21:50:22.344445
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('en')
    assert structure.css_property() == 'background-color: #e3e3f3'

# Generated at 2022-06-23 21:50:26.609799
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    '''Test if the method html_attribute_value of
    class Structure outputs the right data type
    '''
    html_attr_val_obj = Structure(seed=2)
    assert isinstance(html_attr_val_obj.html_attribute_value(), str)


# Generated at 2022-06-23 21:50:28.436298
# Unit test for method html of class Structure
def test_Structure_html():
    """Test for method html of class Structure."""
    assert Structure().html()



# Generated at 2022-06-23 21:50:30.286175
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure("en")
    num = 10
    for _ in range(num - 1):
        test = s.css()
        print(test)
        assert (":" in test) & ("{" in test) & ("}" in test), \
            "Error in method Structure.css()"

# Generated at 2022-06-23 21:50:40.563938
# Unit test for method css of class Structure
def test_Structure_css():
    s=Structure()
    for i in range(50):
        c=s.css()
        assert not c.startswith('""""')
        assert not c.startswith('" """')
        assert not c.startswith('""" ')
        assert not c.startswith('"""{')
        assert not c.startswith(';')
        assert not c.startswith('; ')
        assert not c.startswith(' ;')
        assert not c.startswith(';;')
        assert not c.startswith(';; ')
        assert not c.startswith(' ;;')
        assert not c.startswith(';')
        assert not c.startswith('; ')
        assert not c.startswith(' ;')
        assert not c.startswith(':')


# Generated at 2022-06-23 21:50:46.635109
# Unit test for method html of class Structure
def test_Structure_html():
    s=Structure()
    with open('/Users/hanhanwu/Documents/Projects/GMU/GMU_Data_Hub/data_collection/mimesis_data/html_snippet.txt', 'a') as f:
        for i in range(50):
            f.write(s.html())
            f.write('\n')


# Generated at 2022-06-23 21:50:48.367675
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure('ja')
    assert s.css_property() == 'background-color: #f4d3a1'

# Generated at 2022-06-23 21:50:52.687114
# Unit test for method html of class Structure
def test_Structure_html():
    struct = Structure()
    tags = list(HTML_CONTAINER_TAGS)
    for i in range(100):
        tag = struct.random.choice(tags)
        attrs = list(HTML_CONTAINER_TAGS[tag])  # type: ignore
        k = struct.random.randint(1, len(attrs))
        selected_attrs = struct.random.sample(attrs, k = k)
        attr_str = ' '.join(['{}="{}"'.format(attr, struct.html_attribute_value(tag, attr)) for attr in selected_attrs])
        result = '<{} {}>{}</{}>'.format(tag, attr_str, struct.__text.sentence(), tag)

        assert struct.html() == result

# Generated at 2022-06-23 21:50:59.009346
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value("link", "rel") in [
        'alternate', 'archives', 'author', 'bookmark', 'external',
        'first', 'help', 'index', 'last', 'license', 'next', 'nofollow',
        'noreferrer', 'noopener', 'prev', 'search', 'stylesheet',
        'tag', 'sidebar', 'pingback', 'shortlink', 'preload']
