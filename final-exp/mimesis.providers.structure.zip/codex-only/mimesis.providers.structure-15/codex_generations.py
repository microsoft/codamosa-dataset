

# Generated at 2022-06-23 21:41:02.971005
# Unit test for constructor of class Structure
def test_Structure():
    from mimesis.enums import Locale
    provider = Structure(seed=42, locale=Locale.ENGLISH)
    assert provider.locale == 'en'
    assert provider._seed == 42
    assert provider._random.getstate()


# Generated at 2022-06-23 21:41:14.917556
# Unit test for constructor of class Structure
def test_Structure():
    # testcase 1
    locale_1 = "en"
    seed_1 = None
    struct_1 = Structure(locale_1, seed_1)
    assert struct_1.__dict__ == Structure(locale_1, seed_1).__dict__,\
        "The initial value should be " + str(Structure(locale_1, seed_1).__dict__) + " but the actual value is " + str(struct_1.__dict__)

    # testcase 2
    locale_2 = "en"
    seed_2 = "123"
    struct_2 = Structure(locale_2, seed_2)

# Generated at 2022-06-23 21:41:16.582684
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st = Structure()
    property = st.css_property()
    print(property)
    assert property


# Generated at 2022-06-23 21:41:17.782917
# Unit test for method html of class Structure
def test_Structure_html():
    f = Structure()
    assert f.html()

# Generated at 2022-06-23 21:41:21.387114
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    css_property = structure.css_property()
    assert css_property not in ("", " ", '""', "''"), "The css_property should not be a null or empty string"


# Generated at 2022-06-23 21:41:23.479324
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    res = s.css()
    assert isinstance(res, str)


# Generated at 2022-06-23 21:41:25.109612
# Unit test for method css_property of class Structure
def test_Structure_css_property():
  str=Structure()
  print(str.css_property())


# Generated at 2022-06-23 21:41:26.406880
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s is not None


# Generated at 2022-06-23 21:41:35.761752
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure(seed=123)
    assert s.css() == 'div {color: #843b45; display: flex; background-color: #d848f9; height: 87px; list-style-type: decimal}'
    assert s.html() == '<h6 target="_blank" aria-hidden="true">The <code>Perl</code> built-in function <em>chdir</em> (short for \nchange directory) is used to change the current working directory.\n</h6>'
    assert s.html_attribute_value('a', 'href') == 'http://www.alexander-thomas.com'
    assert s.html_attribute_value('a', 'target') == '_blank'
    assert s.html_attribute_value('div', 'id') == 'test'


# Generated at 2022-06-23 21:41:37.831639
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    prop = Structure.css_property()
    assert prop is not None
    print(prop)


# Generated at 2022-06-23 21:41:41.701126
# Unit test for method html of class Structure
def test_Structure_html():
    print(Structure().html())
    import re
    m = re.match('<(\w+)', Structure().html())
    tag_name = m.groups()[0]
    print(tag_name)


# Generated at 2022-06-23 21:41:50.118363
# Unit test for constructor of class Structure
def test_Structure():
    # Initialize instance of class Structure
    s0 = Structure()
    s1 = Structure(seed=123)
    s2 = Structure(seed=123456778)
    # Check if instances are the same
    assert s0 != s1 != s2, "Structure constructor runs incorrectly"
    # Check if instances have different seeds
    assert s0.seed != s1.seed != s2.seed, \
        "Structure constructor runs incorrectly"
    # Check if instances have equal seeds
    assert s0.seed == 256, "Structure constructor runs incorrectly"
    assert s1.seed == 123, "Structure constructor runs incorrectly"
    assert s2.seed == 123456778, "Structure constructor runs incorrectly"



# Generated at 2022-06-23 21:41:53.443282
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(seed=12345)
    assert s.css() == 'html body .musei {display: block; ' \
                      'padding-top: 44px; margin: 40px;' \
                      ' width: 54px; height: 82px;}'


# Generated at 2022-06-23 21:41:54.837196
# Unit test for constructor of class Structure
def test_Structure():
    st = Structure()
    assert st.__inet is not None
    assert st.__text is not None


# Generated at 2022-06-23 21:42:01.597393
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure('en', seed=12345)
    assert structure.html() == '<p id="explosives" style="height: 54px; ' \
                               'position: fixed;">The term nuclear power ' \
                               'plant is also used, particularly in Europe, ' \
                               'to refer to nuclear marine propulsion.' \
                               '</p>'

    assert structure.html('a') == '<a class="cite-web-title" style="' \
                                  'max-height: 83px; position: absolute;' \
                                  ' top: 0px; background-color: #f5f2cc;' \
                                  '" id="cite-web-title">' \
                                  'The term nuclear power plant is also ' \
                                  'used, particularly in Europe, to refer ' \
                                 

# Generated at 2022-06-23 21:42:07.244839
# Unit test for method html of class Structure
def test_Structure_html():
    """Testing html method of Structure class."""
    from mimesis.enums import MarkupTag as MT
    from mimesis.enums import ContainerTag as CT
    from mimesis.enums import HtmlAttr as HA

    s = Structure("en")

    for i in range(1, 10):
        generated_html = s.html()
        assert generated_html
        assert not generated_html.startswith("<>")
        assert generated_html.endswith("</>")
        assert generated_html.count(">") == 2

        tag_name_beg_idx = generated_html.find("<") + 1
        tag_name_end_idx = generated_html.find(" ")

# Generated at 2022-06-23 21:42:10.138758
# Unit test for constructor of class Structure
def test_Structure():
    st = Structure('en')
    assert st.__dict__ == {"_seed": "1234", "__text": "mimesi", "__inet": "mimesis"}

# Generated at 2022-06-23 21:42:11.529272
# Unit test for method css of class Structure
def test_Structure_css():
    x = Structure().css()
    assert x != None



# Generated at 2022-06-23 21:42:14.091016
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    obj = Structure()
    func_name = 'css_property'
    assert hasattr(obj, func_name)
    assert type(getattr(obj, func_name)()) == str  # noqa: WPS421


# Generated at 2022-06-23 21:42:16.143762
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert isinstance(s.css_property(), str)


# Generated at 2022-06-23 21:42:18.124400
# Unit test for method css of class Structure
def test_Structure_css():
    generator = Structure()
    assert len(generator.css()) > 0



# Generated at 2022-06-23 21:42:19.025356
# Unit test for constructor of class Structure
def test_Structure():
    pass

# Generated at 2022-06-23 21:42:24.275315
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    seed = 2
    test = Structure(seed = seed)
    tag = 'a'
    attribute = 'target'
    expected = ['_blank', '_self', '_parent', '_top']
    actual = []
    for i in range(0,100):
        actual.append(test.html_attribute_value(tag, attribute))
    assert expected == actual


# Generated at 2022-06-23 21:42:26.213715
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Unit test for method css_property of class Structure"""
    s = Structure(seed=0)
    assert s.css_property() == 'font-weight: normal'


# Generated at 2022-06-23 21:42:27.452721
# Unit test for method css of class Structure
def test_Structure_css():
    """Unit test for method css of class Structure."""
    struct = Structure()
    assert struct.css()



# Generated at 2022-06-23 21:42:30.161098
# Unit test for method html of class Structure
def test_Structure_html():
	structure = Structure()
	html = structure.html()
	print(html)

if __name__ == '__main__':
    test_Structure_html()

# Generated at 2022-06-23 21:42:35.344146
# Unit test for method html of class Structure
def test_Structure_html():

    # Initializing an object of class Structure
    structure = Structure()

    # Testing method html of class Structure
    assert isinstance(structure.html(), str)
    assert structure.html() != '<span class="select" id="careers">Ports are created with the built-in function open_port.</span>'
    return

# Generated at 2022-06-23 21:42:42.951567
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure(seed=123)
    # tag: a attribute: download
    print(structure.html_attribute_value(tag='a', attribute='download'))
    # tag: img attribute: srcset
    print(structure.html_attribute_value(tag='img', attribute='srcset'))
    # tag: img attribute: srcset
    print(structure.html_attribute_value(tag='img', attribute='srcset'))
    # tag:  attribute:
    print(structure.html_attribute_value(tag='', attribute=''))
    # tag:  attribute:
    print(structure.html_attribute_value(tag='', attribute=''))

# Generated at 2022-06-23 21:42:48.765604
# Unit test for method html of class Structure
def test_Structure_html():
    """Проверка случайного целочисленного значения атрибутов класса Structure"""
    structure = Structure()
    assert structure.html()

# Generated at 2022-06-23 21:42:51.108977
# Unit test for constructor of class Structure
def test_Structure():
    try:
        s = Structure(seed=42)
        assert(True)
    except Exception as e:
        assert(False)



# Generated at 2022-06-23 21:42:55.339924
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    result = structure.css_property()
    assert isinstance(result, str)
    for css_property in CSS_PROPERTIES:
        assert css_property in result
    assert ':' in result
    assert ';' not in result


# Generated at 2022-06-23 21:43:00.493170
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    for _ in range(0, 1000):
        tag = s.random.choice(["input", "textarea", "optgroup", "option"])
        attribute = s.random.choice(list(s.HTML_CONTAINER_TAGS[tag]))  # type: ignore
        s.html_attribute_value(tag, attribute)

# Generated at 2022-06-23 21:43:02.851855
# Unit test for method css of class Structure
def test_Structure_css():
    """Test method css of class Structure."""
    structure = Structure('en')
    for _ in range(100):
        assert structure.css() != structure.css()


# Generated at 2022-06-23 21:43:12.666204
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSProperty
    from mimesis.schema import Field

    field = Field('css_property')
    for _ in range(10):
        css_val = field.process()
        key, value = css_val.split(':')
        key = key.strip()
        value = value.strip()
        assert key in CSSProperty.__members__
        assert value

    for key in CSSProperty.__members__:
        field = Field('css_property',
                      filter_by={"key": key})
        css_val = field.process()
        assert key in css_val


# Generated at 2022-06-23 21:43:14.385644
# Unit test for constructor of class Structure
def test_Structure():
        """ Test for constructor of class Structure"""
        structure = Structure()
        assert structure is not None


# Generated at 2022-06-23 21:43:23.922787
# Unit test for constructor of class Structure
def test_Structure():
    # Arrange
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.structure import Structure
    from mimesis.builtins.base import BaseSpecProvider

    # Act
    s = Structure()
    g = Gender.MALE
    seed = 3124124124124124124124124124124124124124124124124124124124124
    locale = 'ru-RU'
    provider = RussiaSpecProvider(locale=locale, gender=g, seed=seed)
    s_provider = Structure(provider=provider)
    s_locale = Structure(locale=locale)
    s_gender = Structure(gender=g)
    s_locale_gender = Structure(locale=locale, gender=g)
    s_

# Generated at 2022-06-23 21:43:29.109800
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    attr1 = s.html_attribute_value()
    attr2 = s.html_attribute_value()
    assert s.html_attribute_value().split('=')[0] == attr1.split('=')[0] or s.html_attribute_value().split('=')[0] == attr2.split('=')[0]

test_Structure_html_attribute_value()

# Generated at 2022-06-23 21:43:30.026877
# Unit test for method css of class Structure
def test_Structure_css():
    assert Structure().css() != None


# Generated at 2022-06-23 21:43:31.645523
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    res = structure.css_property()
    assert len(res)>1
    

# Generated at 2022-06-23 21:43:34.432376
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    value = s.html_attribute_value(tag='a', attribute='href')
    assert value.startswith('http') and value.endswith('com')
    value = s.html_attribute_value(tag='a', attribute='title')
    assert len(value) == 3

# Generated at 2022-06-23 21:43:38.620236
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    html = structure.html()
    assert '<' in html
    assert '>' in html
    assert '</' in html
    assert 'id=' in html


# Generated at 2022-06-23 21:43:40.780049
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s._seed == 42
    assert s._locale == 'en'


# Generated at 2022-06-23 21:43:49.660049
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # get instance of Structure class
    mimesis_struct = Structure('en')
    # get random css property
    css_property = mimesis_struct.css_property()
    # split css property to get property, param and their values
    css_property_array = css_property.split(':')
    # check for generated css property param
    css_property_param = css_property_array[0]
    # check for generated css property value
    css_property_value = css_property_array[1]

    # check if random css property param is in css properties or not
    assert css_property_param in list(CSS_PROPERTIES.keys()), 'css property param is not valid'
    # check if generated css property value is valid

# Generated at 2022-06-23 21:43:59.693387
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    import pytest
    from mimesis.enums import HTMLLangAttribute
    structure = Structure(seed=12345)
    attr = structure.html_attribute_value("a", "charset")
    assert attr == "utf-8"

    attr = structure.html_attribute_value("a", "href")
    assert attr == ("http://www.xgfibopj.qa/category/hotels/"
                    "hotels/discover/list/")

    attr = structure.html_attribute_value("a", "id")
    assert attr == "yaku"

    attr = structure.html_attribute_value("a", "lang")
    assert attr in HTMLLangAttribute.__members__.values()

    attr = structure.html_attribute_value("a", "media")


# Generated at 2022-06-23 21:44:02.842943
# Unit test for method css of class Structure
def test_Structure_css():
    _strc = Structure(seed=1234)
    assert _strc.css() == 'a.nunc {display: none; width: 4in; right: 0; }'


# Generated at 2022-06-23 21:44:04.586038
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure('en')
    assert len(structure.css()) > 0


# Generated at 2022-06-23 21:44:10.807694
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    tags = list(HTML_CONTAINER_TAGS.keys())
    s.random.shuffle(tags)

    for tag in tags:
        attributes = list(HTML_CONTAINER_TAGS[tag])
        s.random.shuffle(attributes)
        for attr in attributes:
            s.html_attribute_value(tag, attr)

# Generated at 2022-06-23 21:44:12.635897
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure('en')

    assert structure is not None


# Generated at 2022-06-23 21:44:14.319602
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()
    assert struct is not None


# Generated at 2022-06-23 21:44:17.319998
# Unit test for constructor of class Structure
def test_Structure():
    assert Structure(seed=42).seed == 42
    assert len(Structure().css()) != 0
    assert len(Structure().html()) != 0
    assert len(Structure().html_attribute_value()) != 0

# Generated at 2022-06-23 21:44:19.601687
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    print("Result of method html of class Structure:")
    print("-------------------------------")
    print(structure.html())
    print("-------------------------------")


# Generated at 2022-06-23 21:44:20.634172
# Unit test for method css of class Structure
def test_Structure_css():
    a = Structure()
    assert a.css() != None


# Generated at 2022-06-23 21:44:24.983621
# Unit test for method css of class Structure
def test_Structure_css():
    """Unit test for method css of class Structure."""
    expected_results = """body {
        background-color: #9a9a8e;
        font-size: 18px;
        font-weight: normal;
        margin: auto;
        padding-bottom: 8px;
        padding-left: 14px;
        padding-right: 7px;
        padding-top: 1px
    }"""

    structure = Structure()
    assert structure.css() == expected_results


# Generated at 2022-06-23 21:44:28.819004
# Unit test for method css of class Structure
def test_Structure_css():
    mimesis = Structure()
    for x in range(100):
        css_ = mimesis.css()
        assert isinstance(css_, str)
        assert css_ != ''


# Generated at 2022-06-23 21:44:36.209215
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.structure import Structure
    while(True):
        dt = Datetime(seed=42)
        st = Structure(seed=42)
        st.seed(dt.datetime())
        css = st.css()
        if css == 'border-radius: 1px; color: #a85679; font-style: oblique; height: 1px':
            print("css='{}'".format(css))
            break


# Generated at 2022-06-23 21:44:46.520791
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    assert structure.html_attribute_value() != ''
    assert structure.html_attribute_value() != []
    assert structure.html_attribute_value(tag='html') != ''
    assert structure.html_attribute_value(tag='div') != ''
    assert structure.html_attribute_value(attribute='width') != ''
    assert structure.html_attribute_value(tag='html', attribute='style') != ''
    assert structure.html_attribute_value(tag='div', attribute='width') != ''
    assert structure.html_attribute_value(tag='blockquote', attribute='type') != ''
    assert structure.html_attribute_value(tag='button', attribute='name') != ''

# Generated at 2022-06-23 21:44:55.173211
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis.enums import CSSSelector
    from mimesis.enums import CSSSizeUnit
    from mimesis.enums import CSSPropertyName
    import re

    s = Structure()

    assert re.match(rf'\{CSSSelector.ANY.value}\w+ {{[\w-]+: [\w-]+; '
                    r'[\w-]+: [\w-]+; [\w-]+: [\w-]+; [\w-]+: [\w-]+}}',
                    s.css())

    assert isinstance(s.css(), str)


# Generated at 2022-06-23 21:44:59.804344
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    # Tag and attribute are not specified
    result_value = structure.html_attribute_value()
    assert isinstance(result_value, str), 'Invalid result value'
    for tag in HTML_CONTAINER_TAGS.keys():
        for attribute in HTML_CONTAINER_TAGS[tag]:
            # Tag is not specified
            result_value = structure.html_attribute_value(attribute=attribute)
            assert isinstance(result_value, str), 'Invalid result value'
            # Attribute is not specified
            result_value = structure.html_attribute_value(tag=tag)
            assert isinstance(result_value, str), 'Invalid result value'

# Generated at 2022-06-23 21:45:01.587878
# Unit test for constructor of class Structure
def test_Structure():
    import os
    print(Structure(os.urandom(36)))


# Generated at 2022-06-23 21:45:05.029101
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    results = []
    for tag in HTML_CONTAINER_TAGS:
        for attribute in HTML_CONTAINER_TAGS[tag]:
            results.append(structure.html_attribute_value(tag, attribute))

    assert len(results) > 0

# Generated at 2022-06-23 21:45:06.440617
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert type(Structure().css_property()) == str


# Generated at 2022-06-23 21:45:11.023690
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    html_result = structure.html()
    print(html_result)

    # assert type(html_result) == str
    # assert '<' in html_result
    # assert '>' in html_result
    # assert '</' in html_result


if __name__ == '__main__':
    test_Structure_html()

# Generated at 2022-06-23 21:45:11.954197
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property()

# Generated at 2022-06-23 21:45:15.777482
# Unit test for method html of class Structure
def test_Structure_html():
    strc = Structure()
    som = strc.html()
    assert isinstance(som, str)
    assert som.startswith('<')
    assert som.endswith('>')

# Generated at 2022-06-23 21:45:19.873825
# Unit test for method css of class Structure
def test_Structure_css():
    stru = Structure()
    res = stru.css()
    assert type(res) == str
    try:
        assert len(res) >= 1
    except AssertionError:
        raise AssertionError("failed: length of res is 0")


# Generated at 2022-06-23 21:45:23.285369
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    result = {'('}
    for i in range(100):
        structure = Structure(seed=i)
        css_property = structure.css_property()
        result.add(css_property)
    assert result == {'(', ')', ':', ';'}

# Generated at 2022-06-23 21:45:25.144902
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('en')
    assert structure.css_property() == 'background-color: #f6b3a3'



# Generated at 2022-06-23 21:45:29.848999
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """
    The method test_Structure_html_attribute_value
    tests the method html_attribute_value 
    of the class Structure to check that 
    it returns the right value
    """
    structure = Structure()
    result = structure.html_attribute_value(tag = None, attribute = None)
    print(result)


# Generated at 2022-06-23 21:45:32.353034
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    f = Structure()
    v = f.css_property()
    assert v != None
    assert len(v) > 0
    assert v.count(':') == 1
    assert '-' in v


# Generated at 2022-06-23 21:45:35.991840
# Unit test for method css of class Structure
def test_Structure_css():
    test = Structure(seed=42)
    assert test.css() == "* {font-family: 'julho'; width: 78px; height: 36px; }"


# Generated at 2022-06-23 21:45:43.373215
# Unit test for constructor of class Structure
def test_Structure():
    strc = Structure()
    assert isinstance(strc.css_property(), str)
    assert isinstance(strc.css(), str)
    assert isinstance(strc.html(), str)
    assert isinstance(strc.html_attribute_value(), str)
    assert isinstance(strc.html_attribute_value(), str)
    assert isinstance(strc.html_attribute_value(), str)
    assert isinstance(strc.css_property(), str)

# Generated at 2022-06-23 21:45:45.252399
# Unit test for method css of class Structure
def test_Structure_css():
    struct = Structure()
    for _ in range(0, 1):
        result = struct.css()
        assert(isinstance(result, str))
        print(result)
        

# Generated at 2022-06-23 21:45:50.655571
# Unit test for method html of class Structure
def test_Structure_html():
    def mock_choice(self, source):
        source.sort()
        return source[0]
    Structure.random.choice = mock_choice
    structure = Structure()
    assert structure.html() == '<a href="/"><a href="/">/</a></a>'


# Generated at 2022-06-23 21:45:52.606135
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    structure.html_attribute_value()

# Generated at 2022-06-23 21:45:54.122371
# Unit test for method css of class Structure
def test_Structure_css():
    data = Structure('en').css()
    print(data)



# Generated at 2022-06-23 21:45:55.614040
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    print(Structure().html_attribute_value())


# Generated at 2022-06-23 21:45:58.101105
# Unit test for method css of class Structure
def test_Structure_css():
    data = Structure('en')
    # The default value of the is_unique parameter is False
    assert 'CSS' == data.css()
test_Structure_css()


# Generated at 2022-06-23 21:46:00.041295
# Unit test for method css of class Structure
def test_Structure_css():
    # Arrange
    s = Structure()

    # Act
    result = s.css()

    # Assert
    assert result == result


# Generated at 2022-06-23 21:46:02.423302
# Unit test for method html of class Structure
def test_Structure_html():
    """
    Test case 1 for testing class Structure.
    """
    structure = Structure(seed=1234)
    structure.html()

# Generated at 2022-06-23 21:46:08.742126
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    for i in range(10):
        tag_name = structure.random.choice(list(HTML_CONTAINER_TAGS.keys()))
        tag_attributes = list(HTML_CONTAINER_TAGS[tag_name])  # type: ignore
        attribute_name = structure.random.choice(tag_attributes)
        attribute_value = structure.html_attribute_value(tag_name, attribute_name)
        print('{}={}'.format(attribute_name, attribute_value))

# Generated at 2022-06-23 21:46:11.554344
# Unit test for method css of class Structure
def test_Structure_css():
    assert Structure.css() == '{background: #c2d439; display: block;}'
    assert len(Structure.css()) == len('{background: #c2d439; display: block;}')


# Generated at 2022-06-23 21:46:15.196870
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_provider = Structure()
    structure_provider.random.seed(1)
    result = structure_provider.css_property()
    assert result == 'background-color: #f4d3a1'

# Generated at 2022-06-23 21:46:21.750779
# Unit test for method html of class Structure
def test_Structure_html():
    """Unit test for method "html" of class "Structure".

    The test basically checks that the test does not raise an error
    (which would be a sign that something went wrong), and prints the output.

    The test is not really informative.
    However, the method is so simple that I do not see any value in making
    a more detailed test.

    """
    print(Structure().html())

# Generated at 2022-06-23 21:46:24.107035
# Unit test for constructor of class Structure
def test_Structure():
    x = Structure()
    assert x is not None
    assert x.__class__.__name__ == 'Structure'


# Generated at 2022-06-23 21:46:35.198258
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import Attribute, Tags


# Generated at 2022-06-23 21:46:41.526192
# Unit test for method css of class Structure
def test_Structure_css():
    """Test css method."""

# Generated at 2022-06-23 21:46:43.047136
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    assert s.css()


# Generated at 2022-06-23 21:46:49.851598
# Unit test for method css of class Structure
def test_Structure_css():
    print("test_Structure_css")
    expected = '''
    .box-image {background-color: #f4d3a1; width: 74px; height: 8px}
    .listbox_value {background-color: #f4d3a1; width: 48px; height: 29px}
    .nav li a {background-color: #f4d3a1; width: 28px; height: 47px}'''
    result = Structure().css()
    assert result in expected

# Generated at 2022-06-23 21:46:57.143997
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(seed = 1)
    assert s.css() == "label {width: 1px;height: 56px;font-size: 25px;font-style: inherit;margin-right: 48px;display: inline-table;font-weight: normal;padding-top: 56px;tr: nth-child(3);text-shadow: 56px;font-family: Serif;direction: ltr;transform: inherit;align-items: center;line-height: 20px;text-align: center;color: #85c1b5;font-variant: normal;background-color: #5b5196;border-radius: 10px;position: absolute;margin-left: 1px;border: 0px;list-style-type: circle;}".format()


# Generated at 2022-06-23 21:46:59.139798
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert len(s.css_property()) > 0


# Generated at 2022-06-23 21:47:05.799912
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test the structure class to check the html attribute values"""
    structure = Structure(seed=0)
    assert structure.html_attribute_value(tag='meta', attribute='charset') == 'utf-8'
    assert structure.html_attribute_value(tag='font', attribute='size') == '22'
    assert structure.html_attribute_value(tag='font', attribute='face') == 'mono'
    assert structure.html_attribute_value(tag='font', attribute='colr') == '#123456'

# Generated at 2022-06-23 21:47:07.150570
# Unit test for method css of class Structure
def test_Structure_css():
    assert Structure().css() in CSS_SELECTORS


# Generated at 2022-06-23 21:47:10.726864
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure('en')
    matches = [
        'background',
        'color',
        'position',
    ]
    result = structure.css().split('{')[1][:-1]
    assert any(x in result for x in matches)


# Generated at 2022-06-23 21:47:12.190758
# Unit test for constructor of class Structure
def test_Structure():
    x = Structure()
    assert x.__class__.__name__ == "Structure"


# Generated at 2022-06-23 21:47:13.649726
# Unit test for method css of class Structure
def test_Structure_css():
    struct = Structure('en')
    assert 'presentation' not in struct.css()


# Generated at 2022-06-23 21:47:14.754966
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    print(structure.html())


# Generated at 2022-06-23 21:47:16.900870
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_css_property = Structure(seed=4).css_property()
    assert structure_css_property == 'font-family: \'Lucida Sans Unicode\''
    return 0


# Generated at 2022-06-23 21:47:18.598806
# Unit test for method css of class Structure
def test_Structure_css():
    # arrange
    structure = Structure('en')

    # act
    result = structure.css()

    # assert
    assert len(result.split(' ')) == 3



# Generated at 2022-06-23 21:47:30.411477
# Unit test for constructor of class Structure
def test_Structure():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text
    from mimesis.providers.address import Address
    s = Structure(seed = 0) # Initializing Structure with no params
    assert isinstance(s._Structure__inet, Internet) # Checking __inet
    assert isinstance(s._Structure__text, Text) # Checking __text
    s2 = Structure(locale= "en") # Initializing Structure with locale en
    assert isinstance(s2._Structure__inet, Internet)
    assert isinstance(s2._Structure__text, Text)
    rus_spec = RussiaSpecProvider() # Checking Seed
    assert isinstance(rus_spec.seed, int)
   

# Generated at 2022-06-23 21:47:31.659124
# Unit test for method css of class Structure
def test_Structure_css():
    obj = Structure()
    result = obj.css()
    print('CSS',result)


# Generated at 2022-06-23 21:47:34.826169
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    new_struct = Structure()
    print(new_struct.html_attribute_value('a','href'))

if __name__ == "__main__":
    test_Structure_html_attribute_value()

# Generated at 2022-06-23 21:47:43.399273
# Unit test for method html of class Structure
def test_Structure_html():
    # structure_instance = Structure(seed=5)
    # assert structure_instance.html() == '<q class="decoration" id="support">PVC is a foil material often used to make flooring.</q>'

    structure_instance = Structure(seed=4)
    assert structure_instance.html() == '<div class="flag" id="graphs">Biological and environmental damages.</div>'

    structure_instance = Structure(seed=6)
    assert structure_instance.html() == '<span class="enable" id="monitors">There are two types of materials for this purpose: plastic and composite.</span>'

    structure_instance = Structure(seed=7)
    assert structure_instance.html() == '<span class="zone" id="definitions">For example, a single PC can have a single CPU.</span>'

    structure_instance

# Generated at 2022-06-23 21:47:50.308896
# Unit test for method html of class Structure
def test_Structure_html():
    locale = 'en'
    seed = "00"
    structure = Structure(locale, seed)
    structure.html()
    #assert structure.html() == '<span class="select" id="careers">\n            Ports are created with the built-in function open_port.\n            </span>'
    assert structure.html() == '<h2 class="select" id="careers">\n            Ports are created with the built-in function open_port.\n            </h2>'
    #assert structure.html() == '<p class="green" id="index">\n            Ports are created with the built-in function open_port.\n            </p>'

# Generated at 2022-06-23 21:47:52.451201
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure
    assert structure.__inet
    assert structure.__text

# Generated at 2022-06-23 21:47:54.557195
# Unit test for method html of class Structure
def test_Structure_html():
    print('test_Structure_html')
    structure = Structure()
    print(structure.html())


# Generated at 2022-06-23 21:48:05.257834
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure(seed=0)

# Generated at 2022-06-23 21:48:09.706659
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure(seed=100)
    assert s.html() == '<aside class="select" id="careers">Ports are created with the built-in function open_port.</aside>'


# Generated at 2022-06-23 21:48:11.205795
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    a=Structure()
    print(a.css_property())


# Generated at 2022-06-23 21:48:19.191736
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    test = Structure()

    # html_attribute_value has no arguments
    result = test.html_attribute_value()
    assert isinstance(result, str)

    # html_attribute_value has no arguments
    # and is called many times
    # and values must be different
    test_values = set()
    test_num = 100
    for i in range(test_num):
        test_values.add(test.html_attribute_value())
    assert len(test_values) >= test_num / 2

    # html_attribute_value has arguments
    # and the value must be equal to the second argument
    result = test.html_attribute_value(
        'img',
        'src',
    )
    assert result == 'http://kirichuk.fr/uddd/'

# Generated at 2022-06-23 21:48:22.593741
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Arrange
    s = Structure()
    attribute = 'href'
    tag = 'a'
    # Act
    html = s.html_attribute_value(tag, attribute)
    # Assert
    assert isinstance(html, str)
    assert html.startswith('http://')


# Generated at 2022-06-23 21:48:23.624395
# Unit test for method css of class Structure
def test_Structure_css():
    str1 = Structure()
    str1.css()


# Generated at 2022-06-23 21:48:28.840591
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.providers.structure import Structure
    from mimesis.builtins import Field

    # sample a tag
    structure = Structure()
    tag = structure.random.choice(list(Structure.Meta.html_attributes.keys()))
    # sample an attribute of that tag
    attribute = structure.random.choice(
        list(Structure.Meta.html_attributes[tag]))
    # generate random value for that attribute
    random_value = structure.html_attribute_value(tag, attribute)
    # check that generated value is valid
    assert Field.is_valid(tag, attribute, random_value)


# Generated at 2022-06-23 21:48:30.451222
# Unit test for method html of class Structure
def test_Structure_html():
    assert Structure().html() == "<head>\n</head>"


# Generated at 2022-06-23 21:48:39.840332
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.builtins import StrictField

    def internal_html_attribute_value(tag: str, attribute: str, value: str):
        s = Structure(seed=123)
        result = s.html_attribute_value(tag=tag, attribute=attribute)
        assert isinstance(result, str)
        assert value == result


# Generated at 2022-06-23 21:48:41.322745
# Unit test for method html of class Structure
def test_Structure_html():
	inst = Structure()
	assert isinstance(inst.html(), str)

# Generated at 2022-06-23 21:48:46.822659
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    assert isinstance(structure.html_attribute_value(), str)
    assert isinstance(structure.html_attribute_value('img', 'title'), str)
    assert structure.html_attribute_value()
    assert structure.html_attribute_value('img', 'title')


# Generated at 2022-06-23 21:48:50.098127
# Unit test for method html of class Structure
def test_Structure_html():
    import random
    import mimesis
    #   Initialize
    s = Structure('en', random.choice([True, False]), random.randint(0,1000))
    #   html()
    s.html()

# Generated at 2022-06-23 21:48:50.966424
# Unit test for method html of class Structure
def test_Structure_html():
    st = Structure()
    print(st.html())


# Generated at 2022-06-23 21:48:55.951249
# Unit test for method html of class Structure
def test_Structure_html():
    import pandas as pd
    # pandas display setting
    pd.set_option('display.max_rows', 999)
    pd.set_option('display.max_columns', 999)
    pd.set_option('display.width', 999)
    n = 10000
    seed = 0
    df = pd.DataFrame()
    strc = Structure()
    strc.seed(seed)
    df['html'] = [strc.html() for _ in range(n)]
    print(df.head(10))
    return


# Generated at 2022-06-23 21:49:00.922856
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSProperties

    s = Structure('ru')
    for attr in CSSProperties.__members__:
        prop = s.css_property()
        assert attr in prop, "Property not found in struct"



# Generated at 2022-06-23 21:49:03.436971
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    css_property = Structure().css_property()
    assert len(css_property.split(":")) == 2


# Generated at 2022-06-23 21:49:04.492059
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    val = structure.css_property()
    assert val is not None

# Generated at 2022-06-23 21:49:07.813182
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    provider = Structure()
    text = Text()
    internet = Internet()
    attribute = provider.html_attribute_value(attribute='href')


    assert text.word() not in attribute
    assert internet.home_page() in attribute


# Generated at 2022-06-23 21:49:11.749960
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Generate random value for attribute "type" of tag "input"
    gen = Structure()
    j = gen.html_attribute_value(tag='input', attribute='type')
    assert j in ["text", "submit"]


# Generated at 2022-06-23 21:49:14.278347
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(seed = 1)
    assert s.css() == "'html' {\n style: 'SELECTOR'\n color: '#0d8238';\n\
    font-family: 'Helvetica'\n\
    }"


# Generated at 2022-06-23 21:49:16.785933
# Unit test for constructor of class Structure
def test_Structure():
    structure1 = Structure(seed=42)
    structure2 = Structure(seed='foobar')
    assert isinstance(structure1, Structure)
    assert isinstance(structure2, Structure)



# Generated at 2022-06-23 21:49:28.540188
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure('en')
    print(structure.html_attribute_value(tag='div', attribute='id'))
    print(structure.html_attribute_value(attribute='id'))
    print(structure.html_attribute_value(tag='div', attribute='style'))
    print(structure.html_attribute_value(attribute='style'))
    print(structure.html_attribute_value(tag='div', attribute='data-id'))
    print(structure.html_attribute_value(attribute='data-id'))
    print(structure.html_attribute_value(tag='div', attribute='class'))
    print(structure.html_attribute_value(attribute='class'))

if __name__ == '__main__':
    test_Structure_html_attribute_value()

# Generated at 2022-06-23 21:49:29.019464
# Unit test for method css of class Structure
def test_Structure_css():
    assert Structure().css() is not None


# Generated at 2022-06-23 21:49:30.822810
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s.__inet != None
    assert s.__text != None

# Generated at 2022-06-23 21:49:35.079868
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()

    value1 = structure.css()
    assert isinstance(value1, str)
    assert value1.count(' ') > 0
    assert len(value1) > 0


# Generated at 2022-06-23 21:49:37.673448
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    html = structure.html()

# Generated at 2022-06-23 21:49:39.269813
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    output = structure.css_property()
    assert type(output) is str


# Generated at 2022-06-23 21:49:47.746279
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    # No value specified
    tag=None
    attribute=None
    tag_name = tag
    tag_attributes = ''
    actual = Structure().html_attribute_value(tag, attribute)
    assert actual != tag_attributes

    # tag = 'img', attribute = 'alt'
    tag = 'img'
    attribute = 'alt'
    tag_name = tag
    tag_attributes = attribute
    actual = Structure().html_attribute_value(tag, attribute)
    assert actual != tag_attributes

# Generated at 2022-06-23 21:49:51.379111
# Unit test for method html of class Structure

# Generated at 2022-06-23 21:49:53.552231
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    s = structure.css()
    assert isinstance(s, str)


# Generated at 2022-06-23 21:50:03.420343
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    provider = Structure()
    result = provider.html_attribute_value(tag = 'span', attribute = 'class')
    assert type(result) == str
    result = provider.html_attribute_value(tag = 'span', attribute = 'id')
    assert type(result) == str
    result = provider.html_attribute_value(tag = 'link', attribute = 'rel')
    assert type(result) == str
    result = provider.html_attribute_value(tag = 'link', attribute = 'type')
    assert type(result) == str
    result = provider.html_attribute_value(tag = 'a', attribute = 'href')
    assert type(result) == str
    result = provider.html_attribute_value(tag = 'a', attribute = 'target')
    assert type(result) == str
    result = provider.html_

# Generated at 2022-06-23 21:50:07.840921
# Unit test for constructor of class Structure
def test_Structure():
    class StructureTest(Structure):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    st = StructureTest(seed=0)

    assert st.Meta.name == 'structure'
    assert st.__text.generator.last_int == 43
    assert st.__inet.generator.last_int == 36


# Generated at 2022-06-23 21:50:09.668155
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    html = structure.html()
    print(html)
    assert html is not None


# Generated at 2022-06-23 21:50:22.254008
# Unit test for method css of class Structure
def test_Structure_css():
    S = Structure()
    assert re.match(
        r'^\w+(\.\w+)* \{\s+\w+(: [#a-f\d]{3,6}|: \d+\%|: \d+\w+|: [a-z]+);'
        r'\s+\w+: [#a-f\d]{3,6};\s+\w+: \w+;\s+\w+: [a-z]+;\s+\w+: \d+\%'
        r'(\; \w+: \d+\w+)?(\; \w+: [#a-f\d]{3,6})?(\; \w+: [a-z]+)?\s+\}$',
        S.css(),
    ) is not None

# Generated at 2022-06-23 21:50:33.461693
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from random import randint
    from mimesis.enums import HTMLTag, HTMLAttribute

    structure = Structure("en")

    for tag in HTMLTag:
        for attr in HTMLAttribute:
            if attr in tag.get_attributes():
                if tag == HTMLTag.META:
                    continue
                try:
                    attr_value = structure.html_attribute_value(tag.value, attr.value)
                    print("HTML Tag: " + tag.value + " HTML Attribute: " + attr.value +
                          " Attribute Value: " + attr_value)
                except NotImplementedError:
                    print("HTML Tag: " + tag.value + " HTML Attribute: " + attr.value)
                    pass

if __name__ == '__main__':
    test_Structure_html_

# Generated at 2022-06-23 21:50:37.760862
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    attr_value = structure.html_attribute_value('a', 'href')
    # print(attr_value)  # https://www.bradford-adams.com/
    assert attr_value == 'https://www.bradford-adams.com/'



# Generated at 2022-06-23 21:50:43.458505
# Unit test for constructor of class Structure
def test_Structure():
    # Create the instance of class Structure
    structure = Structure()
    
    # Check attributes
    assert structure.seed
    assert not hasattr(structure, '_BaseDataProvider__locale')
    assert not hasattr(structure, '_BaseDataProvider__localized')
    assert not hasattr(structure, '_BaseDataProvider__seed')
    
    

# Generated at 2022-06-23 21:50:46.137689
# Unit test for constructor of class Structure
def test_Structure():
    # pylint: disable=missing-docstring
    structure = Structure()
    assert isinstance(structure, Structure) and hasattr(structure, 'Meta')

# Generated at 2022-06-23 21:50:49.992789
# Unit test for method html of class Structure
def test_Structure_html():
    # Seed for getting always the same random result
    seed = 0
    structure = Structure(seed=seed, locale='en')
    result = structure.html()

    # If you delete "seed=seed" and run this unit test, then you will get
    # different random results
    expected = '<div id="eugen" class="technique">' \
               'In the Workflow tab, click the title of the' \
               ' workflow you want to review or monitor.</div>'

    assert expected == result

# Generated at 2022-06-23 21:51:00.216292
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()

    def test_attribute_type_is_css():

        result = structure.html_attribute_value(
            tag='div', attribute='style')
        assert result in ['css', 'color', 'size']

        result = structure.html_attribute_value(
            tag='div', attribute='style')
        assert result in ['css', 'color', 'size']

        result = structure.html_attribute_value(
            tag='a', attribute='style')
        assert result in ['css', 'color', 'size']

    def test_attribute_type_is_word():

        result = structure.html_attribute_value(
            tag='img', attribute='src')
        assert result == 'word'

        result = structure.html_attribute_value(
            tag='img', attribute='alt')
        assert result == 'word'