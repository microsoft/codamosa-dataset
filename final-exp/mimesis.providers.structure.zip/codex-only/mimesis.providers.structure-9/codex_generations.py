

# Generated at 2022-06-23 21:41:03.214189
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure(seed=1234)
    expected_css = 'li{padding-left: 1px; background-position: bottom; width: 44px; font-size: 63px; padding-top: 80%; position: top; background-color: #7936dc}'
    assert expected_css == structure.css()


# Generated at 2022-06-23 21:41:06.324233
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    assert isinstance(structure.css(), str)
    assert structure.css() is not None
    assert structure.css() != '<a>'


# Generated at 2022-06-23 21:41:08.149108
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    print("Testing Structure class constructor")
    assert (s.seed == None)


# Generated at 2022-06-23 21:41:09.389774
# Unit test for constructor of class Structure
def test_Structure():
    assert Structure().seed is not None

# Generated at 2022-06-23 21:41:12.480015
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure().html_attribute_value() == Structure().html_attribute_value()
    assert Structure().html_attribute_value('a', 'href') == Structure().html_attribute_value('a', 'href')


# Generated at 2022-06-23 21:41:14.223811
# Unit test for constructor of class Structure
def test_Structure():
    assert Structure().seed == 123

# Generated at 2022-06-23 21:41:16.203928
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    css = s.css()
    print(css)


# Generated at 2022-06-23 21:41:21.505963
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    assert Structure(RussiaSpecProvider(gender=Gender.MALE)).css_property() == 'text-decoration: line-through'
    assert Structure(RussiaSpecProvider(gender=Gender.FEMALE)).css_property() != 'text-decoration: line-through'

# Generated at 2022-06-23 21:41:28.018057
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure(seed=456)

    for tag, attribute in [('a', 'href'), ('img', 'src')]:
        for index in range(10):
            assert structure.html_attribute_value(tag, attribute) == 'https://www.example.com'

    for tag, attribute in [('form', 'action'), ('input', 'action'), ('button', 'action')]:
        for index in range(10):
            assert structure.html_attribute_value(tag, attribute) == '/action' or structure.html_attribute_value(tag, attribute) == 'http://www.example.com/action'


# Generated at 2022-06-23 21:41:29.443988
# Unit test for method html of class Structure
def test_Structure_html():
    result = Structure.html()
    pass
    # print(result)

# Generated at 2022-06-23 21:41:31.460776
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s.seed is not None
    assert s.random is not None
    assert s.__text is not None


# Generated at 2022-06-23 21:41:34.022697
# Unit test for method html of class Structure
def test_Structure_html():
    item = Structure(seed=1)
    expected = '<html lang="en" class="caption">Bees love dwarf trees.</html>'
    actual = item.html()

    assert expected == actual


# Generated at 2022-06-23 21:41:36.064075
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    t = s.css()
    assert t != None


# Generated at 2022-06-23 21:41:39.821319
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st = Structure('en')
    for _ in range(20):
        css = st.css_property()
        assert css != ''
        assert isinstance(css, str)


# Generated at 2022-06-23 21:41:44.964383
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis.enums import CSS
    s = Structure('en')
    res = s.css()
    assert isinstance(res, str)
    assert s.random.choice(CSS.SELECTORS) in res.lower()
    assert s.random.choice(CSS.PROPERTIES) in res.lower()
    assert '#' in res or 'rgb' in res

# Generated at 2022-06-23 21:41:48.240847
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert (structure.__class__.__name__ == "Structure")
    assert (structure.__class__.__module__ == "mimesis.builtins.structure")


# Generated at 2022-06-23 21:41:49.890542
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    a = s.html_attribute_value(tag='a', attribute='href')
    assert a == 'url'

# Generated at 2022-06-23 21:41:53.558209
# Unit test for method css of class Structure
def test_Structure_css():
    d = Structure()
    tag = d.random.choice(HTML_MARKUP_TAGS)
    props = '; '.join([d.css_property() for _ in range(d.random.randint(1, 6))])
    print(tag)
    print(props)


# Generated at 2022-06-23 21:41:54.680607
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s=Structure('en')
    s.css_property()


# Generated at 2022-06-23 21:41:56.124229
# Unit test for method css of class Structure
def test_Structure_css():
    local_structure = Structure(seed=42)
    print(local_structure.css())


# Generated at 2022-06-23 21:42:00.506047
# Unit test for method html of class Structure
def test_Structure_html():
    """Unit test for method html of class Structure"""

    structure = Structure()
    structure.random.seed(1)
    result = structure.html()
    assert result == '<address id="services">Her husband, the coke-bottle.' \
    '</address>', result

    # Test data from example section
    structure.random.seed(42)
    result = structure.html()
    assert result == '<address id="services">Her husband, the coke-bottle.' \
    '</address>', result


# Generated at 2022-06-23 21:42:04.753807
# Unit test for method html of class Structure
def test_Structure_html():
    import unittest
    import xml.etree.ElementTree as ET
    from mimesis.enums import HTMLTag

    html = Structure()
    res = html.html()
    root = ET.fromstring(res)

    assert root.tag in HTMLTag.__members__.values()


# Generated at 2022-06-23 21:42:05.984423
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    html = [structure.html() for _ in range(10)]
    assert len(html) == 10
    

# Generated at 2022-06-23 21:42:07.471327
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    print(s.css())
    print(s.html())

# Generated at 2022-06-23 21:42:09.521360
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure(seed=65)
    assert s.css_property() == 'top: 2px'

# Generated at 2022-06-23 21:42:18.582467
# Unit test for method css of class Structure
def test_Structure_css():
    # mock_random = Mock()
    # mock_random.choice = MagicMock(side_effect=['#8cc1c0', 'm62'])
    # mock_random.randint = MagicMock(return_value=42)
    structure = Structure()
    print('structure.css(): ')
    print(structure.css())
    print('structure.css_property(): ')
    print(structure.css_property())
    print('structure.html(): ')
    print(structure.html())
    print('structure.html_attribute_value(): ')
    print(structure.html_attribute_value())
    print('structure.html_attribute_value(tag=\'p\'): ')
    print(structure.html_attribute_value(tag='p'))

# Generated at 2022-06-23 21:42:22.152360
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Result of this test case may vary depending on random choice
    structure = Structure(seed=12345)
    tag = 'a'
    attr = 'href'
    value = structure.html_attribute_value(tag, attr)
    assert value == 'http://elite.gov'

# Generated at 2022-06-23 21:42:24.004892
# Unit test for constructor of class Structure
def test_Structure():
    object = Structure()
    assert object.__class__.__name__=="Structure"

# Generated at 2022-06-23 21:42:26.217733
# Unit test for constructor of class Structure
def test_Structure():
    """Test constructor of class Structure"""
    structureClassTest = Structure()
    assert type(structureClassTest) == Structure



# Generated at 2022-06-23 21:42:37.475257
# Unit test for method css of class Structure
def test_Structure_css():
    import re
    s = Structure('en',seed=0)
    test = str(s.css())

# Generated at 2022-06-23 21:42:41.835010
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from pprint import pprint
    from mimesis.enums import HTMLElement
    from mimesis.enums import HTMLElementAttribute

    tag = HTMLElement.SECTION
    attribute = HTMLElementAttribute.CLASS
    value = Structure().html_attribute_value(tag, attribute)

    # pprint(value)
    assert isinstance(value, str)

# Generated at 2022-06-23 21:42:43.287518
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    for i in range(1, 100):
        s.css_property()


# Generated at 2022-06-23 21:42:48.067193
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Unit test for method css_property of class Structure.
    """
    css = Structure()
    # print('css: ', css.css_property())
    assert isinstance(css.css_property(), str)


# Generated at 2022-06-23 21:42:51.141376
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert isinstance(s, Structure)
    assert isinstance(s.__inet, Internet)
    assert isinstance(s.__text, Text)


# Generated at 2022-06-23 21:42:52.325893
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    print(structure.css_property())


# Generated at 2022-06-23 21:43:03.371322
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from pytest import raises
    from hypothesis import given, settings
    from .strategies import (
        html_tag_name,
        html_tag_attribute_name,
        html_tag_attribute_type_and_value,
    )

    structure = Structure(seed=12345)
    # when tag is not supported
    with raises(NotImplementedError):
        structure.html_attribute_value('bla-bla', 'bla-bla')
    with raises(NotImplementedError):
        structure.html_attribute_value(tag='bla-bla')
    # when attribute is not supported
    with raises(NotImplementedError):
        structure.html_attribute_value('body', 'bla-bla')

# Generated at 2022-06-23 21:43:05.852586
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert isinstance(s, Structure) is True


# Generated at 2022-06-23 21:43:09.527557
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    st = Structure(seed=123)
    assert st.html_attribute_value('a', 'href') == 'https://www.the-blocks.org'
    assert st.html_attribute_value('area', 'alt') == 'Chase'

# Generated at 2022-06-23 21:43:19.524143
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis.enums import DataField
    s = Structure()
    t = Text()

    assert len(s.css()) > 0

    assert s.css(data_field=DataField.CSS) != "";
    assert s.css(data_field=DataField.CSS) == s.css()

    # Get list of CSS selectors
    css_sel_lst = list(set(CSS_SELECTORS) | set(t.word()))
    assert isinstance(css_sel_lst, list)

    assert s.css(data_field=DataField.CSS_SELECTOR) in css_sel_lst
    css_sel = s.css(data_field=DataField.CSS_SELECTOR)
    assert css_sel in CSS_SELECTORS or css_sel in t.word()
   

# Generated at 2022-06-23 21:43:23.664900
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure"""
    rand_structure = Structure()

    tag = "a"
    attribute = "rel"

    assert rand_structure.html_attribute_value(tag, attribute) in HTML_CONTAINER_TAGS["a"]["rel"]
    assert rand_structure.html_attribute_value(tag, "href") in HTML_CONTAINER_TAGS["a"]["href"]

# Generated at 2022-06-23 21:43:31.233249
# Unit test for method css of class Structure
def test_Structure_css():
    print('Start test_Structure_css')
    structure = Structure(seed=42)
    target_result = 'animation-timing-function: ease-in-outs'
    actual_result = structure.css_property()
    if actual_result == target_result:
        print('actual_result == target_result')
        print('actual_result(%s) == target_result(%s)' %
                (actual_result, target_result))
    else:
        print('actual_result != target_result')
        print('actual_result(%s) != target_result(%s)' %
                (actual_result, target_result))
    print('Finish test_Structure_css')


# Generated at 2022-06-23 21:43:33.422520
# Unit test for constructor of class Structure
def test_Structure():
    st = Structure()
    print(st.css())


# Generated at 2022-06-23 21:43:36.359850
# Unit test for method html of class Structure
def test_Structure_html():
    struct = Structure()
    assert struct.html() == '<p>Simon, Charles and Charles, Charles.</p>'


# Generated at 2022-06-23 21:43:37.037152
# Unit test for method html of class Structure
def test_Structure_html():
    struct = Structure()
    print(struct.html())


# Generated at 2022-06-23 21:43:40.366770
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    result = s.css_property()
    print(result)

if __name__ == '__main__':
    test_Structure_css_property()

# Generated at 2022-06-23 21:43:44.140091
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # arrange
    css = ''
    # act
    for i in range(10000):
        s = Structure()
        css = css + s.css_property()
    # assert
    is_all_case = ':' in css and ';' in css and '; ' in css
    is_any_case = ':' in css or ';' in css or '; ' in css
    assert is_all_case is True and is_any_case is True


# Generated at 2022-06-23 21:43:46.553718
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    html = structure.html()
    print(html)


# Generated at 2022-06-23 21:43:49.218428
# Unit test for constructor of class Structure
def test_Structure():
    generator = Structure()
    assert generator is not None
    assert generator.locale == 'en'


# Generated at 2022-06-23 21:43:53.644535
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    html_tag = 'a'
    attr = 'class'
    structure.html_attribute_value(html_tag, attr)
    attr = 'style'
    structure.html_attribute_value(html_tag, attr)



# Generated at 2022-06-23 21:44:00.592790
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.utils import modify, get_reference_data
    from mimesis.data import CSS_PROPERTIES

    s = Structure(seed=0)
    assert s.css_property() == 'margin: 5px'

    m = modify(CSS_PROPERTIES, key_func=lambda k: '{}: '.format(k))
    s = Structure(seed=1)
    assert s.css_property() == 'margin: auto'

    data = get_reference_data('css_properties.json')
    s = Structure(seed=2)
    assert s.css_property() == 'margin: 50px'


# Generated at 2022-06-23 21:44:05.094219
# Unit test for constructor of class Structure
def test_Structure():
    from mimesis.enums import TextFormat
    from mimesis.providers.structure import Structure
    structure = Structure()
    assert structure is not None
    assert structure.seed is not None
    assert structure.random is not None
    assert structure.__inet is not None
    assert structure.__text is not None
# End


# Generated at 2022-06-23 21:44:07.080440
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure('en')
    assert structure._seed is not None


# Generated at 2022-06-23 21:44:10.081955
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Test for method css_property of class Structure.

    :return: None.
    """
    s = Structure()
    print(s.css_property())
    print(s.css_property())
    print(s.css_property())
    assert True


# Generated at 2022-06-23 21:44:19.433812
# Unit test for method html of class Structure
def test_Structure_html():
    x = Structure(seed=12345)
    a = x.html()
    b = x.html('p', 'class')
    expected_a = '<strong class="bile-duct" id="bordel" onload="understood" style="bottom: 75px">Vietnamese only became the language of the official state in the 20th century.</strong>'
    expected_b = '<p class="rehash">Climb from the machine and to the storm.</p>'
    if a == expected_a:
        print("'a' is ok")
    else:
        print("'a' is not ok")
    if b == expected_b:
        print("'b' is ok")
    else:
        print("'b' is not ok")


# Generated at 2022-06-23 21:44:24.864583
# Unit test for method css of class Structure
def test_Structure_css():
    import mimesis.builtins
    builtins = mimesis.builtins.Builtins('en')
    s = Structure('en')
    css_str = s.css()
    # The returned string should contain the selector
    assert '{' in css_str
    assert '}' in css_str
    # Count the number of properties inside the brackets
    # The data does not contain a property with the form "property : property"
    for i in range(css_str.count(';')):
        prop = builtins.tokenize(css_str, separator=';')[i]
        assert prop.count(':') == 1


# Generated at 2022-06-23 21:44:26.068226
# Unit test for method css of class Structure
def test_Structure_css():
    t=Structure()
    print(t.css())


# Generated at 2022-06-23 21:44:29.806486
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure('en')
    result = structure.css()
    assert isinstance(result, str)
    assert len(result) >= 10


# Generated at 2022-06-23 21:44:40.313687
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert isinstance(s.html_attribute_value(tag='a', attribute='id'), str)
    assert isinstance(s.html_attribute_value(tag='a', attribute='name'), str)
    assert isinstance(s.html_attribute_value(tag='script', attribute='type'), str)
    assert isinstance(s.html_attribute_value(tag='script', attribute='src'), str)
    assert isinstance(s.html_attribute_value(tag='script', attribute='type'), str)
    assert isinstance(s.html_attribute_value(tag='img', attribute='src'), str)
    assert isinstance(s.html_attribute_value(tag='img', attribute='alt'), str)
    assert isinstance(s.html_attribute_value(tag='img', attribute='width'), str)
   

# Generated at 2022-06-23 21:44:41.973101
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    assert (type(structure.css()) is str)



# Generated at 2022-06-23 21:44:45.923348
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct_obj = Structure('en')
    assert isinstance(struct_obj.html_attribute_value('option', 'class'), str)
    assert len(struct_obj.html_attribute_value('option', 'id')) > 0
    assert struct_obj.html_attribute_value('option', 'id') != struct_obj.html_attribute_value('option', 'id')


# Generated at 2022-06-23 21:44:48.148817
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    css_property = structure.css_property()

    assert isinstance(css_property, str)


# Test for method css of class Structure

# Generated at 2022-06-23 21:44:54.540076
# Unit test for constructor of class Structure
def test_Structure():
    """Test case
    """
    # Test class instantiation
    s = Structure()
    s2 = Structure()

    # Test get_seed()
    assert isinstance(s.get_seed(), int)
    assert isinstance(s2.get_seed(), int)

    # Test get_locale()
    assert isinstance(s.get_locale(), str)
    assert isinstance(s2.get_locale(), str)

    # Test css()
    assert isinstance(s.css(), str)

    # Test css_property()
    assert isinstance(s.css_property(), str)

    # Test html()
    assert isinstance(s.html(), str)

    # Test html_attribute_value()
    assert isinstance(s.html_attribute_value(), str)

# Generated at 2022-06-23 21:45:04.603515
# Unit test for method css of class Structure
def test_Structure_css():
    struct = Structure()
    struct.seed(0)
    assert struct.css() == 'img {border: 2px solid #d68ff3; width: 5.3px}'

    struct.seed(1)
    assert struct.css() == '#search.cite {display: list-item; border: 1px solid #3cda12}'

    struct.seed(2)
    assert struct.css() == 'video {border: thick ridge #5bf6fd}'

    struct.seed(3)
    assert struct.css() == 'span {float: right; box-sizing: border-box}'

    struct.seed(4)
    assert struct.css() == '.cite {padding-right: 25px; margin: 0.8px}'

    struct.seed(5)

# Generated at 2022-06-23 21:45:09.852433
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value(tag = "span", attribute = "class") == "css"
    assert structure.html_attribute_value(tag = "span", attribute = "id") == "word"
    assert structure.html_attribute_value("a", "href") == "url"
    assert structure.html_attribute_value("a", "rel") == "alternate"

# Generated at 2022-06-23 21:45:11.082824
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    assert isinstance(structure.html(), str)

# Generated at 2022-06-23 21:45:13.892668
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure(seed=1234567890)
    css = structure.css()
    assert css == 'img {}'


# Generated at 2022-06-23 21:45:23.550335
# Unit test for method html of class Structure
def test_Structure_html():
    struct = Structure(seed=1)
    list_html = []
    
    for i in range(10):
        html_random = struct.html()
        list_html.append(html_random)

# Generated at 2022-06-23 21:45:26.444677
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    provider = Structure(seed=111)
    target = provider.css_property()
    result = 'border-top-style'
    assert result == target


# Generated at 2022-06-23 21:45:27.177072
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    struct = Structure()
    struct.css_property()

# Generated at 2022-06-23 21:45:28.922496
# Unit test for method css of class Structure
def test_Structure_css():
    for i in range(100):
        assert isinstance(Structure().css(), str)


# Generated at 2022-06-23 21:45:30.262217
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    str = structure.html()
    assert type(str) is str

# Generated at 2022-06-23 21:45:33.236882
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    output = structure.html()
    assert isinstance(output, str)
    assert len(output) > 0


# Generated at 2022-06-23 21:45:45.157096
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure(seed=1)
    assert structure.html_attribute_value() == '#57f6d0'
    assert structure.html_attribute_value('img',
                                          'width') == '60px'
    assert structure.html_attribute_value('a',
                                          'href') == 'https://white.com/'
    assert structure.html_attribute_value('span',
                                          'id') == 'paint'
    assert structure.html_attribute_value('div',
                                          'class') == 'select'
    assert structure.html_attribute_value('div',
                                          'rel') == 'of'
    assert structure.html_attribute_value('div',
                                          'name') == 'Ut et ipsa voluptas'

# Generated at 2022-06-23 21:45:47.463278
# Unit test for method css of class Structure
def test_Structure_css():
    M = Structure()
    for _ in range(10):
        assert M.css()

# Generated at 2022-06-23 21:45:50.710778
# Unit test for constructor of class Structure
def test_Structure():
    # init
    s = Structure()
    # assert
    assert s.locale == 'en'
    assert s.seed == 42


# Generated at 2022-06-23 21:45:53.128897
# Unit test for constructor of class Structure
def test_Structure():
    st = Structure()
    print(st.css())
    print(st.html())

test_Structure()

# Generated at 2022-06-23 21:46:01.451032
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis.enums import CSSSizeUnits
    s = Structure('en')
    assert any(s.css() == '{}px'.format(n) for n in range(1, 99))
    assert any(u.value in s.css() for u in CSSSizeUnits)

    assert 'background-color:' in s.css()
    assert '#' in s.css()

    assert any(name in s.css() for name in list(CSS_PROPERTIES))

    assert any(name in s.css() for name in HTML_MARKUP_TAGS)
    assert any(name in s.css() for name in list(HTML_CONTAINER_TAGS))


# Generated at 2022-06-23 21:46:08.312642
# Unit test for constructor of class Structure
def test_Structure():
    obj = Structure()

    test = obj.css()
    assert isinstance(test, str)
    assert len(test) > 0

    test = obj.css_property()
    assert isinstance(test, str)
    assert len(test) > 0
    assert ':' in test

    test = obj.html()
    assert isinstance(test, str)
    assert len(test) > 0

    test = obj.html_attribute_value()
    assert isinstance(test, str)
    assert len(test) > 0


# Generated at 2022-06-23 21:46:10.302957
# Unit test for method css of class Structure
def test_Structure_css():
    import pprint
    s = Structure()
    result = s.css()
    pprint.pprint(result)


# Generated at 2022-06-23 21:46:14.557629
# Unit test for constructor of class Structure
def test_Structure():
    x = Structure(seed=12345)
    assert x.Meta.name == 'structure' and x.Meta.provider_name == 'Structure' #the name and provider_name of class Meta of class Structure is 'structure' and 'Structure'

# Generated at 2022-06-23 21:46:18.162755
# Unit test for method html of class Structure
def test_Structure_html():
    a = Structure()
    b = a.html()
    for i in range(0,68):
        b.find(" ")

# Generated at 2022-06-23 21:46:18.975805
# Unit test for constructor of class Structure
def test_Structure():
    st = Structure()
    meta = st.Meta
    assert meta.name == 'structure'


# Generated at 2022-06-23 21:46:21.014003
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('div', 'id') != None

# Generated at 2022-06-23 21:46:25.574770
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    result = structure.css()
    assert isinstance(result, str)
    assert len(result) >= 10
    assert result[:3].lower() in ['h1 ', 'p ', 'b ', 'a ', '.c ', '#d ']
    assert result[-2:] == '}'


# Generated at 2022-06-23 21:46:32.348001
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    import pytest
    from mimesis.builtins.structure import Structure
    structure=Structure()
    result = structure.css_property()
    assert type(result)==str 
    with pytest.raises(NotImplementedError):
        structure.html_attribute_value(tag='a',attribute='wrongAttribute')
    with pytest.raises(NotImplementedError):
        structure.html_attribute_value(tag='wrongTag',attribute='href')

# Generated at 2022-06-23 21:46:40.287065
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # генерация экземпляра класса Structure
    tmp = Structure()

    # генерация произвольного числа и поиск по его индексу соответствующего значения в списке CSS_PROPERTIES
    for i in range(10):
        tmp.random.randint(1, 10)

        key = tmp.random.choice(list(CSS_PROPERTIES.keys()))
        val = CSS_PROP

# Generated at 2022-06-23 21:46:47.542897
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.providers.structure import Structure
    from mimesis.providers.text import Text
    from mimesis.enums import HTMLElements
    s = Structure()
    t = Text()
    attr = 'class'
    tag = 'link'
    input = (tag, attr)
    output = s.html_attribute_value(tag, attr)
    expected = t.word()
    assert output == expected, 'Attribute value missmatch'


# Generated at 2022-06-23 21:46:50.477428
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    struc = Structure('en', 12345)
    if(struc.css_property()!="align-content: baseline"):
        raise AssertionError
    else:
        print('tests passed')


# Generated at 2022-06-23 21:46:54.257612
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.providers.structure import Structure

    # Creating an instance of Structure class
    structure = Structure()

    # Generating random CSS property
    from_fixture = 'background-color: #f4d3a1'
    from_test = structure.css_property()
    assert from_fixture == from_test


# Generated at 2022-06-23 21:46:58.673044
# Unit test for method css of class Structure
def test_Structure_css():
    import mimesis
    import mimesis.schema
    struct = mimesis.Structure()
    schema = mimesis.schema.Field('css')
    print(struct.process(schema))

# Generated at 2022-06-23 21:47:01.855723
# Unit test for method css of class Structure
def test_Structure_css():
    p = Structure(seed=123)
    answer = p.css()
    assert answer == 'h1 {padding-top: 22px; color: #83d2b2; width: 78mm}'

# Generated at 2022-06-23 21:47:04.593165
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    prop = Structure(seed=1337).html_attribute_value()
    assert prop == '#2130d8'

# Generated at 2022-06-23 21:47:06.314196
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    print(s.css())
    assert s.css() is not None


# Generated at 2022-06-23 21:47:11.795397
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSProperties
    s = Structure('en')
    value = s.css_property()
    assert isinstance(value, str)
    assert len(value.split(':')) == 2
    assert ':' in value
    assert value.split(':')[0].strip() in CSSProperties.keys()
    assert value.split(':')[1].strip() not in ('color', 'url', 'size')

# Generated at 2022-06-23 21:47:13.665129
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure(seed=0, locale='ru')
    assert s is not None


# Generated at 2022-06-23 21:47:17.678938
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    test_value = s.css_property()

    assert (len(test_value) >= 3 and test_value[0].isalpha() and test_value[1] == ":" and test_value[2] == ' ')


# Generated at 2022-06-23 21:47:19.361241
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    structure.html_attribute_value(tag="a", attribute="href")

# Generated at 2022-06-23 21:47:24.591438
# Unit test for method css of class Structure
def test_Structure_css():
    """Test Structure.css() method."""
    str_ = Structure()
    result = str_.css()
    assert result != None
    assert isinstance(result, str)
    assert len(result.split()) > 5


# Generated at 2022-06-23 21:47:26.332462
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    a = Structure(seed=1)
    for i in range(20):
        print(a.css_property())

# Generated at 2022-06-23 21:47:28.208430
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert len(Structure().css_property()) > 0


# Generated at 2022-06-23 21:47:31.484251
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    struct = Structure()
    assert struct.css_property() == "background-color: #f4d3a1"


# Generated at 2022-06-23 21:47:38.655818
# Unit test for constructor of class Structure
def test_Structure():
    from mimesis.providers.structure import Structure
    data = Structure()
    assert hasattr(data, 'Meta')
    assert hasattr(data, 'locale')
    assert hasattr(data, 'seed')
    assert hasattr(data, 'random')
    assert hasattr(data, 'TokenContainer')
    assert hasattr(data, '__inet')
    assert hasattr(data, '__text')
    assert type(data.__inet) == Internet
    assert type(data.__text) == Text


# Generated at 2022-06-23 21:47:39.892278
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert isinstance(s, Structure)


# Generated at 2022-06-23 21:47:41.122972
# Unit test for method html of class Structure
def test_Structure_html():
    local=Structure()
    result=local.html()
    print(result)
    

# Generated at 2022-06-23 21:47:47.047372
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import HTMLElement
    from mimesis.enums import HTMLAttribute

# Generated at 2022-06-23 21:47:53.024808
# Unit test for method html of class Structure
def test_Structure_html():
    """Unit test for method html of class Structure."""
    # Create an instance of Structure
    structure = Structure()

    # Generate HTML
    html = structure.html()

    # Print the result
    print(html)

    # Method assertEqual to test the result
    assert html.startswith('<') and html.endswith('>\n</')


# Generated at 2022-06-23 21:47:55.035774
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct = Structure()
    struct.html_attribute_value(tag='div', attribute='locale')

# Generated at 2022-06-23 21:48:05.591822
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    html_tag = 'img'
    html_att = 'class'
    result = structure.html_attribute_value(html_tag, html_att)


# Generated at 2022-06-23 21:48:16.841564
# Unit test for method html of class Structure
def test_Structure_html():
    tmp = Structure()
    html_result = '<{tag} {attrs}>{content}</{tag}>'
    tag_attrs = list(HTML_CONTAINER_TAGS['img'])
    tag_name = tmp.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    k = tmp.random.randint(1, len(tag_attrs))
    selected_attrs = tmp.random.sample(tag_attrs, k=k)
    attrs = []
    for attr in selected_attrs:
        attrs.append('{}="{}"'.format(attr, tmp.html_attribute_value(
                                        tag_name, attr)))

# Generated at 2022-06-23 21:48:18.946956
# Unit test for constructor of class Structure
def test_Structure():
    obj = Structure()
    obj.css_property()
    obj.html()
    obj.html_attribute_value()
    assert obj is not None

test_Structure()

# Generated at 2022-06-23 21:48:22.445391
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    # test if method works correct with correct arguments
    try:
        assert s.html_attribute_value("html", "background") == "color"
    except NotImplementedError:
        print("s.html_attribute_value(\"html\", \"background\") works incorrect")


# Generated at 2022-06-23 21:48:23.757028
# Unit test for method html of class Structure
def test_Structure_html():
    assert Structure.html("en-US", 123456789) == Structure.html("en-US", 123456789)

# Generated at 2022-06-23 21:48:25.269044
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure"""
    str_ = Structure()
    assert str_.html_attribute_value("a", "href")

# Generated at 2022-06-23 21:48:36.027043
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import HTMLLanguage
    from mimesis.exceptions import NonEnumMemberError
    from mimesis.providers.localization import Localization


# Generated at 2022-06-23 21:48:39.594003
# Unit test for method html of class Structure
def test_Structure_html():
    data_provider_structure = Structure()
    html = data_provider_structure.html()
    for line in html.splitlines():
        print(line)


# Generated at 2022-06-23 21:48:42.592458
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure(seed=1)
    assert structure.html() == '<span class="auxiliary" id="portfolio">Kinder organizations paris merced corporation.</span>'

# Generated at 2022-06-23 21:48:44.000182
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    print(s.css())


# Generated at 2022-06-23 21:48:47.160250
# Unit test for method css of class Structure
def test_Structure_css():
    cls = Structure()
    cls.seed(1)
    assert cls.css() == '{background-color: #2f0a05; text-align: center;}'


# Generated at 2022-06-23 21:48:55.029249
# Unit test for method html of class Structure
def test_Structure_html():
    # test1
    first_result = Structure('ru', seed=303).html()
    assert first_result == '<li style="color: #d9eb8b">Администраторы социальных сетей</li>'

    # test2
    second_result = Structure('en', seed=303).html()
    assert second_result == '<li style="color: #d9eb8b">Social network administrators</li>'

    # test3
    third_result = Structure(seed=303).html()
    assert third_result == '<li style="color: #d9eb8b">Social network administrators</li>'



# Generated at 2022-06-23 21:49:01.859497
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    struct = Structure("en")
    struct_css_prop = struct.css_property()
    if not isinstance(struct_css_prop, str):
        raise TypeError("Return value of Structure.css_property is not a string")
    if len(struct_css_prop) == 0:
        raise ValueError("Return value of Structure.css_property is an empty string")
test_Structure_css_property()

# Generated at 2022-06-23 21:49:03.385840
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure('en')
    assert s.html() != None

# Generated at 2022-06-23 21:49:04.455188
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    f = Structure('ru')
    assert f.css_property() != ''

# Generated at 2022-06-23 21:49:13.598320
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    print(s.html())
    print(s.html())
    print(s.css())
    print(s.css())
    print(s.html_attribute_value(tag="html", attribute="lang"))
    print(s.html_attribute_value(tag="a", attribute="href"))
    print(s.html_attribute_value(tag="div", attribute="class"))
    print(s.html_attribute_value(attribute="id"))
    print(s.html_attribute_value("table", "cellspacing"))
    print(s.html_attribute_value("meta", "charset"))

# test_Structure()

# Generated at 2022-06-23 21:49:15.438794
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    print(structure.css())
    print(structure.css())
    print(structure.css())
    print(structure.css())


# Generated at 2022-06-23 21:49:18.304820
# Unit test for method html of class Structure
def test_Structure_html():
    """
    Test case for method html of class Structure.
    :return:
    """
    print('*' * 50 + 'test_Structure_html' + '*' * 50)
    structure = Structure()
    print(structure.html())

    tag = 'span'
    print(structure.html(tag))


# Generated at 2022-06-23 21:49:19.666162
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    structure.css()

# Generated at 2022-06-23 21:49:25.738046
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct = Structure()

    tag = 'a'
    attribute = 'href'
    exp_value = 'url'
    act_value = HTML_CONTAINER_TAGS[tag][attribute]
    assert exp_value, act_value

    exp_result = struct.html_attribute_value(tag, attribute)
    assert isinstance(exp_result, str)

# Generated at 2022-06-23 21:49:28.470594
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    checker = Structure()
    print(checker.css_property())
    assert len(checker.css_property()) > 0
    assert checker.css_property().find(':') != -1


# Generated at 2022-06-23 21:49:33.595483
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    sample = Structure()
    sample.html_attribute_value('div', 'title')
    sample.html_attribute_value('p', 'title')
    sample.html_attribute_value('font', 'face')
    sample.html_attribute_value('font', 'size')
    sample.html_attribute_value('bdo', 'dir')
    sample.html_attribute_value('q', 'cite')
    sample.html_attribute_value('abbr', 'title')
    sample.html_attribute_value('acronym', 'title')
    sample.html_attribute_value('address', 'title')
    sample.html_attribute_value('article', 'title')
    sample.html_attribute_value('aside', 'title')
    sample.html_attribute_value('audio', 'title')
    sample.html_attribute_

# Generated at 2022-06-23 21:49:34.828495
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure != None

# Generated at 2022-06-23 21:49:38.905662
# Unit test for method html of class Structure
def test_Structure_html():
    stuctr = Structure()
    ans = stuctr.html()
    assert ans is not None
    assert type(ans) == str
    assert len(ans) >= 1


# Generated at 2022-06-23 21:49:43.745044
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    print("Testing method css_property of class Structure")
    strt = Structure(seed=123)
    print("\tfirst: ", strt.css_property())
    print("\tsecond: ", strt.css_property())
    print("\tthird: ", strt.css_property())



# Generated at 2022-06-23 21:49:46.695185
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure('en')
    css = structure.css()
    assert len(css) > 1
    assert '{' in css
    assert css[0] == '{'
    assert css[-1] == '}'


# Generated at 2022-06-23 21:49:50.380834
# Unit test for method html of class Structure
def test_Structure_html():
    import re
    sut = Structure()
    result = sut.html()
    print(result)
    assert re.match(r'<\w+( \w+="\w+")+>\w+\W+</\w+>', result)

# Generated at 2022-06-23 21:49:53.801876
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert isinstance(structure, Structure)
    assert isinstance(structure.__class__, type)


# Generated at 2022-06-23 21:50:03.573866
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.providers.structure import Structure
    from mimesis.datastructures import ConvenientDict
    from mimesis.enums import Languages
    from mimesis.providers.internet import Internet

    my_data = {
        'a': ['href', 'hreflang', 'target'],
        'img': ['src', 'alt', 'title'],
        'iframe': ['src', 'width', 'height', 'name', 'srcdoc'],
        'input': ['type', 'name', 'value', 'form'],
        'li': ['type', 'value'],
        'option': ['label', 'value'],
        'track': ['src', 'srclang', 'kind', 'label'],
    }

    my_dict = ConvenientDict(**my_data)

    structure

# Generated at 2022-06-23 21:50:06.071016
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure(seed=123456)

    structure.css()
# should return
# '* {background-color: #c8e5e1; display: block}'


# Generated at 2022-06-23 21:50:07.884711
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    test_css_property = [
        Structure().css_property() for _ in range(1, 10)]
    assert test_css_property


# Generated at 2022-06-23 21:50:14.310845
# Unit test for constructor of class Structure
def test_Structure():
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.person import Person
    from mimesis.providers.utils import Choice
    def test_Mimesis_init_simple():
        s = Structure()
        assert s is not None
        assert s._seed is not None
        assert s._locale is not None
        assert s._data is not None
        assert s._random is not None
        
    def test_Mimesis_init_with_seed():
        s = Structure(seed=42)
        assert s._seed == 42
        assert s._locale is not None

    def test_Mimesis_init_with_seed_and_locale():
        s = Structure(seed=42, locale='ru')

# Generated at 2022-06-23 21:50:16.790683
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure_obj = Structure('en')
    assert len(structure_obj.css_property()) == 17

# Generated at 2022-06-23 21:50:19.694243
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    html = s.html()
    assert isinstance(html, str)

# Generated at 2022-06-23 21:50:20.915295
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    assert s.css() in CSS_SELECTORS

# Generated at 2022-06-23 21:50:23.651987
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    
    s = Structure()
    property_ = s.css_property()
    assert isinstance(property_, str)
    assert len(property_) > 2

# Unit tests for method css of class Structure

# Generated at 2022-06-23 21:50:35.129354
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for Structure.html_attribute_value()."""
    structure = Structure()
    for tag in HTML_CONTAINER_TAGS:
        for attribute in HTML_CONTAINER_TAGS[tag]:  # type: ignore
            if HTML_CONTAINER_TAGS[tag][attribute] == 'css':
                assert structure.html_attribute_value(tag, attribute) in CSS_PROPERTIES
            elif HTML_CONTAINER_TAGS[tag][attribute] == 'word':
                assert isinstance(structure.html_attribute_value(tag, attribute), str)
            elif HTML_CONTAINER_TAGS[tag][attribute] == 'url':
                assert structure.html_attribute_value(tag, attribute) not in [None, '']
            else:
                raise NotImplementedError

# Generated at 2022-06-23 21:50:36.606097
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    assert isinstance(s.css(), str)



# Generated at 2022-06-23 21:50:46.953685
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure() 
    tag_name = s.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    tag_attributes = list(HTML_CONTAINER_TAGS[tag_name])
    k = s.random.randint(1, len(tag_attributes))
    selected_attrs = s.random.sample(tag_attributes, k=k)
    attrs = []
    for attr in selected_attrs:
        attrs.append('{}="{}"'.format(
            attr, s.html_attribute_value(tag_name, attr)))
    # start of tag

# Generated at 2022-06-23 21:50:48.320621
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    assert len(structure.css()) < 1500


# Generated at 2022-06-23 21:50:51.965888
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.providers.structured import Structure

    structure = Structure()
    assert structure.html_attribute_value()
    assert structure.html_attribute_value('body')
    assert structure.html_attribute_value('body', 'margin')



# Generated at 2022-06-23 21:50:54.710194
# Unit test for method css of class Structure
def test_Structure_css():
    # Initialization
    s = Structure()
    assert s.css()
    print("Test of method css of class Structure successfull")

# Generated at 2022-06-23 21:50:56.423529
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert not (s.css_property()).isspace()


# Generated at 2022-06-23 21:50:57.732632
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure('en')
    structure.html_attribute_value('a', 'href')

# Generated at 2022-06-23 21:51:05.006032
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    s.Meta.name = 'structure'
    print("Test class Structure")
    print("\tInit")
    print("\t\tType : ", type(s))
    print("\tAttributes")
    print("\t\tattr 'Meta' : ", type(s.Meta))
    print("\t\t\tattribut 'name' : ", s.Meta.name)
    print("\tMethods")
    print("\t\tMethod 'css_property' : ", type(s.css_property))
    print("\t\tMethod 'css' : ", type(s.css))
    print("\t\tMethod 'html_attribute_value' : ", type(s.html_attribute_value))
    print("\t\tMethod 'html' : ", type(s.html))