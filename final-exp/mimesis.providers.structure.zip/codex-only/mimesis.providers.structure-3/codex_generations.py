

# Generated at 2022-06-23 21:40:58.216459
# Unit test for method html of class Structure
def test_Structure_html():
    alface = Structure(seed=42)
    print('Method html of class Structure')
    print(alface.html())

# Generated at 2022-06-23 21:41:00.082754
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st = Structure()
    value = st.css_property()
    assert isinstance(value, str) and value


# Generated at 2022-06-23 21:41:04.353167
# Unit test for method html of class Structure
def test_Structure_html():
    gen = Structure(seed=1234)
    h = gen.html()
    assert isinstance(h, str)
    assert h == '<noscript class="select" id="accessibility">principal good</noscript>'

    gen2 = Structure(seed=123)
    h2 = gen2.html()
    assert h2 == '<fieldset class="select" id="expensive">needed pure</fieldset>'


# Generated at 2022-06-23 21:41:11.033992
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    import doctest
    from mimesis.enums import CSSProperties
    from mimesis.providers.structure import Structure
    structure = Structure()
    results = []
    for property in CSSProperties:
        if property not in [
            CSSProperties.FONT_FAMILY,
            CSSProperties.FONT_SIZE,
            CSSProperties.COLOR
        ]:
            results.append(
                structure.css_property()
            )

    loads = [
        result.split(':')[0] in
        [prop.name.lower() for prop in CSSProperties]
        for result in results
    ]
    print(loads)
    assert all(loads)
    print(doctest.testmod())

# Generated at 2022-06-23 21:41:12.605543
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() == 'color: #444444'


# Generated at 2022-06-23 21:41:16.456350
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    for _ in range(128):
        prop = Structure().css_property()
        # Test if the property is in the format "property: value"
        assert prop.count(':') == 1



# Generated at 2022-06-23 21:41:18.196844
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property()


# Generated at 2022-06-23 21:41:28.160594
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Test for html_attribute_value without arguments
    strct = Structure(seed=1)
    result = strct.html_attribute_value()
    assert result == "background-color: #e3f7a3"

    # Test for html_attribute_value with argument tag
    tag = "html"
    strct = Structure(seed=1)
    result = strct.html_attribute_value(tag)
    assert result == "http://www.example.com"

    # Test for html_attribute_value with argument tag
    # and attribute
    tag = "html"
    attribute = "class"
    strct = Structure(seed=1)
    result = strct.html_attribute_value(tag, attribute)
    assert result == "word"
    tag = "div"
    attribute = "class"
    strct

# Generated at 2022-06-23 21:41:29.650952
# Unit test for method css of class Structure
def test_Structure_css():
	structure = Structure('en')
	example = structure.css()
	assert isinstance(example, str)

# Generated at 2022-06-23 21:41:31.158920
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.providers.structure import Structure
    s = Structure()
    print(s.css_property())


# Generated at 2022-06-23 21:41:31.880686
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()
    assert struct is not None

# Generated at 2022-06-23 21:41:43.641055
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure('en')
    tag, attribute = 'b', 'name'
    value = structure.html_attribute_value(tag, attribute)
    assert len(value)
    assert value.isalpha()
    tag, attribute = 'a', 'target'
    value = structure.html_attribute_value(tag, attribute)
    assert len(value)
    assert value.isalpha()
    tag, attribute = 'li', 'value'
    value = structure.html_attribute_value(tag, attribute)
    assert len(value)
    assert value.isnumeric()
    tag, attribute = 'a', 'href'
    value = structure.html_attribute_value(tag, attribute)
    assert len(value)
    assert 'www' in value
    tag, attribute = 'table', 'border'
    value = structure.html

# Generated at 2022-06-23 21:41:52.340274
# Unit test for constructor of class Structure
def test_Structure():
    from mimesis.enums import Locale
    from unittest.mock import Mock
    from mimesis.data import StrictField
    builder = StrictField(locale=Locale.EN,
                          seed=1,
                          providers={},
                          __provider__={},
                          __data__={},
                          __random__=Mock(),
                          __text__=Mock(),
                          __inet__=Mock(),
                          _meta='C')
    test = Structure.__call__(builder)
    assert test.__random__ == builder.__random__
    assert test.__provider__ == builder.__provider__
    assert test.__text__ == builder.__text__
    assert test.__inet__ == builder.__inet__

# Generated at 2022-06-23 21:41:54.941906
# Unit test for constructor of class Structure
def test_Structure():
    """Test class constructor."""
    s = Structure(seed=42)
    assert s.seed == 42
    assert s.random.seed == 42
    assert s.random.random == s.random.orig_random


# Generated at 2022-06-23 21:41:56.545377
# Unit test for method html of class Structure
def test_Structure_html():
    provider = Structure()
    html_test = provider.html()
    assert html_test


# Generated at 2022-06-23 21:41:58.750828
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    css = structure.css()
    assert('{') in css, "css does not have '{{' in it."
    assert('}') in css, "css does not have '}}' in it."


# Generated at 2022-06-23 21:42:04.401719
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test method html_attribute_value of class Structure.

    This method is tested with different inputs. This method returns a random
    attribute with some value from the HTML_CONTAINER_TAGS list.
    """
    structure = Structure()
    assert structure.html_attribute_value()
    assert structure.html_attribute_value('', '')
    assert structure.html_attribute_value('img', 'src')



# Generated at 2022-06-23 21:42:10.889003
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    for _ in range(10):
        assert(s.html() != s.html())
        assert(s.css() != s.css())
        assert(s.css_property() != s.css_property())

    # css with different tags
    for i in range(10):
        assert(len(s.css_property()) > 0)
        assert(len(s.html_attribute_value()) > 0)


# Generated at 2022-06-23 21:42:13.258035
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(seed=1)
    r = s.css()
    assert r == 'a {padding: 5em; padding-top: 53px; margin-bottom: 2px; padding: 4px}'


# Generated at 2022-06-23 21:42:16.201192
# Unit test for constructor of class Structure
def test_Structure():
    # IF language is English
    x = Structure()
    assert x._Structure__seed is not None
    assert x._Structure__locale == "en"
    assert x._Structure__text is not None
    assert x._Structure__inet is not None

# Generated at 2022-06-23 21:42:27.436719
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    str = Structure()
    # tagname = str.random.choice(list(HTML_CONTAINER_TAGS))
    # attribute = str.random.choice(list(HTML_CONTAINER_TAGS[tagname]))
    # result = str.html_attribute_value(tagname, attribute)
    # assert isinstance(result, str)
    #
    # tagname = str.random.choice(list(HTML_CONTAINER_TAGS))
    # result = str.html_attribute_value(tagname)
    # assert isinstance(result, str)

    # tagname = "div"
    # attribute = "class"
    # result = str.html_attribute_value(tagname, attribute)
    # assert isinstance(result, str)
    # print(result)

    # tagname = "div"


# Generated at 2022-06-23 21:42:28.157602
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    pass

# Generated at 2022-06-23 21:42:29.547041
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    assert isinstance(s.css(), str)


# Generated at 2022-06-23 21:42:35.080503
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st = Structure(seed=0)

    assert(st.css_property() == 'margin-bottom: 8px')
    assert(st.css_property() == '-webkit-font-smoothing: antialiased')
    assert(st.css_property() == 'background-color: #f4d3a1')



# Generated at 2022-06-23 21:42:38.778082
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    tags = list(HTML_CONTAINER_TAGS.keys())
    for tag in tags:
        for attr in HTML_CONTAINER_TAGS[tag]:
            s = Structure()
            assert s.html_attribute_value(tag, attr) is not None

# Generated at 2022-06-23 21:42:40.848978
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    res = Structure().css_property()
    assert isinstance(res, str)


# Generated at 2022-06-23 21:42:42.578749
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(random=False)
    assert s.css() == 'a {background-origin: padding-box; font-weight: bold}'


# Generated at 2022-06-23 21:42:46.695789
# Unit test for constructor of class Structure
def test_Structure():
    try:
        Structure(seed=0)
    except Exception as error:
        print ("Structure constructor test:",error)
        assert False
    else:
        assert True

test_Structure()


# Generated at 2022-06-23 21:42:48.167154
# Unit test for method css of class Structure
def test_Structure_css():
    s=Structure()
    s.css()


# Generated at 2022-06-23 21:42:50.542497
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    assert isinstance(s.html(), str)
    print(s.html())

# Generated at 2022-06-23 21:42:52.366529
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure('en')
    print(structure.html())
    print(structure.html())
    print(structure.html())



# Generated at 2022-06-23 21:42:55.650868
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    for i in range(0, 1000):
        css = structure.css()
        assert isinstance(css, string)


# Generated at 2022-06-23 21:43:01.483374
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    my_structure = Structure()
    assert my_structure.html_attribute_value('a') in ['#f5498b', '#5498b0', '#122345', '#234567',
                                                      '#345678', '#456789', '#567890', '#678901',
                                                      '#789012', '#890123', '#901234', '#012345']

# Generated at 2022-06-23 21:43:04.061816
# Unit test for constructor of class Structure
def test_Structure():
    # default seed
    s = Structure('en')
    assert s.css() != None
    assert s.css_property() != None
    assert s.html() != None
    assert s.html_attribute_value() != None

# Generated at 2022-06-23 21:43:08.621024
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    assert isinstance(s.html(), str) is True
    #print(s.html())
    assert '<' in s.html()
    assert '>' in s.html()

# test method html_attribute_value of class Structure

# Generated at 2022-06-23 21:43:12.469732
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.providers.structure import Structure
    from mimesis.enums import HTMLTag, HTMLAttribute
    structure = Structure()
    print(structure.html(HTMLTag.SPAN, HTMLAttribute.CLASS))

# Generated at 2022-06-23 21:43:21.460282
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import CssProperty, HtmlTag
    from mimesis.providers.structure import Structure
    import re

    struct = Structure()
    assert struct.html_attribute_value(HtmlTag.A) in ['_blank', '_self']
    assert struct.html_attribute_value(HtmlTag.A, 'download') == 'word'
    assert re.match(r'[^.]+\.[a-zA-Z]+',
                    struct.html_attribute_value(HtmlTag.A, 'href'))
    assert struct.html_attribute_value(HtmlTag.ABBR) == 'word'

# Generated at 2022-06-23 21:43:23.264399
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Test for method css_property."""
    css = Structure()
    property = css.css_property()
    assert property.count(':') == 1


# Generated at 2022-06-23 21:43:23.820021
# Unit test for constructor of class Structure
def test_Structure():
    x = Structure()


# Generated at 2022-06-23 21:43:24.889137
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    Struct1 = Structure()
    d = Struct1.css_property()
    return d

# Generated at 2022-06-23 21:43:27.408357
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """
    Test case for method html_attribute_value of class Structure.
    """
    structure = Structure()
    tag = "div"
    attribute = "class"
    assert isinstance(structure.html_attribute_value(tag, attribute), str)


# Generated at 2022-06-23 21:43:30.270687
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    for tag in HTML_CONTAINER_TAGS.keys():
        for attr in HTML_CONTAINER_TAGS[tag]:
            print(s.html_attribute_value(tag, attr))


# Generated at 2022-06-23 21:43:39.402219
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    # try to generate random value for specified tag and attribute
    attribute = s.html_attribute_value('div', 'title')
    assert attribute == 'word'
    # try to generate random value for specified tag and attribute
    attribute = s.html_attribute_value('a', 'href')
    assert attribute == 'url'
    # try to generate random value for specified tag and attribute
    attribute = s.html_attribute_value('body', 'style')
    assert attribute == 'css'
    
    

# Generated at 2022-06-23 21:43:39.936385
# Unit test for constructor of class Structure
def test_Structure():
    obj = Structure()
    assert obj is not None

# Generated at 2022-06-23 21:43:41.078835
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test method html_attribute_value.

    :return:
    """
    structure = Structure()
    html = structure.html_attribute_value()
    assert html is not None

# Generated at 2022-06-23 21:43:42.320915
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert Structure().css_property() == "background-color: #954aa0"

# Generated at 2022-06-23 21:43:43.870396
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure('zh')
    result = s.css_property()
    assert result is not None and result

# Generated at 2022-06-23 21:43:55.915946
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit Test for method html_attribute_value of class Structure"""
    p = Structure(seed=0)
    assert p.html_attribute_value() == 'http://www.somerville.biz'
    assert p.html_attribute_value(tag='a', attribute='href') == 'http://www.somerville.biz'
    assert p.html_attribute_value(tag='link', attribute='href') == 'http://www.somerville.biz'
    assert p.html_attribute_value(tag='a', attribute='rel') == 'next'
    assert p.html_attribute_value(tag='link', attribute='rel') == 'next'
    assert p.html_attribute_value(tag='a', attribute='target') == '_blank'
    assert p.html_attribute_value(tag='base', attribute='target')

# Generated at 2022-06-23 21:44:07.116538
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure(seed=0)
    structure.html_attribute_value(tag="a",attribute="name")
    structure.html_attribute_value(tag="a",attribute="rel")
    structure.html_attribute_value(tag="a",attribute="type")
    structure.html_attribute_value(tag="a",attribute="target")
    structure.html_attribute_value(tag="a",attribute="href")
    structure.html_attribute_value(tag="a",attribute="id")
    structure.html_attribute_value(tag="td",attribute="align")
    structure.html_attribute_value(tag="td",attribute="colspan")
    structure.html_attribute_value(tag="td",attribute="headers")
    structure.html_attribute_value(tag="td",attribute="rowspan")
    structure.html_attribute_

# Generated at 2022-06-23 21:44:13.913775
# Unit test for constructor of class Structure
def test_Structure():
    # Test size of the random number generator cache
    s = Structure()
    assert s._rnd._cache_size == 100000
    s = Structure(random_state=12345678)
    assert s._rnd._cache_size == 100000

    s = Structure(random_state=12345678)
    assert s._rnd._cache_size == 100000
    assert s.__inet._rnd._cache_size == 100000
    assert s.__text._rnd._cache_size == 100000


# Generated at 2022-06-23 21:44:19.755044
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test method Structure.html_attribute_value"""
    struct = Structure(seed=1)
    result = struct.html_attribute_value(tag="span", attribute="class")
    expected_result = "background-color: #f4d3a1"
    assert result == expected_result
    result = struct.html_attribute_value(tag="p", attribute="class")
    expected_result = "word-wrap: break-word"
    assert result == expected_result

# Generated at 2022-06-23 21:44:21.196626
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    assert isinstance(structure.html(), str)


# Generated at 2022-06-23 21:44:23.890750
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    for _ in range(100):
        print(s.html())


# Generated at 2022-06-23 21:44:25.641429
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()

    assert (structure.css_property() in CSS_PROPERTIES.keys())

# Generated at 2022-06-23 21:44:37.115588
# Unit test for constructor of class Structure
def test_Structure():
    css_props = ['background-color: #f4d3a1', 'background-image: url(img/car.jpg)', 'width: 95%', 'font-family: Verdana,sans-serif', 'letter-spacing: normal', 'padding-left: 14px', 'background-position: left center', 'border: 1px solid #fff', 'background-repeat: repeat', 'font-size: 100%', 'line-height: 1.15', 'color: #1b1e1f']
    html_props = ['<style type="text/css">#selector { background-color: #f4d3a1 }</style><select id="selector"><option value="option"></option></select>']
    assert Structure().css() in css_props
    assert Structure().css_property() in css_

# Generated at 2022-06-23 21:44:45.994757
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    tmp = Structure()

    l = []
    while len(l) < 10:
        c = tmp.css_property()
        if c not in l:
            l.append(c)


# Generated at 2022-06-23 21:44:50.548733
# Unit test for method css of class Structure
def test_Structure_css():
    css = ['a {text-decoration: underline}', 'a {text-decoration: none}', 'a {text-decoration: underline}', 'a {text-decoration: none}', 'a {text-decoration: underline}', 'a {text-decoration: underline}', 'a {text-decoration: none}', 'a {text-decoration: underline}', 'a {text-decoration: underline}', 'a {text-decoration: underline}']
    obj = Structure()
    for i in range(0, 10):
        assert obj.css() in css


# Generated at 2022-06-23 21:44:52.176617
# Unit test for method css of class Structure
def test_Structure_css():
    _Structure = Structure()
    _Structure.css()


# Generated at 2022-06-23 21:44:58.754781
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    css_property = Structure()

    assert isinstance(css_property.css_property(), str), \
        "The result of method css_property of class Structure must be string"

    assert not len(css_property.css_property()) == 0, \
        "The result of method css_property of class Structure is empty"


# Generated at 2022-06-23 21:45:01.921151
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    for tag in HTML_CONTAINER_TAGS.keys():
        for attribute in HTML_CONTAINER_TAGS[tag]:
            print(s.html_attribute_value(tag, attribute))

# Generated at 2022-06-23 21:45:03.602104
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    tmp = Structure()
    assert tmp.css_property() in CSS_PROPERTIES


# Generated at 2022-06-23 21:45:08.269650
# Unit test for constructor of class Structure
def test_Structure():
    name = "structure"
    cls = Structure
    assert inspect.isclass(cls)
    assert hasattr(cls, 'Meta')
    assert inspect.isclass(cls.Meta)
    assert hasattr(cls.Meta, 'name')
    assert cls.Meta.name == name
    assert hasattr(cls, '__init__')


# Generated at 2022-06-23 21:45:19.243914
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import Attribute
    from mimesis.providers.structure import Structure
    from mimesis.providers.text import Text
    structure = Structure()
    text = Text()
    generated_css = structure.css_property()
    generated_css = generated_css.split(":")
    generated_css_1 = generated_css[0]
    generated_css_2 = generated_css[1]
    generated_css_3 = text.get_attribute(Attribute.HEX_COLOR)
    assert generated_css_1 in Structure.css_property.__doc__
    assert generated_css_2 in Structure.css_property.__doc__
    assert generated_css_3 in Structure.css_property.__doc__


# Generated at 2022-06-23 21:45:22.544109
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    struct = Structure()
    for _ in range(7):
        test = struct.css_property()
        assert isinstance(test, str)


# Generated at 2022-06-23 21:45:24.196648
# Unit test for method html of class Structure
def test_Structure_html():
    struct = Structure()
    struct.html()

# Generated at 2022-06-23 21:45:26.445271
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    for _ in range(100):
        print(s.css())


# Generated at 2022-06-23 21:45:29.010977
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure('en')
    for i in range(0, 100):
        css = structure.css()
        assert css
        print(css)


# Generated at 2022-06-23 21:45:34.328200
# Unit test for method css of class Structure
def test_Structure_css():
    # Case 1
    out1 = Structure(seed=5).css()
    assert out1 == '#select {color: #d356ad}'
    # Case 2
    out2 = Structure(seed=6).css()
    assert out2 == '.shopping {color: #3c3c3c; padding-right: 14%; max-height: 48px}'
    # Case 3
    out3 = Structure(seed=7).css()
    assert out3 == 'h3 {height: 12px; margin-left: 19px}'

# Generated at 2022-06-23 21:45:38.188678
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    result = s.html()
    assert(result == '<main>In a compact space is not a wide range of complex system of mechanical parts.</main>')


# Generated at 2022-06-23 21:45:39.809620
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    sto=Structure()
    print(sto.css_property())


# Generated at 2022-06-23 21:45:48.790161
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import HtmlTag, HtmlAttribute

    structure = Structure()

    # test when both tag and attribute are provided
    # then just returns the value
    value = structure.html_attribute_value(HtmlTag.DIV, HtmlAttribute.CLASS)
    result = structure.random.choice(HTML_CONTAINER_TAGS[HtmlTag.DIV][HtmlAttribute.CLASS])
    assert value == result

    # test when attribute is provided but tag is not provided
    # then first chooses a tag and after that returns the value
    tag_name = structure.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    value = structure.html_attribute_value(attribute=HtmlAttribute.CLASS)

# Generated at 2022-06-23 21:45:59.883943
# Unit test for method html of class Structure
def test_Structure_html():
    # for repeatable results
    structure = Structure(seed=42)
    print(structure.html())
    # <span id="manager" class="vendor day">Services are containers.</span>

    # for repeatable results
    structure = Structure(seed=42)
    print(structure.html())
    # <span id="manager" class="vendor day">Services are containers.</span>

    structure = Structure(seed=5)
    print(structure.html())
    # <label class="carrier">Nodes are Docker Engine instances that have been configured to join the same swarm, either as managers or as workers.</label>

    # for repeatable results
    structure = Structure(seed=42)
    print(structure.html())
    # <span id="manager" class="vendor day">Services are containers.</span>

    # for repeat

# Generated at 2022-06-23 21:46:03.833972
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
  st = Structure()
  assert isinstance(st.html_attribute_value(attribute = 'data-title'), str)
  assert isinstance(st.html_attribute_value(tag = 'span', attribute = 'data-title'), str)
  

# Generated at 2022-06-23 21:46:08.402328
# Unit test for constructor of class Structure
def test_Structure():
    print('\n\nUnit test starting...')
    s = Structure()
    print('CSS:', s.css())
    print('HTML:', s.html())
    print('HTML attr:', s.html_attribute_value())
    print(s.html_attribute_value('a', 'href'))
    print('\nUnit test finished')


# Generated at 2022-06-23 21:46:11.599752
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert isinstance(s, Structure)
    assert isinstance(s.__inet, Internet)
    assert isinstance(s.__text, Text)

# Unit tests for css() of class Structure

# Generated at 2022-06-23 21:46:24.107948
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure().html_attribute_value('a', 'rel') == 'word'
    assert Structure().html_attribute_value('a', 'href') == 'url'
    assert Structure().html_attribute_value('a', 'id') == 'word'
    assert Structure().html_attribute_value('a', 'name') == 'word'
    act = Structure().html_attribute_value('li', 'value')
    assert isinstance(act, int)
    assert Structure().html_attribute_value('area', 'shape') == 'word'
    assert Structure().html_attribute_value('area', 'coords') == 'word'
    assert Structure().html_attribute_value('area', 'href') == 'url'
    assert Structure().html_attribute_value('area', 'alt') == 'word'

# Generated at 2022-06-23 21:46:27.325441
# Unit test for constructor of class Structure
def test_Structure():
    test_Structure = Structure()
    assert test_Structure.seed
    assert test_Structure._data
    assert test_Structure.locale == 'en'

# Generated at 2022-06-23 21:46:29.400935
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    str1 = s.html()
    str2 = s.html()
    assert str1 != str2

# Generated at 2022-06-23 21:46:33.661944
# Unit test for constructor of class Structure
def test_Structure():
    p=Structure(locale='en',seed=42)
    print(p.css())
    print(p.html())
    print(p.css_property())
    print(Structure.Meta)
    print(Structure.Meta.name)

test_Structure()

# Generated at 2022-06-23 21:46:35.100366
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    strObj = Structure()
    print(strObj.css_property())


# Generated at 2022-06-23 21:46:36.029836
# Unit test for constructor of class Structure
def test_Structure():
    pass


# Generated at 2022-06-23 21:46:37.993662
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('ru')
    result = structure.css_property()

    assert isinstance(result, str)


# Generated at 2022-06-23 21:46:38.942912
# Unit test for constructor of class Structure
def test_Structure():
    obj = Structure()
    assert obj is not None

# Generated at 2022-06-23 21:46:43.276811
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis import Generic
    generator = Generic('en')
    print(generator.structure.html())
    #<table width="100%" height="100%" align="center" valign="middle">Lisbon</table>


# Generated at 2022-06-23 21:46:45.625251
# Unit test for constructor of class Structure
def test_Structure():
    data = Structure().__dict__
    assert data['_random'] is not None

# Unit tests for method css() of class Structure

# Generated at 2022-06-23 21:46:54.681985
# Unit test for constructor of class Structure
def test_Structure():
    # return a Structure instance
    s = Structure()
    print(s.random)
    print(s.random.choices)
    print(s.random.choice)
    print(s.random.randint)
    print(s.random.sample)
    print(s.random.choices(range(1, 101, 5), k=3))
    print(s.random.choice(range(1, 101, 5)))
    print(s.random.randint(1, 101))
    print(s.random.sample(range(1, 101, 5), k=3))
    print(s.random.choices(range(1, 101)))

    print(s.CSS_SELECTORS)
    print(s.CSS_PROPERTIES)
    print(s.CSS_SIZE_UNITS)

# Generated at 2022-06-23 21:46:57.514362
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure("en")
    assert structure.css_property() == 'background: black'



# Generated at 2022-06-23 21:47:07.805108
# Unit test for method html of class Structure
def test_Structure_html():
    from .container_tags import HTML_CONTAINER_TAGS
    from .css import CSS_PROPERTIES, CSS_SIZE_UNITS, HTML_MARKUP_TAGS
    from .internet import WEBSITES
    from .text import WORDS
    from mimesis.providers.text import Text
    from mimesis.providers.structure import Structure
    from mimesis.enums import Gender
    text = Text('en')
    structure = Structure('en')

# Generated at 2022-06-23 21:47:10.277768
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    generator = Structure()

    output = generator.css_property()
    assert len(output.split(':')) == 2


# Generated at 2022-06-23 21:47:17.834272
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    a = Structure()
    assert a.html_attribute_value('img', 'src') == 'http://example.com'
    assert a.html_attribute_value('img', 'alt') == 'word'
    assert a.html_attribute_value('img', 'width') == 'size'
    assert a.html_attribute_value('img', 'width') == 'size'
    assert a.html_attribute_value('img', 'height') == 'size'
    assert a.html_attribute_value('img', 'usemap') == 'hash'
    assert a.html_attribute_value('a', 'href') == 'http://example.com'
    assert a.html_attribute_value('a', 'rel') == 'rel|rev'
    assert a.html_attribute_value('div', 'align') == 'align'

# Generated at 2022-06-23 21:47:19.481044
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert Structure.css_property() != ""
    assert Structure.css_property() != ": "


# Generated at 2022-06-23 21:47:25.520424
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    list_properties = []
    for _ in range(100):
        assert len(structure.css_property()) != 0
        list_properties.append(structure.css_property())
    assert len(list_properties) == len(set(list_properties))


# Generated at 2022-06-23 21:47:33.185635
# Unit test for method css of class Structure
def test_Structure_css():
    import random
    observer = random.Random()
    # 1. Test first branch when selector is 'id'
    selector = 'id'
    word = Internet.Meta.word
    css_sel = CSS_SELECTORS[0]+word
    base = HTML_MARKUP_TAGS[0] # HTML_MARKUP_TAGS[0] -> 'a'
    props = []
    for _ in range(1, 6):
        prop = random.choice(list(CSS_PROPERTIES.keys()))
        val = CSS_PROPERTIES[prop]
        if isinstance(val, list):
            val = random.choice(val)
        elif val == 'color':
            val = '#f4d3a1'

# Generated at 2022-06-23 21:47:41.231321
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    structure.random.seed(0)
    css = structure.css()
    html = structure.html()
    assert isinstance(css, str) and isinstance(html, str)
    assert css == '#child {background-color: #4e8dd4; font-family: verdana; margin-left: 48px; padding-top: 56px; color: #b2c9c9; font-size: 56px; line-height: 56px}' and html == '<p id="port" src="http://www.vasquez-cooke.com/" class="manage pick">Greetings by the bot.</p>'


# Generated at 2022-06-23 21:47:42.137730
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure is not None

# Generated at 2022-06-23 21:47:43.792028
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    assert s.html()[:19] == "<h1 class=\"news\"> "

# Generated at 2022-06-23 21:47:46.699869
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = "form"
    attribute = "method"
    x = structure.html_attribute_value(tag, attribute)
    assert x in ["get", "post"]

test_Structure_html_attribute_value()


# Generated at 2022-06-23 21:47:50.118465
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.providers.structure import Structure
    s = Structure()
    for _ in range(10):
        print(s.html_attribute_value(attribute = "class"))


# Generated at 2022-06-23 21:47:52.679571
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    css_property = structure.css_property()
    assert type(css_property) == str

# Generated at 2022-06-23 21:47:53.874411
# Unit test for method css of class Structure
def test_Structure_css():
    assert Structure().css() is not None


# Generated at 2022-06-23 21:47:55.425857
# Unit test for constructor of class Structure
def test_Structure():
    structure= Structure()
    assert isinstance(structure, Structure)

# Generated at 2022-06-23 21:48:04.531959
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.random import Random

    s = Structure(seed=42)
    assert s.css_property() == 'display: block'

    s = Structure(seed=42)
    assert s.css_property() == 'font-size: 20px'

    s = Structure(seed=42)
    assert s.css_property() in CSS_PROPERTIES

    s = Structure(seed=42)
    s.random.seed(42)
    assert s.random.choice(CSS_PROPERTIES) == 'font-size'

    r = Random()
    assert r.choice(CSS_PROPERTIES) == 'background-attachment'


# Generated at 2022-06-23 21:48:06.393532
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert len(Structure.css_property(3)) > 0
    assert len(Structure.css_property(3)) == 3


# Generated at 2022-06-23 21:48:09.945314
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    print(s.css_property())
    print(s.css_property())
    print(s.css_property())
    print(s.css_property())
    print(s.css_property())
    print(s.css_property())
    

# Generated at 2022-06-23 21:48:11.777006
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure._seed is not None
    assert structure.locale is not None


# Generated at 2022-06-23 21:48:13.695729
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    result = structure.css()
    assert result is not None
    assert result is not ''


# Generated at 2022-06-23 21:48:15.242818
# Unit test for method css of class Structure
def test_Structure_css():
    uut = Structure()
    css = uut.css()
    assert type(css) is str


# Generated at 2022-06-23 21:48:16.100595
# Unit test for method css of class Structure
def test_Structure_css():
    for _ in range(10):
        print(Structure().css())


# Generated at 2022-06-23 21:48:23.902079
# Unit test for method html of class Structure

# Generated at 2022-06-23 21:48:31.233598
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test for the method html_attribute_value of class Structure."""
    structure = Structure(seed=12345)
    tag = structure.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    attribute = structure.random.choice(
        list(HTML_CONTAINER_TAGS[tag]),  # type: ignore
    )
    value = structure.html_attribute_value(tag, attribute)
    assert value is not None

# Generated at 2022-06-23 21:48:35.426887
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value(tag="img", attribute="src") == "url"
    assert s.html_attribute_value(tag="div", attribute="class") == "css"
    assert s.html_attribute_value(tag="a", attribute="href") == "url"
    assert s.html_attribute_value(tag="a", attribute="title") == "word"

# Generated at 2022-06-23 21:48:37.720400
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    print(structure.css_property())


# Generated at 2022-06-23 21:48:39.987106
# Unit test for method css of class Structure
def test_Structure_css():
    mimesis_structure = Structure()
    result = mimesis_structure.css()
    assert len(result) > 0


# Generated at 2022-06-23 21:48:50.878724
# Unit test for method html of class Structure
def test_Structure_html():

    from mimesis import Datetime

    from mimesis.builtins.helpers import as_string

    # BEGIN test


# Generated at 2022-06-23 21:48:52.891009
# Unit test for constructor of class Structure
def test_Structure():
    test = Structure('en')
    

# Generated at 2022-06-23 21:49:04.968136
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis.enums import CSSProperty
    from mimesis.providers.structure import Structure
    from mimesis.providers.text import Text
    def test_methods_of_Structure(obj):
        obj.provider = 'structure'
        css = obj.css()
        css_property = obj.css_property()
        html = obj.html()
        html_attribute_value = obj.html_attribute_value()
    obj = Structure("en")
    test_methods_of_Structure(obj)

# Generated at 2022-06-23 21:49:07.312059
# Unit test for method html of class Structure
def test_Structure_html():
    """Unit test for method html of class Structure"""
    structure = Structure()
    structure.html()


# Generated at 2022-06-23 21:49:09.140409
# Unit test for method html of class Structure
def test_Structure_html():
    struct = Structure('en')
    result = struct.html()
    assert result is not None
    assert isinstance(result, str)


# Generated at 2022-06-23 21:49:14.312726
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    s.html_attribute_value('a', 'target') == '_blank'
    s.html_attribute_value() == 'word'
    s.html_attribute_value('head', 'profile') == 'http://gmpg.org/xfn/11'
    s.html_attribute_value('a', 'href') == 'url'


# Generated at 2022-06-23 21:49:17.430596
# Unit test for method html of class Structure
def test_Structure_html():
    seed(1)
    assert Structure().html().startswith('<form')
    seed(2)
    assert Structure().html().startswith('<textarea')
    seed(3)
    assert Structure().html().startswith('<p align="bi')

# Generated at 2022-06-23 21:49:27.617506
# Unit test for constructor of class Structure
def test_Structure():
    a = Structure(seed=123)
    assert isinstance(a, Structure)
    assert a.meta.name == 'structure'
    assert a.random.randint(0, 1000, 1) == [59]
    assert a.random.choice([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == 6
    assert a.random.sample([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], k=5) == [5, 4, 1, 8, 3]
    assert a.random.choice(['a', 'b', 'c', 'd', 'e']) == 'e'


# Generated at 2022-06-23 21:49:30.374645
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert isinstance(s, Structure)
    s = Structure(seed=123456789)
    assert isinstance(s, Structure)


# Generated at 2022-06-23 21:49:41.467225
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    import pytest
    structure = Structure(seed=0)

    assert len(structure.css_property()) == 18
    assert len(structure.css()) > 2

    # testing with tag and attribute
    assert structure.html_attribute_value(tag="form", attribute="id") == "inputfield"
    assert structure.html_attribute_value(tag="form", attribute="class") == "large"
    assert structure.html_attribute_value(tag="form", attribute="required") == "required"

    # testing with only tag
    assert len(structure.html_attribute_value(tag="form")) > 0
    # testing with only attribute
    assert len(structure.html_attribute_value(attribute="content")) > 0


# Generated at 2022-06-23 21:49:43.698187
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    obj = Structure()
    result = obj.css_property()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:49:54.054830
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    gen = Structure(seed=5)
    assert gen.html_attribute_value(tag="iframe", attribute="frameborder") == "0"
    assert gen.html_attribute_value(tag="section", attribute="id") == "home"
    assert gen.html_attribute_value(tag="table", attribute="id") == "example"
    assert gen.html_attribute_value(tag="input", attribute="id") == "name"
    assert gen.html_attribute_value(tag="input", attribute="class") == "input"
    assert gen.html_attribute_value(tag="table", attribute="class") == "table"
    assert gen.html_attribute_value(tag="textarea", attribute="class") == "textarea"
    assert gen.html_attribute_value(tag="button", attribute="class") == "button"

# Generated at 2022-06-23 21:50:00.352288
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    s = Structure(seed=1)

    t1 = s.html_attribute_value()
    assert t1 == '#0f8d9f'

    t2 = s.html_attribute_value(tag='a', attribute='href')
    assert t2 == 'http://www.ramirez.net/'

    t3 = s.html_attribute_value(tag='div', attribute='class')
    assert t3 == 'store-item'

    t4 = s.html_attribute_value(tag='div', attribute='style')
    assert t4 == 'word-wrap: break-word; letter-spacing: 1px;'

    t5 = s.html_attribute_value(tag='input', attribute='class')

# Generated at 2022-06-23 21:50:01.986435
# Unit test for method css of class Structure
def test_Structure_css():
    str = Structure()
    s = str.css()
    assert type(s) == str


# Generated at 2022-06-23 21:50:05.214482
# Unit test for method html of class Structure
def test_Structure_html():
    from random import seed

    s = Structure(seed = 1234567890)
    # the result will be:
    # '<select name="selected_index" type="select">Inbox</select>'
    # (for seed = 1234567890)
    assert s.html()


# Generated at 2022-06-23 21:50:07.163634
# Unit test for method css of class Structure
def test_Structure_css():
    print(Structure().css())


# Generated at 2022-06-23 21:50:09.341077
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('en')
    prop = structure.css_property()
    assert prop is not None
    assert isinstance(prop, str)


# Generated at 2022-06-23 21:50:14.506435
# Unit test for method css of class Structure
def test_Structure_css():
    """Unit test for method css of class Structure."""
    array = []
    for i in range(100):
        structure = Structure()
        css = structure.css()
        # print(css)
        check(css, "CSS")
        array.append(css)
    check_unique(array)


# Generated at 2022-06-23 21:50:25.284150
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.providers import Structure
    s = Structure()
    assert s.html_attribute_value(tag='img',attribute='src') == 'url'
    assert s.html_attribute_value(tag='a',attribute='href') == 'url'
    assert s.html_attribute_value(tag='a',attribute='rel') == 'url'
    assert s.html_attribute_value(tag='a',attribute='target') == 'url'
    assert s.html_attribute_value(tag='a',attribute='download') == 'url'
    assert s.html_attribute_value(tag='a',attribute='hreflang') == 'url'
    assert s.html_attribute_value(tag='article',attribute='name') == 'word'

# Generated at 2022-06-23 21:50:27.169674
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    struct = Structure()
    struct.css_property()


# Generated at 2022-06-23 21:50:29.027345
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    c = Structure()
    result = c.css_property()
    assert result != ""


# Generated at 2022-06-23 21:50:30.188868
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    assert s.html()

# Generated at 2022-06-23 21:50:34.486999
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    tmp = Structure()
    html = tmp.html_attribute_value()
    print(html)
    # html = '<span class="select" id="careers">\n            Ports are created with the built-in function open_port.\n            </span>'


# Generated at 2022-06-23 21:50:36.750813
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    provider = Structure(seed=123)
    actual = provider.css_property()
    expected = 'background-position: left'
    assert actual == expected

# Generated at 2022-06-23 21:50:38.130618
# Unit test for method html of class Structure
def test_Structure_html():
    x = Structure()
    assert isinstance(x.html(), str)

# Generated at 2022-06-23 21:50:45.626576
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""

    structure = Structure(seed=42)
    structure.random.choice = lambda x : 'a'
    assert structure.html_attribute_value() == 'CSS'
    assert structure.html_attribute_value('a', 'a') == 'background-color: #f4d3a1'
    assert structure.html_attribute_value('a', 'a') == 'background-color: #f4d3a1'
    assert structure.html_attribute_value('a', 'a') == 'background-color: #f4d3a1'
    assert structure.html_attribute_value('a', 'a') == 'background-color: #f4d3a1'

# Generated at 2022-06-23 21:50:56.023755
# Unit test for constructor of class Structure
def test_Structure():
    
    # Test for the constructor of class Structure (DEFAULT):
    structure = Structure()
    
    # Test the function css (DEFAULT):
    assert(isinstance(structure.css(), str))
    assert(structure.css() != "")
    
    # Test the function css_property (DEFAULT):
    assert(isinstance(structure.css_property(), str))
    assert(structure.css_property() != "")
    
    # Test the function html (DEFAULT):
    assert(isinstance(structure.html(), str))
    assert(structure.html() != "")
    
    # Test the function html_attribute_value (DEFAULT):
    assert(isinstance(structure.html_attribute_value(), str))
    assert(structure.html_attribute_value() != "")
   