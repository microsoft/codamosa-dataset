

# Generated at 2022-06-23 21:41:02.601165
# Unit test for method css of class Structure
def test_Structure_css():
    css = Structure()
    print("#"*26 + " Unit test for method css of class Structure" + "#"*26)
    for i in range(6):
        print("generate css "+str(i)+":" + css.css())


# Generated at 2022-06-23 21:41:07.265016
# Unit test for method html of class Structure
def test_Structure_html():
    provider = Structure('en')
    result = provider.html()
    print(result)
    # Sample output:
    # <div id="top">Grown non-atomic</div>
    # <p class="last">
    # <input name="top" value="Uriah"/>Nickolas</p>



# Generated at 2022-06-23 21:41:19.179830
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import HTMLElements, HTMLTagAttribute
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.structure import Structure

    s = Structure()

    assert any(s.html().startswith(tag) for tag in HTMLElements)
    assert any(s.html().startswith(tag) for tag in HTMLElements)

    # Method should return, as a string, the HTML tag and its attribute.
    # Testing tag a and attributes href, target, and rel.
    assert any(s.html_attribute_value(tag='a',
                attribute=attr).startswith(attr)
               for attr in HTMLTagAttribute.__members__['a'])

    # Testing whether is possible to generate random values
    # for unsupported attributes

# Generated at 2022-06-23 21:41:26.165320
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()

    assert isinstance(structure.html(), str)
    assert isinstance(structure.html('html'), str)
    assert isinstance(structure.html('html', 'id'), str)
    assert isinstance(structure.html('a', 'href'), str)

    try:
        structure.html('html', 'invalid_attribute')
        assert not True
    except NotImplementedError:
        assert True
    except Exception:
        assert False
    else:
        assert False

# Generated at 2022-06-23 21:41:29.869787
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    html_attr_val = s.html_attribute_value('a', 'href')
    assert isinstance(html_attr_val, str) and html_attr_val.startswith('http')


# Generated at 2022-06-23 21:41:31.503499
# Unit test for method css of class Structure
def test_Structure_css():
    x = Structure()
    css = x.css()
    assert isinstance(css, str)


# Generated at 2022-06-23 21:41:35.700390
# Unit test for constructor of class Structure
def test_Structure():
    """Test for constructor of class Structure."""
    s = Structure()
    assert s is not None
    assert isinstance(s, Structure)
    assert isinstance(s.random, type(s.random))
    assert isinstance(s.seed, int)


# Generated at 2022-06-23 21:41:42.701365
# Unit test for method html of class Structure
def test_Structure_html():
    import re
    structure = Structure(seed=0)
    html = structure.html()
    assert(html[0] == '<')
    assert(html[-1] == '>')
    assert(re.match('<[a-zA-z]+ [a-zA-z]+="[a-zA-Z0-9]+">[a-zA-z]+ [a-zA-z]+[.,]</[a-zA-z]+>', html)) == True

# Generated at 2022-06-23 21:41:46.318653
# Unit test for method html of class Structure
def test_Structure_html():
    # Setup
    sd = Structure()

    # Exercise
    html = sd.html()

    # Verify
    assert html.startswith('<')
    assert html.endswith('>')

    # Cleanup - none necessary


# Generated at 2022-06-23 21:41:49.478615
# Unit test for method css_property of class Structure
def test_Structure_css_property():
	structure = Structure()
	structure.seed(0)
	structure.css_property()
	

# Generated at 2022-06-23 21:41:54.105151
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    for i in range(100):
        tag_name = s.random.choice(list(HTML_CONTAINER_TAGS))
        tag_attributes = list(HTML_CONTAINER_TAGS[tag_name])
        attribute = s.random.choice(tag_attributes)
        assert s.html_attribute_value(tag_name, attribute) is not None


# Generated at 2022-06-23 21:42:05.234121
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis import Structure
    from mimesis.enums import CssProperty as cssPro, CssUnit as cssUnt
    css = Structure('en')
    for i in range(3):
        prop = css.css_property()

# Generated at 2022-06-23 21:42:07.060780
# Unit test for method html of class Structure
def test_Structure_html():
    t = Structure()
    html = t.html()
    # print(html)


# Generated at 2022-06-23 21:42:09.983371
# Unit test for method html of class Structure
def test_Structure_html():
    str1 = Structure().html()
    assert len(str1) > 0
    assert isinstance(str1, str) == True  # Test is not necessary


# Generated at 2022-06-23 21:42:10.981786
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    html = structure.html()
    assert html[:2] == '<' and html[-1:] == '>'

# Generated at 2022-06-23 21:42:12.240675
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    strt = Structure()
    temp = strt.css_property()
    assert temp is not None


# Generated at 2022-06-23 21:42:22.822162
# Unit test for constructor of class Structure
def test_Structure():
    temp = Structure()

    # .html_attribute_value()
    # .html_attribute_value(tag='span', attribute='id')
    assert temp.html_attribute_value(tag='span', attribute='id') is not None
    # .html_attribute_value(attribute='id')
    assert temp.html_attribute_value(attribute='id') is not None
    # .html_attribute_value('div')
    assert temp.html_attribute_value(tag='div') is not None
    # .html_attribute_value('div', 'foo')
    try:
        temp.html_attribute_value(tag='div', attribute='foo')
    except NotImplementedError:
        pass

    # .css_property()
    assert temp.css_property() is not None

    # .css()
    assert temp.css()

# Generated at 2022-06-23 21:42:29.865283
# Unit test for constructor of class Structure
def test_Structure():
    print ("Unit test for constructor of class Structure:\n")

    # Set seed
    s = Structure(seed=1)

    # Check types of attributes
    assert type(s) == Structure
    assert type(s.seed) == int
    assert type(s.__inet) == Internet
    assert type(s.__text) == Text

    # Check values of attributes
    assert s.seed == 1
    assert s.__inet.seed == 1
    assert s.__text.seed == 1


# Generated at 2022-06-23 21:42:33.073960
# Unit test for method css of class Structure
def test_Structure_css():
    css = Structure().css()
    assert not (css.find('body') == -1)
    assert not (css.find('a:link') == -1)


# Generated at 2022-06-23 21:42:34.645583
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    result = structure.html_attribute_value()
    print(result)
    result = structure.html_attribute_value('a', 'href')
    print(result)

# Generated at 2022-06-23 21:42:37.338817
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Arrange
    structure = Structure('en')

    # Act
    property = structure.css_property()

    # Assert
    assert len(property) > 0



# Generated at 2022-06-23 21:42:38.645624
# Unit test for method css of class Structure
def test_Structure_css():
    print()
    print(Structure().css())
    return


# Generated at 2022-06-23 21:42:41.386021
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    bg = s.css_property()
    print(bg)
    assert bg == 'background-color: rgb(57, 75, 31)'


# Generated at 2022-06-23 21:42:45.318365
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()

    tag = 'img'
    attribute = 'src'
    result = structure.html_attribute_value(tag, attribute)
    assert result

    tag = structure.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    attribute = structure.random.choice(list(HTML_CONTAINER_TAGS[tag]))
    result = structure.html_attribute_value(tag, attribute)
    assert result

# Generated at 2022-06-23 21:42:48.419387
# Unit test for method css of class Structure
def test_Structure_css():
    css = Structure()
    assert css.css() == '<a font-size="12em" href="http://www.lisa.com/" name="lynda">fugiat</a>'


# Generated at 2022-06-23 21:42:52.366754
# Unit test for method css of class Structure
def test_Structure_css():
    x = Structure('en')
    assert x.css() == '#line-height .CZ2{background-size: 3%; text-decoration: none; display: inherit; border-width: 2in; font-size: small; background-color: #ff3d3c;}'

# Generated at 2022-06-23 21:42:52.960745
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()

# Generated at 2022-06-23 21:43:03.911594
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Initialize
    S = Structure()
    
    # Make sure each of the following CSS properties has the correct format (e.g. "background-color: #f4d3a1")
    # by checking the result of each call of function css_property
    assert S.css_property().split(':')[0] == 'background-color'
    assert S.css_property().split(':')[1].strip() == '#f4d3a1'    
    
    assert S.css_property().split(':')[0] == 'border'
    assert S.css_property().split(':')[1]

    assert S.css_property().split(':')[0] == 'border-collapse'
    assert S.css_property().split(':')[1]

    assert S.css_property().split

# Generated at 2022-06-23 21:43:14.353297
# Unit test for method css_property of class Structure
def test_Structure_css_property():

    from mimesis.enums import CSSSelectors
    from mimesis.enums import CSSProperties
    from mimesis.enums import CSSSizeUnits

    st = Structure()
    result = st.css_property()

    # checking if result is a nonempty string
    assert(isinstance(result, str))
    assert(result != '')

    # checking if result ends with CSSSizeUnits
    assert(result[-2:] in CSSSizeUnits.__members__)

    # checking if result contains CSSProperties
    assert(result.find(':') != -1)
    assert(result[:result.find(':')].strip() in CSSProperties.__members__)

    # checking if result is a valid CSS property
    assert(result[-2:] in CSSSizeUnits.__members__)

# Generated at 2022-06-23 21:43:15.769676
# Unit test for method css of class Structure
def test_Structure_css():
    obj = Structure()
    temp = obj.css()
    assert temp is not None


# Generated at 2022-06-23 21:43:17.635110
# Unit test for constructor of class Structure
def test_Structure():
    # Check constructor of class Structure
    assert isinstance(Structure(), Structure)


# Generated at 2022-06-23 21:43:20.184224
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    tag = 'img'
    attribute = 'src'
    value = Structure().html_attribute_value(tag, attribute)
    assert isinstance(value, str)
    assert len(value) > 0

# Generated at 2022-06-23 21:43:22.153151
# Unit test for method css of class Structure
def test_Structure_css():
    # call the method
    s = Structure()
    result = s.css()

    # check the result
    assert result


# Generated at 2022-06-23 21:43:23.830595
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    print(structure.html())

# Generated at 2022-06-23 21:43:31.172728
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # r = Structure()
    r = Structure(seed=1337)
    # Assert css_property() is a string
    assert isinstance(r.css_property(), str)
    # Assert value of css_property() is a string
    assert type(r.css_property().split(':')[1].strip()) == str
    # Assert value of css_property() is a number
    # assert type(r.css_property().split(':')[1].split(' ')[0].strip()) == int
    # Assert value of css_property() is a hex color
    # assert len(r.css_property().split(':')[1].strip()) == 7 and r.css_property().split(':')[1].strip()[0] == '#'


# Generated at 2022-06-23 21:43:34.582429
# Unit test for method html of class Structure
def test_Structure_html():
    # Test
    my_Structure = Structure("en")
    result = my_Structure.html()

    # Assert
    assert isinstance(result, str)


# Generated at 2022-06-23 21:43:35.737771
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    property = structure.css_property()
    assert type(property) is str



# Generated at 2022-06-23 21:43:40.339953
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    tag = structure.html().split(' ')[0].replace('<', '')
    attr = structure.html().replace('<', '').replace('>', '').split(' ')[1].split('=')[0]
    # assert tag in HTML_CONTAINER_TAGS, 'Generated tag {} not found in Structured.HTML_CONTAINER_TAGS'.format(tag)
    # assert attr in HTML_CONTAINER_TAGS[tag], 'Generated attribute {} not found in Structured.HTML_CONTAINER_TAGS[{}]'.format(attr, tag)



# Generated at 2022-06-23 21:43:44.455417
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Unit test for method css_property of class Structure."""
    _structure = Structure() # create the object
    _property = _structure.css_property() # call the method
    assert _property is not None

# Generated at 2022-06-23 21:43:47.411169
# Unit test for constructor of class Structure
def test_Structure():
    import mimesis.enums
    s = Structure(mimesis.enums.Language.ENGLISH)
    assert s is not None

# Generated at 2022-06-23 21:43:49.471097
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    css_prop = Structure().css_property()
    assert css_prop

# Generated at 2022-06-23 21:43:54.244652
# Unit test for constructor of class Structure
def test_Structure():
    с = Structure()
    print(с.html())
    print(с.css())
    print(с.css_property())
    print(с.html_attribute_value(attribute='class', tag='span'))

if __name__=='__main__':
    test_Structure()

# Generated at 2022-06-23 21:44:01.844168
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    # создаем объект
    rus = RussiaSpecProvider(locale='ru')
    # указываем какой провайдер использовать
    rus.add_provider('personal', 'ru')
    # генерируем параметры
    gender = Gender.FEMALE
    name = rus.personal.get_full_name(gender, patronymic=True)
    birth_date = rus.datetime.date(start=2000, end=2001)
    patron

# Generated at 2022-06-23 21:44:10.675043
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure"""

    class_test = Structure(seed=123)

    list_html_tag = list(
        HTML_CONTAINER_TAGS.keys(),
    )
    class_test._random.shuffle(list_html_tag)
    tag = list_html_tag[0]
    list_attrs = list(
        HTML_CONTAINER_TAGS[tag],  # type: ignore
    )
    class_test._random.shuffle(list_attrs)
    attr = list_attrs[0]


# Generated at 2022-06-23 21:44:20.188253
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Test case data
    test = Structure(seed=12345)
    test_input = ['color', 'font-family', 'font-size', 'background']
    expected_output = [
        'color: #f4d3a1',
        'font-family: "Comic Sans MS", "Comic Sans", cursive',
        'font-size: 79px',
        'background: url("https://www.w3schools.com/w3images/fjords.jpg")',
    ]
    # Compare
    count = 0
    while count < len(test_input):
        assert test.css_property(test_input[count]) == expected_output[count]
        count += 1
    # Test case data
    test = Structure(seed=12345)

# Generated at 2022-06-23 21:44:21.128201
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert isinstance(structure.html_attribute_value(),str)

# Generated at 2022-06-23 21:44:23.099934
# Unit test for method css of class Structure
def test_Structure_css():
    locale = 'en'
    seed = 0
    structure = Structure(locale, seed) # type: ignore
    css = structure.css()
    print(css)


# Generated at 2022-06-23 21:44:29.067325
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    inst = Structure()
    for tag, attrs in HTML_CONTAINER_TAGS.items():
        for attr in attrs.keys():
            value = inst.html_attribute_value(tag, attr)
            assert value is not None

if __name__ == '__main__':
    inst = Structure()
    test_Structure_html_attribute_value()

# Generated at 2022-06-23 21:44:35.528660
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure(seed=1)
    assert (s.html_attribute_value(tag='a', attribute='href') == 'url')
    assert (s.html_attribute_value(tag='a', attribute='href') == 'www.x.blog')
    assert (s.html_attribute_value(tag='a', attribute='href') == 'url')
    assert (s.html_attribute_value(tag='a', attribute='href') == 'www.example.com')

# Generated at 2022-06-23 21:44:39.653601
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Test for method css_property of class Structure."""
    structure = Structure()
    result = structure.css_property()
    assert isinstance(result, str)
    assert result.count(':') == 1
    assert result.count(';') == 0


# Generated at 2022-06-23 21:44:43.999685
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure('en', seed=42)
    result = structure.css()
    assert result == 'group .form-textarea-wrapper {color: #9df350; '\
        'word-break: break-word; background-color: #6b3023;'\
        ' text-rendering: optimizeSpeed; text-align: left;}'



# Generated at 2022-06-23 21:44:46.749959
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert (s.html_attribute_value('a', 'href') is not None)
    assert (s.html_attribute_value('select', 'name') is not None)
    assert (s.html_attribute_value('input', 'type') is not None)

# Generated at 2022-06-23 21:44:50.095584
# Unit test for constructor of class Structure
def test_Structure():
	structure = Structure()
	info(structure)
	info(structure.__dict__)
	info(Structure.__dict__)

	
if __name__ == '__main__':
	from etc.logger import info

	test_Structure()

# Generated at 2022-06-23 21:45:02.035930
# Unit test for method css of class Structure
def test_Structure_css():
    Arguments = ["css"]
    assert Structure(seed=0).css() == "h5 {background-image: #f3d5a5; border-bottom: 3px; border-color: #f2cc9f; border-left-style: dotted; border-right-style: dotted; border-style: inset; border-top-color: #f6ddae; display: flex; font-family: 'Comic Sans MS',sans-serif; font-size: 19px; margin-left: 13px; opacity: 0.55; outline-color: #f7d8ac; overflow-y: auto; padding-bottom: 24px; padding-left: 8px; text-align: center; text-shadow: #f5d2a5; width: 90px;}"


# Generated at 2022-06-23 21:45:03.692399
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    S = Structure()
    property = S.css_property()
    assert isinstance(property, str)


# Generated at 2022-06-23 21:45:12.513290
# Unit test for method html of class Structure
def test_Structure_html():
    from ddt import data, ddt, unpack
    import random

    @ddt
    class TestStructureHtml:
        def setUp(self):
            self.__seed = random.randint(0, 2 ** 32)
            self.__struct = Structure(seed=self.__seed)


# Generated at 2022-06-23 21:45:16.350389
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    print('Test method "css_property" of class "Structure"')
    structure = Structure()
    print(structure.css_property())
    print(structure.css_property())
    print(structure.css_property())


# Generated at 2022-06-23 21:45:21.507516
# Unit test for method html of class Structure
def test_Structure_html():
    #Input
    s = Structure(seed=1)
    #Expected output
    expected = '<p class="port" id="fonds">Octahedra are created with the ' \
               'built-in function open_port.</p>'
    #Actual output
    actual = s.html()
    #Test
    assert actual == expected


# Generated at 2022-06-23 21:45:23.576105
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    for _ in range(10):
        assert type(s.css_property()) == str


# Generated at 2022-06-23 21:45:25.617607
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure('en')
    assert structure.html_attribute_value('IMG', 'src')

# Generated at 2022-06-23 21:45:27.500316
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st = Structure()
    prop = st.css_property()
    assert prop


# Generated at 2022-06-23 21:45:30.305907
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    assert len(structure.html()) > 0
    assert structure.html().startswith('<')
    assert structure.html().endswith('>')



# Generated at 2022-06-23 21:45:43.225113
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Test case when method is called without parameters
    structure = Structure()
    actual = structure.html_attribute_value()
    assert bool(actual) is True
    # Test case when first parameter passed only
    actual = structure.html_attribute_value('a')
    assert bool(actual) is True
    # Test case when second parameter passed only
    actual = structure.html_attribute_value(None, 'class')
    assert bool(actual) is True
    # Test case when both parameters passed
    actual = structure.html_attribute_value('img', 'alt')
    assert bool(actual) is True
    # Test case when unsupported tag passed
    try:
        structure.html_attribute_value('Q')
    except NotImplementedError:
        assert True
    # Test case when unsupported attribute passed

# Generated at 2022-06-23 21:45:48.118980
# Unit test for method css of class Structure
def test_Structure_css():
    obj = Structure(seed=123)
    prop = obj.css()
    prop_right = "article #target {margin: 0%; color: #e24c4c; \
width: 31px; padding: 10px; overflow: hidden; background-color: #b7305d; \
letter-spacing: 3px; opacity: 0.4; display: none; border: 2px double #bdd5f5;}"
    assert prop == prop_right


# Generated at 2022-06-23 21:45:57.064060
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    for i in range(1000):
        result=structure.html()
        assumed=result.split(' ')[0]
        asseumed_attr=result.split(' ')[1].split('"')[0]
        if assumed[1:].lower() not in HTML_CONTAINER_TAGS.keys():
            print('Error')
            break
        if asseumed_attr not in HTML_CONTAINER_TAGS[assumed[1:]].keys():
            print('Error')
            break
    print('No error')



# Generated at 2022-06-23 21:45:58.364271
# Unit test for method css of class Structure
def test_Structure_css():
    struct=Structure(seed=0)
    struct.css()

# Generated at 2022-06-23 21:46:02.148692
# Unit test for constructor of class Structure
def test_Structure():
    print('\nTest for constructor of class Structure')
    structure = Structure()
    print(structure)
    print(structure.seed)
    print(structure.random)
    print(structure.__dict__)


# Generated at 2022-06-23 21:46:03.333288
# Unit test for method css of class Structure
def test_Structure_css():
    test = Structure()  # type: ignore
    r = test.css()
    print(r)


# Generated at 2022-06-23 21:46:09.964836
# Unit test for method css of class Structure
def test_Structure_css():
    Structure._Structure__inet = lambda self: 'http://aab.ru/'
    Structure._Structure__text = lambda self: 'Some text'

    s = Structure(seed=0)

    assert (s.css() == '#ports {width: 77; font-size: 71; text-align: left; '
                       'font-weight: bold; text-decoration: underline; '
                       'font-family: "Times New Roman", Times, serif; '
                       'background-size: 4; color: #1fdaaf; '
                       'background-color: #546f5a}')



# Generated at 2022-06-23 21:46:22.377458
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    from mimesis.enums import Locale

    from mimesis.builtins import RussiaSpecProvider

    def _en_tests():
        s = Structure(Locale.EN)
        assert s.html_attribute_value(tag=None, attribute=None) != None
        assert s.html_attribute_value(tag='', attribute='') != None
        assert s.html_attribute_value(tag='a', attribute='href') != None
        assert len((s.html_attribute_value(tag='a', attribute='href')).split('://')) == 2
        assert s.html_attribute_value(tag='a', attribute='href-alternate') != None
        assert len((s.html_attribute_value(tag='a', attribute='href-alternate')).split('://')) == 2
        assert s.html_attribute_

# Generated at 2022-06-23 21:46:24.663792
# Unit test for constructor of class Structure
def test_Structure():
    my_struct = Structure(seed=100)
    assert my_struct._Structure__text.sentence() == 'Pit'


# Generated at 2022-06-23 21:46:26.731166
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert isinstance(s, Structure)


# Generated at 2022-06-23 21:46:33.452525
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure(seed=0).html_attribute_value('a', 'href') == 'http://www.lutz.com'
    assert Structure(seed=0).html_attribute_value('a', 'target') == '_blank'
    assert Structure(seed=0).html_attribute_value('a', 'rel') == 'nofollow'
    assert Structure(seed=0).html_attribute_value('a', 'title') == 'condition'
    assert Structure(seed=0).html_attribute_value('button', 'form') == 'url'
    assert Structure(seed=0).html_attribute_value('button', 'type') == 'submit'
    assert Structure(seed=0).html_attribute_value('button', 'name') == 'navigation'

# Generated at 2022-06-23 21:46:35.644608
# Unit test for method css_property of class Structure
def test_Structure_css_property():

    a = Structure()
    assert isinstance(a.css_property(), str)
    assert len(a.css_property()) > 0


# Generated at 2022-06-23 21:46:39.029638
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    for tag in HTML_CONTAINER_TAGS.keys():
        for attr in HTML_CONTAINER_TAGS[tag]:
            result = s.html_attribute_value(tag, attr)
    assert len(result) > 0

# Generated at 2022-06-23 21:46:42.079875
# Unit test for method html of class Structure
def test_Structure_html():
    pass

if __name__ == "__main__":
    # Unit test for method html of class Structure
    test_Structure_html()

# Generated at 2022-06-23 21:46:43.174039
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure is not None

# Generated at 2022-06-23 21:46:51.472117
# Unit test for method css of class Structure
def test_Structure_css():
    from pprint import pprint
    from mimesis.enums import CSSUnit

    test = Structure("en")
    test_set = set()
    num_tests = 100

    for i in range(num_tests):
        example = test.css()
        test_set.add(example)

    for test in test_set:
        print("Test: {}".format(test))

    if len(test_set) != num_tests:
        print("ERROR: Hash collisions")
    else:
        print("SUCCESS: No hash collisions")

    print("Num tests: {}".format(len(test_set)))



# Generated at 2022-06-23 21:46:53.449292
# Unit test for constructor of class Structure
def test_Structure():
    """Test the constructor of Structure class."""
    s = Structure()
    assert s is not None
    assert 'Structure' in s.get_provider_name()


# Generated at 2022-06-23 21:47:05.347982
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s.random.choice(CSS_SELECTORS).__class__.__name__ == 'str'
    assert s.random.choice(CSS_SELECTORS).__class__.__name__ == 'str'
    assert s.random.choice(list(HTML_CONTAINER_TAGS.keys())).__class__.__name__ == 'str'
    assert s.random.choice(list(HTML_CONTAINER_TAGS.keys())).__class__.__name__ == 'str'
    assert s.random.choice(list(HTML_CONTAINER_TAGS.keys())).__class__.__name__ == 'str'
    assert s.random.choice(list(HTML_CONTAINER_TAGS.keys())).__class__.__name__ == 'str'
    assert s.random.choice

# Generated at 2022-06-23 21:47:06.933595
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() != structure.css_property()

#Unit test for method html_attribute_value of class Structure

# Generated at 2022-06-23 21:47:08.364921
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    print(s.html())


# Generated at 2022-06-23 21:47:12.965970
# Unit test for method html of class Structure
def test_Structure_html():
    # Arrange
    import random
    from mimesis.providers.structure import Structure
    data_provider = Structure(locale='en', seed=0)
    data_provider.random = random.Random(0)
    expected = '<span style="width: 35%;">Perfective memory.</span>'
    # Act
    actual = data_provider.html()
    # Assert
    assert actual == expected

# Generated at 2022-06-23 21:47:16.711599
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('link') == 'link'  # type: ignore
    assert s.html_attribute_value('td','rowspan') == 'rowspan'  # type: ignore


# Generated at 2022-06-23 21:47:17.674335
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure


# Generated at 2022-06-23 21:47:21.629502
# Unit test for constructor of class Structure
def test_Structure():
    x = Structure('en')
    assert x.Meta.name == 'structure'
    assert x.text.Meta.name == 'text'
    assert x.text.locale == 'en'
    assert x.internet.Meta.name == 'internet'
    assert x.internet.locale == 'en'


# Generated at 2022-06-23 21:47:24.071105
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Unit test for method css_property of class Structure."""
    r = Structure()
    assert len(r.css_property()) > 0



# Generated at 2022-06-23 21:47:25.760335
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    st=Structure()
    print(st.html_attribute_value('a', 'rel'))

# Generated at 2022-06-23 21:47:30.026488
# Unit test for constructor of class Structure
def test_Structure():
	# test if the constructor is defined
	structure = Structure(locale='en')
	assert structure is not None, 'Failed to create constructor'


# Generated at 2022-06-23 21:47:31.815018
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    print(s.css_property())


# Generated at 2022-06-23 21:47:32.793562
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure is not None


# Generated at 2022-06-23 21:47:33.916176
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    for i in range(10):
        print(structure.css_property())

# Generated at 2022-06-23 21:47:38.218026
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value() is not None
    assert s.html_attribute_value(tag="a") is not None
    assert s.html_attribute_value(tag="a", attribute="href") is not None
    tag = s.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    assert s.html_attribute_value(tag=tag) is not None
    attr = s.random.choice(list(HTML_CONTAINER_TAGS[tag]))
    assert s.html_attribute_value(tag=tag, attribute=attr) is not None

# Generated at 2022-06-23 21:47:45.118851
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure(seed=230)
    assert s.html() == '<div class="vacation" id="singular">Pellentesque nibh.' \
                       '</div>'
    assert s.html() == '<embed class="course" id="long">Dictumst.</embed>'
    assert s.html() == '<p class="revise" id="expansion">Quisque aliquet.' \
                       '</p>'
    assert s.html() == '<span class="select" id="careers">Ports are created' \
                       ' with the built-in function open_port.</span>'
    assert s.html() == '<b class="employee" id="agreement">Dictumst.</b>'

# Generated at 2022-06-23 21:47:49.763089
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    struct1 = Structure('en')
    struct2 = Structure()
    for _ in range(10):
        prop = struct1.css_property()
        # Check that we get a property of the form 'prop: value'
        assert (prop.count(':') == 1) is True
        # Check that the property has a value
        assert (len(prop.split(': ')[1]) != 0) is True
    for _ in range(10):
        assert struct2.css_property() != struct1.css_property()



# Generated at 2022-06-23 21:47:53.308443
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s.random.choice(list(HTML_CONTAINER_TAGS)) != None 
    assert s.random.choice(list(CSS_PROPERTIES)) != None

# Generated at 2022-06-23 21:47:54.436383
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()
    assert struct is not None

# Generated at 2022-06-23 21:47:55.970906
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert Structure().css_property() == 'background-size: 39rem'


# Generated at 2022-06-23 21:47:57.981326
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    assert s.css() == 'div {border: 10px; margin: 10cm}'

# Generated at 2022-06-23 21:48:03.646423
# Unit test for constructor of class Structure
def test_Structure():
    eq_(Structure().random.choice(['a', 'b', 'c']), 'b')
    eq_(Structure(seed=1).random.choice(['a', 'b', 'c']), 'c')

    locale = 'en'
    seed = 1
    structure = Structure(locale, seed)
    assert structure.random.choice(['a', 'b', 'c']) == 'b'
    assert structure.random.choice(['a', 'b', 'c']) == 'a'
    assert structure.random.choice(['a', 'b', 'c']) == 'c'

# Generated at 2022-06-23 21:48:05.383097
# Unit test for constructor of class Structure
def test_Structure():
        structure = Structure()
        assert structure is not None


# Generated at 2022-06-23 21:48:09.351402
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure(seed=0)
    assert structure.css() == "h2 {margin-top: 100%; background-color: #f4d3a1}"


# Generated at 2022-06-23 21:48:11.217937
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    seed(5)
    s = Structure(seed=5)
    print(s.html_attribute_value())

# Generated at 2022-06-23 21:48:20.185691
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.exceptions import NotImplementedError
    from mimesis.mimesis import Mimesis
    from mimesis.providers.structure import Structure
    from mimesis.providers.text import Text

    # Create a structured data provider
    structure_provider = Structure('en')
    # Create a generic text provider
    text_provider = Text('en')

    structure_provider._seed(1234)
    text_provider._seed(1234)

    # If tag is not specified then the provider will generate a random tag
    tag = structure_provider.random.choice(list(structure_provider._html_container_tags.keys()))
    # If attribute is not specified then the provider will generate a random attribute related to the tag

# Generated at 2022-06-23 21:48:27.077831
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    def is_css_property(method):
        """Is string CSS property encoder."""
        css_property = method()
        assert isinstance(css_property, str), 'Not string!'
        assert ':' in css_property, 'No colon!'
        assert all(css_property.split(':'))

        split = css_property.split(':')
        value = split[-1]
        value = value.strip()
        assert value, 'Empty value!'

        key = split[0]
        key = key.strip()
        assert key, 'Empty key! {}'.format(css_property)
        assert key in CSS_PROPERTIES, 'Not in CSS_PROPERTIES: {}'.format(
            key)

    def is_color(method):
        """Is string CSS property encoder."""
       

# Generated at 2022-06-23 21:48:28.716308
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    print(structure.html_attribute_value())
    print(structure.html_attribute_value(tag='a', attribute='href'))

# Generated at 2022-06-23 21:48:29.910395
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    html = structure.html()
    print(html)



# Generated at 2022-06-23 21:48:38.977420
# Unit test for method css of class Structure
def test_Structure_css():
    """Unit tests for method css of class Structure."""
    s = Structure()

# Generated at 2022-06-23 21:48:49.914170
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from pydoc import locate
    from mimesis.data import CSS_PROPERTIES
    from mimesis.exceptions import UnsupportedLanguageError
    from mimesis.providers.structure import Structure
    from mimesis.providers.text import Text
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet
    from mimesis.providers.datetime import Datetime


    s = Structure()
    text = Text()
    inet = Internet()
    dt = Datetime()

    # Test Properties
    assert s.css_property() in CSS_PROPERTIES.keys()

    # Test UnsupportedLanguageError

# Generated at 2022-06-23 21:48:52.866545
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure(seed=1)
    data = s.html()
    assert data == '<style id="infrastructure">Fictum, deserunt mollitia animi, quo dolore fuga possimus,</style>'


# Generated at 2022-06-23 21:48:54.434324
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s._meta.name == 'structure'

# Generated at 2022-06-23 21:48:55.981179
# Unit test for method css of class Structure
def test_Structure_css():
    strct = Structure()
    assert strct.css() is not None


# Generated at 2022-06-23 21:48:58.068825
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure is not None


# Generated at 2022-06-23 21:49:02.234445
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    structure.html() == '<span class="select" id="careers"> \n            \
    Ports are created with the built-in function open_port.\n            </span>'


# Generated at 2022-06-23 21:49:12.148969
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test for method html_attribute_value of class Structure."""
    structure = Structure()
    # 0 - test for input tag (input tag is not in HTML_CONTAINER_TAGS)
    ret = structure.html_attribute_value('input', 'name')
    assert ret == 'name="{}"'.format(structure.__text.word())
    # 1 - test for another tag
    ret = structure.html_attribute_value('a', 'href')
    assert ret == 'href="{}"'.format(structure.__inet.home_page())
    # 2 - test for not supported attribute (input)
    ret = structure.html_attribute_value('input', 'placeholder')
    assert ret == 'placeholder="{}"'.format(structure.__text.word())
    # 3 - test for not supported attribute (a)


# Generated at 2022-06-23 21:49:17.283858
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    print(s.html())
    print(s.html_attribute_value('a', 'href'))
    print(s.html_attribute_value('a', 'rel'))
    print(s.html_attribute_value('div', 'class'))
    print(s.html_attribute_value('div', 'id'))

if __name__ == '__main__':
    test_Structure_html_attribute_value()

# Generated at 2022-06-23 21:49:24.757179
# Unit test for method css of class Structure
def test_Structure_css():
    struct = Structure()
    struct.seed(2)
    assert struct.css() == 'header .main {background: #a69e6a; font-size: 53px; ' \
                           'width: 53px; border: 1px solid #4ce1cb; width: 82px; ' \
                           'color: #3831b3; border-color: #c83ead; font-size: 61px}'



# Generated at 2022-06-23 21:49:25.925623
# Unit test for constructor of class Structure
def test_Structure():
    Structure().__init__()

# Generated at 2022-06-23 21:49:28.891722
# Unit test for method css of class Structure
def test_Structure_css():
    """Unit test for method css of class Structure."""
    structure = Structure()
    assert isinstance(structure.css(), str)
    assert len(structure.css()) != 0


# Generated at 2022-06-23 21:49:29.861037
# Unit test for method html of class Structure
def test_Structure_html():
    assert Structure().html()


# Generated at 2022-06-23 21:49:37.409702
# Unit test for method css of class Structure
def test_Structure_css():
    """ Unit test for method css of class Structure
    """
    _st = Structure()
    _st.random.seed(0)
    assert _st.css() == 'h1 {margin: 13px; width: 65%; display: block}'
# Test the method css with a seed of 0



# Generated at 2022-06-23 21:49:39.596522
# Unit test for method html of class Structure
def test_Structure_html():
    assert Structure().html() == '''<span class="select" id="careers">
    Ports are created with the built-in function open_port.
    </span>'''

# Generated at 2022-06-23 21:49:51.174744
# Unit test for constructor of class Structure
def test_Structure():
    # Check if initialize works correctly
    s = Structure(seed=42)
    assert s is not None
    assert len(s.random) == 100
    assert s.random[0] == -0.19224676830584928
    assert s.random[99] == -0.8684835642676345
    assert s.random[42] == 0.030908675376388483
    assert s.random.state == 'n3q'
    assert s.random.jumpahead(10) == 1000
    assert s.random.state == 't3q'

# Generated at 2022-06-23 21:49:53.009703
# Unit test for method html of class Structure
def test_Structure_html():
    assert Structure().html().find('<a') == 0


# Generated at 2022-06-23 21:49:56.867838
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(seed=12345)
    r = s.css()
    assert r == '#identifier {background-color: #e8d7f6; float: right; height: 58px; position: absolute; text-align: center; transform: matrix(1, 0, 0, -1, 0, 0); width: 30px}'


# Generated at 2022-06-23 21:50:05.748869
# Unit test for method css of class Structure
def test_Structure_css():
    # Arrange
    structure = Structure("en")
    # Act
    css = structure.css()
    # Assert
    assert css.startswith("{") == True
    assert css.endswith("}") == True
    assert len(css.split(";")) >= 1
    assert len(css.split(";")) <= 6
    assert css.count("background-image: url(") == 1
    assert css.count(" ") >= 1
    assert css.count(" ") <= 6
    assert css.count("background-color: #") == 1
    assert css.count("px") >= 1
    assert css.count("px") <= 6
    assert css.count("%") >= 1
    assert css.count("%") <= 6
    assert css.count("pt")

# Generated at 2022-06-23 21:50:07.241993
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    html = structure.html()
    assert len(html)>0


# Generated at 2022-06-23 21:50:09.147316
# Unit test for method css of class Structure
def test_Structure_css():
    with Structure() as s:
        result = s.css()
        print(f'[{result}]\n')


# Generated at 2022-06-23 21:50:11.945808
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    for i in range(100):
        q = Structure(seed=i)
        p = q.css_property()
        assert isinstance(p, str)
        assert p

# Generated at 2022-06-23 21:50:13.976222
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct = Structure()
    struct.html_attribute_value('a', 'href')

# Generated at 2022-06-23 21:50:18.251379
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure.__inet.__class__.__name__ == 'Internet'
    assert structure.__text.__class__.__name__ == 'Text'


# Generated at 2022-06-23 21:50:21.005302
# Unit test for method html of class Structure
def test_Structure_html():
    str = Structure()
    html = str.html()
    assert isinstance(html, str)
    assert len(html) > 0

# Generated at 2022-06-23 21:50:23.821850
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = 'link'
    attribute = 'charset'
    assert structure.html_attribute_value(tag, attribute) == 'word'

# Generated at 2022-06-23 21:50:31.300557
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    print(structure.html_attribute_value('img', 'src'))
    # output: https://www.bbc.co.uk/news/world

    print(structure.html_attribute_value('button', 'style'))
    # output: color: #0d04f0; text-align: justify; background-color: #f4d3a1;
    
    print(structure.html_attribute_value('table', 'class'))
    # output: careers

# Generated at 2022-06-23 21:50:32.130275
# Unit test for method html of class Structure
def test_Structure_html():
    html_ = Structure()
    assert isinstance(html_.html(), str)

# Generated at 2022-06-23 21:50:41.801499
# Unit test for constructor of class Structure
def test_Structure():
    structure_1 = Structure()
    structure_2 = Structure()
    assert structure_1.seed != structure_2.seed
    # seed = structure_1.seed
    # structure_3 = Structure(seed=seed)
    # assert structure_1.seed == structure_2.seed
    assert structure_1.random.randint(1, 1000) == structure_2.random.randint(1, 1000)
    assert structure_1.random.randint(1, 1000) == structure_1.random.randint(1, 1000)
    assert structure_2.random.randint(1, 1000) == structure_2.random.randint(1, 1000)
    assert structure_1.random.randint(1, 1000) != structure_2.random.randint(1, 1000)

# Generated at 2022-06-23 21:50:43.722604
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure(seed=12345)
    s.css_property()


# Generated at 2022-06-23 21:50:46.034914
# Unit test for method html of class Structure
def test_Structure_html():
    import re
    s = Structure()
    text = s.sentence()
    html = s.html()
    assert re.search(text, html)

# Generated at 2022-06-23 21:50:56.380182
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    list_tag = list(HTML_CONTAINER_TAGS.keys())
    list_attr = []
    for key in list_tag:
        list_attr.append(list(HTML_CONTAINER_TAGS[key]))

# Generated at 2022-06-23 21:50:58.031969
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    assert isinstance(structure.html(), str)


# Generated at 2022-06-23 21:50:58.927261
# Unit test for method html of class Structure
def test_Structure_html():
	s = Structure()
	assert s.html() != ''