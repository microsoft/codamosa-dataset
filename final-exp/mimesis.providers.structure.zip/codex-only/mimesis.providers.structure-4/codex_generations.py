

# Generated at 2022-06-23 21:40:58.218758
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure('en')
    assert s._Structure__inet
    assert s._Structure__text


# Generated at 2022-06-23 21:40:59.709344
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()

    css = structure.css()

    assert css is not None


# Generated at 2022-06-23 21:41:03.115170
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Arrange
    seed = 100

    # Act
    s = Structure(seed)
    prop = s.css_property()

    # Assert
    assert prop == 'height: 11px'


# Generated at 2022-06-23 21:41:04.694102
# Unit test for method css of class Structure
def test_Structure_css():
  structure = Structure()

  assert(structure.css() != '')


# Generated at 2022-06-23 21:41:06.899899
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    ss = Structure(seed=71)
    assert ss.css_property() == "margin-right: 10px"

# Generated at 2022-06-23 21:41:18.228522
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
  from mimesis import datetime_

  # Test successful execution
  struct = Structure()
  struct.seed(12345)
  assert struct.html_attribute_value('a', 'href') == '#'
  assert struct.html_attribute_value('a', 'target') == '_blank'
  assert struct.html_attribute_value('a', 'rel') == 'nofollow'
  assert struct.html_attribute_value('img', 'alt') == 'Uploaded image'
  assert struct.html_attribute_value('img', 'src') == 'http://i.imgur.com/kzjtukv.jpg'
  assert struct.html_attribute_value('button', 'type') == 'submit'
  assert struct.html_attribute_value('button', 'name') == 'search'
  assert struct.html_attribute_

# Generated at 2022-06-23 21:41:21.648899
# Unit test for constructor of class Structure
def test_Structure():
    from mimesis.builtins import RussiaSpecProvider

    s = Structure(RussiaSpecProvider)

    assert s is not None
    assert s.seed is not None
    assert s.random is not None
    assert s.locale is not None


# Generated at 2022-06-23 21:41:30.459519
# Unit test for method css of class Structure
def test_Structure_css():
    # GIVEN
    loc = ['cs','en','ru','ja','uk','de','ar','fr','ko','it','tr','es','nl','sk']
    loc = ['en']

# Generated at 2022-06-23 21:41:31.374913
# Unit test for method html of class Structure
def test_Structure_html():
    print(Structure().html())

# Generated at 2022-06-23 21:41:32.975082
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    for _ in range(100):
        print(Structure().css_property())



# Generated at 2022-06-23 21:41:39.243191
# Unit test for method html of class Structure
def test_Structure_html():
    from nose.tools import assert_equal

    obj = Structure(seed=0)
    obj.random.seed(0)
    assert_equal(
        obj.html(),
        '<address class="transition" id="current-receivers">A little-known '
        'decentralized file system</address>'
    )

# Generated at 2022-06-23 21:41:41.801317
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure('en')
    assert isinstance(structure.css(), str)
    assert len(structure.css().split(' ')) > 5


# Generated at 2022-06-23 21:41:46.740533
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    GENERATOR = Structure()
    STRING = '<a href="http://www.fink.com">example</a>'
    assert GENERATOR.html_attribute_value('a', 'href') == 'http://www.fink.com', 'Test case failed'
    assert GENERATOR.html() == STRING, 'Test case failed'

# Generated at 2022-06-23 21:41:49.566601
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    strc = Structure(seed=12345)
    strc.css_property()


# Generated at 2022-06-23 21:41:50.818482
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    css = structure.css()
    assert css is not None


# Generated at 2022-06-23 21:41:52.543676
# Unit test for method css of class Structure
def test_Structure_css():
    st = Structure()
    assert 'background-color: #f4d3a1' == st.css_property()



# Generated at 2022-06-23 21:41:54.026222
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(seed = 1)
    print('\n', s.css(), sep = '')


# Generated at 2022-06-23 21:41:56.017282
# Unit test for method css of class Structure
def test_Structure_css():
    st = Structure()
    rs = st.css()
    print('\nStructure.css test (1):\n', rs)
    assert rs



# Generated at 2022-06-23 21:41:57.298044
# Unit test for method html of class Structure
def test_Structure_html():
    _s = Structure()
    _html = _s.html()
    assert isinstance(_html, str)

# Generated at 2022-06-23 21:42:00.306903
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    prop = Structure().css_property()
    print('Single CSS Property: {}'.format(prop))


# Generated at 2022-06-23 21:42:04.953195
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """
    Purpose:
        Unit test for method css_property of class Structure
    Args:
        None
    Returns:
        None
    Raises:
        AssertionError
    """
    structure = Structure()
    result = structure.css_property()
    assert isinstance(result, str), "result should be a string"


# Generated at 2022-06-23 21:42:10.277395
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    tag_name = s.random.choice(list(HTML_CONTAINER_TAGS))
    tag_attributes = list(HTML_CONTAINER_TAGS[tag_name])  # type: ignore
    k = s.random.randint(1, len(tag_attributes))
    
    selected_attrs = s.random.sample(tag_attributes, k=k)
    
    attrs = []
    for attr in selected_attrs:
        attrs.append('{}="{}"'.format(
            attr, s.html_attribute_value(tag_name, attr)))
    
    html_result = '<{tag} {attrs}>{content}</{tag}>'

# Generated at 2022-06-23 21:42:11.720571
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert isinstance(s, Structure)


# Generated at 2022-06-23 21:42:15.200605
# Unit test for method css of class Structure
def test_Structure_css():
    mimesis = Structure('en')
    assert re.match(r'\w+\s?\{\s?\w+:\s?\w+\s?\w+\s?\w+?\s?\w+\s?\w+\s?}', mimesis.css())

# Generated at 2022-06-23 21:42:25.067138
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis import Structure, HTML_CONTAINER_TAGS
    from random import sample
    es = Structure()
    for _ in range(100):
        t = es.random.choice(HTML_CONTAINER_TAGS.keys())
        a = sample(HTML_CONTAINER_TAGS[t], k=es.random.randint(1, len(HTML_CONTAINER_TAGS[t])))
        # print('{')
        # print(''.join([f'{x} = "{es.html_attribute_value(t, x)}",\n' for x in a]))
        # print('}')
        print(es.html())


# Generated at 2022-06-23 21:42:26.888422
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    value = structure.html_attribute_value('div')
    assert value is not None

# Generated at 2022-06-23 21:42:38.109453
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import HTMLTag
    from mimesis.enums import HTMLAttribute
    from mimesis.providers.structure import Structure
    s = Structure()
    assert s.html_attribute_value(HTMLTag.DIV, HTMLAttribute.CLASS) \
           == s.css_property().split(':')[1].strip()
    assert s.html_attribute_value(HTMLTag.DIV, HTMLAttribute.HREF) \
           == s.__inet.home_page()
    assert s.html_attribute_value(HTMLTag.DIV, HTMLAttribute.ID) \
           == s.__text.word()

# Generated at 2022-06-23 21:42:45.574334
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    import random
    import string
    
    s_obj = Structure()
    tag = 'a'
    attr = 'href'
    assert type(s_obj.html_attribute_value(tag, attr)) == str
    assert len(s_obj.html_attribute_value(tag, attr)) < 200
    assert s_obj.html_attribute_value(tag, attr)[:4] == 'http'
    assert len(s_obj.html_attribute_value('input', 'class')) == 7
    assert s_obj.html_attribute_value('input', 'class')[0] == '#'
    assert len(s_obj.html_attribute_value('input', 'type')) < 10
    
    attributes = list(HTML_CONTAINER_TAGS['a'])

# Generated at 2022-06-23 21:42:47.813237
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    a = Structure()
    assert 'color:' in a.css_property()
    assert 'background-color' in a.css_property()


# Generated at 2022-06-23 21:42:49.818400
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()
    struct.__str__()
    struct.__eq__()

# Generated at 2022-06-23 21:42:52.158863
# Unit test for method css of class Structure
def test_Structure_css():
    """Unit test for method css of class Structure"""
    s = Structure()
    x = s.css()
    print(x)
    assert type(x) == str

# Generated at 2022-06-23 21:42:56.238030
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    structure = Structure()
    tag, attr = 'a', 'href'
    value = structure.html_attribute_value(tag, attr)
    assert value.startswith('http://') or value.startswith('https://')


# Generated at 2022-06-23 21:42:58.375314
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure("en", seed=1)
    for j in range(10):
        assert s.css() == s.css()

# Generated at 2022-06-23 21:43:01.195207
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure(seed=1)
    assert s.__dict__ == Structure(seed=1).__dict__


# Generated at 2022-06-23 21:43:05.516477
# Unit test for method html of class Structure
def test_Structure_html():
    # test_example from mimesis/data/mimesis_structured_data.py
    mimesis_structured_data = Structure()

    html_result = mimesis_structured_data.html()
    assert html_result is not None



# Generated at 2022-06-23 21:43:15.082658
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
  assert Structure(seed=123).html_attribute_value(tag='audio', attribute='preload') == 'auto'
  assert Structure(seed=123).html_attribute_value(tag='div', attribute='class') == 'col-4'
  assert Structure(seed=123).html_attribute_value(tag='audio', attribute='crossorigin') == 'anonymous'
  assert Structure(seed=123).html_attribute_value(tag='form', attribute='id') == 'search'
  assert Structure(seed=123).html_attribute_value(tag='hr', attribute='color') == '#cc3300'
  assert Structure(seed=123).html_attribute_value(tag='hr', attribute='height') == '10px'
  assert Structure(seed=123).html_attribute_value(tag='details', attribute='class') == 'details'
 

# Generated at 2022-06-23 21:43:18.138146
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    print('\n---- test_Structure_css_property --------')
    x = Structure(seed=42)
    for i in range(10):
        print(x.css_property())
# test_Structure_css_property()


# Generated at 2022-06-23 21:43:27.958801
# Unit test for method css_property of class Structure
def test_Structure_css_property():
  from mimesis.enums import CSSProperty
  from mimesis.builtins import CSSProperties
  for i in range(100):
    st = Structure('en')
    css = st.css_property()
    print(css)
    key = css.split(':')[0]
    assert css.split(':')[1] != ''
    assert key in CSSProperties.__members__
    if key == CSSProperty.COLOR.name.lower():
      assert len(css.split(':')[1]) == 7
      assert css.split(':')[1][0] == '#'

# Generated at 2022-06-23 21:43:29.516742
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure('en')
    result = s.css()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:43:33.481210
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    result1 = s.css_property()
    assert isinstance(result1, str)
    assert len(result1) > 0
    assert result1 == 'background-color: #f4d3a1' or result1 == 'background-color: #f4d3a1' or result1 == 'background-color: #f4d3a1'


# Generated at 2022-06-23 21:43:39.351561
# Unit test for method html of class Structure
def test_Structure_html():
    resultado_esperado = '<span class="select" id="careers">Ports are created with the built-in function open_port.</span>'
    # Call to function
    s = Structure()
    resultado_real = s.html()
    assert resultado_real == resultado_esperado


# Generated at 2022-06-23 21:43:43.394356
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from random import Random
    seed = Random().randint(1, 2**32)
    s = Structure(seed = seed)
    assert isinstance(s.css_property(), str)


# Generated at 2022-06-23 21:43:48.471890
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    st = Structure()
    
    result = st.html_attribute_value('a', 'href')
    assert isinstance(result, str)
    assert len(result)
    assert (result.strip()[:2] == 'ft') or (result.strip()[:5] == 'http')

# Generated at 2022-06-23 21:43:55.872303
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    html_result = s.html()
    
    tag_name = s.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    html_result = '<{tag} {attrs}>{content}</{tag}>'
    html_result.format(
            tag=tag_name,
            attrs=' '.join(attrs),
            content=s.__text.sentence(),
        )
    print(html_result)


# Generated at 2022-06-23 21:44:00.210414
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    """ 
    Check whether the method html_attribute_value of class Structure is working correctly
    """

    structured_data = Structure()
    structured_data.html_attribute_value()


# Generated at 2022-06-23 21:44:06.938309
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure"""
    structure = Structure()
    html_container_tags = list(HTML_CONTAINER_TAGS.keys())
    for tag in html_container_tags:
        tags = HTML_CONTAINER_TAGS[tag]
        for attribute in tags:
            log = "structure.html_attribute_value('{0}', '{1}')"
            result = eval(log.format(tag, attribute))
            assert len(result) > 0


# Generated at 2022-06-23 21:44:09.476115
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct = Structure()
    struct.random.seed(1234)
    assert struct.html_attribute_value() in ["#components", "#homes"]

# Generated at 2022-06-23 21:44:10.301108
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    assert s.css()

# Generated at 2022-06-23 21:44:15.908699
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import Attribute
    from mimesis.exceptions import NotImplementedError

    faker = Structure('en')

    for container in HTML_CONTAINER_TAGS:
        for attribute in HTML_CONTAINER_TAGS[container]:
            if attribute == Attribute.CLASS:
                continue
            try:
                faker.html(container, attribute)
            except NotImplementedError:
                continue

# Generated at 2022-06-23 21:44:18.873323
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structured = Structure()
    for tag in HTML_CONTAINER_TAGS:
        for attr in HTML_CONTAINER_TAGS[tag]:
            structured.html_attribute_value(tag, attr)

# Generated at 2022-06-23 21:44:20.220349
# Unit test for method html of class Structure
def test_Structure_html():
    str = Structure(seed=12345)
    print(str.html())
    print(str.html_attribute_value())

# Generated at 2022-06-23 21:44:21.349295
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    #print(structure.html())



# Generated at 2022-06-23 21:44:23.928864
# Unit test for constructor of class Structure
def test_Structure():
    test_Structure = Structure()
    assert isinstance(test_Structure, Structure)


# Generated at 2022-06-23 21:44:35.250997
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import HTMLAttribute, HTMLTag
    s = Structure()
    value1 = s.html_attribute_value(tag=HTMLTag.HTML, attribute=HTMLAttribute.LANG)
    assert value1
    assert isinstance(value1,str)
    value2 = s.html_attribute_value(tag=HTMLTag.META, attribute=HTMLAttribute.CHARSET)
    assert value2
    assert isinstance(value2, str)

    value3 = s.html_attribute_value(tag=HTMLTag.META, attribute=HTMLAttribute.CONTENT)
    assert value3
    assert isinstance(value3, str)
    value4 = s.html_attribute_value(tag=HTMLTag.META, attribute="crap")
    assert value4 == None
    value5 = s.html_attribute_

# Generated at 2022-06-23 21:44:40.629148
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    for tag in HTML_CONTAINER_TAGS.keys():
        for attr in HTML_CONTAINER_TAGS[tag]:
            if isinstance(HTML_CONTAINER_TAGS[tag][attr], list):
                print(structure.html_attribute_value(tag, attr))
            else:
                print(structure.html_attribute_value(tag, attr))

# Generated at 2022-06-23 21:44:42.613520
# Unit test for constructor of class Structure
def test_Structure():
    # Test with 0 args, 1 arg and 2 args
    Structure()
    Structure('ru')
    Structure('ru', seed=10)


# Generated at 2022-06-23 21:44:44.741744
# Unit test for method html of class Structure
def test_Structure_html():
    test_obj = Structure(seed=0)
    assert all([isinstance(test_obj.html(), str), test_obj.html() != ''])


# Generated at 2022-06-23 21:44:52.477634
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure(seed=1)
    r1 = s.html_attribute_value(tag='img', attribute='src')
    r2 = s.html_attribute_value(tag='input', attribute='required')
    r3 = s.html_attribute_value(tag='div', attribute='class')
    r4 = s.html_attribute_value(tag='img', attribute='alt')
    r5 = s.html_attribute_value(tag='div', attribute='visibility')
    r6 = s.html_attribute_value()
    assert r1 == 'http://www.martinez.org/'
    assert r2 == 'required'
    assert r3 == 'color: #f0d0a2; background-color: #b8647f; letter-spacing: 1cm'
    assert r4 == 'content'


# Generated at 2022-06-23 21:44:57.425920
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Test with a valid tag
    result = Structure(seed=1).html_attribute_value(tag='input', attribute='type')
    assert result == 'hidden'

    # Test with an invalid tag
    with pytest.raises(NotImplementedError):
        result = Structure(seed=1).html_attribute_value(tag='invalid_tag', attribute='type')

    # Test with a valid tag but an invalid attribute
    with pytest.raises(NotImplementedError):
        result = Structure(seed=1).html_attribute_value(tag='input', attribute='invalid_attribute')

# Generated at 2022-06-23 21:45:00.374841
# Unit test for constructor of class Structure
def test_Structure():
    try:
        Structure._provider__get_local_provider('en')
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-23 21:45:02.402349
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    css_property = structure.css_property()
    assert isinstance(css_property,str)

# Generated at 2022-06-23 21:45:04.421953
# Unit test for method html of class Structure
def test_Structure_html():
    """
    Class Structure method html returns a string
    """
    s = Structure(seed=123)
    assert type(s.html()) == str

# Generated at 2022-06-23 21:45:08.343262
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    print("structure.html() =", structure.html())
    assert structure.html() == "<span class=\"select\" id=\"careers\">Ports are created with the built-in function open_port.</span>"


# Unit tests for method html_attribute_value of class Structure

# Generated at 2022-06-23 21:45:10.184957
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert isinstance(structure, Structure)



# Generated at 2022-06-23 21:45:11.083051
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure is not None

# Generated at 2022-06-23 21:45:15.971076
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    css_property = s.css_property()
    assert type(css_property) == str
    assert len(css_property) > 0
    assert css_property.count(':') == 1
    assert css_property.count(';') <= 1


# Generated at 2022-06-23 21:45:18.518474
# Unit test for method css_property of class Structure
def test_Structure_css_property():

    # Arrange
    structure = Structure(seed=1)

    # Assert
    assert structure.css_property() == 'font-style: italic'

# Generated at 2022-06-23 21:45:19.918613
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert isinstance(s, Structure) is True


# Generated at 2022-06-23 21:45:21.969672
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    css_property = structure.css_property()
    assert len(css_property) > 0

# Generated at 2022-06-23 21:45:27.501939
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(seed=777)
    res = s.css()
    assert isinstance(res, str)
    assert res.startswith(('body', '#', '.'))
    assert res.endswith('}')
    assert res.count('{') == 1
    assert ':' in res
    assert res.count('\n') in [0, 1]


# Generated at 2022-06-23 21:45:29.988628
# Unit test for constructor of class Structure
def test_Structure():
    """Test constructor of class Structure."""
    seed=0
    structure = Structure(seed=seed)
    assert isinstance(structure, Structure)


# Generated at 2022-06-23 21:45:31.576158
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    for _ in range(10):
        print(structure.html())


# Generated at 2022-06-23 21:45:32.880743
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    Structure.html_attribute_value("a", "href")

# Generated at 2022-06-23 21:45:44.861121
# Unit test for method html of class Structure
def test_Structure_html():
    # Проверяем что при незаданных параметрах, возвращается строка
    myStructure = Structure(seed=42)
    k = myStructure.html()
    assert isinstance(k, str)

    # Проверяем что при незаданном теге, возвращается строка
    myStructure = Structure(seed=42)
    k = myStructure.html(tag = None)
    assert isinstance(k, str)



# Generated at 2022-06-23 21:45:50.600768
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure(seed=10)
    print("structure.seed[1] = {}".format(structure.seed))
    print("structure.random.getstate()[1] = {}".format(structure.random.getstate()))


if __name__ == "__main__":
    test_Structure()

# Generated at 2022-06-23 21:45:52.553741
# Unit test for method css of class Structure
def test_Structure_css():
    x = Structure()
    assert isinstance(x.css(), str)


# Generated at 2022-06-23 21:45:54.799626
# Unit test for method html of class Structure
def test_Structure_html():
	obj = Structure(seed=1)
	result = obj.html()
	assert result == '<spam checked="in_array" readonly="word" style="color: #f4d3a1" value="word">\
	dolor amet, in, sed.</spam>'



# Generated at 2022-06-23 21:45:57.663141
# Unit test for method css of class Structure
def test_Structure_css():
	structure = Structure()
	assert structure.css()
	assert structure.css_property()
	assert structure.html()
	assert structure.html_attribute_value()

if __name__ == '__main__':
	test_Structure_css()

# Generated at 2022-06-23 21:46:00.383756
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s.provider == 'structure'
    assert s.seed is not None
    assert isinstance(s.random, random.Random)


# Generated at 2022-06-23 21:46:05.258140
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    for tag in HTML_CONTAINER_TAGS.keys():
        for attribute in HTML_CONTAINER_TAGS[tag]:
            data = getattr(Structure('en', 0), 'html_attribute_value')(tag, attribute)
            print('tag: {}, attribute: {}, value: {}'.format(tag, attribute, data))


# Generated at 2022-06-23 21:46:07.305059
# Unit test for method html of class Structure
def test_Structure_html():
    st = Structure()
    assert type(st.html()) is str
    assert len(st.html()) > 0


# Generated at 2022-06-23 21:46:09.724786
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure(seed=4)
    data = structure.css_property()
    assert data == 'background: url(https://example.com/)'

# Generated at 2022-06-23 21:46:13.498044
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(seed=0)
    assert s.css() == 'body {border: 1px dashed #2c8181; border-width: 1.4em; display: flex; height: 37mm; width: 77mm; }'


# Generated at 2022-06-23 21:46:14.557241
# Unit test for constructor of class Structure
def test_Structure():
    st = Structure()
    assert(st is not None)

# Generated at 2022-06-23 21:46:18.151384
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure(seed=12345)
    assert structure.css() == 'figure {width: 15cm}'


# Generated at 2022-06-23 21:46:19.784403
# Unit test for method css of class Structure
def test_Structure_css():
	seeder = random.Random(2000)
	random.seed(2000)
	for i in range(0, len(CSS_PROPERTIES)):
		css_result = Structure(seeder).css()
		assert css_result in CSS_PROPERTIES


# Generated at 2022-06-23 21:46:24.342023
# Unit test for constructor of class Structure
def test_Structure():
    st = Structure()
    assert isinstance(st, Structure)
    assert isinstance(st.__inet, Internet)
    assert isinstance(st.__text, Text)
    assert st.locale == 'en'
    assert st.seed == st.__inet.seed == st.__text.seed


# Generated at 2022-06-23 21:46:28.505444
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s.c0de_structure() in dict
    assert s.html_attribute_value() in str
    assert s.css_property() in str
    assert s.css() in str
    assert s.html() in str
    pass

# Generated at 2022-06-23 21:46:29.950494
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure(seed=243)
    assert structure is not None

# Generated at 2022-06-23 21:46:39.240739
# Unit test for method html_attribute_value of class Structure

# Generated at 2022-06-23 21:46:46.169573
# Unit test for constructor of class Structure
def test_Structure():
    a = Structure()
    b = Structure()

    assert a != None
    assert b != None

    assert a.seed == b.seed

    assert a.__text != None
    assert b.__text != None

    assert a.__inet != None
    assert b.__inet != None

    assert a._meta != None
    assert b._meta != None

    assert a._random != None
    assert b._random != None


# Generated at 2022-06-23 21:46:52.892464
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    import random
    import mimesis
    random.seed(0)
    structure = mimesis.Structure()
    size_unit = structure.css_property().split(':')[1].strip()
    assert size_unit in mimesis.CSS_SIZE_UNITS, 'Error in method css_property'
    random.seed(1)
    tag = structure.css_property().split(' ')[0].strip()
    assert tag in mimesis.HTML_MARKUP_TAGS, 'Error in method css_property'


# Generated at 2022-06-23 21:46:57.317598
# Unit test for method html of class Structure
def test_Structure_html():
    """Test method html of class Structure"""
    s = Structure()
    r = s.html()
    assert r.startswith("<")
    assert r.endswith(">")


# Generated at 2022-06-23 21:47:00.188702
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure('en')

    assert structure.html() == '<a href="http://www.millicent.org/">Burgundy</a>'

# Generated at 2022-06-23 21:47:01.621306
# Unit test for method css of class Structure
def test_Structure_css():
    struct = Structure()
    struct.css()



# Generated at 2022-06-23 21:47:03.553450
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    provider = Structure()
    value = provider.css_property()
    assert type(value)==str

# Generated at 2022-06-23 21:47:05.461266
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert isinstance(structure.html_attribute_value(), str)


# Generated at 2022-06-23 21:47:07.902279
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure('en', seed=123)
    assert structure.get_config()['locale'] == 'en'
    assert structure.get_config()['seed'] == 123

# Generated at 2022-06-23 21:47:09.820879
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert Structure().css_property() == 'background-color: #f4d3a1'

# Generated at 2022-06-23 21:47:10.726799
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    s.css() == ''

# Generated at 2022-06-23 21:47:11.639451
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    print(s.html())

# Generated at 2022-06-23 21:47:14.010095
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    for _ in range(100):
        prop = Structure().css_property()
        assert isinstance(prop, str)
        assert len(prop.split(':')) == 2


# Generated at 2022-06-23 21:47:17.291980
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert isinstance(s.random.choice(s.html_attribute_value()), str)
    assert isinstance(s.random.choice(s.html_attribute_value('p', 'id')),
                      str)
    assert isinstance(s.html_attribute_value('p', 'id'), str)

# Generated at 2022-06-23 21:47:18.996369
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert isinstance(s, Structure)

# Unit tests for html() of class Structure

# Generated at 2022-06-23 21:47:22.989725
# Unit test for constructor of class Structure
def test_Structure():

    s = Structure()
    print(s.css())
    print(s.html())



# Generated at 2022-06-23 21:47:29.799473
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    t = Structure()
    assert (t.html_attribute_value('a', 'href') is not None)
    assert (t.html_attribute_value('button', 'formaction') is not None)
    assert (t.html_attribute_value('select', 'form') is not None)

    # Test for unsupported tag
    tag = 'nonesense'
    assert (t.html_attribute_value(tag, 'href') == None)

    # Test for unsupported attribute
    attribute = 'nonesense'
    assert (t.html_attribute_value('a', attribute) == None)

# Generated at 2022-06-23 21:47:31.597736
# Unit test for method html of class Structure
def test_Structure_html():
    st = Structure()
    print(st.html())


# Generated at 2022-06-23 21:47:35.153964
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    css_property = Structure().css_property()
    assert isinstance(css_property, str)
    assert ':' in css_property
    assert css_property.startswith('-') is False


# Generated at 2022-06-23 21:47:39.933886
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_instance = Structure()
    structure_instance.random.seed(0)
    assert structure_instance.html_attribute_value('a', 'href') == 'url'
    assert structure_instance.html_attribute_value('meta', 'charset') == 'utf-8'
    assert structure_instance.html_attribute_value('div', 'class') == 'css'

# Generated at 2022-06-23 21:47:41.398868
# Unit test for method html of class Structure
def test_Structure_html():
    struct = Structure()
    result = struct.html()
    assert type(result) == str and len(result) > 0


# Generated at 2022-06-23 21:47:43.093563
# Unit test for method css of class Structure
def test_Structure_css():
    """Test for method css of class Structure."""
    s = Structure('en')
    s.css()

# Generated at 2022-06-23 21:47:45.441237
# Unit test for method css_property of class Structure
def test_Structure_css_property():
  st = Structure()
  s = st.css_property()
  assert (s.split(':')[1].strip()).lower() == st.css_property().split(':')[1].strip().lower()

# Generated at 2022-06-23 21:47:47.132643
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.providers.structure import Structure
    _structure = Structure()
    _structure.css_property()


# Generated at 2022-06-23 21:47:47.961541
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()



# Generated at 2022-06-23 21:47:50.178342
# Unit test for constructor of class Structure
def test_Structure():
    a = Structure()
    assert a.seed == a._random.seed

# Generated at 2022-06-23 21:47:52.739790
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure(locale="en")
    result = struct.html()
    assert result is not None, "Result is empty"

# Generated at 2022-06-23 21:47:54.760600
# Unit test for method html of class Structure
def test_Structure_html():
    """Function for testing html method of class Structure"""
    structure = Structure()
    print(structure.html())

# Generated at 2022-06-23 21:47:57.650799
# Unit test for method html of class Structure
def test_Structure_html():
    expectedOutput = '<div class="select">Ports are created with the built-in function open_port.</div>'
    assert Structure().html() == expectedOutput



# Generated at 2022-06-23 21:48:03.499817
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import TagAttribute

    s = Structure(seed=123456)

    tag = 'div'
    attr = TagAttribute.ID

    assert s.html_attribute_value(tag, attr) == 'followers'

    tag = 'img'
    attr = TagAttribute.SRC

    assert s.html_attribute_value(tag, attr) == 'http://www.example.com'

    tag = 'a'
    attr = TagAttribute.HREF

    assert s.html_attribute_value(tag, attr) == 'https://www.example.com/'

# Generated at 2022-06-23 21:48:05.847976
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('ru')
    assert len(structure.css_property())


# Generated at 2022-06-23 21:48:16.962890
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    cl = Structure()

    attr_values = [
        'autocapitalize',
        'autocorrect',
        'autofocus',
        'autosave',
        'checked',
        'css',
        'disabled',
        'formnovalidate',
        'hidden',
        'incremental',
        'inputmode',
        'ismap',
        'itemscope',
        'itemtype',
        'itemid',
        'itemref',
        'multiple',
        'novalidate',
        'pubdate',
        'readonly',
        'required',
        'url',
        'word',
        'wrap',
    ]


# Generated at 2022-06-23 21:48:18.262050
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    data_provider = Structure()
    css_property = data_provider.css_property()
    assert css_property != ''



# Generated at 2022-06-23 21:48:19.673771
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    ans = s.html()
    print(ans)


# Generated at 2022-06-23 21:48:21.169180
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure('es')
    assert isinstance(structure, Structure), 'structure no es instancia de Structure'
    css = structure.css()
    assert isinstance(css, str), 'css no es instancia de str'


# Generated at 2022-06-23 21:48:27.802989
# Unit test for method css of class Structure
def test_Structure_css():
    struct = Structure()
    # run some tests
    assert struct.css() == 'b{width: 30em; padding: auto; bottom: 57px; ' \
                           'background-color: #b6c4dc; z-index: 87; ' \
                           'font-variant: normal; outline-style: solid; ' \
                           'overflow-y: hidden}'
    assert struct.css() == '#dd9{display: toolbar; height: 28px; ' \
                           'background-color: #2a2494; width: 87em; ' \
                           'outline-color: #f1a2e1; border-collapse: collapse}'

# Generated at 2022-06-23 21:48:29.581002
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    for i in range(100):
        print(Structure().css_property())

# Generated at 2022-06-23 21:48:30.550659
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    struct = Structure()
    assert struct.css_property()


# Generated at 2022-06-23 21:48:32.873712
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure("en")
    result = structure.html()
    print("result of method html of class Structure: ", result)


# Generated at 2022-06-23 21:48:34.416293
# Unit test for method css of class Structure
def test_Structure_css():
    for i in range(10):
        structure = Structure()
        value = structure.css()
        assert value



# Generated at 2022-06-23 21:48:36.800413
# Unit test for constructor of class Structure
def test_Structure():
    # type: () -> None

    structure = Structure('en')
    assert structure is not None


# Generated at 2022-06-23 21:48:43.171623
# Unit test for method css_property of class Structure
def test_Structure_css_property():
     structure = Structure(seed=None)
     properties = set()
     css_properties = set(CSS_PROPERTIES)
     for i in range(1000):
         prop = structure.css_property()
         properties.add(prop)
     assert len(properties) == len(CSS_PROPERTIES)
     for prop in properties:
         assert prop in css_properties


# Generated at 2022-06-23 21:48:47.836498
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    text = Text('en')
    word = text.word()
    word = word.replace("'", "\\'")
    assert CSS_PROPERTIES['content'] != word
    structure = Structure('en')
    css_property = structure.css_property()
    assert css_property == f"content: '{word}'"


# Generated at 2022-06-23 21:48:50.606593
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis import Structure
    from pprint import pprint
    m = Structure()
    x = m.css()
    pprint(x)
    #print x



# Generated at 2022-06-23 21:48:53.373165
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure(seed=123)

    structure.random.seed(123)
    assert structure.css_property() == 'padding: 22px'

    structure.random.seed(666)
    assert structure.css_property() == 'margin: 13px'

# Generated at 2022-06-23 21:48:55.377356
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # test that the generated string is not empty
    assert len(Structure(seed=0).css_property()) > 0

# Generated at 2022-06-23 21:48:57.916246
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    print(structure.css())

#Unit test for method css_property of class Structure

# Generated at 2022-06-23 21:48:59.965571
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    a = Structure.css_property(Structure)
    print(a)



# Generated at 2022-06-23 21:49:10.000763
# Unit test for method html of class Structure
def test_Structure_html():
    str = Structure()
    tag = str.random.choice(list(HTML_CONTAINER_TAGS))
    tag_attrs = list(HTML_CONTAINER_TAGS[tag])  # type: ignore
    k = str.random.randint(1, len(tag_attrs))

    selected_attrs = str.random.sample(tag_attrs, k=k)

    attrs = []
    for attr in selected_attrs:
        attrs.append('{}="{}"'.format(
            attr, str.html_attribute_value(tag, attr)))

    html_result = '<{tag} {attrs}>{content}</{tag}>'

# Generated at 2022-06-23 21:49:11.238400
# Unit test for method html of class Structure
def test_Structure_html():
    assert True


# Generated at 2022-06-23 21:49:13.864631
# Unit test for constructor of class Structure
def test_Structure():
    sample = Structure()
    assert sample.provider == 'structure'
    assert sample.seed
    assert sample.localization
    assert sample.datetime_format

# Generated at 2022-06-23 21:49:20.758143
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    # Assert that object is an instance of Structure
    assert isinstance(structure, Structure)
    # Assert that object is an instance of BaseDataProvider
    assert isinstance(structure, BaseDataProvider)
    # Assert that object is an instance of BaseProvider
    assert isinstance(structure, BaseDataProvider)
    # Assert that object has an attribute locale
    assert hasattr(structure, 'locale')
    # Assert that object has an attribute seed
    assert hasattr(structure, 'seed')
    # Assert that object has an attribute _random
    assert hasattr(structure, '_random')
    # Assert that object has an attribute __text
    assert hasattr(structure, '__text')
    # Assert that object has an attribute __inet

# Generated at 2022-06-23 21:49:23.217816
# Unit test for method html of class Structure
def test_Structure_html():     
    structure = Structure()
    result = structure.html()
    assert type(result) == str, 'Error in html method of class Structure'
    assert len(result) > 0, 'Error in html method of class Structure'
    assert '<' in result, 'Error in html method of class Structure'


# Generated at 2022-06-23 21:49:25.527985
# Unit test for method html of class Structure
def test_Structure_html():
    print('\n' "Test for method html() of class Structure:")
    structure = Structure()
    print(structure.html())


# Generated at 2022-06-23 21:49:26.877705
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert isinstance(structure, Structure)

# Generated at 2022-06-23 21:49:30.083895
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s.random.__class__.__name__ == 'Generator'
    assert s.random.choice.__class__.__name__ == 'bound method Generator'
    assert s.random.shuffle.__class__.__name__ == 'bound method Generator'
    assert s.random.uniform.__class__.__name__ == 'bound method Generator'


# Generated at 2022-06-23 21:49:33.551730
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    assert(s.css() not in (None, '', ' '))


# Generated at 2022-06-23 21:49:37.717805
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    result = s.html()
    assert isinstance(result, str)
    assert '>' in result
    assert '<' in result


# Generated at 2022-06-23 21:49:38.857318
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    print(structure.css())


# Generated at 2022-06-23 21:49:42.191094
# Unit test for constructor of class Structure
def test_Structure():
    # GIVEN
    s=Structure()
    # THEN
    assert isinstance(s, Structure)
    assert isinstance(s, BaseDataProvider)


# Generated at 2022-06-23 21:49:48.210832
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure() # Создание объекта
    assert struct # Если истинно, то создан объект
    return struct # Возвращение объекта


# Generated at 2022-06-23 21:49:51.006470
# Unit test for method html of class Structure
def test_Structure_html():
    html_tag_str = Structure().html()
    print(html_tag_str)
    print(type(html_tag_str))
    

# Generated at 2022-06-23 21:50:01.867768
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct = Structure()
    struct.seed(0)
    struct.html_attribute_value('a', 'id')
    struct.html_attribute_value('a', 'class')
    struct.html_attribute_value('a', 'rel')
    struct.html_attribute_value('a', 'href')
    struct.html_attribute_value('a', 'title')
    struct.html_attribute_value('form', 'id')
    struct.html_attribute_value('form', 'class')
    struct.html_attribute_value('form', 'method')
    struct.html_attribute_value('form', 'action')
    struct.html_attribute_value('form', 'enctype')
    struct.html_attribute_value('link', 'id')
    struct.html_attribute_value('link', 'class')

# Generated at 2022-06-23 21:50:07.443515
# Unit test for method html of class Structure
def test_Structure_html():
    obj = Structure(seed=42)

    assert obj.html() == '<a href="https://www.RVLMckvwby.fm" rel="nofollow" title="XQGvqmZBzm" target="_blank">Lorem ipsum dolor sit amet</a>'



# Generated at 2022-06-23 21:50:13.123262
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    temp = Structure()
    temp.seed(0)
    assert temp.css_property() == "display: block"
    temp.seed(1)
    assert temp.css_property() == "padding-right: 5px"
    temp.seed(2)
    assert temp.css_property() == "float: none"
    temp.seed(3)
    assert temp.css_property() == "position: absolute"
    temp.seed(4)
    assert temp.css_property() == "background-color: #cbbae1"
    temp.seed(5)
    assert temp.css_property() == "text-align: center"

# Generated at 2022-06-23 21:50:19.803589
# Unit test for method css of class Structure
def test_Structure_css():
    my_structure = Structure()
    result_structure_css = my_structure.css()
    assert result_structure_css is not None
    assert result_structure_css is not None
    assert type(result_structure_css) is str
    assert type(result_structure_css) is not int


# Generated at 2022-06-23 21:50:25.230221
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    l = []
    for tag in list(HTML_CONTAINER_TAGS.keys()):
        print(tag, HTML_CONTAINER_TAGS[tag].keys())
        for attribute in list(HTML_CONTAINER_TAGS[tag].keys()):
            l.append(structure.html_attribute_value(tag, attribute))
    return l



# Generated at 2022-06-23 21:50:29.133881
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    struct_html_attribute_value = structure.html_attribute_value
    try:
        struct_html_attribute_value('a', 'href')
    except NotImplementedError as e:
        assert e is not None

# Generated at 2022-06-23 21:50:33.565759
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    obj = Structure(seed=12345678)
    tag = 'div'
    attribute = 'id'
    expected = 'Structure.html_attribute_value'
    actual = obj.html_attribute_value(tag, attribute)
    assert actual == expected


# Generated at 2022-06-23 21:50:34.682334
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    Structure().html_attribute_value('a', 'rel')

# Generated at 2022-06-23 21:50:43.393382
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    seed = "6c5bf6db849d"
    structure = Structure(seed=seed)
    tag = "i"
    attribute = "id"
    # Tag <i>, attribute id.
    assert structure.html_attribute_value(tag, attribute) == "SCHJS"
    tag = "a"
    attribute = "id"
    # Tag <a>, attribute id.
    assert structure.html_attribute_value(tag, attribute) == "RZXEV"
    structure = Structure(seed=seed)
    tag = "h2"
    attribute = "id"
    # Tag <h2>, attribute id, not in list of tags.

# Generated at 2022-06-23 21:50:48.367875
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()

    for i in range(10):
        print(struct.css())
        print(struct.html())
        print(struct.html_attribute_value())
        print(struct.html_attribute_value('a', 'href'))
        print(struct.html_attribute_value(tag='a', attribute='href'))


test_Structure()

# Generated at 2022-06-23 21:50:49.475147
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Test Structure css_property."""
    s = Structure()
    result = s.css_property()
    assert isinstance(result, str)



# Generated at 2022-06-23 21:50:59.507736
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Test for value list
    s = Structure('en', seed=42)
    assert s.html_attribute_value('br', 'clear') == 'left'

    # Test for value word
    s = Structure('en', seed=42)
    assert s.html_attribute_value('br', 'class') == 'pula'

    # Test for value url
    s = Structure('en', seed=42)
    assert s.html_attribute_value('link', 'href') == 'http://www.kogal.org/'

    # Test for value css
    s = Structure('en', seed=42)
    assert s.html_attribute_value('link', 'style') == \
        'text-transform: uppercase'

    # Test for tag not supporred
    s = Structure('en', seed=42)
   