

# Generated at 2022-06-23 21:41:01.337834
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure('en')
    assert structure is not None


# Generated at 2022-06-23 21:41:03.070202
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('en')
    result = structure.css_property()
    print(result)

# Generated at 2022-06-23 21:41:15.027736
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSPropertyValue
    from mimesis.providers.numbers import Numbers
    from mimesis import Mimesis
    
    provider = Structure('en')
    numbers = Numbers('en')
    seed = numbers.random(min=0, max=99999999)
    mimesis = Mimesis(seed=seed)
    
    obj = mimesis.structure()
    try:
        provider.reset_seed()
    except NameError:
        pass
    print('')
    print('+++++')
    print('Unit test for method css_property of class Structure')
    print('')
    print('Sample generated data from method css_property of class Structure:')
    print('     Method - css_property - result:', provider.css_property())

# Generated at 2022-06-23 21:41:19.775176
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    seed = 123456789
    provider = Structure(seed=seed)
    target = '<article class="good" id="pavement">' + provider.__text.sentence() + '</article>'
    assert provider.html() == target
    

# Generated at 2022-06-23 21:41:21.225959
# Unit test for constructor of class Structure
def test_Structure():
    assert Structure().__class__.__name__ == 'Structure'

# Generated at 2022-06-23 21:41:24.438819
# Unit test for constructor of class Structure
def test_Structure():
    seed = 12345
    st = Structure(seed=seed)
    assert st.seed == seed
    assert st._random.seed == seed
    assert st._Meta.name == 'structure'


# Generated at 2022-06-23 21:41:27.038777
# Unit test for method css of class Structure
def test_Structure_css():
    x = Structure()
    a = 'body{height:8cm; font-weight:bold; font-size:30px}'
    assert x.css() == a


# Generated at 2022-06-23 21:41:30.902128
# Unit test for constructor of class Structure
def test_Structure():
    from mimesis.enums import Category
    structure = Structure(seed=100)
    assert structure._category == Category.WEB_STRUCTURE
    assert structure._seed == 100
    assert isinstance(structure.random, type(structure.random))


# Generated at 2022-06-23 21:41:32.493445
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'

# Generated at 2022-06-23 21:41:37.477043
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    import json
    from pprint import pprint

    seed = 123
    s = Structure(seed=seed)

    with open('tags.json') as json_file:
        data = json.load(json_file)
    for tag in data:
        for attribute in data[tag]:
            attr_type = data[tag][attribute]
            value = s.html_attribute_value(tag, attribute)
            assert isinstance(value, str)
            print(tag, attribute, attr_type, value)

# Generated at 2022-06-23 21:41:42.143819
# Unit test for method css of class Structure
def test_Structure_css():
    struc = Structure()

    import re

    func_test = struc.css()
    regex = re.compile(
        r'^.{1,8}\s?{.+}$',
        re.VERBOSE)

    assert bool(regex.search(func_test))



# Generated at 2022-06-23 21:41:51.324884
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import Attribute
    from mimesis.enums import Tag
    myStructure = Structure('en')

    for enum in Tag:
        for attribute in Attribute:
            print(attribute)
            if attribute == Attribute.CSS:
                print(myStructure.css_property())
                assert True
            elif attribute == Attribute.HREF:
                print(myStructure.__inet.home_page())
                assert True
            elif attribute == Attribute.TYPE:
                print(myStructure.random.choice(
                    list(HTML_CONTAINER_TAGS[enum.value][attribute.value])))
                assert True
            elif attribute == Attribute.NAME:
                print(myStructure.__text.word())
                assert True

# Generated at 2022-06-23 21:41:55.588608
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import MimeTypes
    from mimesis.utils import generate_hash
    from mimesis import Mimesis
    docs = {}
    for _ in range(10):
        m = Mimesis(locale='en', seed=generate_hash())
        structure = m.structure()
        docs[structure.mime(MimeTypes.HTML)] = structure.html()
    print(docs)


# Generated at 2022-06-23 21:42:02.255873
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    st1 = Structure()
    st2 = Structure(seed=1)
    st3 = Structure(seed=2)
    # Check for tag 'a' and attribute 'href'
    assert st1.html_attribute_value(tag='a', attribute='href') == st2.html_attribute_value(tag='a', attribute='href')
    assert st2.html_attribute_value(tag='a', attribute='href') == st3.html_attribute_value(tag='a', attribute='href')
    assert st3.html_attribute_value(tag='a', attribute='href') != st1.html_attribute_value(tag='a', attribute='href')
    # Check for tag 'a' and attribute 'rel'
    assert st1.html_attribute_value(tag='a', attribute='rel') == st2.html_attribute_value

# Generated at 2022-06-23 21:42:04.953721
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure(seed=1)
    for _ in range(50):
        print(s.css_property())
        print("---------------")


# Generated at 2022-06-23 21:42:10.697579
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Test: на выходе CSS, длина >= 6, первые 6 знаков - свойство
    structure = Structure()
    property = structure.css_property()
    assert len(property) >= 6
    assert property[0:6] in CSS_PROPERTIES.keys()


# Generated at 2022-06-23 21:42:14.605087
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    '''
    Test if the method css_property of class Structure is working correctly
    '''
    print("----------------")
    print("Testing of Structure.css_property()...")
    str1 = Structure()
    print(str1.css_property())
test_Structure_css_property()

# Generated at 2022-06-23 21:42:25.745669
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import AttributeType
    from mimesis.providers.structure import Structure

    example_provider = Structure()
    for _ in range(100):
        tag_name = example_provider.random.choice(
            example_provider.list_tags())
        attr_name = example_provider.random.choice(
            example_provider.list_tag_attributes(tag_name))
        attr_type = example_provider.get_attribute_type(tag_name, attr_name)
        attr_value = example_provider.html_attribute_value(tag_name, attr_name)

        assert isinstance(attr_name, str) and attr_name, (
            'Attribute name should be nonempty string')

# Generated at 2022-06-23 21:42:37.053567
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis.enums import CSSPropertyValue
    from mimesis.enums import CSSProperty
    from mimesis.enums import CSSSelector
    from mimesis.enums import CSSSizeUnit
    from mimesis.enums import HTMLAttribute
    from mimesis.enums import HTMLTag
    
    prop1 = CSSProperty.BACKGROUND_COLOR.value
    prop2 = CSSProperty.FONT_WEIGHT.value
    prop3 = CSSProperty.TEXT_ALIGN.value
    prop4 = CSSProperty.BACKGROUND_POSITION_Y.value
    prop5 = CSSProperty.COLOR.value
    prop6 = CSSProperty.Z_INDEX.value
    prop7 = CSSProperty.BORDER_COLOR.value
    prop8 = CSSProperty.PADDING_BOTTOM.value
    prop9 = CSS

# Generated at 2022-06-23 21:42:45.028062
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == structure.__inet.home_page()
    assert structure.html_attribute_value('a', 'title') == structure.__text.word()
    assert structure.html_attribute_value('a', 'type') == 'word'
    assert structure.html_attribute_value('a', 'class') == structure.__text.word()
    assert structure.html_attribute_value('a', 'id') == structure.__text.word()
    assert structure.html_attribute_value('button', 'class') == structure.__text.word()
    assert structure.html_attribute_value('button', 'id') == structure.__text.word()
    assert structure.html_attribute_value('button', 'type') == 'word'
    assert structure.html_attribute

# Generated at 2022-06-23 21:42:46.898184
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    html = s.html()
    assert html is not None


# Generated at 2022-06-23 21:42:48.762838
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    css_foo = s.css_property()
    assert type(css_foo) == str

# Generated at 2022-06-23 21:42:53.504075
# Unit test for method css of class Structure
def test_Structure_css():
    struct = Structure(seed=42)
    assert struct.css() == 'div.group'+''' {
font-size: 1em;
background: repeat(n, bottom);
visibility: hidden;
padding: 5px;
font-weight: normal;
color: #f5f5f5;
border-radius: 7px
}'''


# Generated at 2022-06-23 21:43:00.633303
# Unit test for method css of class Structure
def test_Structure_css():
    cls = Structure()
    print(cls.css())
    print(cls.css_property())
    print(cls.html())
    print(cls.html_attribute_value())
    print(cls.html_attribute_value('a', 'href'))
    # print(cls.html_attribute_value('a', 'data-prop'))


if __name__ == '__main__':
    test_Structure_css()

# Generated at 2022-06-23 21:43:07.676893
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    html_attribute_value = Structure().html_attribute_value

    assert html_attribute_value(tag='a', attribute='href')
    assert html_attribute_value(tag='div', attribute='id')
    assert html_attribute_value(tag='span', attribute='class')
    assert html_attribute_value(tag='span', attribute='style')
    assert html_attribute_value(tag='button', attribute='style')
    assert html_attribute_value(tag='div', attribute='style')

    try:
        assert html_attribute_value(tag='span', attribute='data-test')
    except NotImplementedError:
        pass


# Generated at 2022-06-23 21:43:16.726462
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct = Structure(seed=123) # создание объекта с сидом 123
    assert struct.html_attribute_value('a', 'href') == 'http://www.merry.com/'   # первый тест
    assert struct.html_attribute_value('a', 'href') == 'http://www.merry.co.uk/'   # второй тест
    assert struct.html_attribute_value('span', 'class') == 'formula'   # третий тест
    assert struct.html_attribute_value('span', 'class') == 'formula'   # четвертый те

# Generated at 2022-06-23 21:43:18.307725
# Unit test for constructor of class Structure
def test_Structure():
    try:
        s = Structure()
    except Exception as e:
        print(e)


# Generated at 2022-06-23 21:43:21.344476
# Unit test for method html of class Structure
def test_Structure_html():
    structure_instance = Structure()

    result = structure_instance.html()
    assert isinstance(result, str)
    assert len(result) > 5
    assert '<' in result
    assert '>' in result


# Generated at 2022-06-23 21:43:24.844657
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    print(s.html())
    print(s.html('title'))
    print(s.html_attribute_value('title', 'content'))


# Generated at 2022-06-23 21:43:32.701286
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.providers.structure import Structure
    from mimesis.builtins import Localization
    from mimesis.enums import Gender

    s = Structure("ru")
    m = Structure("ru")
    f = Structure("ru")
    m.seed(1)
    f.seed(2)

    print("Result: ", s.html_attribute_value("a"))
    print("Result: ", s.html_attribute_value("a", "href"))
    print("Result: ", s.html_attribute_value("input", "type"))
    print("Result: ", s.html_attribute_value("input", "placeholder"))
    print("Result: ", s.html_attribute_value("input", "name"))

    print("Result: ", s.html_attribute_value("select", "name"))

# Generated at 2022-06-23 21:43:45.367137
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    import mimesis.enums
    from mimesis.exceptions import UnsupportedLanguageError
    from mimesis.enums import Gender
    from mimesis.providers.structure import Structure
    from mimesis.builtins import en
    from mimesis.builtins import ru
    from mimesis.builtins import zh

    # Test languages (en, ru, zh)
    s = Structure()
    result = s.sex(gender=Gender.MASCULINE)
    assert result in en.Provider.sex.data.male

    s = Structure(locale='ru')
    result = s.sex(gender=Gender.MASCULINE)
    assert result in ru.Provider.sex.data.male

    s = Structure(locale='zh')

# Generated at 2022-06-23 21:43:49.738873
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    provider = Structure('en')
    assert provider.html_attribute_value() == 'word'
    assert provider.html_attribute_value() == 'css'
    assert provider.html_attribute_value() == 'url' 
    

# Generated at 2022-06-23 21:43:50.777345
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    assert s.html()

# Generated at 2022-06-23 21:44:00.402110
# Unit test for constructor of class Structure
def test_Structure():
    from mimesis.builtins.structure import Structure
    from mimesis.data import (
        CSS_PROPERTIES,
        CSS_SELECTORS,
        CSS_SIZE_UNITS,
        HTML_CONTAINER_TAGS,
        HTML_MARKUP_TAGS,
    )
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text
    
    s = Structure()

    assert s._Structure__inet is not None
    assert isinstance(s._Structure__inet, Internet)
    assert s._Structure__text is not None
    assert isinstance(s._Structure__text, Text)
    assert isinstance(s, Structure)
    assert isinstance(s, BaseDataProvider)


# Generated at 2022-06-23 21:44:02.994291
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    S1 = s.html()

    if isinstance(S1,str):
        assert True
    else:
        assert False


# Generated at 2022-06-23 21:44:10.670180
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    strct = Structure()
    tag = 'a'
    attribute = 'rel'
    if attribute in strct.Meta.HTML_TAGS[tag].keys():
        assert (strct.html_attribute_value(tag, attribute)
                in strct.Meta.HTML_TAGS[tag][attribute])
    else:
        raise NotImplementedError(
            'Tag {} or attribute {} is not supported'.format(
                tag, attribute))


# Generated at 2022-06-23 21:44:20.186994
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender, HTMLTag
    from mimesis.providers.structure import Structure

    tag1 = HTMLTag.A
    attribute1 = 'href'
    tag2 = HTMLTag.BUTTON
    attribute2 = 'class'
    tag3 = HTMLTag.ARTICLE
    attribute3 = 'style'
    tag4 = HTMLTag.Q
    attribute4 = 'unsupported'

    structure_provider = Structure(datetime_provider=RussiaSpecProvider(), seed=1)
    assert structure_provider.html_attribute_value(tag=tag1, attribute=attribute1) == 'http://zyrj.ru/g'

# Generated at 2022-06-23 21:44:20.932267
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure

# Generated at 2022-06-23 21:44:21.666257
# Unit test for constructor of class Structure
def test_Structure():
    sl = Structure()
    assert sl is not None

# Generated at 2022-06-23 21:44:23.035500
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    value = Structure().html_attribute_value("img","id")
    assert isinstance(value, str)


# Generated at 2022-06-23 21:44:24.525172
# Unit test for constructor of class Structure
def test_Structure():
	s = Structure()
	s.seed(1)
	assert s

# Generated at 2022-06-23 21:44:27.701658
# Unit test for method css of class Structure
def test_Structure_css():
    st = Structure('en')
    st.css()
    assert True, 'Pattern value is not valid for method css.'


# Generated at 2022-06-23 21:44:30.573374
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    struct = Structure()
    val = struct.html_attribute_value(tag='textarea', attribute='rows')
    assert val == 'css'

# Generated at 2022-06-23 21:44:34.024072
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis.builtins import UnitedStatesSpecProvider
    random = UnitedStatesSpecProvider()
    structure = Structure(random.create_provider())
    assert isinstance(structure.css(), str)



# Generated at 2022-06-23 21:44:35.385307
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    mimesis.meta.Structure.html_attribute_value()

# Generated at 2022-06-23 21:44:36.885022
# Unit test for method css of class Structure
def test_Structure_css():
    obj = Structure()
    obj.css()
    assert 1==1


# Generated at 2022-06-23 21:44:39.906383
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
  # Prepare
  source = Structure()

  # Excute
  result = source.html_attribute_value(tag='form', attribute='action')

  # Assert
  assert result is not None


# Generated at 2022-06-23 21:44:44.554891
# Unit test for method css of class Structure
def test_Structure_css():
    provider = Structure(seed=1)
    result = provider.css()
    assert result == '#careers {font-size: 77ex; border-width: 3px; ' \
                     'cursor: progress; -webkit-border-radius: 39px; ' \
                     'border-style: ridge; font-style: italic; ' \
                     'border-color: #d2306e;}'



# Generated at 2022-06-23 21:44:47.289392
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    stru = Structure()
    assert(stru.html_attribute_value('a')[5:] == 'a href="http://www.example.com"'[5:])

# Generated at 2022-06-23 21:44:48.772757
# Unit test for constructor of class Structure
def test_Structure():
    """Test for constructor of class Structure."""
    obj = Structure()
    assert callable(obj)

# Generated at 2022-06-23 21:44:53.666720
# Unit test for method html of class Structure
def test_Structure_html():
    mystructure = Structure()
    mystructure.html()
    mystructure.html_attribute_value()
    mystructure.html_attribute_value(tag="html", attribute="lang")
    # mystructure.html_attribute_value(tag="html", attribute="xxx")

# Generated at 2022-06-23 21:44:56.729287
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    css_property = structure.css_property()
    assert type(css_property) is str


# Generated at 2022-06-23 21:45:02.580933
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct = Structure(seed=123)
    result = struct.html_attribute_value()
    expected = '<small class="d-block text-muted">Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</small>'
    assert result == expected

# Generated at 2022-06-23 21:45:03.982829
# Unit test for method html of class Structure
def test_Structure_html():
    """Unit test for method html of class Structure."""
    sl = Structure()
    # print(sl.html())

# Generated at 2022-06-23 21:45:06.163094
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()
    assert type(struct).__name__ == 'Structure'
    assert isinstance(struct.seed, int)


# Generated at 2022-06-23 21:45:07.585450
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure('en')
    output = s.css()
    assert isinstance(output, str)


# Generated at 2022-06-23 21:45:08.821932
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure('en')
    assert structure is not None


# Generated at 2022-06-23 21:45:11.285713
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert isinstance(structure, Structure)
    assert structure.__inet
    assert structure.__text
    assert structure.random


# Generated at 2022-06-23 21:45:22.149524
# Unit test for method css of class Structure
def test_Structure_css():
    struct = Structure()
    struct.seed(0)
    css_list = [struct.css(), struct.css(), struct.css(), struct.css(), struct.css()]

# Generated at 2022-06-23 21:45:26.887803
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('en', random_state=1)

    # Test for the first time
    first_time_css_property = structure.css_property()
    # Test for the second time
    second_time_css_property = structure.css_property()

    assert first_time_css_property == second_time_css_property


# Generated at 2022-06-23 21:45:27.892687
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure.seed

# Generated at 2022-06-23 21:45:29.998338
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    obj = Structure()
    ret = obj.html_attribute_value()
    assert ret
    assert isinstance(ret, str)

# Generated at 2022-06-23 21:45:35.878567
# Unit test for constructor of class Structure
def test_Structure():
    str1 = Structure()
    str2 = Structure(seed=0)
    assert str1.seed != str2.seed and str1.random is not str2.random
    assert str1.css_property() != str2.css_property()
    assert str1.css() != str2.css()
    assert str1.html() != str2.html()

# Generated at 2022-06-23 21:45:37.500891
# Unit test for method css of class Structure
def test_Structure_css():
    x = Structure()
    assert type(x.css()) is str


# Generated at 2022-06-23 21:45:47.619920
# Unit test for method html of class Structure

# Generated at 2022-06-23 21:45:49.030005
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    print(s.html())

# Generated at 2022-06-23 21:45:55.657430
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure(seed=0)
    result = structure.css()
    # print(result)

# Generated at 2022-06-23 21:45:57.523977
# Unit test for method css of class Structure
def test_Structure_css():
    css = Structure().css()
    print('CSS: ', css)
    assert css is not None


# Generated at 2022-06-23 21:45:59.848642
# Unit test for constructor of class Structure
def test_Structure():
    assert Structure._meta.name == 'structure'
    assert isinstance(Structure().__inet, Internet)
    assert isinstance(Structure().__text, Text)


# Generated at 2022-06-23 21:46:02.370705
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    html = s.html()
    assert '<' in html
    assert '>' in html


# Generated at 2022-06-23 21:46:06.676871
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure"""
    structure=Structure()
    result=structure.html_attribute_value(tag='a',attribute='href')
    print("result of test_Structure_html_attribute_value()")
    print(result)


# Unit tests for class Structure

# Generated at 2022-06-23 21:46:07.803514
# Unit test for method css of class Structure
def test_Structure_css():
    st = Structure('en')
    print(st.css())

# Generated at 2022-06-23 21:46:12.997361
# Unit test for method css of class Structure
def test_Structure_css():
    st = Structure(seed=42)
    assert st.css() == 'async {display: inline-block; z-index: auto; ' \
                       'background-image: url(https://www.rvt.com/); ' \
                       'max-width: auto; min-height: 20px; ' \
                       'font-weight: bold}'

# Generated at 2022-06-23 21:46:25.026898
# Unit test for method html of class Structure
def test_Structure_html():
    text = Text('en')
    random = Random()
    structure = Structure(random=random, seed=random.randint())
    tag_name = random.choice(list(HTML_CONTAINER_TAGS))
    tag_attributes = list(HTML_CONTAINER_TAGS[tag_name])  # type: ignore
    k = random.randint(1, len(tag_attributes))
    selected_attrs = random.sample(tag_attributes, k=k)
    attrs = []
    for attr in selected_attrs:
        attrs.append('{}="{}"'.format(attr, structure.html_attribute_value(tag_name, attr)))

# Generated at 2022-06-23 21:46:27.162536
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('en')
    print(structure.css_property())


# Generated at 2022-06-23 21:46:28.329941
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    out = s.css_property()
    assert out

# Generated at 2022-06-23 21:46:38.289284
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import MarkupTag
    from mimesis.providers.structure import Structure
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text
    structure = Structure()
    tag = structure.random.choice(list(MarkupTag))
    tag_name = tag.value
    attributes = list(MarkupTag[tag.name]) # type: ignore
    k = structure.random.randint(1, len(attributes))
    selected_attrs = structure.random.sample(attributes, k=k)
    attrs = []

# Generated at 2022-06-23 21:46:39.306576
# Unit test for constructor of class Structure
def test_Structure():
    a = Structure()
    print(a.css())

# Generated at 2022-06-23 21:46:42.842277
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    struct = Structure()
    p = struct.css_property()
    print(p)
    assert isinstance(p, str)
    assert len(p) != 0


# Generated at 2022-06-23 21:46:46.061385
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()
    a = struct.__init__('en')
    assert a == None
    b = struct.__init__('en', seed=0)
    assert b == None


# Generated at 2022-06-23 21:46:47.542333
# Unit test for constructor of class Structure
def test_Structure():
    v = Structure()
    assert isinstance(v, Structure)

# Generated at 2022-06-23 21:46:49.327945
# Unit test for method css of class Structure
def test_Structure_css():
    test = Structure()
    for _ in range(10):
        print(test.css())


# Generated at 2022-06-23 21:46:53.739552
# Unit test for method css of class Structure
def test_Structure_css():
    #Arrange
    #Act
    result = Structure().css()
    #Assert
    #Expect a string of format <tag><selector> {<property>: <value>;...}
    assert result[0] == "<"
    assert result[1]== " "
    assert result[2] == "{"
    assert result[3] == ":"


# Generated at 2022-06-23 21:46:56.926077
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure('en')
    res = structure.html()
    assert isinstance(res, str), res

# Generated at 2022-06-23 21:46:59.033304
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.providers.structure import Structure
    structure = Structure()
    assert structure.html()

# Generated at 2022-06-23 21:47:07.949221
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    html_attributes_values = ['css', 'word', 'url']
    tag = 'a'
    attribute = 'href'
    random_value = random.randint(0, 2)
    value = html_attributes_values[random_value]
    if value == 'css':
        sample = Structure().html_attribute_value(tag, attribute)
        assert len(sample) > 0
    elif value == 'word':
        sample = Structure().html_attribute_value(tag, attribute)
        assert len(sample) > 0
    else:
        sample = Structure().html_attribute_value(tag, attribute)
        assert isinstance(sample, str)
        assert sample.startswith('http')

# Generated at 2022-06-23 21:47:10.778081
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Test the Structure class in css_property function."""
    s = Structure()
    assert isinstance(s.css_property(), str)


# Generated at 2022-06-23 21:47:14.252255
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure('en')
    assert isinstance(s, Structure)
    assert s.locale == 'en'
    assert isinstance(s.text_provider, Text)
    assert isinstance(s.internet_provider, Internet)



# Generated at 2022-06-23 21:47:16.965023
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CssProperty
    from mimesis.providers.structure import Structure
    structure = Structure()
    css_property = structure.css_property()
    assert css_property in list(CssProperty)
    assert css_property in ['auto']

# Generated at 2022-06-23 21:47:24.587473
# Unit test for constructor of class Structure
def test_Structure():
    print(Structure().css_property())
    print(Structure().css())
    print(Structure().html())
    print(Structure().html_attribute_value('a', 'href'))
    print(Structure().html_attribute_value('link', 'href'))
    print(Structure().html_attribute_value('style', 'css'))
    print(Structure().html_attribute_value('a', 'href'))
    print(Structure().html_attribute_value('img', 'src'))
    print(Structure().html_attribute_value())

if __name__ == '__main__':
    test_Structure()

# Generated at 2022-06-23 21:47:26.086239
# Unit test for method css of class Structure
def test_Structure_css():
    assert len(Structure().css()) > 0, "Structure_css FAILED"


# Generated at 2022-06-23 21:47:28.157428
# Unit test for method css of class Structure
def test_Structure_css():
    st = Structure()
    print(st.css())


# Generated at 2022-06-23 21:47:31.046895
# Unit test for method html of class Structure
def test_Structure_html():
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-23 21:47:33.716565
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    assert structure.html()
    assert structure.html('div')
    assert structure.html('div', 'id')
    assert structure.html('span', 'class')

# Generated at 2022-06-23 21:47:35.948340
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()
    assert struct.__class__.__name__ == 'Structure'
    assert struct._locale != None


# Generated at 2022-06-23 21:47:40.927358
# Unit test for constructor of class Structure
def test_Structure():
    def __init__(self, *args, **kwargs) -> None:
        """Initialize attributes.

        :param locale: Current locale.
        :param seed: Seed.
        """
        super().__init__(*args, **kwargs)
        self.__inet = Internet(seed=self.seed)
        self.__text = Text('en', seed=self.seed)



# Generated at 2022-06-23 21:47:42.532135
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st = Structure()
    css_property = st.css_property()
    print(css_property)



# Generated at 2022-06-23 21:47:45.054495
# Unit test for method html of class Structure
def test_Structure_html():
    assert (
        Structure().html()
        == '<span class="select" id="careers">'
            'Ports are created with the built-in function open_port.'
        '</span>'
    )

# Generated at 2022-06-23 21:47:45.893369
# Unit test for method html of class Structure
def test_Structure_html():
    print(Structure().html())

# Generated at 2022-06-23 21:47:50.133767
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure().html_attribute_value('a','href')
    assert Structure().html_attribute_value('img','src')
    assert Structure().html_attribute_value('link','href')
    assert Structure().html_attribute_value('script','src')
    assert Structure().html_attribute_value('form','action')
    assert Structure().html_attribute_value('form','method')
    assert Structure().html_attribute_value('input','type')
    assert Structure().html_attribute_value('input','value')

# Generated at 2022-06-23 21:47:54.153408
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Unit test for method css_property of class Structure"""
    structure = Structure()
    num_tests = 10
    for i in range(num_tests):
        prop = structure.css_property()
        print(prop)


# Generated at 2022-06-23 21:47:54.589585
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    structure.css()

# Generated at 2022-06-23 21:48:01.360587
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.data import HTML_CONTAINER_TAGS
    strc = Structure()
    for tag in HTML_CONTAINER_TAGS:
        for attribute in HTML_CONTAINER_TAGS[tag]:
            try:
                strc.html_attribute_value(tag, attribute)
                print("OK")
            except NotImplementedError:
                print("NO OK")
                print('{} or {} is not supported'
                      .format(tag, attribute))

# Generated at 2022-06-23 21:48:04.762726
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    html = structure.html()
    assert type(html) == str
    assert html[0:3] == '<ul'
    assert html[-6:] == '</ul>\n'


# Generated at 2022-06-23 21:48:07.915031
# Unit test for method css of class Structure
def test_Structure_css():
    provider = Structure('en')
    css = '{}'.format(provider.css())
    assert css


# Generated at 2022-06-23 21:48:12.897306
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = 'a'
    attribute = 'rel'
    assert structure.html_attribute_value(tag, attribute) in \
        ['alternate', 'author', 'bookmark', 'canonical', 'help', 'license',
         'next', 'nofollow', 'noreferrer', 'prefetch', 'prev', 'search',
         'tag']



# Generated at 2022-06-23 21:48:19.685183
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value.

    This test checks for the correct functioning of the html_attribute_value function.
    """
    valid_values = \
        {
            "class": ['word'],
            "id": ['word'],
            "style": ['css'],
            "rel": ['stylesheet'],
            "type": ['text/css'],
            "media": ['media'],
            "href": ['url'],
            "src": ['url']
        }

    for tag, attributes in valid_values.items():
        for attribute in attributes:
            assert type(Structure().html_attribute_value(tag, attribute)) == str

# Generated at 2022-06-23 21:48:22.472254
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    css = s.css()
    assert css.startswith('{}'
      ' {{'.format(s.random.choice(css_selectors))
    ) and ':' in css


# Generated at 2022-06-23 21:48:23.833821
# Unit test for method html of class Structure
def test_Structure_html():
    html = Structure().html()
    # I'm sorry but I don't know what to test here
    assert html == html

# Generated at 2022-06-23 21:48:26.183259
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    for x in range(0, 10):
        s = Structure()
        css = s.css_property()
        print(css)


# Generated at 2022-06-23 21:48:29.811513
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure(seed=12345)
    result = s.css_property()
    # Check that returned result is not empty
    assert result != ''

# Generated at 2022-06-23 21:48:30.519014
# Unit test for method css of class Structure
def test_Structure_css():
    assert Structure().css()


# Generated at 2022-06-23 21:48:32.065680
# Unit test for constructor of class Structure
def test_Structure():
    my_structure = Structure()
    assert isinstance(my_structure, Structure)
    assert isinstance(my_structure.seed, int)
    assert my_structure._validate_seed()


# Generated at 2022-06-23 21:48:34.328666
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    r = s.css_property()
    s = Structure()
    l = s.css_property()
    assert r != l


# Generated at 2022-06-23 21:48:46.188147
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import DataField
    s = Structure()
    assert s.html(DataField.HTML_CONTAINER_TAGS) == s.html()  # random.choice
    assert s.html(DataField.HTML_CONTAINER_TAGS, DataField.HTML_MARKUP_TAGS) == s.html()
    assert s.html(DataField.HTML_MARKUP_TAGS) == s.html()
    assert s.html(tag="table") == s.html()
    assert s.html(tag="table", attribute="class") == s.html()
    assert s.html(tag="table", attribute="cellpadding") == s.html()
    assert s.html(tag="table", attribute="cellspacing") == s.html()

# Generated at 2022-06-23 21:48:49.480860
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('en')
    structure._seed(0)
    for _ in range(3):
        css_property = structure.css_property()
        print(css_property)


# Generated at 2022-06-23 21:48:52.206265
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    result = s.css_property()
    assert isinstance(result, str)
    assert len(result) != 0
    # assert "www.example.com" in result



# Generated at 2022-06-23 21:48:54.793569
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Unit test for method css_property of class Structure."""
    structure = Structure()
    print(structure.css_property())

# Generated at 2022-06-23 21:48:57.028766
# Unit test for method css of class Structure
def test_Structure_css():
    print('Testing Structure.css')
    structure = Structure()
    print(structure.css())


# Generated at 2022-06-23 21:48:59.697151
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    r = structure.css()
    print(r)
    assert r is not None
    

# Generated at 2022-06-23 21:49:09.821987
# Unit test for method html of class Structure
def test_Structure_html():
    import re
    import bs4
    htmls = []
    for _ in range(32):
        s = Structure()
        h = s.html()
        htmls.append(h)

# Generated at 2022-06-23 21:49:12.193909
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    assert type(s.css()) is str
    assert len(s.css()) > 0


# Generated at 2022-06-23 21:49:14.045346
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    result = structure.css()
    assert isinstance(result, str)



# Generated at 2022-06-23 21:49:16.271025
# Unit test for constructor of class Structure
def test_Structure():
    # initialize object of class Structure
    s = Structure(seed=123)
    assert isinstance(s, Structure)
    assert isinstance(s, BaseDataProvider)


# Generated at 2022-06-23 21:49:24.533248
# Unit test for constructor of class Structure
def test_Structure():
    # Creating structure object with structure.json file
    structure = Structure()

    # printing the css properties
    for i in range(10):
        print(structure.css_property())

    # printing the css snippet
    for i in range(10):
        print(structure.css())

    # printing the html tag
    for i in range(10):
        print(structure.html())

if __name__ == '__main__':
    test_Structure()

# Generated at 2022-06-23 21:49:27.157555
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    print(structure.html())
    # print(structure.css_property())
    # print(structure.css())

test_Structure_html()

# Generated at 2022-06-23 21:49:31.307790
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    print('Unit test for method css_property of class Structure')
    print('----------------------------------------------------------')
    structure_provider = Structure()
    css_property = structure_provider.css_property()
    print('css_property = ', css_property)
    print('----------------------------------------------------------')
    

# Generated at 2022-06-23 21:49:35.339079
# Unit test for method html of class Structure
def test_Structure_html():
    print("test_Structure_html")
    assert len(type(Structure(seed=2).html())) == 1247
    assert type(Structure().html()) == str


# Generated at 2022-06-23 21:49:38.162825
# Unit test for method css of class Structure
def test_Structure_css():
    provider = Structure()

    result = provider.css()
    assert len(result) > 0


# Generated at 2022-06-23 21:49:49.562141
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import TagsAttribute
    from mimesis.enums import Tags
    st = Structure()
    # tag = '<link href="https://example.com" rel="stylesheet">'
    tag = st.html()
    print(tag)
    tag = st.html(Tags.LINK)
    print(tag)
    tag = st.html(Tags.A)
    print(tag)
    tag = st.html(Tags.A, TagsAttribute.HREF)
    print(tag)
    tag = st.html(Tags.A, TagsAttribute.REL)
    print(tag)
    tag = st.html(Tags.A, TagsAttribute.ALT)
    print(tag)
    tag = st.html(Tags.A, TagsAttribute.CLASS)
    print(tag)
    tag = st

# Generated at 2022-06-23 21:49:56.136105
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    provider = Structure(seed=123456789)
    provider.random.choice = MagicMock()

    provider.random.choice.return_value = 'background-color'
    _ = provider.css_property()

    provider.random.choice.assert_called_once_with(
        list(CSS_PROPERTIES.keys())
    )


# Generated at 2022-06-23 21:49:57.639770
# Unit test for constructor of class Structure
def test_Structure():
    st = Structure()

    assert isinstance(st, Structure)

# Generated at 2022-06-23 21:49:59.519795
# Unit test for method css of class Structure
def test_Structure_css():
    struct = Structure()
    css = struct.css()
    print(css)


# Generated at 2022-06-23 21:50:01.918700
# Unit test for method html of class Structure
def test_Structure_html():
    '''
    Unit test for method html of class Structure
    '''
    struct = Structure()
    struct.html()
    print('Test for function html passed')


# Generated at 2022-06-23 21:50:03.110733
# Unit test for constructor of class Structure
def test_Structure():
    rs = Structure()
    assert rs is not None


# Generated at 2022-06-23 21:50:04.501667
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'

# Generated at 2022-06-23 21:50:13.491604
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis.enums import CSSProperty
    from mimesis.providers.localization import Locale
    from mimesis.providers.structure import Structure

    assert len(Structure('en').css()) == 63
    assert isinstance(Structure('en').css(), str)
    assert CSSProperty.BORDER_RADIUS.value in Structure('en').css()
    assert CSSProperty.BACKGROUND_COLOR.value in Structure('en').css()
    assert CSSProperty.WIDTH.value in Structure('en').css()
    assert Structure('en').css().startswith('.') == True or '#' or 'span' or 'a'
    assert Structure('en').css().endswith(';') == True or '}'


# Generated at 2022-06-23 21:50:15.184908
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    assert isinstance(s.html(), str)

# Generated at 2022-06-23 21:50:19.392696
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure('en')
    print(structure.css())
    print(structure.html())
    print(structure.html_attribute_value(tag="span"))

# Generated at 2022-06-23 21:50:21.178069
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure(seed=111)
    assert structure, "Structure is not defined."


# Generated at 2022-06-23 21:50:28.204577
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """
    This function test method html_attribute_value of class Structure
    """
    result = Structure(seed=1).html_attribute_value("a", "download")
    assert isinstance(result, str), "result is not a string"
    result = Structure(seed=1).html_attribute_value("a", "href")
    assert isinstance(result, str), "result is not a string"
    result = Structure(seed=1).html_attribute_value(
        "a", "target")
    assert isinstance(result, str), "result is not a string"
    result = Structure(seed=1).html_attribute_value("h1", "class")
    assert isinstance(result, str), "result is not a string"
    result = Structure(seed=1).html_attribute_value("p", "style")

# Generated at 2022-06-23 21:50:30.243343
# Unit test for method css of class Structure
def test_Structure_css(): assert Structure(seed=1).css() == '#detail-renter-text {float: 0;}'

# Generated at 2022-06-23 21:50:33.302861
# Unit test for constructor of class Structure
def test_Structure():
    a = Structure(seed=123456789)
    a.html()
    a.html_attribute_value()
    a.css()
    a.css_property()

# Generated at 2022-06-23 21:50:38.470183
# Unit test for constructor of class Structure
def test_Structure():
    st = Structure()
    assert isinstance(st, Structure) 
    # test_css()
    assert st.css()
    # test_css_property()
    assert st.css_property()
    # test_html()
    assert st.html()
    # test_html_attribute_value()
    assert st.html_attribute_value()
    assert st.html_attribute_value('a', 'href')
    assert st.html_attribute_value(None, 'href') 
    assert st.html_attribute_value('a', None)
    assert st.html_attribute_value('a', 'html')

# Generated at 2022-06-23 21:50:39.751191
# Unit test for constructor of class Structure
def test_Structure():
    obj = Structure()
    assert isinstance(obj, Structure)

# Generated at 2022-06-23 21:50:43.155252
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure(locale='en', seed=20200921)
    assert structure.css_property() == 'border-right-width: 5px'



# Generated at 2022-06-23 21:50:45.487637
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    tester = Structure()
    result = tester.css_property()
    assert type(result) == str


# Generated at 2022-06-23 21:50:49.529014
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = 'iframe'
    attribute = 'src'
    value = structure.html_attribute_value(tag=tag, attribute=attribute)

    regex = r'^(http|https):\/\/[^\s]+$'
    assert re.match(regex, value)

# Generated at 2022-06-23 21:50:52.057541
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # test CSS_PROPERTIES
    for css_prop in CSS_PROPERTIES:
        assert Structure().css_property().startswith(css_prop)


# Generated at 2022-06-23 21:50:57.775346
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    assert (s.css().startswith('#') ==
            True), "Fail: method css of class Structure"
    assert (s.css().endswith('0px') ==
            True), "Fail: method css of class Structure"
    assert (s.css().find('text-align') > 0 ==
            True), "Fail: method css of class Structure"


# Generated at 2022-06-23 21:51:05.035329
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Unit test for method css_property of class Structure."""
    from mimesis.enums import CSSPropertyName

    dummy_provider_1 = Structure()
    css_property = dummy_provider_1.css_property()

    assert isinstance(css_property, str)
    assert len(css_property.split(":")) == 2

    # force property to be 'background-color' and test it
    dummy_provider_2 = Structure(seed=dummy_provider_1.seed)
    dummy_provider_2.random.seed(dummy_provider_1.seed)
    dummy_provider_2.random.choice = lambda x: CSSPropertyName.BACKGROUND_COLOR.value
    css_property_2 = dummy_provider_2.css_property()

    assert css_property_