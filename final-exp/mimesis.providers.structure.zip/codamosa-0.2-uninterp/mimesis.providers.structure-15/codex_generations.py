

# Generated at 2022-06-17 23:06:28.465880
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value() != None
    assert s.html_attribute_value('a') != None
    assert s.html_attribute_value('a', 'href') != None
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute

# Generated at 2022-06-17 23:06:39.585704
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:06:45.275063
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value() in HTML_CONTAINER_TAGS.keys()
    assert s.html_attribute_value(tag='a') in HTML_CONTAINER_TAGS['a']
    assert s.html_attribute_value(tag='a', attribute='href') in ['url', 'word']

# Generated at 2022-06-17 23:06:47.045175
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:06:49.983417
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:06:54.528528
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:07:05.937048
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'rel') == 'word'
    assert s.html_attribute_value('a', 'target') == 'word'
    assert s.html_attribute_value('a', 'type') == 'word'
    assert s.html_attribute_value('a', 'media') == 'word'
    assert s.html_attribute_value('a', 'hreflang') == 'word'
    assert s.html_attribute_value('a', 'charset') == 'word'
    assert s.html_attribute_value('a', 'name') == 'word'
    assert s.html_attribute_value('a', 'download') == 'word'
    assert s.html_attribute_

# Generated at 2022-06-17 23:07:07.054281
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    print(s.css_property())


# Generated at 2022-06-17 23:07:08.425471
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    for i in range(10):
        print(s.css_property())


# Generated at 2022-06-17 23:07:11.594927
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:07:39.910344
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:07:46.532368
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'target') == '_blank'
    assert s.html_attribute_value('a', 'rel') == 'nofollow'
    assert s.html_attribute_value('a', 'type') == 'text/html'
    assert s.html_attribute_value('a', 'download') == 'word'
    assert s.html_attribute_value('a', 'hreflang') == 'en'
    assert s.html_attribute_value('a', 'media') == 'all'
    assert s.html_attribute_value('a', 'ping') == 'url'
    assert s.html_attribute_value('a', 'coords') == 'word'

# Generated at 2022-06-17 23:07:47.479089
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    print(structure.css_property())


# Generated at 2022-06-17 23:07:57.644758
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import Attribute
    from mimesis.enums import Tag
    from mimesis.providers.structure import Structure
    from mimesis.providers.text import Text
    from mimesis.providers.internet import Internet
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.base import BaseUnit
    from mimesis.providers.base import BaseEnum
    from mimesis.providers.base import BaseField
    from mimesis.providers.base import BaseSubfield
    from mimesis.providers.base import BaseSubfield
    from mimesis.providers.base import BaseSubfield
    from mimesis.providers.base import BaseSubfield

# Generated at 2022-06-17 23:07:59.163103
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:08:08.077605
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'rel') == 'word'
    assert structure.html_attribute_value('a', 'target') == 'word'
    assert structure.html_attribute_value('a', 'type') == 'word'
    assert structure.html_attribute_value('a', 'media') == 'word'
    assert structure.html_attribute_value('a', 'hreflang') == 'word'
    assert structure.html_attribute_value('a', 'ping') == 'url'
    assert structure.html_attribute_value('a', 'coords') == 'word'
    assert structure.html_attribute_value('a', 'shape') == 'word'
    assert structure.html_attribute_value

# Generated at 2022-06-17 23:08:09.731719
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:08:11.079580
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() in CSS_PROPERTIES.keys()


# Generated at 2022-06-17 23:08:19.982232
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:08:28.385715
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:08:51.386962
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value()
    assert s.html_attribute_value('a')
    assert s.html_attribute_value('a', 'href')
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:08:54.291932
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:08:55.667867
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() in CSS_PROPERTIES.keys()


# Generated at 2022-06-17 23:08:57.844242
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:09:02.435494
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:09:10.968122
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test for method html_attribute_value of class Structure."""
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'target') == '_blank'
    assert s.html_attribute_value('a', 'title') == 'word'
    assert s.html_attribute_value('a', 'rel') == 'nofollow'
    assert s.html_attribute_value('a', 'media') == 'all'
    assert s.html_attribute_value('a', 'type') == 'text/css'
    assert s.html_attribute_value('a', 'charset') == 'utf-8'
    assert s.html_attribute_value('a', 'name') == 'word'
    assert s.html_attribute_

# Generated at 2022-06-17 23:09:15.948845
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    s = Structure()
    assert s.html_attribute_value()
    assert s.html_attribute_value('a')
    assert s.html_attribute_value('a', 'href')
    assert s.html_attribute_value('a', 'href') == s.html_attribute_value('a', 'href')
    assert s.html_attribute_value('a', 'href') != s.html_attribute_value('a', 'href')

# Generated at 2022-06-17 23:09:17.807484
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() in CSS_PROPERTIES.keys()

# Generated at 2022-06-17 23:09:19.116791
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert isinstance(s.css_property(), str)


# Generated at 2022-06-17 23:09:26.329250
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'rel') == 'word'
    assert structure.html_attribute_value('a', 'target') == 'word'
    assert structure.html_attribute_value('a', 'type') == 'word'
    assert structure.html_attribute_value('a', 'media') == 'word'
    assert structure.html_attribute_value('a', 'hreflang') == 'word'
    assert structure.html_attribute_value('a', 'download') == 'word'
    assert structure.html_attribute_value('a', 'ping') == 'word'