

# Generated at 2022-06-17 23:06:45.848428
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'rel') == 'word'
    assert structure.html_attribute_value('a', 'target') == 'word'
    assert structure.html_attribute_value('a', 'type') == 'word'
    assert structure.html_attribute_value('a', 'media') == 'word'
    assert structure.html_attribute_value('a', 'hreflang') == 'word'
    assert structure.html_attribute_value('a', 'charset') == 'word'
    assert structure.html_attribute_value('a', 'coords') == 'word'