

# Generated at 2022-06-17 23:06:23.759219
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:06:26.170251
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:06:37.776933
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:06:39.624757
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:06:44.237712
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value()
    assert s.html_attribute_value('a')
    assert s.html_attribute_value('a', 'href')
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:06:54.275630
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:06:56.684483
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert isinstance(structure.css_property(), str)


# Generated at 2022-06-17 23:07:07.090271
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import AttributeType
    from mimesis.providers.structure import Structure
    from mimesis.providers.text import Text
    from mimesis.providers.internet import Internet
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.utils import get_provider
    from mimesis.providers.utils import get_provider_by_name
    from mimesis.providers.utils import get_provider_by_qualname
    from mimesis.providers.utils import get_provider_by_subclass
    from mimesis.providers.utils import get_provider_by_subclass_name
    from mimesis.providers.utils import get_provider_by_subclass_qualname

# Generated at 2022-06-17 23:07:17.168213
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'target') == '_blank'
    assert s.html_attribute_value('a', 'rel') == 'nofollow'
    assert s.html_attribute_value('a', 'type') == 'application/rss+xml'
    assert s.html_attribute_value('a', 'media') == 'print'
    assert s.html_attribute_value('a', 'hreflang') == 'en'
    assert s.html_attribute_value('a', 'charset') == 'UTF-8'
    assert s.html_attribute_value('a', 'name') == 'word'
    assert s.html_attribute_value('a', 'rev') == 'made'

# Generated at 2022-06-17 23:07:27.624853
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'target') == '_blank'
    assert structure.html_attribute_value('a', 'rel') == 'nofollow'
    assert structure.html_attribute_value('a', 'type') == 'word'
    assert structure.html_attribute_value('a', 'media') == 'word'
    assert structure.html_attribute_value('a', 'hreflang') == 'word'
    assert structure.html_attribute_value('a', 'charset') == 'word'
    assert structure.html_attribute_value('a', 'rev') == 'word'
    assert structure.html_attribute_

# Generated at 2022-06-17 23:07:52.852342
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    print(s.css_property())


# Generated at 2022-06-17 23:07:54.475077
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() in CSS_PROPERTIES.keys()


# Generated at 2022-06-17 23:07:58.823165
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value() is not None
    assert structure.html_attribute_value(tag='a') is not None
    assert structure.html_attribute_value(attribute='class') is not None
    assert structure.html_attribute_value(tag='a', attribute='class') is not None


# Generated at 2022-06-17 23:08:00.058219
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert len(structure.css_property()) > 0


# Generated at 2022-06-17 23:08:08.975822
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    assert structure.html_attribute_value() is not None
    assert structure.html_attribute_value('a') is not None
    assert structure.html_attribute_value('a', 'href') is not None
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute

# Generated at 2022-06-17 23:08:18.211512
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import Attribute
    from mimesis.enums import Tag
    from mimesis.providers.structure import Structure
    from mimesis.providers.text import Text
    from mimesis.providers.utils import ProviderType

    structure = Structure(seed=42)
    text = Text(seed=42)

    assert structure.html_attribute_value(Tag.A, Attribute.HREF) == 'url'
    assert structure.html_attribute_value(Tag.A, Attribute.REL) == 'word'
    assert structure.html_attribute_value(Tag.A, Attribute.TARGET) == '_blank'
    assert structure.html_attribute_value(Tag.A, Attribute.TYPE) == 'word'

# Generated at 2022-06-17 23:08:25.374114
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:08:33.906879
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'rel') == 'word'
    assert s.html_attribute_value('a', 'target') == 'word'
    assert s.html_attribute_value('a', 'type') == 'word'
    assert s.html_attribute_value('a', 'download') == 'word'
    assert s.html_attribute_value('a', 'hreflang') == 'word'
    assert s.html_attribute_value('a', 'media') == 'word'
    assert s.html_attribute_value('a', 'ping') == 'word'
    assert s.html_attribute_value('a', 'referrerpolicy') == 'word'
    assert s.html_attribute

# Generated at 2022-06-17 23:08:43.126748
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = 'a'
    attribute = 'href'
    assert structure.html_attribute_value(tag, attribute) == structure.__inet.home_page()
    tag = 'a'
    attribute = 'target'
    assert structure.html_attribute_value(tag, attribute) in ['_blank', '_self', '_parent', '_top']
    tag = 'a'
    attribute = 'rel'
    assert structure.html_attribute_value(tag, attribute) in ['alternate', 'author', 'bookmark', 'help', 'license', 'next', 'nofollow', 'noreferrer', 'prefetch', 'prev', 'search', 'tag']
    tag = 'a'
    attribute = 'type'

# Generated at 2022-06-17 23:08:53.248636
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:09:19.058700
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'font-family: Arial'


# Generated at 2022-06-17 23:09:26.269186
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value()
    assert s.html_attribute_value('a')
    assert s.html_attribute_value('a', 'href')
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:09:32.131116
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Test for tag 'a' and attribute 'href'
    assert Structure().html_attribute_value('a', 'href') == 'url'
    # Test for tag 'a' and attribute 'class'
    assert Structure().html_attribute_value('a', 'class') == 'word'
    # Test for tag 'a' and attribute 'target'
    assert Structure().html_attribute_value('a', 'target') == '_blank'
    # Test for tag 'a' and attribute 'rel'
    assert Structure().html_attribute_value('a', 'rel') == 'nofollow'
    # Test for tag 'a' and attribute 'type'
    assert Structure().html_attribute_value('a', 'type') == 'text/css'
    # Test for tag 'a' and attribute 'media'

# Generated at 2022-06-17 23:09:39.486747
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'rel') == 'word'
    assert s.html_attribute_value('a', 'target') == 'word'
    assert s.html_attribute_value('a', 'type') == 'word'
    assert s.html_attribute_value('a', 'download') == 'word'
    assert s.html_attribute_value('a', 'hreflang') == 'word'
    assert s.html_attribute_value('a', 'media') == 'word'
    assert s.html_attribute_value('a', 'ping') == 'url'
    assert s.html_attribute_value('a', 'shape') == 'word'

# Generated at 2022-06-17 23:09:47.705809
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value(tag='a', attribute='href') == 'url'
    assert s.html_attribute_value(tag='a', attribute='href') == 'url'
    assert s.html_attribute_value(tag='a', attribute='href') == 'url'
    assert s.html_attribute_value(tag='a', attribute='href') == 'url'
    assert s.html_attribute_value(tag='a', attribute='href') == 'url'
    assert s.html_attribute_value(tag='a', attribute='href') == 'url'
    assert s.html_attribute_value(tag='a', attribute='href') == 'url'
    assert s.html_attribute_value(tag='a', attribute='href') == 'url'
    assert s.html_attribute_value

# Generated at 2022-06-17 23:09:49.211916
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:09:50.022613
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() in CSS_PROPERTIES

# Generated at 2022-06-17 23:09:57.505856
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value()
    assert structure.html_attribute_value(tag='a', attribute='href')
    assert structure.html_attribute_value(tag='a', attribute='target')
    assert structure.html_attribute_value(tag='a', attribute='rel')
    assert structure.html_attribute_value(tag='a', attribute='type')
    assert structure.html_attribute_value(tag='a', attribute='media')
    assert structure.html_attribute_value(tag='a', attribute='hreflang')
    assert structure.html_attribute_value(tag='a', attribute='download')
    assert structure.html_attribute_value(tag='a', attribute='ping')
    assert structure.html_attribute_value(tag='a', attribute='coords')
    assert structure.html_attribute

# Generated at 2022-06-17 23:10:04.072350
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:10:14.838110
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'target') == '_blank'
    assert s.html_attribute_value('a', 'rel') == 'nofollow'
    assert s.html_attribute_value('a', 'type') == 'text/css'
    assert s.html_attribute_value('a', 'media') == 'all'
    assert s.html_attribute_value('a', 'charset') == 'utf-8'
    assert s.html_attribute_value('a', 'name') == 'word'
    assert s.html_attribute_value('a', 'id') == 'word'
    assert s.html_attribute_value('a', 'class') == 'word'

# Generated at 2022-06-17 23:10:47.420979
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value()
    assert structure.html_attribute_value('a')
    assert structure.html_attribute_value('a', 'href')
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:10:54.994798
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'target') == 'word'
    assert structure.html_attribute_value('a', 'rel') == 'word'
    assert structure.html_attribute_value('a', 'type') == 'word'
    assert structure.html_attribute_value('a', 'media') == 'word'
    assert structure.html_attribute_value('a', 'hreflang') == 'word'
    assert structure.html_attribute_value('a', 'download') == 'word'
    assert structure.html_attribute_value('a', 'ping') == 'word'

# Generated at 2022-06-17 23:11:03.425191
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:11:05.451872
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    css_property = structure.css_property()
    assert css_property is not None
    assert isinstance(css_property, str)
    assert len(css_property) > 0


# Generated at 2022-06-17 23:11:06.596609
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:11:15.638445
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'target') == '_blank'
    assert structure.html_attribute_value('a', 'rel') == 'nofollow'
    assert structure.html_attribute_value('a', 'type') == 'text/css'
    assert structure.html_attribute_value('a', 'media') == 'all'
    assert structure.html_attribute_value('a', 'hreflang') == 'en'
    assert structure.html_attribute_value('a', 'charset') == 'utf-8'
    assert structure.html_attribute_value('a', 'name') == 'word'
    assert structure.html_attribute_value('a', 'download') == 'word'
   

# Generated at 2022-06-17 23:11:22.305662
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'target') == 'word'
    assert structure.html_attribute_value('a', 'rel') == 'word'
    assert structure.html_attribute_value('a', 'type') == 'word'
    assert structure.html_attribute_value('a', 'media') == 'word'
    assert structure.html_attribute_value('a', 'download') == 'word'
    assert structure.html_attribute_value('a', 'hreflang') == 'word'
    assert structure.html_attribute_value('a', 'ping') == 'url'
    assert structure.html_attribute_value('a', 'coords') == 'word'
    assert structure.html_attribute_value

# Generated at 2022-06-17 23:11:31.056488
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value() in HTML_CONTAINER_TAGS.keys()
    assert structure.html_attribute_value(tag='a') in HTML_CONTAINER_TAGS['a']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']

# Generated at 2022-06-17 23:11:35.453259
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value() is not None
    assert structure.html_attribute_value(tag='a') is not None
    assert structure.html_attribute_value(attribute='href') is not None
    assert structure.html_attribute_value(tag='a', attribute='href') is not None
    assert structure.html_attribute_value(tag='a', attribute='href') is not None
    assert structure.html_attribute_value(tag='a', attribute='href') is not None
    assert structure.html_attribute_value(tag='a', attribute='href') is not None
    assert structure.html_attribute_value(tag='a', attribute='href') is not None
    assert structure.html_attribute_value(tag='a', attribute='href') is not None

# Generated at 2022-06-17 23:11:43.647083
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value()
    assert structure.html_attribute_value(tag='a')
    assert structure.html_attribute_value(tag='a', attribute='href')
    assert structure.html_attribute_value(tag='a', attribute='href')
    assert structure.html_attribute_value(tag='a', attribute='href')
    assert structure.html_attribute_value(tag='a', attribute='href')
    assert structure.html_attribute_value(tag='a', attribute='href')
    assert structure.html_attribute_value(tag='a', attribute='href')
    assert structure.html_attribute_value(tag='a', attribute='href')
    assert structure.html_attribute_value(tag='a', attribute='href')

# Generated at 2022-06-17 23:12:07.649052
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:12:08.688702
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    for i in range(100):
        assert structure.css_property()


# Generated at 2022-06-17 23:12:09.705138
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() in CSS_PROPERTIES


# Generated at 2022-06-17 23:12:18.439253
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value()
    assert structure.html_attribute_value(tag='a', attribute='href')
    assert structure.html_attribute_value(tag='a', attribute='rel')
    assert structure.html_attribute_value(tag='a', attribute='target')
    assert structure.html_attribute_value(tag='a', attribute='type')
    assert structure.html_attribute_value(tag='a', attribute='media')
    assert structure.html_attribute_value(tag='a', attribute='hreflang')
    assert structure.html_attribute_value(tag='a', attribute='sizes')
    assert structure.html_attribute_value(tag='a', attribute='charset')
    assert structure.html_attribute_value(tag='a', attribute='rev')
    assert structure.html

# Generated at 2022-06-17 23:12:19.683601
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:12:22.882887
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSProperty
    from mimesis.providers.structure import Structure
    structure = Structure()
    css_property = structure.css_property()
    assert css_property in CSSProperty.__members__.values()


# Generated at 2022-06-17 23:12:30.589550
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    assert structure.html_attribute_value()
    assert structure.html_attribute_value('a')
    assert structure.html_attribute_value('a', 'href')
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:12:31.318280
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    print(s.css_property())


# Generated at 2022-06-17 23:12:41.509226
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'target') == '_blank'
    assert s.html_attribute_value('a', 'rel') == 'nofollow'
    assert s.html_attribute_value('a', 'type') == 'text/html'
    assert s.html_attribute_value('a', 'ping') == 'url'
    assert s.html_attribute_value('a', 'media') == 'all'
    assert s.html_attribute_value('a', 'hreflang') == 'en'
    assert s.html_attribute_value('a', 'type') == 'text/html'
    assert s.html_attribute_value('a', 'charset') == 'utf-8'

# Generated at 2022-06-17 23:12:49.347181
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'class') == 'word'
    assert structure.html_attribute_value('a', 'style') == 'css'
    assert structure.html_attribute_value('a', 'target') == '_blank'
    assert structure.html_attribute_value('a', 'rel') == 'nofollow'
    assert structure.html_attribute_value('a', 'title') == 'word'
    assert structure.html_attribute_value('a', 'id') == 'word'
    assert structure.html_attribute_value('a', 'lang') == 'en'
    assert structure.html_attribute_value('a', 'dir') == 'ltr'
    assert structure.html_attribute_value

# Generated at 2022-06-17 23:13:19.654228
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'rel') == 'word'
    assert s.html_attribute_value('a', 'target') == 'word'
    assert s.html_attribute_value('a', 'type') == 'word'
    assert s.html_attribute_value('a', 'media') == 'word'
    assert s.html_attribute_value('a', 'hreflang') == 'word'
    assert s.html_attribute_value('a', 'charset') == 'word'
    assert s.html_attribute_value('a', 'rev') == 'word'
    assert s.html_attribute_value('a', 'shape') == 'word'
    assert s.html_attribute_