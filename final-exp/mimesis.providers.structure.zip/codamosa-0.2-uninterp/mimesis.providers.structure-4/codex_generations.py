

# Generated at 2022-06-17 23:06:26.535500
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:06:38.049314
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'target') == '_blank'
    assert s.html_attribute_value('a', 'type') == 'word'
    assert s.html_attribute_value('a', 'rel') == 'word'
    assert s.html_attribute_value('a', 'media') == 'word'
    assert s.html_attribute_value('a', 'hreflang') == 'word'
    assert s.html_attribute_value('a', 'type') == 'word'
    assert s.html_attribute_value('a', 'ping') == 'url'
    assert s.html_attribute_value('a', 'coords') == 'word'
    assert s.html_attribute_

# Generated at 2022-06-17 23:06:42.795907
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value() != None
    assert structure.html_attribute_value('a') != None
    assert structure.html_attribute_value('a', 'href') != None
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'class') == 'word'
    assert structure.html_attribute_value('a', 'style') == 'css'
    assert structure.html_attribute_value('a', 'target') == '_blank'
    assert structure.html_attribute_value('a', 'rel') == 'nofollow'
    assert structure.html_attribute_value('a', 'title') == 'word'
    assert structure.html_attribute_value('a', 'download') == 'word'

# Generated at 2022-06-17 23:06:53.143132
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'target') == 'word'
    assert structure.html_attribute_value('a', 'class') == 'css'
    assert structure.html_attribute_value('a', 'rel') == 'word'
    assert structure.html_attribute_value('a', 'type') == 'word'
    assert structure.html_attribute_value('a', 'media') == 'word'
    assert structure.html_attribute_value('a', 'download') == 'word'
    assert structure.html_attribute_value('a', 'hreflang') == 'word'
    assert structure.html_attribute_value('a', 'ping') == 'word'

# Generated at 2022-06-17 23:06:55.834859
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:07:06.421441
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value()
    assert structure.html_attribute_value(tag='a')
    assert structure.html_attribute_value(tag='a', attribute='href')
    assert structure.html_attribute_value(tag='a', attribute='rel')
    assert structure.html_attribute_value(tag='a', attribute='target')
    assert structure.html_attribute_value(tag='a', attribute='type')
    assert structure.html_attribute_value(tag='abbr')
    assert structure.html_attribute_value(tag='abbr', attribute='title')
    assert structure.html_attribute_value(tag='address')
    assert structure.html_attribute_value(tag='area')
    assert structure.html_attribute_value(tag='area', attribute='alt')
    assert structure.html_

# Generated at 2022-06-17 23:07:08.040078
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    css_property = structure.css_property()
    assert isinstance(css_property, str)


# Generated at 2022-06-17 23:07:20.659844
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:07:30.378436
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value() in HTML_CONTAINER_TAGS.keys()
    assert structure.html_attribute_value(tag='a') in HTML_CONTAINER_TAGS['a']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']

# Generated at 2022-06-17 23:07:41.258520
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'class') == 'word'
    assert s.html_attribute_value('a', 'style') == 'css'
    assert s.html_attribute_value('a', 'target') == '_blank'
    assert s.html_attribute_value('a', 'rel') == 'nofollow'
    assert s.html_attribute_value('a', 'title') == 'word'
    assert s.html_attribute_value('a', 'id') == 'word'
    assert s.html_attribute_value('a', 'name') == 'word'
    assert s.html_attribute_value('a', 'lang') == 'en'

# Generated at 2022-06-17 23:08:00.993882
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    print(s.css_property())


# Generated at 2022-06-17 23:08:02.910303
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:08:13.495943
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value()
    assert s.html_attribute_value('a', 'href')
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_

# Generated at 2022-06-17 23:08:20.738359
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value() != None
    assert structure.html_attribute_value('a') != None
    assert structure.html_attribute_value('a', 'href') != None
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute

# Generated at 2022-06-17 23:08:29.140318
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'rel') == 'word'
    assert structure.html_attribute_value('a', 'target') == '_blank'
    assert structure.html_attribute_value('a', 'type') == 'word'
    assert structure.html_attribute_value('a', 'download') == 'word'
    assert structure.html_attribute_value('a', 'hreflang') == 'word'
    assert structure.html_attribute_value('a', 'media') == 'word'
    assert structure.html_attribute_value('a', 'ping') == 'url'
    assert structure.html_attribute_value('a', 'referrerpolicy') == 'word'
    assert structure.html_

# Generated at 2022-06-17 23:08:38.989499
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'target') == '_blank'
    assert structure.html_attribute_value('a', 'rel') == 'nofollow'
    assert structure.html_attribute_value('a', 'type') == 'text/css'
    assert structure.html_attribute_value('a', 'media') == 'screen'
    assert structure.html_attribute_value('a', 'charset') == 'utf-8'
    assert structure.html_attribute_value('a', 'name') == 'word'
    assert structure.html_attribute_value('a', 'class') == 'css'
    assert structure.html_attribute_value('a', 'id') == 'css'

# Generated at 2022-06-17 23:08:40.356565
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:08:50.449560
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:08:52.203134
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() in CSS_PROPERTIES

# Generated at 2022-06-17 23:08:55.131707
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = 'a'
    attribute = 'href'
    value = structure.html_attribute_value(tag, attribute)
    assert value == 'http://www.example.com'


# Generated at 2022-06-17 23:09:21.945871
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'target') == '_blank'
    assert s.html_attribute_value('a', 'rel') == 'nofollow'
    assert s.html_attribute_value('a', 'type') == 'text/html'
    assert s.html_attribute_value('a', 'hreflang') == 'en'
    assert s.html_attribute_value('a', 'media') == 'all'
    assert s.html_attribute_value('a', 'download') == 'word'
    assert s.html_attribute_value('a', 'ping') == 'url'
    assert s.html_attribute_value('a', 'coords') == 'url'

# Generated at 2022-06-17 23:09:29.894772
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value() is not None
    assert structure.html_attribute_value('a') is not None
    assert structure.html_attribute_value('a', 'href') is not None
    assert structure.html_attribute_value('a', 'href') != ''
    assert structure.html_attribute_value('a', 'href') != ' '
    assert structure.html_attribute_value('a', 'href') != '  '
    assert structure.html_attribute_value('a', 'href') != '   '
    assert structure.html_attribute_value('a', 'href') != '    '
    assert structure.html_attribute_value('a', 'href') != '     '
    assert structure.html_attribute_value('a', 'href') != '      '
    assert structure.html_attribute

# Generated at 2022-06-17 23:09:36.012440
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'rel') == 'word'
    assert structure.html_attribute_value('a', 'target') == 'word'
    assert structure.html_attribute_value('a', 'type') == 'word'
    assert structure.html_attribute_value('button', 'autofocus') == 'word'
    assert structure.html_attribute_value('button', 'disabled') == 'word'
    assert structure.html_attribute_value('button', 'form') == 'word'
    assert structure.html_attribute_value('button', 'formaction') == 'url'

# Generated at 2022-06-17 23:09:42.100137
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value() in HTML_CONTAINER_TAGS.keys()
    assert structure.html_attribute_value(tag='a') in HTML_CONTAINER_TAGS['a']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']
    assert structure.html_attribute_value(tag='a', attribute='href') in ['url', 'word']

# Generated at 2022-06-17 23:09:45.280471
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    css_property = s.css_property()
    assert css_property is not None
    assert isinstance(css_property, str)
    assert len(css_property) > 0


# Generated at 2022-06-17 23:09:52.328797
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'target') == '_blank'
    assert structure.html_attribute_value('a', 'rel') == 'nofollow'
    assert structure.html_attribute_value('a', 'type') == 'text/html'
    assert structure.html_attribute_value('a', 'media') == 'all'
    assert structure.html_attribute_value('a', 'hreflang') == 'en'
    assert structure.html_attribute_value('a', 'charset') == 'utf-8'
    assert structure.html_attribute_value('a', 'rev') == 'made'

# Generated at 2022-06-17 23:09:55.435160
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value() in HTML_CONTAINER_TAGS.keys()
    assert s.html_attribute_value(tag='a') in HTML_CONTAINER_TAGS['a']
    assert s.html_attribute_value(tag='a', attribute='href') in ['url', 'word']

# Generated at 2022-06-17 23:10:02.556237
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('a', 'href') == 'url'
    assert s.html_attribute_value('a', 'target') == 'word'
    assert s.html_attribute_value('a', 'rel') == 'word'
    assert s.html_attribute_value('a', 'type') == 'word'
    assert s.html_attribute_value('a', 'media') == 'word'
    assert s.html_attribute_value('a', 'hreflang') == 'word'
    assert s.html_attribute_value('a', 'ping') == 'url'
    assert s.html_attribute_value('a', 'coords') == 'word'
    assert s.html_attribute_value('a', 'shape') == 'word'
    assert s.html_attribute_value

# Generated at 2022-06-17 23:10:03.766856
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() in CSS_PROPERTIES.keys()


# Generated at 2022-06-17 23:10:14.483189
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import HTMLElementAttribute
    from mimesis.enums import HTMLElementTag
    from mimesis.providers.structure import Structure
    structure = Structure()
    assert structure.html_attribute_value(HTMLElementTag.A, HTMLElementAttribute.HREF) != None
    assert structure.html_attribute_value(HTMLElementTag.A, HTMLElementAttribute.HREF) != ''
    assert structure.html_attribute_value(HTMLElementTag.A, HTMLElementAttribute.HREF) != ' '
    assert structure.html_attribute_value(HTMLElementTag.A, HTMLElementAttribute.HREF) != '   '

# Generated at 2022-06-17 23:10:34.738475
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() == 'background-color: #f4d3a1'
