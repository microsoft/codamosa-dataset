

# Generated at 2022-06-17 23:06:40.133856
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import HTMLElementAttribute
    from mimesis.enums import HTMLElementType
    from mimesis.providers.structure import Structure
    structure = Structure()
    assert structure.html_attribute_value(HTMLElementType.A, HTMLElementAttribute.HREF) == 'http://www.example.com'
    assert structure.html_attribute_value(HTMLElementType.A, HTMLElementAttribute.TARGET) == '_blank'
    assert structure.html_attribute_value(HTMLElementType.A, HTMLElementAttribute.REL) == 'nofollow'
    assert structure.html_attribute_value(HTMLElementType.A, HTMLElementAttribute.TYPE) == 'text/html'

# Generated at 2022-06-17 23:06:43.958847
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-17 23:06:45.122130
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    assert structure.css_property() in CSS_PROPERTIES

# Generated at 2022-06-17 23:06:55.976744
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test method html_attribute_value of class Structure."""
    structure = Structure()
    assert structure.html_attribute_value() is not None
    assert structure.html_attribute_value() != ''
    assert structure.html_attribute_value('a', 'href') is not None
    assert structure.html_attribute_value('a', 'href') != ''
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:07:06.540757
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'rel') == 'word'
    assert structure.html_attribute_value('a', 'target') == 'word'
    assert structure.html_attribute_value('a', 'type') == 'word'
    assert structure.html_attribute_value('a', 'download') == 'word'
    assert structure.html_attribute_value('a', 'hreflang') == 'word'
    assert structure.html_attribute_value('a', 'media') == 'word'
    assert structure.html_attribute_value('a', 'ping') == 'url'

# Generated at 2022-06-17 23:07:07.863013
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() == 'background-color: #f4d3a1'

# Generated at 2022-06-17 23:07:11.686915
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = 'a'
    attribute = 'href'
    value = structure.html_attribute_value(tag, attribute)
    assert value == 'http://www.example.com'

# Generated at 2022-06-17 23:07:21.658105
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'

# Generated at 2022-06-17 23:07:30.650921
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    print(s.html_attribute_value('a', 'href'))
    print(s.html_attribute_value('a', 'target'))
    print(s.html_attribute_value('a', 'rel'))
    print(s.html_attribute_value('a', 'type'))
    print(s.html_attribute_value('a', 'media'))
    print(s.html_attribute_value('a', 'hreflang'))
    print(s.html_attribute_value('a', 'download'))
    print(s.html_attribute_value('a', 'ping'))
    print(s.html_attribute_value('a', 'coords'))
    print(s.html_attribute_value('a', 'charset'))

# Generated at 2022-06-17 23:07:41.469130
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value()
    assert structure.html_attribute_value('a')
    assert structure.html_attribute_value('a', 'href')
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'
    assert structure.html_attribute_value('a', 'href') == 'url'