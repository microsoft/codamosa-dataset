

# Generated at 2022-06-12 02:36:46.595621
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() == 'background-color:#f4d3a1'
    assert s.css_property() == 'background-color:#f4d3a1'
    assert s.css_property() == 'background-color:#f4d3a1'


# Generated at 2022-06-12 02:36:50.707574
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value(tag='link', attribute='href')=='http://www.hughes.com/'


# Generated at 2022-06-12 02:37:00.440731
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import HtmlTag
    from mimesis.enums import HtmlAttribute
    from mimesis.enums import HtmlAttrType

    tag = HtmlTag.DIV
    attribute = HtmlAttribute.TITLE
    attr_type = HtmlAttrType.WORD

    structure = Structure()
    result = structure.html_attribute_value(tag.value, attribute.value)
    # result of execution of method html_attribute_value
    assert len(result.split(' ')) == 1
    # result of execution of method html_attribute_value
    assert attr_type.value in result.split(' ')[0]
    #  result of execution of method html_attribute_value
    assert result.split(' ')[0].isupper()

# Generated at 2022-06-12 02:37:01.453634
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    print(s.css_property())

# Generated at 2022-06-12 02:37:02.442254
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    struct = Structure()
    assert isinstance(struct.css_property(), str)

# Generated at 2022-06-12 02:37:05.701818
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    print(structure.html_attribute_value())


# Generated at 2022-06-12 02:37:09.318031
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    a = Structure()
    assert isinstance(a.css_property(),str) and len(a.css_property()) > 0


# Generated at 2022-06-12 02:37:11.626674
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    for _ in range(10):
        assert Structure().css_property() in CSS_PROPERTIES

# Generated at 2022-06-12 02:37:21.996633
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """ Test the method html_attribute_value of class Structure.
    :return: True
    """
    structure = Structure('en')
    structure.html_attribute_value("a", "class")
    structure.html_attribute_value("a", "id")
    structure.html_attribute_value("a", "href")
    structure.html_attribute_value("a", "target")
    structure.html_attribute_value("a", "data-*")
    structure.html_attribute_value("a", "ping")
    structure.html_attribute_value("a", "rel")
    structure.html_attribute_value("a", "media")
    structure.html_attribute_value("a", "hreflang")
    structure.html_attribute_value("a", "type")


# Generated at 2022-06-12 02:37:28.890681
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    sd = Structure()
    result_1 = sd.html_attribute_value('_tag', 'align')
    assert result_1 in ['left', 'right', 'center']

    result_2 = sd.html_attribute_value('_tag', 'align')
    assert result_2 in ['left', 'right', 'center']


# Generated at 2022-06-12 02:37:42.611634
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    strct = Structure()
    property = strct.css_property()
    assert type(property) is str


# Generated at 2022-06-12 02:37:46.975100
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.builtins import RussiaSpecProvider

    loc = RussiaSpecProvider()
    s = Structure(loc)
    assert 'background-color: #f4d3a1' == s.css_property()

# Generated at 2022-06-12 02:37:50.774195
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Testing of method html_attribute_value of class Structure"""
    from mimesis.providers.structure import Structure
    structure = Structure('en')
    assert structure.html_attribute_value()
    assert structure.html_attribute_value('a')
    assert structure.html_attribute_value('a', 'href')

# Generated at 2022-06-12 02:37:55.064015
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    a = "Designed precisely for the cadets"
    for _ in range(100):
        result = structure.html_attribute_value(tag='a', attribute='href') 
        a += result
    assert a != "Designed precisely for the cadets"

# Generated at 2022-06-12 02:38:02.633351
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSProperty
    from mimesis.enums import Color
    from mimesis.enums import URL
    from mimesis.enums import SizeUnit
    str_commands = Structure()
    assert isinstance(str_commands.css_property(), str)
    assert isinstance(str_commands.css_property(CSSProperty('color')), str)
    assert isinstance(str_commands.css_property(CSSProperty('background-color')), str)
    assert isinstance(str_commands.css_property(CSSProperty('background-color'),Color('red')), str)
    assert isinstance(str_commands.css_property(CSSProperty('margin-left'),SizeUnit('rem')), str)


# Generated at 2022-06-12 02:38:05.359773
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s=Structure()
    res=s.css_property()
    print(res)
  

# Generated at 2022-06-12 02:38:12.933732
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    for tag, dic in HTML_CONTAINER_TAGS.items():
        for attr, data in dic.items():
            value = s.html_attribute_value(tag, attr)
            if type(value) == str:
                assert len(value) != 0
            else:
                assert type(value) in [int, bool]


# Generated at 2022-06-12 02:38:14.691626
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # pick a random css_property
    s = Structure()
    css_property = s.css_property()
    assert isinstance(css_property, str), 'css_property should be str'


# Generated at 2022-06-12 02:38:21.646237
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.data import HTML_CONTAINER_TAGS
    tag_name = 'a'
    attribute = 'href'
    value = 'url'
    Structure_test = Structure(seed = 12345)
    Structure_test.html_attribute_value(tag_name, attribute) == value

# Generated at 2022-06-12 02:38:37.102916
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    # Given
    a = Structure()

    # When
    def case(tag: str, attribute: str):
        return a.html_attribute_value(tag, attribute)

    # Then
    assert isinstance(case('img', 'alt'), str)
    assert isinstance(case('a', 'href'), str)
    assert isinstance(case('a', 'target'), str)
    assert isinstance(case('div', 'class'), str)
    assert isinstance(case('div', 'id'), str)
    assert isinstance(case('div', 'style'), str)

# Generated at 2022-06-12 02:39:01.296637
# Unit test for method css_property of class Structure
def test_Structure_css_property():

    structure = Structure(seed=12345)
    structure_css = structure.css_property()
    assert structure_css == 'animation-iteration-count: 1'  # noqa: WPS432

# Generated at 2022-06-12 02:39:10.690768
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    struture = Structure()
    for i in range(10):
        tag = 'a'
        attribute = 'class'
        res = struture.html_attribute_value(tag, attribute)
        # print(res)
        assert isinstance(res, str)
    for i in range(10):
        tag = 'a'
        attribute = 'href'
        res = struture.html_attribute_value(tag, attribute)
        # print(res)
        assert isinstance(res, str)
    for i in range(10):
        tag = 'a'
        attribute = 'title'
        res = struture.html_attribute_value(tag, attribute)
        # print(res)
        assert isinstance(res, str)
    for i in range(10):
        tag = 'img'

# Generated at 2022-06-12 02:39:18.246327
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    fmt = '<{tag} {attrs}>{content}</{tag}>'
    text = Text()
    structure = Structure()
    
    for i in range(10):
        tag = text.word()
        attrs = []
        for j in range(1, 5):
            attrs.append(text.word())
        content = text.sentence()
        result = fmt.format(tag=tag, attrs=structure.html_attribute_value(tag, attrs), content=content)
        assert result != fmt.format(tag=tag, attrs=structure.html_attribute_value(tag, attrs), content=content)

# Generated at 2022-06-12 02:39:20.496145
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    Provider = Structure(seed=42)
    attribute_value = Provider.html_attribute_value()
    assert attribute_value is not None

# Generated at 2022-06-12 02:39:27.861758
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    answer = Structure(seed=1).html_attribute_value()
    assert answer == 'href="https://www.gift.com"'
    answer = Structure(seed=1).html_attribute_value(tag='a')
    assert answer == 'href="https://www.gift.com"'
    answer = Structure(seed=1).html_attribute_value(tag='a', attribute='href')
    assert answer == 'https://www.gift.com'
    answer = Structure(seed=1).html_attribute_value(tag='nav', attribute='class')
    assert answer == 'c'


# Generated at 2022-06-12 02:39:33.846325
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    tag_name = "a"
    attribute = "style"
    assert (HTML_CONTAINER_TAGS[tag_name][attribute]) == "css"

    tag_name = "img"
    attribute = "sizes"
    assert (HTML_CONTAINER_TAGS[tag_name][attribute]) == ["any", "", 256]

    tag_name = "a"
    attribute = "href"
    assert (HTML_CONTAINER_TAGS[tag_name][attribute]) == "url"

# Generated at 2022-06-12 02:39:36.743838
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st = Structure('en')
    result = st.css_property()
    print("CSS property:", result)



# Generated at 2022-06-12 02:39:39.914700
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    struct = Structure()
    prop = struct.css_property()
    assert isinstance(prop, str)


# Generated at 2022-06-12 02:39:42.679727
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Тест для метода html_attribute_value класса Structure"""
    structure = Structure()
    attribute_value = structure.html_attribute_value('div', 'align')

    assert attribute_value in ['left', 'right', 'center', 'justify']



# Generated at 2022-06-12 02:39:58.781937
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    for i in range(30):
        tag = 'a'
        attribute = 'href'
        value = Structure().html_attribute_value(tag, attribute)
        assert value in ['http://www.inboundphones.com/potential', 'http://www.inboundphones.com/jerseys', 'http://www.inboundphones.com/investors']

