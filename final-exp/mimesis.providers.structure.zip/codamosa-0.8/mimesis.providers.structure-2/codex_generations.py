

# Generated at 2022-06-12 02:36:49.860964
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Create a Structure object
    st = Structure()
    # Call the method that we want to test
    tag = st.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    attr = st.random.choice(list(HTML_CONTAINER_TAGS[tag]))
    st.html_attribute_value(tag, attr)

# Generated at 2022-06-12 02:36:58.902680
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test method html_attribute_value from class Structure."""
    structure = Structure(seed=0)
    tag1 = 'meta'
    attribute1 = 'name'
    tag2 = 'meta'
    attribute2 = 'content'
    tag3 = 'div'
    attribute3 = 'class'
    assert structure.html_attribute_value(tag1, attribute1) == 'description'
    assert structure.html_attribute_value(tag2, attribute2) == 'The content of the meta element describes the document. It is optional and useful only if the meta element has a name attribute.'
    assert structure.html_attribute_value(tag3, attribute3) == 'select'

# Generated at 2022-06-12 02:37:00.543862
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure(seed=0)
    assert s.css_property() == 'border-style: solid'


# Generated at 2022-06-12 02:37:02.095882
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    Structure_ = Structure(seed=355)
    assert Structure_.css_property() == 'display: inline-block'


# Generated at 2022-06-12 02:37:12.009734
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    obj = Structure()
    obj.html_attribute_value('a', 'href')

    obj.html_attribute_value(None, 'id')
    obj.html_attribute_value('p', None)
    obj.html_attribute_value(None, None)
    obj.html_attribute_value('div', 'class')
    obj.html_attribute_value('img', 'class')
    obj.html_attribute_value('span', 'class')

# Generated at 2022-06-12 02:37:14.465935
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    res = Structure().html_attribute_value()
    assert res is not None
    assert type(res) == str
test_Structure_html_attribute_value()


# Generated at 2022-06-12 02:37:23.711135
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis import Structure
    from mimesis.enums import Case
    print('\n*** Testing class Structure: method html_attribute_value')
    structure = Structure('en')
    # tag and attribute are not provided as arguments
    tag, attribute = None, None
    print('Testing Structure.html_attribute_value() with tag = {}, attribute = {}'.format(tag, attribute))
    print(structure.html_attribute_value(tag, attribute))
    # tag is provided as argument
    tag = 'a'
    print('\nTesting Structure.html_attribute_value() function with tag = {}'.format(tag))
    print('\n' + structure.html_attribute_value(tag))
    # attribute is provided as argument
    attribute = 'download'

# Generated at 2022-06-12 02:37:26.472973
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert Structure().css_property() == "position: relative"
    assert Structure().css_property() == "position: absolute"


# Generated at 2022-06-12 02:37:31.212984
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    property = structure.css_property().split(':')[0].strip()
    assert property in CSS_PROPERTIES


# Generated at 2022-06-12 02:37:52.043869
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure(seed=4)
    assert structure.html_attribute_value('a', 'class') == '12'
    assert structure.html_attribute_value('a', 'href') == 'text-extension.html'
    assert structure.html_attribute_value(
        'a', 'title') == 'font-family: monospace'
    assert structure.html_attribute_value('b', 'title') == 'height: 93px'
    assert structure.html_attribute_value('textarea', 'disabled') == 'true'
    assert structure.html_attribute_value(
        'textarea', 'readonly') == 'false'
    assert structure.html_attribute_value('textarea', 'required') == 'true'
    assert structure.html_attribute_value('textarea', 'title') == 'css'
    assert structure.html

# Generated at 2022-06-12 02:38:16.876201
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    locale = 'ru'
    seed = 0
    T = Structure(locale, seed)
    # Unit test for parameter tag

    # tag is None
    attribute = 'class'
    __res = T.html_attribute_value(None, attribute)
    __exp = 'span'
    assert __res == __exp, 'Incorrect value of parameter tag'

    # tag is not None
    tag = 'header'
    __res = T.html_attribute_value(tag, attribute)
    __exp = 'header'
    assert __res == __exp, 'Incorrect value of parameter tag'

    # Unit test for parameter attribute

    # attribute is None
    tag = 'header'
    __res = T.html_attribute_value(tag, None)
    __exp = 'word'

# Generated at 2022-06-12 02:38:27.661401
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """ Unit test for method html_attribute_value of class Structure """
    # Arrange
    structure1 = Structure()
    structure2 = Structure()
    structure3 = Structure()

    # Act
    structure1.html_attribute_value()
    structure1.html_attribute_value(tag = 'a')
    structure1.html_attribute_value(attribute = 'href')
    structure1.html_attribute_value('a', 'href')
    structure2.html_attribute_value(tag = 'img')
    structure2.html_attribute_value(attribute = 'src')
    structure2.html_attribute_value('img', 'src')
    structure3.html_attribute_value(tag = 'div')
    structure3.html_attribute_value(attribute = 'class')

# Generated at 2022-06-12 02:38:29.681711
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    tmp = Structure()
    for i in range(1, 5):
        assert tmp.css_property() != ''


# Generated at 2022-06-12 02:38:31.038096
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    result = Structure().html_attribute_value(tag='table',attribute='cellspacing')
    assert isinstance(result, str)

# Generated at 2022-06-12 02:38:34.972962
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure(seed=12345)
    assert s.css_property() == 'text-indent: -1.5em'


# Generated at 2022-06-12 02:38:37.102842
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert Structure.css_property() in CSS_PROPERTIES
    

# Generated at 2022-06-12 02:38:42.843790
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """
    Test for method html_attribute_value of class Structure
    """
    from mimesis.providers.structure import Structure
    structure = Structure()
    tag = None
    attr = None
    html_attribute_value = structure.html_attribute_value(tag, attr)
    assert isinstance(html_attribute_value, str)

# Generated at 2022-06-12 02:38:45.308758
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert Structure().css_property() in CSS_PROPERTIES.keys()


# Generated at 2022-06-12 02:38:51.730790
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()

# Generated at 2022-06-12 02:39:00.757943
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    c = Structure()
    print(c.html_attribute_value(tag='div', attribute='style'))
    print(c.html_attribute_value(tag='img', attribute='src'))
    print(c.html_attribute_value(tag='a', attribute='href'))
    print(c.html_attribute_value(tag='a', attribute='id'))
    print(c.html_attribute_value(tag='a', attribute='target'))
    print(c.html_attribute_value(tag='a', attribute='title'))
    print(c.html_attribute_value(tag='a', attribute='class'))
