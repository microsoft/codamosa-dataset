

# Generated at 2022-06-12 02:36:44.662738
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    css = Structure()
    a = css.css_property()
    print(a)


# Generated at 2022-06-12 02:36:48.057014
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    strc = Structure()
    assert isinstance(strc.html_attribute_value(), str)

# Generated at 2022-06-12 02:36:52.614926
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    s = Structure()
    assert(s.html_attribute_value("div", "class"))
    #assert(s.html_attribute_value("div", "onclick"))

# Generated at 2022-06-12 02:36:57.050282
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    str = Structure()
    new_str=str.html_attribute_value()
    assert isinstance(new_str, str)
    new_str=str.html_attribute_value(None,None)
    assert isinstance(new_str, str)

# Test for method css of class Structure

# Generated at 2022-06-12 02:37:03.882769
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    html_result = '<{tag} {attrs}>{content}</{tag}>'
    attrs = []
    tag = 'a'
    content = 'Hello World!'
    structure = Structure()
    attr1 = 'href'
    value1 = 'https://mimesis.rtfd.io'
    attrs.append('{}="{}"'.format(attr1, value1))
    attr2 = 'title'
    value2 = 'Hello World!'
    attrs.append('{}="{}"'.format(attr2, value2))
    html_result_old = html_result.format(
        tag=tag,
        attrs=' '.join(attrs),
        content=content,
    )
    html_result_new = structure.html()

# Generated at 2022-06-12 02:37:08.444313
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Set a seed value
    seed = 101
    structure = Structure(seed=seed)
    # Test CSS property
    assert type(structure.css_property()) == str

# Generated at 2022-06-12 02:37:16.236949
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.data import HTML_CONTAINER_TAGS
    from mimesis.providers.structure import Structure
    structure = Structure()
    result = structure.html_attribute_value()
    assert isinstance(result, str)
    result2 = structure.html_attribute_value('div', 'id')
    assert isinstance(result2, str)
    result3 = structure.html_attribute_value('div', 'title')
    assert isinstance(result3, str)
    result4 = structure.html_attribute_value('a', 'class')
    assert isinstance(result4, str)
    result5 = structure.html_attribute_value('a', 'href')
    assert isinstance(result5, str)
    result6 = structure.html_attribute_value('p', 'align')

# Generated at 2022-06-12 02:37:18.357988
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    css_property = structure.css_property()
    print(css_property)


# Generated at 2022-06-12 02:37:25.110709
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    import  re
    mimesis = Structure()
    test_result = mimesis.html_attribute_value(tag='img')
    assert re.match(r'(?:alt|height|width)="[a-zA-Z0-9-:]+"', test_result)

    test_result = mimesis.html_attribute_value(tag='div', attribute='class')
    assert re.match(r'class="[a-zA-Z0-9-:]+"', test_result)

    test_result = mimesis.html_attribute_value(tag='a', attribute='href')
    assert re.match(r'href="[a-zA-Z0-9:-]+"', test_result)


# Generated at 2022-06-12 02:37:29.098499
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    print(s.html_attribute_value(tag='div', attribute='class'))
    # Output: class="results"



# Generated at 2022-06-12 02:37:47.446985
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    test = Structure()
    tag = test.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    attr = test.random.choice(list(HTML_CONTAINER_TAGS[tag]))
    print(test.html_attribute_value(tag, attr))

# Generated at 2022-06-12 02:37:50.477708
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure.

    Method to test:
    (1) html_attribute_value
    """

    structure = Structure()
    structure.html_attribute_value('a', 'href')

# Generated at 2022-06-12 02:37:54.529998
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    for tag_name in list(HTML_CONTAINER_TAGS):
        for attr in list(HTML_CONTAINER_TAGS[tag_name]):
            result = s.html_attribute_value(tag_name, attr)
            assert result
            continue

# Generated at 2022-06-12 02:37:58.073799
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property()[0:s.css_property().index(':')] in CSS_PROPERTIES


# Generated at 2022-06-12 02:38:08.556394
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    import re
    import pdb
    # pdb.set_trace()
    structure = Structure(seed=123)

    tag = 'a'
    attribute = 'href'
    result = structure.html_attribute_value(tag, attribute)
    assert re.fullmatch('^[A-Za-z0-9\-\.]+\.[A-Za-z]{2,}$', result)

    tag = 'a'
    attribute = 'target'
    result = structure.html_attribute_value(tag, attribute)
    assert result in ['_blank','_parent','_self','_top']

    tag = 'a'
    attribute = 'rel'
    result = structure.html_attribute_value(tag, attribute)

# Generated at 2022-06-12 02:38:14.742533
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure_provider = Structure()
    for tag, attributes in HTML_CONTAINER_TAGS.items():
        for attribute, value in attributes.items():
            if value == 'css':
                assert len(structure_provider.html_attribute_value(tag, attribute).split(':')) == 2
                continue
            if value == 'url':
                assert len(structure_provider.html_attribute_value(tag, attribute).split('.')) == 2
                continue
            assert len(structure_provider.html_attribute_value(tag, attribute)) > 0

# Generated at 2022-06-12 02:38:17.939410
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert Structure().css_property()
test_Structure_css_property()


# Generated at 2022-06-12 02:38:24.004075
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    val = s.html_attribute_value('a', 'href')
    assert isinstance(val, str)
    assert len(val) > 0
    val = s.html_attribute_value()
    assert isinstance(val, str)
    assert len(val) > 0


# Generated at 2022-06-12 02:38:37.281464
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    expected = s.random.choice(HTML_CONTAINER_TAGS["form"]["method"])
    actual = s.html_attribute_value("form", "method")
    assert expected == actual, "test_Structure_html_attribute_value failed"

# Generated at 2022-06-12 02:38:39.055376
# Unit test for method css_property of class Structure
def test_Structure_css_property():
  structure = Structure()
  assert structure.css_property() != structure.css_property()

# Generated at 2022-06-12 02:39:10.909028
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    import re

    # Instantiate class
    structure = Structure()

    # Generate a random snippet of CSS that assigns value to a property.
    property = structure.css_property()

    # Check if matches regex of CSS Properties
    assert re.match("^(\w+-)?\w+\s*:\s*[^;]+(;\s*|\s*)$", property) != None

    # Generate a random snippet of CSS that assigns value to a property.
    property = structure.css_property()

    # Check if matches regex of CSS Properties
    assert re.match("^(\w+-)?\w+\s*:\s*[^;]+(;\s*|\s*)$", property) != None

    # Generate a random snippet of CSS that assigns value to a property.
    property = structure.css_property()



# Generated at 2022-06-12 02:39:12.647149
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure().html_attribute_value() != NotImplementedError

# Generated at 2022-06-12 02:39:14.533413
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struc = Structure('en', seed=123)
    assert struc.html_attribute_value('a', 'href') == 'https://mimesis.name/'

# Generated at 2022-06-12 02:39:17.849580
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test for method html_attribute_value of class Structure."""
    tag = 'p'
    attribute = 'class'
    st = Structure()
    assert st.html_attribute_value(tag, attribute) == 'css'

# Generated at 2022-06-12 02:39:21.308536
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value(tag='div',attribute='id') == 'word'
    assert s.html_attribute_value(tag='div',attribute='class') == 'word'

# Generated at 2022-06-12 02:39:22.660651
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st = Structure()
    assert True in [val in str(st.css_property()) for val in CSS_PROPERTIES.keys()]

# Generated at 2022-06-12 02:39:25.714877
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    cssProperty = s.css_property()
    assert ':' in cssProperty
    assert ';' not in cssProperty


# Generated at 2022-06-12 02:39:29.940521
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert type(s.html_attribute_value('a', 'href')) == str
    assert type(s.html_attribute_value('div', 'className')) == str
    try:
        s.html_attribute_value('c', 'd')
        assert 1 == 0
    except NotImplementedError:
        assert 1 == 1


# Generated at 2022-06-12 02:39:34.748643
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    s = Structure()
    s.html_attribute_value('div', 'id')
    s.html_attribute_value('img', 'alt')
    s.html_attribute_value('a', 'title')
    s.html_attribute_value('span', 'class')

# Generated at 2022-06-12 02:39:42.890000
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSPropertyType
    from mimesis.enums import CSSPropertyName
    from random import Random
    r = Random()
    s = Structure()
    property_ = s.css_property()
    property_name = property_.split(":")[0].strip()
    assert property_name in [s.name for s in CSSPropertyName], \
        "Property name should be one of the values from CSSPropertyName"
    property_type = property_.split(":")[1].strip()
    assert property_type in [s.value for s in CSSPropertyType], \
        "Property type should be one of the values from CSSPropertyType"
