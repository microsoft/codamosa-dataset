

# Generated at 2022-06-12 02:36:55.497297
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    class A(Structure):
        def css_property(self):
            return super(A,self).css_property()

    structure = A()
    for _ in range(10):
        print(structure.css_property())


# Generated at 2022-06-12 02:37:11.100826
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    attrs = []
    for tag in list(HTML_CONTAINER_TAGS.keys()):
        attrs.extend(HTML_CONTAINER_TAGS[tag]) # type: ignore
    for attr in attrs:
        assert isinstance(structure.html_attribute_value(tag, attr), str)

# Generated at 2022-06-12 02:37:16.722328
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    css_property = structure.css_property()
    assert isinstance(css_property, str)
    assert css_property.count(':') == 1
    assert css_property.count(';') == 0
    assert not css_property.startswith(':')
    assert not css_property.startswith(';')


# Generated at 2022-06-12 02:37:18.768961
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    csd = Structure().css_property()
    assert csd == "background-color: #fae56f"


# Generated at 2022-06-12 02:37:20.626662
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    prop = Structure()
    print(prop.css_property())

# Generated at 2022-06-12 02:37:32.397152
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()

    expected_type_str = ["indent", "white-space", "direction"]
    expected_type_str_default_attribute = ["float", "clear"]
    expected_type_str_default_attribute_absolute = ["position"]
    expected_type_str_default_attribute_border_width = ["border-width"]
    expected_type_str_default_attribute_border_width_negative = ["z-index"]
    expected_type_int = ["top", "right", "bottom", "left", "width", "height"]
    expected_type_word = ["id", "class"]
    expected_type_css = ["style"]
    expected_type_url = ["href"]

    for i in range(100):
        for attribute in expected_type_str:
            s.random.seed(i)

# Generated at 2022-06-12 02:37:33.944771
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct = Structure()
    struct.seed(26)
    assert struct.html_attribute_value('a', 'href') == 'https://www.pisces.com'


# Generated at 2022-06-12 02:37:36.284066
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Tests that the structure provider returns a css property
    from mimesis.providers import Structure
    structure = Structure()
    assert isinstance(structure.css_property(), str)



# Generated at 2022-06-12 02:37:41.749300
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Structure.html_attribute_value() test."""
    structure = Structure(seed=12345)
    a = structure.html_attribute_value(tag='div', attribute='align')
    b = structure.html_attribute_value(tag='span', attribute='class')
    c = structure.html_attribute_value(tag='img', attribute='src')
    d = structure.html_attribute_value(tag='input', attribute='type')
    e = structure.html_attribute_value(tag='blockquote', attribute='cite')
    f = structure.html_attribute_value(tag='q', attribute='cite')
    g = structure.html_attribute_value(tag='table', attribute='border')
    h = structure.html_attribute_value(tag='td', attribute='colspan')
    i = structure.html_attribute_

# Generated at 2022-06-12 02:37:43.057441
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    Structure().css_property()

# Generated at 2022-06-12 02:38:06.647425
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure(seed = 1)
    css_property = structure.css_property()
    assert isinstance(css_property, str)


# Generated at 2022-06-12 02:38:16.585929
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st = Structure()
    prop = st.css_property()
    assert len(prop.split(':')) == 2

# Generated at 2022-06-12 02:38:27.595989
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    # Test random css property
    assert any([s.css_property() == 'font-family: "Times New Roman"' for i in range(100)])
    assert any([s.css_property() == 'font-family: Arial' for i in range(100)])
    assert any([s.css_property() == 'font-family: "Calibri"' for i in range(100)])
    assert any([s.css_property() == 'font-family: "Sans Serif"' for i in range(100)])
    assert any([s.css_property() == 'font-family: "Comic Sans MS"' for i in range(100)])
    assert any([s.css_property() == 'font-family: "Courier New"' for i in range(100)])

# Generated at 2022-06-12 02:38:29.973934
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value(tag = 'div', attribute = 'class') in list(HTML_CONTAINER_TAGS['div'])


# Generated at 2022-06-12 02:38:32.221401
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    x = Structure()
    css_property_generated = x.css_property()
    assert type(css_property_generated) == str
    assert ':' in css_property_generated
    assert ';' not in css_property_generated


# Generated at 2022-06-12 02:38:35.428184
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    if (Structure.html_attribute_value() != Structure.html_attribute_value()):
        raise AssertionError

# Generated at 2022-06-12 02:38:45.207380
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = 'input'
    attribute = 'type'
    value = structure.html_attribute_value(tag, attribute)
    assert type(value) == str
    tag = 'div'
    attribute = 'dirname'
    value = structure.html_attribute_value(tag, attribute)
    assert type(value) == str
    tag = 'span'
    attribute = 'lang'
    value = structure.html_attribute_value(tag, attribute)
    assert type(value) == str
    tag = 'a'
    attribute = 'target'
    value = structure.html_attribute_value(tag, attribute)
    assert type(value) == str


# Generated at 2022-06-12 02:38:47.181505
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct = Structure()
    struct.html_attribute_value(tag='a', attribute='href')

# Generated at 2022-06-12 02:38:52.299252
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    pass
    # structure = Structure(seed=3293)
    # print(structure.html_attribute_value('div'))
    # print(structure.html_attribute_value('p'))
    # print(structure.html_attribute_value('div', 'id'))
    # print(structure.html_attribute_value('span', 'id'))
    # assert True


    # structure = Structure(seed=3293)
    # print(structure.html_attribute_value('form'))
    # print(structure.html_attribute_value('div'))
    # print(structure.html_attribute_value('p'))
    # print(structure.html_attribute_value('div', 'id'))
    # print(structure.html_attribute_value('span', 'id'))
   

# Generated at 2022-06-12 02:38:54.766939
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    generator = Structure()
    test = generator.css_property()
    print(test)
