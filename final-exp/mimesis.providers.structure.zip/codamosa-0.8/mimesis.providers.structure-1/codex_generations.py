

# Generated at 2022-06-12 02:37:20.030937
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st = Structure(seed=42)
    for _ in range(100):
        assert st.css_property() == 'background-color: #b2a2ab'
