

# Generated at 2022-06-12 02:37:04.426610
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    temp = Structure()
    assert temp.css_property()


# Generated at 2022-06-12 02:37:09.625041
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.builtins import HTMLContainerTags
    instance = Structure()
    for tag in HTMLContainerTags.keys():
        for attribute in HTMLContainerTags[tag]:
            instance.html_attribute_value(tag, attribute)

# Generated at 2022-06-12 02:37:21.508831
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    css = Structure(seed=2)
    assert css.css_property() == css.css_property() == 'background-color: #9fd480'
    assert css.css_property() == 'font-size: 5em'
    assert css.css_property() == css.css_property() == 'text-align: center'
    assert css.css_property() == 'width: 47px'
    assert css.css_property() == 'height: 89mm'
    assert css.css_property() == 'width: 64%'
    assert css.css_property() == 'width: 3.2cm'
    assert css.css_property() == css.css_property() == 'height: 41%'


# Generated at 2022-06-12 02:37:24.685826
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    foo = Structure()
    val = foo.html_attribute_value("div", "class")
    assert(isinstance(val, str))

# Generated at 2022-06-12 02:37:27.160238
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a', 'href') != None


# Generated at 2022-06-12 02:37:31.416509
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct = Structure(seed=12345)
    result = struct.html_attribute_value("a", "class")
    assert result == "sociis"

# Generated at 2022-06-12 02:37:34.602301
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test method html_attribute_value of class Structure."""
    result = Structure().html_attribute_value(tag="ol",
                                              attribute="reversed")
    assert result in ["true", "false"]

# Generated at 2022-06-12 02:37:38.412691
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct = Structure()
    struct.html_attribute_value('a', 'class')
    struct.html_attribute_value('div', 'class')
    struct.html_attribute_value('span', 'class')
    struct.html_attribute_value('a', 'coords')
    struct.html_attribute_value('div', 'width')
    struct.html_attribute_value('span', 'height')


# Generated at 2022-06-12 02:37:47.398095
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure(seed=42)
    assert s.html_attribute_value(attribute = 'href',
                                  tag = 'a') == 'https://www.google.com'
    assert s.html_attribute_value(attribute = 'href') == 'https://www.google.com'
    assert s.html_attribute_value() == 'http://www.google.com'



# Generated at 2022-06-12 02:37:49.217944
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    provider = Structure()
    provider.html_attribute_value('a', 'href')