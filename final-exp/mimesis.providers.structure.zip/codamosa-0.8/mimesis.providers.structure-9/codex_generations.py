

# Generated at 2022-06-12 02:36:53.752463
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    cssprop = Structure()
    for i in range(10):
        print(cssprop.css_property())


# Generated at 2022-06-12 02:36:58.655655
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test docstring example."""
    s = Structure()
    # Tests the first tag in the list
    a = s.html_attribute_value("a", "href")
    # Tests the last tag in the list
    q = s.html_attribute_value("q", "cite")
    # Tests tag not in list
    b = s.html_attribute_value("b", "class")
    return [a, q, b]


# Generated at 2022-06-12 02:37:01.928585
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert len(s.css_property().split(':'))==2
    assert s.css_property().split(':')[0] in CSS_PROPERTIES.keys()
    assert s.css_property().split(':')[1] in CSS_PROPERTIES.keys()


# Generated at 2022-06-12 02:37:05.219492
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    for tag in list(HTML_CONTAINER_TAGS.keys()) :
        for attribute in list(HTML_CONTAINER_TAGS[tag]) :
            result = Structure().html_attribute_value(tag, attribute)
            if tag == 'a' and attribute == 'href' :
                assert result.find('.') != -1
            print('%s/%s = %s' % (tag, attribute, result))

# Generated at 2022-06-12 02:37:08.252077
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import HTMLElements
    from mimesis.enums import HTMLAttributes
    from mimesis.providers.structure import Structure

    structure = Structure('en')
    tag = HTMLElements.SPAN
    attribute = HTMLAttributes.CLASS

    class_name = structure.html_attribute_value(tag, attribute)
    assert class_name.startswith('select')

# Generated at 2022-06-12 02:37:13.136925
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Unit test for method Structure.css_property."""
    _structure = Structure()
    _css_property = _structure.css_property()
    assert _css_property

    print(repr(_css_property))
    

# Generated at 2022-06-12 02:37:31.080847
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # pylint: disable=C0103
    assert Structure(seed=5).html_attribute_value(
        tag='a', attribute='href') == 'url'
    assert Structure(seed=5).html_attribute_value(
        tag='a', attribute='href') == 'http://www.krona.com/'
    assert Structure(seed=7).html_attribute_value(
        tag='p', attribute='style') == 'word'
    assert Structure(seed=7).html_attribute_value(
        tag='p', attribute='style') == 'mesmerizing'

# Generated at 2022-06-12 02:37:41.356525
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert(Structure().html_attribute_value("link", "href") != None)



# Generated at 2022-06-12 02:37:52.085100
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    import pytest
    from mimesis.exceptions import NotImplementedError

    strt = Structure()

    with pytest.raises(NotImplementedError):
        strt.html_attribute_value(tag='img', attribute='height')

    with pytest.raises(NotImplementedError):
        strt.html_attribute_value(tag='img', attribute='width')

    with pytest.raises(NotImplementedError):
        strt.html_attribute_value(tag='img', attribute='class')

    with pytest.raises(NotImplementedError):
        strt.html_attribute_value(tag='img', attribute='id')


# Generated at 2022-06-12 02:38:01.438535
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    print("Unit test for method html_attribute_value of class Structure:")
    structure = Structure()
    print("structure.html_attribute_value()="+structure.html_attribute_value())
    print("structure.html_attribute_value('a','href')="+structure.html_attribute_value('a','href'))
    print("structure.html_attribute_value('table','style')="+structure.html_attribute_value('table','style'))
    print("structure.html_attribute_value('input','value')="+structure.html_attribute_value('input','value'))
# test_Structure_html_attribute_value()

# Generated at 2022-06-12 02:38:36.603445
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    test_class = Structure()
    # Correctly handles Class Attribute
    assert (test_class.html_attribute_value(tag='div', attribute='class'))
    # Correctly handles Id Attribute
    assert (test_class.html_attribute_value(tag='div', attribute='id'))
    # Correctly handles href Attribute
    assert (test_class.html_attribute_value(tag='a', attribute='href'))
    # Correctly throws error when attribute is not supported
    try:
        test_class.html_attribute_value(tag='div', attribute='test')
    except NotImplementedError:
        assert 1==1
    # Correctly throws error when tag is not supported