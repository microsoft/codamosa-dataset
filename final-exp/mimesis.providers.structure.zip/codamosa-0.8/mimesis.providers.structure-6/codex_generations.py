

# Generated at 2022-06-12 02:37:14.492194
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = 'img'
    attr = 'src'
    assert structure.html_attribute_value(tag, attr) == structure.html_attribute_value()

# Generated at 2022-06-12 02:37:22.025031
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from json import load
    from os.path import exists, join
    from os import getcwd

    try:
        with open(join(getcwd(), 'tests/data.json')) as f:
            json_data = load(f)

            for tag, value in json_data.items():
                st = Structure()
                attr = st.random.choice(list(value.keys()))
                assert exists(st.html_attribute_value(tag, attr))
    except FileNotFoundError:
        pass

# Generated at 2022-06-12 02:37:24.183964
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure('en')
    assert(len(s.css_property().split(': ')) == 2)