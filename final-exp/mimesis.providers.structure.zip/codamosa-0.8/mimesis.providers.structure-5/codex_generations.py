

# Generated at 2022-06-12 02:36:57.184104
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    import random
    structure = Structure(random.seed(1), 'fr')
    css_property = structure.css_property()
    print(css_property)
    assert css_property == 'border-color: #f4d3a1'


# Generated at 2022-06-12 02:36:58.798705
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    css_a = Structure(seed=1)
    assert css_a.css_property() == 'content: attr'

# Generated at 2022-06-12 02:37:00.440290
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    data = Structure(seed=int('0xDECA', 16)).html_attribute_value()
    assert data


# Generated at 2022-06-12 02:37:02.965827
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    locale = 'en'
    provider = Structure(locale)
    provider.seed(0)

    result = provider.css_property()
    assert result == 'font-family: verdana'

    result = provider.css_property()
    assert result == 'left: 77px'

# Generated at 2022-06-12 02:37:14.749008
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test for method html_attribute_value of class Structure."""
    def html_attribute_value_test(tag=None, attribute=None, expected=None):
        """Test for method html_attribute_value of class Structure."""
        result = Structure().html_attribute_value(tag, attribute)
        assert isinstance(result, str) is True
        assert result == expected

    html_attribute_value_test('a', 'href', 'http://example.com')
    html_attribute_value_test('a', 'href')
    html_attribute_value_test('a')
    html_attribute_value_test(expected='http://example.com')
    html_attribute_value_test('img')
    html_attribute_value_test('img', 'src')

# Generated at 2022-06-12 02:37:20.588646
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Check if css_property of class Structure is correct"""
    s = Structure()
    ans = True

    for i in range(100):
        css = s.css_property()
        if css.split(':')[1] == None:
            ans = False
            break

    assert ans == True


# Generated at 2022-06-12 02:37:24.882400
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure(seed=0)
    assert structure.html_attribute_value() == '<body id="hhv">Of the as be</body>'
    assert structure.html_attribute_value('body') == '<body align="center">Directly with for of</body>'
    assert structure.html_attribute_value('body', 'align') == 'center'
    assert structure.html_attribute_value(attribute='align') == 'center'

    try:
        structure.html_attribute_value(tag='div')
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 02:37:31.574803
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    st = Structure(seed=12345)
    assert st.html_attribute_value(tag='img', attribute='alt') == 'I am an image'
    assert st.html_attribute_value(attribute='class') == 'all_the_world'
    assert st.html_attribute_value('a', 'id') == 'nothing'
    assert st.html_attribute_value('img', 'src') == 'http://www.example.com/map1.jpg'

# Generated at 2022-06-12 02:37:38.555263
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.schema import Field, Schema
    from mimesis.enums import Markup, Tags

    tags = {}
    for tag in Markup:
        tags[tag.name] = {}
        for attr, value in tag.value.items():
            tags[tag.name][attr] = value


    schema = Schema(
        tags,
        seed=1000,
    )
    structure = Structure(
        seed=1000,
    )
    result = schema.create(
        structure_cls=Structure,
    )
    print(result)


if __name__ == '__main__':
    print(Structure().html())

# Generated at 2022-06-12 02:37:45.108543
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    tag = s.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    attr = s.random.choice(list(HTML_CONTAINER_TAGS[tag]))
    s.html_attribute_value(tag, attr)