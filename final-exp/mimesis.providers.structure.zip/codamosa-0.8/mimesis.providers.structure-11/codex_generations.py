

# Generated at 2022-06-12 02:37:17.148423
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    #print(structure.css_property())

#Unit test for method css of class Structure

# Generated at 2022-06-12 02:37:20.512000
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    result = s.css_property()
    assert result.count(':') == 1
    assert result[:result.index(':')].strip() in CSS_PROPERTIES

# Generated at 2022-06-12 02:37:23.723386
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    value = structure.css_property()
    return value


# Generated at 2022-06-12 02:37:32.558067
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """
    HTML tags with attributes are constructed by a random manner.

    """
    import unittest.mock
    s = Structure()
    s.random.choice = unittest.mock.MagicMock(name="choice")
    s.random.choice.return_value = "qwerty"

    with unittest.mock.patch('mimesis.providers.structure.Structure.css_property'):
        s.html_attribute_value()



# Generated at 2022-06-12 02:37:39.916549
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    tag = 'li'

    test_attributes = [
        'style', 'class', 'lang', 'id', 'accesskey',
        'title', 'tabindex', 'dir', 'data-*',
    ]

    test_values = {
        'style': 'css',
        'class': 'word',
        'lang': 'word',
        'id': 'word',
        'accesskey': ['\u0031'],
        'title': 'word',
        'tabindex': list(range(1, 100)),
        'dir': ['ltr', 'rtl'],
        'data-*': 'word',
    }

    s = Structure()

    for attribute in test_attributes:
        value = s.html_attribute_value(tag, attribute)
        assert value in test_values[attribute]

# Generated at 2022-06-12 02:37:42.790417
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Test with inherited class BaseDataProvider and method css_property of Structure class
    s = Structure()
    assert s.css_property() is not None