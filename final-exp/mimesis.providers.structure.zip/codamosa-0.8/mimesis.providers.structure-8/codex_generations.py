

# Generated at 2022-06-12 02:37:06.762054
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    cls = Structure('es')
    tag = 'div'
    attribute = 'class'
    value = cls.html_attribute_value(tag, attribute)
    assert value == "dignissim"
    tag = 'div'
    attribute = 'style'
    value = cls.html_attribute_value(tag, attribute)
    assert value == "margin-right: 57px;"
    tag = 'div'
    attribute = 'contenteditable'
    value = cls.html_attribute_value(tag, attribute)
    assert value == "false"
    tag = 'a'
    attribute = 'href'
    value = cls.html_attribute_value(tag, attribute)
    assert value == "http://homepage.com/"

# Generated at 2022-06-12 02:37:13.042551
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure.html_attribute_value('a', 'href') == 'http://mimesis.ru/'
    assert Structure.html_attribute_value('a', 'alt') == 'duck'
    assert Structure.html_attribute_value('a', 'title') == 'Quack Quack'


# Generated at 2022-06-12 02:37:24.685160
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    st = Structure(seed=None)
    prop = st.css_property()
    assert (prop=='color: black') or (prop=='height: 100px')

# Generated at 2022-06-12 02:37:27.159370
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    x = Structure()
    result = x.css_property()
    return True if result != "" else False


# Generated at 2022-06-12 02:37:33.668535
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    test_attributes = [
        ('a', 'href'), 
        ('a', 'id'), 
        ('div', 'class'), 
        ('div', 'id'), 
        ('div', 'style'), 
        ('i', 'class'), 
        ('img', 'alt'), 
        ('img', 'class'), 
        ('img', 'src'), 
        ('p', 'class'), 
        ('p', 'id'), 
        ('p', 'style'), 
        ('span', 'class'), 
        ('span', 'id'), 
        ('span', 'style')
    ]
    structure = Structure()
    for tag, attr in test_attributes:
        assert structure.html_attribute_value(tag, attr) is not None, 'not implemented'

# Generated at 2022-06-12 02:37:39.745637
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.providers.structure import Structure
    structure = Structure(seed=42)
    assert structure.html_attribute_value(tag="video", attribute="height") == "710"
    assert structure.html_attribute_value(tag="div", attribute="title") == "This is a div element"
    assert structure.html_attribute_value(tag="link", attribute="media") == "all"
    assert structure.html_attribute_value(tag="canvas", attribute="id") == "image-canvas"
    assert structure.html_attribute_value(tag="img", attribute="height") == "70"
    assert structure.html_attribute_value(tag="div", attribute="height") == "740"


# Generated at 2022-06-12 02:37:43.121856
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert isinstance(s.html_attribute_value(), str)

if __name__ == "__main__":
    test_Structure_html_attribute_value()

# Generated at 2022-06-12 02:37:53.175571
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    loc = Structure()
    # tag
    tag_list = ['div', 'p', 'img', 'table', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'hr', 'br']
    for tag in tag_list:
        for i in range(10):
            res = loc.html_attribute_value(tag)
            print(res)
            attr_list = HTML_CONTAINER_TAGS[tag]  # type: ignore
            assert(res in attr_list)


# Generated at 2022-06-12 02:37:59.608465
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    import re
    s = Structure()
    l = re.compile('^[a-z]{,20}: [A-Za-z0-9#]{,7};$')
    for _ in range(100):
        result = s.css_property()
        assert l.match(result)


# Generated at 2022-06-12 02:38:04.053510
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    st = Structure()
    attr = st.html_attribute_value(tag='a', attribute='target')
    assert attr in ('_blank', '_parent', '_top', '_self')

