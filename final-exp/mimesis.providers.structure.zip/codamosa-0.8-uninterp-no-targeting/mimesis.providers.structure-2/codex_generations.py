

# Generated at 2022-06-21 16:31:44.820648
# Unit test for constructor of class Structure
def test_Structure():
    """Unit test for constructor of class Structure."""
    structure = Structure()
    assert isinstance(structure, Structure) is True
    assert isinstance(structure, BaseDataProvider) is True


# Generated at 2022-06-21 16:31:50.912100
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure().html_attribute_value(tag='a', attribute='href') == 'http://www.rempel.info/'
    assert Structure().html_attribute_value(tag='a', attribute='charset') == 'utf-8'
    assert Structure().html_attribute_value(tag='a', attribute='class') == 'info-photo'
    assert Structure().html_attribute_value(tag='a', attribute='hreflang') == 'en-US'
    assert Structure().html_attribute_value(tag='a', attribute='media') == 'handheld'


# Generated at 2022-06-21 16:31:52.902132
# Unit test for constructor of class Structure
def test_Structure():
   assert isinstance(Structure, object)


# Generated at 2022-06-21 16:31:57.943782
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(seed = 42)
    css_0 = s.css()
    assert css_0 == '@media print {width: 245px;}'
    css_1 = s.css()
    assert css_1 == '@media print {margin: 515px;}'


# Generated at 2022-06-21 16:32:00.580207
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    res = structure.css()
    # print(res)
    assert res is not None and len(res) > 0


# Generated at 2022-06-21 16:32:09.830272
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    obj = Structure()
    assert (obj.html_attribute_value('a', 'href')  != None)
    assert ( obj.html_attribute_value('a', 'href')  !="")
    assert (obj.html_attribute_value('a', 'class')  != None)
    assert (obj.html_attribute_value('a', 'class')  !="")
    assert (obj.html_attribute_value('a', 'ping')  != None)
    assert (obj.html_attribute_value('a', 'ping')  !="")
    assert (obj.html_attribute_value('a', 'download')  != None)
    assert (obj.html_attribute_value('a', 'download')  !="")
    assert (obj.html_attribute_value('a', 'rel')  != None)

# Generated at 2022-06-21 16:32:12.375472
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    assert s.css()


# Generated at 2022-06-21 16:32:21.962378
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSUnit
    from mimesis.enums import CSSProperty
    from mimesis.enums import HTMLAttribute
    s = Structure('en')
    assert isinstance(s._Structure__random.choice(list(CSSProperty)), str)
    assert isinstance(s._Structure__random.choice(list(CSSProperty)), str)
    assert isinstance(s._Structure__text.word(), str)
    assert isinstance(s.css_property(), str)
    assert isinstance(s._Structure__text.hex_color(), str)
    assert isinstance(s._Structure__random.choice(list(CSSUnit)), str)
    assert isinstance(s._Structure__random.randint(1, 99), int)


# Generated at 2022-06-21 16:32:29.290846
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.data import HTML_CONTAINER_TAGS
    st = Structure('ru')
    for tag in HTML_CONTAINER_TAGS:
        for attr in HTML_CONTAINER_TAGS[tag]:
            assert st.html_attribute_value(tag, attr) != ''
            print(st.html_attribute_value(tag, attr))
            assert st.html_attribute_value(tag=None, attribute=attr) != ''
            assert st.html_attribute_value() != ''


# Generated at 2022-06-21 16:32:31.106580
# Unit test for constructor of class Structure
def test_Structure():
    str1 = Structure()
    assert str1.__class__.__name__ == 'Structure'


# Generated at 2022-06-21 16:32:59.450467
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    provider = Structure()
    prop = provider.css_property()

    assert(prop is not None)
    assert(isinstance(prop, str))

    prop = prop.split(':')
    prop_name = prop[0].strip()
    prop_value = prop[1].strip()

    assert(prop_name is not None and len(prop_name) > 0)
    assert(prop_value is not None and len(prop_value) > 0)


# Generated at 2022-06-21 16:33:00.442020
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s._seed is not None

# Generated at 2022-06-21 16:33:03.156700
# Unit test for method css of class Structure
def test_Structure_css():
    """Method for testing method css of class Structure"""
    print("test_Structure_css:")
    s = Structure()
    s.css()
    print("\n")


# Generated at 2022-06-21 16:33:05.944197
# Unit test for method css of class Structure
def test_Structure_css():
    str = Structure()
    print(str.css())


# Generated at 2022-06-21 16:33:09.022658
# Unit test for method css of class Structure
def test_Structure_css():
    # Initiate class Structure
    structure = Structure()
    structure.seed(1234)
    result = structure.css()
    assert result == 'article {float: left; text-align: left; }'



# Generated at 2022-06-21 16:33:11.780666
# Unit test for constructor of class Structure
def test_Structure():
    class_name = "Structure"
    #TODO: implement test for constructor of class Structure

# Generated at 2022-06-21 16:33:21.782256
# Unit test for method css of class Structure
def test_Structure_css():
    import random
    import string
    k = random.randint(1, len(CSS_PROPERTIES))
    keys = random.sample(list(CSS_PROPERTIES.keys()), k)
    values = random.sample(list(CSS_PROPERTIES.values()), k)
    dict_ = dict(zip(keys, values))
    for i in range(len(dict_)):
        if dict_[keys[i]] in list(CSS_PROPERTIES.keys()):
            dict_[keys[i]] = dict_[ dict_[keys[i]] ]
        elif dict_[keys[i]] in string.ascii_letters:
            dict_[keys[i]] = ''.join(random.choices(string.ascii_letters, k=k))
    base = random.choice

# Generated at 2022-06-21 16:33:32.669969
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure(seed=1)
    assert structure.html_attribute_value('a', 'charset') == 'css'
    assert structure.html_attribute_value('a', 'dataset') == 'css'
    assert structure.html_attribute_value('a', 'href') == 'https://www.cali.com/'
    assert structure.html_attribute_value('a', 'rel') == 'noreferrer'
    assert structure.html_attribute_value('a', 'src') == 'http://bethany.com/'
    assert structure.html_attribute_value('a', 'target') == 'blank'
    assert structure.html_attribute_value('a', 'title') == 'Cum'
    assert structure.html_attribute_value('a', 'type') == 'text/css'

# Generated at 2022-06-21 16:33:38.992409
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struc = Structure()
    result = struc.html_attribute_value('a')
    assert result == '#' or result == 'none'
    result = struc.html_attribute_value('a', 'href')
    assert result == '#' or result == 'none' or result[0:4] == 'http'
    result = struc.html_attribute_value('div', 'class')
    assert result == 'css'
    result = struc.html_attribute_value('div')
    assert result == 'css' or result == 'word'

# Generated at 2022-06-21 16:33:42.555774
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(seed = 42)
    print(s.css())
    print(s.css())
    print(s.css())
    print(s.css())



# Generated at 2022-06-21 16:34:02.764348
# Unit test for method css of class Structure
def test_Structure_css():
    st = Structure()
    print(st.css())
    print(st.css_property())
    print(st.css_property())


# Generated at 2022-06-21 16:34:03.338922
# Unit test for method html of class Structure
def test_Structure_html():
    return Structure().html()

# Generated at 2022-06-21 16:34:12.349160
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure"""
    structure = Structure()
    structure.html_attribute_value('a', 'href')
    structure.html_attribute_value('a', 'rel')
    structure.html_attribute_value('a', 'media')
    try:
        structure.html_attribute_value('doctype', 'html')
        raise AssertionError()
    except NotImplementedError:
        pass
    try:
        structure.html_attribute_value('a', 'doctype')
        raise AssertionError()
    except NotImplementedError:
        pass



# Generated at 2022-06-21 16:34:23.494903
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    struct1 = Structure()

    struct1.html_attribute_value(tag='a', attribute='href')  # OK
    struct1.html_attribute_value(tag='p', attribute='id')  # OK
    struct1.html_attribute_value(tag='a', attribute='target')  # OK
    struct1.html_attribute_value(tag='b', attribute='class')  # OK

    # Has NotImplementedError exception
    struct2 = Structure()
    struct2.html_attribute_value(tag='a', attribute='src')  # KO
    struct2.html_attribute_value(tag='a', attribute='class')  # KO
    struct2.html_attribute_value(tag='img', attribute='href')  # KO
    struct2.html_attribute_value(tag='a', attribute='parent')  # KO

# Generated at 2022-06-21 16:34:25.295087
# Unit test for method css of class Structure
def test_Structure_css():
    st = Structure()
    tag = st.css()
    assert tag != None, "Error in the method css of class Structure"


# Generated at 2022-06-21 16:34:36.277348
# Unit test for method css of class Structure
def test_Structure_css():
    # Test case 1
    # Input = None
    # Expect = 'span #careers {background-color: #b85c11; margin: 15px 0px; padding: 14px; display: block; font-family: "Times New Roman", serif; width: 50px; height: 8px; overflow-wrap: break-word; margin-top: 5px; font-size: 7em;}'
    struct = Structure()
    struct.seed(6)
    assert struct.css() == 'span #careers {background-color: #b85c11; margin: 15px 0px; padding: 14px; display: block; font-family: "Times New Roman", serif; width: 50px; height: 8px; overflow-wrap: break-word; margin-top: 5px; font-size: 7em;}'

    # Test case 2


# Generated at 2022-06-21 16:34:39.289010
# Unit test for method html of class Structure
def test_Structure_html():
    object_structure = Structure(seed=1)
    assert object_structure.html() == '<a href="http://www.bong.com" id="www">' \
                                      'Eligendi sequi laboriosam reprehenderit' \
                                      ' exercitationem. </a>'
    assert object_structure.html(tag='h1', attribute='id') == 'architecto'



# Generated at 2022-06-21 16:34:40.664423
# Unit test for method css_property of class Structure
def test_Structure_css_property():
  structure = Structure()
  assert(True)
  

# Generated at 2022-06-21 16:34:42.769321
# Unit test for method css of class Structure
def test_Structure_css():
    obj = Structure()
    result = obj.css()
    assert isinstance(result, str)
    assert result


# Generated at 2022-06-21 16:34:45.206848
# Unit test for method html of class Structure
def test_Structure_html():
    Structure().html()
    # ↑ output: <div id="" class="" style="border-size: 60px">
    #            Latin pede.
    #            </div>