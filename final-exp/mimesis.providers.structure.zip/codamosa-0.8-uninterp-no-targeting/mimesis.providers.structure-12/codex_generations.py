

# Generated at 2022-06-21 16:31:42.595524
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure is not None


# Generated at 2022-06-21 16:31:44.493304
# Unit test for method html of class Structure
def test_Structure_html():
    print("test html")
    structural = Structure()
    print(structural.html())
    print("#" * 50)


# Generated at 2022-06-21 16:31:47.167750
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure(seed=42)
    for _ in range(1000):
        css = s.css_property()
        print(css)
        assert css.__len__() > 0


# Generated at 2022-06-21 16:31:48.713737
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure('en')
    assert structure.html() == '<p></p>'


# Generated at 2022-06-21 16:31:50.177467
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    res = s.css_property()
    print(res)


# Generated at 2022-06-21 16:31:59.686112
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure(seed=11)
    assert structure.css() == 'dl-title {margin: 6em; background-color: #9cc9ca; color: #cb8a15}'
    assert structure.html() == '<span style="width: 34px; margin: 6px; font-weight: bold" id="driver-item">Mustang is a car</span>'
    assert structure.html_attribute_value('meta', 'http-equiv') == 'vary'
    assert structure.html_attribute_value() == '<body class="truck-text" role="main">Mustang is a car</body>'

# Generated at 2022-06-21 16:32:02.238283
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    assert type(structure.css()) == str
test_Structure_css()


# Generated at 2022-06-21 16:32:07.147787
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    for i in range(20):
        print(s.css_property())
    return True

if __name__ == "__main__":
    # print(test_Structure_css_property())
    s = Structure()
    print(s.html_attribute_value(tag='a', attribute='href'))
    # print(s.css())
    # print(s.html())

# Generated at 2022-06-21 16:32:14.369378
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    css_property = Structure.css_property
    assert css_property() == 'word-break: break-word'
    assert css_property() == 'word-break: break-all'
    assert css_property() == 'word-break: keep-all'
    assert css_property() == 'word-break: initial'
    assert css_property() == 'word-break: inherit'


# Generated at 2022-06-21 16:32:18.665330
# Unit test for method css_property of class Structure
def test_Structure_css_property():
  from mimesis.builtins import RussiaSpecProvider
  from mimesis.enums import Gender
  provider = RussiaSpecProvider(seed=42)
  structure = Structure(provider, seed=42)

  assert structure.css_property() == 'outline-width: 4px'


# Generated at 2022-06-21 16:32:33.993083
# Unit test for method html of class Structure
def test_Structure_html():
    g1 = Structure(seed=0)
    g2 = Structure(seed=0)
    g3 = Structure(seed=1)
    assert g1.html() == g2.html()
    assert g1.html() != g3.html()


# Generated at 2022-06-21 16:32:35.433593
# Unit test for constructor of class Structure
def test_Structure():
    data = Structure()
    assert data.__class__.__name__ == 'Structure'

# Generated at 2022-06-21 16:32:43.906623
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert isinstance(s.html_attribute_value(), str)
    assert s.html_attribute_value(tag = 'span', attribute = 'class').startswith('class=')
    assert s.html_attribute_value(tag = 'span', attribute = 'id').startswith('id=')
    assert s.html_attribute_value(tag = 'span', attribute = 'lang').startswith('lang=')
    assert s.html_attribute_value(tag = 'div', attribute = 'role').startswith('role=')
    assert s.html_attribute_value(tag = 'div', attribute = 'style').startswith('style=')
    assert s.html_attribute_value(tag = 'div', attribute = 'title').startswith('title=')
    assert s.html_attribute_value

# Generated at 2022-06-21 16:32:45.355458
# Unit test for constructor of class Structure
def test_Structure():
  st = Structure()
  for i in range(10):
    print(st.html())

# Generated at 2022-06-21 16:32:49.730836
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    s.html_attribute_value('a', 'accept')
    s.html_attribute_value('a', 'accesskey')
    s.html_attribute_value('a', 'align')
    s.html_attribute_value('button')
    s.html_attribute_value()

# Generated at 2022-06-21 16:32:51.027805
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    print(s.css_property())

# Generated at 2022-06-21 16:32:57.773601
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    test_css_property_result = []
    test_css_property_result.append('float: center')
    test_css_property_result.append('list-style: square')
    test_css_property_result.append('border-radius: 3.2em')
    test_css_property_result.append('perspective: 99px')
    test_css_property_result.append('color: #eb1ab2')
    test_css_property_result.append('opacity: 0.56')
    test_css_property_result.append('z-index: 0')
    test_css_property_result.append('margin-left: auto')
    test_css_property_result.append('position: fixed')
    test_css_property_result.append('border-width: 0')
    test_css_

# Generated at 2022-06-21 16:33:00.668620
# Unit test for method html of class Structure
def test_Structure_html():
    data = Structure().html()
    print("test_Structure_html: " + data)
    assert len(data) > 0


# Generated at 2022-06-21 16:33:05.944326
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """ Unit test for method html_attribute_value of class Structure.
    """
    s = Structure(seed=0)
    assert s.html_attribute_value() == 'background: #ff00ff'
    assert s.html_attribute_value('html') == 'lang="en"'
    assert s.html_attribute_value('html', 'lang') == 'en'
    assert s.html_attribute_value('head', 'charset') == 'UTF-8'


# Generated at 2022-06-21 16:33:07.020295
# Unit test for constructor of class Structure
def test_Structure():
    st = Structure()
    assert(st.__class__.__name__ == 'Structure')


# Generated at 2022-06-21 16:33:34.938625
# Unit test for method css of class Structure
def test_Structure_css():
    # Unit test for method css of class Structure
    result = Structure().css()
    print(result)
                                


# Generated at 2022-06-21 16:33:42.632168
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    for _ in range(100):
        css = s.css()
        prop = css.split(' {')[1].split('}')[0].split(';')
        print(css)
        # Conditions for testing
        assert css.split(' {')[0] in CSS_SELECTORS + list(HTML_CONTAINER_TAGS.keys()) + HTML_MARKUP_TAGS
        for p in prop:
            assert p.split(':')[0] in CSS_PROPERTIES.keys()


# Generated at 2022-06-21 16:33:44.827418
# Unit test for constructor of class Structure
def test_Structure():
    
    sha256 = Structure()
    assert isinstance(sha256, Structure)



# Generated at 2022-06-21 16:33:51.828050
# Unit test for constructor of class Structure
def test_Structure():
    # Init the class
    s = Structure()
    # css
    css = s.css()
    assert css is not None
    # css property
    css_property = s.css_property()
    assert css_property is not None
    # html
    html = s.html()
    assert html is not None
    # html_attribute_value
    html_attribute_value = s.html_attribute_value()
    assert html_attribute_value is not None

# Generated at 2022-06-21 16:33:53.134277
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    assert isinstance(structure.html(), str),\
        "Structure's html function failed"

# Generated at 2022-06-21 16:33:54.821030
# Unit test for method css of class Structure
def test_Structure_css():
    provider = Structure('en')
    css_str = provider.css()
    assert css_str


# Generated at 2022-06-21 16:34:00.744305
# Unit test for constructor of class Structure
def test_Structure():
    # 1a. When we call Structure, we expect no exceptions to be raised
    structure = Structure()
    # 1b. When the seed is set, we expect the same seed to be used
    seed = 'test'
    structure_test_1b = Structure(seed=seed)
    assert structure_test_1b._seed == seed


# Generated at 2022-06-21 16:34:09.416222
# Unit test for method css of class Structure
def test_Structure_css():
    import random
    import re
    import string
    structure = Structure(random.Random(11), 'en')
    css = structure.css()

    # Check that css is a string
    assert isinstance(css, str)

    # Check that css is not empty
    assert css != ''

    # Check that css string start with curly brace
    assert re.search('^\{[\w\W]*\}', css).group(0) == css

    # Check that css string has at least one property
    assert len(re.findall('\w+: \w+;', css)) >= 1

    # Check that css string has at most six properties
    assert len(re.findall('\w+: \w+;', css)) <= 6


# Generated at 2022-06-21 16:34:10.381994
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    print(s.html())


# Generated at 2022-06-21 16:34:12.211798
# Unit test for method css of class Structure
def test_Structure_css():
    css = Structure.css()
    assert type(css) is str
    assert len(css) >= 10