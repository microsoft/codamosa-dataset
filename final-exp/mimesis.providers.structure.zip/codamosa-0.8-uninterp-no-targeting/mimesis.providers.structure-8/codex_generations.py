

# Generated at 2022-06-21 16:31:53.404130
# Unit test for constructor of class Structure
def test_Structure():
    """Unit test for constructor of class Structure."""
    st = Structure()
    assert bool(st)
    assert isinstance(st, Structure)


# Generated at 2022-06-21 16:31:56.635142
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    result = s.html()
    assert len(result) > 0
    assert type(result) == str
# Test for method html_attribute_value

# Generated at 2022-06-21 16:31:58.412415
# Unit test for constructor of class Structure
def test_Structure():
    st = Structure()
    assert st.seed > 0
    assert st.random is not None


# Generated at 2022-06-21 16:32:00.704145
# Unit test for constructor of class Structure
def test_Structure():
    from mimesis.enums import DataField
    provider = Structure('en')
    assert provider

# Test for method named css of class Structure

# Generated at 2022-06-21 16:32:06.843064
# Unit test for method html of class Structure
def test_Structure_html():
    # Arrange
    from mimesis.enums import Tags
    from mimesis.providers.structure import Structure

    provider = Structure()
    tags_string = ' '.join(map(str, dir(Tags)))

    # Act
    html = provider.html()
    tags_present = tags_string in html

    # Assert
    assert tags_present is True, 'HTML tags are not present in {0}'.format(html)

# Generated at 2022-06-21 16:32:15.237918
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.network import Network
    from mimesis.providers.structure import Structure
    from mimesis.data import HTML_CONTAINER_TAGS

    for tag in HTML_CONTAINER_TAGS:
        structure = Structure()
        for attr in HTML_CONTAINER_TAGS[tag]:
            structure.html_attribute_value(tag, attr)

# Generated at 2022-06-21 16:32:22.395824
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSUnit
    struct = Structure('en')
    result = struct.css_property()
    assert ';' not in result
    assert ': ' in result
    prop, val = result.split(': ')
    assert len(prop) <= len(list(CSS_PROPERTIES.keys()))
    if val.endswith('px') or val.endswith('em') or val.endswith('%'):
        assert CSSUnit.PX.value in result or CSSUnit.EM.value in result \
               or CSSUnit.PERCENT.value in result
    if val.endswith('rem'):
        assert CSSUnit.REM.value in result

# Generated at 2022-06-21 16:32:25.238179
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()
    print("Create Structure")
    print("class Structure")
    print("method: __init__")
    print("normal case")
    assert(struct is not None)
    print("passed\n")


# Generated at 2022-06-21 16:32:36.649246
# Unit test for method html of class Structure
def test_Structure_html():
    pp = Structure()
    for _ in range(10):
        print(pp.html())
    ## Example Output ##
    # <span class="select" id="careers">
    # Spiteful foxes are created with the built-in function open_port.
    # </span>
    # <p dir="auto" class="random-text" id="guarantee">
    # Jaunty chickens sleep.
    # </p>
    # <mark lang="es" class="random-text" title="guarantee">
    # Weak kangaroos do not sleep.
    # </mark>
    # <em style="margin: 6px 0px;">
    # Lazy oxen love.
    # </em>
    # <a lang="es" href="http://www.brown.com/" style="padding-left: 83

# Generated at 2022-06-21 16:32:39.918724
# Unit test for constructor of class Structure
def test_Structure():
    try:
        Structure()
    except Exception:
        assert False
    else:
        assert True
