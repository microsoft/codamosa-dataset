

# Generated at 2022-06-21 16:31:33.912079
# Unit test for constructor of class Structure
def test_Structure():
    obj=Structure('en')
    assert obj is not None


# Generated at 2022-06-21 16:31:44.493261
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure_test = Structure()
    assert structure_test.html_attribute_value('a', 'target') \
        in ['blank', 'self', 'parent', 'top']
    assert structure_test.html_attribute_value('a', 'href') \
        == structure_test.__inet.home_page()
    assert structure_test.html_attribute_value('a', 'download') \
        == structure_test.__text.word()
    assert structure_test.html_attribute_value('a', 'title') \
        == structure_test.__text.word()
    assert structure_test.html_attribute_value('blockquote', 'cite') \
        == structure_test.__inet.home_page()
    assert structure_test.html_attribute_

# Generated at 2022-06-21 16:31:52.351212
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSProperty
    from mimesis.providers.text import Text
    from mimesis.providers.structure import Structure
    from mimesis.providers.internet import Internet
    from itertools import product
    from random import randint
    from collections import defaultdict
    from hashlib import md5
    from os import system
    text = Text('en')
    inet = Internet()
    strc = Structure()
    test_cases = {}
    for val in CSSProperty:
        if isinstance(val.value, list):
            test_cases[val] = [val.value]
        elif val.value == 'color':
            test_cases[val] = [text.hex_color()]

# Generated at 2022-06-21 16:31:54.569258
# Unit test for method html of class Structure
def test_Structure_html():
    assert '<span class="select" id="careers">' in Structure.Structure().html()


# Generated at 2022-06-21 16:31:56.376161
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    s.css()  # returns a random CSS snippet

# Generated at 2022-06-21 16:31:59.789480
# Unit test for method css of class Structure
def test_Structure_css():
    # Fix random seed
    np.random.seed(2)

    # Create an instance
    structure = Structure()

    # The return value should be a string
    assert isinstance(structure.css(), str)


# Generated at 2022-06-21 16:32:04.277268
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    attributes = {}
    for tag in HTML_CONTAINER_TAGS:
        for attribute in HTML_CONTAINER_TAGS[tag]:
            attributes[(tag, attribute)]=(attribute,Structure().html_attribute_value(tag,attribute))
    return attributes


# Generated at 2022-06-21 16:32:05.235363
# Unit test for constructor of class Structure
def test_Structure():
    pass


# Generated at 2022-06-21 16:32:12.109421
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    # Create a provider
    rus_spec = RussiaSpecProvider(locale='ru', seed=None)

    random_structure = Structure(locale='en', seed=None)
    # Get HTML tag names
    html_tags = list(HTML_CONTAINER_TAGS.keys())

    # Check that the methods return correct values
    for i in range(1000):
        tag = random_structure.random.choice(html_tags)
        assert random_structure.html_attribute_value(tag=tag,
                                                     attribute='css') == \
               random_structure.css_property()
        assert random_structure.html_attribute_value(tag=tag,
                                                     attribute='word') == \
               random

# Generated at 2022-06-21 16:32:14.038002
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure(seed=123)
    structure.html()
    assert type(structure.html()) == str

# Generated at 2022-06-21 16:32:35.644930
# Unit test for method css of class Structure
def test_Structure_css():
    # setup
    from mimesis.enums import CSSSelectors, CSSSizeUnits, HTMLElementTags

    structure_obj = Structure()
    # exercise
    css = structure_obj.css()
    # verify
    result_selector = css.split(' ')[0]
    assert result_selector in list(CSSSelectors)
    result_tag = css.split(' ')[1]
    assert result_tag in list(HTMLElementTags) or result_tag in CSSSelectors
    assert css.endswith('}')
    assert css.startswith('{')

    test_prop_name = structure_obj.css_property().split(':')[0]
    assert test_prop_name in list(CSSSelectors)
    test_prop_value = structure_obj.css_property

# Generated at 2022-06-21 16:32:41.216247
# Unit test for constructor of class Structure
def test_Structure():
    dataProvider = Structure()
    print(dataProvider.css())
    print(dataProvider.html())
    print(dataProvider.html_attribute_value())
    print(dataProvider.html_attribute_value(tag="img", attribute="src"))
    print(dataProvider.html_attribute_value(tag="link", attribute="href"))
    print(dataProvider.html_attribute_value(attribute="href"))
    print(dataProvider.html_attribute_value(tag="link"))


# Generated at 2022-06-21 16:32:42.601931
# Unit test for constructor of class Structure
def test_Structure():
    x = Structure()
    x.html()



# Generated at 2022-06-21 16:32:44.759464
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    assert structure is not None


# Generated at 2022-06-21 16:32:47.415335
# Unit test for method html of class Structure
def test_Structure_html():
    assert Structure().html() == '<nav class="summarize" id="transportations">Firings are the way the micro-kernel communicates.</nav>'


# Generated at 2022-06-21 16:32:55.890192
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.providers.base import BaseVariant

    test_val = Structure(seed=42)

    def test_value(tag, attr, value):
        assert test_val.html_attribute_value(tag, attr) == value

    test_value('div', 'class', 'css')
    test_value('div', 'class', 'css')
    test_value('div', 'class', 'css')
    test_value('div', 'class', 'css')


    test_value('img', 'alt', 'word')
    test_value('img', 'alt', 'word')
    test_value('img', 'alt', 'word')
    test_value('img', 'alt', 'word')

    test_value('img', 'src', 'url')


# Generated at 2022-06-21 16:32:59.350272
# Unit test for method css_property of class Structure
def test_Structure_css_property():

    structure = Structure()
    css_property = structure.css_property()
    assert (css_property in str(CSS_PROPERTIES.values()))


# Generated at 2022-06-21 16:33:03.197828
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure(seed=1)
    assert s.css() == 'div {width: 8px; background-color: #f4d3a1; width: 89px; height: 57px; margin: 1px; color: #f4d3a1; padding: 8px}'


# Generated at 2022-06-21 16:33:06.690292
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    result = structure.css_property()
    print(result)


# Generated at 2022-06-21 16:33:11.340099
# Unit test for constructor of class Structure
def test_Structure():
    #Test with seed
    s= Structure( seed=12345)
    assert s.html_attribute_value()=='<h3 accept-charset="utf-8">Trunk</h3>'
    
    #Test without seed
    s= Structure()
    assert s.html_attribute_value()!='<h3 accept-charset="utf-8">Trunk</h3>'
    

# Generated at 2022-06-21 16:33:36.015728
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure(seed=1234)
    for _ in range(0, 10):
        print(structure.css())


# Generated at 2022-06-21 16:33:37.976860
# Unit test for constructor of class Structure
def test_Structure():
    if __name__ == "__main__":

        strture = Structure(locale='cs')
        html_tag = Structure.html(strture)

# Generated at 2022-06-21 16:33:38.868750
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    s.html()

# Generated at 2022-06-21 16:33:42.439596
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    for i in range(100):
        assert len(s.css_property()) > 6 and len(s.css_property()) < 40


# Generated at 2022-06-21 16:33:44.614433
# Unit test for constructor of class Structure
def test_Structure():
    test = Structure()
    #assert test is not None
    print('Test Structure ok')


# Generated at 2022-06-21 16:33:47.768491
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure(seed=12345)
    sample = structure.css()
    assert len(sample) != 0


# Generated at 2022-06-21 16:33:58.650781
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import Attribute

    # Assert that if tag is None, class choose one of the predefined random
    structure = Structure('en', seed=42)
    tag = structure.html_attribute_value()
    assert tag in HTML_CONTAINER_TAGS

    # Assert that if attribute is None, class choose one of the predefined random
    structure = Structure('en', seed=42)
    attr = structure.html_attribute_value(tag)
    assert attr in HTML_CONTAINER_TAGS[tag]

    # Assert that if tag and attribute are specified, it returns the appropriate value
    structure = Structure('en', seed=42)
    attr = structure.html_attribute_value('td', 'rowspan')
    assert attr == Attribute.WORD.value


# Generated at 2022-06-21 16:34:07.868719
# Unit test for constructor of class Structure
def test_Structure():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.randoms import Random

    seed = b'\x15\xa4\x81\xac\x1d\xda$\xef\x87\xa4\xfb\x11\x0e\xfd'
    p = Person('en', Gender.MALE, seed=seed) # creating an instance of class Person
    r = Random(seed=seed) # creating an instance of class Random
    provider = Structure(seed=seed) # creating an instance of class Structure
    # test with class Structure
    assert provider.html_attribute_value() == 'style="height: 0.36em;"'

# Generated at 2022-06-21 16:34:09.348204
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    struc = Structure()
    print(struc.css_property())


# Generated at 2022-06-21 16:34:14.832813
# Unit test for method html of class Structure
def test_Structure_html():
    obj = Structure()
    """
    <div class="lipsum" id="reg" title="Lorem ipsum dolor sit amet.">
    Perspiciatis dolorem sint quidem eaque.
    </div>
    """
    print(obj.html())

    """
    <span class="ipsum" id="ab" title="Quaerat sequi similique quam">
    </span>
    """
    print(obj.html())

    """
    <p align="left" class="lipsum" id="magnam">
    </p>
    """
    print(obj.html())

    """
    <span class="ipsum" id="quia">
    </span>
    """
    print(obj.html())


# Generated at 2022-06-21 16:34:45.632339
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure(seed=42)
    assert structure.html() == '<link rel="stylesheet" href="http://www.cogtib.com">'
    assert structure.html() == '<p lang="en">metu</p>'

# Generated at 2022-06-21 16:34:49.488595
# Unit test for method html of class Structure
def test_Structure_html():
    '''Testing method html of class Structure'''
    html = Structure().html()
    assert html[0]=='<'
    assert html[-1]=='>'

# Generated at 2022-06-21 16:34:50.502603
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()
    struct.css()

# Generated at 2022-06-21 16:34:52.283930
# Unit test for method html of class Structure
def test_Structure_html():
    """Test html method of Structure class."""
    s = Structure()
    assert s.html() == s.html()

# Generated at 2022-06-21 16:35:01.351306
# Unit test for method html_attribute_value of class Structure

# Generated at 2022-06-21 16:35:04.839474
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    loc1 = Structure()
    loc2 = Structure()
    assert loc1.css_property() == loc2.css_property()
    assert isinstance(loc1.css_property(), str)


# Generated at 2022-06-21 16:35:13.436803
# Unit test for constructor of class Structure
def test_Structure():
    ob1 = Structure()
    assert ob1.__text.__class__ == Text
    assert ob1.__inet.__class__ == Internet

    # test __init__ method with one parameter
    ob2 = Structure(locale='en')
    assert ob2.__text.__class__ == Text

    # test __init__ method with 2 parameter
    ob3 = Structure(locale='en', seed=1)
    assert ob3.__inet.__class__ == Internet

    # test __init__ method with 3 parameter
    ob4 = Structure(locale='en', seed=1, random=1)
    assert ob4.__class__ == Structure



# Generated at 2022-06-21 16:35:17.302972
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    data = Structure()
    s = data.css_property()
    t = data.css_property()
    assert s == t


# Generated at 2022-06-21 16:35:21.576318
# Unit test for method html of class Structure
def test_Structure_html():
    def test_html_method_of_Structure_class():
        strct = Structure()
        data = strct.html()
        assert len(data) > 0, 'Failed try of using method html()'

    test_html_method_of_Structure_class()


# Generated at 2022-06-21 16:35:25.194033
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """
    Test Structure.css_property()
    """
    s = Structure(seed=100)
    assert s.css_property() == 'color: #f7e347'
    assert s.css_property() == 'position: initial'