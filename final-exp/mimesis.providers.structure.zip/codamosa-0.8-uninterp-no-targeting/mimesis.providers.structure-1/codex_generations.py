

# Generated at 2022-06-21 16:31:48.911344
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    #test with all lists
    assert type(Structure().css_property())==str
    
    

# Generated at 2022-06-21 16:31:54.058264
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    for _ in range(10):
        s.html()

    assert(s.html_attribute_value('a', 'class') == 'css')
    assert(s.html_attribute_value('a', 'href') == 'url')


# Generated at 2022-06-21 16:31:56.819709
# Unit test for method html of class Structure
def test_Structure_html():
    html = Structure('en').html()
    assert isinstance(html, str)

    assert not HTML_CONTAINER_TAGS == ""

# Generated at 2022-06-21 16:32:00.579377
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    a = Structure()
    assert len(a.html_attribute_value()) > 0     # tag = random
    assert len(a.html_attribute_value('a')) > 0  # tag = a
    assert len(a.html_attribute_value('span', 'class')) > 0

# Generated at 2022-06-21 16:32:03.489480
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure(seed=123)
    assert s.css_property() == 'font-family: serif'



# Generated at 2022-06-21 16:32:05.189671
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('en')
    assert type(structure.css_property()) == str


# Generated at 2022-06-21 16:32:10.763030
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
  import os,sys,inspect
  currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
  parentdir = os.path.dirname(currentdir)
  sys.path.insert(0,parentdir) 
  from HTML_STRUCTURE import HTML_CONTAINER_TAGS
  from mimesis import Structure
  structure = Structure()

  for tag in list(HTML_CONTAINER_TAGS):
    for attribute in list(HTML_CONTAINER_TAGS[tag]):
      structure.html_attribute_value(tag, attribute)

# Generated at 2022-06-21 16:32:12.272484
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure('en')
    s = structure.html()
    assert isinstance(s, str)
    assert len(s) > 0
    print('s',s)

# Generated at 2022-06-21 16:32:15.837572
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """
    Test the method html_attribute_value of class Structure
    """
    test = Structure()
    assert len(test.html_attribute_value(
        tag='style',
        attribute='type',
    )) == 1, 'error'

# Generated at 2022-06-21 16:32:20.311574
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure(seed=4)
    for tag in HTML_CONTAINER_TAGS:
        for attribute in HTML_CONTAINER_TAGS[tag]:
            html_attribute_value = structure.html_attribute_value(
                tag=tag, attribute=attribute
            )
            assert isinstance(html_attribute_value, str)