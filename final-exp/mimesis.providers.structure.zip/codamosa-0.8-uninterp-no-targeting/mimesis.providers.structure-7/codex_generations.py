

# Generated at 2022-06-21 16:31:48.344772
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    assert type(s.css()) == str


# Generated at 2022-06-21 16:32:00.480020
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import Language
    from mimesis.localization import get_localizer

    data = {
        'class': 'css_class',
        'id': 'css_id',
        'href': 'url',
        'src': 'url',
        'rel': ['alternate', 'canonical', 'stylesheet', 'shortcut icon'],
        'type': ['text/css', 'text/html', 'image/gif', 'image/png'],
    }
    HTML_CONTAINER_TAGS['a'] = data
    HTML_CONTAINER_TAGS['span'] = data
    structure = Structure(seed=11)
    structure.html()
    assert structure is not None

    localizer = get_localizer(Language.EN)

# Generated at 2022-06-21 16:32:02.613704
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    result = s.css()
    assert(result != '')

# Generated at 2022-06-21 16:32:06.785807
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Check for random snippet of CSS that assigns value
     to a property."""
    prop_1 = Structure().css_property()
    prop_2 = Structure().css_property()
    prop_3 = Structure().css_property()

    assert prop_1 != prop_2 and prop_2 != prop_3 and prop_1 != prop_3


# Generated at 2022-06-21 16:32:10.559152
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    a = Structure(seed=1)
    assert a.css_property() == 'border-radius: px'
    assert a.css_property() == 'background-position: center'



# Generated at 2022-06-21 16:32:13.651807
# Unit test for constructor of class Structure
def test_Structure():
    """Test the constructor of class Structure."""
    dataset = Structure(seed=10)
    assert isinstance(dataset, Structure)


# Generated at 2022-06-21 16:32:17.891094
# Unit test for constructor of class Structure
def test_Structure():
    print("test_Structure()")
    structure = Structure('en')
    print("structure.css()")
    print(structure.css())
    print("structure.html()")
    print(structure.html())

if __name__ == '__main__':
    test_Structure()

# Generated at 2022-06-21 16:32:19.713964
# Unit test for method html of class Structure
def test_Structure_html():
    assert Structure().html()!=''
    assert len(Structure().html())>20



# Generated at 2022-06-21 16:32:21.354592
# Unit test for constructor of class Structure
def test_Structure():
    """Unit test for constructor of class Structure."""
    structure = Structure()
    assert structure.seed is not None



# Generated at 2022-06-21 16:32:22.989249
# Unit test for method css of class Structure
def test_Structure_css():
    struc = Structure()
    css = struc.css()
    assert isinstance(css, str)
