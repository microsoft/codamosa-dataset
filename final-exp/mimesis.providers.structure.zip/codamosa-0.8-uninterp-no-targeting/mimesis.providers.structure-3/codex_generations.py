

# Generated at 2022-06-21 16:31:47.614917
# Unit test for method css of class Structure
def test_Structure_css():
    result = Structure().css()
    assert isinstance(result, str)


# Generated at 2022-06-21 16:31:48.805561
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s is not None


# Generated at 2022-06-21 16:31:52.130135
# Unit test for method css of class Structure
def test_Structure_css():
    strc = Structure()
    css1 = strc.css()
    assert css1
    assert isinstance(css1, str)

# Generated at 2022-06-21 16:31:54.723772
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    stc = Structure()
    prop = stc.css_property()
    assert isinstance(prop, str)


# Generated at 2022-06-21 16:32:05.809801
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # case 1: tag is not supported or attribute is not supported
    a = Structure()
    try:
        b = a.html_attribute_value(tag='span', attribute='a')
    except NotImplementedError:
        assert True
    else:
        assert True
    try:
        b = a.html_attribute_value(tag='span2', attribute='href')
    except NotImplementedError:
        assert True
    else:
        assert True
    try:
        b = a.html_attribute_value(tag='img', attribute='class')
    except NotImplementedError:
        assert True
    else:
        assert True

    # case 2: tag and attribute are supported
    a = Structure()
    tag = 'a'
    attribute = 'href'

# Generated at 2022-06-21 16:32:12.429752
# Unit test for method css of class Structure
def test_Structure_css():
#    seed_global(24)
    instance = Structure()
    result = instance.css()
    assert result == 'p.prava {box-shadow: #b0; color: #ec89ab; position: relative; background-image: url(//zijeeeexol.biz/bpvfjxhx/); font-style: italic}'
    assert isinstance(result, str)


# Generated at 2022-06-21 16:32:18.796659
# Unit test for method html of class Structure
def test_Structure_html():
    # Create a structure object
    structure = Structure(seed=42)

    # The returned value is a string
    assert isinstance(next(structure.html()), str)
    # The namespace is HTML_CONTAINER_TAGS
    assert next(structure.html()) in HTML_CONTAINER_TAGS
    # The length of the string is longer than or equal to 10.
    _len = len(next(structure.html()))
    assert _len >= 10

# Generated at 2022-06-21 16:32:20.896913
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()

    assert structure.random
    assert structure.seed
    assert structure.__inet
    assert structure.__text


# Generated at 2022-06-21 16:32:21.756104
# Unit test for method html of class Structure
def test_Structure_html():
    assert Structure().html() != None

# Generated at 2022-06-21 16:32:23.070086
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    strc = Structure(seed=0)
    # print(strc.css_property())



# Generated at 2022-06-21 16:32:51.815844
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    # assert s.html_attribute_value('input', 'type') == 'checkbox'
    assert s.html_attribute_value('a', 'href')
    assert s.html_attribute_value('link', 'href')
    assert s.html_attribute_value('link', 'rel')



# Generated at 2022-06-21 16:32:55.027153
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    for i in range(1, 11):
        print("html:\n", s.html())  # noqa


# Generated at 2022-06-21 16:33:02.653817
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Test method html_attribute_value of class Structure."""
    generator = Structure(seed=42)
    result = generator.html_attribute_value(tag="a", attribute="href")
    assert result == 'http://kuebler.net/tags/main/'

# Generated at 2022-06-21 16:33:06.733820
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    # Assert tag without any attributes
    assert len(s.html_attribute_value('br')) == 0

# Generated at 2022-06-21 16:33:08.388918
# Unit test for method html of class Structure
def test_Structure_html():
    """Testing method html of class Structure

    :return:
    """
    gen = Structure()
    print(gen.html())

# Generated at 2022-06-21 16:33:18.738776
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    import json, os
    structure = Structure('en')
    current_directory = os.path.dirname(os.path.abspath(__file__))
    file_html_tag_attributes = '../mimesis/data/HTML_TAG_ATTRIBUTES.json'
    file_html_tag_attributes_path = os.path.join(current_directory, file_html_tag_attributes)

    with open(file_html_tag_attributes_path, encoding='utf-8') as file_data:
        data_values = json.load(file_data)

    tag_attributes = data_values['HTML_TAG_ATTRIBUTES']
    # print("tag_attributes:\n{}".format(tag_attributes))


# Generated at 2022-06-21 16:33:21.123099
# Unit test for method html of class Structure
def test_Structure_html():
    tester = Structure()
    # pylint: disable=protected-access
    print(tester._Structure__text)
    for i in range(0, 100):
        print(tester.html())

# Generated at 2022-06-21 16:33:23.386204
# Unit test for constructor of class Structure
def test_Structure():
    str1 = Structure(seed=123)

    assert str1._seed == 123
    assert str1._locale == 'en'


# Generated at 2022-06-21 16:33:25.313654
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    assert Structure().css_property() == 'background-color: #f4d3a1'


# Generated at 2022-06-21 16:33:36.014366
# Unit test for method html of class Structure