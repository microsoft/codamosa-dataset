

# Generated at 2022-06-21 16:31:44.091621
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    f = Structure()
    assert re.match('^[a-z-]+: [a-z0-9 #]+', f.css_property())

# Generated at 2022-06-21 16:31:46.356391
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis.providers.structure import Structure
    s = Structure()
    result = s.css()
    assert result is not None
#


# Generated at 2022-06-21 16:31:48.634725
# Unit test for constructor of class Structure
def test_Structure():
    test = Structure()
    assert test.css()
    assert test.css_property()
    assert test.html()
    assert test.html_attribute_value()

# Generated at 2022-06-21 16:31:55.234749
# Unit test for method html of class Structure
def test_Structure_html():
    a = Structure()
    tag = a.random.choice(list(HTML_CONTAINER_TAGS.keys()))
    attrs = [
        tuple(attr.split('='))
        for attr in a.html_attribute_value(tag=tag).split()
    ]
    html = a.html(tag=tag, attributes=attrs)
    assert True


# Generated at 2022-06-21 16:31:56.527252
# Unit test for constructor of class Structure
def test_Structure():
    obj = Structure()



# Generated at 2022-06-21 16:32:04.693211
# Unit test for constructor of class Structure
def test_Structure():
    # Test constructor of class Structure
    structure0 = Structure()
    # Test function css of class Structure
    print(structure0.css())
    # Test function css_property of class Structure
    print(structure0.css_property())
    # Test function html of class Structure
    print(structure0.html())
    # Test function html_attribute_value of class Structure
    print(structure0.html_attribute_value())

# Unit test
if __name__ == '__main__':
    test_Structure()

# Generated at 2022-06-21 16:32:11.788901
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert s.css_property() == 'margin: 2rem;'
    assert s.css_property() == 'padding: 1em;'
    assert s.css_property() == 'background-color: #f4d3a1;'
    assert s.css_property() == 'color: #f4d3a1;'
    assert s.css_property() == 'text-align: center;'
    assert s.css_property() == 'font-size: 20px;'
    assert s.css_property() == 'font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;'
    assert s.css_property() == 'font-family: Verdana, Geneva, sans-serif;'

# Generated at 2022-06-21 16:32:15.390508
# Unit test for method html of class Structure
def test_Structure_html():
    # Test 1:
    structure = Structure()
    print(structure.html())

    # Test 2:
    for _ in range(10):
        structure = Structure()
        print(structure.html())


# Generated at 2022-06-21 16:32:18.796599
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = 'button'
    attribute = 'class'
    tag_attribute_expected = 'structure.css_property()'
    assert structure.html_attribute_value(tag, attribute) == tag_attribute_expected

# Generated at 2022-06-21 16:32:20.125899
# Unit test for method html of class Structure
def test_Structure_html():    
    html = Structure.html()
    assert(html != None)

# Generated at 2022-06-21 16:32:53.509098
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    structure = Structure()
    expected_types = ['alt', 'class', 'css', 'id', 'title', 'url', 'word']
    assert structure.html_attribute_value() in expected_types
    structure_error = Structure()
    try:
        structure_error.html_attribute_value(tag='notag', attribute='a')
    except NotImplementedError as e:
        msg = 'Tag notag or attribute a is not supported'
        assert msg == str(e)
    try:
        structure_error.html_attribute_value(tag='select', attribute='a')
    except NotImplementedError as e:
        msg = 'Attribute type a is not implemented'
        assert msg == str(e)

# Generated at 2022-06-21 16:32:59.351292
# Unit test for constructor of class Structure
def test_Structure():
    """Test for Structure Constructor."""
    
    st1 = Structure()
    assert st1 is not None and st1.__class__ == Structure
    
    st2 = Structure(seed = 1234)
    assert st2 is not None and st2.__class__ == Structure
    

# Generated at 2022-06-21 16:33:06.790555
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import ContainerTagAttr as cta
    from mimesis.enums import MarkupTagAttr as mta
    from mimesis.enums import MarkupTag as mt
    from mimesis.enums import ContainerTag as ct

    structure = Structure(seed=42)
    html = structure.html()
    assert html

    html = structure.html(tag=ct.SYNTAX)
    assert html

    html = structure.html(tag=mt.HTML)
    assert html

    html = structure.html(tag=ct.SYNTAX, attribute=cta.CLASS)
    assert html

    html = structure.html(tag=mt.HTML, attribute=mta.ID)
    assert html

    html = structure.html(tag="div", attribute="class")
    assert html



# Generated at 2022-06-21 16:33:10.252260
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    str_ = Structure('en')
    css_prop = str_.css_property()
    assert css_prop != ''
    assert len(css_prop.split(': ')) == 2
    assert len(css_prop.split('; ')) == 1


# Generated at 2022-06-21 16:33:20.817933
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Code for avoiding repetative test
    from mimesis.builtins import Utah
    from mimesis.structure import CSS_PROPERTIES
    from copy import deepcopy
    utah = Utah()
    css_properties = deepcopy(CSS_PROPERTIES)

    # Testcase 1
    structure_provider_instance = Structure(seed=1)
    assert structure_provider_instance.css_property() in css_properties.values()

    # Testcase 2
    structure_provider_instance = Structure(seed=2)
    assert structure_provider_instance.css_property() in css_properties.values()

    # Testcase 3
    structure_provider_instance = Structure(seed=3)
    assert structure_provider_instance.css_property() in css_properties.values()

    # Test

# Generated at 2022-06-21 16:33:32.054997
# Unit test for constructor of class Structure
def test_Structure():
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.person import Person
    from mimesis.providers.profile import Profile
    from mimesis.providers.structured import Structure

    # Test constructor of class Profile
    p = Profile(seed=12345)
    assert p._seed == 12345

    # Test generate name
    name = p.name(gender=Gender.MALE)
    assert name == "John"
    # Test generate full name
    full_name = p.full_name(gender=Gender.MALE)
    assert full_name == "John"
    full_name = p.full_name(gender=Gender.FEMALE)
    assert full_name == "Jessica"

    # Test generate username

# Generated at 2022-06-21 16:33:33.694338
# Unit test for constructor of class Structure
def test_Structure():
    """Test constructor of class Structure"""
    s = Structure()
    assert s is not None


# Generated at 2022-06-21 16:33:38.616314
# Unit test for method html of class Structure
def test_Structure_html():
    """Unit testing for method html of class Structure."""
    # Creating an object
    structure = Structure()
    # Generating an HTML code
    generated_HTML = structure.html()
    # Printing the result
    print("Generated HTML code : " + generated_HTML)
    # Checking that the type of the generated HTML code is string
    assert isinstance(generated_HTML, str) == True


# Generated at 2022-06-21 16:33:42.202048
# Unit test for method html of class Structure
def test_Structure_html():
    gen = Structure()
    html = gen.html()
    assert '<' in html
    assert '</' in html
    assert '=""' not in html


# Generated at 2022-06-21 16:33:44.028229
# Unit test for method css of class Structure
def test_Structure_css():
    vpr = Structure()
    vpr.html()
    return True

# Generated at 2022-06-21 16:34:09.742827
# Unit test for method html of class Structure
def test_Structure_html():
    struc = Structure()
    assert isinstance(struc.html(), str)
