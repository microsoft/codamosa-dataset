

# Generated at 2022-06-21 16:31:53.414245
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    html_attribute_value_args_1 = {
        'tag': 'div',
        'attribute': 'data-test'
    }

    html_attribute_value_result_1 = Structure.html_attribute_value(**html_attribute_value_args_1)

    html_attribute_value_args_2 = {
        'tag': 'div',
        'attribute': 'data-test'
    }
    # First call returns 'word'=property
    html_attribute_value_result_2 = Structure.html_attribute_value(**html_attribute_value_args_2)
    # Second call returns 'url'=property
    html_attribute_value_result_3 = Structure.html_attribute_value(**html_attribute_value_args_2)
    # Third call returns 'css'=property
    html_attribute_

# Generated at 2022-06-21 16:31:55.192355
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('en')
    assert isinstance(structure.css_property(), str)

# Generated at 2022-06-21 16:31:56.480464
# Unit test for method css of class Structure
def test_Structure_css():
    print(Structure().css())



# Generated at 2022-06-21 16:31:58.742263
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    for i in range(len(CSS_PROPERTIES)):
        assert structure.css_property()


# Generated at 2022-06-21 16:32:00.985692
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure('en')
    for i in range(1000):
        assert(': ' in structure.css_property())


# Generated at 2022-06-21 16:32:03.442625
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    assert isinstance(structure.html(), str)



# Generated at 2022-06-21 16:32:04.783261
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert isinstance(s, Structure)

# Generated at 2022-06-21 16:32:11.036123
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    # Using Structure class to call method html_attribute_value
    s = Structure() 
    
    # Make a list of supported HTML tags
    all_tag_list = list(HTML_CONTAINER_TAGS.keys());
    
    # Generate 10 random HTML tags
    tag_list = [];
    for i in range(10):
        tag_list.append(s.random.choice(all_tag_list));
    
    # Make a list of supported attributes for each of 10 random HTML tags
    tag_attributes_list = [];
    for tag in tag_list:
        tag_attributes_list.append(list(HTML_CONTAINER_TAGS[tag]));
    
    # Generate 10 random attributes
    attr_list = [];

# Generated at 2022-06-21 16:32:12.954147
# Unit test for method html of class Structure
def test_Structure_html():
    x = Structure("en")
    result = x.html()
    assert isinstance(result, str)
    assert len(result) > 0
    assert '<' in result and '>' in result

# Generated at 2022-06-21 16:32:18.884012
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.enums import CSSProperties, HTMLAttributes
    from mimesis.providers.structure import Structure
    s = Structure()
    assert (s.html_attribute_value(tag = 'a', attribute = HTMLAttributes.HREF) != '')
    assert (s.html_attribute_value(tag = 'div', attribute = HTMLAttributes.CLASS) != '')
    assert (s.css_property() != '')