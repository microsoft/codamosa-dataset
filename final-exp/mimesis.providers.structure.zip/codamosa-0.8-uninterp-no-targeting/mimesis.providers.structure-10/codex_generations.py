

# Generated at 2022-06-21 16:31:53.568567
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.data import (
        CSS_PROPERTIES,
        HTML_CONTAINER_TAGS,
    )
    from mimesis.enums import Attribute
    from mimesis.providers.text import Text

    struc = Structure(seed=42)

    for tag in HTML_CONTAINER_TAGS.keys():
        for attribute in HTML_CONTAINER_TAGS[tag]:  # type: ignore
            attr_type = HTML_CONTAINER_TAGS[tag][attribute]  # type: ignore

            if attr_type == Attribute.CSS:
                assert CSS_PROPERTIES.keys().__contains__(
                    struc.html_attribute_value(tag, attribute).split(':')[0].strip())

# Generated at 2022-06-21 16:31:55.776068
# Unit test for method html of class Structure
def test_Structure_html():
    strr = Structure()
    assert strr.html() == '<div id="point-pull">in the</div>'

# Generated at 2022-06-21 16:31:57.022940
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()


# Generated at 2022-06-21 16:32:03.905981
# Unit test for constructor of class Structure
def test_Structure():
    print("Test constructor of class Structure")
    st = Structure()
    print("tag = ", st.random_element("html_attribute_value"))
    print("css = ", st.css())
    print("html = ", st.html())
    print("html_attribute_value = ", st.random_element("html_attribute_value"))
    print("html_attribute_value = ", st.html_attribute_value())

if __name__ == "__main__":
    test_Structure()

# Generated at 2022-06-21 16:32:06.279710
# Unit test for method html of class Structure
def test_Structure_html():
    """Unit test for method html of class Structure"""
    # check if the result is not blank
    assert Structure().html() != '', 'Empty result after running'


# Generated at 2022-06-21 16:32:07.790288
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    assert structure.css() is not None, 'The function returns None'


# Generated at 2022-06-21 16:32:12.693892
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure(seed=2)
    ans = structure.css_property()
    print(ans)
    assert ans in ['width: 61', 'display: inline-block', 'width: 30%']


# Generated at 2022-06-21 16:32:17.088441
# Unit test for constructor of class Structure
def test_Structure():
    from mimesis.enums import Gender
    s = Structure(seed=12345)

    assert s.__class__.__name__ == 'Structure'
    assert not s.seed is None
    assert s._seed == 12345
    assert s._gender == Gender.MALE, "Wrong gender assigned"

# Generated at 2022-06-21 16:32:19.961874
# Unit test for method css_property of class Structure
def test_Structure_css_property():
	# css_property() is called on an instance of Structure
	structure = Structure()

	# A string is returned
	assert isinstance(structure.css_property(), str)



# Generated at 2022-06-21 16:32:22.620829
# Unit test for method html of class Structure
def test_Structure_html():
    struc = Structure()
    assert isinstance(struc.html(), str)
    assert not struc.html().isspace()
    assert len(struc.html()) > 0

if __name__ == "__main__":
    test_Structure_html()