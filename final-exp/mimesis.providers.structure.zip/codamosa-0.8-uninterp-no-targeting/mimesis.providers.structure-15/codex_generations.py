

# Generated at 2022-06-21 16:31:39.538292
# Unit test for constructor of class Structure
def test_Structure():
    ''' Checks whether __init__ method of class Structure works correctly or not'''
    structure = Structure()
    # Check if the attribute __inet is of class Internet 
    assert isinstance(structure.__inet, Internet)
    # Check if the attribute __text is of class Text
    assert isinstance(structure.__text, Text)


# Generated at 2022-06-21 16:31:42.595739
# Unit test for method html of class Structure
def test_Structure_html():
    result = Structure().html()
    assert isinstance(result, str)
    assert len(result) > 1



# Generated at 2022-06-21 16:31:44.498002
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.providers.structure import Structure
    s = Structure()
    print(s.css_property())


# Generated at 2022-06-21 16:31:48.476480
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    html = s.html()
    assert len(html.split(' ')) == 4
    assert html.split(' ')[2][-1] == '='
    assert html.split(' ')[2][-2] == '"'
    assert html.split(' ')[2][0] == '"'


# Generated at 2022-06-21 16:31:49.988206
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('a','download') in ['','word','css','url']

# Generated at 2022-06-21 16:31:53.698083
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.enums import Gender, Locale
    structure = Structure(locale=Locale.EN)
    actual = structure.html()
    assert isinstance(actual, str)

# Generated at 2022-06-21 16:31:57.709838
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    struct = Structure(seed=1)

    tag = 'a'
    attribute = 'href'
    value = struct.html_attribute_value(tag, attribute)

    assert value == 'https://www.jeffreyfernandez.info/'

# Generated at 2022-06-21 16:32:07.939887
# Unit test for method css of class Structure
def test_Structure_css():
    struct = Structure(seed=123456)
    assert struct.css() == 'h1 {border-left-style: ridge; width: 34px}'
    assert struct.css() == 'input {color: #494c04; font-style: inherit}'
    assert struct.css() == 'h3 {margin-left: 10px}'
    assert struct.css() == 'h1 {border: 5px dotted #2d0ce1}'
    assert struct.css() == 'a {color: #42b9d9}'
    assert struct.css() == 'ul {text-indent: 14px}'
    assert struct.css() == 'h2 {color: #5e5b5f}'
    assert struct.css() == 'span {color: #63b1ff; width: 25px}'
    assert struct

# Generated at 2022-06-21 16:32:12.705310
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Unit test for method css_property of class Structure."""

    structure_obj = Structure()
    assert structure_obj.css_property() == 'background-color: #6c1e6f'


# Generated at 2022-06-21 16:32:15.447951
# Unit test for method html of class Structure
def test_Structure_html():
    stem = Structure()
    stem.html(tag='div', attribute='class')
    stem.html()
    stem.html(tag='a', attribute='target')

# Generated at 2022-06-21 16:32:46.701401
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure('en')
    print(structure.css())


# Generated at 2022-06-21 16:32:48.071199
# Unit test for method css of class Structure
def test_Structure_css():
    prov = Structure()
    assert isinstance(prov.css(), str)


# Generated at 2022-06-21 16:32:49.540174
# Unit test for constructor of class Structure
def test_Structure():
    s=Structure()
    assert s is not None


# Generated at 2022-06-21 16:32:51.732632
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    provider = Structure()
    tag = 'div'
    attribute = 'style'
    assert provider.html_attribute_value(tag, attribute) != None

# Generated at 2022-06-21 16:33:02.786002
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    a = Structure(seed=12345)
    # test with tag and attribute
    assert a.html_attribute_value(tag='meta', attribute='charset') == 'utf-8'
    # test with tag only
    assert a.html_attribute_value(tag='link') in ['screenshort', 'icon', 'stylesheet', 'manifest']
    # test with attribute only
    assert a.html_attribute_value(attribute='href') == 'http://example.com'
    # test wrong input
    try:
        a.html_attribute_value(tag='wrong', attribute='wrong_attr')
        assert False, "Expected exception raised not raised"
    except NotImplementedError:
        pass



# Generated at 2022-06-21 16:33:06.888182
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure(seed=12345)
    c = s.css_property()
    assert c == "font-size: 90px"

# Generated at 2022-06-21 16:33:09.229328
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s is not None
    assert Structure.Meta.language == 'en'
    assert s.__text.language == 'en'


# Generated at 2022-06-21 16:33:10.504637
# Unit test for method html of class Structure
def test_Structure_html():
    d = Structure()
    assert isinstance(d.html(), str)

# Generated at 2022-06-21 16:33:14.418173
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    html_obj1 = Structure()
    tags = list(HTML_CONTAINER_TAGS.keys())
    attributes = list(HTML_CONTAINER_TAGS['a'])
    tag = tags[1]
    attribute = attributes[1]
    html_obj1.html_attribute_value(tag, attribute)
    pass



# Generated at 2022-06-21 16:33:20.817866
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    # If a random value from the list of properties is selected, the returned value is a string of the format "property_name: value".
    structure.random.choice = lambda x: x[0]
    expected = 'margin: 10px'
    result = structure.css_property()
    assert result == expected
