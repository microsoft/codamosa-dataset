

# Generated at 2022-06-21 16:31:38.085290
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    css_prop = Structure()
    result = css_prop.css_property()
    print(result)
    assert result
    #assert result == True


# Generated at 2022-06-21 16:31:42.880043
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    """Unit test: Method css_property of class Structure."""
    tmp = Structure()
    tmp2 = Structure(seed=1)
    css = tmp.css_property()
    css2 = tmp2.css_property()
    assert css == 'height: auto'
    assert css == css2



# Generated at 2022-06-21 16:31:43.589922
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    obj = Structure()
    result = obj.css_property()
    assert result == 'margin-top: 2px'

# Generated at 2022-06-21 16:31:44.328807
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure("en")
    assert(len(structure.css()) != 0)


# Generated at 2022-06-21 16:31:51.563240
# Unit test for constructor of class Structure
def test_Structure():
    # Use the seed "aaa" for the random number
    structure = Structure('aaa')
    assert structure.css() == 'div {background-size: 2px;list-style-type: decimal}'
    assert structure.css_property()=='text-decoration: underline'
    assert structure.html()=='<a href="#" lang="en-US" name="The-great-gatsby" style="background-repeat: no-repeat">Stock prices fell this morning</a>'
    assert structure.html_attribute_value()=='abbr'
    assert structure.html_attribute_value('a')=='#'
    assert structure.html_attribute_value('a', 'href')=='#'

# Generated at 2022-06-21 16:31:52.644496
# Unit test for method html of class Structure
def test_Structure_html():
    assert Structure().html() != None

# Generated at 2022-06-21 16:31:57.276166
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # Basic test
    test_value = Structure().css_property()
    assert test_value == "background-color: #123456" or "background-color: black" or "background-color: green" or "background-color: #f4d3a1"


# Generated at 2022-06-21 16:32:05.791392
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """The test case for method html_attribute_value of class Structure.

    The test fails if the value returned by the method does not match
    the expected value, in particular if it is not in the list of possible
    values.
    """
    # Expected returned values
    type_css = ['color', 'background-color', 'border-color',
                'border-left-color', 'border-right-color',
                'border-top-color', 'border-bottom-color']
    type_size = ['10px', '100px', '1000px', '10%', '100%', '1000%']

# Generated at 2022-06-21 16:32:07.825833
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure(seed=123)
    property = structure.css_property()
    assert property == 'font-size: 12px'


# Generated at 2022-06-21 16:32:11.844808
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value() != '' and structure.html_attribute_value() is not None


# Generated at 2022-06-21 16:32:24.106146
# Unit test for method html of class Structure
def test_Structure_html():
    html_result = '<form method="post" accept-charset="utf-8">Dolores est qui voluptas ut recusandae consequatur. Reprehenderit voluptate non et adipisci. Repellendus consequuntur voluptatem in. Qui omnis quis quae esse fugit.</form>'
    structure = Structure()
    assert structure.html() == html_result

# Generated at 2022-06-21 16:32:25.661569
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value('span', 'class') == 'word'


# Generated at 2022-06-21 16:32:28.338228
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    assert s, Structure


# Generated at 2022-06-21 16:32:33.992877
# Unit test for constructor of class Structure
def test_Structure():
    # Test 1: Asserting that the seed is taken as an argument
    structure = Structure(seed=12345)
    assert structure.seed == 12345

    # Test 2: Asserting that if the seed is not passed, seeding is disabled
    structure = Structure()
    assert structure.seed == None
    

# Generated at 2022-06-21 16:32:39.918723
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    a = Structure(seed=123)
    css_property = a.css_property()
    assert css_property in ['font-size: 2mm; height: 118; margin-bottom: 3cm',
                            'font-size: 32px; height: 82',
                            'font-size: 7mm; height: 95; margin-bottom: 2cm',
                            'font-size: 89em; margin-bottom: 3cm']


# Generated at 2022-06-21 16:32:49.640160
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value('div', 'align') in ['left', 'right', 'center']
    assert structure.html_attribute_value('div', 'action') == 'url'
    with pytest.raises(NotImplementedError):
        structure.html_attribute_value('div', 'fake_attribute')
    with pytest.raises(NotImplementedError):
        structure.html_attribute_value('fake_tag', 'fake_attribute')
    with pytest.raises(NotImplementedError):
        structure.html_attribute_value('fake_tag', 'fake_attribute')

# Generated at 2022-06-21 16:32:50.615820
# Unit test for method css of class Structure
def test_Structure_css():
  structure = Structure(seed=555)
  print(structure.css())


# Generated at 2022-06-21 16:32:55.714912
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.providers.structure import Structure
    structure = Structure()
    assert structure.html_attribute_value() == "<div>@gmail.com</div>"
    assert structure.html_attribute_value(tag="a", attribute="href") == \
           '<span class="img"></span>'
    assert structure.html_attribute_value(tag="a", attribute="class") == \
           '<a class="js">http://www.slack-corp.com/</a>'

# Generated at 2022-06-21 16:33:03.820905
# Unit test for method css of class Structure
def test_Structure_css():
    str_obj = Structure()
    str_obj.random.seed(2)

    # Test 1
    assert str_obj.css() == '#video {color: #0adcfe; font-size: 71pt; width: 60%; background-color: #3f4e63; height: 12pt; color: #13d1cd}'

    # Test 2
    str_obj.random.seed(305)
    assert str_obj.css() == '#video header .test .test .test .test .test .test .test .test .test {color: #7bdf01}'


# Generated at 2022-06-21 16:33:05.943894
# Unit test for constructor of class Structure
def test_Structure():
    structure_test = Structure()
    assert structure_test is not None


# Generated at 2022-06-21 16:33:29.951301
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure()
    assert(s.css_property() in CSS_PROPERTIES.keys())



# Generated at 2022-06-21 16:33:33.035876
# Unit test for constructor of class Structure
def test_Structure():
    Struct = Structure(random_state=2)
    assert Struct.seed == 2
    assert Struct.random.randint(0, 10) == 6
    assert Struct.random.randint(0, 10) == 8
    return True



# Generated at 2022-06-21 16:33:39.983932
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():

    tag = 'span'
    attribute = 'class'
    value = 'word'
    if isinstance(value, list):
        value = self.random.choice(value)
    elif value == 'css':
        value = self.css_property()
    elif value == 'word':
        value = self.__text.word()
    elif value == 'url':
        value = self.__inet.home_page()
    else:
        raise NotImplementedError(
                'Attribute type {} is not implemented'.format(value))
    assert value=='wod'



# Generated at 2022-06-21 16:33:44.504816
# Unit test for method css of class Structure
def test_Structure_css():
    pattern = r'([a-zA-Z-]+|<.*>){{(.|\s)+?}}'
    assert Structure().css().matches(pattern)


# Generated at 2022-06-21 16:33:46.205419
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure("en")
    assert structure


# Generated at 2022-06-21 16:33:47.477711
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    result = structure.css()
    assert result is not None


# Generated at 2022-06-21 16:33:58.336810
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    tag = "a"
    attribute = "target"
    value = structure.html_attribute_value(tag, attribute)
    assert value == "word"
    tag = "div"
    attribute = "title"
    value = structure.html_attribute_value(tag, attribute)
    assert value == "word"
    tag = "a"
    attribute = "id"
    value = structure.html_attribute_value(tag, attribute)
    assert value == "word"
    tag = "span"
    attribute = "class"
    value = structure.html_attribute_value(tag, attribute)
    assert value == "word"
    tag = "a"
    attribute = "href"
    value = structure.html_attribute_value(tag, attribute)
    assert value == "word"

# Generated at 2022-06-21 16:34:07.270553
# Unit test for method html of class Structure
def test_Structure_html():
    """Test method html of class Structure."""
    tag_name = 'br'
    tag_attributes = list(HTML_CONTAINER_TAGS[tag_name])
    k = 1
    selected_attrs = []
    for _ in range(k):
        selected_attrs.append(Structure().random.choice(tag_attributes))
    attrs = []
    for attr in selected_attrs:
        attrs.append('{}="{}"'.format(
            attr, Structure().html_attribute_value(tag_name,  attr)))
    html_result = '<{tag} {attrs}>{content}</{tag}>'

# Generated at 2022-06-21 16:34:11.576630
# Unit test for method html of class Structure
def test_Structure_html():
    s = Structure()
    class_value = 'select'
    tag = 'p'
    attr = 'class'
    str_html = s.html_attribute_value(tag, attr)
    print(str_html)
    assert class_value in str_html
    assert tag in str_html

# Generated at 2022-06-21 16:34:13.272489
# Unit test for method css of class Structure
def test_Structure_css():
    # test_obj = Structure()
    # print(test_obj.css())
    pass


# Generated at 2022-06-21 16:34:47.055353
# Unit test for method html of class Structure
def test_Structure_html():
    struct = Structure()
    struct.html()

# Generated at 2022-06-21 16:34:51.824508
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    assert structure.html_attribute_value()
    assert structure.html_attribute_value(attribute='class')
    assert structure.html_attribute_value(tag='div')
    assert structure.html_attribute_value(tag='div', attribute='class')


# Generated at 2022-06-21 16:34:55.029617
# Unit test for constructor of class Structure
def test_Structure():
    sd = Structure()
    sd.css()
    sd.css_property()
    sd.html()
    sd.html_attribute_value()

test_Structure()

# Generated at 2022-06-21 16:35:00.279371
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    import random
    from mimesis.data import CSS_PROPERTIES
    from mimesis.providers.structure import Structure
    from mimesis.providers.text import Text
    s = Structure(seed=random.seed())
    text = Text('en', seed=s.seed)
    random.seed(s.seed)
    val = s.css_property()
    prop = val.split()[0]
    # assert prop in CSS_PROPERTIES.keys():
    assert prop in CSS_PROPERTIES.keys()


# Generated at 2022-06-21 16:35:02.356899
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    result = s.css()
    assert isinstance(result, str)


# Generated at 2022-06-21 16:35:04.838987
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    result = structure.css_property()
    assert result in CSS_PROPERTIES
    print(result)


# Generated at 2022-06-21 16:35:07.178984
# Unit test for method html of class Structure
def test_Structure_html():
    struct1 = Structure()
    struct2 = Structure()
    struct3 = Structure()
    assert struct1.html() != struct2.html() != struct3.html()

# Generated at 2022-06-21 16:35:14.865410
# Unit test for method html of class Structure
def test_Structure_html():
    tag_name = 'a'
    tag_attributes = list(HTML_CONTAINER_TAGS[tag_name]) # type: ignore
    so = Structure(seed=1234)
    expected_result = '<a href="http://www.jones-kline.com/category"\
    style="border-radius: 38px; border-color: #8a5a6a; border-width: 54px;\
    border-style: solid;">Ports are created with the built-in function\
    open_port.</a>'
    actual_result = so.html()
    # print(actual_result)
    assert actual_result == expected_result

# Generated at 2022-06-21 16:35:25.644726
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    provider = Structure()
    result1 = provider.html_attribute_value("a", "target")
    assert (result1 in ["_blank", "_self", "_parent", "_top"])
    result2 = provider.html_attribute_value("a", "accesskey")
    assert (result2 in ["letter", "digit", "punctuation"])
    result3 = provider.html_attribute_value("a", "charset")
    assert (result3 in ["UTF-8", "ISO-8859-1"])
    result4 = provider.html_attribute_value("a", "type")
    assert (result4 in ["text/html", "text/css", "text/javascript", "font", "image", "file", "video", "audio"])
    result5 = provider.html_attribute_value("a", "charset")

# Generated at 2022-06-21 16:35:35.876564
# Unit test for method html of class Structure
def test_Structure_html():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    rs = RussiaSpecProvider(seed=42)
    assert rs.structure.html() == '<pre id="render" data-day="5">\n' \
                                  'Η νοσηλευτική του είναι και η συνέχιση\n' \
                                  'του πολύ καλό και πως είναι η πρόταση.\n' \
                                  '<pre>'


# Generated at 2022-06-21 16:36:02.997691
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure("en")
    prop = structure.css_property()
    assert isinstance(prop, str)


# Generated at 2022-06-21 16:36:08.452376
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure()
    result = structure.html_attribute_value('meta', 'charset')
    assert result == 'charset="utf-8"'
    result = structure.html_attribute_value('div', 'class')
    assert result == 'class="container"'
    result = structure.html_attribute_value(attribute='id')
    assert result == 'id="cv"'
    result = structure.html_attribute_value(tag='div')
    assert result == 'rel="nofollow"'


# Generated at 2022-06-21 16:36:09.700446
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    result = structure.css()
    assert result is not None


# Generated at 2022-06-21 16:36:10.390253
# Unit test for method html of class Structure
def test_Structure_html():
    struct = Structure()
    print(struct.html())

# Generated at 2022-06-21 16:36:11.309333
# Unit test for constructor of class Structure
def test_Structure():
  s = Structure()
  assert isinstance(s, Structure)


# Generated at 2022-06-21 16:36:13.314434
# Unit test for method html of class Structure
def test_Structure_html():
    parse_html = Structure()
    html = parse_html.html()
    print(html)
    assert(html != None)