

# Generated at 2022-06-21 16:31:33.709268
# Unit test for method css of class Structure
def test_Structure_css():
    s = Structure()
    result = s.css()
    print(result)
    assert isinstance(result, str)


# Generated at 2022-06-21 16:31:40.649712
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    css = structure.css_property()
    assert css == 'padding: 10px' or \
           css == 'line-height: 1.3' or \
           css == 'border: 1px solid #f4d3a1' or \
           css == 'visibility: visible' or \
           css == 'display: block' or \
           css == 'list-style-type: decimal-leading-zero' or \
           css == 'outline: thin dotted'


# Generated at 2022-06-21 16:31:43.115548
# Unit test for method html of class Structure
def test_Structure_html():
    x = Structure(locale='en')
    print(x.html())


# Generated at 2022-06-21 16:31:48.152443
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    provider = Structure()
    for i in range(10):
        tag = provider.random.choice(list(HTML_CONTAINER_TAGS.keys()))
        attribute = provider.random.choice(list(HTML_CONTAINER_TAGS[tag]))
        result = provider.html_attribute_value(tag, attribute)
        assert(not result == None)
        tested = provider.html_attribute_value()
        assert(not tested == None)

# Generated at 2022-06-21 16:31:53.751535
# Unit test for constructor of class Structure
def test_Structure():
    # Init the class
    structure = Structure()
    assert isinstance(structure.seed, int)
    assert structure._meta.name == "structure"
    assert structure.__text != None
    assert structure.__inet != None
    assert structure.random != None

# Testing the css() method of class Structure.

# Generated at 2022-06-21 16:31:59.788792
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    #1) Creating object
    s = Structure()
    #2) Testing function
    attr = s.html_attribute_value('img','src')
    assert isinstance(attr, str)
    attr = s.html_attribute_value('img','src')
    assert isinstance(attr, str)
    print("'html_attribute_value' method of 'Structure' class works correctly!")


# Generated at 2022-06-21 16:32:01.072448
# Unit test for constructor of class Structure
def test_Structure():
    structure = Structure()
    return structure


# Generated at 2022-06-21 16:32:08.740340
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    assert Structure().html_attribute_value("a", "class") == "select"
    assert Structure().html_attribute_value("a", "id") == "careers"
    assert Structure().html_attribute_value("a", "style") == 'color: #0e0a73'
    assert Structure().html_attribute_value("a", "data") == "category"
    assert Structure().html_attribute_value("a", "href") == 'http://www.dbl.com'

    assert Structure().html_attribute_value() != None

    assert Structure().html_attribute_value("a", "hehe") == NotImplementedError

    #raise NotImplementedError(
    #        'Tag {} or attribute {} is not supported'.format(
    #            tag, attribute))


# Generated at 2022-06-21 16:32:10.762142
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    assert len(structure.css()) > 0


# Generated at 2022-06-21 16:32:20.126586
# Unit test for method css of class Structure
def test_Structure_css():
    # test 1
    css_1 = Structure(seed=0).css()
    assert css_1 == 'body {padding: 3%; color: #914481; display: flex}'
    # test 2
    css_2 = Structure(seed=1).css()
    assert css_2 == 'a {text-align: center; width: 17pt; color: #519016}'
    # test 3
    css_3 = Structure(seed=2).css()
    assert css_3 == '#myElement {color: #442312; border-width: 9px; ' + \
                    'border-color: #4a1304}'


# Generated at 2022-06-21 16:32:44.685318
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""
    s = Structure()

# Generated at 2022-06-21 16:32:46.209273
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    print(structure.css_property())

# Generated at 2022-06-21 16:32:49.145880
# Unit test for constructor of class Structure
def test_Structure():
    """Test the constructor of the class Structure."""
    structure = Structure()
    assert structure.__class__.__name__ == 'Structure'
    assert structure.Meta.name == 'structure'


# Generated at 2022-06-21 16:32:54.737603
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure('en', seed=128)
    assert structure.html() == '<footer class="tent" id="flag">' \
                               'Sed non aliquam metus magna quis vel.' \
                               '</footer>'
    structure_2 = Structure('en', seed=128)
    assert structure_2.html() == '<footer class="tent" id="flag">' \
                                 'Sed non aliquam metus magna quis vel.' \
                                 '</footer>'



# Generated at 2022-06-21 16:32:56.277192
# Unit test for method html of class Structure
def test_Structure_html():
    import mimesis
    mimesis.Structure.html()

# Generated at 2022-06-21 16:32:59.297309
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    s = Structure(seed=12345)
    property = s.css_property()
    assert type(property) == str

# Generated at 2022-06-21 16:33:02.127156
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis.providers.other import Other
    other = Other()
    struct = Structure(seed=other.uuid4())
    assert struct.html_attribute_value() is not None


# Generated at 2022-06-21 16:33:13.294343
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    x = Structure()
    y = HTML_CONTAINER_TAGS["body"]
    z = HTML_CONTAINER_TAGS["a"]
    w = HTML_CONTAINER_TAGS["link"]
    # Test that it returns a value of the correct type
    assert type(x.html_attribute_value("body", "onload")) == str
    assert type(x.html_attribute_value("a", "href")) == str
    assert type(x.html_attribute_value("link", "rel")) == str
    # Test that it returns a value allowed by the spec
    assert x.html_attribute_value("body", "onload") in y["onload"]
    assert x.html_attribute_value("a", "href") in z["href"]
    assert x.html_attribute_value("link", "rel") in w

# Generated at 2022-06-21 16:33:15.117064
# Unit test for method css of class Structure
def test_Structure_css():
    st = Structure()
    s = st.css()
    assert s is not None and s != ''


# Generated at 2022-06-21 16:33:18.653533
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    t = Structure("en")
    print(t.css_property())


if __name__ == '__main__':
    test_Structure_css_property()

# Generated at 2022-06-21 16:33:38.021222
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    structure = Structure('en')
    assert structure.html_attribute_value() != ''

# Generated at 2022-06-21 16:33:40.208348
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure()
    result = structure.css()
    assert isinstance(result,str)
    assert len(result.split()) == 3


# Generated at 2022-06-21 16:33:48.055441
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    """Unit test for method html_attribute_value of class Structure."""

# Generated at 2022-06-21 16:33:59.041183
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    l1 = []
    l2 = []
    l3 = []
    l4 = []
    l5 = []
    l6 = []
    l7 = []
    l8 = []
    l9 = []
    l10 = []
    l11 = []
    l12 = []
    l13 = []
    l14 = []
    l15 = []
    l16 = []
    l17 = []
    l18 = []
    l19 = []
    l20 = []
    l21 = []
    l22 = []
    l23 = []
    l24 = []

# Generated at 2022-06-21 16:34:01.757385
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    from mimesis import Structure

    assert Structure.html_attribute_value(tag='a', attribute='href') == '#'

test_Structure_html_attribute_value()

# Generated at 2022-06-21 16:34:05.754696
# Unit test for constructor of class Structure
def test_Structure():
    struct = Structure()
    struct.html_attribute_value()
    struct.html_attribute_value(tag = 'div')
    struct.html_attribute_value(attribute = 'class')
    struct.html_attribute_value(tag = 'div', attribute = 'class')
    struct.css()
    struct.css_property()
    struct.html()

# Generated at 2022-06-21 16:34:06.792139
# Unit test for method html of class Structure
def test_Structure_html():
    struct = Structure()
    struct.html()

# Generated at 2022-06-21 16:34:09.912351
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    tag = 'h1'
    attribute = 'class'
    assert s.html_attribute_value(tag, attribute) == HTML_CONTAINER_TAGS[tag][attribute]



# Generated at 2022-06-21 16:34:14.774506
# Unit test for method css of class Structure
def test_Structure_css():
    struct = Structure(seed=0)
    css = struct.css()
    print(css)
    assert css == "p {-khtml-text-size-adjust: 100%; -webkit-tap-highlight-color: rgba(0,0,0,0.9); display: inline; text-align: justify; position: relative; color: #5f4b4a}"


# Generated at 2022-06-21 16:34:19.199082
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure(seed=42)
    assert s
    s = Structure(locale='ru', seed=42)
    assert s
    s = Structure(locale='en', seed=42)
    assert s


# Generated at 2022-06-21 16:34:46.192455
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSPropertyType
    struct_provider=Structure()
    print(struct_provider.random.choice(list(CSS_PROPERTIES.keys())))
    print(CSS_PROPERTIES[struct_provider.random.choice(list(CSS_PROPERTIES.keys()))])
    print(struct_provider.css_property())
    print(struct_provider.random.choice(CSS_PROPERTIES))
    print(CSSPropertyType.COLOR)


# Generated at 2022-06-21 16:34:57.245250
# Unit test for method html_attribute_value of class Structure
def test_Structure_html_attribute_value():
    s = Structure()
    assert s.html_attribute_value() != None
    assert s.html_attribute_value(tag = "a") != None
    assert s.html_attribute_value(attribute = "href") != None
    assert s.html_attribute_value(tag = "a",attribute = "href") != None
    try:
        s.html_attribute_value(tag = "test",attribute = "testtest")
        assert False
    except NotImplementedError:
        assert True
    try:
        s.html_attribute_value(attribute = "testtest")
        assert False
    except NotImplementedError:
        assert True
    try:
        s.html_attribute_value(tag = "test")
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-21 16:35:02.679571
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    result = structure.css_property()
    assert isinstance(result, str)
    result = structure.css_property()
    assert isinstance(result, str)
    print(result)


# Generated at 2022-06-21 16:35:13.205459
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    from mimesis.enums import CSSProperties
    from mimesis.providers.structure import Structure
    for i in range(100):
        provider = Structure()
        p1 = provider.css_property()
        p2 = provider.css_property()

# Generated at 2022-06-21 16:35:20.278783
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()

    html_1 = structure.html()
    html_2 = structure.html()
    assert html_1 != html_2
    assert html_1 and html_2

    attr_1 = structure.html_attribute_value()
    attr_2 = structure.html_attribute_value()
    assert attr_1 != attr_2
    assert attr_1 and attr_2

# Generated at 2022-06-21 16:35:24.013646
# Unit test for constructor of class Structure
def test_Structure():
    s = Structure()
    #print(s.html())
    #print(s.css())
    #print(s.html_attribute_value())
    pass

if __name__ == "__main__":
    test_Structure()

# Generated at 2022-06-21 16:35:30.081026
# Unit test for method css of class Structure
def test_Structure_css():
    from mimesis.enums import CSSProperties
    structure = Structure()

    css = structure.css()
    assert isinstance(css, str)

    assert css[0] == '{'
    assert css[-1] == '}'

    css_property_name = css.split(':')[0].strip()
    assert css_property_name in list(CSSProperties)


# Generated at 2022-06-21 16:35:35.461589
# Unit test for method css of class Structure
def test_Structure_css():
    structure = Structure(seed=42)
    data = structure.css()

# Generated at 2022-06-21 16:35:45.541167
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    # create Structure object
    structure = Structure()
    prop = structure.css_property()

    # check data type
    assert type(prop) is str

    # check for available values

# Generated at 2022-06-21 16:35:47.405382
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    structure = Structure()
    print(structure.css_property())


# Generated at 2022-06-21 16:36:31.037017
# Unit test for method html of class Structure
def test_Structure_html():
    structure = Structure()
    for _ in range(10):
        tag = structure.random.choice(list(HTML_CONTAINER_TAGS))
        attribute = structure.random.choice(list(HTML_CONTAINER_TAGS[tag]))  # type: ignore
        result = structure.html_attribute_value(tag, attribute)
        # print(tag, attribute, result)
        assert isinstance(result, str)

# Generated at 2022-06-21 16:36:37.116504
# Unit test for method css_property of class Structure
def test_Structure_css_property():
    S = Structure()
    func_results = []
    for _ in range(10):
        func_results.append(S.css_property())
    func_results.append(S.css_property(S.random.choice(list(CSS_PROPERTIES))))
    for result in func_results:
        assert len(result) != 0
