

# Generated at 2022-06-25 08:48:43.452807
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:48:48.595383
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert(callback_module.CALLBACK_VERSION == 2.0)
    assert(callback_module.CALLBACK_TYPE == 'aggregate')
    assert(callback_module.CALLBACK_NAME == 'tree')
    assert(callback_module.CALLBACK_NEEDS_ENABLED == True)


# Generated at 2022-06-25 08:48:51.564506
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    call_back_module = CallbackModule()
    assert call_back_module.write_tree_file('test', 'test') == None


# Generated at 2022-06-25 08:48:56.054172
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    callback_module.set_options('args')
    assert callback_module.statistics
    assert callback_module.task_queue
    assert callback_module.task_seen
    assert callback_module.task_skip_seen
    assert callback_module.task_errors_seen
    assert callback_module.task_ok_seen
    assert callback_module._play
    assert callback_module._last_task
    assert callback_module._last_task_banner
    assert callback_module.display

# Generated at 2022-06-25 08:49:03.487809
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    # Missing params
    callback_module_1.set_options()
    # Missing params
    callback_module_1.set_options(task_keys={"value": "A"}, var_options={"value": "B"}, direct={"value": "C"})


# Generated at 2022-06-25 08:49:06.192502
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()
    return True

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:49:09.695910
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    task_keys=None
    var_options=None
    direct=None
    callback_module_1.set_options(task_keys=task_keys, var_options=var_options, direct=direct)


# Generated at 2022-06-25 08:49:12.350545
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module == callback_module


# Generated at 2022-06-25 08:49:18.159553
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callback_module_0 is not None

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:49:19.526428
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:49:32.344213
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str_0 = 'adhoc'
    str_1 = 'adhoc'
    callback_module_0 = CallbackModule()
    boolean_0 = callback_module_0._display.verbosity >= 5
    assert boolean_0

    boolean_0 = callback_module_0._display.display('unit test result: %s', True, color=None, stderr=None, screen_only=None, log_only=None)
    assert boolean_0

    boolean_0 = callback_module_0.runner_on_failed()
    assert boolean_0

    boolean_0 = callback_module_0.runner_on_ok()
    assert boolean_0

    callback_module_0.set_options(task_keys=str_0, var_options=str_1)

# Generated at 2022-06-25 08:49:39.508982
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = "hostname"
    buf = "buf"
    output = callback_module_0.write_tree_file(hostname, buf)
    print(output)


# Generated at 2022-06-25 08:49:40.346638
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    pass


# Generated at 2022-06-25 08:49:43.935100
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = ''
    buf = ''
    callback_module_0.write_tree_file(hostname, buf)


# Generated at 2022-06-25 08:49:47.686534
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    var_0 = CallbackModule()
    var_1 = None
    var_2 = None
    var_3 = None

    var_0.set_options( var_1, var_2, var_3)


# Generated at 2022-06-25 08:49:49.998879
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()

# Generated at 2022-06-25 08:49:59.406133
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    callback_module_2 = CallbackModule()
    callback_module_3 = CallbackModule()
    callback_module_4 = CallbackModule()
    callback_module_5 = CallbackModule()
    callback_module_4.set_options(task_keys=None, var_options=[])
    assert True
    # Test assertions for the constructor of class CallbackModule
    assert isinstance(callback_module_0, CallbackModule)
    assert type(callback_module_0) == CallbackModule
    assert isinstance(callback_module_1, CallbackModule)
    assert type(callback_module_1) == CallbackModule
    assert isinstance(callback_module_2, CallbackModule)

# Generated at 2022-06-25 08:50:00.396599
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:50:07.638434
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    var_1 = {"hostname": {
            "ansible_facts": {
                "distribution": "CentOS",
                "distribution_major_version": "7",
                "distribution_release": "Core",
                "distribution_version": "7.2.1511"
                },
            "changed": False,
            "module_stdout": "",
            "stdout": "",
            "stdout_lines": [],
            "warnings": []
            }}
    callback_module_1 = CallbackModule()
    makedirs_safe()


# Generated at 2022-06-25 08:50:08.628814
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.CALLBACK_VERSION == 2.0


# Generated at 2022-06-25 08:50:17.084396
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    test_obj_0 = CallbackModule()
    assert test_obj_0 != None
    hostname = "hostname"
    buf = "buf"
    assert test_obj_0.write_tree_file(hostname, buf) == None


# Generated at 2022-06-25 08:50:21.027261
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    task_keys = []
    var_1 = callback_set_options()
    var_2 = []
    job_id = var_1
    self_vars = var_2
    callback_module_0.set_options(task_keys=task_keys, var_options=self_vars, direct=var_2)


# Generated at 2022-06-25 08:50:25.407710
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    var_1 = callback_module_1.set_options()
    var_2 = callback_module_1.write_tree_file()
    var_3 = callback_module_1.result_to_tree()
    var_4 =  callback_module_1.v2_runner_on_ok()
    var_5 = callback_module_1.v2_runner_on_failed()
    var_6 = callback_module_1.v2_runner_on_unreachable()

# Generated at 2022-06-25 08:50:32.811286
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    #
    # Method set_options
    #
    task_keys = None
    var_options = None
    direct = None
    # Invalid inputs
    # - task_keys,
    # - var_options,
    # - direct,
    try:
        callback_module.set_options(task_keys=task_keys, var_options=var_options, direct=direct)
    except Exception as e:
        print("An exception was thrown: %s" % e)
    #
    # Method write_tree_file
    #
    hostname = None
    buf = None
    # Invalid inputs
    # - hostname,
    # - buf,
    try:
        callback_module.write_tree_file(hostname, buf)
    except Exception as e:
        print

# Generated at 2022-06-25 08:50:34.210050
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()



# Generated at 2022-06-25 08:50:38.027536
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.write_tree_file("NULL", "NULL")


# Generated at 2022-06-25 08:50:39.952547
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:50:43.558145
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.CALLBACK_TYPE == 'aggregate'
    assert callback_module_0.CALLBACK_NAME == 'tree'
    assert callback_module_0.CALLBACK_NEEDS_ENABLED == True
    assert callback_module_0.CALLBACK_VERSION == 2.0


# Generated at 2022-06-25 08:50:44.456418
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert isinstance(CallbackModule(), CallbackModule) == True


# Generated at 2022-06-25 08:50:48.188797
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # Input parameters for this module
    task_keys = None
    var_options = None
    direct = None

    # Call callback method set_options of class CallbackModule
    callback_set_options(task_keys, var_options, direct)

    # Return value(s) from callback method set_options of class CallbackModule


# Generated at 2022-06-25 08:50:59.376142
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()
    assert isinstance(var_0, bool), "result of set_options() must be of bool type"


# Generated at 2022-06-25 08:51:03.585467
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname_0 = None
    buf_0 = None
    try:
        callback_module_0.write_tree_file(hostname_0, buf_0)
        print('Test: tree_file')
    except Exception as e:
        print('Exception raised: {}'.format(e))


# Generated at 2022-06-25 08:51:05.501273
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule.CallbackModule()
    assert isinstance(callback_module_0, CallbackModule.CallbackModule)


# Generated at 2022-06-25 08:51:07.165470
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()

# Generated at 2022-06-25 08:51:09.712543
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_1 = "var_1"
    var_2 = "var_2"
    callback_module_0.write_tree_file(var_1, var_2)


# Generated at 2022-06-25 08:51:12.816511
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert callback_module_1.CALLBACK_NAME == 'tree'
    assert callback_module_1.CALLBACK_VERSION == 2.0
    assert callback_module_1.CALLBACK_TYPE == 'aggregate'
    assert callback_module_1.CALLBACK_NEEDS_ENABLED == True



# Generated at 2022-06-25 08:51:14.181228
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    assert True


# Generated at 2022-06-25 08:51:15.222775
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    v

# Generated at 2022-06-25 08:51:18.082447
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
	callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:51:22.742852
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
  var_CallbackModule = CallbackModule()
  var_CallbackModule.set_options()
  var_CallbackModule.result_to_tree()
  var_CallbackModule.v2_runner_on_ok()
  var_CallbackModule.v2_runner_on_failed()
  var_CallbackModule.v2_runner_on_unreachable()

# Generated at 2022-06-25 08:51:41.899849
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module = CallbackModule()
    buf = 'buf'
    callback_module.write_tree_file('hostname', buf)


# Generated at 2022-06-25 08:51:45.064057
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(callback_tree)


# Generated at 2022-06-25 08:51:47.303818
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, CallbackModule)


# Generated at 2022-06-25 08:51:48.731957
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file()

# Generated at 2022-06-25 08:51:51.239552
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options()


# Generated at 2022-06-25 08:51:52.007974
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()


# Generated at 2022-06-25 08:51:56.126185
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    callback_module_0.__dict__
    var_0 = callback_module_0.set_options(task_keys=None, var_options=None, direct=None)


# Generated at 2022-06-25 08:51:59.675135
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert callback_module_1.CALLBACK_VERSION == 2.0
    assert callback_module_1.CALLBACK_TYPE == 'aggregate'
    assert callback_module_1.CALLBACK_NAME == 'tree'
    assert callback_module_1.CALLBACK_NEEDS_ENABLED == True

# Generated at 2022-06-25 08:52:02.933146
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_1 = 'hostname'
    buffer_0 = 'buf'
    var_2 = callback_module_0.write_tree_file(var_1, buffer_0)


# Generated at 2022-06-25 08:52:04.548224
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()
    assert True



# Generated at 2022-06-25 08:52:47.590624
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_0 = CallbackModule()
    assert var_0 is not None


# Generated at 2022-06-25 08:52:55.921913
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    callback_module = CallbackModule()
    callback_module.set_options()
    assert callback_module.CALLBACK_VERSION == 2.0
    assert callback_module.CALLBACK_TYPE == 'aggregate'
    assert callback_module.CALLBACK_NAME == 'tree'
    assert callback_module.CALLBACK_NEEDS_ENABLED == True
    assert callback_module.tree == '~/.ansible/tree'
    assert callback_module.enabled == True
    #pass


# Generated at 2022-06-25 08:52:59.031961
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = 'treeroot/test'
    buf = {'PLAY FAILED': 'nice job'}
    try:
        callback_module_0.write_tree_file(var_0, buf)
    except Exception as e:
        print('Exception: {}'.format(e))


# Generated at 2022-06-25 08:53:05.784330
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = 'localhost'
    buf = 'test_buf'
    # No exception is raised.
    callback_module_write_tree_file(callback_module_0, hostname, buf)


# Generated at 2022-06-25 08:53:09.353656
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    print('test_CallbackModule_write_tree_file')
    callback_module_0 = CallbackModule()

    hostname = ''
    buf = ''
    return_value = callback_module_0.write_tree_file(hostname, buf)
    assert return_value is None


# Generated at 2022-06-25 08:53:12.183612
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_0 = CallbackModule()


# Generated at 2022-06-25 08:53:13.529785
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:53:16.467870
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    test_case_0()




# Generated at 2022-06-25 08:53:18.398887
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert type(callback_module_0) == CallbackModule


# Generated at 2022-06-25 08:53:27.240786
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_1 = CallbackModule()
    var_0 = "test_value_0"
    var_1 = "test_value_1"
    callback_module_1.write_tree_file(var_0, var_1)
    if(TREE_DIR):
        callback_module_2 = CallbackModule()
        var_2 = "test_value_2"
        var_3 = "test_value_3"
        callback_module_2.write_tree_file(var_2, var_3)

    callback_module_3 = CallbackModule()
    var_4 = "test_value_4"
    var_5 = "test_value_5"
    callback_module_3.write_tree_file(var_4, var_5)


# Generated at 2022-06-25 08:55:11.307124
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    class_0 = CallbackModule()


# Generated at 2022-06-25 08:55:12.142056
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()


# Generated at 2022-06-25 08:55:14.068804
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, CallbackModule)


# Generated at 2022-06-25 08:55:15.365824
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()
    assert var_0 is None


# Generated at 2022-06-25 08:55:16.426204
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()



# Generated at 2022-06-25 08:55:22.730196
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()

    # Tests a case when the tree dir is not set
    makedirs_safe('~/.ansible/tree')
    path = '~/.ansible/tree/test_file'
    with open(path, 'wb+') as fd:
        fd.write('test_file')
    # Tests a case when the tree dir is not set
    makedirs_safe('~/')
    callback_module_0.write_tree_file('test_file.txt', 'test_file')

    with open(path, 'wb+') as fd:
        fd.write('test_file')
    callback_module_0.write_tree_file('test_file.txt', 'test_file')

    with open(path, 'wb+') as fd:
        f

# Generated at 2022-06-25 08:55:26.807207
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname_0 = 'hostname'
    buf_0 = 'buf'
    callback_module_0.tree = 'tree'
    # Call the method
    callback_module_0.write_tree_file(hostname_0, buf_0)

# Generated at 2022-06-25 08:55:35.612371
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert hasattr(callback_module_0, 'CALLBACK_TYPE')
    try:
        assert isinstance(callback_module_0.CALLBACK_TYPE, str)
    except AssertionError:
        try:
            assert isinstance(callback_module_0.CALLBACK_TYPE, str)
        except:
            if not isinstance(callback_module_0.CALLBACK_TYPE, str):
                print('AssertionError expected')
    assert hasattr(callback_module_0, 'CALLBACK_NAME')

# Generated at 2022-06-25 08:55:37.662841
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname_0 = "hostname_0"
    buf_0 = "buf_0"
    callback_module_0.write_tree_file(hostname_0, buf_0)

# Generated at 2022-06-25 08:55:43.530021
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options(var_options=hashes, task_keys=list_0)
