

# Generated at 2022-06-25 08:48:45.811679
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # GIVEN
    set_options_0 = CallbackModule()

    # WHEN
    set_options_0.set_options()

    # THEN
    print(':: CallbackModule :: set_options')



# Generated at 2022-06-25 08:48:55.781639
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    try:
        os.remove("./test_tree/test_case")
    except OSError:
        pass
    callback_module_0 = CallbackModule()
    callback_module_0.tree = "./test_tree"
    callback_module_0.write_tree_file("test_case","test_case_0\n")
    callback_module_0.write_tree_file("test_case","test_case_1\n")
    with open("./test_tree/test_case","r") as f:
        data = f.read()
    if not data == "test_case_0\ntest_case_1\n":
        print("test fail")
    else:
        print("test success")

if __name__ == '__main__':
    test_CallbackModule_write_

# Generated at 2022-06-25 08:49:02.293040
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()
    callback_module_0.write_tree_file("test.test.test", "{\"test\":\"test\"}")


# Generated at 2022-06-25 08:49:06.199384
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    callback_module.set_options(task_keys = None)
    callback_module.set_options(task_keys = {"test_CallbackModule_set_options": "test_CallbackModule_set_options"})


# Generated at 2022-06-25 08:49:10.742667
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()

    # write something into treedir/hostname
    callback_module_0.tree = '/home/ansible/docs/maintained/callback_plugins/tree/docs/lib'
    callback_module_0.write_tree_file('ansible', 'Ansible is great!')


if __name__ == '__main__':
    test_CallbackModule_write_tree_file()

# Generated at 2022-06-25 08:49:12.781249
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()
    assert callback_module_0 is not None

# Generated at 2022-06-25 08:49:18.520582
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.write_tree_file("hostname", "buf")


# Generated at 2022-06-25 08:49:22.046174
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # Set up mock
    opts = {}
    opts['directory'] = 'directory'


    # Run the code to be tested
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(**{'task_keys': None, 'var_options': None, 'direct': None})

    # Confirm the expected result
    assert callback_module_0.get_option('directory') is None


# Generated at 2022-06-25 08:49:33.131152
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    # initial tree
    print('callback_module_0.tree', callback_module_0.tree)
    # set_options
    callback_module_0.set_options()
    # callback_module_1.set_options(task_keys=['task_keys'])  # TODO:
    # callback_module_1.set_options(var_options=['var_options'])  # TODO:
    # callback_module_1.set_options(direct=['direct'])  # TODO:
    # callback_module_1.set_options(task_keys=['task_keys'], var_options=['var_options'], direct=['direct'])  # TODO:
    # check tree again
    print

# Generated at 2022-06-25 08:49:39.276861
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(task_keys=None, var_options=None, direct=None)
    callback_module_0.write_tree_file(hostname="test", buf="test")
    callback_module_0.result_to_tree(result="test")
    callback_module_0.v2_runner_on_ok(result="test")
    callback_module_0.v2_runner_on_failed(result="test", ignore_errors=False)
    callback_module_0.v2_runner_on_unreachable(result="test")

# Generated at 2022-06-25 08:49:44.604885
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = ''
    buf = ''
    assert callback_module_0.write_tree_file(hostname, buf) is None


# Generated at 2022-06-25 08:49:46.781150
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    assert os.path.expanduser(callback_module_0.tree) != ""


# Generated at 2022-06-25 08:49:51.856281
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    import os

    from ansible.module_utils._text import to_bytes, to_text

    callback_module_2 = CallbackModule()

    b'buf'
    b'hostname'
    b'r'
    callback_module_2.write_tree_file('hostname', 'buf')
    callback_module_2.write_tree_file('hostname', b'buf')

# Generated at 2022-06-25 08:49:55.608372
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()

    # set option value
    callback_module.set_options(var_options={'directory': '~/.ansible/tree'}, direct={'_ansible_verbosity': '5'})

    assert callback_module.tree == '~/.ansible/tree'


# Generated at 2022-06-25 08:49:57.146237
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()



# Generated at 2022-06-25 08:50:08.807044
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Test case with specified tree location
    callback_module_0 = CallbackModule()
    try:
        makedirs_safe(callback_module_0.tree)
    except OSError:
        pass

    assert os.path.isdir(callback_module_0.tree)
    print("Output dir exists: %s" % callback_module_0.tree)

    callback_module_0.write_tree_file("host_1", "test_data")
    assert os.path.isfile(os.path.join(callback_module_0.tree, "host_1"))
    print("Created file %s" % os.path.join(callback_module_0.tree, "host_1"))

    assert os.path.getsize(os.path.join(callback_module_0.tree, "host_1"))

# Generated at 2022-06-25 08:50:11.073026
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()



# Generated at 2022-06-25 08:50:17.367727
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cb_m = CallbackModule()
    if cb_m.CALLBACK_VERSION <= 1.0 and cb_m.CALLBACK_TYPE == 'aggregate':
        assert True
    else:
        assert False



# Generated at 2022-06-25 08:50:22.142718
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    callback_module.set_options()
    assert(callback_module.tree is None)

    callback_module = CallbackModule()
    callback_module.set_options(var_options={'directory': 'tests'})
    assert(callback_module.tree == 'tests')

    callback_module = CallbackModule()
    callback_module.set_options(var_options={'directory': 'tests'}, direct={'tree': '.'})
    assert(callback_module.tree == '.')

    print('test_CallbackModule_set_options done')


# Generated at 2022-06-25 08:50:28.434336
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    import os
    callback_module_1 = CallbackModule()
    task_keys = None  
    var_options = None
    direct = None
    callback_module_1.set_options(task_keys, var_options, direct)



# Generated at 2022-06-25 08:50:34.130949
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-25 08:50:35.219888
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    callback_module.set_options()
    assert(callback_module.tree is not None)


# Generated at 2022-06-25 08:50:38.028526
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print(test_case_0.__doc__)
    test_case_0()

# Generated at 2022-06-25 08:50:41.252767
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        assert isinstance(callback_module_0, CallbackModule)
        print("Success: test_CallbackModule_0")
    except AssertionError:
        print("Failure: test_CallbackModule_0")


# Generated at 2022-06-25 08:50:50.059451
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    tree_dir = to_text(unfrackpath(os.path.expanduser('~/.ansible/tree')))
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()
    if not callback_module_0.tree == tree_dir:
        raise Exception('Tree dir not expected value')
    callback_module_1 = CallbackModule()
    callback_module_1.set_options(var_options=dict(directory='test_dir'))
    if not callback_module_1.tree == 'test_dir':
        raise Exception('Tree dir not expected value')

# Generated at 2022-06-25 08:50:51.661285
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    callback_module.set_options()


# Generated at 2022-06-25 08:50:52.536377
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callback_module_0 != None


# Generated at 2022-06-25 08:51:03.020649
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Setup
    test_tree_directory = "/unit_test_tree_directory"
    test_hostname = "test_hostname"
    test_buf = "test_buf"
    expected_tree_directory = "/unit_test_tree_directory/test_hostname"
    with patch('ansible.plugins.callback.tree.makedirs_safe') as mock_makedirs_safe:
        mock_makedirs_safe.side_effect = makedirs_safe
        with patch('ansible.plugins.callback.tree.open', mock_open(), create=True) as mock_open:
            mock_open.return_value.read.return_value = "test_buf"
            # Exercise
            callback_module_0 = CallbackModule()
            callback_module_0.tree = test_tree_directory
            callback_

# Generated at 2022-06-25 08:51:08.298728
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    try:
        callback_module_0.set_options()
    except TypeError as err:
        assert err.args[0] == 'set_options() takes at least 1 argument (0 given)'


# Generated at 2022-06-25 08:51:10.803932
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    task_keys = None
    var_options = None
    direct = None
    callback_module_0.set_options(task_keys=task_keys, var_options=var_options, direct=direct)


# Generated at 2022-06-25 08:51:21.625581
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Initialize the CallbackModule object
    callback_module = CallbackModule()
    # Get expected result
    expected = b'expected_outcome'
    # Call the write_tree_file method of the CallbackModule object
    callback_module.write_tree_file('hostname', 'expected_outcome')
    # In these cases, since the tree directory is not accessible, the output has to be reiterated in order to test the method

# Generated at 2022-06-25 08:51:28.820846
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    var_0 = CallbackModule()
    var_0.get_option('directory')
    var_0.get_option('directory')
    callback_set_options(var_0, var_0)
    callback_set_options(var_0, var_0, var_0)
    callback_set_options(var_0, callback_type=var_0)
    callback_set_options(var_0, callback_needs_whitelist=var_0)
    callback_set_options(var_0, callback_name=var_0)
    var_0.get_option('directory')


# Generated at 2022-06-25 08:51:32.456711
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    var_1 = callback_module_1.set_options()


# Generated at 2022-06-25 08:51:33.974501
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:51:39.384472
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Input parameters
    # The hostname to write to
    hostname = '1.2.3.4'
    
    # The data to write
    buf = 'data'

    callback_module_0 = CallbackModule()

    # Actual results
    callback_module_0.write_tree_file(hostname, buf)

    # Expected results

    # Check if the results match
    assert True # TODO



# Generated at 2022-06-25 08:51:49.339420
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options(callback_module_0, callback_module_0)
    var_1 = callback_write_tree_file(callback_module_0, callback_module_0)
    var_2 = callback_result_to_tree(callback_module_0, callback_module_0)
    var_3 = callback_v2_runner_on_ok(callback_module_0, callback_module_0)
    var_4 = callback_v2_runner_on_failed(callback_module_0, callback_module_0)
    var_5 = callback_v2_runner_on_unreachable(callback_module_0, callback_module_0)

# Generated at 2022-06-25 08:51:59.388037
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    ansible_module_0 = CallbackModule()
    var_0 = CallbackModule()
    var_1 = CallbackModule()
    var_2 = CallbackModule()
    ansible_module_1 = CallbackModule()
    var_3 = CallbackModule()
    var_4 = CallbackModule()
    var_5 = CallbackModule()
    ansible_module_2 = CallbackModule()
    var_6 = CallbackModule()
    var_7 = CallbackModule()
    var_8 = CallbackModule()
    ansible_module_3 = CallbackModule()
    var_9 = CallbackModule()
    var_10 = CallbackModule()
    var_11 = CallbackModule()
    ansible_module_4 = CallbackModule()
    var_12 = CallbackModule()
    var_13

# Generated at 2022-06-25 08:52:02.605132
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        callback_module_0 = CallbackModule()
    except Exception as err_0:
        print(err_0)
    else:
        pass
    finally:
        pass


# Generated at 2022-06-25 08:52:04.408039
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # create an instance of CallbackModule with tmp_TREE_DIR set
    callback_module = CallbackModule()
    TREE_DIR = "/usr/local/ansible/ansible_playbooks/playbooks_0"
    callback_module.set_options()
    assert (callback_module.tree == TREE_DIR)



# Generated at 2022-06-25 08:52:08.821455
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    assert os.path.exists(file_0)
    assert os.path.isdir(file_0)
    assert os.access(file_0, os.R_OK)
    assert os.access(file_0, os.W_OK)


# Generated at 2022-06-25 08:52:18.729870
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test for CallbackModule.__init__
    test_case_0()

# Generated at 2022-06-25 08:52:28.309085
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # mock
    mock_callback_module = MagicMock(CallbackModule)
    mock_hostname = MagicMock(str)
    mock_buf = MagicMock(bytes)

    # arrange
    callback_module = CallbackModule()
    callback_module.tree = "~/.ansible/tree"

    # act
    callback_module.write_tree_file(mock_hostname, mock_buf)

    # assert
    mock_callback_module.makedirs_safe.assert_called_once_with(callback_module.tree)


# Generated at 2022-06-25 08:52:35.991106
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module_0 = CallbackModule()
    module_0.set_options(
        task_keys=None,
        var_options=None,
        direct=None,
    )
    #TODO
    #module_0.write_tree_file(
    #    hostname="hostname",
    #    buf="buf",
    #)
    module_0.result_to_tree(
        result="result",
    )
    module_0.v2_runner_on_ok(
        result="result",
    )
    module_0.v2_runner_on_failed(
        result="result",
        ignore_errors=False,
    )
    module_0.v2_runner_on_unreachable(
        result="result",
    )

# Generated at 2022-06-25 08:52:41.118505
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_instance = CallbackModule()
    result = callback_module_instance.set_options(task_keys=None, var_options=None, direct=None)
    assert result == None


# Generated at 2022-06-25 08:52:42.226935
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()



# Generated at 2022-06-25 08:52:47.897260
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    print('***** In Test Case 0 *****')
    test_case_0()

if __name__ == '__main__':
    test_CallbackModule_write_tree_file()

# Generated at 2022-06-25 08:52:52.140091
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    

# Generated at 2022-06-25 08:52:54.377907
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options(task_keys=None, var_options=None, direct=None)


# Generated at 2022-06-25 08:52:57.595076
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        assert True
    except:
        assert False


# Generated at 2022-06-25 08:52:59.771059
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = u'server.example.com'
    buf = u'{}'
    callback_module_0.write_tree_file(hostname, buf)
    assert(callback_module_0.tree)


# Generated at 2022-06-25 08:53:20.381452
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    task_keys = None
    var_options = None
    direct = None
    result = callback_module.set_options(task_keys, var_options, direct)
    assert callback_module.tree == '~/.ansible/tree'


# Generated at 2022-06-25 08:53:22.386755
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module
    assert isinstance(callback_module, CallbackModule)


# Generated at 2022-06-25 08:53:24.213415
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
	callback_module = CallbackModule()
	callback_module.set_options(params = 1, var_options = 1)

test_case_0()

# Generated at 2022-06-25 08:53:25.898250
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    a = CallbackModule()
    assert isinstance(a, CallbackModule)


# Generated at 2022-06-25 08:53:26.883930
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert var_0 is not None


# Generated at 2022-06-25 08:53:29.445220
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    set_options_0 = CallbackModule()
    set_options_0.set_options(task_keys=None, var_options=None, direct=None)


# Generated at 2022-06-25 08:53:31.987271
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_1 = CallbackModule()
    hostname = "my_hostname"
    buf = "my_buf"
    callback_module_1.tree = "my_tree"
    var_1 = callback_write_tree_file(callback_module_1, hostname, buf)


# Generated at 2022-06-25 08:53:33.817686
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    res_0 = callback_module_0.write_tree_file(callback_module_0, callback_module_0)
    assert res_0 == None
    pass



# Generated at 2022-06-25 08:53:37.017472
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()
    callback_module_0.set_options(task_keys="task_keys_0", var_options="var_options_0", direct="direct_0")


# Generated at 2022-06-25 08:53:42.416756
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = "hostname"
    buf = "buf"
    assert unexeciled_function(callback_module_0._display.verbosity, 2) == unexeciled_function(callback_module_0.verbosity, 2)
    assert unexeciled_function(callback_module_0.tree, var_1) == unexeciled_function(callback_module_0._display.verbosity, 2)


# Generated at 2022-06-25 08:54:36.946372
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    print("Testing set_options...")
    callback_module_0 = CallbackModule()
    
    # Test method set_options of class CallbackModule with arguments
    # task_keys=None, var_options=None, direct=None
    try:
        callback_module_0.set_options()
    except Exception:
        print("CallbackModule.set_options(task_keys=None, var_options=None, direct=None) raised exception")

    print("Done testing set_options\n")


# Generated at 2022-06-25 08:54:39.419731
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options()


# Generated at 2022-06-25 08:54:42.148302
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert isinstance(CallbackModule, object)
    assert isinstance(CallbackModule(), CallbackModule)

# Generated at 2022-06-25 08:54:50.155857
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Constructor test case
    doc_str = "This callback is used by the Ansible (adhoc) command line option "
    callback_module_1 = CallbackModule()
    assert callback_module_1.CALLBACK_TYPE == 'aggregate', "Testcase Failed: CALLBACK_TYPE is not set properly"
    assert callback_module_1.CALLBACK_NAME == 'tree', "Testcase Failed: CALLBACK_NAME is not set properly"
    assert callback_module_1.CALLBACK_NEEDS_ENABLED == True, "Testcase Failed: CALLBACK_NEEDS_ENABLED is not set properly"
    assert callback_module_1.CALLBACK_VERSION == 2, "Testcase Failed: CALLBACK_VERSION is not set properly"
    assert callback_module_1.__doc__.strip() == doc_str

# Generated at 2022-06-25 08:54:51.807664
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_2 = None
    var_3 = None
    var_4 = None
    callback_module_0.set_options("task_keys", var_2, var_3, var_4)


# Generated at 2022-06-25 08:54:53.037492
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()


# Generated at 2022-06-25 08:55:02.139828
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Initialize a CallbackModule object with given options
    callback_module_0 = CallbackModule()
    # Create a result object
    # Get the result of the task in the result object
    var_0 = result._result
    # Dump the result object into a JSON file
    var_0 = callback_module_0._dump_results(var_0)
    # Get the hostname from the result object
    var_1 = result._host.get_name()
    # Write the JSON file into the specified directory
    var_0 = callback_write_tree_file(callback_module_0, var_0)
    return var_0


# Generated at 2022-06-25 08:55:03.676752
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options()


# Generated at 2022-06-25 08:55:07.732196
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.__name__ == 'callback_tree'
    assert callback_module_0.CALLBACK_VERSION == 2.0


# Generated at 2022-06-25 08:55:14.068315
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_2 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_2, callback_module_2)
    assert isinstance(var_0, type(callback_module_2))


if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:56:47.921164
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Set up class arguments values
    callback_module_0 = CallbackModule()
    # assert return type of __init__
    assert isinstance(callback_module_0, CallbackModule)



# Generated at 2022-06-25 08:56:50.092527
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    makedirs_safe(TREE_DIR)
    
    with open(TREE_DIR + "/write_tree_file.json", 'wb+') as fd:
        fd.write(to_bytes(var_0))


# Generated at 2022-06-25 08:56:50.974163
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    assert (set_options) == (set_options)


# Generated at 2022-06-25 08:56:51.888315
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:57:01.976180
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    hostname_0 = "example_hostname"
    buf_0 = "example_buf"
    callback_module_0 = CallbackModule()

    try:
        # Unit test for method write_tree_file of class CallbackModule
        # AssertionError: expected {'treedir': u'/tmp/treedir', '_dump_results': <bound method ? of <ansible.plugins.callback.tree.CallbackModule object at 0x7f7c0726bcd0>>, '_display': <ansible.plugins.callback.CallbackModule object at 0x7f7c0726bcd0>, 'tree': u'/tmp/treedir'} but was {}
        callback_module_0.write_tree_file(hostname_0, buf_0)
    except OSError as error:
        pass


# Generated at 2022-06-25 08:57:05.587196
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options(['task_keys', 'var_options', 'direct'])


# Generated at 2022-06-25 08:57:08.743080
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # var_0 = CallbackModule()
    assert True


# Generated at 2022-06-25 08:57:16.939454
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import os
    import tempfile

    temp_dir_0 = tempfile.gettempdir()
    os.chdir(temp_dir_0)
    # Make sure the constructor of CallbackBase is not broken
    assert not hasattr(CallbackBase, '__init__')
    assert not hasattr(CallbackBase, 'set_options')
    assert not hasattr(CallbackBase, 'dump_results')
    assert not hasattr(CallbackBase, '_dump_results')

    # Make sure the constructor of class CallbackModule is not broken
    assert not hasattr(CallbackModule, '__init__')
    assert not hasattr(CallbackModule, 'set_options')
    assert not hasattr(CallbackModule, 'write_tree_file')
    assert not hasattr(CallbackModule, 'result_to_tree')

# Generated at 2022-06-25 08:57:18.383468
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()


# Generated at 2022-06-25 08:57:20.175305
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)
