

# Generated at 2022-06-25 08:48:46.083530
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module = CallbackModule()
    assert callback_module.CALLBACK_VERSION == 2.0
    assert callback_module.CALLBACK_TYPE == 'aggregate'
    assert callback_module.CALLBACK_NAME == 'tree'
    assert callback_module.CALLBACK_NEEDS_ENABLED == True


# Generated at 2022-06-25 08:48:47.749684
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert isinstance(callback_module_1, CallbackModule)


# Generated at 2022-06-25 08:48:55.185855
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        test_case_0()
        print("Test case 0: [OK]")
    except Exception as e:
        print("[FAIL]\n")
        print("Test case 0: [FAIL]")
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#

# Generated at 2022-06-25 08:48:57.962315
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Arrange
    callback_module_0 = CallbackModule()

    # Assert
    try:
        test_case_0()
        print("test_case_0:OK")
    except:
        print("test_case_0:NG")
    return True

# Generated at 2022-06-25 08:49:03.333754
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():

    callback_module_1 = CallbackModule()
    task_keys_1 = None
    var_options_1 = None
    direct_1 = None

    callback_module_1.set_options(task_keys=task_keys_1, var_options=var_options_1, direct=direct_1)

# Generated at 2022-06-25 08:49:11.727134
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # dir parameter test
    callback_module_0 = CallbackModule()
    hn = 'hostname'
    buf = 'buf'
    callback_module_0.write_tree_file(hn, buf)
    assert callback_module_0.tree == '~/.ansible/tree'
    callback_module_0 = CallbackModule()
    hn = 'hostname'
    buf = 'buf'
    tree = 'tree'
    callback_module_0.tree = tree
    callback_module_0.write_tree_file(hn, buf)
    assert callback_module_0.tree == tree
    callback_module_0 = CallbackModule()
    hn = 'hostname'
    buf = 'buf'
    tree = '~/.ansible/tree'
    callback_module_0.tree = tree
   

# Generated at 2022-06-25 08:49:17.959995
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import sys
    import json
    import pytest
    from ansible.plugins.callback import CallbackBase, CallbackModule
    from ansible import constants
    from test.support.unit import unittest
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.path import makedirs_safe, unfrackpath
    from ansible.errors import AnsibleError
    from ansible.utils.display import Display
    from ansible.module_utils.six.moves import shlex_quote

    #
    # Unit test for method of set_options
    #
    def test_set_options():
        callback_module_0 = CallbackModule()
        callback_module_0.set_options(None, None, None)

    def test_set_options(self):
        callback_module

# Generated at 2022-06-25 08:49:23.267689
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module = CallbackModule()
    callback_module.tree = '/home/user/tree'
    callback_module.write_tree_file('node.example.com', 'test')
    callback_module.tree = '/home/user/tree'
    callback_module.write_tree_file('node.example.com', 'test')
    callback_module.tree = '/home/user/tree'
    callback_module.write_tree_file('node.example.com', 'test')

# Generated at 2022-06-25 08:49:23.656795
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    pass

# Generated at 2022-06-25 08:49:25.355407
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    assert callback_module_0.set_options() is None


# Generated at 2022-06-25 08:49:33.131340
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.disabled == False
    assert callback_module_0.plugin_name == 'tree'
    assert callback_module_0.tree == '~/.ansible/tree'


# Generated at 2022-06-25 08:49:39.708133
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    bytes_0 = b'\x0f\x8c,\xf9\x01\xf5\x0e\x8a\xad\x0e\x9d\xab\x9b\x1b\xd6\x1b\x8b\x10\xbf{\x80\x96\x1b\x19\x98\xb6\x8b\x19\x93\xa5\x81\x8b\x9b\xe5\xe1\xe5\x8a\x01'
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(bytes_0, bytes_0)


# Generated at 2022-06-25 08:49:44.379902
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    bytes_0 = b'\x14\xce\xd9\xf1\xea\xf2\xcf`\xa7\xc0'
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(bytes_0, bytes_0)


# Generated at 2022-06-25 08:49:54.193101
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import pytest
    # Test the example code from the description
    bytes_0 = b"~/.ansible/tree"
    call_back_module_0 = CallbackModule()
    call_back_module_0.set_options(var_options=bytes_0)
    call_back_module_0.CALLBACK_TYPE = "aggregate"
    with pytest.raises(AttributeError):
        call_back_module_0.write_tree_file(bytes_0, bytes_0)
    bytes_1 = b"~/.ansible/tree"
    call_back_module_1 = CallbackModule()
    call_back_module_1.set_options(var_options=bytes_1)
    call_back_module_1.CALLBACK_TYPE = "aggregate"

# Generated at 2022-06-25 08:49:58.044007
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    assert test_case_0() == True

if __name__ == '__main__':
    print("Test Case 0: " + str(test_case_0()))
    print("Test Case 1: " + str(test_case_1()))

# Generated at 2022-06-25 08:50:01.508203
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    result = callback_module_0.set_options(None, None, None)
    assert result == None


# Generated at 2022-06-25 08:50:03.335225
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    os.environ['TREE_DIR'] = '~/.ansible/tree'
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()


# Generated at 2022-06-25 08:50:08.486046
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # CASE:
    # Call with:
    # - hostname: b'2\xf2tpq\xf7\x97\x87\x9f\xecU'
    # - buf: b'2\xf2tpq\xf7\x97\x87\x9f\xecU'
    # Setup the test:
    callback_module_0 = CallbackModule()
    test_case_0()


# Generated at 2022-06-25 08:50:11.727037
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.module_utils._text import to_bytes, to_text
    callback_module_0 = CallbackModule()
    assert callback_module_0._display.verbosity == 3


# Generated at 2022-06-25 08:50:16.891697
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_set_options(callback_module_0, None, None, None)
    assert (var_0 is None)


# Generated at 2022-06-25 08:50:27.813669
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'2\xf2tpq\xf7\x97\x87\x9f\xecU'
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:50:30.149828
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    var_0 = CallbackModule()
    var_1 = None
    var_2 = None
    var_3 = None
    var_0.set_options(task_keys=var_1, var_options=var_2, direct=var_3)


# Generated at 2022-06-25 08:50:39.798746
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'*o\x86\ty\xb4\xce\x1e\x10\x95\x8d\xbd\x1a\xe6\x0f\xb8\x06\xcc\xfc\x81\xd1'
    bytes_1 = b'\x9d\x9e\xb7g\xa2\xaa\x15\x03\xc0\x04\x1d)\xb9\x8a(M\x99\xf2'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options(bytes_0, bytes_1, bytes_1)
    assert var_0 == 0

# Generated at 2022-06-25 08:50:43.203728
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():

    callback_module_0 = CallbackModule()
    bytes_0 = b'\xb7\xf8\xf1?\xc1\x1d\x8b\xed'
    var_0 = callback_write_tree_file
    callback_module_0.write_tree_file(bytes_0, var_0)


# Generated at 2022-06-25 08:50:46.629611
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import pytest
    with pytest.raises(TypeError) as excinfo:
        CallbackModule()
    exception_message = str(excinfo.value)
    assert exception_message == "object.__init__() takes no parameters"


# Generated at 2022-06-25 08:50:48.044458
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():

    callback_module_0 = CallbackModule()
    var_0 = callback_set_options(callback_module_0)

# Generated at 2022-06-25 08:50:51.052911
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    bytes_0 = b' \xfb\xac\x89'
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(None, None, None)
    test_case_0()


# Generated at 2022-06-25 08:50:55.727775
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    #  CallbackModule class instance initialization
    #  with valid parameters
    callback_module_0 = CallbackModule()

    #  CallbackModule class instance initialization
    #  with valid parameters
    callback_module_1 = CallbackModule()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 08:51:03.665495
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'2\xf2tpq\xf7\x97\x87\x9f\xecU'
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(bytes_0, bytes_0, bytes_0)
    callback_module_0.write_tree_file(bytes_0, bytes_0)
    callback_module_0.result_to_tree(bytes_0)
    callback_module_0.v2_runner_on_ok(bytes_0)
    callback_module_0.v2_runner_on_failed(bytes_0, False)
    callback_module_0.v2_runner_on_unreachable(bytes_0)

# Generated at 2022-06-25 08:51:04.262116
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    assert result == expected


# Generated at 2022-06-25 08:51:25.283407
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    cb_mock = Mock()
    cb_mock.tree = '../test/tmp'
    cb_mock.write_tree_file('test', '{\'result\': {\'rc\': 0, \'stdout\': \'test\', \'stderr\': \'test\'}}')
    with open(os.path.join(os.getcwd(), '../test/tmp/test'), 'r') as f:
        assert f.read() == '{\'result\': {\'rc\': 0, \'stdout\': \'test\', \'stderr\': \'test\'}}'
    os.remove(os.path.join(os.getcwd(), '../test/tmp/test'))


# Generated at 2022-06-25 08:51:27.787168
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = ''
    buf = ''
    var_0 = callback_write_tree_file(callback_module_0, hostname, buf)



# Generated at 2022-06-25 08:51:28.581740
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()


# Generated at 2022-06-25 08:51:38.538993
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Arrange
    callback_module_0 = CallbackModule()
    hostname = 'hostname'
    buf = 'buf'
    expected_result = None
    try:
        # Act
        actual_result = callback_module_write_tree_file(callback_module_0, hostname, buf)
        # Assert
        assert actual_result == expected_result
    except AssertionError:
        print('Expected : ' + str(expected_result) + ' but got : ' + str(actual_result))
    except Exception:
        print('An exception occurred while testing the actual result with the expected result')


# Generated at 2022-06-25 08:51:39.751799
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    var_0 = CallbackModule()
    var_1 = var_0.set_options()


# Generated at 2022-06-25 08:51:41.620607
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options()


# Generated at 2022-06-25 08:51:47.638248
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    aCallbackModule = CallbackModule()
    aCallbackModule.tree = '../test/test_tree_data/test_write_tree_file'
    aCallbackModule.write_tree_file('test_data_0', 'test_data_0')
    aCallbackModule.write_tree_file('test_data_1', 'test_data_1')


# Generated at 2022-06-25 08:51:49.670354
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # var_0
    callback_write_tree_file= 'callback_write_tree_file'

    # case_0
    test_case_0()



# Generated at 2022-06-25 08:51:51.680024
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()



# Generated at 2022-06-25 08:51:53.969151
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options()


# Generated at 2022-06-25 08:52:15.816438
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    test_case_0()

# Generated at 2022-06-25 08:52:16.522117
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:52:19.407927
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        callback_module_0 = CallbackModule()
    except NameError:
        # debugging 'CallbackModule' object has no attribute '_display'
        assert 1 == 2
    else:
        assert 1 == 1


# Generated at 2022-06-25 08:52:23.115368
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0 != ''


# Generated at 2022-06-25 08:52:27.054734
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_1 = CallbackModule()
    var_1 = callback_write_tree_file(callback_module_1, callback_module_1)


# Generated at 2022-06-25 08:52:28.456002
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    var_0 = CallbackModule()
    var_0.set_options(var_options=None, task_keys=None, direct=None)


# Generated at 2022-06-25 08:52:28.996386
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_0 = CallbackModule()


# Generated at 2022-06-25 08:52:33.602271
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():

    callback_module_0 = CallbackModule()

    # Possible testable methods for var_0 at this point

    try:
        callback_module_0.write_tree_file(callback_module_0, callback_module_0)
    except AttributeError:
        pass



# Generated at 2022-06-25 08:52:44.816768
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # Initialize data for the test
    callback_module_0 = CallbackModule()
    task_keys_0 = None
    var_options_0 = None
    direct_0 = None
    # Invoke method
    callback_module_0.set_options(task_keys_0, var_options_0, direct_0)
    # Verify that the method call did not change any of the data
    assert task_keys_0 == None
    assert var_options_0 == None
    assert direct_0 == None
    # Verify that the method call did not return anything
    assert var_0 == None


# Generated at 2022-06-25 08:52:50.987809
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():

    callback_module_0 = CallbackModule()

    # from ansible.plugins.callback.tree import CallbackModule
    # test case 0
    callback_module_0.set_options(callback_module_0)
    assert callback_module_0.tree == TREE_DIR

    # from ansible.plugins.callback.tree import to_bytes
    # test case 1
    callback_module_0.set_options(callback_module_0)
    assert callback_module_0.tree == TREE_DIR


# Generated at 2022-06-25 08:53:41.275522
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module = CallbackModule()
    callback_module.tree = 'test_tree'
    buf = 'test_buf'
    try:
        callback_module.write_tree_file('test_hostname', buf)
    except Exception as e:
        assert(False)


# Generated at 2022-06-25 08:53:44.038961
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    callback_module_1.set_options()


# Generated at 2022-06-25 08:53:48.580209
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():

    # Create a test class
    callback_module_0 = CallbackModule()

    # Test with invalid parameters
    try:
        callback_module_0.write_tree_file()
    except TypeError as e:
        assert "write_tree_file() missing 2 required positional arguments: 'hostname' and 'buf'" in str(e)

    # Test with valid parameters
    try:
        callback_module_0.write_tree_file(callback_module_0, callback_module_0)
    except TypeError:
        assert False


# Generated at 2022-06-25 08:53:51.240947
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    var_1 = callback_set_options(callback_module_1, callback_module_1)


# Generated at 2022-06-25 08:53:53.875008
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = 'hostname'
    buf = 'buf'
    var_0 = callback_write_tree_file(callback_module_0, hostname, buf)


# Generated at 2022-06-25 08:53:56.660208
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_set_options_0 = callback_module_0.set_options()
    assert callback_module_set_options_0 == None


# Generated at 2022-06-25 08:54:04.549678
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(task_keys=None, var_options=None, direct=None)
    var_1 = callback_write_tree_file(callback_module_0, callback_module_0)
    if isinstance(var_1, str):
        print("[OK] Return result of method write_tree_file is: %s" % var_1)
    else:
        print("[ERROR] Return result of method write_tree_file is: %s" % var_1)


# Generated at 2022-06-25 08:54:05.615822
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert obj_0 is not []

# Generated at 2022-06-25 08:54:10.058593
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule.CALLBACK_VERSION == 2.0
    assert CallbackModule.CALLBACK_TYPE == 'aggregate'
    assert CallbackModule.CALLBACK_NAME == 'tree'
    assert CallbackModule.CALLBACK_NEEDS_ENABLED == True


# Generated at 2022-06-25 08:54:14.237378
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:56:16.002454
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)



# Generated at 2022-06-25 08:56:21.236897
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    # place test code here
    var_0 = callback_module_0.write_tree_file(callback_module_0, callback_module_0)


# Generated at 2022-06-25 08:56:22.756212
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    var_1 = callback_module_1.set_options()


# Generated at 2022-06-25 08:56:24.168924
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, CallbackModule)


# Generated at 2022-06-25 08:56:30.855403
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert CallbackModule.CALLBACK_VERSION == 2.0, "callback_version is wrong"
    assert CallbackModule.CALLBACK_TYPE == "aggregate", "callback_type is wrong"
    assert CallbackModule.CALLBACK_NAME == "tree", "callback_name is wrong"
    assert CallbackModule.CALLBACK_NEEDS_ENABLED == True, "callback_needs_enabled is wrong"


# Generated at 2022-06-25 08:56:32.462708
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    var_1 = CallbackModule()
    var_2 = var_1.set_options()


# Generated at 2022-06-25 08:56:38.891977
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Define mock objects and method mocks here
    callback_module_0 = CallbackModule()
    assert len(callback_module_0._tasks) == 0
    assert len(callback_module_0._play) == 0
    assert callback_module_0._play_context is None
    assert callback_module_0._last_task is None
    assert callback_module_0._task_fields is None
    assert len(callback_module_0._host_fields) == 0
    assert callback_module_0._result_fields is None
    assert len(callback_module_0._event_fields) == 0
    assert len(callback_module_0._event_data) == 0
    assert callback_module_0._show_custom_stats is False
    assert callback_module_0._display is None
    assert callback_module_0._dump

# Generated at 2022-06-25 08:56:46.712295
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Preparation
    callback_module = CallbackModule()
    callback_module.tree = "~/ansible/tree"
    callback_module.write_tree_file("test_host_0","test_buf_0")

    # Test
    callback_module = CallbackModule()
    callback_module.tree = "~/ansible/tree"
    callback_module.write_tree_file("test_host_1","test_buf_1")

    # Postconditions
    assert True


# Generated at 2022-06-25 08:56:47.397236
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    test_case_0()

# Generated at 2022-06-25 08:56:49.356173
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = Buffer()
    callback_module_0.write_tree_file(callback_module_0, var_0)
