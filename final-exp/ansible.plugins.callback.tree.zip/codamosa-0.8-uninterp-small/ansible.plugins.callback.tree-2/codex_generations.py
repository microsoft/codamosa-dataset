

# Generated at 2022-06-25 08:48:47.590119
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_1 = CallbackModule()
    callback_module_1.tree = "test/test_dir"
    callback_module_1.write_tree_file("test_hostname", "{}")


# Generated at 2022-06-25 08:48:50.144343
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    CallbackModule.write_tree_file("hostname", "buf")


# Generated at 2022-06-25 08:48:55.859205
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        callback_module_0 = CallbackModule()
    except Exception as e:
        print(e)

test_CallbackModule()

# Generated at 2022-06-25 08:49:01.560127
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.write_tree_file("test_0", "ascii")


# Generated at 2022-06-25 08:49:03.249945
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    global callback_module_0
    assert isinstance(callback_module_0, CallbackModule)

#Unit test for method CallbackModule.set_options

# Generated at 2022-06-25 08:49:07.683549
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = "hostname_0"
    buf = "buf_0"
    result = callback_module_0.write_tree_file(hostname, buf) # exception raised
    assert result is None


# Generated at 2022-06-25 08:49:17.425881
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    from ansible.plugins.callback.tree import write_tree_file
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    import os

    test_dir = os.path.dirname(os.path.abspath(__file__))
    print("Test Data Source: " + test_dir)
    test_data_path = os.path.join(test_dir, 'fixtures', 'callback_plugin_tree_data.yml')
    print("Test Data Path: " + test_data_path)


# Generated at 2022-06-25 08:49:20.258494
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()
    assert callback_module_0.tree == '~/.ansible/tree' or callback_module_0.tree == '/etc/ansible/tree'


# Generated at 2022-06-25 08:49:25.245714
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    """set_options(task_keys=None, var_options=None, direct=None)"""
    callback_module_1 = CallbackModule()
    callback_module_2 = CallbackModule()

    callback_module_1.set_options()
    callback_module_2.set_options(task_keys=None, var_options=None, direct=None)

    assert callback_module_1 is not None
    assert callback_module_2 is not None

# Generated at 2022-06-25 08:49:27.801669
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # Creation
    callback_module = CallbackModule()

    # Set options for the callback module
    callback_module.set_options(task_keys=None, var_options=None, direct=None)


# Generated at 2022-06-25 08:49:39.056199
# Unit test for constructor of class CallbackModule

# Generated at 2022-06-25 08:49:43.684975
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    method_name = 'write_tree_file'
    args = (callback_module_0, "test_hostname", 'test_buf')
    call_results = method_call(*args)



# Generated at 2022-06-25 08:49:50.080193
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()

    # Test exception of type Exception
    try:
        callback_module_0.write_tree_file('hostname_0', 'buf_0')
    except Exception as e_0:
        assert isinstance(e_0, Exception)
    else:
        # Throw exception if this test case failed
        raise Exception("Unit test exception occurred")



# Generated at 2022-06-25 08:49:50.622748
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()

# Generated at 2022-06-25 08:49:55.096443
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module._plugin_options == {}
    assert callback_module.tree == '~/.ansible/tree'
    assert callback_module.CALLBACK_VERSION == 2.0
    assert callback_module.CALLBACK_TYPE == 'aggregate'
    assert callback_module.CALLBACK_NAME == 'tree'

# Generated at 2022-06-25 08:49:58.042492
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    test_callback_module_0 = CallbackModule()
    test_callback_module_0.write_tree_file("hostname_0", "buf_0")


# Generated at 2022-06-25 08:50:08.882360
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    with patch.object(CallbackModule, 'set_options') as mock_set_options, \
            patch.object(CallbackModule, 'write_tree_file') as mock_write_tree_file:
        callback_module_1 = CallbackModule()
        callback_module_1.tree = '~/.ansible'
        hostname = '127.0.0.1'
        buf = '''[root@localhost ~]# cat ~/.ansible/127.0.0.1 
{"127.0.0.1": {"changed": false, "invocation": {"module_args": {"name": "root"}, "module_name": "user"}}}
[root@localhost ~]# 
'''
        mock_write_tree_file.return_value = True

# Generated at 2022-06-25 08:50:13.324389
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    assert find_str_in_file('CallbackModule', 'CallbackModule.py') == True
    assert find_str_in_file('write_tree_file(hostname, buf)', 'CallbackModule.py') == True
    callback_module = CallbackModule()
    callback_module.write_tree_file('test path', 'test buf')


# Generated at 2022-06-25 08:50:14.622843
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:50:17.986044
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_2 = CallbackModule()
    # Pass:
    callback_module_2.set_options(task_keys=None, var_options=None, direct=None)



# Generated at 2022-06-25 08:50:28.504595
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        test_case_0()
        print("Constructor of class CallbackModule works.\n")
    except Exception:
        print("Exception occurred; constructor of class CallbackModule may not be working.\n")


# Generated at 2022-06-25 08:50:29.873800
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.write_tree_file('hostname', 'buf')
    assert True


# Generated at 2022-06-25 08:50:30.316246
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    assert True==True

# Generated at 2022-06-25 08:50:33.940226
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()


# Generated at 2022-06-25 08:50:38.539491
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:50:45.605625
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    task_keys_0 = None
    var_options_0 = None
    direct_0 = None
    callback_module_0.set_options(task_keys=task_keys_0, var_options=var_options_0, direct=direct_0)
    assert callback_module_0.tree is None


# Generated at 2022-06-25 08:50:49.483116
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # create an instance of the CallbackModule class
    callback_module_0 = CallbackModule()
    # set some options for the instance
    callback_module_0.set_options({"task_keys": None, "var_options": None, "direct": None})
    # check whether the set_options method of the instance runs without errors
    assert callback_module_0


# Generated at 2022-06-25 08:50:53.309092
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Declare the function input parameters
    hostname = "hostname"
    buf = "buf"
    # Instantiate the callback class
    callback_module_0 = CallbackModule()
    # Execute the function under test
    callback_module_0.write_tree_file(hostname, buf)


# Generated at 2022-06-25 08:50:55.574794
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:50:59.262891
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    print("\n\n\nInvoking test_CallbackModule_set_options")
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()
    print("\nInvoking test_CallbackModule_set_options completed")


# Generated at 2022-06-25 08:51:09.454497
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # Initializing argument
    task_keys_1 = "foo"
    var_2 = {'a': 1, 'b': 2}
    direct_3 = True

    # Initializing instance
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(task_keys_1, var_2, direct_3)


# Generated at 2022-06-25 08:51:11.208747
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_1 = CallbackModule()
    assert callback_module_write_tree_file(callback_module_1, hostname, buf) == None


# Generated at 2022-06-25 08:51:14.218809
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options(task_keys=None, var_options=None, direct=None)


# Generated at 2022-06-25 08:51:17.969763
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.write_tree_file(hostname=str(), buf=str())
    print(var_0)


# Generated at 2022-06-25 08:51:20.147694
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()


# Generated at 2022-06-25 08:51:21.861971
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    assert callback_module_0.set_options()


# Generated at 2022-06-25 08:51:24.502045
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options()


# Generated at 2022-06-25 08:51:25.766548
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_obj = CallbackModule()
# Test initialization

# Generated at 2022-06-25 08:51:27.943336
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    var_1 = CallbackModule()
    var_2 = callback_set_options()
    var_1.set_options(var_2)


# Generated at 2022-06-25 08:51:33.296170
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    var = CallbackModule()
    var.set_options()
    var.set_options(task_keys=["task_keys"], var_options=["var_options"], direct=["direct"])


# Generated at 2022-06-25 08:51:47.698066
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    # Test using both string and bytes values
    hostname = to_bytes("hostname")
    buf = b"buf"
    callback_module_0.write_tree_file(hostname, buf)


# Generated at 2022-06-25 08:51:49.695546
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()
    callback_module_0.set_options(var_0)


# Generated at 2022-06-25 08:51:52.416557
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    cb_m = CallbackModule()
    assert cb_m.write_tree_file(hostname, buf) == None


# Generated at 2022-06-25 08:51:53.969152
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_1 = CallbackModule()
    hostname_1 = 'hostname'
    buf_1 = 'buf'
    callback_module_1.write_tree_file(hostname_1, buf_1)


# Generated at 2022-06-25 08:51:56.227623
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()
    var_1 = callback_module_0.set_options(var_0)
    assert var_1 is not None


# Generated at 2022-06-25 08:51:58.136137
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Return type hint is incorrect. The type hint should be "CallbackModule"
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:52:00.579549
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()


# Generated at 2022-06-25 08:52:03.844724
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_1 = CallbackModule()
    path = callback_module_1.write_tree_file('localhost', '{"test": "foo"}')
    assert path == '/Users/wdstevens/.ansible/tree/localhost'


# Generated at 2022-06-25 08:52:05.154520
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()


# Generated at 2022-06-25 08:52:12.802195
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname_0 = 'jhgfvbnj'
    buf_0 = '1\n'
    callback_module_0.write_tree_file(hostname_0,buf_0)
    hostname_1 = 'jhgfvbnj'
    buf_1 = '00sdfgfd1\n'
    callback_module_0.write_tree_file(hostname_1,buf_1)


# Generated at 2022-06-25 08:52:43.615608
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_write_tree_file_0 = CallbackModule()
    str_0 = 'hostname'
    bytes_0 = callback_write_tree_file_0.write_tree_file(str_0, 'hostname')


# Generated at 2022-06-25 08:52:47.080384
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_1 = CallbackModule()
    print(callback_1)

# Generated at 2022-06-25 08:52:50.071840
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # Failed on me
    var_0 = CallbackModule()
    var_1 = None
    var_2 = None
    var_3 = None
    var_0.set_options(var_1, var_2, var_3)



# Generated at 2022-06-25 08:52:53.889579
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    var_0 = CallbackModule()
    var_1 = None
    var_2 = None
    var_3 = None
    var_0.set_options(var_1,var_2,var_3)


# Generated at 2022-06-25 08:52:58.216972
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Make sure the object was created properly
    assert callback_module_0 != None
    try:
        # Call the method
        callback_module_0.write_tree_file(hostname, buf)
        # Verify the results (This will fail if you did not implement the write_tree_file method)
        assert callback_module_0.write_tree_file(hostname, buf) == "write_tree_file method was not implemented"
    except:
        # Exceptions will result in a failure
        assert False



# Generated at 2022-06-25 08:53:04.039551
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # CallbackModule: Test write_tree_file
    callback_module_0 = CallbackModule()
    var_0 = CallbackModule()
    var_1 = os.urandom(4)
    var_2 = os.urandom(4)
    callback_module_0.write_tree_file(var_1, var_2)



# Generated at 2022-06-25 08:53:07.257249
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    assert True == callback_write_tree_file()


# Generated at 2022-06-25 08:53:08.841598
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Create a new instance of class CallbackModule
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:53:10.921761
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = "hostname0"
    buf = "buf0"
    callback_module_0.write_tree_file(hostname, buf)


# Generated at 2022-06-25 08:53:13.537022
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    if TREE_DIR:
        # TREE_DIR comes from the CLI option --tree, only avialable for adhoc
        tree = unfrackpath(TREE_DIR)
    else:
        tree = callback_get_option('directory')
    callback_module = CallbackModule()
    assert callback_module is not None


# Generated at 2022-06-25 08:54:09.985699
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    try:
        var_0 = CallbackModule()
        var_1 = 'string'
        var_2 = 'string'
        var_0.write_tree_file(var_1, var_2)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 08:54:15.400513
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    makedirs_safe(TREE_DIR)
    callback_module = CallbackModule()
    callback_module.tree = TREE_DIR
    callback_module.write_tree_file(hostname='host', buf='buf')


# Generated at 2022-06-25 08:54:21.195664
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    print("Test: set_options")

    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()


# Generated at 2022-06-25 08:54:24.374651
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()

# Generated at 2022-06-25 08:54:30.131508
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()
    # call the method
    callback_module_0.write_tree_file(var_0, var_0)
    return


# Generated at 2022-06-25 08:54:33.393680
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    callback_module.set_options()

# Generated at 2022-06-25 08:54:34.497184
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    print("Waiting for unit test result.")
#    assert result == expected_result

# Generated at 2022-06-25 08:54:38.890397
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()




# Generated at 2022-06-25 08:54:41.938094
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    pass


if __name__ == '__main__':
    print("Running Test " + "__main__")
    test_case_0()

# Generated at 2022-06-25 08:54:48.071616
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.errors import AnsibleError
    from ansible.utils.listify import listify_lookup_plugin_terms, listify_lookup_plugin_terms_as_string
    from ansible.utils.path import unfrackpath

    callback_module_4 = CallbackModule()
    assert callback_module_4.tree == '~/.ansible/tree', 'Construction of class CallbackModule is incorrect'


# Generated at 2022-06-25 08:56:47.191465
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_write_tree_file = CallbackModule()
    callback_write_tree_file.tree = "Sample tree"
    hostname = "Sample hostname"
    buf = "Sample buf"

    # Call method write_tree_file of class CallbackModule
    output = callback_write_tree_file.write_tree_file(hostname, buf)


# Generated at 2022-06-25 08:56:48.666912
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options()


# Generated at 2022-06-25 08:56:50.807144
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    buf = bytearray(b"nothing")
    callback_module_0 = CallbackModule()
    hostname = "something from nothing"
    callback_module_0.write_tree_file(hostname, buf)


# Generated at 2022-06-25 08:56:54.195428
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
  callback_module_0 = CallbackModule()
  task_keys_0 = None
  var_0 = None
  direct_0 = None
  callback_module_0.set_options(task_keys=task_keys_0, var_options=var_0, direct=direct_0)



# Generated at 2022-06-25 08:57:01.078368
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_1 = CallbackModule()
    var_1 = callback_set_options()
    hostname_1 = var_1._host.get_name()
    buf_1 = var_1._dump_results(var_1._result)
    status_1 = callback_module_1.write_tree_file(hostname_1, buf_1)

    assert status_1 is None, "Status should be None."


# Generated at 2022-06-25 08:57:06.021001
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname_0 = "localhost"
    buf_0 = "~/test/tree"
    return_value_0 = callback_module_0.write_tree_file(hostname_0, buf_0)



# Generated at 2022-06-25 08:57:10.537160
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()


# Generated at 2022-06-25 08:57:12.308233
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    var_1 = CallbackModule()
    func_0 = write_tree_file()
    func_1 = write_tree_file()


# Generated at 2022-06-25 08:57:18.415256
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(task_keys="task_keys_0", var_options="var_options_0", direct="direct_0")
    var_0 = callback_module_0.write_tree_file("hostname_0", "buf_0")
    var_1 = callback_module_0.result_to_tree("result_0")
    var_2 = callback_module_0.v2_runner_on_ok("result_0")
    var_3 = callback_module_0.v2_runner_on_failed("result_0", ignore_errors=False)
    var_4 = callback_module_0.v2_runner_on_unreachable("result_0")


# Generated at 2022-06-25 08:57:20.470357
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options()
    var_1 = callback_write_tree_file(hostname, buf)
