

# Generated at 2022-06-25 08:48:42.378009
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_1 = CallbackModule()
    callback_module_1.tree = 'tree'
    callback_module_1.write_tree_file('hostname', 'buf')


# Generated at 2022-06-25 08:48:45.724266
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    callback_module_1.set_options()


# Generated at 2022-06-25 08:48:50.187456
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    class_CallbackModule = CallbackModule()
    assert class_CallbackModule is not None

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:49:00.629203
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_1 = CallbackModule()
    callback_module_1._display = 'display_object'
    makedirs_safe_method_mock = Mock()
    makedirs_safe_method_mock.return_value = None
    callback_module_1.makedirs_safe = makedirs_safe_method_mock
    to_bytes_method_mock = Mock()
    to_bytes_method_mock.return_value = 'Test_value_of_return'
    callback_module_1.to_bytes = to_bytes_method_mock
    to_text_method_mock = Mock()
    to_text_method_mock.return_value = 'Test_value_of_return'
    callback_module_1.to_text = to_text_method_mock
   

# Generated at 2022-06-25 08:49:07.397754
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module.CALLBACK_VERSION == 2.0
    assert callback_module.CALLBACK_TYPE == 'aggregate'
    assert callback_module.CALLBACK_NAME == 'tree'
    assert callback_module.CALLBACK_NEEDS_ENABLED == True

# Generated at 2022-06-25 08:49:16.622974
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module = CallbackModule()
    try:
        makedirs_safe(callback_module.tree)
    except (OSError, IOError) as e:
        callback_module._display.warning(u"Unable to access or create the configured directory (%s): %s" % (to_text(callback_module.tree), to_text(e)))
    callback_module.write_tree_file('test_host', 'test')
    path = to_bytes(os.path.join(callback_module.tree, 'test_host'))
    with open(path, 'r') as f:
        assert f.read() == 'test'
    os.remove(path)

# Generated at 2022-06-25 08:49:19.963577
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    opt_set_args = calling_kwargs(task_keys=None, var_options=None, direct=None)
    callback_module_1.set_options(**opt_set_args)


# Generated at 2022-06-25 08:49:21.026817
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callback_module_0.tree == "/etc/ansible/tree"

# Generated at 2022-06-25 08:49:24.587531
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = "test_hostname_0"
    buf = ("test_buf_0" + 'ansible')
    callback_module_0.write_tree_file(hostname, buf)



# Generated at 2022-06-25 08:49:30.713509
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    task_keys_0 = None
    var_options_0 = None
    direct_0 = None
    callback_module_0.set_options(task_keys=task_keys_0, var_options=var_options_0, direct=direct_0)


# Generated at 2022-06-25 08:49:39.225533
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    if isinstance(callback_module_0, CallbackModule):
        print("Test 0 passed.")
    else:
        print("Test 0 failed.")


# Generated at 2022-06-25 08:49:40.113599
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_2 = CallbackModule()

# Generated at 2022-06-25 08:49:41.524845
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        assert callback_module_0.tree == None
    except:
        print('Code threw an exception')


# Generated at 2022-06-25 08:49:45.405352
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'aggregate'
    assert callback_module_0.CALLBACK_NAME == 'tree'
    assert callback_module_0.CALLBACK_NEEDS_ENABLED == True


# Generated at 2022-06-25 08:49:47.440275
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options() # Implicitly called within __init__


# Generated at 2022-06-25 08:49:50.406352
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)


# Generated at 2022-06-25 08:49:54.299811
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():

    # init variable
    callback_module = CallbackModule()
    callback_module.options = {
        'directory': '~/.ansible/tree',
        'enabled': True
    }
    callback_module.tree = None

    # call function
    callback_module.set_options()

    assert callback_module.tree == '~/.ansible/tree'

# Generated at 2022-06-25 08:49:56.332995
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()


# Generated at 2022-06-25 08:50:07.114084
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test the constructor of class CallbackModule: def __init__(self): pass
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(task_keys=None, var_options=None, direct=None)
    callback_module_0.v2_runner_on_ok(result=None)
    callback_module_0.v2_runner_on_failed(result=None, ignore_errors=False)
    callback_module_0.v2_runner_on_unreachable(result=None)
    callback_module_0.result_to_tree(result=None)


# Generated at 2022-06-25 08:50:10.754102
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    # Variable assignment
    var_0 = callback_module_0
    # Calling method set_options of class CallbackModule
    var_1 = var_0.set_options()
    return var_1


# Generated at 2022-06-25 08:50:18.406631
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import unittest
    class TestCase1(unittest.TestCase):
        def test_constructor(self):
            CallbackModule()

    unittest.main()


# Generated at 2022-06-25 08:50:21.813536
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():

    callback_module_1 = CallbackModule()

    assert callback_write_tree_file(callback_module_1, callback_module_1)


# Generated at 2022-06-25 08:50:23.293200
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_1 = CallbackModule()
    assert isinstance(callback_module_1.write_tree_file("hostname", "buf"), NoneType)


# Generated at 2022-06-25 08:50:26.463138
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    callback_module_2 = CallbackModule()

# Generated at 2022-06-25 08:50:28.485534
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    obj = CallbackModule()
    test_case_0()

# Generated at 2022-06-25 08:50:29.660211
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    var_1 = callback_module_1.set_options()


# Generated at 2022-06-25 08:50:30.616754
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    test_case_0(callback_module_0)

# Generated at 2022-06-25 08:50:31.734030
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    assert type(callback_module_1.set_options()) == None


# Generated at 2022-06-25 08:50:33.359121
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module = CallbackModule()
    callback_module.tree = None
    assert not callback_module.write_tree_file("hostname", "buf"), "The method write_tree_file() did not return expected value"


# Generated at 2022-06-25 08:50:36.090899
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options(callback_module_0, callback_module_0)



# Generated at 2022-06-25 08:50:49.010867
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()


# Generated at 2022-06-25 08:50:51.094662
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    callback_module_0._display.display(u"debug")


# Generated at 2022-06-25 08:50:58.276608
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    lst_0 = [(0, 0), (0, 1), (1, 0), (1, 1)]
    var_0 = next(lst_0, None)
    while var_0 is not None:
        temp_0 = var_0[0]
        temp_1 = var_0[1]
        var_0 = next(lst_0, None)

if __name__ == '__main__':
    test_case_0()
    test_CallbackModule_write_tree_file()

# Generated at 2022-06-25 08:50:59.452152
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:51:08.384867
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0.set_options(task_keys=None, var_options=None, direct=None), CallbackModule)
    assert type(callback_module_0.write_tree_file(hostname=hostname, buf=buf)) is int
    assert isinstance(callback_module_0.write_tree_file(hostname=hostname, buf=buf), int)
    assert callback_module_0.write_tree_file(hostname=hostname, buf=buf) == 0
    assert type(callback_module_0.result_to_tree(result=result)) is int
    assert isinstance(callback_module_0.result_to_tree(result=result), int)
    assert callback_module_0.result_to_tree(result=result)

# Generated at 2022-06-25 08:51:10.764664
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = ''
    buf = ''
    assert callback_module_0.write_tree_file(hostname, buf) == None


# Generated at 2022-06-25 08:51:11.453674
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:51:13.520108
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    var = callback_module.set_options(task_keys = None, var_options = None, direct = None)



# Generated at 2022-06-25 08:51:25.043876
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = CallbackModule()
    var_1 = CallbackModule()
    var_2 = 'callback_tree_directory'
    var_3 = 'callback_tree_directory'
    var_4 = 'callback_tree_directory'
    var_5 = 'callback_tree_directory'
    callback_module_0.set_options(var_0, var_1, var_2, var_3, var_4, var_5)
    var_6 = 'ansible_play_hosts'
    var_7 = 'ansible_play_hosts'
    var_8 = 'ansible_play_hosts'
    var_9 = 'ansible_play_hosts'
    var_10 = 'ansible_play_hosts'
    callback_module

# Generated at 2022-06-25 08:51:27.864768
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = "127.0.0.1"
    buf = "random"
    var_0 = callback_module_0.write_tree_file(hostname, buf)


# Generated at 2022-06-25 08:51:48.995836
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:51:51.605316
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options()


# Generated at 2022-06-25 08:51:52.811961
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:51:57.071949
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)
    if var_0:
        assert True
    else:
        assert False


# Generated at 2022-06-25 08:52:00.124503
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    pass

# Generated at 2022-06-25 08:52:05.361559
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_2 = CallbackModule()
    var_1 = callback_module_2._dump_results(callback_module_2)
    var_2 = callback_module_2.set_options(var_1, var_1, var_1)
    var_3 = callback_module_2.result_to_tree(var_1)
    var_4 = callback_module_2.v2_runner_on_failed(var_1, var_1)
    var_5 = callback_module_2.v2_runner_on_ok(var_1)
    var_6 = callback_module_2.v2_runner_on_unreachable(var_1)
    var_7 = callback_module_2.write_tree_file(var_1, var_1)


# Generated at 2022-06-25 08:52:10.433182
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback = CallbackModule()
    assert callback.set_options() == None


# Generated at 2022-06-25 08:52:15.778316
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():

    # create stub
    args = ["/home/john/code/ansible/test/callback_plugins", "treedir", "dummy"]
    args_0 = stub.create_stub({"ansible.module_utils.basic.AnsibleModule", *args})
    Dummy = stub.create_class_stub("Dummy", args_0)
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, "hostname", "buf")



# Generated at 2022-06-25 08:52:17.565953
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():

    callback_module_0 = CallbackModule()
    # Below code is for example only
    # Replace or append your code here
    var_0 = callback_module_0.set_options()


# Generated at 2022-06-25 08:52:18.528256
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:53:07.414702
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()


# Generated at 2022-06-25 08:53:09.777065
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    args = []
    verify_args = []
    # No exception print_function
    result = CallbackModule.write_tree_file(*args, **kwargs)
    assert (result == verify_args)


# Generated at 2022-06-25 08:53:17.479171
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    '''
    Unit test for method write_tree_file of class CallbackModule
    '''
    hostname = 'test_hostname'
    buf = 'test_buf'
    callback_module_test = CallbackModule()
    callback_module_test.tree = 'test_tree'

    # CallbackModule.write_tree_file()
    callback_module_test.write_tree_file(hostname, buf)


# Generated at 2022-06-25 08:53:24.854163
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    args = []
    if not len(args) == 2:
        raise AssertionError("Expected 2 arguments, got %d" % len(args))
    if not isinstance(args[0], CallbackModule):
        raise AssertionError("Expected type CallbackModule, got %s" % type(args[0]))
    if not isinstance(args[1], CallbackModule):
        raise AssertionError("Expected type CallbackModule, got %s" % type(args[1]))
    # Return type: 
    # Raises: 
    result = callback_module_0.write_tree_file(callback_module_0, callback_module_0)


# Generated at 2022-06-25 08:53:29.011470
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    #
    # Expectation:
    # throw IOError()
    #
    callback_module_0 = CallbackModule()
    callback_module_0.tree = 'tree'  # Make this call work for any path
    callback_module_0.write_tree_file(hostname='hostname', buf='buf')

# Generated at 2022-06-25 08:53:30.470873
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_0 = CallbackModule()
    assert var_0.tree != None
    assert var_0 != None


# Generated at 2022-06-25 08:53:31.985307
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, CallbackModule)
    assert callback_module_0._display is not None


# Generated at 2022-06-25 08:53:37.194928
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    # dir exists
    try:
        makedirs_safe("./some")
    except (OSError, IOError) as e:
        print("Unable to access or create the configured directory: %s" % (to_text(e)))
    callback_module_0.set_options(var_options="./some")
    assert callback_module_0.tree == unfrackpath("./some")

    # dir not exists
    callback_module_0.set_options(var_options="./test")
    assert callback_module_0.tree == unfrackpath("./test")

    # dir not exists + dir not allow create

# Generated at 2022-06-25 08:53:41.871941
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert callback_module_1._display.verbosity == 2

# Generated at 2022-06-25 08:53:46.449252
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = 'hostname'
    buf = ''
    path = None
    fd = None
    callback_module_0.write_tree_file(hostname, buf)
    assert path == None


# Generated at 2022-06-25 08:55:49.640637
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Create a new instance of CallbackModule
    cbm = CallbackModule()
    assert isinstance(cbm, CallbackModule)


# Generated at 2022-06-25 08:55:51.458541
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass


# Generated at 2022-06-25 08:55:54.016942
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options(callback_module_0, callback_module_0)


# Generated at 2022-06-25 08:56:01.267842
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0 != None
    assert callback_module_0._display != None
    assert callback_module_0.disabled != None
    assert callback_module_0.disabled != False
    assert callback_module_0._options != None
    assert callback_module_0._plugin_name != None
    assert callback_module_0._dump_results != None


# Generated at 2022-06-25 08:56:03.564416
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    TREE_DIR = None
    var_0 = CallbackModule(TREE_DIR)
    print(var_0)


# Generated at 2022-06-25 08:56:06.657617
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.path import makedirs_safe, unfrackpath
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.write_tree_file(hostname, buf)



# Generated at 2022-06-25 08:56:13.445988
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Test with value of type bool (false)
    var_1 = False
    callback_module_1 = CallbackModule(var_1)
    # Test with value of type bool (true)
    var_2 = True
    callback_module_2 = CallbackModule(var_2)
    # Test with value of type int
    var_3 = callback_add_tid(callback_module_2)
    callback_module_3 = CallbackModule(var_3)
    # Test with value of type list
    var_4 = [1, 2, 3]
    callback_module_4 = CallbackModule(var_4)
    # Test with value of type str
    var_5 = 'ansible'
    callback_module_5 = CallbackModule(var_5)
    # Test with value of type tuple
    var_

# Generated at 2022-06-25 08:56:16.390209
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    # Test the default case
    callback_module_0.set_options()
    # Test the CallbackBase case
    var_callback_keys = 0
    var_callback_options = 0
    var_direct = 0
    CallbackBase.set_options(var_callback_keys, var_callback_options, var_direct)


# Generated at 2022-06-25 08:56:19.519925
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callbackModule_instance = CallbackModule()


# Generated at 2022-06-25 08:56:20.598763
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(task_keys=None, var_options=None, direct=None)
