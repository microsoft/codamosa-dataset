

# Generated at 2022-06-25 08:48:51.984595
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    config = dict(option1='value1', option2='value2')
    callback = 'callback'
    loader = None
    tmpdir = None
    plugin_options = dict(plugin_option1='plugin_value1', plugin_option2='plugin_value2')
    connection = 'connection'

    callback_module = CallbackModule(callback, config, loader, tmpdir, plugin_options, connection)
    callback_module.set_options(task_keys=config, var_options=plugin_options, direct=connection)
    assert callback_module.get_option('option1') == 'value1'
    assert callback_module.get_option('option2') == 'value2'
    assert callback_module.get_option('plugin_option1') == 'plugin_value1'

# Generated at 2022-06-25 08:48:55.170517
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()


# Generated at 2022-06-25 08:49:01.186459
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str_1 = ' Ts]V\\:V{`JuE(Vkv'
    callback_module_1 = CallbackModule()
    var_1 = callback_module_1.result_to_tree(str_1)
    str_2 = "n{v|P-zW>OO`D^[f`"
    var_2 = callback_module_1.write_tree_file(str_2)
    str_3 = ' Ts]V\\:V{`JuE(Vkv'
    str_4 = "n{v|P-zW>OO`D^[f`"
    var_3 = callback_module_1.set_options(str_3, str_4)
    str_5 = "n{v|P-zW>OO`D^[f`"
    str_

# Generated at 2022-06-25 08:49:08.254171
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    str_0 = ' Ts]V\\:V{`JuE(Vkv'
    callback_module_0 = CallbackModule()
    makedirs_safe( 'wW~lZ' )
    with open('0%&7', 'wb+') as fd:
        fd.write( to_bytes( callback_v2_runner_on_failed(str_0) ) )



# Generated at 2022-06-25 08:49:10.996119
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # noinspection PyMethodParameters
    class AnyClass:
        def __init__(self, tree):
            self.tree = tree
    hostname = 'my_hostname'
    buf = 'my_buf'
    test_CallbackModule = CallbackModule()
    # noinspection PyArgumentList
    test_CallbackModule.write_tree_file(hostname, buf)


# Generated at 2022-06-25 08:49:17.241725
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    x = CallbackModule()
    hostname = "hostname"
    buf = "buf"
    x.write_tree_file(hostname, buf)
    assert x.tree == "~/.ansible/tree"


# Generated at 2022-06-25 08:49:18.819364
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_0 = CallbackModule()
    assert var_0 == None


# Generated at 2022-06-25 08:49:27.188713
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    fd = open('tests/test_logs/test_CallbackModule.log', 'w')
    callback_module_0 = CallbackModule()
    if CallbackModule.CALLBACK_TYPE == 'aggregate':
        fd.write('PASSED: Check CallbackModule.CALLBACK_TYPE = aggregate\n')
    else:
        fd.write('FAILED: Check CallbackModule.CALLBACK_TYPE = aggregate\n')
    if CallbackModule.CALLBACK_NEEDS_ENABLED == True:
        fd.write('PASSED: Check CallbackModule.CALLBACK_NEEDS_ENABLED = True\n')
    else:
        fd.write('FAILED: Check CallbackModule.CALLBACK_NEEDS_ENABLED = True\n')

# Generated at 2022-06-25 08:49:32.850317
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    str_0 = 'w(+mmz@95Z^jP9oCd`)J1v'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.write_tree_file(str_0)


# Generated at 2022-06-25 08:49:39.295481
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str = ' Ts]V\\:V{`JuE(Vkv'
    callback_module = CallbackModule()
    var = callback_v2_runner_on_failed(str)



# Generated at 2022-06-25 08:49:44.000138
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0 is not None

test_case_0()

# Generated at 2022-06-25 08:49:49.429189
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    result_0 = CallbackModule()
    # test the if condition in the definition of the method set_options() of the class CallbackModule
    if TREE_DIR:
        assert result_0 == TREE_DIR
    else:
        assert result_0.tree == '~/.ansible/tree'

test_CallbackModule()

# Generated at 2022-06-25 08:49:52.691667
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():

    m = CallbackModule()
    assert m
    assert m.tree == "~/.ansible/tree"
    assert m.CALLBACK_VERSION == 2.0
    assert m.CALLBACK_TYPE == 'aggregate'
    assert m.CALLBACK_NAME == 'tree'

# Generated at 2022-06-25 08:49:54.765723
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.write_tree_file("hostname", "buf")



# Generated at 2022-06-25 08:50:01.803212
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    TREE_DIR = ""
    task_keys = None
    var_options = None
    direct = None
    for direct_0 in direct:
        callback_module_0.set_options(task_keys, var_options, direct_0)
        callback_module_0.tree = TREE_DIR
        callback_module_0.set_options(task_keys, var_options, direct_0)
        callback_module_0.tree = TREE_DIR
        callback_module_0.set_options(task_keys, var_options, direct_0)
        callback_module_0.tree = TREE_DIR


# Generated at 2022-06-25 08:50:03.311306
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    callback_module_1.set_options(task_keys=None, var_options=None, direct=None)


# Generated at 2022-06-25 08:50:05.514643
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.write_tree_file(None, None)


# Generated at 2022-06-25 08:50:14.623224
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert (issubclass(CallbackModule, CallbackBase)), "Not subclass of CallbackBase"
    assert (hasattr(CallbackModule, "CALLBACK_VERSION")), "Missing CALLBACK_VERSION"
    assert (hasattr(CallbackModule, "CALLBACK_TYPE")), "Missing CALLBACK_TYPE"
    assert (hasattr(CallbackModule, "CALLBACK_NAME")), "Missing CALLBACK_NAME"
    assert (hasattr(CallbackModule, "CALLBACK_NEEDS_WHITELIST")), "Missing CALLBACK_NEEDS_WHITELIST"
    assert (CallbackModule.CALLBACK_TYPE == 'aggregate'), "CALLBACK_TYPE == 'aggregate'"
    assert (CallbackModule.CALLBACK_NAME == 'tree'), "CALLBACK_NAME == 'tree'"

# Generated at 2022-06-25 08:50:16.709981
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0=CallbackModule()


# Generated at 2022-06-25 08:50:20.162563
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    data_0 = test_case_0()

if __name__ == '__main__':
    # Unit test for class CallbackModule
    # test_CallbackModule()
    # test_case_0()
    print('No test for this class, just an example on how to create a callback plugin.')

# Generated at 2022-06-25 08:50:27.922362
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    # Test with empty arguments
    assert CallbackModule()

    # Test with arguments
    assert CallbackModule(task_keys=None, var_options=None, direct=None)

# Generated at 2022-06-25 08:50:28.676473
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert test_case_0() == None

# Generated at 2022-06-25 08:50:34.264443
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # test_dir = "/root/ansible"
    # assert callback_module_0.set_options(test_dir) ==  '/root/ansible'
    assert True


# Generated at 2022-06-25 08:50:39.481510
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    '''test_CallbackModule_write_tree_file = "test_ansible_collections.notstdlib.moveitallout.plugins.module_utils.tree.CallbackModule, write_tree_file"'''

    # test exception
    # test actual call
    pass


# Generated at 2022-06-25 08:50:46.272587
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    task_keys = None
    var_options = None
    direct = None
    try:
        callback_module_0.set_options(task_keys=task_keys, var_options=var_options, direct=direct)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 08:50:56.018111
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    import os
    import tempfile

    # Create a temporary directory
    dirpath = tempfile.mkdtemp()

    # Create a temporary file
    fd, filepath = tempfile.mkstemp(dir=dirpath)

    # Create the instance and set the options
    callback_module_0 = CallbackModule()
    callback_module_0.tree = dirpath

# Generated at 2022-06-25 08:50:57.831512
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()

# Generated at 2022-06-25 08:51:05.184659
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    from ansible.module_utils._text import to_text
    import os
    import tempfile
    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary file
    fd, tmp_file = tempfile.mkstemp()
    # Get the directory name
    tmp_dir_name = os.path.split(tmp_dir)[1]
    # Get the list of files/directories
    # in the temporary directory
    files_dirs_list = os.listdir(tmp_dir)
    if tmp_dir_name in files_dirs_list:
        # The directory has been created
        result1 = True
    else:
        # The directory has not been created
        result1 = False
    # Read the content of the temporary file

# Generated at 2022-06-25 08:51:08.404778
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():

    callback_module_1 = CallbackModule()
    callback_module_1.set_options(to_bytes('task_keys'), to_bytes('var_options'), to_bytes('direct'))


# Generated at 2022-06-25 08:51:10.390738
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert callback_module_1.CALLBACK_TYPE == 'aggregate'
    assert callback_module_1.CALLBACK_NAME == 'tree'

# Generated at 2022-06-25 08:51:14.224563
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    from ansible.plugins.callback import CallbackBase

    assert CallbackModule()


# Generated at 2022-06-25 08:51:19.553135
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()
    hostname_0 = ""
    buf_0 = "This is a test string"
    var_1 = callback_module_0.write_tree_file(hostname_0, buf_0)


# Generated at 2022-06-25 08:51:28.333939
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
  """
  Test if write_tree_file is working correctly.
  """

  callback_module_0 = CallbackModule()
  directory = callback_module_0.get_option('directory') or callback_module_0.tree
  file_name = "test_file.txt"
  file = os.path.join(directory, file_name)
  if os.path.exists(file):
    os.remove(file)

  # Assert write_tree_file is working correctly
  assert not os.path.exists(file)
  callback_module_0.write_tree_file(file_name, "testing")
  assert os.path.exists(file)

  # Cleanup
  os.remove(file)


# Generated at 2022-06-25 08:51:33.026151
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)



# Generated at 2022-06-25 08:51:37.684102
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module = CallbackModule()
    callback_module.tree = "Untitled Directory"
    callback_module.write_tree_file(hostname="play_1",
                                    buf={"hostname": "play_1", "ok": True, "changed": False, "unreachable": 0,
                                         "skipped": 0, "failed": 0})

# Generated at 2022-06-25 08:51:38.779470
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callback_module_0.__class__ is CallbackModule


# Generated at 2022-06-25 08:51:40.015130
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert(isinstance(CallbackModule(), CallbackModule))


# Generated at 2022-06-25 08:51:45.065782
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.tree = '%c:\\Windows'
    var_34 = callback_module_0.tree
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)


# Generated at 2022-06-25 08:51:52.023839
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.plugins.callback.tree import CallbackModule
    from ansible.plugins.loader import callback_loader
    from ansible.utils.display import Display
    import sys

    doc, plainexamples, returndocs = read_docstring(CallbackModule)
    display = Display()
    callback_module = CallbackModule(display)
    callback_module.set_options()


    assert (callback_module.tree.endswith('.ansible/tree'))

# Generated at 2022-06-25 08:51:54.705830
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options = mock.Mock()
    callback_module_0.get_option = mock.Mock()
    callback_module_0.tree = mock.Mock()
    callback_module_0._display = mock.Mock()

    print(callback_module_0.write_tree_file(hostname='hostname_0', buf='buf_0'))


# Generated at 2022-06-25 08:52:07.229142
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    test_CallbackModule_callback_module_0 = CallbackModule()

    test_CallbackModule_callback_module_1 = CallbackModule()
    var_0 = test_CallbackModule_callback_module_0.set_options(test_CallbackModule_callback_module_1.CALLBACK_TYPE, test_CallbackModule_callback_module_1.CALLBACK_NAME, test_CallbackModule_callback_module_1.CALLBACK_NEEDS_ENABLED)

    test_CallbackModule_callback_module_2 = CallbackModule()

# Generated at 2022-06-25 08:52:15.919240
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 08:52:17.494182
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    class_0 = CallbackModule()
    class_1 = CallbackModule()

    assert result_to_tree(class_0, class_1) == "~/.ansible/tree"

# Generated at 2022-06-25 08:52:19.472666
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    obj = CallbackModule()
    try:
        obj.write_tree_file('hostname', 'buf')
    except Exception as exception:
        obj.fail_json(msg = '%s' % exception)


# Generated at 2022-06-25 08:52:25.866316
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    var_0 = callback_result_to_tree(callback_module_0, callback_module_0)
    var_1 = callback_result_to_tree(callback_module_0, callback_module_0)
    var_2 = callback_result_to_tree(callback_module_0, callback_module_0)


# Generated at 2022-06-25 08:52:27.165752
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    '''
    Test case for method write_tree_file
    '''
    raise NotImplementedError


# Generated at 2022-06-25 08:52:33.791977
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # This is a constructor test case.
    try:
        callback_module_0 = CallbackModule()
        assert True
    except:
        assert False

    # This is a type test case.
    try:
        assert isinstance(callback_module_0, CallbackModule)
    except:
        assert False


# Generated at 2022-06-25 08:52:37.770324
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)


# Generated at 2022-06-25 08:52:43.069711
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    var_0 = CallbackModule()
    var_1 = None
    var_2 = None
    var_3 = None
    var_0.set_options(var_1, var_2, var_3)


# Generated at 2022-06-25 08:52:49.105592
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    print(dir(callback_module)) # __init__ ##
    print(dir(callback_module.__init__)) # __name__ # __dict__ # __code__ # __globals__ # __closure__ # __getattribute__ # __call__ #


# Generated at 2022-06-25 08:53:03.671762
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    param_0 = ""
    param_1 = ""
    # test for pass
    try:
        callback_module_0.write_tree_file(param_0, param_1)
    except Exception as err_0:
        print(err_0)



# Generated at 2022-06-25 08:53:12.806176
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    cb_mock = Mock()
    hostname_mock = Mock()
    buf_mock = Mock()
    cb_mock.tree= Mock()
    cb_mock.tree.exists.return_value= True
    cb_mock.tree.isdir.return_value= True
    cb_mock.tree.access.return_value= True
    cb_mock.tree.mkdir.return_value= True
    cb_mock.tree.__add__.return_value= True
    cb_mock.tree.write.return_value= True
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(hostname_mock, buf_mock)

# Generated at 2022-06-25 08:53:16.452688
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Test case for testing a specific function
    # Calling function being tested
    result = write_tree_file()

    # Comparing the result to expected
    assert result == "expected"


# Generated at 2022-06-25 08:53:18.399087
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, CallbackModule)


# Generated at 2022-06-25 08:53:22.086965
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    callback_module_0.set_options()
    TREE_DIR = None
    if TREE_DIR:
        callback_module_1.set_options(TREE_DIR)


# Generated at 2022-06-25 08:53:22.986035
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()


# Generated at 2022-06-25 08:53:26.733904
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    hostname = None
    buf = None

    # Test with a valid hostname and a buf
    # Expected: write something into treedir/hostname
    hostname = None
    buf = None
    assert_equal(callback_write_tree_file(hostname, buf), None)



# Generated at 2022-06-25 08:53:31.281054
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():

    # Arrange
    callback_module_0 = CallbackModule()
    callback_module_0.tree = "dir"
    file_to_write = "dir/file"

    # Act
    callback_module_0.write_tree_file(file_to_write)

    # Assert

    # Result is that a file was created

# Generated at 2022-06-25 08:53:34.049429
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module = CallbackModule()
    # Uncomment the following line to initialize TREE_DIR with a default value
    # TREE_DIR = "test_value_0"
    buffer_0 = ""
    var_0 = callback_module.write_tree_file(buffer_0)


# Generated at 2022-06-25 08:53:44.257122
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():

    # In order to test tree functionality, the set_options method is
    # called manually
    callback = CallbackModule()
    options = {}
    callback.set_options(var_options=options)
    # Pass a bogus value so that we don't write files to the user's
    # home directory
    callback.tree = 'test_dir'

    # Define a host and output
    hostname = 'localhost'
    output = 'test_output'

    # write_tree_file will invoke this code, which will fail
    # if the hostname or output are not strings
    buf = to_bytes(output)

# Generated at 2022-06-25 08:54:14.122859
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test = CallbackModule()
    test.set_options()
    assert test is not None


# Generated at 2022-06-25 08:54:15.457007
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options()



# Generated at 2022-06-25 08:54:21.384833
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module._dump_results(callback_module) != '', "CallbackModule: empty result"


# Generated at 2022-06-25 08:54:23.826499
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:54:26.082322
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test if the constructor works with no arguments.
    test_case_0()


# Generated at 2022-06-25 08:54:31.412560
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    """test method write_tree_file"""
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)
    assert var_0 is None


# Generated at 2022-06-25 08:54:34.118526
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:54:36.216231
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    callback_module.set_options()


# Generated at 2022-06-25 08:54:39.083160
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:54:43.379816
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    print(repr(callback_module_0))
    assert repr(callback_module_0).startswith('<ansible.plugins.callback.tree.CallbackModule object')


# Generated at 2022-06-25 08:55:43.302098
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test class instantiation
    callback_module = CallbackModule()


# Generated at 2022-06-25 08:55:44.910860
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.__weakref__

# Generated at 2022-06-25 08:55:48.719305
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options(callback_module_0)


# Generated at 2022-06-25 08:55:56.589872
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    print("\n\nTest: write_tree_file\n")
    callback_module_0 = CallbackModule()

    try:
        makedirs_safe(callback_module_0.tree)
    except (OSError, IOError) as e:
        callback_module_0._display.warning(u"Unable to access or create the configured directory (%s): %s" % (to_text(callback_module_0.tree), to_text(e)))

# Generated at 2022-06-25 08:55:57.484140
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)

# Generated at 2022-06-25 08:55:59.357908
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0


# Generated at 2022-06-25 08:56:04.404577
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.set_tree("~/.ansible/tree")
    var_0 = callback_module_0.write_tree_file("hostname", "buf")


# Generated at 2022-06-25 08:56:06.204501
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.tree == '/home/fmliu/.ansible/tree'

# Generated at 2022-06-25 08:56:08.431480
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_scan = CallbackModule()
    callback_module_scan.set_options()


# Generated at 2022-06-25 08:56:10.453064
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:58:29.523917
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()
    assert callback_module_0.tree == callback_module_0.get_option('directory')


# Generated at 2022-06-25 08:58:29.955096
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()

# Generated at 2022-06-25 08:58:30.606553
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()


# Generated at 2022-06-25 08:58:33.158130
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    CallbackModule_0 = CallbackModule()
    # AssertionError raised when trying to execute write_tree_file on CallbackModule_0
    try:
        CallbackModule_0.write_tree_file(CallbackModule_0, CallbackModule_0)
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-25 08:58:33.518177
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
	pass



# Generated at 2022-06-25 08:58:34.283593
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    assert True is True


# Generated at 2022-06-25 08:58:36.254432
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Arguments for the method.
    _hostname = 'tilde'
    _buf = {
        'tilde': '~'
    }

    # Instantiate the class.
    callback_module = CallbackModule()

    # Call the method with correct arguments.
    callback_module._CallbackModule__write_tree_file(_hostname, _buf)


# Generated at 2022-06-25 08:58:38.044858
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    var_1 = 'task_keys'
    var_2 = 'var_options'
    var_3 = 'direct'
    callback_module_1.set_options(task_keys=var_1, var_options=var_2, direct=var_3)


# Generated at 2022-06-25 08:58:38.731505
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:58:43.812121
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    # variable initialization
    callback_module_0 = CallbackModule()

    # assert statements
    if (callback_module_0 == None):
        raise AssertionError("CallBackModule() is null.")
