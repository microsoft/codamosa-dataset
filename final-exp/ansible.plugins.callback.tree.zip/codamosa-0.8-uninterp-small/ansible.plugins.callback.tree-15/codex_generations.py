

# Generated at 2022-06-25 08:48:42.405794
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.write_tree_file()
    callback_module_0.write_tree_file(None)
    callback_module_0.write_tree_file(None, None)


# Generated at 2022-06-25 08:48:50.936654
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = 'host1'
    buf = '{"_ansible_parsed": true, "_ansible_no_log": false, "_ansible_item_label": "msg", "_ansible_verbose_always": true, "_ansible_modified_vars": {}, "invocation": {"module_name": "debug", "module_args": {"msg": "Hello World", "verbosity": 0}}, "item": {"msg": "Hello World"}, "changed": false, "msg": "Hello World", "_ansible_item_result": true}'
    callback_module_0.write_tree_file(hostname, buf)


# Generated at 2022-06-25 08:48:55.693552
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()


# Generated at 2022-06-25 08:48:56.892979
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    CallbackModule().write_tree_file("test_host", "test_buf")

# Generated at 2022-06-25 08:49:01.445211
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.write_tree_file('hostname', b'buf')


# Generated at 2022-06-25 08:49:05.164620
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0



# Generated at 2022-06-25 08:49:12.089342
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    directory = 'test'
    hostname = 'host1'
    buf = 'test'
    callback_module_1 = CallbackModule(task_keys=None, var_options=None, direct=None)
    callback_module_1.set_options(task_keys=None, var_options=None, direct=None)
    callback_module_1.tree = directory
    try:
        makedirs_safe(directory)
    except (OSError, IOError) as e:
        print(u"Unable to access or create the configured directory (%s): %s" % (to_text(directory), to_text(e)))
    assert os.path.exists(directory)
    callback_module_1.write_tree_file(hostname, buf)

# Generated at 2022-06-25 08:49:18.422499
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print('')
    print('###### test_CallbackModule() starts ######')
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()

    print('')
    print('###### test_CallbackModule() ends ######')


# Generated at 2022-06-25 08:49:24.397435
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options('task_keys=None', 'var_options=None', 'direct=None')


# Generated at 2022-06-25 08:49:26.586408
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callback_module_0.tree == "~/.ansible/tree"

# Generated at 2022-06-25 08:49:31.428136
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    try:
        assert test_case_0()
        print("Test Case 0 Passed")
    except AssertionError as e:
        print("Test Case 0 Failed")
    except Exception as e:
        print("Test Case 0 Failed")
    else:
        pass
    finally:
        pass


# Generated at 2022-06-25 08:49:36.377848
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    task_keys = None
    var_options = None
    direct = None
    callback_module.set_options(task_keys=task_keys, var_options=var_options, direct=direct)
    assert True



# Generated at 2022-06-25 08:49:44.713402
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok()
    var_1 = callback_module_0.v2_runner_on_failed()
    var_2 = callback_module_0.v2_runner_on_unreachable()
    str_0 = 'test_buf'
    var_3 = callback_write_tree_file(str_0, str_0)
    var_4 = callback_module_result_to_tree(str_0)
    var_5 = callback_module_set_options()

# Generated at 2022-06-25 08:49:47.520112
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = '"--tree" option when using adhoc.'
    callback_module_0.set_options(var_0)


# Generated at 2022-06-25 08:49:50.824426
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    callback_module_1.set_options(task_keys='task_keys_1', var_options='var_options_1', direct='direct_1')


# Generated at 2022-06-25 08:49:56.380374
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    # Instantiate CallbackModule
    callback_module_0 = CallbackModule()

    assert CallbackModule == type(CallbackModule)
    assert CallbackBase == type(CallbackBase)
    callback_module_0.set_options(task_keys=None, var_options=None, direct=None)

    try:
        # Write to the file
        callback_module_0.write_tree_file('test_hostname', 'test_buf')
        assert True
    except (OSError, IOError):
        assert False

    # Write result to tree
    callback_module_0.result_to_tree('test_result')
    assert 'test_result' == 'test_result'

    # Run the v2_runner_on_ok() method
    callback_module_0.v2_runner_on_ok('test_result')

# Generated at 2022-06-25 08:50:04.294779
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test to verify if the constructor of CallbackModule initializes the attributes.
    assert (CallbackModule.CALLBACK_VERSION == 2.0)
    assert (CallbackModule.CALLBACK_TYPE == 'aggregate')
    assert (CallbackModule.CALLBACK_NAME == 'tree')
    assert (CallbackModule.CALLBACK_NEEDS_ENABLED == True)


# Generated at 2022-06-25 08:50:07.313705
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    print("\n# Unit test for set_options of class CallbackModule")
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()
    print("\nVar dir = ", TREE_DIR)


# Generated at 2022-06-25 08:50:09.791102
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    str_0 = 'test_buf'
    assert type(callback_module_0.write_tree_file(str_0, str_0)) == str


# Generated at 2022-06-25 08:50:14.663215
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # test case 0
    callback_module_0 = CallbackModule()
    str_0 = 'test_task_keys'
    str_1 = 'test_var_options'
    str_2 = 'test_direct'
    var_0 = callback_module_0.set_options(str_0, str_1, str_2)


# Generated at 2022-06-25 08:50:21.124071
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    # test_case_0()

# Generated at 2022-06-25 08:50:23.114431
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    str_0 = 'test_buf'
    var_0 = callback_module_0.write_tree_file(str_0, str_0)

# Generated at 2022-06-25 08:50:23.876676
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:50:27.994549
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    cb = CallbackModule()
    cb.set_options({'dest': 'result'})
    assert 'result' in cb.__dict__



# Generated at 2022-06-25 08:50:30.250377
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:50:37.728996
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callbackModule = CallbackModule()
    ansible_callback_tree_dir = os.environ.get('ANSIBLE_CALLBACK_TREE_DIR')
    if os.path.isdir(ansible_callback_tree_dir):
        test_case_0()
    else:
        var_1 = 'no env'
        var_2 = 'no env'
        var_0 = callback_write_tree_file(var_1, var_2)

try:
    from ansible.plugins.callback.tree import CallbackModule as CallbackModule_0
except ImportError:
    CallbackModule_0 = object


# Generated at 2022-06-25 08:50:45.155150
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    str_0 = 'test_buf'
    callback_write_tree_file(callback_module_0, str_0, str_0)
    assert isinstance(callback_module_0, CallbackModule)
    callback_result_to_tree(callback_module_0, str_0, str_0)
    str_1 = 'test_buf'
    callback_v2_runner_on_ok(callback_module_0, str_1)
    callback_module_0.CALLBACK_TYPE = 'test_buf'
    callback_module_0.v2_runner_on_failed(str_0)
    callback_v2_runner_on_unreachable(callback_module_0, str_1)


# Generated at 2022-06-25 08:50:46.492492
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_0 = CallbackModule()
    assert var_0.tree == '/root/.ansible/tree'


# Generated at 2022-06-25 08:50:49.200321
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        str_0 = 'test_buf'
        var_0 = callback_write_tree_file(str_0, str_0)
    except:
        pass
    else:
        print('Failed to assert')


# Generated at 2022-06-25 08:50:52.614571
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    task_keys = None
    var_options = None
    direct = None
    var_1 = callback_module_0.set_options(task_keys=None, var_options=None, direct=None)


# Generated at 2022-06-25 08:51:12.078314
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import AnsibleCore
    import tempfile

    # Mocking CallbackBase
    class MockedCallbackBase:
        def set_options(self):
            pass

    CallbackBaseMock = MockedCallbackBase()

    # Call the constructor CallbackModule()
    callbackModule_object = AnsibleCore.CallbackModule.CallbackModule(CallbackBaseMock)

    # Check if result is not None
    assert callbackModule_object is not None

    # Check if the instance variables are set
    assert callbackModule_object.CALLBACK_VERSION == 2.0
    assert callbackModule_object.CALLBACK_TYPE == 'aggregate'
    assert callbackModule_object.CALLBACK_NAME == 'tree'
    assert callbackModule_object.CALLBACK_NEEDS_ENABLED == True
    assert callbackModule_object.tree is not None

   

# Generated at 2022-06-25 08:51:14.332259
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.get_option('directory')


# Generated at 2022-06-25 08:51:15.783394
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert isinstance(CallbackModule(), CallbackModule) == True


# Generated at 2022-06-25 08:51:21.403318
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # Setup
    callback_module_0 = CallbackModule()
    task_keys_0 = None
    var_0 = None
    direct_0 = None

    # Invocation
    callback_module_0.set_options(task_keys=task_keys_0, var_options=var_0, direct=direct_0)



# Generated at 2022-06-25 08:51:26.045646
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0_var_1 = {}
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(task_keys = callback_module_0_var_1, var_options = callback_module_0_var_1, direct = callback_module_0_var_1)


# Generated at 2022-06-25 08:51:27.903969
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options()


# Generated at 2022-06-25 08:51:37.122553
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_ = CallbackModule()
    var = callback_module_.set_options()
    var = callback_module_.write_tree_file(hostname, buf)
    var = callback_module_.result_to_tree(result)
    var = callback_module_.v2_runner_on_ok(result)
    var = callback_module_.v2_runner_on_failed(result, ignore_errors)
    var = callback_module_.v2_runner_on_unreachable(result)

# Generated at 2022-06-25 08:51:38.366181
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_0 = CallbackModule()
    return var_0


# Generated at 2022-06-25 08:51:41.992116
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Arguments:
    #    display
    #    options
    #    queue
    #    callback_version
    #    enabled
    #    message_args

    callback_module_0 = CallbackModule()
    assert callback_module_0.__class__.__name__ == 'CallbackModule'

# Generated at 2022-06-25 08:51:44.751415
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:52:10.599657
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.tree is not None


# Generated at 2022-06-25 08:52:12.568439
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)


# Generated at 2022-06-25 08:52:17.117870
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    # fixture
    callback_module_0.tree = "/root"

    assert(callback_module_0.write_tree_file(callback_module_0, "foo.json") == ReturnTypeError)


# Generated at 2022-06-25 08:52:20.866768
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module = CallbackModule()
    callback_module.write_tree_file = 'test_value'
    assert callback_module.write_tree_file == 'test_value'


# Generated at 2022-06-25 08:52:23.355581
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # test case 0
    test_case_0()

# Generated at 2022-06-25 08:52:26.602195
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule(verbosity=0)


# Generated at 2022-06-25 08:52:27.862952
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options()


# Generated at 2022-06-25 08:52:28.780759
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_3 = CallbackModule()
    var_3 = var_3
    return var_3


# Generated at 2022-06-25 08:52:33.768463
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    var_1 = callback_module_1.get_option('directory')
    assert var_1 == '~/.ansible/tree'

if __name__ == '__main__':
    test_case_0()
    test_CallbackModule_set_options()

# Generated at 2022-06-25 08:52:44.816837
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()
    buffer_size_0 = 1024
    buf_0 = readinto(buffer_size_0)
    hostname_0 = 'baz'
    var_0 = makedirs_safe(callback_module_0.tree)
    path_0 = os.path.join(callback_module_0.tree, hostname_0)
    dir_0 = path_0.split(os.path.sep)[0]
    assert_equals('baz', dir_0)


# Generated at 2022-06-25 08:53:35.346959
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, object)
    var_0 = callback_module_0.set_options()
    assert isinstance(var_0, object)

# Generated at 2022-06-25 08:53:36.897292
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options(callback_module_0, 'task_keys', 'var_options', 'direct')


# Generated at 2022-06-25 08:53:41.465773
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        callback_module_1 = CallbackModule('test_host', 'test_task', 'test_res', 'test_tasks', 'test_task_keys', 'test_var_options', 'test_direct')
        assert (True == isinstance(callback_module_1, CallbackModule))
    except Exception as exception:
        assert (False)


# Generated at 2022-06-25 08:53:44.691735
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    callback_module_0.write_tree_file(hostname=None, buf=None)


# Generated at 2022-06-25 08:53:46.975683
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)
    return var_0


# Generated at 2022-06-25 08:53:53.978279
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    import os
    import tempfile

    cb = CallbackModule()
    name = "host"
    cb.tree = tempfile.mkdtemp()
    buf = "buf"
    cb.write_tree_file(name, buf)
    file_path = os.path.join(cb.tree, name)
    assert os.path.exists(file_path)
    with open(file_path, 'rb') as fd:
        read_buf = fd.read()
        assert buf == read_buf

# Generated at 2022-06-25 08:53:55.873736
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
  callback_module = CallbackModule()
  var_1 = callback_set_options(callback_module)


# Generated at 2022-06-25 08:53:59.003107
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    hostname = ""
    buf = ""
    callback_module_0 = CallbackModule()
    callback_module_0.tree = "/home/carl/ansible"
    callback_module_0.write_tree_file(hostname, buf)


# Generated at 2022-06-25 08:54:07.243876
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    # Assign param: task_keys(None) to variable: var_0
    var_0 = callback_module_0.set_options(task_keys=None)
    # Assign param: var_options(None) to variable: var_1
    var_1 = callback_module_0.set_options(var_options=None)
    # Assign param: direct(None) to variable: var_2
    var_2 = callback_module_0.set_options(direct=None)
    # Assign false to variable: var_3
    var_3 = False
    # Assign true to variable: var_4
    var_4 = True
    # Assign param: task_keys(None) to variable: var_5

# Generated at 2022-06-25 08:54:08.984651
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    var_1 = callback_set_options(callback_module_1, callback_module_1)

# Generated at 2022-06-25 08:56:25.200849
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Call instances of CallbackModule
    callback_module_0 = CallbackModule()
    callback_module_0.write_tree_file("hostname", "buf")



# Generated at 2022-06-25 08:56:28.244226
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    assert var_0 == "Tre"


# Generated at 2022-06-25 08:56:30.832077
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    for kwargs_write_tree_file in [{'hostname': "buf", 'buf': "buf"}, {'hostname': "buf", 'buf': "buf"}]:
        print(kwargs_write_tree_file)



# Generated at 2022-06-25 08:56:32.905229
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)


# Generated at 2022-06-25 08:56:34.401178
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0 != False
    assert callback_module_0.tree == "~/.ansible/tree"


# Generated at 2022-06-25 08:56:34.798188
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass



# Generated at 2022-06-25 08:56:41.027249
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    path = 'test_path'
    directory = '/tmp/tree'
    try:
        makedirs_safe(directory)
    except (OSError, IOError) as e:
        print("Unable to access or create the configured directory (%s): %s" % (to_text(directory), to_text(e)))
    callback_module_0 = CallbackModule()
    callback_module_0.write_tree_file(path)

# Generated at 2022-06-25 08:56:45.972669
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
  callback_module = CallbackModule()
  # Unit test for method set_options
  test_case_0(callback_module)


if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:56:46.649930
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:56:48.108716
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    my_callback = CallbackModule(display=None)
    assert len(my_callback.tree) == 0
