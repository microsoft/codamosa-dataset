

# Generated at 2022-06-25 08:48:42.405150
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cb = CallbackModule()

    assert(type(cb)) == CallbackModule

# Generated at 2022-06-25 08:48:45.374047
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert hasattr(CallbackModule(), 'tree')


# Generated at 2022-06-25 08:48:51.887351
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    task_keys = None
    var_options = None
    direct = None
    test_case_1 = callback_module_1.set_options(task_keys=task_keys, var_options=var_options, direct=direct)


# Generated at 2022-06-25 08:48:55.653536
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # create an object of the class
    callback_module_1 = CallbackModule()

    task_keys = {'a': 1, 'b': 2}
    var_options = {'a': 3, 'b': 4}
    direct = {'a': 5, 'b': 6}

    # call the method
    result = callback_module_1.set_options(task_keys=task_keys, var_options=var_options, direct=direct)

# Generated at 2022-06-25 08:48:57.647254
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(task_keys=None, var_options=None, direct=None)

# Generated at 2022-06-25 08:49:01.522015
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    def test_case_1():
        callback_module_0 = CallbackModule()
        callback_module_0.set_options()


# Generated at 2022-06-25 08:49:08.712984
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert callback_module_1._dump_results == '{"SampleResult"}'
    assert callback_module_1._last_task_banner == '{"SampleTaskTitle"}'
    assert callback_module_1.tree == '"~/.ansible/tree"'
    assert callback_module_1._play == '{"SamplePlayData"}'
    assert callback_module_1._last_task == '{"SampleTaskData"}'
    assert callback_module_1.show_custom_stats == '{"SampleCustomStats"}'
    assert callback_module_1.options == '{"SampleOptionsData"}'
    assert callback_module_1._display == '{"SampleDisplayData"}'


# Generated at 2022-06-25 08:49:12.215154
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    obj = CallbackModule()
    assert write_tree_file() == 'something'


# Generated at 2022-06-25 08:49:18.411600
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.plugins.callback.tree import CallbackModule
    callback_module = CallbackModule()
    assert callback_module is not None

# Generated at 2022-06-25 08:49:24.375113
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    try:
        callback_module_1 = CallbackModule()
        callback_module_1.set_options()
    except:
        raise AssertionError


# Generated at 2022-06-25 08:49:38.302898
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert "CallbackModule" not in globals(), "Test for constructor of class CallbackModule in plugin tree.py failed. Class already defined."
    class_name = "CallbackModule"
    class_name = str(class_name)
    class_instance = CallbackModule()
    assert "CallbackBase" in str(class_instance.__class__.__bases__), "Test for constructor of class CallbackModule in plugin tree.py failed. Bases class mismatch. Expected: \"('CallbackBase',)\" Got: \"" + str(
        class_instance.__class__.__bases__) + "\""

# Generated at 2022-06-25 08:49:41.062487
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    assert callback_module_0.write_tree_file(u'/root/.ansible/tree', u"{\n    \"fraction_complete\": 1\n}\n") == None

# Generated at 2022-06-25 08:49:43.404219
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    pass



# Generated at 2022-06-25 08:49:46.264027
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert isinstance(obj, CallbackModule)


# Generated at 2022-06-25 08:49:50.281650
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    task_keys=None
    var_options=None
    direct=None
    callback_module_0.set_options(task_keys=task_keys,var_options=var_options,direct=direct)


# Generated at 2022-06-25 08:49:59.091165
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    # Example: --tree=~/.ansible/tree
    # Example: --tree=$HOME/.ansible/tree
    # Example: --tree=$HOME/dir_name
    # Example: --tree=$HOME/dir_name/sub_dir_name/
    # Example: --tree=.
    TREE_DIR = to_text(u'~/.ansible/tree')
    assert to_text(u'~/.ansible/tree') == TREE_DIR
    callback_module_0.set_options(task_keys=None, var_options=None, direct=None)

# Generated at 2022-06-25 08:50:01.318121
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    c = CallbackModule()
    c.set_options(task_keys=None, var_options=None, direct=None)


# Generated at 2022-06-25 08:50:02.935578
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass


# Generated at 2022-06-25 08:50:06.189379
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    from ansible.plugins import callback_loader
    callback_module = callback_loader._create_directory_if_needed(TREE_DIR);
    assert callback_module.write_tree_file(TREE_DIR, "sample")

# Generated at 2022-06-25 08:50:11.033275
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module = CallbackModule()
    path = os.path.join(callback_module.tree, "ansible")
    try:
        os.remove(path)
    except OSError:
        pass
    callback_module.write_tree_file("ansible", "WOW")
    assert(os.path.isfile(path))



# Generated at 2022-06-25 08:50:21.758902
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.CALLBACK_VERSION = 2.0
    callback_module_0.CALLBACK_TYPE = 'aggregate'
    callback_module_0.CALLBACK_NAME = 'tree'
    callback_module_0.CALLBACK_NEEDS_ENABLED = True
    str_0 = ' sets the base directory, used to find files when a relative path is given '
    task_keys_0 = callback_module_0.set_options(str_0, str_0, str_0)
    assert task_keys_0 == None


# Generated at 2022-06-25 08:50:31.355046
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    #self, task_keys=None, var_options=None, direct=None
    obj_CallbackModule = CallbackModule()
    str_task_keys = ' sets the base directory, used to find files when a relative path is given '
    str_var_options = ' sets the base directory, used to find files when a relative path is given '
    str_direct = ' sets the base directory, used to find files when a relative path is given '
    obj_CallbackModule.set_options(task_keys=str_task_keys, var_options=str_var_options, direct=str_direct)


# Generated at 2022-06-25 08:50:34.795163
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.tree == None


# Generated at 2022-06-25 08:50:35.827588
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    test_case_0()

# Generated at 2022-06-25 08:50:40.574531
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        test_case_0()
    except Exception as e:
        print("Error occurred on line " + str(sys.exc_info()[-1].tb_lineno) + ": " + str(e))

# Generated at 2022-06-25 08:50:45.080502
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
  instance_0 = CallbackModule()
  instance_1 = CallbackModule()


# Generated at 2022-06-25 08:50:53.303144
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    if (not (0)):
        print('FAILURE')
    if (not ('', '', '', '', '', '', '', '')):
        print('FAILURE')
    if (not ('')):
        print('FAILURE')
    if (not (None)):
        print('FAILURE')
    if (not (None)):
        print('FAILURE')
    if (not (2.0)):
        print('FAILURE')
    if (not (False)):
        print('FAILURE')
    if (not (None)):
        print('FAILURE')
    if (not (None)):
        print('FAILURE')
    if (not (None)):
        print('FAILURE')

# Generated at 2022-06-25 08:50:54.801416
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()


# Generated at 2022-06-25 08:51:00.733373
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_1 = CallbackModule()
    #assert(var_1.CALLBACK_NAME == 'tree')
    #assert(var_1.CALLBACK_NEEDS_ENABLED == True)
    #assert(var_1.CALLBACK_TYPE == 'aggregate')
    #assert(var_1.CALLBACK_VERSION == 2.0)


# Generated at 2022-06-25 08:51:05.053497
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callbackmodule_0 = CallbackModule()

test_case_0()
test_CallbackModule()

# Generated at 2022-06-25 08:51:18.044143
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:51:21.438601
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    file = "notifier_callback_plugin.py"
    callback_module = CallbackModule()
    test = isinstance(callback_module, CallbackModule)
    assert test == True


# Generated at 2022-06-25 08:51:26.479148
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options()
    assert var_0 == None, "var_0 was not None"
    assert callback_module_0.tree == "/home/ansible/.ansible/tree", "callback_module_0.tree was not /home/ansible/.ansible/tree"


# Generated at 2022-06-25 08:51:29.106861
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    callback_write_tree_file(callback_module_0, callback_module_0)
    assert callback_module_0.get_option('directory') == '~/.ansible/tree'


# Generated at 2022-06-25 08:51:35.109575
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule.set_options()
    CallbackModule.result_to_tree()
    CallbackModule.write_tree_file()
    CallbackModule.v2_runner_on_failed()
    CallbackModule.v2_runner_on_ok()
    CallbackModule.v2_runner_on_unreachable()


# Generated at 2022-06-25 08:51:37.462789
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    var_0 = callback_module_set_options(callback_module_1)


# Generated at 2022-06-25 08:51:39.268705
# Unit test for method write_tree_file of class CallbackModule

# Generated at 2022-06-25 08:51:48.236985
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.plugin_type == 'notification'
    assert callback_module_0.plugin_name == 'tree'
    assert callback_module_0._display.verbosity == 2
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'aggregate'
    assert callback_module_0.CALLBACK_NAME == 'tree'
    assert callback_module_0.CALLBACK_NEEDS_ENABLED == True
    assert callback_module_0.tree is None


# Generated at 2022-06-25 08:51:49.621582
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()


# Generated at 2022-06-25 08:51:53.351569
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    task_keys_0 = None
    var_0 = callback_module_0.set_options(task_keys=task_keys_0)
    return var_0


# Generated at 2022-06-25 08:52:24.973896
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = {"task_keys": "foo", "var_options": "bar", "direct": "baz"}
    callback_module_0.set_options(task_keys="foo", var_options="bar", direct="baz")
    var_0 = ["task_keys", "var_options", "direct"]
    callback_module_0.set_options(task_keys="foo", var_options="bar", direct="baz")
    var_0 = "bar"
    callback_module_0.set_options(task_keys="foo", var_options="bar", direct="baz")
    var_0 = "baz"
    callback_module_0.set_options(task_keys="foo", var_options="bar", direct="baz")

# Unit test

# Generated at 2022-06-25 08:52:26.759673
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    var = callback_module.set_options()
    print(var)

# Generated at 2022-06-25 08:52:32.182831
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test variables
    callback_module_0 = CallbackModule()

    # Test cases
    test_case_0()

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:52:38.440820
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # callback_module_0 = CallbackModule()
    # var_0 = callback_write_tree_file(callback_module_0, callback_module_0)
    pass


# Generated at 2022-06-25 08:52:42.997469
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cbm = CallbackModule()
    cbm.set_options(var_options=None, task_keys=None, direct=True)
    assert isinstance(cbm, CallbackModule)

# Generated at 2022-06-25 08:52:49.326768
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module.CALLBACK_VERSION == 2.0
    assert callback_module.CALLBACK_TYPE == 'aggregate'
    assert callback_module.CALLBACK_NAME == 'tree'
    assert callback_module.CALLBACK_NEEDS_ENABLED == True


# Generated at 2022-06-25 08:52:50.522067
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    var_0 = CallbackModule()
    var_0.set_options()

# Generated at 2022-06-25 08:52:51.478649
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule([])


# Generated at 2022-06-25 08:52:58.454115
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # obj_0 is an instance of type CallbackModule
    obj_0 = CallbackModule()
    # var_0 is an instance of type CallbackModule
    var_0 = CallbackModule()
    # var_1 is an instance of type string
    var_1 = "ANSIBLE_CALLBACK_TREE_DIR"
    # var_2 is an instance of type bytes
    var_2 = b'~/.ansible/tree'
    # var_3 is an instance of type string
    var_3 = "callback_tree"
    # var_4 is an instance of type string
    var_4 = "directory"
    # var_5 is an instance of type string
    var_5 = "~/.ansible/tree"
    # var_6 is an instance of type bytes

# Generated at 2022-06-25 08:53:04.901824
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    try:
        assert isinstance(write_tree_file, object)
    except AssertionError as e:
        print('Caught AssertionError:', e)


# Generated at 2022-06-25 08:54:04.385850
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    hostname = ""
    buf = ""
    ret_val = callback_module_0.write_tree_file(hostname, buf)


# Generated at 2022-06-25 08:54:07.262116
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.set_options()
    assert callback_module_0.write_tree_file()
    assert callback_module_0.result_to_tree()
    assert callback_module_0.v2_runner_on_ok()
    assert callback_module_0.v2_runner_on_failed()
    assert callback_module_0.v2_runner_on_unreachable()

# Generated at 2022-06-25 08:54:08.674343
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    # Tests start here
    assert callback_module_0 != 0


# Generated at 2022-06-25 08:54:10.280438
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.set_options(task_keys=None, var_options=None, direct=None)


# Generated at 2022-06-25 08:54:19.228614
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    var_0 = callback_set_options(callback_module_0)
    assert type(var_0) == dict
    var_1 = callback_write_tree_file(callback_module_0, callback_module_0)
    assert type(var_1) == NoneType
    var_2 = callback_result_to_tree(callback_module_0, callback_module_0)
    assert type(var_2) == NoneType
    var_3 = callback_v2_runner_on_ok(callback_module_0, callback_module_0)
    assert type(var_3) == NoneType
    var_4 = callback_v2_runner_on_failed(callback_module_0, callback_module_0)
    assert type(var_4) == NoneType


# Generated at 2022-06-25 08:54:19.634687
# Unit test for method set_options of class CallbackModule

# Generated at 2022-06-25 08:54:20.788903
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_1 = CallbackModule()

# Generated at 2022-06-25 08:54:31.358141
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():

    # test_case_0
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)

    # test_case_1
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)

    # test_case_2
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)

    # test_case_3
    callback_module_0 = CallbackModule()
    var_0 = callback_write_tree_file(callback_module_0, callback_module_0)

    # test_case_4

# Generated at 2022-06-25 08:54:34.117331
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    # compare outputs
    # TODO

# Generated at 2022-06-25 08:54:36.394064
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    callback_module_0 = CallbackModule()
    assert callback_module_0.write_tree_file(hostname, buf) == None


# Generated at 2022-06-25 08:56:49.477975
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print("test_CallbackModule: constructor(self, display=None)")
    var_0 = CallbackModule()


# Generated at 2022-06-25 08:56:54.719525
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(task_keys=None, var_options=None, direct=None)
    callback_module_0.write_tree_file('hostname', 'buf')
    callback_module_0.result_to_tree('result')
    callback_module_0.v2_runner_on_ok('result')
    callback_module_0.v2_runner_on_failed('result', 'ignore_errors')
    callback_module_0.v2_runner_on_unreachable('result')

# Generated at 2022-06-25 08:57:00.535844
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    var_test_0 = callback_module_0
    assert var_test_0 == callback_module_0
    var_test_1 = callback_module_0.get_option
    assert var_test_1 == callback_module_0.get_option


# Generated at 2022-06-25 08:57:06.151729
# Unit test for method write_tree_file of class CallbackModule

# Generated at 2022-06-25 08:57:13.262639
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.constants import TREE_DIR

    var_0 = CallbackModule()
    assert var_0.CALLBACK_VERSION == 2.0
    assert var_0.CALLBACK_TYPE == 'aggregate'
    assert var_0.CALLBACK_NAME == 'tree'
    assert var_0.CALLBACK_NEEDS_ENABLED == True

# Generated at 2022-06-25 08:57:16.690784
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test 1
    callback_module_1 = CallbackModule()
    assert callback_module_1.CALLBACK_VERSION == 2.0
    assert callback_module_1.CALLBACK_TYPE == 'aggregate'
    assert callback_module_1.CALLBACK_NAME == 'tree'
    assert callback_module_1.CALLBACK_NEEDS_ENABLED == True


# Generated at 2022-06-25 08:57:26.344342
# Unit test for method write_tree_file of class CallbackModule
def test_CallbackModule_write_tree_file():
    # Create object
    callback_module_0 = CallbackModule()
    # Test infra, not required.. but it helps to check if file creation was done after a test run
    import os
    import shutil
    directory_path = "./test_tree"
    if os.path.exists(directory_path):
        try:
            shutil.rmtree(directory_path)
        except OSError as exc:
            pass
    # Create directory for testing
    os.makedirs(directory_path)
    callback_module_0.tree = directory_path
    # Create test file
    file_path = os.path.join(directory_path, 'callback_module_0')
    file_0 = open(file_path, 'w')
    file_0.close()
    # Test actual method
    callback_

# Generated at 2022-06-25 08:57:31.798561
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    tree_dir = "/home/tree"
    callback_module_0 = CallbackModule()
    callback_module_0.set_options()
    assert(callback_module_0.tree == callback_module_0.tree)
    callback_module_0.set_options(tree = tree_dir)
    assert(callback_module_0.tree == tree_dir)


# Generated at 2022-06-25 08:57:34.548716
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert True


# Generated at 2022-06-25 08:57:38.325385
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # fake load
    callback_module = CallbackModule(1)

    # call write tree_file
    callback_module.write_tree_file(None, None)

    # call result_to_tree
    callback_module.result_to_tree(None)

    # fake load
    callback_module.v2_runner_on_ok(None)
    callback_module.v2_runner_on_failed(None, None)
    callback_module.v2_runner_on_unreachable(None)

