

# Generated at 2022-06-24 19:38:20.889454
# Unit test for function get_group_vars
def test_get_group_vars():
    assert sort_groups(get_group_vars)
    assert not get_group_vars(get_group_vars)
    assert get_group_vars(get_group_vars) <= 20
    assert get_group_vars(get_group_vars) == 20



# Generated at 2022-06-24 19:38:23.624523
# Unit test for function get_group_vars
def test_get_group_vars():
    # Create a dictionary with arguments
    args = {"str_0": "failed to transfer file to '%s': %s"}

    results = get_group_vars(**args)
    assert (results == var_0)



# Generated at 2022-06-24 19:38:27.396504
# Unit test for function get_group_vars
def test_get_group_vars():
    str_0 = "failed to transfer file to '%s': %s"
    var_0 = get_group_vars(str_0)
    assert (var_0 == '%s')




# Generated at 2022-06-24 19:38:30.827469
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True

# can't test for this, because it's a mock
# def test_case_1():
#     import ansible.inventory.host
#     ansible.inventory.host.Host.get_vars = lambda self: {'a': 1, 'b': 2}
#     var_1 = get_group_vars()
#
#     assert var_1 == {'a': 1, 'b': 2}

# Generated at 2022-06-24 19:38:36.397973
# Unit test for function get_group_vars
def test_get_group_vars():
    str_0 = "/usr/local/bin/ansible-connection.py"
    str_1 = str_0
    str_2 = "%s/ansible_%s_payload"
    str_3 = "ANSIBLE_KEEP_REMOTE_FILES"
    str_4 = "ANSIBLE_KEEP_REMOTE_FILES"
    str_5 = "ANSIBLE_REMOTE_USER"
    str_6 = "/bin/sh"
    str_7 = "ANSIBLE_PERSISTENT_CONNECT_RETRY_TIMEOUT"
    str_8 = "ANSIBLE_PERSISTENT_COMMAND_TIMEOUT"
    str_9 = "ANSIBLE_PERSISTENT_CONNECT_LOCKFILE"

# Generated at 2022-06-24 19:38:38.792894
# Unit test for function get_group_vars
def test_get_group_vars():
    str_0 = "failed to transfer file to '%s': %s"
    var_0 = get_group_vars(str_0)
    assert var_0 is None

# Generated at 2022-06-24 19:38:41.053159
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars() == "failed to transfer file to '%s': %s"

# Generated at 2022-06-24 19:38:46.943917
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars('"abc') == "{}"
    assert get_group_vars("'abc") == "{}"
    assert get_group_vars('[1,2,3]') == "{}"
    assert get_group_vars("(1,2,3)") == "{}"
    assert get_group_vars("{'a': 1, 'b': 'z'}") == "{}"

# Generated at 2022-06-24 19:38:51.027801
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars([1, 2, 3]) == 6
    assert get_group_vars(['a', 'b', 'c']) == 'abc'
    assert get_group_vars([]) == ''


# Test for function sort_groups

# Generated at 2022-06-24 19:38:55.122276
# Unit test for function get_group_vars
def test_get_group_vars():
    try:
        test_case_0()
    except Exception as e:
        assert False, "An error occurred on test case 0: " + str(e)


# Make the module executable.

from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 19:38:56.949291
# Unit test for function get_group_vars

# Generated at 2022-06-24 19:38:57.988268
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars() == "failed"

# Generated at 2022-06-24 19:38:58.993080
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True == True



# Generated at 2022-06-24 19:39:02.317777
# Unit test for function get_group_vars
def test_get_group_vars():
    #from ansible.utils.vars import get_group_vars
    result = get_group_vars()
    assert result is not None, "No value returned from get_group_vars"


# Generated at 2022-06-24 19:39:03.232723
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True == True


# Generated at 2022-06-24 19:39:06.564796
# Unit test for function get_group_vars
def test_get_group_vars():
    # Nothing to assert because the function does not return anything
    assert(get_group_vars() == None)
    assert(get_group_vars() == None)
    assert(get_group_vars() == None)



# Generated at 2022-06-24 19:39:07.595879
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True == True


# Generated at 2022-06-24 19:39:08.192332
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars() == expected

# Generated at 2022-06-24 19:39:09.163778
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(var_0) == str_0



# Generated at 2022-06-24 19:39:11.199718
# Unit test for function get_group_vars
def test_get_group_vars():
    """
    Test if the get_group_vars returns the
    expected value for various different
    inputs.
    """
    test_case_0()

# Generated at 2022-06-24 19:39:15.887261
# Unit test for function get_group_vars
def test_get_group_vars():

    assert test_case_0() == ["failed to transfer file to %s: %s"]
    assert test_case_1() == ["failed to transfer file to %s: %s"]

# Generated at 2022-06-24 19:39:17.729405
# Unit test for function get_group_vars
def test_get_group_vars():
    assert 'foo' == 'foo'

# Generated at 2022-06-24 19:39:25.002174
# Unit test for function get_group_vars

# Generated at 2022-06-24 19:39:31.786552
# Unit test for function get_group_vars
def test_get_group_vars():
    str_1 = "failed to transfer file to '%s': %s"
    var_1 = get_group_vars(str_1)
    str_2 = "failed to transfer file to '%s': %s"
    var_2 = get_group_vars(str_2)
    assert (var_1 == var_2)
    print('All test cases passed.')

# Unit test execution
test_get_group_vars()

# Generated at 2022-06-24 19:39:34.417723
# Unit test for function get_group_vars
def test_get_group_vars():

    try:
        assert(test_case_0())
        print("Function 'get_group_vars' works as expected")
    except:
        print("Error: Function 'get_group_vars' does not work as expected")

# Generated at 2022-06-24 19:39:35.664390
# Unit test for function get_group_vars
def test_get_group_vars():
    assert 0



# Generated at 2022-06-24 19:39:37.500615
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(0) == None


# Generated at 2022-06-24 19:39:40.509946
# Unit test for function get_group_vars
def test_get_group_vars():
    assert str(test_case_0) == "failed to transfer file to '%s': %s"


# End of generated tests

if __name__ == "__main__":
    test_get_group_vars()

# Generated at 2022-06-24 19:39:48.285687
# Unit test for function get_group_vars
def test_get_group_vars():

    # Case 0
    test_case_0()
    # Case 1
    str_0 = str_1 = str_2 = str_3 = str_4 = 0
    var_0 = get_group_vars(str_0)
    var_1 = get_group_vars(str_1)
    var_2 = get_group_vars(str_2)
    var_3 = get_group_vars(str_3)
    var_4 = get_group_vars(str_4)
    if (var_2 != var_4):
        var_2 = var_4


# Try to match 'e'

# Generated at 2022-06-24 19:39:49.627608
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars('failed to transfer file to \'%s\': %s') == {}

# Generated at 2022-06-24 19:39:55.514890
# Unit test for function get_group_vars
def test_get_group_vars():
    str_0 = "failed to transfer file to '%s': %s"
    expected_0 = "failed to transfer file to '%s': %s"
    actual_0 = get_group_vars(str_0)
    assert actual_0 == expected_0

# Generated at 2022-06-24 19:40:05.327818
# Unit test for function get_group_vars
def test_get_group_vars():
    ansible_vars_0 = {
        'ansible_ssh_host': '10.254.254.254',
        'ansible_connection': 'network_cli',
        'ansible_network_os': 'nexus'
    }

    ansible_port_0 = 22
    ansible_user_0 = 'localadmin'
    ansible_password_0 = 'Test_Pass'
    ansible_ssh_private_key_file_0 = None
    ansible_become_method_0 = 'enable'
    ansible_become_username_0 = 'admin'
    ansible_become_password_0 = 'Test_Pass'
    ansible_ssh_common_args_0 = '-o StrictHostKeyChecking=no'

# Generated at 2022-06-24 19:40:14.877959
# Unit test for function get_group_vars

# Generated at 2022-06-24 19:40:21.477554
# Unit test for function get_group_vars
def test_get_group_vars():

    # Call function 'get_group_vars' with parameters:
    # ('example_interfaces_only',)
    test_function_0(get_group_vars)

    # Call function 'get_group_vars' with parameters:
    # ('example_interfaces_only_netconf',)
    test_function_1(get_group_vars)


# Generated at 2022-06-24 19:40:27.005076
# Unit test for function get_group_vars
def test_get_group_vars():
    """
    Test get_group_vars
    """

    str_0 = "failed to transfer file to '%s': %s"

    var_0 = get_group_vars(str_0)



# Generated at 2022-06-24 19:40:34.470159
# Unit test for function get_group_vars
def test_get_group_vars():

    # Get a random key
    assert type(get_group_vars.func_code.co_varnames[0]) == str
    assert type(get_group_vars.func_code.co_varnames[1]) == str

    # Get a random value
    assert type(get_group_vars.func_code.co_varnames[2]) == str
    assert type(get_group_vars.func_code.co_varnames[3]) == str


# Generated at 2022-06-24 19:40:42.233173
# Unit test for function get_group_vars

# Generated at 2022-06-24 19:40:43.904455
# Unit test for function get_group_vars
def test_get_group_vars():
    with pytest.raises(TypeError):
        test_case_0()


# Generated at 2022-06-24 19:40:45.568676
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars() == "failed to transfer file to '%s': %s"

# Generated at 2022-06-24 19:40:46.488782
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(str_0) == var_0

# Generated at 2022-06-24 19:40:49.598315
# Unit test for function get_group_vars
def test_get_group_vars():
    assert isinstance(get_group_vars(), dict)

# Generated at 2022-06-24 19:40:51.299319
# Unit test for function get_group_vars
def test_get_group_vars():
    assert test_case_0() == "failed to transfer file to '%s': %s"

# Generated at 2022-06-24 19:41:02.585222
# Unit test for function get_group_vars
def test_get_group_vars():
    arg0 = [
        {'_meta': {'hostvars': {'localhost': {'foo': 1, 'bar': 2}}}, 'all': {'children': ['ungrouped']}, 'group_names': ['group_0'], 'vars': {'baz': 3}},
        {'_meta': {'hostvars': {'localhost': {'foo': 6, 'bar': 7}}}, 'all': {'children': ['ungrouped']}, 'group_names': ['group_0'], 'vars': {'qux': 8}}
    ]
    exp0 = {'baz': 3, 'qux': 8, 'foo': 6, 'bar': 7, 'localhost': {'foo': 6, 'bar': 7}}

# Generated at 2022-06-24 19:41:04.377398
# Unit test for function get_group_vars
def test_get_group_vars():
    assert(type(get_group_vars(str_0)) is dict)

# Generated at 2022-06-24 19:41:11.983536
# Unit test for function get_group_vars
def test_get_group_vars():
    var_1 = get_group_vars(type(sort_groups))
    var_2 = get_group_vars(type(test_case_0))
    var_3 = get_group_vars(type(get_group_vars))

    assert var_1 == type(sort_groups)
    assert var_2 == type(test_case_0)
    assert var_3 == type(get_group_vars)

# Main program
if __name__ == "__main__":
    test_get_group_vars()

# Generated at 2022-06-24 19:41:12.423611
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True

# Generated at 2022-06-24 19:41:14.199246
# Unit test for function get_group_vars
def test_get_group_vars():
    test_case_0()

# Generated at 2022-06-24 19:41:16.005006
# Unit test for function get_group_vars
def test_get_group_vars():
    # create a test case
    test_0 = test_case_0()
    # perform the test
    assert test_0 == True

# Generated at 2022-06-24 19:41:18.222078
# Unit test for function get_group_vars
def test_get_group_vars():
    pass

# Generated at 2022-06-24 19:41:19.075424
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars() == None

# Generated at 2022-06-24 19:41:24.858899
# Unit test for function get_group_vars
def test_get_group_vars():
    assert callable(get_group_vars)

# Generated at 2022-06-24 19:41:26.301170
# Unit test for function get_group_vars
def test_get_group_vars():
    assert not test_case_0()
# END unittest for function get_group_vars

# Generated at 2022-06-24 19:41:27.127689
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars([]) == {}

# Generated at 2022-06-24 19:41:32.010884
# Unit test for function get_group_vars
def test_get_group_vars():
    args = []
    if test_get_group_vars.__name__ == '__main__':
        test_case_0()
    if test_get_group_vars.__name__ == '__main__':
        for arg in sys.argv[1:]:
            args.append(arg)
    else:
        args = args
    for arg in args:
        exec ('%s()' % arg)

# Generated at 2022-06-24 19:41:37.373950
# Unit test for function get_group_vars
def test_get_group_vars():
    var_1 = {web_server: [{host_a: {}}], web_servers: [{host_a: {}}]}

# Generated at 2022-06-24 19:41:38.529258
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True, 'Unable to parse comments'

# Generated at 2022-06-24 19:41:40.080860
# Unit test for function get_group_vars
def test_get_group_vars():
    obj_0 = test_case_0()



# Generated at 2022-06-24 19:41:41.096056
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(_input) == _expected

# Generated at 2022-06-24 19:41:42.078002
# Unit test for function get_group_vars
def test_get_group_vars():
    pass



# Generated at 2022-06-24 19:41:43.027296
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars()

# Generated at 2022-06-24 19:41:54.897488
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True

# Generated at 2022-06-24 19:42:00.219581
# Unit test for function get_group_vars
def test_get_group_vars():
    assert  isinstance(get_group_vars({"failed_when_result": "rc ne 0 and rc ne 66"}), dict)
    assert  isinstance(get_group_vars({"failed_when_result": "rc ne 0 and rc ne 66"}), dict)
    assert  isinstance(get_group_vars({"failed_when_result": "rc ne 0 and rc ne 66"}), dict)

# Generated at 2022-06-24 19:42:02.870205
# Unit test for function get_group_vars
def test_get_group_vars():
    """
    Test the get_group_vars function from the ansible.inventory.host module.
    """

    assert True


# Generated at 2022-06-24 19:42:05.150825
# Unit test for function get_group_vars
def test_get_group_vars():
    var_0 = get_group_vars(b'failed to\x00\x00')
    assert var_0 is b'failed to\x00\x00'

# Generated at 2022-06-24 19:42:08.422506
# Unit test for function get_group_vars
def test_get_group_vars():
    assert "#" in get_group_vars(str)
    assert "g" in get_group_vars(str)
    assert "d" in get_group_vars(str)


# Generated at 2022-06-24 19:42:13.373366
# Unit test for function get_group_vars
def test_get_group_vars():
    assert isinstance(get_group_vars(str_0), dict)
    assert not isinstance(get_group_vars(str_0), str)
    assert not isinstance(get_group_vars(str_0), list)
    assert isinstance(get_group_vars(str_0), bool)


# Generated at 2022-06-24 19:42:22.754903
# Unit test for function get_group_vars
def test_get_group_vars():
    data = {'vars': {'foo': 'bar'}, 'children': ['ungrouped']}
    case_0 = {
        'hosts': {'host_0': {'hostname': 'host_0'}},
        'vars': {
            'ansible_host': 'host_0',
            'ansible_connection': 'ssh',
            'ansible_user': 'user_0',
            'ansible_ssh_pass': 'password_0'
        },
        'children': ['child_0']
    }

# Generated at 2022-06-24 19:42:23.825759
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True == True


# Generated at 2022-06-24 19:42:24.976892
# Unit test for function get_group_vars
def test_get_group_vars():
    assert 'foo' == 'foo'

# Generated at 2022-06-24 19:42:25.913908
# Unit test for function get_group_vars
def test_get_group_vars():
    assert False


# Generated at 2022-06-24 19:42:49.175682
# Unit test for function get_group_vars
def test_get_group_vars():
    # Testing for function get_group_vars without parameters
    get_group_vars_0 = get_group_vars()
    assert get_group_vars_0 == {}

# Generated at 2022-06-24 19:42:51.900563
# Unit test for function get_group_vars
def test_get_group_vars():
    func_name = get_group_vars.__name__
    test_data = ["ansible.inventory.group"]
    param_map = {"groups": test_data}
    test_case_0(func_name, param_map)

# Generated at 2022-06-24 19:42:54.470623
# Unit test for function get_group_vars
def test_get_group_vars():
    assert str(test_case_0)

# Generated at 2022-06-24 19:42:55.938923
# Unit test for function get_group_vars
def test_get_group_vars():
    # Unit test case 0 (common)
    test_case_0()


# Generated at 2022-06-24 19:43:04.698804
# Unit test for function get_group_vars
def test_get_group_vars():
    var_0 = ['HTTP', 'failed to transfer file to \'%s\': %s', 'to', 'urllib2']
    var_1 = ['HTTP', 'failed to transfer file to \'%s\': %s', 'to', 'urllib2']
    var_2 = ['HTTP', 'failed to transfer file to \'%s\': %s', 'to', 'urllib2']
    var_3 = ['HTTP', 'failed to transfer file to \'%s\': %s', 'to', 'urllib2']
    get_group_vars(var_0, var_1, var_2, var_3)
    var_4 = ['HTTP', 'failed to transfer file to \'%s\': %s', 'to', 'urllib2']

# Generated at 2022-06-24 19:43:09.278108
# Unit test for function get_group_vars
def test_get_group_vars():
    for x in range(10):
        print("Running test case #" + str(x))
        test_case_0()

test_get_group_vars()

# Generated at 2022-06-24 19:43:10.122171
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars()



# Generated at 2022-06-24 19:43:18.578529
# Unit test for function get_group_vars
def test_get_group_vars():
    str_0 = ''''%s' is not a valid option for the sudo connection method\nValid options are: %s'''
    var_0 = ''''%s' is not a valid option for the sudo connection method\nValid options are: %s'''
    var_1 = '''Variable '%s' is required by the template, but was not set'''
    var_2 = '''ERROR! The selected transport '%s' does not match the transport option given by the playbook ('%s'). If you continue, your execution will likely fail.\n\n'''

# Generated at 2022-06-24 19:43:19.648740
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(str_0) == var_0

# Generated at 2022-06-24 19:43:26.160707
# Unit test for function get_group_vars
def test_get_group_vars():
    vars = {}
    for group in sort_groups([
        Group(name="all", vars={"foo": "bar"}),
        Group(name="parent", priority=100, vars={"foo": "not_bar"}),
        Group(name="child", depth=1, priority=10, vars={"foo": "also_bar"})
    ]):
        vars = combine_vars(vars, group.get_vars())

    assert vars == {
        "foo": "also_bar",
        "parent_name": "parent",
        "child_name": "child",
        "child_parent_name": "parent"
    }



# Generated at 2022-06-24 19:44:10.758433
# Unit test for function get_group_vars
def test_get_group_vars():
    pass

# Generated at 2022-06-24 19:44:15.543244
# Unit test for function get_group_vars
def test_get_group_vars():
    str_0 = "failed to transfer file to '%s': %s"
    str_1 = "failed to transfer file to '%s': %s"
    var_0 = get_group_vars(str_0)
    var_1 = get_group_vars(str_1)
    assert var_0 == var_1


# Generated at 2022-06-24 19:44:21.494371
# Unit test for function get_group_vars
def test_get_group_vars():

    obj_0 = load_fixture('inventory_group_dict', 'inventory/group_vars')
    # Test if the value of `groups` is a list
    assert isinstance(obj_0, list)
    # Test if the value of each element of `groups` is a Group
    assert all(isinstance(obj_0[i], Group) for i in range(len(obj_0)))
    # Test if the value is an empty list
    assert not obj_0


# Generated at 2022-06-24 19:44:23.246655
# Unit test for function get_group_vars
def test_get_group_vars():
    try:
        assert True
    except Exception as e:
        print("An error occurred in the get_group_vars test case")
        print(e)
    else:
        print("The get_group_vars test case passed!")


# Generated at 2022-06-24 19:44:24.623017
# Unit test for function get_group_vars
def test_get_group_vars():
    assert to_str("") == to_str("")

# Generated at 2022-06-24 19:44:25.825511
# Unit test for function get_group_vars
def test_get_group_vars():
    assert callable(get_group_vars)

# Generated at 2022-06-24 19:44:28.275745
# Unit test for function get_group_vars
def test_get_group_vars():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-24 19:44:37.481775
# Unit test for function get_group_vars
def test_get_group_vars():
    print ("\n\n\n\n#######################\nRunning test for function get_group_vars\n#######################")

    print ("\n\n######\nTEST-1: test_case_0\n######")

    str_0 = "failed to transfer file to '%s': %s"
    print ("Input: ")
    print ("str_0: ", str_0)

    print ("\nOutput: ")
    var_0 = get_group_vars(str_0)
    print ("var_0: ", var_0)


# Main function to trigger unit test
if __name__ == '__main__':
    test_get_group_vars()


# End of unit test

# Generated at 2022-06-24 19:44:47.104932
# Unit test for function get_group_vars

# Generated at 2022-06-24 19:44:51.242754
# Unit test for function get_group_vars
def test_get_group_vars():
    try:
        str_0 = ''
        var_0 = get_group_vars(str_0)
        assert 'successful' == var_0
    except AssertionError as e:
        print(e)
        assert False



# Generated at 2022-06-24 19:46:26.771638
# Unit test for function get_group_vars
def test_get_group_vars():
    test_case_0()

# Generated at 2022-06-24 19:46:27.308770
# Unit test for function get_group_vars
def test_get_group_vars():
    pass

# Generated at 2022-06-24 19:46:31.120640
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(str_0) == var_0

# Generated at 2022-06-24 19:46:35.518330
# Unit test for function get_group_vars
def test_get_group_vars():
    arg_0 = ["foo", "bar"]
    result = get_group_vars(arg_0)
    assert result != None

    arg_1 = ["foo", "bar"]
    result = get_group_vars(arg_1)
    assert result != None

    arg_2 = ["foo", "bar"]
    result = get_group_vars(arg_2)
    assert result != None



# Generated at 2022-06-24 19:46:36.506626
# Unit test for function get_group_vars
def test_get_group_vars():
    assert not get_group_vars(str_0) == var_0

# Generated at 2022-06-24 19:46:38.719145
# Unit test for function get_group_vars
def test_get_group_vars():
    string = '''failed to transfer file to '%s': %s'''

    assert str(get_group_vars(string)) == str('''failed to transfer file to '%s': %s''')

# Generated at 2022-06-24 19:46:41.839389
# Unit test for function get_group_vars
def test_get_group_vars():
    results_0 = test_case_0()

# Generated at 2022-06-24 19:46:49.945624
# Unit test for function get_group_vars
def test_get_group_vars():
  assert get_group_vars(str_0) == var_0
  assert get_group_vars(str_0) == var_0
  assert get_group_vars(str_0) == var_0
  assert get_group_vars(str_0) == var_0
  assert get_group_vars(str_0) == var_0
  assert get_group_vars(str_0) == var_0
  assert get_group_vars(str_0) == var_0
  assert get_group_vars(str_0) == var_0
  assert get_group_vars(str_0) == var_0
  assert get_group_vars(str_0) == var_0
  assert get_group_vars(str_0) == var_0

# Generated at 2022-06-24 19:46:50.769740
# Unit test for function get_group_vars
def test_get_group_vars():
    assert str_0 == var_0

# Generated at 2022-06-24 19:46:53.060063
# Unit test for function get_group_vars
def test_get_group_vars():
    str_0 = "failed to transfer file to '%s': %s"
    var_0 = get_group_vars(str_0)
