

# Generated at 2022-06-24 19:38:27.344841
# Unit test for function get_group_vars
def test_get_group_vars():
    import filecmp
    import shutil
    import ansible.parsing.dataloader
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.manager

    DATA_PATH = os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/inventory')
    INVENTORY_PATH = os.path.join(DATA_PATH, 'sample_inventory.ini')
    expected_result_file = "./unit/ansible/inventory/test_group/expected_results/test_get_group_vars__unit.txt"
    test_result_file = "./unit/ansible/inventory/test_group/test_results/test_get_group_vars__unit.txt"

    # set up environment
    ansible.pars

# Generated at 2022-06-24 19:38:32.561431
# Unit test for function get_group_vars
def test_get_group_vars():
    # Setup test data
    int_0 = 70

    # Exercise function
    var_0 = get_group_vars(int_0)

    # Verify Expected Results
    assert var_0 == int_0

# Generated at 2022-06-24 19:38:36.145058
# Unit test for function get_group_vars
def test_get_group_vars():
    pass

# Generated at 2022-06-24 19:38:46.383763
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = None
    var_3 = get_group_vars(int_0)
    assert var_3 == {}, 'Ansible not returning expected value'
    int_0 = 70
    var_3 = get_group_vars(int_0)
    assert var_3 == {}, 'Ansible not returning expected value'
    int_0 = {'a': 25, 'b': 36}
    var_3 = get_group_vars(int_0)
    assert var_3 == {'a': 25, 'b': 36}, 'Ansible not returning expected value'
    int_0 = 3.14159
    var_3 = get_group_vars(int_0)
    assert var_3 == {}, 'Ansible not returning expected value'

# Generated at 2022-06-24 19:38:48.512713
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(70) == {}, 'Expected dict() to equal dict()'

# Generated at 2022-06-24 19:38:50.642975
# Unit test for function get_group_vars
def test_get_group_vars():
    """
    Test if get_group_vars is defined.
    """
    assert callable(get_group_vars)



# Generated at 2022-06-24 19:38:51.561429
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True == True


# Generated at 2022-06-24 19:39:02.022008
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 40
    var_0 = get_group_vars(int_0)
    assert var_0 == 40

    int_0 = 42
    var_0 = get_group_vars(int_0)
    assert var_0 == 42

    int_0 = 40.5
    var_0 = get_group_vars(int_0)
    assert var_0 == 40.5

    int_0 = [42, 53]
    var_0 = get_group_vars(int_0)
    assert var_0 == [42, 53]

    int_0 = {'a': 42, 'b': 53, 'c': [42, 53], 'd': 'pop', 'e': [3, 4, 5, 6]}
    var_0 = get_group_vars(int_0)

# Generated at 2022-06-24 19:39:11.804855
# Unit test for function get_group_vars
def test_get_group_vars():
    from ansible.vars import GroupVars
    from ansible.parsing.dataloader import DataLoader

    grps = ['group0', 'group1', 'group2', 'group3', 'group4']
    for g in grps:
        assert g in GroupVars

    group = GroupVars(grps[0], loader=DataLoader())
    group.vars = {'group_ansible_var': 'group0'}
    assert {'group_ansible_var': 'group0'} == get_group_vars([group])

    loader = DataLoader()

    group0 = GroupVars(grps[0], loader=loader)
    group0.vars = {'group_ansible_var': 'group0'}

# Generated at 2022-06-24 19:39:13.836783
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(70) == 70


# Generated at 2022-06-24 19:39:17.965409
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(int_0) == (var_0)

# Generated at 2022-06-24 19:39:19.219384
# Unit test for function get_group_vars
def test_get_group_vars():
    assert isinstance(test_case_0(), dict)


# Generated at 2022-06-24 19:39:19.701634
# Unit test for function get_group_vars
def test_get_group_vars():
    assert func_0() == None

# Generated at 2022-06-24 19:39:21.575207
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 70
    var_0 = get_group_vars(int_0)
    assert var_0 == 1



# Generated at 2022-06-24 19:39:30.984723
# Unit test for function get_group_vars
def test_get_group_vars():
    var_1 = {"a": 1, "b": 2}
    var_2 = {"a": 5, "c": 10}
    var_3 = {"c": 5}

    class MockGroup(object):
        def __init__(self, depth, priority, vars):
            self.depth = depth
            self.priority = priority
            self.vars = vars

        def get_vars(self):
            return self.vars

    groups = [
        MockGroup(0, 1, var_1),
        MockGroup(0, 2, var_2),
        MockGroup(3, 3, var_3),
    ]

    var_4 = get_group_vars(groups)
    if var_4 == {'a': 5, 'b': 2, 'c': 5}:
        return True

# Generated at 2022-06-24 19:39:42.688596
# Unit test for function get_group_vars
def test_get_group_vars():
    var_1 = {'ansible_user': 'ec2-user', 'ec2_metadata': 'TEST1', 'ansible_password': 'VAR_1'}
    var_2 = {'ec2_metadata': 'TEST2', 'ansible_ssh_user': 'ubuntu', 'ec2_ami': 'ami-0000000a', 'ansible_ssh_pass': 'VAR_2'}
    int_0 = {'app': Group([Host(name='127.0.0.1')],var_1), 'ec2': Group([Host(name='127.0.0.1')],var_2)}
    var_3 = get_group_vars(int_0)

# Generated at 2022-06-24 19:39:43.891900
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True


# Generated at 2022-06-24 19:39:44.809374
# Unit test for function get_group_vars
def test_get_group_vars():
    test_case_0()

# Generated at 2022-06-24 19:39:47.164534
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 70
    var_0 = get_group_vars(int_0)

    assert var_0 == 70
    test_case_0()

# Generated at 2022-06-24 19:39:48.085087
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(70) == 70

# Generated at 2022-06-24 19:39:51.215804
# Unit test for function get_group_vars
def test_get_group_vars():
    assert callable(get_group_vars)

    assert get_group_vars(70) == {}

# Generated at 2022-06-24 19:39:52.780897
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 70
    var_0 = get_group_vars(int_0)
    assert var_0 == 70

# Generated at 2022-06-24 19:39:57.763985
# Unit test for function get_group_vars
def test_get_group_vars():
    func_name = 'get_group_vars'
    var_0 = {'group_0': {'var_0': 0}}

    # Test with empty variables
    r = combine_vars(var_0)
    assert r == var_0

    # Test with valid input
    r = get_group_vars(var_0)
    assert r == var_0

# Generated at 2022-06-24 19:39:58.876367
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(5) == 5

# Generated at 2022-06-24 19:40:03.417948
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 70

    with patch('ansible.inventory.manager.get_group_vars') as mock_get_group_vars:
        mock_get_group_vars.return_value = {}
        var_0 = get_group_vars(int_0)

        assert isinstance(var_0, dict)
        assert_equal(var_0, {})



# Generated at 2022-06-24 19:40:06.518572
# Unit test for function get_group_vars
def test_get_group_vars():
    cur_vars = get_group_vars(1)
    new_vars = {}
    get_group_vars(cur_vars, new_vars)
    assert cur_vars == new_vars

# Generated at 2022-06-24 19:40:08.396329
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 70
    var_0 = get_group_vars(int_0)
    assert var_0 == 70


# Generated at 2022-06-24 19:40:12.835361
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(0) == None, "Ansible failed to return the proper results"
    assert get_group_vars(5) == None, "Ansible failed to return the proper results"
    assert get_group_vars(6) == None, "Ansible failed to return the proper results"
    assert get_group_vars(-11) == None, "Ansible failed to return the proper results"

# Generated at 2022-06-24 19:40:20.008079
# Unit test for function get_group_vars
def test_get_group_vars():
    host_0 = ansible.inventory.host.Host('localhost')
    group_0 = ansible.inventory.group.Group(name='all')
    group_0.vars = {'ansible_connection': 'local', 'ansible_ssh_user': 'myuser', 'ansible_ssh_pass': 'mypassword'}
    group_0.hosts = [host_0]
    group_0.depth = 0
    group_0.priority = 0
    assert 'ansible_connection' in get_group_vars([group_0])

# Generated at 2022-06-24 19:40:26.980296
# Unit test for function get_group_vars
def test_get_group_vars():
    # Getting 'int' object is not callable error
    int_0 = 70
    int_1 = 70
    int_2 = 70
    int_3 = 70
    dict_0 = {}
    dict_1 = {}
    dict_1['vars'] = dict_0
    dict_2 = {}
    dict_2['vars'] = dict_0
    dict_3 = {}
    dict_3['vars'] = dict_0
    dict_4 = {}
    dict_4['vars'] = dict_0
    dict_5 = {}
    dict_5['children'] = dict_4
    dict_5['vars'] = dict_0
    dict_6 = {}
    dict_6['children'] = dict_4
    dict_6['vars'] = dict_0
    dict_7 = {}


# Generated at 2022-06-24 19:40:31.995603
# Unit test for function get_group_vars
def test_get_group_vars():
    val_0 = get_group_vars(int_0)
    assert val_0 == var_0

# Generated at 2022-06-24 19:40:33.188177
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(70) == get_group_vars(70)

# Generated at 2022-06-24 19:40:40.860289
# Unit test for function get_group_vars
def test_get_group_vars():
    int_2 = 70
    str_0 = 'hosta'
    str_1 = 'hostb'
    str_2 = 'hostc'
    str_3 = 'hostd'
    str_4 = 'hoste'
    str_5 = 'hostf'
    dict_0 = {'ansible_host': str_0, 'ansible_user': str_1, 'ansible_port': int_2}
    dict_1 = {'ansible_host': str_0, 'ansible_user': str_1, 'ansible_port': int_2}
    dict_2 = {'ansible_host': str_0, 'ansible_user': str_2, 'ansible_port': int_2}

# Generated at 2022-06-24 19:40:41.738703
# Unit test for function get_group_vars
def test_get_group_vars():
    assert var_0 == {}


# Generated at 2022-06-24 19:40:43.241871
# Unit test for function get_group_vars
def test_get_group_vars():
    test_case_0()


main = test_get_group_vars

# Generated at 2022-06-24 19:40:53.146035
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(70) == 70
    assert get_group_vars(0) == 0
    assert get_group_vars(0.0) == 0.0
    assert get_group_vars('') == ''
    assert get_group_vars('hi') == 'hi'
    assert get_group_vars(False) == False
    assert get_group_vars(True) == True
    assert get_group_vars([]) == []
    assert get_group_vars([0]) == [0]
    assert get_group_vars([0.0]) == [0.0]
    assert get_group_vars(['']) == ['']
    assert get_group_vars(['hi']) == ['hi']

# Generated at 2022-06-24 19:40:53.807558
# Unit test for function get_group_vars
def test_get_group_vars():
    pass

# Generated at 2022-06-24 19:40:55.062561
# Unit test for function get_group_vars
def test_get_group_vars():
    # IndexError exception
    try:
        test_case_0()
    except Exception as e:
        assert(str(e) == 'list index out of range')

# Generated at 2022-06-24 19:40:58.620986
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 70
    var_0 = get_group_vars(int_0)


# Generated at 2022-06-24 19:41:03.124792
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 70
    result_0 = test_case_0()
    assert result_0 == int_0


# Integration tests

# Generated at 2022-06-24 19:41:15.390746
# Unit test for function get_group_vars
def test_get_group_vars():
    a = [1, 2, 3]

    assert sorted(a) == [1, 2, 3], 'List not sorted'
    assert sum((1, 2, 2)) == 6, 'Should be 6'



# Generated at 2022-06-24 19:41:18.458222
# Unit test for function get_group_vars
def test_get_group_vars():
    assert 1 == 1


# Generated at 2022-06-24 19:41:20.812958
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 70
    var_0 = get_group_vars(int_0)


# Tests for functions
# Unit tests for function sort_groups

# Generated at 2022-06-24 19:41:23.540254
# Unit test for function get_group_vars
def test_get_group_vars():
    test_case_0()

# Generated at 2022-06-24 19:41:29.479688
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 70
    var_0 = get_group_vars(int_0)
    assert isinstance(var_0, dict)
    assert var_0 == {}

    int_0 = [70, 50, '140', '100']
    var_0 = get_group_vars(int_0)
    assert isinstance(var_0, dict)
    assert var_0 == {}

    int_0 = [70, 10, 70]
    var_0 = get_group_vars(int_0)
    assert isinstance(var_0, dict)
    assert var_0 == {}

    int_0 = [10, 10, 70]
    var_0 = get_group_vars(int_0)
    assert isinstance(var_0, dict)
    assert var_0 == {}

   

# Generated at 2022-06-24 19:41:29.992528
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True


# Generated at 2022-06-24 19:41:30.626472
# Unit test for function get_group_vars
def test_get_group_vars():
    pass

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-24 19:41:31.975006
# Unit test for function get_group_vars
def test_get_group_vars():
    assert test_case_0.__name__ == "int_0"

if __name__ == "__main__":
    test_get_group_vars()

# Generated at 2022-06-24 19:41:33.096566
# Unit test for function get_group_vars
def test_get_group_vars():
  assert 1

# Test cases for function get_group_vars

# Generated at 2022-06-24 19:41:44.183026
# Unit test for function get_group_vars
def test_get_group_vars():
    assert sort_groups(67) == 67
    assert sort_groups(63) == 63
    assert sort_groups(90) == 90
    assert sort_groups(90) == 90
    assert sort_groups(34) == 34
    assert sort_groups(45) == 45
    assert sort_groups(64) == 64
    assert sort_groups(23) == 23
    assert sort_groups(2) == 2
    assert sort_groups(92) == 92
    assert sort_groups(4) == 4
    assert sort_groups(17) == 17
    assert sort_groups(82) == 82
    assert sort_groups(97) == 97
    assert sort_groups(59) == 59
    assert sort_groups(36) == 36
    assert sort_groups(81) == 81
    assert sort_groups(99) == 99
   

# Generated at 2022-06-24 19:42:08.123037
# Unit test for function get_group_vars
def test_get_group_vars():
    print()
    print('TEST: test_get_group_vars')

    try:
        from ansible.inventory.group import Group
        from ansible.inventory.host import Host
    except ImportError:
        print('SKIP: ansible is not installed')
        return

    # initialize
    g = Group('test')

    # create 3 groups
    g.add_child_group(Group('g0', depth=1))
    g.add_child_group(Group('g1', depth=2))
    g.add_child_group(Group('g2', depth=3, priority=10))

    # Each group has the following vars
    g.set_variable('depth', 0)
    g.vars['hostvars'] = {'h0': {'depth': 1}}

# Generated at 2022-06-24 19:42:10.349836
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(int_0) == get_group_vars(int_0)


# Generated at 2022-06-24 19:42:12.568941
# Unit test for function get_group_vars
def test_get_group_vars():
    test_case_0()


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 19:42:19.076960
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 70
    assert get_group_vars(int_0) == {'ansible_ssh_user': 'ubuntu', 'ansible_ssh_private_key_file': '/home/ubuntu/kp.pem', 'ansible_connection': 'ssh'}


# Generated at 2022-06-24 19:42:23.143499
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = None
    try:
        int_0 = get_group_vars(int_0)
    except:
        pass
    return int_0 is None


# Generated at 2022-06-24 19:42:31.392717
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 70
    var_0 = get_group_vars(int_0)
    sub_0 = var_0.pop(70)
    sub_1 = var_0.pop(70)
    sub_1 = var_0.pop(50)
    sub_1 = var_0.pop(20)
    sub_1 = var_0.pop(30)
    sub_1 = var_0.pop(60)
    sub_1 = var_0.pop(10)
    sub_1 = var_0.pop(40)

# Generated at 2022-06-24 19:42:41.651222
# Unit test for function get_group_vars
def test_get_group_vars():
    vars_to_test = [
        {},
        {'a': 1},
        {'a': 1, 'b': 'two'},
        {'a': 1, 'b': 'two', 'c': 3},
    ]

    assert get_group_vars([]) == {}

    # order of input should not be relevant
    assert get_group_vars(vars_to_test) == get_group_vars(vars_to_test[::-1])

    # same vars are overwritten by latter vars
    assert get_group_vars([{'a': 1, 'b': 'two'}, {'a': 1, 'b': 'two', 'c': 3}]) == {'a': 1, 'b': 'two', 'c': 3}

# Generated at 2022-06-24 19:42:50.962927
# Unit test for function get_group_vars
def test_get_group_vars():
    if "AnsibleModule" in globals():
        from ansible.module_utils.network.nxos.nxos import get_group_vars
        from ansible.module_utils.six import PY2
        host = 'host'
        group = 'group'
        runner = MockRunner()
        runner.add_inventory_hosts(host, group)
        runner.add_inventory_groups(host, group)
        result = get_group_vars(runner.inventory, runner.loader)
        assert result is not None
        result = get_group_vars(runner.inventory, runner.loader, host)
        assert result is not None
        result = get_group_vars(runner.inventory, runner.loader, host, group)
        assert result is not None



# Generated at 2022-06-24 19:42:53.669446
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 70
    result = get_group_vars(int_0)
    assert result != None



# Generated at 2022-06-24 19:42:56.269140
# Unit test for function get_group_vars
def test_get_group_vars():
    '''
    Test for the get_group_vars function
    '''
    for test_val in [70]:
        assert test_val == get_group_vars(test_val)
    for test_val in [70]:
        assert test_val == get_group_vars(test_val)

# Generated at 2022-06-24 19:43:27.808390
# Unit test for function get_group_vars
def test_get_group_vars():

    # Functional test for function get_group_vars
    assert get_group_vars(70) == None

# Generated at 2022-06-24 19:43:28.943657
# Unit test for function get_group_vars
def test_get_group_vars():
    data = {}
    # noinspection PyTypeChecker
    assert get_group_vars(data) is not None


# Generated at 2022-06-24 19:43:38.659456
# Unit test for function get_group_vars
def test_get_group_vars():
    r'''
    Tests for the get_group_vars function, which is used to combine all
    the group vars from a list of inventory groups.
    '''
    from ansible.module_utils.common.text.converters import to_bytes, to_native
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Testing with a poor-man's inventory
    local_host_0 = Host(name='localhost')
    local_host_1 = Host(name='localhost')
    local_host_2 = Host(name='localhost')

    vars_local_host_0 = local_host_0.vars
    vars_local_host_1 = local_host_1.vars
    vars_local_host_2 = local

# Generated at 2022-06-24 19:43:39.627878
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True


# Generated at 2022-06-24 19:43:48.976804
# Unit test for function get_group_vars
def test_get_group_vars():
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_1 = get_group_vars(var_1)
    if var_1 != var_2:
        errors.append("Failed to verify that get_group_vars(var_1) == var_2")
    var_3 = get_group_vars(var_3)
    if var_3 != var_4:
        errors.append("Failed to verify that get_group_vars(var_3) == var_4")
    if var_1 != var_4:
        errors.append("Failed to verify that var_1 == var_4")
    if var_3 != var_2:
        errors.append("Failed to verify that var_3 == var_2")

# Generated at 2022-06-24 19:43:50.268429
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True


# Generated at 2022-06-24 19:43:59.061147
# Unit test for function get_group_vars
def test_get_group_vars():
    import ansible.inventory.group
    int_0 = 70
    class_0 = ansible.inventory.group.Group
    var_0 = class_0()
    var_1 = [var_0]
    var_1.append(var_0)
    var_1.append(var_0)
    var_1.append(var_0)
    var_1.append(var_0)
    var_1.append(var_0)
    var_3 = {'key_0': 'value_1'}
    var_0.vars = var_3
    var_2 = get_group_vars(var_1)
    print(var_2)
    assert var_2 == var_3



# Generated at 2022-06-24 19:44:00.077186
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True


# Generated at 2022-06-24 19:44:01.694855
# Unit test for function get_group_vars
def test_get_group_vars():
    assert(get_group_vars("70") == int_0)

# Generated at 2022-06-24 19:44:02.407343
# Unit test for function get_group_vars
def test_get_group_vars():
    assert 1 == 0

# Generated at 2022-06-24 19:45:10.908655
# Unit test for function get_group_vars
def test_get_group_vars():
    group = Group()
    group.name = "foo"
    group.depth = 1
    group.priority = 100
    group.vars = {'a': 1}
    assert get_group_vars([group]) == {'a': 1}

    group2 = Group()
    group2.name = "bar"
    group2.depth = 2
    group2.priority = 200
    group2.vars = {'a': 2, 'b': 2}
    assert get_group_vars([group, group2]) == {'a': 2, 'b': 2}

    group3 = Group()
    group3.name = "baz"
    group3.depth = 1
    group3.priority = 300
    group3.vars = {'a': 3, 'b': 3}
    assert get_group_

# Generated at 2022-06-24 19:45:11.302657
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True

# Generated at 2022-06-24 19:45:12.085541
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(70) != 70

# Generated at 2022-06-24 19:45:15.566531
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = None
    var_0 = get_group_vars(int_0)
    print(var_0)


if __name__ == '__main__':
    test_case_0()
    test_get_group_vars()

# Generated at 2022-06-24 19:45:19.148670
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 1
    get_group_vars(int_0)

    int_0 = 70
    get_group_vars(int_0)

# Generated at 2022-06-24 19:45:22.722923
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True


# Generated at 2022-06-24 19:45:25.762140
# Unit test for function get_group_vars
def test_get_group_vars():
    print("In function")
    result = get_group_vars(70)
    assert len(result) == 0
# Main program
if __name__ == "__main__":
    test_case_0()
    test_get_group_vars()

# Generated at 2022-06-24 19:45:34.793325
# Unit test for function get_group_vars
def test_get_group_vars():
    hosts = [
        MockGroup(vars={'foo': 'first'}, depth=0, priority=0),
        MockGroup(vars={'bar': 'second'}, depth=1, priority=0),
        MockGroup(vars={'foo': 'third'}, depth=1, priority=0),
    ]
    assert get_group_vars(hosts) == {'foo': 'third', 'bar': 'second'}

    hosts = [
        MockGroup(vars={'foo': 'first'}, depth=0, priority=0),
        MockGroup(vars={'foo': 'second'}, depth=0, priority=0),
    ]
    assert get_group_vars(hosts) == {'foo': 'second'}


# Generated at 2022-06-24 19:45:35.623229
# Unit test for function get_group_vars
def test_get_group_vars():
    results = get_group_vars()
    assert results is None


# Generated at 2022-06-24 19:45:36.791012
# Unit test for function get_group_vars
def test_get_group_vars():
    assert sort_groups(70) == sorted(70, key=lambda g: (g.depth, g.priority, g.name))

# Generated at 2022-06-24 19:47:58.342723
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 70
    var_0 = get_group_vars(int_0)

    assert int_0 == 70
    assert var_0 == 70

# Generated at 2022-06-24 19:48:04.402121
# Unit test for function get_group_vars
def test_get_group_vars():
    # Test case 0
    int_0 = 70
    var_0 = get_group_vars(int_0)
    # Test case 1
    int_0 = 70
    var_0 = get_group_vars(int_0)
    # Test case 2
    int_0 = 70
    var_0 = get_group_vars(int_0)
    # Test case 3
    int_0 = 70
    var_0 = get_group_vars(int_0)
    # Test case 4
    int_0 = 70
    var_0 = get_group_vars(int_0)
    # Test case 5
    int_0 = 70
    var_0 = get_group_vars(int_0)
    # Test case 6
    int_0 = 70
    var_0 = get

# Generated at 2022-06-24 19:48:08.610181
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 70
    var_0 = get_group_vars(int_0)


# Generated at 2022-06-24 19:48:15.948732
# Unit test for function get_group_vars

# Generated at 2022-06-24 19:48:23.746962
# Unit test for function get_group_vars
def test_get_group_vars():
    host_list = [
        {
            "hostname": "localhost",
            "ansible_host": "127.0.0.1",
            "ansible_user": "vagrant",
        }
    ]
    host_group = [
        {
            "name": "test_group",
            "hosts": host_list
        }
    ]

    host_group[0]["vars"] = {
        "myvar": "myvalue"
    }

    assert get_group_vars(host_group) == {"myvar": "myvalue"}