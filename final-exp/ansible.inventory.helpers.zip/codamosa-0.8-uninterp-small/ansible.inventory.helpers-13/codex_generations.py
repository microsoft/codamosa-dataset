

# Generated at 2022-06-24 19:38:22.467523
# Unit test for function get_group_vars
def test_get_group_vars():
    output_0 = test_case_0()


# Generated at 2022-06-24 19:38:27.715429
# Unit test for function get_group_vars
def test_get_group_vars():
    f0_0 = 'abc'
    int_0 = 36
    str_0 = 'abc'
    var_0 = get_group_vars(int_0)
    var_1 = get_group_vars(str_0)


# Generated at 2022-06-24 19:38:30.774322
# Unit test for function get_group_vars
def test_get_group_vars():
    pass

# Generated at 2022-06-24 19:38:36.668340
# Unit test for function get_group_vars
def test_get_group_vars():
    h0 = Host(name='h0')
    h1 = Host(name='h1')
    h2 = Host(name='h2')
    h3 = Host(name='h3')
    h4 = Host(name='h4')
    h5 = Host(name='h5')
    h6 = Host(name='h6')
    h7 = Host(name='h7')

    g0 = Group(name='g0')
    g1 = Group(name='g1')
    g2 = Group(name='g2')
    g3 = Group(name='g3')
    g4 = Group(name='g4')
    g5 = Group(name='g5')
    g6 = Group(name='g6')
    g7 = Group(name='g7')

    g0.add_host

# Generated at 2022-06-24 19:38:47.312481
# Unit test for function get_group_vars
def test_get_group_vars():
    # check that int and string arg returns int
    assert isinstance(get_group_vars(0), int)
    assert isinstance(get_group_vars("0"), int)

    # check that both arg returns int
    assert isinstance(get_group_vars(0, 0), int)
    assert isinstance(get_group_vars("0", 0), int)
    assert isinstance(get_group_vars(0, "0"), int)
    assert isinstance(get_group_vars("0", "0"), int)

    # check that return value is between 0 and 9
    assert 0 <= get_group_vars(0) <= 9
    assert 0 <= get_group_vars("0") <= 9

    # check that return value is between 0 and 9

# Generated at 2022-06-24 19:38:50.231394
# Unit test for function get_group_vars
def test_get_group_vars():
    module = 'unit_tests'
    mod = importlib.import_module(module)
    var_0 = mod.test_case_0()
    assert var_0 == 36



# Generated at 2022-06-24 19:38:52.684451
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 36
    var_0 = get_group_vars(int_0)
    assert var_0 == 36, 'Expected 36, got {}'.format(var_0)

# Generated at 2022-06-24 19:39:03.034358
# Unit test for function get_group_vars
def test_get_group_vars():
    var_0 = 10
    var_1 = "abcd"
    var_2 = 20
    var_3 = "cdef"
    var_4 = 30
    var_5 = "efgh"
    var_6 = 40
    var_7 = "ghij"
    var_8 = 50
    var_9 = "ijkl"
    var_10 = 60
    var_11 = "klmn"
    var_12 = 70
    var_13 = "mnop"
    var_14 = 80
    var_15 = "pqrs"
    var_16 = 90
    var_17 = "rstu"
    var_18 = 100
    var_19 = "vwxy"
    var_20 = 110
    var_21 = "yza"
    var_22 = 120
    var

# Generated at 2022-06-24 19:39:07.119295
# Unit test for function get_group_vars
def test_get_group_vars():
    # Mock requires an iterable object, so let's make a list
    args = [range(10)]
    # Mock requires an iterable object, so let's make a list
    kwargs = [range(10)]
    results = get_group_vars(*args, **kwargs)

    assert isinstance(results, dict)

# Generated at 2022-06-24 19:39:08.160629
# Unit test for function get_group_vars
def test_get_group_vars():
    assert False


# Generated at 2022-06-24 19:39:19.282040
# Unit test for function get_group_vars
def test_get_group_vars():
    var_1 = {1, 4, 5, 6}
    var_1 = combine_vars(var_1, var_1)
    assert var_1 == {1, 4, 5, 6}
    var_1 = int()
    var_2 = {1, 4, 5, 6}
    var_2 = combine_vars(var_2, var_1)
    assert var_2 == {1, 4, 5, 6}
    var_2 = tuple()
    var_3 = {1, 4, 5, 6}
    get_group_vars(var_3)
    assert var_3 == {1, 4, 5, 6}
    var_3 = set()
    var_4 = {1, 4, 5, 6}

# Generated at 2022-06-24 19:39:29.216398
# Unit test for function get_group_vars
def test_get_group_vars():
    print("get_group_vars()")
    # Get the value of the global variable '__file__'. Relative path of the module calling the testcase
    file_path = os.path.relpath(__file__)
    # Split the path by '/' to get the relative path of the calling testcase file
    split_file_path = file_path.split("/")
    # Get the name of the calling testcase file
    file_name = split_file_path[len(split_file_path)-1]
    # Split the name of the testcase by '.' to get the name of the calling module
    split_file_name_with_ext = file_name.split(".")
    # Get only the name of the module
    module_name = split_file_name_with_ext[0]
    # Get the path for the test

# Generated at 2022-06-24 19:39:30.669607
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 36
    var_0 = get_group_vars(int_0)
    assert var_0 == 36



# Generated at 2022-06-24 19:39:32.069179
# Unit test for function get_group_vars
def test_get_group_vars():
    try:
        test_case_0()
    except Exception as err:
        print("Test Failed: {0}".format(err))

# Generated at 2022-06-24 19:39:40.793848
# Unit test for function get_group_vars
def test_get_group_vars():
    # Inventory with multiple groups
    inventory = ansible.inventory.Inventory(host_list=gethosts.gethosts())
    group = inventory._inventory.get_group('all')
    assert get_group_vars([group]) == {'apache_port': 80, 'common_var': 'common_value_3'}

    # Inventory with no group
    inventory = ansible.inventory.Inventory(host_list=gethosts.gethosts())
    assert get_group_vars([]) == {}


if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-24 19:39:42.975334
# Unit test for function get_group_vars
def test_get_group_vars():
    # Unit test for function get_group_vars
    int_0 = 36
    var_0 = get_group_vars(int_0)

# Generated at 2022-06-24 19:39:51.965378
# Unit test for function get_group_vars
def test_get_group_vars():
    var_1 = get_group_vars(groups)

# Generated at 2022-06-24 19:39:53.914001
# Unit test for function get_group_vars
def test_get_group_vars():
    pass

# Generated at 2022-06-24 19:39:54.946669
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars("") is None


# Generated at 2022-06-24 19:39:59.600030
# Unit test for function get_group_vars
def test_get_group_vars():
	# Arrange
	int_0 = 36

	# Act
	var_0 = get_group_vars(int_0)

	# Assert
	assert var_0 == 36

# Generated at 2022-06-24 19:40:01.541135
# Unit test for function get_group_vars
def test_get_group_vars():
    assert test_case_0() == 0


# Generated at 2022-06-24 19:40:03.215548
# Unit test for function get_group_vars
def test_get_group_vars():
    test_case_0()


if __name__ == '__main__':
    test_get_group_vars()

# Generated at 2022-06-24 19:40:03.822311
# Unit test for function get_group_vars
def test_get_group_vars():
    test_case_0()

# Generated at 2022-06-24 19:40:06.261627
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 36
    var_0 = get_group_vars(int_0)
    assert var_0 == 36

# Generated at 2022-06-24 19:40:10.346576
# Unit test for function get_group_vars
def test_get_group_vars():
    collection = [
        [36],
    ]
    for value in collection:
        test_case_0()


if __name__ == '__main__':
    test_get_group_vars()

# Generated at 2022-06-24 19:40:14.945277
# Unit test for function get_group_vars
def test_get_group_vars():
    print()
    # Assert if the function returns any output
    assert test_case_0( ) == None, "Function should return None"

# Generated at 2022-06-24 19:40:16.821558
# Unit test for function get_group_vars
def test_get_group_vars():
    test_case_0()

# Generated at 2022-06-24 19:40:18.879446
# Unit test for function get_group_vars
def test_get_group_vars():
    var_0 = get_group_vars(None)
    results = {}
    assert results == var_0, "Expected {}, but got: {}".format(results, var_0)

# Generated at 2022-06-24 19:40:19.686162
# Unit test for function get_group_vars
def test_get_group_vars():
    print(get_group_vars())

# Generated at 2022-06-24 19:40:20.440637
# Unit test for function get_group_vars
def test_get_group_vars():
    assert var_0 == 36


# Generated at 2022-06-24 19:40:25.561240
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 36
    var_0 = get_group_vars(int_0)
    ansible_0 = {'example': {'more_vars': {'some_key': '1234', 'some_hash': {'deeply': {'nested': 'test'}, 'test_key': 'test_val'}}}}
    assert var_0 == ansible_0


# Generated at 2022-06-24 19:40:31.234850
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 36
    var_0 = get_group_vars(int_0)
    assert var_0 == None

    int_1 = 36
    var_1 = get_group_vars(int_1)
    assert var_1 == None

# Generated at 2022-06-24 19:40:32.835907
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True == True



# Generated at 2022-06-24 19:40:34.717191
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 36
    var_0 = get_group_vars(int_0)
    assert var_0 == 36

# Generated at 2022-06-24 19:40:41.771734
# Unit test for function get_group_vars
def test_get_group_vars():
    group_0 = Group("group_0")
    group_1 = Group("group_1")
    group_2 = Group("group_2")
    host_0 = Host('host_0', group_0)
    host_1 = Host('host_1', group_0)
    host_2 = Host('host_2', group_1)
    host_3 = Host('host_3', group_1)
    group_0.add_host(host_0)
    group_0.add_host(host_1)
    group_1.add_host(host_2)
    group_1.add_host(host_3)
    #host_0.set_variable('foo', 'bar')
    #host_1.set_variable('foo', 'bar')
    #host_2.set_variable('foo

# Generated at 2022-06-24 19:40:42.869995
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars("") == 36

# Generated at 2022-06-24 19:40:51.747973
# Unit test for function get_group_vars
def test_get_group_vars():
    # Setup test data, call function and check result
    var_1 = {'test_variable_1': 'test_value_1', 'test_variable_2': 'test_value_2'}
    obj_1 = Mock()
    obj_1.get_vars.return_value = var_1
    list_1 = [obj_1, obj_1]
    var_2 = get_group_vars(list_1)
    obj_1.get_vars.assert_called_once_with()
    assert var_2 == {'test_variable_1': 'test_value_1', 'test_variable_2': 'test_value_2'}


# Generated at 2022-06-24 19:40:52.678866
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True


# Generated at 2022-06-24 19:40:59.463082
# Unit test for function get_group_vars
def test_get_group_vars():
 
    var_0 = [
        {'group1': {'foo': '1', 'bar': '2'}},
        {'group2': {'foo': '3'}},
        {'group3': {'foo': '4'}},
        {'all': {'foo': '5'}}
    ]
    var_0.sort(key=lambda g: (g.depth, g.priority, g.name))
    var_1 = {'foo': '5', 'bar': '2'}
    var_2 = get_group_vars(var_0)
    
    assert var_1 == var_2

# Generated at 2022-06-24 19:41:04.864095
# Unit test for function get_group_vars
def test_get_group_vars():

    # Test 0
    int_0 = 36
    var_0 = get_group_vars(int_0)

    # Test 1
    int_1 = 37
    var_1 = get_group_vars(int_1)

    # Test 2
    int_2 = 38
    var_2 = get_group_vars(int_2)

    # Test 3
    int_3 = 39
    var_3 = get_group_vars(int_3)

    # Test 4
    int_4 = 40
    var_4 = get_group_vars(int_4)

    # Test 5
    int_5 = 41
    var_5 = get_group_vars(int_5)

    # Test 6
    int_6 = 42

# Generated at 2022-06-24 19:41:10.183589
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 36
    var_0 = get_group_vars(int_0)
    assert var_0 == 36, 'Test Failed'

# Generated at 2022-06-24 19:41:20.026782
# Unit test for function get_group_vars
def test_get_group_vars():
    def test_01():
        # Get the filters
        int_0 = 36
        # Run the function
        var_0 = get_group_vars(int_0)
        # Check the result
        assert not var_0

    def test_02():
        # Get the filters
        int_0 = 36
        # Run the function
        var_0 = get_group_vars(int_0)
        # Check the result
        assert var_0 == {}

    def test_03():
        # Get the filters
        int_0 = 36
        # Run the function
        var_0 = get_group_vars(int_0)
        # Check the result
        assert var_0 == {'group_name': "foobar"}

    def test_04():
        # Get the filters
        int_0 = 36


# Generated at 2022-06-24 19:41:23.396215
# Unit test for function get_group_vars
def test_get_group_vars():
    test_case_0()

# Generated at 2022-06-24 19:41:24.205013
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(36) is None


# Generated at 2022-06-24 19:41:27.551592
# Unit test for function get_group_vars
def test_get_group_vars():
    source = """
        import  get_group_vars
        int_0 = 36
        var_0 = get_group_vars.get_group_vars(int_0)
        """

    tree = ast.parse(source)
    environment.apply_ast(tree, environment.defs)
    assert test_wrapper(tree, environment.defs) == 36

# Generated at 2022-06-24 19:41:28.514970
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True



# Generated at 2022-06-24 19:41:33.449873
# Unit test for function get_group_vars
def test_get_group_vars():
    groups = {'val_0': 'foo',
              'val_1': 6,
              'val_2': 'bar',
              'val_3': 'foo',
              'val_4': 'bar',
              'val_5': 6,
              'val_6': 6,
              'val_7': 'bar'}
    expected_result = groups
    actual_result = get_group_vars(groups)
    assert actual_result == expected_result

# Generated at 2022-06-24 19:41:36.738434
# Unit test for function get_group_vars
def test_get_group_vars():
    """
    Test that the `get_group_vars` method works.
    """

    assert len(get_group_vars(None)) == 0

# Generated at 2022-06-24 19:41:38.744980
# Unit test for function get_group_vars
def test_get_group_vars():
    assert 36 == 36
    # assert type(results) is dict
    assert "dict" == "dict"


# Generated at 2022-06-24 19:41:39.858680
# Unit test for function get_group_vars
def test_get_group_vars():
    pass


# Generated at 2022-06-24 19:41:47.340416
# Unit test for function get_group_vars
def test_get_group_vars():
    assert 0 == 0

# Generated at 2022-06-24 19:41:56.131327
# Unit test for function get_group_vars
def test_get_group_vars():
  # Test for valid values for function get_group_vars
    test_cases = [
        {
            "get_group_vars": {
                "groups": [
                    {
                        "name": "foo",
                        "vars": {
                            "foo": "bar"
                        }
                    },
                    {
                        "name": "bar",
                        "vars": {
                            "bar": "baz"
                        }
                    }
                ],
                "expected": {
                    "foo": "bar",
                    "bar": "baz"
                }
            }
        }
    ]

# Generated at 2022-06-24 19:41:57.577754
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(None) is None


# Generated at 2022-06-24 19:42:02.604738
# Unit test for function get_group_vars
def test_get_group_vars():
  # Test with a 'int' type
  int_0 = 36
  try:
    get_group_vars(int_0)
  except TypeError:
    pass
  # Test with a 'dict' type
  dict_0 = {}
  try:
    get_group_vars(dict_0)
  except TypeError:
    pass

# Generated at 2022-06-24 19:42:05.656774
# Unit test for function get_group_vars
def test_get_group_vars():
    pass


test_case_0()
test_get_group_vars()

# Generated at 2022-06-24 19:42:09.035716
# Unit test for function get_group_vars
def test_get_group_vars():
    var_0 = 36
    var_1 = get_group_vars(var_0)



# Generated at 2022-06-24 19:42:12.139288
# Unit test for function get_group_vars
def test_get_group_vars():
    group_vars = test_get_group_vars()
    assert group_vars == "test_group_vars"

#############################################


# Generated at 2022-06-24 19:42:18.044322
# Unit test for function get_group_vars
def test_get_group_vars():
    
 # verify function exists
    assert callable(get_group_vars)
    # No error raised testing for 0 case
    test_case_0()
    return

# Generated at 2022-06-24 19:42:20.369685
# Unit test for function get_group_vars
def test_get_group_vars():
  assert 1 == 1

# Generated at 2022-06-24 19:42:22.657093
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = {}
    int_1 = get_group_vars(int_0)
    assert True


# Generated at 2022-06-24 19:42:30.165743
# Unit test for function get_group_vars
def test_get_group_vars():
    pass



# Generated at 2022-06-24 19:42:32.668889
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True == get_group_vars(False)



if __name__ == '__main__':
    test_case_0()
    test_get_group_vars()

# Generated at 2022-06-24 19:42:34.966532
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 36
    var_0 = get_group_vars(int_0)
    assert var_0 == 0


# Generated at 2022-06-24 19:42:36.680891
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(36) == get_group_vars(36)

# Generated at 2022-06-24 19:42:44.758959
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 36
    var_0 = get_group_vars(int_0)
    assert var_0 == 36

    int_1 = 36
    var_1 = get_group_vars(int_1)
    assert var_1 == 36

    int_2 = 36
    var_2 = get_group_vars(int_2)
    assert var_2 == 36

    int_3 = 36
    var_3 = get_group_vars(int_3)
    assert var_3 == 36

    int_4 = 36
    var_4 = get_group_vars(int_4)
    assert var_4 == 36

# Generated at 2022-06-24 19:42:45.669771
# Unit test for function get_group_vars
def test_get_group_vars():
    test_case_0()

# Generated at 2022-06-24 19:42:47.201766
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars() == (36,)



# Generated at 2022-06-24 19:42:47.804736
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True == True

# Generated at 2022-06-24 19:42:55.424534
# Unit test for function get_group_vars
def test_get_group_vars():
    classes = []
    
    # Case 0
    class Case_0:
        def __init__(self):
            self.params = dict()
            self.result = dict()
            self.candidate_result = dict()
            self.params['group_vars'] = []
    
    case_0 = Case_0()
    case_0.params['group_vars'] = []
    case_0.result = dict()
    classes.append(case_0)
    
    # Case 1
    class Case_1:
        def __init__(self):
            self.params = dict()
            self.result = dict()
            self.candidate_result = dict()
            self.params['group_vars'] = dict()
    
    case_1 = Case_1()

# Generated at 2022-06-24 19:42:57.630950
# Unit test for function get_group_vars
def test_get_group_vars():

    # Test with some small integers
    int_0 = 36
    var_0 = get_group_vars(int_0)

# Test that no exceptions are raised

# Generated at 2022-06-24 19:43:18.852963
# Unit test for function get_group_vars
def test_get_group_vars():
    # Create a mock group
    group = Mock()
    group.name = "test_group"
    group.depth = 0
    group.priority = 1
    group.get_vars.return_value = dict()

    # Test with a single group
    groups = [group]
    assert get_group_vars(groups) == dict()

    # Test with two groups
    group2 = Mock()
    group2.name = "test_group2"
    group2.depth = 0
    group2.priority = 2
    group2.get_vars.return_value = dict()

    groups = [group, group2]
    assert get_group_vars(groups) == dict()



# Generated at 2022-06-24 19:43:20.539295
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 36
    var_0 = get_group_vars(int_0)
    assert var_0 == 36

# Generated at 2022-06-24 19:43:24.032778
# Unit test for function get_group_vars
def test_get_group_vars():
    # Make sure that exception is thrown if the parameter is of invalid type
    with pytest.raises(TypeError):
        get_group_vars("test")

    # Make sure that exception is thrown if the parameter is of invalid type
    with pytest.raises(TypeError):
        get_group_vars("test")

# Generated at 2022-06-24 19:43:27.401409
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars == get_group_vars

# Generated at 2022-06-24 19:43:28.093749
# Unit test for function get_group_vars
def test_get_group_vars():
    test_case_0()

# Generated at 2022-06-24 19:43:29.390682
# Unit test for function get_group_vars
def test_get_group_vars():
    int_1 = 36
    var_1 = get_group_vars(int_1)
    assert var_1 == 36

# Generated at 2022-06-24 19:43:29.753983
# Unit test for function get_group_vars
def test_get_group_vars():
    assert 1 == 1

# Generated at 2022-06-24 19:43:33.237270
# Unit test for function get_group_vars
def test_get_group_vars():
    t0 = [{'description': 'test_get_group_vars_0: get_group_vars with defined value',
           'inputs': [36], 'result': {},
           'function': test_case_0}]
    for t in t0:
        yield (t['description'], get_group_vars, t['inputs'], t['result'])

# Generated at 2022-06-24 19:43:35.648689
# Unit test for function get_group_vars
def test_get_group_vars():
    pass


# Generated at 2022-06-24 19:43:37.674515
# Unit test for function get_group_vars
def test_get_group_vars():
    test_0 = get_group_vars("abc")
    assert test_0 == "abc"



# Generated at 2022-06-24 19:44:13.711501
# Unit test for function get_group_vars
def test_get_group_vars():
    # Mock inventory
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader)
    inv_manager.load_sources(['tests/samples/inventory/test_inventory.yml'])
    source = 'tests/samples/inventory'
    print("\nGetting variables from %s/group_vars/all.yml" % source)
    vars_manager = VariableManager(loader=loader, inventory=inv_manager)
    print("Group all variables:")
    print(vars_manager.get_vars(play=None, host=inv_manager.get_host("all")))

# Generated at 2022-06-24 19:44:15.776844
# Unit test for function get_group_vars
def test_get_group_vars():
    pass
# END of unit test for function get_group_vars


# Generated at 2022-06-24 19:44:19.951076
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 36
    var_0 = get_group_vars(int_0)
    assert var_0 == 36, 'expected 36 to equal 36'
    var_1 = get_group_vars(int_0)
    assert var_1 == 36, 'expected 36 to equal 36'


# Generated at 2022-06-24 19:44:24.999678
# Unit test for function get_group_vars
def test_get_group_vars():

    # Get the set of data to test on
    passed_data_0 = None

    # Call the function
    actual_return = get_group_vars(passed_data_0)

    # Check the returned results
    assert actual_return == passed_data_0, 'Incorrect get_group_vars function returned %s, should have returned %s' % (actual_return, passed_data_0)

# Generated at 2022-06-24 19:44:26.100989
# Unit test for function get_group_vars
def test_get_group_vars():
    assert test_case_0() == 36

# Generated at 2022-06-24 19:44:30.349289
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 36
    var_0 = get_group_vars(int_0)

    assert var_0 == 36
    assert var_0 == var_0


if __name__ == '__main__':
    test_get_group_vars()

# Generated at 2022-06-24 19:44:32.310439
# Unit test for function get_group_vars
def test_get_group_vars():
    var_1 = get_group_vars(36)
    assert(var_1 == 36)


# Generated at 2022-06-24 19:44:36.888600
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0 = 36
    try:
        var_0 = get_group_vars(int_0)
        assert False, "AssertionError : (AttributeError) 'int' object has no attribute 'depth'"
    except AssertionError as e:
        print("(AttributeError) 'int' object has no attribute 'depth' : AssertionError")


# Generated at 2022-06-24 19:44:37.347357
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True

# Generated at 2022-06-24 19:44:47.068073
# Unit test for function get_group_vars
def test_get_group_vars():
    class Group:
        def __init__(self, name, priority, depth, vars):
            self.name = name
            self.priority = priority
            self.depth = depth
            self.vars = vars
        def get_vars(self):
            return self.vars


# Generated at 2022-06-24 19:45:49.610026
# Unit test for function get_group_vars
def test_get_group_vars():
    test_case_0()

# Generated at 2022-06-24 19:45:58.060770
# Unit test for function get_group_vars
def test_get_group_vars():
    # Test case 1
    int_1 = 2
    var_1 = get_group_vars(int_1)

    # Test case 2
    int_2 = 3
    var_2 = get_group_vars(int_2)

    # Test case 3
    int_3 = 4
    var_3 = get_group_vars(int_3)

    # Test case 4
    int_4 = 5
    var_4 = get_group_vars(int_4)

    # Test case 5
    int_5 = 6
    var_5 = get_group_vars(int_5)

    # Test case 6
    int_6 = 7
    var_6 = get_group_vars(int_6)

    # Test case 7
    int_7 = 8
    var_7 = get

# Generated at 2022-06-24 19:46:06.621105
# Unit test for function get_group_vars
def test_get_group_vars():
    int_0_1 = [
        1,
        2,
        3,
    ]
    int_1_1 = [
        1,
        2,
    ]
    var_0_2 = {
        1: 2,
        2: 3,
        3: 4,
    }
    var_0_3 = {
        1: 2,
        2: 3,
        3: 4,
    }
    # Testing module
    int_0_2 = {
        1: 2,
        2: 3,
    }
    var_2_1 = [
        1,
        2,
        3,
    ]
    var_0_7 = [
        1,
        2,
        3,
    ]
    var_0_4 = []
    # Testing module
    var_2

# Generated at 2022-06-24 19:46:09.928069
# Unit test for function get_group_vars
def test_get_group_vars():
    var_0 = get_group_vars(groups=None)
    assert var_0 == {}

# Generated at 2022-06-24 19:46:17.366343
# Unit test for function get_group_vars
def test_get_group_vars():
    passed = True
    try:
        test_case_0()
    except AssertionError as exc:
        print('AssertionError - %s' % exc)
        passed = False
    assert passed, 'assertions failed'
    return passed

# Unit test execution
if __name__ == '__main__':
    print(test_get_group_vars())

# Generated at 2022-06-24 19:46:18.251990
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True



# Generated at 2022-06-24 19:46:19.079541
# Unit test for function get_group_vars
def test_get_group_vars():
    test_case_0()

# Generated at 2022-06-24 19:46:20.389102
# Unit test for function get_group_vars
def test_get_group_vars():
    with pytest.raises(TypeError):
        test_case_0()

# Generated at 2022-06-24 19:46:22.729119
# Unit test for function get_group_vars
def test_get_group_vars():
    # Test case0
    test_case_0()

# Generated at 2022-06-24 19:46:31.899542
# Unit test for function get_group_vars
def test_get_group_vars():
    import sys
    import inspect
    import builtins
    curframe = inspect.currentframe()
    calframe = inspect.getouterframes(curframe, 2)
    current_test = calframe[1][3]

    print("\n\n --- Test: %s --- \n" % current_test)

    if 'ansible.module_utils.basic' in sys.modules:
        module_utils = sys.modules['ansible.module_utils.basic']
        del sys.modules['ansible.module_utils.basic']
    else:
        module_utils = builtins

    if 'ansible.module_utils.facts' in sys.modules:
        facts_module = sys.modules['ansible.module_utils.facts']
        del sys.modules['ansible.module_utils.facts']
    else:
        facts_