

# Generated at 2022-06-24 19:38:27.410060
# Unit test for function get_group_vars
def test_get_group_vars():
    bool_0 = True
    var_0 = get_group_vars(bool_0)
    bool_0 = True
    var_1 = get_group_vars(bool_0)
    bool_0 = True
    var_0 = get_group_vars(bool_0)
    bool_0 = True
    var_1 = get_group_vars(bool_0)
    bool_0 = True
    var_0 = get_group_vars(bool_0)
    bool_0 = True
    var_1 = get_group_vars(bool_0)
    bool_0 = True
    var_0 = get_group_vars(bool_0)
    bool_0 = True
    var_1 = get_group_vars(bool_0)
    bool_0 = True


# Generated at 2022-06-24 19:38:28.521229
# Unit test for function get_group_vars
def test_get_group_vars():
    bool_0 = True
    var_0 = get_group_vars(bool_0)
    assert var_0 == {}

# Generated at 2022-06-24 19:38:34.323354
# Unit test for function get_group_vars
def test_get_group_vars():
    host = Host(groups=[
        Group(name='a', vars={'a': 1, 'b': 1}),
        Group(name='b', vars={'a': 2, 'c': 2}),
        Group(name='c', vars={'c': 3}),
    ])
    assert get_group_vars(host.get_groups()) == {
        'a': 1,
        'b': 1,
        'c': 2,
    }



# Generated at 2022-06-24 19:38:37.296949
# Unit test for function get_group_vars
def test_get_group_vars():
    assert(get_group_vars()) # FIXME: implement your test here


# Generated at 2022-06-24 19:38:40.294373
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(bool)

# Generated at 2022-06-24 19:38:44.745246
# Unit test for function get_group_vars
def test_get_group_vars():
    assert callable(get_group_vars)
    
# VCRpy test to get response from get_group_vars

# Generated at 2022-06-24 19:38:56.164047
# Unit test for function get_group_vars
def test_get_group_vars():
    # Declare class mock object 'Group',
    # it's instance object is passed to function get_group_vars as param groups.
    class mock_Group():
        # Declare class mock object 'depth',
        # it's instance object has attribute 'depth' to replace
        # the real object 'ansible.inventory.group.Group.depth'
        class mock_depth:
            def __init__(self):
                self.depth = 1
        # Declare class mock object 'priority',
        # it's instance object has attribute 'priority' to replace
        # the real object 'ansible.inventory.group.Group.priority'
        class mock_priority:
            def __init__(self):
                self.priority = 1
        # Declare class mock object 'name',
        # it's instance object has attribute 'name' to replace
        # the

# Generated at 2022-06-24 19:39:04.621022
# Unit test for function get_group_vars
def test_get_group_vars():
    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext

    group_0 = AnsibleError(msg="foo 0")
    group_0 = get_group_vars(group_0)

    group_1 = PlayContext()
    group_1 = get_group_vars(group_1)

    group_2 = {'foo': 'bar 2'}
    group_2 = get_group_vars(group_2)

    group_3 = {'foo': 'bar 3'}
    group_3 = get_group_vars(group_3)

    group_4 = {'foo': 'bar 4'}
    group_4 = get_group_vars(group_4)

    group_5 = {'foo': 'bar 5'}
    group_5

# Generated at 2022-06-24 19:39:14.211091
# Unit test for function get_group_vars
def test_get_group_vars():
    bool_0 = False
    str_0 = "iZ2zeW8DB1A"
    str_1 = "["
    str_2 = "]"
    str_3 = "reg"
    str_4 = "ex"
    str_5 = "i"
    str_6 = "t:"
    str_7 = "."
    str_8 = "enable"
    str_9 = ":2"
    str_10 = "Z2zeW8"
    str_11 = "4"
    str_12 = "8"
    str_13 = "0"
    str_14 = "DB1A"
    str_15 = ":"
    str_16 = "."
    str_17 = "terminal"
    str_18 = "monitor"
    str_19 = "enable"
   

# Generated at 2022-06-24 19:39:18.621684
# Unit test for function get_group_vars
def test_get_group_vars():
    bool_0 = True
    var_0 = get_group_vars(bool_0)

    assert var_0 is True

# Generated at 2022-06-24 19:39:24.041363
# Unit test for function get_group_vars
def test_get_group_vars():
    print("test")
    assert True is not False, 'AssertionError raised'
    assert isinstance(var_0, dict), 'Number of arguments: 1. Argument 0: {0}'.format(bool_0)
    assert False is not True, 'AssertionError raised'
    assert 3 == 3, 'AssertionError raised'

# Generated at 2022-06-24 19:39:25.638217
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True


# Generated at 2022-06-24 19:39:27.451711
# Unit test for function get_group_vars
def test_get_group_vars():
    bool_0 = ...  # Provide your input here.
    var_0 = get_group_vars(bool_0)

# Generated at 2022-06-24 19:39:30.467610
# Unit test for function get_group_vars
def test_get_group_vars():
    """Test for function get_group_vars.
    """

    assert callable(get_group_vars)

# Generated at 2022-06-24 19:39:34.196284
# Unit test for function get_group_vars
def test_get_group_vars():
    assert_result = {'lte_service_availability' : False, 'lte_network_mode' : 'LTE/UMTS/GSM', 'lte_service_status' : False, 'lte_registration_status' : 'Not registered'}
    #assert test_case_0() == assert_result
    assert True == True

# Generated at 2022-06-24 19:39:35.155836
# Unit test for function get_group_vars
def test_get_group_vars():
    assert callable(get_group_vars)

# Generated at 2022-06-24 19:39:39.145768
# Unit test for function get_group_vars
def test_get_group_vars():
    var = dict(a=1, b=2, c=3) 
    print(var)


if __name__ == "__main__":
    test_case_0()
    test_get_group_vars()

# Generated at 2022-06-24 19:39:41.283337
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True == True
# unit tests end here

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 19:39:41.903580
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True == True



# Generated at 2022-06-24 19:39:43.833219
# Unit test for function get_group_vars
def test_get_group_vars():
    args = []
    if __name__ == '__main__':
        for arg in args:
            get_group_vars(arg)
            
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-24 19:39:45.935100
# Unit test for function get_group_vars
def test_get_group_vars():
    # Unit test for function get_group_vars
    assert True


# Generated at 2022-06-24 19:39:46.613686
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars('groups') == 'dictionary'

# Generated at 2022-06-24 19:39:48.250216
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(bool) == {}
    assert get_group_vars(float) == {}



# Generated at 2022-06-24 19:39:55.322380
# Unit test for function get_group_vars

# Generated at 2022-06-24 19:40:00.097193
# Unit test for function get_group_vars
def test_get_group_vars():
    x = '''
    var_0 = 1
    x = get_group_vars(var_0)
    assert x == 0
    '''
    print(x)



# Generated at 2022-06-24 19:40:03.605697
# Unit test for function get_group_vars
def test_get_group_vars():
    assert test_case_0() is None

# Generated at 2022-06-24 19:40:04.286464
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True


# Generated at 2022-06-24 19:40:11.100776
# Unit test for function get_group_vars
def test_get_group_vars():
    test_0 = {'value': 0,
              'name': 'test_0',
              'kwargs': {'bool_0': True},
              'expected': 0}
    
    test_1 = {'value': 1,
              'name': 'test_1',
              'kwargs': {},
              'expected': 1}
    
    tests = [test_0, test_1]

    for test in tests:
        value = test['value']
        expected = test['expected']
        result = get_group_vars(value)
        assert result == expected, "Expected " + str(expected) + ", but got: " + str(result)
    
    

# Generated at 2022-06-24 19:40:12.208679
# Unit test for function get_group_vars
def test_get_group_vars():
    assert callable(get_group_vars)


# Generated at 2022-06-24 19:40:16.552741
# Unit test for function get_group_vars
def test_get_group_vars():
    print('Test get_group_vars()')
    test_case_0()


if __name__ == '__main__':
    test_get_group_vars()

# Generated at 2022-06-24 19:40:19.732035
# Unit test for function get_group_vars
def test_get_group_vars():
    pass

# Generated at 2022-06-24 19:40:20.197652
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True == True

# Generated at 2022-06-24 19:40:25.000948
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True
    assert True
    assert False


# Unit test function get_group_vars

# Generated at 2022-06-24 19:40:26.893217
# Unit test for function get_group_vars
def test_get_group_vars():

    assert True == True

# Generated at 2022-06-24 19:40:27.280706
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True



# Generated at 2022-06-24 19:40:29.691221
# Unit test for function get_group_vars
def test_get_group_vars():
    output = get_group_vars(var_0)
    assert isinstance(output, dict)

# Generated at 2022-06-24 19:40:31.577593
# Unit test for function get_group_vars
def test_get_group_vars():
    var_0 = True
    var_1 = get_group_vars(var_0)
    assert var_1 == None

# Generated at 2022-06-24 19:40:33.152386
# Unit test for function get_group_vars
def test_get_group_vars():
    """
    Unit test for function get_group_vars
    """
    pass

# Generated at 2022-06-24 19:40:34.216538
# Unit test for function get_group_vars
def test_get_group_vars():
    assert callable(get_group_vars), \
        'Function "get_group_vars" is not callable'


# Generated at 2022-06-24 19:40:41.488582
# Unit test for function get_group_vars
def test_get_group_vars():
    host1 = dict(name = 'host1', ansible_host = 'host1.example.com', ansible_user = 'user1')
    host2 = dict(name = 'host2', ansible_host = 'host2.example.com', ansible_user = 'user2')
    host3 = dict(name = 'host3', ansible_host = 'host3.example.com', ansible_user = 'user3')
    host4 = dict(name = 'host4', ansible_host = 'host4.example.com', ansible_user = 'user4')
    host5 = dict(name = 'host5', ansible_host = 'host5.example.com', ansible_user = 'user5')

# Generated at 2022-06-24 19:40:46.010752
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(bool_0) == bool_0

# Generated at 2022-06-24 19:40:47.337179
# Unit test for function get_group_vars
def test_get_group_vars():
    var_0 = get_group_vars(0)
    assert True

# Generated at 2022-06-24 19:40:49.817268
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True == True

# Generated at 2022-06-24 19:40:53.411444
# Unit test for function get_group_vars
def test_get_group_vars():
    var_5 = {'vpc_id': 'vpc-XXXXXXXX', 'ec2_region': 'us-east-1', 'ec2_url': 'https://ec2.us-east-1.amazonaws.com', 'instance_type': 't2.micro', 'ec2_key_pair': 'XXXXXXXXXXX', 'ec2_security_groups': '["XXXXXX"]'}
    bool_1 = get_group_vars(var_5)
    assert True == bool_1


# Generated at 2022-06-24 19:40:54.237961
# Unit test for function get_group_vars
def test_get_group_vars():
    pass

# Generated at 2022-06-24 19:41:01.307056
# Unit test for function get_group_vars
def test_get_group_vars():
    assert_equal(get_group_vars(False), False)
    assert_equal(get_group_vars(True), True)
    assert_equal(get_group_vars('string'), 'string')
    assert_equal(get_group_vars(None), None)
    assert_equal(get_group_vars([]), [])
    assert_equal(get_group_vars(()), ())
    assert_equal(get_group_vars({}), {})
    assert_equal(get_group_vars(set()), set())
    assert_equal(get_group_vars(0), 0)
    assert_equal(get_group_vars(1), 1)



# Generated at 2022-06-24 19:41:09.217950
# Unit test for function get_group_vars
def test_get_group_vars():
    a = 'a'
    b = 'b'
    c = 'c'
    d = 'd'

    var_0 = False
    var_0 = get_group_vars(var_0)
    var_1 = True
    var_1 = get_group_vars(var_1)
    var_2 = 1
    var_2 = get_group_vars(var_2)
    var_3 = "a"
    var_3 = get_group_vars(var_3)

    var_4 = ['a']
    var_4 = get_group_vars(var_4)
    var_5 = ['a', 1]
    var_5 = get_group_vars(var_5)
    var_6 = ['a', 1, "b"]

# Generated at 2022-06-24 19:41:16.482232
# Unit test for function get_group_vars
def test_get_group_vars():
    # FIXME: The following testcases have been commented out due to the changes in the refactored ansible.utils.vars module.
    # Test case #0
    '''
    Test case #0

    Test scenario:

    When passing a bool
    '''
    test_case_0()

    # Test case #1
    '''
    Test case #1

    Test scenario:

    When passing a list of groups
    '''
    test_case_1()



# Generated at 2022-06-24 19:41:24.852359
# Unit test for function get_group_vars
def test_get_group_vars():
    host_0 = {"name": "host_0", "address": "192.168.1.1", "groups": []}
    host_1 = {"name": "host_1", "address": "192.168.1.2", "groups": []}
    host_2 = {"name": "host_2", "address": "192.168.1.3", "groups": []}
    group_0 = {"name": "group_0", "hosts": [host_0, host_1], "groups": []}
    group_1 = {"name": "group_1", "hosts": [host_2], "groups": []}
    group_2 = {"name": "group_2", "hosts": [host_0, host_1, host_2], "groups": []}


# Generated at 2022-06-24 19:41:25.382654
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True

# Generated at 2022-06-24 19:41:32.926162
# Unit test for function get_group_vars
def test_get_group_vars():
    val = True
    
    actual = get_group_vars(val)
    assert actual == True

# Generated at 2022-06-24 19:41:38.313949
# Unit test for function get_group_vars
def test_get_group_vars():

    # Set up mock
    ansible = AnsibleModule()
    ansible.params = {'groups': {'var': 'value'}}

    # Set up expected result
    expected = {}

    # Execute
    result = get_group_vars(ansible.params)

    # Verify expected result
    assertEqual(result, expected)

# Generated at 2022-06-24 19:41:39.858532
# Unit test for function get_group_vars
def test_get_group_vars():
    # Test case #0
    test_case_0()


# Utility function 

# Generated at 2022-06-24 19:41:41.646415
# Unit test for function get_group_vars
def test_get_group_vars():
    # TODO: modify the testcase to get a non-null value
    assert func_0 == "hello"

# Generated at 2022-06-24 19:41:46.159279
# Unit test for function get_group_vars
def test_get_group_vars():
    # Initialize test object
    test_obj = {
        'bool_0': True,
        'var_0': get_group_vars(bool_0),
    }
    # Test call to function
    result = get_group_vars()
    # Verify expected result
    assert result == test_obj

# Generated at 2022-06-24 19:41:48.713102
# Unit test for function get_group_vars
def test_get_group_vars():
    assert callable(get_group_vars) == True


if __name__ == "__main__":
    test_case_0()
    test_get_group_vars()

# Generated at 2022-06-24 19:41:49.615141
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True == True # to reset the compiler error

# Generated at 2022-06-24 19:41:52.360254
# Unit test for function get_group_vars
def test_get_group_vars():
    var_0 = True
    func_ret_0 = get_group_vars(var_0)
    assert func_ret_0 == True

# Generated at 2022-06-24 19:42:03.830749
# Unit test for function get_group_vars
def test_get_group_vars():
    # Create the 'ansible.inventory.group.Group' instance
    group_0 = ansible.inventory.group.Group()

    # Create the 'ansible.inventory.group.Group' instance
    group_1 = ansible.inventory.group.Group()

    # Create the 'list' instance
    list_0 = [group_0, group_1]

    # Call function 'get_group_vars' with the required arguments
    # The return type of the function 'get_group_vars' is a dictionary.
    # Assert that the return value is of type 'dict'.
    assert isinstance(get_group_vars(list_0), dict)

    # Call function 'get_group_vars' with the default argument
    # The return type of the function 'get_group_vars' is a dictionary.
    # Ass

# Generated at 2022-06-24 19:42:04.997042
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars([]) == {}
    assert get_group_vars(['test']) == {}


# Generated at 2022-06-24 19:42:24.529392
# Unit test for function get_group_vars
def test_get_group_vars():
    # Get a test case description
    test_case = '0'
    test_case_0()
    if test_case == '0':
        print('PASSED: get_group_vars.')
    else:
        print('FAILED: get_group_vars.')

if __name__ == '__main__':
    test_get_group_vars()

# Generated at 2022-06-24 19:42:27.911251
# Unit test for function get_group_vars
def test_get_group_vars():
    # default function call
    # assert get_group_vars()

    # optional case
    test_case_0()



# Generated at 2022-06-24 19:42:28.796103
# Unit test for function get_group_vars
def test_get_group_vars():
    get_group_vars("")


# Generated at 2022-06-24 19:42:30.706729
# Unit test for function get_group_vars
def test_get_group_vars():
    assert callable(get_group_vars)
    assert isinstance(get_group_vars(bool_0), dict)

# Generated at 2022-06-24 19:42:32.926547
# Unit test for function get_group_vars
def test_get_group_vars():
    bool_0 = True
    var_0 = get_group_vars(bool_0)
    assert var_0 is not None



# Generated at 2022-06-24 19:42:43.410561
# Unit test for function get_group_vars

# Generated at 2022-06-24 19:42:45.177822
# Unit test for function get_group_vars
def test_get_group_vars():
    mock_bool_0 = True
    mock_var_0 = get_group_vars(mock_bool_0)
    
    assert not mock_var_0

# Generated at 2022-06-24 19:42:47.113370
# Unit test for function get_group_vars
def test_get_group_vars():
    bool_0 = True
    var_0 = get_group_vars(bool_0)

# Generated at 2022-06-24 19:42:48.438682
# Unit test for function get_group_vars
def test_get_group_vars():
    assert False


# Regression test for function get_group_vars

# Generated at 2022-06-24 19:42:53.607195
# Unit test for function get_group_vars
def test_get_group_vars():
    vars_1 = {'var_0': "bi'l'r", 'var_1': 6, 'var_2': '', 'var_3': True}
    var_2 = '6'
    var_2 = get_group_vars(vars_1)
    assert var_2 == {'var_0': "bi'l'r", 'var_1': 6, 'var_2': '', 'var_3': True}, 'Error: Did not get the expected output'


# Generated at 2022-06-24 19:43:07.286402
# Unit test for function get_group_vars
def test_get_group_vars():
    pass

# Generated at 2022-06-24 19:43:09.224817
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True

# Generated at 2022-06-24 19:43:10.080984
# Unit test for function get_group_vars
def test_get_group_vars():
    assert callable(get_group_vars)

# Generated at 2022-06-24 19:43:15.013281
# Unit test for function get_group_vars
def test_get_group_vars():
    var_0 = [{'name': 'group1', 'variables': {'foo': 2, 'bar': 3}}, {'name': 'group2', 'variables': {'foo': 1}},
             {'name': 'group3', 'variables': {'bar': 4}}]
    assert get_group_vars(var_0) == {'foo': 2, 'bar': 4}



# Generated at 2022-06-24 19:43:21.814208
# Unit test for function get_group_vars
def test_get_group_vars():
    groups = [{ 'name': 'ansible',
                'hosts': [ { 'name': 'localhost', 'vars': { 'ansible_connection': 'local' }}, 
                           { 'name': 'localhost' }]},
              { 'name': 'children',
                'children': [ { 'name': 'nested',
                                'hosts': [ { 'name': 'localhost', 'vars': { 'ansible_connection': 'ssh' }}, 
                                           { 'name': 'localhost' }]}]},
              { 'name': 'all',
                'hosts': [ { 'name': 'localhost' }],
                'children': [ { 'name': 'nested',
                                'hosts': [ { 'name': 'localhost' }]}]}]


# Generated at 2022-06-24 19:43:22.413429
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True

# Generated at 2022-06-24 19:43:28.964889
# Unit test for function get_group_vars
def test_get_group_vars():
    # Asserts that groups with lower depth come first, and that groups with the
    # same depth are sorted by priority and name.
    def _assert_group_order(self, groups, order):
        """
        Asserts that `groups` sorts to `order` when passed to get_group_vars.

        :arg groups: list of ansible.inventory.group.Group objects
        :arg order: list of ansible.inventory.group.Group names
        """
        self.assertEqual(
            [group.name for group in sort_groups(groups)],
            order,
        )

    ansible_options = {
        'hash_behaviour': 'merge'
    }
    # TODO: This is somewhat ugly, but mocking AnsibleModule has a lot of
    # boilerplate, and we don't necessarily expect this feature to

# Generated at 2022-06-24 19:43:30.618083
# Unit test for function get_group_vars
def test_get_group_vars():
    var_0 = dict({ u'var_0': u'value_0', u'var_2': u'value_2' })
    assert var_0 == get_group_vars(var_0)

# Generated at 2022-06-24 19:43:33.057051
# Unit test for function get_group_vars
def test_get_group_vars():
    tests = {
        'empty': {
            'from': '',
            'want': {}
        },
    }

    for test_name, test in tests.items():
        result = get_group_vars(test['from'])
        assert result == test['want'], \
            f"{test_name}: got '{result}' but want '{test['want']}'"

# Generated at 2022-06-24 19:43:36.371439
# Unit test for function get_group_vars
def test_get_group_vars():
    bool_0 = True
    var_0 = get_group_vars(bool_0)

# Generated at 2022-06-24 19:44:07.070925
# Unit test for function get_group_vars
def test_get_group_vars():
    try:
        assert(get_group_vars('bool'))
        print("get_group_vars test passed")
    except AssertionError as e:
        print("get_group_vars test FAILED")
        raise(e)



# Generated at 2022-06-24 19:44:09.068668
# Unit test for function get_group_vars
def test_get_group_vars():
    assert not False
    assert get_group_vars(True) == True



# Generated at 2022-06-24 19:44:10.679533
# Unit test for function get_group_vars
def test_get_group_vars():
    bool_0 = True
    var_0 = get_group_vars(bool_0)

# Generated at 2022-06-24 19:44:12.937737
# Unit test for function get_group_vars
def test_get_group_vars():

    # Invocation with dummy values for testing purpose
    bool_0 = True
    var_0 = get_group_vars(bool_0)



# Generated at 2022-06-24 19:44:17.754082
# Unit test for function get_group_vars
def test_get_group_vars():

    # Call get_group_vars with proper parameters
    assert True == False # FIXME: test doesn't use REs

    # Call get_group_vars with a different number of arguments
    # assert False == True
    # with pytest.raises(TypeError):
    #     get_group_vars()

# Generated at 2022-06-24 19:44:23.773569
# Unit test for function get_group_vars
def test_get_group_vars():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    source = "localhost"
    inventory = VariableManager(loader=None, sources=source)
    vars = VariableManager()
    host = Host(name="localhost", inventory=inventory, vars=vars)
    host.set_variable('hello', 'world')
    assert host.get_variable('hello') == 'world'



# Generated at 2022-06-24 19:44:25.593839
# Unit test for function get_group_vars
def test_get_group_vars():
    var_1 = False
    var_0 = get_group_vars(var_1)

# Generated at 2022-06-24 19:44:36.122747
# Unit test for function get_group_vars

# Generated at 2022-06-24 19:44:40.724757
# Unit test for function get_group_vars

# Generated at 2022-06-24 19:44:47.687998
# Unit test for function get_group_vars
def test_get_group_vars():
    bool_0 = False
    var_0 = get_group_vars(bool_0)
    bool_1 = False
    var_1 = get_group_vars(bool_1)
    bool_2 = False
    var_2 = get_group_vars(bool_2)
    bool_3 = False
    var_3 = get_group_vars(bool_3)
    bool_4 = True
    var_4 = get_group_vars(bool_4)
    bool_5 = True
    var_5 = get_group_vars(bool_5)
    bool_6 = True
    var_6 = get_group_vars(bool_6)
    bool_7 = True
    var_7 = get_group_vars(bool_7)
    bool_8 = True


# Generated at 2022-06-24 19:45:48.585295
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(None) == {}

# Test of using the test infrastructure

# Generated at 2022-06-24 19:45:52.889167
# Unit test for function get_group_vars
def test_get_group_vars():
    assert None == None, "Invalid data passed to get_group_vars"
    assert None == None, "Invalid data passed to get_group_vars"
    assert None == None, "Invalid data passed to get_group_vars"
    assert None == None, "Invalid data passed to get_group_vars"

# Generated at 2022-06-24 19:45:56.169972
# Unit test for function get_group_vars
def test_get_group_vars():
    assert callable(get_group_vars)
    assert str(type(get_group_vars(True))) == "<class 'builtin_function_or_method'>"
    assert str(type(get_group_vars(True))) == "<class 'builtin_function_or_method'>"

# Generated at 2022-06-24 19:45:57.920847
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(bool) is None

# Generated at 2022-06-24 19:46:00.997654
# Unit test for function get_group_vars
def test_get_group_vars():
    var_0 = None
    var_1 = None
    def func_0():
        var_0 = False
    with pytest.raises(Exception):
        result = get_group_vars(var_0)

# Generated at 2022-06-24 19:46:01.660914
# Unit test for function get_group_vars
def test_get_group_vars():
    assert True == True

# Generated at 2022-06-24 19:46:04.551628
# Unit test for function get_group_vars
def test_get_group_vars():
    print("in test_get_group_vars")
    test_case_0()



# Generated at 2022-06-24 19:46:05.145507
# Unit test for function get_group_vars
def test_get_group_vars():
    assert bool_0 == var_0

# Generated at 2022-06-24 19:46:06.860013
# Unit test for function get_group_vars
def test_get_group_vars():
    # Assign/run boolean for test case 0
    test_0_bool = True
    if test_0_bool:
        test_case_0()


# Execute unit tests
test_get_group_vars()

# Generated at 2022-06-24 19:46:12.624832
# Unit test for function get_group_vars
def test_get_group_vars():
    assert get_group_vars(bool()) == None
    assert get_group_vars(dict()) == None
    assert get_group_vars(int()) == None
    assert get_group_vars(float()) == None
    assert get_group_vars(list()) == None
    assert get_group_vars(set()) == None
    assert get_group_vars(str()) == None
    assert get_group_vars(tuple()) == None