

# Generated at 2022-06-24 11:10:52.197251
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String
    from typesystem.fields import Field
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        foo = String(required=True)
        bar = Integer(min_value=0)

    def test_assert_message_is_str(message: Message) -> typing.Any:
        assert isinstance(message, str)

    class TestField(Field):
        def __init__(self, *, min_value=None, max_value=None):
            super().__init__(validators=[])
            self.min_value = min_value
            self.max_value = max_value


# Generated at 2022-06-24 11:11:03.886093
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_str = """
    hello:
        world:
            test:
                abc: !abc 123
                xyz: !xyz 123
                !abc: 123
                !xyz: 123
            false: False
        list:
            - abc
            - def
            - ghi
        key: value
    another:
        list:
        test:
            abc: !abc 123
            xyz: !xyz 123
            !abc: 123
            !xyz: 123
        key: value
        - abc
        - def
        - ghi
    false: False
    """

# Generated at 2022-06-24 11:11:12.154836
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None
    content = """
a: Yes
b:
  c: Hello
  d: 123
"""
    token = tokenize_yaml(content)
    expected = DictToken({
        'a': ScalarToken('Yes', 0, 3, content),
        'b': DictToken({
            'c': ScalarToken('Hello', 10, 13, content),
            'd': ScalarToken('123', 21, 24, content)
        }, 7, 24, content),
    }, 0, 24, content)
    assert token == expected


# Generated at 2022-06-24 11:11:14.200820
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(b"name: ahi")
    assert token.keys() == ["name"]


# Generated at 2022-06-24 11:11:19.681978
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
---

a: 'foo'
b: [1, 2, 3]
c: true

"""
    token = tokenize_yaml(content)
    assert token.value == {"a": "foo", "b": [1, 2, 3], "c": True}



# Generated at 2022-06-24 11:11:28.788195
# Unit test for function validate_yaml
def test_validate_yaml():
    class AddressSchema(Schema):
        street = Field(type=str)
        city = Field(type=str)
        zip_code = Field(type=str)

    class Person(Schema):
        name = Field(type=str)
        address = Field(type=AddressSchema)

    yaml_string = """
    name: Bob
    address:
        street: 123 Main St.
        city: Morristown
        zip_code: 07960
    """
    result = validate_yaml(yaml_string, Person)
    assert result == ({'name': 'Bob', 'address': {'street': '123 Main St.', 'city': 'Morristown', 'zip_code': '07960'}}, None)

# Generated at 2022-06-24 11:11:33.580381
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = b"""
        a:
          b: B
          c:
            - 1
            - 2
            - 3
        d: D
    """
    token = tokenize_yaml(content)
    assert token == {
        "a": {
            "b": "B",  # ScalarTokens
            "c": [1, 2, 3],  # ListToken
        },
        "d": "D",
    }
    assert token.content == content.decode()
    assert token["a"].content == content.decode()
    assert token["a"]["b"].content == content.decode()
    assert token["a"]["c"].content == content.decode()
    assert token["a"]["c"][1].content == content.decode()

# Generated at 2022-06-24 11:11:45.394719
# Unit test for function tokenize_yaml

# Generated at 2022-06-24 11:11:54.426103
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer

    schema = {"foo": String()}
    value, errors = validate_yaml(
        content="""
        foo:
            - 1
    """,
        validator=schema,
    )
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 8
    assert errors[0].position.char_index == 19

    schema = {"foo": Integer()}
    value, errors = validate_yaml(
        content="""
        foo: bar
    """,
        validator=schema,
    )
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 8
    assert errors[0].position.char_index == 19

# Generated at 2022-06-24 11:12:04.213546
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test that validate_yaml works as expected.
    """
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class NameSchema(Schema):
        name = String()

    value, error_messages = validate_yaml(
        b"""
    name:
    """,
        NameSchema,
    )

    assert not value
    assert error_messages == [
        Message(
            code="missing_field",
            text="Missing required field: name.",
            path=["name"],
            position=Position(line_no=3, column_no=1, char_index=20),
        )
    ]

    value, error_messages = validate_yaml(
        b"""
    name: 
    """,
        NameSchema,
    )



# Generated at 2022-06-24 11:12:13.421816
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test for the function validate_yaml()
    """
    from typesystem.fields import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    # Valid case
    value, error_messages = validate_yaml(
        """name: Tom
        age: 20
        """,
        Person,
    )
    assert value == {"name": "Tom", "age": 20}
    assert error_messages == []

    # Invalid case
    value, error_messages = validate_yaml(
        """name: Tom
        age: "20"
        """,
        Person,
    )
    assert value == {"name": "Tom", "age": "20"}
    assert len(error_messages) == 1

# Generated at 2022-06-24 11:12:17.102628
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "size: small"
    validator = Field(name="size", type="string", max_length=5)
    value, error_messages = validate_yaml(content, validator)
    assert value == "small"
    assert error_messages == []


# Generated at 2022-06-24 11:12:20.593282
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('{"name":"Milton"}')
    assert str(token) == 'DictToken, start=0, end=14'
    assert str(token.data) == "{'name': 'Milton'}"


# Generated at 2022-06-24 11:12:30.569041
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import yaml
    test_data = """
        - test
        - test1
        - "test 2"
        - test3
    """
    token_obj = tokenize_yaml(test_data)
    assert isinstance(token_obj, ListToken)
    assert token_obj.start == 0
    assert token_obj.end == len(test_data) - 1
    value = token_obj.value
    assert len(value) == 4
    assert value[0].value == "test"
    assert value[1].value == "test1"
    assert value[2].value == "test 2"
    assert value[3].value == "test3"
    assert value[0].content == test_data
    assert value[1].content == test_data
    assert value[2].content == test_data

# Generated at 2022-06-24 11:12:38.899662
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
hello: world
an_int: 3
a_float: 3.14
true_bool: True
false_bool: False
null_value: null
an_array:
- 1
- 2.0
- 3.14
'''
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.content == content
    assert token.start_index == 0
    assert token.end_index == len(content) - 1
    assert token.position == Position(line_no=1, column_no=1, char_index=0)
    assert token.end_position == Position(line_no=12, column_no=4, char_index=len(content) - 1)
    assert token["hello"].content == content

# Generated at 2022-06-24 11:12:46.282808
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
  # Load YAML
  yaml_content = """
  # Comment
  - "foo"
  - "bar"
  - "bat"
  """
  token = tokenize_yaml(yaml_content)
  assert type(token) == ListToken
  assert len(token.value) == 3

  # Load a yaml string with a quote mark inside a string
  yaml_content = """
  - 'foo''s bar'
  """
  token = tokenize_yaml(yaml_content)
  assert type(token) == ListToken
  assert len(token.value) == 1
  assert type(token.value[0]) == ScalarToken
  assert token.value[0].value == "foo's bar"

# Generated at 2022-06-24 11:12:54.416985
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from hypothesis import given, example
    from .strategies import yaml_content

    yaml_content = given(yaml_content())
    @yaml_content
    @example("---")
    @example("---\n")
    @example("---\n---")
    def test_tokenize_yaml(content):
        try:
            tokenize_yaml(content)
            #print("TOKENIZE_YAML CONTENT: " + str(content))
        except ParseError:
            pass
    test_tokenize_yaml()


# Generated at 2022-06-24 11:12:56.591952
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('a: 1')== {'a': 1}
    assert tokenize_yaml('a: x') == {'a': 'x'}


# Generated at 2022-06-24 11:13:06.501582
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        description="A description.",
        fields={
            "sample": "string",
            "sample_integer": "integer",
            "sample_number": "number",
            "sample_boolean": "boolean",
            "sample_object": {"fields": {"a": "string", "b": "string"}},
            "sample_array": {"items": "string"},
        },
    )

    content = (
        "sample: Hello\n"
        "sample_integer: 42\n"
        "sample_number: 4.2\n"
        "sample_boolean: false\n"
        "sample_object:\n"
        "  a: Hello\n"
        "  b: World\n"
        "sample_array: [Hello, World]"
    )

    validator = schema

# Generated at 2022-06-24 11:13:18.232341
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('[1,2,3]', List(Integer)) == ([1,2,3], [])
    assert validate_yaml('{"k1":1,"k2":2}', Dict({"k1":Integer, "k2":Integer})) == ({'k1':1,'k2':2}, [])
    assert validate_yaml('[1,2,3]', List(Integer, min_length=5)) == ([1,2,3], [])
    assert validate_yaml('', List(Integer)) == ([], [])
    assert validate_yaml('[1,b,3]', List(Integer)) == ([1,None,3], [])

# Generated at 2022-06-24 11:13:24.387173
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = "string"
        age = "integer"

    try:
        valid, errors = validate_yaml(content=b"""
            name: "A. N. Other"
            age: 32
        """, validator=Person)
    except ImportError:
        raise unittest.SkipTest("'pyyaml' must be installed.")

    assert valid == {
        "name": "A. N. Other",
        "age": 32,
    }

    assert errors == []



# Generated at 2022-06-24 11:13:33.729101
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        content='{"my_field": "my_value"}',
        validator=Schema({"my_field": Field()}),
    ) == (
        {'my_field': 'my_value'}, []
    )

    assert validate_yaml(
        content="1",
        validator=Schema({"my_field": Field()}),
    ) == (
        None, [
            Message(
                text="Expected a dictionary.",
                code="invalid_type",
                position=Position(line_no=1, column_no=1, char_index=0),
            )
        ]
    )


# Generated at 2022-06-24 11:13:43.104575
# Unit test for function validate_yaml
def test_validate_yaml():
    with open('typesystem/test_parse_exc.yml', 'r') as file:
        content = file.read()
    with open('typesystem/test_parse_exc.yml', 'rb') as file:
        content_bytes = file.read()
    with open('typesystem/test_valid_exc.yml', 'r') as file:
        content_valid = file.read()
    with open('typesystem/raw_json_schema/schema_2_valid.json', 'r') as file:
        schema = file.read()
    with open('typesystem/raw_json_schema/schema_2_invalid.json', 'r') as file:
        schema_invalid = file.read()

# Generated at 2022-06-24 11:13:49.548313
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        validators=[Validator(lambda val: val is not None), Validator(lambda val: len(str(val)))],
        required=True,
    )
    validate_yaml.__annotations__["content"] = str
    validate_yaml.__annotations__["validator"] = type(schema)



# Generated at 2022-06-24 11:13:57.794777
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        date: '2018-06-05'
        description: This is a description
        done: True
        id: 1
        rank: 0.001
        title: A title
    """
    message = """
        date: '2018-06-05'
        description: This is a description
        done: True
        id: 1
        rank: 0.001
        title: A title
    """
    validator = Message(
        {
            "date": Date(),
            "description": String(max_length=100),
            "done": Boolean(),
            "id": Integer(minimum=0),
            "rank": Float(minimum=0, maximum=1),
            "title": String(max_length=100),
        }
    )
    todo, errors = validate_yaml(content, validator)


# Generated at 2022-06-24 11:14:01.953922
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema
    from typesystem.tokenize import validate_yaml

    class PlanetSchema(Schema):
        name = String()
        moons = Integer()

    schema = PlanetSchema()
    schema.validate_yaml('{name: "Jupiter", moons: 69}')

# Generated at 2022-06-24 11:14:06.881224
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String()

    value, error_messages = validate_yaml(content='name: My Name', validator=TestSchema)
    assert len(error_messages) == 0
    assert value["name"] == "My Name"



# Generated at 2022-06-24 11:14:18.758334
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Ensure we can validate against a schema
    """
    from typesystem import Schema, fields

    class BasicSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer()

    yaml_string = "name: yaml_user\nage: 99\n"
    value, errors = validate_yaml(yaml_string, BasicSchema())
    assert value == {'name': 'yaml_user', 'age': 99}
    assert 'not a valid integer' in errors[0].text
    assert errors[0].position.line_no is 3
    assert errors[0].position.column_no is 1

    yaml_string = "name: yaml_user\nage: 99\n"

# Generated at 2022-06-24 11:14:24.311718
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"data: {a: 'a', b: 'b'}"
    string_token = validate_yaml(content, Field(validators=[validators.max_length(3)]))
    assert type(string_token) == ScalarToken
    assert string_token.start == 19
    assert string_token.end == 20
    assert string_token.content == "b"
    assert string_token.value == "b"



# Generated at 2022-06-24 11:14:34.054891
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # true
    assert tokenize_yaml('"foo"') == ScalarToken("foo", 0, 5, content='"foo"')
    # false
    assert tokenize_yaml('"foo"') != ScalarToken("bar", 0, 5, content='"foo"')

    # true
    assert tokenize_yaml("[1, 2, 3]") == ListToken([1, 2, 3], 0, 9, content="[1, 2, 3]")
    # false
    assert tokenize_yaml("[1, 2, 3]") != ListToken([1, 2, 3, 4], 0, 9, content="[1, 2, 3]")

    # true

# Generated at 2022-06-24 11:14:36.842960
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "a: 5"
    field = Field(type="integer")
    value, errors = validate_yaml(content=content, validator=field)
    assert errors == []


# Generated at 2022-06-24 11:14:44.113234
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    123
    """
    validator = Field(name="f1", type="integer")
    msg = validate_yaml(content,validator)
    print(msg)
    content = """
    "abc"
    """
    validator = Field(name="f1", type="string")
    msg = validate_yaml(content,validator)
    print(msg)
    content = """
    123: 456
    """
    validator = Field(name="f1", type="dict")
    msg = validate_yaml(content,validator)
    print(msg)
    content = """
    ---
    - 1
    - 2
    - 3
    """
    validator = Field(name="f1", type="list")
    msg = validate_yaml(content,validator)


# Generated at 2022-06-24 11:14:53.785335
# Unit test for function tokenize_yaml

# Generated at 2022-06-24 11:15:05.456314
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("""
        name: foo
        age: 42
    """) == DictToken(
        dict(name="foo", age=42), start=6, end=24, content="\n        name: foo\n        age: 42\n    ",
    )

    assert tokenize_yaml("""
        - foo
        - 42
    """) == ListToken(
        ["foo", 42], start=6, end=20, content="\n        - foo\n        - 42\n    ",
    )

    assert tokenize_yaml("""
        foo
    """) == ScalarToken("foo", start=6, end=9, content="\n        foo\n    ")


# Generated at 2022-06-24 11:15:15.891762
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem.errors import ErrorMessage
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        title = String(required=True)
        age = Integer()

    content = b"""
        title: Hello
        age: world
    """

    result = validate_yaml(content, validator=MySchema)

    assert isinstance(result[0], Token)
    assert len(result[1]) == 1
    assert isinstance(result[1][0], ErrorMessage)

    assert result[1][0].field_name == "age"
    assert result[1][0].message == "Invalid value."
    assert result[1][0].code == "invalid_value"

# Generated at 2022-06-24 11:15:22.117360
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token1 = tokenize_yaml("""
        - a
        - b
    """)
    assert isinstance(token1, ListToken)
    assert token1.value == ["a", "b"]

    token2 = tokenize_yaml("""
        a: 1
        b: 2
    """)
    assert isinstance(token2, DictToken)
    assert token2.value == {"a": 1, "b": 2}



# Generated at 2022-06-24 11:15:26.643570
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '{ "test": [1,2,3], "test2": "test"}'
    token = tokenize_yaml(content)
    assert token.value[0].value == "test"
    assert token.value[1].value[0].value == 1

# Generated at 2022-06-24 11:15:36.088779
# Unit test for function validate_yaml
def test_validate_yaml():
    import os
    import pytest
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String, Float, Boolean

    class Person(Schema):
        name = String()
        age = Integer(nullable=True)
        height = Float(nullable=True)
        worker = Boolean(nullable=True)

    yaml_text_1 = """{
    name: Diego
    age: 28
    height: 175.5
    worker: true
}
"""
    yaml_text_2 = """
name: Pedro
age: 32
"""

    yaml_text_3 = """
    name: {
        first_name: Mery
        second_name: Flores
    }
    age: 19
    height: 1.55
    worker: true
"""

    yaml_text_4

# Generated at 2022-06-24 11:15:44.081581
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    yaml_string = '''
    - label: "a"
      type: integer
      value: 1
    - label: "b"
      type: string
      value: two
    '''

    class TestSchema(Schema):
        a = Integer()
        b = String()

    schema = TestSchema()
    value, error_messages = validate_yaml(yaml_string, schema)
    print(value)
    print(error_messages)

# Generated at 2022-06-24 11:15:47.271536
# Unit test for function validate_yaml
def test_validate_yaml():
    token = tokenize_yaml('{"a": "value"}')
    print(validate_yaml(token, Schema))
    print(token)
    

if __name__ == "__main__":
    test_validate_yaml()

# Generated at 2022-06-24 11:15:55.201090
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == {}, "Empty dict not parsed"
    assert tokenize_yaml("[]") == [], "Empty list not parsed"
    assert tokenize_yaml("{\"foo\": [1,2,3]}") == {"foo": [1, 2, 3]}, "Dict not parsed"
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3], "List not parsed"
    assert tokenize_yaml("foo") == "foo", "String not parsed"
    assert tokenize_yaml("1") == 1, "Int not parsed"
    assert tokenize_yaml("1.12") == 1.12, "Float not parsed"
    assert tokenize_yaml("true") == True, "Bool not parsed"
    assert tokenize_yaml

# Generated at 2022-06-24 11:16:06.436131
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Check that the function tokenize_yaml works correctly
    """

    assert tokenize_yaml("abc") == "abc"
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("null") is None
    assert tokenize_yaml("true") is True
    assert tokenize_yaml("false") is False
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_yaml("{a: 1, b: 2}") == {"a": 1, "b": 2}
    assert tokenize_yaml("{a: 1, b: 2}") == {"a": 1, "b": 2}

# Generated at 2022-06-24 11:16:09.275341
# Unit test for function validate_yaml
def test_validate_yaml():
    content='"hello"'
    validator="str"
    validate_yaml(content,validator)
    assert 1==1


# Generated at 2022-06-24 11:16:15.783445
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"some_int": int})

    value, errors = validate_yaml(
        content="", validator=schema,
    )
    assert value == {"some_int": None}
    assert [str(err) for err in errors] == ["No content.", "This field is required."]

    value, errors = validate_yaml(
        content="some_int: 1", validator=schema,
    )
    assert value == {"some_int": 1}
    assert errors == []



# Generated at 2022-06-24 11:16:24.770772
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem import schema

    # Basic validation of a scalar value.
    value, messages = validate_yaml("true", validator=schema.Boolean())
    assert value is True
    assert messages == []

    # Basic validation of a dictionary.
    value, messages = validate_yaml(
        """\
name: John
age: 30
""",
        validator=schema.Schema({"name": schema.String(), "age": schema.Integer()}),
    )
    assert value == {"name": "John", "age": 30}
    assert messages == []

    # Basic validation of a list.

# Generated at 2022-06-24 11:16:33.654320
# Unit test for function validate_yaml
def test_validate_yaml():
    fields = [
        Field(type="string", required=True),
        Field(type="integer", required=True),
    ]

    class TestSchema(Schema):
        fields = fields

    token = tokenize_yaml("{")
    value, error_messages = validate_yaml(content="{}", validator=fields)
    assert not error_messages
    assert value == {"_start": 0, "0": "", "_end": 0}

    value, error_messages = validate_yaml(content="", validator=fields)
    assert len(error_messages) == 1
    assert error_messages[0].text == "No content."

    token = tokenize_yaml("foo")
    value, error_messages = validate_yaml(content="foo", validator=fields)

# Generated at 2022-06-24 11:16:41.731694
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema([
        "name",
        "age",
        "address",
        "hobbies",
        "is_happy",
        "dob"
    ])
    value, error_msgs = validate_yaml("""
name: mehul agarwal
age: 20
address:
    city: kolkata
    State: West bengal
    country: India
hobbies:
    - football
    - cricket
is_happy: true
dob: 1996-08-13
    """, schema)

    assert len(error_msgs) == 0

# Generated at 2022-06-24 11:16:48.660376
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "{'name': 'John', 'age': 42}"
    validator = Field(label="Test", field_type="string")
    _, errors = validate_yaml(content, validator)
    expected_error = {
        "code": "parse_error",
        "message": "mapping values are not allowed here.",
        "params": {
            "content": "{'name': 'John', 'age': 42}",
            "start": 0,
            "end": 31,
            "column": 1,
            "line": 1,
            "scalar": "Test",
            "pointer": "",
        },
    }

    assert errors[0] == expected_error

# Generated at 2022-06-24 11:16:52.207590
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    expected = DictToken({"a": "b"}, start=0, end=6, content="a: b")
    observed = tokenize_yaml("a: b")
    assert observed == expected



# Generated at 2022-06-24 11:17:02.416562
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(name="person", type_name="object", fields=[
        Field(name="name", type_name="string"),
        Field(name="age", type_name="integer"),
        Field(name="favorite_colors", 
            type_name="array",
            items=Field(type_name="string")
        )
    ])
    value = {
        "name": "John",
        "age": "42",
        "favorite_colors": [
            "blue",
            "red",
            "green"
        ]
    }
    content = """
person:
  name: John
  age: 42
  favorite_colors: 
    - blue
    - red
    - green
    """
    assert validate_yaml(content, validator) == (value, None)


# Generated at 2022-06-24 11:17:05.300002
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"\nhello: hello\n"
    token = tokenize_yaml(content)
    value, errors = validate_with_positions(token, Schema({"hello": str}))
    assert value == {"hello": "hello"}
    assert not errors

# Generated at 2022-06-24 11:17:06.569490
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None


# Generated at 2022-06-24 11:17:16.462005
# Unit test for function validate_yaml
def test_validate_yaml():
    """Testing validate_yaml function"""
    from typesystem.base import String, Schema
    from typesystem.fields import Fields

    YAML_STRING = """
    hello: world
    number: 42
    bool: true
    none: null
    list:
        - hello
        - world
    """

    class TestSchema(Schema):
        class Meta:
            fields = Fields(
                {"hello": String(), "number": String(), "bool": String(), "none": String()}
            )

    schema = TestSchema()

    value, error_messages = validate_yaml(YAML_STRING, schema)

# Generated at 2022-06-24 11:17:23.808281
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: 1
    b:
      c: 3
    """
    token = tokenize_yaml(content)
    assert token == DictToken(
        {"a": 1, "b": DictToken({"c": 3}, 6, 19, content=content)}, 0, 18, content=content
    )

    content = """
    - 1
    - 2
    - 3
    """

    token = tokenize_yaml(content)
    assert token == ListToken(
        [1, 2, 3], 0, 11, content=content
    )
    

# Generated at 2022-06-24 11:17:35.192647
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(min_length=3, max_length=100)
        age = Integer(minimum=0)

    # Test a parse error.
    try:
        validate_yaml("Name: Brian\nAge: ", Person)
    except ParseError as exc:
        assert exc.text == "expected a plain value."
        assert exc.code == "parse_error"
        assert exc.position == Position(
            column_no=10, line_no=2, char_index=10
        )
    else:
        assert False, "Did not raise ParseError."

    # Test a validation error.
    value, errors = validate_yaml("Name: Brian\nAge: x", Person)
    assert value is None
    assert len(errors) == 1

# Generated at 2022-06-24 11:17:40.976488
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String

    class PersonSchema(Schema):
        age = Integer()
        name = String()

    content = "age: 10\nname: alice\n"
    value, error_messages = validate_yaml(content=content, validator=PersonSchema)

    assert error_messages == []
    assert value == {"age": 10, "name": "alice"}

# Generated at 2022-06-24 11:17:51.697334
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: room-1
      number: 123
    - name: room-2
      number: 456
    """
    from typesystem.schema import Schema

    from typesystem.fields import String, Integer

    class Room(Schema):
        name = String()
        number = Integer()

    result, messages = validate_yaml(content=content, validator=Room)
    assert messages == []
    assert result[0] == {
        "name": "room-1",
        "number": 123,
    }
    assert result[1] == {
        "name": "room-2",
        "number": 456,
    }

# Generated at 2022-06-24 11:17:57.785111
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        my_field = Field(type="string")
        my_int = Field(type="integer")

    # Handle cases that result in a TypeSystem parse error.
    with pytest.raises(ValidationError) as exc:
        assert validate_yaml(content='', validator=MySchema)
    assert exc.value.messages == [
        Message(
            field=Field(name="my_field", required=True, type="string"),
            code="required",
            text="This field is required.",
        )
    ]

    with pytest.raises(ValidationError) as exc:
        assert validate_yaml(
            content=b"",
            validator=MySchema,
        )

# Generated at 2022-06-24 11:18:06.376893
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = ""
    token = tokenize_yaml(content)
    assert token is None

    content = """\
message: "Hello, world!"
    """
    token = tokenize_yaml(content)
    assert token is not None
    assert token.start == 0
    assert token.end == 32
    assert token.content == content
    assert token.items() == (
        ("message", ScalarToken("Hello, world!", 9, 22, content)),
    )

    content = """\
name: "Reginald Perrin"
age: 47
    """
    token = tokenize_yaml(content)
    assert token is not None
    assert token.start == 0
    assert token.end == 46
    assert token.content == content

# Generated at 2022-06-24 11:18:16.254458
# Unit test for function validate_yaml
def test_validate_yaml():
    class Fruit(Schema):
        name = Field(type=str)

    class Bag(Schema):
        content = Field(type=Fruit, min_length=1)

    content = """
- name: apple
- name: orange
- name: banana
"""
    bag, errors = validate_yaml(content, Bag)
    assert isinstance(bag, Bag)
    assert not errors

    content = """
- name: apple
- name: orange
- name:
- name: banana
"""
    bag, errors = validate_yaml(content, Bag)
    assert isinstance(bag, Bag)
    assert errors[0].position.char_index == 9
    assert errors[0].text == "Field may not be blank."
    assert errors[0].code == "blank"


# Generated at 2022-06-24 11:18:25.994757
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        field_one = fields.IntegerField()
        field_two = fields.StringField()

    content = dedent("""\
        field_one: 1
        field_two: 2
    """)
    value, errors = validate_yaml(content, MySchema)
    assert errors == [
        Message(
            text="Value must be string.",
            code='invalid_type',
            position=Position(
                char_index=15,
                column_no=3,
                line_no=2
            )
        )
    ]


# Generated at 2022-06-24 11:18:30.897918
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('"foo"')
    assert(isinstance(token, ScalarToken))
    assert(token.value == 'foo')
    assert(token.start_index == 0)
    assert(token.end_index == 5)
    assert(token.content == '"foo"')
    

# Generated at 2022-06-24 11:18:39.171218
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test_input = textwrap.dedent(
        """
    - a:
        - b:
            - c: 1
              d: 2
      e: 3
      f:
        - 6
        - 7
    - g: h
    """
    ).strip()
    assert tokenize_yaml(test_input) == [
        {
            "a": [
                {
                    "b": [
                        {"c": 1, "d": 2},
                    ],
                    "e": 3,
                    "f": [6, 7],
                },
            ],
        },
        {"g": "h"},
    ]



# Generated at 2022-06-24 11:18:42.785780
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "greeting: Hello\nname: World"
    schema = Schema({"greeting": str, "name": str})
    (value, errors) = validate_yaml(content, schema)
    assert errors == []
    assert isinstance(value, dict)
    assert value["greeting"] == "Hello"
    assert value["name"] == "World"


# Generated at 2022-06-24 11:18:49.346578
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    try:
        import yaml
        from yaml.loader import SafeLoader
    except ImportError:  # pragma: no cover
        yaml = None  # type: ignore
        SafeLoader = None  # type: ignore
    assert tokenize_yaml('') == None
    assert tokenize_yaml(' ') == None
    assert tokenize_yaml('a: b') == {'a': 'b'}
    assert tokenize_yaml('a:\n  b') == {'a': 'b'}
    assert tokenize_yaml('a:\n - 1\n - 2\n - 3\n') == {'a': [1,2,3]}
    assert tokenize_yaml('a: b\nc: d') == {'a': 'b', 'c':'d'}
    assert tokenize

# Generated at 2022-06-24 11:19:00.437754
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.base import ValidationError
    from typesystem.fields import String

    token = tokenize_yaml("foo: bar")
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == 6
    assert token.content == "foo: bar"
    assert token["foo"] == "bar"
    assert token["foo"].start == 0
    assert token["foo"].end == 6
    assert token["foo"].content == "foo: bar"

    token = tokenize_yaml("- foo")
    assert isinstance(token, ListToken)
    assert token.start == 0
    assert token.end == 3
    assert token.content == "- foo"
    assert token[0] == "foo"
    assert token[0].start == 2

# Generated at 2022-06-24 11:19:08.571322
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem.types
    from typesystem.types import Integer, String
    from typesystem.schemas import Schema
    from typesystem import fields

    class SimpleSchema(Schema):
        name = String(max_length=10)
        value = Integer(maximum=10)

    assert validate_yaml("name: foo\nvalue: 5", SimpleSchema) == SimpleSchema({'name': 'foo', 'value': 5})

    errors = validate_yaml("name: foo\nvalue: 15", SimpleSchema)[1]
    assert len(errors) == 1
    error = errors[0]
    assert error.code == 'value.maximum'
    assert error.message == '15 is bigger than 10'
    assert error.position.line_no == 2
    assert error.position.column_no == 5

# Generated at 2022-06-24 11:19:13.825625
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema.of({"field": int})

    value, errors = validate_yaml(b"field: 1", schema)
    assert "1" == value
    assert not errors

    value, errors = validate_yaml(b"field: one", schema)
    assert errors
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 1



# Generated at 2022-06-24 11:19:21.673561
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test_string = """
    foo: bar
    fizz: buzz
    """
    token_data = {'foo': 'bar', 'fizz': 'buzz'}
    token = tokenize_yaml(test_string)
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == len(test_string) - 1
    assert token.data == token_data



# Generated at 2022-06-24 11:19:31.300157
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    token = tokenize_yaml("{foo: bar}")
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}
    assert token.start == 0
    assert token.end == 9
    assert token.content == "{foo: bar}"

    token = tokenize_yaml("[foo, bar]")
    assert isinstance(token, ListToken)
    assert token.value == ["foo", "bar"]
    assert token.start == 0
    assert token.end == 9
    assert token.content == "[foo, bar]"

    token = tokenize_yaml("nope")
    assert isinstance(token, ScalarToken)
    assert token.value == "nope"
    assert token.start == 0


# Generated at 2022-06-24 11:19:37.623690
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("[123, 321]") == [
        ScalarToken(123, 1, 2, "[123, 321]"),
        ScalarToken(321, 8, 9, "[123, 321]"),
    ]
    assert tokenize_yaml('{"a": 1, "b": 2}') == {
        "a": ScalarToken(1, 5, 6, '{"a": 1, "b": 2}'),
        "b": ScalarToken(2, 11, 12, '{"a": 1, "b": 2}'),
    }


# Generated at 2022-06-24 11:19:44.833873
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    actual = tokenize_yaml("""
        messages:
          - "hey"
          - "hi"
        """)
    assert actual == {'messages': ['hey', 'hi']}

    actual = tokenize_yaml('''
        messages:
          - "hey"
          - "hi"
          - category: "test"
        ''')
    assert actual == {'messages': ['hey', 'hi', {'category': 'test'}]}

    actual = tokenize_yaml('''
        messages:
          - "hey"
          - "hi"
          - category: "test"
        more: true
        ''')
    assert actual == {'messages': ['hey', 'hi', {'category': 'test'}], 'more': True}

# Generated at 2022-06-24 11:19:54.050200
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("x: null") == {'x': None}
    assert tokenize_yaml("x: 42") == {'x': 42}
    assert tokenize_yaml("x: true") == {'x': True}
    assert tokenize_yaml("x: ") == {'x': ""}
    assert tokenize_yaml("x: 'null'") == {'x': 'null'}
    assert tokenize_yaml("") == None
    assert tokenize_yaml("x: null, y: 42") == {'x': None, 'y': 42}
    assert tokenize_yaml("[1, 2]") == [1, 2]
    assert tokenize_yaml("[1, null]") == [1, None]


# Generated at 2022-06-24 11:19:57.681935
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(" - 1 \n - 2 \n - 3  ").content == " - 1 \n - 2 \n - 3  "
    assert type(tokenize_yaml(" - 1 \n - 2 \n - 3  ")) == ListToken
    print(tokenize_yaml(" - 1 \n - 2 \n - 3  "))



# Generated at 2022-06-24 11:20:03.646621
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('''a: foo
    b: 1
    c: true
    d: null
    e:
        - 2
        - 3
        - 4
        - 5''') == {
        'a': 'foo',
        'b': 1,
        'c': True,
        'd': None,
        'e': [2, 3, 4, 5]
    }

# Generated at 2022-06-24 11:20:07.577306
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String

    yaml_str = "abc"
    parsed_value, error_messages = validate_yaml(yaml_str, String())

    assert parsed_value == "abc"
    assert not error_messages

# Generated at 2022-06-24 11:20:10.204520
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("1") == DictToken({"1": 1}, index_start=0, index_stop=1, content="1")


# Generated at 2022-06-24 11:20:15.242000
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        """
        Example of a YAML schema
        """

        name = String()

    yaml_doc = """
    ---
    name: Olly
    """
    value, errors = validate_yaml(yaml_doc, TestSchema)

    assert errors == []
    assert value == {'name': 'Olly'}

    yaml_doc = """
    ---
    name: Olly
    age: Three
    """
    value, errors = validate_yaml(yaml_doc, TestSchema)

    assert errors[0].code == "field_error"
    assert errors[0].text == "Field 'age' is invalid."
    assert errors[0].value == "Three"

# Generated at 2022-06-24 11:20:25.886508
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(format="name")
        age = String(format="age")

    people = """
    - name: "Jimmy"
      age: "7"
    - name: "Jane"
      age: "8"
    """
    value, errors = validate_yaml(people, validator=Person)
    assert value == [
        {"name": "Jimmy", "age": "7"},
        {"name": "Jane", "age": "8"},
    ]
    assert not errors

    people = """
    - name: "Jimmy"
    - name: "Jane"
      age: 7
    """
    value, errors = validate_yaml(people, validator=Person)
    assert value == [{"name": "Jimmy"}, {"name": "Jane"}]

# Generated at 2022-06-24 11:20:32.632399
# Unit test for function validate_yaml
def test_validate_yaml():
    Schema = typesystem.Schema

    class NameField(typesystem.String):
        max_length = 100

    class EmailField(typesystem.String):
        pattern = r".*@.*"

    class UserSchema(Schema):
        name = NameField()
        email = EmailField()

    user_yaml = """
    name: "Bob"
    email: "foo@bar.baz"
    """

    (value, errors) = validate_yaml(user_yaml, UserSchema)

    assert len(errors) == 0

    assert value.name == "Bob"
    assert value.email == "foo@bar.baz"



# Generated at 2022-06-24 11:20:40.920570
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer
    from typesystem.schemas import Schema

    schema = Schema({"x": Integer()})

    _, errors = validate_yaml(content="x: val", validator=schema)
    assert errors == [
        Message(
            text="Validation failed.",
            code="validation_failed",
            position=Position(line_no=1, column_no=1, char_index=0),
        ),
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=1, column_no=3, char_index=2),
        ),
    ]

