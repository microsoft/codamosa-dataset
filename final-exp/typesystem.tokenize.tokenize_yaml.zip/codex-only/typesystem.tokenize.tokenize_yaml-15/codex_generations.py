

# Generated at 2022-06-24 11:10:47.869496
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "hello: |\n  world"
    validator = Field(type_name="string")

    result = validate_yaml(content, validator)
    assert isinstance(result, typing.Tuple)
    assert len(result) == 2
    assert result[0] == "world"
    assert isinstance(result[1], typing.List)
    assert not result[1]

    content = b"hello: |\n  world"
    validator = Field(type_name="string")

    result = validate_yaml(content, validator)
    assert isinstance(result, typing.Tuple)
    assert len(result) == 2
    assert result[0] == "world"
    assert isinstance(result[1], typing.List)
    assert not result[1]


# Generated at 2022-06-24 11:10:51.634423
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: b
    """
    validator = Field(key="a")
    value, errors = validate_yaml(content, validator)
    assert value == "b"



# Generated at 2022-06-24 11:11:03.157045
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Boolean, Field, String


# Generated at 2022-06-24 11:11:10.226065
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(b"hello: world")
    assert token == DictToken({'hello': 'world'}, 0, 14)
    assert token.start == 0
    assert token.end == 14
    assert token.content == 'hello: world'

    token = tokenize_yaml(b"hello: world\ngoodbye: world")
    assert token == DictToken({'hello': 'world', 'goodbye': 'world'}, 0, 29)
    assert token.start == 0
    assert token.end == 29
    assert token.content == 'hello: world\ngoodbye: world'

    with pytest.raises(ParseError):
        tokenize_yaml(b"hello: world\n    - foo")
        tokenize_yaml(b"hello: world\n    - foo")

# Generated at 2022-06-24 11:11:22.264400
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_test_dict = {
        "test_list_int": [1, 2, 3],
        "test_list_str": ["a", "b", "c"],
        "test_list_bool": [True, False, True],
        "test_list_null": [None, None, None],
        "test_dict_int": {"1": 1, "2": 2, "3": 3},
        "test_dict_str": {"a": "a", "b": "b", "c": "c"},
        "test_dict_bool": {"T": True, "F": False},
        "test_dict_null": {"N": None},
    }

    yaml_test_str = yaml.dump(yaml_test_dict)

# Generated at 2022-06-24 11:11:30.567729
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    schema = typing.Dict[str, typing.Union[str, typing.List[float]]]
    validator = typing.cast(Schema, Field.from_type(schema))
    content = "name: Grahame"
    assert validator.validate(content) == {"name": "Grahame"}
    content = "name: Grahame\nage: 50.5"
    assert validator.validate(content) == {"name": "Grahame", "age": 50.5}
    content = "name: Grahame\nage: 50.5\n\n"
    assert validator.validate(content) == {"name": "Grahame", "age": 50.5}
    content = "name: Grahame\nage: 50.5\n\n\n"

# Generated at 2022-06-24 11:11:34.303761
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "Steve"
    """
    value, messages = validate_yaml(content, Person)

    assert value == {"name": "Steve"}
    assert messages == []



# Generated at 2022-06-24 11:11:45.942592
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem import types
 
    class PersonSchema(Schema):
        name = types.String(min_length=2)
        age = types.Integer(minimum=18)
        favourite_drink = types.String(enum=["coffee", "beer", "wine"])
        location = types.String()

    yaml_string = """
    name: Jack
    age: 50
    favourite_drink: beer
    location: New York
    """

    try:
        value, error_messages = validate_yaml(yaml_string, PersonSchema)
    except ParseError as exc:
        error_messages = [exc]


# Generated at 2022-06-24 11:11:54.220927
# Unit test for function validate_yaml
def test_validate_yaml():

    # Parse failure
    content = """
value: None
"""
    validator = Field(type="object", properties={"value": "integer"})
    value, error_messages = validate_yaml(content, validator)
    assert len(error_messages) == 1
    assert error_messages[0].code == "expected_type"
    assert error_messages[0].position.line_no == 2
    assert error_messages[0].position.column_no == 7

    class YAMLSchema(Schema):
        value = Field(type="object", properties={"value": "integer"})

    schema = YAMLSchema()
    value, error_messages = validate_yaml(content, schema)
    assert len(error_messages) == 1

# Generated at 2022-06-24 11:11:58.573363
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: 1
    b: 2
    """
    expected = DictToken({"a": 1, "b": 2}, 0, 29)
    token = tokenize_yaml(content)
    assert token == expected
    assert content == token.content



# Generated at 2022-06-24 11:12:02.386809
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b'name: test\n'
    validator = Schema(
        {"name": str}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {'name': 'test'}
    assert error_messages == []


# Generated at 2022-06-24 11:12:11.343069
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Schema(
        fields={"name": Field(type="string"), "height": Field(type="integer")},
    )
    value, errors = validate_yaml(
        content="""
        height: 1.75
        name: "John Smith"
        """,
        validator=validator,
    )

    assert value == {"name": "John Smith", "height": 1}

    assert len(errors) == 1

    error = errors[0]
    assert error.field == "height"
    assert error.message == "Value must be an integer."
    assert error.code == "invalid_type"
    assert error.position.column_no == 9
    assert error.position.line_no == 2
    assert error.position.char_index == 15

# Generated at 2022-06-24 11:12:20.919404
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None

    assert isinstance(tokenize_yaml("test:test"), DictToken)
    assert tokenize_yaml("test:test").get("test") == None

    assert isinstance(tokenize_yaml("x: 1"), DictToken)
    assert tokenize_yaml("x: 1").get("x") == ScalarToken(1, 2, 3, content = "x: 1")

    assert isinstance(tokenize_yaml("test: [1,2,3]"), DictToken)
    assert tokenize_yaml("test: [1,2,3]").get("test") == ListToken([1,2,3], 5, 10, content = "test: [1,2,3]")


# Generated at 2022-06-24 11:12:25.936969
# Unit test for function validate_yaml
def test_validate_yaml():
    file_content = """
    data:
      name:
        first_name: John
        last_name: Smith
    """
    token, error_messages = validate_yaml(
        content=file_content, validator=PersonSchema
    )
    assert token["data"]["name"]["first_name"] == "John"
    assert not error_messages


# Generated at 2022-06-24 11:12:34.568216
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test strings
    test_string_1 = "key: value"
    test_string_2 = "key: 1"
    test_string_3 = "key: 1.1"
    test_string_4 = "key: [1, 1.1]"

    # Test result
    result_1 = tokenize_yaml(test_string_1).value
    result_2 = tokenize_yaml(test_string_2).value
    result_3 = tokenize_yaml(test_string_3).value
    result_4 = tokenize_yaml(test_string_4).value

    # Test exceptions
    exception_1 = "1, 2"

    assert(result_1 == {'key': 'value'})
    assert(result_2 == {'key': 1})

# Generated at 2022-06-24 11:12:39.224251
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("foo: bar")
    assert isinstance(token, DictToken)
    assert token.children[0].value == "foo"
    assert token.children[1].value == "bar"

# Generated at 2022-06-24 11:12:48.269506
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import String
    from typesystem.schemas import Schema

    content = b"""
    name: string
    """
    print(content)
    value, error_messages = validate_yaml(content=content, validator=String())
    print(value)
    print(error_messages)

    class MySchema(Schema):
        name = String()
    content2 = b"""
    name: string
    """
    print(content2)
    value, error_messages = validate_yaml(content=content2, validator=MySchema)
    print(value)
    print(error_messages)

    class MySchema(Schema):
        name = String(min_length=10, max_length=200)

# Generated at 2022-06-24 11:12:52.756783
# Unit test for function validate_yaml
def test_validate_yaml():
    # assert validate_yaml("invalid yaml")
    validator = Field(type="string", max_length=10)
    errors = [
        {
            "code": "too_long",
            "field": None,
            "message": "Ensure this value has at most 10 characters (it has 11).",
            "row_no": 1,
            "column_no": 1,
        }
    ]
    validator = Field(type="string", max_length=10)
    assert validate_yaml("hello there", validator) == (
        "hello there",
        [],
    )

    assert validate_yaml("hello there mate", validator) == (
        None,
        errors,
    )

# Generated at 2022-06-24 11:13:02.918742
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test that tokenize_yaml properly converts valid YAML into tokens.

    with pytest.raises(ParseError):
        tokenize_yaml("")

    assert tokenize_yaml("5") == ScalarToken(5, 0, 1)
    assert tokenize_yaml("5.5") == ScalarToken(5.5, 0, 3)
    assert tokenize_yaml("-5") == ScalarToken(-5, 0, 2)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4)

# Generated at 2022-06-24 11:13:13.721198
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_str = """
        a: 1
        b:
            c: yes
        d:
            - 1
            - 2
            - 3
        e:
            - hello
    """
    dt = tokenize_yaml(yaml_str)
    assert isinstance(dt, DictToken)
    assert dt.raw_value == {'a': 1, 'b': {'c': 'yes'}, 'd': [1, 2, 3], 'e': ['hello']}
    assert len(dt.children) == 4
    assert dt.children['a'].raw_value == 1
    assert dt.children['a'].content == '1'
    assert dt.children['d'].children[0].content == '1'

# Generated at 2022-06-24 11:13:15.722597
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None, "No content."



# Generated at 2022-06-24 11:13:25.015283
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml("")
    assert str(excinfo.value) == "No content."
    
    token = tokenize_yaml("1")
    assert isinstance(token, ScalarToken)
    assert token.value == 1
    
    token = tokenize_yaml("""\
        1
        2
        3
    """)
    assert isinstance(token, ScalarToken)
    assert token.value == 1
    
    token = tokenize_yaml("""
        - 1
        - 2
        - 3
    """)
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3]


# Generated at 2022-06-24 11:13:30.506487
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Scalar tokenize
    assert tokenize_yaml("A string") == ScalarToken("A string", 0, 8, content="A string")
    assert tokenize_yaml("A\nstring") == ScalarToken("A\nstring", 0, 8, content="A\nstring")
    assert tokenize_yaml("100") == ScalarToken(100, 0, 2, content="100")
    assert tokenize_yaml("100.12") == ScalarToken(100.12, 0, 5, content="100.12")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")

# Generated at 2022-06-24 11:13:41.646937
# Unit test for function validate_yaml
def test_validate_yaml():
    class AddressSchema(Schema):
        address = Field(StringType(format='uppercase'))
        city = Field(StringType())
        state = Field(StringType())
        zip_code = Field(StringType())

    class OrderSchema(Schema):
        item = Field(StringType())
        quantitiy = Field(IntegerType())
        address = Field(AddressSchema())

    class UserSchema(Schema):
        name = Field(StringType())
        order = Field(ArrayType(OrderSchema()))


# Generated at 2022-06-24 11:13:54.444898
# Unit test for function validate_yaml
def test_validate_yaml():
    ########################################
    # Real Data
    ########################################
    validator = Field(type="string")
    value, error_messages = validate_yaml(content='''
name: John Doe
age: 25
''', validator=validator)
    assert error_messages is not None
    assert len(error_messages) == 1
    assert error_messages[0]['message'] == 'Value must be a string.'
    assert error_messages[0]['code'] == 'invalid_type'
    assert error_messages[0]['position']['column_no'] == 1
    assert error_messages[0]['position']['line_no'] == 1
    assert error_messages[0]['position']['char_index'] == 0
    # TODO: this test will pass

# Generated at 2022-06-24 11:14:02.214162
# Unit test for function validate_yaml
def test_validate_yaml():
    # TODO: Move test_validate_yaml to a proper test file and get 100% coverage.
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class ExampleSchema(Schema):
        field = String()

    content = "field: hello"

    value, errors = validate_yaml(content, ExampleSchema)
    assert value == {"field": "hello"}
    assert errors == []

    content = "not_field: hello"

    value, errors = validate_yaml(content, ExampleSchema)
    assert value == {"not_field": "hello"}
    assert [e.position.line_no for e in errors] == [1]

    content = "field: hello\nnot_field: not_hello"


# Generated at 2022-06-24 11:14:09.988647
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_string = """
root:
  - name: Jane Smith
    age: 30
    email: jane@example.com
  - name: John Doe
    age: -2
    email: john@example.com
"""
    Person = Schema.of(
        {"name": str, "age": int, "email": str}
    )
    validator = Field(type=List[Person])

    # Validate a valid YAML string
    (data, errors) = validate_yaml(content=yaml_string, validator=validator)
    assert errors == []

# Generated at 2022-06-24 11:14:21.462404
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test function validate_yaml"""
    import yaml
    from typesystem import Integer, Str, Schema

    class MySchema(Schema):
        a = Str()
        b = Integer()

    content = yaml.dump({'a': 'hello', 'b': 2})
    value, errors = validate_yaml(content, validator=MySchema())
    assert errors == []
    assert value == {'a': 'hello', 'b': 2}

    content = yaml.dump({'a': 'hello', 'b': 3.14159})
    value, errors = validate_yaml(content, validator=MySchema())
    assert len(errors) == 1
    error = errors[0]
    assert isinstance(error, ValidationError)
    assert error.code == "invalid_type"

# Generated at 2022-06-24 11:14:22.734015
# Unit test for function validate_yaml
def test_validate_yaml():
    assert isinstance(validate_yaml("", Field()), tuple)

# Generated at 2022-06-24 11:14:28.973686
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = Field(required=True)
        age = Field(type="integer", required=True)

    class People(Schema):
        people = Field(required=True, type="list", items=Person)

    PERSON_VALID = """
    name: John
    age: 45
    """

    assert validate_yaml(PERSON_VALID, Person) == ({'name': 'John', 'age': 45}, [])

    PERSON_INVALID = """
    foo: John
    """


# Generated at 2022-06-24 11:14:37.892190
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "ok: true\n"
    validator = Schema(fields={"ok": "boolean"})
    value, errors = validate_yaml(content=content, validator=validator)
    assert value == {"ok": True}
    assert errors == []

    content = "bad: 2\n"
    value, errors = validate_yaml(content=content, validator=validator)
    assert value == {"bad": 2}
    assert isinstance(errors[0], ValidationError)
    assert "Expected a boolean" in errors[0].messages()[0].text
    assert errors[0].messages()[0].position.column_no == 5

# Generated at 2022-06-24 11:14:43.329001
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    validator = Integer()
    value, errors = validate_yaml('123', validator)
    assert value == 123
    assert len(errors) == 0
    
    class PersonSchema(Schema):
        name = Integer(required=True)
        age = Integer()
    value, errors = validate_yaml('age: 26\nname: 28', PersonSchema)    
    assert value is not None
    assert errors is not None
    assert len(errors) == 1
    print(errors)

# Generated at 2022-06-24 11:14:53.539113
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("test: content"), DictToken)
    assert isinstance(tokenize_yaml("test: - foo"), DictToken)
    assert isinstance(tokenize_yaml("test: [ foo ]"), DictToken)
    assert isinstance(tokenize_yaml("test: '{}'"), DictToken)
    assert isinstance(tokenize_yaml("test: 'foo'"), DictToken)
    assert isinstance(tokenize_yaml("test: foo"), DictToken)
    assert isinstance(tokenize_yaml("test: true"), DictToken)
    assert isinstance(tokenize_yaml("test: false"), DictToken)
    assert isinstance(tokenize_yaml("test: null"), DictToken)

# Generated at 2022-06-24 11:14:57.654685
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = typing.List[int] #https://docs.python.org/3/library/typing.html#typing.List
    content = "[1, 2, 3]"
    value, error_messages = validate_yaml(content, validator)
    assert value == [1,2,3]
    assert error_messages == []


# Generated at 2022-06-24 11:15:03.116541
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem import String
    from typesystem.tokenize.validation import validate
    from typesystem.tokenize.validation import validate_with_positions

    token = tokenize_yaml('foo: "bar"\n')
    assert isinstance(token, DictToken)
    assert token.items[0].value == "bar"
    assert token.items[0].start == 8
    assert token.items[0].end == 12

    value, error_messages = validate_with_positions(token, String)
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 1

    value, error_messages = validate(token, String)
    assert error_messages[0].position.line_no is None

# Generated at 2022-06-24 11:15:10.160408
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String

    class MySchema(Schema):
        name = String()
        age = Integer()

    result, errors = validate_yaml(
        """
        name: Mat
        age: 27
        """,
        MySchema,
    )

    assert result == {"name": "Mat", "age": 27}
    assert not errors



# Generated at 2022-06-24 11:15:17.989389
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: 'Ravi Prakash'"
    validator = fields.Dict({
        "name": fields.String(max_length=20)
    })
    res, errors = validate_yaml(content, validator)
    assert not errors
    content = "name: 'Ravi Prakash'"
    validator = fields.Dict({
        "name": fields.String(max_length=10)
    })
    res, errors = validate_yaml(content, validator)
    assert len(errors) == 1


if __name__ == "__main__":
    test_validate_yaml()

# Generated at 2022-06-24 11:15:26.639354
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    errors = []

    class UserSchema(Schema):
        name = Field(type=str)
        age = Field(type=int, minimum=0)

    # --- Valid content ---------------------------------------------------------
    validator = UserSchema()
    errors = validate_yaml(
        b"""
        name: "Bob"
        age: 5
        """,
        validator=validator,
    )
    assert errors == []

    # --- Invalid content --------------------------------------------------------
    validator = UserSchema()
    errors = validate_yaml(
        b"""
        name: "Bob"
        age: abc
        """,
        validator=validator,
    )
    assert len(errors) == 1

# Generated at 2022-06-24 11:15:33.274847
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(name="foo", fields={"name": StringField(min_length=2)})
    data, errors = validate_yaml(
        content="""name: p""",
        validator=schema,
    )
    assert errors == [
        Message(
            text="Must be at least 2 characters long.",
            code="too_short",
            position=Position(column_no=7, char_index=7, line_no=1),
        )
    ]

# Generated at 2022-06-24 11:15:42.277957
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import IntegerField, BooleanField, StringField

    class MySchema(Schema):
        age = IntegerField()
        name = StringField()
        has_pet = BooleanField()

        def clean_age(self, value):
            if value < 0:
                raise ValidationError(text="Age must be greater than zero.")
            return value

    content = """
    age: -1
    name: John Doe
    has_pet: true
    """

    value, error_messages = validate_yaml(content, MySchema)
    print(value, error_messages)


if __name__ == "__main__":
    test_validate_yaml()

# Generated at 2022-06-24 11:15:51.686195
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        import yaml
    except ImportError:
        pytest.xfail("PyYAML is not installed.")

    # Strings
    value, errors = validate_yaml("""not-valid: "nope" """, "string")
    assert value == "not-valid: nope"
    assert len(errors) == 1
    assert errors[0].code == 'if_field_then_value_must_be_string'
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 1

    # Lists
    value, errors = validate_yaml("""not-valid: "nope" """, "[string]")
    assert value == ["not-valid: nope"]
    assert len(errors) == 1

# Generated at 2022-06-24 11:16:01.616702
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo: "bar"
    baz: 123
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

    content = """
    - foo
    - bar
    - baz
    """
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)

    content = "boop: 123"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

    content = "123"
    token = tokenize_yaml(content)
    assert isinstance(token, ScalarToken)

# Generated at 2022-06-24 11:16:03.994095
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    expected = {"foo": 1, "bar": 2, "baz": 3}
    content = "---\nfoo: 1\nbar: 2\nbaz: 3\n"
    yaml_token = tokenize_yaml(content)
    assert yaml_token.value == expected



# Generated at 2022-06-24 11:16:13.659054
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    if yaml is None:
        pytest.skip("yaml must be installed to run unit tests")
    content = textwrap.dedent(
        """\
        name: Test
        price: 12.99
        type:
          - t-shirt
          - small
        """
    )

    with pytest.raises(ParseError):
        token = tokenize_yaml(content="")

    token = tokenize_yaml(content=content)
    assert token.value == {
        "name": "Test",
        "price": 12.99,
        "type": ["t-shirt", "small"],
    }

    assert isinstance(token, DictToken)
    assert isinstance(token.value["name"], ScalarToken)
    assert token.value["name"].value == "Test"
    assert isinstance

# Generated at 2022-06-24 11:16:17.808082
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('{"foo": [1, 2, 3]}')
    assert type(token) is DictToken
    token1 = tokenize_yaml('[1, 2, 3]')
    assert type(token1) is ListToken

# Generated at 2022-06-24 11:16:25.795207
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_string = '''
        - name: David
          email: davidr@bounteous.com
        - name: Michael
          email: michaelp@bounteous.com
    '''
    token = tokenize_yaml(yaml_string)
    assert isinstance(token, ListToken)
    assert isinstance(token.value[0], DictToken)
    assert isinstance(token.value[0].value['name'], ScalarToken)
    assert isinstance(token.value[0].value['email'], ScalarToken)
    assert isinstance(token.value[1], DictToken)
    assert isinstance(token.value[1].value['name'], ScalarToken)
    assert isinstance(token.value[1].value['email'], ScalarToken)

# Generated at 2022-06-24 11:16:31.156257
# Unit test for function tokenize_yaml

# Generated at 2022-06-24 11:16:39.112059
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None
    content = """
    name: "Test message"

    number: 123.456

    integer: 123

    boolean: True

    null:
    """
    expected = {
        "name": "Test message",
        "number": 123.456,
        "integer": 123,
        "boolean": True,
        "null": None,
    }

    token = tokenize_yaml(content)
    assert token.value == expected



# Generated at 2022-06-24 11:16:46.623509
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    This is a simple unit test for the `tokenize_yaml` method. The test is
    located here so the Travis build only runs it once. This test can be
    ignored for now.
    """
    assert yaml is not None, "'pyyaml' must be installed."

    content = """
    # Comment
    hello:
      - foo
      - bar
    """

    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert isinstance(token["hello"], ListToken)
    assert token["hello"] == [ScalarToken("foo"), ScalarToken("bar")]



# Generated at 2022-06-24 11:16:55.350030
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test all scalars and simple collections
    assert tokenize_yaml('"string"') == ScalarToken('string', 0, 8, content='"string"')
    assert tokenize_yaml('123') == ScalarToken(123, 0, 3, content='123')
    assert tokenize_yaml('true') == ScalarToken(True, 0, 4, content='true')
    assert tokenize_yaml('null') == ScalarToken(None, 0, 4, content='null')
    assert tokenize_yaml('[1, 2, 3]') == ListToken([1, 2, 3], 0, 9, content='[1, 2, 3]')

# Generated at 2022-06-24 11:17:05.481405
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    def test_string_empty():
        """
        Test that an empty string raises ParseError with "No content." message
        """
    # Arrange
        content = ""
        with pytest.raises(ParseError) as exc_info:
            # Act
            tokenize_yaml(content)
        # Assert
        exc = exc_info.value
        assert exc.text == "No content."
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)

    def test_string_invalid_yaml():
        """
        Test that invalid YAML raises ParseError with appropriate message
        """
        # Arrange
        content = ":a:b:c"

# Generated at 2022-06-24 11:17:08.325540
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert tokenize_yaml("") == {}



# Generated at 2022-06-24 11:17:17.240556
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        properties={
            "title": {
                "type": "string",
                "min_length": 3
            },
            "author": {
                "type": "string",
                "min_length": 3
            },
            "pages": {
                "type": "integer",
                "min": 3
            }
        }
    )
    good_content = b'''
        title: The Three-Body Problem
        author: Cixin Liu
        pages: 400
    '''
    _, error_messages = validate_yaml(content=good_content, validator=schema)
    assert len(error_messages) == 0

    bad_content = b'''
        title: "The Three-Body Problem"
        author: Cixin Liu
        pages: 3
    '''

# Generated at 2022-06-24 11:17:26.069035
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test case: A valid YAML string
    assert tokenize_yaml("a: 1") == DictToken({'a': 1}, 0, 6, content="a: 1")
    assert tokenize_yaml("name: John") == DictToken({'name': 'John'}, 0, 8, content="name: John")
    assert tokenize_yaml("age: 21") == DictToken({'age': 21}, 0, 6, content="age: 21")

    # test case: An invalid YAML string
    try:
        tokenize_yaml("a: \n name: John \n age: 21")
    except ParseError as error:
        assert error.text == "did not find expected key"
        assert error.code == "parse_error"
        assert error.position.line_no == 2

# Generated at 2022-06-24 11:17:34.125116
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '{"a": 1}'
    validator = fields.Dict({"a":fields.Integer()})
    token = tokenize_yaml(content)
    try:
        validate_with_positions(token=token, validator=validator)
    except ParseError as e:
        assert e.text == 'No content.'
        assert e.code == 'no_content'
        assert e.position.line_no == 1
        assert e.position.column_no == 1
        assert e.position.char_index == 0
    else:
        assert False, "No exception raised"

# Generated at 2022-06-24 11:17:43.612651
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test that the function can accept a string or bytes input
    string_input = tokenize_yaml("a: 66")
    assert isinstance(string_input, DictToken)
    bytes_input = tokenize_yaml(b"a: 66")
    assert isinstance(bytes_input, DictToken)

    # Test that the function returns a tokenized version of the YAML with the
    # expected values
    tokenized = tokenize_yaml("a: 66")
    assert isinstance(tokenized, DictToken)
    assert tokenized._value == {"a": 66}
    assert tokenized.start == 0
    assert tokenized.end == 3
    assert tokenized.content == "a: 66"

    # Test that the function raises a ParseError if the YAML is invalid

# Generated at 2022-06-24 11:17:55.056674
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Any
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken, ScalarToken

    class UserSchema(Schema):
        username = Any()

    data = b""  # type: ignore
    content, error_messages = validate_yaml(data, UserSchema)
    assert len(error_messages) == 1
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 1
    assert error_messages[0].text == "No content."

    data = b"""
    username: test
    """  # type: ignore
    content, error_messages = validate_yaml(data, UserSchema)
    assert not error_messages

# Generated at 2022-06-24 11:18:02.714132
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Unit test for case with empty string
    with pytest.raises(ParseError):
        token = tokenize_yaml("")
    
    # Unit test for case with invalid string
    with pytest.raises(ParseError):
        token = tokenize_yaml("{key: value}")
    
    # Unit test for case with valid string
    token = tokenize_yaml("""
    mapping:
        key: value
    """)


# Generated at 2022-06-24 11:18:12.876827
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        a = "string"
        b = "integer"
        c = {"d": "string"}

    r = validate_yaml(
        b"""
    a: test
    b: 1
    c:
        d: test2
    """,
        MySchema,
    )
    assert r == ({"a": "test", "b": 1, "c": {"d": "test2"}}, {})
    r = validate_yaml(
        b"""
    a: test
    b: 1
    c:
        d: 2
    """,
        MySchema,
    )
    assert r[0] is None

# Generated at 2022-06-24 11:18:19.792588
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(b"42") == ScalarToken(42, 0, 1, content="42")
    assert tokenize_yaml(b"42.5") == ScalarToken(42.5, 0, 3, content="42.5")
    assert tokenize_yaml(b"0") == ScalarToken(0, 0, 1, content="0")
    assert tokenize_yaml(b"0.0") == ScalarToken(0.0, 0, 3, content="0.0")
    assert tokenize_yaml(b"-42") == ScalarToken(-42, 0, 2, content="-42")
    assert tokenize_yaml(b"-42.0") == ScalarToken(-42.0, 0, 4, content="-42.0")

# Generated at 2022-06-24 11:18:26.764427
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    content = """
    - s: "asd"
    - test: !test asd
    - test: !test
    - test:
      - !test asd
    - test: !test asd
      - asd
    - test: !test asd
      - asd
    - test: !test [asd]
    """
    token = tokenize_yaml(content)



# Generated at 2022-06-24 11:18:29.657498
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""foo:
  - a
  - b
  - c
""")
    assert isinstance(token, DictToken)
    assert token.value == {"foo": ["a", "b", "c"]}



# Generated at 2022-06-24 11:18:39.986018
# Unit test for function validate_yaml
def test_validate_yaml():
    class SomeSchema(Schema):
        a = fields.String()
    try:
        # test parse error
        validate_yaml("a: b\nc: \n d", SomeSchema)
    except ParseError as e:
        assert str(e) == "No block scalar indicator. line 2, column 2 (char 10)"
        assert e.code == "parse_error"
    try:
        # test validation error
        validate_yaml("a: 42", SomeSchema)
    except ValidationError as e:
        assert str(e) == "This must be a string. line 1, column 3 (char 4)"
        assert e.code == "invalid_type"
    # test valid
    value, messages = validate_yaml("a: '42'\nc: 41", SomeSchema)

# Generated at 2022-06-24 11:18:46.586600
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test yaml string that should parse correctly
    yml = "location: us-east-1"
    token = tokenize_yaml(yml)
    assert isinstance(token, DictToken)
    assert token["location"] == "us-east-1"
    
    # Test yaml string that should raise ParseError
    bad_yml = "location: us-east-1\n"
    with pytest.raises(ParseError):
        token = tokenize_yaml(bad_yml)

    # Test bytes string that should parse correctly
    yml_bytes = b"location: us-east-1"
    token = tokenize_yaml(yml_bytes)
    assert isinstance(token, DictToken)
    assert token["location"] == "us-east-1"

# Unit test

# Generated at 2022-06-24 11:18:57.545984
# Unit test for function validate_yaml
def test_validate_yaml():
    from pprint import pprint
    from typesystem import Schema, String

    # Define a new String Field subclass:
    class Keyword(String):

        keywords = ["true", "yes", "on", "false", "no", "off"]

        def validate(self, value: str) -> str:
            if value not in self.keywords:
                raise ValidationError('Keyword must be one of true, false, on, no, off.')
            return value

    # Create some test data that fails the Keyword validator:
    content = """
    no
    """

    # Unformatted YAML input results in unformatted error messages:
    schema = Schema({"test": Keyword()})
    result = validate_yaml(content, schema)
    print("Unformatted YAML:")

# Generated at 2022-06-24 11:19:04.159339
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Schema(fields={
        "name": Field(type="string"),
        "user_id": Field(type="integer"),
        "location": Field(type="string")
    })
    value, errors = validate_yaml("""
    name: Thomas
    user_id: 123
    location: Amsterdam
    """, validator=validator)

    assert errors == []
    assert value == {
        "name": "Thomas",
        "user_id": 123,
        "location": "Amsterdam"
    }

# Generated at 2022-06-24 11:19:14.877064
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        email = String(max_length=100)

    def validate_person(content: typing.Union[str, bytes]) -> bool:
        try:
            value, errors = validate_yaml(
                content=content,
                validator=Person,
            )
            return len(errors) == 0
        except ParseError:
            return False

    assert validate_person(content=b"name: Jane Doe\nemail: jane@example.com")
    assert validate_person(content="name: Jane Doe\nemail: jane@example.com")
    assert not validate_person(content="name: Jane Doe")
    assert not validate_person(content="name: Jane Doe\nemail:")

# Generated at 2022-06-24 11:19:24.607928
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"name": str})
    assert validate_yaml(
        """
    name: Value
    """,
        schema,
    ) == ({"name": "Value"}, [])

    assert validate_yaml(
        """
    name:
    """,
        schema,
    ) == (None, [Message(text="This field is required.", code="required", path=["name"])])

    assert validate_yaml(
        """
    name: 123
    """,
        schema,
    ) == (None, [Message(text="Value is not a valid string.", code="type_error.str", path=["name"])])



# Generated at 2022-06-24 11:19:32.890149
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: foo
    age: 21
    alive: true
    """
    # Type check
    from typesystem import types
    from typesystem.schemas import Schema

    class Person(Schema):
        name = types.String(max_length=100)
        age = types.Integer(minimum=0, maximum=130)
        alive = types.Boolean()
    # Test validation success
    value, error_messages = validate_yaml(content, Person)
    assert not error_messages
    # Test validation fail
    value, error_messages = validate_yaml(content, Person(required=["name", "age"]))
    assert error_messages



# Generated at 2022-06-24 11:19:34.903459
# Unit test for function validate_yaml
def test_validate_yaml():
    # TODO: Create a unit test for this function in typesystem.yaml
    assert True

# Generated at 2022-06-24 11:19:41.844975
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == {}, "empty dict"
    assert tokenize_yaml("{a: b}") == {"a": "b"}
    assert tokenize_yaml("{a: b, c: d}") == {"a": "b", "c": "d"}
    assert tokenize_yaml("{a: b, c: d}") == {"a": "b", "c": "d"}
    assert tokenize_yaml("{a: b, c: d,}") == {"a": "b", "c": "d"}
    assert tokenize_yaml("{a: [1, 2, 3]}") == {"a": [1, 2, 3]}


# Generated at 2022-06-24 11:19:47.132344
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    @dataclasses.dataclass
    class TestSchema(Schema):
        x: int
        y: float = 2.0

    yaml = """
    x: 3
    y: 2.3333
    """
    token = tokenize_yaml(yaml)
    schema = TestSchema(token)
    dataclasses.asdict(schema)


# Generated at 2022-06-24 11:19:56.507277
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Number, Boolean, Instance
    from typesystem.schemas import Schema
    from typesystem.datetime_types import DateTime

    class Person(Schema):
        name: str = String(max_length=10)
        age: int = Integer(minimum=1, maximum=150)
        favorite_number: float = Number()
        birthday: typing.Optional[datetime] = DateTime()
        employed: bool = Boolean()

    input_invalid_age = """
        name: 'Tester'
        age: 200
        favorite_number: 3.14
        birthday: '2020-05-22T14:23:32.763Z'
        employed: true
    """
    value, errors = validate_yaml(input_invalid_age, Person)

# Generated at 2022-06-24 11:20:07.419423
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import String, Integer
    from typesystem.fields import Field
    class A(Schema):
        a = Field(String())
        b = Field(Integer())
    tokenized = tokenize_yaml('''
        a: string
        b: 4
    ''')
    assert tokenized.value == {'a': 'string', 'b': 4}
    assert validate_yaml('''
        a: string
        b: 4
    ''', A) == ({"a": "string", "b": 4}, [])

# Generated at 2022-06-24 11:20:13.294147
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.integer import Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class UserRegistration(Schema):
        name = String(min_length=2, max_length=10)
        email = String(pattern=r"^\w+@\w+\.\w+$")
        age = Integer(minimum=0, maximum=120)

    errors = validate_with_positions(
        """
    # A valid user object
    name: James
    email: james@example.com
    age: 24
    """,
        validator=UserRegistration,
    )
    assert errors == []


# Generated at 2022-06-24 11:20:19.470925
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from pprint import pprint
    content='''
    - [measurement, tagset, fieldset]
    - [system, {region: us-east}, {load: 1}]
    - [system, {region: us-east}, {load: 1}]
    - [system, {region: us-east}, {load: 1}]
    - [system, {region: us-east}, {load: 1}]
    - [system, {region: us-east}, {load: 1}]
    - [system, {region: us-east}, {load: 1}]
    '''
    token = tokenize_yaml(content)
    pprint(token)


# Generated at 2022-06-24 11:20:22.865052
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("a") == 'a'
    assert tokenize_yaml("-") == []
    assert tokenize_yaml("a: b") == {'a': 'b'}



# Generated at 2022-06-24 11:20:32.024988
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test_scalar = "hello"
    assert isinstance(tokenize_yaml(test_scalar), ScalarToken)

    test_dict_in_str = "test_dict: {hello: 'test'}"
    assert isinstance(tokenize_yaml(test_dict_in_str), DictToken)

    test_dict_in_str_2 = "test_dict: {hello: test}"
    assert isinstance(tokenize_yaml(test_dict_in_str_2), DictToken)

    test_dict_in_str_3 = "test_dict: {hello: test, hello2: test2}"
    assert isinstance(tokenize_yaml(test_dict_in_str_3), DictToken)


# Generated at 2022-06-24 11:20:42.197167
# Unit test for function validate_yaml
def test_validate_yaml():

    schema = Schema([
        Field(name="name", type="string"),
        Field(name="age", type="integer"),
    ])
    value, error_messages = validate_yaml(b"name: 'John'", schema)
    assert len(error_messages) == 1
    assert error_messages[0].code == "required"
    assert error_messages[0].position.column_no == 0

    value, error_messages = validate_yaml(b"name: 'John' age: '25'", schema)
    assert value == {"name": "John", "age": 25}
    assert not error_messages

    value, error_messages = validate_yaml(b"name: 'John'\nage: 25", schema)
    assert value == {"name": "John", "age": 25}