

# Generated at 2022-06-24 11:10:47.918103
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "12345"
    validator = Field(type="integer")
    expected = (12345, [])
    result = validate_yaml(content, validator)
    assert result == expected

    content = "12345"
    validator = Field(type="string")
    expected = ("12345", [])
    result = validate_yaml(content, validator)
    assert result == expected

    content = "true"
    validator = Field(type="boolean")
    expected = (True, [])
    result = validate_yaml(content, validator)
    assert result == expected

    content = "string"
    validator = Field(type="boolean")

# Generated at 2022-06-24 11:10:57.725991
# Unit test for function validate_yaml
def test_validate_yaml():  # pragma: no cover
    from typesystem import Integer, Model, String

    class Person(Model):
        name = String()
        age = Integer()

    # test successful validation
    person = "Beep: 40"
    value, errors = validate_yaml(person, validator=Person)
    assert not errors
    assert value == {"name": "Beep", "age": 40}

    # test validation errors
    person = "Beep: 'forty'"
    value, errors = validate_yaml(person, validator=Person)
    assert errors
    assert value == {"name": "Beep", "age": "forty"}

    # test parsing errors
    person = "Beep"
    with pytest.raises(ParseError):
        value, errors = validate_yaml(person, validator=Person)

# Generated at 2022-06-24 11:11:06.308078
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        username = fields.Str(max_length=10)
        age = fields.Int(minimum=0, maximum=100)

    content = """
    username: samuelcolvin
    age: 40
    """
    value, errors = validate_yaml(content, UserSchema)
    assert value == {'username': 'samuelcolvin', 'age': 40}
    assert errors == {
        'username': [Message(text='Value length must be less than or equal to 10.', code='max_length', position=Position(char_index=12,
            column_no=4, line_no=2))]
    }



# Generated at 2022-06-24 11:11:10.592964
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # No content.
    # yaml.load('', Loader=CustomSafeLoader)
    # does not raise an error.
    with raises(ParseError) as excinfo:
        tokenize_yaml("")
    assert excinfo.value.text == "No content."
    assert not excinfo.value.position

    # Bad content.
    with raises(ParseError) as excinfo:
        tokenize_yaml("a: \n  - 2: [b]\n")
    assert excinfo.value.text == "mapping values are not allowed here."
    assert excinfo.value.position

    # Correct content.

# Generated at 2022-06-24 11:11:19.340069
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
key1: "foo"
key2:
    - a
    - b
    - c
key3: 1
""")

    assert isinstance(token, DictToken)
    assert isinstance(token["key1"], ScalarToken)
    assert token["key1"].value == "foo"
    assert isinstance(token["key2"], ListToken)
    assert isinstance(token["key3"], ScalarToken)
    assert token["key3"].value == 1


# Unit tests for function validate_yaml

# Generated at 2022-06-24 11:11:29.069400
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("空字符串"), ScalarToken)
    assert isinstance(tokenize_yaml("#这是一个注释"), ScalarToken)
    assert isinstance(tokenize_yaml("value: 123"), DictToken)
    assert isinstance(tokenize_yaml("- foo"), ListToken)
    with pytest.raises(ParseError):
        tokenize_yaml("value 123")
    with pytest.raises(ParseError):
        tokenize_yaml("value: 123\nvalue")
    with pytest.raises(ParseError):
        tokenize_yaml("value: 123\nvalue: 456")

# Generated at 2022-06-24 11:11:37.745987
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    class Group(Schema):
        name = String()
        members = Array(items=Person())

    schema_yaml = (
        "name: String\n"
        "members: Array\n"
        "  items: Person\n"
        "\n"
        "definitions:\n"
        "  Person: |\n"
        "    name: String\n"
        "    age: Integer\n"
    )

    result = validate_yaml(schema_yaml, validator=Group)
    assert len(result.errors) == 0

    class ListOfSomething(Schema):
        items = Array()

    schema_yaml = "items: Integer"

# Generated at 2022-06-24 11:11:43.505716
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test_content = '''
    - 
        name: John
        age: 20
        tags:
            - human
            - english
            - male
    - 
        name: Jane
        age: 32
        tags:
            - human
            - french
            - female
    '''
    assert isinstance(tokenize_yaml(test_content), ListToken)



# Generated at 2022-06-24 11:11:52.389400
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("example: 123") == DictToken({"example": "123"}, 0, 12, content="example: 123")
    assert tokenize_yaml("example: - 123\n- 456") == DictToken({ "example": ["123", "456"] }, 0, 19, content="example: - 123\n- 456")
    assert tokenize_yaml("example: [123, 456]") == DictToken({"example": ["123", "456"]}, 0, 19, content="example: [123, 456]")
    assert tokenize_yaml("example: '123'") == DictToken({"example": "123"}, 0, 13, content="example: '123'")

# Generated at 2022-06-24 11:12:02.512012
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()

    # Test validate_yaml
    value, errors = validate_yaml(b"""
        name: "Bob"
    """, Person)
    assert value == {"name": "Bob"}
    assert len(errors) == 0

    value, errors = validate_yaml(b"""
        name: 123
    """, Person)
    assert value == {"name": "123"}
    assert errors[0].code == "invalid_type"
    assert errors[0].position.column_no == 10

    value, errors = validate_yaml(b"""
        foo: 123
    """, Person)
    assert value is None
    assert errors[0].code == "missing"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no

# Generated at 2022-06-24 11:12:08.298114
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = fields.String(required=True)
        age = fields.Integer(min_value=0, max_value=150)

    content = """
    name: John
    age: "-10"
    """

    value, error_messages = validate_yaml(content, validator=Person)
    assert error_messages == [
        Message(code="invalid_type", text="Must be an integer.", position=None),
    ]

# Generated at 2022-06-24 11:12:15.828004
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test to validate the YAML is been validated properly or not
    """
    content = "username: test1\nage: 10\nsex: male\n"
    validator = Schema.from_dict(
        {
            "username": fields.String(),
            "age": fields.Number(),
            "sex": fields.String(enum=["male", "female"]),
        }
    )
    v = validate_yaml(content, validator)
    expected_value = {
        "username": "test1",
        "age": 10,
        "sex": "male",
    }
    assert v == (expected_value, [])



# Generated at 2022-06-24 11:12:20.020453
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("no_map_or_list") == "no_map_or_list"
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_yaml("""
foo: bar
""") == {'foo': 'bar'}



# Generated at 2022-06-24 11:12:30.037167
# Unit test for function validate_yaml
def test_validate_yaml():
    # Validation of a str
    assert validate_yaml('{"foo":"bar"}', Field(type=str))[0] == {"foo": "bar"}

    # Validation of an int
    assert validate_yaml('{"foo":"bar"}', Field(type=int))[0] == "bar"

    try:
        validate_yaml('{"foo":"bar"}', Field(type=str))
    except ValidationError:
        pass
    else:
        assert False

    # Validation of a list
    assert validate_yaml('[{"foo":"bar"}]', Field(type=list))[0] == [{"foo": "bar"}]

    try:
        validate_yaml('[{"foo":"bar"}]', Field(type=str))
    except ValidationError:
        pass
    else:
        assert False



# Generated at 2022-06-24 11:12:36.802228
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field()
    value, errors = validate_yaml(b"123", validator)
    assert value == 123
    assert errors == []

    validator = Field(required=True)
    value, errors = validate_yaml(b"123", validator)
    assert value == 123
    assert errors == []

    validator = Field(type=int, minimum=4)
    value, errors = validate_yaml(b"123", validator)
    assert value == 123
    assert errors == [
        ValidationError(
            text="Must be greater than or equal to 4.", code="min_value", position=Position(column_no=1, line_no=1, char_index=0)
        )
    ]

    validator = Field(type=int, minimum=4)
    value, errors = validate_y

# Generated at 2022-06-24 11:12:45.697020
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_str = """
        name: 'John'
        age: 0
        address:
            street: '123 Main St.'
            city: 'Centerville'
            state: 'CA'
            zip: 90210
        """

    class PersonSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer(min_value=0)
        address = fields.Dictionary(
            properties={
                "state": fields.String(max_length=2),
                "zip": fields.String(max_length=5),
                "street": fields.String(),
                "city": fields.String(),
            }
        )

    value, messages = validate_yaml(yaml_str, validator=PersonSchema)

# Generated at 2022-06-24 11:12:55.494074
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content_yaml = """
    - greeting: "hello"
      count: 1
      extra: null
    - greeting: "goodbye"
      count: ["a", "b", "c"]
      extra: "d"
    """
    token = tokenize_yaml(content_yaml)
    assert len(token.value) == 2
    assert len(token.value[0].value) == 3
    assert token.value[0].value["count"].value == 1
    assert len(token.value[1].value) == 3
    assert len(token.value[1].value["count"].value) == 3
    assert token.value[1].value["count"].value[0].value == "a"


# Generated at 2022-06-24 11:13:05.329472
# Unit test for function validate_yaml
def test_validate_yaml():
    class User(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True)

    class Users(Schema):
        users = fields.List(fields.Schema(User))

    data = """
        users:
          - name: Bob
            age: 10
          - name: Alice
            age: 23
          - name: Geraldine
            age: 'invalid'
    """
    value, errors = validate_yaml(data, Users)

# Generated at 2022-06-24 11:13:09.182274
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    value:
    - item: 1
    - item: 2
    """
    token = tokenize_yaml(content)
    assert token.content == content
    assert token["value"][0]["item"] == 1

# Generated at 2022-06-24 11:13:17.990037
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml

    class ListItem(Schema):
        value = Integer()
        key = String()

    class List(Schema):
        items = Array(items=ListItem(max_length=2))

    content = yaml.dump({"items": [{"value": 10, "key": "ten"}]}).encode("utf-8")

    assert validate_yaml(content, validator=List)
    content = yaml.dump({"items": [{"value": 3}]}).encode("utf-8")
    assert not validate_yaml(content, validator=List)



# Generated at 2022-06-24 11:13:26.021925
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = (
        "a: 1\n"
        "b:\n"
        "   - 2\n"
        "   - 3\n"
        "c: true\n"
        "d: null\n"
        "e: 3.1415\n"
        "f:\n"
        "   name: Steve\n"
        "   friends: Mike\n"
    )
    token = tokenize_yaml(content)
    assert token["a"].value == 1
    assert token["b"][0].value == 2
    assert token["d"].value == None
    assert token["e"].value == pytest.approx(3.1415)
    assert token["f"]["name"].value == "Steve"


# Generated at 2022-06-24 11:13:28.611442
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: bob\n"
    Schema = validate_yaml(content, Field("name"))
    assert isinstance(Schema, list)


# Generated at 2022-06-24 11:13:36.144513
# Unit test for function validate_yaml
def test_validate_yaml():
  assert validate_yaml(
        """
        admin:
            name: John Doe
            email: john.doe@example.com
        """,
        typing.Dict[str, typing.Dict[str, str]],
    ) == ({'admin': {'name': 'John Doe', 'email': 'john.doe@example.com'}}, [])


# Generated at 2022-06-24 11:13:42.924835
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Successful tokenization
    token = tokenize_yaml('["name", 1, False, {"x": 1}]')
    assert isinstance(token, ListToken)
    assert token.value == ["name", 1, False, {"x": 1}]

    # Unsuccessful tokenization
    content = "name, 1, False, {"
    position = Position(line_no=1, column_no=12, char_index=11)
    with pytest.raises(ParseError) as e:
        tokenize_yaml(content)
    assert str(e.value) == "No content."
    assert e.value.position == position



# Generated at 2022-06-24 11:13:55.597786
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
twint:
  username: test_username
  search_query:
    - "a"
    - "b"
    - "c"
    - ["a", "b", "c"]
    - [a, b, c]
"""

    validator = Schema(
        {"twint": {"username": str, "search_query": [str]}})
    token = tokenize_yaml(content)

    # test tokenize
    assert isinstance(token, DictToken)
    assert isinstance(token.value["twint"]["username"], ScalarToken)
    assert isinstance(token.value["twint"]["search_query"], ListToken)
    assert isinstance(token.value["twint"]["search_query"][0], ScalarToken)

# Generated at 2022-06-24 11:13:58.754131
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml('first: last'), DictToken)

# Generated at 2022-06-24 11:14:08.183097
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Test the tokenize_yaml() function.

    Test that inputs containing the following cases
    pass without raising exceptions:
    - Whitespace only (whitespace strings, strings containing just newlines)
    - Comments
    - Escaped newlines
    - Inline collection indicators
    - Indented block sequences
    - Scalar values
    """
    # Test whitespace only strings.
    assert tokenize_yaml(" ").value == ""
    assert tokenize_yaml("\n\n").value == ""
    assert tokenize_yaml("  \n  \n  ").value == ""
    assert tokenize_yaml("  \n\n \n \n\n   ").value == ""
    assert tokenize_yaml("  \n  \n  ").item_indices == [0, 2]
   

# Generated at 2022-06-24 11:14:09.818265
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('test') == {'test': None}

# Generated at 2022-06-24 11:14:20.577467
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""a:
    - 1
    - 2
    - 3
b:
    c: d

e: f
g: h
""")
    assert token == {'a': [1, 2, 3], 'b': {'c': 'd'}, 'e': 'f', 'g': 'h'}

if __name__ == '__main__':
    token = tokenize_yaml("""a:
    - 1
    - 2
    - 3
b:
    c: d

e: f
g: h
""")
    assert token == {'a': [1, 2, 3], 'b': {'c': 'd'}, 'e': 'f', 'g': 'h'}

# Generated at 2022-06-24 11:14:26.950470
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    with pytest.raises(AssertionError):
        tokenize_yaml({"a": 1, "b": 2})
    assert tokenize_yaml(b'a: 1\nb: 2\n') == {"a": 1, "b": 2}
    assert tokenize_yaml('a: 1\nb: 2\n') == {"a": 1, "b": 2}
    assert tokenize_yaml(b'\xa1\xa2\n') == None
    assert tokenize_yaml('') == None
    with pytest.raises(ParseError):
        tokenize_yaml('  ')


# Generated at 2022-06-24 11:14:34.248293
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert issubclass(type(tokenize_yaml("")), DictToken)
    assert issubclass(type(tokenize_yaml("{}")), DictToken)
    assert issubclass(type(tokenize_yaml("key: value")), DictToken)
    assert issubclass(type(tokenize_yaml("key: - value")), DictToken)
    assert issubclass(type(tokenize_yaml("key: [value]")), DictToken)
    assert issubclass(type(tokenize_yaml("[value]")), ListToken)
    assert issubclass(type(tokenize_yaml("- value")), ListToken)

if __name__ == "__main__":
    test_tokenize_yaml()

# Generated at 2022-06-24 11:14:42.716598
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_str = '''\
            foo: 123
            bar:
              - baz
              - biz: 123
            '''

    assert yaml is not None, "'pyyaml' must be installed."

    token = tokenize_yaml(yaml_str)
    assert isinstance(token, Token)
    assert token.get_child(["foo"]).get_value() == 123
    assert token.get_child(["bar", 1, "biz"]).get_value() == 123
    from typesystem.tokenize.tokens import (
        Token,
        DictToken,
        ListToken,
        ScalarToken,
    )
    assert isinstance(token, Token)
    assert isinstance(token.get_child(["foo"]), ScalarToken)

# Generated at 2022-06-24 11:14:53.660457
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(name="test", type="str")
    assert validate_yaml(b"test", field) == ("test", None)

    field = Field(name="test", type="int")
    assert validate_yaml(b"123", field) == (123, None)

    field = Field(name="test", type="int")
    result, errors = validate_yaml(b"foo", field)
    assert errors[0].text == "The value of field 'test' must be of type int."

    field = Field(name="test", type="str", enum=["a", "b"])
    assert validate_yaml(b"a", field) == ("a", None)

    field = Field(name="test", type="str", enum=["a", "b"])

# Generated at 2022-06-24 11:15:05.418459
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    result_name:
      - name: "result_0"
        value: 0
      - name: "result_1"
        value: 1
    """
    schema = Schema(
        {"result_name": Field(items=[{"name": str, "value": int}], many=True)}
    )
    result, error_message = validate_yaml(content, schema)

    expected_result = {
        "result_name": [
            {"name": "result_0", "value": 0},
            {"name": "result_1", "value": 1},
        ]
    }
    assert result == expected_result
    assert error_message is None


# Generated at 2022-06-24 11:15:14.173961
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert validate_yaml("23", Field(typ=int)) == (23, [])
    assert isinstance(validate_yaml("23", Field(typ=str))[0], str)
    assert validate_yaml("23", Field(typ=str)) == ("23", [])
    assert validate_yaml("test", Field(typ=str)) == ("test", [])
    assert validate_yaml("test", Field(typ=int)) == ("test", [])
    assert validate_yaml("test", Field(typ=float)) == ("test", [])

# Generated at 2022-06-24 11:15:16.251711
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("{}", Dict()) == (
        {},
        [],
    )

# Generated at 2022-06-24 11:15:18.204636
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content=b"foo: bar", validator=Field(type="string"))

# Generated at 2022-06-24 11:15:22.849855
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('{"a":"1"}') == DictToken({"a": "1"}, 0, 7)
    assert tokenize_yaml('[1, 2, 3]') == ListToken([1, 2, 3], 0, 8)


# Generated at 2022-06-24 11:15:33.729877
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    yaml_str = """
    - 1
    - 2
    - 3
    """
    assert isinstance(tokenize_yaml(yaml_str), ListToken)
    assert len(tokenize_yaml(yaml_str).value) == 3
    assert isinstance(tokenize_yaml(yaml_str).value[0], ScalarToken)
    assert tokenize_yaml(yaml_str).value[0].value == 1
    assert isinstance(tokenize_yaml(yaml_str).value[1], ScalarToken)
    assert tokenize_yaml(yaml_str).value[1].value == 2
    assert isinstance(tokenize_yaml(yaml_str).value[2], ScalarToken)
   

# Generated at 2022-06-24 11:15:36.440516
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(b"foo: 'bar'\n")
    assert token == {'foo': 'bar'}



# Generated at 2022-06-24 11:15:44.854895
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == []
    assert tokenize_yaml("true") == [True]
    assert tokenize_yaml("---\n- 2\n- 2\n- 2") == [[2, 2, 2]]
    assert tokenize_yaml("2") == [2]
    assert tokenize_yaml("- 2") == [[2]]
    assert tokenize_yaml("- 2.3") == [[2.3]]
    assert tokenize_yaml("- 2.3e-4") == [[2.3e-4]]

# Generated at 2022-06-24 11:15:47.321022
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: Alice Cohen\n" + "address: 123 Main Street, Palo Alto"
    field = typing.Dict[str, str]
    value, messages = validate_yaml(content, field)
    assert value == {"name": "Alice Cohen", "address": "123 Main Street, Palo Alto"}

# Generated at 2022-06-24 11:15:55.228687
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "hello: world\nbeep: boop"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"hello": "world", "beep": "boop"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = 'key: "beep\\nboop"'
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"key": "beep\nboop"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = "name: [\"beep\", \"boop\"]"
    token = tokenize_

# Generated at 2022-06-24 11:16:02.060775
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    token = tokenize_yaml(
        """
        first_name: "Alice"
        last_name: "Akagi"
        age: 18
        """
        )

    assert token.type == "dict"
    assert token.len == 3
    assert token.get("first_name").value == "Alice"
    assert token.get("last_name").value == "Akagi"
    assert token.get("age").value == 18


# Generated at 2022-06-24 11:16:09.631576
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    first_name:
    - John
    - Mary
    last_name: Smith
    """)
    assert isinstance(token.value, dict)
    assert token.value == {
        "first_name": ["John", "Mary"],
        "last_name": "Smith"
    }
    assert token.start == 0
    assert token.end == 52
    assert token.content == """
    first_name:
    - John
    - Mary
    last_name: Smith
    """



# Generated at 2022-06-24 11:16:17.294898
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem import Schema, fields
    from typesystem.validators import MaxLength, MinLength

    class TestSchema(Schema):
        """
        Wiki example for nested dict
        """
        first_name = fields.String(validators=[MinLength(1), MaxLength(255)])
        last_name = fields.String(validators=[MinLength(1), MaxLength(255)])

    yaml_data = '{{first_name: "John", last_name: "Doe"},  {first_name: "John", last_name: "Doe"}}'

    try:
        value, error_messages = validate_yaml(yaml_data, TestSchema())
    except ValidationError as exc:
        error_messages = exc.messages

# Generated at 2022-06-24 11:16:22.601429
# Unit test for function validate_yaml
def test_validate_yaml():
    class YAMLSchema(Schema):
        name = String(required=True)

        tags = String(required=True)
        tags2 = String(required=True)
        tags3 = String(required=True)

    yaml_string = """
    name: Roger
    tags: Taco
    tags2: Pizza
    tags3: Sushi
    """

    assert YAMLSchema().validate_yaml(yaml_string)



# Generated at 2022-06-24 11:16:31.751928
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Dict, String, Integer

    class UserSchema(Schema):
        username = String(format="email")
        age = Integer(minimum=0)

    data = b"username: alice@example.com\nage: 26"
    result = validate_yaml(data, validator=UserSchema)
    assert result == ({
        "username": "alice@example.com",
        "age": 26
    }, [])

    data = b"username: alice\nage: 26"
    result = validate_yaml(data, validator=UserSchema)

# Generated at 2022-06-24 11:16:37.654752
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    print(str(tokenize_yaml("""'hello': world""")))

    print(str(tokenize_yaml("""
    - 86
    - 256
    - 0x100
    - 0X100
    - 0o100
    - 0O100
    - 0b100
    - 0B100
    """)))

# Generated at 2022-06-24 11:16:44.666129
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Array
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        array = Array(items=Array(items=True))

    validator = TestSchema()

    # test parse error
    invalid_content = ":"
    with pytest.raises(ParseError) as exc:
        validate_yaml(content=invalid_content, validator=validator)
    assert exc.value.code == "parse_error"
    assert exc.value.position.char_index == 0
    assert exc.value.position.line_no == 1
    assert exc.value.position.column_no == 1

    # test validation error
    invalid_content = "[[], 'foo']"

# Generated at 2022-06-24 11:16:54.763676
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        x = Float()
        y = Float()
        z = Float()
        r = Float()

    validator = MySchema()
    content = """
    x: 1.0
    y: 2.0
    z: 3.0
    r: 4.0
    """
    expected = {
        "x": 1.0,
        "y": 2.0,
        "z": 3.0,
        "r": 4.0,
    }
    actual, errors = validate_yaml(content, validator)
    assert errors == []
    assert actual == expected

    content = """
    x: "foo"
    y: 2.0
    z: 3.0
    r: 4.0
    """
    expected = "value must be a float"
   

# Generated at 2022-06-24 11:17:03.559298
# Unit test for function validate_yaml
def test_validate_yaml():
    with pytest.raises(ParseError) as exc_info:
        validate_yaml(content="", validator=Integer(format="int32"))
    assert (
        'Parse error at position (line_no: 1, column_no: 1, char_index: 0): No content.'
        == exc_info.value.detail
    )

    with pytest.raises(ParseError) as exc_info:
        validate_yaml(
            content="""
        a:
          b: "foo"
          c:
            - 1
            - 2
        """,
            validator=Integer(format="int32"),
        )

# Generated at 2022-06-24 11:17:13.941716
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken(mapping={}, start=0, end=1)
    assert tokenize_yaml("[]") == ListToken(value=[], start=0, end=1)
    assert tokenize_yaml('"string"') == ScalarToken('string', start=0, end=7)
    assert tokenize_yaml("42") == ScalarToken(42, start=0, end=1)
    assert tokenize_yaml("-42") == ScalarToken(-42, start=0, end=2)
    assert tokenize_yaml("3.14") == ScalarToken(3.14, start=0, end=3)
    assert tokenize_yaml(".14") == ScalarToken(.14, start=0, end=2)
    assert tokenize_

# Generated at 2022-06-24 11:17:18.349175
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test for string with extra white spaces
    user_string1 = "name:     Rishi "
    assert tokenize_yaml(user_string1) == {'name': 'Rishi'}

    # Test for a valid string
    user_string2 = """name: Rishi
    age: 18"""
    assert tokenize_yaml(user_string2) == {'name': 'Rishi', 'age': 18}


# Generated at 2022-06-24 11:17:21.677438
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    from typesystem.schemas import Schema
    class Person(Schema):
        name=String()

    value, errors = validate_yaml("name", Person)
    assert value == {'name': ''}

# Generated at 2022-06-24 11:17:28.211156
# Unit test for function validate_yaml
def test_validate_yaml():
    # Tests should pass
    content_list = [
        '{"name": "johann", "age": "21", "is_programmer": True}', # passed
        '{"foo": "bar", "boo": "baz"}', # passed
        '{"what do you do?": "I am a student"}', # passed
        '{"what do you do?": "I am a student", "age": "21"}', # passed
        '{"foo": "bar", "baz": 42}', # passed
    ]
    for content in content_list:
        value, error_messages = validate_yaml(content, )
        assert error_messages == []

    # Tests should fail, should return a list of error messages

# Generated at 2022-06-24 11:17:36.867706
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """\
    - foo
    - bar
    - baz
    """
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert token.value == ["foo", "bar", "baz"]
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"foo": "bar"}'
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content



# Generated at 2022-06-24 11:17:45.454925
# Unit test for function validate_yaml
def test_validate_yaml():
    class YAMLSchema(Schema):
        title = Field(type="string")
        company = Field(type="string")
        skills = Field(type="array", items=Field(type="string"))

    content = """
    title: Data Scientist
    company: Starfish
    skills:
        - python
        - machine learning
        - statistics
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    value, error_messages = validate_with_positions(
        token=token, validator=YAMLSchema
    )
    assert value.title == "Data Scientist"
    assert value.company == "Starfish"
    assert value.skills == ["python", "machine learning", "statistics"]
    assert error_messages is None



# Generated at 2022-06-24 11:17:52.031886
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class MySchema(Schema):
        name = String()
        favorite_number = String()

    errors = validate_yaml("foo: bar\nfavorite_number: 3", MySchema)
    assert not errors

    errors = validate_yaml("foo: bar", MySchema)
    assert errors



# Generated at 2022-06-24 11:17:58.229245
# Unit test for function validate_yaml
def test_validate_yaml():

    #test with data in single quotes
    inputData = "{'a': 1}"
    schema = typesystem.Schema(properties={"a": typesystem.Integer(minimum=2)})
    value, error = validate_yaml(inputData, schema)

    #validate error
    assert error[0].code == "minimum" and error[0].position.column_no == 5

    #test with data in double quotes
    inputData = '{"a": 1}'
    schema = typesystem.Schema(properties={"a": typesystem.Integer(minimum=2)})
    value, error = validate_yaml(inputData, schema)

    #validate error
    assert error[0].code == "minimum" and error[0].position.column_no == 5

    #test with nested data

# Generated at 2022-06-24 11:18:01.620660
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b'{"a": "b"}'
    validator = Schema(fields={"a": Field(type="string")})
    value, errors = validate_yaml(content, validator)
    assert value == {"a": "b"}
    assert errors == []

# Generated at 2022-06-24 11:18:11.836971
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Dict, Boolean

    schema = Dict(fields={
        "foo": String(required=True),
        "bar": Integer(default=42),
        "baz": Boolean(),
    })

    content = textwrap.dedent(
        """
    foo: abc
    bar: 42
    baz: true
    """
    )
    value, error_messages = validate_yaml(content, validator=schema)
    assert value == {"foo": "abc", "bar": 42, "baz": True}
    assert error_messages == []

    content = textwrap.dedent(
        """
    bar: true
    """
    )
    value, error_messages = validate_yaml(content, validator=schema)
    assert value is None

# Generated at 2022-06-24 11:18:14.683663
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    field = String("name")
    value, errors = validate_yaml("name: tom", field)
    assert value == "tom"
    assert errors == []



# Generated at 2022-06-24 11:18:18.846159
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = String()

    errors = validate_yaml("not YAML", PersonSchema)
    assert len(errors) == 1
    error = errors[0]
    assert error.code == "parse_error"
    assert error.text == "unexpected character."
    assert error.position.line_no == 1
    assert error.position.column_no == 1
    assert error.position.char_index == 1


# Generated at 2022-06-24 11:18:21.064285
# Unit test for function validate_yaml
def test_validate_yaml():
    data=validate_yaml(
        content="",
        validator=Schema
    )
    assert isinstance(data[1], Message)

# Generated at 2022-06-24 11:18:31.008488
# Unit test for function validate_yaml
def test_validate_yaml():
    str_content = """
    a: 1
    b: "2"
    c: True    
    d: 
        - 1
        - 2
        - 3
    """

    value, errors = validate_yaml(str_content, validator={"a": int, "b": str, "c": bool, "d": [int]})
    assert value == {"a": 1, "b": "2", "c": True, "d": [1, 2, 3]}
    assert errors == []

    str_content = """
    - 1
    - 2
    - 3
    """

    value, errors = validate_yaml(str_content, validator=[int])
    assert value == [1, 2, 3]
    assert errors == []


# Generated at 2022-06-24 11:18:40.929664
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(b"", 'int()') == (0, None)
    assert validate_yaml(b"", 'int(max_value=5)') == (0, None)
    assert validate_yaml(b"", 'int(min_value=5)') == (5, None)
    assert validate_yaml(b"", 'str()') == ('', None)

    assert validate_yaml(b"\n  - 5", 'list_of(int(min_value=5))') == ([5], None)
    assert validate_yaml(b"\n  - 5", 'list_of(int())') == ([5], None)

# Generated at 2022-06-24 11:18:43.296727
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    parse_result = tokenize_yaml('{"key": "value"}')
    assert isinstance(parse_result, DictToken)
    assert parse_result.value == {'key': 'value'}


# Generated at 2022-06-24 11:18:49.519807
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import validators

    Field = validators.String()
    MESSAGE = 'Line 1, Column 1\nExpected a string, but got 1'

    # test case 1: valid content
    content = '''
            string: "abc"
            int: 1.0
            float: 1.0
            bool: true
            null: null
        '''
    token = tokenize_yaml(content)
    value, error_msg = validate_with_positions(token, Field)
    assert not error_msg, 'should not have error message'

    # test case 2: invalid content
    content = '''
            int: 1
            float: 1.0
            bool: true
            null: null
        '''
    token = tokenize_yaml(content)
    value, error_msg = validate_

# Generated at 2022-06-24 11:18:56.028717
# Unit test for function validate_yaml
def test_validate_yaml():
    # given
    content = "foo: 1"
    validator = Field(type="string")

    # when
    try:
        validate_yaml(content, validator)

    # then
    except ValidationError as e:
        assert e.messages == [
            Message(
                text="Should be of type 'string'.",
                code="type_error.string",
                position=_get_position(content, index=5),
            )
        ]

# Generated at 2022-06-24 11:19:05.838432
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test the case of empty string.
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml("")
    assert str(excinfo.value) == 'Parse error at line 1, column 1: No content.'
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.char_index == 0

    # Test the simple case of the string "hello world"
    token = tokenize_yaml("hello world")
    assert isinstance(token, ScalarToken)
    assert token.value == "hello world"
    assert token.start == 0
    assert token.end == 10
    assert token.content == "hello world"
    assert token.position.line_no == 1

# Generated at 2022-06-24 11:19:12.530880
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("{}")
    assert isinstance(token, DictToken)
    assert token.key_value_pairs == {}
    assert token.start_index == 0
    assert token.end_index == 1

    token = tokenize_yaml("{'key': 'value'}")
    assert isinstance(token, DictToken)
    assert token.key_value_pairs == {"key": "value"}
    assert token.start_index == 0
    assert token.end_index == 15

    token = tokenize_yaml("[True, False]")
    assert isinstance(token, ListToken)
    assert token.items == [True, False]
    assert token.start_index == 0
    assert token.end_index == 15


# Generated at 2022-06-24 11:19:24.324445
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Empty string case
    with pytest.raises(ParseError):
        tokenize_yaml("")
    # Non-empty string cases
    assert tokenize_yaml("a: b") == {'a': 'b'}
    assert tokenize_yaml("a: b\nc: d") == {'a': 'b', 'c': 'd'}
    assert tokenize_yaml("a:\n - b\n - c") == {'a': ['b', 'c']}
    assert tokenize_yaml("a:\n - b:\n    - c\n    - d") == {'a': {'b': ['c', 'd']}}
    assert tokenize_yaml("a: 1") == {'a': 1}

# Generated at 2022-06-24 11:19:32.850277
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    ---
    key1: value1
    key2: value2
    key3: value3
    """

    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert len(token.items) == 3
    assert token.items[0].key == "key1"
    assert token.items[0].value.value == "value1"
    assert token.items[1].key == "key2"
    assert token.items[1].value.value == "value2"
    assert token.items[2].key == "key3"
    assert token.items[2].value.value == "value3"



# Generated at 2022-06-24 11:19:36.642390
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - foo
    - bar
    """
    field = typing.List(typing.String)
    value, errors = validate_yaml(content, field)
    assert value == ["foo", "bar"]
    assert errors == []



# Generated at 2022-06-24 11:19:43.746747
# Unit test for function validate_yaml
def test_validate_yaml():
    # testing simple field
    validator = Field(field_type="str")
    content = "test"
    _, error_messages = validate_yaml(validator=validator, content=content)
    assert len(error_messages) == 0

    # testing simple nested field
    validator = Field(
        field_type="list",
        sub_field=Field(
            field_type="list", sub_field=Field(field_type="int", min_value=5)
        ),
    )
    content = "[[5, 6], [5,5]]"
    _, error_messages = validate_yaml(validator=validator, content=content)
    assert len(error_messages) == 3

    # testing simple nested field

# Generated at 2022-06-24 11:19:50.136103
# Unit test for function validate_yaml
def test_validate_yaml():
    # Create a very simple schema for testing.
    class BadSchema(Schema):
        # This field is optional, but must be of type "dict"
        test_field = Field(required=False, type_=dict)

    example = (
        "---\n"
        "test_field: 42\n"
        "  test_field:\n"
        "    - foo: bar\n"
        "    - baz: garply\n"
    )

    # Test with a Schema class
    value, messages = validate_yaml(content=example, validator=BadSchema)
    assert messages == []
    assert value == {
        "test_field": [
            {"foo": "bar"},
            {"baz": "garply"},
        ]
    }

    # Test with a Field instance
    value

# Generated at 2022-06-24 11:19:54.265702
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = "string"

    content = b"""\
    name: "John Doe"
    """

    value, error_messages = validate_yaml(content=content, validator=Person)

    assert value == {"name": "John Doe"}
    assert error_messages == []



# Generated at 2022-06-24 11:20:01.601879
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = String()

    content = "name: foo"
    value, messages = validate_yaml(content, MySchema)

    assert value == {"name": "foo"}
    assert messages == []

    assert validate_yaml(b"\nname: foo", MySchema) == ({"name": "foo"}, [])

    content = "name: 1"
    value, messages = validate_yaml(content, MySchema)

    assert value == {"name": "1"}
    assert len(messages) == 1
    assert messages[0].code == "invalid_type"
    assert messages[0].path == "name"
    assert messages[0].position.line_no == 1
    assert messages[0].position.char_index == 5


# Generated at 2022-06-24 11:20:05.440600
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""
        name: John
        age: 25
        title: Engineer
        """

    class Person(Schema):
        name = String
        age = Integer
        title = String

    value, messages = validate_yaml(content, Person)



# Generated at 2022-06-24 11:20:15.386028
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    b: hello
    c:
        - 1
        - 2
    """

    class ValidateSchema(Schema):
        a = Field(int, nullable=False)
        b = Field(str, nullable=False)
        c = Field([int], nullable=False)

    validate_result = validate_yaml(content, ValidateSchema)
    assert len(validate_result.errors) == 0, "Validate error: " + str(
        validate_result.errors
    )
    assert isinstance(validate_result.value, dict), "Validate value is not a dict."
    assert "a" in validate_result.value, "Validate result has no a element."

# Generated at 2022-06-24 11:20:21.825869
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('12') == ScalarToken(12, 0, 1, content='12')
    assert tokenize_yaml('[12, 13]') == ListToken([12, 13], 0, 5, content='[12, 13]')
    assert tokenize_yaml('{a: 12, b: 13}') == DictToken({'a': 12, 'b': 13}, 0, 11, content='{a: 12, b: 13}')


# Generated at 2022-06-24 11:20:31.185925
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('foo: 1', {'foo': int})[1][0].code == 'parse_error'
    assert validate_yaml('foo: 1\r', {'foo': int})[1][0].code == 'parse_error'
    assert validate_yaml('foo: 1\r', {'foo': int})[1][1].code == 'unexpected_character'
    assert validate_yaml('foo: 1', {'foo': int})[1][1].code == 'unexpected_character'
    assert validate_yaml('foo: 1', {'foo': int})[1][1].char_index == 4
    assert validate_yaml('foo: 1\n', {'foo': int})[1][0].char_index == 4

# Generated at 2022-06-24 11:20:37.039684
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(type="string", min_length=2, max_length=5)
    value, errors = validate_yaml(field, "123")
    assert value == "123"
    assert not errors

    value, errors = validate_yaml(field, "")
    assert errors[0] == ValidationError(text="Must be at least 2 characters.", code="min_length")

# Generated at 2022-06-24 11:20:41.758338
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - {name: john doe, age: 10}
    - {name: jane doe, age: 9}
    """
    validator = Schema([{"name": str, "age": int}])
    value, error_messages = validate_yaml(content, validator)
    validator(value)
    assert value == [{"name": "john doe", "age": 10}, {"name": "jane doe", "age": 9}]



# Generated at 2022-06-24 11:20:44.045602
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('test: "validate"')
    assert isinstance(token, DictToken) and list(token.keys()) == ['test'] and token['test'] == "validate"

