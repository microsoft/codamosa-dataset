

# Generated at 2022-06-24 11:10:47.094654
# Unit test for function validate_yaml
def test_validate_yaml():
    class RegistrySchema(Schema):
        registry_name = Field(type="string")
        registry_namespace = Field(type="string")
        registry_url = Field(type="string")
        registry_username = Field(type="string")
        registry_password = Field(type="string")
        registry_email = Field(type="string")
        registry_type = Field(type="string")

    yaml_string = '''
registry_name:
registry_namespace:
registry_url:
registry_username:
registry_password:
registry_email:
'''

# Generated at 2022-06-24 11:10:56.528748
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.schemas import Schema, fields

    class PetSchema(Schema):
        name = fields.String(max_length=20)
        owner = fields.String(max_length=20)

    yaml_pet_schema = '''\
    type: object
    properties:
      name:
        type: string
        maxLength: 20
      owner:
        type: string
        maxLength: 20
    '''

    token1 = tokenize_yaml(yaml_pet_schema)
    token2 = PetSchema.tokenize()

    def assert_equal(token1, token2):
        assert type(token1) == type(token2)

# Generated at 2022-06-24 11:11:06.721686
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # Test scalar
    assert tokenize_yaml("10") == ScalarToken(10, 0, 1, content="10")
    assert tokenize_yaml("10.0") == ScalarToken(10.0, 0, 3, content="10.0")
    assert tokenize_yaml("1e5") == ScalarToken(1e5, 0, 3, content="1e5")
    assert tokenize_yaml("1E5") == ScalarToken(1E5, 0, 3, content="1E5")
    assert tokenize_yaml("1.2e5") == ScalarToken(1.2e5, 0, 5, content="1.2e5")

# Generated at 2022-06-24 11:11:15.608782
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """- a:
      - b:
        - c: 1
        - c: 2
      - b:
        - c: 3
        - c: 4
    - a:
      - b:
        - c: 5
        - c: 6
      - b:
        - c: 7
        - c: 8
    """
    token = tokenize_yaml(content)
    assert token.token_type == "dict"
    assert token.value == [
        {"a": [{"b": [{"c": 1}, {"c": 2}]}, {"b": [{"c": 3}, {"c": 4}]}]},
        {"a": [{"b": [{"c": 5}, {"c": 6}]}, {"b": [{"c": 7}, {"c": 8}]}]},
    ]

# Generated at 2022-06-24 11:11:26.745719
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    content = """
a: 1
b: 2
c:
  d: 3
  e: 4
  f:
    - 5
    - 6
    -
      g: 7
      h:
      - 8
      - 9
      -
        i: 10
        j: 11
  k:
    - 12
    - 13
    -
      l: 14
      m: 15
      n:
        - 16
      o:
      - 17
      - 18
p: 19
q:
- 20
- 21
-
  - 22
  - 23
  -
    - 24
    - 25
    -
      - 26
"""

    result = tokenize_yaml(content)


# Generated at 2022-06-24 11:11:30.150487
# Unit test for function validate_yaml
def test_validate_yaml():
    class YType(types.Schema):
        x = types.String()

    text = u'x: "hello"'
    result, messages = validate_yaml(text, YType)
    print("errors: %s" % messages)

    assert result is not None
    assert len(messages) == 0


# Generated at 2022-06-24 11:11:38.101967
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Tokenize a string and return the tokens
    content = "---\n- one\n- two\n- three\n"
    result = tokenize_yaml(content)
    # Check if the result has a list token at index 0
    assert(isinstance(result[0], ListToken))
    # Check if the result has another list token at index 0.0
    assert(isinstance(result[0][0], ListToken))
    # Check if the result has a scalar token at index 0.1
    assert(isinstance(result[0][1], ScalarToken))
    # Check if the result has another scalar token at index 0.2
    assert(isinstance(result[0][2], ScalarToken))
    # Check if the result has another scalar token at index 0.3

# Generated at 2022-06-24 11:11:48.047870
# Unit test for function validate_yaml
def test_validate_yaml():
    class User(Schema):
        first_name = String(max_length=10)
        last_name = String(max_length=10)

    content = """
    first_name: John
    last_name: Smith
    """
    result, error_messages = validate_yaml(content, User)
    assert error_messages == []
    assert result.first_name == "John"
    assert result.last_name == "Smith"

    content = """
    first_name: This is a very long name
    last_name: Smith
    """
    result, error_messages = validate_yaml(content, User)

# Generated at 2022-06-24 11:11:49.564708
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("test") == "test"


# Unit tests for function validate_yaml

# Generated at 2022-06-24 11:11:59.714790
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content1 = {"key1": ["value1", "value2"]}
    content2 = {"key1": ["value1", "value2"], "key2": "value3"}

    content1 = yaml.dump(content1)
    content2 = yaml.dump(content2)

    token1 = tokenize_yaml(content1)
    token2 = tokenize_yaml(content2)

    assert isinstance(token1, DictToken)
    assert isinstance(token2, DictToken)

    assert isinstance(token1.value["key1"], ListToken)
    assert isinstance(token2.value["key1"], ListToken)
    assert isinstance(token2.value["key2"], ScalarToken)

# unit test for function validate_yaml

# Generated at 2022-06-24 11:12:06.442211
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schema import Schema
    from typesystem.fields import String, Integer
    
    text = """
    id: 1
    name: "bob"
    """
    class Person(Schema):
        id = Integer()
        name = String()

    value, errors = validate_yaml(content=text, validator=Person)

    assert value == {"id": 1, "name": "bob"}
    assert len(errors) == 0



# Generated at 2022-06-24 11:12:15.379996
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema

    class Example(Schema):
        field1 = int

    class Nested(Schema):
        field1 = str
        field2 = int

    class NestedList(Schema):
        field1 = int
        field2 = [Nested]

    class MoreNesting(Schema):
        field1 = Nested
        field2 = [Example]

    token = tokenize_yaml("""\
field1: 1
field2: - 2
        - 2
        - 2
        - 2
""")
    assert token == {"field1": 1, "field2": [2, 2, 2, 2]}

    nested_token = tokenize_yaml("""\
    field1: foo
    field2: 2
""")

# Generated at 2022-06-24 11:12:21.229959
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('') == ''
    assert tokenize_yaml('text') == 'text'
    assert tokenize_yaml('""') == ''
    assert tokenize_yaml('"text"') == 'text'
    assert tokenize_yaml('10') == 10
    assert tokenize_yaml('10.1') == 10.1
    assert tokenize_yaml('true') == True
    assert tokenize_yaml('false') == False
    assert tokenize_yaml('null') == None
    assert tokenize_yaml('[1, 2]') == [1, 2]
    assert tokenize_yaml('{}') == {}
    assert tokenize_yaml('{"first": 1, "second": 2}') == {'first': 1, 'second': 2}



# Generated at 2022-06-24 11:12:31.174066
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # most of these tests are not needed since this is basically a wrapper
    # around yaml.safe_load() and we don't really want to test that
    # functionality as it is not something that was developed specifically
    # for typesystem.
    content = """
    # This is a comment.

    ---
    item1:
        - a
        - b
        - c
    item2:
        a: apple
        b: banana
        c: cherry
    item3:
        - 1
        - 2
        - 3
    item4: 123
    item5: true
    item6: null
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

    # Handling an empty string
    with pytest.raises(ParseError) as exc_info:
        tokenize

# Generated at 2022-06-24 11:12:39.430450
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == {}, "YAML parsing fails for an empty string"

    # Test for various valid YAML strings
    assert tokenize_yaml("{}") == DictToken({}, 0, 1), "YAML parsing fails for an empty dictionary"
    assert tokenize_yaml("[]") == ListToken([], 0, 1), "YAML parsing fails for an empty list"
    assert tokenize_yaml("{a: 1}") == DictToken({"a": ScalarToken(1,3,3, content="{a: 1}")}, 0, 7), "YAML parsing fails for a dictionary"

# Generated at 2022-06-24 11:12:44.072113
# Unit test for function validate_yaml
def test_validate_yaml():
    example = """
    name: Janice
    age: 24
    """

    class UserSchema(Schema):
        name = String(max_length=20)
        age = Integer()

    result = validate_yaml(example, UserSchema)

    print(result)
    # ( { 'name': 'Janice', 'age': 24 }, [] )

# Generated at 2022-06-24 11:12:46.663609
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")



# Generated at 2022-06-24 11:12:56.497987
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test_dict = {"a": 1, "b": 2}
    test_list = [3, 4]
    test_int = 5
    test_float = 6.0
    test_bool = True
    test_null = None

    content = "{a: 1, b: 2}\n- 3\n- 4\n5\n6.0\ntrue\nnull"
    result_dict = tokenize_yaml(content)

    assert result_dict.value == test_dict
    assert result_dict.content == content
    assert result_dict.start == 0
    assert result_dict.end == 14

    result_list = result_dict["b"]
    assert result_list.value == test_list
    assert result_list.content == content
    assert result_list.start == 15
    assert result_list.end

# Generated at 2022-06-24 11:13:00.865960
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    field = Field(type="boolean")
    token = tokenize_yaml(content=b"foo: true")
    value, error_messages = validate_with_positions(token=token, validator=Field)
    assert value == {'foo': True}
    assert not error_messages

# Generated at 2022-06-24 11:13:09.191402
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    token = tokenize_yaml('{"foo": "bar"}')
    assert token == DictToken(
        {"foo": ScalarToken("bar", 2, 9, content="{'foo': 'bar'}")},
        0,
        10,
        content="{'foo': 'bar'}",
    )

    token = tokenize_yaml('[1, 2, 3]')

# Generated at 2022-06-24 11:13:20.456363
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # YAML string
    yaml_str = """
        a: 1
        b:
          c: 2
        d:
          - 3
          - 4
          - 5
        """
    # Tokenized YAML string

# Generated at 2022-06-24 11:13:30.608995
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    assert tokenize_yaml("") == None
    assert tokenize_yaml(" [] ") == []
    assert tokenize_yaml(" {} ") == {}
    assert tokenize_yaml("'test'") == 'test'
    assert tokenize_yaml("'test '") == 'test '
    assert tokenize_yaml("'test\n'") == 'test\n'
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("-1") == -1
    assert tokenize_yaml("1.1") == 1.1
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("test:test1") == {'test': 'test1'}

# Generated at 2022-06-24 11:13:41.646812
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    hello: world
    1: banana
    2: apple
    """

    token = tokenize_yaml(content)
    assert token.content == content

    expected = {
        "hello": "world",
        "1": "banana",
        "2": "apple",
    }
    assert token.value == expected

    assert token.start_index == 1
    assert token.end_index == 42

    assert token.children[0].content == content
    assert token.children[0].name == "hello"
    assert token.children[0].start_index == 9
    assert token.children[0].end_index == 20

    assert token.children[1].content == content
    assert token.children[1].name == "1"
    assert token.children[1].start_index == 24
   

# Generated at 2022-06-24 11:13:50.615302
# Unit test for function validate_yaml
def test_validate_yaml():

    content = '''
    name: Bill
    age: 20
    notes:
        - hello
        - how are you
    '''

    expected_outputs = {'name': 'Bill', 'age': 20, 'notes': ['hello', 'how are you']}

    validator = Schema(fields={"name": str, "age": int, "notes": List(str)})
    res = validate_yaml(content, validator)
    assert res[0] == expected_outputs
    assert res[1] == []

# Generated at 2022-06-24 11:13:55.350958
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        name = fields.String(required=True)
        email = fields.String(required=True)

    UserSchema().validate({'name': 'test', 'email': 'test@test.com'})

    content = """
    name: test
    email: test@test.com
    """

    value, error_messages = validate_yaml(content, UserSchema())
    return error_messages


# Generated at 2022-06-24 11:14:05.876138
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # create a datafile with test data

    # place the datafile in a string
    with open("tests/test.yaml", "r") as file:
        test_data = file.read()

    # create a dict with correct answers
    correct_answers = {"a":1,
                       "b":2,
                       "c":3,
                       "d":4,
                       "e":5,
                       "f":6,
                       "g":7,
                       "h":8,
                       "i":9}

    # test the answers
    assert tokenize_yaml(test_data) == correct_answers

# unit test for function validate_yaml

# Generated at 2022-06-24 11:14:15.562204
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test that the validate_yaml function behaves as expected
    """
    from typesystem.base import TypeSystem, String

    content = "name: johndoe\n"

    # Test without error
    (value, error_messages) = validate_yaml(content, validator=String())
    assert value == "johndoe"
    assert len(error_messages) == 0

    class Person(TypeSystem):
        name = String(default="")

    # Test with error
    (value, error_messages) = validate_yaml(content, validator=Person())
    assert value == {}
    assert len(error_messages) == 1

# Generated at 2022-06-24 11:14:21.199045
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_content = """
        name: Steve
        age: 28
    """
    class User(Schema):
        name = String(max_length=100)
        age = Integer()

    value, errors = validate_yaml(yaml_content, User)
    assert value['name'] == 'Steve'
    assert value['age'] == 28
    assert errors == []



# Generated at 2022-06-24 11:14:25.696978
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = 'a: "1"'
    assert isinstance(tokenize_yaml(content), DictToken)
    assert tokenize_yaml(content).value["a"] == "1"
    assert tokenize_yaml(content).start_index == 0
    assert tokenize_yaml(content).end_index == len(content) - 1
    assert tokenize_yaml(content).content == content

# Generated at 2022-06-24 11:14:33.406666
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields
    from typesystem.fields import Integer
    from typing import Union

    class Person(Schema):
        name = fields.String()
        age = fields.Integer()

    # Success case
    content = '''
    name: jon snow
    age: 16
    '''
    person, errors = validate_yaml(content, Person)
    assert person == {"name": "jon snow", "age": 16}
    assert errors == []

    # Error case
    content = '''
    name: jon snow
    age: sixteen
    '''
    person, errors = validate_yaml(content, Person)
    assert isinstance(errors[0], ValidationError)
    assert errors[0].text == "Must be a valid integer."


# Generated at 2022-06-24 11:14:39.865867
# Unit test for function validate_yaml
def test_validate_yaml():
    class SimpleSchema(Schema):
        name = "SimpleSchema"
        fields = {
            "full_name": "str",
            "age": "int",
        }

    content = '''
        full_name: Arnold R. Palmer
        age: 87
    '''
    data, errors = validate_yaml(content, validator=SimpleSchema)

# Generated at 2022-06-24 11:14:51.190506
# Unit test for function validate_yaml
def test_validate_yaml():
    def _assert_valid(content: str, validator: typing.Union[Field, typing.Type[Schema]]):
        value = validate_yaml(content=content, validator=validator)
        assert value is None

    def _assert_invalid(
        content: str,
        validator: typing.Union[Field, typing.Type[Schema]],
        errors: typing.List[Message],
    ):
        value, messages = validate_yaml(content=content, validator=validator)
        assert value is None
        assert messages == errors

    class UserSchema(Schema):
        id = Integer()
        name = String()

    _assert_valid(content="""<
        id: 1
        name: Alice
        >""", validator=UserSchema)


# Generated at 2022-06-24 11:14:58.775353
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class User(Schema):
        id = Integer(maximum=999)
        name = String()

    data = {"id": 999, "name": "Chris"}
    result = validate_json(json.dumps(data), User)
    assert len(result.errors) == 0
    assert result.value == {"id": 999, "name": "Chris"}

    data = {"id": 1000, "name": "Chris"}
    result = validate_json(json.dumps(data), User)
    error = result.errors[0]
    assert error.text == "Ensure this value is less than or equal to 999."
    assert error.position == Position(line_no=1, column_no=11, char_index=10)

    data

# Generated at 2022-06-24 11:15:10.290141
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    # Valid value
    valid_value = b'age: 35\nname: Paul'
    value, errors = validate_yaml(valid_value, Person)
    assert errors == []

    # Invalid value
    invalid_value = b'age: 35\nname: "Paul"'
    value, errors = validate_yaml(invalid_value, Person)
    assert len(errors) == 1
    error = errors[0]
    assert isinstance(error, ValidationError)
    assert error.text == 'Must be of type "integer".'
    assert error.context["expected"] == "integer"
    assert error.context["got"] == "string"
    assert error.code == "invalid_type"
    position = error.position

# Generated at 2022-06-24 11:15:19.248911
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        variables:
           schema:
              type: record
              fields:
                 - { name: "count", type: "int" }
                 - { name: "max"  , type: "int" }
                 - { name: "names", type: "array", items: "string" }
           type: "object"
              """

    if yaml:
        class CustomSafeLoader(SafeLoader):
            pass

        def construct_mapping(loader: "yaml.Loader", node: "yaml.Node") -> DictToken:
            start = node.start_mark.index
            end = node.end_mark.index
            mapping = loader.construct_mapping(node)
            return DictToken(mapping, start, end - 1, content=content)


# Generated at 2022-06-24 11:15:24.002942
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    class TestSchema(Schema):
        name = String()
        age = Integer()
    s = TestSchema()
    s.validate(b"name: 1\nage: yaml")

# Generated at 2022-06-24 11:15:28.214907
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    content = '{"greeting": "hello world"}'
    assert tokenize_yaml(content) == {'greeting': 'hello world'}



# Generated at 2022-06-24 11:15:36.618810
# Unit test for function validate_yaml
def test_validate_yaml():
    # Successful parse and validation
    assert validate_yaml(
        b"42", Field(type="number")
    ) == (42, [])
    # Failed parse
    assert validate_yaml(
        b"foo\nbar: baz", Field(type="number")
    ) == (None, [Message(
        code="parse_error",
        position=Position(
            char_index=0,
            column_no=1,
            line_no=1,
        ),
        text="mapping values are not allowed here.",
    )])
    # Failed validation

# Generated at 2022-06-24 11:15:42.905484
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("""{"a":1}""") == {"a": 1}
    assert tokenize_yaml("""["a", 1]""") == ["a", 1]
    assert tokenize_yaml("""[1, 2]""") == [1, 2]
    assert tokenize_yaml("""{"a":"b"}""") == {"a": "b"}


# Generated at 2022-06-24 11:15:49.949024
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    contents = [
        """
        foo:
            bar: "baz"
            list:
                - 1
                - 2
        """,
        """
        foo:
            bar:
                baz: 1
                buz: 2
        """,
        """
        foo:
            bar:
                baz: 1
                buz: 2
            list:
                - 1
                - 2
        """,
    ]
    for content in contents:
        token = tokenize_yaml(content)
        assert isinstance(token, DictToken)

# Generated at 2022-06-24 11:15:56.666875
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Create scalar tokens
    assert isinstance(tokenize_yaml("hi"), ScalarToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("1.5"), ScalarToken)

    # Create list tokens
    assert isinstance(tokenize_yaml("[1, 2, 3]"), ListToken)
    assert isinstance(tokenize_yaml("[1.5, 2.4, 3.4]"), ListToken)
    assert isinstance(tokenize_yaml("[hi, hello, howdy]"), ListToken)

    # Create dict tokens
    assert isinstance(tokenize_yaml("{hello: 1, world: 2}"), DictToken)

# Generated at 2022-06-24 11:16:07.414014
# Unit test for function validate_yaml
def test_validate_yaml():
    def validate(content, expected_value, expected_errors=[]):
        value, errors = validate_yaml(
            content, schema_class=TestSchema, allow_unknown=False
        )
        assert value == expected_value
        assert errors == expected_errors

    validate(
        content=None,
        expected_value=None,
        expected_errors=[
            Message(
                text="Required value.",
                code="required",
                type="value_error.missing",
                position=Position(column_no=1, line_no=1, char_index=0),
            )
        ],
    )

# Generated at 2022-06-24 11:16:11.804074
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""{"name": "Mat"}"""
    testschema = Schema(fields={"name": {"type": "string"}})
    value, error_messages = validate_yaml(content, testschema)
    assert value == {"name": "Mat"}
    assert error_messages == []

# Generated at 2022-06-24 11:16:20.576723
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    content = "{'name': 'bob', 'age': '19'}"
    class User(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=100)
    value, errors = validate_yaml(content, validator=User)
    assert value == {"name": "bob", "age": 19}
    assert len(errors) == 1
    error = errors[0]
    assert isinstance(error, ValidationError)
    assert error.error == "age must be no more than 100."


# Generated at 2022-06-24 11:16:23.515145
# Unit test for function validate_yaml
def test_validate_yaml():
    value, error_messages = validate_yaml(
    """
    - 1
    - 2
    - 3
    """,
    list
    )
    print (error_messages)

test_validate_yaml()


# Generated at 2022-06-24 11:16:32.642983
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test simple string
    content = """
    foo: bar
    """
    token = tokenize_yaml(content)
    assert token.value == {"foo": "bar"}
    # Test simple string with starting new line
    content = """
foo: bar
    """
    token = tokenize_yaml(content)
    assert token.value == {"foo": "bar"}
    # Test simple string with ending new line
    content = """
foo: bar
"""
    token = tokenize_yaml(content)
    assert token.value == {"foo": "bar"}
    # Test integer
    content = """
foo: 1
    """
    token = tokenize_yaml(content)
    assert token.value == {"foo": 1}
    # Test float
    content = """
foo: 1.0
    """
    token

# Generated at 2022-06-24 11:16:38.854105
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
    ---
    a: foo
    b:
    - [1,2,3]
    - 4
    '''
    token = tokenize_yaml(content)
    assert token.get(['a']) == 'foo'
    assert token.get(['b', 0]) == [1,2,3]
    assert token.get(['b', 1]) == 4



# Generated at 2022-06-24 11:16:43.939718
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        name = types.String()
        age = types.Integer()
    
    content = \
"""
name: "Mike"
age: "33"
"""
    errors = validate_yaml(content, UserSchema)
    assert (errors == [
        Message(
            code="invalid_type",
            field="age",
            text="Value must be of type 'integer'.",
            position=Position(line_no=3, column_no=5, char_index=15),
        ),
    ])

# Generated at 2022-06-24 11:16:49.239539
# Unit test for function validate_yaml
def test_validate_yaml():
    # Set up validator
    class MySchema(Schema):
        field_a = Integer(minimum=0, maximum=9)

    # Validate
    yaml_content = "field_a: -1"
    (value, error_messages) = validate_yaml(yaml_content, MySchema)
    
    # Check value
    assert not value

    # Check error_messages
    assert len(error_messages) == 1
    assert error_messages[0].text == "Number must be greater or equal to 0."
    assert error_messages[0].position.char_index == 8
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 8
    assert error_messages[0].position.code == "m"

# Generated at 2022-06-24 11:17:00.842630
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, Structure, String
    from typesystem.fields import Field, Key
    from typesystem.schemas import Schema

    class User(Structure):
        username = String()
        password = String()
        age = Integer()

    class Login(Field):
        username = String()
        password = String()

    class LoginSchema(Schema):
        username = String()
        password = String()
        age = Integer()

    assert validate_yaml("", validator=User) == ({}, ["Expected a dict."])
    assert validate_yaml("{}", validator=User) == ({}, ["Incomplete: one or more fields required."])
    assert validate_yaml("username", validator=User) == ({}, ["Expected a dict."])

# Generated at 2022-06-24 11:17:08.011560
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    text = """
        key:
          - item1
          - item2
    """
    token = tokenize_yaml(text)
    assert isinstance(token, DictToken)
    assert token.keys() == ["key"]
    sub_token = token.values[0].value
    assert isinstance(sub_token, ListToken)
    assert sub_token.values == [ScalarToken("item1", 0, 3, content=text), ScalarToken("item2", 0, 3, content=text)]


# Generated at 2022-06-24 11:17:11.129353
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"a": int})
    content = b"a: 1"
    value, errors = validate_yaml(content, schema)
    assert value == {"a": 1}
    assert not errors


# Generated at 2022-06-24 11:17:18.954024
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(content='a: 1') == DictToken({'a': ScalarToken('1', 0, 5)}, 0, 5, content='a: 1')
    assert tokenize_yaml(content='a: 1\nb: 2') == DictToken({'a': ScalarToken('1', 0, 5), 'b': ScalarToken('2', 6, 11)}, 0, 11, content='a: 1\nb: 2')
    assert tokenize_yaml(content='a:') == DictToken({'a': None}, 0, 3, content='a:')
    assert tokenize_yaml(content='- 1\n- 2') == ListToken([ScalarToken('1', 1, 4), ScalarToken('2', 6, 9)], 0, 10, content='- 1\n- 2')


# Generated at 2022-06-24 11:17:28.941432
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Simple case
    result = tokenize_yaml("foo: bar\n baz: 1")
    assert isinstance(result, DictToken)

    # Empty string returns error token
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml("")
    assert excinfo.value.text == "No content."
    assert excinfo.value.position.char_index == 0
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.column_no == 1

    # Special characters
    result = tokenize_yaml("foo: bar\t baz: 1\nboop: '\\t'")
    assert isinstance(result, DictToken)

    # Indentation
    result = tokenize_yaml("foo:\n    bar: 1")

# Generated at 2022-06-24 11:17:36.733190
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    content = "{foo: 1}"
    token = tokenize_yaml(content)
    assert token.data == {"foo": 1}

    content = "[1, 2]"
    token = tokenize_yaml(content)
    assert token.data == [1, 2]

    content = "1"
    token = tokenize_yaml(content)
    assert token.data == 1

    content = '"foo"'
    token = tokenize_yaml(content)
    assert token.data == "foo"

    content = "true"
    token = tokenize_yaml(content)
    assert token.data

    content = "false"
    token = tokenize_yaml(content)
    assert not token.data

    content = "null"


# Generated at 2022-06-24 11:17:45.381652
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: First List item
      age: 20
      balance: 345
    - name: 2nd List item
      age: 'twenty-one'
      balance: 0
    """

    schema = Schema(
        fields={
            "name": Field(str),
            "age": Field(str),
            "balance": Field(int),
        }
    )

    value, error_messages = validate_yaml(content, schema)


# Generated at 2022-06-24 11:17:56.322067
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'PyYaml' must be installed."

    from typesystem.schemas import Schema

    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    from typesystem.tokenize.positional_validation import validate_with_positions

    # Test for non string input
    try:
        tokenize_yaml(b"null:")
    except ParseError:
        pass

    # Test for valid yaml
    token = tokenize_yaml("key: value")
    assert isinstance(token, DictToken)

    # Test for invalid yaml
    try:
        tokenize_yaml("key: value\nkey: value")
    except ParseError:
        pass

    # Test for empty yaml

# Generated at 2022-06-24 11:18:05.895488
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    dict_token = tokenize_yaml(content="{a:b}")
    assert dict_token.start == 0
    assert dict_token.end == 3
    assert dict_token.field_name == "a"
    assert dict_token.value == "b"

    list_token = tokenize_yaml(content="[a,b]")
    assert list_token.start == 0
    assert list_token.end == 4
    assert list_token.field_name == 0
    assert list_token.value == "a"

    scalar_token = tokenize_yaml(content="a")
    assert scalar_token.start == 0
    assert scalar_token.end == 0
    assert scalar_token.field_name is None
    assert scalar_token.value == "a"

    token = token

# Generated at 2022-06-24 11:18:15.951731
# Unit test for function validate_yaml
def test_validate_yaml():
    # Catch YAML parse errors.
    with pytest.raises(ParseError) as exc_info:
        validate_yaml(
            b"""
        test:
        - 'hello'
        - 'world'
        - '!'
        """,
            validator=Field(type="string"),
        )
    errors = exc_info.value.errors
    assert len(errors) == 1
    assert errors[0].code == "parse_error"
    assert errors[0].path == ["test", 2]

    # Catch type errors.
    with pytest.raises(ParseError) as exc_info:
        validate_yaml(
            """
        test:
        - 'hello'
        - 'world'
        - '!'
        """,
            validator=Field(type="string"),
        )

# Generated at 2022-06-24 11:18:27.975028
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import yaml
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken
    # Test ScalarToken
    # String
    assert tokenize_yaml('"a string"') == ScalarToken("a string", 0, 9, content='"a string"')
    # Integer
    assert tokenize_yaml('1') == ScalarToken(1, 0, 0, content='1')
    # Float
    assert tokenize_yaml('1.2') == ScalarToken(1.2, 0, 2, content='1.2')
    # True
    assert tokenize_yaml('true') == ScalarToken(True, 0, 3, content='true')
    # False
    assert tokenize_yaml('false') == ScalarToken(False, 0, 4, content='false')
   

# Generated at 2022-06-24 11:18:31.337622
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('[1, 2, 3]').value == [1, 2, 3]
    assert tokenize_yaml('{"a": 1, "b": 2}').value == {"a": 1, "b": 2}


# Generated at 2022-06-24 11:18:37.100312
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test empty string
    content = ""
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml(content)
    assert str(excinfo.value) == "No content."

    # test scalar
    content = '"test"'
    token = tokenize_yaml(content)
    assert isinstance(token, ScalarToken)
    assert token.value == "test"

    # test list
    content = "- 1\n- 2\n- test"
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert token.value[0].value == 1
    assert token.value[1].value == 2
    assert token.value[2].value == "test"

    # test dict

# Generated at 2022-06-24 11:18:45.057688
# Unit test for function validate_yaml
def test_validate_yaml():

 
    schema = typesystem.Schema(
        fields={
            "name": typesystem.String(
                description="Your name.", max_length=10, min_length=1, pattern=r"^[\w ]+$"
            ),
            "status": typesystem.String(choices=["active", "inactive"]),
            "description": typesystem.String(description="A description."),
            "features": typesystem.List(of=typesystem.String(max_length=10)),
            "product_ids": typesystem.List(
                of=typesystem.Integer(), description="List of product ids."
            ),
            "birthday": typesystem.Date(),
            "scores": typesystem.List(of=typesystem.Float()),
        },
        description="Your profile settings.",
    )

    input_

# Generated at 2022-06-24 11:18:51.435667
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ""
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("-a") == "-a"
    assert tokenize_yaml("- 1") == [-1]
    assert tokenize_yaml("- 1\n- 2") == [-1, -2]
    assert tokenize_yaml("a\n  b: c") == {"a": {"b": "c"}}


# Generated at 2022-06-24 11:19:02.376262
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_string = """
        test_string: "hello world"
        test_int: 50
        test_float: 2.5
        test_bool: true
        test_null: null
        test_list: [10, 20, 30]
        test_dict:
            sub_dict1: "hello"
            sub_dict2:
                subsub_dict: "world"
    """

    def assert_token(value, start, end, content):
        assert isinstance(value, type(token.value[start]))
        assert token.value[start] == value
        assert token.value[end] == value
        assert token.value[start].value == value.value
        assert token.value[start].start == value.start
        assert token.value[end].end == value.end

# Generated at 2022-06-24 11:19:13.332753
# Unit test for function validate_yaml
def test_validate_yaml():
    v1 = Field(name="v1", primitive_type=int)
    v2 = Field(name="v2", primitive_type=float)
    class MySchema(Schema):
        v1 = v1
        v2 = v2

    # Valid YAML object
    content = """
    v1: 1
    v2: 2.3
    """

    assert validate_yaml(content, MySchema) == (
        {"v1": 1, "v2": 2.3},
        None,  # No errors
    )

    # Valid YAML list
    content = """
    - 1
    - 2.3
    """


# Generated at 2022-06-24 11:19:18.407428
# Unit test for function validate_yaml
def test_validate_yaml():
    code = """
    title: A Note
    content: This is a note.
    """
    validator = Schema({"title": str, "content": str})
    validate_yaml(code, validator)

# Test example from typesystem repo docs

# Generated at 2022-06-24 11:19:28.215133
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    id: 123
    name: 'John Doe'
    """

    # Create a subclass of Schema from a python dictionary and expect schema that is a String Field
    class PersonSchema1(Schema):
        type_mapping = {"name": "String"}
    _, error_messages = validate_yaml(
        content, validator=PersonSchema1
    )
    assert len(error_messages) == 1
    assert error_messages[0].text == "Expected a field of type 'String'."

    # Create a subclass of Schema from a python dictionary and expect schema that is a Integer Field
    class PersonSchema2(Schema):
        type_mapping = {"id": "Integer"}

# Generated at 2022-06-24 11:19:33.593900
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = type_system.String(required=True)
        age = type_system.Integer(required=True)

    content = """name: Mark
age: 20
"""
    value, error_messages = validate_yaml(TestSchema, content)
    assert value == {"name": "Mark", "age": 20}
    assert error_messages == []



# Generated at 2022-06-24 11:19:41.779597
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test with a simple YAML string
    s = "foo: bar\n"
    assert tokenize_yaml(s) == {"foo": "bar"}

    # edge case that resulted in an infinite loop when the original parser
    # was used
    s = "\n"
    assert tokenize_yaml(s) is None

    # test with an empty string
    try:
        tokenize_yaml("")
        assert False
    except ParseError as e:
        assert e.text == "No content."
        assert str(e) == "No content."

    # test with a valid string
    s = "foo: bar\n"
    assert tokenize_yaml(s) == {"foo": "bar"}

    # test with an invalid string

# Generated at 2022-06-24 11:19:47.395009
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "TestSchema"
        fields = {
            "name": String(max_length=20),
            "age": Integer()
        }

    value, errors = validate_yaml("name: john\nage: 20\n", TestSchema)
    assert value == {'name': 'john', 'age': 20}
    assert errors == []



# Generated at 2022-06-24 11:19:56.748975
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        example = Field(str)

    def test_case(content: str, expected_value: typing.Optional[str], expected_errors: typing.List[Message]) -> None:
        value, errors = validate_yaml(content, validator=TestSchema)
        assert value == expected_value
        assert errors == expected_errors

    test_case(
        content="this is not yaml",
        expected_value=None,
        expected_errors=[
            ParseError(text="could not find expected ':'", code="parse_error", position=Position(line_no=1, column_no=1, char_index=0)),
            ValidationError(text="Value is not valid.", code="not_valid", position=None),
        ],
    )

# Generated at 2022-06-24 11:20:07.833975
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Unit test cases for tokenize_yaml
    """
    content_1 = """
        a: b
        c: d
        e: f
    """
    token_1 = tokenize_yaml(content_1)

    assert token_1.content == content_1
    assert token_1["a"].content == "b"
    assert token_1["c"].content == "d"
    assert token_1["e"].content == "f"

    token_1["a"].value = "g"

    assert token_1.content == """
        a: g
        c: d
        e: f
    """
    assert token_1["a"].content == "g"
    assert token_1["c"].content == "d"

# Generated at 2022-06-24 11:20:10.109746
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    input_text = 'name: "John"\nage: 23'
    tokenize_yaml(input_text)


# Generated at 2022-06-24 11:20:18.310783
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """my_name: John
my_age: 30
my_shoe_size: .7
"""
    my_schema = Schema(type="object", properties={"my_name": type("string"), "my_age": type("integer"), "my_shoe_size": type("number")})

    res = validate_yaml(content, my_schema)
    assert res[0] == {"my_name": "John", "my_age": 30, "my_shoe_size": 0.7}
    assert len(res[1]) == 0

    content = """my_name: John
my_age: 30
my_shoe_size: foo
"""
    res = validate_yaml(content, my_schema)

# Generated at 2022-06-24 11:20:28.125471
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema, fields

    class User(Schema):
        name = fields.String()
        age = fields.Integer()

    content = """
name: Bob
age: 30
"""
    value, errors = validate_yaml(content, validator=User)
    assert value == {"name": "Bob", "age": 30}
    assert errors == []

    content = """
name: Bob
age: "Foo"
"""
    value, errors = validate_yaml(content, validator=User)
    assert value is None
    assert errors == [
        Message(
            text="Must be a valid integer.",
            code="integer",
            field_name="age",
            position=Position(column_no=4, line_no=3, char_index=4),
        )
    ]



# Generated at 2022-06-24 11:20:39.607045
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema, fields

    class User(Schema):
        name = fields.String()
        age = fields.Integer()

    content = """
    name: Markus
    age: 1.2
    """
    value, error_messages = validate_yaml(content, validator=User)
    assert not value
    assert len(error_messages) == 2
    msg = error_messages[0]
    assert msg.field_name == "age"
    assert msg.position.line_no == 3
    assert msg.position.column_no == 5
    assert msg.position.char_index == 17
    assert msg.text == "expected type: <class 'int'> got: 1.2"

if __name__ == "__main__":
    test_validate_yaml()