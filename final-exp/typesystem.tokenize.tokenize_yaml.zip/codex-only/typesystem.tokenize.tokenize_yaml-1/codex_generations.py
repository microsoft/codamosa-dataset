

# Generated at 2022-06-24 11:10:46.220089
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("list: [1, 2]") == {'list': [1, 2]}
    assert tokenize_yaml("bool: true") == {'bool': True} 
    assert tokenize_yaml("null: null") == {'null': None}

# Generated at 2022-06-24 11:10:55.742156
# Unit test for function validate_yaml
def test_validate_yaml():

    class UserSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True)
        email = fields.String(format="email")

    content = """
    name: John
    age: 30
    email: john@example.com
    """

    value, error_messages = validate_yaml(content, UserSchema.as_field())
    assert value == {"name": "John", "age": 30, "email": "john@example.com"}
    assert len(error_messages) == 0

    content = """
    name: John
    age: 30
    email: john
    """

    value, error_messages = validate_yaml(content, UserSchema.as_field())

# Generated at 2022-06-24 11:11:05.131706
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Validates against a specified field and/or schema.
    """
    class MySchema(Schema):
        first_name = String(max_length=10)
        last_name = String(max_length=10)
        age = Integer()
        is_old = Boolean()

    data = '''
    first_name: John
    last_name: Doe
    age: 30
    is_old: False
    '''

    expected = {
        "first_name": "John",
        "last_name": "Doe",
        "age": 30,
        "is_old": False,
    }

    assert expected == validate_yaml(data, MySchema)

# Generated at 2022-06-24 11:11:13.640504
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        email = String(required=True)
        age = Integer()

    # Valid input
    content = """
        email: "example@example.com"
        age: 30
        """
    user, error_messages = validate_yaml(content=content, validator=UserSchema)
    assert user == {"email": "example@example.com", "age": 30}
    assert error_messages == []

    # Invalid input
    content = """
        email: "example@example.com"
        age: "30"
        """
    user, error_messages = validate_yaml(content=content, validator=UserSchema)
    assert user is None
    assert len(error_messages) == 1

# Generated at 2022-06-24 11:11:25.700156
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    def check(content, expected):
        token = tokenize_yaml(content)
        actual = token.as_python()
        assert actual == expected
        return actual

    check("1", 1)
    check("-1", -1)
    check("1.1", 1.1)
    check("-1.1", -1.1)
    check("""1: a\n 2: b\n""", {"1": "a", "2": "b"})
    check("""-1: a\n -2: b\n""", {"-1": "a", "-2": "b"})
    check("""-a: a\n -b: b\n""", {"-a": "a", "-b": "b"})

# Generated at 2022-06-24 11:11:35.285646
# Unit test for function validate_yaml
def test_validate_yaml():
    # Validating against a Plain Text Field
    content = "Hello World"
    field = Field(type="string")
    assert validate_yaml(content, field) == ("Hello World", [])

    # Validating against a Schema
    content = """
    name: Jane Doe
    age: 35
    """
    class UserSchema(Schema):
        name = UserSchema.fields.String()
        age = UserSchema.fields.Integer()
    assert validate_yaml(content, UserSchema) == (
        {'name': 'Jane Doe', 'age': 35},
        []
    )

    # Checking for parse error
    content = """
    name: Jane
    age: Doe
    """
    class UserSchema(Schema):
        name = UserSchema.fields.String()
        age = UserSchema

# Generated at 2022-06-24 11:11:42.170985
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('[1, 2, 3, 4]') == [1, 2, 3, 4]
    assert tokenize_yaml('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert tokenize_yaml('"hello, world"') == 'hello, world'
    try:
        tokenize_yaml(12345)
    except:
        assert True


# Generated at 2022-06-24 11:11:47.813662
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "test"
        age = 1
        settings = {"color": "blue"}

    content = b"""
name: test
age: 1
settings:
    color: blue
"""
    value, messages = validate_yaml(
        content, TestSchema
    )
    assert value == {"name": "test", "age": 1, "settings": {"color": "blue"}}
    assert messages == []



# Generated at 2022-06-24 11:11:55.500655
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    yaml_content = "age: 12\n"
    age = Field(validators=[Min(10)])
    class Person(Schema):
        age = age
    (value, errors) = validate_yaml(yaml_content, Person)
    assert errors == []
    assert value["age"] == 12
    yaml_content = "age: 9\n"
    (value, errors) = validate_yaml(yaml_content, Person)
    assert len(errors) == 1
    error = errors[0]
    assert error.position == Position(
        char_index=7, column_no=2, line_no=1
    )
    assert error.text == "Must be equal to or greater than 10."


# Generated at 2022-06-24 11:11:59.946112
# Unit test for function validate_yaml
def test_validate_yaml():
    class User(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: Anima
    age: 36
    """

    value, error_messages = validate_yaml(content, User)
    print(value)

    assert error_messages == []

# Generated at 2022-06-24 11:12:10.365653
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = b"""
---
foo: 1
bar: 2.0
baz: "qux"
ding: true
dong: null
bacon:
    - 1
    - 2
    - 3
    - 4
eggs:
    - name: foo
      value: 1
      extra: bar
    - name: bar
      value: 2
      extra: baz
    - name: baz
      value: 3.0
      extra: qux
    - name: ding
      value: true
      extra: dong
    - name: dong
      value: null
      extra: bacon
"""
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

# Generated at 2022-06-24 11:12:11.980960
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")



# Generated at 2022-06-24 11:12:21.327523
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('---') is None
    assert tokenize_yaml('---\n') is None
    assert tokenize_yaml('   ') is None
    assert tokenize_yaml('123') == ScalarToken(value=123, start=0, end=2, content='123')
    assert tokenize_yaml('   123\n') == ScalarToken(
        value=123, start=3, end=5, content='   123\n'
    )
    assert tokenize_yaml('123\n') == ScalarToken(
        value=123, start=0, end=2, content='123\n'
    )
    assert tokenize_yaml('123 456') == ScalarToken(
        value=123, start=0, end=2, content='123 456'
    )


# Generated at 2022-06-24 11:12:31.250653
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ScalarToken("", 0, 0, content="")
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")
    assert tokenize_yaml("[1, 2, 3]") == ListToken([1, 2, 3], 0, 8, content="[1, 2, 3]")
    assert tokenize_yaml("{foo: bar}") == DictToken({"foo": "bar"}, 0, 10, content="{foo: bar}")
    assert (
        tokenize_yaml("[{foo: bar}, {foo: bar}]")
        == ListToken(
            [{"foo": "bar"}, {"foo": "bar"}], 0, 21, content="[{foo: bar}, {foo: bar}]"
        )
    )


# Generated at 2022-06-24 11:12:39.490863
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        int_field = Field(type=int, required=True)
        string_field = Field(type=str, required=True)

    value, messages = validate_yaml(
        content="int_field: 1\nstring_field: 's'", validator=TestSchema
    )
    assert value == {"int_field": 1, "string_field": "s"}
    assert messages == []

    value, messages = validate_yaml(
        content="int_field: 1\nstring_field: 1", validator=TestSchema
    )
    assert value is ParseError

# Generated at 2022-06-24 11:12:48.268751
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_1 = """
    def:
      a: 1
      b: 2
    """
    r = tokenize_yaml(yaml_1)
    assert r.info == {'a': 1, 'b': 2}

    yaml_2 = """
    def:
      a: 1
      b: 2
      c:
        a: 11
        b: 22
    """
    r = tokenize_yaml(yaml_2)
    assert r.info == {'a': 1, 'b': 2, 'c': {'a': 11, 'b': 22}}

    yaml_3 = """
    def:
      a: 1
      b: 2
      c:
        - 1
        - 2
    """
    r = tokenize_yaml(yaml_3)
    assert r

# Generated at 2022-06-24 11:12:50.815839
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '{"a": 1}'
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1}


# Generated at 2022-06-24 11:13:02.116756
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml('"hello"'), ScalarToken)
    assert isinstance(tokenize_yaml("123"), ScalarToken)
    assert isinstance(tokenize_yaml("1.0"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)

    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml("{")
        assert str(excinfo) == "Expected '}'."
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml("[")


# Generated at 2022-06-24 11:13:09.808717
# Unit test for function validate_yaml
def test_validate_yaml():
    import random
    random.seed(123)

    class UserSchema(Schema):
        id = Integer(minimum=0)
        name = String(min_length=3, max_length=10)

    class PostSchema(Schema):
        id = Integer(minimum=0)
        title = String(max_length=100)
        body = String(min_length=20)
        user_id = Integer(minimum=0, maximum=100)

    schema = Schema(
        id=Integer(minimum=0),
        title=String(min_length=3, max_length=100),
        body=String(min_length=10),
        user = UserSchema,
        posts = List[PostSchema]
    )


# Generated at 2022-06-24 11:13:14.256207
# Unit test for function validate_yaml
def test_validate_yaml():
    content: typing.Union[str, bytes] = '{"test": "ing"}'
    validator: typing.Union[Field, typing.Type[Schema]] = {
        "test": Field(required="yes")
    }
    value, error_messages = validate_yaml(content, validator)
    assert value

# Generated at 2022-06-24 11:13:24.423024
# Unit test for function validate_yaml
def test_validate_yaml():
    class Validate(Schema):
        value = Field(type="string")

    value, error_messages = validate_yaml(b"{value: toto}\n", Validate)
    assert error_messages == []

    value, error_messages = validate_yaml(b"{value: toto}\n", Validate)
    assert error_messages == []

    # Tests the case of a validator that is a schema class
    value, error_messages = validate_yaml(b"{value: toto}\n", Validate)
    assert error_messages == []

    class BadValidate(Schema):
        value = Field(type="string", required=True)

    # It works when the required value is present

# Generated at 2022-06-24 11:13:33.764576
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import fields
    from typesystem.schemas import Schema

    class YAMLValidator(Schema):
        name = fields.String()
        age = fields.Integer()

    assert YAMLValidator.validate_yaml(
        "name: 'Ronald Weasly'\nage: 20", return_errors=True
    ) == ({'name': 'Ronald Weasly', 'age': 20}, [])
    assert YAMLValidator.validate_yaml(
        "name: 'Ronald Weasly'\nage: 20", return_errors=False
    ) == ({'name': 'Ronald Weasly', 'age': 20})


# Generated at 2022-06-24 11:13:43.134854
# Unit test for function validate_yaml
def test_validate_yaml():

    # Should fail with a parse error.
    with pytest.raises(ParseError) as exc_info:
        validate_yaml("invalid yaml", "a field")

    assert exc_info.value.position.line_no == 1
    assert exc_info.value.position.column_no == 0
    assert exc_info.value.position.char_index == 0

    # Should succeed.
    value, errors = validate_yaml("name: John", "name: string")
    assert value == {"name": "John"}
    assert errors == []

    # Should fail due to max_length.
    value, errors = validate_yaml("name: John123", "name: string[max_length=5]")
    assert value == {"name": "John123"}
    assert errors[0].position.line_no == 1

# Generated at 2022-06-24 11:13:46.938464
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(content = "" ) == ScalarToken(None, 0, -1, content="")


# Generated at 2022-06-24 11:13:52.380587
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    - a: 1
    - b: 2
    """
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert token.content == content
    assert token.start == 12
    assert token.end == 28
    assert token[0]["a"] == 1
    assert token[1]["b"] == 2



# Generated at 2022-06-24 11:13:54.332750
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert (
        tokenize_yaml('"foo"')
        == ScalarToken(value='foo', start=0, end=5, content='"foo"')
    )

# Generated at 2022-06-24 11:14:01.571698
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""
title: 123
tags:
  - programming
  - python
  - typesystem

books:
  - title: Hello, World!
    author: Michael Kennedy
    url: http://exploreflask.com
  - title: The Hitchhiker's Guide to Python
    author: Kenneth Reitz
    url: http://docs.python-guide.org
    """
    validator = Schema({"title": str, "books": [{"title": str}]})
    assert validate_yaml(content, validator) == ({
        "title": "123",
        "books": [
            {"title": "Hello, World!"},
            {"title": "The Hitchhiker's Guide to Python"},
        ],
    }, [])

# Generated at 2022-06-24 11:14:02.655444
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("", Schema) == ([], {})



# Generated at 2022-06-24 11:14:09.064325
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        bar = fields.String()

    str_content = """
    foo:
        - "string1"
        - "string2"
    """

    _, error_messages = validate_yaml(content=str_content, validator=TestSchema)

    assert len(error_messages) == 1
    message = error_messages[0]
    assert isinstance(message, Message)
    assert message.text == "Keyword 'foo' not in schema."
    assert message.position == Position(line_no=2, column_no=8, char_index=8)



# Generated at 2022-06-24 11:14:15.132817
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """\
    - name: John Doe
      email: john@example.com
    - name: James Doe
      email: james@example.com
    - name: Jane Doe
      email: jane@example.com
    """

    token = tokenize_yaml(content)

    assert isinstance(token, ListToken)
    assert len(token.value) == 3
    assert token.start == 1
    assert token.end == 66

    assert isinstance(token.value[0], DictToken)
    assert len(token.value[0].value) == 2
    assert token.value[0].value["name"] == "John Doe"
    assert token.value[0].value["email"] == "john@example.com"
    assert token.value[0].start == 2

# Generated at 2022-06-24 11:14:23.699117
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_string = \
"""
# A mapping from owner names to pet names
favorite pets:
    # The Adams family
    John Adams:
    - name: George
      species: dog
    - name: Martha
      species: cat
    Thomas Jefferson:
    - name: Martha
      species: bear
"""
    token = tokenize_yaml(yaml_string)
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)
    assert "favorite pets" in token.value
    assert len(token.value) == 1
    assert token.start == 7
    assert token.end == 119



# Generated at 2022-06-24 11:14:32.526083
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo".encode("utf-8")) == ScalarToken("foo", 0, 3, content="foo")
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 3, content="foo")
    assert tokenize_yaml('"foo"') == ScalarToken("foo", 0, 5, content='"foo"')
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("3.14") == ScalarToken(3.14, 0, 4, content="3.14")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")


# Generated at 2022-06-24 11:14:36.798584
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        answer: 42
        foo: "bar"
        """

    class TestSchema(Schema):
        answer = typesystem.Integer()
        foo = typesystem.String()

    value, error = validate_yaml(content, TestSchema)
    assert value == {'answer': 42, 'foo': 'bar'}

# Generated at 2022-06-24 11:14:43.725570
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
# A dictionary
a:
  b: 1
  c: 2
"""
    token = tokenize_yaml(content)
    with open(
        "tests/test_tokenize_yaml/test_tokenize_yaml.actual.py", "w"
    ) as f:
        f.write(str(token))
    with open(
        "tests/test_tokenize_yaml/test_tokenize_yaml.actual.py"
    ) as f:
        actual = f.read()
    with open(
        "tests/test_tokenize_yaml/test_tokenize_yaml.expected.py"
    ) as f:
        expected = f.read()
    assert actual == expected

# Generated at 2022-06-24 11:14:53.593422
# Unit test for function validate_yaml
def test_validate_yaml():
    def test_text(text):
        v = Field(format="yaml")
        expected_value, expected_messages = validate_yaml(text, v)
        # this is not any exact value, it is just that the given text should
        # be parsed successfully and validated successfully
        assert expected_messages == []

    test_text("""
        - a
        - b
    """)
    test_text("""
        a: b
        c: d
    """)
    test_text("""
        a:
          b: c
    """)
    test_text(""""a": b""")
    test_text("""
        -
          - a
          - b
        -
          - c
          - d
    """)
    test_text("""
        - a
          b
    """)


# Generated at 2022-06-24 11:15:03.923501
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    def check_token(source: str, expected: Token):
        result = tokenize_yaml(source)
        assert result == expected

    check_token("hello", ScalarToken("hello", 0, 4, content="hello"))

    check_token("[1]", ListToken([1], 0, 2, content="[1]"))
    check_token("[1, 2]", ListToken([1, 2], 0, 5, content="[1, 2]"))

    check_token("{foo: bar}", DictToken({"foo": "bar"}, 0, 10, content="{foo: bar}"))
    check_token("{foo: bar, baz: quux}", DictToken({"foo": "bar", "baz": "quux"}, 0, 19, content="{foo: bar, baz: quux}"))

# Generated at 2022-06-24 11:15:15.149676
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('{"hello": "world"}').get_value() == {'hello': 'world'}
    assert (tokenize_yaml('["foo", "bar", "baz"]').get_value() == 
            ['foo', 'bar', 'baz'])
    assert tokenize_yaml('- foo\n- bar\n- baz').get_value() ==  ['foo', 'bar', 'baz']
    assert tokenize_yaml('foo: bar').get_value() == { 'foo': 'bar' }
    assert tokenize_yaml("""\
---
- Mark McGwire
- Sammy Sosa
- Ken Griffey
""").get_value() == ['Mark McGwire', 'Sammy Sosa', 'Ken Griffey']


# Generated at 2022-06-24 11:15:23.357971
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import fields
    from typesystem.schemas import Schema

    validator = fields.List(fields.String())
    assert validate_yaml('[1, "2"]', validator) == ([1, "2"], [])

    class CarSchema(Schema):
        brand = fields.String(max_length=4)
        price = fields.Integer()

    assert validate_yaml('{brand: "Mercedes", price: 27000 }', CarSchema) == \
           ({"brand": "Mercedes", "price": 27000 }, [])

# Generated at 2022-06-24 11:15:33.983886
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    # null
    null:
    - a
    - b
    - c
    # dict
    dict:
      a: 1
      b: 2
      # list
      list:
        - 2
        - 3
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    # Test null
    assert isinstance(token.value["null"], ListToken)
    assert len(token.value["null"].value) == 3
    # Test dict
    assert isinstance(token.value["dict"], DictToken)
    assert isinstance(token.value["dict"].value["a"], ScalarToken)
    assert token.value["dict"].value["a"].value == 1
    # Test list

# Generated at 2022-06-24 11:15:38.512806
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        content="",
        validator="a string") == (None, [Message(position=Position(char_index=0, column_no=1, line_no=1), text='Value must be of type "str"', code='type_error', kind='error')]
    )

# Generated at 2022-06-24 11:15:49.238178
# Unit test for function validate_yaml
def test_validate_yaml():

    class Person(Schema):
        name = String("Name")
        age = Integer("Age", minimum=18)

    # Testing a correct input
    correct_person = """
        name: Jane
        age: 25
    """
    assert validate_yaml(correct_person, validator=Person) == (
        {'name': 'Jane', 'age': 25},
        [],
    )

    # Testing an incorrect input
    bad_age = """
        name: Bob
        age: 17
    """
    result = validate_yaml(bad_age, validator=Person)

# Generated at 2022-06-24 11:15:50.544259
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(content="{}") == DictToken({}, 0, 1, content="{}")

# Generated at 2022-06-24 11:16:02.194319
# Unit test for function validate_yaml
def test_validate_yaml():

    class TestSchema(Schema):
        username = Field(str)

    # Test a successful parse and validation
    value, error_messages = validate_yaml(
        b"""
        username: Test User
        """,
        TestSchema,
    )

    assert value == {"username": "Test User"}
    assert not error_messages

    # Test a parse failure
    try:
        value, error_messages = validate_yaml(
            b"""
            This is not valid YAML.
            """,
            TestSchema,
        )
    except ParseError as exc:
        assert exc.position == Position(
            line_no=1, column_no=1, char_index=0
        )
    else:
        assert False, "ParseError expected."

    # Test a validation failure
   

# Generated at 2022-06-24 11:16:12.446769
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
id: 123
name: A
categories:
  - cat1
  - cat2
    """
    class MySchema(Schema):
        id = Field(type="integer")
        name = Field(type="string")
        categories = Field(type="string[]")
    r = validate_yaml(content, MySchema)
    assert r[0]["id"] == 123
    assert r[0]["name"] == "A"
    assert r[0]["categories"] == ["cat1", "cat2"]
    assert r[1] is None
    content = content.replace("123", "abc")
    r = validate_yaml(content, MySchema)
    assert r[1] is not None

# Generated at 2022-06-24 11:16:23.316826
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('{"a": 2, "b": 4}')

    assert token.start == 0
    assert token.end == 16
    assert token.value == {"a": 2, "b": 4}
    assert token.line_no == 1
    assert token.column_no == 1
    assert token.char_index == 0

    assert isinstance(token, DictToken)
    assert isinstance(token["a"], ScalarToken)
    assert token["a"].start == 3
    assert token["a"].end == 4
    assert token["a"].value == 2
    assert isinstance(token["b"], ScalarToken)
    assert token["b"].start == 10
    assert token["b"].end == 11
    assert token["b"].value == 4



# Generated at 2022-06-24 11:16:27.776448
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '"foo"'
    validator = String()

    # ensure valid result
    value, errors = validate_yaml(content=content, validator=validator)
    assert errors == []

    # ensure invalid result
    content = "[foo, bar, 3]"
    value, errors = validate_yaml(content=content, validator=validator)
    assert errors != []



# Generated at 2022-06-24 11:16:36.169804
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer

    class Person(Schema):
        name = String()
        age = Integer()

    token, errors = validate_yaml(
        content=b"name: John\nage: 25", validator=Person
    )

    assert isinstance(token, DictToken)
    assert token.content == "name: John\nage: 25"
    assert token.value == {"name": "John", "age": 25}
    assert token.start == 0
    assert token.end == 13
    assert token.get(path=["name"]).value == "John"
    assert token.get(path=["name"]).content == "John"
    assert token.get(path=["name"]).start == 6
    assert token.get(path=["name"]).end == 10

    assert errors == []



# Generated at 2022-06-24 11:16:45.590694
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content='[1,2,3]'
    token = tokenize_yaml(content)
    assert token.start == 0
    assert token.end == 7
    assert isinstance(token, ListToken)

    content='{a:1, b:2}'
    token = tokenize_yaml(content)
    assert token.start == 0
    assert token.end == 8
    assert isinstance(token, DictToken)

    content='a'
    token = tokenize_yaml(content)
    assert token.start == 0
    assert token.end == 1
    assert isinstance(token, ScalarToken)

    with pytest.raises(ParseError):
        token = tokenize_yaml("")



# Generated at 2022-06-24 11:16:52.910388
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(str, pattern="^[a-z]+$")
    value, error_messages = validate_yaml(b"foo: false", validator)
    assert isinstance(value, DictToken)
    assert isinstance(error_messages, list)
    assert len(error_messages) == 1
    assert isinstance(error_messages[0], Message)
    assert error_messages[0].text == "Must be a string."
    assert error_messages[0].code == "invalid_type"
    assert error_messages[0].position.column_no == 6



# Generated at 2022-06-24 11:16:58.132097
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "apple: 10\norange: 15"
    token = tokenize_yaml(content)
    assert token.content == "apple: 10\norange: 15"
    assert token[0].content == "10"
    assert token[0].start == 9
    assert token[0].end == 10
    assert token[1].content == "15"



# Generated at 2022-06-24 11:16:59.983935
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('foo: "bar"') == {'foo': 'bar'}


# Generated at 2022-06-24 11:17:03.617661
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    yaml_string_1 = """
    1: {'a': 'value'}
    2: "value"
    """

    token = tokenize_yaml(yaml_string_1)

    assert token.tokens[1] == ('a', 'value')
    assert token.tokens[2] == ('2', 'value')



# Generated at 2022-06-24 11:17:13.991606
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test the tokenization of a valid YAML string.
    assert tokenize_yaml('name: "Joe"') == {'name': 'Joe'}

    # Test that a parse error on the YAML string raises a ParseError.
    with pytest.raises(ParseError) as exc_info:
        tokenize_yaml('name = "Joe"')
    assert exc_info.value.code == "parse_error"

    # Test that validating a valid YAML string returns a valid value, with
    # no error messages.
    class User(Schema):
        name = fields.Str()

    token, error_messages = validate_yaml('name: "Joe"', User)
    assert token == {'name': 'Joe'}
    assert isinstance(error_messages, typing.List)


# Generated at 2022-06-24 11:17:19.482699
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    doc1 = "foo: bar"
    doc2 = "[{'hi':'hi'}]"
    valid_doc = tokenize_yaml(doc1)
    assert isinstance(valid_doc, Token)
    assert isinstance(valid_doc, DictToken)
    invalid_doc = tokenize_yaml(doc2)
    assert isinstance(invalid_doc, Token)
    assert isinstance(invalid_doc, ListToken)
    # 'Token' object has no attribute 'content'
    assert invalid_doc.content == doc2
    assert invalid_doc[0].content == doc2



# Generated at 2022-06-24 11:17:27.318486
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = typesystem.String()
        age = typesystem.Integer(minimum=21)

    def validate(content: str, validator: typing.Union[Field, typing.Type[Schema]]) -> typing.Dict[typing.Any, typing.Any]:
        value, messages = validate_yaml(content, PersonSchema)
        return messages

    content1 = "name: Martin\nage: 25"
    messages1 = validate(content1, PersonSchema)
    assert messages1 == {}

    content2 = "name: Martin\nage: 20"
    messages2 = validate(content2, PersonSchema)

# Generated at 2022-06-24 11:17:34.554341
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Test whether tokenize_yaml function works
    """
    with pytest.raises(ParseError):
        tokenize_yaml("")

    # Test a simple
    d = tokenize_yaml("hello: world")
    assert d == {'hello': 'world'}

    d = tokenize_yaml(""""
    hello: world
    name:
        - John
        - Smith
    """)
    assert d == {'hello': 'world', 'name': ['John', 'Smith']}



# Generated at 2022-06-24 11:17:44.101403
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("foo: hello")
    assert token == {"foo": "hello"}
    assert isinstance(token, DictToken)
    assert isinstance(token[0], ScalarToken)
    assert isinstance(token[1], ScalarToken)

    token = tokenize_yaml("- 1\n- two")
    assert token == [1, "two"]
    assert isinstance(token, ListToken)
    assert isinstance(token[0], ScalarToken)
    assert isinstance(token[1], ScalarToken)

    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml("")
    assert excinfo.value.code == "no_content"
    assert excinfo.value.text == "No content."


# Generated at 2022-06-24 11:17:55.199985
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None

    from typesystem import String

    value, errors = validate_yaml(
        content="foo: bar", validator=String(max_length=4, name="foo")
    )
    assert value == "bar"
    assert len(errors) == 0

    value, errors = validate_yaml(
        content="foo: baz", validator=String(max_length=4, name="foo")
    )
    assert value == "baz"
    assert len(errors) == 0

    value, errors = validate_yaml(
        content="foo: quux", validator=String(max_length=4, name="foo")
    )
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "max_length"

    value, errors = validate_

# Generated at 2022-06-24 11:18:02.383432
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: jerry
    age: 18
    """
    value, error_dict, error_messages = validate_yaml(
        content=content, validator=UserSchema
    )
    assert value == {"name": "jerry", "age": 18}
    assert error_dict == {}
    assert error_messages == []



# Generated at 2022-06-24 11:18:07.383081
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: Example
    value: 13.56
    """

    class MySchema(Schema):
        name = Field(type="string")
        value = Field(type="float")

    value, messages = validate_yaml(content, MySchema)
    assert value == {"name": "Example", "value": 13.56}
    assert not messages

# Generated at 2022-06-24 11:18:16.855876
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
        a:
            b:
                c: 1
    '''

    # This field should allow a nested structure of one level.
    class MySchema(Schema):
        a = Field(sub_fields={'b': Field(sub_fields={'c': Field(sub_fields={'d': Field()})})})

    value, error_messages = validate_yaml(content=content, validator=MySchema)
    assert error_messages == [
        ValidationError(
            text='Additional properties are not allowed (\'c\' was unexpected).',
            code='additional_properties',
            position=Position(column_no=10, line_no=6, char_index=49),
        )
    ]

    # This field should allow a nested structure of one level.

# Generated at 2022-06-24 11:18:20.458983
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    hello: world
    number: 100
    float: 100.05
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)



# Generated at 2022-06-24 11:18:30.550909
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        name = Text(max_length=100)

    assert validate_yaml(
        """
        name: Alice
        """,
        UserSchema,
    ) == ({'name': 'Alice'}, [])

    assert validate_yaml(
        """
        name: Alice
        """,
        UserSchema,
    ) == ({'name': 'Alice'}, [])


# Generated at 2022-06-24 11:18:38.806374
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ""
    assert tokenize_yaml("42") == 42
    assert tokenize_yaml("true") is True
    assert tokenize_yaml('{"foo": 42, "bar": "hello"}') == {
        "foo": 42,
        "bar": "hello",
    }
    assert tokenize_yaml("[42, 16, 9]") == [42, 16, 9]
    assert tokenize_yaml("hello\nworld") == "hello\nworld"
    assert tokenize_yaml("42.2") == 42.2
    assert tokenize_yaml("null") is None



# Generated at 2022-06-24 11:18:45.547905
# Unit test for function validate_yaml
def test_validate_yaml():
    base_file = '''
    name: Carl
    age: 12
    '''
    base_file = validate_yaml(base_file, Schema)
    assert base_file[0] == {"name": "Carl", "age": 12}
    assert base_file[1] == []

    invalid_file = '''
    name: '''
    invalid_file = validate_yaml(invalid_file, Schema)
    assert invalid_file[0] == None
    assert invalid_file[1] == [Message(
        text='Missing required property "age"',
        code="required_field",
        position=Position(char_index=5, column_no=6, line_no=2)
    )]


# Generated at 2022-06-24 11:18:56.659619
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Unit test for function tokenize_yaml()
    """
    assert yaml is not None, "'pyyaml' must be installed."

    token = tokenize_yaml("key: value")
    assert isinstance(token, DictToken)
    assert token.keys() == ["key"]
    assert token["key"] == "value"

    token = tokenize_yaml("- key")
    assert isinstance(token, ListToken)
    assert token[0] == "key"

    assert tokenize_yaml("key: !int 10").value() == {"key": 10}
    assert tokenize_yaml("key: !float 10.0").value() == {"key": 10.0}

    assert tokenize_yaml("key: !bool true").value() == {"key": True}
    assert tokenize_yaml

# Generated at 2022-06-24 11:19:06.064115
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.fields import Boolean, Number, String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.fields import Array
    from typesystem.tokenize.tokens import ListToken
    from typesystem.fields import Field
    from typesystem.tokenize.tokens import DictToken
    from typesystem.fields import Enum
    from typesystem.tokenize.tokens import ScalarToken

    content1 = """
        hello: world
        lorem: ipsum
    """

    token_test1 = tokenize_yaml(content1)

# Generated at 2022-06-24 11:19:14.986797
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    # Test that an exception is raised for an empty content string.
    try:
        tokenize_yaml(content="")
        assert False, "Expected a ParseError."
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.code == "no_content"
    # Test that an exception is raised for a malformed content string.
    try:
        tokenize_yaml(content="{")
        assert False, "Expected a ParseError."
    except ParseError as exc:
        assert exc.text == "while scanning a simple key", exc.text

# Generated at 2022-06-24 11:19:25.859272
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import fields
    from typesystem.tokenize.positional_validation import _get_validated

    document = """
    - a
    - b: 1
    """

    # Test for validating a list of string items
    schema = fields.List(items=fields.String())

    value, error_messages = validate_yaml(document, schema)
    assert error_messages == []
    assert value == ["a", {"b": 1}]

    # Test flat schema
    schema = fields.Dict(properties={
        "a": fields.Integer(minimum=5),
        "b": fields.String(min_length=5),
    })

    value, error_messages = validate_yaml(document, schema)

# Generated at 2022-06-24 11:19:31.464302
# Unit test for function validate_yaml
def test_validate_yaml():

    class TestSchema(Schema):
        s = Boolean()
        a = Integer()
    
    def test(s):
        (value, messages) = validate_yaml(s, TestSchema())
        return value, messages 

    # test successful case
    value, messages = test("s: True\na: 10")
    assert value == {'s':True, 'a':10}
    assert len(messages) == 0

    # test unsuccessful case
    value, messages = test("s: Test\na: 10")
    assert value == {}
    assert len(messages) == 1

    # test multiple unsuccessful case
    value, messages = test("s: Test\na: Test")
    assert value == {}
    assert len(messages) == 2

    # test multiple failure but if one success

# Generated at 2022-06-24 11:19:38.729437
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml function
    """
    # Given:
    content = """
        foo: bar
        baz:
            - qux
            - quz
    """

    class MySchema(Schema):
        foo = {"type": str}  # type: ignore
        baz = {"items": {"type": str}, "type": "array"}  # type: ignore

    # When:
    value, error_messages = validate_yaml(content, MySchema)

    # Then:
    assert value.get("foo") == "bar"
    assert value.get("baz") == ["qux", "quz"]
    assert not error_messages

# Generated at 2022-06-24 11:19:42.731369
# Unit test for function validate_yaml
def test_validate_yaml():
    class SimpleSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    result = validate_yaml(
        content='name: "jason"\nage: 100',
        validator=SimpleSchema,
    )
    assert result == {
        "name": "jason",
        "age": 100,
    }


# Generated at 2022-06-24 11:19:53.258249
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    content = """
        key:
          nested: value
        key2:
          nested2: value2
    """.strip()

    try:
        value, error_messages = validate_yaml(
            content=content, validator=Field(type_class=str)
        )
    except ValidationError:
        value, error_messages = None, []


# Generated at 2022-06-24 11:20:01.035884
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema("test schema")
    schema.add_field("foo", "string")
    schema.add_field("bar", "string")
    schema.add_field("baz", "string")

    value, error_messages = validate_yaml(b"foo: foo1\nbar: bar1\nbaz: baz1\n", schema)
    assert not error_messages
    assert value == {"foo": "foo1", "bar": "bar1", "baz": "baz1"}

    value, error_messages = validate_yaml(b"foo: foo1\nbar: bar1\n#baz: baz1\n", schema)
    assert not error_messages
    assert value == {"foo": "foo1", "bar": "bar1", "baz": None}

    value

# Generated at 2022-06-24 11:20:09.037259
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    token_string = "string"
    token_int = 2
    token_float = 3.4
    token_dict = {"name": "yaml", "language": "python"}

    content = (
        "string\n"
        "2\n"
        "3.4\n"
        "name: yaml\n"
        "language: python"
    )

    assert tokenize_yaml(content) == token_dict
    assert tokenize_yaml("") == None



# Generated at 2022-06-24 11:20:14.356340
# Unit test for function tokenize_yaml

# Generated at 2022-06-24 11:20:24.231242
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    def assert_tokenize_yaml(content: str, expected: typing.Any) -> None:
        token = tokenize_yaml(content)
        assert token == expected

    content = "a: 1\nb: 2"
    expected = [
        (DictToken({"a": 1, "b": 2}, 0, 8, content=content), ""),
        (ScalarToken("a", 0, 0, content=content), ""),
        (ScalarToken("1", 4, 4, content=content), ""),
        (ScalarToken("b", 6, 6, content=content), ""),
        (ScalarToken("2", 10, 10, content=content), ""),
    ]
    for token, name in expected:
        assert getattr(token, name) == expected[name]

    assert_tokenize

# Generated at 2022-06-24 11:20:28.549755
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test string is based on sample.yaml in test/sample.yaml
    string = """id: 19
name: bobby
location: null
temperature: 9
is_guest: true
date_of_birth: 2012-11-05
friends:
  - id: 29
    name: james
  - id: 39
    name: sally
"""
    # Test tokens are based on sample.yaml in test/sample.yaml

# Generated at 2022-06-24 11:20:35.867592
# Unit test for function validate_yaml
def test_validate_yaml():
    import os
    from typesystem.fields import AnyField, StringField
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import PositionedMessage
    from typesystem.exceptions import ValidationError

    class MySchema(Schema):
        name = StringField()
        age = AnyField()

    class ValidationTestCase:
        def __init__(self, name: str, content: str, expected_value: typing.Any):
            self.name = name
            self.content = content
            self.expected_value = expected_value


# Generated at 2022-06-24 11:20:44.440442
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
    key1: value1
    key2: value2
    '''
    token = tokenize_yaml(content)
    assert token.value == {'key1': 'value1', 'key2': 'value2'}

    # Error case
    content = '''
    key1: vlaue1
    key2: value2
    '''
    msg = 'Mapping values are not allowed here. Did you forget a colon earlier?'
    try:
        tokenize_yaml(content)
    except ParseError as e:
        assert e.text == msg

    content = '''
    key1: value1
    key2: value2
    '''
    token = tokenize_yaml(content)