

# Generated at 2022-06-24 11:10:46.581209
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import yaml
    content = yaml.safe_load("""
    - hosts
    - urls
    - files
    """)
    token = tokenize_yaml("""
    - hosts
    - urls
    - files
    """)
    assert(content == token.get_value())

# Generated at 2022-06-24 11:10:49.212171
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None
    res, err = validate_yaml(content=b"foo: bar", validator={"foo": str})
    assert res == {"foo": "bar"}
    assert err == []

# Generated at 2022-06-24 11:10:59.632668
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    class TestSchema(Schema):
        field1 = Integer()
        field2 = String(min_length=1)

    valid_yaml = "{field1: 123, field2: 'abc'}"
    result = validate_yaml(valid_yaml, TestSchema)
    assert result[0]
    assert len(result[1]) == 0

    invalid_value_yaml = "{field1: 123, field2: ['abc', 'def']}"
    result = validate_yaml(invalid_value_yaml, TestSchema)
    assert result[0] is None
    assert len(result[1]) == 2
    assert isinstance(result[1][0], ValidationError)

# Generated at 2022-06-24 11:11:01.058182
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test_content = """
        one:
            two:
                three: 3
    """
    token = tokenize_yaml(test_content)
    assert token.value == {'one': {'two': {'three': 3}}}

# Generated at 2022-06-24 11:11:09.090390
# Unit test for function validate_yaml
def test_validate_yaml():
    error_messages = validate_yaml(b"foo:\n  name: Test\n  tags: [1, 2, 3]",
                                   Schema)
    assert not error_messages

    error_messages = validate_yaml(b"foo:\n  name: Test\n  tags: [1, 2, 3]",
                                   ValidSchema)
    assert not error_messages

    error_messages = validate_yaml(b"foo:\n  name: Test\n  tags: [1, 2, 3]",
                                   InvalidSchema)
    assert error_messages
    assert len(error_messages) == 1
    assert error_messages[0].code == 'invalid_type'
    assert error_messages[0].text == 'Must be a string.'
    assert error_messages

# Generated at 2022-06-24 11:11:14.813449
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields=[
        {"type": "string"},
        {"type": "integer"},
    ])
    assert validate_yaml(
        "---\n- a\n- 1\n",
        validator=schema
    ) == (
        [ScalarToken(value="a", start=3, end=3, content="- a\n"),
         ScalarToken(value=1, start=7, end=7, content="- 1\n")],
        [],
    )

# Generated at 2022-06-24 11:11:20.654571
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    input_data = '{"a": 1}'
    content = tokenize_yaml(input_data)

    assert isinstance(content, DictToken)
    assert isinstance(content.year.value, ScalarToken)
    assert isinstance(content.year.value.value, int)
    assert content.year.value.value == 1

# Generated at 2022-06-24 11:11:29.808416
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test yaml validation"""
    class AddressSchema(Schema):
        """Schema class to test validate_yaml function"""

        street = Field(str)
        city = Field(str)
        zipcode = Field(str)
        country = Field(str)

    class UserSchema(Schema):
        """Schema class to test validate_yaml function"""

        name = Field(str)
        address = Field(AddressSchema)

    user_yaml = """
    name: John Smith
    address:
        street: 1400 Pennsylvania Avenue
        city: Washington
        zipcode: 20500
        country: United States
    """
    user_value, user_errors = validate_yaml(user_yaml, UserSchema)
    assert user_errors == {}


# Generated at 2022-06-24 11:11:33.112130
# Unit test for function validate_yaml
def test_validate_yaml():
    with open('./data-integration/test_data/bacterias.yaml', mode='rb') as file:
        assert validate_yaml(file.read(), validator=Bacterias) == ('correct', [])

if __name__ == '__main__':
    test_validate_yaml()

# Generated at 2022-06-24 11:11:45.341383
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    # Test a dictionary
    content = '{"a":1}'
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

    content = '{"a":"dict"}'
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

    # Test a list
    content = '[1,2,3]'
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)

    content = '["list"]'
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)

    # Test a scalar, integer
    content = '1'
    token = tokenize_yaml(content)

# Generated at 2022-06-24 11:11:52.432140
# Unit test for function validate_yaml
def test_validate_yaml():
    valid_content = b"""
        - name: John
          email: john@example.com
          age: 27
    """
    invalid_content = b"""
        - name: John
          email: john@example.com
          age: "27"
    """
    errors = validate_yaml(invalid_content, validator=UserSchema)
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 4
    assert errors[0].position.column_no == 13
    assert errors[0].position.char_index == 48
    assert errors[0].child_errors[0].code == "expected_integer"
    assert errors[0].child_errors[0].position.line_no == 4
    assert errors[0].child_errors[0].position.column_no

# Generated at 2022-06-24 11:12:02.551505
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=5, description="Person's name.")
        age = Integer(minimum=21, description="Person's age.")

    content = """
    name: "Bill"
    age: 23
    """
    good, errors = validate_yaml(content, validator=Person)
    assert not errors
    assert good["name"] == "Bill"
    assert good["age"] == 23

    bad_content = """
    name: "Joe"
    age: 20
    """

    good, errors = validate_yaml(bad_content, validator=Person)
    assert len(errors) == 2

    for error in errors:
        msg = error.text.split(":")[0].strip()

# Generated at 2022-06-24 11:12:11.898033
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = String(title="Name")

    content = "name: 'David'"
    value, errors = validate_yaml(content, TestSchema)
    assert value == {"name": "David"}
    assert errors == []

    content = "name: 42"
    value, errors = validate_yaml(content, TestSchema)
    assert value is None
    assert errors == [
        ValidationError(
            text="Must be a string.",
            code="invalid",
            path=["name"],
            position=Position(line_no=1, column_no=5, char_index=5),
        )
    ]

    content = "fake: 'David'"
    value, errors = validate_yaml(content, TestSchema)
    assert value is None

# Generated at 2022-06-24 11:12:18.103919
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        first_name: "Jane"
        last_name: "Doe"
        email: "jane@example.com"
    """
    class PersonSchema(Schema):
        first_name = String(max_length=100)
        last_name = String(max_length=100)
        email = Email()
    value, messages = validate_yaml(content, PersonSchema)
    assert isinstance(value, dict)
    assert len(messages) == 0



# Generated at 2022-06-24 11:12:28.559562
# Unit test for function validate_yaml
def test_validate_yaml():
    # Tests for success cases
    assert validate_yaml(content=b'{"foo": "bar", "bar": "baz"}', validator=Schema) == ({"foo": "bar", "bar": "baz"}, [])
    assert validate_yaml(content=b'[1, 2, 3]', validator=Schema) == ([1, 2, 3], [])
    assert validate_yaml(content=b'"foobar"', validator=Schema) == ("foobar", [])

    # Tests for failure cases
    try:
        validate_yaml(content=b'{"foo": "bar", "bar": "baz", "moo", "moo"}', validator=Schema)
    except ParseError as e:
        assert e.text == "Invalid sequence or mapping."

# Generated at 2022-06-24 11:12:36.050343
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    assert tokenize_yaml("") == None
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}
    assert tokenize_yaml("foo: 123") == {"foo": 123}
    assert tokenize_yaml("foo: 123.4") == {"foo": 123.4}
    assert tokenize_yaml("foo: true") == {"foo": True}
    assert tokenize_yaml("foo: null") == {"foo": None}
    assert tokenize_yaml("foo: 123\nbar: 456") == {"foo": 123, "bar": 456}



# Generated at 2022-06-24 11:12:45.477869
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.text.validators import MarkdownString
    from typesystem.text.fields import MarkdownField
    from typesystem.text.schemas import MarkdownSchema

    class TestSchema(MarkdownSchema):
        class Meta:
            field_validators = [MarkdownString()]

    class TestField(MarkdownField):
        def __init__(self):
            super().__init__()
            self.validators.append(MarkdownString())


# Generated at 2022-06-24 11:12:55.959669
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John"
    age: 32
    occupation: "Dentist"
    salary: 75000
    """

    # Test with a Schema
    class TestSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)
        occupation = Field(type=str)
        salary = Field(type=int)

    # Define a custom validator for the occupation field
    class TestOccupationValidator(Field):
        def validate(self, value: typing.Any) -> typing.Any:
            if value not in ["Dentist", "Mechanic", "Teacher"]:
                raise ValidationError("Invalid occupation")
            return value

    # Update the occupation field
    TestSchema.fields["occupation"] = TestOccupationValidator()
    value, error_

# Generated at 2022-06-24 11:13:05.766071
# Unit test for function validate_yaml
def test_validate_yaml():
    #Test for a valid yaml
    with open('./test/test_yaml.yaml') as f:
        yaml = f.read()
        value, errors = validate_yaml(yaml, validator=Schema)
        assert value
        assert not errors

    #Test for a valid yaml with a single error
    with open('./test/test_yaml_error.yaml') as f:
        yaml = f.read()
        value, errors = validate_yaml(yaml, validator=Schema)
        assert not value
        assert len(errors) == 1
        assert errors[0].text == "Must be a number."

    #Test for a valid yaml with multiple errors
    with open('./test/test_yaml_errors.yaml') as f:
        yaml = f

# Generated at 2022-06-24 11:13:17.113604
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem

    age = typesystem.Integer(min_value=0)
    name = typesystem.String(min_length=3)

    class Person(typesystem.Schema):
        age = age
        name = name

    data = "name: 'foo'\nage: 10\n"

    value, error_messages = validate_yaml(data, Person)

    assert {} == value
    assert [
        ValidationError(
            field_name="name",
            message="Must be at least 3 characters.",
            code="min_length",
            path=[],
        ),
        ValidationError(
            field_name="name",
            message="A valid string is required.",
            code="required",
            path=[],
        ),
    ] == error_messages

# Generated at 2022-06-24 11:13:25.722243
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Single word 
    content = "word"
    token = tokenize_yaml(content)
    assert token.__class__ is ScalarToken
    assert token.start == 0
    assert token.end == 3
    assert token.content == content

    # Single number
    content = "1"
    token = tokenize_yaml(content)
    assert token.__class__ is ScalarToken
    assert token.start == 0
    assert token.end == 1
    assert token.content == content

    # Single list
    content = "[]"
    token = tokenize_yaml(content)
    assert token.__class__ is ListToken
    assert token.start == 0
    assert token.end == 1
    assert token.content == content

    # Single null
    content = "null"
    token = tokenize_yaml

# Generated at 2022-06-24 11:13:30.562811
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "\"Some Value\n"
    field = Field.string()
    assert validate_yaml(content, field) == ('Some Value', [])

    content = "not: a: valid: yaml"
    field = Field.string()
    assert validate_yaml(content, field) == (None, [('text', 'Expected a string.')])


# Generated at 2022-06-24 11:13:40.677635
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("15") == 15
    assert tokenize_yaml("1.5") == 1.5
    assert tokenize_yaml("true") is True
    assert tokenize_yaml("false") is False
    assert tokenize_yaml("null") is None
    assert tokenize_yaml("[1, 2]") == [1,2]
    assert tokenize_yaml("{:age:12,:name:jason}") == {":age":12,":name":"jason"}
    assert tokenize_yaml("") == ""
    assert tokenize_yaml("\n") == ""


# Generated at 2022-06-24 11:13:43.326401
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(content='''name: Eric\nage: 33''') == {'name': 'Eric', 'age': 33}
    

# Generated at 2022-06-24 11:13:52.330746
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(b"hello: world")
    assert isinstance(token, DictToken)
    assert token.value == {"hello": "world"}
    assert token.start == 0
    assert token.end == len("hello: world") - 1

    assert isinstance(token.get("hello"), ScalarToken)
    assert token.get("hello").value == "world"
    assert token.get("hello").start == len("hello: ")
    assert token.get("hello").end == len("hello: world") - 1



# Generated at 2022-06-24 11:13:58.025737
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    try:
        from typesystem.tokenize.positional_validation import validate_with_positions

        validator = schema_class(fields=[field("x", type="string")])
        value, errors = validate_yaml(
            """
        x: foo

        y: bar
      """,
            validator,
        )
        assert not errors
        assert value == {"x": "foo"}
    except AssertionError as e:
        raise e
    except:
        pass

import typesystem
from typesystem import fields
from typesystem import schemas


# Generated at 2022-06-24 11:14:04.223394
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema()
    schema.add_field("name", str)
    schema.add_field("age", int)

    value, error_list = validate_yaml("{name: ann, age: 56}", validator=schema)

    assert isinstance(value, dict)
    assert value == {"name": "ann", "age": 56}
    assert len(error_list) == 0

# Generated at 2022-06-24 11:14:11.665574
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import fields, struct

    class UserSchema(struct.Schema):
        name = fields.String()
        age = fields.Integer()

    errors = validate_yaml(
        """
        name: James
        age: blah
    """,
        UserSchema,
    )
    assert len(errors) == 1
    error = errors[0]
    assert error.code == "invalid_type"
    assert error.position.line_no == 3
    assert error.position.column_no == 4



# Generated at 2022-06-24 11:14:17.648885
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields

    class User(Schema):
        username = fields.String()
        email = fields.Email()
        age = fields.Integer(required=False)

    data = """
        username: dolph
        email: dolph@aquaman
    """

    value, errors = validate_yaml(data, User)

    assert value == {
        "username": "dolph",
        "email": "dolph@aquaman",
    }
    assert errors == [
        Message("Missing required field 'age'.", code="missing_field", position=Position(line_no=3, column_no=18, char_index=47)),
    ]

    data = """
        email: dolph@aquaman
        username: dolph
    """

    value, errors = validate_yaml(data, User)

# Generated at 2022-06-24 11:14:24.155594
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        title = "My schema"
        description = "Validates a YAML string"
        typ = "object"
        properties = {"name": {"type": "string", "title": "Name"}}
        required = ["name"]

    content = "\n\nname: John\n\n"
    value, errors = validate_yaml(content, validator=MySchema)

    assert value == {"name": "John"}
    assert errors == []


# Generated at 2022-06-24 11:14:32.274902
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String

    # Valid test
    content = b"'Test String'"
    validator = String()
    valid, errors = validate_yaml(content, validator)
    assert valid == 'Test String'
    assert len(errors) == 0

    # Invalid test
    content = b'"Test String'
    validator = String()
    valid, errors = validate_yaml(content, validator)
    assert valid is None
    assert len(errors) == 1
    assert errors[0].text == "Unmatched '\"'."
    assert errors[0].code == "parse_error"
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 1
    assert errors[0].position.char_index == 0



# Generated at 2022-06-24 11:14:41.258160
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None

    #str_content = "anything"
    #token = tokenize_yaml(str_content)
    #error_messages = validate_with_positions(token,validator = IntegerField())
    #assert isinstance(error_messages, list)
    #assert len(error_messages) == 1
    # assert error_messages[0].code == "invalid"
    #assert error_messages[0].text == '"anything" is not of type "integer"'
    #assert error_messages[0].position.line_no == 1
    #assert error_messages[0].position.column_no == 1
    #assert error_messages[0].position.char_index == 0

    str_content = "true"

# Generated at 2022-06-24 11:14:44.229301
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert_equal(type(tokenize_yaml("root:")), DictToken)
    assert_equal(type(tokenize_yaml("- root:")), ListToken)


# Generated at 2022-06-24 11:14:46.908854
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    key:
        - 1
        - 2
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.get("key"), ListToken)


# Generated at 2022-06-24 11:14:53.860645
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    field = Field(type='string')

    content = 'str'
    token = tokenize_yaml(content)
    value, messages = validate_with_positions(token=token, validator=field)

    # value is not None
    assert value is not None

    # value is str
    assert isinstance(value, str)

    assert len(messages) == 0



# Generated at 2022-06-24 11:15:02.521156
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Given
    content = """# Here is a comment
animals:
- cat
- dog
- python
"""
    # When
    token = tokenize_yaml(content)
    # Then
    expected = {
        "animals": [
                {"token_type": "scalar", "value": "cat"},
                {"token_type": "scalar", "value": "dog"},
                {"token_type": "scalar", "value": "python"},
                ],
        "token_type": "dict",
    }
    assert token == expected, "Should parse as expected"

# Generated at 2022-06-24 11:15:03.301874
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert True

# Generated at 2022-06-24 11:15:14.455700
# Unit test for function validate_yaml
def test_validate_yaml():
    #Unit test for function validate_yaml
    assert yaml is not None, "'pyyaml' must be installed."

    #It should return value as a dictionary and error_messages as an array
    #with two tuples, if the content is valid YAML raw data
    raw_data = """
            - name: Alex
              age: 7
              country: USA
            - name: John
              age: 7
              country: England
            """
    from typesystem.fields import Text, Number, Array, Object, String
    from typesystem.fields import Object
    from typesystem import Schema
    class Person(Schema):
        name = String(max_length=10, required=True)
        age = Number(minimum=0, maximum=100, required=True)
        country = Text()

    value, error_messages = validate_

# Generated at 2022-06-24 11:15:24.801025
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("1") == ScalarToken("1", 0, 0, content="1")
    assert tokenize_yaml("'test'") == ScalarToken("test", 0, 4, content="'test'")
    assert tokenize_yaml("- 1\n- 2") == ListToken([ScalarToken("1", 1, 1, content="- 1\n- 2"), ScalarToken("2", 5, 5, content="- 1\n- 2")], 0, 8, content="- 1\n- 2")
    assert tokenize_yaml("a: 1") == DictToken({ScalarToken("a", 0, 0, content="a: 1"): ScalarToken("1", 3, 3, content="a: 1")}, 0, 4, content="a: 1")



# Generated at 2022-06-24 11:15:26.587768
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("[1, 2, 3]")
    assert type(token) == ListToken
    assert token.end_index == len("[1, 2, 3]") - 1



# Generated at 2022-06-24 11:15:36.059831
# Unit test for function validate_yaml
def test_validate_yaml():

    # Successful parsing and validation
    valid_yaml = """
    a: "something"
    b: 15
    c:
    - 1
    - 2
    - 3
    """
    class TestSchema(Schema):
        a = Field(string)
        b = Field(integer)
        c = Field(list_of(integer))

    value, error_messages = validate_yaml(content=valid_yaml, validator=TestSchema)

    assert value == {
        "a": "something",
        "b": 15,
        "c": [1, 2, 3]
    }
    assert error_messages == []

    # Parse error
    invalid_yaml = """
    a: "something"
    "b": 15
    """
    value, error_messages = validate_y

# Generated at 2022-06-24 11:15:46.629126
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(b"{'name': 'graphql', 'surname': 'python'}")
    assert isinstance(token, DictToken)

    token = tokenize_yaml(b"["
                          b"{'name': 'graphql', 'surname': 'python'},"
                          b"{'name': 'graphql', 'surname': 'python'}"
                          b"]")
    assert isinstance(token, ListToken)

    token = tokenize_yaml(b"42")
    assert isinstance(token, ScalarToken)

    token = tokenize_yaml(b"true")
    assert isinstance(token, ScalarToken)

    token = tokenize_yaml(b"false")
    assert isinstance(token, ScalarToken)

    token = tokenize

# Generated at 2022-06-24 11:15:54.795792
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Array, Boolean, Integer

    from .utils import get_content, schema_to_string, schema_to_field

    validator: typing.Union[Field, typing.Type[Schema]]

    # Test simple boolean and integer fields.
    validator = Boolean()
    assert validate_yaml(content="true", validator=validator) == (True, [])
    assert validate_yaml(content="false", validator=validator) == (False, [])

    validator = Integer()
    assert validate_yaml(content="42", validator=validator) == (42, [])

    # Test simple array.
    content = get_content("test_validate_yaml.yaml")
    validator = Array(items=Integer())

# Generated at 2022-06-24 11:16:06.037902
# Unit test for function validate_yaml
def test_validate_yaml():
    content1 = '''
    name: yaml
    age: 29
    '''

    class PersonSchema(Schema):
        name = types.String(max_length=10)
        age = types.Integer(minimum=18, maximum=99)

    value, errors = validate_yaml(content1, PersonSchema)
    assert value == {'name': 'yaml', 'age': 29}
    assert errors == []

    content2 = '''
    name: yaml
    height: 6.0
    weight: 160
    '''

    class PersonSchema(Schema):
        name = types.String(max_length=10)
        age = types.Integer(minimum=18, maximum=99)

    value, errors = validate_yaml(content2, PersonSchema)

# Generated at 2022-06-24 11:16:14.314714
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer

    # checks that validation works without any errors
    value, errors = validate_yaml("42", Integer(max_value=50))
    assert value == 42
    assert errors == []

    # checks that validation works with errors
    value, errors = validate_yaml("42", Integer(max_value=1))
    assert value == 42
    assert len(errors) == 1
    assert errors[0].text == "The maximum allowed value is 1."
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 1
    assert errors[0].position.char_index == 0
    assert errors[0].code == "max_value"

# Generated at 2022-06-24 11:16:23.838857
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), DictToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("42"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("'test'"), ScalarToken)
    assert isinstance(tokenize_yaml('"test"'), ScalarToken)

    # Test position information.
    assert tokenize_yaml("{}")[0].position.char_index == 0
    assert tokenize_

# Generated at 2022-06-24 11:16:30.159436
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    test: 12
    """
    # Parse content
    token = tokenize_yaml(content)
    # Assert if the parsed content has valid token structure
    assert token
    assert issubclass(type(token), DictToken)
    assert token.value.keys() == {"test"}
    assert token.value["test"] == ScalarToken(
        "12", 1, 6, content="\n    test: 12\n    "
    )
    assert token.start == 1
    assert token.end == 6



# Generated at 2022-06-24 11:16:33.994288
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    a: b
    c:
        - d1
        - d2
    """)
    assert token.value == {'a': 'b', 'c': ['d1', 'd2']}
    assert token.start == 0
    assert token.end == 37


# Generated at 2022-06-24 11:16:44.598625
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content="""
        foo: bar
        baz:
            - 1
            - 2
            - 3
        """
    token = tokenize_yaml(content)
    assert type(token) == DictToken
    assert token.start_index == len(content)-len(content.strip())
    assert token.end_index == len(content)

    assert type(token.data["foo"]) == ScalarToken
    assert token.data["foo"].start_index == content.find("bar")
    assert token.data["foo"].end_index == token.data["foo"].start_index+len("bar")

    assert type(token.data["baz"]) == ListToken
    assert token.data["baz"].start_index == content.find("baz")
    assert token.data["baz"].end

# Generated at 2022-06-24 11:16:51.451766
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import String
    from typesystem.schemas import Schema

    class A(Schema):
        name = String()
        age = String()

    schema = A.as_yaml()

    result, errors = validate_yaml(schema, A)
    assert errors == []

    bad_schema = "hello"
    result, errors = validate_yaml(bad_schema, A)
    assert errors != []



# Generated at 2022-06-24 11:17:01.843460
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    def _token_check(token, expected):
        if isinstance(token, ScalarToken):
            assert token._value == expected
        elif isinstance(token, ListToken):
            assert len(token._value) == len(expected)
            for token_item, expected_item in zip(token._value, expected):
                _token_check(token_item, expected_item)
        elif isinstance(token, DictToken):
            assert len(token._value) == len(expected)
            for key in expected:
                _token_check(token._value[key], expected[key])
        else:
            assert False


# Generated at 2022-06-24 11:17:12.384046
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
name:
  first: foo
  last: bar
""")
    assert isinstance(token, Token)
    assert isinstance(token.get("name"), Token)
    assert isinstance(token.get("name").get("first"), Token)
    assert isinstance(token.get("name").get("last"), Token)

    assert token.get("name").get("first").start == 15
    assert token.get("name").get("first").end == 19
    assert token.get("name").get("last").start == 28
    assert token.get("name").get("last").end == 31

    assert token.get("name").get("first").source == "foo"
    assert token.get("name").get("last").source == "bar"


# Generated at 2022-06-24 11:17:21.286643
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    assert tokenize_yaml("""
    foo:
        - one
        - two
        - three
    """) == {
        "foo": [
            ScalarToken("one", 9, 11, content="""
    foo:
        - one
        - two
        - three
    """),
            ScalarToken("two", 15, 17, content="""
    foo:
        - one
        - two
        - three
    """),
            ScalarToken("three", 21, 26, content="""
    foo:
        - one
        - two
        - three
    """),
        ]
    }


# Generated at 2022-06-24 11:17:31.830048
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        - 1:
            - 11
        - 2:
            - 21
            - 22
        - 3:
            - 31
            - 32
            - 33
        - 4
    """
    str_content = content.expandtabs().strip()
    end_of_first_line = len(str_content.splitlines()[0]) + 1
    token = tokenize_yaml(content)
    assert token.value == [
        {"1": [11]},
        {"2": [21, 22]},
        {"3": [31, 32, 33]},
        4,
    ]
    assert token.start == 0
    assert token.end == len(str_content) - 1

# Generated at 2022-06-24 11:17:41.682463
# Unit test for function validate_yaml
def test_validate_yaml():
    # Simple case: nothing is wrong with the YAML content
    validator = Field(name='a', required=True, type='string')
    content = b'a: bowman'
    assert("{'a': 'bowman'}, [])" == repr(validate_yaml(content, validator)))
    
    # YAML has syntax error, e.g. 'a: bobman'
    content = b'a: bobman'
    assert(("{'errors': {'a': 'Value must be of type \'string\'.'}}" == repr(validate_yaml(content, validator))) | \
    ("{'errors': {'a': 'Value must be of type &apos;string&apos;.'}}" == repr(validate_yaml(content, validator))))

    # YAML has missing

# Generated at 2022-06-24 11:17:53.811204
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem import types

    content = "foo: bar"
    token = tokenize_yaml(content)
    assert token.content == content
    assert token["foo"].content == "bar"
    assert token.start == 0
    assert token.end == 7
    assert token["foo"].start == 4
    assert token["foo"].end == 7
    assert token["foo"].position == Position(line_no=1, column_no=5, char_index=4)
    assert token["foo"].value == "bar"

    content = """
    foo: [bar, baz]
    """
    token = tokenize_yaml(content)
    assert token.content == content
    assert token["foo"].content == "bar"
    assert token["foo"][1].content == "baz"

# Generated at 2022-06-24 11:18:05.159521
# Unit test for function validate_yaml
def test_validate_yaml():
    '''
    This is a unit test for the function validate_yaml
    '''
    # Test of a list field
    list_field = Field(type=["array", "string"])
    # The field type is list and the content is a list - good
    value_ok, messages = validate_yaml('["a", "b"]', list_field)
    assert not messages
    assert value_ok == ['a', 'b']
    # The field type is list and the content is a string - bad
    value_bad, messages = validate_yaml('"a"', list_field)
    assert messages
    assert messages[0].code == "type_error"
    assert value_bad is None
    # Test of a string field
    string_field = Field(type="string")
    # The field type is string and the content is

# Generated at 2022-06-24 11:18:12.426788
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class PetSchema(Schema):
        name = String(max_length=30)
        age = Integer()

    content = """
    name: 'Fido'
    age: 13
    """
    value, errors = validate_yaml(content=content, validator=PetSchema)
    assert errors == []
    assert value["name"] == "Fido"
    assert value["age"] == 13



# Generated at 2022-06-24 11:18:18.236037
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """ Test function for function 'tokenize_yaml'.
    """
    content = '''
     name: John
     age: 23
     location:
       city: "New York"
       country: US
    '''
    token = tokenize_yaml(content)
    assert token.value == {
        "name": "John",
        "age": 23,
        "location": {
            "city": "New York",
            "country": "US"
        }
    }
    assert token.start == 0
    assert token.end == 66



# Generated at 2022-06-24 11:18:26.040874
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = {
        "name": "Jane Doe",
        "address": "400 Ala Moana Blvd",
        "zip_code": "96813",
    }

    validator = parse_yaml_schema(
        """
        type: object
        properties:
          name:
            type: string
          address:
            type: string
          zip_code:
            type: string
        """
    )

    value, errors = validate_yaml(
        yaml.dump(schema), validator
    )
    assert not errors

# Generated at 2022-06-24 11:18:36.659160
# Unit test for function tokenize_yaml

# Generated at 2022-06-24 11:18:38.727371
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = "text"
        age = "integer"

    content = """
    name: Lorem
    age: 25
    """

    value, errors = validate_yaml(content, Person)



# Generated at 2022-06-24 11:18:45.946581
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.json_schema import Object, String

    # Schema definition
    class MySchema(Schema):
        key = String()

    yaml_content = "key: value"

    (value, error_messages) = validate_yaml(yaml_content, MySchema)

    assert value == {"key": "value"}
    assert error_messages == []

    # Invalid yaml content
    yaml_content = "key: \n  value"
    (value, error_messages) = validate_yaml(yaml_content, MySchema)

    assert error_messages[0].text == "found unacceptable indentation."
    assert error_messages[0].position.char_index == len('key: \n ')

    # # Invalid yaml content

# Generated at 2022-06-24 11:18:51.340821
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()
        married = Boolean()

    errors = validate_yaml(
        """
        name: Jack
        age: 35
        married: false
        """,
        Person,
    )
    model = Person({"name": "Jack", "age": 35, "married": False})
    assert errors is None
    assert model == model

# Generated at 2022-06-24 11:19:02.333345
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem.fields import String, Integer, Boolean

    class PersonSchema(Schema):
        name = String(required=True)
        age = Integer(required=True)
        alive = Boolean(default=True)

    content = """
    name: Jane Smith
    age: 40
    """.strip()

    valid, error_messages = validate_yaml(content, PersonSchema)
    assert not error_messages
    assert valid.dict() == {
        "name": "Jane Smith",
        "age": 40,
        "alive": True,
    }

    valid, error_messages = validate_yaml(content, PersonSchema)
    assert not error_messages

# Generated at 2022-06-24 11:19:09.851682
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array

    class Person(Schema):
        email = String(max_length=100)
        age = Integer()
        friends = Array(items=["email"])

    content = b"""\
email: dave@example.com
age: 35
friends:
  - tim@example.com
"""

    # Valid document
    assert validate_yaml(content=content, validator=Person) == (
        {
            "email": "dave@example.com",
            "age": 35,
            "friends": ["tim@example.com"],
        },
        [],
    )

    # Invalid document as `age` is not an integer
    content = b"""\
email: dave@example.com
age: "35"
friends:
  - tim@example.com
"""


# Generated at 2022-06-24 11:19:13.372422
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_string = """
list: []
dict:
  key: value
"""
    schema = Schema(fields={"list": Field(type="list"), "dict": Field(type="dict")})
    value, error_messages = validate_yaml(content=yaml_string, validator=schema)
    assert value == {"list": [], "dict": {"key": "value"}}
    assert error_messages == []



# Generated at 2022-06-24 11:19:24.807777
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Array
    from typesystem.tokenize import Position, Message

    pattern = String(pattern="^\\d+$")

    valid, errors = validate_yaml(content="[]", validator=Array(items=pattern))
    assert valid == []
    assert errors == []

    valid, errors = validate_yaml(content="[123, abc]", validator=Array(items=pattern))
    assert valid == [123, "abc"]

    expected_error = Message(
        text="Must be in the format of a number.",
        code="invalid_pattern",
        position=Position(
            char_index=7,
            column_no=8,
            line_no=1,
        ),
    )
    assert errors == [expected_error]

# Generated at 2022-06-24 11:19:27.471168
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == {"": ""}
    assert tokenize_yaml("{}").start == 0
    assert tokenize_yaml("{}").end == 1


# Generated at 2022-06-24 11:19:37.764862
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = field = fields.String()

    content = b"""
    name: "Bill"
    """
    value, messages = validate_yaml(content, Person)
    assert messages == []
    assert value['name'] == "Bill"

    content = b"""
    missing: "Bill"
    """
    value, messages = validate_yaml(content, Person)
    assert messages == [Message(
        code='field_required',
        kind='error',
        text='This field is required.',
        position=Position(char_index=4, column_no=5, line_no=2),
    )]
    assert value == {}


__all__ = ["tokenize_yaml", "validate_yaml"]

# Generated at 2022-06-24 11:19:45.191952
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token_dict = tokenize_yaml('{"name": "Eric Chung"}')
    print(token_dict)
    token_dict_2 = tokenize_yaml('{"name": "Eric Chung", "age": 28}')
    print(token_dict_2)
    token_list = tokenize_yaml('["Eric Chung"]')
    print(token_list)
    token_int = tokenize_yaml('123')
    print(token_int)
    token_float = tokenize_yaml('123.456')
    print(token_float)
    token_empty_string = tokenize_yaml('')
    print(token_empty_string)
    token_bool = tokenize_yaml('true')
    print(token_bool)
    token_null = tokenize_yaml('null')
   

# Generated at 2022-06-24 11:19:54.700586
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    class Person(Schema):
        name = String()
        age = Integer(minimum=0)

    content = b"name: \"test_user\"\nage: -1"
    assert isinstance(validate_yaml(content, validator=Person), tuple)
    assert isinstance(validate_yaml(content, validator=Person)[0], Person)
    assert isinstance(validate_yaml(content, validator=Person)[1], list)
    assert isinstance(validate_yaml(content, validator=Person)[1][0], Message)

    content = b"name: \"test_user\"\nage: 1"
    assert isinstance(validate_yaml(content, validator=Person), tuple)

# Generated at 2022-06-24 11:19:58.951568
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yamlstring = """
        - a
        - b
        - c
    """
    list = ListToken(
        value=["a", "b", "c"],
        start=0,
        end=len(yamlstring) - 1,
        content=yamlstring,
    )

    assert list == tokenize_yaml(yamlstring)

# Generated at 2022-06-24 11:20:09.626977
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """Test function tokenize_yaml"""
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize import validate_yaml
    from typesystem.fields import Integer, String, Boolean

    class MySchema(Schema):
        name = String()
        age = Integer()
        has_car = Boolean()

    # Test valid YAML records
    my_yaml = """
    name: hello
    age: 55
    hasCar: True
    """
    my_test = validate_yaml(my_yaml, MySchema)
    assert my_test[0] is not None
    assert my_test[1] is None


# Generated at 2022-06-24 11:20:17.983505
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test a simple scalar
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")

    # Test a string scalar
    assert (
        tokenize_yaml("'foo'")
        == ScalarToken("foo", 1, 4, content="'foo'")
    )
    assert (
        tokenize_yaml('"foo"')
        == ScalarToken("foo", 1, 4, content='"foo"')
    )

    # Test a scalar that might be a boolean
    assert (
        tokenize_yaml("Yes")
        == ScalarToken("Yes", 0, 2, content="Yes")
    )

    # Test a scalar that is a boolean

# Generated at 2022-06-24 11:20:28.041838
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # -------------- success (single value)
    # string
    assert tokenize_yaml("foo") == ScalarToken("foo", start=0, end=3, content="foo")
    # integer
    assert tokenize_yaml("1") == ScalarToken(1, start=0, end=1, content="1")
    # float
    assert tokenize_yaml("2.5") == ScalarToken(
        2.5, start=0, end=3, content="2.5"
    )
    # boolean - true
    assert tokenize_yaml("true") == ScalarToken(True, start=0, end=4, content="true")
    # boolean - false
    assert tokenize_yaml("false") == ScalarToken(
        False, start=0, end=5, content="false"
    )

# Generated at 2022-06-24 11:20:39.566264
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer
    from typesystem.schemas import Schema, fields
    from typesystem.types import Text

    schema = Schema([fields.String("name"), fields.Integer("age")])
    content = """
        name: Jane
        age: 25
    """
    token, error_messages = validate_yaml(content, schema)
    assert token.value["name"] == "Jane"
    assert token.value["age"] == 25
    assert not error_messages

    content = """
        name: Jane
        age: 25
        extra: field
    """
    token, error_messages = validate_yaml(content, schema)
    assert token.value["name"] == "Jane"
    assert token.value["age"] == 25
    assert len(error_messages) == 1

# Generated at 2022-06-24 11:20:44.228934
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields
    class Person(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True)

    yaml_str = """---
name: Jane
age: 45
"""
    value, errors = validate_yaml(yaml_str, Person)
    assert value == {'name': 'Jane', 'age': 45}
    assert not errors
