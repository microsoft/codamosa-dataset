

# Generated at 2022-06-24 11:10:52.185336
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from yaml import load
    from yaml import SafeLoader
    from yaml.loader import ConstructorError, MappingNode, SequenceNode, ScalarNode
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class FakeYamlNode:
        def __init__(self, start_index=0, end_index=0):
            self.start_mark = FakeYamlMark(start_index)
            self.end_mark = FakeYamlMark(end_index)

        def __repr__(self):
            return "<FakeYamlNode>"

    class FakeYamlMark:
        def __init__(self, index):
            self.index = index

    class CustomSafeLoader(SafeLoader):
        pass

    def construct_mapping(loader, node):
        mapping = loader.construct_m

# Generated at 2022-06-24 11:10:56.892866
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_string = """\
    foo: bar
    baz: qux
    """
    token = tokenize_yaml(yaml_string)

    assert isinstance(token, DictToken)
    assert token.tree_content["foo"] == "bar"
    assert token.tree_content["baz"] == "qux"
    assert token.content == yaml_string
    assert token.positions["foo"][0] == _get_position(yaml_string, index=7)
    assert token.positions["baz"][0] == _get_position(yaml_string, index=23)



# Generated at 2022-06-24 11:11:06.723207
# Unit test for function validate_yaml
def test_validate_yaml():
    # Tests for inputs provided by user
    # 1. Content of type string
    content = """
    - {name: arpit, age: 21}
    - {name: ankita, age: 20}
    - {name: tanvi, age: 19}
    """
    schema = Schema({"name": str, "age": int}, name="Student")
    assert validate_yaml(content=content, validator=schema) == ([], {})
    # 2. Content of type bytes
    content = b"""
    - {name: arpit, age: 21}
    - {name: ankita, age: 20}
    - {name: tanvi, age: 19}
    """
    assert validate_yaml(content=content, validator=schema) == ([], {})

# Generated at 2022-06-24 11:11:11.227035
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b'foo: bar\n'
    validator = Schema.of(foo=Field(type=str, required=True))
    value, errors = validate_yaml(content, validator)
    assert value == {"foo": "bar"}
    assert isinstance(errors, list)
    assert len(errors) == 0



# Generated at 2022-06-24 11:11:18.087603
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {"name": Field(String), "value": Field(Number), "if": Field(Boolean)}
    )
    (value, errors) = validate_yaml(
        """
        name: 'test'
        value: 7
        if: true
    """.strip(),
        schema,
    )
    assert value == {"name": "test", "value": 7, "if": True}
    assert len(errors) == 0

# Generated at 2022-06-24 11:11:20.927966
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), DictToken)
    assert isinstance(tokenize_yaml("test_json"), DictToken)



# Generated at 2022-06-24 11:11:29.958392
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        username=String(min_length=3, max_length=10),
        password=String(min_length=8),
        active=Bool(),
        age=Integer(minimum=18, maximum=100),
    )
    content = "username: Frank\n"
    value, error_messages = validate_yaml(content=content, validator=schema)
    assert len(error_messages) == 3
    assert error_messages[0]["text"] == 'Missing field "password".'
    assert error_messages[1]["text"] == 'Missing field "active".'
    assert error_messages[2]["text"] == 'Missing field "age".'
    assert value is None


# Generated at 2022-06-24 11:11:36.561150
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('{"age": "5", "name": "Jill", "locations": ["Boston","Seoul"], "value":  null}')
    assert isinstance(token, DictToken)
    assert len(token.value) == 4
    assert token.value["age"].value == "5"
    assert token.value["name"].value == "Jill"
    assert token.value["locations"].value == ["Boston","Seoul"]
    assert token.value["value"].value ==  None

    assert token.position_start == 0
    assert token.position_end == 55



# Generated at 2022-06-24 11:11:46.898621
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    mocks = {
        "content1": '{a: 1, b: "c"}',
        "content2": '[a, 1, "c"]',
        "content3": '1',
        "content4": "true",
        "content5": "false",
        "content6": "null",
        "content7": "true\n1\n- [a, b]",
    }
    assert isinstance(tokenize_yaml(mocks["content1"]), DictToken)
    assert isinstance(tokenize_yaml(mocks["content2"]), ListToken)
    assert isinstance(tokenize_yaml(mocks["content3"]), ScalarToken)
    assert isinstance(tokenize_yaml(mocks["content4"]), ScalarToken)

# Generated at 2022-06-24 11:11:54.949183
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test with a string value.
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")
    # Test with a byte value.
    assert tokenize_yaml(b"foo") == ScalarToken("foo", 0, 2, content="foo")
    # Test with a string literal.
    assert tokenize_yaml("'foo'") == ScalarToken("foo", 0, 5, content="'foo'")
    # Test with a string literal that includes an escaped single quote.
    assert tokenize_yaml("'foo\\''") == ScalarToken(
        "foo'", 0, 7, content="'foo\\''"
    )
    # Test with a numeric value.
    assert tokenize_yaml("123") == ScalarToken(123, 0, 3, content="123")

# Generated at 2022-06-24 11:12:01.105081
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
      field: value
      list:
        - value1
        - value2
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert "field" in token
    assert token["field"] == "value"

    assert "list" in token
    assert isinstance(token["list"], ListToken)
    assert token["list"] == ["value1", "value2"]



# Generated at 2022-06-24 11:12:06.079606
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_string = "testvalue: testvalue2"
    schema = Schema('test', {'testvalue': String()})
    assert validate_yaml(yaml_string, schema)  # should pass
    yaml_string = "testvalue: 123"
    assert not validate_yaml(yaml_string, schema)  # should fail

if __name__ == "__main__":
  test_validate_yaml()

# Generated at 2022-06-24 11:12:15.156698
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String, Schema, ValidationError
    from typesystem.schemas import get_schema_errors

    class MySchema(Schema):
        name = String()
        age = Integer()

    value, error_messages = validate_yaml(b"age: hi", MySchema)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 4
    assert error_messages[0].position.char_index == 5

    value, error_messages = validate_yaml(b"age: hi", MySchema(partial=True))
    assert value == {"age": "hi"}
    assert len(error_messages) == 0

   

# Generated at 2022-06-24 11:12:20.140414
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    try:
        import yaml
        from typesystem.tokenize.tokens import DictToken
    except ImportError:
        return
    # Test a simple case
    content = '{"fname":"Dhruv", "lname": "Kaushish"}'
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.source.decode('utf-8') == content
    assert token.end == len(content) - 1
    assert token.attributes == {'fname': 'Dhruv', 'lname': 'Kaushish'}


# Generated at 2022-06-24 11:12:25.463908
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        int_field = Field(Integer)

    content = "int_field: 'hello'"
    result = validate_yaml(content, MySchema)
    assert result[1][0].text == "Must be an integer."
    assert result[1][0].position.line_no == 1
    assert result[1][0].position.column_no == 11



# Generated at 2022-06-24 11:12:26.083180
# Unit test for function validate_yaml
def test_validate_yaml():
    pass

# Generated at 2022-06-24 11:12:32.143957
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import fields
    from typesystem.schema import Schema

    class PersonSchema(Schema):
        name = fields.String(max_length=5)
        age = fields.Integer()

    content = """
        name: Alex
        age: 22
    """

    validator = PersonSchema()
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "Alex", "age": 22}
    assert error_messages == []



# Generated at 2022-06-24 11:12:40.154269
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('"a"') == ScalarToken("a", 0, 3, content='"a"')
    assert tokenize_yaml('"a": null') == DictToken({"a": None}, 0, 8, content='"a": null')
    assert tokenize_yaml('[1, 2, 3]') == ListToken([1, 2, 3], 0, 8, content='[1, 2, 3]')
    assert tokenize_yaml('{1, 2, 3}') == DictToken({1: None, 2: None, 3: None}, 0, 8, content='{1, 2, 3}')
    assert tokenize_yaml('a: null') == DictToken({"a": None}, 0, 7, content='a: null')
    assert tokenize_yaml('[1]')

# Generated at 2022-06-24 11:12:51.009095
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class Person(Schema):
        name = String(required=True, max_length=32)
        age = Integer()

    yaml_content = """
        ---
        name: Alice
        age: 18
    """

    value, error_messages = validate_yaml(yaml_content, validator=Person)
    assert value == {"name": "Alice", "age": 18}
    assert error_messages == []

    yaml_content = """
        ---
        name: Alice
    """

    value, error_messages = validate_yaml(yaml_content, validator=Person)
    assert value is None
    assert len(error_messages) == 1

    text = "Missing value for required field."

# Generated at 2022-06-24 11:13:02.163220
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """\
    test:
      - 1
      - 2
      - 3
      - 4
      - 5
      - 6
      - 7
      - 8
      - 9
      - 10
      - name: 'tyler'
        age: 30
      - name: 'jane'
        age: 30
      - name: 'jane'
        age: 30
      - name: 'jane'
        age: 30
    """

    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert len(token) == 1

    token = token[0]
    assert isinstance(token, ListToken)
    assert len(token) == 12
    assert token[11] == [
        ("name", "jane"),
        ("age", 30),
    ]
   

# Generated at 2022-06-24 11:13:09.647658
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Boolean, Array, Dict

    field = Dict(properties={
        "message": String(),
        "count": Integer()
    })

    value, errors = validate_yaml(content="message: Hello World\n" +
                                         "count: 1\n" +
                                         "boolean: true",
                                  validator=field)

    assert value == {
        "message": "Hello World",
        "count": 1,
        "boolean": True
    }

    assert errors == [Message(
        text="Additional properties are not allowed ('boolean' was unexpected)",
        code="additional_properties",
        position=Position(line_no=3, column_no=2, char_index=23))]


# Generated at 2022-06-24 11:13:20.899852
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test for empty string
    with pytest.raises(ParseError):
        validate_yaml("", field.String())
    # Test for invalid characters
    with pytest.raises(ParseError):
        validate_yaml("!!!", field.String())
    # Test for valid characters
    try:
        value, error_message = validate_yaml("!!!", field.String())
        print(value, error_message)
    except ParseError:
        print("Parse error")
    # Test for invalid YAML
    with pytest.raises(ParseError):
        validate_yaml("[%s] %s", field.String())
    # Test for valid YAML

# Generated at 2022-06-24 11:13:30.870715
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: Test"
    validator = Field(name="name", type="string")

    value, error_messages = validate_yaml(content=content, validator=validator)
    assert error_messages == []
    assert value == "Test"

    content = "1"
    validator = Field(name="number", type="string")

    value, error_messages = validate_yaml(content=content, validator=validator)
    assert error_messages == [
        Message(code="invalid_type", text="Expected string, but got 1.", path=["number"])
    ]
    assert value is None

    content = "1"
    validator = Field(name="number", type=int)


# Generated at 2022-06-24 11:13:41.798947
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # A simple test to ensure that the tokenize_yaml function is producing the expected tokens
    # for various basic YAML input strings.
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}
    assert tokenize_yaml("foo: [bar, baz]") == {"foo": ["bar", "baz"]}
    assert tokenize_yaml("foo: {bar: baz}") == {"foo": {"bar": "baz"}}

    # Ensure that the tokenize_yaml function raises a ParseError if the YAML input string is
    # invalid.
    with pytest.raises(ParseError):
        tokenize_yaml("{ foo: bar }")

    # Ensure that the ParseError raised has the correct position information

# Generated at 2022-06-24 11:13:54.602408
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema as TypesystemSchema, fields

    class TestSchema(TypesystemSchema):
        name = fields.String(max_length=100)
        age = fields.Integer(minimum=0, maximum=100)
        email = fields.Email()

    yaml_str = dedent(
        """
        name: Tomasz
        age: 100
        email: 'tomasz@example.com'
        """
    )
    # Test valid
    value, errors = validate_yaml(yaml_str, TestSchema)
    assert value == {"name": "Tomasz", "age": 100, "email": "tomasz@example.com"}
    assert not errors

    # Test invalid

# Generated at 2022-06-24 11:14:02.328921
# Unit test for function validate_yaml
def test_validate_yaml():
    class User(Schema):
        username = fields.String()
        email = fields.Email()
        age = fields.Integer(description="An integer")

    value, error_messages = validate_yaml(
        """username: "user"
email: "foo@example.com"
age: "not an int"
""",
        validator=User,
    )

    assert value["username"] == "user"
    assert value["email"] == "foo@example.com"
    assert value["age"] == "not an int"
    assert len(error_messages) == 1
    assert error_messages[0].description == "An integer"
    assert error_messages[0].code == "invalid_type"
    assert error_messages[0].position.char_index == 28



# Generated at 2022-06-24 11:14:03.582617
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

# Generated at 2022-06-24 11:14:14.517607
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    with pytest.raises(ParseError):
        tokenize_yaml("")

    with pytest.raises(ParseError):
        tokenize_yaml("*")

    with pytest.raises(ParseError):
        tokenize_yaml("[&")

    assert tokenize_yaml("[]") == ListToken([], 0, 1)
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4)

    assert tokenize_yaml("123") == ScalarToken(123, 0, 2)


# Generated at 2022-06-24 11:14:24.851095
# Unit test for function validate_yaml
def test_validate_yaml():
    from pprint import pprint
    from typesystem import String
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize_yaml, validate_yaml

    # Test data
    DOCUMENT_1 = """
    - name: John
      email: john@example.com
    - name: Jane
      email: jane@example.com
    - name: Jimmy
      email: jimmy@example.com
    """
    DOCUMENT_2 = """
    - name: John
      email: john@example.com
      phone: 555-1234
    - name: Jane
      email: jane@example.com
      phone: 555-2345
    - name: Jimmy
      email: jimmy@example.com
      phone: 555-3456
    """
    DOCUMENT

# Generated at 2022-06-24 11:14:28.646847
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('''
        # Example
        name: John Doe
        age: 43
        children:
            - Mary
            - Bill
        ''') == {'name':  'John Doe', 'age': 43, 'children': ['Mary', 'Bill']}


# Generated at 2022-06-24 11:14:35.422768
# Unit test for function validate_yaml
def test_validate_yaml():
    content = textwrap.dedent(
        """\
        ---
        - id: 123
          name: 'foo'
          color:
            red: 10
            green: 10
            blue: 200
        - id: 234
          name: 'bar'
          color:
            red: 100
            green: 100
            blue: 20
        """
    )

    class Color(Schema):
        red = fields.Integer(min_value=0, max_value=255)
        green = fields.Integer(min_value=0, max_value=255)
        blue = fields.Integer(min_value=0, max_value=255)

    class User(Schema):
        id = fields.Integer()
        name = fields.String(max_length=100)
        color = fields.Nested(Color)

    value,

# Generated at 2022-06-24 11:14:43.410194
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem.schemas import Schema
    from typesystem.fields import *

    class SimpleSchema(Schema):
        name = String()

    value, error_messages = validate_yaml(content="""
    name: Hello
    """, validator=SimpleSchema)

    assert value == {"name": "Hello"}
    assert not error_messages

    value, error_messages = validate_yaml(content="""
    names:
      - Hello
      - "Another value"
    """, validator=SimpleSchema)

    assert value is None

# Generated at 2022-06-24 11:14:53.581951
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
a: 2
b:
  - 1
  - 2
  - 3
""")
    expected = DictToken(
        {"a": 2, "b": [1, 2, 3]},
        start=1,
        end=47,
        content="""
a: 2
b:
  - 1
  - 2
  - 3
""",
    )
    assert token == expected

    with pytest.raises(ParseError):
        tokenize_yaml("")

    content = """
a: 2
b:
  - 1
  - 2
  - 3
"""

    with pytest.raises(ParseError) as exc_info:
        tokenize_yaml(content + "c:\n  1")

    assert exc_info.value.position

# Generated at 2022-06-24 11:15:03.923455
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    
    content = "foo: bar"
    pos = Position(line_no=0, column_no=0, char_index=0)
    content_tuple = (content, pos)

    # Asserts that a scalar value was returned by tokenize_yaml
    assert isinstance(tokenize_yaml(content_tuple), ScalarToken)

    content = "foo: [1,2,3]"
    pos = Position(line_no=0, column_no=0, char_index=0)
    content_tuple = (content, pos)

    # Asserts that a list value was returned by tokenize_yaml
    assert isinstance(tokenize_yaml(content_tuple), ListToken)

    content = "foo: {a: 1, b: 2}"

# Generated at 2022-06-24 11:15:08.334387
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
  content = """
  key:
    - hello
    - world
    - 1
    - 2
  """
  token = tokenize_yaml(content)


if __name__ == "__main__":
  test_tokenize_yaml()

# Generated at 2022-06-24 11:15:16.490999
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test empty string throws error
    with pytest.raises(ParseError):
        tokenize_yaml('')
    # Test empty dictionary
    assert tokenize_yaml('{}') == {}
    # Test empty list
    assert tokenize_yaml('[]') == []
    # Test valid string
    assert tokenize_yaml('foo') == 'foo'
    # Test valid integer
    assert tokenize_yaml('42') == 42
    # Test valid float
    assert tokenize_yaml('3.14') == 3.14
    # Test valid boolean
    assert tokenize_yaml('true') == True
    

# Generated at 2022-06-24 11:15:19.006860
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "name: foo"
    dict_token = tokenize_yaml(content)
    assert dict_token.items[0].key == "name"
    assert dict_token.items[0].value.value == "foo"



# Generated at 2022-06-24 11:15:22.908008
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
            foo:
              - bar
        """)
    assert isinstance(token, DictToken)



# Generated at 2022-06-24 11:15:33.765307
# Unit test for function validate_yaml
def test_validate_yaml():
    
    class MySchema(Schema):

        name = String()
        age = Integer(minimum=0)
        weight = Float(minimum=0, default=90)
        married = Boolean(default=False)

        class Options:
            validate_schema = True

    content = """
    name: "Daniel"
    age: -1

    """

    # parse and validate yaml, return value and error messages
    value, messages = validate_yaml(content, MySchema)

    # validate that value is none
    assert value is None

    # validate that error messages exist
    assert messages

    # check error message contents
    assert messages["$"]["type"] == "object"
    assert messages["$"]["validations"]["schema"] == "Must be an object."

# Generated at 2022-06-24 11:15:41.405762
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('name: "a"') == {'name':'a'}
    #assert tokenize_yaml('age: 19') == {'age':19}
    assert tokenize_yaml('age: "19"') == {'age':'19'}
    assert tokenize_yaml('age: "19"\nname: "a"') == {'age':'19', 'name':'a'}
    assert tokenize_yaml('age: 19\nname: "a"') == {'age':19, 'name':'a'}
    assert tokenize_yaml('age: "19"\nname: "a"\naddress: "bj"\n') == {'age':'19', 'name':'a', 'address':'bj'}
    assert tokenize_yaml

# Generated at 2022-06-24 11:15:42.553859
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None


# Generated at 2022-06-24 11:15:51.875298
# Unit test for function validate_yaml
def test_validate_yaml():

    # Testing validating a simple string
    class StringField(Field):
        pass

    simple_content = """
    test: hello
    """
    value, error_messages = validate_yaml(simple_content, StringField())
    assert error_messages == []
    assert value == "hello"

    # Testing validation of a simple number
    class NumberField(Field):
        pass

    simple_content = """
    test: 10
    """
    value, error_messages = validate_yaml(simple_content, NumberField())
    assert error_messages == []
    assert value == 10

    # Testing validation of an invalid string
    simple_content = """
    test: 10
    """
    value, error_messages = validate_yaml(simple_content, StringField())

# Generated at 2022-06-24 11:16:03.563916
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.base import Message, ParseError, Position, ValidationError
    from typesystem.fields import Field
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken, Token

    assert yaml is not None, "'pyyaml' must be installed."

    if isinstance(content, bytes):
        str_content = content.decode("utf-8", "ignore")
    else:
        str_content = content

    if not str_content.strip():
        # Handle the empty string case explicitly for clear error messaging.
        position = Position(column_no=1, line_no=1, char_index=0)

# Generated at 2022-06-24 11:16:05.727543
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: 1
    b: <test>
    c: - 1
      - 2
      - 3
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)



# Generated at 2022-06-24 11:16:14.803558
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test empty string
    try:
        tokenize_yaml("")
    except ParseError as exc:
        message = str(exc)
        assert "line 1, column 1" in message
        assert "No content." in message

    # Test basic YAML parsing
    token = tokenize_yaml("hello: world")
    assert token == {"hello": "world"}
    assert isinstance(token, DictToken)
    assert token.start_pos == Position(line_no=1, column_no=1, char_index=0)
    assert token.end_pos == Position(line_no=1, column_no=11, char_index=10)

    # Test invalid YAML parsing

# Generated at 2022-06-24 11:16:24.238306
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.schemas import Root, Schema, fields
    from typesystem.tokenize.nodes import DictToken, ListToken, ScalarToken

    # Dump into valid YAML
    schema = Schema({"words": fields.String()})
    assert yaml.dump({"words": "hello"}) == 'words: hello\n'

    # Expect invalid YAML to raise a ParseError instance
    with pytest.raises(ParseError):
        tokenize_yaml("'foo': 'bar'")

    # Load valid YAML into tokens
    tokens = tokenize_yaml("words: hello")
    assert isinstance(tokens, DictToken)
    assert tokens.value == {"words": "hello"}

    # Validate the root token, with no additional context
    result = validate_with

# Generated at 2022-06-24 11:16:25.799738
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "test"
    assert tokenize_yaml(content).value == 'test'


# Generated at 2022-06-24 11:16:34.539443
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Generate a token from a YAML string, using the validate_with_positions()
    # function for validation.
    content_str = """
        a: 1
        b: 2
        c: [true, false]
        d:
          - foo
          - bar
    """

# Generated at 2022-06-24 11:16:45.016800
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('{"a": 1}')
    assert token.get('a', content="{a: 1}") == 1

    assert token.get('a', content="{a: 1}") == 1
    assert token.get('b', content="{a: 1}") == None

    DictToken.content = "{a: 1}"
    token.content = "{a: 1}"

    token = tokenize_yaml('[1, 2]')
    assert token == [1, 2]

    assert tokenize_yaml("1").value == 1
    assert tokenize_yaml('"01"').value == "01"

    assert token[0] == 1
    assert token[1] == 2
    assert token.get(2) == None
    assert token[:] == [1, 2]
    assert token

# Generated at 2022-06-24 11:16:52.313118
# Unit test for function validate_yaml
def test_validate_yaml():
    
    test_schema = """
    type: object
    properties:
        b:
            type: boolean
    """
    test_content = """
    b: hello
    """
    
    result = validate_yaml(test_content,Schema.load_schema_string(test_schema))
    assert len(result) == 2
    assert len(result[1]) >= 1
    assert isinstance(result[1][0],ValidationError)
    assert result[1][0].text == 'Must be a boolean.'

# Generated at 2022-06-24 11:16:57.208701
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    import typesystem

    class Example(typesystem.Schema):
        name = typesystem.String()

    example = {"name": 42}
    content = yaml.dump(example)
    _, messages = validate_yaml(content, Example)
    assert len(messages) == 2
    assert messages[0].text == "Not a valid string."
    assert messages[0].code == "type_error.string"
    assert messages[0].position == Position(1, 15, 14)
    assert messages[1].text == "Input must match the following schema."
    assert messages[1].code == "input_error.schema"
    assert messages[1].position == Position(1, 1, 0)



# Generated at 2022-06-24 11:17:05.018159
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    key1: val1
    key2: val2
    """)
    assert isinstance(token, DictToken)
    assert len(token.items()) == 2
    assert token.get("key1") == "val1"
    assert token.get("key2") == "val2"

    token = tokenize_yaml("""---
    - 1
    - 2
    - 3
    """)
    assert isinstance(token, ListToken)
    assert len(token) == 3
    assert token[0] == 1
    assert token[1] == 2
    assert token[2] == 3

    token = tokenize_yaml("""
    true: yes
    false: no
    """)
    assert isinstance(token, DictToken)
    assert token.get

# Generated at 2022-06-24 11:17:15.123438
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Test that the function throws a ParseError when called with an empty string.
    with pytest.raises(ParseError):
        tokenize_yaml("")

    # Test that the function works when handling a list of strings.
    assert isinstance(tokenize_yaml("- foo"), ListToken)

    # Test that the function works when handling a dictionary of key/value pairs.
    assert isinstance(tokenize_yaml("foo: bar"), DictToken)

    # Test that the function works when handling a integer.
    assert isinstance(tokenize_yaml("1"), ScalarToken)

    # Test that the function works when handling a float.
    assert isinstance(tokenize_yaml("1.1"), ScalarToken)

    # Test that the

# Generated at 2022-06-24 11:17:18.293360
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = u'{"age": 34}\n'
    token = tokenize_yaml(content)
    assert token
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == len(content) - 1


# Generated at 2022-06-24 11:17:21.237347
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        b'{"a": "foobar"}',
        {"a": {"type": "string"}},
    ) == ({'a': 'foobar'}, [])



# Generated at 2022-06-24 11:17:31.745747
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test various YAML strings passed as bytes.
    assert validate_yaml(b"", "") == ("", [])
    assert validate_yaml(b"1", int) == (1, [])
    assert validate_yaml(b"1.1", float) == (1.1, [])
    assert validate_yaml(b"true", bool) == (True, [])
    assert validate_yaml(b"false", bool) == (False, [])
    assert validate_yaml(b"null", type(None)) == (None, [])
    # Test various YAML strings.
    assert validate_yaml("", "") == ("", [])
    assert validate_yaml("1", int) == (1, [])

# Generated at 2022-06-24 11:17:40.937137
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_string = """
    title: Example
    tags:
      - foo
      - bar
      - baz
    """

    token = tokenize_yaml(yaml_string)
    assert token.get_value(["title"]) == "Example"
    assert token.get_value(["tags", 1]) == "bar"

    yaml_string_2 = """
    title: Example
    tags:
      - foo
      - bar
      - baz
    """

    token = tokenize_yaml(yaml_string_2)
    assert token.get_value(["title"]) == "Example"
    assert token.get_value(["tags", 1]) == "bar"


# Generated at 2022-06-24 11:17:48.363145
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Simple test
    token = tokenize_yaml("""
        key: value
    """)
    assert isinstance(token, DictToken)
    assert len(token.items) == 1
    assert token.items[0][0].value == "key"
    assert token.items[0][0].type == ScalarToken
    assert token.items[0][1].value == "value"
    assert token.items[0][1].type == ScalarToken

    # Yaml comments
    token = tokenize_yaml("""
        key: value  # comment
    """)
    assert isinstance(token, DictToken)
    assert len(token.items) == 1
    assert token.items[0][0].value == "key"
    assert token.items[0][0].type == ScalarToken
    assert token

# Generated at 2022-06-24 11:17:57.294164
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    def _validate_positions(item: typing.Any) -> None:
        if isinstance(item, Token):
            assert item.start_position and item.end_position
            assert item.start_position.char_index >= 0
            assert item.end_position.char_index >= 0

            assert item.start_position.line_no >= 1
            assert item.end_position.line_no >= 1

            if item.start_position.line_no == item.end_position.line_no:
                assert item.start_position.column_no <= item.end_position.column_no
            else:
                assert item.start_position.column_no <= (
                    item.start_position.column_no + len(item.get_line())
                )


# Generated at 2022-06-24 11:18:06.179347
# Unit test for function validate_yaml
def test_validate_yaml():
    schema_string = '''
        type: object
        required:
            - facts
        properties:
            facts:
                type: object
                required:
                    - os_version
                properties:
                    os_version:
                        type: string
                    distro:
                        type: string

    '''
    error_msg = "{\"type_error\": {\"code\": \"type_error.type\", \"message\": \"Must be of type 'object'.\", \"schema_path\": [\"properties\", \"facts\"]}}"
    schema = Schema.from_string(schema_string)
    data = {"facts": "Not an object!!!"}
    value, errors = validate_yaml(yaml.safe_dump(data), schema)
    assert(value == None)
    assert(error_msg in errors)


# Generated at 2022-06-24 11:18:16.066874
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem import Integer, Object, String
    from typesystem.schemas import Schema
    from tests.fixtures import PersonSchema

    class Person(object):
        def __init__(self, name: str, age: int):
            self.name = name
            self.age = age

    class PersonSchema(Schema):
        name = String()
        age = Integer()

    class Person(object):
        def __init__(self, name: str, age: int):
            self.name = name
            self.age = age

    def construct_object(loader: yaml.Loader, node: yaml.Node) -> Person:
        start = node.start_mark.index
        end = node.end_mark.index
        mapping = loader.construct_mapping(node)
        return Person

# Generated at 2022-06-24 11:18:28.055077
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Schema, ValidationError, ValidationError
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken, Token

    content = '{"age": "twenty"}'
    validator = String(name="age", max_length=5)

    result, errors = validate_yaml(content=content, validator=validator)
    assert result == {"age": "twenty"}
    assert len(errors) == 1
    assert errors == [
        ValidationError(
            code="max_length",
            message="May not be longer than 5 characters.",
            validator=validator,
        )
    ]


# Generated at 2022-06-24 11:18:31.040199
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("test: 12") == {'test': 12}
    assert tokenize_yaml("test: [1,2,3]") == {'test': [1, 2, 3]}


# Generated at 2022-06-24 11:18:40.972338
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("[1, 2, 3]") == ListToken([1, 2, 3], 0, 8, content="[1, 2, 3]")
    assert tokenize_yaml("{'a': 1}") == DictToken({'a': 1}, 0, 8, content="{'a': 1}")
    assert tokenize_yaml('{a: "foo", b: null}') == DictToken({'a': "foo", 'b': None}, 0, 21, content='{a: "foo", b: null}')
    assert tokenize_yaml('["foo", "bar"]') == ListToken(["foo", "bar"], 0, 13, content='["foo", "bar"]')

# Generated at 2022-06-24 11:18:46.048004
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("a", Field(String())) == ("a", [])
    assert validate_yaml("", Field(String())) == (None, [])
    assert validate_yaml("123", Field(Integer())) == (123, [])
    assert validate_yaml("123", Field(String())) == (None, [])
    assert validate_yaml("", Field(Integer())) == (None, [])
    assert validate_yaml("hello", Field(Integer())) == (None, [])
    assert validate_yaml("1", Field(Integer(), required=False)) == (1, [])
    assert validate_yaml("", Field(Integer(), required=False)) == (None, [])
    assert validate_yaml("abc", Field(Integer(), required=False)) == (None, [])
    assert validate_

# Generated at 2022-06-24 11:18:50.727190
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type=int)

    # Parse the YAML content, returning errors (if any)
    content = '{"hello": ["world"]}'
    result, errors = validate_yaml(content, validator)
    print(errors)


if __name__ == "__main__":
    test_validate_yaml()

# Generated at 2022-06-24 11:19:01.762560
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = fields.String()

    class TestSchemaNested(Schema):
        value = fields.String()
        nested = fields.Nested(TestSchema)

    # Test a schema with a nested schema field.
    valid_value = """
    value: hello
    nested:
      name: Jimmy
    """
    assert validate_yaml(valid_value, TestSchemaNested) == (
        {
            "value": "hello",
            "nested": {
                "name": "Jimmy"
            }
        },
        [],
    )

    value = """
    value: hello
    nested:
      name: Jimmy
      other: true
    """

# Generated at 2022-06-24 11:19:08.914227
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    assert yaml is not None

    schema = Schema(fields={"name": String()})
    content = "# Example YAML string\nname: John Doe\n"

    result = validate_with_positions(token=tokenize_yaml(content), validator=schema)
    assert result == ({"name": "John Doe"}, [])

# Generated at 2022-06-24 11:19:14.638422
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, SchemaField

    class YAMLSchema(Schema):
        name = String()

    def validate_yaml_test():
        content1 = "name: John Doe"
        result1 = validate_yaml(content=content1, validator=YAMLSchema)
        assert result1[0].get("name") == "John Doe"

    def validate_yaml_test2():
        content2 = "#name: John Doe"
        result2 = validate_yaml(content=content2, validator=SchemaField(YAMLSchema))
        assert result2[0].get("name") == "John Doe"

    validate_yaml_test()
    validate_yaml_test2()
    print("Test validate_yaml passed")

# Generated at 2022-06-24 11:19:25.612231
# Unit test for function validate_yaml
def test_validate_yaml():
    def invalid_amount(amount: int) -> typing.List[Message]:
        if amount < 50000:
            return [
                Message(
                    code="invalid",
                    position=Position(line_no=1, column_no=1, char_index=0, value=50000),
                )
            ]
        return []

    class Transfer(Schema):
        amount = Field(types=int, validators=[invalid_amount])

    content = "amount: 100"
    assert validate_yaml(content, validator=Transfer) == ({"amount": 100}, [])

    content = "amount: 10"
    _, errors = validate_yaml(content, validator=Transfer)
    assert errors[0].position.column_no == 1
    assert errors[0].position.line_no == 1

# Generated at 2022-06-24 11:19:35.259220
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("123") == ScalarToken(123, 0, 2, content="123")
    assert tokenize_yaml("123.5") == ScalarToken(123.5, 0, 4, content="123.5")

    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")

    assert tokenize_yaml("string") == ScalarToken("string", 0, 6, content="string")

    assert tokenize_yaml("123\n456") == DictToken({"123": "456"}, 0, 7, content="123\n456")
   

# Generated at 2022-06-24 11:19:42.856961
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(min_length=3)

    class MyList(Schema):
        name = String(min_length=3)
        members = List(Person())

    validator = MyList()

    content = '''\
name: My Test List
members:
- name: Test
- name: TestT
- name: TestT
- name: TestT
'''
    value, messages = validate_yaml(content, validator)
    assert isinstance(value, dict)
    assert isinstance(messages, list)
    assert len(value) == 2
    assert len(messages) == 1
    message = messages[0]
    assert isinstance(message, Message)
    assert message.code == "min_length"
    assert message.text == "Must be at least 3 characters."

# Generated at 2022-06-24 11:19:46.557895
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: "bar"
    """
    type_ = types.String()

    value, errors = validate_yaml(content, type_)

    assert value == "bar"
    assert not errors

# Generated at 2022-06-24 11:19:49.445385
# Unit test for function validate_yaml
def test_validate_yaml():
  content = """
  # My Sample YAML File
  name: Boyana Norris
  age: 27
  """
  token = tokenize_yaml(content)
  assert token == Token()


# Generated at 2022-06-24 11:19:58.384227
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "Test Schema"
        fields = {"foo": "string", "bar": "boolean"}

    class TestSchema_OptionalField(Schema):
        name = "Test Schema"
        fields = {"foo": "string"}

    schema = TestSchema()

    assert schema.validate_yaml(b"foo: hello") == ({"foo": "hello"}, [])
    assert schema.validate_yaml(b"bar: false") == ({"bar": False}, [])
    assert schema.validate_yaml(b"foo: hello\nbar: false") == (
        {"foo": "hello", "bar": False},
        [],
    )
    assert schema.validate_yaml(b"foo: hello\nbar: false\nbaz: true")

# Generated at 2022-06-24 11:20:09.235544
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    name: foo
    # comment
    age:
    - 1
    - 2
    - 3
    """
    tok = tokenize_yaml(content)
    assert tok["name"] == "foo"
    assert tok["age"][1] == 2

    try:
        tokenize_yaml("")
    except ParseError as e:
        assert e.position == Position(1, 1, 0)
        assert e.text == "No content."
        assert e.code == "no_content"

    content = """
    root:
      foo:
        bar:
          - bat
          - cat
          - dat
    """
    tok = tokenize_yaml(content)
    assert tok["root"]["foo"]["bar"][0] == "bat"


# Generated at 2022-06-24 11:20:17.634901
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ScalarToken(None, 0, 0)
    assert tokenize_yaml("[1, 2]") == ListToken([1, 2], 0, 7)
    assert tokenize_yaml('{"foo": "bar"}') == DictToken({"foo": "bar"}, 0, 13)
    assert tokenize_yaml("[1, 2]") == ListToken([1, 2], 0, 7)
    assert tokenize_yaml("3") == ScalarToken(3, 0, 1)
    assert tokenize_yaml("-4") == ScalarToken(-4, 0, 2)
    assert tokenize_yaml("3.4") == ScalarToken(3.4, 0, 3)

# Generated at 2022-06-24 11:20:20.171542
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    expected_value = {'name': 'John Smith', 'age': 55, 'spouse': None, 'children': ['Jane', 'Ralph']}
    value, external_errors = validate_yaml("""
        name: John Smith
        age: 55
        spouse: null
        children:
            - Jane
            - Ralph
    """, Schema)

    assert len(external_errors) == 0
    assert value == expected_value



# Generated at 2022-06-24 11:20:24.996694
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken, Token

    # Empty string
    content = ''
    token = tokenize_yaml(content)
    validator = String.instance()
    assert validate_yaml(content, validator) == (None, [])
    # Error message
    content = '\n\n'
    token = tokenize_yaml(content)
    validator = String.instance()
    assert validate_yaml(content, validator) == (None, [])
    # Valid scalar
    content = '12'
    token = tokenize_yaml(content)
    valid

# Generated at 2022-06-24 11:20:33.074138
# Unit test for function validate_yaml
def test_validate_yaml():
    # Check for parse error message.
    # Wrong type.
    with pytest.raises(ParseError) as e:
        validate_yaml("'foo'", String())
    assert "Invalid type: 'str'. Did you mean 'str'?" in e.value.detail

    # Missing required field
    with pytest.raises(ParseError) as e:
        validate_yaml("{}", String(required=True))
    assert "Missing required field." in e.value.detail

    # Unknown Field
    with pytest.raises(ParseError) as e:
        validate_yaml("- name: foo\n  age: 30", String())
    assert "Invalid property 'age': This field is not defined." in e.value.detail

    # Unknown property

# Generated at 2022-06-24 11:20:42.789063
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert (
        tokenize_yaml("a: 1\nb: 2")
        == DictToken({"a": 1, "b": 2}, start=0, end=5, content="a: 1\nb: 2")
    )

    assert (
        tokenize_yaml("a: 1\nb: [1, 2]")
        == DictToken({"a": 1, "b": [1, 2]}, start=0, end=11, content="a: 1\nb: [1, 2]")
    )

    assert (
        tokenize_yaml("a: 1\nb: 2\n")
        == DictToken({"a": 1, "b": 2}, start=0, end=6, content="a: 1\nb: 2\n")
    )
