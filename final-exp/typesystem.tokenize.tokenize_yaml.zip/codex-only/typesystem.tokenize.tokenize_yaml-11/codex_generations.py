

# Generated at 2022-06-24 11:10:53.052424
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b''
    assert validate_yaml(content, None) == (Token(None), None)

    content = (b'name: Corey Schafer\n' +
               b'website: https://coreyms.com\n' +
               b'name:\n' +
               b'  - Corey\n' +
               b'  - Schafer\n' +
               b'favorite_food:\n' +
               b'  - pizza\n' +
               b'  - tacos\n' +
               b'  - hamburger\n' +
               b'pet:\n' +
               b'  name: Barry\n' +
               b'  animal: dog\n' +
               b'  breed: Poodle\n')

# Generated at 2022-06-24 11:11:04.883582
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("foo: bar", {"foo": "string"}) == ({'foo': 'bar'}, [])
    assert validate_yaml(
        "foo: bar", {"foo": "string", "bar": {"baz": {"type": "string"}}}
    ) == ({'foo': 'bar', 'bar': {}}, [])


# Generated at 2022-06-24 11:11:13.149163
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        name: Foo
        age: 20
        active: true
        weight: 120.3
        """
    validator = Field(name="user", type_="object", properties={
        "name": Field(name="name", type_="string", min_length=1),
        "age": Field(name="age", type_="integer", format_="int32"),
        "active": Field(name="active", type_="boolean"),
        "weight": Field(name="weight", type_="number", format_="float"),
    })
    results = validate_yaml(content, validator)

    assert results == (
        {
            'name': 'Foo',
            'age': 20,
            'active': True,
            'weight': 120.3,
        },
        [],
    )

# Generated at 2022-06-24 11:11:20.652881
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a:
      b:
      - c: "text"
      - d: "text"
    """
    token = tokenize_yaml(content)
    assert type(token) == DictToken

    content = """
    - a:
        b:
      - c: "text"
      - d: "text"
    """
    token = tokenize_yaml(content)
    assert type(token) == ListToken


# Generated at 2022-06-24 11:11:28.593055
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String, Schema, List

    content = """
    answer: 42
    name: Steve
    friends:
        - Bob
        - Sue
        - Mary
    """
    validator = Schema(
        {
            "answer": Integer,
            "name": String,
            "friends": List(String),
        }
    )
    value, messages = validate_yaml(content, validator=validator)
    assert value == {
        "answer": 42,
        "name": "Steve",
        "friends": ["Bob", "Sue", "Mary"]
    }
    assert len(messages) == 0

# Generated at 2022-06-24 11:11:37.305720
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    # This is a comment that should be ignored
    ---
    hello: world
    age: 10
    """)
    assert token.content == """
    ---
    hello: world
    age: 10
    """
    assert token.value == {"hello": "world", "age": 10}
    assert token.start_position.line_no == 3
    assert token.end_position.line_no == 5

    token = tokenize_yaml("""
    ---
    - Hello
    - World
    """)
    assert token.content == """
    ---
    - Hello
    - World
    """
    assert token.value == ["Hello", "World"]
    assert token.start_position.line_no == 3
    assert token.end_position.line_no == 5




# Generated at 2022-06-24 11:11:40.892310
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("'a'"), ScalarToken)
    assert isinstance(tokenize_yaml('"a"'), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("{key: 'value'}"), DictToken)


# Generated at 2022-06-24 11:11:49.489891
# Unit test for function validate_yaml
def test_validate_yaml():

    from typesystem.fields import String, Integer, Array

    from typesystem.schemas import Schema

    # Create a simple schema with a single field
    class TestSchema(Schema):
        name = String()

    # Validate a valid YAML string against the schema
    valid_yaml_string = "name: hello"
    result = validate_yaml(valid_yaml_string, TestSchema())
    assert result == ({"name": "hello"}, [])

    # Validate an invalid YAML string against the schema
    invalid_yaml_string = "foo"
    result = validate_yaml(invalid_yaml_string, TestSchema())
    assert result == (None, [])

    class TestArraySchema(Schema):
        numbers = Array(items=Integer())

    valid_yaml_array

# Generated at 2022-06-24 11:11:59.993284
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test parsing of a string literal
    content = '''
    data:
      - "Hello"
      - "World"
      - "!"
    '''
    token = tokenize_yaml(content)
    assert token.value == [
        ScalarToken("Hello", 12, 17, content=content),
        ScalarToken("World", 20, 25, content=content),
        ScalarToken("!", 28, 28, content=content),
    ]

    # Test parsing of a numeric literal
    content = '''
    data:
      - 1
      - 2.5
      - 1.0e+100
    '''
    token = tokenize_yaml(content)

# Generated at 2022-06-24 11:12:10.454007
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: bar
    baz:
      - qux
      - gobble
    """
    schema = Schema(
        fields={
            "foo": Field(type="string"),
            "baz": Field(type="array", items=Field(type="string")),
        }
    )
    value, error_messages = validate_yaml(content, schema)
    assert len(error_messages) == 0
    assert value["foo"] == "bar"
    assert value["baz"] == ["qux", "gobble"]

    incorrect_content = """
    foo: bar
    baz:
      - qux
      - false
    """
    value, error_messages = validate_yaml(incorrect_content, schema)
    assert len(error_messages) == 1

# Generated at 2022-06-24 11:12:15.440664
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """Test our tokenizing ability, ensuring the yaml object we construct is equivalent
    to the original yaml object."""
    assert yaml is not None, "'pyyaml' must be installed."

    yaml_string = "---\nfoo: bar\n"
    parsed_yaml = yaml.safe_load(yaml_string)

    assert parsed_yaml == tokenize_yaml(yaml_string)


# Generated at 2022-06-24 11:12:20.955340
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem.types import String, Integer, Float, Boolean
    from typesystem import Schema

    class Test(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_tall = Boolean()

    test_string = """
    name: Jeff
    age: 28
    height: 5.9
    is_tall: true
    """
    result, errors = validate_yaml(test_string, Test)
    assert result == {
        'name': u'Jeff',
        'age': 28,
        'height': 5.9,
        'is_tall': True,
    }
    assert not errors



# Generated at 2022-06-24 11:12:30.439154
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import yaml
    from typesystem.tokenize.tokens import ScalarToken, ListToken, DictToken

    yaml_string = """\
# This is a yaml file! :)
---
# This is a comment
-   "This is a list"
    # A comment in list
-   "This is another list item"
-   98.9898
-   "Hello world"
key: "value"
"""
    print(yaml.load(yaml_string))
    token = tokenize_yaml(yaml_string)
    assert isinstance(token, ListToken)

# Generated at 2022-06-24 11:12:38.798900
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem import String, Integer, Schema
    import yaml

    class UserSchema(Schema):
        name = String(max_length=50)
        age = Integer(minimum=0)

    user_schema = UserSchema()

    # Test a valid YAML document.
    content = """
        name: John Doe
        age: 43
    """
    yaml_user_data, messages = validate_yaml(content, user_schema)
    assert yaml_user_data == {"name": "John Doe", "age": 43}
    assert not messages

    # Test an invalid YAML document.
    content = """
        age: 43
    """

# Generated at 2022-06-24 11:12:46.693814
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    There is no need to test all possible types of YAML tokens.
    The function is only used to obtain the positional information
    of a token. Therefore, we only need to test the correct
    positional information.
    """
    content = "---\na: 1\n"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken), "The token must be a dict."

    content = "---\n- 1\n"
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken), "The token must be a list."

    content = "---\nkey: value\n"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken), "The token must be a dict."

    scalar = token["key"]


# Generated at 2022-06-24 11:12:56.205646
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        # name = String()
        age = Integer()

    value, errors = validate_yaml(
        content="""
        name: "hello"
        age: 34
        """,
        validator=TestSchema,
    )
    assert not errors
    assert value == {'age': 34}

    value, errors = validate_yaml(
        content="""
        name: "hello"
        """,
        validator=TestSchema,
    )

    errors = list(errors)
    expected = [
        ValidationError(
            text="Missing field.",
            code="missing_field",
            constraint={"field": "age"},
        )
    ]


# Generated at 2022-06-24 11:13:06.150955
# Unit test for function validate_yaml
def test_validate_yaml():
    token = tokenize_yaml("[1, 2, 3]")
    validator = Field(type='array', items=Field(type='integer'))
    assert validate_yaml("[1, 2, 3]", validator) == ([1, 2, 3], [])

    # Test case where value is invalid and has a parse error
    token = tokenize_yaml("[1, 2, 3][1, 2, 3")
    validator = Field(type='array', items=Field(type='integer'))
    values, [error] = validate_yaml("[1, 2, 3][1, 2, 3", validator)
    assert values == []
    assert error.text == "bad indentation of a mapping entry"
    assert error.position.line_no == 1
    assert error.position.column_no == 14



# Generated at 2022-06-24 11:13:12.162156
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    one: 1
    two: 2
    three: 3
    """)
    assert isinstance(token, DictToken)
    assert len(token.items) == 3
    key, value = token.items[0]
    assert key == "one"
    assert isinstance(value, ScalarToken)
    assert value.value == 1



# Generated at 2022-06-24 11:13:20.228016
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = fields.String()
        age = fields.String()
        friends = fields.List(fields.Integer())

    content = """
    name: John Smith
    age: 26
    friends:
    - 1
    - 2
    """

    result = validate_yaml(content, Person)
    assert result == (
        {
            "name": "John Smith",
            "age": "26",
            "friends": [1, 2],
        },
        [],
    )



# Generated at 2022-06-24 11:13:30.473318
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """Test tokenize_yaml correctly tokenizes and raises errors as expected."""
    from typesystem.fields import String

    class EmptySchema(Schema):
        pass

    # Empty content.
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml("")
    assert excinfo.value.code == "no_content"
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.column_no == 1

    # Basic YAML content.
    token = tokenize_yaml("test: foo")
    assert token.to_primitive() == {"test": "foo"}

    # Incorrectly typed content.
    token = tokenize_yaml("test: 1")

# Generated at 2022-06-24 11:13:38.570170
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        age = Integer(minimum=5)

    value, error_messages = validate_yaml(b"age: 0", validator=MySchema)
    assert error_messages == [
        Message(
            text="Must be greater than or equal to 5.",
            code="min_value",
            position=Position(line_no=1, column_no=6, char_index=5),
        )
    ]



# Generated at 2022-06-24 11:13:43.966386
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_yaml = """
        - A
        - B
        - C
    """
    expected_output = ListToken(["A", "B", "C"], 1, 23, content=str_yaml)
    assert tokenize_yaml(str_yaml) == expected_output
    assert tokenize_yaml(str_yaml.encode("utf-8")) == expected_output

    str_yaml = """
        fruits:
          - apple
          - banana
          - orange
    """
    expected_output = DictToken(
        {"fruits": ListToken(["apple", "banana", "orange"], 10, 36, content=str_yaml)},
        1,
        41,
        content=str_yaml,
    )
    assert tokenize_yaml(str_yaml) == expected_

# Generated at 2022-06-24 11:13:56.227428
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Valid YAML
    content = "key1:value1"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == content.__len__() - 1

    content = "[item1, item2, item3]"
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert token.start == 0
    assert token.end == content.__len__() - 1

    content = "a string"
    token = tokenize_yaml(content)
    assert isinstance(token, ScalarToken)
    assert token.start == 0
    assert token.end == content.__len__() - 1

    content = "123"
    token = tokenize_yaml(content)


# Generated at 2022-06-24 11:14:03.927227
# Unit test for function validate_yaml
def test_validate_yaml():
    from datetime import datetime
    from typesystem import Date, Integer, Schema
    from typesystem.fields import DateTime
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize_yaml

    class MessageSchema(Schema):
        text = Date()
        number = Integer()

    input_content = "---\n" + \
        "text: '2019-10-01'\n" + \
        "number: 110\n"
    token = tokenize_yaml(input_content)
    assert token.to_primitive() == {'text': '2019-10-01', 'number': 110}

    input_content_1 = "---\n" + \
        "text: '2019-10-01'\n" + \
        "number: 110\n"


# Generated at 2022-06-24 11:14:05.828754
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('this: "is a test"') == {'this': 'is a test'}



# Generated at 2022-06-24 11:14:17.120692
# Unit test for function validate_yaml
def test_validate_yaml():
    content ="""
    a: hello
    b: world
    c: 42
    """
    schema = Schema({"a": String(max_length=2), "b": String(max_length=10), "c": String(max_length=20)})
    value, messages = validate_yaml(content, schema)
    assert len(messages) == 1
    assert str(messages[0]) == "String value is too long."
    assert messages[0].position.line_no == 2
    assert messages[0].position.column_no == 4

    content = "not-valid-input"
    schema = Schema({"a": String(), "b": String(), "c": String()})
    value, messages = validate_yaml(content, schema)
    assert len(messages) == 1

# Generated at 2022-06-24 11:14:23.953008
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        a: 1
        b: 2
        c: 3
    """

    schema = Schema.from_dict(
        {
            "a": Integer(maximum=100),
            "b": Integer(maximum=100),
            "c": Integer(maximum=100),
        }
    )

    value, errors = validate_yaml(content, schema)
    assert value == {"a": 1, "b": 2, "c": 3}
    assert errors is None


# Generated at 2022-06-24 11:14:32.885967
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer
    token, errors = validate_yaml("x: 'foo'", Integer(name="x"))
    assert isinstance(token, DictToken)
    assert isinstance(errors, list)
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)
    assert errors[0].text == "Value must be an integer."
    assert errors[0].position == Position(column_no=6, line_no=1, char_index=5)
    assert errors[0].code == "invalid_type"
    assert errors[0].validator == Integer(name="x")
    assert errors[0].context == {"field": "x", "value": "foo"}



# Generated at 2022-06-24 11:14:41.802413
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("test value") == "test value"
    assert tokenize_yaml("0") == 0
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("-1") == -1
    assert tokenize_yaml("0.1") == 0.1
    assert tokenize_yaml("-0.1") == -0.1
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_yaml("{ a: 1, b: 2, c: 3 }") == {"a": 1, "b": 2, "c": 3}

#

# Generated at 2022-06-24 11:14:44.037464
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        foo: "bar"
        """) 
    assert token == {'foo':'bar'}



# Generated at 2022-06-24 11:14:47.434645
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    #valid_yaml_content = '''
    #name: John Doe
    #age: 42
    #'''
    #assert(tokenize_yaml(valid_yaml_content) is not None)
    assert(True == True)

# Generated at 2022-06-24 11:14:48.958561
# Unit test for function validate_yaml
def test_validate_yaml():
    pass

# Generated at 2022-06-24 11:14:54.647495
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: 'Person'
    properties:
        name:
            description: 'The name of the person.'
            type: string
        age:
            description: 'The age of the person.'
            type: integer
    """
    tokens = tokenize_yaml(content)
    assert isinstance(tokens, DictToken)
    value, error_messages = validate_with_positions(token, Schema)
    assert error_messages == []

# Generated at 2022-06-24 11:14:55.974059
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml('{"Grapefruit": "red"}'), DictToken)


# Generated at 2022-06-24 11:15:01.946229
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("- foo\n- bar") == ListToken(["foo", "bar"], 0, 12, content="- foo\n- bar")
    assert tokenize_yaml("{foo: bar}") == DictToken({"foo": "bar"}, 0, 8, content="{foo: bar}")
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")
    assert tokenize_yaml("42") == ScalarToken("42", 0, 1, content="42")
    assert tokenize_yaml("3.14") == ScalarToken("3.14", 0, 3, content="3.14")
    assert tokenize_yaml("true") == ScalarToken("true", 0, 3, content="true")
    assert tokenize_yaml("null") == Scal

# Generated at 2022-06-24 11:15:10.332316
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer
    from typesystem.schemas import Schema

    class IntegerListSchema(Schema):
        items = Integer()

    schema = IntegerListSchema()
    data = [1, 2, 3]
    content = yaml.safe_dump(data)
    (value, messages) = validate_yaml(content, validator=schema)
    assert len(messages) == 0
    assert value == data

if __name__ == "__main__":
    test_validate_yaml()

# Generated at 2022-06-24 11:15:18.510992
# Unit test for function validate_yaml

# Generated at 2022-06-24 11:15:26.955560
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # empty string
    content = ''
    with pytest.raises(ParseError) as execinfo:
        tokenize_yaml(content)
    assert execinfo.type == ParseError
    assert execinfo.value.text == "No content."
    assert execinfo.value.position.line_no == 1
    assert execinfo.value.position.column_no == 1
    assert execinfo.value.position.char_index == 0

    # null
    content = 'null'
    token = tokenize_yaml(content)
    assert token._type == 'null'
    assert token.raw_value == 'null'
    assert token.value is None
    assert token.start_index == 0
    assert token.end_index == 3
    assert token.content == content

    # bool
    content = 'true'


# Generated at 2022-06-24 11:15:36.281664
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    test1 = "title: 'The Raven'"
    title_token = tokenize_yaml(test1)
    assert isinstance(title_token, DictToken)
    title = title_token.value['title']

    assert isinstance(title, ScalarToken)
    assert title.value == 'The Raven'

    test2 = '[1,2,3,4]'
    nums_token = tokenize_yaml(test2)
    assert isinstance(nums_token, ListToken)
    assert len(nums_token.value) == 4
    for num in nums_token.value:
        assert isinstance(num, ScalarToken)
        assert isinstance(num.value, int)

    # Following tests are taken from yaml.org and validated against PyYaml

# Generated at 2022-06-24 11:15:46.808620
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String

    content = b"""
    a: 1
    b: 2
    """

    errors = validate_yaml(content, Integer)  # type: ignore
    assert len(errors) == 1

    error, = errors
    assert error.code == "invalid_type"
    assert error.position == Position(char_index=0, column_no=1, line_no=1)

    schema = Schema({"a": Integer, "b": Integer})
    value, errors = validate_yaml(content, schema)
    assert value == {"a": 1, "b": 2}
    assert not errors

    content = b"""
    a: 1
    a: 2
    """

    value, errors = validate_yaml(content, schema)

# Generated at 2022-06-24 11:15:54.915285
# Unit test for function validate_yaml
def test_validate_yaml():
    json_object = dict(key1="1", key2=True)
    json_array = [dict(key1="1", key2=True), dict(key1="1", key2=True)]
    schema_dict = dict(key1="string", key2="boolean")
    schema_arr = dict(items="object")
    schema = dict(object="object", list="array")
    assert validate_yaml(json.dumps(json_object), schema_dict) == (
        json_object,
        [],
    )
    assert validate_yaml(json.dumps(json_array), schema_arr) == (
        json_array,
        [],
    )

# Generated at 2022-06-24 11:16:06.084679
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # raises Parse Error
    with pytest.raises(ParseError) as exc: tokenize_yaml("")
    assert exc.value.text == "No content."
    assert exc.value.code == "no_content"
    assert exc.value.position == Position(column_no=1, line_no=1, char_index=0)
    
    # raises Parse Error
    with pytest.raises(ParseError) as exc: tokenize_yaml("garbage")
    assert exc.value.text == "mapping values are not allowed here."
    assert exc.value.code == "parse_error"
    assert exc.value.position == Position(column_no=1, line_no=1, char_index=0)
    
    # raises Parse Error

# Generated at 2022-06-24 11:16:15.000510
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    expected_value = {
        "int": 1,
        "float": 3.14,
        "string": "test",
        "list": [1, 2, 3],
        "dict": {"a": "b"},
        "null": None
    }

    test_content = ("int: 1\n"
                    "float: 3.14\n"
                    "string: test\n"
                    "list: [1, 2, 3]\n"
                    "dict:\n"
                    "  a: b\n"
                    "null: null\n")
    result = tokenize_yaml(test_content)
    assert result == expected_value

    # Test parsing bytes.

# Generated at 2022-06-24 11:16:22.814882
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    valid_yaml_string = """
    username: jane-victoria
    password: s3cr3t
    """
    token = tokenize_yaml(valid_yaml_string)
    assert token.type == "dict"
    assert token.content == valid_yaml_string
    assert token.start == 0
    assert token.end == 42
    assert token["username"].value == "jane-victoria"
    assert token["username"].content is None
    assert token["username"].start == 21
    assert token["username"].end == 35
    


# Generated at 2022-06-24 11:16:31.953621
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Line and column numbers should be populated correctly
    token = tokenize_yaml("""
        foo: bar
        baz:
            - foobar
            - foobaz
    """)
    assert token.value == {'foo': 'bar', 'baz': ['foobar', 'foobaz']}
    assert token.start_line == 2
    assert token.start_column == 3
    assert token.start_char_index == 5
    assert token.end_line == 4
    assert token.end_column == 12
    assert token.end_char_index == 53

    # Error messages should be raised correctly
    with pytest.raises(ParseError) as exc_info:
        tokenize_yaml("""
            foo:
                bar:
                    - "foobar"
        """)
    assert exc_info

# Generated at 2022-06-24 11:16:40.550123
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken, Token
    assert isinstance(tokenize_yaml(''), Token)
    assert isinstance(tokenize_yaml('foo: bar'), DictToken)
    assert isinstance(tokenize_yaml('- foo: bar'), ListToken)
    assert isinstance(tokenize_yaml('42'), ScalarToken)
    assert isinstance(tokenize_yaml('true'), ScalarToken)
    assert isinstance(tokenize_yaml('null'), ScalarToken)

# Generated at 2022-06-24 11:16:48.912639
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token_1 = tokenize_yaml("key: 1")
    assert isinstance(token_1, DictToken)
    assert token_1.start == 0
    assert token_1.end == 5

    token_2 = tokenize_yaml("- 1\n- 2")
    assert isinstance(token_2, ListToken)
    assert token_2.start == 0
    assert token_2.end == 6

    token_3 = tokenize_yaml("1")
    assert isinstance(token_3, ScalarToken)
    assert token_3.start == 0
    assert token_3.end == 1

    token_4 = tokenize_yaml("key:\n  1")
    assert isinstance(token_4, DictToken)
    assert token_4.start == 0
    assert token_4.end

# Generated at 2022-06-24 11:17:00.381629
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        foo:
            bar: 'hello'
            baz: 1
            qux:
                - 1
                - 2
                - 3
        """
    expected_yaml_token = DictToken({
        u'foo': DictToken({
            u'bar': ScalarToken(u'hello', 38, 47, content=content),
            u'baz': ScalarToken(1, 58, 59, content=content),
            u'qux': ListToken([
                ScalarToken(1, 82, 83, content=content),
                ScalarToken(2, 90, 91, content=content),
                ScalarToken(3, 98, 99, content=content),
            ], 80, 100, content=content),
        }, 7, 101, content=content),
    }, 5, 102, content=content)


# Generated at 2022-06-24 11:17:06.262362
# Unit test for function validate_yaml
def test_validate_yaml():
    y1 = '''
    - name: John Smith
      age: 25
      position:
        x: 1.0
        y: 1.1
    - name: Jane Smith
      age: 26
    '''
    schema = Schema(fields={
        "name": str,
        "age": int,
        "position": {
            "x": float,
            "y": float
        }
    })
    assert validate_yaml(y1, schema)

# Generated at 2022-06-24 11:17:16.275281
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    assert tokenize_yaml("""foo: "bar" """) == DictToken({"foo": "bar"}, 0, 10)
    assert tokenize_yaml("""foo:    "bar" """) == DictToken({"foo": "bar"}, 0, 13)
    assert tokenize_yaml("""foo:    "bar"\n""") == DictToken({"foo": "bar"}, 0, 14)
    assert tokenize_yaml("""foo:  "bar"\n""") == DictToken({"foo": "bar"}, 0, 12)
    assert tokenize_yaml("""foo: bar\n""") == DictToken({"foo": "bar"}, 0, 8)

# Generated at 2022-06-24 11:17:23.064908
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('{ "a": 1 }') == {
        "a": 1
    }

    assert tokenize_yaml('[ "a", 1 ]') == [
        "a", 1
    ]

    assert tokenize_yaml('"a"') == "a"

    assert tokenize_yaml('1') == 1

    assert tokenize_yaml('null') is None

    assert tokenize_yaml('true') is True

    assert tokenize_yaml('false') is False



# Generated at 2022-06-24 11:17:28.797204
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Ensure YAML errors are marked with positions.
    """
    def assert_position(error: ValidationError, position: Position) -> None:
        assert error.position.line_no == position.line_no
        assert error.position.column_no == position.column_no
        assert error.position.char_index == position.char_index

    schema = Schema([Field(name="hello", required=True)])
    content = "\n\n\nhello: world"

    value, errors = validate_yaml(content, schema)
    assert value["hello"] == "world"
    assert not errors

    schema = Schema([Field(name="hello", required=True)])
    content = "\n\n\nworld"

    value, errors = validate_yaml(content, schema)
    assert value == {}

# Generated at 2022-06-24 11:17:31.807046
# Unit test for function validate_yaml
def test_validate_yaml():
    s = '''
    - id: 1
      type: object
      properties:
        name:
          type: string
        quantity:
          type: integer
    '''
    value, errors = validate_yaml(s, Schema)
    assert not errors

# Generated at 2022-06-24 11:17:33.900142
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    token = tokenize_yaml(b"")
    with pytest.raises(ParseError):
        validate_with_positions(token=token, validator=Schema)



# Generated at 2022-06-24 11:17:43.309308
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    content = "name: 'John'\nage: 32"
    value, errs = validate_yaml(content, Person)

    assert value is not None
    assert value == {"name": "John", "age": 32}
    assert errs == []

    content = "name: 'John'\nage: thirty-two"

    expected_errs = [
        Message(
            text="Value is not a valid integer.",
            code="invalid_type",
            position=Position(line_no=2, column_no=4, char_index=13),
        )
    ]

    value, errs = validate_yaml(content, Person)

    assert value is None
    assert errs == expected_

# Generated at 2022-06-24 11:17:51.286840
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
description: Introduction to the widget.
type: string
"""
    token = tokenize_yaml(content)
    assert token["description"].value == "Introduction to the widget."
    assert token["description"].start_index == 28
    assert token["description"].end_index == 54
    assert token["type"].value == "string"
    assert token["type"].start_index == 66
    assert token["type"].end_index == 71


# Generated at 2022-06-24 11:17:57.412656
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(type="bool", required=True)
    schema = Schema([field])
    content = "no"
    value, messages = validate_yaml(content, field)
    assert value is None
    assert messages
    assert len(messages) == 1
    assert messages[0].code == "not_a_bool"
    assert messages[0].text == "Must be a boolean."

    content = "true"
    value, messages = validate_yaml(content, field)
    assert value is None
    assert messages
    assert len(messages) == 1
    assert messages[0].code == "missing_field"
    assert messages[0].text == "This field is required."

    value, messages = validate_yaml("true", schema)
    assert value == True
    assert messages
    assert not messages

    content

# Generated at 2022-06-24 11:18:06.226065
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # Type: ScalarToken
    assert type(tokenize_yaml("abc")) == ScalarToken
    assert type(tokenize_yaml("123")) == ScalarToken
    assert type(tokenize_yaml("3.14")) == ScalarToken

    # Invalid YAML: ParseError
    with pytest.raises(ParseError):
        tokenize_yaml("[1")
    with pytest.raises(ParseError):
        tokenize_yaml("a: 1")

    # Empty YAML: ParseError
    with pytest.raises(ParseError):
        tokenize_yaml("")

    # Type: ListToken
    assert type(tokenize_yaml("[1, 2]")) == ListToken

# Generated at 2022-06-24 11:18:15.114395
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml('{"a": 1, "b": 2}'), DictToken)
    assert isinstance(tokenize_yaml('["a", 1, "b", 2]'), ListToken)
    assert isinstance(tokenize_yaml('"a"'), ScalarToken)
    assert isinstance(tokenize_yaml('1'), ScalarToken)
    assert isinstance(tokenize_yaml('1.1'), ScalarToken)
    assert isinstance(tokenize_yaml('true'), ScalarToken)
    assert isinstance(tokenize_yaml('false'), ScalarToken)
    assert isinstance(tokenize_yaml('None'), ScalarToken)



# Generated at 2022-06-24 11:18:20.314200
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
  a: 1
  b: 4
  c: 2
  """

    assert validate_yaml(content=content, validator=Schema({"b": "integer"})) == (
        {"b": 4},
        [],
    )

# Generated at 2022-06-24 11:18:26.854564
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """Test YAML parsing"""
    assert isinstance(tokenize_yaml(""), ScalarToken)
    assert isinstance(tokenize_yaml("- 1"), ListToken)
    assert isinstance(tokenize_yaml("- 1\n- 2"), ListToken)
    assert isinstance(tokenize_yaml("foo: 1"), DictToken)
    assert isinstance(tokenize_yaml("foo: 1\nbar: 2"), DictToken)

# Generated at 2022-06-24 11:18:32.867799
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    ---
    a: 1
    b: 2
    """

    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert isinstance(token["a"], ScalarToken)
    assert isinstance(token["b"], ScalarToken)

    assert token["a"].value == 1
    assert token["a"].start == 6
    assert token["a"].end == 8

    assert token["b"].value == 2
    assert token["b"].start == 12
    assert token["b"].end == 14



# Generated at 2022-06-24 11:18:42.356219
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    ---
    id: 1
    title: "Hello"
    """

    class TitleSchema(Schema):
        title = Field(str)

    # This should pass.
    ret = validate_yaml(content, TitleSchema)
    assert ret[0]["title"] == "Hello"
    assert not ret[1]

    # This should fail.
    class IdSchema(Schema):
        id = Field(str)

    ret = validate_yaml(content, IdSchema)
    assert ret[0] is None
    assert ret[1]["id"].text == "Value must be of type 'str'."

    # Test a type mismatch.
    content = """
    ---
    id: "1"
    """

    class IdSchema(Schema):
        id = Field(int)

# Generated at 2022-06-24 11:18:44.021308
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert "test" == tokenize_yaml("test: 1").items()[0][0].value


# Generated at 2022-06-24 11:18:49.298181
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = String()
    value, messages = validate_yaml("hello", validator)
    assert value == "hello"
    assert messages == []
    content = "hello"
    token = tokenize_yaml(content)
    value, messages = validate_with_positions(token, validator)
    assert value == "hello"
    assert messages == []

# Generated at 2022-06-24 11:19:00.389386
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        content="""\
    - id: "matt"
      name: "Matt"
    - id: "joseph"
      name: "Joseph"
    """,
        validator=Schema(
            fields={"id": String(), "name": String()},
            meta={"many": True},
        ),
    ) == ([
        {"id": "matt", "name": "Matt"},
        {"id": "joseph", "name": "Joseph"}
    ], [])

# Generated at 2022-06-24 11:19:02.424768
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    isinstance(tokenize_yaml('''
---
foo:
  bar: baz
'''), Token)



# Generated at 2022-06-24 11:19:11.808706
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""
    title: My Title
    description: Some description
    thumbs:
        0:
            name: thumb 13
            type: vga
        1:
            name: thumb 12
            type: vga
    """
    schema = Schema({
        "title": types.String(),
        "description": types.String(),
        "thumbs": types.Array(types.Number(),types.Object({
            "name": types.String(),
            "type": types.String()
        }))
    })
    value, messages = validate_yaml(content, schema)
    assert value
    assert len(messages) == 0

# Generated at 2022-06-24 11:19:21.422857
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test empty input
    with pytest.raises(ParseError):
        tokenize_yaml("")

    # Test incomplete YML
    with pytest.raises(ParseError):
        tokenize_yaml("'test':")

    # Test valid YML
    result = tokenize_yaml("test_field: test_value")
    assert isinstance(result, DictToken)
    result = tokenize_yaml("test_list:['test_value', 'test_value']")
    assert isinstance(result, DictToken)



# Generated at 2022-06-24 11:19:26.107238
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    schema = Schema(fields=[Field(name="x", type="text")])
    content = """\
    x: hello
    """
    value, error_messages = validate_yaml(content, schema)
    assert value == {"x": "hello"}



# Generated at 2022-06-24 11:19:35.716415
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Unit test for function tokenize_yaml
    token = tokenize_yaml('"test_value"')
    assert isinstance(token, ScalarToken)
    assert token.value == "test_value"

    token = tokenize_yaml("[1, 2, 3]")
    assert isinstance(token, ListToken)
    assert isinstance(token.value[0], ScalarToken)
    assert token.value[0].value == 1
    assert isinstance(token.value[1], ScalarToken)
    assert token.value[1].value == 2
    assert isinstance(token.value[2], ScalarToken)
    assert token.value[2].value == 3

    token = tokenize_yaml("{key: value}")
    assert isinstance(token, DictToken)
    dict_token = token

# Generated at 2022-06-24 11:19:43.170620
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
        a:
            b: 123
            c:
                d: 456
        e:
            - 1
            - 2
            - 3
        f:
            -
                h: 789
                i: 890
        j: true
        k: null
    '''
    token = tokenize_yaml(content)

# Generated at 2022-06-24 11:19:45.432828
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    s = "a: 'b'"
    token = tokenize_yaml(s)
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == len(s) - 1
    assert token.content == s
    assert token.value == {"a": "b"}



# Generated at 2022-06-24 11:19:51.667564
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "created_at: 2020-10-13 14:07:00.341228"
    expected_value = {'created_at': '2020-10-13 14:07:00.341228'}

    class MySchema(Schema):
        created_at = Field(format="date-time")

    result, error_messages = validate_yaml(content, validator=MySchema())
    
    assert result == expected_value
    assert error_messages == []

# Generated at 2022-06-24 11:19:59.989714
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    def assert_token(token, value):
        """ Asserts basic properties of a token.
        (start, end, value and type)
        """
        assert token.value == value
        assert token.start == 0
        assert token.end == 0
        assert token.type == type(value)

    assert_token(tokenize_yaml("null"), None)
    assert_token(tokenize_yaml("true"), True)
    assert_token(tokenize_yaml("false"), False)
    assert_token(tokenize_yaml("1"), 1)
    assert_token(tokenize_yaml("0"), 0)
    assert_token(tokenize_yaml("-1"), -1)
    assert_token(tokenize_yaml("1.0"), 1.0)

# Generated at 2022-06-24 11:20:07.983088
# Unit test for function validate_yaml
def test_validate_yaml():

    content = """
    foo: hello
    bar:
      - 1
      - 2
      - 3
    whiz: true
    """

    class MySchema(Schema):
        foo = fields.String()
        bar = fields.List(fields.Integer())
        whiz = fields.Boolean()

    value, errors = validate_yaml(content=content, validator=MySchema)
    assert value == {
        "foo": "hello",
        "bar": [1, 2, 3],
        "whiz": True,
    }
    assert errors == []

# Generated at 2022-06-24 11:20:16.858311
# Unit test for function validate_yaml
def test_validate_yaml():
    class AddressSchema(Schema):
        street = StringField()
        city = StringField()
        zip_code = StringField()

    class PersonSchema(Schema):
        name = StringField()
        age = IntField()
        address = ModelField(AddressSchema)

    content = "age: hello\naddress:\n  city: Melbourne"
    value, errors = validate_yaml(content, validator=PersonSchema)
    assert value is None
    assert len(errors) == 2
    assert isinstance(errors, list)
    assert isinstance(errors[0], ValidationError)
    assert errors[0].code == "invalid_type"
    assert errors[1].code == "required"

    person_content = "name: John\nage: 20\naddress:\n  city: Melbourne"
    value

# Generated at 2022-06-24 11:20:27.784509
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    assert tokenize_yaml("") == None

    assert tokenize_yaml("3") == ScalarToken(3, 0, 1, "3")

    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, "true")

    assert tokenize_yaml("\"Hello world\"") == ScalarToken("Hello world", 0, 13, "\"Hello world\"")

    assert tokenize_yaml("[3, 1]") == ListToken([3, 1], 0, 6, "[3, 1]")

    assert tokenize_yaml("{a: 1, b: 2}") == DictToken({"a": 1, "b": 2}, 0, 13, "{a: 1, b: 2}")

    assert tokenize_yaml("[{a: 1}, {b: 2}]") == ListToken

# Generated at 2022-06-24 11:20:39.266428
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = b"foo: bar"
    tokens = tokenize_yaml(content)
    assert tokens[0] == "bar"
    assert tokens[1] == 8
    assert tokens[2] == 10

    content = "foo: bar"
    tokens = tokenize_yaml(content)
    assert tokens[0] == "bar"
    assert tokens[1] == 4
    assert tokens[2] == 6

    content = b"foo: \n  bar"
    tokens = tokenize_yaml(content)
    assert tokens[0] == "bar"
    assert tokens[1] == 8
    assert tokens[2] == 12

    content = "foo: \n  bar"
    tokens = tokenize_yaml(content)
    assert tokens[0] == "bar"
    assert tokens[1] == 7


# Generated at 2022-06-24 11:20:46.644100
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    # Simple data structures should be tokenized correctly.
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("5") == 5
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") is True
    assert tokenize_yaml("false") is False
    assert tokenize_yaml("null") is None

    # Tokenized tokens should be marked with correct ranges.
    assert tokenize_yaml("{}").start == 0
    assert tokenize_yaml("{}").end == 1

    # Tokenized tokens should preserve token content.
    assert tokenize_yaml("[a]").content == "[a]"

    # Tokenizing an empty string should raise an error.
