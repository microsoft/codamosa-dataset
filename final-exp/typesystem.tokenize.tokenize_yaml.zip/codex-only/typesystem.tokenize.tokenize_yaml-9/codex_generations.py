

# Generated at 2022-06-24 11:10:42.986592
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert (
        tokenize_yaml(b'name: "typesystem"')
        == {'name': 'typesystem'}
    )



# Generated at 2022-06-24 11:10:53.802571
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Empty YAML string
    assert tokenize_yaml("")
    # YAML string with no content
    content = "\n  \n"
    assert tokenize_yaml(content)
    # YAML string with no content (with multiple lines)
    content = "\n  \n\n  \n"
    assert tokenize_yaml(content)
    # YAML string with no content (with multiple spaces)
    content = "   "
    assert tokenize_yaml(content)
    # Simple YAML string with only strings
    content = "name: Peter"
    assert tokenize_yaml(content)
    # Simple YAML string with integer
    content = "age: 32"
    assert tokenize_yaml(content)
    # Simple YAML string with float

# Generated at 2022-06-24 11:11:02.010493
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("---\n- 1\n- 2\n- 3") == [1, 2, 3]
    assert tokenize_yaml("---\nfoo: bar") == {"foo": "bar"}
    assert (
        tokenize_yaml(
            "---\n- !<tag:yaml.org,2002:str> foo\n- !<tag:yaml.org,2002:str> baz"
        )
        == ["foo", "baz"]
    )



# Generated at 2022-06-24 11:11:09.600879
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ScalarToken(None, 0, 0, content="")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    assert tokenize_yaml("~") == ScalarToken(None, 0, 0, content="~")
    assert tokenize_yaml("-") == ScalarToken("-", 0, 0, content="-")
    assert tokenize_yaml("-1") == ScalarToken(-1, 0, 1, content="-1")

# Generated at 2022-06-24 11:11:13.081412
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == []
    if yaml is not None:
        assert tokenize_yaml("""
            - "foo": 1
            - "bar": 2
        """) == [{"foo": 1}, {"bar": 2}]



# Generated at 2022-06-24 11:11:18.275608
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    {
      "name": "Jane",
      "age": "bob"
    }
    """
    validator = typing.TypeVar("validator", bound=Schema)
    errors = validate_yaml(content, validator)
    assert isinstance(errors, list)

# Generated at 2022-06-24 11:11:21.633064
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: John"
    validator = typing.Union[Field, typing.Type[Schema]]
    assert validate_yaml(content, validator)
    return "passed"


# Generated at 2022-06-24 11:11:30.271671
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
  content = """---
        title: Example Schema
        type: object
        properties:
          firstName:
            type: string
          lastName:
            type: string
          age:
            description: Age in years
            type: integer
            minimum: 0
        required:
        - firstName
        - lastName
        """
  token = tokenize_yaml(content)
  assert token.keys() == ['title', 'type', 'properties', 'required']
  assert type(token['properties']) == DictToken
  assert type(token['required']) == ListToken
  assert type(token['properties']['age']) == DictToken
  assert type(token['properties']['age']['minimum']) == ScalarToken
  assert token['properties']['age']['minimum'].value == 0
 

# Generated at 2022-06-24 11:11:34.109413
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    d = {"a": "b", "c": [{"d": 1}, {"e": 1}]}
    d_str = 'a: "b"\nc:\n- d: 1\n- e: 1'
    assert tokenize_yaml(d_str) == d


# Generated at 2022-06-24 11:11:45.737759
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert(tokenize_yaml("Hello, world!") == "Hello, world!")
    assert(tokenize_yaml("42") == 42)
    assert(tokenize_yaml("42.5") == 42.5)
    assert(tokenize_yaml("3.14E2") == 314.0)
    assert(tokenize_yaml("{'a': 42}") == {'a': 42})
    assert(tokenize_yaml("[1, 2, 3]") == [1, 2, 3])
    assert(tokenize_yaml("[]") == [])
    assert(tokenize_yaml("{}") == {})
    assert(tokenize_yaml("null") is None)
    assert(tokenize_yaml("true") is True)

# Generated at 2022-06-24 11:11:52.600976
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Test Success Scenario
    from typesystem.fields import String
    from typesystem.types import ShortString

    class UserSchema(Schema):
        username = ShortString(max_length=100)

    payload = "username: admin"
    value, errors = validate_yaml(content=payload, validator=UserSchema)
    assert errors == []

    # Test Error Scenarios
    payload = "username: "
    value, errors = validate_yaml(content=payload, validator=UserSchema)
    assert errors != []
    payload = "username: ad"
    value, errors = validate_yaml(content=payload, validator=UserSchema)
    assert errors != []

# Generated at 2022-06-24 11:11:58.777664
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 20
    """
    class PersonSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True)

    value, errors = validate_yaml(content, validator=PersonSchema)
    assert type(value) == dict
    assert value["name"] == "John"
    assert value["age"] == 20
    assert errors == []


# Generated at 2022-06-24 11:12:07.506374
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert isinstance(tokenize_yaml('{"a": "b", "c": "d"}'), DictToken)
    assert isinstance(tokenize_yaml('{"a": "b", "c": "d"}'), DictToken)
    assert isinstance(tokenize_yaml('[1,2,3]'), ListToken)
    assert isinstance(tokenize_yaml('a'), ScalarToken)
    assert isinstance(tokenize_yaml('1'), ScalarToken)
    assert isinstance(tokenize_yaml('1.0'), ScalarToken)
    assert isinstance(tokenize_yaml('true'), ScalarToken)
    assert isinstance(tokenize_yaml('false'), ScalarToken)

# Generated at 2022-06-24 11:12:16.282354
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import yaml
    assert yaml is not None

    class CustomSafeLoader(yaml.SafeLoader):
        pass
    # Say we want to test the case where we have an empty file
    # For now we would like to see what happens

    def construct_mapping(loader, node):
        mapping = loader.construct_mapping(node)
        return DictToken(mapping)

    def construct_sequence(loader, node):
        value = loader.construct_sequence(node)
        return ListToken(value)

    def construct_scalar(loader, node):
        value = loader.construct_scalar(node)
        return ScalarToken(value)

    CustomSafeLoader.add_constructor(
        yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, construct_mapping
    )

   

# Generated at 2022-06-24 11:12:19.169994
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
	content = """
	name: John
	"""
	token = tokenize_yaml(content)
	assert token.get_token(token.START, token.END) == content


# Generated at 2022-06-24 11:12:26.738586
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{a: 1}") == DictToken({'a': 1}, 0, 5)
    assert tokenize_yaml("{a: 1}") == DictToken({'a': 1}, 0, 5)
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml(": a: 1")
        assert "Expected '{', got" in excinfo._excinfo[1].problem
        assert excinfo._excinfo[1].problem_mark.line == 1
        assert excinfo._excinfo[1].problem_mark.column == 1



# Generated at 2022-06-24 11:12:35.080753
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema, Structure

    class MySchema(Schema):
        foo = String()
        bar = Integer(minimum=5)

    # A valid input YAML string
    input_valid = '''
        foo: "hello"
        bar: 5
        '''

    # Invalid input YAML: missing key "bar"
    input_invalid_missing_key = '''
        foo: "hello"
        '''

    # Invalid input YAML: incorrect type for "bar"
    input_invalid_incorrect_type = '''
        foo: "hello"
        bar: "not_an_integer"
        '''

    # Invalid input YAML: incorrect type for "bar"

# Generated at 2022-06-24 11:12:41.985902
# Unit test for function validate_yaml
def test_validate_yaml():
    #
    # setup
    #
    class BasicYAMLSchema(Schema):
        name = "BasicYAMLSchema"
        a = Field()
        b = Field()

    #
    # Validate a basic schema
    #
    content = u"""
        a:
            - 5.4
            - 0
            - 100
            - true
            - false
            - null
        b:
            c:
                d:
                    e:
                        - test
                        - int: 5
                        - float: 50.5
    """

    required_fields, errors = validate_yaml(content, BasicYAMLSchema)
    assert required_fields["a"] == [5.4, 0.0, 100.0, True, False, None]

# Generated at 2022-06-24 11:12:47.530279
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        person:
            name: John Smith
            age: 26
            address:
                street: 7th Street
                city: New York
            hobbies:
                - Basketball
                - Traveling
    """
    token = tokenize_yaml(content)

    assert isinstance(token, DictToken)
    assert token.value == {
        "person": {
            "name": "John Smith",
            "age": 26,
            "address": {"street": "7th Street", "city": "New York"},
            "hobbies": ["Basketball", "Traveling"],
        }
    }



# Generated at 2022-06-24 11:12:56.741399
# Unit test for function validate_yaml
def test_validate_yaml():
            sample_validation_error = Message( 
                text='Must be equal to "foobar".', 
                code='invalid', 
                type='error', 
                context={'required': 'foobar'}, 
                position=Position(1, 1, 0), 
                value=ScalarToken('hello world', 0, 12, 'hello world')
            )
            sample_validation_error_2 = Message( 
                text='Must be equal to "foobar".', 
                code='invalid', 
                type='error', 
                context={'required': 'foobar'}, 
                position=Position(1, 2, 13), 
                value=ScalarToken('hello world', 0, 12, 'hello world')
            )

# Generated at 2022-06-24 11:13:04.558137
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    assert tokenize_yaml("123") == ScalarToken(123, 0, 2, content="123")
    assert tokenize_yaml("hello") == ScalarToken("hello", 0, 4, content="hello")
    assert tokenize_yaml("hello: world") == DictToken({'hello': 'world'}, 0, 11, content="hello: world")
    assert tokenize_yaml("- hello") == ListToken(['hello'], 0, 7, content="- hello")


# Generated at 2022-06-24 11:13:15.556920
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test_1
    res = tokenize_yaml('text_1: "@text_1"')
    assert isinstance(res,DictToken)
    assert res.dict_val['text_1'] == '@text_1'

    # test_2
    res = tokenize_yaml('number: 1')
    assert isinstance(res,DictToken)
    assert res.dict_val['number'] == 1

    # test_3
    res = tokenize_yaml('text_2: |')
    assert isinstance(res,DictToken)
    assert res.dict_val['text_2'] == ''

    # test_4
    with pytest.raises(ParseError, match=r"No content."):
        tokenize_yaml('')
    
    # test_5
    res

# Generated at 2022-06-24 11:13:24.918114
# Unit test for function validate_yaml
def test_validate_yaml():
    # Success cases
    try:
        assert validate_yaml("community: yes", Field(description="description")) == (
            "yes",
            [],
        )
    except Exception:
        assert False
    try:
        assert validate_yaml("58.48", Field(description="description")) == (
            58.48,
            [],
        )
    except Exception:
        assert False
    try:
        assert validate_yaml(b"12", Field(description="description")) == (12, [])
    except Exception:
        assert False

    # Create a simple Schema type
    class MySchema(Schema):
        field = Field(description="description")

    # Success case

# Generated at 2022-06-24 11:13:27.765492
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo: "abc"
    """
    tokens = tokenize_yaml(content)
    assert tokens.yaml == {'foo': 'abc'}

# Generated at 2022-06-24 11:13:35.698053
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem.schema import Schema
    from typesystem.fields import String

    class AddressSchema(Schema):
        street = String()
        city = String()
        zip_code = String()

    class PersonSchema(Schema):
        name = String()
        age = String()
        addresses = AddressSchema(many=True)

    yaml_string = """
    name: Jim Bloggs
    age: 45
    addresses:
        - street: 1 The Street
          city: Some City
          zip_code: 12345
        - street: 2 Another Street
          city: Some City
          zip_code: 12345
    """

    value, errors = validate_yaml(yaml_string, PersonSchema)
    assert errors == []

# Generated at 2022-06-24 11:13:38.422507
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - hello
    - world
    """

    errors = validate_yaml(content, ListToken)
    assert len(errors) == 0



# Generated at 2022-06-24 11:13:45.294129
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(
        "{name: test_dict, year: 2020, is_end: true, null_value: null, percentage: 10.5}"
    ) == {
        "name": "test_dict",
        "year": 2020,
        "is_end": True,
        "null_value": None,
        "percentage": 10.5,
    }

    assert tokenize_yaml("[]") == []

    assert tokenize_yaml("- [1, 2, 3]\n- [4, 5, 6]") == [[1, 2, 3], [4, 5, 6]]

    with pytest.raises(ParseError, match="No content."):
        tokenize_yaml("")



# Generated at 2022-06-24 11:13:56.481964
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("- 1"), ListToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("1.1"), ScalarToken)
    assert isinstance(tokenize_yaml("a"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml("{a: 1}"), DictToken)
    assert isinstance(tokenize_yaml("1 2"), ScalarToken)

# Generated at 2022-06-24 11:14:07.294027
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("a") == ScalarToken("a")
    assert tokenize_yaml("123") == ScalarToken(123)
    assert tokenize_yaml("12.34") == ScalarToken(12.34)
    assert tokenize_yaml("true") == ScalarToken(True)
    assert tokenize_yaml("false") == ScalarToken(False)
    assert tokenize_yaml("null") == ScalarToken(None)
    assert tokenize_yaml("- a") == ListToken(["a"])
    assert tokenize_yaml("- 1\n- 2") == ListToken([1, 2])
    assert tokenize_yaml("key: value") == DictToken({"key": "value"})

# Generated at 2022-06-24 11:14:19.465338
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem
    import pytest

    class UserSchema(typesystem.Schema):
        name: typesystem.String = typesystem.String(max_length=100)
        age: typesystem.Integer = typesystem.Integer(maximum=100)
        bio: typesystem.String = typesystem.String(required=False)

    yaml_string = """
    name: Josiah Carberry
    age: 31
    bio: ""
    """

    schema = UserSchema()
    value, errors = validate_yaml(content=yaml_string, validator=schema)

    assert not errors
    assert value == {"name": "Josiah Carberry", "age": 31, "bio": ""}

    schema = UserSchema(strict=True)

# Generated at 2022-06-24 11:14:21.534263
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('''
        key: value
        key2: value2
    ''') == {'key': 'value', 'key2': 'value2'}


# Generated at 2022-06-24 11:14:28.501835
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = (
        "first_name: John\n"
        "last_name: Smith\n"
        "age: 25"
    )
    tokens = tokenize_yaml(content)
    expected = DictToken(
        {
            "first_name": "John",
            "last_name": "Smith",
            "age": 25,
        },
        0,
        len(content) - 1,
        content=content,
    )
    assert tokens == expected

    expected = DictToken(
        {
            "first_name": "John",
            "last_name": "Smith",
            "age": 25,
        },
        0,
        len(content) - 1,
        content=content,
    )
    tokens = tokenize_yaml(content)
    assert tokens == expected


# Generated at 2022-06-24 11:14:38.945199
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == {}, "Empty YAML should tokenize to empty dict."
    assert (tokenize_yaml("foo: 42") == {'foo': ScalarToken('42', 0, 6, content="foo: 42")}), "YAML should tokenize."
    assert (
        tokenize_yaml("foo: 42\nbar: \n  - baz") ==
        {
            'foo': ScalarToken('42', 0, 6, content="foo: 42\nbar: \n  - baz"),
            'bar': [ScalarToken('baz', 13, 17, content="foo: 42\nbar: \n  - baz")]
        }
    ), "YAML should tokenize."



# Generated at 2022-06-24 11:14:50.088271
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem import parse_error, validation_error

    class User(Schema):
        name = String()
        age = Integer(minimum=13)

    content = """
        name: Alex
        age: 12
    """

    (value, errors) = validate_yaml(content=content, validator=User)
    assert errors == [
        validation_error(
            field="age",
            text="Ensure this value is greater than or equal to 13.",
            code="min_value",
            position=Position(line_no=2, column_no=8, char_index=16),
        )
    ]
    assert value == {"name": "Alex", "age": 12}


# Generated at 2022-06-24 11:14:58.018463
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, start=0, end=1)
    assert tokenize_yaml("[]") == ListToken([], start=0, end=1)
    assert tokenize_yaml("foo") == ScalarToken("foo", start=0, end=2)
    assert tokenize_yaml("42") == ScalarToken(42, start=0, end=1)
    assert tokenize_yaml("3.14159") == ScalarToken(3.14159, start=0, end=6)
    assert tokenize_yaml("true") == ScalarToken(True, start=0, end=3)
    assert tokenize_yaml("false") == ScalarToken(False, start=0, end=4)
    assert tokenize_yaml("null") == Scalar

# Generated at 2022-06-24 11:15:06.865775
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("A: B") == DictToken({
        'A': 'B'
    }, start=0, end=3, content='A: B')
    assert tokenize_yaml("A: B\nC: D") == DictToken({
        'A': 'B',
        'C': 'D'
    }, start=0, end=8, content='A: B\nC: D')
    assert tokenize_yaml("A: B\nC: D\n") == DictToken({
        'A': 'B',
        'C': 'D'
    }, start=0, end=8, content='A: B\nC: D\n')

# Generated at 2022-06-24 11:15:16.633669
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem.types import String, Integer

    class YAMLField(Field):
        def validate(self, value: str) -> str:
            return value.strip()

    class YAMLIntegerField(Integer):
        def validate(self, value: int) -> int:
            if value < 0:
                raise ValidationError("Must be an positive number.")
            return value

    class YAMLSchema(Schema):
        name = YAMLField(description="Full name", max_length=100)
        age = YAMLIntegerField()

    valid_yaml_content = """
name: Tony Stark
age: 42
"""

    invalid_yaml_content = """
name: Tony Stark
age: "42"
"""

    invalid_y

# Generated at 2022-06-24 11:15:21.810736
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test that tokenize_yaml correctly tokenizes YAML content
    assert isinstance(tokenize_yaml(""), ScalarToken)
    assert isinstance(tokenize_yaml("foo: bar"), DictToken)
    assert isinstance(tokenize_yaml("- bar"), ListToken)


# Generated at 2022-06-24 11:15:29.571228
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "a: 1"
    id = "['a', 1]"
    res = tokenize_yaml(content)
    assert res.serialize() == id
    #
    content = "a: [{b: 1}, {c: 2}]"
    id = "['a', [{'b': 1}, {'c': 2}]]"
    res = tokenize_yaml(content)
    assert res.serialize() == id


# Generated at 2022-06-24 11:15:37.218202
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}").start == 0
    assert tokenize_yaml("{}").end == 1
    assert tokenize_yaml("{}").content == "{}"

    assert tokenize_yaml("{a: b}")["a"].content == "b"
    assert tokenize_yaml("{a: b}").content == "{a: b}"

    assert tokenize_yaml("[c]")[0].content == "c"
    assert tokenize_yaml("[c]").content == "[c]"

    assert tokenize_yaml("[]").content == "[]"

    assert tokenize_yaml("a").content == "a"

    with pytest.raises(ParseError) as exc:
        tokenize_yaml("")

    assert exc.value.text == "No content."

# Generated at 2022-06-24 11:15:47.887919
# Unit test for function tokenize_yaml

# Generated at 2022-06-24 11:15:50.081244
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('{"this": "is", "a": "test"}') == DictToken({'a': 'test', 'this': 'is'}, 0, 30, '{"this": "is", "a": "test"}')


# Generated at 2022-06-24 11:16:01.617457
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Test cases
    """
    empty_string = tokenize_yaml('')
    assert empty_string == {}

    one_level_string = tokenize_yaml('key1: value1\nkey2: value2')
    assert one_level_string == {
        "key1": "value1",
        "key2": "value2"
    }

    nested_string = tokenize_yaml('key1: value1\nkey2: value2\nkey3:\n  subkey1: value3\n  subkey2: value4')

# Generated at 2022-06-24 11:16:08.419937
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_content = bytes(
        """
        ---
        id: 1
        name: Alice
        """
    )
    class Person(Schema):
        id = Field(int)
        name = Field(str)

    value, error_messages = validate_yaml(
        content=yaml_content, validator=Person
    )
    assert error_messages == []
    assert value.id == 1
    assert value.name == "Alice"


# Generated at 2022-06-24 11:16:11.152467
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # valid simple yaml
    tokenize_yaml('a: a')

    # invalid empty yaml
    with pytest.raises(ParseError):
        tokenize_yaml('')


# Generated at 2022-06-24 11:16:22.080374
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = String()
        age = Int()

    content = 'name: "Alice"\nage: 25'
    errors = validate_yaml(content, TestSchema)
    assert not errors

    content = "name: Alice"
    errors = validate_yaml(content, TestSchema)
    assert errors
    assert len(errors) == 1
    error = errors[0]
    assert error.code == "required"
    assert error.position == Position(column_no=1, line_no=1, char_index=0)

    content = "name: Alice"
    instance, errors = validate_yaml(content, TestSchema())
    assert errors
    assert len(errors) == 1
    error = errors[0]
    assert error.code == "required"

# Generated at 2022-06-24 11:16:25.164925
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert type(tokenize_yaml("test: value")) is DictToken
    assert type(tokenize_yaml("- item")) is ListToken
    assert type(tokenize_yaml("value")) is ScalarToken


# Generated at 2022-06-24 11:16:27.741147
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """- string: is this fun?"""
    token = tokenize_yaml(content)
    value = validate_with_positions(token=token, validator=typing.Dict[str, str])
    assert value == ({'string': 'is this fun?'}, [])

# Generated at 2022-06-24 11:16:36.138968
# Unit test for function validate_yaml
def test_validate_yaml():
    BASE_SCHEMA = {
        "type": "object",
        "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
    }

    content = """
name: "Foo"
age: 31
"""

    assert validate_yaml(content, BASE_SCHEMA) == (
        {"name": "Foo", "age": 31},
        [],
    )

    content = """
name: Foo
age: 31
"""

    assert validate_yaml(content, BASE_SCHEMA) == (
        {},
        [Message(text="Value is not of type 'string'.", code="type_error.string")],
    )

    content = """
name: "Foo"
age: thirty one
"""


# Generated at 2022-06-24 11:16:41.975674
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""
            name: "tarun"
            age: 24
        """
    class UserSchema(Schema):
        name = String(max_length=10)
        age = Integer()
    value, error_messages = validate_yaml(content, UserSchema)
    assert error_messages == []
    assert value == {"name": "tarun", "age": 24}


# Generated at 2022-06-24 11:16:52.564544
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Simple success case.
    (value, errors) = validate_yaml(
        content="name: test", validator={"name": {"type": "string"}}
    )
    assert value == {"name": "test"}
    assert errors == []

    # Simple failure case.
    (value, errors) = validate_yaml(
        content="name: test", validator={"name": {"type": "integer"}}
    )
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert isinstance(errors[0].position, Position)

    # Failure case with multiple errors.

# Generated at 2022-06-24 11:17:00.635290
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        foo = String()
        bar = Integer()

    errors = validate_yaml(content='{"foo": "hi", "baz": "bye"}', validator=MySchema)
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 11
    assert errors[0].position.char_index == 10
    assert errors[0].code == "validation_error"

# Unit tests for function tokenize_yaml

# Generated at 2022-06-24 11:17:05.814645
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a:
        - a
        - b
    b: c
    """
    token = tokenize_yaml(content)

    assert isinstance(token, DictToken)

    assert isinstance(token["a"], ListToken)
    assert isinstance(token["a"][0], ScalarToken)
    assert isinstance(token["a"][1], ScalarToken)
    assert token["a"][0].value == "a"
    assert token["a"][1].value == "b"

    assert isinstance(token["b"], ScalarToken)
    assert token["b"].value == "c"



# Generated at 2022-06-24 11:17:12.899857
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"a": Field(int, required=True)})
    assert validate_yaml(b"a: ", schema) == (None, [Message("Parse error.", code="parse_error")])
    assert validate_yaml(b"a: ", schema) == (None, [Message("Parse error.", code="parse_error")])
    assert validate_yaml(b"a: ", schema) == (None, [Message("Parse error.", code="parse_error")])



# Generated at 2022-06-24 11:17:16.995961
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    content = """
    name: Drew
    age: 1
    """

    value, errors = validate_yaml(content, PersonSchema)

    assert value == {"name": "Drew", "age": 1}
    assert errors == []



# Generated at 2022-06-24 11:17:25.894336
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test_case = """
        properties:
          type: object
          properties:
            id:
              type: string
              format: uuid
            name:
              type: string
              min_length: 3
              max_length: 255
            host:
              type: string
              min_length: 3
              max_length: 255
            description:
              type: string
              max_length: 255
            port:
              type: integer
              minimum: 0
              maximum: 65535
            status:
              type: string
              enum: [enabled, disabled]
            host:
              type: string
              min_length: 3
              max_length: 255
            tags:
              type: array
              items:
                type: string
                min_length: 1
                max_length: 255
        """

    test_result = token

# Generated at 2022-06-24 11:17:36.145737
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("""
        - a
        - b
    """) == ListToken(
        [
            ScalarToken("a", 0, 0, content="\n        - a\n        - b\n    "),
            ScalarToken("b", 0, 0, content="\n        - a\n        - b\n    "),
        ],
        0,
        0,
        content="\n        - a\n        - b\n    ",
    )


# Generated at 2022-06-24 11:17:41.914253
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
age: 18
name:
    first: John
    last: Smith
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert isinstance(token["age"], ScalarToken)
    assert isinstance(token["name"], DictToken)
    assert isinstance(token["name"]["first"], ScalarToken)
    assert isinstance(token["name"]["last"], ScalarToken)


# Generated at 2022-06-24 11:17:54.013179
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    # Test a YAML string with all data types and format.
    yaml_str = """
    # list with 3 elements
    - true
    - 0.4
    - -1
    # mapping with 2 elements
    name: Alex
    age: 20
    """
    expected = DictToken(  # type: ignore
        {"name": "Alex", "age": 20},
        start=17,
        end=73,
        content=yaml_str,
    )
    assert tokenize_yaml(yaml_str) == expected
    # Test an empty string.
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml("")
    assert excinfo.value.position.char_index == 0


# Generated at 2022-06-24 11:18:05.363477
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    tokenize_yaml("{}")
    tokenize_yaml("[]")
    tokenize_yaml("foo")
    tokenize_yaml("42")
    tokenize_yaml("0")
    tokenize_yaml("3.14")
    tokenize_yaml("true")
    tokenize_yaml("false")
    tokenize_yaml("null")
    tokenize_yaml("\t{}\t")
    tokenize_yaml("\n{}\n")
    tokenize_yaml("yaml")
    tokenize_yaml("\t{}\n")
    tokenize_yaml("""
    - one
    - two
    - three
    """)
    tokenize_yaml("""
    one: 1
    two: 2
    three: 3
    """)

# Generated at 2022-06-24 11:18:15.911451
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    data_list = ['hello', 'world']
    data_map = {'hello': 'world'}
    assert tokenize_yaml('') == ''
    assert tokenize_yaml('') == ''
    assert tokenize_yaml(' ') == ''
    assert tokenize_yaml('\n') == ''
    assert tokenize_yaml('- hello\n  - world') == ['- hello', '  - world']
    assert tokenize_yaml('- hello\n  - world') == ['- hello', '  - world']
    assert tokenize_yaml('- hello\n  - world') == data_list
    assert tokenize_yaml('- hello\n  - world') == data_list
    assert tokenize_yaml('\n- hello\n  - world') == data_list
   

# Generated at 2022-06-24 11:18:27.894213
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("""
    foo:
      - bar
    """) == {"foo": ["bar"]}

    assert tokenize_yaml("""
    foo:
      - bar: test
    """) == {"foo": [{"bar": "test"}]}

    assert tokenize_yaml("""
    foo:
      - bar:
          test:
            - 123
            - 456
    """) == {"foo": [{"bar": {"test": [123, 456]}}]}

    # Test parsing of string, int, float, bool, and null types.
    assert tokenize_yaml("""
    foo: abc123
    """) == {"foo": "abc123"}

    assert tokenize_yaml("""
    foo: 123
    """) == {"foo": 123}

    assert tokenize_y

# Generated at 2022-06-24 11:18:34.591075
# Unit test for function tokenize_yaml
def test_tokenize_yaml(): # pragma: no cover
    content = '''
    a: "hello"
    b: 42
    c: true
    d: false
    e: null
    f: 1.23
    g: 
        a: 42
        b: 21
    h:
        - 42
        - 54
        - "hello"
    '''
    from pprint import pprint

    token = tokenize_yaml(content)

    pprint(token)
    pprint(token.to_primitive())



# Generated at 2022-06-24 11:18:43.575885
# Unit test for function validate_yaml
def test_validate_yaml():
    class CustomSchema(Schema):
        name = "CustomSchema"
        fields = [
            Field(type="string"),
            Field(type="string", required=False),
            Field(type="number"),
            Field(type="number", required=False),
            Field(type="boolean"),
            Field(type="boolean", required=False),
            Field(type="null"),
            Field(type="null", required=False),
            Field(type="string", pattern="^[A-Za-z]+$"),
        ]


# Generated at 2022-06-24 11:18:48.709142
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Data - yaml string
    yaml_str = """foo: bar
baz:
  - hello
  - world
qux:
  - foo: bar
    baz: qux
  - one: two
    three: four
"""
    # Execution
    token = tokenize_yaml(yaml_str)
    # Verification
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar", "baz": ["hello", "world"], "qux": [{"foo": "bar", "baz": "qux"}, {"one": "two", "three": "four"}]}


# Generated at 2022-06-24 11:18:59.853783
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import CompoundSchema, Schema

    class PersonSchema(CompoundSchema):
        name = Field(type="string")
        age = Field(type="integer")

    person1 = PersonSchema()
    person2 = PersonSchema()
    person1.name = "Luke"
    person1.age = 10
    person2.name = "Megan"
    person2.age = 21
    content = dedent(
        """
        - name: Luke
          age: 10
        - name: Megan
          age: 21
        """
    )
    value, error_messages = validate_yaml(content, ListToken(PersonSchema))
    assert value == tokenize_yaml(content)
    assert error_messages == []
    assert value == [person1, person2]



# Generated at 2022-06-24 11:19:02.637824
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = {"text": {"type": "text", "required": True}}
    value, _ = validate_yaml(content=b"text", validator=schema)
    assert value == {"text": "text"}

# Generated at 2022-06-24 11:19:07.664003
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    - item
    - item
    - item
    """
    token = tokenize_yaml(content)
    assert isinstance(token, Token)
    assert token.data == ["item", "item", "item"]

    content = """
    name: Test
    age: 22
    """
    token = tokenize_yaml(content)
    assert isinstance(token, Token)
    assert token.data["name"] == "Test"
    assert token.data["age"] == 22

# Generated at 2022-06-24 11:19:13.115613
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer

    class Person(Schema):
        name = Integer()

    content = "name: Matt"
    (value, errors) = validate_yaml(content=content, validator=Person)
    assert errors[0].text == 'Invalid type for field "name". Expected "integer".'
    assert errors[0].position.char_index == len("name: ")

# Generated at 2022-06-24 11:19:24.965645
# Unit test for function validate_yaml
def test_validate_yaml():
    from yaml import safe_load
    from typesystem.schemas import Schema
    from typesystem.fields import String, Boolean, Integer, Float, AnyOf, Enum
    from typesystem.fields.types import DateTime
    import datetime

    def validate_yaml_schema(yaml_string, schema):
        """
        Validates that the given string follows the typesystem type in the given
        Schema.

        Args:
            yaml_string (str): string in YAML format
            schema (Schema|dict): A Schema subclass or a dictionary describing
                typesystem types.

        Returns:
            The validated yaml_string in Python data format.
        """
        if not isinstance(schema, Schema):
            schema_class = Schema.generate(schema)
        else:
            schema_

# Generated at 2022-06-24 11:19:34.603300
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    dict_schema = {
        "dict_field": {
            "type": "dict",
            "properties": {
                "a_field": {"type": "integer"},
                "another_field": {"type": "boolean"},
            },
        }
    }
    dict_content = "dict_field:\na_field: 123\nanother_field: True"
    dict_token = tokenize_yaml(dict_content)
    assert isinstance(dict_token, dict)
    assert isinstance(dict_token["dict_field"], dict)
    assert dict_token["dict_field"]["a_field"] == 123
    assert dict_token["dict_field"]["another_field"] is True
    value, errors = validate_yaml(dict_content, dict_schema)
    assert not errors

# Generated at 2022-06-24 11:19:37.975458
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    field = Field(
        name="title", type="string", required=True, description="A string."
    )
    value, errors = validate_yaml(
        content="""title: Wibble""", validator=field
    )
    assert not errors
    assert value == "Wibble"



# Generated at 2022-06-24 11:19:41.463357
# Unit test for function validate_yaml
def test_validate_yaml():
    #Assigning correct yaml content
    content = "name: James"
    #Assigning correct schema
    validator = Schema([
        Field("name", type="string")
    ])
    value, messages = validate_yaml(content, validator)
    assert value == {"name": "James"}
    assert messages == []


# Generated at 2022-06-24 11:19:51.679901
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "abc"
    token = tokenize_yaml(content)
    assert token.value == "abc"
    assert token.start == 0
    assert token.end == 2
    assert token.content == "abc"

    content = "---\n- [1, 2]\n- {a: b, c: d}\n"
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert len(token.value) == 2
    assert token.value[0] == [1, 2]
    assert token.value[1] == {"a": "b", "c": "d"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content



# Generated at 2022-06-24 11:19:54.349888
# Unit test for function validate_yaml
def test_validate_yaml():
    token = ListToken([ScalarToken("hello")])
    assert token.type == "list"
    assert token.value[0].type == "scalar"
    assert token.value[0].value == "hello"

# Generated at 2022-06-24 11:20:01.648822
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {
            "name": str,
            "year": int,
            "state": str,
            "city": str,
            "address": str,
        }
    )
    data = """
    name: karthik
    year: 1999
    state: karnataka
    city: mangalore
    address: amanakar
    """

    assert validate_yaml(data, schema) == ({"name": "karthik",
                                            "year": 1999,
                                            "state": "karnataka",
                                            "city": "mangalore",
                                            "address": "amanakar"},
                                           [])


# Generated at 2022-06-24 11:20:12.333200
# Unit test for function validate_yaml
def test_validate_yaml():

    schema = Schema('test', {
        'title': 'text',
        'category': 'text',
        'price': 'number',
        'discount': 'number',
        'stock': 'number',
    })
    value, error_messages = validate_yaml(
        """
        title: The Catcher In The Rye<
        category: book
        price: 0
        discount: 0
        stock: 10
        """,
        validator=schema,
    )

    assert len(error_messages) == 2
    assert error_messages[0].text == 'String contains a control character.'
    assert error_messages[0].position.line_no == 2
    assert error_messages[0].position.column_no == 24

    assert error_messages[1].text == 'Additional property category found.'

# Generated at 2022-06-24 11:20:19.495764
# Unit test for function tokenize_yaml

# Generated at 2022-06-24 11:20:22.483429
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test by running tokenize_yaml on a test YAML string
    # and then running type(token) and token.value on it
    # to confirm that it's a ListToken with the correct value

    test_yaml = '''
    - item1
    - item2
    '''

    token = tokenize_yaml(test_yaml)
    assert isinstance(token, ListToken)
    assert token.value == ['item1', 'item2']

# Generated at 2022-06-24 11:20:31.722848
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = Field(str)
        age = Field(int)
        height = Field(float)
        gender = Field(str)
        alive = Field(bool)

    yaml_str = """
        name: Mark
        age: 27
        gender: Male
        height: [1,2,3]
        alive: False
    """

    # Test that the function returns a two-tuple of (object, error messages)
    value, messages = validate_yaml(yaml_str, Person)

    # Test that the returned error messages have correct positions
    assert messages[0].position.line_no == 4
    assert messages[0].position.column_no == 7
    assert messages[1].position.line_no == 6
    assert messages[1].position.column_no == 7

    # Test

# Generated at 2022-06-24 11:20:41.982391
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test basic YAML parsing, including detection of leading whitespace.
    """
    s = "key: value"
    value, errors = validate_yaml(s, Schema({"key": str}))
    assert value == {"key": "value"}
    assert errors == []
    value, errors = validate_yaml("\n".join(["", "", "", "", "", s]), Schema({"key": str}))
    assert value == {"key": "value"}
    assert errors == []
    # extra key
    s = "key: value\nkey: not-value"
    value, errors = validate_yaml(s, Schema({"key": str}))
    assert value == {"key": "value"}