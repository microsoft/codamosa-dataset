

# Generated at 2022-06-24 11:10:37.062452
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(b"1", "integer") == (1, [])

# Generated at 2022-06-24 11:10:38.962394
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    id: 1
    """
    value, errors = validate_yaml(content, Field(type="integer"))
    assert errors == []
    assert value == {
        "id": 1
    }

# Generated at 2022-06-24 11:10:45.379563
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("1") == ScalarToken("1", 0, 0, content="1")
    assert tokenize_yaml("1.5") == ScalarToken("1.5", 0, 2, content="1.5")
    assert tokenize_yaml("0xFF") == ScalarToken("0xFF", 0, 3, content="0xFF")
    assert tokenize_yaml("-1") == ScalarToken("-1", 0, 1, content="-1")
    assert tokenize_yaml("true") == ScalarToken("true", 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken("false", 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken("null", 0, 3, content="null")

# Generated at 2022-06-24 11:10:54.099475
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    assert tokenize_yaml("foo: bar") == DictToken(  # type: ignore
        {"foo": "bar"}, 0, 8, content="foo: bar"
    )
    assert tokenize_yaml("[0, 1]") == ListToken([0, 1], 0, 6, content="[0, 1]")

    assert tokenize_yaml("---") is None
    assert tokenize_yaml("---\n  foo: bar") == DictToken(  # type: ignore
        {}, 3, 11, content="---\n  foo: bar"
    )



# Generated at 2022-06-24 11:11:05.253543
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("one: two") == DictToken(
        {"one": ScalarToken("two", 4, 6, content="one: two")},
        0,
        7,
        content="one: two",
    )
    assert tokenize_yaml("[1, 2, 3]") == ListToken(
        [ScalarToken(1, 1, 1, content="[1, 2, 3]"), ScalarToken(2, 3, 3, content="[1, 2, 3]"), ScalarToken(3, 5, 5, content="[1, 2, 3]")],
        0,
        6,
        content="[1, 2, 3]",
    )

# Generated at 2022-06-24 11:11:07.971907
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = r"""
    - hello
    - world
    """
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert type(token) == ListToken
    assert token.value[0] == "hello"
    assert token.value[1] == "world"
    assert token.start == 1
    assert token.end == 1 + len(content)
    assert token.content == content

# Generated at 2022-06-24 11:11:16.224300
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.1") == ScalarToken(1.1, 0, 2, content="1.1")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml('"1"') == ScalarToken("1", 0, 3, content='"1"')
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")

# Generated at 2022-06-24 11:11:22.206999
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo: bar
    baz:
      - 1
      - 2
    """

    token = tokenize_yaml(content)

    assert token.is_dict()
    assert token.get_child_token("foo").is_scalar()
    assert token.get_child_token("foo").value == "bar"
    assert token.get_child_token("baz").is_list()
    assert token.get_child_token("baz").get_child_token(0).is_scalar()
    assert token.get_child_token("baz").get_child_token(0).value == 1



# Generated at 2022-06-24 11:11:26.396680
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
      age: 10
    '''
    validator = Field(type="integer")

    value, error_messages = validate_yaml(content, validator)

    assert value == 10
    assert len(error_messages) == 0


# Generated at 2022-06-24 11:11:31.225400
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem.definitions import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType

    result, errors = validate_yaml(b'yaml_example: "test"', StringType(format="date"))
    assert errors == []
    assert result == {"yaml_example": "test"}
    result, errors = validate_yaml(b'yaml_example: "test"', String(format="date"))
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)

# Generated at 2022-06-24 11:11:42.957565
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Tokens should be correctly generated from YAML strings.
    """
    # Empty YAML string.
    empty_string_token = tokenize_yaml("")
    assert empty_string_token == DictToken({}, 0, -1, content="")
    # Single value YAML string.
    single_value_string_token = tokenize_yaml("test")
    assert single_value_string_token == ScalarToken("test", 0, 4, content="test")
    # Multiline YAML string.
    multiline_string_token = tokenize_yaml("test: \n  nested: \n    value")

# Generated at 2022-06-24 11:11:46.552208
# Unit test for function validate_yaml
def test_validate_yaml():
    schema_content = """
    type: object
    properties:
        username:
            type: string
        age:
            type: integer
    required:
    - username
    """
    schema = Schema(schema_content)
    error_messages = validate_yaml(
        content="""
        username: bad.username
        age: not_a_number
        """,
        validator=schema,
    )
    assert len(error_messages) == 2
    assert error_messages[0].code == "invalid_format"
    assert error_messages[1].code == "invalid_type"

# Generated at 2022-06-24 11:11:54.691065
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test well formatted single string value
    assert tokenize_yaml('test: "value"') == {'test': 'value'}

    # Test well formatted single integer value
    assert tokenize_yaml('test: 12') == {'test': 12}

    # Test well formatted single floating point value
    assert tokenize_yaml('test: 0.1') == {'test': 0.1}

    # Test well formatted single boolean value
    assert tokenize_yaml('test: true') == {'test': True}
    assert tokenize_yaml('test: false') == {'test': False}

    # Test well formatted single null value
    assert tokenize_yaml('null') == None

    # Test well formatted single array value

# Generated at 2022-06-24 11:11:58.047695
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    field = Field(type=int, array=True)
    value = validate_yaml(content, field)
    assert value == [1, 2, 3]
    assert isinstance(value, list)

# Generated at 2022-06-24 11:12:06.821980
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("-foo") == ["foo"]
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}
    assert tokenize_yaml("foo:") == {"foo": None}
    assert tokenize_yaml("foo: 1") == {"foo": 1}
    assert tokenize_yaml("foo: 1.0") == {"foo": 1.0}
    assert tokenize_yaml("foo: true") == {"foo": True}
    assert tokenize_yaml("foo: null") == {"foo": None}
    assert tokenize_yaml("""
    foo: "ba r"
    """) == {"foo": "ba r"}

# Generated at 2022-06-24 11:12:12.660678
# Unit test for function validate_yaml
def test_validate_yaml(): 
    from typesystem import String
    from typesystem import Object
    from typesystem import ObjectField

    class Address(Object):
        street = String()
        zip = String()
        city = String()

    class Person(Object):
        name = String()
        age = String()
        address = ObjectField(Address)

    errors = validate_yaml(content = """name: Manuel
age: 49

""", validator=Person)
    assert(errors[0]['text'] == 'Missing field "address".')    


# Generated at 2022-06-24 11:12:21.693021
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    def assert_is_token(yaml_source: str, expected_token: Token) -> None:
        actual_token = tokenize_yaml(yaml_source)
        assert actual_token == expected_token

    assert_is_token(
        """
{
    "a": ["b", "c"]
}
""",
        DictToken(
            {"a": ListToken(["b", "c"], 9, 21, content="    \"a\": [\"b\", \"c\"]\n")},
            0,
            26,
            content="\n{\n    \"a\": [\"b\", \"c\"]\n}\n",
        ),
    )


# Generated at 2022-06-24 11:12:25.078749
# Unit test for function validate_yaml
def test_validate_yaml():
    field = typesystem.String(max_length=10)
    (value, messages) = validate_yaml("test\n", validator=field)
    assert value == "test"
    assert len(messages) == 0


# Generated at 2022-06-24 11:12:33.983419
# Unit test for function validate_yaml
def test_validate_yaml():
    from unittest import TestCase, mock
    from typesystem import String, Integer

    class TestSchema(Schema):
        a = String(max_length=1)
        b = Integer()

    # Test that tokenize_yaml returns a correct Token object
    tc1 = TestCase()
    obj1 = tokenize_yaml("{a: str, b: int}")
    tc1.assertEqual(obj1, {'a': 'str', 'b': int})
    
    # Test that validate_yaml returns the correct error message (contains the error code and a short description of the error)
    tc2 = TestCase()
    mock_payload = mock.Mock()
    mock_payload.read.return_value = "{a: str, b: int}"

# Generated at 2022-06-24 11:12:44.942081
# Unit test for function validate_yaml
def test_validate_yaml():
    
    from collections import OrderedDict
    from typesystem.fields import Integer, Number, String
    from typesystem.schemas import Schema, fields
    from typesystem import types

    yaml_doc = """\
    -
        name: John
        age: 25
    -
        age: 25
        name: John
    -
        age: 90
        name: Mary
        lives:
            - New York
            - Seattle
    -
        age: -90
        name: Mary
        lives:
            - New York
            - Seattle
    -
        age: 25
        name: John
        lives:
            - New York
            - SEATTLE
    -
        age: 25
        name: John
        lives:
            - New York
            - Seattle
            - Atlanta
    """
    # want this to work

# Generated at 2022-06-24 11:12:55.531699
# Unit test for function validate_yaml
def test_validate_yaml():
    # Palindrome
    value, errors = validate_yaml(
        b"---\n'Do geese see God?'",
        String(min_length=1, max_length=255)
    )
    assert value == "Do geese see God?"
    assert errors == []

    value, errors = validate_yaml(
        b"---\n!foo",
        String(min_length=1, max_length=255)
    )
    assert value is None
    assert len(errors) == 1
    assert isinstance(errors[0], ParseError)
    assert errors[0].text == "unacceptable character #x21"
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 2


# Generated at 2022-06-24 11:13:05.368042
# Unit test for function validate_yaml
def test_validate_yaml():

    # validation with no errors
    validator = Schema({"name": types.String()})

    value, errors = validate_yaml(
        """\
    name: Jane
    """, validator=validator
    )

    assert errors == []

    # validation with errors
    validator = Schema({"name": types.String()})

    value, errors = validate_yaml(
        """\
    name: Jane, John
    """, validator=validator
    )

    assert len(errors) == 2
    assert errors[0].code == "required_str"
    assert errors[0].position.char_index == 8
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 9
    assert errors[0].text == "Required type: str."

# Generated at 2022-06-24 11:13:16.948776
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert Token  # noqa
    assert DictToken  # noqa
    assert ListToken  # noqa
    assert ScalarToken  # noqa

    assert tokenize_yaml("") is None

    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("foo"), ScalarToken)
    assert isinstance(tokenize_yaml("3"), ScalarToken)
    assert isinstance(tokenize_yaml("3.14"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)


# Generated at 2022-06-24 11:13:24.640875
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_str = '''
    - [1, 2, 3]
    - {a: 1, b: 2, c: 3}
    '''
    token = tokenize_yaml(yaml_str)
    true_token = yaml.load(yaml_str)
    assert token == true_token
    yaml_str2 = '''
    - [1, 2, 3]
    - {a: 1, b: 2, c: 3}
    '''
    token = tokenize_yaml(yaml_str2)
    true_token = yaml.load(yaml_str2)
    assert token == true_token



# Generated at 2022-06-24 11:13:33.938871
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), ListToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("\n{}"), DictToken)
    assert isinstance(tokenize_yaml("{'z': 5}"), DictToken)
    assert isinstance(tokenize_yaml("{'z': 5.00}"), DictToken)
    assert isinstance(tokenize_yaml("{'z': 5.00, 'y': 0}"), DictToken)
    assert isinstance(tokenize_yaml("{'z': 0.00, 'y': 3.0}"), DictToken)

# Generated at 2022-06-24 11:13:39.887639
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert tokenize_yaml("[]").start == 0
    assert tokenize_yaml("[]").end == 1
    assert tokenize_yaml("[]").content == "[]"

    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert tokenize_yaml("{}").start == 0
    assert tokenize_yaml("{}").end == 1
    assert tokenize_yaml("{}").content == "{}"

    assert isinstance(tokenize_yaml("'string'"), ScalarToken)
    assert tokenize_yaml("'string'").start == 0
    assert tokenize_yaml("'string'").end == 8
    assert tokenize_yaml("'string'").content == "'string'"

    assert isinstance

# Generated at 2022-06-24 11:13:52.430283
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("foo: bar")
    assert isinstance(token, DictToken)
    assert isinstance(token.elements[0], ScalarToken)
    assert token.elements[0].value == "foo"
    assert token.elements[0].start == 0
    assert token.elements[0].end == 3
    assert token.elements[0].content == "foo: bar"

    assert isinstance(token.elements[1], ScalarToken)
    assert token.elements[1].value == "bar"
    assert token.elements[1].start == 5
    assert token.elements[1].end == 8
    assert token.elements[1].content == "foo: bar"

    assert token.start == 0
    assert token.end == 8

# Generated at 2022-06-24 11:14:00.291912
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields

    class ExampleSchema(Schema):
        name = fields.String()
        age = fields.Integer()
        weight = fields.Float()
        is_boolean = fields.Boolean()
        is_none = fields.Boolean()

    content = """
    name: abc
    age: 25
    weight: 65.3
    is_boolean: true
    is_none: null
    """
    value, error_messages = validate_yaml(content, ExampleSchema())
    assert value == {
        "name": "abc",
        "age": 25,
        "weight": 65.3,
        "is_boolean": True,
        "is_none": None,
    }
    assert not error_messages


# Generated at 2022-06-24 11:14:06.961536
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        a: 1
        b:
            c: 3
            d: 4
        e: 5""")
    assert isinstance(token, DictToken)
    assert token.value == {
        "a": 1,
        "b": {"c": 3, "d": 4},
        "e": 5,
    }
    assert token.start == 0
    assert token.end == 25
    assert token.content == """
        a: 1
        b:
            c: 3
            d: 4
        e: 5"""

# Generated at 2022-06-24 11:14:19.020901
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "a:\n  b:\n    c:\n      - x\n      - y\n      - z\n  d: 1\n  e:\n   - 'foo'\n   - 'bar'"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

    assert len(token.content) == len(content)
    assert token.content == content

    assert token.mapping["a"].content == "\n  b:\n    c:\n      - x\n      - y\n      - z\n  d: 1\n  e:\n   - 'foo'\n   - 'bar'"
    assert token.mapping["a"].end_index == len(content) - 1
    assert token.mapping["a"].start_index == 0

# Generated at 2022-06-24 11:14:25.342539
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('4', Field(type="integer"))[0] == 4
    assert validate_yaml('value', Field(type="string"))[0] == "value"
    assert validate_yaml('true', Field(type="boolean"))[0] == True
    assert validate_yaml('false', Field(type="boolean"))[0] == False
    assert validate_yaml('null', Field(type="null"))[0] == None

# Type check function validate_yaml

# Generated at 2022-06-24 11:14:33.376873
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('{"k": "v"}') == DictToken({'k': 'v'}, 0, 11, '{"k": "v"}')
    assert tokenize_yaml('[1, 2, 3]') == ListToken([1, 2, 3], 0, 9, '[1, 2, 3]')
    assert tokenize_yaml('"some_value"') == ScalarToken('some_value', 0, 12, '"some_value"')
    assert tokenize_yaml('42') == ScalarToken(42, 0, 2, '42')
    assert tokenize_yaml('4.2') == ScalarToken(4.2, 0, 3, '4.2')
    assert tokenize_yaml('true') == ScalarToken(True, 0, 4, 'true')
    assert tokenize

# Generated at 2022-06-24 11:14:38.853186
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    token = tokenize_yaml("""
        ---
        a: 123
        b:
            - a
            - b
    """)

    assert isinstance(token, DictToken)
    assert token.value == {"a": 123, "b": ["a", "b"]}
    assert token.start == 2
    assert token.end == 31


# Generated at 2022-06-24 11:14:50.006056
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = typesystem.Schema(
        properties={
            "name": typesystem.String(),
            "age": typesystem.Integer(),
            "email": typesystem.String(format="email"),
        }
    )
    data = """name: Steve
age: 10
email: me@you.com
"""
    assert validate_yaml(data, schema) == (
        {
            "name": "Steve",
            "age": 10,
            "email": "me@you.com",
        },
        [],
    )

    # Handle parsing errors
    data = """name: Steve
age: 10
email: me@you."""
    with pytest.raises(ParseError) as exc_info:
        validate_yaml(data, schema)

# Generated at 2022-06-24 11:14:53.780130
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        color: blue
        value: 42
        """)
    assert isinstance(token, DictToken)
    assert token.keys() == ["color", "value"]
    assert token.items() == [("color", "blue"), ("value", 42)]



# Generated at 2022-06-24 11:15:05.455594
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = types.String()

    person_schema = PersonSchema()

    content = """
    ---
    name: Mark
    """
    value, errors = validate_yaml(content, person_schema)
    assert not errors
    assert value == {"name": "Mark"}

    content = """
    ---
    name: "Mark"
    """
    value, errors = validate_yaml(content, person_schema)
    assert not errors
    assert value == {"name": "Mark"}

    content = """
    ---
    name: "Mark
    """
    value, errors = validate_yaml(content, person_schema)
    assert errors
    assert value is None

    content = """
    ---
    name: "Mark"
    """

# Generated at 2022-06-24 11:15:15.857687
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Success cases
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("hello"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml("5"), ScalarToken)
    assert isinstance(tokenize_yaml("5.5"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(
        tokenize_yaml(
            "id: earl"
        ),
        DictToken,
    )

# Generated at 2022-06-24 11:15:21.974795
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
a: 1
b: 2
c: 3
"""
    class MySchema(Schema):
        a = Field(label="a")
        b = Field(label="b")
        c = Field(label="c")
    value, errors = validate_yaml(content, MySchema)
    assert value == {"a":1,"b":2,"c":3}

# Generated at 2022-06-24 11:15:33.352579
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String, dict_field, list_field
    from tests.base import simple_schema

    content = """
    name: Russell
    age: 38
    """

    value, errors = validate_yaml(content, simple_schema)
    assert value == {"name": "Russell", "age": 38}
    assert not errors

    # Bad value
    content = """
    name: Russell
    age: thirty-eight
    """

    value, errors = validate_yaml(content, simple_schema)
    assert value == None
    assert errors[0].code == "invalid_type"

    # Bad field name
    content = """
    name: Russell
    age: 38
    not-allowed: this is not allowed
    """


# Generated at 2022-06-24 11:15:43.071305
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        foo: bar
        lorem:
          ipsum:
            dolor: sit
            amet:
              consectetur: adipiscing
              elit: |
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.

                Ut enim ad minim veniam, quis nostrud exercitation ullamco
                laboris nisi ut aliquip ex ea commodo consequat.
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

# Generated at 2022-06-24 11:15:49.311835
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Array, Integer

    class Article(Schema):
        title = String(min_length=10, max_length=20)
        tags = Array(items=String(), min_items=1, max_items=10)

    good_yaml = b"""
    title: Hello, world
    tags: [Some, nice, tags]
    """
    value, errors = validate_yaml(good_yaml, Article)
    assert value == {"title": "Hello, world", "tags": ["Some", "nice", "tags"]}
    assert errors == []

    bad_yaml = b"""
    title: Hello, world
    tags: [Some, nice, tags]
    missing: some_field
    """
    value, errors = validate_yaml

# Generated at 2022-06-24 11:15:58.418422
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('') == None
    assert tokenize_yaml('') != 1
    assert tokenize_yaml('  ') == None
    assert tokenize_yaml('[{}]') == [{}]
    assert tokenize_yaml('[{\n}]') == [{}]
    assert tokenize_yaml('{}') == {}
    assert tokenize_yaml('[{}, \'abcd\', 1]') == [{}, 'abcd', 1]
    assert tokenize_yaml('{\'name\': \'John\'}') == {'name': 'John'}


# Generated at 2022-06-24 11:16:05.204858
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer
    from typesystem.schema import Schema

    class PersonSchema(Schema):
        name = Integer()

    content = b"(1, 2)\n"
    assert validate_yaml(content, PersonSchema) == (None, [
        Message(
            text="No Yaml content was specified.",
            code='no_content',
            position=Position(
                line_no=1,
                column_no=1,
                char_index=0,
            )
        ),
    ])

# Generated at 2022-06-24 11:16:14.492476
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean
    from typing import Dict, List

    # Test data
    content1 = """
    product:
      name: "Coffee"
      price: 3.24
      size: 12
    """
    content2 = """
    -
      name: "Coffee"
      price: 3.24
      size: 12
    """
    content3 = "true"
    content4 = "yes"
    content5 = "3.14"

    # Test fields
    name = String()
    price = Float()
    size = Integer()

    # Test schemas
    class Product(Schema):
        name = name
        price = price
        size = size

    class ProductList(Schema):
        products = Product.list()


    # Test validator
   

# Generated at 2022-06-24 11:16:21.552037
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = fields.String
        email = fields.String
        age = fields.Integer()

    value, error_messages = validate_yaml(
        """
        name: "Sean"
        email:
        age: 25
        """,
        MySchema
    )

    assert error_messages == [
        Message(
            errors={'email': ['This field is required.']},
            position=Position(char_index=32, column_no=5, line_no=4),
        )
    ]

# Generated at 2022-06-24 11:16:26.346592
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo:
      bar: 1
      baz: "quux"
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert len(token) == 1
    assert token[0] == ("foo", DictToken({0: 1, 1: "quux"}, start=6, end=37, content=content))


# Generated at 2022-06-24 11:16:33.843491
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(
        """
dictionary:
  a: 1
  b: 2
  c: 3
dictionary_with_no_values:
  a:
  b:
  c:
  d:
list:
  - 1
  - 2
  - 3
empty_list: []
empty_dict: {}
string: "foo"
boolean: true
integer: 1
float: 1.0
null: null
"""
    )
    assert isinstance(token, DictToken)
    assert token["dictionary"].get("a") == ScalarToken("1", line=3, column=3)



# Generated at 2022-06-24 11:16:44.470568
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = Field(type="string")
        age = Field(type="integer", minimum=0)

    (value, error_messages) = validate_yaml(
        "name: Chris\nage: 42",
        validator=MySchema,
    )
    assert value == {"name": "Chris", "age": 42}, "Should validate input."
    assert not error_messages, "Should not have any errors"

    (value, error_messages) = validate_yaml("name: jimbo\nage: -5", validator=MySchema)
    assert value == None
    assert error_messages[0].position.line_no == 2, "Should be on second line"

# Generated at 2022-06-24 11:16:52.278107
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    - [0, 1, 2]
    - [3, 4, 5]
    - [6, 7, 8]
    """
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)

    content2 = """
    max_rate: 1
    min_rate: 0
    """
    token2 = tokenize_yaml(content2)
    assert isinstance(token2, DictToken)
    assert list(token2.keys()) == ["max_rate", "min_rate"]



# Generated at 2022-06-24 11:17:02.417431
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields
    from typesystem.compatibility import text_type

    class User(Schema):
        name = fields.String(max_length=10)
        age = fields.Integer()

    yaml_content = text_type("name: Jim Bob\nage: 20")

    assert validate_yaml(yaml_content, validator=User) == (
        {"name": "Jim Bob", "age": 20},
        [],
    )

    yaml_content = text_type("name: Jim Bob\nage: this is not an integer")


# Generated at 2022-06-24 11:17:08.457606
# Unit test for function validate_yaml
def test_validate_yaml():
    import json
    import os
    import pytest
    import yaml

    from typesystem.tests.support import UserSchema

    root = os.path.dirname(__file__)
    fixtures_dir = os.path.join(root, "fixtures")
    yaml_path = os.path.join(fixtures_dir, "errors.yaml")
    with open(yaml_path) as f:
        data = yaml.safe_load(f)
    schema = UserSchema()

    for test_case in data:
        content = test_case["content"]
        if not isinstance(content, str):
            # Some test scenarios contain a non-string content value.
            # The logic in this module assumes that content is in fact a
            # string, so we skip these cases here.
            continue

        value,

# Generated at 2022-06-24 11:17:13.455666
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    data = """\
name: Bob
age: 30
"""
    value, errors = validate_yaml(data, Person)
    assert value == {"name": "Bob", "age": 30}
    assert errors == []

    data = """\
name: Bob
age: thirty
"""
    value, errors = validate_yaml(data, Person)
    assert value is None

# Generated at 2022-06-24 11:17:20.704981
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        fruits:
          - apple
          - banana
          - cherry
      """
    validator = Field(type=["string", "null"])
    value, errors = validate_yaml(content, validator)
    assert errors == [
        Message(
            code="typesystem.type_error",
            text="List item must be a string or null.",
            position=Position(
                char_index=12,
                column_no=1,
                line_no=3,
                highlight="- apple\n-   ^\n- banana\n- cherry",
            ),
        )
    ]

    # Test case where the first line includes a byte order mark.
    content = "\ufeff" + content
    value, errors = validate_yaml(content, validator)

# Generated at 2022-06-24 11:17:26.243848
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: 1
    b: 2
    """
    token = tokenize_yaml(content)

    assert token.get_element("a") == 1
    assert token.get_element("b") == 2

    assert token.get_element("c") is None
    assert token.get_element("a", 0) is None


# Generated at 2022-06-24 11:17:36.327158
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # check if the function run without error
    yaml_content = '''
                    ---
                    name: John Doe
                    age: 43
                    children:
                      -
                        name: Alice
                        age: 5
                      -
                        name: Bob
                        age: 8
                    '''
    token = tokenize_yaml(yaml_content)
    assert token is not None
    # check if token is type of DictToken
    assert isinstance(token, DictToken) 
    # check the values of the fields
    assert token.get('name') == 'John Doe'
    assert token.get('age') == 43
    # check if the children is a list
    assert isinstance(token.get('children'), ListToken)
    # check the values of the children

# Generated at 2022-06-24 11:17:41.228333
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("""
            id: 1
            """, 'Integer') == (1, [])
    assert validate_yaml("""
            id: not_int
            """, 'Integer') == (None,[Message({'code': 'invalid_type', 'text': 'value is not an int', 'position': {'line_no': 2, 'column_no': 14, 'char_index': 18}})])

# Generated at 2022-06-24 11:17:51.287503
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('{"a":1, "b":"a"}') == {'a': 1, 'b': 'a'}
    assert tokenize_yaml('[1,2]') == [1,2]
    assert tokenize_yaml('1') == 1
    assert tokenize_yaml('"a"') == 'a'
    assert tokenize_yaml('null') == None
    assert tokenize_yaml('false') == False
    assert tokenize_yaml('true') == True
    assert tokenize_yaml('1.3') == 1.3


# Generated at 2022-06-24 11:17:58.692521
# Unit test for function validate_yaml
def test_validate_yaml():
    content = (
        "languages:\n"
        "  - Python: 3.7\n"
        "  - JavaScript: 'ES2015'\n"
        "  - Elm: '0.19'"
    )
    schema = Schema.from_dict(
        {"languages": {"type": "list", "items": {"type": "dict", "properties": {"key": {"type": "string"}, "value": {"type": "string"}}}}}
    )
    value, error_messages = validate_yaml(content, schema)
    assert not error_messages
    assert value == {"languages": [{"key": "Python", "value": "3.7"}, {"key": "JavaScript", "value": "ES2015"}, {"key": "Elm", "value": "0.19"}]}

# Generated at 2022-06-24 11:18:08.709930
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    try:
        import pytest  # noqa: F401
    except ImportError:  # pragma: no cover
        raise unittest.SkipTest("Pytest not installed.")

    from typesystem import types

    class SimpleSchema(Schema):
        field = types.Integer()

    assert validate_yaml(b"field: value", validator=SimpleSchema) == (
        None,
        [ValidationError(position=Position(line_no=1, column_no=9, char_index=8))],
    )
    assert validate_yaml(b"field: 100", validator=SimpleSchema) == (
        {"field": 100},
        [],
    )
    validator = types.Integer()
    assert validate_yaml

# Generated at 2022-06-24 11:18:17.698431
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Tests for validate_yaml()
    """
    import yaml
    from typesystem.base import Message
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        email = String(required=True)

    content = yaml.dump({"email": "nobody@example.com"})
    value, error_messages = validate_yaml(content, PersonSchema)
    assert error_messages == []
    assert value == {"email": "nobody@example.com"}

    content = yaml.dump({"email": "nobody@example.com", "password": "123456"})
    value, error_messages = validate_yaml(content, PersonSchema)

# Generated at 2022-06-24 11:18:21.525197
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: b
    c: d
    e: 3
    """
    token = tokenize_yaml(content)
    assert token.get_value() == {'a': 'b', 'c': 'd', 'e': 3}


# Generated at 2022-06-24 11:18:27.641243
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Unit test to compare output and expected output of tokenize_yaml
    """
    a = "test1: value1"
    b = "test2: value2"
    c = {'test1': 'value1', 'test2': 'value2'}
    d = tokenize_yaml(a)
    e = tokenize_yaml(b)
    assert d == e == c


# Generated at 2022-06-24 11:18:33.265627
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert type(tokenize_yaml('{"a":1}')) == DictToken
    assert type(tokenize_yaml('["a",1]')) == ListToken
    assert type(tokenize_yaml('1')) == ScalarToken
    try:
        tokenize_yaml(b'{"a":1}')
    except ParseError:
        pass
    else:
        assert False


# Generated at 2022-06-24 11:18:42.674955
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer

    error_messages: typing.List[Message] = []

    # Test the function
    value, error_messages = validate_yaml("7", validator=Integer())
    assert value == 7
    assert error_messages is None

    # Test the function on invalid value
    value, error_messages = validate_yaml("seven", validator=Integer())
    assert value is None
    assert error_messages[0].code == "invalid"
    assert error_messages[0].text == "Must be one of 'int, float'."
    assert error_messages[0].position == Position(
        column_no=1, char_index=0, line_no=1
    )

    # Test the function

# Generated at 2022-06-24 11:18:49.298341
# Unit test for function validate_yaml
def test_validate_yaml():
    s = '''
    -
      key1: [1, 2, 3]
      key2: [{a: 2}, {b: 3}]
    -
      key1: 4
      key2: 'test'
    -
      key1: 5
      key2:
        - [1, 2, {x: [1]}]
        - [2, 3, {y: [2]}]
    '''

    class Schema(typesystem.Schema):
        x = typesystem.Integer(minimum=1)

    class Schema2(typesystem.Schema):
        y = typesystem.Integer(minimum=1)

    class SubSchema(typesystem.Schema):
        a = typesystem.Integer()
        b = typesystem.Integer()

# Generated at 2022-06-24 11:18:56.974909
# Unit test for function validate_yaml
def test_validate_yaml():
    # Arrange
    content = """
    street: Dolphin Road
    city: London
    """
    validator = Schema(
        {
            "street": Field(str, required=True),
            "city": Field(str, required=True),
        }
    )

    # Action
    value, error_messages = validate_yaml(content, validator)

    # Assert
    assert error_messages is None
    assert value == {
        "street": "Dolphin Road",
        "city": "London",
    }



# Generated at 2022-06-24 11:19:00.194380
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    hello:
      world:
        - hello
        - how
        - are
        - you
    """
    assert isinstance(tokenize_yaml(content), DictToken)


# Generated at 2022-06-24 11:19:01.531314
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml
    """
    #TODO

# Generated at 2022-06-24 11:19:12.436213
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    class CustomSafeLoader(SafeLoader):
        pass

    def construct_mapping(loader: "yaml.Loader", node: "yaml.Node") -> DictToken:
        start = node.start_mark.index
        end = node.end_mark.index
        mapping = loader.construct_mapping(node)
        return DictToken(mapping, start, end - 1, content=str_content)

    def construct_sequence(loader: "yaml.Loader", node: "yaml.Node") -> ListToken:
        start = node.start_mark.index
        end = node.end_mark.index
        value = loader.construct_sequence(node)
        return ListToken(value, start, end - 1, content=str_content)


# Generated at 2022-06-24 11:19:24.202422
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("hello: world") == DictToken({"hello": "world"}, 0, 11, content="hello: world")
    assert tokenize_yaml("{one: two, three: four}") == DictToken({"one": "two", "three": "four"}, 0, 20, content="{one: two, three: four}")
    assert tokenize_yaml("[one, two, three]") == ListToken(["one", "two", "three"], 0, 15, content="[one, two, three]")
    assert tokenize_yaml("100") == ScalarToken(100, 0, 2, content="100")
    assert tokenize_yaml("100.123") == ScalarToken(100.123, 0, 6, content="100.123")

# Generated at 2022-06-24 11:19:34.413093
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test function validate_yaml."""
    # Test validator type check
    with pytest.raises(AssertionError):
        validate_yaml(content='', validator='')

    # Test domain validator
    content = "http://example.com/example.schema"
    validator = fields.String(pattern="^http://example.com/.+$")
    assert validate_yaml(content=content, validator=validator) == (
        content,
        [],
    )

    # Test invalid domain validator
    content = "example.com/example.schema"
    validator = fields.String(pattern="^http://example.com/.+$")

# Generated at 2022-06-24 11:19:42.286232
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    result = validate_yaml("", String())
    assert result == ([], None)
    result = validate_yaml("hello", String())
    assert result == (["hello"], None)
    result = validate_yaml("hello", String(min_length=10))
    assert result == ([], [{
        'code': 'min_length',
        'error': 'Must have at least 10 characters.',
        'position': {
            'column_no': 1,
            'line_no': 1,
            'char_index': 0
        }
    }])
    result = validate_yaml("hello", String(max_length=3))

# Generated at 2022-06-24 11:19:52.739024
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None
    assert yaml.__version__ >= "5.1"
    assert yaml.__version__ < "6"

    token = tokenize_yaml({"key": "value"})
    print(token)
    assert token.start == 0
    assert token.end == 15
    assert token.value == {"key": "value"}

    token = tokenize_yaml(["item"])
    print(token)
    assert token.start == 0
    assert token.end == 6
    assert token.value == ["item"]

    token = tokenize_yaml("value")
    print(token)
    assert token.start == 0
    assert token.end == 5
    assert token.value == "value"

    token = tokenize_yaml("")
    print(token)

# Generated at 2022-06-24 11:20:00.717187
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # setup
    import os.path
    import yaml
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken
    from typesystem.tokenize.positional_validation import validate_with_positions
    from .utils import load_data

    tokens = load_data(
        "typesystem/tests/validation/yaml_tokenized.yml"
    )
    schema = load_data(
        "typesystem/tests/validation/yaml_tokenized_schema.yml"
    )

    token = tokenize_yaml(tokens)
    validator = Schema.from_dict(schema)

    value, error_messages = validate_with_positions(token, validator)

# Generated at 2022-06-24 11:20:11.562251
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, Schema

    class Person(Schema):
        age = Integer()

    value, error_messages = validate_yaml(
        content="""age: 10""", validator=Person)
    assert error_messages == []
    assert value == {"age": 10}

    value, error_messages = validate_yaml(
        content="""age: not an int""", validator=Person)
    assert error_messages == [Message(
        text='Cannot convert "not an int" to Integer.', code="invalid",
        position=Position(column_no=6, line_no=1, char_index=6))]
    assert value == {"age": "not an int"}


# Generated at 2022-06-24 11:20:21.524696
# Unit test for function validate_yaml
def test_validate_yaml():
    from pprint import pprint
    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    from typesystem import validate

    # Test that content is validatable
    class TestSchema(Schema):
        f = Integer()

    assert(isinstance(validate({"f": 1}, TestSchema), TestSchema))
    assert(isinstance(validate_yaml(TestYMLData, TestSchema), typing.Tuple))

    # Test that nested schemas are validatable
    class TestSchema(Schema):
        f = Integer()

    class TestNestedSchema(Schema):
        f = TestSchema()

    assert(isinstance(validate({"f": {"f": 1}}, TestNestedSchema), TestNestedSchema))

# Generated at 2022-06-24 11:20:24.231779
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field.string()
    actual = validate_yaml("test", validator)
    expected = ("test", [])
    assert actual == expected


# Generated at 2022-06-24 11:20:32.632513
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        field = Field(type="string")

    value, errors = validate_yaml(
        "field: Hello world",
        validator=MySchema
    )
    assert value == {"field": "Hello world"}
    assert not errors

    value, errors = validate_yaml(
        "field: Hello world",
        validator=MySchema(required=["field"])
    )
    assert value == {"field": "Hello world"}
    assert not errors

    value, errors = validate_yaml(
        "field: Hello world",
        validator=MySchema(required=["field", "other_field"])
    )
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "required_field"
    assert errors[0].text

# Generated at 2022-06-24 11:20:42.362936
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    - item1
    - item2
    """
    assert tokenize_yaml(content) == ["item1", "item2"]
    assert tokenize_yaml(None) is None
    assert tokenize_yaml(False) is False
    assert tokenize_yaml(True) is True
    assert tokenize_yaml(0) == 0
    assert tokenize_yaml(0.0) == 0.0
    assert tokenize_yaml(0.0j) == 0.0j
    assert tokenize_yaml('') == ''
    assert tokenize_yaml('item') == 'item'
    assert tokenize_yaml('123') == '123'
    assert tokenize_yaml({'item': 'item1'}) == {'item': 'item1'}
    assert token