

# Generated at 2022-06-24 11:10:46.764684
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ScalarToken("", 0, -1)
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1)
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4)
    assert tokenize_yaml("true\n") == ScalarToken(True, 0, 4)
    assert tokenize_yaml("'C:\\test'") == ScalarToken("C:\\test", 0, 8)
    assert tokenize_yaml('"C:\\test"') == ScalarToken("C:\\test", 0, 8)

# Generated at 2022-06-24 11:10:56.168462
# Unit test for function validate_yaml
def test_validate_yaml():
    assert isinstance(validate_yaml("test", "string")[0], str)
    assert all((isinstance(i, Message) for i in validate_yaml("test", "string")[1]))

    assert isinstance(validate_yaml("test", "integer")[0], int)
    assert not validate_yaml("test", "integer")[1]

    assert isinstance(validate_yaml("1", "integer")[0], int)
    assert not validate_yaml("1", "integer")[1]

    assert isinstance(validate_yaml(1, "integer")[0], int)
    assert not validate_yaml(1, "integer")[1]

    assert isinstance(validate_yaml("1.1", "number")[0], float)
    assert not validate_yaml

# Generated at 2022-06-24 11:11:06.422767
# Unit test for function validate_yaml
def test_validate_yaml():
    class MathSchema(Schema):
        num1 = Field(type=int, required=True)
        num2 = Field(type=int, required=True)

    expected_none, expected_errors = validate_yaml(
        '''\
        num1: "hi"
        num2: "ho"
        ''',
        MathSchema,
    )
    assert expected_none is None

# Generated at 2022-06-24 11:11:16.762114
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Dict

    class PostSchema(Schema):
        author = String()
        title = String()
        body = String()
        comments = Integer()

    valid_yaml = """
    author: 'James'
    title: 'The post'
    body: 'A story'
    comments: 2
    """

    invalid_yaml = """
    author: 'James'
    title: 'The post'
    body: 'A story'
    comments: '2'
    """

    value, error_messages = validate_yaml(valid_yaml, PostSchema)

    assert value == {
        'author': 'James',
        'title': 'The post',
        'body': 'A story',
        'comments': 2,
    }


# Generated at 2022-06-24 11:11:19.877483
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('[1,2,3]') == [1,2,3]
    assert tokenize_yaml('[4,5,6]') == [4,5,6]


# Generated at 2022-06-24 11:11:29.424882
# Unit test for function validate_yaml

# Generated at 2022-06-24 11:11:41.059965
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """This function tests the tokenize_yaml function, with different inputs to test the different outputs"""
    assert tokenize_yaml('') == ParseError(text="No content.", code="no_content", position=Position(column_no=1, line_no=1, char_index=0))
    assert tokenize_yaml('test') == ScalarToken(value='test', start=0, end=3, content='test')
    assert tokenize_yaml('[1, 2, 3]') == ListToken(value=[1, 2, 3], start=0, end=8, content='[1, 2, 3]')

# Generated at 2022-06-24 11:11:49.620473
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Dict, Integer, String
    from typesystem.schemas import Schema

    class PetSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=30)
        is_house_trained = Boolean()

    content = u"""
    name: 'Garfield'
    age: 8
    is_house_trained: true
    """

    pet, error_messages = validate_yaml(content=content, validator=PetSchema)
    assert error_messages == []
    assert pet["name"] == "Garfield"
    assert pet["age"] == 8
    assert pet["is_house_trained"] is True

    class PetsSchema(Schema):
        pets = List(items=PetSchema())


# Generated at 2022-06-24 11:12:00.161962
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem import fields, schemas


    class Person(schemas.Schema):
        first_name = fields.String()
        last_name = fields.String()
        age = fields.Integer()


    test_yaml = """
    first_name: Jon
    last_name: 'Snow'
    age: 18
    """
    result = validate_yaml(test_yaml, Person)
    assert result is None

    test_yaml = """
    first_name: Jon
    last_name: 'Snow'
    age: 18
    not_a_property: foo
    """
    result = validate_yaml(test_yaml, Person)

# Generated at 2022-06-24 11:12:08.438157
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=20)
        age = Integer()
        happy = Boolean()


    content = """
    name: Jane Smith
    age: 30
    happy: True
    """
    value, errors = validate_yaml(content, Person)
    assert errors is None
    assert value["name"] == "Jane Smith"
    assert value["age"] == 30
    assert value["happy"]

    class BadPerson(Schema):
        name = String()
        age = String()

    content = """
    name: Jane Smith
    age: 30
    """
    value, errors = validate_yaml(content, BadPerson)
    assert errors is not None
    error = errors[0]
    assert error.type == "type_error"

# Generated at 2022-06-24 11:12:16.968941
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        field1 = Field(type="string")
        field2 = Field(type="string")
        field3 = Field(type="integer")
        field4 = Field(type="string")

    content = """
    field1: hello
    field2: world
    """
    result, errors = validate_yaml(content=content, validator=TestSchema)
    assert result == {"field1": "hello", "field2": "world"}
    assert len(errors) == 1
    assert errors[0].text == "Missing required field 'field3'."

    content = """
    field1: hello
    field2: world
    field3: 6
    """
    result, errors = validate_yaml(content=content, validator=TestSchema)

# Generated at 2022-06-24 11:12:27.112225
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.tokens import DictToken
    from typesystem.tokenize.tokens import ListToken
    from typesystem.tokenize.tokens import ScalarToken
    from typesystem.fields import String, Integer, Float, Boolean, List
    assert isinstance(tokenize_yaml("value: abc"), DictToken)
    assert isinstance(tokenize_yaml("- 123"), ListToken)
    assert isinstance(tokenize_yaml("'string'"), ScalarToken)
    assert isinstance(tokenize_yaml('"string"'), ScalarToken)
    assert isinstance(tokenize_yaml("123"), ScalarToken)
    assert isinstance(tokenize_yaml("123.5"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)


# Generated at 2022-06-24 11:12:35.076164
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test to check if the function validate_yaml works as expected.
    """
    schema_dict = {
        "name": "Person",
        "fields": [
            {"name": "name", "type": "string"},
            {"name": "age", "type": "integer"},
            {"name": "height", "type": "number"},
            {"name": "biography", "type": "string"},
        ],
    }
    test_schema = Schema.from_dict(schema_dict)
    test_content = """name: John
age: 25
height: 1.65
biography: This is an example biography.
"""
    value = validate_yaml(content=test_content, validator=test_schema)
    assert value is not None

# Generated at 2022-06-24 11:12:37.260945
# Unit test for function validate_yaml
def test_validate_yaml():
  assert validate_yaml('', validator=None) == (None, [])

# Generated at 2022-06-24 11:12:41.568614
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    msg: "Foo"
    """

    expected_token = DictToken(
        {"msg": ScalarToken("Foo", 0, 7, content=content)}, 0, 8, content=content
    )

    assert tokenize_yaml(content) == expected_token


# Generated at 2022-06-24 11:12:45.491501
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    name: "abc"
    age: 10
    '''
    class TestSchema(Schema):
        name = String()
        age = Integer()

    value, errors = validate_yaml(content, TestSchema)
    assert value == {'name': 'abc', 'age': 10}
    assert not errors



# Generated at 2022-06-24 11:12:55.959864
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem import Schema
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.tokenize.tokens import ScalarToken, ListToken, DictToken

    class TestSchema(Schema):
        name = String()
        size = Integer()
        price = Float()
        is_available = Boolean()

    assert tokenize_yaml("") is None

    assert tokenize_yaml("name: Test") == DictToken(
        {"name": ScalarToken("Test", start=0, end=10, content="name: Test")},
        start=0,
        end=10,
        content="name: Test",
    )


# Generated at 2022-06-24 11:13:00.244022
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    data_str = '''
    example: 
        - name: "John"
          age: 7
        - name: "Alex"
          age: 12
          gender: "male"
    '''
    token = tokenize_yaml(data_str)
    assert isinstance(token, DictToken)

# Generated at 2022-06-24 11:13:08.852961
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Array, Boolean

    class BooleanArray(Schema):
        array = Array(Boolean())

    content = b"array: [true, false, yes, no, 0, 1, 2, 12.3, {}]"
    value, _ = validate_yaml(content=content, validator=BooleanArray)
    assert value == {
        "array": [True, False, True, False, False, True, True, True, {}]
    }

    content = b"array: true"
    value, _ = validate_yaml(content=content, validator=BooleanArray)
    assert value == {"array": True}

    content = b"array: [true, false, yes, no, 0, 1, 2, 12.3, {}"

# Generated at 2022-06-24 11:13:20.135186
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(b'{}') == DictToken({}, 0, 1, content=b'{}')
    assert tokenize_yaml(b'{"a": 1}') == DictToken({'a': 1}, 0, 6, content=b'{"a": 1}')
    assert tokenize_yaml(b'[]') == ListToken([], 0, 1, content=b'[]')
    assert tokenize_yaml(b'[1]') == ListToken([1], 0, 2, content=b'[1]')
    assert tokenize_yaml(b'"abc"') == ScalarToken('abc', 0, 4, content=b'"abc"')
    assert tokenize_yaml(b'1') == ScalarToken(1, 0, 1, content=b'1')
    assert tokenize

# Generated at 2022-06-24 11:13:30.428816
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class MySchema(Schema):
        number = Field(type="number")

    content = """
    number: 1
    """
    yaml_content = yaml.safe_load(content)
    value, error_list = validate_yaml(content=content, validator=MySchema)
    assert value == yaml_content
    assert not error_list

    content = """
    number: 'a'
    """
    yaml_content = yaml.safe_load(content)
    value, error_list = validate_yaml(content=content, validator=MySchema)
    assert value == yaml_content
    assert len(error_list) == 1
    assert error_list[0].code == "number"
    assert error

# Generated at 2022-06-24 11:13:41.648606
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String

    # Normal cases
    result, errors = validate_yaml("hello", String(max_length=4))
    assert result == 'hello'
    assert errors == []

    result, errors = validate_yaml("'abc'", String(max_length=10, quoted=True))
    assert result == "'abc'"
    assert errors == []

    # Error cases
    result, errors = validate_yaml("c", String(max_length=1))
    assert result is None
    assert len(errors) == 1

    result, errors = validate_yaml("'abc'", String(max_length=1, quoted=True))
    assert result is None
    assert len(errors) == 1

    result, errors = validate_yaml("'abc'", String(max_length=4))
    assert result is None

# Generated at 2022-06-24 11:13:48.106633
# Unit test for function validate_yaml
def test_validate_yaml():
    class Book(Schema):
        title = String(max_length=100, required=True)

    content = """
        title: War and Peace
        author: Leo Tolstoy
    """

    result_token, errors = validate_yaml(content, Book())
    assert result_token == {
        "title": "War and Peace"
    }

# Generated at 2022-06-24 11:13:57.200776
# Unit test for function validate_yaml
def test_validate_yaml():
    class User(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=100)

    content = """
    name: John Doe
    age: 999999999999999999999999999999999999999999999
    """
    value, errors = validate_yaml(content, validator=User)
    assert value == {'name': 'John Doe', 'age': 999999999999999999999999999999999999999999999}
    assert len(errors) == 1
    assert errors[0].text == 'Must be less than or equal to 100.'
    assert errors[0].position == Position(
        line_no=3, column_no=4, char_index=48)

# Generated at 2022-06-24 11:14:02.190499
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") is None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("""
name: Alice
age: 20
""").age == 20

# Generated at 2022-06-24 11:14:09.218640
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        {
          "name": "Lemur",
          "age": 1.5,
          "locations": [
            "Prague",
            "Melbourne"
          ]
        }
    """
    token = tokenize_yaml(content)
    expected_token = DictToken(
        {"name": "Lemur", "age": 1.5, "locations": ["Prague", "Melbourne"]},
        start=13,
        end=139,
        content=content,
    )
    assert token == expected_token

    token = tokenize_yaml("")
    assert token == DictToken(mapping={}, start=0, end=-1, content="")



# Generated at 2022-06-24 11:14:19.735368
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == {}
    assert tokenize_yaml("a:") == {"a": {}}
    assert tokenize_yaml("a: 1") == {"a": 1}
    assert tokenize_yaml("a: 1\nb: 2") == {"a": 1, "b": 2}
    assert tokenize_yaml("a: 1\nb:") == {"a": 1, "b": {}}
    assert tokenize_yaml("a:\n  b: c") == {"a": {"b": "c"}}
    assert tokenize_yaml("a:\n  - b\n  - c") == {"a": ["b", "c"]}



# Generated at 2022-06-24 11:14:27.557144
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(format="name")
        age = Integer(minimum=0)

    content = """
    name: Alice
    age: 25
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "Alice", "age": 25}
    assert error_messages == []

    content = """
    name: Alice
    """
    _, error_messages = validate_yaml(content, Person)
    assert error_messages == [
        Message("This field is required.", type="required", position=Position(2, 16)),
    ]

    content = """
    name: Alice
    age: this-is-not-an-int
    """
    _, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-24 11:14:39.122694
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Unit test for validate_yaml
    """

    with pytest.raises(AssertionError):
        validate_yaml(content=1, validator=1)
    if yaml is None:
        return

    class TestSchema(Schema):
        name = "string"
        email = "string"
        age = "integer"

    valid = TestSchema()
    value = {'name': 'John', 'email': 'john@example.com', 'age': 30}
    content = '''
        name: John
        email: john@example.com
        age: 30
    '''
    assert validate_yaml(content, valid) == (value, None)

    value = "invalid type"

# Generated at 2022-06-24 11:14:46.410088
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
  content = '''
  yaml: [
    "a",
    "b",
    "c"
  ]
  toml: [
    "a",
    "b",
    "c"
  ]
  '''
  token = tokenize_yaml(content)
  assert isinstance(token, DictToken)
  assert token.start_position == Position(line_no=4, column_no=0, char_index=3)
  assert token.end_position == Position(line_no=9, column_no=0, char_index=64)

# Generated at 2022-06-24 11:14:54.068118
# Unit test for function validate_yaml
def test_validate_yaml():
    class PlayerSchema(Schema):
        name = String(maximum_length=30)
        age = Integer(minimum_value=1, maximum_value=99)

    errors = validate_yaml(content="name: Steve", validator=PlayerSchema)
    assert errors == [
        Message(
            text="Missing field",
            code="missing_field",
            validator="PlayerSchema.age",
            position=Position(line_no=1, column_no=1, char_index=0),
        )
    ]


# Generated at 2022-06-24 11:15:05.685132
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem.fields import String, Integer, Boolean
    from typesystem.schemas import Schema

    class Employee(Schema):
        name = String(max_length=10)
        age = Integer(minimum=20)
        active = Boolean(default=False)

    content = "name: John\nage: 25\nactive: Yes"

    (value, error_messages) = validate_yaml(content, validator=Employee)
    assert len(error_messages) == 2
    assert error_messages[0].position.line_no == 3
    assert error_messages[0].position.column_no == 8
    assert error_messages[1].position.line_no == 1
    assert error_messages[1].position

# Generated at 2022-06-24 11:15:13.912962
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    valid_yaml = b"""
        example:
            - one
            - two
            - three
        """
    token = tokenize_yaml(valid_yaml)
    # Test the value of the newly made Token
    assert token.value == {"example": ["one", "two", "three"]}

    invalid_yaml = b"""
        example:
            - one
              two
            - three
        """
    with pytest.raises(ParseError):
        token = tokenize_yaml(invalid_yaml)

# Unit tests for function validate_yaml

# Generated at 2022-06-24 11:15:16.490060
# Unit test for function validate_yaml
def test_validate_yaml():
    # yaml string not provided
    assert validate_yaml(content=None, validator={'n': 'N'}) == ('', {})



# Generated at 2022-06-24 11:15:22.415117
# Unit test for function validate_yaml
def test_validate_yaml():
    invalid_yaml = "nope: yes\n"
    errors = validate_yaml(invalid_yaml, Schema)
    e = errors[0]
    assert e.text == "did not find expected ':'"
    assert e.position.line_no == 1
    assert e.position.column_no == 5
    assert e.code == "parse_error"

# Generated at 2022-06-24 11:15:26.868601
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("a: 1") == {'a': 1}
    assert tokenize_yaml("a: 1\nb: 2\nc: {d: 3}") == {'a': 1, 'b': 2, 'c': {'d': 3}}

# Generated at 2022-06-24 11:15:36.228686
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.validators import (
        Text,
        Integer,
        List,
        Boolean,
        Numeric,
        Dict,
        Choice,
    )

    # Testcase 1 - Valid Content
    content = """
        username: Tom
        age: 30
        address:
            city: London
            state: England
        scores:
            - 95
            - 82
            - 95
        is_member: true
        """

# Generated at 2022-06-24 11:15:39.316004
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"quantity: 10"
    validator = Field(name="quantity", type="integer")

    value = validate_yaml(content, validator)

    assert value == (10, [])

# Generated at 2022-06-24 11:15:41.130386
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("hello\nworld: yes") == {"hello": {"world": "yes"}}


# Generated at 2022-06-24 11:15:50.926197
# Unit test for function validate_yaml
def test_validate_yaml():
    
    class Person(Schema):
        name = String()
        age = Integer()

    class Address(Schema):
        city = String(min_length=2, max_length=20)
        state = String()

    class PersonAddress(Schema):
        person = Person()
        address = Address()

        def clean(self, data):
            self.errors.pop("person.age", None)
            return data

    class OrderSchema(Schema):
        amount = Decimal()
        person = Person()
        addresses = Array(of=Address)
        person_address = PersonAddress()
        shipped_on = Date()


# Generated at 2022-06-24 11:16:02.682104
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("test_string") == ScalarToken("test_string", 0, len("test_string") - 1, content="test_string")
    assert tokenize_yaml("123") == ScalarToken(123, 0, len("123") - 1, content="123")
    assert tokenize_yaml("123.0") == ScalarToken(123.0, 0, len("123.0") - 1, content="123.0")
    assert tokenize_yaml("null") == ScalarToken(None, 0, len("null") - 1, content="null")
    assert tokenize_yaml("true") == ScalarToken(True, 0, len("true") - 1, content="true")

# Generated at 2022-06-24 11:16:12.891677
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: bar
    """
    value, messages = validate_yaml(content, Field(type="string"))
    assert value == "bar"
    assert len(messages) == 0

    content = """
    foo: bar
    baz: quz
    """
    value, messages = validate_yaml(content, Field(type="string"))
    assert value is None
    assert len(messages) == 1
    assert messages[0].code == "invalid_value"

    content = """
    foo:
        bar: baz
        quz:
            - quz
    """
    value, messages = validate_yaml(content, Field(type="string"))
    assert value is None
    assert len(messages) == 1
    assert messages[0].code == "invalid_value"

   

# Generated at 2022-06-24 11:16:21.893204
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test for DictToken
    content = '{"employee": "Tom"}'
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {'employee': 'Tom'}
    assert token.start == 0
    assert token.end == content.__len__() - 1
    # Test for ListToken
    content = "[employee, Tom, who]"
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert token.value == ["employee", "Tom", "who"]
    assert token.start == 0
    assert token.end == content.__len__() - 1
    # Test for ScalarToken
    content = "employee: Tom"
    token = tokenize_yaml(content)

# Generated at 2022-06-24 11:16:28.539143
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):

        key1 = Field(type="integer")
        key2 = Field(type="string")
        key3 = TestSchema()

    validator = TestSchema()

    # Test basic yaml parsing
    content = """
        key1: 1
        key2: "value2"
        key3:
          key1: 2
          key2: value3
        """
    value, messages = validate_yaml(content=content, validator=validator)
    assert isinstance(value, dict)
    assert value["key2"] == "value2"
    assert isinstance(value["key3"], dict)
    assert value["key3"]["key2"] == "value3"

    # Test validation errors

# Generated at 2022-06-24 11:16:36.523513
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        foo: "bar"
        baz:
            - 1
            - 2
            - 3
        """
    token = tokenize_yaml(content)
    assert token
    assert isinstance(token, DictToken)
    assert token.start_index == 2
    assert token.end_index == 44
    assert token.content == content

    assert isinstance(token.data, dict)
    assert token.data["foo"]
    assert token.data["baz"]
    assert isinstance(token.data["foo"], ScalarToken)
    assert isinstance(token.data["baz"], ListToken)

    token = tokenize_yaml("foo: 1")
    assert isinstance(token, DictToken)
    assert isinstance(token.data["foo"], ScalarToken)

# Generated at 2022-06-24 11:16:46.472113
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String
    from typesystem.schemas import Schema

    class Pet(Schema):
        id = Integer()
        name = String(max_length=20)

    content = """
    - id: 123
      name: "Alfred"
    - id: 678
      name: "Hortense"
    """

    errors = validate_yaml(content, validator=Pet)
    assert not errors.is_success

# Generated at 2022-06-24 11:16:55.317009
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml function
    """
    from typesystem.fields import String
    from typesystem import Schema

    class TestSchema(Schema):
        test_string = String(required=True)

    response, error_messages = validate_yaml(
        b"test_string: test", TestSchema
    )
    assert response == {"test_string": "test"}

    response, error_messages = validate_yaml(
        b"test_string: test\n"
        b"test_string: test",
        TestSchema,
    )
    assert isinstance(error_messages[0], ParseError)
    assert error_messages[0].text == "while scanning a simple key"


# Generated at 2022-06-24 11:17:05.439336
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.base import Message
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    yaml_string = """
    name: Jane
    age: 30
    """

    value, errors = validate_yaml(yaml_string, Person)

    assert value.name == "Jane"
    assert value.age == 30
    assert not errors

    yaml_string = """
    name: Jane
    """

    value, errors = validate_yaml(yaml_string, Person)

    assert value.name == "Jane"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 1
   

# Generated at 2022-06-24 11:17:08.270781
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    class CustomSafeLoader(SafeLoader):
        pass
    yaml.load('test', Loader=CustomSafeLoader)


# Generated at 2022-06-24 11:17:17.171373
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.tokens import DictToken, ScalarToken
    from typesystem.tokenize.positional_validation import ValidationError
    from typesystem.base import Message

    token = tokenize_yaml("""
    foo:
        bar: baz
        x: y
    """)
    assert type(token) is DictToken
    assert token.value == {"foo": {"bar": "baz", "x": "y"}}
    assert token.start == 0
    assert token.end == 36

    token = tokenize_yaml('"string"')
    assert type(token) is ScalarToken
    assert token.value == "string"
    assert token.start == 0
    assert token.end == 8

    # Test error handling

# Generated at 2022-06-24 11:17:18.419926
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('') == {}



# Generated at 2022-06-24 11:17:24.042278
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "firstName: John\nlastName: Smith\nisAlive: true\n"
    validator = Schema({"firstName": str, "lastName": str, "isAlive": bool})
    (value, error_messages) = validate_yaml(content, validator)
    assert value == {"firstName": "John", "lastName": "Smith", "isAlive": True}
    assert error_messages == []



# Generated at 2022-06-24 11:17:35.426099
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Case 1: Empty string
    with pytest.raises(ParseError) as error:
        tokenize_yaml("")
    assert error.value.code == "no_content"
    assert str(error.value) == "ParseError at charindex 0: No content."

    # Case 2: Regular string
    every_type = tokenize_yaml(
        textwrap.dedent(
            """
            foo: bar
            bar:
              - 1
              - 1.0
              - true
              - null
              - []
              - {}
            """
        )
    )
    assert every_type.value == {
        "foo": "bar",
        "bar": [1, 1.0, True, None, [], {}],
    }

    # Case 3: String with special characters
    assert tokenize

# Generated at 2022-06-24 11:17:44.748785
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test dictionaries
    test_dict = {}
    assert type(tokenize_yaml(test_dict)) is DictToken
    
    test_dict = {"key":"value"}
    assert type(tokenize_yaml(test_dict)) is DictToken
    
    test_dict = {"key":"value", "key2":"value2"}
    assert type(tokenize_yaml(test_dict)) is DictToken

    # Test lists
    test_list = []
    assert type(tokenize_yaml(test_list)) is ListToken
    
    test_list = [1, 2]
    assert type(tokenize_yaml(test_list)) is ListToken
    
    test_list = [1, "Hello"]
    assert type(tokenize_yaml(test_list)) is ListToken

    # Test

# Generated at 2022-06-24 11:17:53.175431
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_string = """
    -peter:
        name: peter
        age: 12
    -mary:
        name: mary
        age: 15
    """
    class Person(Schema):
        name = str
        age = int
    
    class Group(Schema):
        members = [Person]

    validator = Group()

    (value, errors) = validate_yaml(yaml_string, validator)
    assert value is None
    assert errors.count() == 1
    # print(str(errors)+'\n')

# Generated at 2022-06-24 11:18:00.639803
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    hi:
      what: "what"
      this:
        is:
          test: "test"
          nothing: null
        a:
          nothing: null
        b:
          nothing: null
        c:
          nothing: null
        d:
          nothing: null
    """
    result = tokenize_yaml(content)
    assert result.content == dedent(content)
    assert result["hi"]["what"].content == content


# Generated at 2022-06-24 11:18:10.665064
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, List, String
    value, error_messages = validate_yaml("1234", Integer())
    assert value == 1234
    assert len(error_messages) == 0

    import yaml
    content = yaml.dump("test_string")
    value, error_messages = validate_yaml(content, String())
    assert value == "test_string"
    assert len(error_messages) == 0

    content = yaml.dump([1, 2, 3])
    value, error_messages = validate_yaml(content, List(items=Integer()))
    assert value == [1, 2, 3]
    assert len(error_messages) == 0

    content = yaml.dump("not_an_integer")

# Generated at 2022-06-24 11:18:18.533973
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test function validate_yaml
    """
    name = "Tobin"
    content = "hello: world"
    schema = """
    type: object
    properties:
        hello: {type: string}
    """
    yaml_schema = yaml.load(schema)
    yaml_result = validate_yaml(content=content, validator=yaml_schema)
    assert yaml_result[0] == {"hello": "world"}

    content = "hello: world"
    with pytest.raises(ValidationError):
        result = validate_yaml(content=content, validator="hello")
    with pytest.raises(ValidationError):
        result = validate_yaml(content=name, validator={"type": "integer"})

# Generated at 2022-06-24 11:18:29.095356
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    assert tokenize_yaml("[1, 2, 3]") == ListToken([1, 2, 3], 0, 7)
    assert tokenize_yaml("{\"a\": 3}") == DictToken({"a": 3}, 0, 7)
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0)
    assert tokenize_yaml("1.5") == ScalarToken(1.5, 0, 3)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4)
    assert tokenize_yaml("~") == ScalarToken(None, 0, 0)

    # Test the error cases

# Generated at 2022-06-24 11:18:38.657642
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("[]") == ListToken([], 0, 1)
    assert tokenize_yaml("text") == ScalarToken("text", 0, 3)
    assert tokenize_yaml("123") == ScalarToken(123, 0, 3)
    assert tokenize_yaml("1.45") == ScalarToken(1.45, 0, 4)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4)



# Generated at 2022-06-24 11:18:45.913023
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert tokenize_yaml("") == ScalarToken("", 0, -1)
    assert tokenize_yaml("a") == ScalarToken("a", 0, 1)
    assert tokenize_yaml("2019") == ScalarToken(2019, 0, 3)
    assert tokenize_yaml("20.5") == ScalarToken("20.5", 0, 3)
    assert tokenize_yaml("true") == ScalarToken("true", 0, 3)
    assert tokenize_yaml("- a").value == ["a"]
    assert tokenize_yaml("- a - b\n").value == {"- a": ["- b"]}
    assert tokenize_yaml("a: b").value == {"a": "b"}
    assert token

# Generated at 2022-06-24 11:18:56.874643
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "name"
        fields = ["name"]

    content = "name: John\n"
    value, errors = validate_yaml(content=content, validator=TestSchema)
    assert value == {"name": "John"}
    assert isinstance(errors, list)
    assert not errors

    data = {"name": "John", "age": 35}
    content = yaml.dump(data, default_flow_style=True)
    value, errors = validate_yaml(content=content, validator=TestSchema)
    assert value == {"name": "John"}
    assert isinstance(errors, list)
    assert len(errors) == 1
    assert errors[0].text == "'age' is an unexpected field."
    assert errors[0].position.line_no == 1

# Generated at 2022-06-24 11:19:06.210643
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(validate_yaml(
        b"{ 'a': 1 }",
        Field(required=True, primitive_type=int)
    ), typing.Tuple[int, typing.List[Message]])
    assert isinstance(validate_yaml(
        b"{ 'a': '2' }",
        Field(required=True, primitive_type=int)
    ), typing.Tuple[int, typing.List[Message]])
    assert isinstance(validate_yaml(
        b"{ 'a': 3 }",
        Field(required=True, primitive_type=str)
    ), typing.Tuple[str, typing.List[Message]])

# Generated at 2022-06-24 11:19:15.069793
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """Unit test for function tokenize_yaml"""
    from typesystem.fields import IntegerField
    from typesystem.schemas import Schema
    from typesystem.main import validate

    class Person(Schema):
        name = IntegerField()
        age = IntegerField()

    value, errors = validate_yaml(b"abc", Person)
    assert isinstance(errors, list)
    assert len(errors) == 1
    assert isinstance(errors[0], Message)
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 1
    assert errors[0].position.char_index == 0

    value, errors = validate(b"abc", Person)
    assert isinstance(errors, list)
    assert len(errors) == 1

# Generated at 2022-06-24 11:19:17.916286
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "10"
    validator = typing.List[Field]
    assert validate_yaml(content, validator) == [ParseError]

# Generated at 2022-06-24 11:19:23.205158
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    class TestSchema(Schema):
        name = String()
        age = Integer()

    content = '\n'.join(["name: Test", "age: 10"])

    try:
        value, errors = validate_yaml(content=content, validator=TestSchema)
        assert value == {"name": "Test", "age": 10}
        assert errors == []
    except ParseError:
        assert False, "Should not raise ParseError."
    except ValidationError:
        assert False, "Should not raise ValidationError."

    content = "name: Test\nage: 10\nfoo: bar"

# Generated at 2022-06-24 11:19:33.268204
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class NameSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True, gt=0)

    value, errors = validate_yaml(
        """
        age: 99
        name: John Smith
        """,
        NameSchema,
    )
    assert value == {"age": 99, "name": "John Smith"}
    assert not errors

    value, errors = validate_yaml(
        """
        age: 99
        name: John Smith
        female: True
        """,
        NameSchema,
    )
    assert value == {"age": 99, "name": "John Smith", "female": True}
    assert len(errors) == 1

# Generated at 2022-06-24 11:19:42.450895
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        fields={
            "title": Field(required=True),
            "name": Field(required=True),
            "email": Field(required=True, type="email"),
            "age": Field(required=True, type="integer"),
            "is_active": Field(required="boolean"),
        }
    )

    value, error_messages = validate_yaml(
        content='''
        title: Mr
        name: John Smith
        email: john@example.com
        age: 42
        is_active: yes
        ''',
        validator=schema,
    )


# Generated at 2022-06-24 11:19:52.957835
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("[1]") == ListToken([ScalarToken(1, 1, 1, content="[1]")], 0, 3, content="[1]")
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("{a: 1}") == DictToken({ScalarToken("a", 2, 2, content="{a: 1}"): ScalarToken(1, 5, 5, content="{a: 1}")}, 0, 7, content="{a: 1}")
    assert tokenize_yaml("'test'") == Scalar

# Generated at 2022-06-24 11:19:59.918886
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_str = "foo: 'bar'"
    class SampleSchema(Schema):
        w: int
        y: int

    value, error_messages = validate_yaml(yaml_str, SampleSchema)
    assert value == {"w": None, "y": None}
    assert error_messages == [
        Message(
            text="Extra fields: 'foo'.",
            kind=Message.ERROR,
            position=Position(line_no=1, column_no=1, char_index=0),
            code="extra_fields",
        )
    ]

if __name__ == "__main__":
    test_validate_yaml()

# Generated at 2022-06-24 11:20:06.921825
# Unit test for function validate_yaml
def test_validate_yaml():
    YAML = """
    id: 5
    name: Jon Smith
    email: test@example.com
    """
    class User(Schema):
        id = types.Integer()
        name = types.String()
        email = types.Email()

    result, errors = validate_yaml(YAML, User)

    assert result == {
        "id": 5,
        "name": "Jon Smith",
        "email": "test@example.com",
    }
    assert not errors, errors



# Generated at 2022-06-24 11:20:16.231054
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(b"", Field()) == (None, [])
    assert validate_yaml(b"", Field(required=True)) == (None, ["This field is required."])
    assert validate_yaml(b"1", Field(type="integer")) == (1, [])
    assert validate_yaml(b"1", Field(type="string")) == (None, ["Not a string."])
    assert validate_yaml(b"true", Field(type="boolean")) == (True, [])
    assert validate_yaml(b"1", Field(minimum=2)) == (None, ["Must be at least 2."])
    assert validate_yaml(b"1", Field(maximum=0)) == (None, ["Must be no more than 0."])

# Generated at 2022-06-24 11:20:21.110523
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    content = b''
    validator = typing.Union[Field, typing.Type[Schema]]
    token = tokenize_yaml(content)
    assert(validate_with_positions(token=token, validator=validator) == None)

# Generated at 2022-06-24 11:20:26.617147
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_text = """
    field_1: 123
    field_2: text
    """
    token = tokenize_yaml(yaml_text)
    assert isinstance(token, DictToken)
    assert token.child[0] == 123
    assert token.child[1] == 'text'
    assert token.start == 0
    assert token.end == 55


# Generated at 2022-06-24 11:20:33.553733
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema.from_dict(
        {
            "name": "person",
            "fields": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
                "fav_colours": {"type": "array", "items": {"type": "string"}},
            },
        }
    )
    value, error_messages = validate_yaml(
        b"name: Bob\nage: 28\nfav_colours:\n  - red\n  - blue\n", schema
    )
    assert error_messages == []
    assert value == {
        "fav_colours": ["red", "blue"],
        "age": 28,
        "name": "Bob",
    }

# Generated at 2022-06-24 11:20:42.243111
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert validate_yaml(content="", validator=Schema) == (None, [])
    assert validate_yaml(content="[]", validator=Schema) == (None, [])
    assert validate_yaml(content="42", validator=Schema) == (None, [])
    assert validate_yaml(content="'hello'", validator=Schema) == (None, [])
    assert validate_yaml(content="{}", validator=Schema) == (None, [])
    assert validate_yaml(content="true", validator=Schema) == (None, [])
    assert validate_yaml(content="false", validator=Schema) == (None, [])

