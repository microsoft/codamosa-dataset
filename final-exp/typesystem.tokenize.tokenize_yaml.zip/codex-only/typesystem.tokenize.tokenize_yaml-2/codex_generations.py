

# Generated at 2022-06-24 11:10:39.227563
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    bla:
        a: 1
        b: 2
    """
    result = tokenize_yaml(content)
    assert result.content is not None
    assert result.start == 1
    assert result.end == (len(content) - 1)


# Generated at 2022-06-24 11:10:45.603696
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('{"id":{"name":"John"},"age":35}')
    str(token)
    assert token.token_index(index=1) == (1,1)
    assert token.token_index(index=2) == (1,2)
    assert token.token_index(index=3) == (1,3)
    assert token.token_index(index=4) == (1,4)
    assert token.token_index(index=5) == (1,5)
    assert token.token_index(index=6) == (1,6)
    assert token.token_index(index=7) == (1,7)
    assert token.token_index(index=8) == (1,8)
    assert token.token_index(index=9) == (1,9)


# Generated at 2022-06-24 11:10:55.655882
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(content=b"---\n'foo'\n")
    assert token.content == "'foo'\n"
    assert token.start == 3
    assert token.end == 7

    assert token.as_str() == "foo"
    assert token.as_int() == 0
    assert token.as_float() == 0.0
    assert token.as_bool() is False
    assert token.as_list() == []
    assert token.as_dict() == {}

    expected_position = Position(line_no=1, column_no=5, char_index=5)
    assert token.position == expected_position

    token2 = tokenize_yaml(content='---\n- "foo"\n')
    assert token2.as_list() == ["foo"]

    # Ensure we

# Generated at 2022-06-24 11:11:05.998844
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Basic struct test, with error positions
    assert tokenize_yaml("A: a") == dict(A='a')
    assert tokenize_yaml("A: 1") == dict(A='1')
    assert tokenize_yaml("A: a\nB: b") == dict(A='a', B='b')
    assert tokenize_yaml("- a\n- b") == dict(A='a', B='b')

    # Test for errors, and error positions

# Generated at 2022-06-24 11:11:13.285104
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    yaml = "name: John\nage: 12"
    result = validate_yaml(yaml, validator=PersonSchema)
    assert result.data["name"] == "John"
    assert result.data["age"] == 12

    yaml = "name: John"
    with pytest.raises(ValidationError) as exc:
        validate_yaml(yaml, validator=PersonSchema)
    assert exc.value.message == "Missing required field: 'age'."



# Generated at 2022-06-24 11:11:24.752077
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert (
        tokenize_yaml(b"key: 'value'") == DictToken({"key": "value"}, 0, 13, content=b"key: 'value'")
    )
    assert (
        tokenize_yaml(b"key: 'value'") == DictToken({"key": "value"}, 0, 13, content=b"key: 'value'")
    )
    assert tokenize_yaml(b"key: value") == DictToken({"key": "value"}, 0, 10, content=b"key: value")
    assert tokenize_yaml(b"1") == ScalarToken(1, 0, 1, content=b"1")
    assert tokenize_yaml(b" ") == ScalarToken(None, 0, 1, content=b" ")
    assert tokenize_

# Generated at 2022-06-24 11:11:31.810481
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    hello: world
    test: 1234
    list:
        - foo
        - bar
    null: null
    """

    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert len(token) == 5
    assert token["hello"].value == "world"
    assert token["test"].value == 1234
    assert isinstance(token["list"], ListToken)
    assert token["null"].value is None

    # Test handling of nested scalars.
    content = """
    hello:
        - bar: baz
    """
    token = tokenize_yaml(content)
    assert isinstance(token["hello"], ListToken)
    assert isinstance(token["hello"][0], DictToken)

# Generated at 2022-06-24 11:11:37.649374
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String

    content = """\
    bar: foo
    baz:
      - a
      - b
      - c
    """

    class TestSchema(Schema):
        foo = String()
        bar = String()

    ret, errors = validate_yaml(content=content, validator=TestSchema)
    assert len(errors) == 1
    message = errors[0]
    assert isinstance(message, Message)
    assert message.type == "missing"
    assert message.path == "foo"


# Generated at 2022-06-24 11:11:43.299927
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test empty string.
    with pytest.raises(ParseError) as exc_info:
        tokenize_yaml("")

    assert "No content." == exc_info.value.text

    # Test invalid YAML.
    with pytest.raises(ParseError) as exc_info:
        tokenize_yaml("foo: bar: baz")

    assert "'mapping values are not allowed here'" in exc_info.value.text

    # Test lists.
    assert [1, 2, 3] == tokenize_yaml("[1, 2, 3]")

    # Test dicts.

# Generated at 2022-06-24 11:11:52.212787
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import String
    from django.http import Http404
    from  django.utils.html import strip_tags
    from django.middleware.csrf import get_token
    from django.middleware.csrf import rotate_token
    from django.utils.crypto import get_random_string
    class MyField(Field):
        def check_types(self, value: typing.Any) -> typing.Any:
            return value
    field=MyField(String())
    #testcase1 test valid yaml
    content=b'name: world'
    (value,err_msg)=validate_yaml(content,field)
    assert err_msg==[]
    assert value=={"name":"world"}
    #testcase2 test invalid yaml
    content=b'name: world'
   

# Generated at 2022-06-24 11:12:02.342040
# Unit test for function validate_yaml
def test_validate_yaml():

    def test_validate_yaml_string():

        field = Field(name="test", type="string")
        content = "This is a test."
        value, errors = validate_yaml(content, field)

        assert value == "This is a test."
        assert errors == []

        # Test that an empty string raises an error.
        content = ""
        value, errors = validate_yaml(content, field)
        assert len(errors) == 1
        assert errors[0] == Message(
            text="String value expected.",
            code="invalid",
            position=Position(column_no=1, line_no=1, char_index=0),
        )

    def test_validate_yaml_integer():

        field = Field(name="test", type="integer")
        content = "123"
        value,

# Generated at 2022-06-24 11:12:05.627170
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test valid YAML
    content = yaml.dump({"test": True})
    print("test_tokenize_yaml", content)
    token = tokenize_yaml(content)
    assert token.get("test") == True



# Generated at 2022-06-24 11:12:14.576237
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
  assert tokenize_yaml("- aaa") == ListToken(
    ["aaa"], start=0, stop=4, content="- aaa"
  )

  assert tokenize_yaml("- aaa\n- bbb") == ListToken(
    ["aaa", "bbb"], start=0, stop=9, content="- aaa\n- bbb"
  )

  assert tokenize_yaml("aaa: bbb") == DictToken(
    {"aaa": "bbb"}, start=0, stop=7, content="aaa: bbb"
  )

  assert tokenize_yaml("foo: 1") == DictToken(
    {"foo": 1}, start=0, stop=5, content="foo: 1"
  )


# Generated at 2022-06-24 11:12:20.653051
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class StringField(Field):
        def validate(self, value, **kwargs) -> typing.Any:
            if not isinstance(value, str):
                raise ValidationError("Not a string")
            return value

        def serialize(self, value, **kwargs) -> str:
            return value

    def missing_required_field(error):
        """
        yaml.load converts an empty mapping to None.
        """
        if isinstance(error, ValidationError) and error.code == "required":
            return True
        return False

    class TestSchema(Schema):
        field = StringField(required=True)

    content = b"""
field: some value
"""


# Generated at 2022-06-24 11:12:30.615446
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    content = yaml.dump({"name": "John", "age": "invalid"})
    value, errors = validate_yaml(content, validator=Person)
    assert (
        errors[0]
        == Message(
            text="Enter a whole number.",
            code="not_a_number",
            position=Position(
                char_index=29,  # End index of the invalid value: "invalid".
                line_no=2,
                column_no=11,
                doc_path="age",
            ),
        )
    )

    content = yaml.dump({"name": "John", "age": None})

# Generated at 2022-06-24 11:12:38.373972
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("abc") == "abc"
    assert tokenize_yaml("100") == 100
    assert tokenize_yaml("-100") == -100
    assert tokenize_yaml("1.1") == 1.1
    assert tokenize_yaml("true") is True
    assert tokenize_yaml("false") is False
    assert tokenize_yaml("null") is None

    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_yaml("{x: 100}") == {"x": 100}
    assert tokenize_yaml("{x: 100, y: 200}") == {"x": 100, "y": 200}



# Generated at 2022-06-24 11:12:48.155321
# Unit test for function validate_yaml
def test_validate_yaml():
    from pprint import pprint as pp
    from typesystem import Integer, String

    class MySchema(Schema):
        name = String()
        age = Integer()

    result = validate_yaml(
        content="""
name: Brian
age: 1
""",
        validator=MySchema,
    )
    assert result[0] == {'age': 1, 'name': 'Brian'}
    assert result[1] == []

    result = validate_yaml(
        content="""
name: Brian
age: '1'
""",
        validator=MySchema,
    )
    assert result[0] == {'age': '1', 'name': 'Brian'}
    assert len(result[1]) == 1
    assert result[1][0].code == 'invalid_type'

# Generated at 2022-06-24 11:12:51.202305
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    # This is a comment
    attributes:
        - foo
        - bar
    """

    token = tokenize_yaml(content)
    assert len(token) == 1
    assert token["attributes"].content == "foo\nbar\n"

# Generated at 2022-06-24 11:12:54.136934
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Make sure that parsing an empty string works correctly.
    with pytest.raises(ParseError):
        tokenize_yaml("")



# Generated at 2022-06-24 11:12:58.523797
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_str = """
            - 0.1
            - 0.2
            - 0.3
            - 0.4
            """
    assert tokenize_yaml(yaml_str) == [0.1, 0.2, 0.3, 0.4]


# Generated at 2022-06-24 11:13:07.762492
# Unit test for function validate_yaml
def test_validate_yaml():
    assert isinstance(validate_yaml(5, int), typing.Tuple[int, typing.List[Message[typing.Any]]])
    assert isinstance(validate_yaml(5.5, int), typing.Tuple[int, typing.List[Message[typing.Any]]])
    assert isinstance(validate_yaml(True, int), typing.Tuple[int, typing.List[Message[typing.Any]]])
    assert isinstance(validate_yaml(None, int), typing.Tuple[int, typing.List[Message[typing.Any]]])
    assert isinstance(validate_yaml('"hi"', int), typing.Tuple[int, typing.List[Message[typing.Any]]])

# Generated at 2022-06-24 11:13:13.285840
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(type="string")
    expected = '{"name": ["Must be a string."], "age": ["This field is required."]}'
    content = """
    name: 123
    age: 
    """
    errors, value = validate_yaml(content=content, validator=field)
    errors_compact = json.dumps(errors, sort_keys=True)
    assert errors_compact == expected

# Generated at 2022-06-24 11:13:21.832446
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.strings import MaxLength

    content = '''
    m:
      - 1
      - 2
      - 3
    '''

    validator = String(validators=[MaxLength(max_length=2)])
    value, errors = validate_yaml(content, validator)

    assert errors == [
        ValidationError(
            field_name=["m", 2], field=validator, text="Must have no more than 2 characters."
        )
    ]

    assert value == [
        "1",
        "2",
        "3",
    ]

# Generated at 2022-06-24 11:13:31.080821
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = fields.String()

    def validate_schema(content, validator):
        (value, error_messages) = validate_yaml(content, validator)
        return error_messages

    (valid_yaml_str, _, valid_schema_error_messages) = validate_schema(
        'name: "Sam"' , MySchema
    )
    assert len(valid_schema_error_messages) == 0

    (invalid_yaml_str, _, invalid_schema_error_messages) = validate_schema(
        "name: 'Sam'" , MySchema
    )
    assert len(invalid_schema_error_messages) == 1



# Generated at 2022-06-24 11:13:36.076953
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("a:\n  - b\n  - c") == {"a": ["b", "c"]}
    assert tokenize_yaml("a:") == {"a": None}


# Generated at 2022-06-24 11:13:44.566728
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('''
        fruits:
          - apple
          - banana
          - orange
            - grape
            - cherry
    ''')
    assert type(token) == DictToken
    assert token.get_position(0) == "start"
    assert token.get_position(1) == "fruits"
    assert token.get_position(2) == "fruits"
    assert token.get_position(3) == "fruits"
    assert token.get_position(4) == "fruits"
    assert token.get_position(5) == "fruits"
    assert token.get_position(6) == "fruits"
    assert token.get_position(7) == "end"
    assert token.get_position(8) == "end"
    assert token.get_

# Generated at 2022-06-24 11:13:53.271802
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    - name: "John"
    - name: "Jane"
    - name: 1
    - name:
      status:
    '''

    class UserSchema(Schema):
        name = fields.String()
        status = fields.String(required=False)
    
    value, errors = validate_yaml(content, UserSchema)
    assert len(value) == 3
    assert len(errors) == 1
    error = errors[0]
    assert error.instance == {"name": 1}
    assert error.code == "int_invalid_type"

# Generated at 2022-06-24 11:13:58.068295
# Unit test for function validate_yaml
def test_validate_yaml():
    '''
    Running unit test
    '''
    class SimpleSchema(Schema):
        """
        A schema with a single field.
        """
        field = Field(key="field", description="A simple field.")

    input_ = (
        "field: value\n"
    )

    result = validate_yaml(input_, SimpleSchema)

    assert result == (
        {"field": "value"},
        {"field": []},
    )


# Generated at 2022-06-24 11:14:03.694907
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(name={"type": str, "required": True}, age={"type": int})
    (value, error_message) = validate_yaml(
        """
        name: 'peter'
        """,
        schema,
    )
    assert isinstance(error_message, list)
    assert len(error_message) == 1
    assert error_message[0].text == "'age' is a required field."
    assert error_message[0].position.line_no == 2
    assert error_message[0].position.column_no == 1



# Generated at 2022-06-24 11:14:14.561597
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = fields.String(max_length=10)
        age = fields.Integer(minimum=0, maximum=150)
    errors = validate_yaml(
        content="name: Hello\nage: 20", validator=MySchema
    )
    assert errors == []

    errors = validate_yaml(
        content="name: This is too long\nage: 20", validator=MySchema
    )
    assert errors == [
        Message(
            text="String is too long.",
            code="max_length",
            position=Position(char_index=6, column_no=7, line_no=1),
        )
    ]

    errors = validate_yaml(
        content="name: Hello\nage: -20", validator=MySchema
    )

# Generated at 2022-06-24 11:14:20.803599
# Unit test for function validate_yaml
def test_validate_yaml():

    from typesystem.schemas import Schema

    class UserSchema(Schema):
        userName = Field(str, max_length=50)

    with open("tests/tests/example.yaml") as myfile:
        content=myfile.read()
    result    = validate_yaml(content, UserSchema)
    assert result[1][0].code == 'extra_fields'


# Generated at 2022-06-24 11:14:21.730569
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("2") == 2


# Generated at 2022-06-24 11:14:27.253430
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test the validate_yaml function.
    """
    class TestSchema(Schema):
        name = Str()

    content = r"""
        name: Test
    """

    test_schema = TestSchema()
    value, error_messages = validate_yaml(content, test_schema)
    assert value == {"name": "Test"}
    assert error_messages == []



# Generated at 2022-06-24 11:14:34.649411
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields
    test_schema = Schema(
        {
            "name": fields.String(),
            "age": fields.Integer(validators=[fields.range_validator(minimum=18)]),
        }
    )
    value, errors = validate_yaml(b"name: foo\nage: 17", test_schema)
    assert len(errors) == 1
    assert errors[0] == Message(
        text="Value is outside of range of valid values.",
        code="invalid_range",
        position=Position(line_no=2, column_no=6, char_index=11),
    )
    value, errors = validate_yaml(b"name: foo\nage: 17", test_schema, error_format="text")

# Generated at 2022-06-24 11:14:42.967575
# Unit test for function validate_yaml
def test_validate_yaml():
    r1 = validate_yaml(content='[[1, 2], [4, 5]]', validator=List([List([Int(), Int()])]))
    assert r1[0] == [[1, 2], [4, 5]]
    assert r1[1] == ()
    r2 = validate_yaml(content='[[2, 4], [6, 8]]', validator=List([List([Int(), Int()])]))
    assert r2[0] == [[2, 4], [6, 8]]
    assert r2[1] == ()
    r3 = validate_yaml(content='[[1, 2, 3], [4, 5, 6]]', validator=List([List([Int(), Int()])]))
    assert r3[0] == []

# Generated at 2022-06-24 11:14:53.246087
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    schema = Schema({"message": String()})

    (value, messages) = validate_yaml(b"message: Hello World", schema)
    assert value == {"message": "Hello World"}
    assert not messages

    with pytest.raises(ParseError) as excinfo:
        validate_yaml(b"message: Hello World\nmessag: Hello World", schema)

    assert excinfo.value.code == "parse_error"
    assert excinfo.value.position == Position(2, 1, 35)

    (value, messages) = validate_yaml(b"", schema)
    assert not value
    assert messages == [Message(text="No content.", code="no_content", position=Position(1, 1, 0))]


# Generated at 2022-06-24 11:15:04.730081
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer

    class MySchema(Schema):
        name = String()
        age = Integer()

    errors = validate_yaml(
        content='name: "valid"\nage: "invalid"',
        validator=MySchema,
    )
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)
    assert len(errors[0].messages) == 1
    assert isinstance(errors[0].messages[0], Message)
    assert errors[0].messages[0].position.line_no == 2
    assert errors[0].messages[0].position.column_no == 6
    assert errors[0].messages[0].position.char_index == 17

# Generated at 2022-06-24 11:15:07.138680
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("test") == 'test'


# Generated at 2022-06-24 11:15:16.943141
# Unit test for function validate_yaml
def test_validate_yaml():
    import typing
    import uuid
    content: str = """
    {
      "name": "Lee",
      "age": 27,
      "height": 1.75,
      "email": "",
      "username": "lee",
      "password": "jklasdf0934ui23oi452345",
      "is_admin": true,
      "id": "3e9f1c57-90bc-4e15-9225-43a265c5a0f7"
    } 
    """
    class User(Schema):
        name = fields.String(required=True, max_length=100)
        age = fields.Integer(required=True, minimum=0, maximum=200)
        height = fields.Float(required=True, minimum=0)

# Generated at 2022-06-24 11:15:26.096847
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('{ "a": { "b" : [1, 2]} }')
    assert isinstance(token, DictToken)
    assert len(token.value) == 1

    token = tokenize_yaml('{ "a": { "b" : [1, 2]} }')
    assert isinstance(token, DictToken)
    assert isinstance(token.value['a'], DictToken)
    assert isinstance(token.value['a'].value['b'], ListToken)

    token = tokenize_yaml('[]')
    assert isinstance(token, ListToken)
    assert len(token.value) == 0

    token = tokenize_yaml('["a"]')
    assert isinstance(token, ListToken)
    assert isinstance(token.value[0], ScalarToken)

# Generated at 2022-06-24 11:15:35.913767
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import Position
    from typesystem.tokenize.tokens import ScalarToken

    assert tokenize_yaml(b"") is None
    assert tokenize_yaml(b"# a comment") is None

    # Empty dict
    token = tokenize_yaml(b"{}")
    assert token == {}
    assert token.start == 0
    assert token.end == 1
    assert token.content == "{}"

    # Empty list
    token = tokenize_yaml(b"[]")
    assert token == []
    assert token.start == 0
    assert token.end == 1
    assert token.content == "[]"

    # String value

# Generated at 2022-06-24 11:15:44.513231
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_str = ""
    validator = Field(required=True)
    value, errors = validate_yaml(content=yaml_str, validator=validator)
    assert value is None
    assert len(errors) == 1
    assert errors[0].detail == "No content."
    assert errors[0].code == "no_content"

    yaml_str = "a: 1"
    validator = Field(required=True)
    value, errors = validate_yaml(content=yaml_str, validator=validator)
    assert value == {"a": 1}
    assert len(errors) == 0

    yaml_str = "[1, 2]"
    validator = Field(required=True)
    value, errors = validate_yaml(content=yaml_str, validator=validator)
   

# Generated at 2022-06-24 11:15:50.861801
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(
        tokenize_yaml("[1, 2, 3]"), ListToken)
    assert isinstance(tokenize_yaml("{a: b, c: d}"), DictToken)
    assert isinstance(tokenize_yaml("42"), ScalarToken)
    assert tokenize_yaml("42").value == 42
    assert tokenize_yaml("-42").value == -42
    assert tokenize_yaml("3.14").value == 3.14
    assert tokenize_yaml("0.5").value == 0.5
    assert tokenize_yaml("true").value is True
    assert tokenize_yaml("false").value is False
    assert tokenize_yaml("null").value is None

# Generated at 2022-06-24 11:16:02.636599
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    - dict:
      key: value
    - list:
      - item
    - 123.456
    - "string"
    """
    token = tokenize_yaml(content)
    assert token.__class__.__name__ == "ListToken"
    assert token.start == 0
    assert token.end == 73  # character position after EOL

    dict_token = token[0]
    assert dict_token.__class__.__name__ == "DictToken"
    assert dict_token.start == 8
    assert dict_token.end == 36

    key_token = dict_token["key"]
    assert key_token.__class__.__name__ == "ScalarToken"
    assert key_token.start == 25
    assert key_token.end == 34


# Generated at 2022-06-24 11:16:12.816575
# Unit test for function validate_yaml
def test_validate_yaml():
    class BookSchema(Schema):
        title = Field(format="title")
        year = Field(format="year", title="year of publication")
        due_date = Field(format="date", title="due date", required=False)
        author = Field(format="name")
        category = Field(format="category")

    # Test 1: No errors in input.
    yaml_content = b"""
    title: The Catcher in the Rye
    year: 1951
    author: J. D. Salinger
    category: fiction
    """
    errors = validate_yaml(content=yaml_content, validator=BookSchema)
    assert not errors

    # Test 2: Parse error in input.
    yaml_content = b"""year: 1951
    author: J. D. Salinger
    category: fiction
    """

# Generated at 2022-06-24 11:16:21.516999
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml function for correct error and position messages
    """
    class MySchema(Schema):
        field1 = Integer()
        field2 = String()
        field3 = String(enum=["a", "b"])

    content = """field1: 1
field2: "abc"
field3: c"""
    value, messages = validate_yaml(content, validator=MySchema)
    assert len(messages) == 1
    message = messages[0]
    assert isinstance(message, Message)
    assert message.text == "Must be one of ['a', 'b']."
    assert message.position.line_no == 3
    assert message.position.column_no == 7
    assert message.position.char_index == 29

# Generated at 2022-06-24 11:16:30.639177
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    # Can parse a single value.
    value = tokenize_yaml("value: foo")
    assert value == {"value": "foo"}

    # Can parse a list.
    value = tokenize_yaml("- 1\n- 2\n- 3")
    assert value == [1, 2, 3]

    # Can parse an empty list.
    value = tokenize_yaml("[]")
    assert value == []

    # Can parse a nested list.
    value = tokenize_yaml("- - 1\n  - 2\n  - - 3\n    - 4")
    assert value == [[1, 2, [3, 4]]]

    # Can parse an empty string.
    value = tokenize_yaml("")

# Generated at 2022-06-24 11:16:37.796144
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("""
    a:
        - 1
        - 2
      """) == DictToken({"a": [1, 2]}, 0, 13, content="""
    a:
        - 1
        - 2
      """)
    assert tokenize_yaml("""
    a: 1
    """) == DictToken({"a": 1}, 0, 6, content="""
    a: 1
    """)
    assert tokenize_yaml("""
    - 1
    - 2
    """) == ListToken([1, 2], 0, 10, content="""
    - 1
    - 2
    """)

# Generated at 2022-06-24 11:16:41.876687
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    content = """
        - 1
        - 2
    """
    token = tokenize_yaml(content)
    assert type(token) is ListToken
    assert token.start_index == 0
    assert token.end_index == 16
    assert token.value == [1, 2]

# Generated at 2022-06-24 11:16:49.006577
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        username = StringField(max_length=20),
        password = StringField()
    )
    content = '''
username: this is a text
password: this is a text
'''
    value, error_messages = validate_yaml(content.encode(), schema)
    assert error_messages == [
        {
            'code': 'max_length',
            'message': 'Must be at most 20 characters.',
            'position': Position(
                char_index=10, column_no=11, line_no=2
            )
        },
    ]
    assert value == {'username': 'this is a text', 'password': 'this is a text'}

# Generated at 2022-06-24 11:17:00.510821
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    valid_yaml = '''
    key:
        scalar_value: some string value
        this_is_a_list:
            - "item1"
            - "item2"
            - "item3"
    '''

    invalid_yaml = '''
    key:
        scalar_value: some string value
        this_is_a_list:
            - "item1"
            - "item2"
            - "item3"
    bad indentation

    '''

    # Unit test for a valid YAML string
    tokenize_yaml(valid_yaml)

    # Unit test for an invalid YAML string
    try:
        tokenize_yaml(invalid_yaml)
    except ParseError as err:
        print("Parse error: " + err.text)



# Generated at 2022-06-24 11:17:06.619061
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml

    :return:
    """
    input_ = {
        "items": [
            {"name": "item1", "price_per_item": "1"},
            {"name": "item2", "price_per_item": "2"},
        ]
    }

    yaml_string = yaml.dump(input_)

    # Test with a schema
    class PurchaseOrderSchema(Schema):
        items = typesystem.List(
            typesystem.Array(
                typesystem.Object(
                    properties={
                        "name": typesystem.String(),
                        "price_per_item": typesystem.Float(),
                    }
                )
            )
        )

    value, error_messages = validate_yaml(yaml_string, PurchaseOrderSchema)

    assert value == input

# Generated at 2022-06-24 11:17:16.496855
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(key="first_name", type="string")
    # Test valid case
    response = validate_yaml(content='"Justin"', validator=field)
    assert response[0] == "Justin"

    # Test invalid case
    response = validate_yaml(content='"Justin', validator=field)
    assert response[0] is None
    assert isinstance(response[1], ValidationError)
    assert response[1].errors[0].position.line_no == 1
    assert response[1].errors[0].position.column_no == 8
    assert response[1].errors[0].position.char_index == 7
    assert isinstance(response[1].errors[0], Message)
    assert response[1].errors[0].text == "Invalid YAML value."

# Generated at 2022-06-24 11:17:25.532251
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    def validate(content: str, validator: Field) -> typing.Tuple[typing.Any, typing.List[Message]]:
        token = tokenize_yaml(content)
        return validate_with_positions(token=token, validator=validator)

    assert (
        validate("{}", String(name="foo")) == (
            {},
            [
                ValidationError(
                    text="Missing 'foo' data.",
                    code="missing_field",
                    position=Position(line_no=1, column_no=2, char_index=1),
                )
            ],
        )
    )


# Generated at 2022-06-24 11:17:30.230899
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""
    {
        "foo": "Hello",
        "bar": 123
    }
    """

    class MySchema(Schema):
        foo = String(max_length=5)
        bar = Integer()

    result = validate_yaml(content, MySchema)
    assert len(result.errors) == 1
    assert result.errors[0].code == "max_length"
    assert result.errors[0].text == "Ensure this value has at most 5 characters (it has 6)."
    assert result.errors[0].position.column_no == 21
    assert result.errors[0].position.line_no == 3
    assert result.errors[0].position.char_index == 57



# Generated at 2022-06-24 11:17:40.728553
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[1, 2, 3]"), ListToken)
    assert isinstance(tokenize_yaml("123"), ScalarToken)

    with pytest.raises(ParseError):
        tokenize_yaml("")

    with pytest.raises(ParseError):
        tokenize_yaml("{")

    with pytest.raises(ParseError):
        tokenize_yaml("- foo: bar")

    # The following cases will successfully parse by are invalid YAML:
    with pytest.raises(ParseError):
        tokenize_yaml("{1: 1}")


# Generated at 2022-06-24 11:17:48.260022
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {
            "foo": Field(number),
            "bar": Field(number),
            "baz": Field(number),
            "qux": Field(number),
            "quux": Field(number),
        }
    )
    value, error_messages = validate_yaml(
        """
    foo: 1
    bar:
        - 1
        - 2
    baz:
        - 1
        - "a"
    qux:
        - 3
        - "f"
        - 9
    quux: 3
    """
        ,
        schema=schema,
    )

# Generated at 2022-06-24 11:17:50.689431
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None
    token = tokenize_yaml("[1, 2]")
    assert token.tokens[0] == 1
    assert token.tokens[1] == 2


# Generated at 2022-06-24 11:17:52.756293
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        test: hello
        test: world
    """)
    assert isinstance(token, DictToken)
    assert token.value == {"test": "world"}


# Generated at 2022-06-24 11:17:59.100025
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    input_string = '''\
    a: b
    c: d'''
    expected_output = DictToken(
        {"a": ScalarToken("b", 0, 0, input_string),
         "c": ScalarToken("d", 0, 0, input_string)},
        0, 0,
        input_string)
    assert tokenize_yaml(input_string) == expected_output

    input_string = '''\
    a: "b"
    c: d'''
    expected_output = DictToken(
        {"a": ScalarToken("b", 0, 0, input_string),
         "c": ScalarToken("d", 0, 0, input_string)},
        0, 0,
        input_string)
    assert tokenize_yaml(input_string) == expected_output

# Generated at 2022-06-24 11:18:08.982550
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Testing the handling of non-string content type
    with pytest.raises(AssertionError):
        tokenize_yaml(b'---\n"hello"'), '"pyyaml" must be installed.'

    # Testing the handling of empty content
    with pytest.raises(ParseError):
        tokenize_yaml('')

    # Testing the handling of a simple string
    assert tokenize_yaml('hello') == 'hello'

    # Testing the handling of a simple list
    token = tokenize_yaml('[a, b, c]')
    assert isinstance(token, ListToken)
    assert token.values == ['a', 'b', 'c']

    # Testing the handling of a simple dictionary
    token = tokenize_yaml('{a: b, c: d}')
    assert isinstance

# Generated at 2022-06-24 11:18:13.965598
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("hello: world") == {'hello': 'world'}
    assert tokenize_yaml("hello: [1, 2]") == {'hello': [1, 2]}
    assert tokenize_yaml("hello:") == {'hello': None}

    with pytest.raises(ParseError):
        tokenize_yaml("")

# Generated at 2022-06-24 11:18:17.943597
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        validate_yaml("", validator=Field(type="string"))
    except (ParseError, ValidationError) as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
    else:  # pragma: no cover
        raise AssertionError("Expected ParseError, but no exception was raised.")

    try:
        validate_yaml("  \n  ", validator=Field(type="string"))
    except (ParseError, ValidationError) as exc:
        assert exc.position.line_no == 2
        assert exc.position.column_no == 2
        assert exc.position.char_index == 4

# Generated at 2022-06-24 11:18:28.659259
# Unit test for function validate_yaml
def test_validate_yaml():

    class SimpleSchema(Schema):
        text = String()
        number = Integer()

    content = "text: hi\nnumber: '10'"
    validator = SimpleSchema()
    errors = validate_yaml(content, validator)
    assert errors == ([], {'text': 'hi', 'number': 10})

    content = "text: hi\nnumber: 'abc'"
    validator = SimpleSchema()
    errors = validate_yaml(content, validator)
    assert errors[0] == Message(
        text="Not a valid integer.",
        code="type_error.integer",
        position=Position(column_no=7, line_no=2, char_index=16),
    )

    content = "text:\n  hi\nnumber: '10'"
    validator = SimpleSchema()


# Generated at 2022-06-24 11:18:38.855355
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        age = Field(type=int)
        name = Field(type=str)
        when = Field.datetime(tzinfo=None, format="%Y-%m-%dT%H:%M:%S.%f")
        is_active = Field(type=bool)
        is_retired = Field(type=bool)
        balance = Field.number()
        email = Field.email()

    data = b"""
        age: 44
        name: Marvin
        when: 2018-09-18T23:55:00.123456
        is_active: true
        is_retired: false
        balance: 10.5
        email: marvin@example.com
    """
    value, messages = validate_yaml(data, Person)

# Generated at 2022-06-24 11:18:46.138535
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test string
    content = """
    users:
      - name: jane doe
        email: jdoe@example.com
      - name: john doe
        email: jdoe@example.com
    """
    tokenize_yaml(content) == yaml.load(content)

    # Test bytes
    content = b"""
    users:
      - name: jane doe
        email: jdoe@example.com
      - name: john doe
        email: jdoe@example.com
    """
    tokenize_yaml(content) == yaml.load(content)

    # Test error
    content = "key value"
    try:
        tokenize_yaml(content)
    except ParseError as e:
        assert e.code == 'parse_error'

# Generated at 2022-06-24 11:18:57.080559
# Unit test for function validate_yaml
def test_validate_yaml():
    # Validate a simple integer
    content = "1234"
    (value, errors) = validate_yaml(content, "integer")
    assert value == 1234
    assert errors == []

    # Validate a yaml document with a simple integer in it
    content = "79\n"
    (value, errors) = validate_yaml(content, "integer")
    assert value == 79
    assert errors == []

    # Validate a yaml document with a simple integer in it, but with a trailing newline
    content = "79\n\n"
    (value, errors) = validate_yaml(content, "integer")
    assert value == 79
    assert errors == []

    # Validate a yaml document with a simple integer in it, but with a trailing space, newline
    content = "79 \n"

# Generated at 2022-06-24 11:19:00.664313
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('[1, 2, 3]')
    assert token.start == 0
    assert token.end == 8
    assert token.value == [1, 2, 3]


# Unit tests for function validate_yaml

# Generated at 2022-06-24 11:19:08.721680
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    from typesystem.errors import ValidationErrors

    errors = ValidationErrors()

    assert isinstance(validate_yaml('hi', Field()), type(None))
    assert isinstance(validate_yaml('hi', String()), str)
    assert isinstance(validate_yaml('hi', String(required=True)), str)

    errors, value = validate_yaml('hi', String(min_length=3))
    assert len(errors) == 1
    assert errors.messages()[0].text == 'Must be at least 3 characters.'

    errors, value = validate_yaml("---\nhi: d", Schema({"hi": String()}))
    assert len(errors) == 0
    assert value == {"hi": "d"}


# Generated at 2022-06-24 11:19:16.445335
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Dict, List, String, Integer
    from typesystem.schemas import Schema


    class TeamSchema(Schema):
        name = String(required=True, min_length=2)
        members = List(String(min_length=2))

    class TeamSchema1(Schema):
        name = String(required=True, min_length=2)
        members = Integer(min_length=2)

    class TeamSchema2(Schema):
        name = String(required=True, min_length=2)


    class BoardSchema(Schema):
        teams = Dict(values=TeamSchema)

    class BoardSchema1(Schema):
        teams = Dict(values=TeamSchema1)

    class BoardSchema2(Schema):
        teams = D

# Generated at 2022-06-24 11:19:26.947619
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        foo = types.Text()
        bar = types.Text()
        baz = types.Number()

    content = textwrap.dedent(
        """
    foo: hello
    bar: world
    baz: 3
    """
    )
    value, messages = validate_yaml(content=content, validator=MySchema)
    assert value == {"foo": "hello", "bar": "world", "baz": 3}
    assert len(messages) == 0
    
    content = textwrap.dedent(
        """
    bar: world
    foo: hello
    baz: a
    """
    )
    value, messages = validate_yaml(content=content, validator=MySchema)

# Generated at 2022-06-24 11:19:36.450859
# Unit test for function validate_yaml
def test_validate_yaml():
    def assert_valid(value):
        messages = validate_yaml(value, validator=TestSchema())
        assert messages == []

    def assert_message(value, code, text, line_no, column_no, char_index):
        messages = validate_yaml(value, validator=TestSchema())
        assert len(messages) == 1
        assert messages[0] == Message(
            code=code,
            text=text,
            position=Position(line_no=line_no, column_no=column_no, char_index=char_index),
        )

    assert_valid("test: abc")
    assert_valid("test: abc\nkey: value")
    assert_valid("test: abc\nkey: value\ntest2: abc")


# Generated at 2022-06-24 11:19:43.645332
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    first_name: Anton
    last_name: Glukhov
    age: 23
    male: true
    pi_value: 3.14
    address:
        city: Simferopol
        street: Malinovskogo
        building: 5
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {
        "first_name": "Anton",
        "last_name": "Glukhov",
        "age": 23,
        "male": True,
        "pi_value": 3.14,
        "address": {
            "city": "Simferopol",
            "street": "Malinovskogo",
            "building": 5,
        }
    }
    assert token.start == 2


# Generated at 2022-06-24 11:19:46.022745
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml('name: Tom'), DictToken)
    assert isinstance(tokenize_yaml('[1, 2]'), ListToken)
    assert isinstance(tokenize_yaml('true'), ScalarToken)



# Generated at 2022-06-24 11:19:55.498600
# Unit test for function validate_yaml
def test_validate_yaml():
    import json

    content = """
    hello: 5
    """
    result = validate_yaml(content, Schema({"hello": int}))
    assert result == ({"hello": 5}, [])

    content = """
    hello: bar
    """
    result = validate_yaml(content, Schema({"hello": int}))
    expected = {
        "messages": [
            {
                "code": "type_error",
                "data": {"type": "int"},
                "text": "Must be of type int.",
                "position": {"column_no": 10, "line_no": 2, "char_index": 10},
            }
        ]
    }

    assert result == (None, expected["messages"])

    content = """
    hello: 5
    """
    messages, value = validate

# Generated at 2022-06-24 11:19:57.720969
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    data = {"a": "a", "b": "b"}
    assert tokenize_yaml(content=yaml.dump(data)) == data



# Generated at 2022-06-24 11:20:04.868577
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        foo = Field(type=str)

    value, errors = validate_yaml(content='{"foo": 123}', validator=TestSchema)
    assert value is None
    assert len(errors) == 1
    assert errors[0] == Message(
        text="Not a valid string.",
        code="type_error.str",
        position=Position(line_no=1, column_no=8, char_index=7),
    )


# Generated at 2022-06-24 11:20:13.704487
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('a: 1') == {'a': 1}
    assert tokenize_yaml('a: "1"') == {'a': '1'}
    assert tokenize_yaml('a: true') == {'a': True}
    assert tokenize_yaml('a: false') == {'a': False}
    assert tokenize_yaml('a: null') == {'a': None}
    assert tokenize_yaml('a: [1, 2, 3]') == {'a': [1, 2, 3]}
    assert tokenize_yaml('a: {b: 1}') == {'a': {'b':1}}



# Generated at 2022-06-24 11:20:23.035800
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Simple test case
    content_1 = '{"name": "John", "age": 30}'
    assert tokenize_yaml(content_1) == {'age': 30, 'name': 'John'}

    # Empty content
    with pytest.raises(ParseError):
        tokenize_yaml('')

    # Empty list
    content_2 = '[]'
    assert tokenize_yaml(content_2) == []

    # Empty map
    content_3 = '{}'
    assert tokenize_yaml(content_3) == {}

    # Tags
    content_4 = "{%YAML 1.2\n---\n!!map {name: John, age: 30}}"

# Generated at 2022-06-24 11:20:28.908574
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test with a nested YAML string
    content = """
    country:
      name: China
      population: 1300
    """

    token = tokenize_yaml(content)

    assert token.children == {
        "country": DictToken(
            {"name": ScalarToken("China"), "population": ScalarToken(1300)},
            1,
            30,
            content,
        )
    }



# Generated at 2022-06-24 11:20:32.966393
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    data = '''
    id: 1
    name: karan
    '''
    tokenized_dict = tokenize_yaml(data)
    assert tokenized_dict == {'id': 1, 'name': 'karan'}
    


# Generated at 2022-06-24 11:20:42.676567
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    class Author(Schema):
        name = Field(str)
        age = Field(int)

    class Book(Schema):
        title = Field(str)
        authors = Field(list, item=Author)

    content = """
    title: A Feast for Crows
    authors:
        - name: George R. R. Martin
          age: 69
        - name: J. R. R. Tolkien
          age: 81
    """