

# Generated at 2022-06-24 11:10:50.059589
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('hi: "there"')
    assert token.start == 0
    assert token.end == 11
    assert token.content == 'hi: "there"'
    assert token.value == {}
    assert token.keys == ['hi']
    assert token.children == [Token(
        start=5,
        value="there",
        end=10,
        content='hi: "there"',
        children=[]
    )]
    assert token.start_position.line_no == 1
    assert token.end_position.line_no == 1



# Generated at 2022-06-24 11:10:56.723130
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_example = """
message:
  hello: world
  python_key: value
  list:
    - one
    - two
    - three

list:
  - 1
  - 2
  - 3
  - 4
  number: 4
  """

    token = tokenize_yaml(yaml_example)
    assert isinstance(token, DictToken), "yaml_example token is a DictToken"

    # test scalar value
    assert token["message"]["hello"] == "world", (
        "yaml_example token[message][hello] is 'world'"
    )

    assert token["message"]["python_key"] == "value", (
        "yaml_example token[message][python_key] is 'value'"
    )


# Generated at 2022-06-24 11:11:01.710717
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = b"""\
foo: bar
baz:
    qux: [1, 2, 3]
"""
    assert tokenize_yaml(content) == {
        "foo": "bar",
        "baz": {"qux": [1, 2, 3]},
    }



# Generated at 2022-06-24 11:11:07.013580
# Unit test for function validate_yaml
def test_validate_yaml():
    if yaml is not None:
        try:
            token = tokenize_yaml("not yaml")
            assert not isinstance(token, Token)
        except ParseError as e:
            assert e.text == "could not find expected ':'."
            assert e.position == Position(column_no=8, line_no=1, char_index=7)
            assert e.code == "parse_error"
        else:
            assert False

# Generated at 2022-06-24 11:11:09.635381
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    content = "name: Kalle"
    expected = {
        'name': 'Kalle'
    }
    assert tokenize_yaml(content) == expected



# Generated at 2022-06-24 11:11:14.068728
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields = {
        'someString' :  Text(max_length=200),
        'someInt' : Integer()
        })
    content = """
    someString: "Some string."
    someInt: 4
    """
    obj = schema.validate(content)
    assert obj['someString'] == "Some string."


# Generated at 2022-06-24 11:11:21.897609
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "foo: bar"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.content == content
    assert token.start_pos == Position(0, 1, 0)
    assert token.end_pos == Position(7, 1, 7)
    assert len(token.mapping) == 1
    assert token.mapping["foo"] == ScalarToken("bar", 4, 1, 4)


# Generated at 2022-06-24 11:11:30.398573
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class SimpleSchema(Schema):
        name = String()

    content = "\n".join(
        [
            "name: dhoer",
            "age: 42",  # <-- age is not part of the schema.
            "height:",  # <-- height should be a number.
            "      5.8"
        ]
    )

    value, errors = validate_yaml(content, SimpleSchema)
    assert isinstance(errors, list)
    assert isinstance(errors[0], ValidationError)

    assert len(errors) == 3

    # The first error is due to the age field.
    assert errors[0].code == "missing_field"
    assert errors[0].position.line_no == 2
   

# Generated at 2022-06-24 11:11:35.832450
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema

    class MySchema(Schema):
        id = int
        name = str

    content = """
    - id: 11
      name: Hello
    - id: 22
      name: World
      """
    value, errors = validate_yaml(content, validator=MySchema)
    assert value == [
        {"id": 11, "name": "Hello"},
        {"id": 22, "name": "World"},
    ]
    assert not errors


# Generated at 2022-06-24 11:11:46.461908
# Unit test for function validate_yaml
def test_validate_yaml():
    with open("backend/tests/fixtures/test.yaml", "r") as stream:
        test_yaml = yaml.load(stream, Loader=yaml.FullLoader)
    assert test_yaml["app_instance"]["app_id"] == "com.example.app"
    assert test_yaml["app_instance"]["version_id"] == 1

    with open("backend/tests/fixtures/validation_error_test.yaml", "r") as stream:
        test_yaml = yaml.load(stream, Loader=yaml.FullLoader)
    assert test_yaml["app_instance"]["app_id"] == "com.example.error"
    assert test_yaml["app_instance"]["version_id"] == "1"


# Generated at 2022-06-24 11:11:50.346291
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_string = """
    title: "Hello, World!"
    """

    token = tokenize_yaml(yaml_string)
    assert token.value == {"title": "Hello, World!"}
    assert token.start == 0
    assert token.end == 26
    assert token.position == (6, 0)


# Generated at 2022-06-24 11:11:54.668906
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - foo
    - bar
    - baz
    """
    validator = ListField(StringField(max_length=3))
    assert validate_yaml(content, validator) == ([b'foo', b'bar', b'baz'], None)



# Generated at 2022-06-24 11:11:59.990432
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema

    class ExampleSchema(Schema):
        name = "string"
        age = "integer"

    content = 'name: "Joe"\nage: 25'
    assert validate_yaml(content, ExampleSchema) == (
        {'name': 'Joe', 'age': 25},
        [],
    )



# Generated at 2022-06-24 11:12:04.107014
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={'foo': Field(required=True)})
    yaml_string = 'foo: bar'
    assert validate_yaml(yaml_string, schema) == ({'foo': 'bar'}, [])

# Generated at 2022-06-24 11:12:10.999535
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test data
    content = """
    # A comment
    type: person
    name: Carl Sagan
    """
    validator = Field(name="name", required=True, type="string")
    expected = ("Carl Sagan", [])
    actual = validate_yaml(content, validator)
    assert actual == expected

    content = "2.0"
    validator = Field(name="field", required=True, type="number")
    expected = (2.0, [])
    actual = validate_yaml(content, validator)
    assert actual == expected

    content = """
    "2002-05-30"
    """
    validator = Field(name="field", required=True, type="date")
    expected = (datetime.date(2002, 5, 30), [])

# Generated at 2022-06-24 11:12:14.789800
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Arrange and Act
    content = "---\n" \
        "key: my_value\n" \
        "...\n"
    token = tokenize_yaml(content)

    # Assert
    assert token.get("key") == "my_value"



# Generated at 2022-06-24 11:12:16.504614
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize import Token

    assert isinstance(tokenize_yaml('{}'), Token)


# Generated at 2022-06-24 11:12:26.455601
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = fields.String(required=True, max_length=100)
        age = fields.Integer(minimum=0, maximum=120)

    content = '{name: "Alice", age: 30}'

    value, error_messages = validate_yaml(content, PersonSchema)
    assert error_messages == []
    assert value == {"name": "Alice", "age": 30}

    content = '{name: "Alice", age: 30'

    value, error_messages = validate_yaml(content, PersonSchema)
    assert error_messages[0].text == "expected '}', but found '<document end>'."
    assert error_messages[0].code == "parse_error"

# Generated at 2022-06-24 11:12:31.832974
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field("value", type=int)
    token = tokenize_yaml("value: abc")
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=validator)
    token = tokenize_yaml("value: 123")
    value = validate_with_positions(token=token, validator=validator)
    assert value == (123, [])

# Generated at 2022-06-24 11:12:37.742098
# Unit test for function validate_yaml
def test_validate_yaml():
    with open("../test_input_data/input.yml", "r") as f:
        content = f.read()
        from typesystem.types import String as tsString
        from typesystem.types import Boolean as tsBool
        from typesystem.types import Object as tsObject
        class InputSchema(Schema):
            name = tsString()
            age = tsString(description='Age of patient in years')
            is_full = tsBool()
        result = validate_yaml(content, InputSchema)
        assert len(result[0]) == 3
        assert len(result[1]) == 0
        assert result[0]['name'] == 'John Doe'
        assert result[0]['age'] == '70'
        assert result[0]['is_full'] == True

# Generated at 2022-06-24 11:12:46.254082
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import types
    from typesystem.types import String

    class PetSchema(Schema):
        name = String(required=True)
        age = types.Integer()
        hungry = types.Boolean(required=True)

    def validate_pet(pet: typing.Dict[str, typing.Any]) -> typing.Tuple[bool, str]:
        value, msgs = validate_yaml(pet, PetSchema)
        if msgs:
            ret = (False, msgs[0].text)
        else:
            ret = (True, value)

        return ret

    pet = """
    name: "Fido"
    age: -12
    hungry: yes
    """

    # Successful validation.

# Generated at 2022-06-24 11:12:51.143686
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    b: 2
    """
    schema = Schema({"a": int, "b": int})
    validated_value, error_messages = validate_yaml(content, schema)
    print(validated_value, error_messages)

# Generated at 2022-06-24 11:12:56.856906
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Unit test for function tokenize_yaml
    """
    token = tokenize_yaml("a: 1\nb:2")
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert isinstance(token.keys, ListToken)
    assert token.keys.value == ["a", "b"]


# Generated at 2022-06-24 11:12:59.710049
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"true"
    validator = Field(type="boolean")

    result = validate_yaml(content, validator)
    assert result == ((True, []))

# Generated at 2022-06-24 11:13:08.536015
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test with a Field
    result, errors = validate_yaml(
        content='- 1\n- 2\n- 3', 
        validator=Field(type='array', items=Field(type='integer')),
    )
    assert errors == []
    assert result == [1, 2, 3]

    # Test with a Schema
    class MySchema(Schema):
        field = Field(type='array', items=Field(type='integer'))
    result, errors = validate_yaml(
        content='field: [1, 2, 3]', 
        validator=MySchema,
    )
    assert errors == []
    assert result == {'field': [1, 2, 3]}

if __name__ == '__main__':
    test_validate_yaml()

# Generated at 2022-06-24 11:13:09.928539
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("""{"a": "b"}""")

# Generated at 2022-06-24 11:13:21.531897
# Unit test for function tokenize_yaml

# Generated at 2022-06-24 11:13:31.123133
# Unit test for function validate_yaml
def test_validate_yaml():
    data = b"""
name: test
extra:
  - first
  - second
  - third
    """
    schema = Schema(fields={"name": fields.String(), "extra": fields.List(fields.String())})
    value, error_messages = validate_yaml(data, schema)
    assert error_messages == []
    assert value == {
        "name": "test",
        "extra": ["first", "second", "third"],
    }

    # Non-string key
    data = b"{1: 2, 3: 4}"
    schema = Schema(fields={"name": fields.String(), "extra": fields.List(fields.String())})
    value, error_messages = validate_yaml(data, schema)
    assert len(error_messages) == 1

# Generated at 2022-06-24 11:13:41.983507
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
                key1: value1
                key2:
                  - value2a
                  - value2b
                key3: value3
              '''
    result = tokenize_yaml(content)
    assert isinstance(result, DictToken)
    assert len(result) == 3
    assert result[0][0] == 'key1'
    assert result[0][1].value == 'value1'
    assert result[1][0] == 'key2'
    assert isinstance(result[1][1], ListToken)
    assert result[1][1][0].value == 'value2a'
    assert result[1][1][1].value == 'value2b'
    assert result[2][0] == 'key3'
    assert result[2][1].value == 'value3'

#

# Generated at 2022-06-24 11:13:54.749599
# Unit test for function validate_yaml
def test_validate_yaml():

    assert _get_position("hi there", 4) == Position(
        line_no=1, column_no=5, char_index=4
    )

    assert _get_position("hi\nthere", 4) == Position(
        line_no=1, column_no=5, char_index=4
    )

    assert _get_position("hi\nthere", 6) == Position(
        line_no=2, column_no=2, char_index=6
    )

    assert validate_yaml("foo: bar", {"foo": str}) == ({
        'foo': 'bar',
    }, None)


# Generated at 2022-06-24 11:14:00.483305
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        field = String(pattern="is this some|kind of|regex??")

    yaml_str = """\
        field: "this is not a regex"
    """

    errors = validate_yaml(yaml_str, TestSchema)["field"]
    assert len(errors) == 1
    assert errors[0].code == "pattern"
    assert errors[0].text == "'this is not a regex' does not match pattern 'is this some|kind of|regex??'."

    yaml_str = """\
        field: "is this some kind of regex?"
    """

    value, errors = validate_yaml(yaml_str, TestSchema)
    assert errors == {}
    assert value == {"field": "is this some kind of regex?"}

# Generated at 2022-06-24 11:14:05.925143
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
a: 1
b:
  - 2
  - 3
c: null
"""
    token = tokenize_yaml(content)
    assert token == DictToken(
        {
            "a": ScalarToken(1, 3, 3, content=content),
            "b": ListToken([ScalarToken(2, 9, 9, content=content), ScalarToken(3, 11, 11, content=content)], 8, 11, content=content),
            "c": ScalarToken(None, 15, 18, content=content),
        },
        0,
        18,
        content=content
    )


# Unit tests for function validate_yaml

# Generated at 2022-06-24 11:14:10.592518
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
    - foo
    - bar
    - baz
    '''
    assert isinstance(tokenize_yaml(content), ListToken)

    content_2 = "{'key': 'value'}"
    assert isinstance(tokenize_yaml(content_2), DictToken)



# Generated at 2022-06-24 11:14:13.788630
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "a: b"
    validator = Field(type="string")

    assert (validate_yaml(content, validator)) == ("b", [])

# Generated at 2022-06-24 11:14:24.234630
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
    name: John Doe
    age: 23
    contact:
      email: john@example.com
      phone: 2347654321
    '''

    expected_token = DictToken(
        value={
            "name": ScalarToken("John Doe", 6, 18, content),
            "age": ScalarToken("23", 27, 30, content),
            "contact": DictToken(
                value={
                    "email": ScalarToken("john@example.com", 35, 51, content),
                    "phone": ScalarToken("2347654321", 56, 68, content),
                },
                start=33,
                end=69,
                content=content,
            ),
        },
        start=3,
        end=72,
        content=content,
    )

    actual_token

# Generated at 2022-06-24 11:14:29.685582
# Unit test for function tokenize_yaml

# Generated at 2022-06-24 11:14:33.413187
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("{}", Schema()) is None, "should return None if no error"
    assert validate_yaml("{", Schema()) is not None, "should return error if invalid"

# Tests for function tokenize_yaml

# Generated at 2022-06-24 11:14:41.565729
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Structure

    _content = """
    text: hello world
    list:
        - 1
        - 2
        - 3
    """
    _schema = Structure(
        {"list": String()},
    )
    value, error_messages = validate_yaml(
        content=_content,
        validator=_schema,
    )
    assert isinstance(value, dict)
    assert len(error_messages) == 1
    error_message = error_messages[0]
    assert isinstance(error_message, Message)
    assert error_message.code == "type_error.string"
    assert error_message.text == "Expected a string."
    assert error_message.position.line_no == 7
    assert error_message.position.column_no == 8
   

# Generated at 2022-06-24 11:14:43.360450
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(content="foo: bar")
    assert token.value == [{"foo": "bar"}]

# Generated at 2022-06-24 11:14:48.901337
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        foo: 1
        bar: 2
    """
    validator = {"foo": int, "bar": int}
    value, error_messages = validate_yaml(content, validator)
    assert value == {'foo': 1, 'bar': 2}
    assert error_messages == []



# Generated at 2022-06-24 11:14:55.473885
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    class AnimalSchema(Schema):
        name = 'text'
        legs = 'integer'
        domesticated = 'boolean'
        items = ['items']
        pets = 'integer'
    document = yaml.load("""\
--- 
name: text
legs: 2
microchip_id: 12345678
items: 
  - food
  - bowl
pets: 
  - cat
  - dog
""")
    errors = validate_yaml(yaml.dump(document), AnimalSchema)
    print(errors)



# Generated at 2022-06-24 11:15:06.556861
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.types import String as StringType
    from typesystem.schemas import Schema as SchemaType

    class MySchema(SchemaType):
        name = String()

    class MySchema2(SchemaType):
        name = String()
        name2 = String()

    content = "name: test\n"
    value, messages = validate_yaml(content, validator=MySchema)
    assert value == {"name": "test"}
    assert messages == []

    content = "name: test\nname2: test\n"
    value, messages = validate_yaml(content, validator=MySchema)
    assert value == {"name": "test"}

# Generated at 2022-06-24 11:15:09.804695
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("[1, 2]")
    assert len(token.items) == 2
    assert token.items[0].value == 1
    assert token.items[1].value == 2

# Generated at 2022-06-24 11:15:18.952510
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema()
    schema.add_field('name',str)
    schema.add_field('age',int)

    # pass
    (value, error_messages) = validate_yaml("name: John\nage: 20",schema)
    assert error_messages == []
    
    # failed name field validation
    (value, error_messages) = validate_yaml("name: John20\nage: 20",schema)
    assert len(error_messages) == 1
    
    # fail age field validation
    (value, error_messages) = validate_yaml("name: John\nage: 20.5",schema)
    assert len(error_messages) == 1
    
    # fail multiple field validation

# Generated at 2022-06-24 11:15:25.559364
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")
    assert tokenize_yaml("foo: bar") == DictToken({"foo": "bar"}, 0, 8, content="foo: bar")
    assert tokenize_yaml("- foo") == ListToken(["foo"], 0, 5, content="- foo")


# Generated at 2022-06-24 11:15:33.197022
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        name: John
        age: 38
        balance: 1234.56
        is_active: true
        role: user
        """
    schema = Schema(
        {
            "name": "string",
            "age": "number",
            "balance": "number",
            "is_active": "boolean",
            "role": "const:user",
        }
    )
    _, error_messages = validate_yaml(content, schema)
    assert not error_messages



# Generated at 2022-06-24 11:15:40.614166
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # an example yaml file
    content = '''
    diet:
      fat: 5
      salt: 1.2
      sugar: 2.4
    '''
    token = tokenize_yaml(content)
    assert token == {
        'diet': {'fat': 5, 'salt': 1.2, 'sugar': 2.4}
    }
    assert repr(token) == repr(
        {'diet': {'fat': 5, 'salt': 1.2, 'sugar': 2.4}}
    )
    print(token)


# Generated at 2022-06-24 11:15:49.457641
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "{'foo': 'bar'}"
    schema = Schema(fields={"foo": "string"})
    value, error_messages = validate_yaml(content, schema)
    assert len(error_messages) == 0
    assert value == {"foo": "bar"}

    content = "{'foo': 'bar'}"
    schema = Schema(fields={"foo": "string", "bar": "string"})
    value, error_messages = validate_yaml(content, schema)
    assert len(error_messages) == 1
    assert type(error_messages[0]) == ValidationError
    assert error_messages[0].field_name == "bar"



# Generated at 2022-06-24 11:16:00.803401
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String, Boolean

    class RootSchema(Schema):
        name = String()
        age = Integer()
        active = Boolean()

    # Valid input
    yaml_str = """
    name: John Doe
    age: 42
    active: false
    """
    value, errors = validate_yaml(yaml_str, RootSchema)

    assert len(errors) == 0
    assert value == {'name': 'John Doe', 'age': 42, 'active': False}

    # Invalid input
    yaml_str = """
    name: John Doe
    age: 42
    active: not a boolean
    """
    value, errors = validate_yaml(yaml_str, RootSchema)

    assert len(errors) == 1

# Generated at 2022-06-24 11:16:05.017356
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: Tim Bosch"
    class Person(Schema):
        name: str
    validator = Person()
    value, errors = validate_yaml(content, validator)
    assert errors == [], "errors must be empty"
    assert value['name'] == "Tim Bosch"
    

# Generated at 2022-06-24 11:16:12.417256
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "{'key': 'value', 'key2': [1, 2, 3]}"

    # Test error handling
    with pytest.raises(ParseError):
        tokenize_yaml(content)

    # Test valid yaml
    content = """
    key: value
    key2:
      - 1
      - 2
      - 3
    """

    token = tokenize_yaml(content)

    assert token == {
        "key": "value" ,
        "key2": [1, 2, 3],
    }


# Generated at 2022-06-24 11:16:22.040897
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foobar: "this is a string"
    a_number: 3
    a_float: 3.14
    a_bool: true
    a_list: [1, 2, 3]
    a_dict:
        foo: bar

    """

    token = tokenize_yaml(content)
    assert token.value == {
        "foobar": "this is a string",
        "a_number": 3,
        "a_float": 3.14,
        "a_bool": True,
        "a_list": [1, 2, 3],
        "a_dict": {"foo": "bar"},
    }



# Generated at 2022-06-24 11:16:31.208817
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.tokens import ListToken, DictToken, ScalarToken

    content = """
    root:
        list:
            - 1
            - 2
            - 3
        dict:
            a: 1
            b: 2
            c: 3
        bool: false
        float: 1.0
        int: 1
        null: null
        str: hello
    """
    root = tokenize_yaml(content)
    assert isinstance(root, DictToken)
    assert root.keys == {"root"}
    assert len(root.value) == 1
    assert "root" in root.value
    root_token = root.value["root"]
    assert isinstance(root_token, DictToken)

# Generated at 2022-06-24 11:16:39.171197
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    content = '''
name: "Alice"
age: 35
'''
    validator = typing.cast(Schema, Schema.of({"name": str, "age": int}))
    (value, error_messages) = validate_yaml(content=content, validator=validator)

    assert value == {"name": "Alice", "age": 35}


# Generated at 2022-06-24 11:16:48.050096
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        fields={
            "name": Field(type="string"),
            "age": Field(type="integer"),
            "occupation": Field(type="string"),
        }
    )

    def _test(content: str, expected: typing.Tuple[typing.Any, typing.List[Message]]):
        value, errors = validate_yaml(content=content, validator=schema)
        assert (value, errors) == expected

    _test(
        """
        name: "Joe Numa"
        age: 44
        occupation: "Engineer"
        """,
        (
            {"name": "Joe Numa", "age": 44, "occupation": "Engineer"},
            [],
        ),
    )


# Generated at 2022-06-24 11:16:59.651468
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = fields.String()
        age = fields.Integer()

    token = tokenize_yaml("""\
name: Jula da Costa
age: 26
""")
    assert isinstance(token, DictToken)
    assert len(token.items) == 2
    assert token.items[0][0] == "name"
    assert token.items[0][1] == "Jula da Costa"
    assert token.items[1][0] == "age"
    assert token.items[1][1] == 26
    value, error_messages = validate_yaml(
        content="""\
name: Jula da Costa
age: 26
""",
        validator=Person,
    )
    assert value == {"name": "Jula da Costa", "age": 26}

# Generated at 2022-06-24 11:17:10.684747
# Unit test for function tokenize_yaml

# Generated at 2022-06-24 11:17:18.700988
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") is None
    assert tokenize_yaml("   \n") is None

    # Scalar values:
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("true") is True
    assert tokenize_yaml("null") is None
    assert tokenize_yaml("test") == "test"
    assert tokenize_yaml('"test"') == "test"

    # Sequence values:
    assert tokenize_yaml("[1, 1]") == [1, 1]
    assert tokenize_yaml("[true, false]") == [True, False]
    assert tokenize_yaml("[null, 1, null]") == [None, 1, None]

# Generated at 2022-06-24 11:17:26.941984
# Unit test for function validate_yaml
def test_validate_yaml():
    class ExampleSchema(Schema):
        foo = fields.String(max_length=10)

    content = "foo: bar"
    value, error_messages = validate_yaml(content, validator=ExampleSchema)
    assert error_messages == []
    assert value == {"foo": "bar"}
    assert value.token.content == content

    content = "foo: bar bar bar"
    _, error_messages = validate_yaml(content, validator=ExampleSchema)
    assert len(error_messages) == 2
    assert error_messages[0].code == "max_length"
    assert error_messages[0].position == Position(
        column_no=10, line_no=1, char_index=9
    )

# Generated at 2022-06-24 11:17:36.866012
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "my_dict:\n  my_key: my_value"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"my_key": "my_value"}
    assert len(token.value) == 1

    content = "my_list:\n  - 1\n  - 2\n  - 3"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"my_list": [1, 2, 3]}
    assert len(token.value) == 1

    content = "123"
    token = tokenize_yaml(content)
    assert isinstance(token, ScalarToken)
    assert token.value == 123

    content = "123.4"
    token

# Generated at 2022-06-24 11:17:45.454867
# Unit test for function validate_yaml
def test_validate_yaml():
    # Define a simple schema to validate against
    class CreditCard(Schema):
        card_type = "string"
        last_four = "string"

    class Person(Schema):
        name = "string"
        age = "integer"
        email = "string"
        credit_card = CreditCard

    valid_content = """
    name: Bob
    age: 42
    email: bob@example.com
    credit_card:
        card_type: visa
        last_four: 1234
    """

    invalid_content = """
    name: 42
    age: Bob
    email: Bob@example.com
    credit_card:
        card_type: hello
        last_four: world
    """


# Generated at 2022-06-24 11:17:46.783633
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == []



# Generated at 2022-06-24 11:17:53.087224
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Test yaml string parsing.

    Examples
    --------
    >>> tokenize_yaml('{"foo": 5}')
    [{'foo': 5}]

    >>> tokenize_yaml('[1, 2, 3]')
    [[1, 2, 3]]

    >>> tokenize_yaml('asdf')
    ['asdf']
    """
    pass


# Generated at 2022-06-24 11:17:57.060760
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    content = '''
    foo:
    - bar
    - bat
    '''
    token = tokenize_yaml(content.encode())
    assert isinstance(token, DictToken)
    assert token.value == {"foo": ["bar", "bat"]}


# Generated at 2022-06-24 11:18:05.916768
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test validate_yaml function."""
    from typesystem.fields import Boolean, Integer, String

    # Test ok
    content = """
    name:
        - test1
        - test2
    """
    expected = ([{"name": "test1"}, {"name": "test2"}], None)
    assert validate_yaml(content, List(String(name="name"))) == expected

    # Test parse error
    content = """
    name:
        - test1
        - test2
    result:
      - test1
    """
    # test exception
    with pytest.raises(ParseError) as excinfo:
        validate_yaml(content, List(String(name="name")))
    expected = "Bad indentation of a mapping entry at line 5, column 7."

# Generated at 2022-06-24 11:18:15.951913
# Unit test for function validate_yaml
def test_validate_yaml():
    test_schema = Schema('test_schema', {
        'id': 'integer',
        'values': ['array', 'string']
    })
    assert not validate_yaml(
        """
        id: 1
        values: [1, 2, 3, 4]
        """,
        test_schema
    )
    assert validate_yaml(
        """
        id: '1'
        values: [1, 2, 3, 4]
        """,
        test_schema
    )
    assert validate_yaml(
        """
        id: '1'
        values: [1, 2, 3, 4]
        """,
        test_schema
    )

# Generated at 2022-06-24 11:18:27.935009
# Unit test for function validate_yaml
def test_validate_yaml():
    import json

    with open("tests/data/pet-list.json") as f:
        data = json.loads(f.read())
    with open("tests/data/pet-list.yaml") as f:
        data_yaml = f.read()

    class Pet(Schema):
        id = Integer()
        name = String()
        age = Integer()

    class PetList(Schema):
        list = List(Pet)

    schema = PetList()
    value, error_messages = validate_yaml(data_yaml, validator=schema)
    assert value == data
    assert error_messages is None

    schema = List(String())
    value, error_messages = validate_yaml(data_yaml, validator=schema)
    assert value == data
    assert error_messages

# Generated at 2022-06-24 11:18:38.215722
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    b: 2
    c: 3
    """
    validator = Schema(
        {"a": int, "b": int, "c": int},
        error_messages={"required": "Field is required."},
    )
    assert validate_yaml(content, validator) == (
        {"a": 1, "b": 2, "c": 3},
        [],
    )

    content = """
    a: 1
    c: 3
    """

# Generated at 2022-06-24 11:18:42.430340
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None
    assert yaml.parser is not None
    content = """
    a: b
    c: d
    """
    token = tokenize_yaml(content)
    assert token.keys == ["a", "c"]
    assert token.get("a") == "b"
    assert token.get("c") == "d"



# Generated at 2022-06-24 11:18:46.093363
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo: 'bar'
    """.strip()

    assert isinstance(tokenize_yaml(content), DictToken), "YAML string should be parsed as a DictToken"
    assert isinstance(tokenize_yaml(content), Token), "YAML string should be parsed as a Token"


# Generated at 2022-06-24 11:18:57.028854
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_string_1 = "hi: hello"
    yaml_string_2 = "hi: [world, world]\n"
    yaml_string_3 = "[{world: world}]"

    token_1 = tokenize_yaml(yaml_string_1)
    token_2 = tokenize_yaml(yaml_string_2)
    token_3 = tokenize_yaml(yaml_string_3)

    assert isinstance(token_1, DictToken)
    assert token_1["hi"] == "hello"
    assert token_1.start_position == 0
    assert token_1.end_position == 7

    assert isinstance(token_2, DictToken)
    assert token_2["hi"] == ["world", "world"]
    assert token_2.start_position == 0

# Generated at 2022-06-24 11:19:06.285440
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str = '''This is a multiline string.
With a second line.'''
    assert tokenize_yaml(str) == 'This is a multiline string.\nWith a second line.'
    assert tokenize_yaml('') == ''
    assert tokenize_yaml('\n') == ''
    assert tokenize_yaml('''\n \t \n''') == ''
    assert tokenize_yaml('a') == 'a'

    assert tokenize_yaml('[1, 2]') == [1, 2]
    assert tokenize_yaml('["a", "b"]') == ["a", "b"]
    assert tokenize_yaml('["a", 2]') == ["a", 2]
    assert tokenize_yaml('[1, "b"]') == [1, "b"]

# Generated at 2022-06-24 11:19:15.129482
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('{"foo": "bar"}') == {"foo": "bar"}
    assert tokenize_yaml('["bar"]') == ["bar"]
    assert tokenize_yaml('123') == 123
    assert tokenize_yaml('123.5') == 123.5
    assert tokenize_yaml('123e-5') == 123e-5
    # True
    assert tokenize_yaml('true') == True
    assert tokenize_yaml('True') == True
    assert tokenize_yaml('TRUE') == True
    # False
    assert tokenize_yaml('false') == False
    assert tokenize_yaml('False') == False
    assert tokenize_yaml('FALSE') == False
    # None
    assert tokenize_yaml('null') == None
    assert tokenize_

# Generated at 2022-06-24 11:19:25.953219
# Unit test for function tokenize_yaml

# Generated at 2022-06-24 11:19:29.362993
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Parse and validate a YAML string, returning positionally marked error
    messages on parse or validation failures.

    Returns a two-tuple of (value, error_messages)
    """
    assert yaml is not None, "'pyyaml' must be installed."



# Generated at 2022-06-24 11:19:33.268624
# Unit test for function validate_yaml
def test_validate_yaml():
    with open("test_data/example1.yaml") as f:
        content = f.read()
        token = tokenize_yaml(content)
        value, _ = validate_with_positions(token=token, validator=Schema)
        assert value["foo"] == [1, "two"]

# Generated at 2022-06-24 11:19:38.012448
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        from typesystem.fields import String
        from typesystem import Schema
    except ImportError:  # pragma: no cover
        return
    class Person(Schema):
        name = String(max_length=10)
    person = Person(validator=String(max_length=10))
    person.validate(validate_yaml(content="""name: Abraham Lincoln""", validator=Person))

# Generated at 2022-06-24 11:19:45.395451
# Unit test for function validate_yaml
def test_validate_yaml():
    # for use in testing
    def load(value):
        if isinstance(value, str):
            return value
        return yaml.dump(value)

    class Person(Schema):
        name = String()
        age = Integer(minimum=0)
        gender = String(enum=["M", "F"])

    person = Person(name="Nicholas", age=11, gender="M")
    yaml_string = load(person)

    # test that a valid yaml string is validated correctly
    value, error_messages = validate_yaml(yaml_string, Person)
    assert value.name == "Nicholas"
    assert error_messages == []

    # test that an invalid yaml string throws the correct error
    yaml_string = "a: b"

# Generated at 2022-06-24 11:19:54.870156
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    input = u'''
    # Comments in YAML should be preserved in typesystem tokens.
    name: "Example"
    # Inline comments should be preserved.
    age: 25
    weight: 80.5
    is_admin: true
    hobbies: [surfing, hiking]
    # Comments should also be preserved with nested objects
    details:
        height: 180
        eye_color: brown
    '''
    assert tokenize_yaml(input) == {
        'name': 'Example',
        'age': 25,
        'weight': 80.5,
        'is_admin': True,
        'hobbies': ['surfing', 'hiking'],
        'details': {
            'height': 180,
            'eye_color': 'brown',
        },
    }

# Unit tests for function validate_y

# Generated at 2022-06-24 11:20:04.733602
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    token = tokenize_yaml("""{
        "a": "asdf",
        "b": {
            "c": "asdf",
            "d": [1, 2, 3],
            "e": [{
                "f": 1
            }]
        },
        "g": [1, 2, 3]
    }""")

    token_schema = Schema(
        {
            "a": Field(type="string"),
            "b": Schema(
                {"c": Field(type="string"), "d": Field(type="array", items=Field(type="integer"))}
            ),
            "g": Field(type="array", items=Field(type="integer")),
        }
    )

    assert validate_with_

# Generated at 2022-06-24 11:20:07.417740
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "test: hello world"
    result = tokenize_yaml(content)
    assert result == {"test": "hello world"}


# Generated at 2022-06-24 11:20:10.990619
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        field0 = Field(type=str)
        field1 = Field(type=str)

    my_schema = MySchema()

    errors = validate_yaml("field0: hi\nfield1: there", my_schema)[1]

    assert errors == []

    errors2 = validate_yaml("field0: hi\nfield1: there", my_schema)[1]

    assert errors2 == []

# Generated at 2022-06-24 11:20:18.766421
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert yaml_invalidate is not None, "'pyyaml' must be installed."

    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=5)

    # Valid input
    content = r"""
    name: Foo
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "Foo"}
    assert len(error_messages) == 0

    # Invalid input
    content = r"""
    name: FooBar
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert len(error_messages) == 1
   

# Generated at 2022-06-24 11:20:25.660215
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = fields.String()
        age = fields.Integer()

    content = "- name: kim\n  age: 32\n- name: jess\n  age: 27"
    errors = validate_json(content, Person.as_list())
    assert not errors, errors

    content = ""
    errors = validate_json(content, Person.as_list())
    assert errors

    content = "hello"
    errors = validate_json(content, Person.as_list())
    assert errors


# Generated at 2022-06-24 11:20:33.417627
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), ListToken)
    with pytest.raises(AssertionError):
        tokenize_yaml(" ")

    assert isinstance(tokenize_yaml("[1, 2]"), ListToken)
    assert isinstance(tokenize_yaml("[1,2]"), ListToken)
    assert isinstance(tokenize_yaml("[1,]"), ListToken)
    assert isinstance(tokenize_yaml("- 1"), ListToken)
    assert isinstance(tokenize_yaml("-1"), ListToken)
    assert isinstance(tokenize_yaml("[1, [2, 3], 4]"), ListToken)
    assert isinstance(tokenize_yaml("[1\n2]"), ListToken)

# Generated at 2022-06-24 11:20:43.083662
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    - foo
    - bar
    """
    tokens = tokenize_yaml(content=content)
    assert tokens == ListToken([ScalarToken("foo", 0, 2, content=content), ScalarToken("bar", 6, 8, content=content)], 0, 10, content=content)
    content = """
    foo:
      bar: baz
    """
    tokens = tokenize_yaml(content=content)
    assert tokens == DictToken({"foo": DictToken({"bar": ScalarToken("baz", 10, 12, content=content)}, 4, 14, content=content)}, 0, 14, content=content)
    content = """
    foo:
      bar:
        - baz
        - qux
    """
    tokens = tokenize_yaml(content=content)