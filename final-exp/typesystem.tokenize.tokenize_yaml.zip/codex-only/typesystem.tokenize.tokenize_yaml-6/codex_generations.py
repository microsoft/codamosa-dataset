

# Generated at 2022-06-24 11:10:49.518715
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("""
    foo:
      - bar
      - baz
    """) == DictToken(
        {"foo": ListToken(["bar", "baz"], 9, 20, content="""
    foo:
      - bar
      - baz
    """)},
        0,
        21,
        content="""
    foo:
      - bar
      - baz
    """,
    )

# Generated at 2022-06-24 11:10:55.905707
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, types
    from typesystem.fields import Dict
    from typesystem.schemas import Schema
    class PetSchema(Schema):
        """
        Schema for Pets
        """
        name = types.String(max_length=32, pattern=r"^[a-zA-Z0-9_-]*$")
        owner = types.String(min_length=8)
        age = types.Integer(minimum=0, maximum=20)
    
    test_pet = """
    name: name
    owner: owner
    age: 6
    """
    print (validate_yaml(content=test_pet, validator=PetSchema))

# Generated at 2022-06-24 11:11:02.824220
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class User(Schema):
        name = String(required=True)
        age = Integer()

    validator = User()

    content = """
    name: Greg
    age: 32
    """

    value, error_messages = validate_yaml(content, validator)

    assert value == {"name": "Greg", "age": 32}
    assert error_messages is None



# Generated at 2022-06-24 11:11:10.017171
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo: bar").mapping == {'foo': 'bar'}
    assert tokenize_yaml("bar").scalar == 'bar'
    assert tokenize_yaml("- bar").list == ['bar']
    assert tokenize_yaml("123").scalar == 123
    assert tokenize_yaml("123.45").scalar == 123.45
    assert tokenize_yaml("true").scalar == True
    assert tokenize_yaml("false").scalar == False
    assert tokenize_yaml("null").scalar == None

    # Make sure that strings are properly tokenized
    assert tokenize_yaml("""
        foo:
            - bar
            - baz
        """).mapping == {'foo': ['bar', 'baz']}

    # Make

# Generated at 2022-06-24 11:11:17.305751
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        fields={"foo": Field(required=True, validators=[MinLength(1), MaxLength(5)])}
    )
    try:
        value, errors = validate_yaml("", schema)
    except ParseError:
        pass
    else:
        assert False, "Expected a ParseError to be raised."
    try:
        value, errors = validate_yaml("'", schema)
    except ParseError:
        pass
    else:
        assert False, "Expected a ParseError to be raised."
    try:
        value, errors = validate_yaml("{}", schema)
    except ParseError:
        pass
    else:
        assert False, "Expected a ParseError to be raised."

# Generated at 2022-06-24 11:11:24.873328
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    # Load the Yaml file to test
    with open("test_yaml_file.yml", "r") as yfile:
        # Set up the validator
        validator = yaml.safe_load(yfile)
        # Load the file to test
        with open("test_content_1.yml", "r") as contentfile:
            content = contentfile.read()
        # Run the function
        value = validate_yaml(content, validator)
        # Check it worked
        assert("version" in value[0])



# Generated at 2022-06-24 11:11:29.266230
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.base import Message
    from typesystem.fields import Field
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken, Token
    from typesystem.tokenize.yaml_tokenize import tokenize_yaml
    from typesystem.tokenize.yaml_tokenize import validate_yaml
    class MySchema(Schema):
        name = Field(required=True, max_length=12)
        age = Field(required=True)

    content = """
    a:
      - b: 1
        c: 2
      - d: 3
        e: 4
    """
    tokens = tokenize_yaml(content)
    result

# Generated at 2022-06-24 11:11:40.836876
# Unit test for function validate_yaml
def test_validate_yaml():

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    # Successful validation
    content = "name: John Doe\nage: 22"
    validated_data, error_messages = validate_yaml(content, validator=Person)

    assert validated_data == {"name": "John Doe", "age": 22}
    assert error_messages == []

    # Key error
    content = "name: John Doe\nheight: 6"
    validated_data, error_messages = validate_yaml(content, validator=Person)

    assert validated_data is None
    assert len(error_messages) == 1
    assert error_messages[0].code == "no_key"
    assert error_messages[0].text == "No key 'age'."
    assert error_mess

# Generated at 2022-06-24 11:11:49.461895
# Unit test for function validate_yaml
def test_validate_yaml():
    class Car(Schema):
        brand = StringField(max_length=200)
        color = StringField()

    class Driver(Schema):
        name = StringField(max_length=200)
        age = IntegerField()
        car = ListField(child=NestedField(Car))

    class Cars(Schema):
        driver = ListField(child=NestedField(Driver))
    
    yaml_cars_str = """
driver:
  - name: John Smith
    age: 35
    car:
      - brand: Buick
        color: Red
  - name: Clare Smith
    age: 32
    car:
      - brand: Tesla
        color: blue
      - brand: Jeep
        color: Red
"""
    _, messages = validate_yaml(yaml_cars_str, Cars)
    print

# Generated at 2022-06-24 11:11:59.946943
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test that a correct string gives a correct result
    content = "1"
    (val, err) = validate_yaml(content, Int(min_value=0, max_value=2))
    assert err == []
    assert val == 1

    # Test that an incorrect string gives an incorrect result
    content = "3"
    (val, err) = validate_yaml(content, Int(min_value=0, max_value=2))
    assert len(err) == 1
    assert isinstance(err[0], ValidationError)
    assert err[0].code == "max_value"
    assert not val

    # Test that a correct list gets parsed correctly
    content = "[1, 2, 3]"
    (val, err) = validate_yaml(content, List(items=Int))
    assert not err
   

# Generated at 2022-06-24 11:12:08.284135
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, DateTime, Date, Integer, Boolean, Float
    from typesystem.schemas import Schema
    from datetime import datetime, date
    class Example(Schema):
        name = String(required=True)
        age = Integer(minimum=1, maximum=150)
        alive = Boolean(required=True)
        weight = Float(minimum=0.0, precision=2)
        birthday = Date()
        last_login = DateTime(required=True)

    content = "---\n"
    content += "name: John\n"
    content += "age: 26\n"
    content += "alive: yes\n"
    content += "weight: 95.32\n"
    content += "birthday: 2020-02-10\n"

# Generated at 2022-06-24 11:12:16.870789
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_str = """
    age: '"bad"'
    name: 
        - Chris
        - John
        - Hanson
    """

    class User(Schema):
        name = fields.String()
        age = fields.Integer()

    value, errors = validate_yaml(yaml_str, validator=User)
    assert value is None
    assert isinstance(errors, list)
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)
    assert errors[0].messages == [
        Message(
            code="invalid_type",
            position=Position(line_no=2, column_no=8, char_index=11),
            text="Value must be of type 'integer'.",
            type="integer",
        )
    ]

# Generated at 2022-06-24 11:12:26.973552
# Unit test for function validate_yaml
def test_validate_yaml():
    field = {
        "id": 1,
        "name": "A green door",
        "price": 12.50,
        "tags": ["home", "green"]
    }
    field_schema = {
        "id": {"type": "integer"},
        "name": {"type": "string"},
        "price": {"type": "number"},
        "tags": {"type": "array", "items": {"type": "string"}}
    }

    field_yml = yaml.dump(field)
    field_yml_schema = yaml.dump(field_schema)

    schema = yaml.load(field_yml_schema, Loader=yaml.FullLoader)

    (field, error) = validate_yaml(field_yml, schema)


# Generated at 2022-06-24 11:12:30.367597
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Array

    from typesystem.types import String

    schema = Array(items=String())
    assert validate_yaml(content='["a"]', validator=schema) == (["a"], None)



# Generated at 2022-06-24 11:12:34.660804
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        first_name = String(max_length=20)
        last_name = String(max_length=20)

    result, error_messages = validate_yaml(
        textwrap.dedent(
            """
    first_name: John
    last_name:
        Doe
    """
        ),
        validator=Person,
    )

    print(result)
    print(error_messages)

# Generated at 2022-06-24 11:12:45.011440
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    result = tokenize_yaml("""
    a: hello
    b: world
    c:
        x: 1
    """)
    assert isinstance(result, DictToken)
    assert len(result.value) == 3

    # Test positional validation
    token = tokenize_yaml("""
    a: hello
    b: world
    c:
        x:
    """)
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == len(token.content) - 1

    assert isinstance(token.value.get("a"), ScalarToken)
    assert token.value.get("a").start == 5
    assert token.value.get("a").end == 9

    assert isinstance(token.value.get("b"), ScalarToken)

# Generated at 2022-06-24 11:12:55.640900
# Unit test for function validate_yaml
def test_validate_yaml():
    from tests.support.typesystem import Integer, Object

    # Case: Parse failures
    try:
        validate_yaml("this is not valid yaml", Integer)
    except ParseError as ex:
        assert ex.position.line_no == 1
        assert ex.position.column_no == 1
    else:
        assert False, "parse error should have been raised"

    # Case: Validation failures
    value, error_messages = validate_yaml(
        """
        - foo
        - bar
        - baz
    """,
        Integer,
    )
    assert len(error_messages) == 3

    error_messages = sorted(error_messages, key=lambda e: e.position.line_no)
    assert error_messages[0].position.line_no == 2
    assert error

# Generated at 2022-06-24 11:13:05.448813
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem.integer import Integer
    from typesystem.schemas import Schema
    from typesystem.string import String

    class User(Schema):
        id = Integer()
        name = String(max_length=50)
        email = String(format="email")

    class UserMessage(Message):
        type: String(format="email")
        user: User

    content = """
            {
             user:
                 id: 1
                 name: jakub
                 email: jakub@example.com
            }
    """

    value, errors = validate_yaml(content, validator=UserMessage)

    assert value.type == "jakub@example.com"
    assert value.user.id == 1
    assert value.user.name == "jakub"
    assert value.user

# Generated at 2022-06-24 11:13:09.312920
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("foo: bar\n")
    assert token.value == {"foo": "bar"}
    assert isinstance(token, DictToken)

if __name__ == "__main__":
    test_tokenize_yaml()

# Generated at 2022-06-24 11:13:19.828592
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        first = Field(str)
        last = Field(str)

    # Firstname, lastname
    data = {'first': "John", 'last': "Doe"}
    person_yaml = yaml.dump(data)

    value, error_messages = validate_yaml(person_yaml, validator=Person)
    assert value == data

    # Firstname, lastname
    data = {'first': "John", 'first': "Doe"}
    person_yaml = yaml.dump(data)

    value, error_messages = validate_yaml(person_yaml, validator=Person)
    assert error_messages[0].text == "Extra content after valid values."

# Generated at 2022-06-24 11:13:26.075293
# Unit test for function tokenize_yaml
def test_tokenize_yaml():   
    from _test.yaml import single_yaml_node_value, single_yaml_node_info
    assert tokenize_yaml(single_yaml_node_value) == single_yaml_node_info

    from _test.yaml import multiple_yaml_nodes_value, multiple_yaml_nodes_info
    assert tokenize_yaml(multiple_yaml_nodes_value) == multiple_yaml_nodes_info

# Generated at 2022-06-24 11:13:34.756611
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("string") == "string"
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("42") == 42
    assert tokenize_yaml("42.0") == 42.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("{a:b}") == {"a": "b"}
    assert tokenize_yaml("{a:{c:d}}") == {"a": {"c": "d"}}
    assert tokenize_yaml("[abc,def]") == ["abc", "def"]
    assert tokenize

# Generated at 2022-06-24 11:13:39.572828
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()

    content = """\
        name: Fred
        age: 42
    """
    result = validate_yaml(content, Person)
    assert result.value == {"name": "Fred", "age": 42}
    assert result.errors == []

# Generated at 2022-06-24 11:13:52.381119
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test yaml string
    yaml_string = """
    username: "JSmith"
    email: "john.smith@email.com"
    password: "password"
    """
    token = tokenize_yaml(yaml_string)
    assert token == {"username": "JSmith", "email": "john.smith@email.com", "password": "password"}

    # Test bytestring
    yaml_bytestring = b"""
    username: "JSmith"
    email: "john.smith@email.com"
    password: "password"
    """
    token = tokenize_yaml(yaml_bytestring)
    assert token == {"username": "JSmith", "email": "john.smith@email.com", "password": "password"}



# Generated at 2022-06-24 11:13:59.696578
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo:
        bar:
            baz: hello
            quux: world
        arr: [1, 2, 3]
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value["foo"]["bar"]["baz"] == "hello"
    assert token.value["foo"]["bar"]["quux"] == "world"
    assert token.value["foo"]["arr"] == [1, 2, 3]

    assert token.value == {
        "foo": {
            "bar": {"baz": "hello", "quux": "world"},
            "arr": [1, 2, 3],
        }
    }

    assert token.content == content

# Generated at 2022-06-24 11:14:08.901529
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import parse_yaml_schema
    from typesystem.types import Integer, String
    from yaml import load as yaml_load
    import os
    import pytest

    schema = parse_yaml_schema(f"""
    id:
        type: integer
    name:
        type: string
    """)

    # Pass case
    content = b"""
    id: 1
    name: Sridhar
    """
    assert schema.validate_yaml(content) == {'id': 1, 'name': 'Sridhar'}

    # Fail case with array of errors
    content = b"""
    id: a
    name: 23
    """
    with pytest.raises(ValidationError) as error:
        schema.validate_yaml(content)

# Generated at 2022-06-24 11:14:20.531869
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.exceptions import ErrorMessage
    from typesystem.tokenize.tokens import DictToken, ScalarToken
    from typesystem.tokenize.positional_validation import get_path_string
    from typesystem.tokenize.positional_validation import validate_with_positions

    class BarSchema(Schema):
        foo = String()

    token = DictToken({"foo": "bar"})
    api_schema = BarSchema()
    value, error_messages = validate_with_positions(token, api_schema)
    assert value == {"foo": "bar"}
    assert error_messages == []

    token = ScalarToken("bar")
    api_schema = BarSchema()


# Generated at 2022-06-24 11:14:27.994040
# Unit test for function validate_yaml
def test_validate_yaml():
    def generate_message_list(result):
        messages = []
        for i in range(len(result[1])):
            messages.append(
                Message(
                    text=result[1][i]["text"],
                    code=result[1][i]["code"],
                    position=result[1][i]["position"],
                )
            )
        return messages
    class Animal(Schema):
        name = String()
        age = Integer()
    class Cat(Schema):
        name = String()
        age = Integer()
        # the definition of `luck_factor` is not required
        luck_factor = Float(required=False)
    result = validate_yaml(content=''' 
        name: cat
        age: 3
    ''', validator=Cat)

# Generated at 2022-06-24 11:14:39.209049
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(b"abc") == ScalarToken(u"abc", 0, 2)
    assert tokenize_yaml(u"abc") == ScalarToken(u"abc", 0, 2)
    assert tokenize_yaml(b" 123 ") == ScalarToken(123, 1, 3)
    assert tokenize_yaml(b" !!int 123 ") == ScalarToken(123, 8, 10)
    assert tokenize_yaml(b" 123.5 ") == ScalarToken(123.5, 1, 5)
    assert tokenize_yaml(b" !!float 123.5 ") == ScalarToken(123.5, 12, 17)
    assert tokenize_yaml(b" 123.0 ") == ScalarToken(123.0, 1, 5)
    assert tokenize_y

# Generated at 2022-06-24 11:14:50.508341
# Unit test for function validate_yaml
def test_validate_yaml():
    class User(Schema):
        name = Field(type=str)

    # Parse a valid document.
    value, errors = validate_yaml(b"name: peter\n", User)
    assert errors == []
    assert value == {"name": "peter"}

    # Parse an invalid document.
    value, errors = validate_yaml(b"name: null\n", User)
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)
    assert errors[0].text == "Must be of type 'string'."

    # Parse a document with multiple validation errors.
    value, errors = validate_yaml(b"name: 4\n", User)
    assert len(errors) == 2
    assert isinstance(errors[0], ValidationError)

# Generated at 2022-06-24 11:14:54.499312
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: typesystem
    age: 3
    """
    validator = Schema(name=Field(type_=str), age=Field(type_=int))
    assert validate_yaml(content=content, validator=validator) == (
        {"name": "typesystem", "age": 3},
        None,
    )

# Generated at 2022-06-24 11:14:56.646701
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}



# Generated at 2022-06-24 11:15:01.084253
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    valid = """
    name: Bill
    age: 42
    """
    value, messages = validate_yaml(valid, Person)
    assert value == {"name": "Bill", "age": 42}
    assert not messages

    invalid = """
    name: Bill
    age: false
    """
    value, messages = validate_yaml(invalid, Person)
    assert messages == [Message("Invalid type.", code="invalid_type", position=Position(3, 6, 11))]

# Generated at 2022-06-24 11:15:10.330563
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, String

    class PetSchema(Schema):
        name = String(max_length=256)

    content = "name: Barky"
    value, error_messages = validate_yaml(content, PetSchema)
    assert value == {"name": "Barky"}
    assert not error_messages

    content = "name: Bark"
    _, error_messages = validate_yaml(content, PetSchema)
    assert error_messages[0].text == "String value is too short."
    assert error_messages[0].position == Position(1, 12, 11)

# Generated at 2022-06-24 11:15:14.730066
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(b"{key: value}")
    assert isinstance(token, dict)
    assert token["key"] == "value"
    assert token["key"].start == 0
    assert token["key"].end == 10



# Generated at 2022-06-24 11:15:23.048580
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}
    assert tokenize_yaml("foo: null") == {"foo": None}
    assert tokenize_yaml("foo: 1") == {"foo": 1}
    assert tokenize_yaml("foo: 1.0") == {"foo": 1.0}
    assert tokenize_yaml("foo: 1.1") == {"foo": 1.1}
    assert tokenize_yaml("foo: true") == {"foo": True}
    assert tokenize_yaml("foo: false") == {"foo": False}

# Generated at 2022-06-24 11:15:32.310391
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """\
        the:
          quick: brown
          fox:
            - jumps
            - over
            - the:
                lazy: dog
    """
    # Handle the empty string case explicitly for clear error messaging.
    assert tokenize_yaml('the: quick') == {'the': 'quick'}
    assert tokenize_yaml(content) == {'the': {'quick': 'brown', 'fox': ['jumps', 'over', {'the': {'lazy': 'dog'}}]}}
    assert tokenize_yaml({'the':'test'}) == {'the':'test'}



# Generated at 2022-06-24 11:15:40.894943
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"name": String()})
    # Check the case where no problems with the YAML
    (value, error_messages) = validate_yaml("name: Jane Doe\n", schema)
    assert not error_messages

    # Now check the case where there is a problem
    (value, error_messages) = validate_yaml("name: true\n", schema)
    assert len(error_messages) == 1  # There's only one problem
    assert error_messages[0].position.line_no == 1  # The error is on line 1
    assert error_messages[0].position.column_no == 7  # The error is on column 7

# Generated at 2022-06-24 11:15:43.234257
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "hello: world"
    token = tokenize_yaml(content)
    print(token)


# Generated at 2022-06-24 11:15:49.367751
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    string1 = "test: test"
    assert isinstance(tokenize_yaml(string1), DictToken)
    assert tokenize_yaml(string1).content == string1
    assert tokenize_yaml(string1).start == 0
    assert tokenize_yaml(string1).end == 8
    assert tokenize_yaml(string1).value == {"test": "test"}
    assert isinstance(tokenize_yaml(string1).get("test"), ScalarToken)
    assert tokenize_yaml(string1).get("test").content == string1
    assert tokenize_yaml(string1).get("test").start == 5
    assert tokenize_yaml(string1).get("test").end == 8
    assert tokenize_yaml(string1).get("test").value == "test"

    string

# Generated at 2022-06-24 11:15:54.622468
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema([
        'array',
        'float',
        'int',
        'number',
        'object',
        'string',
    ])
    yaml_ = 'array: [1, 2]'
    errors = Schema(
        schema,
        ('object', ('array', 'B'))
    ).validate(yaml_)
    print(errors)


# Generated at 2022-06-24 11:16:05.990035
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        integer = Field(type="integer")
        number = Field(type="number")
        string = Field(type="string")
        boolean = Field(type="boolean")
        null = Field(type="null")

    yaml = """
    integer: 1
    number: 1.0
    string: abcd
    boolean: true
    null: null
    """
    value, error_messages = validate_yaml(yaml, TestSchema())
    assert value["integer"] == 1
    assert value["number"] == 1.0
    assert value["string"] == "abcd"
    assert value["boolean"] is True
    assert value["null"] is None
    assert not error_messages

    yaml = """integer: 1"""
    _, error_messages = validate_y

# Generated at 2022-06-24 11:16:10.943323
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema.parse({"name": "string", "age": "integer"})
    content = "name: John\nage: 15"
    value, error_messages = validate_yaml(content, schema)
    assert value == {"name": "John", "age": 15}
    assert not error_messages



# Generated at 2022-06-24 11:16:21.961095
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ""
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml('"True"') == "True"
    assert tokenize_yaml('"False"') == "False"
    assert tokenize_yaml('"None"') == "None"
    assert tokenize_yaml("0.0") == 0.0
    assert tokenize_yaml("-0.0") == -0.0
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.1") == 1.1
    assert tokenize_yaml("-1") == -1
    assert tokenize_yaml("-1.1") == -1

# Generated at 2022-06-24 11:16:30.767466
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Cover all code paths for the tokenize_yaml function.
    assert tokenize_yaml("abcdefgh") == "abcdefgh"
    assert tokenize_yaml("- 1\n- 2\n- 3\n") == ["1", "2", "3"]
    assert tokenize_yaml("true: true\nfalse: false\n") == {
        "true": True,
        "false": False,
    }
    assert tokenize_yaml("1: 1\n2: 2\n3: 3\n") == {"1": "1", "2": "2", "3": "3"}
    assert tokenize_yaml("---") == None
    with pytest.raises(ParseError):
        tokenize_yaml("")



# Generated at 2022-06-24 11:16:35.041571
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type="string")
    value, errors = validate_yaml(
        content="foo: bar", validator=validator
    )
    assert errors == {
        "text": "Expected a scalar.",
        "code": "invalid_type",
        "position": Position(line_no=1, column_no=1, char_index=0),
    }



# Generated at 2022-06-24 11:16:45.388945
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, String, Integer, fields, types
    from typesystem.errors import ValidationError as TypeValidationError

    class Test(types.Schema):
        email = fields.String(format="email")

    class User(types.Schema):
        id = fields.Integer(minimum=1)
        name = fields.String()
        test = fields.Nested(Test())

    # Test good input
    value, _ =validate_yaml('''
    id: 2
    name: 'Example'
    test:
      email: example@example.com
    ''', User())
    assert value == {"id": 2, "name": "Example", "test": {"email": "example@example.com"}}

    # Test bad input

# Generated at 2022-06-24 11:16:54.832010
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(None) is None

    assert tokenize_yaml("") is None

    assert tokenize_yaml("null") is None

    assert tokenize_yaml("true") is True

    assert tokenize_yaml("false") is False

    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("-1") == -1
    assert tokenize_yaml("+1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("0.1") == 0.1
    assert tokenize_yaml("10e2") == 1000.0
    assert tokenize_yaml("10E2") == 1000.0
    assert tokenize_yaml("13e+4") == 130000.0
    assert tokenize_y

# Generated at 2022-06-24 11:17:04.700746
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array

    class Person(Schema):
        name = String()
        age = Integer()

    class Team(Schema):
        person = Person()

    class TeamArray(Schema):
        team = Array(of=Team())

    ok_content = """
        team:
          - person:
              name: Bob
              age: 12
          - person:
              name: Alice
              age: 18
        """

    assert validate_yaml(content=ok_content, validator=TeamArray) == ([], None)

    err_content = """
        team:
          - person:
              name: Bob
              age: 12
          - person:
              name: Alice
              age: notanumber
        """
    errors = validate_yaml(content=err_content, validator=TeamArray)

# Generated at 2022-06-24 11:17:12.302438
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema([{"name": "name", "type": "string"}, {"name": "age", "type": "integer"}])
    content = b'name: "John"\nage: "10"'
    value, error_messages = validate_yaml(content, schema)
    assert len(error_messages) == 2
    assert isinstance(error_messages[0], Message)
    assert error_messages[0].code == "invalid_type"
    assert error_messages[0].field == "age"



# Generated at 2022-06-24 11:17:22.425779
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String, validate, Schema
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Field
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    class MySchema(Schema):
        name = String(required=True)
        items = Field(of=Integer, repeated=True)

    content = """\
name: foo
# Comment!
items: [1, 2, 3]
"""

    with pytest.raises(ValidationError):
        validate(content, validator=MySchema)

    value, error_messages = validate_yaml(content, validator=MySchema)
    assert error_messages == []
    assert isinstance(value, DictToken)

# Generated at 2022-06-24 11:17:28.307102
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("\n") == None
    assert tokenize_yaml(" ") == None
    assert tokenize_yaml("\t") == None
    assert tokenize_yaml("\r") == None
    assert tokenize_yaml("{") == None
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("cat: 1") == {"cat": 1}
    assert tokenize_yaml("cat: 1, dog: 2") == None
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("cat: 1, dog: 2") == None
    assert tokenize_yaml("cat: 1, dog: 2") == None

# Generated at 2022-06-24 11:17:35.268761
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("test"), ScalarToken)
    assert isinstance(tokenize_yaml("123"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)



# Generated at 2022-06-24 11:17:44.743952
# Unit test for function validate_yaml
def test_validate_yaml():
    assert isinstance(validate_yaml("foo", str)[0], ScalarToken)
    assert (
        validate_yaml("foo", {"name": str})[0]
        == DictToken({0: ScalarToken("name", 1, 4, "foo"), 1: ScalarToken("foo", 6, 9, "foo")}, 0, 9, "foo")
    )
    assert validate_yaml("- foo", [str])[0] == ListToken(
        [ScalarToken("foo", 3, 6, "- foo")], 0, 6, "- foo"
    )

# Generated at 2022-06-24 11:17:47.628336
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo: bar") == {'foo': 'bar'}


# Generated at 2022-06-24 11:17:55.473898
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.models import Model
    from typesystem.types import String

    class Person(Model):
        name = String()

    yaml_data = """
    name: Arthur
    age: 34
    """

    value, error_messages = validate_yaml(yaml_data, validator=Person)
    assert value == {"name": "Arthur"}
    assert len(error_messages) == 1
    assert error_messages[0].code == "unknown_field"
    assert error_messages[0].position.line_no == 3
    assert error_messages[0].position.column_no == 5



# Generated at 2022-06-24 11:18:01.730408
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert type(tokenize_yaml("{}")) == DictToken
    assert type(tokenize_yaml("['a', 'b', 'c']")) == ListToken
    assert type(tokenize_yaml("True")) == ScalarToken
    assert type(tokenize_yaml("""
        'text'
        """)) == ScalarToken



# Generated at 2022-06-24 11:18:07.621779
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = Field(name="name", type_=str)
        age = Field(name="age", type_=int)
        parent = Field(name="parent", type_=MySchema)

    content = """
    - name: Alex
      age: 3
    - name: Alex
      age: 3

    parent:
      name: John
      age: 30
      parent:
        name: Jane
        age: 50
        """

    value, errors = validate_yaml(content, MySchema)

# Generated at 2022-06-24 11:18:14.153347
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "a: b\nb: c\n"
    token = tokenize_yaml(content)
    assert token.type == "mapping"
    assert token[0].type == "scalar"
    assert token[0].start == token[0].pos_start
    assert token[0].end == token[0].pos_end
    assert token[0].value == "a"
    assert token[1].value == "b"
    assert token[2].value == "b"



# Generated at 2022-06-24 11:18:20.349077
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type_=int)
    value, errors = validate_yaml("123", validator)
    assert value == 123
    assert errors == []

    value, errors = validate_yaml("abc", validator)
    assert value is None
    assert errors == [
        ValidationError(
            error="Must be of type 'int'.",
            position=Position(line_no=1, column_no=1, char_index=0),
        )
    ]

    value, errors = validate_yaml("abc\ndef", validator)
    assert value is None
    assert errors == [
        ValidationError(
            error="Must be of type 'int'.",
            position=Position(line_no=1, column_no=1, char_index=0),
        )
    ]


# Test parsing

# Generated at 2022-06-24 11:18:27.249241
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('') == None
    assert tokenize_yaml('[1, 2, 3]') == [ScalarToken(1, 0, 0, ''), ScalarToken(2, 0, 0, ''), ScalarToken(3, 0, 0, '')]
    assert tokenize_yaml('{a: b}') == [DictToken({'a': ScalarToken('b', 0, 0, '')},0,0,'')]

# Generated at 2022-06-24 11:18:34.375101
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    print("Testing function tokenize_yaml")
    input = "['a','b','c']"
    expected_output = ListToken(['a','b','c'], 0, 11, "['a','b','c']")
    assert tokenize_yaml(input) == expected_output
    input = "{'a':'b','c':'d'}"
    expected_output = DictToken({'a':'b','c':'d'}, 0, 14, "{'a':'b','c':'d'}")
    assert tokenize_yaml(input) == expected_output
    input = "null"
    expected_output = ScalarToken(None, 0, 3, "null")
    assert tokenize_yaml(input) == expected_output
    input = "0"

# Generated at 2022-06-24 11:18:39.691911
# Unit test for function validate_yaml
def test_validate_yaml():
    #test success case
    validator = Field(type=str)
    content = "some_content"
    assert validate_yaml(content, validator) == ("some_content", [])

    #test failure case
    validator = Field(type=int)
    content = "some_content"
    assert validate_yaml(content, validator) == (validator, [])

# Generated at 2022-06-24 11:18:41.516920
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == []
    assert tokenize_yaml("a: 1") == {'a': 1}


# Generated at 2022-06-24 11:18:43.765462
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """Should tokenize yaml."""
    token = tokenize_yaml('"test"')
    assert token == ScalarToken('test', 0, 5, content='"test"')


# Generated at 2022-06-24 11:18:46.917432
# Unit test for function validate_yaml
def test_validate_yaml():
    class User(Schema):
        name = String(max_length=25)

    content = """\
name: foo
"""

    value, error_messages = validate_yaml(content=content, validator=User)

    assert value == {"name": "foo"}
    assert len(error_messages) == 0



# Generated at 2022-06-24 11:18:53.741148
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""
    name: John
    age: 35
    children:
      - name: Jane
        age: 12
      - name: Joan
        age: 9
    """
    value, error_messages = validate_yaml(content, ChildSchema)
    assert value == {"name": "John", "age": 35, "children": [{"name": "Jane", "age": 12}, {"name": "Joan", "age": 9}]}
    assert error_messages == []



# Generated at 2022-06-24 11:19:01.762438
# Unit test for function validate_yaml
def test_validate_yaml():
    import pprint
    content = """
    item:
      - name: jack
        age: 19
        traits:
          - nice
          - friendly
      - name: jill
        traits:
          - honest
    """
    validator = Field(name="item", type=Schema(
        name="item", fields={"name": Field(type=str), "age": Field(type=int), "traits": Field(type=list)}
    ))
    value, errors = validate_yaml(content, validator)
    pprint.pprint(errors)

# Generated at 2022-06-24 11:19:12.815672
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # scalar
    actual = tokenize_yaml("foo")
    assert actual.value == "foo"
    assert actual.start == 0
    assert actual.end == 3

    # list
    actual = tokenize_yaml("- 12\n- 13.5")
    assert isinstance(actual, ListToken)
    assert len(actual.value) == 2
    assert actual.value[0].value == 12
    assert actual.value[1].value == 13.5

    # dict
    content = "\n".join(["foo: 12", "bar: 13"])
    actual = tokenize_yaml(content)
    assert isinstance(actual, DictToken)
    assert actual.value["foo"].value == 12
    assert actual.value["bar"].value == 13

    # empty

# Generated at 2022-06-24 11:19:24.607779
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") is None
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("foo\nbar") == "foo\nbar"
    assert tokenize_yaml("foo: bar") == DictToken({"foo": "bar"}, 0, 8, content="foo: bar")
    assert tokenize_yaml("foo:\n  bar") == DictToken({"foo": "bar"}, 0, 12, content="foo:\n  bar")
    assert tokenize_yaml("foo:\n- bar") == DictToken({"foo": ["bar"]}, 0, 12, content="foo:\n- bar")

# Generated at 2022-06-24 11:19:34.460501
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # case 1
    assert tokenize_yaml("{}") == {}
    # case 2
    assert tokenize_yaml("{}") == {}
    # case 3
    assert tokenize_yaml("{}") == {}
    # case 4
    assert tokenize_yaml("{}") == {}
    # case 5
    assert tokenize_yaml("{}") == {}
    # case 6
    assert tokenize_yaml("{}") == {}
    # case 7
    assert tokenize_yaml("{}") == {}
    # case 8
    assert tokenize_yaml("{}") == {}
    # case 9
    assert tokenize_yaml("{}") == {}
    # case 10
    assert tokenize_yaml("{}") == {}
    # case 11
    assert tokenize

# Generated at 2022-06-24 11:19:41.662171
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('"val"') == ScalarToken('val', 0, 4, content='"val"')
    assert tokenize_yaml('{}') == DictToken({}, 0, 1, content='{}')
    assert tokenize_yaml('- 1\n- 2') == ListToken([1, 2], 0, 6, content='- 1\n- 2')
    assert tokenize_yaml('"\n') == ParseError(text='while scanning a quoted scalar', code='parse_error', position=Position(column_no=2, line_no=1, char_index=1))



# Generated at 2022-06-24 11:19:52.121248
# Unit test for function validate_yaml
def test_validate_yaml():
    class SomeSchema(Schema):
        name = Str()
        age = Int()
        requested_greeting = Str()

    content = """
        name: Jane Doe
        age: 40
        request_greeting: Hello!
    """
    val, err = validate_yaml(content, SomeSchema())
    assert val == {'name': 'Jane Doe', 'age': 40, 'request_greeting': 'Hello!'}
    assert len(err) == 5
    assert err[0].text == "Unknown field name 'request_greeting'."
    assert err[0].position.line_no == 4
    assert err[0].position.column_no == 5
    assert err[1].text == "Unused field names: 'request_greeting'."

# Generated at 2022-06-24 11:20:00.312937
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    # Get back positionally marked error messages on failure.
    (value, errors) = validate_yaml(
        b"""name: Bob
        age: "not an int"
        """,
        Person,
    )
    expected_errors = [
        {
            "code": "is_type",
            "message": "Must be an integer.",
            "position": {"line_no": 2, "column_no": 9, "char_index": 15},
            "value": "not an int",
        }
    ]
    assert errors == expected_errors

    # Success.

# Generated at 2022-06-24 11:20:06.873866
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("{}", Schema(fields={})) == ({}, [])
    assert validate_yaml("{'a': 5}", Schema(fields={'a': Field(type='integer')})) == ({'a': 5}, [])
    with pytest.raises(ParseError) as exc_info:
        validate_yaml("{", Schema(fields={}))
    assert exc_info.type == ParseError


# Generated at 2022-06-24 11:20:08.478761
# Unit test for function validate_yaml
def test_validate_yaml():
    assert isinstance(validate_yaml('a:b',{}),tuple)

# Generated at 2022-06-24 11:20:11.605049
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
    foo: bar
    baz:
      - qux
      - quux
    '''
    tokens = tokenize_yaml(content)
    return tokens


# Generated at 2022-06-24 11:20:21.435086
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem import validators

    schema = String(validators=[validators.MinLength(4)])
    value, error_messages = validate_yaml(
        content='"test"',
        validator=schema,
    )
    assert value == 'test'
    assert len(error_messages) == 0
    value, error_messages = validate_yaml(
            content='"foo"',
            validator=schema,
    )
    assert len(error_messages) == 1
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 1
    assert error_messages[0].position.char_index == 0

    schema = Integer()
    value, error_messages

# Generated at 2022-06-24 11:20:30.860171
# Unit test for function validate_yaml
def test_validate_yaml():
    content = (
        "name: john smith\n"
        "age: 23\n"
        "address:\n"
        "  street: 1 main st\n"
        "  city: kings landing\n"
    )
    token = tokenize_yaml(content)
    assert token.content == content
    assert token.start == 0
    assert token.end == len(content) - 1

    class Address(Schema):
        street = Field()
        city = Field()

    class Person(Schema):
        name = Field()
        age = Field(validators=["integer"])
        address = Field(schema=Address)

    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-24 11:20:35.376049
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    text = "test: value"
    token = tokenize_yaml(text)
    print(token)
    assert token == {"test": "value"}
    assert isinstance(token, DictToken)
    assert isinstance(token["test"], ScalarToken)



# Generated at 2022-06-24 11:20:40.125248
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(
        """
foo:
  bar: baz

# a comment

baz:
- a
- b
- c
- d
- e
"""
    )
    assert token == {
        "foo": {"bar": "baz"},
        "baz": ["a", "b", "c", "d", "e"],
    }



# Generated at 2022-06-24 11:20:47.169712
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields

    class Person(Schema):
        name = fields.String()
        age = fields.Integer()

    content = """
    name: 1
    age: foo
    """

    (
        data,
        error_messages,
    ) = validate_yaml(content, Person)

    assert data == None
    assert len(error_messages) == 2