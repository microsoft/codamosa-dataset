

# Generated at 2022-06-24 11:10:53.197149
# Unit test for function tokenize_yaml

# Generated at 2022-06-24 11:11:05.052150
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem import fields

    content = """
        foo:
            bar: 5
        """

    (value, messages) = validate_yaml(content, fields.Dictionary({"foo": fields.Integer(1, 10)}))
    assert value == {"foo": {"bar": 5}}
    assert len(messages) == 0

    (value, messages) = validate_yaml(content, fields.Dictionary({"foo": fields.Integer(1, 2)}))
    assert value == {"foo": {"bar": 5}}
    assert len(messages) == 1
    assert messages[0].text == "foo"
    assert messages[0].code == "not_a_valid_choice"


# Generated at 2022-06-24 11:11:14.563265
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Empty string
    assert tokenize_yaml(content="") is None

    # Scalars
    content = "foo"
    assert tokenize_yaml(content=content).value == "foo"

    content = "123"
    assert tokenize_yaml(content=content).value == "123"

    content = "1.23"
    assert tokenize_yaml(content=content).value == "1.23"

    content = "true"
    assert tokenize_yaml(content=content).value == "true"

    # Lists
    content = "[]"
    assert tokenize_yaml(content=content).value == []

    content = "[ foo, 123, 1.23, true ]"
    assert tokenize_yaml(content=content).value == ["foo", "123", "1.23", "true"]



# Generated at 2022-06-24 11:11:18.686608
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("foo: bar")
    token.value["foo"].value = "bar"
    assert token.value["foo"].value == "bar"



# Generated at 2022-06-24 11:11:27.378396
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_str = """
        my_name: ryan
        works_at: the_guardian
        likes:
           - books
           - beer 
           - bicycling
        """
    validator = Schema(
        {"my_name": str, "works_at": str, "likes": [str]}
    )
    # print(validate_yaml(yaml_str, validator))
    assert type(validate_yaml(yaml_str, validator)[0]) == dict 
    assert type(validate_yaml(yaml_str, validator)[1]) == list 
    
    
    


# Generated at 2022-06-24 11:11:33.633235
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    given_content = 'foo: bar'
    given_validator = None
    expected_position = Position(line_no=1, column_no=1, char_index=0)

    try:
        token = tokenize_yaml(given_content)
        value = validate_with_positions(token, given_validator)
    except ParseError as exc:
        messages = exc.messages

    # Check that the error message is correct
    assert messages[0].position == expected_position
    assert messages[0].text == 'No content.'
    assert messages[0].code == 'no_content'

# Generated at 2022-06-24 11:11:40.702722
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: bar
    foo: bar
    """
    schema = Schema({"foo": str})
    value, errors = validate_yaml(content, schema)
    assert value == {"foo": "bar"}
    assert len(errors) == 2
    assert errors[0].position.line_no == 2
    assert errors[1].position.line_no == 3



# Generated at 2022-06-24 11:11:49.381477
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = types.String()
        age = types.Integer()
    schema = MySchema()

    class MySchema(Schema):
        name = types.String()
        age = types.Integer()

    schema = MySchema()
    # Test successful validation
    content = """
    name: John
    age: 23
    """
    (value, error_messages) = validate_yaml(content, schema)
    assert value == {'name': 'John', 'age': 23}
    assert error_messages == []

    # Test unsuccessful validation
    content = """
    name: John
    age: xxx
    """
    (value, error_messages) = validate_yaml(content, schema)
    assert value == None

# Generated at 2022-06-24 11:11:57.931203
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = Text(max_length=100)
        age = Integer(minimum=0)

    valid, errors = validate_yaml(
        """\
    name: Bob
    age: 42
    """,
        Person,
    )
    assert valid == {"name": "Bob", "age": 42}
    assert not errors

    valid, errors = validate_yaml(
        """\
    name: Bob
    age: 'forty-two'
    """,
        Person,
    )
    assert errors[0].text == "'forty-two' could not be parsed as integer."



# Generated at 2022-06-24 11:12:01.829359
# Unit test for function validate_yaml
def test_validate_yaml():
    text = """
    a: 2
    b: "apple"
    """
    value = validate_yaml(text, Schema({
        'a': int,
        'b': str,
    }))
    assert value == ({'a': 2, 'b': 'apple'}, [])


# Generated at 2022-06-24 11:12:11.605452
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer as TSInteger, String as TSString
    from typesystem.schemas import Schema as TSSchema

    class MySchema(TSSchema):
        flag = TSString()
        n = TSInteger()

    # Test good string
    value, errors = validate_yaml(
        content="""
        flag: -n
        n: 2
        """,
        validator=MySchema,
    )
    assert value == {"flag": "-n", "n": 2}
    assert not errors

    # Test invalid string
    value, errors = validate_yaml(
        content="""
        flag: -n
        n : asdf
        """,
        validator=MySchema,
    )
    assert value is None
    assert isinstance(errors, list)
    assert len(errors)

# Generated at 2022-06-24 11:12:21.144148
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("a: b") == DictToken({"a": "b"}, 0, 4)
    assert tokenize_yaml("[1, 2]") == ListToken([1, 2], 0, 6)
    assert tokenize_yaml("[1, -2]") == ListToken([1, -2], 0, 7)
    assert tokenize_yaml("3") == ScalarToken(3, 0, 1)
    assert tokenize_yaml("-3") == ScalarToken(-3, 0, 2)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5)
    assert tokenize

# Generated at 2022-06-24 11:12:31.095834
# Unit test for function validate_yaml
def test_validate_yaml():
    # test parse error
    #test_result = validate_yaml('hello ia m a', Schema('test', fields={'hello': String(max_length=4)}))
    #print (test_result)

    #test_result = validate_yaml('hello: ia m a', Schema('test', fields={'hello': String(max_length=4)}))
    #print (test_result)

    # test validation error
    #test_result = validate_yaml('hello: ia m a', Schema('test', fields={'hello': String(max_length=5)}))
    #print (test_result)

    # test char index
    test_result = validate_yaml('hello : ia m a', Schema('test', fields={'hello': String(max_length=5)}))

# Generated at 2022-06-24 11:12:39.365580
# Unit test for function validate_yaml
def test_validate_yaml():
    def validate_yaml_test_impl(yaml_data, yaml_schema):
        yaml_value, yaml_errors = validate_yaml(yaml_data, yaml_schema)
        if not yaml_errors:
            print(yaml_value)
        else:
            print(yaml_errors)

    # definitions can be reused
    definitions = {"my_definition": {"type": "string"}}

    # A simple schema for a Map of simple scalars
    yaml_schema = Schema(
        {
            "title": {"type": "string"},
            "year": {"type": "integer"},
            "synopsis": {"type": "string"},
        },
        title="Movie schema",
        description="A schema for storing information about movies",
    )

    # Test a valid movie object


# Generated at 2022-06-24 11:12:41.839333
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "foo: bar"
    token = tokenize_yaml(content)
    assert token == {"foo": "bar"}

# Generated at 2022-06-24 11:12:50.282215
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('[1, 2, 3, 4]') == [ScalarToken(1, 0, 0, content='[1, 2, 3, 4]'), ScalarToken(2, 2, 2, content='[1, 2, 3, 4]'), ScalarToken(3, 4, 4, content='[1, 2, 3, 4]'), ScalarToken(4, 6, 6, content='[1, 2, 3, 4]')]
    assert tokenize_yaml('{"name": "Johnny"}') == [('name', ScalarToken('Johnny', 7, 13, content='{"name": "Johnny"}'))]
    assert tokenize_yaml('a: 1') == [('a', ScalarToken(1, 4, 4, content='a: 1'))]

# Generated at 2022-06-24 11:12:53.906557
# Unit test for function validate_yaml
def test_validate_yaml():
    content = 'age:4'
    token = tokenize_yaml(content)
    validator = Field(type="integer")
    result = validate_with_positions(token=token, validator=validator)
    assert result == ([], {'age': 4})



# Generated at 2022-06-24 11:13:04.137882
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("{}", validator=Schema) == ({}, [])

    assert validate_yaml("{}", validator=Dict({})) == ({}, [])

    assert validate_yaml("123", validator=Int()) == (123, [])

    assert validate_yaml("123", validator=String()) == (
        "123",
        [
            Message(
                text="String value expected.",
                code="invalid",
                position=Position(
                    line_no=1, column_no=1, char_index=0,
                )
            )
        ]
    )


# Generated at 2022-06-24 11:13:10.258708
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{test:test2}") == {'test': 'test2'}
    assert tokenize_yaml("{test:test2,test3:test4}") == {'test': 'test2', 'test3': 'test4'}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("[test,test2]") == ['test', 'test2']

# Generated at 2022-06-24 11:13:11.803150
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(b"{}", Schema)

# Generated at 2022-06-24 11:13:22.615990
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Scalar test cases
    assert tokenize_yaml("'string'") == ScalarToken(value="string", start=0, end=7, content="'string'")
    assert tokenize_yaml("123") == ScalarToken(value=123, start=0, end=2, content="123")
    assert tokenize_yaml("12.3") == ScalarToken(value=12.3, start=0, end=3, content="12.3")
    assert tokenize_yaml("12.3e-5") == ScalarToken(value=12.3e-5, start=0, end=6, content="12.3e-5")

# Generated at 2022-06-24 11:13:25.892338
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "somecontentstring"
    validator = Field(type=str)
    value = validate_yaml(content=content, validator=validator)
    assert(value == ("somecontentstring", []))


# Generated at 2022-06-24 11:13:34.629511
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('name: "1"')
    assert isinstance(token, tokenize.tokens.DictToken)
    assert token.value['name'].value == '1'
    token = tokenize_yaml('- "1"')
    assert isinstance(token, tokenize.tokens.ListToken)
    assert token.value[0].value == '1'
    token = tokenize_yaml('"1"')
    assert isinstance(token, tokenize.tokens.ScalarToken)
    assert token.value == '1'
    token = tokenize_yaml('1')
    assert isinstance(token, tokenize.tokens.ScalarToken)
    assert token.value == 1
    token = tokenize_yaml('1.1')
    assert isinstance

# Generated at 2022-06-24 11:13:43.167664
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('{"foo": [1, 2, 3]}')
    assert isinstance(token, DictToken)
    assert len(token) == 1
    assert token['foo'] == [ScalarToken(1, 7, 8, content='{"foo": [1, 2, 3]}'),
                            ScalarToken(2, 10, 11, content='{"foo": [1, 2, 3]}'),
                            ScalarToken(3, 13, 14, content='{"foo": [1, 2, 3]}')]
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == 18
    assert token.raw_value == '{"foo": [1, 2, 3]}'



# Generated at 2022-06-24 11:13:55.817708
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("blah:") == {
        "blah": ""
    }
    assert tokenize_yaml("blah: value") == {
        "blah": "value"
    }
    assert tokenize_yaml("blah:\n  nested: true") == {
        "blah": {"nested": True}
    }
    assert tokenize_yaml("- blah") == [
        "blah"
    ]
    assert tokenize_yaml("- 1") == [
        1
    ]
    assert tokenize_yaml("blah:") == {
        "blah": ""
    }
    assert tokenize_yaml("blah: null") == {
        "blah": None
    }

# Generated at 2022-06-24 11:14:02.602728
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(
        tokenize_yaml("{foo: bar}"),
        DictToken,
    ), "tokenize_yaml returned unexpected token type"

    assert isinstance(
        tokenize_yaml("[1,2, 3]"),
        ListToken,
    ), "tokenize_yaml returned unexpected token type"



# Generated at 2022-06-24 11:14:09.031168
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('') == ''
    assert tokenize_yaml('true') == True
    assert tokenize_yaml('false') == False
    assert tokenize_yaml('null') == None
    assert tokenize_yaml('1') == 1
    assert tokenize_yaml('1.0') == 1.0
    assert tokenize_yaml('foo') == 'foo'
    assert tokenize_yaml('"foo"') == 'foo'
    assert tokenize_yaml('foo: 1') == {'foo': 1}
    assert tokenize_yaml('- foo') == ['foo']


# Generated at 2022-06-24 11:14:20.665229
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(required=True)

    (value, errors) = validate_yaml("hello", field)
    assert value == "hello"
    assert len(errors) == 0

    (value, errors) = validate_yaml("hello\nworld", field)
    assert value == "hello\nworld"
    assert len(errors) == 0

    (value, errors) = validate_yaml("hello # comment", field)
    assert value == "hello # comment"
    assert len(errors) == 0

    (value, errors) = validate_yaml("", field)
    assert value == ""
    assert len(errors) == 0

    (value, errors) = validate_yaml("\n", field)
    assert value == "\n"
    assert len(errors) == 0

    (value, errors) = validate_yaml

# Generated at 2022-06-24 11:14:28.067940
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    dict_token = tokenize_yaml('{ "name": "john", "age": 30 }')
    assert isinstance(dict_token, DictToken)
    assert dict_token.start == 0
    assert dict_token.end == 30
    assert dict_token.value == {"name": "john", "age": 30}
    name_token = dict_token.value["name"]
    assert isinstance(name_token, ScalarToken)
    assert name_token.start == 9
    assert name_token.end == 14
    assert name_token.value == "john"
    age_token = dict_token.value["age"]
    assert isinstance(age_token, ScalarToken)
    assert age_token.start == 19
    assert age_

# Generated at 2022-06-24 11:14:32.632019
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    hello: world
    """)
    assert token.validate({"hello": types.String()}) == {"hello": "world"}



# Generated at 2022-06-24 11:14:40.967491
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field('S')
    for v in range(0, 1):
        with pytest.raises(ParseError):
            assert validate_yaml(
                "this is a test\\",
                validator=validator,
            )
    with pytest.raises(ValidationError) as e:
        value, errors = validate_yaml(
            '{"foo": "bar"}',
            validator=validator,
        )
    assert e.value.message.text == "Expected string but found dict."
    assert e.value.message.position == Position(line_no=1, column_no=2, char_index=2)
    assert e.value.message.code == "invalid_type"

# Generated at 2022-06-24 11:14:52.043601
# Unit test for function tokenize_yaml

# Generated at 2022-06-24 11:14:57.660029
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = String()
        age = Integer(minimum=0, maximum=200)
    c, e = validate_yaml("""
        name: "John"
        age: "32"
        """, PersonSchema)
    assert c == {"name": "John", "age": 32}
    assert e == []
    c, e = validate_yaml("""
        name: "John"
        age: "-32"
        """, PersonSchema)
    assert c is None and len(e) == 1



# Generated at 2022-06-24 11:15:04.995813
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    test:
      - [1, 2, 3]
      - x: y
    """
    content = content.lstrip()
    assert yaml is not None
    token = tokenize_yaml(content)
    assert token == {
        "test": [
            [1, 2, 3],
            {"x": "y"},
        ]
    }
    position = token[0].children[0].position
    assert position.line_no == 2
    assert position.column_no == 5
    assert position.char_index == 11

# Generated at 2022-06-24 11:15:12.594840
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        - a: 1
        - a: 2
        - a: 3
        - a: 4
    """
    class TestSchema(Schema):
        a = Field(types=int)
    validator = TestSchema()
    value, errors = validate_yaml(content, validator)
    assert len(errors) == 0
    assert value == [{"a": 1}, {"a": 2}, {"a": 3}, {"a": 4}]


# Generated at 2022-06-24 11:15:24.088052
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert isinstance(tokenize_yaml('foo'), ScalarToken)
    assert isinstance(tokenize_yaml('[foo]'), ListToken)
    assert isinstance(tokenize_yaml('{"foo": "bar"}'), DictToken)
    assert isinstance(tokenize_yaml(''), Token)
    assert isinstance(tokenize_yaml('invalid'), ParseError)
    assert isinstance(tokenize_yaml('invalid', desc='string'), ParseError)
    assert isinstance(tokenize_yaml('invalid', desc='bytes'), ParseError)
    assert isinstance(tokenize_yaml('invalid', desc='bytes', content='valid'), Token)

# Generated at 2022-06-24 11:15:33.353107
# Unit test for function validate_yaml
def test_validate_yaml():
    class HumanSchema(Schema):
        name = String(max_length=50)
        age = Integer(minimum=0)

    err_msg, value = validate_yaml(
        b"""
        name: "John Smith"
        age: 34
        """,
        validator=HumanSchema,
    )
    assert value == {'name': 'John Smith', 'age': 34}
    assert err_msg is None

    err_msg, value = validate_yaml(
        b"""
        name: 453
        age: -32
        """,
        validator=HumanSchema,
    )
    assert value == None
    assert err_msg is not None

# Generated at 2022-06-24 11:15:42.025134
# Unit test for function validate_yaml
def test_validate_yaml():
    content = (
        "null: null\n"
        "boolean: true\n"
        "integer: 42\n"
        "float: 3.14\n"
        "list: \n"
        "- one\n"
        "- two\n"
        "- three\n"
        "mapping:\n"
        " one: 1\n"
        " two: 2\n"
        " three: 3\n"
        "binary: !!binary gIGC\n"
        "timestamp: 2001-12-15T02:59:43.1Z\n"
    )
    (value, errors) = validate_yaml(content, Schema)
    assert len(errors) == 0

# Generated at 2022-06-24 11:15:46.808735
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    age: 30
    name: test
    """
    schema = Schema(
        properties={"age": int, "name": str.as_required()}
    )

    value, errors = validate_yaml(content=content, validator=schema)
    assert value == {'age': 30, 'name': 'test'}
    assert errors == {}



# Generated at 2022-06-24 11:15:53.194014
# Unit test for function validate_yaml
def test_validate_yaml():
    value, errors = validate_yaml("test: X", fields.String())
    assert value == 'X'
    assert errors == []

    value, errors = validate_yaml("invalid-yaml: x", fields.String())
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == 'parse_error'
    assert errors[0].text == "expected ':'.\n"
    assert errors[0].position == Position(line_no=1, column_no=10, char_index=9)


# Generated at 2022-06-24 11:16:04.529926
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test the tokens
    token = tokenize_yaml('{"key": 1}')
    assert isinstance(token, DictToken)
    assert isinstance(token.value['key'], ScalarToken)

    token = tokenize_yaml('''[1, "item", null]''')
    assert isinstance(token, ListToken)
    assert isinstance(token.value[0], ScalarToken)
    assert isinstance(token.value[1], ScalarToken)
    assert isinstance(token.value[2], ScalarToken)

    token = tokenize_yaml('''{'key'}''')
    assert isinstance(token, ScalarToken)

    # test the error messages

# Generated at 2022-06-24 11:16:07.413674
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "foo: 'bar'."
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

    class TestSchema(Schema):
        foo = Field()

# Generated at 2022-06-24 11:16:16.270051
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    
    assert tokenize_yaml('') == None
    assert tokenize_yaml('  ') == None
    assert tokenize_yaml('# test comment') == None

    assert tokenize_yaml('null') == None
    assert tokenize_yaml('true') == True
    assert tokenize_yaml('false') == False
    assert tokenize_yaml('"TEST STRING"') == "TEST STRING"
    assert tokenize_yaml('12') == 12
    assert tokenize_yaml('12.34') == 12.34
    assert tokenize_yaml('12e34') == 12e34
    assert tokenize_yaml('12E34') == 12E34
    

# Generated at 2022-06-24 11:16:25.061505
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    valid_yaml = r"""
- value1
- value2
- value3
"""
    token = tokenize_yaml(valid_yaml)
    assert isinstance(token, ListToken)
    assert isinstance(token.values[0], ScalarToken)
    assert token.values[0].value == "value1"
    assert isinstance(token.values[1], ScalarToken)
    assert token.values[1].value == "value2"
    assert isinstance(token.values[2], ScalarToken)
    assert token.values[2].value == "value3"

    invalid_yaml = r"""
- value1
- value2
- value3
-
"""


# Generated at 2022-06-24 11:16:33.993064
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("a: 1") == DictToken({'a':1}, 0, 4, content="a: 1")
    assert tokenize_yaml("a: []") == DictToken({'a':[]}, 0, 5, content="a: []")
    assert tokenize_yaml("a: [1, 2]") == DictToken({'a':[1, 2]}, 0, 9, content="a: [1, 2]")
    assert tokenize_yaml("a: {b: 1}") == DictToken({'a':{'b':1}}, 0, 10, content="a: {b: 1}")
    assert tokenize_yaml("a: y") == DictToken({'a':'y'}, 0, 4, content="a: y")
    assert tokenize_yaml

# Generated at 2022-06-24 11:16:41.286378
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "a: 1\nb: 2\n"
    token = tokenize_yaml(content)
    # Assert content, start, end, and values
    assert token.content == content
    assert token.start == 0
    assert token.end == 11
    assert token.get("a") == ScalarToken("1", start=2, end=3, content=content)
    assert token.get("b") == ScalarToken("2", start=7, end=8, content=content)



# Generated at 2022-06-24 11:16:44.146471
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert type(tokenize_yaml('''
    hello:
      - one: 1
        two: 2
      - three: 3
        four: 4
    ''')) == DictToken


# Generated at 2022-06-24 11:16:49.623317
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test case for validate_yaml function"""
    from typesystem.types import String
    validator = String(max_length=4)
    assert validate_yaml(content="test", validator=validator) == ("test", [])



# Generated at 2022-06-24 11:17:01.042308
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test for Field
    class TestField(Field):
        pass

    x = TestField(name="TestField")

    valid_content = """
    Test content!
    """

    result = validate_yaml(valid_content, validator=x)
    assert result == ({"string": "Test content!\n"}, False)

    invalid_content = """
    Invalid Test content!
    """

    expected_error = Message(
        text="Invalid Test content!\n",
        code="parse_error",
        position=Position(line_no=2, column_no=1, char_index=9)
    )

    try:
        validate_yaml(invalid_content, validator=x)
    except ParseError as err:
        assert err.messages == {'string': [expected_error]}

    #

# Generated at 2022-06-24 11:17:11.524312
# Unit test for function validate_yaml
def test_validate_yaml():
    class MetadataSchema(Schema):
        name = fields.String()
        role = fields.Choice(choices=("author", "contributor", "reader"))

    content_templ = """
    name: {name}
    role: {role}
    """

    # Test valid input
    content = content_templ.format(name="Samantha", role="author")
    parsed, errors = validate_yaml(content, MetadataSchema)
    assert errors == []
    assert isinstance(parsed, DictToken)
    assert parsed.mapping["name"].value_ == "Samantha"
    assert parsed.mapping["role"].value_ == "author"

    # Test valid input, with some extra whitespace

# Generated at 2022-06-24 11:17:21.775055
# Unit test for function tokenize_yaml

# Generated at 2022-06-24 11:17:25.593668
# Unit test for function validate_yaml
def test_validate_yaml():
    # pylint: disable=W0212
    content = r"""
    a:
      - b
      - c
      - d
      - e
    """  # noqa: E501
    token = tokenize_yaml(content)
    value, errors = validate_with_positions(None, token)
    assert errors == []

# Generated at 2022-06-24 11:17:32.957537
# Unit test for function validate_yaml

# Generated at 2022-06-24 11:17:41.902775
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)

    valid_yaml = """
    name: John
    age: 32
    """
    value, error_messages = validate_yaml(valid_yaml, TestSchema)
    assert value == {"name": "John", "age": 32}
    assert not error_messages

    invalid_yaml = """
    name: John
    birthday: yesterday
    age: 32
    """
    _, error_messages = validate_yaml(invalid_yaml, TestSchema)
    assert len(error_messages) == 1
    error = error_messages[0]
    assert error.text == "Additional properties are not allowed"
    assert error.code == "extra_properties"

# Generated at 2022-06-24 11:17:53.307339
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type=str)
    value, errors = validate_yaml(content="foo", validator=validator)
    assert not errors
    assert value == "foo"

    value, errors = validate_yaml(content="", validator=validator)
    assert not errors
    assert value == ""

    value, errors = validate_yaml(content="a", validator=validator)
    assert len(errors) == 1
    expected_message = Message(
        position=Position(char_index=0, line_no=1, column_no=1),
        text="Invalid value.",
        code="invalid",
        type="str",
        info={},
    )
    assert errors[0] == expected_message



# Generated at 2022-06-24 11:18:03.792626
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    data_yaml = """
    a:
      - 1
      - 2
      - 3
    b: 2
    """
    value, errors = validate_yaml(data_yaml, Field("a", type="array", items=Field("a", type="integer")))
    assert value == {'a': [1, 2, 3], 'b': 2}

    data_bad_yaml = """
    a:
      - 1
      - x
      - 3
    """
    value, errors = validate_yaml(data_bad_yaml, Field("a", type="array", items=Field("a", type="integer")))
    assert len(errors) == 1



# Generated at 2022-06-24 11:18:14.290538
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({
        "name": fields.String,
        "age": fields.Integer
    })
    result, error_messages = validate_yaml("""name: John\nage: 25\n""", schema)
    assert result == {'name': 'John', 'age': 25}
    assert error_messages == [] 
    result, error_messages = validate_yaml("""name: John\nage: twenty-five\n""", schema)
    assert result == {'name': 'John', 'age': 'twenty-five'}
    assert error_messages == [
        {'text': 'Must be an integer.', 'type': 'invalid', 'position': None, 'code': 'type_error.integer'}
    ] 

# Generated at 2022-06-24 11:18:15.334374
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("hi\nthere") == "hi\nthere"



# Generated at 2022-06-24 11:18:27.384102
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
number: 123
float: 3.14
text: A string
array:
    - 1
    - 2
    - 3
    - array:
          - 1.1
          - 2.1
          - 3.1
          - text: Text inside array
          - bool: true
          - null: null
    - bool: true
    - null: null
dict:
    one: 1
    two: 2
    three: 3
""")
    assert isinstance(token, DictToken)

    number = token["number"]
    assert isinstance(number, ScalarToken)
    assert number.value == 123

    float = token["float"]
    assert isinstance(float, ScalarToken)
    assert float.value == 3.14

    text = token["text"]
    assert isinstance

# Generated at 2022-06-24 11:18:33.222552
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    expected_output = DictToken({'key1': 1, 'key2': 'abc', 'list': [1, 2, 3, 4]}, 0, 0, content=None)
    content = """
    key1: 1
    key2: abc
    list: [1, 2, 3, 4]
    """
    output = tokenize_yaml(content)

    assert expected_output == output



# Generated at 2022-06-24 11:18:39.478392
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == {}
    assert tokenize_yaml(" ") == {}
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("""
    a: 1
    b:
      c: 2
      d: 3
    """)

    with pytest.raises(ValidationError):
        assert tokenize_yaml("{a: 1")




# Generated at 2022-06-24 11:18:46.747575
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    def check_token(
        content: typing.Union[str, bytes],
        expected_token: typing.Union[Token, ParseError],
    ) -> None:
        try:
            token = tokenize_yaml(content)
        except ParseError as exc:
            assert isinstance(expected_token, ParseError)
            assert exc.code == expected_token.code
            assert exc.text == expected_token.text
            assert exc.position.line_no == expected_token.position.line_no
            assert exc.position.column_no == expected_token.position.column_no
            assert exc.position.char_index == expected_token.position.char_index
        else:
            assert token == expected_token


# Generated at 2022-06-24 11:18:53.176715
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem.field import String
    from typesystem.tokenize.tokens import DictToken

    value, messages = validate_yaml(b"name: John Doe", validator=String)
    assert value is not None
    assert len(messages) == 0
    assert isinstance(value, DictToken)
    assert value.get("name", None) == "John Doe"



# Generated at 2022-06-24 11:19:02.378154
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Function should be able to parse YAML string correctly
    token = tokenize_yaml('name: "abc"')
    assert isinstance(token, DictToken)
    assert isinstance(token['name'], ScalarToken)
    assert token['name'].value == 'abc'
    token = tokenize_yaml('[1, 2, 3]')
    assert isinstance(token, ListToken)
    assert token[0].value == 1
    assert token[1].value == 2
    assert token[2].value == 3
    # Exception handling
    with pytest.raises(ParseError):
        tokenize_yaml('name: "abc')

    

# Generated at 2022-06-24 11:19:13.332045
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String

    class TestSchema(Schema):
        name = String()
        age = Integer()

    TestSchema()

    content = """\
name: "Amit"
age: 23
"""
    value, error_messages = validate_yaml(content=content, validator=TestSchema)
    assert error_messages == []
    assert value == {"name": "Amit", "age": 23}

    content = """\
name: "Amit"
age: "24"
"""

    value, error_messages = validate_yaml(content=content, validator=TestSchema)
    errors = [
        Message(text="Must be an integer.", code="type_error", position=Position(line_no=3, column_no=5, char_index=23)),
    ]

# Generated at 2022-06-24 11:19:25.071745
# Unit test for function validate_yaml
def test_validate_yaml():
    # Valid content
    valid_content = """
        name: Jane Smith
        age: 42
        """
    schema = Schema(
        {
            "name": str,
            "age": int,
        }
    )
    (result, errors) = validate_yaml(valid_content, schema)
    assert (result.name, result.age) == ('Jane Smith', 42)
    assert errors is None

    # Invalid content
    invalid_content = """
        name: Jane Smith
        age: forty two
        """
    schema = Schema(
        {
            "name": str,
            "age": int,
        }
    )
    (_, errors) = validate_yaml(invalid_content, schema)

# Generated at 2022-06-24 11:19:34.753154
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test for valid YAML
    valid_yaml = """
    - 1
    - 2
    - 3
    """
    # Test for invalid YAML
    invalid_yaml = """
    - 1
    - 2
    3
    """
    # Test for empty string
    empty_string = ""

    # Expected result for valid YAML
    expected_valid_yaml = ListToken([1, 2, 3], start=4, end=15, content=valid_yaml)
    # Expected result for invalid YAML
    expected_invalid_yaml = ParseError(
        text="expected <block end>, but found '-'.",
        code="parse_error",
        position=Position(column_no=5, line_no=5, char_index=17),
    )
    # Expected

# Generated at 2022-06-24 11:19:42.503039
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test cases for typesystem.tokenize.yaml
    """
    class User(Schema):
        id = Field(type="integer")
        name = Field(type="string")

    input_content = b"""{
        "id": 123,
        "name": "Test"
    }"""
    assert validate_yaml(input_content, User) == ({"id": 123, "name": "Test"}, [])

    input_content = """{
        "id": 123
    }"""

# Generated at 2022-06-24 11:19:53.002115
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('key: value') == DictToken({"key": "value"}, 0, 10, content='key: value')
    assert tokenize_yaml('key: "value"') == DictToken({"key": "value"}, 0, 11, content='key: "value"')
    assert tokenize_yaml('key: - value') == DictToken({"key": ["value"]}, 0, 11, content='key: - value')
    assert tokenize_yaml('[1, 2, 3]') == ListToken([1, 2, 3], 0, 7, content='[1, 2, 3]')
    assert tokenize_yaml('value') == ScalarToken('value', 0, 5, content='value')

# Generated at 2022-06-24 11:20:00.906407
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        fieldi = "integer"
        fieldj = "string"

    assert validate_yaml(
        """
fieldi: 1
fieldj: "hello"
""",
        validator=TestSchema,
    ) == (
        {"fieldi": 1, "fieldj": "hello"},
        [],
    )

    assert validate_yaml(
        """
fieldi: 1
fieldj: "hello"
""",
        validator=TestSchema,
    ) == (
        {"fieldi": 1, "fieldj": "hello"},
        [],
    )


# Generated at 2022-06-24 11:20:05.588639
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem import String, Integer

    class Person(Schema):
        name = String
        age = Integer

    yaml_content = """
        name: Jane Doe
        age: 42
    """

    token = tokenize_yaml(yaml_content)
    assert token.value == {'name': 'Jane Doe', 'age': 42}



# Generated at 2022-06-24 11:20:15.490249
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema): 
        Batch = Field(key='batch', format='b')
        C = Field(key='c', format='c')
        D = Field(key='d', format='d')
        E = Field(key='e', format='e')
        F = Field(key='f', format='f')
        G = Field(key='g', format='g')
        H = Field(key='h', format='h')
        I = Field(key='i', format='i')
        J = Field(key='j', format='j')
        K = Field(key='k', format='k')
        L = Field(key='l', format='l')
        M = Field(key='m', format='m')
        N = Field(key='n', format='n')

# Generated at 2022-06-24 11:20:21.641474
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    from typesystem.schemas import Schema

    content =    """
    - name: Alice
      city: New York
    - name: Bob
      city: London
    """

    class Person(Schema):
        name = String()

    class City(Schema):
        name = String()

    person_validator = Person()

    print(validate_yaml(content, person_validator))

# Generated at 2022-06-24 11:20:23.656512
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(field_type=int)
    value, errors = validate_yaml(b"- 1", field)

    assert not errors

# Generated at 2022-06-24 11:20:32.453837
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("foo"), ScalarToken)
    assert tokenize_yaml("foo").value == "foo"
    assert tokenize_yaml("123").value == 123
    assert tokenize_yaml("{foo: bar}") == {"foo": "bar"}
    assert tokenize_yaml("{foo: 123, baz: true}") == {"foo": 123, "baz": True}
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.5") == 1.5
    assert tokenize_y

# Generated at 2022-06-24 11:20:40.540327
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_content = '''
    key1: value
    key2:
      - value1
      - value2
      -
        key3: value3
    '''
    token = tokenize_yaml(str_content)
    assert isinstance(token, DictToken)
    assert len(token) == 2
    assert token["key1"].raw_value == "value"
    assert token["key2"].raw_value == ["value1", "value2", {"key3": "value3"}]
    assert token["key2"][0].raw_value == "value1"
    assert token["key2"][1].raw_value == "value2"
    assert token["key2"][2].raw_value == {"key3": "value3"}

# Generated at 2022-06-24 11:20:47.394348
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Example validator
    """
    class Registry(Schema):
        title = validators.String()
        container_num = validators.Integer()

    class Form(Schema):
        registry = validators.Nested(Registry)

    # In the case of a successful validation
    form_data = """
    registry:
        title: "Titre"
        container_num: 12
    """
    value, error_messages = validate_yaml(form_data, Form)
    assert value == {
        "registry": {
            "title": "Titre",
            "container_num": 12
        }
    }
    assert error_messages == []

    # In the case of an error in validation