

# Generated at 2022-06-24 11:10:52.718155
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields=[
        Field(name='name', type_='string'),
        Field(name='age', type_='integer'),
        Field(name='hobbies', type_=ListToken)
    ])
    content = '''
name: "Tom"
age: "20"
hobbies:
    - handball
    - skiing
    - chess
    - karate
'''
    value, error_messages = validate_yaml(content, schema)
    assert isinstance(value, DictToken)
    assert isinstance(error_messages, list)
    assert len(error_messages) == 1
    assert isinstance(error_messages[0], ValidationError)
    assert not error_messages[0].position.column_no  # Check that position is correctly calculated
    assert not error_messages

# Generated at 2022-06-24 11:11:04.499088
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    string1 = "foo: 1"
    token1 = tokenize_yaml(string1)
    assert isinstance(token1, DictToken)
    assert token1.value == {"foo": 1}

    string2 = "foo: 1\nbar: true"
    token2 = tokenize_yaml(string2)
    assert isinstance(token2, DictToken)
    assert token2.value == {"foo": 1, "bar": True}

    string3 = ("foo:\n"
               "  - a\n"
               "  - b")
    token3 = tokenize_yaml(string3)
    assert isinstance(token3, DictToken)
    assert isinstance(token3.value["foo"], ListToken)
    assert token3.value["foo"].value == ["a", "b"]

   

# Generated at 2022-06-24 11:11:14.488752
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.tokens import DictToken, ListToken
    from typesystem.fields import String, Integer

    yaml_string = """
    one: 1
    two: 2
    three:
        - 3
        - 4
        - 5
    """
    token = tokenize_yaml(yaml_string)

    # Assert the parsed type is a dict.
    assert isinstance(token, DictToken)

    # Assert that the dict contents are expected.
    assert token["one"].value == 1
    assert token["two"].value == 2
    assert isinstance(token["three"], ListToken)
    assert token["three"].value == [3, 4, 5]

    # Assert that the error message

# Generated at 2022-06-24 11:11:26.515228
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Test tokenize with a scalar value.
    token = tokenize_yaml("'hello'")
    assert isinstance(token, ScalarToken)
    assert token.value == "'hello'"
    assert token.index == 0
    assert token.end_index == 6

    # Test tokenize with a list value.
    token = tokenize_yaml("- item")
    assert isinstance(token, ListToken)
    assert token[0].value == "item"
    assert token.index == 0
    assert token.end_index == 5

    # Test tokenize with a mapping value.
    token = tokenize_yaml("name: item")
    assert isinstance(token, DictToken)
    assert token["name"].value == "item"


# Generated at 2022-06-24 11:11:35.559917
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test empty string case
    assert tokenize_yaml("") == ScalarToken(None, char_index=0, content="")
    assert tokenize_yaml(" ") == ScalarToken(None, char_index=0, content=" ")

    # test basic string cases
    assert tokenize_yaml("asdf") == ScalarToken("asdf", char_index=0, content="asdf")
    assert tokenize_yaml("\"asdf\"") == ScalarToken("asdf", char_index=0, content="\"asdf\"")
    assert tokenize_yaml(
        "as\ndf"
    ) == ScalarToken("as\ndf", char_index=0, content="as\ndf")

    # test empty objects

# Generated at 2022-06-24 11:11:41.155712
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        fields={
            "name": Field(types=[str], required=True),
            "age": Field(types=[int], required=False),
        }
    )
    assert validate_yaml(b'{name: "maria"}', schema) == (
        {'name': u'maria'},
        [],
    )


# Generated at 2022-06-24 11:11:43.115203
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema("string")
    errors = validate_yaml("test", schema)
    assert errors is None

# Generated at 2022-06-24 11:11:51.425327
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        field_a = Field(required=True)
        field_b = Field(required=True, max_length=5)
        field_c = Field(required=True, choices=["a", "b", "c"])
        field_d = Field(required=True, min_items=1)
        field_e = Field(required=True, item=Field(min_length=1))

    content = "\n".join(
        [
            "field_a: 1",
            "field_b: 12345",
            "field_c: c",
            "field_d: [1, 2, 3]",
            "field_e: [a, b, c]",
        ]
    )

# Generated at 2022-06-24 11:11:58.124410
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String

    content = "hello"
    assert validate_yaml(content, String()) == (content, [])

    content = "hello\nworld\n"
    assert validate_yaml(content, String()) == (content, [])

    content = "hello\nworld\n"
    assert validate_yaml(content, String(min_length=5)) == (content, [])

    content = "\u2713"  # checkmark
    assert validate_yaml(content, String()) == (content, [])

    content = b"hello"
    assert validate_yaml(content, String()) == ("hello", [])

    content = b"\xc3\xa1"
    assert validate_yaml(content, String()) == ("á", [])

    content = b"hello\nworld\n"


# Generated at 2022-06-24 11:12:06.889393
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ScalarToken(None, 0, -1, content="")
    assert tokenize_yaml("42") == ScalarToken(42, 0, 1, content="42")
    assert tokenize_yaml("3.14") == ScalarToken(3.14, 0, 3, content="3.14")
    assert tokenize_yaml("yes") == ScalarToken(True, 0, 2, content="yes")
    assert tokenize_yaml("no") == ScalarToken(False, 0, 1, content="no")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")

# Generated at 2022-06-24 11:12:15.827898
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("1.0e5") == 1.0e5
    assert tokenize_yaml("~") == None
    assert tokenize_yaml("""
    - 1
    - 2
    - 3
    """) == [1, 2, 3]
    assert tokenize_yaml("""
    - 1
    - 2
    - 3
    - [4, 5, 6]
    """) == [1, 2, 3, [4, 5, 6]]

# Generated at 2022-06-24 11:12:16.773026
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("1", Field(type=int)) == 1


# Generated at 2022-06-24 11:12:26.834495
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import pytest
    from typesystem import String
    content = "content"
    result = tokenize_yaml(content)
    assert isinstance(result, ScalarToken) and result.value == content
    result = tokenize_yaml("42")
    assert isinstance(result, ScalarToken) and result.value == 42
    result = tokenize_yaml("42.5")
    assert isinstance(result, ScalarToken) and result.value == 42.5
    result = tokenize_yaml("[1, 2, 3]")
    assert isinstance(result, ListToken) and result.value == [1, 2, 3]
    result = tokenize_yaml("{a: 1}")
    assert isinstance(result, DictToken) and result.value == {"a": 1}

# Generated at 2022-06-24 11:12:29.917790
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('{"name": 123}',  {"name": "string"}) == ({'name': 123}, {'name': "value is not a valid string"})


# Code for custom yaml Dumper


# Generated at 2022-06-24 11:12:36.726382
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    content = b'key1: "value1"\nkey2: value2\nkey3:\n  - subval1\n  - subval2\n'
    validator = Schema({"key1": str, "key2": str})
    value, errors = validate_yaml(content=content, validator=validator)
    assert value == {
        "key1": "value1",
        "key2": "value2",
    }
    assert len(errors) == 1
    error1 = errors[0]
    assert error1.source == "root"
    assert error1.code == "missing_field"
    assert error1.text == f"Missing required field 'key3'."

# Generated at 2022-06-24 11:12:44.512548
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_str = """
    foo: bar
    baz:
        - "one"
        - two
        - 3
    """
    try:
        class MySchema(Schema):
            foo = Field(description="a foo")
            baz = Field(items=Field())
    except NameError:
        pass
    else:
        valid, errors = validate_yaml(yaml_str, MySchema)
        assert valid == {
            "foo": "bar",
            "baz": ["one", "two", 3],
        }
        assert isinstance(errors, list)
        message = errors[0]
        assert isinstance(message, Message)

# Generated at 2022-06-24 11:12:53.906344
# Unit test for function validate_yaml
def test_validate_yaml():
    # Simple test which expects no errors
    validator = Field(type="integer")
    result = validate_yaml(content="42", validator=validator)
    assert result == (42, [])

    # Expected error
    validator = Field(type="integer")
    result = validate_yaml(content="'42'", validator=validator)
    assert result == (None, [ValidationError(code="invalid_type", field_name=None,
                                                text="Invalid type. Expected 'integer' but got 'string'.",
                                                position=Position(0, 1, 1), validator=validator)])

 

# Generated at 2022-06-24 11:13:04.137727
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("v1: 1"), DictToken)
    assert isinstance(tokenize_yaml("- 1"), ListToken)
    assert isinstance(tokenize_yaml("v1: 1; v2: 2"), DictToken)
    assert isinstance(tokenize_yaml("'1'"), ScalarToken)
    assert isinstance(tokenize_yaml("'1'; '2'"), ListToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("1; 2"), ListToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("true; false"), ListToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)


# Generated at 2022-06-24 11:13:09.874427
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml('foo'), ScalarToken)
    assert isinstance(tokenize_yaml('[1, 2]'), ListToken)
    assert isinstance(tokenize_yaml('{a:1}'), DictToken)
    assert tokenize_yaml('{a:1}').start == 0
    assert tokenize_yaml('{a:1}').end == 4


# Generated at 2022-06-24 11:13:21.119989
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test_yaml_str = """
    -
      anchor: 'test'
      color: blue
    - color: red
    -
      - color: green
      - color: black
      - color: white
        anchor: 'null'
    """
    one = DictToken({"anchor": "test", "color": "blue"}, 0, 40, content=test_yaml_str)
    two = DictToken({"color": "red"}, 50, 58, content=test_yaml_str)
    three_one = DictToken({"color": "green"}, 66, 77, content=test_yaml_str)
    three_two = DictToken({"color": "black"}, 83, 93, content=test_yaml_str)

# Generated at 2022-06-24 11:13:30.913873
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test the validate_yaml function."""
    # Test with Schema
    schema = Schema([
        ('test', datetime.date),
        ('test2', typing.List[int]),
        ('test3', str)
    ])
    value, error_messages = validate_yaml(
        content="test: 2020-10-14\ntest2: [1, 0, 4]\ntest3: hello",
        validator=schema
    )
    assert (value, error_messages) == ({
        'test': datetime.date(2020, 10, 14),
        'test2': [1, 0, 4],
        'test3': 'hello',
    }, [])


# Generated at 2022-06-24 11:13:35.907530
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from yaml import full_load
    content = """
    foo: True
    bar: 123
    """
    token = tokenize_yaml(content)
    assert full_load(content) == token
    assert token.start_index == 1
    assert token.end_index == 23



# Generated at 2022-06-24 11:13:40.101665
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test a basic YAML file with a simple key/value
    content = 'key: value'
    token = tokenize_yaml(content)
    assert token.keys() == ['key']
    assert token['key'] == 'value'


# Generated at 2022-06-24 11:13:49.921651
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test function validate_yaml()
    """
    class TestSchema(Schema):
        """
        A sample schema.
        """

        field1 = Field(type="string")
        field2 = Field(type="boolean")

    yaml_content = """
    field1: "TypeSystem is awesome"
    field2: false
    """
    value, errors = validate_yaml(content=yaml_content, validator=TestSchema)

    assert value is not None
    assert value["field1"] == "TypeSystem is awesome"
    assert value["field2"] is False
    assert not errors

# Generated at 2022-06-24 11:13:58.737048
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("[]") == ListToken([], 0, 1)
    assert tokenize_yaml('"foo"') == ScalarToken("foo", 0, 4)
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1)
    assert tokenize_yaml("1.1") == ScalarToken(1.1, 0, 3)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4)

# Generated at 2022-06-24 11:14:05.584225
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import ScalarToken
    from typesystem.tokenize.tokens import ListToken
    from typesystem.tokenize.tokens import DictToken
    from typesystem.base import Position
 
    content = """
        a:
          b:
            c: [foo, bar, baz]
            d:
              - e: f
              - g: h
        i: j
        k: [l, m, n] 
    """

    token = tokenize_yaml(content)

    assert type(token) == DictToken, "Should be a DictToken"

# Generated at 2022-06-24 11:14:07.148410
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('foo: 1')
    assert type(token) is DictToken


# Generated at 2022-06-24 11:14:19.196802
# Unit test for function validate_yaml
def test_validate_yaml():
    import pytest
    from typesystem.fields import Integer, String

    class TestField(Field):
        pass

    class TestSchema(Schema):
        field = TestField()

    class TestField2(Field):
        pass

    class TestSchema2(Schema):
        field = TestField2()

    class TestSchema3(Schema):
        field = TestField2()

    class TestSchema4(Schema):
        field = Integer()

    class TestSchema6(Schema):
        field = Integer()
        field1 = Integer()

    class TestSchema7(Schema):
        field = Integer()
        field1 = Integer()

    class TestSchema8(Schema):
        field = Integer()
        field1 = Integer()
        field2 = Integer()
        field3 = Integer()
        field

# Generated at 2022-06-24 11:14:27.313607
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()

    class Pig(Schema):
        id = String()
        name = String()

    class PigSchema(Schema):
        id = String()
        age = Integer(minimum=0, maximum=10)
        name = String()
        friendly = Boolean()
        owner = Object(schema=Person)
        description = String(enum=["a", "b", "c"])

    yaml_string = """
    id: pig1
    age: 3
    name: Mr. Piggy
    friendly: true
    owner:
        name: Mrs. Piggy
    description: a
    """

    data, error_messages = validate_yaml(yaml_string, validator=PigSchema)

# Generated at 2022-06-24 11:14:34.700498
# Unit test for function validate_yaml
def test_validate_yaml():

    class MySchema(Schema):
        name = "string"
        age = "integer"
        favorite_color = "string"

    # This content fails to validate
    content = "name: John Doe\nage: \"30\"\nfavorite_color: blue\n"
    value, error_messages = validate_yaml(content, MySchema)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].code == "invalid"
    assert error_messages[0].position.line_no == 2
    assert error_messages[0].position.column_no == 5

    # This content succeeds
    content = "name: John Doe\nage: 30\nfavorite_color: blue\n"

# Generated at 2022-06-24 11:14:42.994383
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Given
    expected_result = {
        "name": "John",
        "age": 30,
        "cars": [
            {"name": "Ford", "models": ["Fiesta", "Focus", "Mustang"]},
            {"name": "BMW", "models": ["320", "X3", "X5"]},
            {"name": "Fiat", "models": ["500", "Panda"]},
        ],
    }
    content = '''
    cars:
      - name: Ford
        models:
          - Fiesta
          - Focus
          - Mustang
      - name: BMW
        models:
          - 320
          - X3
          - X5
      - name: Fiat
        models:
          - 500
          - Panda
    name: John
    age: 30
    '''
    # When
    result

# Generated at 2022-06-24 11:14:53.142423
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content='', validator=Schema) == ({}, [])
    assert validate_yaml(content='{}', validator=Schema) == ({}, [])

    assert validate_yaml(content='["this", "valid"]', validator=Schema) == (
        {"value": ["this", "valid"]},
        [],
    )

    messages = validate_yaml(content='["that", "invalid"]', validator=Schema)[1]
    assert len(messages) == 2
    assert messages[0].code == "required_field"
    assert messages[0].text == "The 'required' field is required."

    assert messages[1].code == "required_field"
    assert messages[1].text == "The 'required' field is required."

# Generated at 2022-06-24 11:15:05.343692
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content=b"1", validator=int) == (1, [])
    assert validate_yaml(content=b"1.0", validator=float) == (1.0, [])
    assert validate_yaml(content=b"true", validator=bool) == (True, [])
    assert validate_yaml(content=b"false", validator=bool) == (False, [])
    assert validate_yaml(content=b"null", validator=str) == (None, [])


# Generated at 2022-06-24 11:15:06.341595
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    pass


# Generated at 2022-06-24 11:15:16.561567
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml function.
    """
    class User(Schema):
        username = Field(type="string")
        email = Field(type="string", format="email")

    content = """\
        username: aasdf
        email: aasdf@example.com
    """
    value, messages = validate_yaml(content, User)
    assert value["username"] == "aasdf"
    assert value["email"] == "aasdf@example.com"
    assert not messages

    content = """\
        username: aasdf
        email: aasdf@
    """
    value, messages = validate_yaml(content, User)
    assert value["username"] == "aasdf"
    assert value["email"] == "aasdf@"

# Generated at 2022-06-24 11:15:22.483622
# Unit test for function validate_yaml
def test_validate_yaml():
    import io
    import sys
    from typesystem.fields import String
    from typesystem.tokenize.positional_validation import MessagePrinter
    from typesystem.tokenize.tokens import ListToken
    from typesystem.tokenize.validation import validate, ValidationError
    from yaml import load, scan, parser

    class ExampleSchema(Schema):
        title = String(min_length=3)
        dates = String(format="date")

    content = """
    title: Example
    dates:
        - tomorrow
        - yesterday
    """

    # Correctly validates content.
    value, errors = validate_yaml(content, validator=ExampleSchema)
    assert errors == []
    assert value == {
        "title": "Example",
        "dates": ["tomorrow", "yesterday"],
    }

# Generated at 2022-06-24 11:15:24.225724
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = typing.Type[Schema]
    content = typing.Union[str, bytes]
    validate_yaml(content, validator)

# Generated at 2022-06-24 11:15:34.586490
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "1.0"
    validator = Field(type_name="number")
    value, error_messages = validate_yaml(content, validator)
    assert value == 1.0

    content = "1.0"
    validator = Field(type_name="string")
    try:
        value, error_messages = validate_yaml(content, validator)
    except ValidationError as exc:
        assert error_messages is not None

    content = "A"
    validator = Field(type_name="string", pattern="B")
    try:
        value, error_messages = validate_yaml(content, validator)
    except ValidationError as exc:
        assert error_messages is not None

    content = "A"

# Generated at 2022-06-24 11:15:39.122894
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    """
    schema = Schema(properties={"a": {"type": "number"}})
    value, error_messages = validate_yaml(content=content, validator=schema)
    assert error_messages == []
    assert value["a"] == 1



# Generated at 2022-06-24 11:15:49.500082
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    res = tokenize_yaml("""
a: b
c: d
1: 2
""")
    assert isinstance(res, DictToken)
    assert len(res._value) == 3
    for key, value in res._value.items():
        assert isinstance(key, ScalarToken)
        assert isinstance(value, ScalarToken)
    assert res._start == 0
    assert res._end == 14
    assert res.content == """
a: b
c: d
1: 2
"""

    res = tokenize_yaml("""
- a
-
- b
""")
    assert isinstance(res, ListToken)
    assert len(res._value) == 3
    for item in res._value:
        assert isinstance(item, ScalarToken)
    assert res._start == 0

# Generated at 2022-06-24 11:15:58.982206
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    test: [{"baz": "buz"}, "buz"]
    """
    validator = Schema([{"test": [str]}])

    value, error_messages = validate_yaml(content, validator)
    assert value == {"test": [{"baz": "buz"}, "buz"]}

    content = """
    test:
        - "buz"
        - baz
    """
    value, error_messages = validate_yaml(content, validator)
    assert len(error_messages) == 1
    assert error_messages[0].position.column_no == 8



# Generated at 2022-06-24 11:16:09.587912
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    result = validate_yaml(
        Person(),
        """
        name: Paul
        age: 28
        """,
    )

    assert result == (
        {'name': 'Paul', 'age': 28},
        None,
    )

    result = validate_yaml(
        Person(),
        """
        name: Paul
        age: "28"
        """,
    )

    assert isinstance(result[1], Message)
    assert result[1].code == "invalid_type"
    assert result[1].position == Position(line_no=3, column_no=5, char_index=23)


# Generated at 2022-06-24 11:16:14.434415
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):

        """
        I define the person name as a scalar string,
        with a minimum length of 3 characters,
        and a maximum length of 10 characters.
        """
        name = String(min_length=3, max_length=10)

    content = """
    name: Mike
    """
    
    expectedResult = ({'name': 'Mike'}, [])

    result = validate_yaml(content, PersonSchema)

    assert result == expectedResult

# Generated at 2022-06-24 11:16:18.868827
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    a: A
    b: B
    '''

    values = validate_yaml(
        content,
        {
            "a": str,
            "b": str,
        },
    )

    assert values == ({"a": "A", "b": "B"}, [])



# Generated at 2022-06-24 11:16:26.782974
# Unit test for function validate_yaml
def test_validate_yaml():
    # test with validator
    content = "name: tyepsystem"
    assert validate_yaml(content, validator=Field(type="string")) == (
        content,
        [],
    )
    # test with schema class
    content = "name: tyepsystem"
    class UserSchema(Schema):
        name = Field(type="string")
    assert validate_yaml(content, validator=UserSchema) == (
        {'name': 'tyepsystem'},
        [],
    )
    # test with invalid format
    content = "name: tyepsystem"
    class UserSchema(Schema):
        name = Field(type="string", min_length=20)

# Generated at 2022-06-24 11:16:30.028566
# Unit test for function validate_yaml
def test_validate_yaml():
    assert (
        validate_yaml(
            content='field: value',
            validator=Schema({"field": "string"}),
        )
        ==
        (
            {'field': 'value'},
            []
        )
    )

# Generated at 2022-06-24 11:16:35.288857
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    token = tokenize_yaml('{"foo": "bar"}')
    assert token.start_position.__dict__ == {'line_no': 1, 'column_no': 1, 'char_index': 0}
    assert token.end_position.__dict__ == {'line_no': 1, 'column_no': 16, 'char_index': 15}
    assert token.value == {'foo': 'bar'}



# Generated at 2022-06-24 11:16:45.592078
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer
    from typesystem.fields import EnumField
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        gender = EnumField(enum=["male", "female"])

    try:
        validate_yaml(
            """\
name: John Doe
age: 42
gender: male""",
            Person,
        )
    except ValidationError as exc:
        assert False, exc.messages


# Generated at 2022-06-24 11:16:49.623322
# Unit test for function validate_yaml
def test_validate_yaml():
    with pytest.raises(AssertionError):
        validate_yaml('', 'field')
    response = validate_yaml('a: 1', 'field')
    assert response == None


# Generated at 2022-06-24 11:17:01.042254
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test_dict = {"a": 1, "b": 2, "c": [3, 4, 5], "d": {"e": 6, "f": [7, 8, 9]}}
    assert tokenize_yaml("a: 1\nb: 2\nc:\n- 3\n- 4\n- 5\nd:\n  e: 6\n  f:\n  - 7\n  - 8\n  - 9") == test_dict
    assert tokenize_yaml("{a:1,b:2,c:[3,4,5],d:{e:6,f:[7,8,9]}}") == test_dict

# Generated at 2022-06-24 11:17:11.524792
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem
    import datetime
    import yaml
    test_schema = typesystem.Schema(
        properties=[
            typesystem.String(
                name="email", constraints=[typesystem.format.email()]
            ),
            typesystem.String(name="password", minimum_length=8),
            typesystem.Dict(
                name="user",
                properties=[
                    typesystem.Integer(name="id", minimum=1),
                    typesystem.String(name="name"),
                ],
            ),
        ]
    )
    content = """
    email: ed@example.com
    password: 12345678
    user:
      id: 1
      name: ed
    """

    # Validating a YAML string
    value, errors = validate_yaml(content, test_schema)

# Generated at 2022-06-24 11:17:20.164192
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""
    user:
      name: User One
      password: foo
    """
    Query = validator_for(
        {
            "user": {
                "name": str,
                "password": {"type": str, "min_length": 8},
            }
        },
    )
    value, errors = validate_yaml(content, Query)
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 12
    assert errors[0].position.char_index == 27
    assert errors[0].text == 'Must have at least 8 characters.'
    assert errors[0].code == 'min_length'

# Generated at 2022-06-24 11:17:23.268571
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    print("test_tokenize_yaml")
    content = '{"name":"darshan","password":"1234"}'
    tokenize_yaml(content)
    
test_tokenize_yaml()

# Generated at 2022-06-24 11:17:34.718489
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Boolean, Integer
    from typesystem.schemas import create_schema
    from typesystem.tokenize.positional_validation import validate_with_positions
    # Success case
    yaml = "---\n- True\n- False\n"
    schema = create_schema({"items": [Boolean(), Integer()]})
    value, errors = validate_yaml(yaml, schema)
    assert value == [True, 0]
    assert len(errors) == 0
    # Array of invalid items
    yaml = "---\n- True\n- two\n"
    value, errors = validate_yaml(yaml, schema)
    assert value is None
    assert len(errors) == 1
    assert errors[0].position.char_index == 13


# Generated at 2022-06-24 11:17:44.280671
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert (
        tokenize_yaml("foo: bar")
        == {"foo": ScalarToken("bar", 0, 8, content="foo: bar")}
    )
    assert (
        tokenize_yaml("foo: [bar, baz]")
        == {
            "foo": ListToken(
                [
                    ScalarToken("bar", 5, 9, content="foo: [bar, baz]"),
                    ScalarToken("baz", 11, 15, content="foo: [bar, baz]"),
                ],
                0,
                17,
                content="foo: [bar, baz]",
            )
        }
    )

# Generated at 2022-06-24 11:17:55.376096
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class Recipe(Schema):
        ingredients = String()
        servings = Integer(minimum=1, maximum=8)
        title = String(required=True)

    schema = Recipe()
    assert validate_yaml('title: Egg Salad\nservings: 4\ningredients:', schema) == (None, [Message(text='This field is required.', code='required', position=Position(char_index=12, column_no=3, line_no=2))])
    assert validate_yaml('title: Egg Salad\nservings: 4\ningredients:\n- eggs', schema) == ({'servings': 4, 'ingredients': '- eggs', 'title': 'Egg Salad'}, [])

# Generated at 2022-06-24 11:17:59.941648
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Schema

    class Item(Schema):
        name = String()

    errors = validate_yaml(
        content='{"name": "John"}',
        validator=Item
    )

    assert(errors == ({"name": "John"}, []))

# Generated at 2022-06-24 11:18:04.921866
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "test: invalid"
    validator = Field(type="string")

    value, error_messages = validate_yaml(content, validator)

    assert value is None
    assert isinstance(error_messages, list)
    assert len(error_messages) == 1
    assert error_messages[0].text == "Value did not match a required type."
    assert error_messages[0].position.char_index == 5



# Generated at 2022-06-24 11:18:15.545585
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Positive testing with dict
    assert tokenize_yaml(b'{"a": "b"}') == {'a': 'b'}
    assert tokenize_yaml(b'{"a": "b", "c": 1, "d": [1, 2, 3]}') == {'a': 'b', 'c': 1, 'd': [1, 2, 3]}
    assert tokenize_yaml(b'{"a": [1, 2, {"b": "c", "d": 1, "e": [1, 2, 3]}]}') == {'a': [1, 2, {'b': 'c', 'd': 1, 'e': [1, 2, 3]}]}

    # Positive testing with list
    assert tokenize_yaml(b'- a\n- b') == ['a', 'b']
    assert token

# Generated at 2022-06-24 11:18:27.512807
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        attr = Field(type="string", required=True)

    content = """
    attr : this!
    """
    result, error_messages = validate_yaml(content=content, validator=TestSchema)
    assert result is None

# Generated at 2022-06-24 11:18:38.116057
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {
            "name": "string",
            "age": "integer",
            "taco": "tacoschema"
        },
        converters={
            "string": str,
            "integer": int,
            "float": float,
            "boolean": bool,
        },
    )

    class TacoSchema(Schema):
        name = "string"
        taco = "string"

    class PersonSchema(Schema):
        name = "string"
        age = "integer"

    schema.set_fields({"taco": TacoSchema})

    validator = PersonSchema
    content = """\
---
name: Bob
age: 29
taco:
  name: taco bell
  taco: yes
time: 3
"""


# Generated at 2022-06-24 11:18:43.508675
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    tokenize_yaml("")
    tokenize_yaml("   \n   \t ")
    tokenize_yaml("hello")
    tokenize_yaml("hello: world")
    tokenize_yaml(b"hello: world")

    with pytest.raises(ParseError):
        tokenize_yaml("-")
        tokenize_yaml("- foo")
        tokenize_yaml("- - foo")
        tokenize_yaml("- - foo:")



# Generated at 2022-06-24 11:18:49.635011
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        year = Field(type="integer")
        name = Field(type="string")
        is_active = Field(type="boolean", required=False)

    value, error_messages = validate_yaml(
        "year: 2015\nname: Foo\nis_active: no\n",
        validator=TestSchema,
    )

    assert value == {"year": 2015, "name": "Foo", "is_active": False}
    assert error_messages == []

    value, error_messages = validate_yaml(
        "year: 2015\nis_active: no\n", validator=TestSchema
    )

    assert value == {"year": 2015, "is_active": False}

# Generated at 2022-06-24 11:18:57.759289
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("[]") == ListToken([], 0, 1)
    assert tokenize_yaml("[1, 2, 3]") == ListToken([1, 2, 3], 0, 8)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3)

# Generated at 2022-06-24 11:19:06.805721
# Unit test for function validate_yaml
def test_validate_yaml():
    content='''
    test:
        test2:
            - [james, 2, 3]
            - [james, 2]
            - [james, 2]
    '''
    class TestSchema(Schema):
        test = ListField(TextField())
        test2 = ListField(ListField(TextField()))
    token = tokenize_yaml(content)
    (value, error_messages) = validate_with_positions(token=token, validator=TestSchema)
    assert error_messages[1].error_code == 'extra_items'
    assert error_messages[1].error_message== 'Extra items not allowed'
    assert error_messages[1].position.char_index == 163
    assert error_messages[1].position.line_no == 12

# Generated at 2022-06-24 11:19:13.238239
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String, Array, Schema

    yaml_string = """
    - 1
    - 2
    - 'nope'
    - 4
    """

    class MySchema(Schema):
        items = Array(items=Integer())

    value, errors = validate_yaml(yaml_string, MySchema)
    assert value == [1, 2, 4]
    assert len(errors) == 1
    assert errors[0].position.line_no == 3



# Generated at 2022-06-24 11:19:24.998487
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem import Boolean, Schema, String

    class Pet(Schema):
        name = String(max_length=10)
        age = String(max_length=3)
        species = String(max_length=10)
        available = Boolean()

    input_yaml = """
    - name: 'alice'
      age: '10'
      species: 'dog'
      available: null
    - name: 'bob'
      age: '5'
      species: 'cat'
      available: true
    """
    yaml_obj = yaml.load(input_yaml)
    _, error_messages = validate_yaml(input_yaml, Pet)
    assert len(error_messages) == 1

# Generated at 2022-06-24 11:19:27.854354
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    data = tokenize_yaml("{test : abc}")
    assert isinstance(data, DictToken)
    assert len(data)==1
    assert data["test"]=="abc"



# Generated at 2022-06-24 11:19:32.252171
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("null").value == None
    assert tokenize_yaml("true").value == True
    assert tokenize_yaml("false").value == False
    assert tokenize_yaml("3").value == 3
    assert tokenize_yaml("3.14").value == 3.14
    assert tokenize_yaml("hi").value == "hi"



# Generated at 2022-06-24 11:19:41.032757
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test for valid reading of yaml strings
    value, error_messages = validate_yaml("a: 1\nb: 2", Schema)
    assert isinstance(value, dict)
    assert value == {"a": "1", "b": "2"}
    assert error_messages == []

    value, error_messages = validate_yaml("1", Field(type="integer"))
    assert value == 1
    assert error_messages == []

    value, error_messages = validate_yaml("1.0", Field(type="float"))
    assert value == 1.0
    assert error_messages == []

    # Test for invalid reading of yaml strings
    value, error_messages = validate_yaml("a: 1\nb: 2", Field(type="integer"))
    assert isinstance(value, dict)


# Generated at 2022-06-24 11:19:46.963086
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("a: 1", {"a": int}) == ({"a": 1}, None)
    assert validate_yaml(b"a: 1", {"a": int}) == ({"a": 1}, None)
    assert validate_yaml("a: 1", {"a": str}) == (None, [
        Message("Value must be of type 'str'.", "invalid_type", Position(
            column_no=4, line_no=1, char_index=3,
        ))
    ])
    assert validate_yaml("a: 1", Field(str)) == (None, [
        Message("Value must be of type 'str'.", "invalid_type", Position(
            column_no=4, line_no=1, char_index=3,
        ))
    ])

# Generated at 2022-06-24 11:19:51.180061
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('{"one": "two"}')
    assert isinstance(token, DictToken)
    assert token.value["one"] == "two"
    assert token.start == 0
    assert token.end == 13
    assert token.content == '{"one": "two"}'


# Generated at 2022-06-24 11:19:59.600943
# Unit test for function validate_yaml
def test_validate_yaml():

    class AnimalSchema(Schema):
        name = Field(type=str, max_length=5)
        age = Field(type=int)
        alive = Field(type=bool, required=False)


    # Happy path: success
    result = validate_yaml(content = "name: cat\nage: 2", validator = AnimalSchema)
    assert result[1] == []


    # Sad path: ParseError
    result = validate_yaml(content = "name: cat\nage", validator = AnimalSchema)
    assert result[1][0].text == "Did not find expected ':' while scanning a simple key."


    # Sad path: ValidationError
    result = validate_yaml(content = "name: cat\nage: banana", validator = AnimalSchema)

# Generated at 2022-06-24 11:20:09.578526
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test basic scenarios
    token = tokenize_yaml("""
        ---
        foo: bar
        """)
    assert isinstance(token, DictToken)
    assert token.value["foo"] == "bar"
    assert token.start == 0
    assert token.end == 18

    # Test multi-line scenarios
    token = tokenize_yaml("""
        ---
        foo: bar
        baz: 
            - 1
            - 2
            - 3
        """)
    assert isinstance(token, DictToken)
    assert token.value["foo"] == "bar"
    assert token.value["baz"] == [1, 2, 3]
    assert token.start == 0
    assert token.end == 49



# Generated at 2022-06-24 11:20:10.709934
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(content='') == ''

# Generated at 2022-06-24 11:20:18.598190
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    token = tokenize_yaml("a:b")
    assert isinstance(token, DictToken)
    assert token.items() == {"a": "b"}
    assert str(token) == "DictToken(content='a:b', start=0, end=3)"

    token = tokenize_yaml("a: 1")
    assert isinstance(token, DictToken)
    assert token.items() == {"a": 1}
    assert str(token) == "DictToken(content='a: 1', start=0, end=4)"

    token = tokenize_yaml("a: 1.1")
    assert isinstance(token, DictToken)
    assert token.items() == {"a": 1.1}

# Generated at 2022-06-24 11:20:23.345049
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('') is None
    assert tokenize_yaml('true') == ScalarToken(True, 0, 3, content='true')
    assert tokenize_yaml('false') == ScalarToken(False, 0, 4, content='false')
    assert tokenize_yaml('1') == ScalarToken(1, 0, 1, content='1')
    assert tokenize_yaml('1.1') == ScalarToken(1.1, 0, 3, content='1.1')
    assert tokenize_yaml('null') == ScalarToken(None, 0, 4, content='null')
    assert tokenize_yaml('string') == ScalarToken('string', 0, 6, content='string')

# Generated at 2022-06-24 11:20:28.539296
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("{}", {"yaml": str}) == ({}, [])
    assert validate_yaml("{x: 1}", {"yaml": str}) == ({"x": "1"}, [])
    assert validate_yaml("[1, 2, 3]", [str]) == (["1", "2", "3"], [])
#------------------------------------



# Generated at 2022-06-24 11:20:39.649771
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = fields.String(required=True)
        # the optional fields are non-optional by default
        age = fields.String()
        sex = fields.String(required=False)

    # test valid YAML content
    content = """
        name: John
        age: 30
    """
    result, err_msgs = validate_yaml(content, PersonSchema)
    assert len(err_msgs) == 0
    assert result == {
        "name": "John",
        "age": "30",
        "sex": None,
    }

    # test invalid YAML content
    content = """
        name: John
        other
    """
    _, err_msgs = validate_yaml(content, PersonSchema)
    assert len(err_msgs)

# Generated at 2022-06-24 11:20:43.262751
# Unit test for function validate_yaml
def test_validate_yaml():
    # Create yaml example
    yaml = """
    - 1
    - 2
    - 3
    """
    # Import validator
    from typesystem import Integer, Array
    # Assert validator
    assert validate_yaml(yaml, Array(items=Integer())) == ([1, 2, 3], [])