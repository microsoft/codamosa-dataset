

# Generated at 2022-06-22 06:18:42.757392
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    content = """
    key_a: val_a
    key_b: val_b
    """
    schema_class = typing.TypeVar("schema_class", bound=Schema)
    field = String(required=True)
    assert validate_yaml(content=content, validator=field) == (tokenize_yaml(content), [])
    schema_class = typing.TypeVar("schema_class", bound=Schema)
    assert validate_yaml(content=content, validator=schema_class) == (tokenize_yaml(content), [])
    content = """
    key_a: val_a
    key_b:
    """

# Generated at 2022-06-22 06:18:49.934393
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test parsing a string with minimal content
    token = tokenize_yaml("value: 1")
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == len("value: 1") - 1

    # Test parsing a string with minimal content
    token = tokenize_yaml("[]")
    assert isinstance(token, ListToken)
    assert token.start == 0
    assert token.end == len("[]") - 1

    # Test parsing a string with minimal content
    token = tokenize_yaml("a")
    assert isinstance(token, ScalarToken)
    assert token.start == 0
    assert token.end == len("a") - 1

    # Test parsing an integer
    token = tokenize_yaml("1")
    assert isinstance(token, ScalarToken)


# Generated at 2022-06-22 06:18:59.747810
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # testing comment (parsing error with parser)
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml("# comment")
    assert excinfo.value.text == "could not found expected '<document start>'".capitalize()

    # testing empty string
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml("")
    assert excinfo.value.text == "No content."

    # testing empty array (parsing error with parser)
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml("[]")
    assert excinfo.value.text == "could not found expected '<document start>'".capitalize()

    # testing empty dictionary (parsing error with parser)

# Generated at 2022-06-22 06:19:11.365296
# Unit test for function validate_yaml
def test_validate_yaml():
    class AValidator(typesystem.Schema):
        b = typesystem.String()
        c = typesystem.String()

    class BValidator(typesystem.Schema):
        b = typesystem.String(max_length=2)

    value, error_messages = validate_yaml(
        content=b"""a: b
        c: d""",
        validator=AValidator,
    )
    assert not error_messages

    value, error_messages = validate_yaml(
        content=b"""a: b
        c: d""",
        validator=BValidator,
    )
    assert error_messages
    assert (
        error_messages[0].text
        == "b: 'String value too long (max 2 characters).'"
    )

    value, error_messages

# Generated at 2022-06-22 06:19:20.331256
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import warnings

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        import yaml

    if yaml:
        yaml_obj = yaml.load(
            """
            # Comments are permitted.
            foo: bar
            baz:
                - hello
                - world
            """
        )
        token = tokenize_yaml(
            """
            foo: bar
            baz:
                - hello
                - world
            """
        )

        assert yaml_obj == token.value
    else:
        raise ImportError("pyyaml")


# Generated at 2022-06-22 06:19:27.044742
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    # Inner comment
    key: "hello"
    # List comment
    - one
    - two
    - three
    """)
    assert isinstance(token, DictToken)
    assert token.content == """
    # Inner comment
    key: "hello"
    # List comment
    - one
    - two
    - three
    """
    assert token.start_position == Position(line_no=2, column_no=5, char_index=5)
    assert token.end_position == Position(line_no=8, column_no=3, char_index=78)
    assert token.data["key"] == ScalarToken("hello", start=13, end=20, content=token.content)
    assert token.data["key"].value == "hello"


# Generated at 2022-06-22 06:19:36.564152
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class Validator(Schema):
        name = 'string'

    validator = Validator()

    content = 'name: value'

    value, error_messages = validate_yaml(content, validator)

    assert value == {'name': 'value'}
    assert len(error_messages) == 0

    class InvalidValidator(Schema):
        name = 'email'

    invalid_validator = InvalidValidator()

    value, error_messages = validate_yaml(content, invalid_validator)

    assert len(error_messages) == 1

# Generated at 2022-06-22 06:19:40.064829
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import String
    assert type(validate_yaml("foo: bar", String(name="foo"))) == tuple


# Generated at 2022-06-22 06:19:51.492215
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    valid_yaml = """
    foo:
      bar: 2
      baz: 3
    """
    assert validate_yaml(valid_yaml, {"foo": {"bar": int, "baz": int}}) == (
        {"foo": {"bar": 2, "baz": 3}},
        [],
    )
    invalid_yaml = """
    foo:
      bar: 2
      baz: 3
      boo: 'not an int'
    """
    with pytest.raises(ValidationError) as exc_info:
        value, messages = validate_yaml(
            invalid_yaml, {"foo": {"bar": int, "baz": int, "boo": int}}
        )

# Generated at 2022-06-22 06:20:03.965952
# Unit test for function tokenize_yaml

# Generated at 2022-06-22 06:20:20.889347
# Unit test for function validate_yaml
def test_validate_yaml():
    # Make sure that function validate_yaml throws an error for an empty string.
    try:
        validate_yaml("", None)
        assert False
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.code == "no_content"
        assert exc.text == "No content."

    # Make sure that function validate_yaml throws an error for an invalid string.
    try:
        validate_yaml("[foo: bar]", None)
        assert False
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0

# Generated at 2022-06-22 06:20:22.569702
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == Token()



# Generated at 2022-06-22 06:20:33.865683
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    name: Jane
    age: None
    '''

    class Person(Schema):
        name = String(required=True)
        age = Integer()

    value, errors = validate_yaml(content, Person)
    assert value == {'name': 'Jane', 'age': None}
    assert errors == []

    content = '''
    name: Jane
    age: None
    '''

    class Person(Schema):
        name = String(required=True)
        age = Integer()

    value, errors = validate_yaml(content, Person)
    assert value == {'name': 'Jane', 'age': None}
    assert errors == []

    content = '''
    name: Jane
    age: None
    '''


# Generated at 2022-06-22 06:20:43.066169
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import *
    from typesystem.schemas import *
    from typesystem import errors

    # Test a simple case
    content = "hi: 'there'"
    schema = Schema({"hi": String()})
    value, errors = validate_yaml(content, schema)
    assert errors == []
    assert value == {"hi": "there"}

    # Test with a simple type.
    content = "hi: 'there'"
    value, errors = validate_yaml(content, String)
    assert len(errors) == 1
    error = errors[0]
    assert isinstance(error, errors.SchemaError)
    assert error.code == "invalid_type"
    assert error.position.char_index == 0

    # Test with a simple type that should actually parse.
    content = "'there'"


# Generated at 2022-06-22 06:20:54.804380
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test for empty string
    try:
        tokenize_yaml(content="")
        assert False, "Parse error not raised for empty string"
    except ParseError as e:
        assert e.text == "No content."
        assert e.code == "no_content"
        assert e.position == Position(column_no=1, line_no=1, char_index=0)

    # Test for valid yaml string
    token = tokenize_yaml(content="test:test")
    assert isinstance(token, DictToken)
    assert token.value == {"test": "test"}
    assert token.start == 0
    assert token.end == 9
    assert isinstance(token.get_subtoken("test"), ScalarToken)
    assert token.get_subtoken("test").value == "test"
   

# Generated at 2022-06-22 06:21:06.602365
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("a: b") == DictToken({"a": "b"}, 0, 5, content="a: b")
    assert tokenize_yaml("a: b\nc: d") == DictToken({"a": "b", "c": "d"}, 0, 8, content="a: b\nc: d")
    assert tokenize_yaml("- a\n- b") == ListToken(["a", "b"], 0, 8, content="- a\n- b")
    assert tokenize_yaml("a: 1\nb: 2.0\nc: true\nd: null") == DictToken({"a": 1, "b": 2.0, "c": True, "d": None}, 0, 26, content="a: 1\nb: 2.0\nc: true\nd: null")


# Generated at 2022-06-22 06:21:18.618723
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert (tokenize_yaml("")) == None
    assert (tokenize_yaml("{}")) == DictToken([], 0, 1, content="{}")
    assert (tokenize_yaml("[]")) == ListToken([], 0, 1, content="[]")
    assert (tokenize_yaml("null")) == ScalarToken(None, 0, 4, content="null")
    assert (tokenize_yaml("1")) == ScalarToken(1, 0, 1, content="1")
    assert (tokenize_yaml("1.5")) == ScalarToken(1.5, 0, 3, content="1.5")
    assert (tokenize_yaml("true")) == ScalarToken(True, 0, 4, content="true")

# Generated at 2022-06-22 06:21:24.920374
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Arrange
    content = "test: 123"

    # Act
    token = tokenize_yaml(content)

    # Assert
    assert token.to_dict() == {"test": 123}


# Generated at 2022-06-22 06:21:36.948377
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    foo:
      bar: 1
      baz: 2.0
      norf: true
    """)

    assert token.content == """
    foo:
      bar: 1
      baz: 2.0
      norf: true
    """
    assert token.start_index == 6
    assert token.end_index == 48
    assert token.keys() == ["foo"]
    assert token["foo"].content == """
      bar: 1
      baz: 2.0
      norf: true
    """
    assert token["foo"].start_index == 12
    assert token["foo"].end_index == 48
    assert token["foo"].keys() == ["bar", "baz", "norf"]

# Generated at 2022-06-22 06:21:48.531998
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """---
list:
    - 1.0
    - 2.0
    - 3.0
dict:
    a: 1
    b: 2
    c: 3
"""
    token = tokenize_yaml(content)

    assert type(token.value) == dict
    assert token.start_index == 0
    assert token.end_index == 63

    dict_token = token.value["dict"]
    assert type(dict_token) == DictToken
    assert dict_token.start_index == 33
    assert dict_token.end_index == 62

    list_token = token.value["list"]
    assert type(list_token) == ListToken
    assert list_token.start_index == 4
    assert list_token.end_index == 32

    assert list_token.value[0].start_

# Generated at 2022-06-22 06:21:59.721638
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        # comment
        value:
            - 1 # inline comment
            - 2
            - 3 # inline comment
    """)
    assert isinstance(token, DictToken)
    value, errors = validate_yaml(content="""
            value:
              - 1
              - 2
              - 3
    """, validator=Field(type="integer", allow_null=True, min_items=3, max_items=3))
    assert value == {"value": [1, 2, 3]}
    assert not errors
    value, errors = validate_yaml(content="""
        value:
          - 1
    """, validator=Field(type="integer", allow_null=True, min_items=3, max_items=3))
    assert value is None
    assert len(errors)

# Generated at 2022-06-22 06:22:05.282871
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name:
      first: Bob
      last: Marley
    """
    schema = Schema({"name": {"first": str, "last": str}}, partial=True)

    value, errors = validate_yaml(content, schema)
    assert errors == []
    assert value == {"name": {"first": "Bob", "last": "Marley"}}

# Generated at 2022-06-22 06:22:11.223694
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    d = {"a": 1, "b": [2, 3], "c": {"d": "e", "f": {"g": 4}}}

    yaml_content = """
    a: 1
    b:
      - 2
      - 3
    c:
      d: e
      f:
        g: 4
    """

    token = tokenize_yaml(yaml_content)
    assert token == d



# Generated at 2022-06-22 06:22:18.176703
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    result = validate_yaml(
        content="""
        name: Jack
        age: 16
        """,
        validator=PersonSchema()
    )
    assert result.value == {"name": "Jack", "age": 16}
    assert result.errors == []



# Generated at 2022-06-22 06:22:22.521693
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class TestSchema(Schema):
        foo = String()
    schema = TestSchema
    value, errors = validate_yaml(content="foo: bar", validator=schema)



# Generated at 2022-06-22 06:22:29.163163
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('5') == 5
    assert tokenize_yaml('-5') == -5
    assert tokenize_yaml('5.5') == 5.5
    assert tokenize_yaml('[5, 5]') == [5, 5]
    assert tokenize_yaml('5.5+5j') == 5.5+5j
    assert tokenize_yaml('true') == True
    assert tokenize_yaml('{}') == {}
    assert tokenize_yaml('null') == None



# Generated at 2022-06-22 06:22:36.686182
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = Field(type="text")
        age = Field(type="integer")
    content = """
name: John
age: 37
"""
    result = validate_yaml(content, validator=MySchema)
    value, error_messages = result
    assert value is not None
    assert value["name"] == "John"
    assert value["age"] == 37
    assert error_messages is None

# Generated at 2022-06-22 06:22:46.368539
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    from typesystem.tokenize.tokens import ScalarToken, Token

    value, errors = validate_yaml('"hello"', String)
    assert value == 'hello'
    assert not errors

    value, errors = validate_yaml(
        "a: 1\n- 1\n- 2\n- \n  - a\n  - b",
        {"a":String, "b":[int]},
    )
    assert value == {"a": "1", "b": [1, 2, ["a", "b"]]}
    assert not errors

    value, errors = validate_yaml('"hello"', String(min_length=6))
    assert value == 'hello'
    assert len(errors) == 1
    assert isinstance(errors[0].token, ScalarToken)

# Generated at 2022-06-22 06:22:56.122843
# Unit test for function validate_yaml
def test_validate_yaml():
    input_yaml = '''
    widgets:
      - name: foo
        color: blue
        size: large
      - name: bar
        color: blue
        size: small
      - name: baz
        color: purple
        size: small
    '''
    class Widget(Schema):
        name = String(max_length=50)
        color = String(max_length=50)
        size = String(max_length=50)

    class Test(Schema):
        widgets = Array(items=Widget)


# Generated at 2022-06-22 06:23:03.999451
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert type(
        tokenize_yaml(
            """
cluster1: &cluster1
  host: localhost
  port: 3306
  user: root
  password: password
cluster2: &cluster2
  host: localhost2
  port: 3307
  user: root
  passwd: password
clusters:
  - <<: *cluster1
    name: db1
  - <<: *cluster2
    name: db2
"""
        )
    ) is DictToken



# Generated at 2022-06-22 06:23:17.770185
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test function 'validate_yaml'
    """
    from typesystem import String, Integer, Float, Boolean
    from typesystem.fields import NotEmpty

    msg = validate_yaml(b"""
    str: 'string'
    int: 7
    float: 2.123
    bool: true
    """,
        Integer() | String() | Float() | Boolean())
    assert isinstance(msg, Message)
    assert not msg.errors
    assert msg.value == {
        'str': 'string',
        'int': 7,
        'float': 2.123,
        'bool': True,
    }

    msg = validate_yaml(b"""
    empty_str: ''
    """,
        String() | NotEmpty())
    assert isinstance(msg, Message)
    assert msg.errors
    error

# Generated at 2022-06-22 06:23:24.245139
# Unit test for function validate_yaml
def test_validate_yaml():
    # from typesystem.tokenize.yaml import validate_yaml
    from tests.test_fields import User

    content = '''
    name: Kai
    age: 21
    '''

    user, errors = validate_yaml(content, User)
    assert not errors
    assert user.name == 'Kai'
    assert user.age == 21

# Generated at 2022-06-22 06:23:27.093152
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        - - 0
          - 1
        -   - 0
            - 1
        -   - 0
            - 1
    """

    assert isinstance(tokenize_yaml(content), ListToken)

# Generated at 2022-06-22 06:23:28.783488
# Unit test for function validate_yaml
def test_validate_yaml():
    result = validate_yaml('foo: bar', Schema) 
    assert not result[1]


# Generated at 2022-06-22 06:23:41.604925
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Schema

    # create a schema type
    class MySchema(Schema):
        title = String(min_length=3, max_length=10)
        age = Integer()
        # define a custom validator
        def my_validator(self, value, field, instance):
            if value < 20:
                raise ValidationError("value below 20")
        my_val = Integer(validators=[my_validator, ])

    # test if validate_yaml works
    # define a yaml string
    yaml_str = "title: This is a title\nage: 22\nmy_val: 15"

    # validate the yaml string
    val, errs = validate_yaml(yaml_str, MySchema)
    assert len(errs) == 1

# Generated at 2022-06-22 06:23:49.055419
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_yaml("[1, 2, 3]") == ListToken([1, 2, 3], 0, 7, "[1, 2, 3]")
    assert tokenize_yaml("42") == ScalarToken(42, 0, 1, "42")


# Generated at 2022-06-22 06:23:59.502425
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        class Meta:
            fields = ["foo"]

    field = Field(type=str)

    assert validate_yaml(content="", validator=TestSchema) == (
        {},
        [
            Message(
                text="Unable to parse content.",
                code="parse_error",
                position=Position(line_no=1, column_no=1, char_index=0),
            )
        ],
    )

    assert validate_yaml(content="notyaml", validator=TestSchema) == (
        {},
        [
            Message(
                text="Unable to parse content.",
                code="parse_error",
                position=Position(line_no=1, column_no=1, char_index=0),
            )
        ],
    )



# Generated at 2022-06-22 06:24:02.582892
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("""
    - 1
    - 2
    - 3
    """) == ListToken([1,2,3])


# Generated at 2022-06-22 06:24:12.187461
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == []

    assert tokenize_yaml('a: b') == [
        DictToken(mapping={'a': 'b'}, start=0, end=3, content='a: b')]

    assert tokenize_yaml("a: b\nc: d") == [
        DictToken(mapping={'a': 'b', 'c': 'd'}, start=0, end=8, content="a: b\nc: d")]



# Generated at 2022-06-22 06:24:24.943450
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: 1
    b:
        - 2
        - 3
    c:
        d: 4
        e: 5
    f:
        -
            - 6
            - 7
    """
    token = tokenize_yaml(content)
    assert token.as_dict() == {
        "a": "1",
        "b": ["2", "3"],
        "c": {"d": "4", "e": "5"},
        "f": [["6", "7"]],
    }
    assert token.as_str() == content
    assert token.value == {"a": "1", "b": ["2", "3"], "c": {"d": "4", "e": "5"}, "f": [["6", "7"]]}
    assert token.start == 0
    assert token

# Generated at 2022-06-22 06:24:33.806217
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("[one, two, three]")
    assert token.type == ListToken
    assert token.value == ["one", "two", "three"]

    token = tokenize_yaml("{one: 1, two: 2, three: 3}")
    assert token.type == DictToken
    assert token.value == {"one": 1, "two": 2, "three": 3}


# Unit tests for function validate_yaml

# Generated at 2022-06-22 06:24:45.013863
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('') == ScalarToken(None, 0, 0, content='')
    assert tokenize_yaml(' ') == ScalarToken(None, 0, 1, content=' ')
    assert tokenize_yaml('\n') == ScalarToken(None, 0, 1, content='\n')
    assert tokenize_yaml('\t') == ScalarToken(None, 0, 1, content='\t')
    assert tokenize_yaml('null') == ScalarToken(None, 0, 4, content='null')
    assert tokenize_yaml('true') == ScalarToken(True, 0, 4, content='true')
    assert tokenize_yaml('false') == ScalarToken(False, 0, 5, content='false')
    assert tokenize_yaml('1') == Scalar

# Generated at 2022-06-22 06:24:51.581622
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        test = Field(type="string")

    valid, errors = validate_yaml(validator=TestSchema, content=b"test: 'foo'")
    assert isinstance(errors, list)
    assert len(errors) == 0

    valid, errors = validate_yaml(validator=TestSchema, content=b"")
    assert isinstance(errors, list)
    assert len(errors) == 1

    valid, errors = validate_yaml(validator=TestSchema, content=b"test: ''")
    assert isinstance(errors, list)
    assert len(errors) == 0

    valid, errors = validate_yaml(validator=TestSchema, content=b"test: 0")
    assert isinstance(errors, list)
    assert len(errors) == 1

# Generated at 2022-06-22 06:25:00.153834
# Unit test for function validate_yaml
def test_validate_yaml():

    schema = Schema("", {
        "name": fields.String(),
        "hobbies": fields.Array(
            items=fields.String()
        )
    })
    content = """
    name: "John Doe"
    hobbies:
      - soccer
      - swimming
      - jogging
    """
    
    value, error_messages = validate_yaml(content, schema)
    assert value == {
        "name": "John Doe",
        "hobbies": ["soccer", "swimming", "jogging"],
    }
    assert error_messages == []




# Generated at 2022-06-22 06:25:10.133673
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = fields.Text(max_length=3)
        description = fields.Text(required=False)

    content = """
        name: "Foo Bar Baz"
        description: "Hello, World"
    """

    expected = [
        Message(
            text="Must be no longer than 3 characters.",
            code="too_long",
            position=Position(line_no=2, column_no=6, char_index=7),
        ),
    ]

    value, messages = validate_yaml(content, TestSchema)

    assert value == {"name": "Foo Bar Baz", "description": "Hello, World"}
    assert messages == expected



# Generated at 2022-06-22 06:25:14.915205
# Unit test for function validate_yaml
def test_validate_yaml():

    class MySchema(Schema):
        my_string = String()

    assert validate_yaml(
        validator=MySchema, content='{"my_string": "Hey"}'
    ) == ({"my_string": "Hey"}, [])



# Generated at 2022-06-22 06:25:21.021377
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Array, Integer, String

    class PetSchema(Schema):
        id = Integer()
        name = String()
        nicknames = Array(items=String())

    content = """
    - id: 12345
      name: "Snoopy"
      nicknames:
      - Snoopy
      - Snoop Dogg
      - Snoop Lion
      - Snoopzilla
    """
    token, errors = validate_yaml(content, validator=PetSchema)

    assert token == [
        {
            "id": 12345,
            "name": "Snoopy",
            "nicknames": [
                "Snoopy",
                "Snoop Dogg",
                "Snoop Lion",
                "Snoopzilla",
            ],
        },
    ]
    assert not errors



# Generated at 2022-06-22 06:25:28.506192
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test empty string
    content = ""
    error = None
    try:
        tokenize_yaml(content)
    except ParseError as exc:
        error = exc
    assert error is not None
    assert error.text == "No content."
    assert error.code == "no_content"
    assert error.position.line_no == 1
    assert error.position.column_no == 1
    assert error.position.char_index == 0



# Generated at 2022-06-22 06:25:37.725042
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
        hello:
            - world
            - water
        - banana
        - mango
    '''
    validator = Schema(
        Hello={
            "type": "list",
            "items": {"type": "str"},
            "required": True,
        }
    )
    value, messages = validate_yaml(content, validator)
    print(messages)
    assert len(messages) == 0

# Generated at 2022-06-22 06:25:50.091854
# Unit test for function validate_yaml
def test_validate_yaml():
    """ Test function validate_yaml """
    correct = {
        "first_name": "Paula",
        "last_name": "Bean",
        "age": 41,
        "spouse": None,
        "children": [],
        "pets": [
            {"name": "Misty", "species": "dog"},
            {"name": "Whiskers", "species": "cat"},
        ],
    }
    incorrect = {
        "first_name": "Paula",
        "last_name": "Bean",
        "age": 41,
        "spouse": "",
        "children": [],
        "pets": [
            {"name": "Misty", "species": "dog"},
            {"name": "Whiskers", "species": "cat"},
        ],
    }

# Generated at 2022-06-22 06:26:04.404988
# Unit test for function validate_yaml
def test_validate_yaml():

    class SimpleSchema(Schema):
        title = "A simple schema."
        one = "A simple string value."
        two = "Another simple string value."

    def test_validate_yaml_schema():
        schema = SimpleSchema()
        value, errors = validate_yaml(
            content=b"one: 1\ntwo: 2", validator=schema
        )
        assert errors == []
        assert value == {"one": "1", "two": "2"}

    def test_validate_yaml_field():
        schema = SimpleSchema()
        field = schema.fields["one"]
        value, errors = validate_yaml(content=b"one: 1", validator=field)
        assert errors == []
        assert value == "1"


# Generated at 2022-06-22 06:26:13.839614
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: Jane Doe
    age: 25
    occupation:
      employer: Acme, Inc
      position: CEO
    """

    class PersonSchema(Schema):
        name = Field(str, max_length=10)
        age = Field(int)
        occupation = Field(Dict[str, str])

    value, errors = validate_yaml(content, PersonSchema)
    assert not errors
    assert value == {
        "name": "Jane Doe",
        "age": 25,
        "occupation": {"employer": "Acme, Inc", "position": "CEO"},
    }



# Generated at 2022-06-22 06:26:25.005733
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    This test case covers the following test conditions:

    1. Test case to validate YAML:
        1.1 Validate YAML with each field validating individually
        1.2 Validate YAML with fields validating as a whole

    2. Test validation of YAML document with custom error messages
    3. Test valdiation of YAML document with simple error messages
    """

    from typesystem.fields import Integer, String, Array
    from typesystem.exceptions import Invalid
    from typesystem.validators import MaxLengthValidator

    class Person(Schema):
        name = String()
        age = Integer()
        nickname = String(validators=[MaxLengthValidator(2)])
        address = String(max_length=3)
        id = Integer(minimum=0)
        hobbies = Array(items=String)



# Generated at 2022-06-22 06:26:37.218576
# Unit test for function validate_yaml
def test_validate_yaml():
    import pytest
    from typesystem import String, Schema
    from typesystem.message import Message
    from typesystem.parse_error import ParseError
    from typesystem.position import Position

    content = "123"
    value = 123
    test1 = [Message(
        text='Expected type "integer" but got type "string".',
        code="invalid_type",
        field=None)]

    assert validate_yaml(content, Field(type=String)) == (None, test1)

    content = "[123, 456]"
    value = [123, 456]
    test2 = [Message(
        text='Expected type "integer" but got type "list".',
        code="invalid_type",
        field=None)]


# Generated at 2022-06-22 06:26:47.431899
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    title: Test title
    one_or_many: 123
    '''

    class testSchema(Schema):
        title = String(required=True)
        one_or_many = String() | Integer()

    value, error_messages = validate_yaml(content, testSchema)
    assert len(error_messages) == 0
    assert value is not None
    assert value['title'] == 'Test title'
    assert value['one_or_many'] == 123

    content = '''
    title: Test title
    one_or_many: 123
    non_existing: 123
    '''

    value, error_messages = validate_yaml(content, testSchema)
    assert len(error_messages) == 1

# Generated at 2022-06-22 06:26:56.567919
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"text: hello"
    validator = Field(type=str)
    assert validate_yaml(content, validator) == ("hello", None)

    content = b"text: \n  hello"
    validator = Field(type=str)
    assert validate_yaml(content, validator) == ("hello", None)

    content = b"text: \n  hello"
    validator = Field(type=str, max_length=3)
    assert validate_yaml(content, validator) == ("hello", [('text', 'Must not be greater than 3 characters.', Position(1, 7, 6))])

    content = b"text: \n  hello"

# Generated at 2022-06-22 06:27:01.336965
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = types.String(min_length=2)

    content = "name: ab"
    value, messages = validate_yaml(content, Person)

    # Check that no errors were returned
    assert len(messages) == 0

# Generated at 2022-06-22 06:27:04.936241
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    print(validate_yaml(yaml.load("""
struct:
  id: 1234
  first_name: Bob
  last_name: Jones
  email: [1,2,3]
  """), StructSchema))

# Generated at 2022-06-22 06:27:15.733567
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        name="TestSchema",
        fields=[
            Field(key="name", required=True, type="string"),
            Field(key="age", required=True, type="number"),
            Field(key="children", type="array"),
        ],
    )

    content = """\
name: "Foo"
age: 10
children:
    - "Bar"
    - "Baz"
"""

    result, errors = validate_yaml(content, validator=schema)

    assert result == {
        "name": "Foo",
        "age": 10,
        "children": ["Bar", "Baz"],
    }

    assert errors == []



# Generated at 2022-06-22 06:27:17.743948
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("'string'", yaml, str) == ("string", [])


# Generated at 2022-06-22 06:27:29.045637
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('''
      - one: value1
        two: value2
      - 3
    ''')
    assert isinstance(token, ListToken)
    assert token.value == [
        {
            "one": "value1",
            "two": "value2"
        },
        "3"
    ]
    assert token.start_pos == Position(
        line_no=2,
        column_no=6,
        char_index=6
    )
    assert token.end_pos == Position(
        line_no=4,
        column_no=4,
        char_index=34
    )



# Generated at 2022-06-22 06:27:37.685493
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {
            "name": Field(str),
            "age": Field(int),
            "is_married": Field(bool),
            "children": Field(int, nullable=True),
            "incomes": Field([int]),
        }
    )
    yaml_content = """
name: John Doe
age: 58
is_married: no
children: false
incomes: [12345.67, -9876.54]
"""
    value, errors = validate_yaml(yaml_content, schema)

# Generated at 2022-06-22 06:27:45.798280
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(
        """
        name: John Doe
        age: 43
        addresses:
          - street: 123 Main St.
            city: Springfield
            state: OH
          - city: Sometown
            state: CA
        """)
    assert token == {
        "name": "John Doe",
        "age": 43,
        "addresses": [
            {"street": "123 Main St.", "city": "Springfield", "state": "OH"},
            {"city": "Sometown", "state": "CA"},
        ],
    }
    assert token.start == 0
    assert token.end == 158



# Generated at 2022-06-22 06:27:56.901376
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Field, String

    class PersonSchema(Schema):
        name = String()
        age = Field(typing.Optional[int])

    content = """
        name: Josh
        age: 30
    """
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "Josh", "age": 30}
    assert len(error_messages) == 0

    content = """
        name: |
          This is some very long text.
          That actually covers several lines.
        age: 30
    """
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {
        "name": "This is some very long text.\nThat actually covers several lines.",
        "age": 30,
    }
   

# Generated at 2022-06-22 06:28:04.442068
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        name=Field(type_name="string"),
        email=Field(type_name="string", format="email"),
        age=Field(type_name="integer", minimum=0, maximum=150),
        address=Schema(
            type_name="object",
            properties={"street": Field(type_name="string"), "city": Field(type_name="string")},
        ),
        friends=Schema(
            type_name="array",
            items=Schema(
                type_name="object",
                properties={"name": Field(type_name="string"), "email": Field(type_name="string")},
                required=["name", "email"],
            ),
            min_items=0,
        ),
    )


# Generated at 2022-06-22 06:28:08.558140
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = yaml.dump({'x': 1, 'y': 2})
    assert tokenize_yaml(content) == {'x': ScalarToken(1, 6, 7, content=content), 'y': ScalarToken(2, 13, 14, content=content)}


# Generated at 2022-06-22 06:28:13.063353
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    my_yaml = "square: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]"
    my_tokens = tokenize_yaml(my_yaml)
    assert isinstance(my_tokens, DictToken)


# Generated at 2022-06-22 06:28:23.578537
# Unit test for function validate_yaml
def test_validate_yaml():
    import os

    # Get working directory
    dir_path = os.path.dirname(os.path.realpath(__file__))
    # Test schema
    schema = '''
---
title: Test Schema
type: object
required:
- first_name
- last_name
properties:
  first_name:
    type: string
  last_name:
    type: string
    minLength: 1
    maxLength: 100
  middle_name:
    type: string
  age:
    type: integer
    minimum: 0
    maximum: 100
    '''
    # Test cases