

# Generated at 2022-06-22 06:18:46.362587
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test to make sure validate_yaml function works with valid data and gets correct error message
    Returns:
        None
    """
    content = "a: True\nb: False\nc: null"
    validator = Schema({"a": Boolean(), "b": Boolean(), "c": NoneType()})
    value, errors = validate_yaml(content=content, validator=validator)
    assert len(errors) == 0 and value == {"a": True, "b": False, "c": None}

    # Test validation error
    content = "a: {}"
    validator = Schema({"a": Boolean()})
    value, errors = validate_yaml(content=content, validator=validator)
    assert len(errors) == 1 and type(errors[0]) == ValidationError

    # Test parse error


# Generated at 2022-06-22 06:18:53.422611
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import yaml

    assert yaml is not None, "'pyyaml' must be installed."

    token = tokenize_yaml(
        """
        - a
        - b
        - c
        """
    )
    assert isinstance(token, ListToken)
    assert token.value == ["a", "b", "c"]

    token = tokenize_yaml(
        """
        a: 1
        b: 2
        c: 3
        """
    )
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-22 06:19:02.667965
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    result_1 = tokenize_yaml("""
        foo:
          - foo
          - bar
          - baz
    """.strip())
    assert result_1.content == """
        foo:
          - foo
          - bar
          - baz
    """.strip()
    assert result_1.start == 0
    assert result_1.end == 34
    assert result_1["foo"].start == 2
    assert result_1["foo"].end == 33
    assert result_1["foo"][0].start == 7
    assert result_1["foo"][0].end == 14
    assert result_1["foo"][1].start == 16
    assert result_1["foo"][1].end == 21
    assert result_1["foo"][2].start == 23

# Generated at 2022-06-22 06:19:13.408848
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        - id: 1
          product: Product 1
          category: Category 1
        - id: 2
          product: Product 2
          category: Category 2
        - id: 3
          product: Product 3
          category: Category 3
        """
    class ProductSchema(Schema):
        id = Integer(min_value=1, max_value=3)
        product = String(max_length=10)
        category = String(max_length=10)
    value, errors = validate_yaml(content, ProductSchema)

# Generated at 2022-06-22 06:19:23.593284
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String


    class UserSchema(Schema):
        name = String()
        age = Integer()

    value, errors = validate_yaml(
        content="""
        name: bob
        age: 27
        """,
        validator=UserSchema,
    )
    assert value == {"name": "bob", "age": 27}
    assert not errors
    value, errors = validate_yaml(
        content="""
        name: bob
        age: twenty-seven
        """,
        validator=UserSchema,
    )
    assert not value
    assert len(errors) == 1
    error = errors[0]
    assert error.code == "invalid_type"
    assert error.path == ["age"]


# Generated at 2022-06-22 06:19:34.988494
# Unit test for function validate_yaml
def test_validate_yaml():
    # https://yaml.org/spec/1.2/spec.html#id2760395
    content = """
foo: bar
baz:
- qux
- quux
corge:
  grault: garply
  waldo: fred
"""
    class MySchema(Schema):
        foo = Field(type="string")
        baz = Field(type="list", items=Field(type="string"))
        corge = Field(type="object", properties={"grault": Field(type="string")})

    value, errors = validate_yaml(content, validator=MySchema)

    assert value == {
        "foo": "bar",
        "baz": ["qux", "quux"],
        "corge": {"grault": "garply"},
    }
    assert errors == []



# Generated at 2022-06-22 06:19:44.464905
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_content = """
    - name: Foo
      age: 10
    """
    parsed_object = tokenize_yaml(yaml_content)
    assert parsed_object.value[0].value['name'].value == 'Foo'
    assert parsed_object.value[0].value['age'].value == 10

    yaml_content = """
    - name: Foo
      age:
    """
    try:
        parsed_object = tokenize_yaml(yaml_content)
    except ParseError as e:
        assert e.position.line_no == 4
        assert e.position.column_no == 10



# Generated at 2022-06-22 06:19:56.457025
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, fields, schemas

    class Pet(schemas.Schema):
        name = fields.String()
        age = fields.Integer()

    class Person(schemas.Schema):
        name = fields.String(max_length=5)
        pets = fields.Array(fields.Nested(Pet))

    yml_data = """
    name: Bob
    pets:
    - name: Fluffy
      age: 3
    - name: Doggo
      age: 12
    """

    value, error_map = validate_yaml(yml_data, validator=Person)
    assert value == {
        "name": "Bob",
        "pets": [{"name": "Fluffy", "age": 3}, {"name": "Doggo", "age": 12}],
    }

# Generated at 2022-06-22 06:20:04.207316
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields

    content = """
    name: John Doe
    age: 43
    """

    class Profile(Schema):
        name = fields.String(max_length=100)
        age = fields.Integer(minimum=0, maximum=130)

    validated, error_messages = validate_yaml(content, Profile)
    assert validated == {"name": "John Doe", "age": 43}
    assert not error_messages



# Generated at 2022-06-22 06:20:11.962016
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = String()

    from typesystem.tokenize.tokens import DictToken
    from typesystem.tokenize.tokens import ListToken
    from typesystem.tokenize.tokens import ScalarToken

    def execute(**kwargs):
        content = kwargs.pop("content")
        validator = kwargs.pop("validator")
        expected_value = kwargs.pop("expected_value")
        expected_messages = kwargs.pop("expected_messages")
        if isinstance(content, typing.Callable):
            content = content()

        value, messages = validate_yaml(content=content, validator=validator)


# Generated at 2022-06-22 06:20:18.328528
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
	assert tokenize_yaml("""
a: 1
b: 3
	""") == DictToken(
		{"a": ScalarToken(1), "b": ScalarToken(3)},
		0,
		19
	)


# Generated at 2022-06-22 06:20:26.466726
# Unit test for function validate_yaml
def test_validate_yaml():
    # ValidationError on invalid yaml document
    with pytest.raises(ValidationError):
        validate_yaml(content='foo=bar', validator='string')
    # ParseError on invalid yaml document
    with pytest.raises(ParseError):
        validate_yaml(content='!!', validator='string')
    # ValidationError on invalid data
    with pytest.raises(ValidationError):
        validate_yaml(content='foo: bar', validator='string')



# Generated at 2022-06-22 06:20:31.727090
# Unit test for function validate_yaml
def test_validate_yaml():
    with open('./mock_data/test_data.yaml') as file:
        content = file.read()
    validator = yaml.load(open('./mock_data/test_schema.yaml'))
    result = validate_yaml(content, validator)
    print(result)

# Generated at 2022-06-22 06:20:42.272294
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    schema = Schema({"name": String()})
    assert tokenize_yaml("{}") == DictToken({}, 0, 0, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 0, content="[]")
    assert tokenize_yaml("[1]") == ListToken([1], 0, 1, content="[1]")
    assert tokenize_yaml("[1, 2]") == ListToken([1, 2], 0, 5, content="[1, 2]")

# Generated at 2022-06-22 06:20:53.538430
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('''
        foo:
            bar:
                - 0
                - 1.1
                - true
                - false
                - null
                - a string
    ''')
    assert token.get("foo") == {
        "bar": [
            0,
            1.1,
            True,
            False,
            None,
            "a string",
        ]
    }

    token = tokenize_yaml("""
        foo:
            - a string
            - an int: 123
    """)
    assert token.get("foo") == [
        "a string",
        {"an int": 123},
    ]

    class MySchema(Schema):
        foo = "string"


# Generated at 2022-06-22 06:21:03.969804
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: Jane Doe
    age: 21
    """
    class PersonSchema(Schema):

        name = String(max_length=50)
        age = Integer()

    value, errors = validate_yaml(content, validator=PersonSchema)
    assert errors == []
    assert value == {
        "name": "Jane Doe",
        "age": 21,
    }
    assert isinstance(value, dict)

    assert validate_yaml(content, validator=PersonSchema)[0] == {
        "name": "Jane Doe",
        "age": 21,
    }

    content = """
    name: Jane Doe
    """
    value, errors = validate_yaml(content, validator=PersonSchema)
    assert len(errors) == 1

# Generated at 2022-06-22 06:21:08.603439
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Given
    content = '''
        # Our pets
        pets:
            - cat
            - dog
            - fish
    '''

    # When
    token = tokenize_yaml(content)

    # Then
    assert token == DictToken({'pets': [ScalarToken('cat'), ScalarToken('dog'), ScalarToken('fish')]})


# Generated at 2022-06-22 06:21:17.385847
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    
    class AnimalSchema(Schema):
        name = String()
        legs = Integer()
    
    with open("./tests/fixtures/yaml/animal.yaml", "r") as file:
        content = file.read()
    
    value, error_messages = validate_yaml(content=content, validator=AnimalSchema)
    assert value == {'name': 'Luna', 'legs': 4}
    assert error_messages == []

# Generated at 2022-06-22 06:21:21.546696
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("foo: bar")
    assert isinstance(token, DictToken)
    assert token[0] == "foo"
    assert token[1] == "bar"

    token = tokenize_yaml("foo")
    assert isinstance(token, ScalarToken)


# Generated at 2022-06-22 06:21:26.593487
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    input = """
    - list
    - item1
    - item2
    """
    token = tokenize_yaml(input)
    assert isinstance(token, ListToken)
    assert token.value == ['list', 'item1', 'item2']

test_tokenize_yaml()


# Generated at 2022-06-22 06:21:35.052604
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # sample yaml
    yaml_str = """
        ---
        name: "John"
        age: 32
        """

    # Tokenize the yaml
    token = tokenize_yaml(yaml_str)
    assert token == {"name":"John","age":32}

# Generated at 2022-06-22 06:21:44.106329
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(b"a: 1") == DictToken({"a": 1}, 0, 6)

    assert tokenize_yaml(b"a:\n  b: 1\n  d: 2") == DictToken(
        {"a": DictToken({"b": 1, "d": 2})}, 0, 16
    )

    assert tokenize_yaml(b"- a\n- b") == ListToken([ScalarToken("a"), ScalarToken("b")], 0, 8)

# End unit tests for function tokenize_yaml


# Unit test code for function validate_yaml

# Generated at 2022-06-22 06:21:49.936880
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Check the case that raises an exception.
    with pytest.raises(ParseError):
        tokenize_yaml("{invalid yaml")

    # Check the case that returns a token.
    # The token itself is checked in typesystem/tests/test_tokenize.py
    result = tokenize_yaml("{}")
    assert result.__class__ == DictToken

# Generated at 2022-06-22 06:21:58.873190
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    test to validate tokenize_yaml function
    """
    yamlfile="""
    - a: "Dave"
    - b: "James"
    """
    token=tokenize_yaml(yamlfile)
    assert token.items() == [{'a': 'Dave'}, {'b': 'James'}]

    yamlfile="""
    a: "Dave"
    b: "James"
    """
    token=tokenize_yaml(yamlfile)
    assert token.items() == [{'a': 'Dave'}, {'b': 'James'}]
    
    token=tokenize_yaml(yamlfile)

# Generated at 2022-06-22 06:22:09.035484
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == {"a": 1}
    assert tokenize_yaml("a: 1") == {"a": 1}
    assert tokenize_yaml("a: [1, 2]") == {"a": [1, 2]}
    assert tokenize_yaml("a: [1, 2]") == {"a": [1, 2]}
    assert tokenize_yaml("a:\n  - 1\n  - 2") == {"a": [1, 2]}

    try:
        tokenize_yaml("a:")
        assert False
    except ParseError as exc:
        assert exc.position.column_no == 3
        assert exc.position.line_no == 1
        assert exc.position.char_index == 3
        assert exc.code == "parse_error"


# Generated at 2022-06-22 06:22:15.853063
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        age = Integer()
        name = String()

    content = "age: 27\nname: Tyler"
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"age": 27, "name": "Tyler"}
    assert error_messages == []



# Generated at 2022-06-22 06:22:20.778096
# Unit test for function validate_yaml
def test_validate_yaml():
    example_schema = Schema(fields={"name": str, "age": int})
    data, errors = validate_yaml(content="name: John Smith\nage: 25", validator=example_schema)
    assert data == {"name": "John Smith", "age": 25}
    assert not errors

# Generated at 2022-06-22 06:22:29.431455
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
        name: "John Smith"
        age: 23
        address:
          street: "123 Main St"
          city: "New York"
    '''

    class Person(Schema):
        name = String(max_length=50)
        age = Integer()
        address = Nested(
            "typesystem.formats.yaml.tests.test_validate_yaml.Address"
        )

    class Address(Schema):
        street = String(max_length=100)
        city = String(max_length=100)

    value, error_messages = validate_yaml(content, Person)

    assert error_messages


# Unit tests for function tokenize_yaml

# Generated at 2022-06-22 06:22:37.679817
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    # A comment
    foo: "bar"
    baz: 12
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.tokens["foo"], ScalarToken)
    assert token.tokens["foo"].value == "bar"
    assert isinstance(token.tokens["baz"], ScalarToken)
    assert token.tokens["baz"].value == 12

# Generated at 2022-06-22 06:22:47.378468
# Unit test for function validate_yaml
def test_validate_yaml():
    token = tokenize_yaml("---\nfoo: bar")
    validator = Dict(properties={"foo": String()})
    assert validate_yaml("---\nfoo: bar", validator) == ({"foo": "bar"}, [])
    assert validator.validate({"foo": "bar"}, position={}) is None

    token = tokenize_yaml("---\nfoo: 123")
    validator = Dict(properties={"foo": Integer()})
    assert validate_yaml("---\nfoo: 123", validator) == ({"foo": 123}, [])
    assert validator.validate({"foo": 123}, position={}) is None



# Generated at 2022-06-22 06:23:02.885526
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Simple valid string
    token = tokenize_yaml("""
    name: Leo
    age: 5
    """)
    assert token.start == 0
    assert token.end == 31
    assert isinstance(token, DictToken)
    assert token.content == """
    name: Leo
    age: 5
    """
    assert isinstance(token.value['name'], ScalarToken)
    assert token.value['name'].value == 'Leo'
    assert token.value['name'].content == """
    name: Leo
    age: 5
    """

    # Empty string
    try:
        token = tokenize_yaml("")
    except ParseError as exc:
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char

# Generated at 2022-06-22 06:23:15.541285
# Unit test for function validate_yaml
def test_validate_yaml():

    class PlayerSchema(Schema):
        name = Field(str, required=True)
        email = Field(str, required=True)
        # The validator will be _get_position when testing.
        position = Field(str, required=False)
        points = Field(int, required=True)

    def test_validate_yaml_success():

        # type: () -> None
        """
        Successfully validate a valid YAML string.
        """
        # content is a valid YAML string.
        content = """
        name: David
        email: david@example.com
        points: 6
        """

        # error_messages is an empty list.
        # value is {'name': 'David', 'email': 'david@example.com', 'points': 6}
        # type: ignore
        value

# Generated at 2022-06-22 06:23:21.626611
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("[\n3,\n4\n]")
    assert isinstance(token, ListToken)
    assert token.start_index == 0
    assert token.stop_index == 7
    assert list(token) == [ScalarToken(3, 2, 2), ScalarToken(4, 5, 5)]

    token = tokenize_yaml("{a: 1}")
    assert isinstance(token, DictToken)
    assert token.start_index == 0
    assert token.stop_index == 5
    assert list(token) == [("a", ScalarToken(1, 4, 4))]

    token = tokenize_yaml("{a:\n1}")
    assert isinstance(token, DictToken)
    assert token.start_index == 0
    assert token.stop_

# Generated at 2022-06-22 06:23:30.440548
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
name: John Doe
age: 40
is_active: true
bio: null
favorite_foods:
  - pizza
  - tacos
  - burritos
pets:
  - type: dog
    name: Bolt
  - type: cat
    name: Mittens
    age: 10
    birthday: 2018-10-01
  - type: rabbit
    name: Penny
'''  # noqa
    value, error_messages = validate_yaml(content, StandardMixedValidator)

# Generated at 2022-06-22 06:23:42.805222
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('field: value') == DictToken(
        {'field': 'value'}, 0, 13, content='field: value'
    )

    assert tokenize_yaml('[1, 2, 3]') == ListToken(
        [1, 2, 3], 0, 7, content='[1, 2, 3]'
    )

    assert tokenize_yaml('"value"') == ScalarToken(
        'value', 0, 6, content='"value"'
    )

    assert tokenize_yaml('!!int 7') == ScalarToken(
        7, 0, 5, content='!!int 7'
    )

    assert tokenize_yaml('!!float 7.0') == ScalarToken(
        7.0, 0, 8, content='!!float 7.0'
    )

   

# Generated at 2022-06-22 06:23:52.514765
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(required=True)
        age = Int(minimum=0)
        alive = Boolean()

    schema = Person()
    assert isinstance(schema, type)

    data = """
    name: Bob
    age: 34
    alive: true
    """
    value, errors = validate_yaml(data, schema)
    assert value == {"name": "Bob", "age": 34, "alive": True}
    assert errors == []

    data = """
    name: Bob
    age: 34
    alive: true

    """  # Extra line at the end...
    value, errors = validate_yaml(data, schema)
    assert value == {"name": "Bob", "age": 34, "alive": True}
    assert errors == []



# Generated at 2022-06-22 06:24:04.305504
# Unit test for function tokenize_yaml

# Generated at 2022-06-22 06:24:10.091783
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("foo: bar", {"foo": str}) == ({'foo': 'bar'}, [])
    assert validate_yaml("foo: bar", {"foo": int}) == (None, [(0, "Type mismatch of value 'bar' at foo: Expected 'int' but got 'str'")])

# Generated at 2022-06-22 06:24:17.095677
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('"Hello World"', str) == ("Hello World",[])
    assert validate_yaml('wrong', str) == (None,[ValidationError(text='Value must be of type str.', code='type_error', position=Position(line_no=1, column_no=1, char_index=0))])
    assert validate_yaml('hello world', str) == (None,[ValidationError(text='Value must be of type str.', code='type_error', position=Position(line_no=1, column_no=1, char_index=0))])

# Generated at 2022-06-22 06:24:27.568508
# Unit test for function validate_yaml
def test_validate_yaml():
    value, errors = validate_yaml(
        b"""
    list:
      - item: a
        number: 1
      - item: b
        number: 2
    string: test
    number: 123
    """,
        validator=Schema(
            {
                "list": Field(
                    item=Field(
                        {"item": Field(str), "number": Field(int, gt=0, lt=10)}
                    ),
                    min_items=2,
                ),
                "string": Field(str),
                "number": Field(int),
            }
        ),
    )
    assert value == {
        "list": [{"item": "a", "number": 1}, {"item": "b", "number": 2}],
        "string": "test",
        "number": 123,
    }


# Generated at 2022-06-22 06:24:47.218028
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # pylint: disable=import-outside-toplevel
    assert yaml is not None, "'pyyaml' must be installed."

    content = """
        foo: bar
        baz:
            - a
            - b
            - c
        nested:
            nested:
                deeper: d
    """
    token = tokenize_yaml(content)
    assert token is not None
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == len(content) - 1
    assert len(token.value) == 3

    assert "foo" in token.value
    foo = token.value["foo"]
    assert isinstance(foo, ScalarToken)
    assert foo.value == "bar"
    assert foo.start == 11
    assert foo.end == 15

   

# Generated at 2022-06-22 06:24:57.904894
# Unit test for function validate_yaml
def test_validate_yaml():
    test_content = "key1: 2\nkey2: 'string'\nkey3: [1, true, null]\nkey4: {}\n"
    class TestSchema(Schema):
        key1 = fields.Int()
        key2 = fields.String()
        key3 = fields.List(
            items=[fields.Int(), fields.Boolean(), fields.Any()]
        )
        key4 = fields.Dict()
    assert validate_yaml(test_content, TestSchema) == (
        {'key1': 2, 'key2': 'string', 'key3': [1, True, None], 'key4': {}},
        [],
    )
    class TestSchema(Schema):
        key1 = fields.Int()
        key2 = fields.String()
        key3 = fields

# Generated at 2022-06-22 06:25:03.772539
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Test empty string
    token_test = tokenize_yaml("")
    assert isinstance(token_test, Token)

    # Test parsing yaml
    yaml_content = "my_field: test"
    token = tokenize_yaml(yaml_content)
    assert isinstance(token, DictToken)

    # Test parsing yaml with error
    with pytest.raises(ParseError):
        tokenize_yaml("&")


# Generated at 2022-06-22 06:25:16.535212
# Unit test for function validate_yaml
def test_validate_yaml():
    import pytest
    from typesystem import String

    s = String(max_length=10)

    value, error_messages = validate_yaml("valid string", s)

    assert error_messages == []
    assert value == "valid string"

    value, error_messages = validate_yaml("invalid", s)

    assert error_messages == []
    assert value == "invalid"

    value, error_messages = validate_yaml("'invalid'", s)

    assert len(error_messages) == 1
    assert error_messages[0].text == 'Value must be a str instance.'
    assert error_messages[0].code == 'type_error'
    assert error_messages[0].position.column == 2
    assert error_messages[0].position.line == 1
   

# Generated at 2022-06-22 06:25:28.390136
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b'{"system": "linux","location": {"city": "San Francisco","state": "California"}}'
    class LocationSchema(Schema):
        city = Field(str)
        state = Field(str)
    class SystemSchema(Schema):
        system = Field(str)
        location = Field(LocationSchema)

    errors = validate_yaml(content, SystemSchema)
    assert len(errors) == 0
    assert errors[0].args[0] == "Expected str for 'system' but got <class 'str'>."

    content = b'{"system": "windows","location": {"city": "New York","state": "New York"}}'
    errors = validate_yaml(content, SystemSchema)
    assert len(errors) == 1

# Generated at 2022-06-22 06:25:41.482681
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test string content
    with pytest.raises(ParseError):
        tokenize_yaml("")
    assert tokenize_yaml("foo") == "foo"

    with pytest.raises(ParseError):
        tokenize_yaml("1 1")
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml(".1") == 0.1
    assert tokenize_yaml("101170141181260686181273.4738991") == 101170141181260686181273.4738991
    assert tokenize_yaml("[1, true, 3, false]") == [1, True, 3, False]

# Generated at 2022-06-22 06:25:52.147898
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('letter: 1', "Letter") == "Letter"
    assert validate_yaml('letter: 2', "Letter") == "Letter"
    assert validate_yaml('letter: 3', "Letter") == "Letter"
    assert validate_yaml('letter: 4', "Letter") == "Letter"
    assert validate_yaml('letter: 5', "Letter") == "Letter"
    assert validate_yaml('letter: 6', "Letter") == "Letter"
    assert validate_yaml('letter: 7', "Letter") == "Letter"
    assert validate_yaml('letter: 8', "Letter") == "Letter"
    assert validate_yaml('letter: 9', "Letter") == "Letter"
    assert validate_yaml('letter: 10', "Letter") == "Letter"

# Generated at 2022-06-22 06:26:04.096705
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # normal yaml
    yaml_str = '''
    foo: bar
    bar: 1
    baz: true
    '''
    actual = tokenize_yaml(yaml_str)
    assert actual.value == {'foo': 'bar', 'bar': 1, 'baz': True}
    assert actual.start == 0
    assert actual.end == 36
    assert actual.content == yaml_str

    # empty yaml
    yaml_str = ''
    with pytest.raises(ParseError):
        tokenize_yaml(yaml_str)

    # empty token yaml
    yaml_str = '   '
    actual = tokenize_yaml(yaml_str)
    assert actual is None

    # normal sequence yaml

# Generated at 2022-06-22 06:26:15.689755
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(
        """
    - apple
    - banana
    - cherry
    """
    )
    assert isinstance(token, ListToken)
    assert token.value == ["apple", "banana", "cherry"]
    assert token.start == 2
    assert token.end == 10
    assert token.content == "\n    - apple\n    - banana\n    - cherry\n    "
    with pytest.raises(ParseError):
        tokenize_yaml("")
    with pytest.raises(ParseError):
        tokenize_yaml("one: two")
    with pytest.raises(ParseError):
        tokenize_yaml("\n    - one: two\n    ")


# Unit tests for function validate_yaml

# Generated at 2022-06-22 06:26:27.324184
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test loading an empty YAML string
    assert validate_yaml("", Field()) == (None, [])

    # Test loading an empty YAML string with a required field
    assert validate_yaml("", Field(required=True)) == (None, [Message(
        text="This field is required.",
        code="required",
        position=Position(
            char_index=0,
            column_no=1,
            line_no=1,
        ),
    )])

    # Test loading a YAML int
    assert validate_yaml("123", Field()) == (123, [])
    assert validate_yaml("123", Field(required=True)) == (123, [])

    # Test loading a YAML float
    assert validate_yaml("1.23", Field()) == (1.23, [])


# Generated at 2022-06-22 06:26:44.363198
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.base import ValidationError
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import (
        ErrorMessage,
        FieldPath,
    )
    from typesystem.tokenize.tokens import DictToken, ScalarToken
    from typesystem.types import IntegerType

    class PersonSchema(Schema):

        name = IntegerType(required=True)
        balance = IntegerType(required=True)


# Generated at 2022-06-22 06:26:55.686035
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        key1:
            - 'a'
            - 'b'
            - 'c'
        key2:
            foo: bar
            bar: baz
            baz: foo
    """)
    assert isinstance(token, DictToken)
    assert token.keys == ["key1", "key2"]
    assert isinstance(token.items["key1"], ListToken)
    assert token.items["key1"].value == ["a", "b", "c"]
    assert isinstance(token.items["key2"], DictToken)
    assert token.items["key2"].keys == ["foo", "bar", "baz"]
    assert token.items["key2"].items["bar"].value == "baz"



# Generated at 2022-06-22 06:27:07.784394
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml('"hello"'), ScalarToken)
    assert isinstance(tokenize_yaml('"hello"'), ScalarToken)
    assert isinstance(tokenize_yaml('hello'), ScalarToken)
    assert isinstance(tokenize_yaml('["hello"]'), ListToken)
    assert isinstance(tokenize_yaml('{hello: "hello"}'), DictToken)
    assert isinstance(tokenize_yaml('+1'), ScalarToken)
    assert isinstance(tokenize_yaml('+1.0'), ScalarToken)
    assert isinstance(tokenize_yaml('true'), ScalarToken)
    assert isinstance(tokenize_yaml('false'), ScalarToken)
    assert isinstance(tokenize_yaml('null'), ScalarToken)
    assert tokenize_

# Generated at 2022-06-22 06:27:19.641728
# Unit test for function validate_yaml
def test_validate_yaml():
    # NOTE: this test function is kept in the tokenize module because it is
    # intended to be used as a unit test for the validate_yaml function. It
    # could be moved to a different location (such as the top-level typesystem
    # package) if/when we add tests that are not directly tied to implementation
    # code.

    class SimpleSchema(Schema):
        schema = {
            "name": {"type": "string"},
            "salary": {"type": "number"},
            "manager": {"type": "boolean"},
        }

    class NestedSchema(Schema):
        schema = {
            "name": {"type": "string"},
            "salary": {"type": "number"},
            "boss": {"schema": SimpleSchema},
        }


# Generated at 2022-06-22 06:27:30.445853
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Float, Schema
    from typesystem import ParseError

    class SimpleSchema(Schema):
        string = String()
        integer = Integer()
        float = Float()

    # Valid cases
    assert validate_yaml("string: 'yes'\ninteger: 10\nfloat: 2.5", SimpleSchema) == \
        ({"string": "yes", "integer": 10, "float": 2.5}, [])
    assert validate_yaml("""string: "yes"\ninteger: 10\nfloat: 2.5""", SimpleSchema) == \
        ({"string": "yes", "integer": 10, "float": 2.5}, [])

    # Invalid cases

# Generated at 2022-06-22 06:27:36.078078
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml(" ") == None
    assert tokenize_yaml("a: 1") == {"a": 1}
    assert tokenize_yaml("[1,2,3]") == [1, 2, 3]
    assert tokenize_yaml("-1") == -1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("'foo'") == "foo"



# Generated at 2022-06-22 06:27:47.653992
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    '''
    Test Case to check the tokenize_yaml functions
    '''

    # trying to load empty string
    try:
        tokenize_yaml('')
    except ParseError as e:
        assert e.text == "No content." and e.code == "no_content" and e.position.line_no == 1 and e.position.column_no == 1 and e.position.char_index == 0

    # trying to load a string with a scalar type
    try:
        tokenize_yaml('42')
    except ParseError as e:
        assert e.text == "'42' is not a valid YAML tag." and e.code == "parse_error" and e.position.line_no == 1 and e.position.column_no == 1 and e.position.char_index == 0

   

# Generated at 2022-06-22 06:27:58.646109
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Example taken from https://yaml-multiline.info/examples-for-python/
    content = """
    # Example taken from https://yaml-multiline.info/examples-for-python/
    name: Alan Turing
    date-of-birth: 23.06.1912
    date-of-death: 07.06.1954
    bio:
        Alan Mathison Turing was a British mathematician, computer scientist, logician, cryptanalyst, philosopher, and theoretical biologist.
        Turing was highly influential in the development of theoretical computer science, providing a formalization of the concepts of algorithm and computation with the Turing machine, which can be considered a model of a general-purpose computer.
        Turing is widely considered to be the father of theoretical computer science and artificial intelligence.
    """
    token = tokenize_yaml(content)
    # We use y

# Generated at 2022-06-22 06:28:05.211043
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    string_field: hello
    int_field: 5
    float_field: 3.2
    bool_field: true
    list_field:
    - 1
    - 2
    - 3
    '''

    class SimpleSchema(Schema):
        string_field = Field(str)
        int_field = Field(int)
        float_field = Field(float)
        bool_field = Field(bool)
        list_field = Field([int])

    value, error_messages = validate_yaml(content, SimpleSchema)

    assert len(error_messages) == 0

# Generated at 2022-06-22 06:28:11.478536
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    assert isinstance(tokenize_yaml(b"test"), ScalarToken)
    assert isinstance(tokenize_yaml(b"test: hello"), DictToken)
    assert isinstance(tokenize_yaml(b"test: hello\n  - hello"), DictToken)
    assert isinstance(tokenize_yaml(b"- hello"), ListToken)
    assert isinstance(tokenize_yaml(b"- 123"), ListToken)
    assert isinstance(tokenize_yaml(b"- true"), ListToken)

    assert tokenize_yaml(b"test: hello").value == {"test": "hello"}
    assert tokenize_yaml(b"- hello").value == ["hello"]

# Generated at 2022-06-22 06:28:21.387608
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(validators=["max_length:4"])
    assert validate_yaml("foobar", field) == (
        "foobar",
        Message(
            text="Ensure this value has at most 4 characters (it has 6).",
            code="max_length",
            position=Position(1, 6, 11),
        ),
    )
