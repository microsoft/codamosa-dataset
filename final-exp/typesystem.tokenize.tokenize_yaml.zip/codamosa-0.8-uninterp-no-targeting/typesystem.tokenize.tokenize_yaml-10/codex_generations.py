

# Generated at 2022-06-22 06:18:41.006262
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer

    class Stuff(Schema):
        name = String()
        age = Integer()

    # Test valid case
    result, error_messages = validate_yaml("name: John\nage: 42", Stuff)
    assert result == {"name": "John", "age": 42}

    # Test invalid case
    result, error_messages = validate_yaml("name: John\nage: xyzzy", Stuff)
    assert error_messages == [
        Message(
            text="Value is not a valid integer.",
            code="invalid_type",
            position=Position(column_no=5, line_no=2, char_index=10),
        )
    ]



# Generated at 2022-06-22 06:18:46.829133
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("foo"), ScalarToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("1.0"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)



# Generated at 2022-06-22 06:18:56.407516
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml
    """
    import typesystem
    import typesystem.exceptions

    class Company(typesystem.Schema):
        name = typesystem.String(max_length=40)
        established = typesystem.Date(format="%Y-%m-%d")

    data = """
    name: Acme
    established: "1942-04-01"
    """

    value, error_messages = validate_yaml(data, validator=Company)
    assert value == {"name": "Acme", "established": "1942-04-01"}
    assert error_messages == []

    data = """
    established: "1942-04-01"
    name: Acme
    """

    value, error_messages = validate_yaml(data, validator=Company)
   

# Generated at 2022-06-22 06:19:09.055039
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    test if validate_yaml() function works as expected
    """
    Schema = type("Schema", (Schema,), {"name": fields.String()})
    value, error_messages = validate_yaml("name: 'Test'", Schema)
    assert value == {"name": "Test"}
    assert error_messages == []

    value, error_messages = validate_yaml("name: Test", Schema)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].code == 'validation_error'
    assert error_messages[0].text == 'Value must be a string.'

    value, error_messages = validate_yaml("word: 'test'", Schema)
    assert value is None
    assert len(error_messages)

# Generated at 2022-06-22 06:19:20.683501
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem as ts
    from typesystem.base import get_validation_errors
    from typesystem.types import String
    from typesystem.schemas import CreateSchema

    class UserCreateSchema(CreateSchema):
        name = String(max_length=100)

    # Valid data
    data = """name: John Smith"""
    content = (None, data)
    value, error_messages = validate_yaml(content, UserCreateSchema)
    assert value == {"name": "John Smith"}
    assert not error_messages

    # Valid data with extra whitespace
    data = """name:   John Smith   """
    content = (None, data)
    value, error_messages = validate_yaml(content, UserCreateSchema)
    assert value == {"name": "John Smith"}
    assert not error

# Generated at 2022-06-22 06:19:27.208047
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Array, Integer, Object
    from typesystem.exceptions import ValidationError

    class Child(Object):
        fields = {
            "name": String,
            "age": Integer
        }

    class Person(Object):
        fields = {
            "name": String,
            "age": Integer,
            "children": Array[Child]
        }

    content = '''
    name: "Ben"
    age: 20
    children:
      - name: "Alice"
        age: 12
      - name: "Bob"
        age: 14
    '''


# Generated at 2022-06-22 06:19:38.639883
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "a:\n  - b\n  - c"
    result = tokenize_yaml(content)

    assert isinstance(result, DictToken)
    assert result.value == {"a": ["b", "c"]}
    assert result.start_index == 0
    assert result.end_index == len(content)
    assert result.content == content
    assert result.get_position(index=0).line_no == 1
    assert result.get_position(index=0).column_no == 0
    assert result.get_position(index=0).char_index == 0
    assert result.get_position(index=1).line_no == 1
    assert result.get_position(index=1).column_no == 1
    assert result.get_position(index=1).char_index == 1

# Generated at 2022-06-22 06:19:49.989147
# Unit test for function validate_yaml
def test_validate_yaml():
    # This test uses the typesystem.schemas.Schema class as a validator.
    class TestSchema(Schema):
        a = Field(type=int)
        b = Field(type=int)

    # Test error handling with a Schema instance
    content = "a: 1\nb: yaml"
    result = validate_yaml(content=content, validator=TestSchema)
    assert isinstance(result, tuple) and len(result) == 2
    assert result[0] == ({"a": 1, "b": "yaml"}, None)
    assert isinstance(result[1], list) and len(result[1]) == 1
    assert result[1][0].code == "type_error"

    # Test error handling with a Schema class

# Generated at 2022-06-22 06:19:55.496962
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = typing.Union[list, typing.Dict[str, int]]
    content = "name: 'test'"
    try:
        result = validate_yaml(content, validator)
        assert isinstance(result[0], result[1])
    except ValueError:
        print(result[1])

    # Create a Schema and test the function
    class PersonSchema(Schema):
        name = typing.Union[str, int]
        age = int

    content = "name: 'test' \n age: '29'"
    try:
        result = validate_yaml(content, PersonSchema)
        assert isinstance(result[0], result[1])
    except ValueError:
        print(result[1])

# Generated at 2022-06-22 06:20:00.579833
# Unit test for function validate_yaml
def test_validate_yaml():
    class Comment(Schema):
        username = Field(type=str)
        body = Field(type=str)

    content = "username: brian\nbody: Hello"

    valid, errors = validate_yaml(content=content, validator=Comment)
    assert valid

    invalid_content = "username: brian\nbody: Hello\n"
    valid, errors = validate_yaml(content=invalid_content, validator=Comment)
    assert not valid
    assert len(errors) == 1

# Generated at 2022-06-22 06:20:13.827706
# Unit test for function tokenize_yaml

# Generated at 2022-06-22 06:20:25.917437
# Unit test for function validate_yaml
def test_validate_yaml():
	from typesystem import String, fields, types
	from typesystem.schemas import Schema
	from typesystem.tokenize.tokens import DictToken, ScalarToken

	# Test 1, Validating a string
	@fields.define_field("k", required=True, type = String)
	class D(Schema):
		pass
	
	value, errors = validate_yaml(content = "k: \"v\"", validator = D)

	assert(isinstance(value, DictToken))
	assert(isinstance(value.value["k"], ScalarToken))

	# Test 2, Validating a string with errors
	value, errors = validate_yaml(content = "k: \"v\"", validator = types.Integer)

# Generated at 2022-06-22 06:20:30.644413
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == 'No content.'
    assert tokenize_yaml("1") == '1'
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]

if __name__ == '__main__':
    test_tokenize_yaml()

# Generated at 2022-06-22 06:20:39.478508
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("2")
    assert isinstance(token, ScalarToken)
    assert token.value == 2
    assert token.start == 0
    assert token.end == 1
    assert token.content == "2"

    token = tokenize_yaml("2.0")
    assert isinstance(token, ScalarToken)
    assert token.value == 2.0
    assert token.start == 0
    assert token.end == 3
    assert token.content == "2.0"

    token = tokenize_yaml("-2")
    assert isinstance(token, ScalarToken)
    assert token.value == -2
    assert token.start == 0
    assert token.end == 2
    assert token.content == "-2"

    token = tokenize_yaml("'str'")

# Generated at 2022-06-22 06:20:46.627696
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), ScalarToken)
    assert isinstance(tokenize_yaml("[1]"), ListToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("3.14"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)

# Generated at 2022-06-22 06:20:58.643348
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Boolean
    from typesystem.schemas import Schema as SchemaClass

    class MySchema(SchemaClass):
        my_string = String(max_length=10)
        my_integer = Integer()
        my_boolean = Boolean()

    content = "my_string: foo\nmy_integer: 1\nmy_boolean: true"
    result = validate_yaml(content, validator=MySchema)
    assert result == (
        {
            "my_string": "foo",
            "my_integer": 1,
            "my_boolean": True,
        },
        [],
    )


# Generated at 2022-06-22 06:21:09.027994
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem.fields import Array, Integer, String

    schema = Array(of=Integer())
    content = b"- 1\n- 3\n- 6"
    (result, error_messages) = validate_yaml(content, validator=schema)
    assert result == [1, 3, 6]
    assert error_messages == []

    schema = Array(of=String())
    (result, error_messages) = validate_yaml(content, validator=schema)
    assert result == None # type: ignore
    assert len(error_messages) == 1
    assert error_messages[0].position.line_no == 3
    assert error_messages[0].position.column_no ==3

# Generated at 2022-06-22 06:21:16.548422
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Assert that the validate_yaml function raises a ParseError if there is no content
    passed into it, that a validation error is raised if there is an error in the input
    and that an output is printed if the input is valid
    """
    import typesystem

    class JokeSchema(typesystem.Schema):
        text = typesystem.String(description="The text of a joke.")

    validator = JokeSchema()

    assert validate_yaml(content="", validator=validator) == ({}, [])

    with pytest.raises(ParseError):
        validate_yaml(content=" ", validator=validator)


# Generated at 2022-06-22 06:21:22.025428
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test case 1. Given a empty string
    content = ''
    position = Position(column_no=1, line_no=1, char_index=0)
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml(content)
    assert 'No content.' in str(excinfo.value)
    assert 'no_content' in str(excinfo.value)
    assert 'position' in str(excinfo.value.position)
    assert 'column_no' in str(excinfo.value.position)
    assert '1' in str(excinfo.value.position)
    assert 'line_no' in str(excinfo.value.position)
    assert '1' in str(excinfo.value.position)
    assert 'char_index' in str(excinfo.value.position)

# Generated at 2022-06-22 06:21:31.623561
# Unit test for function validate_yaml

# Generated at 2022-06-22 06:21:46.808257
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("a: b") == DictToken({"a": "b"}, 0, 5, "a: b")
    assert tokenize_yaml("a: b\nb: c") == DictToken({"a": "b", "b": "c"}, 0, 9, "a: b\nb: c")
    assert tokenize_yaml("- a\n- b") == ListToken(["a", "b"], 0, 8, "- a\n- b")
    assert tokenize_yaml("- a\n- B") == ListToken(["a", "B"], 0, 8, "- a\n- B")
    assert tokenize_yaml("!!python/tuple [a, b]") == ListToken(("a", "b"), 0, 20, "!!python/tuple [a, b]")

# Generated at 2022-06-22 06:21:55.176294
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """Test tokenize_yaml"""
    assert isinstance(tokenize_yaml(""), DictToken)
    assert isinstance(tokenize_yaml("a: 1"), DictToken)
    assert isinstance(tokenize_yaml("a: 1\n"), DictToken)
    assert isinstance(tokenize_yaml("a: 1\nb: 2"), DictToken)
    assert isinstance(tokenize_yaml("- a"), ListToken)
    assert isinstance(tokenize_yaml("- a\n"), ListToken)
    assert isinstance(tokenize_yaml("- a\n- b"), ListToken)



# Generated at 2022-06-22 06:22:05.383735
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("", validator=int) == (None, [])
    assert validate_yaml("", validator=int, skip_errors=True) == (None, [])
    assert validate_yaml("", validator=int, skip_errors=False) == (None, [])

    assert validate_yaml("1", validator=int) == (1, [])
    assert validate_yaml("1", validator=int, skip_errors=True) == (1, [])
    assert validate_yaml("1", validator=int, skip_errors=False) == (1, [])

    assert validate_yaml(1, validator=int) == (1, [])
    assert validate_yaml(1, validator=int, skip_errors=True) == (1, [])
    assert validate_

# Generated at 2022-06-22 06:22:15.966624
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Tokens representing the same data structure, but with different metadata
    content_1 = '{"a": {"b": "c"}}'
    token_1 = tokenize_yaml(content_1)

    content_2 = '{"a": {"b": "c"},}'
    token_2 = tokenize_yaml(content_2)

    content_3 = '''
        a:
          b: c
    '''

    token_3 = tokenize_yaml(content_3)

    for token in [token_1, token_2, token_3]:
        assert isinstance(token, DictToken)
        assert token.keys() == ["a"]

        assert isinstance(token["a"], DictToken)
        assert token["a"].keys() == ["b"]


# Generated at 2022-06-22 06:22:27.217885
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: George
    age: 40
    """

    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "George", "age": 40}
    assert error_messages == []

    content = "boom"
    try:
        validate_yaml(content, PersonSchema)
    except ParseError as exc:
        assert exc.text == "while scanning for the next token found character 'b' that cannot start any token."
        assert exc.code == "parse_error"

# Generated at 2022-06-22 06:22:37.226390
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
    # Comment here
    ---
    key: "value"
    key2:
        - value2
        - value2a
    key3:
        key4: "foo"
    '''

    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value.get('key')

    content = '''
    ---
    - "value"
    - "value2"
    '''

    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert len(token.value) == 2

    content = '''
    ---
    key:
    '''

    with pytest.raises(ParseError,):
        tokenize_yaml(content)


# Generated at 2022-06-22 06:22:41.717125
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "name: jack"
    token = tokenize_yaml(content)

    assert token == {'name': 'jack'}

    content = """
    name: jack
    age: 20
    """

    token = tokenize_yaml(content)

    assert token == {'name': 'jack', 'age': 20}



# Generated at 2022-06-22 06:22:52.584342
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Check tokenize_yaml for no content
    try:
        tokenize_yaml("")
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.details["line"] == ""

    # Check tokenize_yaml for non-nested
    token = tokenize_yaml("value: 10")
    assert token.value == {"value": 10}
    assert token.start == 0
    assert token.end == len("value: 10") - 1
    assert token.content == "value: 10"

    # Check tokenize_yaml for nested

# Generated at 2022-06-22 06:22:57.000556
# Unit test for function validate_yaml
def test_validate_yaml():
    data = "name: Kurt Russell"
    validator = Schema(fields={"name": Field(basetype=str)})
    assert validate_yaml(data, validator)[0] == {"name": "Kurt Russell"}



# Generated at 2022-06-22 06:23:09.224042
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Boolean

    class SimpleSchema(Schema):
        name = String()
        age = Integer()
        active = Boolean()

        def validate(self, data: typing.Dict[str, typing.Any]) -> typing.Any:
            if data["age"] > 60:
                raise ValidationError({"age": "too old"})
            return data

    # Test a valid YAML string
    content = """name: Jane Doe
age: 42
active: true"""
    value, error_messages = validate_yaml(content, SimpleSchema)
    assert error_messages == [], f"Expected empty error messages, got {error_messages}"

    # Test an invalid YAML string
    content = """name: Jane Doe
age: 42
active z true"""
    _,

# Generated at 2022-06-22 06:23:21.919209
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    class Person(Schema):
        name = String(max_length=5)
    content = b"name: this is a long name"
    errors = validate_yaml(content, Person())[1]
    assert len(errors) == 1
    error = errors[0]
    assert error.text == 'Value is too long (5 characters max).'
    assert error.position.line_no == 1
    assert error.position.column_no == 15
    assert error.position.char_index == 15

# Generated at 2022-06-22 06:23:30.559370
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test that document start and end markers in YAML are ignored.
    # NOTE: this is not guaranteed by the spec. If a future version of
    # pyyaml starts considering the document start and end markers then
    # we will need to update this test.
    eq_(
        tokenize_yaml(
            textwrap.dedent(
                """
                ---
                a: 1
                ---
                b: 2
                ---
                """
            )
        ),
        DictToken({"b": 2}, 0, 20, content="b: 2"),
    )

    # Test that the 'content' attribute is correctly set on each token
    parsed = tokenize_yaml(textwrap.dedent("""\
    foo:
      - 1
      - 2
      -
        - 3
        - 4
    """))
    eq

# Generated at 2022-06-22 06:23:34.764513
# Unit test for function validate_yaml
def test_validate_yaml():
    token = tokenize_yaml(content = '{"name": "john"}')
    value, error_messages = validate_with_positions(token=token, validator={"type":"string", "required":True, "max_length": 5})
    assert value == 'john'
    assert error_messages == []



# Generated at 2022-06-22 06:23:46.481160
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = typing.List[typing.Dict[typing.Any, typing.Any]]

    raw_yaml = textwrap.dedent(
        """
        - {
            first: 'John',
            last: Doe
        }
        - {
            first: 'Adam',
            last: Smith
        }
        """
    ).strip()

    value, error_messages = validate_yaml(raw_yaml, PersonSchema)

    assert not error_messages
    assert value == [
        {"first": "John", "last": "Doe"},
        {"first": "Adam", "last": "Smith"},
    ]


# Generated at 2022-06-22 06:23:59.154435
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''---
name:
  first_name: John
  last_name: Smith
age: 25
address:
  street: 65 Ambling Way
  city: Springfield
  state: Oregon
...
'''
    token = tokenize_yaml(content)

# Generated at 2022-06-22 06:24:07.964961
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("""
        str: "This is a string."
        int: 123
        float: 123.45
        bool: True
        null: ~
        empty: ~
        list: ["This", "is", "a", "list"]
        dict:
            str: "This is a dict."
        """) == {
        "str": "This is a string.",
        "int": 123,
        "float": 123.45,
        "bool": True,
        "null": None,
        "empty": None,
        "list": ["This", "is", "a", "list"],
        "dict": {"str": "This is a dict."},
    }


# Generated at 2022-06-22 06:24:14.150549
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Test the tokenize_yaml function
    """
    from typesystem.fields import Integer

    validator = Integer()

    contents = ["0", "1.4", "1.0", ".4", "1.4e1", "1.4e+1"]
    for content in contents:
        result, error_messages = validate_yaml(content, validator)
        assert result == float(content)
        assert error_messages == []

# Generated at 2022-06-22 06:24:18.255768
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String

    content = "foo: bar"
    schema = Schema({"foo": String()})
    value, messages = validate_yaml(content, schema)
    assert messages == []
    assert value == {"foo": "bar"}

# Generated at 2022-06-22 06:24:28.328944
# Unit test for function validate_yaml
def test_validate_yaml():
    basic_yaml_example = """
        a: 1
        b: [1,2,3]
        c: true
        d: null
        e: a string
        f: 1e-15
    """
    int_schema = Schema(fields={"a": Field(int)})
    int_valid, int_messages = validate_yaml(
        content=basic_yaml_example, validator=int_schema
    )

    assert int_messages == []
    assert int_valid == {"a": 1, "b": [1, 2, 3], "c": True, "d": None, "e": "a string", "f": 1e-15}

    int_array_schema = Schema(fields={"b": Field(int, array=True)})
    int_valid, int_

# Generated at 2022-06-22 06:24:31.145867
# Unit test for function validate_yaml
def test_validate_yaml():
  content = '''
  a: 1
  b: 2
  '''
  token = tokenize_yaml(content)
  assert token['a'] == 1 and token['b'] == 2

# Generated at 2022-06-22 06:24:47.599097
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema([
        Field(name="a", type="integer", required=True),
        Field(name="b", type="string"),
    ])[0]

    assert validate_yaml(
        content="a: 10\nb: hello world\n", validator=schema
    ) == {"a": 10, "b": "hello world"}

    assert validate_yaml(content="a: 10\n", validator=schema) == {"a": 10}

    # Missing 'a'
    result, messages = validate_yaml(content="b: hello world\n", validator=schema)
    assert result is None

# Generated at 2022-06-22 06:24:59.797280
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test valid YAML string
    content = b"int_field: 123\nstring_field: Test string"
    class ExampleSchema(Schema):
        int_field = Field(type=int)
        string_field = Field(type=str)
    value, errors = validate_yaml(content, ExampleSchema)
    assert value == {"int_field": 123, "string_field": "Test string"}
    assert not errors

    # Test invalid YAML string
    content = b"int_field: 123\nstring_field: 'Test string"
    value, errors = validate_yaml(content, ExampleSchema)
    assert value == {"int_field": 123}
    assert errors[0].position.line_no == 2
    assert errors[0].position.char_index == 23

# Generated at 2022-06-22 06:25:06.016163
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test = "This is a test string."
    token = tokenize_yaml(test)
    assert isinstance(token, ScalarToken)
    assert token.value == test
    assert token.position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=22, line_no=1, char_index=21)



# Generated at 2022-06-22 06:25:17.370765
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("123", validator=int) == (123, None)
    assert validate_yaml("[123]", validator=int) == ([123], None)
    assert validate_yaml("[[123], 123]", validator=int) == ([[123], 123], None)
    assert validate_yaml("[123, 456]", validator=int) == ([123, 456], None)
    assert validate_yaml("{123: 456}", validator=int) == ({123: 456}, None)
    assert validate_yaml("[123, {}]", validator=int) == ([123, {}], None)
    assert validate_yaml("[123, {abc: 123}]", validator=int) == ([123, {'abc': 123}], None)

# Generated at 2022-06-22 06:25:28.158432
# Unit test for function validate_yaml
def test_validate_yaml():

    # Testing empty list
    # When provided with an empty list as content, an empty error message is returned
    assert validate_yaml(content=[], validator=Schema) == (None, [])
    # If a non-empty error message is returned, this indicates an error
    assert validate_yaml(content=[], validator=Schema) != (None, ["error message"])

    # Testing invalid content
    # When provided with an invalid content, the error message returned indicates that there is an error in the list
    assert validate_yaml(content="[", validator=Schema) == (None, [Message(text="No content.", position=Position(column_no=1, line_no=1, char_index=0), code="no_content", type="error")])

# Generated at 2022-06-22 06:25:40.677995
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import String, Integer

    class TestSchema(Schema):
        test = String(required=True)
        other = Integer(default=2) 

    try:
        import yaml
    except ImportError:  # pragma: no cover
        yaml = None  # type: ignore

    assert yaml is not None, "'pyyaml' must be installed."

    good_data = b"test: good"
    assert validate_yaml(good_data, validator=TestSchema)

    bad_data = b"this: is not right"
    try:
        validate_yaml(bad_data, validator=TestSchema)
        should_fail = True
    except ValidationError as e:
        assert e.messages[0].position.column_no == 6

# Generated at 2022-06-22 06:25:51.989662
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    key: value
    """
    validator = Field(type="string")
    value, error_messages = validate_yaml(content, validator)

    assert value == "value"
    assert error_messages == []

    content = """
    key: false
    """
    validator = Field(type="string")
    value, error_messages = validate_yaml(content, validator)

    assert value == "false"
    assert error_messages == []

    content = """
    key: value
    """
    validator = Field(type="object")
    value, error_messages = validate_yaml(content, validator)

    assert value == "value"

# Generated at 2022-06-22 06:26:01.842911
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    value = tokenize_yaml("""
        root:
          first_entry:
            name: foo
            description: bar
            entries:
              - one
              - two
              - three
          second_entry:
            name: baz
            description: bat
            entries:
              - four
              - five
              - six
    """)
    assert ({'root': {'first_entry': {'name': 'foo', 'description': 'bar', 'entries': ['one', 'two', 'three']}, 'second_entry': {'name': 'baz', 'description': 'bat', 'entries': ['four', 'five', 'six']}}} == value)

# Generated at 2022-06-22 06:26:06.718092
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    schema = Schema(structure={
        "name": String(),
        "address": String(),
    })

    yaml_string = """
    name: "Bobby Tables"
    address: "123 Main St."
    """

    result = validate_yaml(yaml_string, schema)
    assert result == ({"name": "Bobby Tables", "address": "123 Main St."}, [])

# Generated at 2022-06-22 06:26:18.448538
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Testing empty string case
    with pytest.raises(ParseError) as exc_info:
        tokenize_yaml("")
    assert str(exc_info.value) == "No content."

    # Testing invalid yaml string
    with pytest.raises(ParseError) as exc_info:
        tokenize_yaml("\n \n \n %")
    assert str(exc_info.value) == "Unexpected character '%' at line:4, column:1, index:6."

    # Testing valid yaml string
    assert tokenize_yaml("- hello \n  - world") == ListToken(["hello", "world"], 0, 19)

# Generated at 2022-06-22 06:26:28.030659
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test validate yaml against a simple schema
    class Foo(Schema):
        name = Field("string")
        age = Field("integer")

    data = """
    name: test
    age: 30
    """
    v, e = validate_yaml(data, Foo)
    assert v is not None
    assert e is None



# Generated at 2022-06-22 06:26:40.512614
# Unit test for function validate_yaml
def test_validate_yaml():
    class PetSchema(Schema):
        name = "string"
        age = "integer"

    class PersonSchema(Schema):
        name = "string"
        pet = "PetSchema"

    good_person_yaml = """
        name: "Bob"
        pet:
          name: "Fluffy"
          age: 4
    """
    value, error_messages = validate_yaml(
        content=good_person_yaml, validator=PersonSchema
    )
    assert value == {"name": "Bob", "pet": {"name": "Fluffy", "age": 4}}
    assert not error_messages

    bad_person_yaml = """
        name: "Bob"
        pet:
            name: "Fluffy"
            age: "not an age"
    """
    value,

# Generated at 2022-06-22 06:26:50.712658
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    name: "Joe"
    age: 21
    """
    expected = {'name': 'Joe', 'age': 21}
    assert tokenize_yaml(content) == expected


# Unit tests for function validate_yaml

# Generated at 2022-06-22 06:27:00.911062
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    token = tokenize_yaml("""
        foo:
          - bar
          - baz
          - [qux, quux]
          - corge
          - grault:
              garply: waldo
              fred: plugh
              xyzzy: thud
          - waldo
        foo2: bar
    """)

# Generated at 2022-06-22 06:27:09.916688
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("- 1"), ListToken)
    assert isinstance(tokenize_yaml("""
        - 1
        - 2
    """), ListToken)
    assert isinstance(tokenize_yaml("""
        a: 1
    """), DictToken)
    assert isinstance(tokenize_yaml("""
        a: 1
        b: 2
    """), DictToken)
    assert isinstance(tokenize_yaml('1'), ScalarToken)
    assert isinstance(tokenize_yaml('"a"'), ScalarToken)
    assert isinstance(tokenize_yaml('true'), ScalarToken)
    assert isinstance

# Generated at 2022-06-22 06:27:14.189167
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        people:
          - name: Alice
            age: 23
            foods:
              - apple
              - orange
          - name: Bob
            age: 27
            foods:
              - banana
              - pineapple
        """)
    expected = {
        "people": [
            {
                "name": "Alice",
                "age": 23,
                "foods": ["apple", "orange"],
            },
            {
                "name": "Bob",
                "age": 27,
                "foods": ["banana", "pineapple"],
            },
        ]
    }
    assert token.get() == expected



# Generated at 2022-06-22 06:27:17.943577
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test empty yaml
    try:
        tokenize_yaml('')
        assert False, 'Should have raised ParseError'
    except ParseError as e:
        assert e.position.column_no == 1
        assert e.position.line_no == 1
        assert e.position.char_index == 0
        assert e.text == 'No content.'
        assert e.code == 'no_content'

    # Test parse error
    try:
        tokenize_yaml('{')
        assert False, 'Should have raised ParseError'
    except ParseError as e:
        assert e.position.column_no == 1
        assert e.position.line_no == 1
        assert e.position.char_index == 0

# Generated at 2022-06-22 06:27:27.221749
# Unit test for function validate_yaml
def test_validate_yaml():
    assert(validate_yaml('a: hi', Field(str, format="date-time"))[1] == [Message('Not a valid date-time.',
        code='date_time', position=Position(char_index=3, column_no=4, line_no=1))])
    assert(validate_yaml('a: hi', Field(str))[1] == [])
    assert(validate_yaml('a: hi', Field(str, format="date-time", required=True))[1] == [Message('Value may not be null.', code='required',
        position=Position(char_index=3, column_no=4, line_no=1))])

# Generated at 2022-06-22 06:27:36.597267
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import fields, schemas
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken, Token

    name_field = fields.String(name="name")
    dob_field = fields.String(name="date_of_birth")
    age_field = fields.Integer(name="age")
    username_field = fields.String(name="username")
    password_field = fields.String(name="password")

    class LoginSchema(schemas.Schema):
        username = username_field
        password = password_field

    class UserSchema(schemas.Schema):
        name = name_field
        date_of_birth = dob_field
        age = age_field


# Generated at 2022-06-22 06:27:47.868468
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 29
    """
    assert validate_yaml(content=content, validator=PersonSchema) == {
        "name": "John",
        "age": 29
    }, "Should return data"

    content = """
    name: John Doe
    """
    assert validate_yaml(content=content, validator=PersonSchema) == {
        "name": "John Doe",
        "age": None
    }, "Should return data"

    content = """
    name: John Doe
    age: 29
    """
    assert validate_yaml(content=content, validator=PersonSchema) == {
        "name": "John Doe",
        "age": 29
    }, "Should return data"

    content = """
    name: John
    """
    assert validate_

# Generated at 2022-06-22 06:28:03.335354
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('["hello", "world"]').value == ["hello", "world"]
    assert tokenize_yaml('["hello", "world"]').start == 0
    assert tokenize_yaml('["hello", "world"]').end == 14
    assert tokenize_yaml('["hello", "world"]').content == '["hello", "world"]'
    assert isinstance(tokenize_yaml('["hello", "world"]'), ListToken)
    assert tokenize_yaml('hello: "world"').value == {"hello": "world"}
    assert tokenize_yaml('hello: "world"').start == 0
    assert tokenize_yaml('hello: "world"').end == 11
    assert tokenize_yaml('hello: "world"').content == 'hello: "world"'

# Generated at 2022-06-22 06:28:14.277266
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    class PersonSchema(Schema):
        first_name = String(max_length=5)
        last_name = String(max_length=5)

    def get_error_text(msg):
        return "".join(map(lambda x: x.text, msg.children))

    yaml_content = b"""
        first_name: John
        last_name: Smith
    """

    # Test success case
    values, msg = validate_yaml(yaml_content, validator=PersonSchema)
    assert values == {
        "first_name": "John",
        "last_name": "Smith"
    }

    assert not msg

    # Test failure case
    y