

# Generated at 2022-06-22 06:18:38.437775
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml('{"key": "value"}'), DictToken)
    assert isinstance(tokenize_yaml('["item1", "item2"]'), ListToken)
    assert isinstance(tokenize_yaml('"some value"'), ScalarToken)
    assert isinstance(tokenize_yaml('some_value'), ScalarToken)


# Generated at 2022-06-22 06:18:41.718904
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Basic case
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}

    # No content case
    assert tokenize_yaml("\n \t \n   \r\t   ") is None



# Generated at 2022-06-22 06:18:49.471243
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = '''
    {
        "type": "object",
        "properties": {
            "name": {
                "type": "string"
            },
            "telephone": {
                "type": "string",
                "format": "phone"
            },
            "email": {
                "type": "string",
                "format": "email"
            },
            "enabled": {
                "type": "boolean"
            }
        },
        "required": ["name"]
    }
    '''

    instance = '''
    {
        "name": "John Doe",
        "telephone": "1234",
        "email": "john@example.com",
        "enabled": null
    }
    '''


# Generated at 2022-06-22 06:18:59.014265
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    data:
      x: 1
      y: 2
    """
    root = tokenize_yaml(content)
    assert isinstance(root, DictToken)
    assert root.items["data"].items["x"] == ScalarToken(1, 9, 11, "data: ... y: 2")
    assert root.items["data"].items["y"] == ScalarToken(2, 18, 20, "data: ... y: 2")

    content = """!!python/object:collections.defaultdict [str,str]
        ? "scalar"
        : {"mapping": "with a scalar key"}
    """
    root = tokenize_yaml(content)
    assert isinstance(root, DictToken)


# Generated at 2022-06-22 06:18:59.910007
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "[1, 2, 3]"
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)

# Generated at 2022-06-22 06:19:06.926105
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_str = """
---
key: value
dict:
  one: two
  three: four
list:
- one
- two
- three
"""
    actual = tokenize_yaml(yaml_str)
    assert actual == {
        "key": "value",
        "dict": {"one": "two", "three": "four"},
        "list": ["one", "two", "three"],
    }


# Generated at 2022-06-22 06:19:18.247542
# Unit test for function validate_yaml
def test_validate_yaml():
    """Unit test for function validate_yaml"""
    import os
    import sys
    import pytest
    from typesystem.base import Type
    from typesystem.fields import String as String_
    from typesystem.schemas import Schema

    if sys.version_info[0] == 3 and sys.version_info[1] >= 5:
        from typesystem.fields import Integer as Integer_
        from typesystem.fields import Dict, List
    else:
        from typesystem.fields import Integer as Integer_  # type: ignore
        from typesystem.fields import Dict as Dict  # type: ignore
        from typesystem.fields import List as List  # type: ignore

    class MySchema(Schema):
        name = String_(max_length=100)
        number = Integer_()

# Generated at 2022-06-22 06:19:28.266477
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        a = Field(type_=str)
        b = Field(type_=str)

    #*****************************
    # test missing value
    #****************************
    content = """
    a: foo
    """
    err_msg = validate_yaml(
        content=content, validator=MySchema
    )[1]
    assert len(err_msg) == 2
    assert err_msg[0].text == "Value is missing."
    assert err_msg[0].code == "required"
    assert err_msg[0].position == Position(2, 3, 12)
    assert err_msg[1].text == "Value is missing."
    assert err_msg[1].code == "required"
    assert err_msg[1].position == Position(3, 3, 20)

# Generated at 2022-06-22 06:19:39.291388
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class IntegerList(Schema):
        value = ListToken(items=Integer())

    class IntegerListOfLists(Schema):
        value = ListToken(items=ListToken(items=Integer()))

    class StringDictOfLists(Schema):
        value = DictToken(
            keys=String(),
            values=ListToken(items=String()),
        )

    class Person(Schema):
        name = String(max_length=50)
        age = Integer(minimum=0)

    class People(Schema):
        value = ListToken(
            items=Person(),
            min_length=2,
        )


# Generated at 2022-06-22 06:19:41.915196
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    data = tokenize_yaml('{ "username": "Jane Doe" }')
    assert(data.value['username'] == 'Jane Doe' )


# Generated at 2022-06-22 06:19:55.905407
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    actual = tokenize_yaml("""
     # Just some comments
     a: 1
     b: 2
     c: 3
    """)
    expected = DictToken(
        {"a": ScalarToken(1, 2, 4, "a: 1\nb: 2\nc: 3\n"),
        "b": ScalarToken(2, 6, 8, "a: 1\nb: 2\nc: 3\n"),
        "c": ScalarToken(3, 10, 12, "a: 1\nb: 2\nc: 3\n")},
        0, 12, "a: 1\nb: 2\nc: 3\n"
    )
    assert actual == expected


# Generated at 2022-06-22 06:20:07.551879
# Unit test for function tokenize_yaml

# Generated at 2022-06-22 06:20:17.733779
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields

    class BookSchema(Schema):
        title = fields.String(max_length=60)
        publisher = fields.String(null=True)
        published_at = fields.DateTime(null=True)

    yaml_string = """
        title: Das Kapital
        author: Karl Marx
    """
    result = validate_yaml(yaml_string, BookSchema())
    assert result[0] is None
    errors = result[1]
    assert len(errors) == 2
    assert errors[0].code == "type_error"
    assert errors[1].code == "missing_field"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 6



# Generated at 2022-06-22 06:20:29.848854
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml function
    """
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem.schema import Schema
    from typesystem.fields import Boolean

    class TestSchema(Schema):
        """
        Define a simple schema for testing
        """

        field1 = Boolean()
        field2 = Boolean()

    validator = TestSchema()
    content = "field1: yes\nfield2: no\n"
    (value, messages) = validate_yaml(content, validator)
    assert value["field1"] is True
    assert value["field2"] is False
    assert messages == []

    content = "field1\nfield2: no\n"

# Generated at 2022-06-22 06:20:41.564902
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Expected result : tokenized dictionary
    tokenized_dict = tokenize_yaml(
        """
{
  "foo": 1,
  "bar": 2,
}
"""
    )
    assert isinstance(tokenized_dict, DictToken)
    assert tokenized_dict.value == {"foo": 1, "bar": 2}

    # Expected result : tokenized list
    tokenized_list = tokenize_yaml(
        """
[
  "foo",
  "bar",
]
"""
    )
    assert isinstance(tokenized_list, ListToken)
    assert tokenized_list.value == ["foo", "bar"]

    # Expected result : tokenized float
    tokenized_float = tokenize_yaml(
        """
1.4
"""
    )

# Generated at 2022-06-22 06:20:46.318837
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo: 42\n") == {'foo': 42}
    assert tokenize_yaml("foo: bar\n") == {'foo': 'bar'}
    assert tokenize_yaml("""key:
          - value1
          - value2""") == {'key': ['value1', 'value2']}



# Generated at 2022-06-22 06:20:52.254556
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("a: - b") == {"a": ["b"]}
    assert tokenize_yaml("a: - b - c") == {"a": ["b", "c"]}
    assert tokenize_yaml("a: - b - c\nd: e") == {"a": ["b", "c"], "d": "e"}


# Generated at 2022-06-22 06:20:58.588767
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    token = tokenize_yaml("""
    url: http:
    type: string
    """)

    assert isinstance(token, DictToken)
    assert len(token.items) == 2
    assert token.items[0][0] == "url"
    assert isinstance(token.items[0][1], ScalarToken)
    assert token.items[1][0] == "type"



# Generated at 2022-06-22 06:21:09.001522
# Unit test for function validate_yaml
def test_validate_yaml():
    # type: () -> None
    class Person(Schema):
        title = String(max_length=10)
        name = String(max_length=10)
        age = Number(minimum=10, maximum=100)
        # email = Email()

    yaml_str = textwrap.dedent(
        """\
        title: Mr
        name: Rob
        age: 33
        """
    )

    try:
        value, msgs = validate_yaml(yaml_str, Person)
    except ValidationError as exc:
        msgs = exc.messages
    except ParseError as exc:
        msgs = [exc.message]
    if msgs:
        print("\n".join(str(msg) for msg in msgs))


# Generated at 2022-06-22 06:21:13.785277
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields=[Field(name="expenses", type="list", items=Field(type="integer"))])
    payload = """expenses: [100, 200]"""
    value, errors = validate_yaml(payload, validator=schema)

    assert len(errors) == 0

# Generated at 2022-06-22 06:21:19.033046
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('{"a":3}')
    assert isinstance(token, DictToken)



# Generated at 2022-06-22 06:21:30.999195
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, Integer, String, Float
    from typesystem.tokenize.tokens import ScalarToken

    class TestSchema(Schema):
        name = String(min_length=5)
        age = Integer(description="Age must be a whole number.")
        height = Float(description="Height must be a number.", required=False)

    content = """
    name: Elizabeth Parker
    age: 25
    height: 1.85
    """

    assert validate_yaml(content, validator=TestSchema) == (
        {"name": "Elizabeth Parker", "age": 25, "height": 1.85},
        [],
    )

    content = """
    name: Beth
    age: 25
    """


# Generated at 2022-06-22 06:21:36.546178
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test for string
    content = "name: foo"
    result = tokenize_yaml(content)
    assert result == DictToken({"name": "foo"}, start=0, end=7, content=content)

    # test for bytestring
    content = b"name: foo"
    result = tokenize_yaml(content)
    assert result == DictToken({"name": "foo"}, start=0, end=7, content=content)


# Generated at 2022-06-22 06:21:47.661584
# Unit test for function validate_yaml

# Generated at 2022-06-22 06:21:57.922413
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test_yaml_dict = """
    a: 1
    b: "bla"
    c: true
    d: null
    e:
      - 1
      - false
      - "3"
    f:
      -
        f1: 1
        f2: 2
    g:
      g1:
        g11: 1
        g12: 2
      g2:
        g21: true
        g22: false
    """
    test_token = tokenize_yaml(test_yaml_dict)
    assert test_token['a'] == ScalarToken(1, 4, 7, test_yaml_dict)
    assert test_token['b'] == ScalarToken("bla", 10, 16, test_yaml_dict)

# Generated at 2022-06-22 06:22:00.390433
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field.string(format="uri")
    content = """
        - https://www.google.com/
        - https://www.google.com/
    """
    value, errors = validate_yaml(content, field)
    assert not errors, "Errors by uri format"



# Generated at 2022-06-22 06:22:11.274667
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(int, min_value=10)

    content = "8"
    value, error_messages = validate_yaml(content, field)
    message = error_messages[0]
    assert isinstance(message, Message)
    assert message.position.line_no == 1
    assert message.position.column_no == 1
    assert message.position.char_index == 0
    assert message.code == "min_value"

    content = "8\n"
    value, error_messages = validate_yaml(content, field)
    message = error_messages[0]
    assert isinstance(message, Message)
    assert message.position.line_no == 1
    assert message.position.column_no == 1
    assert message.position.char_index == 0

# Generated at 2022-06-22 06:22:20.147346
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    content = '''
     -
        a: 10
        b: "string"
     -
        a: "string"
        b: 20
    '''
    token = tokenize_yaml(content)
    errors = validate_with_positions(token, String())
    assert len(errors) == 1
    position = errors[0].position
    assert position.line_no == 3
    assert position.column_no == 14
    assert position.char_index == 44

# Generated at 2022-06-22 06:22:29.697885
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("foo")
    assert token.type == "scalar"
    assert token.value == "foo"
    assert token.start == 0
    assert token.end == 2
    assert token.content == "foo"

    token = tokenize_yaml([1, 2, 3])
    assert token.type == "list"
    assert token.value == [1, 2, 3]
    assert token.start == 0
    assert token.end == 5
    assert token.content == "[1, 2, 3]"

    token = tokenize_yaml({"foo": "bar"})
    assert token.type == "dict"
    assert token.value == {"foo": "bar"}
    assert token.start == 0
    assert token.end == 8
    assert token.content == "{foo: bar}"




# Generated at 2022-06-22 06:22:39.413271
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = fields.String()
        age = fields.Integer()

    content = """- name: Bob
      age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "Bob", "age": 30}
    assert errors == []
    content = """- name: Bob
      aeg: 30
    """
    value, errors = validate_yaml(content, Person)
    assert errors == [
        Message(
            text="Missing required field.",
            code="missing_required_field",
            field_name="age",
            field_index=1,
            position=Position(line_no=3, column_no=4, char_index=14),
        )
    ]

# Generated at 2022-06-22 06:22:52.931841
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("42") == ScalarToken(42, 0, 1, content="42")
    assert tokenize_yaml("42.7") == ScalarToken(42.7, 0, 3, content="42.7")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("off") == ScalarToken(False, 0, 3, content="off")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 3, content="foo")
    assert tokenize_yaml("'foo'") == ScalarToken("foo", 0, 5, content="'foo'")
    assert tokenize_yaml

# Generated at 2022-06-22 06:23:00.820120
# Unit test for function validate_yaml
def test_validate_yaml():
    # Validator
    class PostSchema(Schema):
        title = String()

    # Valid document
    content = "title: Hello"
    value, errors = validate_yaml(content, PostSchema)
    assert not errors
    assert value["title"] == "Hello"

    # Invalid document
    content = "title: 'Hello'"
    value, errors = validate_yaml(content, PostSchema)
    assert errors
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 6
    assert errors[0].position.char_index == 5



# Generated at 2022-06-22 06:23:08.991047
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml function
    """
    # Test of the schema:
    schema = Schema(
        fields={"name": Field(required=True, type_="string"), "age": Field(required=True, type_="integer"), }
    )

    # Create an object conforming to the schema
    content = """
    name: 'Test'
    age: 42
    """

    # Test that the function returns the correct value.
    assert validate_yaml(content, schema)[0] == {"name": "Test", "age": 42}



# Generated at 2022-06-22 06:23:18.493322
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert (
        tokenize_yaml("""
    foo: [
        true,
        false,
        123,
        3.14,
        null,
        "Hello, \\nYAML!"
    ]
    """)
        == DictToken(
            {"foo": ListToken([True, False, 123, 3.14, None, "Hello, \nYAML!"])},
            0,
            56,
            content="""
    foo: [
        true,
        false,
        123,
        3.14,
        null,
        "Hello, \\nYAML!"
    ]
    """,
        )
    )

    assert tokenize_yaml("123") == 123
    assert tokenize_yaml("3.14") == 3.14

# Generated at 2022-06-22 06:23:29.138087
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = String()
        age = Integer()

    content = b"""
        name: "Jane"
        age: 21
    """
    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name":"Jane", "age":21}
    assert errors == []

    content = b"""{
        "name": "Jane",
        "age": "21",
    }"""
    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name":"Jane", "age": 21}
    assert len(errors) == 1
    assert errors[0].text == "Value must be an integer."

    content = b"""
        name: Jane
    """
    value, errors = validate_yaml(content, PersonSchema)
    assert value

# Generated at 2022-06-22 06:23:42.063795
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: 1
    b:
      - 2
      - 3
    """

    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": [2, 3]}
    assert token.start == 3
    assert token.end == 22

    sub_token = token.value["b"]
    assert isinstance(sub_token, ListToken)
    assert sub_token.value == [2, 3]
    assert sub_token.start == 14
    assert sub_token.end == 22

    content = "a:\n  - 1\n  - 2"

    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": [1, 2]}

# Generated at 2022-06-22 06:23:52.226210
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # String without any characters
    with pytest.raises(ParseError):
        token = tokenize_yaml('')
    
    assert tokenize_yaml('{}').value == {}
    assert tokenize_yaml('"hello world"').value == 'hello world'
    assert tokenize_yaml('[1, 2, 3]').value == [1, 2, 3]
    assert tokenize_yaml('1').value == 1
    assert tokenize_yaml('0.01').value == 0.01
    assert tokenize_yaml('true').value == True
    assert tokenize_yaml('null').value == None


# Generated at 2022-06-22 06:24:01.339939
# Unit test for function tokenize_yaml
def test_tokenize_yaml(): 
    #import PyYAML
    #assert PyYAML is not None, "PyYAML must be installed."
    if PyYAML is not None:
        assert PyYAML.version_info.major >= 3, "PyYAML version must be equal or larger than 3"
    else:
        assert False, "PyYAML must be installed"

    yaml_content = '''Foo:
    - 1
    - 2
    - 3
    - 4
    - 5
    - 6
    Bar:
    - a
    - b
    - c
    '''

    token = tokenize_yaml(yaml_content)
    assert type(token) is DictToken
    assert token.items['Foo'].type == ListToken
    assert token.items['Bar'].type == ListToken

# Generated at 2022-06-22 06:24:07.850258
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo: hello
    bar:
      - third
      - fourth
      - fifth
    baz: qux
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)
    assert token.value["foo"] == "hello"
    assert token.get("bar") == ["third", "fourth", "fifth"]
    assert token.get("bar") == ["third", "fourth", "fifth"]

    token = token.get("bar")
    assert isinstance(token, ListToken)
    assert isinstance(token.value, list)



# Generated at 2022-06-22 06:24:14.109110
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(
"""
    pets:
        - dog
        - cat
        - rat
        -
            - dog
            - cat
        -
            name: dog
            age: 5
            breed: husky
    name: abigail
    age: 30
    favorite_food:
        - sushi
        - pizza
"""
    )

    assert isinstance(token, DictToken)



# Generated at 2022-06-22 06:24:27.077189
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # [{},[],{},[]]
    # [{},[]]
    # {},[],{},[]
    # {},[],
    # [],
    # []
    # [][]
    # {}{}
    content = "---\n- name: Brian\n  greeting: hello\n- name: Cindy\n  greeting: hi"
    token = tokenize_yaml(content)

    assert token.__class__.__name__ == 'ListToken'
    assert len(token) == 2
    assert token[0].__class__.__name__ == 'DictToken'
    assert token[1].__class__.__name__ == 'DictToken'
    assert len(token[0]) == 2

# Generated at 2022-06-22 06:24:37.747424
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml()
    """
    validator = Field()

    # Success
    assert validate_yaml("null", validator) == (None, [])
    assert validate_yaml("10", validator) == (10, [])

    # ParseError
    with pytest.raises(ParseError) as exc_info:
        validate_yaml("nul", validator)
    assert exc_info.value.position.line_no == 1
    assert exc_info.value.position.column_no == 2

    # ValidationError
    with pytest.raises(ValidationError) as exc_info:
        validate_yaml("10", int)
    assert exc_info.value.messages[0].position.line_no == 1

# Generated at 2022-06-22 06:24:47.456675
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("""
        1: one
        2: two
        3:
          - 3.1
          - 3.2
    """) == {
        "1": "one",
        "2": "two",
        "3": ["3.1", "3.2"],
    }

    assert tokenize_yaml("""
        - 1
        - 2
        - 3
    """) == [1, 2, 3]

    assert tokenize_yaml("""
        foo: bar
    """) == {"foo": "bar"}

    assert tokenize_yaml("1") == 1



# Generated at 2022-06-22 06:24:59.568655
# Unit test for function validate_yaml
def test_validate_yaml():
    my_yaml = '''
    a: 
        hello: world
        port: 8080
        tags: 
            - ok
            - 4
            - true
            - null
    '''
    value, errors = validate_yaml(my_yaml, Field(type="object"))
    assert errors == []
    value, errors = validate_yaml(my_yaml, Field(type="object", required=["a"]))
    assert errors == []
    value, errors = validate_yaml(my_yaml, Field(type="object", required=["a", "b"]))
    assert len(errors) == 1
    assert issubclass(errors[0].__class__, Message)
    assert issubclass(errors[0].__class__, ValidationError)

# Generated at 2022-06-22 06:25:02.880829
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    token = tokenize_yaml('a: b')
    assert token == {'a': 'b'}



# Generated at 2022-06-22 06:25:07.969032
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(name="name", type="string")
    assert validate_yaml(content="name: tobi", validator=validator) == (
        {"name": "tobi"},
        [],
    )

# Generated at 2022-06-22 06:25:18.597807
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('""') == ScalarToken(value='', start=0, end=1, content='""')
    assert tokenize_yaml('"test"') == ScalarToken(value='test', start=0, end=5, content='"test"')
    assert tokenize_yaml('"test\ntest"') == ScalarToken(value='test\ntest', start=0, end=12, content='"test\ntest"')
    assert tokenize_yaml('5') == ScalarToken(value=5, start=0, end=1, content='5')
    assert tokenize_yaml('5.5') == ScalarToken(value=5.5, start=0, end=3, content='5.5')
    assert tokenize_yaml('5e+10') == ScalarToken

# Generated at 2022-06-22 06:25:24.237412
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    name: test
    names: [first, second]
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert isinstance(token["names"], ListToken)
    assert isinstance(token["name"], ScalarToken)
    assert isinstance(token["names"][1], ScalarToken)

# Generated at 2022-06-22 06:25:36.517849
# Unit test for function validate_yaml
def test_validate_yaml():
    class User(Schema):
        name = String(max_length=4)

    # test for nested tokens
    content = """
    users:
      - id: 1
        name: UserA
      - name: UserB
    """
    (obj, error_messages) = validate_yaml(content, User)

    assert error_messages[0].message == "'id' is required."
    assert error_messages[0].position.line_no == 4
    assert error_messages[0].position.column_no == 7
    assert error_messages[0].code == "required"
    assert error_messages[0].details == {'field': 'id'}

    expecte_yaml_content = """
    users:
      - name: UserA
      - name: UserB
    """

# Generated at 2022-06-22 06:25:43.952531
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    from tests.tokenize.test_tokenize import test_tokenize_yaml

    schema = String(max_length=10)

    content = '''
        email: test@example.com
        password: "myPassword"
        '''
    value, error_messages = validate_yaml(content, schema)
    test_tokenize_yaml(content)



# Generated at 2022-06-22 06:26:00.264949
# Unit test for function validate_yaml
def test_validate_yaml():
    # test a YAML string whose first character is a '{' for success
    content = b"{'name': 'John Doe', 'age': 25}"
    validator = typing.Type[Schema]
    value, error_messages = validate_yaml(content, validator)
    assert value
    assert not error_messages
    # test a YAML string whose first character is a '{' for failure
    content = b"{'name': 'John Doe', 'age': '25'}"
    validator = typing.Type[Schema]
    value, error_messages = validate_yaml(content, validator)
    assert value
    assert error_messages
    # test a YAML string whose first character is a '[' for success

# Generated at 2022-06-22 06:26:08.028061
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem import Array, Boolean, Integer, Object, String
    from typesystem.errors import ValidationError

    class MySchema(Object):
        a = Array(items=Integer, required=True)
        b = Boolean(required=True)
        c = String()
        d = Integer()

    content = """
    a: [1, 2.0, 3.2]
    b: true
    c: foo
    """

    # Successful validation
    value, errors = validate_yaml(content, MySchema)
    assert errors is None
    assert value == {
        "a": [1, 2, 3],
        "b": True,
        "c": "foo",
    }

    # Invalid value
    errors = validate_yaml(content, MySchema.fields["a"])


# Generated at 2022-06-22 06:26:19.610398
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(b'test: 123'), DictToken)
    assert isinstance(tokenize_yaml(b'test: 123'), DictToken)
    assert isinstance(tokenize_yaml(b''), DictToken)  # Empty string parsed to empty dict
    assert isinstance(tokenize_yaml(b'1: 1'), DictToken)  # Key is not string
    assert isinstance(tokenize_yaml(b'"a": 1'), DictToken)  # Key is string
    assert isinstance(tokenize_yaml(b'false: 1'), DictToken)  # Key is boolean
    assert isinstance(tokenize_yaml(b'test: "a"'), DictToken)  # Value is string

# Generated at 2022-06-22 06:26:31.318491
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = u"foo: 42\nbar: True\nbaz:\n  - 1\n  - 2\n  - 3\n"
    token = tokenize_yaml(content)
    assert token.as_dict() == {
        "foo": 42,
        "bar": True,
        "baz": [1, 2, 3],
    }

    # Exception
    errors = []
    content = u"foo: 42\nbar: True\nbaz:\n  - 1\n  - 2\n  - 3\n  \n"
    token = tokenize_yaml(content)
    assert token.as_dict() == {
        "foo": 42,
        "bar": True,
        "baz": [1, 2, 3],
    }



# Generated at 2022-06-22 06:26:43.269774
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """- one: fish
                  - two: fish
                  - red: fish
                  - blue: fish
                 """
    field = Field(
        type="object",
        properties={
            "one": {"type": "integer", "multiple_of": 3},
            "two": {"type": "integer"},
        },
    )
    value, error_messages = validate_yaml(content, field)
    assert value == {"one": 3, "two": 2}
    assert error_messages == [
        Message(
            code="type_mismatch",
            message="Expected type 'integer' but got 'string'.",
            field="one",
            position=Position(
                line_no=1, column_no=7, char_index=6),
        ),
    ]

# Generated at 2022-06-22 06:26:51.460709
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 0, content="{}")
    assert tokenize_yaml("{a:a}") == DictToken({"a": "a"}, 0, 5, content="{a:a}")
    assert tokenize_yaml("{a: a}") == DictToken({"a": "a"}, 0, 6, content="{a: a}")
    assert tokenize_yaml("{a: {b:1}}") == DictToken({"a": {"b": 1}}, 0, 10, content="{a: {b:1}}")

# Generated at 2022-06-22 06:27:03.834134
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    hello: world
    nums:
        - 1
        - 2
        - 3
    """

    class MySchema(Schema):
        hello = "str"
        nums = "list[int]"

    value, errors = validate_yaml(content, MySchema)
    assert value == {"hello": "world", "nums": [1, 2, 3]}
    assert errors == []

    expected_errors = [
        ValidationError("Expected a list.", ["nums"]),
        ValidationError("Expected an int.", ["nums", 0]),
    ]
    value, errors = validate_yaml("nums: [1, '2', 3]", MySchema)
    assert value == {"nums": ["1", "2", "3"]}
    assert errors == expected_errors



# Generated at 2022-06-22 06:27:12.293761
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    d = {
        "kind": "string", "format": "regex",
        "pattern": "^[A-Za-z0-9-_]+(\\.[A-Za-z0-9-_]+)*$",
        "required": True,
    }
    assert tokenize_yaml(yaml.dump(d)) == DictToken(d)
    assert tokenize_yaml("") == DictToken({})
    assert tokenize_yaml("[]") == ListToken([])



# Generated at 2022-06-22 06:27:22.730678
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert type(tokenize_yaml("[1, 2, 3]")) == ListToken
    assert type(tokenize_yaml("{'name': 'typesystem'}")) == DictToken
    assert type(tokenize_yaml("1")) == ScalarToken
    assert type(tokenize_yaml("2.0")) == ScalarToken
    assert type(tokenize_yaml("True")) == ScalarToken
    assert type(tokenize_yaml("""
        owner:
            name: "matt"
            age: 32
    """)) == DictToken
    assert type(tokenize_yaml("""
        - [1, 2]
        - [3, 4]
    """)) == ListToken



# Generated at 2022-06-22 06:27:31.954629
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Number

    class ExampleSchema(Schema):
        name = String(max_length=12, required=True)
        age = Number(min_value=0)

    yaml_content = """
        name: John Smith
        age: 42
    """

    value, error_messages = validate_yaml(yaml_content, validator=ExampleSchema)
    assert error_messages == []
    assert value == {"name": "John Smith", "age": 42}

# Generated at 2022-06-22 06:27:48.035259
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("'foo bar'"), ScalarToken)
    assert isinstance(tokenize_yaml("'foo\\bbar'"), ScalarToken)
    assert isinstance(tokenize_yaml("'foo\\bar'"), ScalarToken)
    assert isinstance(tokenize_yaml("123"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml("!python/none ''"), ScalarToken)

# Generated at 2022-06-22 06:27:50.035223
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('val: a')
    assert token == {'val': 'a'}



# Generated at 2022-06-22 06:28:01.566469
# Unit test for function validate_yaml
def test_validate_yaml():
    class ExampleSchema(Schema):
        name = "string"
        age = "integer"

    value, errors = validate_yaml(
        content="""- name: Bob
                  - age: 21""",
        validator=ExampleSchema,
    )
    assert value == [{"name": "Bob"}, {"age": 21}]
    assert errors == []

    value, errors = validate_yaml(
        content="- name: Bob\n" "age: 21",
        validator=ExampleSchema,
    )
    assert value is None

# Generated at 2022-06-22 06:28:13.074289
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer
    from typesystem.yaml import validate_yaml, tokenize_yaml
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError, ParseError

    class Person(Schema):
        name = String()
        age = Integer()

    schema = Person()

    # create a valid "document"
    valid_document = """
    name: Bob
    age: 32
    """

    # use the validate_yaml function to parse, validate & return errors
    value, errors = validate_yaml(valid_document, schema)
    assert value == {"name": "Bob", "age": 32}
    assert errors == []  # no errors

    # Attempt to parse an invalid "document"
    invalid_document = """
    name: Bob
    """

    value

# Generated at 2022-06-22 06:28:24.363154
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo: bar") == DictToken({'foo': 'bar'}, 0, 8, content='foo: bar\n')
    assert tokenize_yaml("foo: 1\nbar: 2") == DictToken({'foo': 1, 'bar': 2}, 0, 13, content='foo: 1\nbar: 2\n')
    assert tokenize_yaml("- foo\n- bar") == ListToken(['foo', 'bar'], 0, 10, content='- foo\n- bar\n')
    assert tokenize_yaml("foo") == ScalarToken('foo', 0, 2, content='foo')
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content='1')