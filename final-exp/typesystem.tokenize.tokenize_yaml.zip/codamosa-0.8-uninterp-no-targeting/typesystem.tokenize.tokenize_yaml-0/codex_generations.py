

# Generated at 2022-06-22 06:18:40.452222
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.types import String
    from typesystem.fields import Field
    from typesystem.schemas import Schema
    from typesystem.types import String

    class UserSchema(Schema):
        username = String(max_length=10)
        password = String(min_length=8)
        age = Field(required=False)

    test_validator = UserSchema()

    # invalid_data = validate_yaml(
    #     """
    #     username: test
    #     password: 1234
    #     """,
    #     validator=test_validator,
    # )
    # assert len(invalid_data.errors) == 2

    # http://yaml.org/spec/1.2/spec.html#id2775170


# Generated at 2022-06-22 06:18:48.678765
# Unit test for function tokenize_yaml

# Generated at 2022-06-22 06:18:54.412234
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('{"name": "Evan"}', {'properties': {'name': {'type': 'string'}}}) == ({'name': 'Evan'}, [])
    assert validate_yaml('{"name": "Evan"}', {'properties': {'name': {'type': 'number'}}}) == ({'name': 'Evan'}, [{'code': 'invalid_type', 'text': 'Expected type "number" but received type "str".', 'position': Position(line_no=1, column_no=8, char_index=8)}])

# Generated at 2022-06-22 06:19:03.378536
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml('13\n'), ScalarToken)
    assert isinstance(tokenize_yaml('null\n'), ScalarToken)
    assert isinstance(tokenize_yaml('false\n'), ScalarToken)
    assert isinstance(tokenize_yaml('true\n'), ScalarToken)
    assert isinstance(tokenize_yaml('"string"\n'), ScalarToken)
    assert isinstance(tokenize_yaml('3.1415\n'), ScalarToken)
    assert isinstance(tokenize_yaml('\n- 1\n- 2\n'), ListToken)
    assert isinstance(tokenize_yaml('\n- "1"\n- "2"\n'), ListToken)

# Generated at 2022-06-22 06:19:14.059716
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    object1 = tokenize_yaml("{foo: bar}")
    assert object1.value["foo"] == "bar"

    array1 = tokenize_yaml("- foo")
    assert array1.value[0] == "foo"

    scalar1 = tokenize_yaml("foo")
    assert scalar1.value == "foo"

    scalar2 = tokenize_yaml("123")
    assert scalar2.value == 123

    scalar3 = tokenize_yaml("123.0")
    assert scalar3.value == 123.0

    scalar4 = tokenize_yaml("true")
    assert scalar4.value == True

    scalar5 = tokenize_yaml("false")
    assert scalar5.value == False

    scalar6 = tokenize_yaml("null")


# Generated at 2022-06-22 06:19:24.249506
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    assert tokenize_yaml("123") == 123
    assert tokenize_yaml("'123'") == "123"
    assert tokenize_yaml("True") is True
    assert tokenize_yaml("False") is False
    assert tokenize_yaml("null") is None
    assert tokenize_yaml('"123"') == "123"
    assert tokenize_yaml("123.45") == 123.45
    assert tokenize_yaml("123.45e2") == 123.45e2
    assert tokenize_yaml("123e2") == 123e2
    assert tokenize_yaml("'2013-04-23'") == "2013-04-23"

    assert tokenize_yaml("[]") == []

# Generated at 2022-06-22 06:19:32.167119
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {
            "name": Field(str, min_length=1, required=True),
            "age": Field(int, minimum=18, required=True),
            "notifications": Field(
                [{"message": Field(str, required=True), "created": Field(str)}],
                required=True,
            ),
        },
        required=True,
    )

    content = """
        name: Alex Meade
        age: 35
        notifications:
        - message: Hello! Welcome to my blog
          created: 2012-03-12T18:04:00+02:00

        - message: Check out my experience!
          created: 2018-03-12T18:04:00+02:00
        """

    value, messages = validate_yaml(content, schema)

# Generated at 2022-06-22 06:19:35.649540
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(pattern="^[a-zA-Z]+$")
        age = Float(minimum=0, maximum=100)

    content = """
        name: Bob
        age: 27
    """
    value, _errors = validate_yaml(content, validator=Person)

    assert value == {"name": "Bob", "age": 27}



# Generated at 2022-06-22 06:19:46.656491
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer

    class PersonSchema(Schema):
        name = String(max_length=15)
        age = Integer(default=18, minimum=0, maximum=100)
        favorite_color = String()

    # success
    yaml_str = """
    name: "Someone"
    age: 99
    favorite_color: "Blue"
    """
    yaml_str_byt = yaml_str.encode("utf-8")
    values, errors = validate_yaml(yaml_str, PersonSchema)
    assert errors == []
    values, errors = validate_yaml(yaml_str_byt, PersonSchema)
    assert errors == []

    # validation error

# Generated at 2022-06-22 06:19:59.313859
# Unit test for function validate_yaml
def test_validate_yaml():
    import json

    class Contact(Schema):
        name = Field(type="string", required=True)
        email = Field(type="string", required=True)
        phone = Field(type="string", required=True)

    yaml_string = (
        'name: "Michele Bologna"\n'
        'email: mbologna@example.com\n'
        'phone: "555-1212"\n'
    )
    result = validate_yaml(yaml_string, Contact)
    assert result == (
        {"name": "Michele Bologna", "email": "mbologna@example.com", "phone": "555-1212"},
        [],
    )


# Generated at 2022-06-22 06:20:04.995357
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
	# Test the test_tokenize_yaml function
	assert tokenize_yaml("123") == 123
	assert tokenize_yaml("123.5") == 123.5
	assert tokenize_yaml("true") is True
	assert tokenize_yaml("false") is False
	assert tokenize_yaml("null") is None
	assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
	assert tokenize_yaml("{A: 123}") == {"A": 123}



# Generated at 2022-06-22 06:20:12.310181
# Unit test for function validate_yaml
def test_validate_yaml():
    def validate_yaml(self):
        try:
            import yaml
            import typesystem
        except ImportError:  # pragma: no cover
            raise unittest.SkipTest("YAML import error.")
        if yaml is None:  # pragma: no cover
            raise unittest.SkipTest("YAML import error.")
        # Valid YAML

# Generated at 2022-06-22 06:20:21.420655
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert issubclass(validate_yaml.__annotations__['content'], (str, bytes))
    assert issubclass(validate_yaml.__annotations__['validator'], (Field, Schema))
    assert issubclass(validate_yaml.__annotations__['return'], tuple)
    assert issubclass(validate_yaml.__annotations__['return'][0], typing.Any)
    assert issubclass(validate_yaml.__annotations__['return'][1], list)
    assert issubclass(validate_yaml.__annotations__['return'][1][0], Message)

    from typesystem import String

    # Simple scalar values
    value, messages = validate_yaml(b"'a'", String(max_length=1))

# Generated at 2022-06-22 06:20:32.350414
# Unit test for function validate_yaml
def test_validate_yaml():
    res = validate_yaml(
        content=b"""
        ---
        name: "test"
        age_years: 31
        """,
        validator=Field(type="string", required=True),
    )
    assert res[0] == "test"
    assert res[1] == []

    res = validate_yaml(
        content=b"""
        ---
        age_years: 31
        """,
        validator=Field(type="string", required=True),
    )
    assert res[0] == ""
    assert res[1] == [
        Message(
            text="Missing data for required field.",
            code="required_field",
            position=Position(line_no=2, column_no=1, char_index=12),
        )
    ]


# Generated at 2022-06-22 06:20:40.414391
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        fields={"name": Field(type="string"), "options": Field(type="list", items=Field(type="string"))}
    )

    # Test correct output
    value, error_messages = validate_yaml(
        content="""
    name: test
    options:
      - test1
      - test2
    """,
        validator=schema,
    )
    assert value == {"name": "test", "options": ["test1", "test2"]}
    assert error_messages == []

    # Test parse error
    _, error_messages = validate_yaml(content="""name: """, validator=schema)

# Generated at 2022-06-22 06:20:51.477478
# Unit test for function validate_yaml
def test_validate_yaml():
    import copy
    import jsonschema
    from jsonschema import validate
    import json

    def json_equals(json1, json2):
        def json_sort(j):
            if isinstance(j, dict):
                return json.dumps(sorted(j.items()), sort_keys=True)
            return json.dumps(sorted(j), sort_keys=True)

        return json_sort(json1) == json_sort(json2)

    def validate_yaml_equals(content, typ, result):
        assert json_equals(validate_yaml(content, typ), result)
    
    class MyType(Schema):
        name = String()
        age = Integer()

    class MyType2(Schema):
        name = String()
        age = Integer()
       

# Generated at 2022-06-22 06:21:02.481055
# Unit test for function validate_yaml
def test_validate_yaml():
    # invalid yaml
    content = "!!str"
    try:
        validate_yaml(content, Schema)
    except ParseError as exc:
        assert exc.text == "found character that cannot start any token.", exc.text
        assert exc.code == "parse_error", exc.code
        assert exc.position.line_no == 1, exc.position.line_no
        assert exc.position.column_no == 1, exc.position.column_no
        assert exc.position.char_index == 0, exc.position.char_index
    else:
        assert False, "should raise a ParseError"

    # invalid document
    content = "---\nfoo\n---\nbar\n..."

# Generated at 2022-06-22 06:21:11.266569
# Unit test for function validate_yaml
def test_validate_yaml():
    schema_raw = """
    name: str
    address:
      street: str
      zip: int
    """

    schema = yaml.safe_load(schema_raw)
    validator = Schema(schema)

    data = yaml.safe_load("""
    name: John
    address:
      street: First
      zip: 4321
    """)

    value, error_messages = validate_yaml(data, validator)
    assert error_messages == []

    data = yaml.safe_load("""
    address:
      street: First
      zip: 4321
    """)

    value, error_messages = validate_yaml(data, validator)
    assert len(error_messages) == 1
    assert error_messages[0].position.line_no == 2


# Generated at 2022-06-22 06:21:18.462874
# Unit test for function validate_yaml
def test_validate_yaml():
    # Make a field to validate the YAML against.
    num_field = fields.Integer(name="number", required=True)

    # Load the YAML file.
    with open("tests/data/simple.yaml") as f:
        content = f.read()

    # Validate the YAML file against the field.
    value, errors = validate_yaml(content, num_field)

    # Print the value and errors.
    print(value)
    print(errors)

# Generated at 2022-06-22 06:21:30.964914
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    import yaml

    class UserSchema(Schema):
        name = String(max_length=20)

    assert UserSchema() is not None

    yaml_content = "name: Joe Doe"
    token = tokenize_yaml(yaml_content)

    assert isinstance(token, DictToken)

    assert isinstance(token.value, dict)
    assert "name" in token.value
    assert token.value["name"] == "Joe Doe"

    assert token.get_position(0) is None
    assert token.get_position(1) is None
    assert token.get_position(2) is None
    assert token.get_position(3) is None

    pos = token.get_position(4)

   

# Generated at 2022-06-22 06:21:39.943724
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = r"""
    birthday: 1991-01-11
    first_name: John
    last_name: Doe
    """

    expected = {
        "birthday": "1991-01-11",
        "first_name": "John",
        "last_name": "Doe",
    }
    actual = tokenize_yaml(content)
    assert expected == actual



# Generated at 2022-06-22 06:21:51.278281
# Unit test for function validate_yaml
def test_validate_yaml():
    _yaml_str = """
            id: 5
            name: Some name
            age: 55
            addresses:
                -   street: 123 Main St.
                    city: New York
                    state: NY
                    zip: 12345
                    latitude: 40.67
                    longitude: -73.94
                -   street: 456 Broad St.
                    city: Brooklyn
                    state: NY
                    zip: 11229
                    latitude: 40.65
                    longitude: -73.93
            pets:
                -   animal:
                        type: Dog
                        name: Max
                    age: 3
                    weight: 22
                -   animal:
                        type: Cat
                        name: Charlie
                    age: 4
                    weight: 12
            """

    class Address(Schema):
        street = Field(type="string")

# Generated at 2022-06-22 06:21:53.284953
# Unit test for function validate_yaml
def test_validate_yaml():
    token = Token({'$': [{'$': 'spam'}]})
    #assert validate_yaml(token, validator=None)

# Generated at 2022-06-22 06:21:56.644438
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(content)
    assert type(token) in (DictToken, ListToken, ScalarToken)

# Generated at 2022-06-22 06:21:58.276040
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    obj = {"a": 1, "b": 2}
    assert tokenize_yaml(yaml.dump(obj)) == obj



# Generated at 2022-06-22 06:22:02.406796
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('name: "my name"')
    assert isinstance(token, DictToken)
    assert len(token.items) == 1
    assert token.items[0].key == "name"
    assert token.items[0].value.value == "my name"

#  Unit test to function validate_yaml

# Generated at 2022-06-22 06:22:13.872635
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "foo: bar\n  'baz': quux\n  foobar:\n    - baz\n    - quux\n"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.content == content
    assert token.start == 0
    assert token.end == len(content)
    assert token.data == {"foo": "bar", "baz": "quux", "foobar": ["baz", "quux"]}

    # Test lists.
    content = "- foo\n- bar\n- baz\n"
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert token.content == content
    assert token.start == 0
    assert token.end == len(content)
    assert token

# Generated at 2022-06-22 06:22:26.000553
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # test for yaml scalar token
    # single_line_scalar
    content = "hello\n"
    assert isinstance(tokenize_yaml(content), ScalarToken)
    content = "248"
    assert isinstance(tokenize_yaml(content), ScalarToken)
    content = "0"
    assert isinstance(tokenize_yaml(content), ScalarToken)
    content = "true"
    assert isinstance(tokenize_yaml(content), ScalarToken)
    content = "4.5"
    assert isinstance(tokenize_yaml(content), ScalarToken)
    content = "4.5e4"
    assert isinstance(tokenize_yaml(content), ScalarToken)

# Generated at 2022-06-22 06:22:36.165508
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem.yaml
    class PostSchema(Schema):
        title = typesystem.String(max_length=100)
        tags = typesystem.Array(items=typesystem.String(max_length=20))

    yaml_string = 'title: "Valid post"\ntags:\n- foo\n- bar\n'

    value, error_messages = typesystem.yaml.validate_yaml(yaml_string, PostSchema)
    assert not error_messages

    value, error_messages = typesystem.yaml.validate_yaml("title: 'a'", PostSchema)
    assert len(error_messages) == 1
    assert error_messages[0].position == '<YAML>'

    value, error_messages = typesystem.yaml.validate

# Generated at 2022-06-22 06:22:41.282825
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    try:
        data, errors = validate_yaml(
            """
        name: Eric
        age: thirty two
        """,
            Person,
        )
    except ParseError:
        pass
    print(type(data))
    print(type(errors))
    print(errors)


# Generated at 2022-06-22 06:22:55.488766
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test_tokenize_yaml_empty
    assert tokenize_yaml("") == None

    # test_tokenize_yaml_str
    assert tokenize_yaml("a" * 10) == ScalarToken("a" * 10)

    # test_tokenize_yaml_int
    assert tokenize_yaml("5") == ScalarToken(5)

    # test_tokenize_yaml_list
    assert tokenize_yaml("[1,2,3]") == ListToken([1, 2, 3])

    # test_tokenize_yaml_dict
    assert tokenize_yaml("{a: 1, b: 2}") == DictToken({"a": 1, "b": 2})

    # test_tokenize_yaml_position_start

# Generated at 2022-06-22 06:23:04.913176
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        id = fields.Integer(required=True)

    cont = "id: 1"
    (value, err) = validate_yaml(cont, MySchema)
    assert value == {"id": 1}

    cont = "id: 'a'"
    (value, err) = validate_yaml(cont, MySchema)
    assert err["id"][0].code == 'parse_error'

    cont = "id: a"
    (value, err) = validate_yaml(cont, MySchema)
    assert err["id"][0].code == 'type_error'

    cont = "foo: 1"
    (value, err) = validate_yaml(cont, MySchema)
    assert err['id'][0].code == 'required'

# Generated at 2022-06-22 06:23:16.894115
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Demonstrate the use of the function validate_yaml.
    """
    from typesystem import String
    from typesystem.schemas import Schema

    class SimpleSchema(Schema):
        my_field = String()

    yaml1 = "my_field: 123"
    yaml2 = "my_field: this is a string"

    valid, errors = validate_yaml(yaml1, SimpleSchema)
    assert errors[0].code == 'invalid_type'
    assert errors[0].text == 'Should be a string.'
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 11
    assert errors[0].position.char_index == 10

    valid, errors = validate_yaml(yaml2, SimpleSchema)
    assert valid

# Generated at 2022-06-22 06:23:24.297289
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String()

    content = """
        name: foo
    """

    (value, errors) = validate_yaml(content, validator=TestSchema)

    assert not errors
    assert value == {"name": "foo"}



# Generated at 2022-06-22 06:23:29.416355
# Unit test for function validate_yaml
def test_validate_yaml():
    #content = '''
    #name: Example
    #'''
    content = '''
name: Example
'''
    token = tokenize_yaml(content)
    node = validate_yaml(content, validator=Schema)
    assert token == node
    #print('token: ' + str(token))

# Generated at 2022-06-22 06:23:40.066010
# Unit test for function validate_yaml
def test_validate_yaml():
    class Name(Schema):
        first = Field(type="string")
        last = Field(type="string")

    class Address(Schema):
        address = Field(type="string")
        city = Field(type="string")
        state = Field(type="string", max_length=2)
        zip = Field(type="string")
        second_address = Field(type="string", optional=True)

    class User(Schema):
        name = Field(type=Name)
        age = Field(type="string")
        address = Field(type=Address)

    content = """
            name:
                first: Bob
                last: Cratchit
            age: 45
            address:
                address: 123 Main Street
                city: New York
                state: NY
                zip: 10302
            """

    value, errors = validate

# Generated at 2022-06-22 06:23:52.116676
# Unit test for function validate_yaml
def test_validate_yaml():
    class SimpleSchema(Schema):
        name = String(min_length=1, max_length=10)

    content = "name: xyz"
    assert validate_yaml(content, SimpleSchema) == (
        {"name": "xyz"},
        [],
    )

    content = "name: xyz\nname: abc"
    assert validate_yaml(content, SimpleSchema) == (
        None,
        [
            Message(
                text="Extra field name.",
                code="extra",
                field="name",
                position=Position(
                    char_index=6, column_no=7, line_no=2, field="name",
                ),
            )
        ],
    )

    content = "name: xyz\nname: abc"

# Generated at 2022-06-22 06:23:55.409758
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    c:3
    """
    token = tokenize_yaml(content)
    assert token.start_char == 0
    assert token.end_char == 7
    assert token.content == content



# Generated at 2022-06-22 06:24:03.300444
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("key: value") == DictToken({'key': 'value'}, 0, 11, 'key: value')
    assert tokenize_yaml("dict: {key: value}") == DictToken({'dict': {'key': 'value'}}, 0, 17, 'dict: {key: value}')
    assert tokenize_yaml("list: [value]") == DictToken({'list': ['value']}, 0, 11, 'list: [value]')
    assert tokenize_yaml("key: 42") == DictToken({'key': 42}, 0, 7, 'key: 42')
    # TODO: check YAML line numbers
    #assert tokenize_yaml("key: 42\n key: 42") == DictToken({'key': 42}, 0, 15, 'key: 42

# Generated at 2022-06-22 06:24:08.577610
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == {}
    assert tokenize_yaml("foo: bar") == {'foo': 'bar'}
    assert tokenize_yaml("- bar") == ['bar']



# Generated at 2022-06-22 06:24:20.631906
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("""
    - a: 1
    - b: 2
    - c: 3
    """), ListToken)

    # Ensure that an empty string raises an exception.
    with pytest.raises(ParseError):
        tokenize_yaml("")

    # Ensure that an invalid YAML raises an exception.
    with pytest.raises(ParseError):
        tokenize_yaml("""\
a: b
  c: d
""")



# Generated at 2022-06-22 06:24:27.492443
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('{"a": [1, 2]}') == {"a": [1, 2]}
    assert tokenize_yaml('[1, 2, 3]') == [1, 2, 3]
    assert tokenize_yaml('{"a": 1}') == {"a": 1}
    assert tokenize_yaml('1') == 1
    assert tokenize_yaml('true') == True
    assert tokenize_yaml('false') == False
    assert tokenize_yaml('null') == None

# Generated at 2022-06-22 06:24:31.323635
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''a:
    - b
    - c'''  # type: ignore
    try:
        token = tokenize_yaml(content)
    except ParseError as e:
        print(e)
        token = None
    assert isinstance(token, DictToken)
 


# Generated at 2022-06-22 06:24:37.416454
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: 1
    b:
      - 2
      - 3
      - c: 4
        d: 5
    e: 6
    """

    token = tokenize_yaml(content)
    expected = {
        "a": 1,
        "b": [2, 3, {"c": 4, "d": 5}],
        "e": 6,
    }

    assert token == expected



# Generated at 2022-06-22 06:24:46.732899
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name:
      phone: 555-1212
      email: old@example.com
    - name:
      phone: 555-1212
      email: new@example.com
    """
    validator = Schema(
        fields=[
            Field(name="name"),
            Field(name="phone", validators=["phone_number"]),
            Field(name="email", validators=["email"]),
        ],
    )
    value, error_messages = validate_yaml(content, validator)
    assert error_messages[0].position.line_no == 4


# Generated at 2022-06-22 06:24:49.240335
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # scalar type
    assert isinstance(tokenize_yaml("5"), ScalarToken)
    assert tokenize_yaml("5").value == 5


# Generated at 2022-06-22 06:24:56.580781
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_content = """
    user:
        name: foo
        age: 20
        addresses:
            - home:
                city: London
              work:
                city: Wisconsin
    """
    token = tokenize_yaml(content=yaml_content)
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == len(yaml_content) - 1
    assert token.content == yaml_content


# Unit tests for function validate_yaml

# Generated at 2022-06-22 06:25:00.583379
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        # Note: YAML is whitespace sensitive
        name: John Smith
        age:  43
     """)
    print(token.content)


# Generated at 2022-06-22 06:25:03.435214
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(
        """
    data:
      hello: world
    """
    )

    assert isinstance(token, DictToken)



# Generated at 2022-06-22 06:25:14.964816
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "hello: world"
    validator = typing.Dict[str, str]
    result = validate_yaml(content=content, validator=validator)
    expected = ({'hello': 'world'}, [])
    assert expected == result

    content = "'hello': world"
    validator = typing.Dict[str, str]
    result = validate_yaml(content=content, validator=validator)
    expected = (
        None,
        [
            {
                "code": "invalid_value_type",
                "message": "Invalid value type.",
                "position": {
                    "column_no": 1,
                    "line_no": 1,
                    "char_index": 0,
                },
            }
        ],
    )
    assert expected == result


# Generated at 2022-06-22 06:25:31.166093
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    def check_yaml_parse(content: str, expected_value: typing.Any) -> None:
        token = tokenize_yaml(content)
        assert token == expected_value

    check_yaml_parse("", {})
    check_yaml_parse("null", None)
    check_yaml_parse("0", 0)
    check_yaml_parse("true", True)
    check_yaml_parse("[1, 2, 3]", [1, 2, 3])

    check_yaml_parse("a: 1", {"a": 1})
    check_yaml_parse("a: \"hello\"", {"a": "hello"})

    check_yaml_parse("foo\nbar", "foo\nbar")

# Generated at 2022-06-22 06:25:44.526607
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test an empty string
    try:
        token = tokenize_yaml("")
    except ParseError as e:
        assert e.position.line_no == 1
        assert e.position.column_no == 1
        assert e.position.char_index == 0
        assert e.code == "no_content"
        assert e.text == "No content."

    # Test different kind of values
    token = tokenize_yaml("""
    key: test
    list:
    - value1
    - value2
    """)

    assert token.kind == "dict"
    assert token.key_values == {"key": "test", "list": ["value1", "value2"]}

    # Test invalid yaml

# Generated at 2022-06-22 06:25:56.297144
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Test cases to check the basic tokenization of a yaml string.
    """
    # Test empty string
    with pytest.raises(ParseError, match='No content'):
        tokenize_yaml("")

    # Test missing colon
    with pytest.raises(ParseError, match='malformed'):
        tokenize_yaml("really: good")

    # Test missing comma
    with pytest.raises(ParseError, match='malformed'):
        tokenize_yaml("{'sage': 'green' 'jalapeno': 'spicy'}")

    # Test missing space
    with pytest.raises(ParseError, match='malformed'):
        tokenize_yaml("{'sage': 'green'}")

    # Test missing closing bracket

# Generated at 2022-06-22 06:25:59.670927
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "foo: 2"
    token = tokenize_yaml(content)
    _, messages = validate_yaml(content, Field(type=int))
    assert messages[0].position.char_index == 0

# Generated at 2022-06-22 06:26:04.504152
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        authors:
            - Stephan Tolksdorf
            - Mike Bayer
        comment: "For documentation"
    """)
    assert isinstance(token, DictToken)
    assert token.value == {
        "authors": [
            ScalarToken("Stephan Tolksdorf", 15, 33, content=token.content),
            ScalarToken("Mike Bayer", 35, 44, content=token.content),
        ],
        "comment": ScalarToken("For documentation", 50, 68, content=token.content),
    }

# Generated at 2022-06-22 06:26:14.348145
# Unit test for function validate_yaml
def test_validate_yaml():
    class ShipSchema(Schema):
        name = "string"

    class PersonSchema(Schema):
        name = "string"
        age = "integer"
        ships = ShipSchema[:]

    # Everything works
    person_schema = PersonSchema()
    content = """
        name: Jean-Luc Picard
        age: 59
        ships:
          - Enterprise D
          - Enterprise E
    """
    (value, errors) = validate_yaml(content, person_schema)
    assert errors == []

    # Invalid data
    content = b"""
        name: Jean-Luc Picard
        age: sixtynine
        ships:
          - Enterprise D
          - Enterprise E
    """

# Generated at 2022-06-22 06:26:25.484924
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
title: Hello World
content:
  qux: 123
  quux:
    - hello
    - world
"""
    assert tokenize_yaml(content) == {
        "title": "Hello World",
        "content": {"qux": 123, "quux": ["hello", "world"]},
    }

    content = """
- hello
- world
"""
    assert tokenize_yaml(content) == ["hello", "world"]

    content = '''
"hello\nworld"
'''
    assert tokenize_yaml(content) == "hello\nworld"

    with pytest.raises(ParseError) as exc_info:
        tokenize_yaml("")

    assert exc_info.value.text == "No content."

# Generated at 2022-06-22 06:26:37.730750
# Unit test for function validate_yaml
def test_validate_yaml():
    # Get a validator class
    from typesystem import types

    class ExampleSchema(Schema):
        title = types.String(required=True)
        price = types.Integer(required=True)
        tags = types.Array(items=types.String)

    validator = ExampleSchema()

    # Successful validation
    value, error_messages = validate_yaml(
        "title: My Cool Title\nprice: 20\ntags: [hot, cool]", validator=validator
    )
    assert len(error_messages) == 0
    assert value == {"title": "My Cool Title", "price": 20, "tags": ["hot", "cool"]}

    # Unsuccessful validation

# Generated at 2022-06-22 06:26:43.658992
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    b: 'hello'
    """

    class SimpleSchema(Schema):
        a = Integer()
        b = String()

    value, error_msgs = validate_yaml(content, SimpleSchema)
    assert isinstance(error_msgs, list)
    assert len(error_msgs) == 0



# Generated at 2022-06-22 06:26:51.765009
# Unit test for function validate_yaml
def test_validate_yaml():
    # type: () -> None
    yaml_string = "name: 'John Doe'"
    schema = Schema(fields={"name": Field(required=True)})
    yaml.load(yaml_string, Loader=yaml.FullLoader)  # type: ignore

    # This should return, no error messages
    assert validate_yaml(yaml_string, schema)[1] == []

    invalid_yaml_string = "name: 'John Doe'\nage: '15'"
    with pytest.raises(ValidationError):
        validate_yaml(invalid_yaml_string, schema)



# Generated at 2022-06-22 06:27:05.047002
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    correct_token = DictToken(
        {
            "foo": ScalarToken("bar"),
            "baz": ListToken([ScalarToken("qux")]),
            "quz": DictToken({"hello": ScalarToken("world")}),
        },
        0,
        50,
        content=(
            "foo: bar\nbaz:\n  - qux\nquz:\n  hello: world\n"
        ),
    )
    assert tokenize_yaml("foo: bar\nbaz:\n  - qux\nquz:\n  hello: world") == correct_token

# Generated at 2022-06-22 06:27:17.152105
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    assert (tokenize_yaml('') == ParseError(text="No content.", code="no_content", position=Position(column_no=1, line_no=1, char_index=0)))
    assert (tokenize_yaml('<') == ParseError(text='expected "<document start>", but found "<block mapping start>"\n  in "<unicode string>", line 1, column 1', code="parse_error", position=Position(column_no=1, line_no=1, char_index=0)))

# Generated at 2022-06-22 06:27:25.558155
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    beverages:
        tea:
            - green
            - black
            - white
        coffee:
            - light
            - strong
            - medium
    """
    validator = Field()
    validate_yaml_success = validate_yaml(content, validator)
    assert validate_yaml_success[0] == {
        "beverages": {"tea": ["green", "black", "white"], "coffee": ["light", "strong", "medium"]}
    }
    assert len(validate_yaml_success[1]) == 0


# Generated at 2022-06-22 06:27:35.726105
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    with pytest.raises(ParseError, match="No content.",):
        # Empty string should raise a ParseError
        tokenize_yaml("")

    # Empty objects should be parsed as an empty list or dict.
    token = tokenize_yaml("[]")
    assert isinstance(token, ListToken)
    assert token.start == 0
    assert token.end == 1
    assert token.content == "[]"
    assert token.value == []

    token = tokenize_yaml("{}")
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == 1
    assert token.content == "{}"
    assert token.value == {}

    # Should be able to parse scalar tokens.
    token = tokenize_yaml("string")

# Generated at 2022-06-22 06:27:47.558564
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer
    from typesystem.schemas import Schema

    class User(Schema):
        username = String(max_length=5)
        age = Integer(minimum=5)

    try:
        validate_yaml(b"username: luke\nage: 4", User)
        assert False, "Expected a ParseError."
    except ParseError as exc:
        assert exc.position.char_index == 10, "Unexpected error location."
        assert exc.code == "parse_error", "Unexpected error code."

    try:
        validate_yaml(b"username: luke\nage: 4", User)
        assert False, "Expected a ValidationError."
    except ValidationError as exc:
        assert exc.code == "min_value", "Unexpected error code."

# Generated at 2022-06-22 06:27:58.547460
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("12"), ScalarToken)
    assert isinstance(tokenize_yaml("1.2"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml("'value'"), ScalarToken)
    assert isinstance(tokenize_yaml('"value"'), ScalarToken)
    assert isinstance(tokenize_yaml("{ key: value }"), DictToken)
    assert isinstance(tokenize_yaml("{ 'key': value }"), DictToken)
    assert isinstance(tokenize_yaml('{ "key": value }'), DictToken)

# Generated at 2022-06-22 06:28:05.191476
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None

    from typesystem import types
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        class Meta:
            allow_unknown_fields = False

        name = types.String(min_length=1)
        age = types.Integer(minimum=18)
        height = types.Number(minimum=1.7)

    content = """
name: Paul
age: 26
height: 1.8
"""
    assert validate_yaml(content, PersonSchema) == (
        {"name": "Paul", "age": 26, "height": 1.8},
        [],
    )

    content = """
name: Paul
age: 16
height: 1.8
"""
    value, messages = validate_yaml(content, PersonSchema)

# Generated at 2022-06-22 06:28:10.498435
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    data = """
    a: 1
    b:
      c:
        - d
        - e
    """
    assert tokenize_yaml(data) == {"a": 1, "b": {"c": ["d", "e"]}}

    data = """
    a: !<tag:yaml.org,2002:str> Hello World
    b:
        - !<tag:yaml.org,2002:int> 0
        - !<tag:yaml.org,2002:null>
    """
    assert tokenize_yaml(data) == {"a": "Hello World", "b": [0, None]}



# Generated at 2022-06-22 06:28:14.326502
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(str)

    with open("test.yml","r") as f:
        yml = f.read()
    value, messages = validate_yaml(yml, field)
    assert len(messages) == 0


# Generated at 2022-06-22 06:28:20.227115
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import String
    from typesystem.schemas import Schema

    class BasicSchema(Schema):
        name = String(max_length=10)

    content = """
    name: John Doe
    """
    validator = BasicSchema()
    value, errors = validate_yaml(content, validator)

    assert value == {"name": "John Doe"}
    assert errors == []