

# Generated at 2022-06-22 06:18:40.397671
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test for empty content
    with pytest.raises(ParseError) as exc_info:
        tokenize_yaml("")
    assert "No content." in str(exc_info.value)
    assert exc_info.value.position.line_no == 1
    assert exc_info.value.position.column_no == 1
    assert exc_info.value.position.char_index == 0

    # Test for parsing errors
    with pytest.raises(ParseError) as exc_info:
        tokenize_yaml("[1, 2, 3")
    assert "expected ']', but found '<stream end>'" in str(exc_info.value)
    assert exc_info.value.position.line_no == 1
    assert exc_info.value.position.column_no == 7
    assert exc_

# Generated at 2022-06-22 06:18:41.767694
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "foo: bar\n"

    assert tokenize_yaml(content) == {"foo": "bar"}

# Generated at 2022-06-22 06:18:47.855038
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    document = """
    a: 1
    b:
      - 1
      - 2
      - 3
    """

    assert(
        tokenize_yaml(document) == {
            'a': ScalarToken(1, 0, 1, content=document),
            'b': ListToken([
                ScalarToken(1, 0, 1, content=document),
                ScalarToken(2, 0, 1, content=document),
                ScalarToken(3, 0, 1, content=document)], 0, 1, content=document)
        }
    )


# Generated at 2022-06-22 06:18:57.539868
# Unit test for function validate_yaml
def test_validate_yaml():

    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer()

        class Meta:
            ordered = True

    content = """
    name: Peter
    age: 35
    """

    validator = PersonSchema()

    peter, errors = validate_yaml(content, validator)

    assert peter["name"] == "Peter"
    assert peter["age"] == 35
    assert errors == []

    invalid_content = """
    name: Peter
    age: '35'
    """

    peter, errors = validate_yaml(invalid_content, validator)

    assert peter["name"] == "Peter"
    assert peter["age"] is None

# Generated at 2022-06-22 06:19:09.370101
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Unit test for function validate_yaml
    """
    # Test empty data
    data = ""
    token, error_messages = validate_yaml(data, validator=None)
    assert token is None
    assert len(error_messages) == 1
    assert error_messages[0].message == "No content."
    assert error_messages[0].code == "no_content"
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 1
    assert error_messages[0].position.char_index == 0

    # Test parse error
    data = ";"
    token, error_messages = validate_yaml(data, validator=None)
    assert token is None

# Generated at 2022-06-22 06:19:15.291769
# Unit test for function validate_yaml
def test_validate_yaml():
    '''Test the function validate_yaml.

    This tests that:
        - validate_yaml returns a two-tuple of (value, error_messages)
        - the error_messages is a Message instance
            - with specific message, code, and line_no and column_no
    '''
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem.fields import String
    from typesystem.validators import min_length

    schema = String(validators=[min_length(3)])
    result = validate_yaml("T", schema)

    assert type(result) is tuple
    assert len(result) == 2
    value, error_messages = result

    assert value == 'T'
    assert type(error_messages) is Message

# Generated at 2022-06-22 06:19:18.339027
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type='string')
    value = validate_yaml(content="test", validator=validator)
    print(value)



# Generated at 2022-06-22 06:19:28.606717
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
fruit:
  - apple
  - banana
  - orange
veggies: []
drink: coffee
""")

# Generated at 2022-06-22 06:19:31.382987
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo: bar
    """
    token = tokenize_yaml(content)
    assert token == {"foo": "bar"}



# Generated at 2022-06-22 06:19:42.093078
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test valid yaml, empty string
    assert tokenize_yaml("") == {}

    # Test valid yaml, empty dict
    assert tokenize_yaml("{}") == {}

    # Test valid yaml, empty list
    assert tokenize_yaml("[]") == []

    # Test valid yaml, list
    assert tokenize_yaml("[ 1, 2 , 3 ]") == [1, 2, 3]

    # Test valid yaml, list with keys
    assert tokenize_yaml("[ a: 1, b: 2, c: 3 ]") == [1, 2, 3]

    # Test valid yaml, list with keys and no whitespace
    assert tokenize_yaml("[a:1,b:2,c:3]") == [1, 2, 3]

    # Test valid yaml, list

# Generated at 2022-06-22 06:19:53.689239
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_str = """
    a: 1
    b: 2
    c: 3
    """
    parsed_yaml = tokenize_yaml(yaml_str)

    assert isinstance(parsed_yaml, DictToken)
    assert parsed_yaml.content == yaml_str

    yaml_str = """
    - a
    - b
    - c
    """
    parsed_yaml = tokenize_yaml(yaml_str)

    assert isinstance(parsed_yaml, ListToken)
    assert parsed_yaml.content == yaml_str



# Generated at 2022-06-22 06:20:01.201164
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: bar
    """
    token = tokenize_yaml(content)
    print (token)
    # assert validate_yaml(content, Field(type=str)) == (200, "Found the person")
    # assert validate_yaml(content, Field(type=int)) == (400, "Could not find the person")

if __name__ == '__main__':
    test_validate_yaml()

# Generated at 2022-06-22 06:20:09.301385
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Check empty file
    with pytest.raises(ParseError):
        tokenize_yaml("")
    # Check empty dict
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, True)
    # Check empty list
    assert tokenize_yaml("[]") == ListToken([], 0, 1, True)
    # Check dict with one key-value pair
    assert tokenize_yaml("{a:1}") == DictToken({'a': 1}, 0, 4, True)
    # Check list with one element
    assert tokenize_yaml("[1]") == ListToken([1], 0, 2, True)
    # Check scalar value
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, True)
    # Check booleans


# Generated at 2022-06-22 06:20:16.750108
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(parse_json=True)
    value, errors = validate_yaml(
        '"{"hello":"world"}"', validator
    )
    assert not errors
    assert isinstance(value, dict)
    assert value['hello'] == 'world'

    value, errors = validate_yaml(
        'true', validator
    )
    assert errors and len(errors) == 1
    e = errors[0]
    assert isinstance(e, ValidationError)
    assert e.text.endswith(', "true" is not a valid JSON string.')

# Generated at 2022-06-22 06:20:22.937865
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String

    validator = String(max_length=10)
    content = b"""
    this is a test:
        - 1
        - 2
        - 3
    """
    value, error_messages = validate_yaml(content, validator)
    assert error_messages[0].code == "parse_error"

# Generated at 2022-06-22 06:20:34.269691
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        name: "John"
        age: 42
    """
    # John
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.start == 3
    assert token.end == 43
    assert token.value == {"name": "John", "age": 42}

    # No content.
    try:
        tokenize_yaml("")
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
    else:
        assert False, "Expected exception."

    # Syntax error.

# Generated at 2022-06-22 06:20:41.235336
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    DICT_CONTENT = """
        test_string: hello
        test_int: 10
        test_float: 3.14
        test_bool: true
        test_null: null
        test_list:
            - item1
            - item2
        test_dict:
          name: john
          age: 23
          address:
            street: "1000 1st ave"
            state: WA
    """
    token = tokenize_yaml(DICT_CONTENT)

# Generated at 2022-06-22 06:20:52.421115
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem import String, Schema
    from typesystem.fields import Field
    from typesystem.tokenize.tokens import ScalarToken, DictToken, ListToken

    schema = Schema(properties={"name": String()})
    token = tokenize_yaml('{name: "Erick"}')
    assert isinstance(token, DictToken)
    assert token == {'name': ScalarToken('Erick', 0, 12, content='{name: "Erick"}')}

    token = tokenize_yaml('[1, 2, 3]')
    assert isinstance(token, ListToken)

# Generated at 2022-06-22 06:20:54.912627
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "description: this is a test"
    validator = Schema(description=Field(description="description"))
    with pytest.raises(ValidationError) as exc_info:
        validate_yaml(content, validator)

    assert exc_info.value.code == "required"
    assert (
        exc_info.value.messages[0].position.line_no
        == content.count("\n", 0, exc_info.value.messages[0].position.char_index) + 1
    )

# Generated at 2022-06-22 06:21:06.768788
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # String
    test_string = '''
    This is a test.
    '''
    result = tokenize_yaml(test_string)
    assert result.start == 1
    assert result.end == 42
    assert result.value == "This is a test."
    # Bytes
    test_string = '''\
    This is a test'''.encode('utf-8')
    result = tokenize_yaml(test_string)
    assert result.start == 1
    assert result.end == 41
    assert result.value == "This is a test"
    # Empty
    test_string = ''
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml(test_string)
    assert excinfo.value.text == "No content."

# Generated at 2022-06-22 06:21:14.830240
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("key: 123", "scalar") == (None, [])
    assert validate_yaml("key: 123", "integer") == (None, [Message(code='type', message="Invalid type.", name="", position=Position(column_no=6,line_no=1,char_index=6))])

# Generated at 2022-06-22 06:21:20.767940
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import ErrorMessage
    from typesystem.fields import String, Integer, Float, Boolean

    # The following validation should fail for the following reasons:
    #   1. The `name` field is missing.
    #   2. The `age` field is not an integer.
    #   3. The `salary` field is not a float.
    #   4. The `hired` field is not a boolean.
    #   5. The `interests` field is not a list.
    #   6. The `telephone` field is not a number.
    #   7. The `emergency-contacts` field is not a dictionary.
    #   8. The `emergency-contacts` dictionary is missing the `address` field.
    #   9. The `emergency-contacts` dictionary is missing the `relationship` field

# Generated at 2022-06-22 06:21:31.186712
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    text = "key1: 'string'\nkey2: 2\nkey3: 3.1415\nkey4: true\nkey5: false\n"
    assert isinstance(tokenize_yaml(text), Token)

    text = "key1: 'string'\nkey2: 2\nkey3: 3.1415\nkey4: true\nkey5: false"
    assert isinstance(tokenize_yaml(text), Token)

    text = ""
    assert isinstance(tokenize_yaml(text), Token)

    text = "key1: 'string'\nkey2: 2\nkey3: 3.1415\nkey4: true\nkey5: false\nkey6:"
    assert isinstance(tokenize_yaml(text), Token)  # fail

# Generated at 2022-06-22 06:21:35.580254
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert isinstance(tokenize_yaml(b"foo: bar"), DictToken)
    assert isinstance(tokenize_yaml(b"""foo: !baz
  val: 3"""), DictToken)
    assert isinstance(tokenize_yaml(b"""foo:
  - bar
  - !baz
    val: 3"""), DictToken)
    assert isinstance(tokenize_yaml(b"- foo\n- bar"), ListToken)
    assert isinstance(tokenize_yaml(b"foo: 3"), DictToken)
    assert isinstance(tokenize_yaml(b"foo: bar"), DictToken)
    assert isinstance(tokenize_yaml(b"foo: false"), DictToken)

# Generated at 2022-06-22 06:21:42.705144
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml('"string"'), ScalarToken)
    assert isinstance(tokenize_yaml("[1,2,3]"), ListToken)
    assert isinstance(tokenize_yaml('{a: "b"}'), DictToken)
    assert isinstance(tokenize_yaml('{a: "b"}'), DictToken)
    assert isinstance(tokenize_yaml('{a: "b"}'), DictToken)

# Generated at 2022-06-22 06:21:51.770755
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String, Schema
    
    class PersonSchema(Schema):
        name = String()
        age = Integer()

    yaml_string = """
        name: Clark
        age: 25
    """
    
    value, msgs = validate_yaml(yaml_string, PersonSchema)
    assert value == {"name": "Clark", "age": 25}
    assert not msgs
    
    yaml_string = """
        name: Clark
        age: twenty-five
    """
    
    value, msgs = validate_yaml(yaml_string, PersonSchema)
    assert len(msgs) == 1 # Error during validation
    msg = msgs[0]
    assert msg.code == 'invalid_type'
    assert msg.position.line_no == 3
   

# Generated at 2022-06-22 06:22:00.241407
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = textwrap.dedent(
        """
        -
          name: Chris
          age: 28
        -
          name: Rami
          age: 21
        -
          name: Ben
          age: 22
        """
    )
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert token.children[0].children[0].children[0].value == "name"
    assert token.children[0].children[0].children[1].value == "Chris"
    assert token.children[1].children[0].children[0].value == "name"
    assert token.children[1].children[0].children[1].value == "Rami"
    assert token.children[2].children[0].children[0].value == "name"

# Generated at 2022-06-22 06:22:11.126428
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: foo
    age: 10
    """
    validator = Schema(
        {"name": Field(str), "age": Field(int)},
        strict=False,
        non_field_errors=True,
    )
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == []

    content = """\
name: foo
age: bar
"""
    validator = Schema(
        {"name": Field(str), "age": Field(int)},
        strict=False,
        non_field_errors=True,
    )
    value, error_messages = validate_yaml(content, validator)

# Generated at 2022-06-22 06:22:23.984900
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml('{a: 1}'), DictToken)
    assert isinstance(tokenize_yaml('[1, 2, 3]'), ListToken)
    assert isinstance(tokenize_yaml('"hello"'), ScalarToken)
    assert isinstance(tokenize_yaml('"\\u0041"'), ScalarToken)
    assert isinstance(tokenize_yaml('"\\uF0F0"'), ScalarToken)
    assert isinstance(tokenize_yaml('"\\u3040"'), ScalarToken)
    assert isinstance(tokenize_yaml('1'), ScalarToken)
    assert isinstance(tokenize_yaml('1.1'), ScalarToken)
    assert isinstance(tokenize_yaml('true'), ScalarToken)

# Generated at 2022-06-22 06:22:31.107992
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import (
        Boolean,
        Number,
        String,
        Text,
        Array,
        Enum,
        Object,
    )

    from typesystem.yaml import validate_yaml

    class TestSchema(Schema):
        number_field = Number()
        string_field = String()
        text_field = Text()
        boolean_field = Boolean()
        array_field = Array(items=Number())
        enum_field = Enum(options=["a", "b", "c"])
        object_field = Object(fields={"number": Number()})

    validator = TestSchema()

# Generated at 2022-06-22 06:22:44.301262
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("a: 1\nb: 2"), DictToken)
    assert isinstance(tokenize_yaml("a: 1\nb: 2\nc: 3\n"), DictToken)
    assert isinstance(tokenize_yaml("[hello, world]"), ListToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("1.23e+10"), ScalarToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)

# Generated at 2022-06-22 06:22:54.192243
# Unit test for function validate_yaml
def test_validate_yaml():
    from fields import String, Integer
    from schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=100)

    value, errors = validate_yaml(
        """
        name: "John Doe"
        age: 50
        """
        .strip(),
        Person,
    )

    assert value == {"name": "John Doe", "age": 50}
    assert errors == []

    value, errors = validate_yaml(
        """
        age: 50
        name: "John Doe"
        """.strip(),
        Person,
    )

    assert value == {"name": "John Doe", "age": 50}
    assert errors == []



# Generated at 2022-06-22 06:23:03.634851
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("xyz"), ScalarToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)

    # Test that bytes can be used as input.
    assert isinstance(tokenize_yaml(b""), ListToken)

    # Test that error messages are posiionally accurate.
    with pytest.raises(ParseError) as exc_info:
        tokenize_yaml('{"a" 123}')

    assert exc_info.value.position == Position(line_no=1, column_no=7, char_index=7)
    assert (
        exc_info.value.text
        == 'expected <block end>, but found \'123\'. (line 1, column 7)'
    )

# Generated at 2022-06-22 06:23:13.895028
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # no content
    with pytest.raises(ParseError):
        tokenize_yaml("")

    # no matching token
    with pytest.raises(ParseError):
        tokenize_yaml("3.14")

    # scalar
    assert isinstance(tokenize_yaml("Foo"), ScalarToken)

    # list
    assert isinstance(tokenize_yaml("[1, 2, 3]"), ListToken)

    # mapping
    assert isinstance(tokenize_yaml("{foo: bar}"), DictToken)

    expected = """\
foo: 'bar'
baz: 1
"""
    assert tokenize_yaml(expected).serialize() == expected



# Generated at 2022-06-22 06:23:18.966405
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class PetSchema(Schema):
        name = String(max_length=255)

    content = "name: Fluffy\n"
    error_messages = validate_yaml(content, PetSchema)
    assert error_messages == []


# Generated at 2022-06-22 06:23:23.182857
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    content = "value: Hi"
    token = tokenize_yaml(content)
    assert token.as_dict() == {"value": "Hi"}


# Generated at 2022-06-22 06:23:30.901573
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('[0, 1]') == [0, 1]
    assert tokenize_yaml('[0, 1,]') == [0, 1]
    assert tokenize_yaml('[0, 1 ]') == [0, 1]
    assert tokenize_yaml('[0, 1] ') == [0, 1]
    assert tokenize_yaml(' {a: 0}') == {'a': 0}
    assert tokenize_yaml('{a: 0} ') == {'a': 0}
    assert tokenize_yaml('{a: 0} ') == {'a': 0}
    assert tokenize_yaml('{a: 0 }') == {'a': 0}
    assert tokenize_yaml('{ "a": 0 } ') == {'a': 0}

# Generated at 2022-06-22 06:23:42.864503
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import Boolean, DateTime, Dict, Integer
    
    class PersonSchema(Schema):
        age = Integer(min_value=0, max_value=120)
        birthday = DateTime(format="%Y-%m-%d")
        retired = Boolean()
        spouse = Dict(schema=PersonSchema, required=False)

    data = """
    age: 30
    birthday: 1990-01-01
    retired: false
    spouse:
      age: 25
      birthday: 1992-05-10
      retired: false
    """
    value, errors = validate_yaml(data, validator=PersonSchema)
    assert not errors, errors
    assert value["age"] == 30
    assert value["birthday"] == datetime.datetime(1990, 1, 1)
    assert value

# Generated at 2022-06-22 06:23:50.044633
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Empty string
    assert tokenize_yaml('') == None

    # Check case of a raw string
    assert tokenize_yaml('1') == ScalarToken(1, 0, 0, content = '1')

    # Check case of a dict
    assert tokenize_yaml('"a": 2') == DictToken({"a": 2}, 0, 4, content = '"a": 2')

    # Check case of a list
    assert tokenize_yaml('[1, 2]') == ListToken([1, 2], 0, 5, content = '[1, 2]')

    # Check case of a nested dict
    assert tokenize_yaml('"a": [1, 2]') == DictToken({"a": [1, 2]}, 0, 9, content = '"a": [1, 2]')



# Generated at 2022-06-22 06:24:00.456050
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test with single empty dictionary
    content = {
        "name": "kiran",
        "address": [{"street": "1st street"}, {"street": "2nd street"}],
    }
    output = tokenize_yaml(content)
    assert isinstance(output, DictToken)
    assert isinstance(output.value, dict)
    assert output.value["name"] == "kiran"
    assert isinstance(output.value["address"], ListToken)
    assert isinstance(output.value["address"].value, list)
    assert output.value["address"].value[0]["street"] == "1st street"
    assert isinstance(output.value["address"].value[1], DictToken)
    assert isinstance(output.value["address"].value[1].value, dict)

# Generated at 2022-06-22 06:24:15.504106
# Unit test for function validate_yaml
def test_validate_yaml():
    field = String(pattern=r'\d+')
    assert validate_yaml(b'a', field) == (None, [Message(text='Invalid data type.', code='invalid_type',
                                                        type='string', position=Position(char_index=0, column_no=1,
                                                                                          line_no=1),
                                                        field_name=None)])

# Generated at 2022-06-22 06:24:26.307319
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    str_content = """
---
- 1
- 2
- 3
- 4
- {a: A}
- {b: B}
- {c: C}
- {d: D}
- name: John Doe
...
"""
    token = tokenize_yaml(str_content)

    assert token.start == 0
    assert token.end == len(str_content) - 3
    assert token.value == [1, 2, 3, 4, {"a": "A"}, {"b": "B"}, {"c": "C"}, {"d": "D"}, {"name": "John Doe"}]
    assert token.get_position(9) == Position(line_no=5, column_no=4, char_index=33)


# Generated at 2022-06-22 06:24:33.607171
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    
    class Person(Schema):
        name = String()
        age = String()

    yaml = """\
    name: Alice
    age: "23"
    """

    value, errors = validate_yaml(content=yaml, validator=Person)
    assert value == {"name": "Alice", "age": "23"}
    assert errors == []

# Generated at 2022-06-22 06:24:44.695198
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Test tokenizer for YAML
    """

    # Basic cases.
    assert isinstance(tokenize_yaml(""), ScalarToken)
    assert isinstance(tokenize_yaml("hello"), ScalarToken)
    assert isinstance(tokenize_yaml("123"), ScalarToken)
    assert isinstance(tokenize_yaml("1.23"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml("[1, 2, 3]"), ListToken)
    assert isinstance(tokenize_yaml("{a: 1}"), DictToken)

    # Test error messages.

# Generated at 2022-06-22 06:24:50.126268
# Unit test for function validate_yaml
def test_validate_yaml():
    class ExampleSchema(Schema):
        prop1 = "string"
        prop2 = "number"

    content = """
    prop1: value1
    prop2: 10
    """
    value, error_messages = validate_yaml(content, ExampleSchema)

    if error_messages:
        for error_message in error_messages:
            print(error_message.text)

    expected = [
        "prop1: value1",
        "prop2: 10",
    ]
    assert value == expected



# Generated at 2022-06-22 06:25:00.330305
# Unit test for function validate_yaml
def test_validate_yaml():
    import json
    from typesystem import Schema
    from typesystem.types import String

    class PersonSchema(Schema):
        name = String(min_length=1, max_length=4)

    errors = validate_yaml(
        '{"name": "Rachel"}', validator=PersonSchema
    )[1]
    assert json.dumps(errors, sort_keys=True) == '[{"code": "invalid_max_length", "text": "Ensure this value has at most 4 characters (it has 5).", "position": {"column_no": 19, "line_no": 1, "char_index": 18}, "field": "name"}]'

# Generated at 2022-06-22 06:25:02.339252
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("""
    name: test
    """), DictToken)



# Generated at 2022-06-22 06:25:14.112379
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    content = """
        foo:
          bar:
            baz: 1
        """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.value["foo"], DictToken)
    assert isinstance(token.value["foo"].value["bar"], DictToken)
    assert isinstance(token.value["foo"].value["bar"].value["baz"], ScalarToken)
    assert token.value["foo"].value["bar"].value["baz"].value == 1
    assert token.start == 1
    assert token.end == 2
    assert token.content == content

    token = tokenize_yaml("1")
    assert isinstance(token, ScalarToken)

# Generated at 2022-06-22 06:25:19.701814
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = ""
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {}

    content = "id: 1"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"id": 1}
    token = token.value["id"]
    assert isinstance(token, ScalarToken)
    assert token.value == "1"



# Generated at 2022-06-22 06:25:31.809819
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    for yaml_obj, str_content in (
        ({"a": 1}, 'a: 1\n'),
        ({"a": 1, "b": 2}, 'a: 1\nb: 2\n'),
        ({"a": {"b": 1}}, 'a:\n  b: 1\n'),
        ({"a": {"b": [1]}}, 'a:\n  b:\n    - 1\n'),
        ({"a": {"b": [1, 2]}}, 'a:\n  b:\n    - 1\n    - 2\n'),
        (
            {"a": {"b": 1}, "c": 2},
            'a:\n  b: 1\nc: 2\n',
        ),
    ):
        token = tokenize_yaml(str_content)
        assert token == yaml_obj

# Generated at 2022-06-22 06:25:47.338722
# Unit test for function validate_yaml
def test_validate_yaml():
    # Create the validator to check against.
    class Register(Schema):
        email = Field(type="string")
        password = Field(type="string")

    # Check that an empty string raises an error.
    try:
        validate_yaml("", validator=Register)
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position == Position(line_no=1, column_no=1, char_index=0)
    else:
        assert False, "Did not raise ParseError as expected."

    # Check that valid YAML parses and validates successfully.
    content = """
    email: john@example.com
    password: s3cur3p4$$w0rd
    """
    value, errors = validate_yaml(content, validator=Register)

# Generated at 2022-06-22 06:25:54.650413
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "person:\n  name: 'Alice' #comment\n  email: alice@example.com"
    validator = type(
        "Person",
        (Schema,),
        {
            "name": Field(str)
        }
    )


    value, error_messages = validate_yaml(content, validator)
    assert value == {"person": {"name": "Alice", "email": "alice@example.com"}}
    assert not error_messages

# Generated at 2022-06-22 06:26:01.108624
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    test:
        - hello
        - world
    """
    result = tokenize_yaml(content)
    assert type(result) is DictToken
    assert type(result.value['test']) is ListToken
    assert result.value['test'].value == ['hello', 'world']
    assert result.start == content.index('t')
    assert result.end == content.index('rld')+3 
    assert result.content == content


# Generated at 2022-06-22 06:26:04.512665
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"name": Field(type_hint=str)})
    content = b"""\
name: "Alex"
"""
    value, errors = validate_yaml(content, schema)
    assert value == {"name": "Alex"}
    assert not errors



# Generated at 2022-06-22 06:26:06.743727
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem
    assert isinstance(validate_yaml(content="", validator=typesystem.String()), tuple)


# Generated at 2022-06-22 06:26:15.640202
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("value"), ScalarToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("1.1"), ScalarToken)
    assert isinstance(tokenize_yaml("yes"), ScalarToken)
    assert isinstance(tokenize_yaml("no"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)

    with pytest.raises(ParseError):
        tokenize_yaml("{]")
    with pytest.raises(ParseError):
        tokenize_yaml("[}")

# Generated at 2022-06-22 06:26:27.330083
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Validate that the tokenize_yaml function works as expected.
    """
    assert yaml is not None, "'pyyaml' must be installed."
    content = ""
    with pytest.raises(ParseError):
        token = tokenize_yaml(content)

    content = "foo"
    token = tokenize_yaml(content)
    assert isinstance(token, ScalarToken)
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.value == "foo"

    content = "[foo]"
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert token.start == 0
    assert token.end == len(content) - 1
    assert isinstance(token.value[0], ScalarToken)


# Generated at 2022-06-22 06:26:36.779090
# Unit test for function tokenize_yaml
def test_tokenize_yaml():    
    content = """
    name: "test"
    properties:
        age: 10
    """
    name = ScalarToken("test", 3, 11, content)
    age = ScalarToken(10, 37, 39, content)
    properties = DictToken({"age": age}, 18, 46, content)

    expected_result = DictToken({"name": name, "properties": properties}, 0, 47, content)

    assert tokenize_yaml(content) == expected_result

    content = """
    - "test 1"
    - "test 2"
    - "test 3"
    """
    test_1 = ScalarToken("test 1", 3, 13, content)
    test_2 = ScalarToken("test 2", 18, 28, content)

# Generated at 2022-06-22 06:26:45.851279
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "''"

    validator = Field(required=True, type='string')

    value, error_messages = validate_yaml(content, validator)

    assert error_messages == {"extra_characters": [Message(
        text=ParseError(
            text="No content.",
            code="no_content",
            position=Position(
                column_no=1, line_no=1, char_index=0
            )
        ),
        position=Position(
            column_no=1, line_no=1, char_index=0
        )
    )]}

# Generated at 2022-06-22 06:26:57.315131
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    # Simple schema
    class PersonSchema(Schema):
        name = String(max_length=30)

    # Valid input
    value, errors = validate_yaml("name: 'John'", validator=PersonSchema)
    assert value 
    assert not errors
    
    # Invalid input
    value, errors = validate_yaml("age: 'John'", validator=PersonSchema)
    assert not value
    assert len(errors) == 1

    # Invalid input
    value, errors = validate_yaml("name: 'John Joseph'", validator=PersonSchema)
    assert not value
    assert len(errors) == 1


# Generated at 2022-06-22 06:27:08.807333
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Test tokenize_yaml function
    """
    assert yaml is not None, "'pyyaml' must be installed."
    test_dict = {"id": "1", "name": "sumti"}, 5, {"id": "2", "name": "sumti2"}
    test_str = yaml.dump(test_dict)
    token = tokenize_yaml(test_str)
    assert token


# Generated at 2022-06-22 06:27:20.708125
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_str = """
        yaml_str: "test"
        yaml_int: 42
        yaml_float: 3.14
        yaml_null: ~
        yaml_bool: false
        yaml_list:
            - item1
            - item2
            - item3
    """
    values = yaml.safe_load(yaml_str)

    token = tokenize_yaml(yaml_str)
    assert isinstance(token, DictToken)
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 10
    assert token.end_position.column_no == 15
    assert token.content == yaml_str
    assert token.value == values



# Generated at 2022-06-22 06:27:24.546784
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("""
        key1: value1
        key2:
            - item1
            - item2
    """) == {
        "key1": "value1",
        "key2": ["item1", "item2"],
    }



# Generated at 2022-06-22 06:27:32.597102
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    CONTENT = '''
    data:
      -
        id: 1
        title: 'foo'
      -
        id: 2
        title: 'bar'
    '''

    token = tokenize_yaml(CONTENT)
    assert len(list(token.keys())) == 1
    assert token["data"] == [
        {"id": 1, "title": "foo"},
        {"id": 2, "title": "bar"},
    ]



# Generated at 2022-06-22 06:27:45.452086
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test that parsing and validating works as expected.
    """
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        title = String(min_length=5)

    value, errors = validate_yaml(
        """
        title: hello
        """,
        validator=MySchema,
    )

    assert value is not None
    assert isinstance(value, dict)
    assert len(errors) == 0

    value, errors = validate_yaml(
        """
        title: hi
        """,
        validator=MySchema,
    )
    assert value is None
    assert isinstance(errors, list)
    assert len(errors) == 1
    error = errors[0]
    assert isinstance(error, Message)

# Generated at 2022-06-22 06:27:55.412755
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    token = tokenize_yaml("foo: bar")
    assert token["foo"]

    token = tokenize_yaml("- 1")
    assert token[0]

    token = tokenize_yaml("[]")
    assert token == []

    # Edge case for empty string.
    try:
        tokenize_yaml("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.text == "No content."
        assert exc.position.char_index == 0
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
    else:
        assert False, "Expected ParseError."



# Generated at 2022-06-22 06:28:03.553880
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Unit test for function validate_yaml
    """
    from typesystem.fields import Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        age = Integer(minimum=18, maximum=100)

    value, errors = validate_yaml(b"age: 12", Person)
    assert value == {"age": 12}
    assert len(errors) == 1
    assert errors[0].position

    value, errors = validate_yaml(b"age: 99", Person)
    assert value == {"age": 99}
    assert len(errors) == 0

    value, errors = validate_yaml(b"age: 101", Person)
    assert value is None
    assert len(errors) == 1



# Generated at 2022-06-22 06:28:08.221109
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert tokenize_yaml(content=b"{foo: bar}") == {"foo": "bar"}
    assert tokenize_yaml(content='{foo: "bar"}') == {"foo": "bar"}
    assert tokenize_yaml(content="{foo: 'bar'}") == {"foo": "bar"}
    assert tokenize_yaml(content='{foo: ! "bar"}') == {"foo": "bar"}
    assert tokenize_yaml(content="{foo: ! 'bar'}") == {"foo": "bar"}
    assert tokenize_yaml(content="{foo: [bar]}") == {"foo": ["bar"]}

# Generated at 2022-06-22 06:28:18.534299
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    source = "name: a\nother: b"
    token = tokenize_yaml(source)
    assert token == {"name": "a", "other": "b"}
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == len(source) - 1
    assert token.get_content(0, 3) == "nam"

    source = "name: a\nother: b\n"
    token = tokenize_yaml(source)
    assert token == {"name": "a", "other": "b"}
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == len(source) - 1
    assert token.get_content(0, 3) == "nam"

    source = "name: a"
    token