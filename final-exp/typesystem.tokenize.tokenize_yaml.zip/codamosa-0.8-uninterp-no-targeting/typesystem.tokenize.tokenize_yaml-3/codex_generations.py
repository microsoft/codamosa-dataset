

# Generated at 2022-06-22 06:18:40.434828
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content='''
development:
  database: postgres
  queue: redis
'''
    res = tokenize_yaml(content)
    assert isinstance(res, DictToken)

    content='''
development:
  database: postgres
  queue: redis
testing:
  database: postgres
  queue: redis
production:
  database: postgres
  queue: redis
'''
    res = tokenize_yaml(content)
    assert isinstance(res, DictToken)

    content='''
[{'a': 'b'}, {'c': 'd'}, {'e': 'f'}]
'''
    res = tokenize_yaml(content)
    assert isinstance(res, ListToken)


# Generated at 2022-06-22 06:18:42.973906
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("{}")
    assert isinstance(token, DictToken)

    token = tokenize_yaml("[]")
    assert isinstance(token, ListToken)

    token = tokenize_yaml('"foo"')
    assert isinstance(token, ScalarToken)

# Generated at 2022-06-22 06:18:47.570271
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Valid YAML
    token = tokenize_yaml("test: value")
    assert isinstance(token, DictToken)
    assert token == {"test": "value"}

    # Invalid YAML
    with pytest.raises(ParseError) as e:
        tokenize_yaml("test: &value")
        assert isinstance(token, DictToken)
        assert token == {"test": "value"}



# Generated at 2022-06-22 06:18:57.205298
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test YAML parsing works without errors.
    assert tokenize_yaml('name: "Bob"') == {'name': 'Bob'}
    assert tokenize_yaml('name: "Bob"') == {'name': 'Bob'}
    assert tokenize_yaml('name: "Bob"') == {'name': 'Bob'}
    assert tokenize_yaml('name: "Bob"') == {'name': 'Bob'}
    assert tokenize_yaml('name: "Bob"') == {'name': 'Bob'}
    assert tokenize_yaml('name: "Bob"') == {'name': 'Bob'}
    assert tokenize_yaml('name: "Bob"') == {'name': 'Bob'}

# Generated at 2022-06-22 06:19:08.455910
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
        [
            {
                "type": "dict",
                "required": True,
                "properties": [
                    {
                        "type": "list",
                        "required": False,
                        "items": {"type": "string"}
                    }
                ]
            }
        ]
    '''
    validator = Field(type="list", items={
        "type": "dict",
        "required": True,
        "properties": [
            {
                "type": "list",
                "required": False,
                "items": {"type": "string"}
            }
        ]
    })
    value, errors = validate_yaml(content, validator)
    print(value)
    print(errors)


# Generated at 2022-06-22 06:19:13.811965
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo: abc
    bar: 123
    baz:
        - violet
        - indigo
        - blue
        - green
        - yellow
        - orange
        - red
    """

    expected = """{
    foo: abc,
    bar: 123,
    baz:
        - violet
        - indigo
        - blue
        - green
        - yellow
        - orange
        - red
    }"""

    token = tokenize_yaml(content)
    assert repr(token) == expected


# Generated at 2022-06-22 06:19:23.938010
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None

    assert tokenize_yaml("[]").as_dict() == []
    assert tokenize_yaml("[1, 2]").as_dict() == [1, 2]
    assert tokenize_yaml("[{}, {}]").as_dict() == [{}, {}]

    assert tokenize_yaml("{}").as_dict() == {}
    assert tokenize_yaml("{a: 1}").as_dict() == {"a": 1}
    assert tokenize_yaml("{a: 1, b: 2}").as_dict() == {
        "a": 1,
        "b": 2,
    }

    assert tokenize_yaml("num: 1").as_dict() == {"num": 1}



# Generated at 2022-06-22 06:19:35.332724
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    foo = {"foo": "-"}
    foo_token = tokenize_yaml("foo: -")
    assert foo_token == DictToken(foo, start=0, end=7, content="foo: -")

    string_list = {"foo": ["bar"]}
    string_list_token = tokenize_yaml("foo:\n - bar")
    assert string_list_token == DictToken(string_list, start=0, end=12, content="foo:\n - bar")

    integer_list = {"foo": [1, 2]}
    integer_list_token = tokenize_yaml("foo:\n - 1\n - 2")
    assert integer_list_token == DictToken(integer_list, start=0, end=18, content="foo:\n - 1\n - 2")


# Generated at 2022-06-22 06:19:46.348662
# Unit test for function validate_yaml
def test_validate_yaml():
    # type: () -> None

    import yaml
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Field, String
    from typesystem.schemas import Schema


    class PersonSchema(Schema):
        name = String()
        age = Field()


    class PersonSchema1(Schema):
        name = String()
        age = Field()
        skills= Field()

    class PersonSchema2(Schema):
        name = String()
        age = Field()
        skills= Field()
        date_of_birth = Field()


    def validate_yaml(content, validator):
        return yaml.load(content, Loader=yaml.FullLoader)

    # function: validate_yaml()

    # Testcase 1 (Testcase for successful parsing)

    # Ar

# Generated at 2022-06-22 06:19:58.975025
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """Test tokenize_yaml method"""
    success_token = tokenize_yaml("this: is: a: test:")
    assert isinstance(success_token, DictToken)
    assert success_token.content == "this: is: a: test:"
    assert success_token.start == 0
    assert success_token.end == 15
    assert success_token.dict_value == {"this": {"is": {"a": {"test": None}}}}

    fail_token = tokenize_yaml("this: is: a: test")
    assert isinstance(fail_token, DictToken)
    assert fail_token.content == "this: is: a: test"
    assert fail_token.start == 0
    assert fail_token.end == 14

# Generated at 2022-06-22 06:20:10.575692
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.typing import StringType

    class Foo(Schema):
        foo = StringType(max_length=5)

    content = "foo: 123456"
    expected_error_message = "Character 6: '6' is longer than maximum length 5."
    value, error_messages = validate_yaml(content, validator=Foo)
    assert error_messages[0].text == expected_error_message



# Generated at 2022-06-22 06:20:17.023080
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert isinstance(tokenize_yaml(''), str)
    assert tokenize_yaml('') == "No content."



# Generated at 2022-06-22 06:20:29.122159
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "pyyaml must be installed."
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = "string"
        age = "number"

    content = """
    name: Jane
    age: 28
    """

    assert validate_yaml(content, PersonSchema) == ({'name': 'Jane', 'age': 28}, [])

    content = """
    name: Jane
    """

    messages = validate_yaml(content, PersonSchema)[1]

    assert messages[0] == Message(
        text="Missing required key 'age'.",
        code="missing-key",
        position=Position(column_no=1, line_no=3, char_index=13),
    )


# Generated at 2022-06-22 06:20:35.684794
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer

    class TestSchema(Schema):
        age = Integer()

    content = "age: text"

    messages = validate_yaml(content, TestSchema())

    assert len(messages) == 1
    message = messages[0]
    assert isinstance(message, Message)
    assert message.code == "invalid_type"
    assert message.text == "Must be of type integer."
    assert message.position == Position(line_no=1, column_no=5, char_index=4)

# Generated at 2022-06-22 06:20:46.472969
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ""
    assert tokenize_yaml("1234") == 1234
    assert tokenize_yaml("123.4") == 123.4
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("null") == None

    token = tokenize_yaml('[null, true, false, null]')
    assert isinstance(token, ListToken)
    assert token.value == [None, True, False, None]

    token = tokenize_yaml('{one: 123, two: "test"}')
    assert isinstance(token, DictToken)
    assert token.value == {"one": 123, "two": "test"}



# Generated at 2022-06-22 06:20:51.393349
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_string = """
    name: Example Name
    age: 10
    """
    result = tokenize_yaml(yaml_string)
    assert isinstance(result, DictToken)
    assert result.data == {'name': 'Example Name', 'age': 10}


# Generated at 2022-06-22 06:20:58.691333
# Unit test for function validate_yaml
def test_validate_yaml():
    from datetime import datetime
    # Setup
    validator = Field(format="date-time", required=True)
    content = "2020-07-31T12:15:00.000000"
    # Exercise
    result = validate_yaml(content, validator)
    # Verify
    assert result == (
        datetime(2020, 7, 31, 12, 15, tzinfo=datetime.utcnow().tzinfo),
        [],
    )

# Generated at 2022-06-22 06:21:09.045094
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    print("Tokenize yaml")
    content = "key: value\nkey2: value2"
    token = tokenize_yaml(content)
    # print(token)
    assert isinstance(token, Token), "token is type Token"
    assert token['key'] == "value", "value is value"
    assert token['key2'] == "value2", "value2 is value2"
    # Check invalid yaml
    content = "key: value\n: NOTVALIDYAML\nkey2: value2"
    token = tokenize_yaml(content)
    # print(token)
    assert isinstance(token, Token), "token is type Token"
    assert token['key'] == "value", "value is value"
    assert token['key2'] == "value2", "value2 is value2"


# Generated at 2022-06-22 06:21:12.028727
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema([
        Field(name="field1", type="string"),
        Field(name="field2", type="string"),
    ])
    value, error_messages = validate_yaml(
        content="field1: value1\nfield2: value2", validator=schema
    )
    assert value == {"field1": "value1", "field2": "value2"}
    assert error_messages == []


# Generated at 2022-06-22 06:21:20.287807
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        value, errors = validate_yaml("", object)
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert exc.position.char_index == 0
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1

    value, errors = validate_yaml("1", int)
    assert value == 1
    assert errors == []


YAMLMixin = typing.TypeVar("YAMLMixin", bound="YAMLBase")



# Generated at 2022-06-22 06:21:31.962477
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
    - foo
    - bar
    - baz
    '''
    assert tokenize_yaml(content) == ["foo", "bar", "baz"]

    content = "([{]}"
    assert tokenize_yaml(content) == "([{]}"

    content = "!@#$%^&*()"
    token = tokenize_yaml(content)
    assert token.value == "!@#$%^&*()"
    assert token.start == 0
    assert token.end == 11
    assert token.content == "!@#$%^&*()"
    assert token.position == Position(
        column_no=1, line_no=1, char_index=0
    )
    assert token.text == "!@#$%^&*()"

# Generated at 2022-06-22 06:21:37.709441
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("", Integer()) == (0, (Message(text='Not an integer.', code='type_error', position=Position(char_index=0, column_no=1, line_no=1)),))
    assert validate_yaml("null", Integer()) == (0, (Message(text='Not an integer.', code='type_error', position=Position(char_index=0, column_no=1, line_no=1)),))
    assert validate_yaml("1", Integer(minimum=0)) == (1, ())
    assert validate_yaml("[1, 2, 3]", Array(items=Integer())) == ([1, 2, 3], ())
    assert validate_yaml("{}", Object(properties={})) == ({}, ())

if __name__ == "__main__":
    test_valid

# Generated at 2022-06-22 06:21:48.939753
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
knownKeys:
 - key1
 - key2
 - key3
unknownKeys:
 - unknownkey1
 - unknownkey2
    """

    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

    # test type of knownKeys
    assert isinstance(token.value["knownKeys"], ListToken)

    # test type of unknownKeys
    assert isinstance(token.value["unknownKeys"], ListToken)

    # test content of knownKeys
    assert token.value["knownKeys"].value[0] == "key1"
    assert token.value["knownKeys"].value[1] == "key2"
    assert token.value["knownKeys"].value[2] == "key3"

    # test content of unknownKeys

# Generated at 2022-06-22 06:21:54.454092
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    test_yaml = """
    test:
        - foo
        - bar
        - baz
    """

    output = tokenize_yaml(test_yaml)

    assert len(output) == 1
    assert output['test'][2].start == 51
    assert output['test'][2].end == 54
    assert output['test'][2].content == 'baz'



# Generated at 2022-06-22 06:21:57.877723
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    result = tokenize_yaml('valid: true')
    assert isinstance(result, DictToken)
    assert result.content == 'valid: true'
    assert result[0] == 'valid'
    assert result[1].content == 'true'



# Generated at 2022-06-22 06:22:01.229341
# Unit test for function validate_yaml
def test_validate_yaml():
    content = 'email: "example@example.org"\nage: 30'
    validator = Schema(
        {
            "email": "email",
            "age": "integer"
        }
    )
    value = validate_yaml(content=content, validator=validator)

# Generated at 2022-06-22 06:22:10.876386
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    content = """\
name: Andy
age: "32"
"""
    (person, error_messages) = validate_yaml(content, validator=Person)
    assert person == Person(name="Andy", age=32)
    assert error_messages == [
        Message(
            text="invalid value",
            code="invalid_value",
            position=Position(
                line_no=3, column_no=6, char_index=14
            ),
        )
    ]



# Generated at 2022-06-22 06:22:16.413671
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    yaml_str = """
    a: 1
    b: 2
    """

    assert tokenize_yaml(yaml_str) == {"a": 1, "b": 2}



# Generated at 2022-06-22 06:22:20.945113
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('{"key": "I am a string"}') == DictToken(
        {"key": ScalarToken("I am a string", 6, 22, content='{"key": "I am a string"}')},
        0,
        23,
        content='{"key": "I am a string"}',
    )


# Generated at 2022-06-22 06:22:27.482702
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(field_type=str, required=True)

    # Success
    value, errors = validate_yaml("foo", validator)
    assert value == "foo"
    assert errors == []

    # Failure
    value, errors = validate_yaml("", validator)
    assert value == ""
    assert errors == [
        ValidationError(
            messages=["This field is required."],
            code="required",
            position=Position(column_no=1, line_no=1, char_index=0),
        )
    ]

# Generated at 2022-06-22 06:22:40.743440
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("123") == ScalarToken(123, 0, 2, content="123")
    assert tokenize_yaml("123.456") == ScalarToken(123.456, 0, 6, content="123.456")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("-123.456") == ScalarToken(-123.456, 0, 8, content="-123.456")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")
    assert tokenize_yaml("null.null") == ScalarToken("null.null", 0, 8, content="null.null")

# Generated at 2022-06-22 06:22:49.489704
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken
    from typesystem.tokenize.tokens import Token
    assert isinstance(tokenize_yaml("foo"), ScalarToken)
    assert 1 == tokenize_yaml("1").value
    assert 1.5 == tokenize_yaml("1.5").value
    assert isinstance(tokenize_yaml("[1]"), ListToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    with pytest.raises(ParseError):
        tokenize_yaml("")
    with pytest.raises(ParseError):
        tokenize_yaml("[1")
    with pytest.raises(ParseError):
        tokenize_yaml("[")

# Generated at 2022-06-22 06:22:53.351465
# Unit test for function validate_yaml
def test_validate_yaml():
    msg = "hello world"
    assert validate_yaml(msg, Field(type="string"))[0] == msg
    assert validate_yaml("", Field(type="string", required=True))[1][0].text == "This field is required."
    assert validate_yaml("", Field(type="string", min_length=1))[1][0].text == "This field is too short."


# Generated at 2022-06-22 06:22:57.449724
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_str = """
    a: b
    b:
        a: hello
        """
    tokens = tokenize_yaml(yaml_str)
    assert tokens == {
        "a": "b",
        "b": {"a": "hello"}
    }

# Generated at 2022-06-22 06:23:04.206636
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"age": int, "name": str, "color": str})
    data = """
    age: 1
    name: bob
    color: blue
    """
    
    assert validate_yaml(data, schema)[0] == {
        "age": 1,
        "name": "bob",
        "color": "blue",
    }


# Generated at 2022-06-22 06:23:16.073967
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('') == None
    assert tokenize_yaml('null') == None
    assert tokenize_yaml('true') == True
    assert tokenize_yaml('false') == False
    assert tokenize_yaml('a') == 'a'
    assert tokenize_yaml('1') == 1
    assert tokenize_yaml('1.0') == 1.0
    assert tokenize_yaml('[1, 2, 3]') == [1,2,3]
    assert tokenize_yaml('a: 1') == {'a': 1}
    assert tokenize_yaml('{a: 1}') == {'a': 1}

# Generated at 2022-06-22 06:23:21.816697
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
    key1: value1
    key2: value2
    '''
    assert tokenize_yaml(content) == {"key1": "value1", "key2": "value2"}


# Generated at 2022-06-22 06:23:30.514403
# Unit test for function validate_yaml
def test_validate_yaml():
    # test passing with no errors
    content = """
    a: foo
    b: bar
    """
    structure = {"a": "foo", "b": "bar"}
    value, error_messages = validate_yaml(content=content, validator=structure)
    assert value == structure
    assert error_messages == []

    # test passing with expected strict error
    content = """
    a: foo
    b: bar
    """
    structure = {"a": "foo"}
    value, error_messages = validate_yaml(content=content, validator=structure)
    assert value == structure

# Generated at 2022-06-22 06:23:35.041799
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array
    content = '''
    str_field: foo
    list_field:
      - 1
      - 2
    '''
    validator = Schema(
        {
            "str_field": String(),
            "list_field": Array(Integer()),
        }
    )
    validate_yaml(content, validator)

# Generated at 2022-06-22 06:23:47.042473
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # Test that an empty file produces a ParseError exception
    with pytest.raises(ParseError):
        token = tokenize_yaml('')

    # Test that an error in the YAML syntax produces a ParseError exception
    with pytest.raises(ParseError):
        token = tokenize_yaml('...')
    
    # Test that a valid token is returned if the YAML syntax is correct
    token = tokenize_yaml('{"name": "Alex"}')
    assert type(token) == DictToken, "Expected dict token"
    assert "name" in token.value, "Missing key in dict token"
    assert token.value["name"] == "Alex", "Wrong value in dict token"

    # Test that a valid token is returned even if the YAML syntax is incorrect

# Generated at 2022-06-22 06:24:02.160231
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem import fields
    from typesystem.tokenize.tokens import DictToken, ScalarToken
    from typesystem.errors import Error
    import yaml
    from typing import List, Union
    next_position = 0
    def create_dict_token(key: str, value: Union[str, 'DictToken'], start: int, end: int):
        global next_position
        return DictToken({key: value}, start, end, content='test')
    def create_scalar_token(value: str):
        global next_position
        return ScalarToken(value, next_position, next_position + len(value) - 1, content='test')

# Generated at 2022-06-22 06:24:05.801102
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        from typesystem.fields import Integer
    except ImportError:  # pragma: no cover
        pytest.skip("pyyaml needs to be installed first.")

    content = "---\nint: 0"

    value, errors = validate_yaml(content, Integer())

    assert errors == []
    assert value == 0



# Generated at 2022-06-22 06:24:13.423349
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer

    content = "'foo'"  # This is an invalid value for Integer.

    value, errors = validate_yaml(content, Integer())
    msg = errors[0]
    assert msg.text == "Value is not valid."
    assert msg.code == "invalid"
    assert msg.position.line_no == 1
    assert msg.position.column_no == 1
    assert msg.position.char_index == 0



# Generated at 2022-06-22 06:24:23.112145
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml('"string"'), ScalarToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("1.5"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)



# Generated at 2022-06-22 06:24:30.755951
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") is None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml('{"a": 1}') == DictToken({"a": 1}, 0, 5)
    assert tokenize_yaml('[1, 2, 3]') == ListToken([1, 2, 3], 0, 8)
    assert tokenize_yaml('"a"') == ScalarToken("a", 0, 2)
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1)
    assert tokenize_yaml("a") == ScalarToken("a", 0, 1)
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3)

# Generated at 2022-06-22 06:24:42.388892
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test the tokenize_yaml function
    assert tokenize_yaml("null: Null value") == {'null': ScalarToken(None, 0, 12, content="null: Null value")}
    assert tokenize_yaml("bool: true") == {'bool': ScalarToken(True, 0, 8, content="bool: true")}
    assert tokenize_yaml("bool: false") == {'bool': ScalarToken(False, 0, 9, content="bool: false")}
    assert tokenize_yaml("float: 1.5e5") == {'float': ScalarToken(150000.0, 0, 10, content="float: 1.5e5")}

# Generated at 2022-06-22 06:24:49.288502
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"name": types.String(description="The name of the user")})
    assert validate_yaml("{}", schema) == ({}, [])
    assert validate_yaml("-", schema) == ([], ["Expected a mapping but found a sequence."])
    assert validate_yaml("\n\t-", schema) == (
        [],
        [
            "Expected a mapping but found a sequence.",
            "The `name` field is required.",
        ],
    )



# Generated at 2022-06-22 06:25:01.062575
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), ScalarToken)
    assert isinstance(tokenize_yaml("string"), ScalarToken)
    assert isinstance(tokenize_yaml("1234"), ScalarToken)
    assert isinstance(tokenize_yaml("123.004"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)

    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("{}").items[0], ListToken)
    assert isinstance(tokenize_yaml("{}").items[1], ListToken)


# Generated at 2022-06-22 06:25:12.574731
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String

    token, errors = validate_yaml(content='""', validator=String())
    assert isinstance(token, ScalarToken)
    assert not errors

    token, errors = validate_yaml(content='""', validator=String(max_length=5))
    assert isinstance(token, ScalarToken)
    assert not errors

    token, errors = validate_yaml(content='""', validator=String(min_length=2))
    assert isinstance(token, ScalarToken)
    assert len(errors) == 1
    assert isinstance(errors, list)
    assert isinstance(errors[0], ValidationError)

    token, errors = validate_yaml(
        content='!!python/object/apply:typesystem.String ["", "hello"]', validator=String()
    )
   

# Generated at 2022-06-22 06:25:21.167288
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"a: 1\nb: 2"
    schema = Schema({"a": int, "b": int})
    assert validate_yaml(content, schema) == ({'a': 1, 'b': 2}, [])
    content = b"a: 1\nb: [2, 3, 4]"
    assert validate_yaml(content, schema) == ({'a': 1, 'b': [2, 3, 4]}, [])
    content = b"a: 1\nb: {}"
    assert validate_yaml(content, schema) == ({'a': 1, 'b': {}}, [])
    content = b"a: 1\nb: '{}'"
    assert validate_yaml(content, schema) == ({'a': 1, 'b': '{}'}, [])

# Generated at 2022-06-22 06:25:35.488771
# Unit test for function validate_yaml
def test_validate_yaml():
    class PatientSchema(Schema):
        name = typesystem.String(required=True)
        age = typesystem.Integer(required=True)

    input_yaml = """
    name: Jack
    age: 47
    """
    
    # Pass case
    value, error_messages = validate_yaml(input_yaml, PatientSchema)
    assert len(error_messages) == 0

    # Fail case - incorrect type
    input_yaml = """
    name: Jack
    age: 47.5
    """

    _, error_messages = validate_yaml(input_yaml, PatientSchema)
    assert len(error_messages) > 0


if __name__ == "__main__":
    test_validate_yaml()

# Generated at 2022-06-22 06:25:48.288617
# Unit test for function validate_yaml
def test_validate_yaml():
    def validate_schema(validator: typing.Union[Field, typing.Type[Schema]]) -> typing.List[Message]:
        validator_instance = (
            validator() if isinstance(validator, type) else validator
        )
        content = '{"name": "test"}'
        try:
            value, errors = validate_yaml(content, validator_instance)
        except ParseError as error:
            if error.position.char_index is not None:
                return [Message(error.text, error.position)]
            else:
                return [Message(error.text, Position(0, 0, 0))]
        else:
            return errors

    class PersonSchema(Schema):
        name = Field(str, min_length=1)

    # Test the function with a Field instance

# Generated at 2022-06-22 06:25:59.199770
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = types.String()
        age = types.Integer()
    
    json = 'name: John\nage: 30'
    assert validate_yaml(json, Person)[0] == {'name': 'John', 'age': 30}
    
    json = 'name: John\nage: john'
    assert isinstance(validate_yaml(json, Person)[1], Message)
    
    assert validate_yaml('a: b\nage: 30', Person)[0] == {'a': 'b', 'age': 30}
    assert validate_yaml('a: b\nage: john', Person)[0] == {'a': 'b', 'age': 'john'}


# Generated at 2022-06-22 06:26:04.431895
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Given
    content = """
        foo: 123
        bar: 456
    """

    # When
    token = tokenize_yaml(content)

    # Then
    assert isinstance(token, DictToken)
    assert isinstance(token.foo, ScalarToken)
    assert token.foo.value == 123
    assert isinstance(token.bar, ScalarToken)
    assert token.bar.value == 456

# Generated at 2022-06-22 06:26:16.057610
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test a valid YAML input
    # Test when only one validator is passed
    validators1 = {
        "name": "string"
    }
    schema1 = Schema(validators1)
    content_string1 = "name: Kevin"
    value_string1, error_messages_string1 = validate_yaml(
        content_string1, schema1
    )
    assert value_string1 == {'name': 'Kevin'}
    assert error_messages_string1 == []

    # Test when list of validators is passed
    validators2 = [
        "string",
        "email"
    ]
    schema2 = Schema(validators2)
    content_string2 = "name: Kevin"

# Generated at 2022-06-22 06:26:27.363390
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    assert isinstance(tokenize_yaml(""), DictToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("hi"), ScalarToken)
    assert isinstance(tokenize_yaml("1.1"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)

    assert not isinstance(tokenize_yaml(""), ListToken)
   

# Generated at 2022-06-22 06:26:39.800956
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer

    # valid yaml
    parsed, err = validate_yaml(
        b"""
        integer: 123
        integer_list:
        - 1
        - 2
        - 3
        """,
        schema={"integer": Integer(), "integer_list": Integer[:]},
    )
    assert not err
    assert parsed == {"integer": 123, "integer_list": [1, 2, 3]}

    # invalid yaml
    parsed, err = validate_yaml(
        b"""
        integer_list:
        - 1
        - "two"
        - 3
        """,
        schema={"integer_list": Integer[:]},
    )
    assert len(err) == 1
    assert err[0].code == "invalid_type"
    assert len(err[0].messages)

# Generated at 2022-06-22 06:26:50.261311
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test empty String
    try:
        tokenize_yaml("")
    except ParseError as e:
        assert e.position == Position(column_no=1, line_no=1, char_index=0)
        assert e.code == "no_content"
        assert e.text == "No content."
    
    # test empty dict
    expected_dictionary = {'name': 'John', 'age': 21}
    input_dict = ("""
        name: John
        age: 21
        """)
    assert(tokenize_yaml(input_dict) == expected_dictionary)
    
    # test empty list
    expected_list = ['name', 'John', 'age', 21]

# Generated at 2022-06-22 06:26:58.506155
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '{"a":"b"}'
    validator = Field(name='a', required=True, validators=[lambda v: True])
    assert validate_yaml(content, validator) == ({'a': 'b'}, [])

    content = '{"a":"b"'
    validator = Field(name='a', required=True, validators=[lambda v: True])
    with pytest.raises(ParseError):
        validate_yaml(content, validator)


# Generated at 2022-06-22 06:27:10.471181
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    items:
    - type: string
    - type: integer
    - type: object
      properties:
        name: string
    - type: array
      items: string
      min_items: 4
    - type: array
      items:
        type: integer
        minimum: 10
    """

    item_schema = Schema(
        type="object",
        properties=Schema(type="object", properties={"type": "string"}),
        additional_properties=False,
    )

    schema = Schema(
        type="object",
        properties={
            "items": [item_schema]
        },
        additional_properties=False,
    )

    value, validation_errors = validate_yaml(content, schema)


# Generated at 2022-06-22 06:27:18.929151
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
        name: joe
        age: 10
    '''
    validator = Schema(
        {
            "name": str,
            "age": int
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {
        "name": "joe",
        "age": 10
    }
    assert errors == []

# Generated at 2022-06-22 06:27:29.931837
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "3"
    validator = typesystem.Integer(max_value=10)
    value, error_messages = validate_yaml(content, validator)
    assert value == 3
    assert len(error_messages) == 0

    content = "not_an_int"
    validator = typesystem.Integer(max_value=10)
    value, error_messages = validate_yaml(content, validator)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].code == "invalid_type"
    assert error_messages[0].position.char_index == 0
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 1

    content = "20"

# Generated at 2022-06-22 06:27:37.343324
# Unit test for function validate_yaml
def test_validate_yaml():
    mutate_message = Message(
        text=f"Field at path '{fieldpath}' must be '{expected_type}', found '{actual_type}'."
    )
    if not value:
        return
    if isinstance(value, str):
        return mutate_message(
            text=f"Field at path '{fieldpath}' must be '{expected_type}', found empty string."
        )
    if isinstance(value, bool):
        return mutate_message(
            text=(
                f"Field at path '{fieldpath}' must be '{expected_type}', found boolean "
                f"value '{value}'."
            )
        )

# Generated at 2022-06-22 06:27:48.407530
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.base import Field, ValidationError
    from typesystem.fields import String

    class CustomField(Field):
        def validate(self, value, path):
            if value == "foo":
                raise ValidationError('must not be foo')

    validator = CustomField()
    assert validate_yaml(content='foo', validator=validator) == (
        None,
        [
            Message(
                text="must not be foo.",
                code="invalid",
                type="",
                path=["foo"],
                position=Position(1, 1, 0),
            )
        ],
    )

    validator = String(max_length=2)

# Generated at 2022-06-22 06:27:57.674673
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    src1 = """
        a: aaaa
        b:
            - bbbb
        c:
            - cccc
            - dddd
    """
    src2 = """
        a: aaaa
        b:
            - bbbb
        c:
            - cccc
            - !value
    """
    token1 = tokenize_yaml(src1)
    token2 = tokenize_yaml(src2)
    assert isinstance(token1, DictToken)
    assert isinstance(token2, DictToken)
    assert str(token1) == src1
    assert str(token2) == src2

# Generated at 2022-06-22 06:28:04.768838
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    def test(input, expected_tokens, expected_error=None):
        if expected_error:
            try:
                tokenize_yaml(input)
            except ParseError as error:
                assert expected_error == error.__dict__
                return

        else:
            token = tokenize_yaml(input)
            assert expected_tokens == token.__dict__
    input = '''\
    key: value
    key2: value2
    '''


# Generated at 2022-06-22 06:28:15.404154
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.exceptions import ParseError, ValidationError
    class Student(Schema):
        name = String()

    # ValueError if content is not valid yaml
    try:
        validate_yaml(b'name: Na\xdfve', Student)
    except ParseError as e:
        assert e.text == 'expected <block end>, but found \'<bad indentation>\''
        assert e.position.line_no == 1
        assert e.position.column_no == 12

    # ValidationError if content is valid yaml but does not satisfy schema

# Generated at 2022-06-22 06:28:23.418055
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test list token
    token = tokenize_yaml('[1]')

    assert isinstance(token, ListToken)
    assert 0 == token.start
    assert 2 == token.end
    assert isinstance(token[0], ScalarToken)
    assert 1 == token[0].value

    # Test dict token
    token = tokenize_yaml('{"a": 2}')

    assert isinstance(token, DictToken)
    assert 0 == token.start
    assert 5 == token.end
    assert isinstance(token['a'], ScalarToken)
    assert 2 == token['a'].value

