

# Generated at 2022-06-22 06:18:42.329033
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    first_name: Joe
    last_name: Smith
    """
    validator = Schema.from_fields(
        {
            "first_name": Field(type="string"),
            "last_name": Field(type="string"),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"first_name": "Joe", "last_name": "Smith"}
    assert len(error_messages) == 0

    content = """
    first_name: Joe
    lastname: Smith
    """
    validator = Schema.from_fields(
        {
            "first_name": Field(type="string"),
            "last_name": Field(type="string"),
        }
    )
    value, error_messages = validate_

# Generated at 2022-06-22 06:18:52.406951
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test to validate a YAML string
    content = 'title: "The Title"\ncontent: "The Content"'
    validator = Schema({"title": String(), "content": String()})
    result = validate_yaml(content, validator)
    assert result == ({'title': 'The Title', 'content': 'The Content'}, [])

    # Test to validate a YAML string
    content = 'title: "The Title"\ncontent: "The Content"'
    validator = Schema({"title": String(), "content": Number()})
    result = validate_yaml(content, validator)

# Generated at 2022-06-22 06:19:01.900952
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Schema([
        Field(
            name='name',
            required=True,
            validators=[Length(min=1)],
            position=Position(column_no=5, char_index=5, line_no=3)
        ),
        Field(
            name='age',
            required=True,
            validators=[
                Type(int),
                Range(min=0, max=130),
            ],
            position=Position(column_no=5, char_index=18, line_no=4)
        ),
    ])
    content = """
---
name: "peter"
age: 30
"""
    value, errors = validate_yaml(content, validator)
    assert value == {'name': "peter", 'age': 30}
    assert errors == []



# Generated at 2022-06-22 06:19:05.575020
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    test_str:
      - hi
      - hello
    another_str:
      - 1
      - 0
    '''
    errors = validate_yaml(content, Schema.of(fields={
        "test_str": Field(str),
        "another_str": Field(list, of=int)
    }))
    assert len(errors) == 0



# Generated at 2022-06-22 06:19:14.321566
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert issubclass(tokenize_yaml(""), DictToken)
    assert issubclass(tokenize_yaml("foo: bar"), DictToken)
    assert issubclass(tokenize_yaml("- foo"), ListToken)
    assert issubclass(tokenize_yaml("- foo\n- bar"), ListToken)
    assert issubclass(tokenize_yaml("1234"), ScalarToken)
    assert issubclass(tokenize_yaml("bar"), ScalarToken)
    assert issubclass(tokenize_yaml('"bar"'), ScalarToken)
    assert issubclass(tokenize_yaml("true"), ScalarToken)
    assert issubclass(tokenize_yaml("1234"), ScalarToken)
    assert issubclass(tokenize_yaml("null"), ScalarToken)


# Generated at 2022-06-22 06:19:24.457403
# Unit test for function validate_yaml
def test_validate_yaml():
    def run_test(test_string, expected_output):
        token = tokenize_yaml(test_string)
        (value, messages) = validate_with_positions(
            token=token, validator=BasicYamlSchema
        )
        assert token == expected_output[0]
        assert messages == expected_output[1]

    def run_test_exception(test_string, expected_output):
        try:
            tokenize_yaml(test_string)
        except ParseError as e:
            assert e.text == expected_output
        else:
            assert False, "Did not raise Exception"

    class BasicYamlSchema(Schema):
        name = Field(required=True, type=str)
        age = Field(required=True, type=int)

# Generated at 2022-06-22 06:19:32.412568
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test empty string
    content = ""
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml(content)
    error_message = excinfo.value.args[0]
    error_code = excinfo.value.args[1]
    assert error_message == "No content."
    assert error_code == "no_content"

    # Test scalars
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0

    # Test lists
    assert tokenize_yaml("[1,2]") == [1, 2]

    # Test dicts
    assert tokenize_yaml("{'a':1, 'b':2}") == {"a": 1, "b": 2}

    # Test bad YAML


# Generated at 2022-06-22 06:19:40.694186
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
    {
        "a": int,
        "b": str,
        "c": {
            "c1": int,
        }
    },
    )
    content = """
    a: 1
    b: hello
    c:
        c1: world
    """
    assert isinstance(validate_yaml(content, schema), tuple)
    assert isinstance(validate_yaml(content, schema)[0], dict)
    assert isinstance(validate_yaml(content, schema)[1], Message)

# Generated at 2022-06-22 06:19:50.191021
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ScalarToken(None, 0, 0, content="")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    assert tokenize_yaml("True") == ScalarToken(True, 0, 3, content="True")
    assert tokenize_yaml("1234") == ScalarToken(1234, 0, 3, content="1234")
    assert tokenize_yaml("12.34") == ScalarToken(12.34, 0, 5, content="12.34")
    assert tokenize_yaml("-1234") == ScalarToken(-1234, 0, 4, content="-1234")

# Generated at 2022-06-22 06:20:02.742681
# Unit test for function validate_yaml
def test_validate_yaml():
    from typing import Callable, Any
    from typesystem.schemas import Schema
    from typesystem.fields import String, Number
    import pytest

    class TestSchema(Schema):
        name = String()
        email = String(format="email")
        age = Number()

    validator: Callable[[Any, Any], Any] = validate_yaml
    with pytest.raises(ParseError):
        validator(b"", TestSchema)

    # The content is *not* a YAML string
    with pytest.raises(ParseError):
        validator(b"foo", TestSchema)

    # The content is not a valid email address
    with pytest.raises(ValidationError) as excinfo:
        validator("email: foo", TestSchema)
    msg = excinfo

# Generated at 2022-06-22 06:20:12.795732
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        a = fields.String(min_length=2, max_length=10)
        b = fields.String()  # noqa

    schema = MySchema()
    content = "a: abc\nb: d"
    value, error_messages = validate_yaml(content, schema)

    assert value == {"a": "abc", "b": "d"}
    assert error_messages == []



# Generated at 2022-06-22 06:20:21.447045
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Valid YAML that parses to a string
    token = tokenize_yaml(content="key: value")
    assert isinstance(token, DictToken)
    assert token.content == "key: value"
    assert token.start_index == 0
    assert token.end_index == 8

    # Valid YAML that parses to a list
    token = tokenize_yaml(content="- one\n- two")
    assert isinstance(token, ListToken)
    assert token.content == "- one\n- two"
    assert token.start_index == 0
    assert token.end_index == 11
    assert isinstance(token.token_at_index(0), ScalarToken)
    assert token.token_at_index(0).content == "one"

# Generated at 2022-06-22 06:20:32.879662
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert (tokenize_yaml("""
    name: foo
    age: 25
    """)) == DictToken({'name': 'foo', 'age': 25}, 0, 29, content="""
    name: foo
    age: 25
    """)
    assert (tokenize_yaml("""
    - foo
    - bar
    """)) == ListToken(['foo', 'bar'], 0, 16, content="""
    - foo
    - bar
    """)

# Generated at 2022-06-22 06:20:42.726641
# Unit test for function validate_yaml
def test_validate_yaml():
    def test(validator, data, expected_errors=None):
        value, error_messages = validate_yaml(data, validator)
        assert error_messages == expected_errors

    test(validator=List(Integer()), data="[5, 6, 7, 8]", expected_errors=None)
    test(validator=List(Integer()), data="[5, 6, 7, 'a']", expected_errors=[
        Message(
            text="Value 'a' is not of type 'integer'.",
            code="invalid",
            position=Position(column_no=7, char_index=7, line_no=1),
        ),
    ])

# Generated at 2022-06-22 06:20:54.025266
# Unit test for function validate_yaml
def test_validate_yaml():
    with open("config_perfect.yaml") as f:
        config_perfect = f.read()
        config_perfect_token = tokenize_yaml(config_perfect)

# Generated at 2022-06-22 06:21:03.751287
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("[1, 2, 3, 4]")
    assert token.value == [1, 2, 3, 4]

    token = tokenize_yaml(" k1: v1")
    assert token.value["k1"] == "v1"

    token = tokenize_yaml("{k1: [v1, v2]")
    assert token.value["k1"] == ["v1", "v2"]

    token = tokenize_yaml("[1, 2, 3, 4")
    assert token.value == [1, 2, 3, 4]

    token = tokenize_yaml("{1: 2, 3: 4")
    assert token.value == {1: 2, 3: 4}



# Generated at 2022-06-22 06:21:09.922987
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    
    content = yaml.dump([1, 2, 3])
    validator = "List[int]"

    token = tokenize_yaml(content)
    validate_with_positions(token=token, validator=validator)

    # assert validate_with_positions(token=token, validator=validator) == ([1,2,3],[])
    # assert validate_yaml(content=content,validator=validator) == ([1,2,3],[])
    # assert validate_yaml(content=content,validator=validator) == None

    
    

# Generated at 2022-06-22 06:21:21.265407
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == {"": ""}
    assert tokenize_yaml("{}") == {"": ""}
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("5") == 5
    assert tokenize_yaml("5.0") == 5.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml('''"test"''') == "test"
    assert tokenize_yaml('''"test"''') == "test"
    assert tokenize_yaml('''["test"]''') == ["test"]
    assert tokenize_yaml('''["test"]''') == ["test"]



# Generated at 2022-06-22 06:21:31.369107
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("null") == ScalarToken(value=None, start=0, end=3, content="null")
    assert tokenize_yaml("false") == ScalarToken(value=False, start=0, end=4, content="false")
    assert tokenize_yaml("true") == ScalarToken(value=True, start=0, end=3, content="true")
    assert tokenize_yaml("0") == ScalarToken(value=0, start=0, end=1, content="0")
    assert tokenize_yaml("-0") == ScalarToken(value=0, start=0, end=2, content="-0")
    assert tokenize_yaml("1") == ScalarToken(value=1, start=0, end=1, content="1")
    assert tokenize_

# Generated at 2022-06-22 06:21:41.426204
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # YAML string
    yaml_str = "a: 1\nb: 2"
    expected_str_output = "DictToken(OrderedDict([('a', ScalarToken(1, 0, 1, content='a: 1\\nb: 2')), ('b', ScalarToken(2, 4, 5, content='a: 1\\nb: 2'))]), 0, 10, content='a: 1\\nb: 2')"

    # YAML bytes
    yaml_bytes = b"a: 1\nb: 2"

# Generated at 2022-06-22 06:21:55.223896
# Unit test for function validate_yaml
def test_validate_yaml():

    class User(Schema):
        name = fields.String()
        email = fields.String()

    content = ""
    with pytest.raises(ParseError) as exc_info:
        validate_yaml(content, User)
    assert exc_info.value.position.line_no == 1
    assert exc_info.value.position.column_no == 1
    assert exc_info.value.position.char_index == 0

    content = """
    name: Anthony Ford
    email: anthony.ford@example.com
    """

    assert validate_yaml(content, User) == (
        {"name": "Anthony Ford", "email": "anthony.ford@example.com"},
        [],
    )


# Generated at 2022-06-22 06:22:05.675245
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        a: 1
        b:
          c: 2
          d: 3
          e:
            - 1
            - 2
            - 3
            -
              f: 4
              g: 5
    """
    token = tokenize_yaml(content)

    # Ensure that the content of the tokens is correct.
    assert token.items["a"].value == 1
    assert token.items["b"].items["c"].value == 2
    assert token.items["b"].items["d"].value == 3
    assert token.items["b"].items["e"].items[0].value == 1
    assert token.items["b"].items["e"].items[3].items["f"].value == 4

# Generated at 2022-06-22 06:22:16.162538
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Number
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    assert validate_yaml("", String()) == (None, [])
    assert validate_yaml("", Number()) == (None, [])
    assert validate_yaml("", String()[10]) == (None, ["Value may not be null."])
    assert validate_yaml("", String()[10:]) == (None, ["Value may not be null."])
    assert validate_yaml("", String(min_length=10)) == (
        None,
        [
            "Value may not be null.",
            "Must have at least 10 characters.",
        ],
    )
    assert validate_yaml("", String() | Number()) == (None, ["Value may not be null."])

    assert validate

# Generated at 2022-06-22 06:22:27.367799
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer
    from typesystem.base import ValidationError
    from typesystem.fields import Field
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.tokens import ScalarToken
    from typesystem.tokenize.yaml import validate_yaml

    # Test validating a YAML string.
    validator = Field(type=Integer())
    value, error_messages = validate_yaml(content="1", validator=validator)
    assert value == 1
    assert error_messages == []
    with pytest.raises(ValidationError):
        validate_yaml(content="x", validator=validator)

# Generated at 2022-06-22 06:22:37.480615
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = {"name": "name", "type": "string"}
    content = '{"name": "abc"}'
    assert validate_yaml(content, schema) == (
        {'name': 'abc'},
        None,
    )
    content = "name: abc"
    assert validate_yaml(content, schema) == (
        None,
        [
            ValidationError(
                text="Additional properties are not allowed ('name' was unexpected).",
                code="unexpected",
                position=Position(column_no=1, line_no=1, char_index=0),
            )
        ],
    )
    content = '["abc"]'

# Generated at 2022-06-22 06:22:48.825379
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"foo": {"type": "string"}})
    value, error_messages = validate_yaml(
        content='foo: "bar"', validator=schema,
    )
    assert (value, error_messages) == ({"foo": "bar"}, [])

    value, error_messages = validate_yaml(
        content="foo:", validator=schema,
    )
    assert (
        value,
        error_messages,
    ) == (
        None,
        [
            ValidationError(
                "Invalid value.",
                position=Position(
                    line_no=1, column_no=5, char_index=4,
                ),
                code="invalid_value",
                field="foo",
            ),
        ],
    )

    value,

# Generated at 2022-06-22 06:22:55.419970
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Tests the validate_yaml function.
    """
    try:
        from typesystem.main import types
        from typesystem.typing import RegisterType
    except ImportError:  # pragma: no cover
        return

    @RegisterType()
    class Person(types.Schema):
        name = types.String()
        age = types.Integer()

    person_schema = Person()
    # Validates successfully.
    person = Person(name="Roger", age=35)
    # Generates the correct error messages.
    person = Person(name="Roger")
    errors = [
        Message(
            text="This field is required.",
            code="required",
            position=Position(column_no=2, line_no=4, char_index=14),
        )
    ]

    assert errors == person_sche

# Generated at 2022-06-22 06:23:04.863107
# Unit test for function validate_yaml
def test_validate_yaml():
    assert(validate_yaml(b'h\nllo', (str))[0] == 'h\nllo')
    assert(validate_yaml(b'h\nllo', (str))[1] == [])
    assert(validate_yaml(b'h\nllo', (int))[0] == None)
    assert(isinstance(validate_yaml(b'h\nllo', (int))[1], list))
    assert(validate_yaml(b'h\nllo', (int))[1][0].text == 'must be an integer.')
    assert(isinstance(validate_yaml(b'h\nllo', (int))[1][0], ValidationError))

# Generated at 2022-06-22 06:23:16.822811
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: Adam
      city: "London"
    - name: Brett
      city: "Sydney"
    - name: Chris
      city: "New York"
    - name: Katie
      city: "Melbourne"
    - name: Simon
      city: "Johannesburg"
    - name: "Zoe"
      city: "Tokyo"
    - name: Zzzzzz
      city: "Hong Kong"
    """

    schema = Schema(fields={"name": {"type": "string", "max_length": 10}})

    class SchemaWithNullableField(Schema):
        name = {"type": "string", "nullable": True}
        city = {"type": "string", "max_length": 10}


# Generated at 2022-06-22 06:23:23.430609
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("2"), ScalarToken)
    assert isinstance(tokenize_yaml("-2"), ScalarToken)
    assert isinstance(tokenize_yaml("2.0"), ScalarToken)
    assert isinstance(tokenize_yaml("abc"), ScalarToken)


# Generated at 2022-06-22 06:23:31.195884
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"name": String()})
    body = '{"name":"John"}'
    value, errors = validate_yaml(content=body, validator=schema)
    assert value == {"name": "John"}
    assert errors == (Message(text="No errors.", code="no_errors", position=None),)

# Generated at 2022-06-22 06:23:32.777697
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    tokenize_yaml("")
    tokenize_yaml("")

# Generated at 2022-06-22 06:23:44.536786
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem import String

    str_content = "a:"
    value, error_messages = validate_yaml(str_content, String(max_length=1))
    assert value is not None
    assert len(error_messages) == 0

    str_content = "- b:"
    value, error_messages = validate_yaml(str_content, String(max_length=1))
    assert value is not None
    assert len(error_messages) == 0

    str_content = "a: \"0123456789\""
    value, error_messages = validate_yaml(str_content, String(max_length=4))
    assert value is None
    assert len(error_messages) == 1


# Generated at 2022-06-22 06:23:51.158914
# Unit test for function validate_yaml
def test_validate_yaml():
    value, errors = validate_yaml(
        b"foo: bar\n"
        b"baz: 42\n",
        {
            "foo": "text",
            "baz": "number"
        }
    )
    assert value == {'foo': 'bar', 'baz': 42}
    assert errors == []

    value, errors = validate_yaml(
        b"foo: bar\n"
        b"baz: 42\n",
        {
            "foo": "text",
            "baz": "number",
            "extra": "text"
        }
    )
    assert value == {'foo': 'bar', 'baz': 42}
    assert len(errors) == 1
    assert errors[0].text == "Extra fields not allowed."

# Generated at 2022-06-22 06:23:59.288694
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test for empty string works
    content = ''
    assert tokenize_yaml(content) == None

    # Test for non-empty string works
    content = 'This is a valid string.'
    assert tokenize_yaml(content) == content

    # Test for bytestring works
    content = b'This is a valid bytestring.'
    assert tokenize_yaml(content) == content.decode('utf-8', 'ignore')

    # Test for error handling works
    content = '*This is an invalid string. The asterisk is an invalid character in a YAML string.'
    with pytest.raises(ParseError):
        tokenize_yaml(content)

# Generated at 2022-06-22 06:24:07.965250
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test simple scalar token
    content = """
        a:
            - b
    """
    tokens = tokenize_yaml(content)
    assert tokens.items()[0][0].content == 'a'
    assert tokens.items()[0][1].values()[0].content == 'b'

    # Test invalid scalar token
    content = """
        - a:
            - b
    """
    tokens = tokenize_yaml(content)
    assert tokens.values()[0].items()[0][0].content == 'a'
    assert tokens.values()[0].items()[0][1].values()[0].content == 'b'

    # Test invalid scalar token
    content = """
        -   
            a: b
    """

# Generated at 2022-06-22 06:24:18.563295
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        test_field = Field(validators=[validate.Length(max=5)])

    good_yaml = "test_field: fooooo"
    assert validate_yaml(good_yaml, TestSchema) == (
        {},
        [Message(text="Ensure this field has no more than 5 characters.", code="max_length", line_no=1, column_no=17)],
    )

    good_yaml = "test_field:  :"
    assert validate_yaml(good_yaml, TestSchema) == ({}, [])

    bad_yaml = "test_field"

# Generated at 2022-06-22 06:24:19.973265
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert None == tokenize_yaml("")


# Generated at 2022-06-22 06:24:25.963243
# Unit test for function validate_yaml
def test_validate_yaml():
    class ExampleSchema(Schema):
        first_name = fields.String()
        last_name = fields.String()
        age = fields.Integer()

    schema = ExampleSchema()
    content = """
    first_name: James
    last_name: Arthur
    age: 123
    """
    value, errors = validate_yaml(content, schema)
    assert len(errors) == 0



# Generated at 2022-06-22 06:24:37.872560
# Unit test for function tokenize_yaml

# Generated at 2022-06-22 06:24:50.883126
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    content = """
        name: John Doe
        age: 10
        married: false
        children: []
        hobbies:
          - cycling
          - running
    """
    expected = """name: John Doe
age: 10
married: false
children: []
hobbies:
  - cycling
  - running"""
    from typesystem.schemas import Schema
    from typesystem import fields

    class SomeSchema(Schema):
        name = fields.String(format="name")
        age = fields.Integer(min_value=0, max_value=130)
        married = fields.Boolean()
        children = fields.Array(fields.String(format="name"))
        hobbies = fields.Array(fields.String(format="name"))


# Generated at 2022-06-22 06:24:54.631984
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test file is expected to be found in tests/files/
    content = open('files/test-yaml.yml', 'r').read()
    validate_yaml(content, MySchema)


# Generated at 2022-06-22 06:25:06.811423
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test scalar case
    assert tokenize_yaml("test") == ScalarToken("test", 0, 3, content="test")

    # Test list case
    assert tokenize_yaml(" [1, 2]") == ListToken([1, 2], 1, 7, content=" [1, 2]")

    # Test dict case
    assert tokenize_yaml("{a: 2}") == DictToken({"a": 2}, 0, 5, content="{a: 2}")

    # Test empty content
    with pytest.raises(ParseError, match="No content"):
        tokenize_yaml("")

    # Test content with error
    with pytest.raises(ParseError, match="Unexpected end of stream"):
        tokenize_yaml("{a:}")



# Generated at 2022-06-22 06:25:09.605716
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)

    value, errors = validate_yaml("name: 'joe'", Person)
    assert errors == []

# Generated at 2022-06-22 06:25:19.940994
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Field name is not mentioned in the Locust error logs.
    """
    # Given a content and a validator

# Generated at 2022-06-22 06:25:25.955568
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("""
        name: John
        given_name: John
        last_name: Doe
        age: 10
        """, Schema) == (
        {
            "name": "John",
            "given_name": "John",
            "last_name": "Doe",
            "age": 10
        },
        []
    )

# Generated at 2022-06-22 06:25:29.741345
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), DictToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("'foo'"), ScalarToken)
    assert isinstance(tokenize_yaml('"foo"'), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("123"), ScalarToken)
    assert isinstance(tokenize_yaml("123.45"), ScalarToken)

# Generated at 2022-06-22 06:25:39.923033
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields.primitives import Any, Number, String
    from typesystem.exceptions import ValidationError
    class TestSchema(Schema):
        name = String()
        test = Number()

    content = b"""
name: test
test: 2
"""

    assert validate_yaml(content, validator=TestSchema) == ('test','2')
    with pytest.raises(ValidationError):
        validate_yaml(content, validator=TestSchema(required=False))
    with pytest.raises(ValidationError):
        validate_yaml(content, validator=Any())

# Generated at 2022-06-22 06:25:51.596124
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.yaml import validate_yaml
    from typesystem import String
    from typesystem.schemas import Schema

    class MovieSchema(Schema):
        title = String(max_length=100)

    result, errors = validate_yaml(
        content='title: An Ill-Advised Autobiography',
        validator=MovieSchema,
    )
    assert result.title == "An Ill-Advised Autobiography", "Correct title"
    assert errors == [], "No errors"

    result, errors = validate_yaml(
        content='title: Once Upon a Time in Hollywood', validator=MovieSchema
    )


# Generated at 2022-06-22 06:25:59.604870
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        field1 = String()
        id = Integer()
        names = Array(items=String())
        location = Object(additional_properties=Boolean())

    _, errors = validate_yaml(
        """
        field1: test1
        id: 12
        names:
        - name1
        - name2
        location:
            country: true
            province: false
    """,
        TestSchema,
    )
    assert len(errors) == 0



# Generated at 2022-06-22 06:26:08.719475
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """a_string: !!str This is a string.
a_int: !!int 10
a_float: !!float 10.0
a_bool: !!bool "false"
a_null: !!null ~
a_list: !!seq
    - 1
    - 2
    - 3
a_dict:
    b_string: !!str This is a string.
    b_int: !!int 10
    b_float: !!float 10.0
    b_bool: !!bool "false"
    b_null: !!null ~
    b_list: !!seq
        - 1
        - 2
        - 3"""
    token = tokenize_yaml(content)
    assert token
    assert token['a_string'].value == 'This is a string.'
    assert token['a_int'].value == 10

# Generated at 2022-06-22 06:26:20.384560
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ""
    assert tokenize_yaml("123") == 123
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("[1, 2]") == [1, 2]
    assert tokenize_yaml("{a: 1, b: 2}") == {"a": 1, "b": 2}
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a test") == "a test"
    assert tokenize_yaml("3.14") == 3.14

# Generated at 2022-06-22 06:26:25.938403
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: 1
    b: 2
    c:
        - 1
        - 2
        - 3
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.to_primitive() == {"a": 1, "b": 2, "c": [1, 2, 3]}



# Generated at 2022-06-22 06:26:38.177115
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), ScalarToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("a"), ScalarToken)
    assert isinstance(tokenize_yaml("1.0"), ScalarToken)
    assert isinstance(tokenize_yaml("1.0e10"), ScalarToken)
    assert isinstance(tokenize_yaml("yes"), ScalarToken)
    assert isinstance(tokenize_yaml("no"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)

# Generated at 2022-06-22 06:26:49.456568
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields
    from typesystem.tokenize.base import tokenize_yaml

    class SimpleObject(Schema):
        name = fields.String()
        age = fields.Integer()

    # Add an error to the object
    SimpleObject.add_error("age", "invalid_age", "Your age is invalid.")

    # Validate the YAML content.
    content = """
    name: Vince
    age: 22
    """

    token = tokenize_yaml(content)
    value, error_messages = validate_with_positions(token, SimpleObject)

    # Assert the value.
    assert value == {"name": "Vince", "age": 22}

    # Assert the expected error.
    assert len(error_messages) == 1

# Generated at 2022-06-22 06:26:57.258393
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
---
name: Tyler
age: 21
tags:
  - red
  - green
  - blue
'''
    class Person(Schema):
        name = Text()
        age = Integer()
        tags = List(Text())
    value, errors = validate_yaml(content, Person)
    assert value == {
        "name": "Tyler",
        "age": 21,
        "tags": ["red", "green", "blue"]
    }
    assert errors == []



# Generated at 2022-06-22 06:27:09.187097
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert isinstance(tokenize_yaml("key: value"), DictToken)
    assert isinstance(tokenize_yaml("- 1"), ListToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("1.2"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert tokenize_yaml("key: value").keys() == ['key']
    assert tokenize_yaml("- 1").values() == [1]
    assert tokenize_yaml("1").values() == 1
    assert tokenize_yaml("1.2").values() == 1.

# Generated at 2022-06-22 06:27:10.653818
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == {}



# Generated at 2022-06-22 06:27:22.269158
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test all the import functionality of typesystem's validate, using 
    a simple yaml file
    """
    assert yaml is not None, "'pyyaml' must be installed."
    assert Field is not None, "'Field' must be installed."
    assert Schema is not None, "'Schema' must be installed."

    class NoInputError(Exception):  # pragma: no cover
        """No input error class, defines an internal error module"""
        pass

    #load the test file
    try:
        with open("./test/test_validate_yaml.yaml",'r') as file_obj:
            content = file_obj.read()
    except IOError:
        raise NoInputError  # pragma: no cover

    #Define a test schema

# Generated at 2022-06-22 06:27:23.528269
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

# Generated at 2022-06-22 06:27:26.833030
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
  yaml_string = "!ScalarToken value=5, start=0, end=1, content='5'"
  assert tokenize_yaml(yaml_string) == "5"


# Generated at 2022-06-22 06:27:30.014773
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    nav:
      - text: Menu 1
        url: /menu1/
      - text: Menu 2
        url: /menu2/
    """
    assert content == tokenize_yaml(content).content


# Generated at 2022-06-22 06:27:32.681209
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(required=True, type="string")
    # TODO: add unit test



# Generated at 2022-06-22 06:27:38.323352
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(name="yaml", type="string")
    value, error_messages = validate_yaml("one: two", validator)
    assert value == u"one: two"
    assert error_messages.as_dict() == {}


# Generated at 2022-06-22 06:27:47.605317
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
name: apple
address:
    number: 123
    street: Some Road
    city: Some City
    country: New Zealand
quantity: 2
    """
    assert yaml is not None, "'pyyaml' must be installed."

    token = tokenize_yaml(content)

    assert isinstance(token, DictToken)
    assert token.value == {
        'name': 'apple',
        'address': {
            'number': 123,
            'street': 'Some Road',
            'city': 'Some City',
            'country': 'New Zealand',
        },
        'quantity': 2,
    }


# Generated at 2022-06-22 06:27:59.430484
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: 1
    b: 2
    c: 3
    """
    dict_token = tokenize_yaml(content)
    assert dict_token.value == {"a": 1, "b": 2, "c": 3}
    assert dict_token.start == 1
    assert dict_token.end == len(content) - 2

    content = "# a comment\n"
    dict_token = tokenize_yaml(content)
    assert dict_token.value == {}
    assert dict_token.start == 0
    assert dict_token.end == len(content) - 1

    content = "a\n"
    with pytest.raises(ParseError):
        tokenize_yaml(content)

    content = "a: 1\nb: 2\nc: 3\n"

# Generated at 2022-06-22 06:28:11.098720
# Unit test for function validate_yaml
def test_validate_yaml():
    class Sample(Schema):
        name = fields.String()
        age = fields.Integer(max_value=100)

    result = validate_yaml(
        content="""
    name: Ron Swanson
    age: 50
    """,
        validator=Sample,
    )
    value, error_messages = result
    assert value == {"name": "Ron Swanson", "age": 50}
    assert not error_messages

    result = validate_yaml(
        content="""
    name: Ron Swanson
    age: 500
    """,
        validator=Sample,
    )
    value, error_messages = result
    assert not value

# Generated at 2022-06-22 06:28:15.557305
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('{"a":1, "b":[{"c":"d"}]}')
    assert isinstance(token, DictToken)
    assert token.content == '{"a":1, "b":[{"c":"d"}]}'