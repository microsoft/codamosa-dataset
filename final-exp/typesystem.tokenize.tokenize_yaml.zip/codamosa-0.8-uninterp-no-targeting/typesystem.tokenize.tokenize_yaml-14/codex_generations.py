

# Generated at 2022-06-22 06:18:46.439429
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import (
        AnyField,
        ArrayField,
        DateField,
        DateTimeField,
        IntegerField,
        StringField,
    )
    from typesystem.schemas import Schema

    class TodoSchema(Schema):
        title = StringField()
        due_date = DateField(format="%Y-%m-%d")
        completed = AnyField()

    yaml_schema = """
            title: a title
            due_date: 2019-01-01
            completed: false
            """
    value, errors = validate_yaml(yaml_schema, TodoSchema)
    assert value == {"title": "a title", "due_date": datetime.date(2019, 1, 1), "completed": False}


# Generated at 2022-06-22 06:18:54.249063
# Unit test for function validate_yaml
def test_validate_yaml():
    import textwrap, sys

    def validate_yaml_test(yaml_string, validator,expected_parsed_error_list):
        print("*******TESTING*******")
        print("yaml_string:", yaml_string)
        print("validator:", validator)
        position_marked_errors = validate_yaml(yaml_string, validator)
        print("position_marked_errors:", position_marked_errors)
        assert position_marked_errors[1] == expected_parsed_error_list
        print("")

    from typesystem import Schema, fields

    class Person(Schema):
        name = fields.String(max_length=20)
        age = fields.Integer()


# Generated at 2022-06-22 06:19:05.698010
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("[]")
    assert issubclass(type(token), ListToken)

    token = tokenize_yaml("{}")
    assert issubclass(type(token), DictToken)

    token = tokenize_yaml("1.0")
    assert issubclass(type(token), ScalarToken)
    assert token.value == 1.0

    token = tokenize_yaml("1")
    assert issubclass(type(token), ScalarToken)
    assert token.value == 1



# Generated at 2022-06-22 06:19:16.298627
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test parsing a YAML string.
    input_data = '''
    a: 1
    b: 2
    c: 3
    '''
    token = tokenize_yaml(input_data)
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == 27
    assert token.value == {'a': 1, 'b': 2, 'c': 3}

    # Test parsing a YAML bytestring.
    input_data = b'a: 1\nb: 2\nc: 3'
    token = tokenize_yaml(input_data)
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == 14

# Generated at 2022-06-22 06:19:25.314122
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    token = tokenize_yaml("""
    key: value
    """)
    assert isinstance(token, DictToken)
    assert token.value["key"] == "value"
    assert token.start == 1
    assert token.end == 20

    token = tokenize_yaml("""
    - item
    """)
    assert isinstance(token, ListToken)
    assert token.value[0] == "item"
    assert token.start == 1
    assert token.end == 11

    token = tokenize_yaml("value")
    assert isinstance(token, ScalarToken)
    assert token.value == "value"
    assert token.start == 0
    assert token.end == 4

# Generated at 2022-06-22 06:19:28.340001
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content='{"hello":"world"}'
    tokens = tokenize_yaml(content)
    assert isinstance(tokens, DictToken)
    assert isinstance(tokens.value['hello'], ScalarToken)
    assert isinstance(tokens.value['hello'].value, str)


# Generated at 2022-06-22 06:19:38.917073
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    content = 'name: "Eric"\nage: 99'
    person, messages = validate_yaml(content, validator=Person)
    # should pass
    assert person.name == "Eric"
    assert person.age == 99
    assert not messages

    content = 'name: "Eric"\nage: not_int'
    person, messages = validate_yaml(content, validator=Person)
    # should fail
    assert messages
    assert messages[0].text == 'Value should be of type "int", but got "not_int".'
    assert messages[0].position.line_no == 2
    assert messages[0].position.column_no == 4



# Generated at 2022-06-22 06:19:50.299822
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    content = """
    a: 1
    b: "c"
    c: true
    d: null
    e: [1, 2, 3]
    f:
    - 1
    - 2
    - 3
    """

    token = tokenize_yaml(content)
    print(token)
    assert isinstance(token, DictToken)
    assert isinstance(token.value["a"], ScalarToken)
    assert isinstance(token.value["b"], ScalarToken)
    assert isinstance(token.value["c"], ScalarToken)
    assert isinstance(token.value["d"], ScalarToken)
    assert isinstance(token.value["e"], ListToken)
    assert isinstance(token.value["f"], ListToken)



# Generated at 2022-06-22 06:20:02.844375
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    list:
    - item1
    - item2
    dict:
       a: apple
       b: banana
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.start == 1
    assert token.end == 59
    assert token.content == content
    assert token.value.keys() == {"list", "dict"}
    assert isinstance(token.value["list"], ListToken)
    assert token.value["list"].start == 12
    assert token.value["list"].end == 18
    assert token.value["list"].value == ["item1", "item2"]
    assert isinstance(token.value["dict"], DictToken)
    assert token.value["dict"].start == 29

# Generated at 2022-06-22 06:20:07.566827
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("{a:b}"), DictToken)
    assert isinstance(tokenize_yaml("[a, b]"), ListToken)
    assert isinstance(tokenize_yaml("b"), ScalarToken)
    assert tokenize_yaml("{a:b}").start == 0
    assert tokenize_yaml("b").end == 1
    assert tokenize_yaml("{a:b}").get_position(0).char_index == 0



# Generated at 2022-06-22 06:20:21.369777
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = fields.List(fields.Integer())
    value, errors = validate_yaml('- 1\n- 2', schema)
    assert value == [1, 2]
    assert(errors == [])

    value, errors = validate_yaml('- 1\n- "2"', schema)
    assert value == [1]
    print(errors)
    assert(errors[0].text == '"2" is not a valid integer.')

    value, errors = validate_yaml('- 1\n- not a number', schema)
    assert value == [1]
    assert(errors[0].text == '"not a number" does not match "<class \'typesystem.fields.Integer\'>"')
    
    value, errors = validate_yaml('\n- 1\n- "2"', schema)

# Generated at 2022-06-22 06:20:32.780421
# Unit test for function validate_yaml
def test_validate_yaml():
    SCHEMA = {
        "properties": {
            "name": {"type": "string", "maxLength": 100},
            "email": {"type": "string", "format": "email"},
        },
        "required": ["name", "email"],
    }
    validator = Schema(SCHEMA)
    data = {"name": "Eliot", "email": "eliot@example.com"}
    content = yaml.dump(data)
    yaml_value, yaml_error_msgs = validate_yaml(content, validator)
    assert yaml_value == data
    assert yaml_error_msgs == []

    bad_data = {"name": "El", "email": "eliot@example.com"}
    bad_content = yaml.dump(bad_data)
    yaml_bad_

# Generated at 2022-06-22 06:20:39.943449
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("[1, 2]")
    assert isinstance(token, ListToken)
    assert token.value == [1, 2]
    assert token.content[token.start : token.end + 1] == "[1, 2]"

    token = tokenize_yaml("{foo: bar}")
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}
    assert token.content[token.start : token.end + 1] == "{foo: bar}"

    token = tokenize_yaml("42")
    assert isinstance(token, ScalarToken)
    assert token.value == 42



# Generated at 2022-06-22 06:20:47.173730
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("1.5"), ScalarToken)
    assert isinstance(tokenize_yaml("'string'"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)


# Generated at 2022-06-22 06:20:51.597974
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    token = tokenize_yaml("")
    assert token.type == "DictToken"

    token = tokenize_yaml("foo:")
    assert token.type == "DictToken"

    token = tokenize_yaml("foo: bar")
    assert token.type == "DictToken"


# Generated at 2022-06-22 06:21:02.566728
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content_dict = {
        "name": "Jane",
        "age": 27,
        "quizzes": [5, 10, 15],
        "final": 20,
        "success": True,
        "nothing": None,
    }
    content_list = [5, 10, 15, 20]
    content_scalar = "hello world"
    content_int = 5
    content_float = 5.0
    content_bool = True
    content_null = None
    assert tokenize_yaml(content_dict) == content_dict
    assert tokenize_yaml(content_list) == content_list
    assert tokenize_yaml(content_scalar) == content_scalar
    assert tokenize_yaml(content_int) == content_int

# Generated at 2022-06-22 06:21:07.467790
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        test = "text"

    try:
        content = b"test: 1'"
        assert validate_yaml(content, TestSchema) == None
    except AssertionError:
        pass
    else:
        raise AssertionError("lỗi")

    try:
        content = "test: 1"
        assert validate_yaml(content, TestSchema) == ({"test": "1"}, None)
    except AssertionError:
        pass
    else:
        raise AssertionError("lỗi")

# Generated at 2022-06-22 06:21:08.723780
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ""

# Generated at 2022-06-22 06:21:15.598539
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Given
    content = """
        a: 1
        b: 2
        c: 3
        """

    # When
    token = tokenize_yaml(content)

    # Then
    assert token.code == 'dict'
    assert token.start == 0
    assert token.end == 23
    assert token.content == content

    # Given
    content = """
        a: !Seq
         - 1
         - 2
         - 3
        """

    # When
    token = tokenize_yaml(content)

    # Then
    assert token.code == 'dict'
    assert token.start == 0
    assert token.end == 30
    assert token.content == content


# Generated at 2022-06-22 06:21:18.863189
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test for function validate_yaml"""
    assert yaml is not None, "'pyyaml' must be installed."

    class Person(Schema):
        name = String(max_length=6)
        age = Integer()

    content = "name: 'John'\nage: 28"
    value, error_messages = validate_yaml(content, Person)

    assert error_messages == []



# Generated at 2022-06-22 06:21:31.514639
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem
    class Pet(typesystem.Schema):
        name = typesystem.String(max_length=100)
        age = typesystem.Integer(default=10)
        weight = typesystem.Float(default=20.4)
        is_rabies_vaccinated = typesystem.Boolean(default=True)
        owner_id = typesystem.Integer()
        created_at = typesystem.Date(default='2016-01-01')
        last_login = typesystem.DateTime(default=datetime.datetime(2016, 2, 1, 2, 3, 4))
        points = typesystem.Decimal(max_digits=3)

    class PetList(typesystem.Schema):
        pets = typesystem.Array(items=Pet)


# Generated at 2022-06-22 06:21:43.314227
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Boolean, Integer
    from typesystem import Schema
    from typesystem import ValidationError

    class MySchema(Schema):
        name = String(min_length=3, max_length=10)
        age = Integer(minimum=0)
        is_fun = Boolean()

    schema = MySchema()

    # Successful validation
    value, error_messages = validate_yaml(
        content="name: John\nage: 30\nis_fun: true",
        validator=schema
    )
    assert error_messages == []
    assert value == {"name": "John", "age": 30, "is_fun": True}

    # Failed validation

# Generated at 2022-06-22 06:21:49.642947
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('---\na: 1\n')
    assert type(token) == DictToken
    assert token.start == 0
    assert token.end == 6
    assert token.children[0].value == 'a'
    assert token.children[1].value == 1
    assert token.children[1].start == 4
    assert token.children[1].end == 5


# Generated at 2022-06-22 06:21:58.041565
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Query a dictionary
    content = """
        # A comment
        key: value
    """
    token = tokenize_yaml(content)
    assert token.value == {"key": "value"}

    # Query a list
    content = """
        - foo
        - bar
        - baz
    """
    token = tokenize_yaml(content)
    assert token.value == ["foo", "bar", "baz"]

    # Query an integer
    content = "42"
    token = tokenize_yaml(content)
    assert token.value == 42

    # Query a float
    content = "42.14"
    token = tokenize_yaml(content)
    assert token.value == 42.14

    # Query null
    content = "null"
    token = tokenize_yaml(content)


# Generated at 2022-06-22 06:22:09.767323
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(b"{}") == {}
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("{a:b}") == {"a": "b"}
    assert tokenize_yaml("- foo") == ["foo"]
    assert tokenize_yaml("null") is None
    assert tokenize_yaml("10") == 10
    assert tokenize_yaml("10.0") == 10.0
    assert tokenize_yaml("true") is True
    assert tokenize_yaml("false") is False

    # Handle the empty string case explicitly for clear error messaging.
    try:
        tokenize_yaml("")
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert exc

# Generated at 2022-06-22 06:22:16.014854
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    text = '''
    type: object
    properties:
      name:
        type: string
    '''
    tokens = tokenize_yaml(text)
    assert tokens == {
        "type": "object",
        "properties": {"name": {"type": "string"}},
    }
    assert tokens.content == text



# Generated at 2022-06-22 06:22:24.991832
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test ScalarToken
    token = tokenize_yaml("name: Eric")
    assert isinstance(token, DictToken)
    assert isinstance(token["name"], ScalarToken)
    # Test ListToken
    token = tokenize_yaml("- E")
    assert isinstance(token, ListToken)
    assert isinstance(token[0], ScalarToken)
    # Test DictToken
    token = tokenize_yaml("name: E")
    assert isinstance(token, DictToken)
    assert isinstance(token["name"], ScalarToken)
    assert token["name"].value == "E"
    assert token["name"].start == 6
    assert token["name"].end == 6


# Generated at 2022-06-22 06:22:34.287307
# Unit test for function validate_yaml
def test_validate_yaml():
    class Song(Schema):
        title = String()
        artist = String()

    class Playlist(Schema):
        name = String()
        songs = List(Song)

    content = """
        name: "My playlist"
        songs:
            - title: "Song 1"
              artist: "Artist 1"
            - title: "Song 2"
              artist: 123
    """

    value, error_messages = validate_yaml(content, validator=Playlist)

    assert len(error_messages) == 1
    # Ensure error message includes positional data.
    assert error_messages[0].text == "Valid type is 'str'."
    # Ensure error message includes content.
    assert error_messages[0].position.content == content

    # Ensure other parsing/validation still works.
    assert value.songs

# Generated at 2022-06-22 06:22:35.880160
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    pass


# Generated at 2022-06-22 06:22:47.478607
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        name: "Joe"
        age: 43
        is_married: true
        kids:
          - name: "Alice"
          - name: "Bob"
          - name: "Charlie"
            age: 3
        pets:
          - name: "Max"
            type: "dog"
    """)
    assert token == {
        "name": "Joe",
        "age": 43,
        "is_married": True,
        "kids": [
            {"name": "Alice"},
            {"name": "Bob"},
            {"name": "Charlie", "age": 3},
        ],
        "pets": [{"name": "Max", "type": "dog"}],
    }
    assert isinstance(token, DictToken)

# Generated at 2022-06-22 06:22:53.836393
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    integer: 10
    string: test string
    boolean: True
    """
    result = tokenize_yaml(content)
    assert type(result) == DictToken
    assert result.value == {'integer': 10, 'string': 'test string', 'boolean': True}
    assert result.start == 1
    assert result.end == len(content) - 1
    assert result.content == content



# Generated at 2022-06-22 06:23:03.172235
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(name="foo", type="string")
    # Test a simple YAML string
    value, messages = validate_yaml(
        content="foo: bar", validator=validator)
    assert value == {'foo': 'bar'}
    assert messages == []

    # Test a simple YAML string with mistyped key
    value, messages = validate_yaml(
        content="foo: 42", validator=validator)
    assert value == {'foo': 42}
    assert len(messages) == 1
    # Check the message text
    assert messages[0].text == "Value '42' is not of type 'string'."
    assert messages[0].position == Position(
        line_no=1, column_no=4, char_index=4)

# Generated at 2022-06-22 06:23:15.811587
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == {"": ""}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_yaml("foo: {bar: baz}\n") == {"foo": {"bar": "baz"}}
    assert tokenize_yaml("foo: {bar: baz}\nqux: quux") == {"foo": {"bar": "baz"}, "qux": "quux"}
    assert tokenize_yaml("42") == 42
    assert tokenize_yaml("-42") == -42
    assert tokenize_yaml("3.14") == 3.14
    assert tokenize_

# Generated at 2022-06-22 06:23:28.388838
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    - apples
    - oranges
    - pears
    """
    tokens = tokenize_yaml(content)
    assert tokens == ListToken(['apples', 'oranges', 'pears'], 0, 27, content=content)
    content = """
    apples:
      - red
      - green
      - golden
    oranges:
      - navel
      - valencia
      - blood
    """
    tokens = tokenize_yaml(content)
    assert tokens == DictToken({'apples': ['red', 'green', 'golden'], 'oranges': ['navel', 'valencia', 'blood']}, 0, 112, content=content)

# Generated at 2022-06-22 06:23:41.135626
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String, Schema

    class User(Schema):
        name = String()
        age = Integer()

    content = """
    name: Fred
    age: 52
    """
    value, error_messages = validate_yaml(content, validator=User)
    assert value == {"name": "Fred", "age": 52}
    assert error_messages == []

    content = """
    name: Fred
    age: fifty-two
    """
    value, error_messages = validate_yaml(content, validator=User)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be a valid integer."
    assert error_messages[0].position.char_index == 18

# Generated at 2022-06-22 06:23:53.070951
# Unit test for function validate_yaml
def test_validate_yaml():
    import copy
    import json

    import pytest

    from typesystem.exceptions import ValidationError
    from typesystem.fields import Array, Dict, Integer, Map, String

    class Product(Schema):
        code = String(max_length=10)
        price = Integer(minimum=0)
        in_stock = Integer(minimum=0, maximum=3)

    class Request(Schema):
        products = Array(
            items=Dict(
                map=Map(
                    code=String(max_length=10, min_length=4),
                    price=Integer(minimum=0),
                    quantity=Integer(minimum=1),
                )
            )
        )

    content = """{
        products: []
    }"""

    value, errors = validate_yaml(content, Request)

# Generated at 2022-06-22 06:24:01.889029
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Testing of no content
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml("")
        assert excinfo.match("No content.")

    # Testing with an empty dict
    token = tokenize_yaml("{}")
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == -1
    assert token.value == {}

    # Testing with an empty list
    token = tokenize_yaml("[]")
    assert isinstance(token, ListToken)
    assert token.start == 0
    assert token.end == -1
    assert token.value == []

    # Testing with a single string
    token = tokenize_yaml('"foo"')
    assert isinstance(token, ScalarToken)
    assert token.start == 0

# Generated at 2022-06-22 06:24:14.324599
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import (
        Array,
        Boolean,
        Integer,
        Object,
        String,
    )
    from typesystem.schemas import Schema

    class MySchema(Schema):
        code = String(max_length=10)
        description = String(max_length=100)
        optional_description = String(max_length=100, required=False)
        birthday = Integer(minimum=0)
        admin = Boolean()
        tags = Array(items=String(), max_items=3)
        friends = Array(items=Object({"name": String(), "age": Integer()}))


# Generated at 2022-06-22 06:24:24.658475
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("[]") == ListToken([], 0, 1)

    assert tokenize_yaml("1") == ScalarToken(1, 0, 0)
    assert tokenize_yaml("0") == ScalarToken(0, 0, 0)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3)

    with pytest.raises(ParseError):
        tokenize_yaml("")

# Generated at 2022-06-22 06:24:30.721754
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.base import Validator, validate, ValidationError
    from typesystem.fields import String
    from typesystem.schemas import Schema



# Generated at 2022-06-22 06:24:35.977058
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    result = tokenize_yaml("{'foo': 'bar', 'baz': 42}")
    assert isinstance(result, DictToken)



# Generated at 2022-06-22 06:24:47.220528
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test_data = {
        "key1": "value1",
        "key2": [
            True,
            False,
            None
        ],
        "key3": 12345,
        "key4": 12.345,
        "key5": [
            {"key1": "value1", "key2": "value2"},
            {"key1": "value1", "key2": "value2"},
        ],
        "key6": "value2",
    }

# Generated at 2022-06-22 06:24:56.463291
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_content = b'a: hello\nb: 2\nc: [3, 4,' + b'\n5]' + b'\n d: \n  - 6\n  - 7\n'
    yaml_token = tokenize_yaml(yaml_content)
    assert isinstance(yaml_token, DictToken)
    assert yaml_token.value == {
        'a': 'hello',
        'b': 2,
        'c': [3, 4, 5],
        'd': [6, 7]
    }
    assert yaml_token.start == 0
    assert yaml_token.end == 29



# Generated at 2022-06-22 06:24:59.417906
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('{"name":"bob"}', Schema({"name": String()})) == ({'name': 'bob'}, [])

# Generated at 2022-06-22 06:25:10.763793
# Unit test for function validate_yaml
def test_validate_yaml():
    schema=Schema(
    fields={
    "values":List(items=Dict(fields={
        "value":Number(),
        "timestamp":DateTime()
    }))
})

content = (
    "values:\n"
    "- {\n"
    "    value: 10,\n"
    "    timestamp: 2016-07-08T12:30:20Z\n"
    "  }\n"
    "- {\n"
    "    value: 20,\n"
    "    timestamp: 2016-07-08T13:30:20Z\n"
    "  }\n"
    "- {\n"
    "    value: 30,\n"
    "    timestamp: 2016-07-08T14:30:20Z\n"
    "  }\n"
)


# Generated at 2022-06-22 06:25:20.557605
# Unit test for function validate_yaml
def test_validate_yaml():
    valid_yaml_content = """
        title: test_title
        description: test description
        properties:
            contents:
                type: array
                items:
                    type: object
                    properties:
                        title:
                            type: string
                        description:
                            type: string
                        contents:
                            type: array
                            items:
                                type: object
                                properties:
                                    title:
                                        type: string
                                    description:
                                        type: string
    """

# Generated at 2022-06-22 06:25:32.946283
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = {
        "name": "book",
        "type": "object",
        "properties": {
            "title": {"type": "string", "min_length": 3},
            "price": {"type": "integer", "minimum": 1},
            "is_available": {"type": "boolean"},
            "authors": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
                    "required": ["name"],
                },
            },
        },
        "required": ["title"],
    }


# Generated at 2022-06-22 06:25:46.094848
# Unit test for function validate_yaml
def test_validate_yaml():

    class PointSchema(Schema):
        x = fields.Number(required=True)
        y = fields.Number(required=True)

    class PolygonSchema(Schema):
        points = fields.List(fields.Object(PointSchema), required=True)

    class ObjectSchema(Schema):
        polygon = fields.Object(PolygonSchema, required=True)

    content = """
    # A simple example.
    polygon:
      points:
      - x: 1
        y: 2
      - x: 2
        y: 3
      - x: 3
        y: 4
      - x: 4
        y: 5
    """
    value, error_messages = validate_yaml(content, ObjectSchema)
    # Test if the correct object is returned

# Generated at 2022-06-22 06:25:57.351549
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Case 1: Simple emptry YAML object
    content = yaml.dump({})
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.content == content
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.value == {}

    # Case 2: Simple YAML object
    content = yaml.dump({"foo": "bar"})
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.content == content
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.value == {"foo": "bar"}

    # Case 3: Simple empty YAML list
    content = yaml.dump([])


# Generated at 2022-06-22 06:26:06.429772
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    token = tokenize_yaml("""
    a:
      b: 12
    """)
    assert isinstance(token, DictToken)
    assert token.data == {
        "a": DictToken({'b': ScalarToken(12, 14, 15, content="\n    a:\n      b: 12\n    ")}, 6, 15, content="\n    a:\n      b: 12\n    ")
    }

    # Check for custom tokens
    token = tokenize_yaml("""
    a: Hello World
    """)
    assert isinstance(token, DictToken)

# Generated at 2022-06-22 06:26:19.982917
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {"title": String, "street-address": String}
    )
    value, error_messages = validate_yaml("title: small\nstreet-address: 1234", schema)
    assert error_messages == []
    assert value == {"title": "small", "street-address": "1234"}
    value, error_messages = validate_yaml("title: small", schema)
    assert len(error_messages) == 1
    assert error_messages[0] == Message("field is required", name="street-address", pointer="street-address")
    assert value == {"title": "small"}
    value, error_messages = validate_yaml("title: small\nstreet-address: small", schema)

# Generated at 2022-06-22 06:26:30.771173
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    first_name: Jane
    last_name: Smith
    pets:
    - dog
    - cat
    ages:
    - 2
    - 3
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.keys() == ["first_name", "last_name", "pets", "ages"]

    pets = token["pets"]
    assert isinstance(pets, ListToken)
    assert pets.value == ["dog", "cat"]

    first_pets = pets[0]
    assert isinstance(first_pets, ScalarToken)
    assert first_pets.value == "dog"

    first_name = token["first_name"]
    assert isinstance(first_name, ScalarToken)
    assert first_name

# Generated at 2022-06-22 06:26:38.063778
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("""
        - item1
        - item2
        - item3
    """) == [
        ScalarToken(value="item1", start=7, end=12, content="""
        - item1
        - item2
        - item3
    """),
        ScalarToken(value="item2", start=17, end=22, content="""
        - item1
        - item2
        - item3
    """),
        ScalarToken(value="item3", start=27, end=32, content="""
        - item1
        - item2
        - item3
    """),
    ]


# Generated at 2022-06-22 06:26:49.378310
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    test_dict_key:
        test_dict_key_2: test_dict_value_2
        test_dict_key_3:
            test_dict_key_4: test_dict_value_4
    test_list:
        - test_list_value_1
        - test_list_value_2
    """
    expected_dict_type = DictToken
    expected_dict_keys = ["test_dict_key", "test_list"]
    expected_dict_key_2_type = DictToken
    expected_dict_key_2_keys = ["test_dict_key_2", "test_dict_key_3"]
    expected_dict_key_2_value_2_type = ScalarToken

# Generated at 2022-06-22 06:26:59.785035
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: 1
    bar: a
    baz: 0.5
    """
    value, error_messages = validate_yaml(content, Schema)
    assert value == {'foo':1, 'bar': 'a', 'baz':0.5}
    assert len(error_messages) == 0

    _, error_messages = validate_yaml("", Schema)
    assert len(error_messages) > 0
    assert error_messages[0].code == 'no_content'
    assert error_messages[0].text == 'No content.'
    assert error_messages[0].position.char_index == 0



# Generated at 2022-06-22 06:27:11.865620
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    print("\n tokenize_yaml \n")
    str1 = "scalar: single line text"
    assert isinstance(tokenize_yaml(str1), DictToken)
    assert isinstance(tokenize_yaml(str1)["scalar"], ScalarToken)
    assert tokenize_yaml(str1)["scalar"]._value == "single line text"

    str2 = "scalar: |\n multi-line\n string"
    assert isinstance(tokenize_yaml(str2), DictToken)
    assert isinstance(tokenize_yaml(str2)["scalar"], ScalarToken)
    assert tokenize_yaml(str2)["scalar"]._value == "multi-line\n string"


# Generated at 2022-06-22 06:27:14.158312
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    foo: bar
    baz:
        - qux
        - quux
    '''

    class MySchema(Schema):
        foo = "string"
        baz = "list"

    v = validate_yaml(content, validator=MySchema)

    assert not isinstance(v, ValidationError)


# Generated at 2022-06-22 06:27:22.310883
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=128)
        age = Integer()

    
    person = Person()
    assert person.validate_yaml(b"name: John\nage: 21") == ([{"data": {"name": "John", "age": 21}}], [])
    assert person.validate_yaml(b"name: John") == (None, [{"position": {"column_no": 1, "char_index": 0, "line_no": 1}, "text": "Missing required value.", "code": "missing"}])



# Generated at 2022-06-22 06:27:33.794082
# Unit test for function validate_yaml
def test_validate_yaml():
    class IntegerSchema(Schema):
        age = Field(required=True, type="integer")
    class StringSchema(Schema):
        name = Field(required=True, type="string")
    class ListOfIntegerSchema(Schema):
        integers = Field(required=True, type="list", type_of="integer")
    class ListOfStringSchema(Schema):
        strings = Field(required=True, type="list", type_of="string")
    class ListOfListOfIntegerSchema(Schema):
        list_of_list_of_integers = Field(required=True, type="list", type_of="list")
    class ListOfDictSchema(Schema):
        list_of_dicts = Field(required=True, type="list", type_of="dict")

# Generated at 2022-06-22 06:27:46.189990
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # DictToken
    assert type(tokenize_yaml("{}")) == DictToken
    assert type(tokenize_yaml("{key: value}")) == DictToken
    assert type(tokenize_yaml("{key1: {key2: value2}}")) == DictToken

    # ListToken
    assert type(tokenize_yaml("[]")) == ListToken
    assert type(tokenize_yaml("[1, 2]")) == ListToken
    assert type(tokenize_yaml("[1, [2, 3]]")) == ListToken

    # ScalarToken
    assert type(tokenize_yaml("A string.")) == ScalarToken
    assert type(tokenize_yaml("1")) == ScalarToken
    assert type(tokenize_yaml("1.0")) == ScalarToken

# Generated at 2022-06-22 06:28:02.289944
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ScalarToken(None, 0, 0, "")
    assert tokenize_yaml("42") == ScalarToken(42, 0, 1, "42")
    assert tokenize_yaml("foo: 'bar'") == DictToken({"foo": "bar"}, 0, 8, "foo: 'bar'")
    assert tokenize_yaml("- 'foo'\n- 'bar'") == ListToken(["foo", "bar"], 0, 11, "- 'foo'\n- 'bar'")
    assert tokenize_yaml("[true, false, null]") == ListToken([True, False, None], 0, 19, "[true, false, null]")

# Generated at 2022-06-22 06:28:09.813498
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}
    assert tokenize_yaml("foo: 42") == {"foo": 42}
    assert tokenize_yaml("---\nfoo: bar") == {"foo": "bar"}
    assert tokenize_yaml("foo: bar\n...") == {"foo": "bar"}
    assert tokenize_yaml("foo:\n  - bar\n  - baz") == {"foo": ["bar", "baz"]}



# Generated at 2022-06-22 06:28:19.742505
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert (
        str(tokenize_yaml('{"name": "John", "address": {"city": "Boston"}}'))
        == "DictToken([('name', ScalarToken('John', 7, 11, content='{'name': 'John', 'address': {'city': 'Boston'}}')), ('address', DictToken([('city', ScalarToken('Boston', 28, 33, content='{'name': 'John', 'address': {'city': 'Boston'}}'))], 25, 33, content='{'name': 'John', 'address': {'city': 'Boston'}}'))], 1, 44, content='{'name': 'John', 'address': {'city': 'Boston'}}')"
    )

