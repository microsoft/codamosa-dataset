

# Generated at 2022-06-22 06:18:40.667857
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    class TestySchema(Schema):
        int_field = Field(type="integer")
    content = "int_field: A"
    error_messages = validate_yaml(content=content, validator=TestySchema)
    assert error_messages == [
        Message(
            text="Invalid integer.",
            code="type_error.integer",
            position=Position(column_no=12, line_no=1, char_index=11),
        )
    ]

# Generated at 2022-06-22 06:18:49.081494
# Unit test for function validate_yaml
def test_validate_yaml():
    # No content
    try:
        validate_yaml("", validator=Field(string))
    except ParseError as error:
        print(error.text)
        print("Position: line {}, column {}".format(error.position.line_no, error.position.column_no))

    # Badly formed list
    try:
        validate_yaml("[a,\n b]", validator=Field(list_of_strings))
    except ParseError as error:
        print(error.text)
        print("Position: line {}, column {}".format(error.position.line_no, error.position.column_no))

    # Badly formed dict

# Generated at 2022-06-22 06:18:59.132375
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml1 = """
# User configuration:
defaults:
  editor: vim
  env: foo
user:
  name: First Last
  email: foo@bar.com
    """
    yaml2 = """
# User configuration:
defaults:
      editor: vim
    """
    yaml3 = """
# User configuration:
defaults:
      editor: vim
user:
      name: First Last
      email: foo@bar.com
      active: true
      projects:
          - foo
          - bar
    """

    token1 = tokenize_yaml(yaml1)
    print(token1)
    token2 = tokenize_yaml(yaml2)
    print(token2)
    token3 = tokenize_yaml(yaml3)
    print(token3)

    assert token

# Generated at 2022-06-22 06:19:06.205583
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '{first_name: "John", last_name: "Doe", age: 18}'
    validator = get_user_schema()
    value, error_messages = validate_yaml(content, validator)

    assert len(error_messages) == 0, (
        "validate_yaml with valid content didn't have any error_messages"
    )
    assert len(value.keys()) == 3, (
        "validate_yaml with valid content didn't have all keys"
    )
    assert value["first_name"] == "John", (
        "validate_yaml with valid content didn't have correct first_name"
    )
    assert value["last_name"] == "Doe", (
        "validate_yaml with valid content didn't have correct last_name"
    )

# Generated at 2022-06-22 06:19:16.687313
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    first_name: Sam
    last_name: Smith
    address_line_1: 123 Main Street
    address_line_2: Apartment 123
    city: Austin
    state: TX
    zipcode: 12345
    phone_number: 123-456-7890
    '''

    validator = Schema([
        Field(name='first_name', validators=['min_length:2']),
        Field(name='last_name', validators=['min_length:2']),
    ])
    # content is valid.
    value, errors = validate_yaml(content, validator)
    assert (content == value)
    assert (errors == [])

    # content is invalid.
    content = '''
    first_name: Sam
    last_name: Smith
    '''

   

# Generated at 2022-06-22 06:19:25.768617
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""
        -
          foo: bar
          bar: bar
          bar: bar
        -
          foo: bar
          bar: bar
          bar: bar
    """
    validator = ListToken(
        [
            DictToken({"foo": ScalarToken(1, 0, 0), "bar": ScalarToken(1, 0, 0)}),
            DictToken({"foo": ScalarToken(1, 0, 0), "bar": ScalarToken(1, 0, 0)}),
        ],
        0,
        0,
    )
    value, errors = validate_yaml(content, validator)
    assert len(errors) == 4
    assert len(errors[0].messages) == 1

# Generated at 2022-06-22 06:19:27.209223
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("123", int) == (123, {})


# Generated at 2022-06-22 06:19:35.896175
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema


    class Person(Schema):
        name = String()

    content = Person.serialize({"name": "John Doe"})
    with open('/home/hongbo/Desktop/Work-On-Code/typesystem-tokenize/test_validate_yaml.txt', 'w') as f:
        f.write(content)
    value, error_messages = validate_yaml(content, Person)
    print('value', value)
    print('error_messages', error_messages)

# Generated at 2022-06-22 06:19:46.846194
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        field_a = "string"
        field_b = "integer"
        field_c = "boolean"

    content = """
    field_a: a
    field_b: 123
    field_c: true
    """

    value, errors = validate_yaml(content, TestSchema)

    assert value == {"field_a": "a", "field_b": 123, "field_c": True}
    assert errors == []

    content = """
    field_a: a
    field_c: false
    """

    value, errors = validate_yaml(content, TestSchema)

    assert value == {"field_a": "a"}
    assert len(errors) == 2
    assert errors[0].code == "required_field"
    assert errors[0].position

# Generated at 2022-06-22 06:19:50.144534
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "test-string"
    token = tokenize_yaml(content)
    assert token.content == content
    assert token.start == 0
    assert token.end == len(content)-1


# Generated at 2022-06-22 06:19:55.334033
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None


# Unit tests for the function validate_yaml

# Generated at 2022-06-22 06:19:59.258306
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem import fields
    from typesystem.tokenize.parse_errors import ParseError

# Generated at 2022-06-22 06:20:03.764573
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    data = '''
name:
  - John
  - Smith
age: 25
    '''

    assert isinstance(tokenize_yaml(data), DictToken)
    # assert tokenize_yaml(data) == {'name': ['John', 'Smith'], 'age': 25}

# Generated at 2022-06-22 06:20:11.804342
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(type="integer")
    content = b"123"
    value, error_messages = validate_yaml(content, field)
    assert value == 123
    assert not error_messages

    content = b"hello"
    value, error_messages = validate_yaml(content, field)
    assert value == "hello"
    assert len(error_messages) == 1
    error = error_messages[0]
    assert error.code == "type_error"
    assert error.position.column_no == 1

    content = b"hello\n123"
    value, error_messages = validate_yaml(content, field)
    assert value == "hello\n123"
    assert len(error_messages) == 2
    assert error_messages[0].position.line_no == 1

# Generated at 2022-06-22 06:20:20.991171
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test parses YAML and returns the resulting object and error messages
    
    # Test a valid schema
    result = validate_yaml(
    '''
    name: 'John Doe'
    age: 50
    height: 1.83
    is_admin: true
    email: jdoe123@gmail.com
    favorite_numbers:
      - 5
      - 8
      - 10
      - -5
      - 0
      - 0.0
    ''',
    Schema(
        {"name": str, "age": [int], "height": float, "is_admin": bool, "email": str, "favorite_numbers": [int]},
        required=True,
    )
)
    
    # Test the correctness of the returned value and error messages

# Generated at 2022-06-22 06:20:30.609109
# Unit test for function validate_yaml
def test_validate_yaml():
	from typesystem import String, Integer
	class User(Schema):
	    name = String(max_length=100)
	    age = Integer()

	(value_valid, error_messages_valid) = validate_yaml('''name: Josua
	age: 25''', validator=User)

	(value_invalid, error_messages_invalid) = validate_yaml('''name: Josua
	age: 25''', validator=Integer())

	assert value_valid == {'age': 25, 'name': 'Josua'}
	assert len(error_messages_valid) == 0
	assert value_invalid is None
	assert len(error_messages_invalid) == 1

# Generated at 2022-06-22 06:20:35.727153
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields

    class BookSchema(Schema):
        title = fields.String()
        year = fields.Integer()

    content = """
    title: A Clockwork Orange
    year: 1962
    """
    value, error_messages = validate_yaml(content, BookSchema)
    assert isinstance(value, dict)
    assert not error_messages



# Generated at 2022-06-22 06:20:39.754552
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
a:
  b: hello
  c: 1
'''
    validator = Schema(
        {
            "a": Schema({"b": str, "c": int})
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"a": {"b": "hello", "c": 1}}
    assert errors == []

# Generated at 2022-06-22 06:20:49.809261
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: 1
    b: true
    c:
      - 10
    """
    token = tokenize_yaml(content)
    assert type(token) == DictToken
    assert set(token.keys()) == {"a", "b", "c"}
    assert type(token["a"]) == ScalarToken
    assert token["a"].value == 1
    assert type(token["b"]) == ScalarToken
    assert token["b"].value == True
    assert type(token["c"]) == ListToken
    assert len(token["c"]) == 1
    assert type(token["c"][0]) == ScalarToken
    assert token["c"][0].value == 10


# Generated at 2022-06-22 06:21:01.158694
# Unit test for function validate_yaml
def test_validate_yaml():
    content = yaml.dump(
        {
            "simple_scalar": True,
            "simple_sequence": [1, 2, 3],
            "simple_mapping": {"a": 1, "b": 2},
        }
    )
    # Use a dummy field for the purpose of this test.
    class DummyField(Field):
        def deserialize(self, value, *args, **kwargs):
            return value
    class DummySchema(Schema):
        simple_scalar = DummyField()
        simple_sequence = DummyField(repeated=True)
        simple_mapping = DummyField(mapping=True)
    value, error_messages = validate_yaml(content, DummySchema)
    assert len(error_messages) == 0
    # Test that token positions

# Generated at 2022-06-22 06:21:06.200393
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        name = String(max_length=100)

    errors = validate_yaml(b"", UserSchema())
    assert errors == {"name": ["This field is required."]}



# Generated at 2022-06-22 06:21:18.144285
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(max_length=10)
        age = Integer()

    # Valid YAML
    value, errors = validate_yaml(
        b"name: Bob\nage: 42", validator=MySchema
    )
    assert value == {"name": "Bob", "age": 42}
    assert errors == []

    # Invalid YAML - expected a key
    value, errors = validate_yaml(
        b"name: Bob\n", validator=MySchema
    )
    assert value == {}
    assert len(errors) == 1
    assert type(errors[0]) == ParseError
    assert errors[0].code == "parse_error"
    assert errors

# Generated at 2022-06-22 06:21:30.940944
# Unit test for function validate_yaml
def test_validate_yaml():

    class User(Schema):
        """
        Used to test the validate function
        """

        class Meta:
            title = "User"

        username = fields.String()
        age = fields.Integer()

    field = fields.Dict({
        "id": fields.Integer(),
        "username": fields.String(),
        "age": fields.Integer()
    })

    # Raise errors if either the schema or the field is not defined
    assert raise_error_if(validate_yaml, "", "")

    # Test if validate returns the correct information when given a field
    assert validate_yaml("5", field) == (5, [])
    assert validate_yaml("5.0", field) == (5.0, [])

# Generated at 2022-06-22 06:21:34.346838
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(
        type="string"
    )
    yaml_str = "---\ntest"
    value, errors = validate_yaml(
        content=yaml_str,
        validator=validator
    )
    assert errors == []



# Generated at 2022-06-22 06:21:45.656975
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken([], 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("true") == ScalarToken("true", 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken("false", 0, 4, content="false")
    assert tokenize_yaml("") == ScalarToken("", 0, 0, content="")
    assert tokenize_yaml("12") == ScalarToken(12, 0, 1, content="12")
    assert tokenize_yaml("12.0") == ScalarToken(12.0, 0, 3, content="12.0")

# Generated at 2022-06-22 06:21:56.014712
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('number: "10"', "int") == (10, [])
    assert validate_yaml('number: "10"', "str") == ("10", [])
    assert validate_yaml('number: 10', "int") == (10, [])
    assert validate_yaml('number: 10', "str") == ("10", [])
    assert validate_yaml('number: 10.1', "float") == (10.1, [])
    assert validate_yaml('number: 10.1', "str") == ('10.1', [])
    assert validate_yaml('number: -10.1', "float") == (-10.1, [])
    assert validate_yaml('number: -10.1', "str") == ('-10.1', [])

# Generated at 2022-06-22 06:22:01.250078
# Unit test for function validate_yaml
def test_validate_yaml():
    input_yaml = """
    name: Bob
    age: 25
    """
    PersonSchema = Schema.define(name=Field(type="string"), age=Field(type='integer'))
    
    assert validate_yaml(input_yaml, PersonSchema) == ({'name': 'Bob', 'age': 25}, [])

    input_yaml = 3
    assert validate_yaml(input_yaml, PersonSchema)[1] == [Message(
            text='Value must be a dictionary.',
            code='type_error.mapping',
            pointer='',
            position=Position(column_no=1, line_no=1, char_index=0),
        )]

# Generated at 2022-06-22 06:22:13.126379
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("23") == 23
    assert tokenize_yaml('"Hello"') == "Hello"
    assert tokenize_yaml("Hello") == "Hello"
    assert tokenize_yaml("true") is True
    assert tokenize_yaml("false") is False
    assert tokenize_yaml("null") is None
    assert (
        tokenize_yaml('{"name": "John"}')
        == dict(name="John")
        == DictToken(dict(name="John"), 0, 13, content='{"name": "John"}')
    )
    assert tokenize_yaml("[1, 2]") == [1, 2]
    assert tokenize_yaml("0.4") == 0.4

# Generated at 2022-06-22 06:22:22.770061
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(
        """
    # This is a comment.
    name: James
    age: 32
    is_active: false
    foods:
      - {"id": 1}
      - {"id": 2}
    """
    )
    assert isinstance(token, dict)
    assert token.as_yaml() == {
        'name': 'James',
        'age': 32,
        'is_active': False,
        'foods': [
            {'id': 1},
            {'id': 2},
        ],
    }


# Generated at 2022-06-22 06:22:26.900887
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # print('hello')
    d1 = tokenize_yaml("123")
    d2 = tokenize_yaml("[1,2,3]")
    assert d1==123
    assert d2==[1,2,3]


# Generated at 2022-06-22 06:22:41.700637
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = String()

    # Test successful validation with a Schema class.
    data = b"name: Alice"
    value, error_messages = validate_yaml(data, validator=PersonSchema)

    assert value == {"name": "Alice"}
    assert error_messages == []

    # Test successful validation with a Field instance.
    data = b"name: Alice"
    value, error_messages = validate_yaml(data, validator=String())

    assert value == "Alice"
    assert error_messages == []

    # Test parse errors.
    data = b"name: Alice\nunknown_field: Foo"
    value, error_messages = validate_yaml(data, validator=PersonSchema)

    assert value is None

# Generated at 2022-06-22 06:22:50.472401
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test valid
    content = """
        countries:
          - name: UK
            tld: .uk
            id: 3
          - name: DE
            tld: .de
            id: 4
          - name: FR
            tld: .fr
            id: 6
          - name: US
            tld: .us
            id: 10
    """
    result = validate_yaml(
        content,
        validator=Schema(
            {"countries": Field(items={"name": Field(max_length=2), "tld": Field()})}
        ),
    )

    assert isinstance(result, dict)

# Generated at 2022-06-22 06:22:53.409486
# Unit test for function validate_yaml
def test_validate_yaml():
    test_yaml = """
    name: Badger
    age: 3
    """
    class Person(Schema):
        name = String(min_length=2, max_length=5)
        age = Integer()

    person, errors = validate_yaml(test_yaml, Person)
    assert errors is None

# Generated at 2022-06-22 06:23:03.007196
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    class User(Schema):
        username = String()

    class Comment(Schema):
        body = String()

    class Post(Schema):
        title = String()
        comments = List(of=Comment)

    class Site(Schema):
        name = String()
        users = List(of=User)
        posts = List(of=Post)

    validator = Site()


# Generated at 2022-06-22 06:23:06.168219
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import String

    field = String(min_length=2, max_length=2)
    value, errors = validate_yaml(content='', validator=field)
    assert value is None

# Generated at 2022-06-22 06:23:18.073881
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(
        """
    - a: b
      c: d
    - foo: 7
      bar: 8
"""
    )
    assert token.start == 0
    assert token.end == 49
    assert token.content == tokenize_yaml.fget.__doc__[10:]
    assert isinstance(token, ListToken)
    assert isinstance(token[0], DictToken)
    assert isinstance(token[0]["a"], ScalarToken)
    assert isinstance(token[0]["c"], ScalarToken)
    assert token[0]["a"].value == "b"
    assert token[0]["c"].value == "d"
    assert isinstance(token[1], DictToken)
    assert isinstance(token[1]["foo"], ScalarToken)

# Generated at 2022-06-22 06:23:29.071876
# Unit test for function validate_yaml
def test_validate_yaml():
    min_length = types.MinLength(1)
    max_length = types.MaxLength(10)
    ratio = types.Ratio(ratio=0.5)
    optional_ratio = types.Optional(ratio)
    included_in = types.IncludedIn(choices=[1, 2, 3])
    included_in_opt = types.Optional(included_in)

    # Field types test
    message = validate_yaml('"one"', min_length)
    assert isinstance(message, Message)
    assert message.success is True

    message = validate_yaml('"this is way too long"', max_length)
    assert message.success is False
    assert isinstance(message.errors, list)
    error = message.errors[0]
    assert error.code == 'max_length'
   

# Generated at 2022-06-22 06:23:33.542413
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('{"id": 1, "name": "Jim", "balance": 5000}')
    assert token == {'id': 1, 'name': 'Jim', 'balance': 5000}

# Generated at 2022-06-22 06:23:38.499944
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""[
        {"hello": "world"},
        {"goodbye": "world"}
    ]""")
    assert isinstance(token, ListToken)
    assert isinstance(token[0], DictToken)
    assert isinstance(token[1], DictToken)



# Generated at 2022-06-22 06:23:42.106927
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    test_key_1:
        test_key_2:
            test_key_3: string
    """)
    print(token)


test_tokenize_yaml()

# Generated at 2022-06-22 06:23:56.460299
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    level1:
        level2:
            level3: []
    """
    token = tokenize_yaml(content)
    assert token.index == {
        "level1": DictToken({"level2": DictToken({"level3": ListToken([])})}, 2, 39)
    }
    assert token.value == {
        "level1": {"level2": {"level3": []}}
    }
    assert token.content == content

    content = """
    level1:
        level2:
            level3: [1, 2]
    """
    token = tokenize_yaml(content)

# Generated at 2022-06-22 06:24:06.727878
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('- "a"\n- "b"\n- "c"\n') == ListToken(["a", "b", "c"], 0, 23)
    assert tokenize_yaml('a: "b"\nc: "d"\n') == DictToken({'a': "b", 'c': "d"}, 0, 15)
    assert tokenize_yaml('"a"\n') == ScalarToken("a", 0, 2)
    assert tokenize_yaml("a: 1") == DictToken({"a": 1}, 0, 4)
    assert tokenize_yaml("a: 1.2") == DictToken({"a": 1.2}, 0, 5)
    assert tokenize_yaml("a: true") == DictToken({"a": True}, 0, 7)

# Generated at 2022-06-22 06:24:17.164531
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    content = """
        root:
          fruits:
            - apple
            - banana
        """
    assert isinstance(tokenize_yaml(content), DictToken)

    content = """
        root:
          fruits:
            - apple
            - banana
        """
    assert isinstance(tokenize_yaml(content), DictToken)

    content = """
        root:
          fruits:
            - apple
            - banana
        """
    assert isinstance(tokenize_yaml(content), DictToken)

    content = """
        root:
          fruits:
            - apple
            - banana
        """
    assert isinstance(tokenize_yaml(content), DictToken)


# Generated at 2022-06-22 06:24:27.603770
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '{"hello": "world", "foo": "bar", "num": 10, "num1": 10.01}'
    token = tokenize_yaml(content)
    assert token.items[0].position == Position(line_no=1, column_no=2, char_index=1)
    assert token.items[1].position == Position(line_no=1, column_no=11, char_index=10)
    assert token.items[2].position == Position(line_no=1, column_no=22, char_index=21)
    assert token.items[3].position == Position(line_no=1, column_no=30, char_index=29)
    #error cases
    content = '{"hello": "world", "foo": "bar", "num": 10, '

# Generated at 2022-06-22 06:24:36.018543
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - foo
    - false
    - null
    - {}
    - []
    """
    validator = Field(type="array", items=Field(type="string"))
    value, errors = validate_yaml(content, validator)
    assert errors[0].token.value == "1"
    assert errors[1].token.value == "false"
    assert errors[2].token.value == "null"
    assert errors[3].token.value == "{}"
    assert errors[4].token.value == "[]"
    assert value == ["foo"]


# Generated at 2022-06-22 06:24:47.252678
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from pprint import pprint
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.token_utils import print_token_tree

    validator = Field(type="string")
    yaml_text = "A string"
    token = tokenize_yaml(yaml_text)
    token_errors = validate_with_positions(token=token, validator=validator)
    assert token_errors.error_messages == []
    assert isinstance(token, Token)
    print(print_token_tree(token))

    yaml_text = "{}"
    token = tokenize_yaml(yaml_text)
    token_errors = validate_with_positions(token=token, validator=validator)

# Generated at 2022-06-22 06:24:57.931023
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class TestField(Field):
        pass

    class TestSchema(Schema):
        test1 = TestField(description="Test 1")
        test2 = TestField(description="Test 2")

    content = "test2: 1\ntest1: 10\n"

    parsed_result, errors = validate_yaml(content, TestSchema)

    assert parsed_result == {"test2": 1, "test1": 10}
    assert "test2" in errors
    assert "test1" in errors
    assert errors["test2"].position.line_no == 1
    assert errors["test1"].position.line_no == 2

    content = "test2: 1\ntest2: 10\n"

    parsed_result, errors = validate_y

# Generated at 2022-06-22 06:25:02.666251
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
name: Foo
age: 20
"""
    
    class Person(Schema):
        name = String()
        age = Integer()
    
    schema = Person()
    assert validate_yaml(content, schema) == (
        {'name': 'Foo', 'age': 20}, []
    )

# Generated at 2022-06-22 06:25:05.471614
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."



# Generated at 2022-06-22 06:25:16.857395
# Unit test for function validate_yaml
def test_validate_yaml():
    class PlayerSchema(Schema):
        name = fields.String(max_length=50)
        age = fields.Integer(minimum=18, maximum=40)

    validator = PlayerSchema()
    content1 = 'name: John\nage: 14'
    value, error_messages = validate_yaml(content1, validator)
    assert error_messages[0].text == "'age' must be no less than 18."
    assert error_messages[0].position.char_index == 11

    content2 = 'name: John\nage: 50'
    value, error_messages = validate_yaml(content2, validator)
    assert error_messages[0].text == "'age' must be no greater than 40."
    assert error_messages[0].position.char_index == 11

    content

# Generated at 2022-06-22 06:25:31.339164
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = type('schema', (Schema,), {'string_field': Field()})
    value, error_messages = validate_yaml(
        b'---\nstring_field: "positive"', schema
    )
    assert value == {"string_field": "positive"}
    assert not error_messages
    value, error_messages = validate_yaml(
        b'---\nstring_field: ["negative"]', schema
    )
    assert value == None
    assert len(error_messages) == 1

# Generated at 2022-06-22 06:25:39.111442
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        foo: bar
        baz:
            - qux
    """

    token = tokenize_yaml(content)
    validator = Schema(
        {"foo": "string", "baz": ["string", "null"]}, strict_unknown_fields=True
    )
    result = validate_yaml(content, validator)
    assert result == ({'foo': 'bar', 'baz': ['qux']}, None)



# Generated at 2022-06-22 06:25:51.095811
# Unit test for function validate_yaml
def test_validate_yaml():
    """"""
    import yaml
    from sys import modules

    def validate_yaml(content: typing.Union[str, bytes], validator: typing.Union[Field, typing.Type[Schema]]) -> typing.Any:
        """"""
        assert yaml is not None, "'pyyaml' must be installed."

        token = tokenize_yaml(content)
        return validate_with_positions(token=token, validator=validator)
    
    # Assert that it works on a valid string
    assert validate_yaml('{}', Schema(fields={})) == ({}, [])

    # Assert that it works on an invalid string
    assert validate_yaml('{', Schema(fields={})) == ({}, [])

    # Assert that it works on an empty string
    assert validate_y

# Generated at 2022-06-22 06:26:02.908413
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import json
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(title="Name", max_length=100)
        age = String(title="Age", max_length=100)

    # Test empty YAML
    with pytest.raises(ParseError, match="No content."):
        tokenize_yaml("")

    # Test invalid YAML
    with pytest.raises(ParseError, match="expected '<document start>', but found '<block mapping start>'"):
        tokenize_yaml("---")

    # Test valid YAML
    yaml_string = """
        name: John Doe
        age: 30
    """
    token = tokenize_yaml(yaml_string)

    # Test

# Generated at 2022-06-22 06:26:14.969789
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()
        gender = String(choices=["male", "female"])

    content_without_error = """
        name: John
        age: 30
        gender: male
    """

    content_with_parse_error = """
      name: John
      age: "30"
      gender: male
    """

    content_with_validation_error = """
      name: John
      age: 30
      gender: unknown
    """
    # Validate with no error
    result = validate_yaml(content_without_error, MySchema)
    assert not result[1]

# Generated at 2022-06-22 06:26:20.211617
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(content = "- a") == [ScalarToken(value = 'a', start = 2, end = 2, content = '- a')]
    assert tokenize_yaml(content = "- 1") == [ScalarToken(value = 1, start = 2, end = 2, content = '- 1')]
    assert tokenize_yaml(content = "- 100") == [ScalarToken(value = 100, start = 2, end = 4, content = '- 100')]
    assert tokenize_yaml(content = "- 0.1") == [ScalarToken(value = 0.1, start = 2, end = 4, content = '- 0.1')]

# Generated at 2022-06-22 06:26:31.900792
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"foo": {"type": "string"}})
    from typesystem.types import String, Integer
    from typesystem.fields import Field

    content = "foo: bar"
    result = validate_yaml(content, schema)

    # Did we get a valid result for a valid schema
    assert len(result[1]) == 0

    # Did we get the type we expected
    assert isinstance(result[0], dict)
    assert isinstance(result[0]["foo"], str)

    # Did we get the value we expected
    assert result[0]["foo"] == "bar"

    # Did we get the right error message for the wrong schema
    content = "foo: bar"
    result = validate_yaml(content, String())
    assert isinstance(result[1], list)

# Generated at 2022-06-22 06:26:44.168091
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.validators import Array
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class MySchema(Schema):
        my_field = String(name="my_field")
        my_int = String(name="my_int", validators=[Array(size=2)])

    # Valid case
    value, error_messages = validate_yaml(
        """
        my_field: alice
        my_int:
          - 0
          - 1
        """,
        validator=MySchema,
    )

    assert error_messages == []
    assert value == {"my_field": "alice", "my_int": [0, 1]}

    # Invalid case

# Generated at 2022-06-22 06:26:53.945653
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
        foo:
          - 1
          - 2
          - 3
        bar:
          - True
          - False
          - 'foo'
        baz:
          - 1.0
          - 2.0
          - 3.0
        qux:
          - null
        quux:
          - 1
          - null
    '''
    value, messages = validate_yaml(content, validator=Field("test"))
    assert messages == []
    assert value == {
        "foo": [1, 2, 3],
        "bar": [True, False, "foo"],
        "baz": [1.0, 2.0, 3.0],
        "qux": [None],
        "quux": [1, None],
    }

    # Test a failure where the content is invalid JSON

# Generated at 2022-06-22 06:27:04.935475
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test the YAML functionality.
    """

    # Tests for the tokenize_yaml function.
    assert isinstance(tokenize_yaml(""), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml("1234"), ScalarToken)
    assert isinstance(tokenize_yaml("1234.5678"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("\"foo\""), ScalarToken)
    assert isinstance(tokenize_yaml("["), ListToken)
    assert isinstance(tokenize_yaml("[1,2]"), ListToken)
   

# Generated at 2022-06-22 06:27:12.193009
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Boolean

    class MySchema(Schema):
        name = String(max_length=5)
        value = Integer(maximum=10)

    errors = validate_yaml(
        yaml.dump(MySchema.from_dict({"name": "test", "value": 5}).value), MySchema
    )[1]
    assert len(errors) == 0

    errors = validate_yaml(
        yaml.dump(MySchema.from_dict({"name": "test", "value": 15}).value), MySchema
    )[1]
    error = errors[0]
    assert error.position.line_no == 2
    assert error.position.column_no == 8



# Generated at 2022-06-22 06:27:23.330812
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import fields
    from typesystem.schemas import Schema

    class Person(Schema):
        name = fields.String(min_length=1)
        age = fields.Integer()
    
    person, errors = validate_yaml(b"name: John Doe\nage: 22", Person)
    assert person == {"name": "John Doe", "age": 22}
    assert len(errors) == 0

    person, errors = validate_yaml(b"name: John Doe\nage: 22.5", Person)
    assert person == {"name": "John Doe", "age": 22}
    assert errors[0].code == "invalid_type"
    assert errors[0].text == "Field must be of type 'integer'."
    assert errors[0].position.line_no == 2



# Generated at 2022-06-22 06:27:33.755458
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("100") == 100
    assert tokenize_yaml("100.00") == 100.0
    assert tokenize_yaml("true") is True
    assert tokenize_yaml("null") is None
    assert tokenize_yaml("test") == "test"
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_yaml("{'a': 1, 'b': 2}") == {"a": 1, "b": 2}
    token = tokenize_yaml("{'a': 1, 'b': 2}")
    assert token.start == 0
    assert token.end == 17



# Generated at 2022-06-22 06:27:46.189182
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_str = """
    first_key: value1
    second_key: value2
    third_key:
        - value3
        - value4
    """
    tok = tokenize_yaml(yaml_str)
    assert isinstance(tok, DictToken)
    assert tok.value == {
        "first_key": "value1",
        "second_key": "value2",
        "third_key": ["value3", "value4"],
    }
    assert tok.start == 1
    assert tok.end == len(yaml_str) - 1

    assert tok.keys == ["first_key", "second_key", "third_key"]

    tok_second_key = tok[1]

# Generated at 2022-06-22 06:27:51.442060
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    {
      a: 1
    }
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.content == content

    content = """
    - kk
    - kk
    """
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert token.content == content



# Generated at 2022-06-22 06:27:56.121772
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = "string"

    validator = PersonSchema()

    value, errors = validate_yaml(
        content="""
            name: John
            """,
        validator=validator,
    )
    assert value is not None
    assert errors == []



# Generated at 2022-06-22 06:28:07.423330
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("hello: fish"), DictToken)
    assert isinstance(tokenize_yaml("- hello"), ListToken)
    assert isinstance(tokenize_yaml("hello"), ScalarToken)
    assert isinstance(tokenize_yaml("123"), ScalarToken)
    assert isinstance(tokenize_yaml("1.23"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml("1.0"), ScalarToken)
    assert isinstance(tokenize_yaml("- 1"), ListToken)

# Generated at 2022-06-22 06:28:14.024333
# Unit test for function validate_yaml
def test_validate_yaml():
    error_messages = validate_yaml('foo: 1', Field(name="foo", type="string"))
    assert len(error_messages) == 1
    error_message = error_messages[0]
    assert error_message.position.char_index == 0
    assert error_message.position.line_no == 1
    assert error_message.position.column_no == 1
    assert error_message.text == "'foo' must be of type 'string'."



# Generated at 2022-06-22 06:28:24.892727
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.tokens import Token
    from typesystem.types import String, Integer, Float, Boolean, Object

    assert tokenize_yaml("~") == ScalarToken(None, 0, 0)
    token = tokenize_yaml("foo:")
    assert isinstance(token, DictToken)
    assert token.keys() == ["foo"]
    assert token.values() == [None]
    assert token.start == 0
    assert token.end == 3
    assert tokenize_yaml("foo: bar") == DictToken({"foo": "bar"}, 0, 8)
    assert tokenize_yaml("foo: 1") == DictToken({"foo": 1}, 0, 5)
    assert tokenize_yaml