

# Generated at 2022-06-22 06:18:41.940332
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(
"""
name:
  first: Arthur
  last: Dent
age: 42
"""
    )
    assert isinstance(token, DictToken)
    assert token.value["name"] == {
        "first": "Arthur",
        "last": "Dent"
    }
    assert token.value["age"] == 42


# Generated at 2022-06-22 06:18:45.933924
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    
    s = '''
    {
    "name": "Alice",
    "age": 33,
    "height": 1.80
    }
    '''
    token = tokenize_yaml(s)
    assert token == {'name': 'Alice', 'age': 33, 'height': 1.8}
    

    
    

# Generated at 2022-06-22 06:18:51.617262
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed to use this function."
    content = """
    - foo
    - bar
    """
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert len(token.data) == 2
    assert isinstance(token.data[0], ScalarToken)
    assert token.data[0].data == "foo"



# Generated at 2022-06-22 06:19:01.210268
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('{"a": "hi"}') == {"a": "hi"}

# Generated at 2022-06-22 06:19:04.925463
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token=tokenize_yaml('{"foo": "1", "bar": "2"}')
    print(token)
    for key,i in token.value.items():
        print(key, i)


# Generated at 2022-06-22 06:19:15.726798
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert (tokenize_yaml("null")) == ScalarToken(value=None, start_index=0, end_index=3)
    assert (tokenize_yaml("1")) == ScalarToken(value=1, start_index=0, end_index=1)
    assert (tokenize_yaml('1.1')) == ScalarToken(value=1.1, start_index=0, end_index=3)
    assert (tokenize_yaml("true")) == ScalarToken(value=True, start_index=0, end_index=4)
    assert (tokenize_yaml("false")) == ScalarToken(value=False, start_index=0, end_index=5)

# Generated at 2022-06-22 06:19:25.570586
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class ObjectSchema(Schema):
        field = String()

    class ListSchema(Schema):
        items = ObjectSchema.field()

    # Success cases.
    assert validate_yaml("", String()) == (None, [])
    assert validate_yaml("field: value", ObjectSchema()) == ({"field": "value"}, [])
    assert (
        validate_yaml("- item1\n- item2", String().list(min_length=1))
        == (["item1", "item2"], [])
    )

# Generated at 2022-06-22 06:19:32.627904
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Primitive values
    assert tokenize_yaml("10") == ScalarToken(10, char_start=0, char_end=2, content="10")
    assert tokenize_yaml("10.5") == ScalarToken(
        10.5, char_start=0, char_end=4, content="10.5"
    )
    assert tokenize_yaml("true") == ScalarToken(
        True, char_start=0, char_end=4, content="true"
    )
    assert tokenize_yaml("false") == ScalarToken(
        False, char_start=0, char_end=5, content="false"
    )

# Generated at 2022-06-22 06:19:41.342469
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        person:
            name: Tobias
            age: 34
            addresses:
                - city: CPH
                    zip: 1424
                - city: Aarhus
                    zip: 8000
        """
    expected = {
        "person": {
            "name": "Tobias",
            "age": 34,
            "addresses": [
                {"city": "CPH", "zip": 1424},
                {"city": "Aarhus", "zip": 8000},
            ],
        }
    }
    res = tokenize_yaml(content)
    assert expected == res.value



# Generated at 2022-06-22 06:19:45.538526
# Unit test for function tokenize_yaml
def test_tokenize_yaml(): #type: ignore
    assert tokenize_yaml("") == None


# Generated at 2022-06-22 06:19:54.219485
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "{'decimal': 3.14, 'int': 3}\n"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.keys() == ['decimal', 'int']
    assert token.values() == [ScalarToken("3.14", 6, 9, content=content), ScalarToken("3", 16, 16, content=content)]


# Generated at 2022-06-22 06:20:04.245707
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        field = Field(required=True)

    content = "field: value\n"

    value, errors = validate_yaml(content, MySchema)
    print(value, errors)
    assert errors == []

    content = "  field: value\n"

    value, errors = validate_yaml(content, MySchema)
    print(value, errors)
    assert errors == []

    content = "field: value"

    value, errors = validate_yaml(content, MySchema)
    print(value, errors)
    assert errors == []

    content = "  field: value"

    value, errors = validate_yaml(content, MySchema)
    print(value, errors)
    assert errors == []

    class EmptySchema(Schema):
        pass



# Generated at 2022-06-22 06:20:07.217842
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = Field(type="string")
    value, errors = validate_yaml(b'{"name":"foo"}', MySchema)
    assert errors == []
    assert value == {'name': 'foo'}

# Generated at 2022-06-22 06:20:17.733352
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(b'') == None
    assert tokenize_yaml(b'a') == 'a'
    assert tokenize_yaml(b'---') == None
    assert tokenize_yaml(b'---\n') == None
    assert tokenize_yaml(b'---\nname:') == {'name': None}
    assert tokenize_yaml(b'---\nname: 1') == {'name': 1}
    assert tokenize_yaml(b'---\nname: 1\n') == {'name': 1}
    assert tokenize_yaml(b'---\nname: 1\n...\n') == {'name': 1}
    assert tokenize_yaml(b'---\nname: 1\n...') == {'name': 1}

# Generated at 2022-06-22 06:20:29.848795
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import fields
    from typesystem.schemas import Schema

    class ColorSchema(Schema):
        name = fields.String(max_length=10)
        hex = fields.String(max_length=7)

    class ColorCollection(Schema):
        colors = fields.List(fields.Schema("Color", ColorSchema))

    # Valid case
    value = validate_yaml(
        """
colors:
  - name: "Green"
    hex: "#00ff00"
  - name: "Red"
    hex: "#ff0000"
  - name: "Blue"
    hex: "#0000ff"
""",
        ColorCollection
    )[0]

# Generated at 2022-06-22 06:20:41.591890
# Unit test for function validate_yaml
def test_validate_yaml():
    # success
    content = textwrap.dedent(
        """
    first: "value"
    second: 5
    third:
        - key1: value1
        - key2: value2
        - key3: value3
    """
    )
    validator = Schema({"first": str, "second": int, "third": [{"key1": str}]})
    value, error_messages = validate_yaml(content, validator)
    assert not error_messages
    assert value == {
        "first": "value",
        "second": 5,
        "third": [{"key1": "value1"}, {"key2": "value2"}, {"key3": "value3"}],
    }

    # failure

# Generated at 2022-06-22 06:20:52.862581
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(b"foo: bar") == {"foo": "bar"}
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}
    assert tokenize_yaml('"foo": "bar"') == {"foo": "bar"}

    assert tokenize_yaml(b"foo: 123") == {"foo": 123}
    assert tokenize_yaml(b"foo: 123.45") == {"foo": 123.45}
    assert tokenize_yaml(b"foo: true") == {"foo": True}
    assert tokenize_yaml(b"foo: false") == {"foo": False}
    assert tokenize_yaml(b"foo: null") == {"foo": None}

    assert tokenize_yaml(b"- foo\n- bar") == ["foo", "bar"]

   

# Generated at 2022-06-22 06:21:03.498827
# Unit test for function validate_yaml
def test_validate_yaml():
    # test case1
    str_content = '''
    metric: AHS
    time: 2019-04-02T19:00:00Z
    values: [100, 0]
    '''

    class yaml_schema(Schema):
        metric = "string"
        time = "datetime"
        values = "list[int]"

    yaml_data, errors = validate_yaml(str_content, yaml_schema)
    assert yaml_data["metric"] == "AHS"

    # test case2
    class yaml_schema1(Schema):
        metric = "string"
        time = "list[int]"
        values = "string"

    yaml_data1, errors1 = validate_yaml(str_content, yaml_schema1)

# Generated at 2022-06-22 06:21:11.140594
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: myname\n"
    field = Field(type="integer", name="name")
    assert validate_yaml(content=content, validator=field) == (
        None,
        [
            (
                ValidationError(text="Must be an integer.", code="invalid_type"),
                Position(line_no=1, column_no=6, char_index=5),
            )
        ],
    )
    
    content = "[1, 2, 3]\n"
    field = Field(type="integer", name="name")

# Generated at 2022-06-22 06:21:16.027494
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    value = {
        "hello": ["world"],
        "another": True,
    }

    yaml_value = yaml.dump(value, default_flow_style=False)
    token = tokenize_yaml(yaml_value)
    assert token.value == value



# Generated at 2022-06-22 06:21:28.090293
# Unit test for function validate_yaml
def test_validate_yaml():
    import ast

    class TestSchema(Schema):
        def validate_schema_test(self,a):
            return a

    validator = TestSchema(schema_test=int,required={"schema_test":True})
    content = '''{"schema_test": 12}'''
    value = ast.literal_eval(content)
    error_messages = []
    assert validate_yaml(content,validator) == (value, error_messages)


# Generated at 2022-06-22 06:21:30.231631
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content='', validator=Field(type="string"))
    assert validate_yaml(content='"foo"', validator=Field(type="string"))

# Generated at 2022-06-22 06:21:40.385697
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    #basic
    assert isinstance(tokenize_yaml("---\nhello : bye")[0], DictToken)
    assert isinstance(tokenize_yaml("---\n- bye")[0], ListToken)
    assert isinstance(tokenize_yaml("---\n1")[0], ScalarToken)
    assert isinstance(tokenize_yaml("---\n1.1")[0], ScalarToken)
    assert isinstance(tokenize_yaml("---\ntrue")[0], ScalarToken)
    assert isinstance(tokenize_yaml("---\n- hello")[0], ListToken)
    assert isinstance(tokenize_yaml("---\n-\n - hello")[0], ListToken)

# Generated at 2022-06-22 06:21:50.254269
# Unit test for function validate_yaml
def test_validate_yaml():
    # Since we want to test the error messages, use __main__.Field
    from typesystem.main import Field
    from typesystem.error_messages import Message
    from typesystem.tokenize.positional_validation import ValidationError

    field = Field(type="string", min_length=3, max_length=10)

    content = "this-is-too-short\nthis-is-the-correct-length\n"
    expected = Message(
        text="Shorter than minimum length.",
        code="min_length",
        position=Position(
            line_no=1,
            column_no=1,
            char_index=0,
        ),
    )
    actual = validate_yaml(content=content, validator=field)
    assert ValidationError(expected) == actual


# Generated at 2022-06-22 06:21:59.480991
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type="string")
    value, messages = validate_yaml(content="string", validator=validator)
    assert value == "string"
    assert messages == []

    value, messages = validate_yaml(content=123, validator=validator)
    assert messages == [
        Message(
            text="Expected a string.",
            code="type_error.string",
            position=Position(
                line_no=1, column_no=1, char_index=0),
        ),
    ]

    value, messages = validate_yaml(content="123", validator=validator)
    assert messages == []

    value, messages = validate_yaml(content=True, validator=validator)

# Generated at 2022-06-22 06:22:03.020670
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    root = tokenize_yaml("""
- a: 1
- b: 2
""")
    assert root == DictToken({"a": 1, "b": 2}, 0, 18)



# Generated at 2022-06-22 06:22:14.465548
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(required=True)
        age = Integer()

    content = b"name: Rajesh\nage: 20"
    value, errors = validate_yaml(
        content=content, validator=Person
    )  # type: ignore
    print(errors)
    assert value == {"name": "Rajesh", "age": 20}
    assert len(errors) == 0
    # Non-existent data
    content = b"name: Rajes"
    value, errors = validate_yaml(
        content=content, validator=Person
    )  # type: ignore
    assert len(errors) == 1
    assert errors[0].code == "not_in_schema"
    # Missing data
    content = b"age: 10"
    value, errors = validate_yaml

# Generated at 2022-06-22 06:22:26.564879
# Unit test for function validate_yaml
def test_validate_yaml():
    import sys
    import os
    import pytest

    from typesystem.base import Message, ParseError, Position, ValidationError

    from typesystem.fields import Field, String

    from typesystem.schemas import Schema

    from typesystem.tokenize.positional_validation import validate_with_positions

    def validate_yaml(
        content: str,
        validator: typing.Union[Field, typing.Type[Schema]],
    ) -> typing.Any:
        return validate_with_positions(
            token=tokenize_yaml(content), validator=validator
        )

    def validate_simple_yaml(content: str) -> typing.Any:
        return validate_yaml(content, Field(name="text", type_="string"))


# Generated at 2022-06-22 06:22:36.503810
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    assert yaml is not None, "'pyyaml' must be installed."

    if isinstance(content, bytes):
        str_content = content.decode("utf-8", "ignore")
    else:
        str_content = content

    if not str_content.strip():
        # Handle the empty string case explicitly for clear error messaging.
        position = Position(column_no=1, line_no=1, char_index=0)
        raise ParseError(text="No content.", code="no_content", position=position)

    class CustomSafeLoader(SafeLoader):
        pass

    def construct_mapping(loader: "yaml.Loader", node: "yaml.Node") -> DictToken:
        start = node.start_mark.index
        end = node.end_mark.index
        mapping = loader.construct_m

# Generated at 2022-06-22 06:22:39.703249
# Unit test for function validate_yaml
def test_validate_yaml():
    validation_results = validate_yaml(
        "Name: Anthony",
        Schema({"Name": fields.String}),
    )
    expected = (
        {"Name": "Anthony"},
        [],
    )
    assert validation_results == expected

# Generated at 2022-06-22 06:22:44.395834
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("- 1", Field(types=[int])) == (
        [1],
        [],
    )

# Generated at 2022-06-22 06:22:53.566956
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    user:
      name: "John Doe"
      email:
      - john@example.com
      - john.doe@example.com
    """
    
    class User(Schema):
        name = typesystem.String(max_length=100)
        email = typesystem.Array(items=typesystem.Email(), min_items=1)
    
    user, errors = validate_yaml(content, validator=User)
    print(user)
    # {'name': 'John Doe', 'email': ['john@example.com', 'john.doe@example.com']}
    print(errors)
    # []


# Generated at 2022-06-22 06:23:02.179404
# Unit test for function validate_yaml
def test_validate_yaml():
    # test for a field
    field = Field(typ="string")
    (value, error_messages) = validate_yaml(b'foo: "bar"', field)
    assert error_messages == [Message(code="expected_type", text="Expected a string.", position=Position(char_index=5, column_no=6, line_no=1))]

    # test for a schema
    class MySchema(Schema):
        foo = Field(typ="string")
        
    (value, error_messages) = validate_yaml(b'foo: "bar"', MySchema)
    assert error_messages == []
    assert value == {"foo": "bar"}



# Generated at 2022-06-22 06:23:14.868927
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        foo = String()

    token = tokenize_yaml(
        """
        foo: hello
        """
    )

    assert isinstance(token, DictToken)
    assert token.startpos == 1
    assert token.endpos == 32
    assert token.content.strip() == "foo: hello"

    assert isinstance(token.value, dict)
    assert token.value == {"foo": "hello"}

    value, errors = validate_yaml(
        """
        foo: hello
        """,
        validator=MySchema,
    )
    assert value == {"foo": "hello"}
    assert not errors


# Generated at 2022-06-22 06:23:21.241374
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test for empty string
    try:
        tokenize_yaml("")
    except ParseError as e:
        print(e)

    # Test for incorrect YAML string
    # TEST IS COMMENTED OUT BECAUSE OF API CHANGES IN PYYAML
    # try:
    #     tokenize_yaml("{{}")
    # except ParseError as e:
    #     print(e)

    string = """
    # Comments in YAML look like this.
    name: David
    age: 42
    wife:
        name: Donna
        age: 39
    kids:
        - name: Anna
          age: 10
        - name: Grace
          age: 7
        - name: Lucy
          age: 4
    """

    token_tree = tokenize_yaml(string)
   

# Generated at 2022-06-22 06:23:30.235580
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test scalar values
    test_case1 = tokenize_yaml("""test: aaa""")
    assert test_case1.get("test") == "aaa"
    test_case2 = tokenize_yaml("""test: 123""")
    assert test_case2.get("test") == 123
    test_case3 = tokenize_yaml("""test: 1.23""")
    assert test_case3.get("test") == 1.23
    test_case4 = tokenize_yaml("""test: null""")
    assert test_case4.get("test") is None
    test_case5 = tokenize_yaml("""test: true""")
    assert test_case5.get("test") == True
    test_case6 = tokenize_yaml("""test: false""")
   

# Generated at 2022-06-22 06:23:36.867718
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import Integer, String

    class Person(Schema):
        age = Integer(minimum=0, maximum=130)
        name = String(pattern=r"\w+ \w+")

    payload = """
    age: "32"
    name: "Herman Munster"
    """

    value, errors = validate_yaml(content=payload, validator=Person)
    assert errors[0].text == "Must be a valid integer."

# Generated at 2022-06-22 06:23:40.383525
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content=b'name: John\nage: 35\n', validator=PersonSchema) == (
        {'name': 'John', 'age': 35},
        [],
    )

# Generated at 2022-06-22 06:23:48.819661
# Unit test for function validate_yaml
def test_validate_yaml():

    class ExampleSchema(Schema):
        name = Field(str)
        age = Field(int)
        sport = Field([str])
        votes = Field(int)

    yaml_str = '''
    name: Brian
    age: 25
    sport:
      - soccer
      - tennis
      - basketball
    '''

    assert_equal(validate_yaml(yaml_str, ExampleSchema), ({'name': 'Brian', 'age': 25, 'sport': ['soccer', 'tennis', 'basketball']}, []))



# Generated at 2022-06-22 06:23:51.785641
# Unit test for function validate_yaml
def test_validate_yaml():
    val_result = validate_yaml('{"name": "test"}', Schema)
    assert isinstance(val_result, tuple)
    assert isinstance(val_result[0], dict)

# Generated at 2022-06-22 06:24:05.426083
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String

    field = String()

    value, messages = validate_yaml("test", field)

    assert value == "test"
    assert not messages

    value, messages = validate_yaml("", field)

    assert value == ""
    assert not messages

    value, messages = validate_yaml("[1, 2, 3]", field)

    assert value == "[1, 2, 3]"
    assert len(messages) == 1
    code, message, position = messages[0]
    assert code == "invalid"
    assert "expected a string" in message.lower()
    assert position.line_no == 1
    assert position.column_no == 1
    assert position.char_index == 0


# Generated at 2022-06-22 06:24:16.683956
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(
        """
        a: val
        b:
          - 1
          - 2
        c:
          - sub1: 4
            sub2: 2
          - sub3: 5
            sub4: 3
        d: {e: val, f: val}
        """
    )

    assert type(token) is DictToken

# Generated at 2022-06-22 06:24:26.263921
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema("test_validate_yaml", {"name": str, "age": int})
    # test valid input
    value, error = validate_yaml("name: Tom\nage: 12", schema)
    assert value == {"name":"Tom","age":12} and error == []
    # test with invalid input
    value, error = validate_yaml("name: Tom\nage: 12abc", schema)
    assert value == None and error == [Message(
        text="String '12abc' could not be parsed as int.", code="cast",
        position=Position(column_no=15, line_no=2, char_index=18),
        path=["age"], type="int",
    )]

# Generated at 2022-06-22 06:24:33.557770
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
---
name: cat
meaning: A real life character.
hobbies:
  - sleeping
  - eating
"""
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {
        "name": "cat",
        "meaning": "A real life character.",
        "hobbies": ["sleeping", "eating"],
    }



# Generated at 2022-06-22 06:24:45.532948
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.base import DictToken, ListToken, ScalarToken

    content = "hello"
    token = tokenize_yaml(content)
    assert token == ScalarToken("hello", 0, 4, content=content)

    content = "string: hello"
    token = tokenize_yaml(content)
    assert token == DictToken({"string": "hello"}, 0, 12, content=content)

    content = "list: [world, test, hello]"
    token = tokenize_yaml(content)
    assert token == DictToken(
        {"list": ["world", "test", "hello"]}, 0, 26, content=content
    )

    content = "list: [world, test, hello]\nhaha"
    token = tokenize_yaml(content)
    assert token == D

# Generated at 2022-06-22 06:24:54.183730
# Unit test for function tokenize_yaml
def test_tokenize_yaml(): # pragma: no cover
    assert tokenize_yaml("") == None
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("hello") == "hello"
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}
    assert tokenize_yaml("false: null") == {"false": None}
    assert tokenize_yaml("- foo") == ["foo"]
    assert tokenize_yaml("- 3.14") == [3.14]
    assert tokenize_yaml("- true") == [True]

# Generated at 2022-06-22 06:24:57.237593
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('a: 1', 'a') == ('a: 1', None)



# Generated at 2022-06-22 06:25:08.812671
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
	yaml_string = """
		name: John
		age: 42
		friends:
			- Rob
			- Jen
			- Bob
	"""
	token = tokenize_yaml(yaml_string)
	assert isinstance(token, DictToken)
	assert token == {
		'name': 'John',
		'age': 42,
		'friends': [
			'Rob',
			'Jen',
			'Bob'
		]
	}
	assert token.start == 0
	assert token.end == len(yaml_string) - 1

# Generated at 2022-06-22 06:25:18.574867
# Unit test for function validate_yaml
def test_validate_yaml():
    class Address(Schema):
        building_number = Field(str)
        # street_name = Field(str)
        postal_code = Field(str)

    content = dedent(
        """\
        building_number: 789
        street_name:  Fake Street
        postal_code: 12345
    """
    )
    value, error_messages = validate_yaml(content, Address)
    assert len(error_messages) == 0
    assert value["building_number"] == "789"
    assert value["street_name"] == "Fake Street"
    assert value["postal_code"] == "12345"

    content = dedent(
        """\
        building_number: 789
        street_name:  Fake Street
        postal_code: invalid
    """
    )
    value, error_

# Generated at 2022-06-22 06:25:30.276338
# Unit test for function validate_yaml
def test_validate_yaml():
    """ Test validate_yaml function. """

    # Correct input
    # Test with positive integer, integer, float, boolean, and string
    schema = {"integer": int, "float": float, "string": str}
    content = "integer: 1\nfloat: 1.0\nstring: 'One'\n"
    (value, error_messages) = validate_yaml(content, schema)
    assert error_messages == {}
    assert value == {"integer": 1, "float": 1.0, "string": "One"}

    # Incorrect input
    # Test for incorrect integer, float, boolean, and string
    schema = {"integer": int, "float": float, "string": str}
    content = "integer: 1.0\nfloat: One\nstring: 0\n"
    (value, error_messages)

# Generated at 2022-06-22 06:25:40.861320
# Unit test for function validate_yaml
def test_validate_yaml():
    import io
    import json
    from typesystem.string import String
    s = io.StringIO('''
        a: hello
        b: 1
    ''')
    schema = {
        'a': String,
        'b': String
    }
    value, err = validate_yaml(s, schema)
    assert err is not None
    assert len(err) == 1
    assert value['a'] == 'hello'
    assert value['b'] == '1'


# Generated at 2022-06-22 06:25:52.021056
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    a = open("test/sample.yaml").read()
    token1 = tokenize_yaml(a)
    b = open("test/config.yaml").read()
    token2 = tokenize_yaml(b)
    c = open("test/yaml_1.yaml").read()
    token3 = tokenize_yaml(c)
    d = open("test/yaml_2.yaml").read()
    token4 = tokenize_yaml(d)
    assert token1.child_tokens['Author'] == token2.child_tokens['author']
    assert token1.child_tokens['Name'] == token2.child_tokens['name']
    assert token1.child_tokens['Base Directory'] == token2.child_tokens['root']

# Generated at 2022-06-22 06:26:03.976288
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == DictToken({}, 0, 0, content="")
    assert tokenize_yaml("{}") == DictToken({}, 0, 0, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 0, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.1") == ScalarToken(1.1, 0, 0, content="1.1")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 0, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 0, content="false")

# Generated at 2022-06-22 06:26:05.465679
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == {}


# Generated at 2022-06-22 06:26:17.115281
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    This test shows the error message produced when the YAML content is not in a parseable format.
    """
    # Confirm the YAML content is invalid by inspecting the error message produced

# Generated at 2022-06-22 06:26:28.425296
# Unit test for function validate_yaml
def test_validate_yaml():
    # I would have liked to put this into a tests/ directory but was
    # unable to get pytest to work with a package that contains a
    # tests/ directory.
    assert yaml is not None, "'pyyaml' must be installed."

    # Simple field validation
    validator = Field(type="string")
    (
        value,
        messages,
    ) = validate_yaml(b"test", validator)  # type: ignore # yaml is 'None' in type check
    assert value == "test"
    assert not messages
    (value, messages) = validate_yaml(b"1", validator)
    assert value is None

# Generated at 2022-06-22 06:26:40.052647
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "foo: 1"
    validator = Schema(fields={"foo": Field(required=True)})
    value = validate_yaml(content, validator)
    assert len(value[1]) == 0  # noqa

    content = "foo: null"
    validator = Schema(fields={"foo": Field(required=True)})
    value = validate_yaml(content, validator)
    assert len(value[1]) == 0  # noqa

    content = "foo: null"
    validator = Schema(fields={"foo": Field(required=True, allow_null=False)})
    value = validate_yaml(content, validator)
    assert len(value[1]) == 1  # noqa



# Generated at 2022-06-22 06:26:45.061843
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import yaml
    from yaml.loader import SafeLoader
    assert SafeLoader is not None
    s = """
    a: 1
    b: true
    c: null
    d: 3.2
    """
    token = tokenize_yaml(s)
    assert yaml.dump(token) == yaml.dump(yaml.load(s, SafeLoader))

# Generated at 2022-06-22 06:26:56.498552
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.validators import MinLength
    from copy import copy
    # Empty string
    content = ''
    with pytest.raises(ParseError) as pe:
        tokenize_yaml(content)
    assert str(pe.value) == 'No content.'
    assert pe.value.position.line_no == 1
    assert pe.value.position.column_no == 1
    # Valid YAML
    content = '''
    foo: bar
    '''
    token = tokenize_yaml(content)
    assert token == {'foo': 'bar'}
    assert token.start_index == 0
    assert token.end_index == 12
    # Content without leading whitespace
    content = 'foo: bar'

# Generated at 2022-06-22 06:26:59.887419
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"title: Example"
    validator = Schema()
    token = tokenize_yaml(content)

    assert(validate_yaml(content,validator))

# Generated at 2022-06-22 06:27:14.429376
# Unit test for function validate_yaml
def test_validate_yaml():
    import pytest

    with pytest.raises(ValidationError) as exc_info:
        validate_yaml('{"foo": "bar", "baz": [1, 2, 3]}', Schema)

    exc = exc_info.value
    messages = [message.to_dict() for message in exc.messages]
    assert messages == [{
        'code': 'missing_field',
        'text': 'Required field does not exist.',
        'field': 'type',
        'position': {
            'column_no': 2,
            'char_index': 1,
            'line_no': 1
        },
    }]

    with pytest.raises(ParseError) as exc_info:
        validate_yaml('', Schema)

    exc = exc_info.value
    assert exc.position

# Generated at 2022-06-22 06:27:26.260965
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), DictToken)
    assert tokenize_yaml("") == {}
    assert isinstance(tokenize_yaml('one: 1'), DictToken)
    assert tokenize_yaml('one: 1') == {"one" : 1}
    assert isinstance(tokenize_yaml("""
        one: 1
        two: 2
    """), DictToken)
    assert tokenize_yaml("""
        one: 1
        two: 2
    """) == {"one" : 1, "two" : 2}
    assert isinstance(tokenize_yaml("[1, 2, 3]"), ListToken)
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]

# Generated at 2022-06-22 06:27:35.878560
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = str

    token, error_messages = validate_yaml(b"foo: 'bar'", validator=MySchema)

    assert token["foo"] == "bar"
    assert len(error_messages) == 0

    token, error_messages = validate_yaml(b"foo: 2.62", validator=MySchema)

    assert token["foo"] == "2.62" # NOTE: YAML is implicitly converted to str
    assert len(error_messages) == 0

    token, error_messages = validate_yaml(b"foo: [1, 2, 3]", validator=MySchema)

    assert token["foo"] == ["1", "2", "3"] # NOTE: YAML is implicitly converted to str

# Generated at 2022-06-22 06:27:44.945055
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, List, Dict, Any

    schema = Dict({
        "name": String(),
        "age": Integer(null=True),
        "score": Float(null=True),
        "notes": List(String(), default=[], null=True),
        "hobbies": Dict(Any()),
        "children": List(Dict({
            "name": String(),
            "age": Integer(),
        })),
    })
    data = u"""\
name: Bob
age: 42
score: 3.1415
notes:
  - 'Hello, world!'
  - 'Goodbye, world!'
hobbies: { bowling: true, golf: false }
children:
  - name: Alice
    age: 10
  - name: Charlie
    age: 7
"""


# Generated at 2022-06-22 06:27:55.305031
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.tokens import ListToken, DictToken, ScalarToken

    content = "a: 1\n"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1}

    content = "a: 1\n  b: 2\n"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1}

    content = "- 1\n- 2\n"
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert token.value == [1, 2]

    content = "1\n"
    token = tokenize_yaml(content)

# Generated at 2022-06-22 06:28:06.568201
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.exceptions import ParseError
    from typesystem.tokenize.tokens import DictToken, ScalarToken
    from typesystem.tokenize.tokens import ListToken, Token, is_dict_token
    from typesystem.tokenize.tokens import is_list_token, is_scalar_token
    import pytest

    expected = Token(
        start=0, end=13, content="start: foo\nend: bar"
    )
    assert tokenize_yaml("start: foo\nend: bar") == expected

    expected = Token(start=0, end=6, content="null:")
    assert tokenize_yaml("null:") == expected

    # This is not a valid YAML structure
    with pytest.raises(ParseError) as exc:
        token

# Generated at 2022-06-22 06:28:12.345630
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)

    content = b"""
    name: Noam Chomsky
    """
    token = tokenize_yaml(content)
    assert token.yaml() == content
    value, error = validate_yaml(content, validator=Person())
    assert error is None
    assert value == {"name": "Noam Chomsky"}


# Generated at 2022-06-22 06:28:23.418286
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), ScalarToken)
    assert isinstance(tokenize_yaml("- a"), ListToken)
    assert isinstance(tokenize_yaml("{a : 1}"), DictToken)
    assert isinstance(tokenize_yaml("a: 1"), DictToken)
    assert isinstance(tokenize_yaml("[{a : 1}]"), ListToken)

assert isinstance(tokenize_yaml(""), ScalarToken)
assert isinstance(tokenize_yaml("- a"), ListToken)
assert isinstance(tokenize_yaml("{a : 1}"), DictToken)
assert isinstance(tokenize_yaml("a: 1"), DictToken)
assert isinstance(tokenize_yaml("[{a : 1}]"), ListToken)
