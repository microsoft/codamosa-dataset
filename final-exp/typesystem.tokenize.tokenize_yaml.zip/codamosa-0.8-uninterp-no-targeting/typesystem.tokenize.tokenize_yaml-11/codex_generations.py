

# Generated at 2022-06-22 06:18:40.958845
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
    - name: Bloggs, Joe
      points: 12
      time: 21:45
    - name: Smith, Jane
      points: 21
      time: 11:56
    '''
    token = tokenize_yaml(content)
    assert token == [
        {
            "name": "Bloggs, Joe",
            "points": 12,
            "time": "21:45",
        },
        {
            "name": "Smith, Jane",
            "points": 21,
            "time": "11:56",
        },
    ]
    # Empty content test
    content = ''
    with pytest.raises(ParseError):
        tokenize_yaml(content)

    # Invalid content test.

# Generated at 2022-06-22 06:18:49.439285
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.base import Context
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class CustomerSchema(Schema):
        name = String(required=True)

    errors = validate_yaml("", validator=CustomerSchema)[1]

    assert errors[0].text == "No content."
    assert errors[0].position.column_no == 1
    assert errors[0].position.line_no == 1

    token, errors = validate_yaml("name: Daphne", validator=CustomerSchema)

    assert token.name == "Daphne"
    assert errors == []

    token, errors = validate_yaml("{}", validator=CustomerSchema)

    assert errors[0].text == "The 'name' field is required."

# Generated at 2022-06-22 06:18:59.347953
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "color: red"
    str_1 = "color: red\n"
    str_2 = "color: red[1]"
    str_3 = ""
    str_4 = "color: [red, green]"
    str_5 = 'color: [red, green,"blue"]'
    str_6 = "color: {red: \"red\", green: \"green\", blue: \"blue\"}"
    str_7 = "red"
    str_8 = "[1, 2, 3]"
    str_9 = "[1, 2, 3,]"
    str_10 = '- 1\n- 2\n- 3\n'
    str_11 = "[1, 2, 3]"
    str_12 = '{"red": "red", "green": "green", "blue": "blue"}'
    str_

# Generated at 2022-06-22 06:19:11.012678
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String

    class User(Schema):
        name = String(max_length=20)
        age = Integer(minimum=0, maximum=100)

    content = """
    name: Alex
    age: 19
    """

    result = validate_yaml(content, User)
    assert result[0].age == 19
    assert result[1] == []

    content = """
    name: Alex
    age: -12
    """

    result = validate_yaml(content, User)
    assert result[0].age == -12
    assert result[1] == [
        Message(
            text="Must be greater than or equal to 0.",
            code="minimum",
            position=Position(line_no=3, column_no=4, char_index=14),
        )
    ]

# Generated at 2022-06-22 06:19:22.558151
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        - 1
        - 2.0
        - 3
        - 4.0
    """
    validator = typing.List[typing.Union[int, float]]
    result = validate_yaml(content, validator)
    assert result == ([1, 2.0, 3, 4.0], [])
    content = """
        - 1
        - 2.0
        - "3"
        - 4.0
    """
    result = validate_yaml(content, validator)
    assert result[0] == [1, 2.0, "3", 4.0]
    assert result[1]
    assert (
        result[1][0].text
        == 'Unexpected value of type "str" for list item at index "2".'
    )

# Generated at 2022-06-22 06:19:33.843663
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        data = {"a": 1, "b": 2, "c": 3}

        def configure(self, *args, **kwargs):
            self.fields = {"a": Field(int), "b": Field(int), "c": Field(int)}
            super().configure(*args, **kwargs)

    yaml = """
    a: 1
    b: 2
    c: 3
    """
    # test succeeded
    (valid, errors) = validate_yaml(content=yaml, validator=TestSchema)
    assert isinstance(valid, DictToken)
    assert isinstance(errors, list)
    assert len(errors) == 0

    # test failed: type error

# Generated at 2022-06-22 06:19:44.969516
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test for parse errors.
    for content in ["{broken}", "{[broken]}", "{garbage: /}"]:
        with pytest.raises(ParseError):
            validate_yaml(content=content, validator=str)

    # Test for validation errors.
    for content, expected_text in [
        ["42", "Value must be a string."],
        ["not a number", "Value must be a number."],
        ["[1, 2]", "Value must be a dictionary."],
        ["{a: 3}", "Extra field 'a' not permitted."],
    ]:
        with pytest.raises(ValidationError) as exc_info:
            validate_yaml(content=content, validator=int)

        error_message = exc_info.value.error_messages[0]
       

# Generated at 2022-06-22 06:19:52.805705
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    key1: value1
    key2: value2
    '''
    class SimpleSchema(Schema):
        key1 = Field(type="string")
        key2 = Field(type="string")

    value, error_messages = validate_yaml(content, validator=SimpleSchema)

    assert error_messages == []
    assert value["key1"] == "value1"
    assert value["key2"] == "value2"



# Generated at 2022-06-22 06:20:05.149413
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('{"a": 1, "b": 2}')
    assert isinstance(token, DictToken)
    assert token.start_index == 0
    assert token.end_index == 14
    assert token.keys() == ["a", "b"]
    assert token.get_child("a").start_index == 3
    assert token.get_child("a").end_index == 4
    assert token.get_child("a").value == 1
    assert token.get_child("b").start_index == 11
    assert token.get_child("b").end_index == 12
    assert token.get_child("b").value == 2

    token = tokenize_yaml("[1, 2]")
    assert isinstance(token, ListToken)
    assert token.start_index == 0
    assert token

# Generated at 2022-06-22 06:20:16.525233
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None

    good_yaml = """
    ---
    hello: world
    world:
      - hello
      - world
    """
    bad_yaml = """
    ---
    hello: world
    world:
      - hello
      - world
    test: true
    """
    class MySchema(Schema):
        hello = "string"
        world = ["string"]

    value, error_messages = validate_yaml(good_yaml, MySchema)

    assert value == MySchema(hello="world", world=["hello", "world"])
    assert not error_messages

    value, error_messages = validate_yaml(bad_yaml, MySchema)

    assert value is None

# Generated at 2022-06-22 06:20:31.563737
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()
        alive = Boolean()

    def validate_schema(content, schema):
        value, messages = validate_yaml(content, schema)
        if messages:
            raise ValidationError(messages=messages)
        return value
    
    # happy path
    person = '''
    name: Michael
    age: 28
    alive: true
    '''
    print(validate_schema(person, Person))

    # sad path
    person = '''
    name: Michael
    age: twentyeight
    alive: true
    '''
    with pytest.raises(ValidationError):
        validate_schema(person, Person)


if __name__ == '__main__':
    test_validate_yaml()

# Generated at 2022-06-22 06:20:39.972156
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Number, String, Array, Schema, Boolean
    from typesystem.fields import Reference
    from typesystem.base import ValidationError
    from typing import Any, List

    class User(Schema):
        id = Number(minimum=1)
        name = String()
        email = String()
        is_active = Boolean()
        followers = Array(items=Reference("self"))

    schema = User()

    yaml_content = """
        id: 2
        name: yaml
        email: yaml@yaml.com
        is_active: true
        """

    result = validate_yaml(yaml_content, schema)


# Generated at 2022-06-22 06:20:45.515541
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"{'color': '#fff', 'name': 'John' }"
    full_name = fields.String(required=True)
    name = fields.Dict({"color": fields.String(max_length=7), "name": full_name})

# Generated at 2022-06-22 06:20:57.469874
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test YAML string containing a list
    content = "[1, 2, 3]"
    field = Field(type="integer")
    result = validate_yaml(content=content, validator=field)

    assert not result.error_messages
    assert result.data == [1, 2, 3]

    # Test YAML string containing a dictionary of integers
    content = "{'one':1,'two':2,'three':3}"
    field = Field(type="dict", properties={"one": Field(type="integer")})
    result = validate_yaml(content=content, validator=field)

    assert result.error_messages
    assert result.data == {"one": 1, "two": 2, "three": 3}

    # Test YAML string containing a boolean value
    content = "true"
    field = Field

# Generated at 2022-06-22 06:21:05.955861
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")



# Generated at 2022-06-22 06:21:12.720146
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_content = '''
    name: John Smith
    age: 30
    '''

    token = tokenize_yaml(str_content)
    assert type(token) is DictToken
    assert type(token.value) is dict
    assert token.value['name'] == 'John Smith'
    assert token.value['age'] == 30

    assert token.start == 3
    assert token.end == 36


# Generated at 2022-06-22 06:21:23.446161
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = Field(str)
        age = Field(int)

    with pytest.raises(ParseError) as exc:
        validate_yaml('{"name": "Alex",', PersonSchema)
    assert exc.value.text == "expected <block end>, but found undefined."
    assert exc.value.position.line_no == 1
    assert exc.value.position.column_no == 17

    with pytest.raises(ValidationError) as exc:
        validate_yaml('{"name": "Alex"}', PersonSchema)
    assert len(exc.value.messages) == 1
    assert exc.value.messages[0].text == "Missing required value."
    assert exc.value.messages[0].position.line_no == 1

# Generated at 2022-06-22 06:21:26.754338
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = open("tests/data/yaml/simple.yaml").read()
    token = tokenize_yaml(content)
    assert token.value == {"name": "Foobar", "age": 20}



# Generated at 2022-06-22 06:21:32.730402
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = Text()

    value, errors = validate_yaml(b"name: sluppert", PersonSchema)
    assert value == {"name": "sluppert"}
    assert errors == []

    value, errors = validate_yaml(b"namez: sluppert", PersonSchema)
    assert value is None
    assert errors == [
        ValidationError(
            text='Schema has no field named "namez".',
            code="invalid_field",
            position=Position(char_index=0, column_no=0, line_no=1),
        )
    ]



# Generated at 2022-06-22 06:21:42.777625
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test validate YAML file with no content
    with open("data/empty.yml", "r") as f:
        data = f.read()
    assert validate_yaml(data, validator=None)[1][0].text == "No content."

    # Test validate YAML file with typesystem object
    class Person(Schema):
        name = String()

    contents = """
    name: "Hello"
    """
    assert validate_yaml(contents, validator=Person())[1] == []

    # Test validate YAML file with Field object
    field = String(max_length=2)

    assert validate_yaml("Hello", validator=field)[1][0].text == "Value is too long."

# Generated at 2022-06-22 06:21:55.551559
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "# empty list"
    token = tokenize_yaml(content)
    assert token.value == []
    assert token.start == 0
    assert token.end == 12
    assert token.content == "# empty list"

    content = "# empty list with spaces"
    token = tokenize_yaml(content)
    assert token.value == []
    assert token.start == 0
    assert token.end == 23
    assert token.content == "# empty list with spaces"

    content = "# empty list\n"
    token = tokenize_yaml(content)
    assert token.value == []
    assert token.start == 0
    assert token.end == 12
    assert token.content == "# empty list\n"

    content = """
    
    
# empty list
    """

# Generated at 2022-06-22 06:21:58.653937
# Unit test for function validate_yaml
def test_validate_yaml():
    content = open("test.yml", "r").read()
    validator = Field(name="a_dict", type="object")
    assert validate_yaml(content=content, validator=validator) == "a_dict"



# Generated at 2022-06-22 06:22:08.775681
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test yaml parsing
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("123") == 123
    assert tokenize_yaml("12.3") == 12.3
    assert tokenize_yaml("true") is True
    assert tokenize_yaml("false") is False
    assert tokenize_yaml("null") is None
    assert tokenize_yaml("'foo'") == "foo"
    assert tokenize_yaml('"foo"') == "foo"
    assert tokenize_yaml("""- foo""") == ["foo"]
    assert tokenize_yaml('"foo\nbar"') == "foo\nbar"
    assert tokenize_yaml('"foo\tbar"') == "foo\tbar"

# Generated at 2022-06-22 06:22:16.221375
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('a: 1')
    assert isinstance(token, DictToken)
    assert token.items["a"].value == 1

    token = tokenize_yaml('a: [1,2]')
    assert isinstance(token, DictToken)
    assert isinstance(token.items["a"], ListToken)
    assert token.items["a"].items[0].value == 1
    assert token.items["a"].items[1].value == 2


# Generated at 2022-06-22 06:22:27.013759
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "foo: bar\n"
    validator = Schema.of({"foo": str})
    value, error_messages = validate_yaml(content, validator=validator)
    assert error_messages == []
    assert value == {"foo": "bar"}

    content = "foo: bar\n"
    validator = Schema.of({"foo": int})
    value, error_messages = validate_yaml(content, validator=validator)
    assert len(error_messages) == 1
    assert error_messages[0].code == "invalid_type"
    assert error_messages[0].position == Position(line_no=1, column_no=8, char_index=7)
    assert value is None



# Generated at 2022-06-22 06:22:37.063712
# Unit test for function validate_yaml
def test_validate_yaml():
    #
    # create field for test
    #
    children = [Field("name"), Field("age", type="integer")]
    list_field = Field("list_of_children", type="list", items=children)

    #
    # test good flow
    #
    content = """
    list_of_children:
    - name: eli
      age: 5
    - name: omer
      age: 8
    """
    _, error_messages = validate_yaml(content, list_field)
    assert error_messages == []

    #
    # test bad flow, missing mandatory field
    #
    content = """
    list_of_children:
    - name: eli
    - name: omer
      age: 8
    """

# Generated at 2022-06-22 06:22:43.073240
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Note that tokenize_yaml is the same for all formats.
    from typesystem.tokenize.positional_validation import test_utils
    from typesystem.tokenize import validate_yaml as yaml_validator

    test_utils.test_tokenize(test_case=test_utils.TEST_CASES,
                             tokenizer=tokenize_yaml,
                             validator=yaml_validator,
                             format_name='yaml')

# Generated at 2022-06-22 06:22:51.553735
# Unit test for function validate_yaml
def test_validate_yaml():
    s = """
    name: foo
    """
    yaml_string = "name: string"
    schema = Schema(fields={"name": {"type": "string"}})  
    value, messages = validate_yaml(yaml_string, schema)
    assert value['name'] == "string"
    assert messages == []

    s2 = "name: bar"
    schema2 = Schema(fields={"name": {"type": "string"}})
    value2, messages2 = validate_yaml(s2, schema2)
    assert value2['name'] == "bar"
    assert messages2 == []

    s3 = "name: 1.0"
    schema3 = Schema(fields={"name": {"type": "number"}})

# Generated at 2022-06-22 06:22:56.247473
# Unit test for function validate_yaml
def test_validate_yaml():
    import pyyaml
    from typesystem.schemas import Schema

    valid_yaml = """
    name: "Bob Smith"
    name: "Alice Smith"
    """

    invalid_yaml = """
    name: "Bob Smith"
    age: 99
    """

    class Person(Schema):
        name = String(max_length=20)

    value, error_messages = validate_yaml(invalid_yaml, Person)

    assert len(error_messages) == 1
    assert error_messages[0].position.line_no == 3
    assert error_messages[0].position.column_no == 5

# Generated at 2022-06-22 06:23:05.955512
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, Schema, String

    from typesystem.base import ValidationError
    from typesystem.fields import Field

    class User(Schema):
        name = String()
        age = Integer()

    token = tokenize_yaml(b"name: foo")
    err1 = "Missing required value for field 'age' of type 'Integer'."
    assert validate_yaml(b"name: foo", User) == (
        None,
        [ValidationError(text=err1, code="missing_required_field")],
    )
    assert validate_with_positions(token, User) == (
        None,
        [ValidationError(text=err1, code="missing_required_field")],
    )

    field = Field(type="string", required=True)
    assert validate_with_positions

# Generated at 2022-06-22 06:23:17.580913
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    text = """
    hello: world
    foo:
      - bar
      - baz
    """
    assert isinstance(tokenize_yaml(text), DictToken)

    text = """
    - foo
    """
    assert isinstance(tokenize_yaml(text), ListToken)

    text = "foo"
    assert isinstance(tokenize_yaml(text), ScalarToken)

    text = """
    - 123
    - 456
    """
    assert isinstance(tokenize_yaml(text), ListToken)
    assert isinstance(tokenize_yaml(text).value[0], ScalarToken)
    assert tokenize_yaml(text).value[0].value == 123

# Generated at 2022-06-22 06:23:22.181174
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    tokenize_yaml('100')
    tokenize_yaml('100.2')
    tokenize_yaml('true')
    tokenize_yaml('{"key1": "value1", "key2": false}')

# Generated at 2022-06-22 06:23:30.646503
# Unit test for function validate_yaml
def test_validate_yaml():

    class Validate(Schema):
        name = "Validate"
        foo = Field(type="integer")

    content = (
        "{"
        '  "foo": "bar"'
        "}"
    )

    value, error_messages = validate_yaml(content=content, validator=Validate)
    assert isinstance(value, DictToken)
    assert len(error_messages) == 1
    error_message = error_messages[0]
    assert isinstance(error_message, ValidationError)

    content = (
        "{"
        '  "foo": 123'
        "}"
    )

    value, error_messages = validate_yaml(content=content, validator=Validate)
    assert isinstance(value, DictToken)
    assert not error_messages



# Generated at 2022-06-22 06:23:34.891126
# Unit test for function validate_yaml
def test_validate_yaml():
	import pytest
	class SimpleSchema(Schema):
		a = fields.String()
		b = fields.Integer()

	input_str = (
		'a: this is a\n'
		'b: 1\n'
	)
	pytest.main([__file__, "-s"])

# Generated at 2022-06-22 06:23:46.845180
# Unit test for function validate_yaml
def test_validate_yaml():

    class UserSchema(Schema):
        username = Field(name="username", required=True)
        first_name = Field(name="first_name")
        last_name = Field(name="last_name")
        age = Field(name="age", type="integer")

    user = {
        "username": "jsmith",
        "first_name": "John",
        "last_name": "Smith",
        "age": 27,
    }

    # Good User
    yaml = """
username: jsmith
first_name: John
last_name: Smith
age: 27
    """
    value, errors = validate_yaml(yaml, UserSchema)
    assert user == value
    assert not errors

    # Bad User (Capitalized age)

# Generated at 2022-06-22 06:23:51.950753
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    hello: world
    foo:
        - bar
        - baz
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == len(content) - 1



# Generated at 2022-06-22 06:23:59.878982
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    example_dict = yaml.load("{foo: bar}", Loader=yaml.SafeLoader)
    assert example_dict['foo'] == 'bar'

    example_int = yaml.load("42", Loader=yaml.SafeLoader)
    assert example_int == 42

    example_float = yaml.load("42.05", Loader=yaml.SafeLoader)
    assert example_float == 42.05

    example_bool = yaml.load("true", Loader=yaml.SafeLoader)
    assert example_bool

    example_null = yaml.load("null", Loader=yaml.SafeLoader)
    assert example_null == None


# Generated at 2022-06-22 06:24:08.437564
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test valid YAML
    # Test single level mapping
    token = tokenize_yaml("a: 1\nb: 2")
    assert isinstance(token, DictToken)
    assert token.as_dict() == {"a": 1, "b": 2}
    # Test single level seq
    token = tokenize_yaml("- 1\n- 2")
    assert isinstance(token, ListToken)
    assert token.as_list() == [1, 2]
    # Test multiple nesting
    token = tokenize_yaml("a:\n  - b: c\n    d: 1\n    - 2\n    - 3\n    e: f")
    assert isinstance(token, DictToken)

# Generated at 2022-06-22 06:24:18.907687
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        id: 1
        name: "Happy"
    """

    token = tokenize_yaml(content)

    assert isinstance(token, DictToken)
    assert token.value["id"] == 1
    assert token.value["name"] == "Happy"

    assert token.start_char == 0
    assert token.end_char == 36
    assert token.content == content

    assert token.parts[0].value == "id"
    assert token.parts[1].value == 1
    assert token.parts[2].value == "name"
    assert token.parts[3].value == "Happy"

    assert token.parts[0].start_char == 5
    assert token.parts[0].end_char == 7
    assert token.parts[0].content == content
    assert token.parts[1].start

# Generated at 2022-06-22 06:24:28.717576
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test parsing an empty YAML file
    content = ''
    validator = None
    try:
        validate_yaml(content=content, validator=validator)
    except ParseError as e:
        assert e.code == 'no_content'
        assert e.position
        assert e.text == 'No content.'

    # Test parsing a simple YAML file
    content = 'foo: bar'
    validator = None
    token, errors = validate_yaml(content=content, validator=validator)
    assert token.start == 0
    assert token.end == len(content)
    assert token.content == content
    assert token.value == token.children['foo'].value
    assert token.value == "bar"
    assert errors is None

    # Test parsing and validating a simple YAML file

# Generated at 2022-06-22 06:24:42.762797
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('{"name": "Isha", "color": "yellow", "age": 27}')
    assert token.type == "dict"
    assert token.value == {'name': 'Isha', 'color': 'yellow', 'age': 27}

    token = tokenize_yaml('[1, 2, 3]')
    assert token.type == "list"
    assert token.value == [1, 2, 3]

    token = tokenize_yaml('name: Isha')
    assert token.type == "scalar"
    assert token.value == 'name: Isha'

    content = '{"name": "Isha", "color": "yellow", "age": 27}'
    token = tokenize_yaml(content)
    assert token.get_text(token.start, token.end)

# Generated at 2022-06-22 06:24:52.497265
# Unit test for function validate_yaml
def test_validate_yaml():
    # Arrange
    content_string = """
    {
        "address": {
            "street_address": "21 2nd Street",
            "city": "New York",
            "state": "NY",
            "zip": "10021-3100"
        },
        "phone_number": [
            {
                "type": "home",
                "number": "212 555-1234"
            },
            {
                "type": "office",
                "number": "646 555-4567"
            }
        ]
    }"""

# Generated at 2022-06-22 06:25:02.296093
# Unit test for function validate_yaml
def test_validate_yaml():
    class Animal(Schema):
        kind = Field(type=str)

    class Cat(Schema):
        legs = Field(type=int)
        name = Field(type=str)
        age = Field(type=int)
        is_lazy = Field(type=bool)
        size = Field(type=float)

        # Set the a default value
        is_lazy = True

        # Rename the field to kind in the output
        kind = Field(type=str, rename_to='kind')

    class Dog(Schema):
        legs = Field(type=int)
        name = Field(type=str)
        age = Field(type=int)
        is_lazy = Field(type=bool)
        size = Field(type=float)

        # Set the a default value
        is_lazy = True

# Generated at 2022-06-22 06:25:07.536671
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Arrange
    content = "foo: bar"
    # Act
    token = tokenize_yaml(content)
    # Assert
    assert token == DictToken({"foo": "bar"}, 0, 8, content = content)



# Generated at 2022-06-22 06:25:13.792972
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(type="string")
    value = "test"
    content = "test"
    assert validate_yaml(content, field) == (value, [])
    content = 123
    with pytest.raises(ValidationError):
        validate_yaml(content, field)
    content = ""
    with pytest.raises(ValidationError):
        validate_yaml(content, field)

# Generated at 2022-06-22 06:25:21.757431
# Unit test for function validate_yaml
def test_validate_yaml():
    assert Field.validate_yaml("'hello'", Field(type="string")) == (
        "hello",
        [],
    )

    assert Field.validate_yaml("'hello'", Field(type="string", min_length=5)) == (
        "hello",
        [],
    )

    assert Field.validate_yaml("'hello'", Field(type="string", min_length=6)) == (
        None,
        [
            Message(
                start=0,
                end=6,
                text="Ensure this value has at least 6 characters (it has 5).",
                code="min_length",
                field="",
            )
        ],
    )


# Generated at 2022-06-22 06:25:24.928193
# Unit test for function validate_yaml
def test_validate_yaml():
    # This test is a stub.  Please add or amend tests as appropriate.
    print("This is a stub test, please remove.", file=sys.stderr)



# Generated at 2022-06-22 06:25:37.360009
# Unit test for function validate_yaml
def test_validate_yaml():
    class ConfigSchema(Schema):
        name = Text(required=True)
        email = Email(required=True)

    # Basic valid case.
    content = """
    name: "john"
    email: "john@example.com"
    """
    assert validate_yaml(content, ConfigSchema) == (
        {  # value
            "name": "john",
            "email": "john@example.com",
        },
        [],  # error_messages
    )

    # Error case.
    content = """
    name: "john"
    email: "not email"
    """

# Generated at 2022-06-22 06:25:40.445665
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(b'{"name": "Bilbo Baggins"}', {'name': str})[0] == {'name': 'Bilbo Baggins'}

# Generated at 2022-06-22 06:25:50.754452
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("[]") == ListToken([], 0, 1)
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2)
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1)
    assert tokenize_yaml("1.1") == ScalarToken(1.1, 0, 2)
    assert tokenize_yaml("yes") == ScalarToken(True, 0, 2)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3)



# Generated at 2022-06-22 06:26:04.151462
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
	content = '''
	- key: value
	  key1: value1
	  key2: value2
	- key3: value3
	  key4: value4
	- key5: value5
	'''
	
	result = tokenize_yaml(content)
	assert(result[0]['key'] == 'value')
	assert(result[0]['key1'] == 'value1')
	assert(result[0]['key2'] == 'value2')
	assert(result[1]['key3'] == 'value3')
	assert(result[1]['key4'] == 'value4')
	assert(result[2]['key5'] == 'value5')
	

# Generated at 2022-06-22 06:26:10.782357
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    result = tokenize_yaml(
        b"""
---
mapping:
  key: value
list:
  - item1
  - item2
scalar: value
integer: 1
float: 1.1
bool: true
null: ~
"""
    )
    assert result == {"mapping": {"key": "value"}, "list": ["item1", "item2"], "scalar": "value",
                      "integer": 1, "float": 1.1, "bool": True, "null": None}

# Generated at 2022-06-22 06:26:20.031828
# Unit test for function validate_yaml
def test_validate_yaml():
    class NestedSchema(Schema):
        field1 = "int"
        field2 = "str"

    class TestSchema(Schema):
        field1 = "int"
        field3 = NestedSchema

    content = """
      field1: 12
      field3:
        field1: 5
        field2: hello
    """

    value, error_messages = validate_yaml(content, TestSchema)
    assert isinstance(error_messages, list)
    assert len(error_messages) == 0
    assert value == {"field1": 12, "field3": {"field1": 5, "field2": "hello"}}



# Generated at 2022-06-22 06:26:30.812273
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        name = fields.String()
        email = fields.Email()

    assert validate_yaml("name: mr smith\nemail: mr.smith@gmail.com", UserSchema) == (
        {
            "name": "mr smith",
            "email": "mr.smith@gmail.com"
        },
        [],
    )


# Generated at 2022-06-22 06:26:34.317582
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    with open('tokens.yaml', 'r') as f:
        data = yaml.load(f, Loader=yaml.FullLoader)
    token = tokenize_yaml(data)
    assert isinstance(token, dict)
    assert isinstance(token['Key'], str)


# Generated at 2022-06-22 06:26:46.407899
# Unit test for function validate_yaml
def test_validate_yaml():
    class User(Schema):
        name = fields.String(required=True)
        age = fields.Integer()

    content = '''
    name: John
    age: "test"
    '''

    value, errors = validate_yaml(content, User)
    assert value is None
    assert len(errors) == 1
    assert not errors[0].error_type.to_string().startswith("ParseError")
    assert "age" in errors[0].error_type.to_string()
    assert "#/age" in errors[0].json_pointer

    content = "test"

    value, errors = validate_yaml(content, User)
    assert value is None
    assert len(errors) == 1
    assert errors[0].error_type.to_string().startswith("ParseError")
   

# Generated at 2022-06-22 06:26:55.956936
# Unit test for function validate_yaml
def test_validate_yaml():
    from pprint import pprint
    # error_messages = validate_yaml(
    #     b'{"name": "test", "surname": "test_test" }',
    #     Schema,
    # )
    # pprint(error_messages)
    # error_messages = validate_yaml(
    #     b'{"name": "test"}',
    #     Schema,
    # )
    # pprint(error_messages)
    error_messages = validate_yaml(
        b'{"name": "test", "surname": "test_test" }',
        Schema,
    )
    pprint(error_messages)

# Generated at 2022-06-22 06:27:08.044462
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = "string"

    value, error_messages = validate_yaml(
        content="""name: "Alice"\n""", validator=UserSchema
    )
    assert value == {"name": "Alice"}
    assert error_messages == []

    value, error_messages = validate_yaml(
        content="""not a real user\n""", validator=UserSchema
    )
    assert value == {}
    assert len(error_messages) == 1

# Generated at 2022-06-22 06:27:19.798352
# Unit test for function validate_yaml
def test_validate_yaml():
    import pytest
    from typesystem import Integer, String

    class TestSchema(Schema):
        a = Integer()
        b = String()

    content = '''
    a: 1
    b: Test
    '''

    value, error_messages = validate_yaml(content=content, validator=TestSchema)

    assert value == {"a": 1, "b": "Test"}
    assert len(error_messages) == 0

    content = '''
    a:
    b: Test
    '''

    value, error_messages_raw = validate_yaml(content=content, validator=TestSchema)
    assert value is None

# Generated at 2022-06-22 06:27:32.258838
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        a_string = Field(type="string", required=True, max_length=5)
        an_integer = Field(type="integer")

    good_content = u"""
    a_string: "Hello"
    an_integer: 5
    """

    assert validate_yaml(good_content, MySchema) == (
        {"a_string": "Hello", "an_integer": 5},
        None,
    )

    bad_content = u"""
    a_string: 4
    an_integer: 5
    """

    errors = validate_yaml(bad_content, MySchema)[1]
    assert len(errors) == 1
    assert errors[0].text == "must be a string."
    assert errors[0].position.char_index == 8
    assert isinstance

# Generated at 2022-06-22 06:27:40.718887
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    tok = tokenize_yaml("hello: world")
    assert isinstance(tok, DictToken)
    assert isinstance(tok.value["hello"], ScalarToken)
    assert isinstance(tok.value["hello"], ScalarToken)
    assert tok.value["hello"].value == "world"



# Generated at 2022-06-22 06:27:44.500267
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
- 1
- 2
- 3
- 4
- 5
- 6
- 7
- 8
- 9
    """
    assert type(tokenize_yaml(content)) == ListToken



# Generated at 2022-06-22 06:27:48.025927
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        a: "one"
        b: two
    """)
    assert isinstance(
        token, DictToken
    ), "incorrect token type should be DictToken"


# Generated at 2022-06-22 06:27:58.985707
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(
        tokenize_yaml("name: test_yaml_tokenize\n"),
        DictToken,
    )
    assert isinstance(
        tokenize_yaml("[1, 2, 3]"),
        ListToken,
    )
    assert isinstance(
        tokenize_yaml("1"),
        ScalarToken,
    )
    assert isinstance(
        tokenize_yaml("1.0"),
        ScalarToken,
    )
    assert isinstance(
        tokenize_yaml("True"),
        ScalarToken,
    )
    assert isinstance(
        tokenize_yaml("null"),
        ScalarToken,
    )
    # Test illegal input
    with pytest.raises(ParseError):
        tokenize_yaml("[")

# Generated at 2022-06-22 06:28:06.071239
# Unit test for function validate_yaml
def test_validate_yaml():
    """Unit test for function validate_yaml"""
    import yaml
    from typesystem import String, Integer
    from typesystem_yaml import validate_yaml

    content = yaml.safe_dump({"a": 1, "b": 2, "c": 3})
    class Schema(String):
        min_length = 2
    validator = Schema
    value, error_messages = validate_yaml(content, validator=validator)
    assert error_messages
    position = error_messages[0]["position"]
    assert position.char_index == 1
    assert position.column_no == 2
    assert position.line_no == 1

    class Schema(Integer):
        minimum = 2
    validator = Schema

    content = yaml.safe_dump(2)
    value, error_mess

# Generated at 2022-06-22 06:28:16.582051
# Unit test for function validate_yaml
def test_validate_yaml():

    from typesystem import Schema
    from typesystem import fields
    from typesystem.encoders import json_schema_encoder

    class Pet(Schema):
        name = fields.String()
        tag = fields.String()

    class Dog(Pet):
        breed = fields.String()

    class Cat(Pet):
        color = fields.String()

    class Human(Schema):
        full_name = fields.String()
        dob = fields.Date()
        pet = fields.Union([Dog, Cat])

    class Shelter(Schema):
        name = fields.String()
        pets = fields.List(Human)
        capacity = fields.Integer()

    schema = Shelter()
    # Create a valid input