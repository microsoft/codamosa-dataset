

# Generated at 2022-06-22 06:18:40.712751
# Unit test for function validate_yaml

# Generated at 2022-06-22 06:18:41.736581
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None



# Generated at 2022-06-22 06:18:51.109038
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    a:
        b:
            c: 1
            d:
                - e
                - f
        g: true
    '''
    validator = Schema(fields={"a": Field(fields={"b": Field(fields={
        "c": Field(type="integer"),
        "d": Field(type="array", items=Field(type="string"))
    })})})

    value, errors = validate_yaml(content, validator)
    assert errors == []
    assert value == {'a': {'b': {'d': ['e', 'f'], 'c': 1}}}



# Generated at 2022-06-22 06:18:58.583354
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    country:
        name: USA
        population: 300
        location:
            - latitude: 37.8
              longitude: -122.4
            - latitude: 39.8
              longitude: -121.6
    """)
    assert token.value == {'country': {
        'name': 'USA',
        'population': 300,
        'location': [
            {'latitude': 37.8, 'longitude': -122.4},
            {'latitude': 39.8, 'longitude': -121.6}
        ]
    }}


# Generated at 2022-06-22 06:19:10.457082
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = Field(str)
        age = Field(int)

    data = "name: Bob\nage: 50"
    token = tokenize_yaml(data)

    result, errors = validate_yaml(token=token, validator=PersonSchema)
    assert result == {"name": "Bob", "age": 50}
    assert not errors

    data = "name: Bob\nage: 50\none_extra_field: 30"
    token = tokenize_yaml(data)

    result, errors = validate_yaml(token=token, validator=PersonSchema)
    assert not result
    assert len(errors) == 1
    assert errors[0].position.line_no == 3

# Generated at 2022-06-22 06:19:21.600711
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields=[Field(name="name", type="string", required=True)])
    value, error_messages = validate_yaml(b'---\nname: John', schema)
    assert value == {"name": "John"}
    assert error_messages == []

    # ---
    value, error_messages = validate_yaml(b'name: John', schema)
    assert value is None
    assert error_messages == [
        Message(
            type=Message.ERROR,
            text="Invalid YAML syntax: Could not find expected ':'.",
            code="parse_error",
            position=Position(line_no=1, column_no=1, char_index=0),
        )
    ]

    # ---

# Generated at 2022-06-22 06:19:32.525916
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("a: 1")
    assert isinstance(token, DictToken)
    assert token.start_index == 0
    assert token.end_index == 3
    assert token.keys() == [ScalarToken("a", 0, 0), ScalarToken(1, 4, 4)]
    assert token.values() == [ScalarToken(1, 4, 4)]

    token = tokenize_yaml(b"a: 1")
    assert isinstance(token, DictToken)
    assert token.start_index == 0
    assert token.end_index == 3
    assert token.keys() == [ScalarToken("a", 0, 0), ScalarToken(1, 4, 4)]
    assert token.values() == [ScalarToken(1, 4, 4)]

    token = tokenize

# Generated at 2022-06-22 06:19:43.527787
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem.schemas import Schema
    from typesystem.fields import Integer

    class Foo(Schema):
        foo = Integer(minimum=5)

    def test_foo():
        value, error_messages = validate_yaml(
                content='foo: 3', validator=Foo,
        )
        assert len(error_messages) == 1
        assert error_messages[0] == Message(
                text='Must be at least 5.',
                code='min_value',
                position=Position(line_no=1, column_no=7, char_index=7),
                validator=Foo.fields['foo'],
        )


# Generated at 2022-06-22 06:19:55.849960
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    def parse_message(msg: str) -> Message:
        message_parts = msg.split(" ", 1)
        message_string = message_parts[1]
        return Message.parse(message_string)

    class FakeType(Field):
        def validate(self, value: typing.Any) -> typing.Any:
            raise ValidationError(text="Fake validation error.")

        @property
        def description(self) -> str:
            return "FakeType"

    # Positive tests
    try:
        expected = "!FakeType 'foo'"
        actual = validate_yaml("foo", FakeType())[1][0]
        assert expected == str(actual)
    except ParseError:
        raise AssertionError("Positive ParseError test failed.")



# Generated at 2022-06-22 06:20:07.561416
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem import types
    assert validate_yaml(b"foo", String()) == ("foo", [])
    assert validate_yaml(b"bar", types.String()) == ("bar", [])
    assert validate_yaml(b"123", types.Integer()) == (123, [])
    assert validate_yaml(b"foo\nbar", types.String()) == ("foo\nbar", [])
    content = b"ref: #/definitions/foo"
    assert validate_yaml(content, String()) == ("foo", [])
    # Error: No content.
    with pytest.raises(ParseError) as excinfo:
        validate_yaml(b"", types.String())
    assert excinfo.value.code == "no_content"
    assert excinfo

# Generated at 2022-06-22 06:20:20.512204
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = fields.String()
        age = fields.Integer()

    name_error = Message(text="Wrong type.", code="type_error", position=Position(line_no=1, column_no=7, char_index=6))
    age_error = Message(text="Wrong type.", code="type_error", position=Position(line_no=2, column_no=6, char_index=13))

    content = """
    name: 1
    age: false
    """
    value, errors = validate_yaml(content, Person)
    assert not value
    assert errors == [name_error, age_error]


# Generated at 2022-06-22 06:20:30.919410
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        class Meta:
            strict = True

        a = Field(type=str)

        b = Field(type=int)

    input_good = b"""
    a: hello
    b: 1
    """

    input_bad = b"""
    a: hello
    b: two
    """

    value, error_messages = validate_yaml(input_good, TestSchema)
    assert value == {"a": "hello", "b": 1}
    assert not error_messages

    value, error_messages = validate_yaml(input_bad, TestSchema)
    assert value["b"].parse_error

# Generated at 2022-06-22 06:20:35.683756
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = typing.List[typing.Dict]

    content = """
    str: its a str
    name: its a str
    bool: True
    ints:
        - 1
        - 2
        - 3
    """

    value, errors = validate_yaml(content, schema)

    print (errors)
    assert len(errors) == 0


# Generated at 2022-06-22 06:20:41.936361
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("[]") == ListToken([], index_start=0, index_end=1, content="[]")
    assert tokenize_yaml("[1]") == ListToken([ScalarToken(1, 0, 1, content="[1]")], 0, 2, content="[1]")
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("{a: 1}") == DictToken({"a": ScalarToken(1, 4, 5, content="{a: 1}")}, 0, 6, content="{a: 1}")

# Generated at 2022-06-22 06:20:46.109306
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    field = Field(type="string")
    content = """
    stringitem: String
    intitem: 1
    floatitem: 1.00
    boolitem: true
    nullitem: null
    listitem:
        - 1
        - 2
    dictitem:
        item1: 1
        item2: 2
    """
    result = validate_yaml(content, field)
    assert type(result[0]) is str
    assert type(result[1]) is list


# Generated at 2022-06-22 06:20:57.833215
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo: bar
    baz: qwerty
    """
    assert type(tokenize_yaml(content)) is DictToken
    assert tokenize_yaml(content).start == 1
    assert tokenize_yaml(content).end == 34
    assert type(tokenize_yaml(content).value) is dict

    assert tokenize_yaml(content).value["foo"].value == "bar"
    assert type(tokenize_yaml(content).value["foo"]) is ScalarToken
    assert tokenize_yaml(content).value["foo"].start == 6
    assert tokenize_yaml(content).value["foo"].end == 9
    assert tokenize_yaml(content).value["foo"].content == content


# Generated at 2022-06-22 06:21:07.829361
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = ""
    result = tokenize_yaml(content)
    assert result == []

    content = "[1, 2, 3]"
    result = tokenize_yaml(content)
    assert isinstance(result, ListToken)

    content = "{'key':[1, 2, 3]}"
    result = tokenize_yaml(content)
    assert isinstance(result, DictToken)

    content = "- {'key':[1, 2, 3], 'foo':'bar'}"
    result = tokenize_yaml(content)
    assert isinstance(result, ListToken)

    content = "true"
    result = tokenize_yaml(content)
    assert isinstance(result, ScalarToken)

    content = "1"
    result = tokenize_yaml(content)

# Generated at 2022-06-22 06:21:19.624214
# Unit test for function validate_yaml
def test_validate_yaml():
    # Validator
    class Params(Schema):
        title = Field(str)
        num = Field(int)

    # Error messages are a tuple of errors in list
    assert validate_yaml("title: 1\nnum: 3", Params) == (
        {"title": "1", "num": 3},
        [
            Message(
                text="Value must be a string (received 'int' instead).",
                code="invalid_type",
                kind="value_error.type_error.invalid_type",
                position=Position(line_no=1, column_no=7, char_index=6),
            )
        ],
    )

    # YAML parse error

# Generated at 2022-06-22 06:21:31.065549
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(
        type="integer",
    )

    value, error_messages = validate_yaml(content="42", validator=field)
    assert value == 42
    assert not error_messages

    value, error_messages = validate_yaml(content="fourty two", validator=field)
    assert value is None
    assert len(error_messages) == 1
    message = error_messages[0]
    assert message.text == "Must be of type 'integer'."
    assert message.code == "invalid_type"
    assert message.position.line_no == 1
    assert message.position.column_no == 1
    assert message.position.char_index == 0


# Generated at 2022-06-22 06:21:33.289355
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert(tokenize_yaml("") == "error")
    assert(tokenize_yaml("{key:value}") == "error")

# Generated at 2022-06-22 06:21:40.381313
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    test for validate_yaml function
    subject to change
    """
    content = "yup"
    validator = Field()
    assert validate_yaml(content, validator) == (u"yup", [])

# Generated at 2022-06-22 06:21:50.285937
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    exc = None
    try:
        tokenize_yaml({})
    except Exception as e:
        exc = e
    assert type(exc) == ParseError, "Empty set not handled correctly"

    exc = None
    try:
        tokenize_yaml("")
    except Exception as e:
        exc = e
    assert type(exc) == ParseError, "Empty string not handled correctly"

    content = "name: Jose\n"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken), "Dictionary not handled correctly"
    assert token.content == content, "Content not matched correctly"
    assert token.start == 0, "Start index not matched correctly"

# Generated at 2022-06-22 06:21:55.880131
# Unit test for function validate_yaml
def test_validate_yaml():
    content = u"""
        name: John Doe
        age: "28"
        occupation: 'Teacher'
        registered: true
    """
    schema = Schema(
        {
            "name": str,
            "age": int,
            "occupation": str,
            "registered": bool,
        }
    )
    value, error_messages = validate_yaml(content, schema)
    assert error_messages == []

# Generated at 2022-06-22 06:22:02.177484
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test a dictionary
    token = tokenize_yaml('{"foo": "bar"}')
    assert isinstance(token, DictToken)

    # test a list
    token = tokenize_yaml('["foo", "bar"]')
    assert isinstance(token, ListToken)

    # test a scalar
    token = tokenize_yaml('"foo"')
    assert isinstance(token, ScalarToken)

    # make sure empty string raises exception
    with pytest.raises(ParseError):
        tokenize_yaml('')

# Generated at 2022-06-22 06:22:10.928982
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(max_length=10)

    content = """
name: Derek

"""

    value, errors = validate_yaml(content=content, validator=MySchema)
    assert value == {"name": "Derek"}
    assert not errors

    content = """
name:
- Derek
- Martin

"""

    value, errors = validate_yaml(content=content, validator=MySchema)
    assert value == {"name": ["Derek", "Martin"]}
    assert not errors

# Generated at 2022-06-22 06:22:19.222234
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    test_string = "hello"
    token = tokenize_yaml(test_string)
    assert token.value == "hello"
    assert token.start == 0
    assert token.end == 5
    assert token.content == "hello"
    assert token.positional is True
    assert token.children == []
    assert token.index_l == 0
    assert token.index_r == len(test_string)

# Generated at 2022-06-22 06:22:29.349621
# Unit test for function validate_yaml
def test_validate_yaml():
    class SimpleSchema(Schema):
        name = fields.String(max_length=10)

    content = """name: Hello world"""
    value, errors = validate_yaml(content, validator=SimpleSchema)

    assert errors == [
        {
            "field": "name",
            "messages": [
                {
                    "code": "max_length",
                    "text": "Must have no more than 10 characters.",
                    "position": Position(column_no=5, line_no=1, char_index=5),
                }
            ],
        }
    ]

    content = """name: John"""
    value, errors = validate_yaml(content, validator=SimpleSchema)
    assert value == {"name": "John"}
    assert errors == []



# Generated at 2022-06-22 06:22:41.651163
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test case for ScalarToken
    token = tokenize_yaml('name: "John Doe"')
    assert token == {'name': "John Doe"}
    assert type(token) is DictToken
    assert type(token['name']) is ScalarToken # 'name' is ScalarToken

    # Test case for ListToken
    token = tokenize_yaml('"John","Doe"')
    assert token == ["John", "Doe"]
    assert type(token) is ListToken
    assert type(token[0]) is ScalarToken # first value is ScalarToken

    # Test case for parse error
    try:
        tokenize_yaml("{'name': 'John Doe'}")
    except ParseError as e: 
        assert e.text == "mapping values are not allowed here"

# Generated at 2022-06-22 06:22:52.533558
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Number
    from typesystem.schemas import Schema
    type_name="test_validate_yaml"
    class TestYamlSchema(Schema):
        name = String()
        age = Number()
    content = "name: John\nage: 23"
    # Success
    value, errors = validate_yaml(content=content, validator=TestYamlSchema)
    assert not errors
    assert value['name'] == 'John'
    assert value['age'] == 23
    # Failure
    content ="name: John"
    value, errors = validate_yaml(content=content, validator=TestYamlSchema)
    assert type(errors[0]) == ValidationError
    assert errors[0].field_name == "age"

# Generated at 2022-06-22 06:23:00.781126
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(
"""
type: object
additionalProperties: false
properties:
  name:
    type: string
  age:
    type: integer
    minimum: 0
    maximum: 150
required:
  - name
  - age
"""
    ) == {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer", "minimum": 0, "maximum": 150},
        },
        "required": ["name", "age"],
    }



# Generated at 2022-06-22 06:23:15.889235
# Unit test for function validate_yaml
def test_validate_yaml():
    # a complete, successful validation
    schema = Schema({
        "name": str,
        "dob": datetime,
        "children": [
            {
                "name": str,
                "dob": datetime,
                "gender": OneOf(["male", "female"]),
            }
        ],
    })

    yaml_string = """
    name: Socrates
    dob: 469 BC
    children:
    - name: Socrates Jr.
      dob: 429 BC
      gender: male
    """


# Generated at 2022-06-22 06:23:28.463273
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test if tokenizing empty string returns such an error
    with pytest.raises(ParseError, match='No content.'):
        try:
            # Try to parse the empty string
            tokenize_yaml("")
        except ParseError as exc:
            # Check if the error is of the correct type
            assert exc.code == 'no_content'
            raise
    # Test if parsing a YAML sample from the spec (https://yaml.org/spec/1.2/spec.html#id2804923) returns the correct result
    assert tokenize_yaml("""
    - Mark McGwire
    - Sammy Sosa
    - Ken Griffey
    """).value == [
        "Mark McGwire",
        "Sammy Sosa",
        "Ken Griffey",
    ]
    # Test if parsing a YAM

# Generated at 2022-06-22 06:23:41.268060
# Unit test for function validate_yaml
def test_validate_yaml():
    class Example(Schema):
        foo = Field(type="string")

    def _assert_errors(
        expected_errors: typing.List[Message],
        actual_errors: typing.List[Message],
    ) -> None:
        for index, message in enumerate(expected_errors):
            assert message == actual_errors[index]

    # Test against a yaml string.
    value, errors = validate_yaml(
        content="foo: bar", validator=Example(),
    )
    assert value == {"foo": "bar"}
    assert not errors

    value, errors = validate_yaml(content="{}", validator=Example())
    assert value == {}
    assert not errors

    value, errors = validate_yaml(
        content="- a\n- b\n- c", validator=Example(),
    )

# Generated at 2022-06-22 06:23:53.172708
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        content="{}",
        validator=Schema({"first_name": String()}),
    )[0] == {}
    assert validate_yaml(
        content="{}",
        validator=Schema({"last_name": String()}),
    )[1] == [
        Message(
            text="Missing a required property.",
            code="missing_property",
            pointer="#/last_name",
            position=Position(
                line_no=1, column_no=1, char_index=0),
            value=None)
    ]
    # Invalid example - last name is not required
    assert validate_yaml(
        content="{}",
        validator=Schema({"first_name": String()}),
    )[1] == []

# Generated at 2022-06-22 06:24:01.954673
# Unit test for function validate_yaml
def test_validate_yaml():
    # Simple success case
    (value, _) = validate_yaml("123", int)
    assert 123 == value

    # Simple parse error case
    (_, errors) = validate_yaml("junk", int)
    assert len(errors) == 1
    assert "Parse error: Unrecognized character." == errors[0].text

    # Simple validation error case
    (_, errors) = validate_yaml("12.3", int)
    assert len(errors) == 1
    assert "Not a valid integer." == errors[0].text

    # Complex error case
    (_, errors) = validate_yaml("""[1, 2, "3"]""", int)
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"

# Generated at 2022-06-22 06:24:10.970275
# Unit test for function validate_yaml
def test_validate_yaml():
    def _assert_roundtrip(content: str, value: typing.Any) -> None:
        """Assert that parsing a value and then serializing it back to YAML is an identity operation."""
        parsed_value, error_messages = validate_yaml(content=content, validator=validator)
        assert len(error_messages) == 0
        assert parsed_value == value

    # Test a simple field.
    validator = Field(type=str)
    content = '"Hello World!"'
    _assert_roundtrip(content=content, value="Hello World!")

    # Test a schema.
    class MySchema(Schema):
        field_one = Field(type=int)
        field_two = Field(type=float)

    validator = MySchema.as_field()

# Generated at 2022-06-22 06:24:20.938360
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token_ = tokenize_yaml("""
        name: edgar
        age: 20
        hobbies:
            - gardening
            - fishing
        """)
    name_token = token_["name"]
    age_token = token_["age"]
    hobby_token = token_["hobbies"]
    gardening_token = hobby_token[0]
    fishing_token = hobby_token[1]
    assert name_token == ScalarToken("edgar", 6, 12, content=token_.content)
    assert age_token == ScalarToken("20", 20, 21, content=token_.content)
    assert hobby_token == ListToken(["gardening", "fishing"], 37, 57, content=token_.content)
    assert gardening_token == ScalarToken("gardening", 47, 54, content=token_.content)
    assert fishing

# Generated at 2022-06-22 06:24:25.832305
# Unit test for function validate_yaml
def test_validate_yaml():
    source = """
    name: Sam
    age:  5
    """
    schema = Schema({"name": str, "age": int})
    value, error_messages = validate_yaml(source, schema)
    assert value == {"name": "Sam", "age": 5}
    assert error_messages == []

# Generated at 2022-06-22 06:24:32.319523
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        comments:
            # This is a comment
            # This is another comment
            # This is a line of content
        schema:
            type: object
            required:
            - name
            properties:
                name:
                    type: string
    """

    errors = validate_yaml(content, Schema)

    assert len(errors) == 0


# Generated at 2022-06-22 06:24:44.017750
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    def check_position(index, method, line_no, column_no, char_index):
        position = method(_get_position(content, index))
        assert position == Position(
            line_no=line_no, column_no=column_no, char_index=char_index
        )

    content = (
        "name:\n"
        "  first: John\n"
        "  last: Smith\n"
        "age: 24\n"
    )
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token == {
        "name": {"first": "John", "last": "Smith"},
        "age": 24,
    }


# Generated at 2022-06-22 06:24:55.293716
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = {
        "string": {"type": "string"},
        "int": {"type": "integer"},
        "list": {"type": "list", "items": {"type": "number"}},
    }
    sample_data = {
        "string": "string",
        "int": 6,
        "list": [4, 5, 6]
    }

    #Unit test for validation on string
    with pytest.raises(ValidationError) as exc_info:
        validate_yaml(sample_data["string"], schema["string"])
    error_message = exc_info.value.message
    assert str(error_message) == "Must be a YAML string."
    assert error_message.code == "parse_error"
    assert error_message.position.char_index == 0

    #Unit test for validation

# Generated at 2022-06-22 06:25:07.431606
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test validate_with_positions with a YAML string"""
    content = """
    username: 'will.robertson'
    first_name: Will
    last_name: Robertson
    """
    field = Field(type="string", required=True)
    validator = Schema(
        properties={
            "username": field,
            "first_name": field,
            "last_name": field,
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {
        "username": "will.robertson",
        "first_name": "Will",
        "last_name": "Robertson",
    }
    assert error_messages == []


# Generated at 2022-06-22 06:25:18.176061
# Unit test for function validate_yaml
def test_validate_yaml():
    schemadef = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "string"},
            "address": {
                "type": "object",
                "properties": {
                    "number": {"type": "number"},
                    "street": {"type": "string"},
                    "city": {"type": "string"},
                },
            },
            "items": {
                "type": "array",
                "items": {"type": "string"},
                "minItems": 2,
                "maxItems": 2,
            },
        },
        "required": ["name", "age", "address", "items"],
    }
    schema = Schema(**schemadef)

    # Test valid yaml

# Generated at 2022-06-22 06:25:27.404164
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content_yaml = {
        "name": "hello",
        "age": 18
    }
    content_yaml_string = """
        name: hello
        age: 18"""
    content_string = "test string"
    content_bytes = bytes(content_string, encoding="utf-8")
    with pytest.raises(AssertionError):
        tokenize_yaml(content_string)
    with pytest.raises(AssertionError):
        tokenize_yaml(content_bytes)

    assert yaml.dump(content_yaml) == tokenize_yaml(content_yaml_string)



# Generated at 2022-06-22 06:25:32.189794
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class ExampleSchema(Schema):
        name = String()
        age = Integer()

    assert validate_yaml(
        content="age: 100\nname: Alex",
        validator=ExampleSchema,
    ) == (
        {"name": "Alex", "age": 100},
        [],
    )

    assert validate_yaml(
        content="age: 50\nname: Alex",
        validator=ExampleSchema(),
    ) == (
        {"name": "Alex", "age": 50},
        [],
    )


# Generated at 2022-06-22 06:25:44.185960
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "email": {"type": "string", "format": "email"},
        },
    }
    test_data = {
        "name": "John",
        "email": "john@example.com",
    }
    value, errors = validate_yaml(yaml.dump(test_data), schema)
    assert errors == []
    assert value == test_data
    test_data = {
        "name": "John",
        "email": "john@example",
    }
    value, errors = validate_yaml(yaml.dump(test_data), schema)
    assert errors != []

# Generated at 2022-06-22 06:25:53.728707
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Scalars
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true")
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    # Lists
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    # Dicts
    assert tokenize_yaml("{a: 1, b: {c: 2}}") == {"a": 1, "b": {"c": 2}}

# Generated at 2022-06-22 06:26:03.844473
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Tests validate_yaml function.
    """

    class Person(Schema):
        first_name = String(max_length=10)
        last_name = String(max_length=20)

    input_string = textwrap.dedent(
        """\
    first_name: "John"
    last_name: "Appleseed"
    """
    )

    (value, errors) = validate_yaml(input_string, Person)
    assert not errors

    input_string = textwrap.dedent(
        """\
    first_name: "John"
    last_name: This is going to be too long to fit in a last name, so this should fail.
    """
    )

    (value, errors) = validate_yaml(input_string, Person)
    assert "last_name"

# Generated at 2022-06-22 06:26:15.468733
# Unit test for function validate_yaml
def test_validate_yaml():
    def validate_yaml(content: str, validator: typing.Union[Field, typing.Type[Schema]]) -> typing.Any:
        token = tokenize_yaml(content)
        return validate_with_positions(token=token, validator=validator)

    class PersonSchema(Schema):
        name = String()
        age = Integer()

    # Parse and validate a valid YAML string.
    (value, error_messages) = validate_yaml(
        content="""
        name: yaml
        age: 1
        """,
        validator=PersonSchema,
    )
    assert error_messages == []
    assert value == {"name": "yaml", "age": 1}

    # Parse and validate an invalid YAML string.
    (value, error_messages)

# Generated at 2022-06-22 06:26:27.328347
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "---\n- 1\n- 2.0\n- true\n- false\n- null\n- 'string'\n- !tag test"
    token = tokenize_yaml(content)
    assert token.content == content
    assert token.start == 0
    assert token.end == len(content) - 1
    assert isinstance(token, ListToken)
    assert len(token.value) == 7
    assert token.value[0] == 1
    assert isinstance(token.value[0], ScalarToken)
    assert token.value[1] == 2.0
    assert isinstance(token.value[1], ScalarToken)
    assert token.value[2] == True
    assert isinstance(token.value[2], ScalarToken)
    assert token.value[3] == False
   

# Generated at 2022-06-22 06:26:42.285013
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem.schemas import Schema, fields
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.tokens import Token

    class ColorSchema(Schema):
        r = fields.Integer(multiple_of=100)
        g = fields.Integer(multiple_of=100)
        b = fields.Integer(multiple_of=100)

    yaml_content = """
    r: 100
    g: 100
    b: 100
    """

    token = yaml.safe_load(yaml_content)
    value, error_messages = validate_with_positions(
        token=token, validator=ColorSchema
    )
    assert not error_messages, str(error_messages)

# Generated at 2022-06-22 06:26:53.373625
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "foo: bar\n"
    token = tokenize_yaml(content)
    assert token == DictToken({"foo": "bar"}, 0, 8, content=content)

    content = "foo: bar\n"
    token = tokenize_yaml(content)
    assert token == DictToken({"foo": "bar"}, 0, 8, content=content)

    content = "foo: bar\n"
    token = tokenize_yaml(content)
    assert token == DictToken({"foo": "bar"}, 0, 8, content=content)

    content = '{"foo": 1}\n'
    token = tokenize_yaml(content)
    assert token == DictToken({"foo": 1}, 0, 9, content=content)

    content = "bar\n"
    token = tokenize_

# Generated at 2022-06-22 06:27:05.522007
# Unit test for function validate_yaml
def test_validate_yaml():
    content = ""
    validator = Field(name="test_validate_yaml")
    value, error_messages = validate_yaml(content, validator)
    assert value is None
    assert error_messages == [
        Message(
            code="no_content",
            message="No content.",
            position=Position(column_no=1, line_no=1, char_index=0),
            schema={'name': 'test_validate_yaml'},
        )
    ]

    with pytest.raises(ValidationError) as ei:
        validate_yaml(content, validator, raise_exceptions=True)
    error_messages = ei.value.messages

# Generated at 2022-06-22 06:27:09.350301
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_str = """
    - id: asdf  # this is a comment
      name: asdf
      adsgjgasdg
      jasdg
      - a
      - b
      - c
    - id: asdf # this is a comment
      name: asdf
    """
    ast = tokenize_yaml(yaml_str)
    print(ast)


# Generated at 2022-06-22 06:27:16.884936
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "a: 1\nb: 2\n"
    token = tokenize_yaml(content)
    assert token.content == content
    assert token.start == 0
    assert token.end == content.index(3)
    assert token.value["a"] == "1"
    assert token.value["b"] == "2"
    assert isinstance(token.value["a"], ScalarToken)
    assert isinstance(token.value["b"], ScalarToken)



# Generated at 2022-06-22 06:27:27.792569
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class SimpleSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)

    content = "name: michael\nage: 28"

    value, errors = validate_yaml(content=content, validator=SimpleSchema)

    assert value == {"name": "michael", "age": 28}
    assert not errors

    content = "name: michael\nage: twenty-eight"

    value, errors = validate_yaml(content=content, validator=SimpleSchema)
    assert value == {"name": "michael", "age": "twenty-eight"}
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"

# Generated at 2022-06-22 06:27:30.612211
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "a: b\nc: d"
    assert validate_yaml(content, typing.Dict[str, str]) == ({'a': 'b', 'c': 'd'}, [])

# Generated at 2022-06-22 06:27:43.477672
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.1") == ScalarToken(1.1, 0, 2, content="1.1")
    assert tokenize_yaml("1.1e1") == ScalarToken(1.1e1, 0, 4, content="1.1e1")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")

# Generated at 2022-06-22 06:27:53.390327
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.base import Scalar  # noqa
    from typesystem.fields import String  # noqa

    schema = Schema(content=String())
    assert tokenize_yaml("") is None
    content, errors = validate_yaml("", schema)
    assert len(errors) == 1

    assert tokenize_yaml("{}") == DictToken(content={}, start=0, end=1, content="{}")
    assert tokenize_yaml("[]") == ListToken(content=[], start=0, end=1, content="[]")
    assert tokenize_yaml("a: b") == DictToken(
        content={"a": "b"}, start=0, end=3, content="a: b"
    )

# Generated at 2022-06-22 06:28:04.578539
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_content = '''
    meta:
        schema_version: 2.0
        generated: "2019-04-18T06:34:14"
    data:
        - name: A
          data:
              value: "1,000"
              label: "one thousand"

        - name: B
          data:
              value: "2,000"
              label: "two thousand"
    '''
    struct: Token = tokenize_yaml(yaml_content)
    assert isinstance(struct, DictToken) and len(struct.children) == 2
    assert struct.children['meta'] and struct.children['data']
    meta_token = struct.children['meta']
    assert isinstance(meta_token, DictToken) and len(meta_token.children) == 2
    assert meta_token.children

# Generated at 2022-06-22 06:28:17.587864
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("[]") == ListToken([])

    assert tokenize_yaml("{}") == DictToken({})

    assert tokenize_yaml("-") == ListToken([])

    assert tokenize_yaml("- foo") == ListToken(["foo"])

    assert tokenize_yaml("foo: bar") == DictToken({"foo": "bar"})

    assert tokenize_yaml("123") == ScalarToken(123)

    assert tokenize_yaml("0.0") == ScalarToken(0.0)

    assert tokenize_yaml("true") == ScalarToken(True)

    assert tokenize_yaml("null") == ScalarToken(None)

    assert tokenize_yaml("1930-01-01") == ScalarToken("1930-01-01")

