

# Generated at 2022-06-22 06:18:45.280355
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = String(max_length=100)
        age = Integer(min_value=0, max_value=150)

    content = '''
    name: "Einstein"
    age: "very old"
    '''

    value, messages = validate_yaml(
        content=content, validator=PersonSchema
    )

    assert not value
    assert isinstance(messages, Messages)
    assert messages.error_code == "invalid_type"



# Generated at 2022-06-22 06:18:54.016952
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content="1", validator=int) == (1, [])
    # This is a string in python, but an int in YAML
    assert validate_yaml(content="100", validator=int) == (100, [])
    assert validate_yaml(content="100", validator=float) == (100, [])

    value, errors = validate_yaml(content="", validator=str)
    assert isinstance(value, str)
    assert len(errors) == 1

    value, errors = validate_yaml(content="abc", validator=int)
    assert isinstance(value, int)
    assert len(errors) == 1

    value, errors = validate_yaml(content="100", validator=float)
    assert isinstance(value, float)
    assert len(errors)

# Generated at 2022-06-22 06:19:03.220372
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: Baron
    age: 20
    """

    value, error_messages = validate_yaml(content, validator=Person())
    assert value == {"name": "Baron", "age": 20}
    assert error_messages == []



# Generated at 2022-06-22 06:19:13.854731
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    def test_parse(yaml_str, expected_obj):
        token = tokenize_yaml(yaml_str)
        assert expected_obj == token

    def test_empty_parse():
        test_parse("", [])

    def test_scalar_parse():
        test_parse("foo", ScalarToken("foo", 0, 2))
        test_parse("10", ScalarToken(10, 0, 1))
        test_parse("1.0", ScalarToken(1.0, 0, 3))
        test_parse('"foo"', ScalarToken("foo", 0, 4))
        test_parse("true", ScalarToken(True, 0, 3))
        test_parse("null", ScalarToken(None, 0, 3))

# Generated at 2022-06-22 06:19:19.903269
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test function validate_yaml
    """
    from typesystem import String, Integer

    class MySchema(Schema):
        number = Integer()
        name = String()

    data = b"name: item1\nnumber: 1"
    _, errors = validate_yaml(data, validator=MySchema)
    if errors:
        print("Test on validate_yaml failed")
        exit()


# Generated at 2022-06-22 06:19:26.222357
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("{}", {"age": int}) == ({"age": None}, [])

    value, errors = validate_yaml("{}", {"age": int, "name": str})
    assert value == {"age": None, "name": None}
    assert len(errors) == 2
    assert errors[0].code == "required"
    assert errors[1].code == "required"

    # Regression check that the field's default type is used, rather than
    # yaml.SafeLoader's empty string default.
    value, errors = validate_yaml("", "name")
    assert value == None
    assert len(errors) == 1
    assert errors[0].code == "required"

# Generated at 2022-06-22 06:19:32.840281
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer

    content = b'''
    - person
    - age: 18
    '''

    field = Integer(name='age', required=True, allow_blank=False)
    class PersonSchema(Schema):
        name = field
    schema = PersonSchema

    validate_yaml(content, schema) == ({'name': 'person', 'age': 18}, [])


# Generated at 2022-06-22 06:19:43.933189
# Unit test for function validate_yaml
def test_validate_yaml():

    schema = Schema(fields=[Field(name="name")])
    result = validate_yaml(b'name:xyz', schema)
    assert result[0] == {'name': 'xyz'}
    assert not result[1]

    data = """
    name: "typesystem"
    homepage: "https://github.com/typesystem/typesystem"
    version: "!expr 1.0.0"
    maintainers:
      - name: "Karl Hobley"
      - name: "Tim Heap"
    """
    schema.validate(data)


# Generated at 2022-06-22 06:19:56.346170
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    sample_list= [1, 2, 3, 4]
    sample_dict = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    sample_str = "Hello"
    sample_int = 45
    sample_float = 123.45
    sample_bool_true = True
    sample_bool_false = False
    sample_null_value = None

    token = tokenize_yaml(sample_list)
    assert(isinstance(token, ListToken))
    assert(token.end == 4)
    assert(token.start == 0)
    assert(token.value == [1, 2, 3, 4])
    token = tokenize_yaml(sample_dict)
    assert(isinstance(token, DictToken))

# Generated at 2022-06-22 06:20:04.060765
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('"a": 1\n"b": 2')
    assert isinstance(token, DictToken)
    assert token.content == '"a": 1\n"b": 2'
    assert token.keys() == ["a", "b"]
    assert token.values() == [ScalarToken(1, 4, 5), ScalarToken(2, 10, 11)]
    assert token.start == 0
    assert token.end == 12


# Generated at 2022-06-22 06:20:21.422172
# Unit test for function validate_yaml
def test_validate_yaml():
    # This tests uses a schema from Field
    schema = {"name": "string", "age": "integer"}
    # The input is a dictionary
    input_data = {"name": "Bob", "age": 12}
    value, error_messages = validate_yaml(input_data, schema)
    assert error_messages == []
    assert value == {"name": "Bob", "age": 12}

    # This tests uses a schema from Schema
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        class Meta:
            title = "Person"

    # The input is a dictionary
    input_data = {"name": "Bob", "age": 12}
    value, error_messages = validate_yaml(input_data, Person)

# Generated at 2022-06-22 06:20:32.828120
# Unit test for function validate_yaml
def test_validate_yaml():
    # Initialize test schema
    class TestSchema(Schema):
        name = String()
        age = Integer()

    # Test with valid data
    valid_data = """
    name: Test name
    age: 20
    """
    value, error_messages = validate_yaml(valid_data, TestSchema)
    assert len(error_messages) == 0
    assert value == {'name': 'Test name', 'age': 20}

    # Test with invalid data
    invalid_data = """
    name: Test name
    age: abc
    """
    value, error_messages = validate_yaml(invalid_data, TestSchema)
    assert len(error_messages) == 1
    assert error_messages[0].text == '"abc" is not of type "integer"'
    assert error

# Generated at 2022-06-22 06:20:42.707409
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test parsing an empty string by default.
    # Use an assert_raises to catch the ParseError.
    with pytest.raises(ParseError):
        tokenize_yaml(content="")
    # Test parsing a non-empty string.
    token = tokenize_yaml(
        content="""
        unknown_key:
          - value1
          - value2
        """
    )
    # Assert value is of type DictToken
    assert isinstance(token, DictToken)
    # Assert dict token has two keys
    assert len(token.values) == 2
    # Assert first value is of type ScalarToken
    assert isinstance(token.values["unknown_key"], ScalarToken)
    # Type assert first value as a ListToken

# Generated at 2022-06-22 06:20:47.529016
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("42") == ScalarToken(42, 0, 2, content="42")
    assert tokenize_yaml("2.5") == ScalarToken(2.5, 0, 3, content="2.5")
    assert tokenize_yaml("yes") == ScalarToken(True, 0, 3, content="yes")
    assert tokenize_yaml("no") == ScalarToken(False, 0, 2, content="no")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")

# Generated at 2022-06-22 06:20:59.122200
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
name: "Roy"
age: 20
'''
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=100)

    value, error_messages = validate_yaml(content, Person)
    assert value['name'] == "Roy"
    assert value['age'] == 20
    assert error_messages == []

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=20, maximum=100)

    value, error_messages = validate_yaml(content, Person)
    assert value['name'] == "Roy"
    assert value['age'] == 20
    assert error_messages == []


# Generated at 2022-06-22 06:21:09.918962
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test for validate_yaml
    """
    field = Field(type="string")
    validator = Schema(fields={"test": field})
    test_content = "Not a YAML string"
    value, error_messages = validate_yaml(test_content, field)
    assert len(error_messages) > 0
    assert value is None
    test_content = "{n: Not a YAML string}"
    value, error_messages = validate_yaml(test_content, field)
    assert len(error_messages) > 0
    assert value is None
    test_content = '{"test":"input"}'
    value, error_messages = validate_yaml(test_content, validator)
    assert len(error_messages) == 0

# Generated at 2022-06-22 06:21:20.512680
# Unit test for function validate_yaml
def test_validate_yaml():
    # test invalid yaml
    yaml_content = """
    first: 1
    second: 2
    third: 3
    """
    try:
        value, error_messages = validate_yaml(yaml_content, "")
    except ParseError as e:
        assert e.position.char_index == 0
        assert e.position.column_no == 1
        assert e.position.line_no == 1

    # test valid yaml
    yaml_content = """
    name: "Joe"
    score: 10
    """
    value, error_messages = validate_yaml(yaml_content, "")
    assert value == {"name": "Joe", "score": 10}
    assert(error_messages == {})

# Generated at 2022-06-22 06:21:31.157663
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert SafeLoader is not None, "'pyyaml' must be installed."

    # test_string_validation
    test_str = "happy: true\n" 
    assert(tokenize_yaml(test_str) == DictToken({'happy': True}, 0, 11, content=test_str))

    # test_unicode_validation
    test_str = "\u263A: true\n" 
    assert(tokenize_yaml(test_str) == DictToken({'☺': True}, 0, 9, content=test_str))

    # test_empty_stream
    test_str = ""

# Generated at 2022-06-22 06:21:36.252483
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_scalar = "foo"
    yaml_map = "foo: bar"
    yaml_seq = """- foo
    - bar"""

    assert isinstance(tokenize_yaml(yaml_scalar), ScalarToken)
    assert isinstance(tokenize_yaml(yaml_map), DictToken)
    assert isinstance(tokenize_yaml(yaml_seq), ListToken)



# Generated at 2022-06-22 06:21:47.256394
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        """
        foo: bar
        """,
        Schema({"foo": String()}),
    ) == ({"foo": "bar"}, [])

    assert validate_yaml(
        """
        foo: 123
        """,
        Schema({"foo": String()}),
    ) == (
        {"foo": 123},
        [
            Message(
                text="Must be of type 'string'.",
                code="type_error.string",
                position=Position(line_no=2, column_no=6, char_index=14),
            )
        ],
    )


# Generated at 2022-06-22 06:21:59.746310
# Unit test for function validate_yaml
def test_validate_yaml():
    #
    # First tests with no error cases
    #
    assert validate_yaml(b"foo", str) == ("foo", [])
    assert validate_yaml('foo', str) == ("foo", [])

    assert validate_yaml(b"42", int) == (42, [])
    assert validate_yaml('42', int) == (42, [])

    assert validate_yaml(b"3.14", float) == (3.14, [])
    assert validate_yaml('3.14', float) == (3.14, [])

    assert validate_yaml(b"true", bool) == (True, [])
    assert validate_yaml('true', bool) == (True, [])

    class MySchema(Schema):
        foo = str
        bar = int

    my_sche

# Generated at 2022-06-22 06:22:08.320144
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    data_dict = {'a': {'b': 1, 'c': 2}, 'd': [1, 2, 3]}
    data_yaml = 'a:\n  b: 1\n  c: 2\nd: [1, 2, 3]'
    print("Data in dict format:", data_dict)
    print("Data in yaml format:", data_yaml)
    token = tokenize_yaml(data_yaml)
    print("Token after tokenize_yaml:", token)
    assert (token == data_dict)
    print("tokenize_yaml works fine")


# Generated at 2022-06-22 06:22:18.572850
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    [
        {
            "username": "",
            "password": "",
            "email": "joe@example.com"
        }
    ]
    '''
    class User(Schema):
        username = String(validators=[Regex("^[a-zA-Z0-9\._]+$")])
        password = String(validators=[Regex("^[a-zA-Z0-9\._]+$")])
        email = Email()

    validator = List(User)
    value, errors = validate_yaml(content, validator)
    assert value == [{"username": "", "password": "", "email": "joe@example.com"}]

    assert len(errors) == 2
    message = errors[0]

# Generated at 2022-06-22 06:22:28.515843
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=50)
        age = Integer()

    content = 'name: "Alice"\nage: 12'
    value, error_messages = validate_yaml(content, validator=Person)
    assert len(error_messages) == 0

    content = 'name: "Alice"'
    value, error_messages = validate_yaml(content, validator=Person)
    assert len(error_messages) == 1
    message = error_messages[0]
    assert message.code == "missing_field"
    assert message.field_name == "age"
    assert message.position.line_no == 2
    assert message.position.column_no == 1



# Generated at 2022-06-22 06:22:41.265638
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    test_validate_yaml
    """
    import typesystem
    from typesystem import types

    class UserSchema(typesystem.Schema):
        """
        UserSchema
        """

        name = types.String(max_length=100)
        age = types.Integer(minimum=18, maximum=99)
        active = types.Boolean()

    with pytest.raises(ValidationError, match=r"extra_field"):
        UserSchema.validate_yaml(
            """
            name: John Doe
            age: 35
            active: true
            gender: male
            """
        )


# Generated at 2022-06-22 06:22:50.051403
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import yaml
    from yaml.loader import SafeLoader

    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken, Token

    class CustomSafeLoader(SafeLoader):
        pass

    def construct_mapping(loader, node):
        start = node.start_mark.index
        end = node.end_mark.index
        mapping = loader.construct_mapping(node)
        return DictToken(mapping, start, end - 1, content=content)

    def construct_sequence(loader, node):
        start = node.start_mark.index
        end = node.end_mark.index
        value = loader.construct_sequence(node)

# Generated at 2022-06-22 06:22:52.290301
# Unit test for function tokenize_yaml
def test_tokenize_yaml():  
  content = '["Chris", "Scott", "John"]'
  tokens = tokenize_yaml(content)

  assert tokens.value == ['Chris', 'Scott', 'John']


# Generated at 2022-06-22 06:23:02.845421
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    test_scalar: hello
    test_int: 123
    test_float: 123.456
    test_bool: true
    test_null: null
    test_dict:
      test_nested: testing
      test_nested_list:
        - one
        - two
        - three
    test_list:
      - 1
      - 2
      - 3
    test_list_empty: []
    """

# Generated at 2022-06-22 06:23:15.501057
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ""
    assert tokenize_yaml(" ") == " "
    assert tokenize_yaml("1") == ScalarToken(1, start=0, end=0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, start=0, end=2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, start=0, end=3, content="true")
    assert tokenize_yaml("null") == ScalarToken(None, start=0, end=3, content="null")
    assert tokenize_yaml("./file.txt") == ScalarToken(
        "./file.txt", start=0, end=9, content="./file.txt"
    )


# Generated at 2022-06-22 06:23:24.410687
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Empty string
    token = tokenize_yaml('')
    assert token == {}
    # None
    token = tokenize_yaml(None)
    assert token == {}

    # Dict
    token = tokenize_yaml('foo: 1')
    assert token == {'foo': 1}
    # List
    token = tokenize_yaml('- 1')
    assert token == [1]
    # Scalar
    token = tokenize_yaml('1')
    assert token == 1
    # Float
    token = tokenize_yaml('!float 1')
    assert token == 1.0
    # Int
    token = tokenize_yaml('!int 1')
    assert token == 1



# Generated at 2022-06-22 06:23:39.438837
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({
        "name": String(min_length=1, max_length=10),
        "age": Integer(minimum=1, maximum=100),
    })
    value, errors = validate_yaml(b"name: John\nage: 22\n", schema)
    assert value == {"name": "John", "age": 22}
    assert errors == []
    value, errors = validate_yaml(b"name: John\nage: 22\n", schema)
    assert value == {"name": "John", "age": 22}
    assert errors == []
    value, errors = validate_yaml(b"name: John\nage: 22\n", schema)
    assert value == {"name": "John", "age": 22}
    assert errors == []

# Generated at 2022-06-22 06:23:51.518832
# Unit test for function validate_yaml
def test_validate_yaml():
    from yaml.parser import ParserError

    assert validate_yaml(content="", validator=Field(required=True)) == (
        None,
        [
            Message(
                text="This field is required.",
                code="required",
                position=Position(line_no=1, column_no=1),
            )
        ],
    )

    assert validate_yaml(content="{}", validator=Field(required=True)) == (
        None,
        [
            Message(
                text="This field is required.",
                code="required",
                position=Position(line_no=1, column_no=2),
            )
        ],
    )


# Generated at 2022-06-22 06:24:00.942246
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """{
        "Foo": {
            "Bar": 123
        },
        "Baz": "Hello World"
    }"""
    tokenized = tokenize_yaml(content)
    # Function tokenize_yaml returns a DictToken which is a representation of a dictionary.
    assert isinstance(tokenized, DictToken)
    # print(tokenized)
    for k, v in tokenized.items():
        # Bar has the value 123, which is an integer.
        if k == "Bar":
            assert type(v) == int
        # Baz has the value "Hello World", which is a string.
        elif k == "Baz":
            assert type(v) == str

# Generated at 2022-06-22 06:24:06.068277
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        version: v1
        title: Hello World
        type: object
        properties:
          hello:
            type: string
            title: Hello
          world:
            type: string
            title: World
        required:
          - hello
          - world
        """)
    assert isinstance(token, DictToken)
    assert len(token.value) == 5
    assert token.value['version'] == 'v1'
    assert isinstance(token.value['properties'], DictToken)
    assert isinstance(token.value['properties'].value['hello'], DictToken)
    assert isinstance(token.value['required'], ListToken)
    assert token.value['required'].value[0] == 'hello'
    assert token.start == 0
    assert token.end

# Generated at 2022-06-22 06:24:10.004319
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test validate_yaml"""
    class MySchema(Schema):
        foo = "string"

    content = b"foo: 'bar'"
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"foo": "bar"}
    assert not error_messages

    content = b"foo: bar"
    value, error_messages = validate_yaml(content, MySchema)
    assert value is None
    assert len(error_messages) == 1
    error = error_messages[0]
    assert isinstance(error, ValidationError)
    assert error.code == "type_error.string"

    content = b"foo: [bar, baz]"
    value, error_messages = validate_yaml(content, MySchema)

# Generated at 2022-06-22 06:24:20.425818
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "a:\n  b:\n    c: 30\n    d: 30\n"
    from typesystem import Schema, fields
    from typesystem import ValidationError, ValidationErrors
    from typesystem.types import Integer


# Generated at 2022-06-22 06:24:29.683320
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import pytest
    from typesystem.fields import String, Integer, Float, Boolean, NoneType

    content = """
a: 1
b: "asd"
c: true
d: false
e: null
f: 3.14
"""

    token = tokenize_yaml(content)
    validator = Schema(fields={"a": Integer(min_value=0), "b": String(), "c": Boolean(), "d": Boolean(), "e": NoneType(), "f": Float()})
    value, error = validate_yaml(content, validator)
    assert token.as_dict() == {"a": 1, "b": "asd", "c": True, "d": False, "e": None, "f": 3.14}
    assert not error


# Generated at 2022-06-22 06:24:37.029160
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    token = tokenize_yaml(b"{a: b}")
    assert isinstance(token, DictToken)
    assert token.content == "{a: b}"
    assert token.start_index == 0
    assert token.end_index == 5
    assert token.value == {"a": "b"}

    token = tokenize_yaml(b"{a: {b: c}}")
    assert isinstance(token, DictToken)
    print(token)



# Generated at 2022-06-22 06:24:47.908671
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_txt = """
    yaml:
        - name: James
          age: 21
        - name: Adam
          age: 22
        - name: John
          age: 23"""
    token = tokenize_yaml(yaml_txt)
    assert token.start == 0
    assert token.end == len(yaml_txt) - 1
    assert isinstance(token.content, str)
    assert token.content == yaml_txt
    assert isinstance(token.value, dict)
    assert list(token.value.keys()) == ["yaml"]
    assert len(token.value["yaml"]) == 3

    for item in token.value["yaml"]:
        assert isinstance(item, DictToken)
        assert len(item.value) == 2

# Generated at 2022-06-22 06:25:00.095313
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Boolean

    class ExampleSchema(Schema):
        name = String(max_length=20)
        age = Integer(minimum=1, maximum=100)
        is_active = Boolean(default=True)

    result = validate_yaml(
        content='name: "Jim"\nage: 50\nis_active: false', 
        validator=ExampleSchema
    )
    value = result[0]
    assert value["name"] == "Jim"
    assert value["age"] == 50
    assert value["is_active"] == False


# Generated at 2022-06-22 06:25:10.095551
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.tokens import ScalarToken
    token = tokenize_yaml("foobar\n")
    assert isinstance(token, ScalarToken)
    assert token.value == "foobar"
    assert token.char_start == 0
    assert token.char_end == 6
    assert token.line_no == 1
    assert token.column_no == 1
    assert token.column_end == 8

# Generated at 2022-06-22 06:25:20.295314
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    - a:
        - b: c
        - c: d
    - a: c
    - a:
        - b:
            - c: d
    - a:
        - b:
            - c: d
            - d: e
    '''
    class ListSchema(Schema):
        items = [
            {
                "a": [{"b": [{"c": str}]}]
            },
            {"a": str},
            {
                "a": [
                    {
                        "b": [
                            {
                                "c": str,
                                "d": str,
                            }
                        ]
                    }
                ]
            },
        ]
    result = validate_yaml(content, ListSchema)

# Generated at 2022-06-22 06:25:32.519412
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        first_name = fields.String()
        last_name = fields.String()
        date_joined = fields.DateTime()

    content = b"""
    first_name: Sam
    last_name: Smith
    date_joined: "2018-03-03"
    """
    errors = validate_yaml(content, UserSchema())
    assert len(errors) == 0
    content = b"""
    first_name: Sam
    last_name: Smith
    date_joined: 03-03-2018
    """
    errors = validate_yaml(content, UserSchema())
    assert len(errors) == 1
    assert errors[0].code == "value_error.date"
    assert errors[0].position.line_no == 4
    assert errors[0].position.column_

# Generated at 2022-06-22 06:25:45.706114
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    content = '''
    root:
      hello: world
      foo:
        bar: baz
    '''
    token = tokenize_yaml(content)
    assert token.get("root").get("hello").value == "world"
    assert token.get("root").get("foo").get("bar").value == "baz"
    assert token.get("root").get("foo").get("bar").start == len('''
    root:
      hello: world
      foo:
        ''')
    assert token.get("root").get("foo").get("bar").end == len('''
    root:
      hello: world
      foo:
        bar: ''')

    content = "blah"
    token = tokenize_y

# Generated at 2022-06-22 06:25:55.925406
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    name: John
    age: 45
    """)
    assert token.start == 0
    assert token.end == 44
    assert token.start == token.start_pos.char_index
    assert token.end == token.end_pos.char_index
    assert token.end_pos.line_no == 3
    assert token.end_pos.column_no == 1
    assert token.data == {"age": 45, "name": "John"}
    assert token.position == (1, 1)
    assert token.values() == [("name", 1, 5), ("John", 2, 5), ("age", 4, 4), (45, 5, 4)]

# Generated at 2022-06-22 06:26:06.760231
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None

    assert isinstance(tokenize_yaml(""), ScalarToken)
    assert isinstance(tokenize_yaml("hello"), ScalarToken)
    assert isinstance(tokenize_yaml("%YAML 1.2"), ScalarToken)
    assert isinstance(tokenize_yaml("42"), ScalarToken)
    assert isinstance(tokenize_yaml("42.5"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance

# Generated at 2022-06-22 06:26:12.464276
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    with open('test/test_data/test.yaml', 'r') as stream:
        content = stream.read()
    with open('test/test_data/test.json', 'r') as stream:
        expected = stream.read()
    assert json.dumps(tokenize_yaml(content), cls=JSONEncoder) == expected
 

# Generated at 2022-06-22 06:26:23.520798
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('1') == ScalarToken(value=1, start=0, end=0, content='1')
    assert tokenize_yaml('"test"') == ScalarToken(value="test", start=0, end=5, content='"test"')
    assert tokenize_yaml('true') == ScalarToken(value=True, start=0, end=3, content='true')
    assert tokenize_yaml('false') == ScalarToken(value=False, start=0, end=4, content='false')
    assert tokenize_yaml('null') == ScalarToken(value=None, start=0, end=3, content='null')
    assert tokenize_yaml('{}') == DictToken(value={}, start=0, end=1, content='{}')

# Generated at 2022-06-22 06:26:35.890526
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = {
        "title": "Person",
        "type": "object",
        "properties": {
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "age": {"type": "integer"},
            "aliases": {
                "type": "array",
                "items": {"type": "string"},
            }
        }
    }
    document = """
    first_name: Anthony
    last_name: Ausinger
    age: 30
    aliases:
    - Tony
    - Anto
    - Ant
    """
    vv = Schema(schema)
    vv.validate(document)
    assert not vv.errors
    value = vv.window(document)
    assert value["first_name"] == "Anthony"

# Generated at 2022-06-22 06:26:47.497898
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    example_string = b"""
    root:
      level_1:
        level_2:
          level_3:
            level_4:
              level_5:
                level_6:
                  level_7:
                    level_8:
                      level_9:
                        level_10:
                          - 1
                          - 2
                          - 3
    """
    example_token = tokenize_yaml(example_string)
    assert isinstance(example_token, DictToken)
    assert isinstance(example_token[0], DictToken)
    assert isinstance(example_token[0][0], DictToken)
    assert isinstance(example_token[0][0][0], DictToken)
    assert isinstance(example_token[0][0][0][0], DictToken)

# Generated at 2022-06-22 06:27:02.258920
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert_equals(
        tokenize_yaml(""),
        ParseError(text="No content.", code="no_content", position=Position(column_no=1, line_no=1, char_index=0))
    )

    assert_equals(
        tokenize_yaml("|"),
        ParseError(text="could not find expected ':'", code="parse_error", position=Position(column_no=2, line_no=1, char_index=1))
    )

    assert_equals(
        tokenize_yaml("["),
        ParseError(text="unexpected end of stream", code="parse_error", position=Position(column_no=2, line_no=1, char_index=1))
    )


# Generated at 2022-06-22 06:27:14.487241
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    validator = Person()

    content = """
        name: mattt
    """
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "mattt"}
    assert errors == []

    content = """
        name: mattt
        age: 29
    """
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "mattt"}
    assert len(errors) == 1
    error = errors[0]
    assert error.code == "type_error"
    assert error.text == "Invalid type: expected <str>."

# Generated at 2022-06-22 06:27:26.335317
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    To use this function, run `pytest tests.py` under the project directory.
    """
    # Test ScalarToken
    assert isinstance(tokenize_yaml('''"Hello, world!"'''), ScalarToken)
    assert isinstance(tokenize_yaml('"Hello, world!"'), ScalarToken)
    assert isinstance(tokenize_yaml('''"8"'''), ScalarToken)
    assert isinstance(tokenize_yaml('''"8.8"'''), ScalarToken)
    assert isinstance(tokenize_yaml('''"true"'''), ScalarToken)
    assert isinstance(tokenize_yaml('''"true"'''), ScalarToken)
    assert isinstance(tokenize_yaml('''"null"'''), ScalarToken)

    # Test ListToken

# Generated at 2022-06-22 06:27:31.096487
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken, ScalarToken

    class TestSchema(Schema):
        age = Integer()

        class Meta:
            strict = True

    yaml_content = """
    age: 23
    """

    errors = validate_yaml(yaml_content, TestSchema)
    assert errors == []

    yaml_content = """
    age: age
    """

    errors = validate_yaml(yaml_content, TestSchema)
    assert len(errors) == 1
    assert isinstance(errors[0].token, ScalarToken)
    assert errors[0].messages[0].code == "value_error.integer"


# Generated at 2022-06-22 06:27:38.859387
# Unit test for function validate_yaml
def test_validate_yaml():
    #  test for schema validation - validate_yaml()
    assert validate_yaml(content=b"a:b", validator=str) == ("a", "")
    assert validate_yaml(content=b"a:b:\n-c:\n -d", validator=str) == ("a", "")

if __name__ == "__main__":
    #  test for function validate_yaml
    test_validate_yaml()

# Generated at 2022-06-22 06:27:48.982403
# Unit test for function validate_yaml
def test_validate_yaml():
    # Check that it raises ParseErrors for invalid YAML.
    def check_parse_error(content, message, column_no, line_no, char_index):
        _, messages = validate_yaml(content, Field(int, default=1))
        assert len(messages) == 1
        assert messages[0].text == message
        assert messages[0].position.column_no == column_no
        assert messages[0].position.line_no == line_no
        assert messages[0].position.char_index == char_index

    check_parse_error(content="", message="No content.", column_no=1, line_no=1, char_index=0)

# Generated at 2022-06-22 06:27:50.394323
# Unit test for function validate_yaml
def test_validate_yaml():
    # TO DO
    # test_validate_yaml()
    return None



# Generated at 2022-06-22 06:28:02.036532
# Unit test for function tokenize_yaml

# Generated at 2022-06-22 06:28:13.263699
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, start=0, end=1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], start=0, end=1, content="[]")
    assert tokenize_yaml("foo") == ScalarToken("foo", start=0, end=2, content="foo")
    assert tokenize_yaml("123") == ScalarToken(123, start=0, end=2, content="123")
    assert tokenize_yaml("123.45") == ScalarToken(
        123.45, start=0, end=5, content="123.45"
    )
    assert tokenize_yaml("true") == ScalarToken(
        True, start=0, end=3, content="true"
    )
    assert tokenize

# Generated at 2022-06-22 06:28:20.592271
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    age: 27
    job: Scientist
    """
    token = tokenize_yaml(content)
    assert token.value == {'age': 27, 'job': 'Scientist'}
    assert token.start == 2
    assert token.end == 46
    assert token.value['age'].start == 13
    assert token.value['age'].end == 15
    assert token.value['job'].start == 27
    assert token.value['job'].end == 36
