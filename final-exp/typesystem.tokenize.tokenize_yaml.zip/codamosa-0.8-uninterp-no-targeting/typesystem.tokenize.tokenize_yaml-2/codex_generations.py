

# Generated at 2022-06-22 06:18:41.606158
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("hello") == 'hello'

# Generated at 2022-06-22 06:18:49.396071
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Enum, Integer
    from typesystem.structures import Dict

    schema = Schema([
        Enum("type",  enum=["full", "trial"], required=True, strict=True),
        Dict("details", fields={
            "title": String(),
            "publication_date": Integer()
        }, required=True)
    ], strict=True)

    yaml = """\
    type: foo
    details:
      title: ''
      publication_date: 'test'
    """

    status, errors = validate_yaml(yaml, validator=schema)
    assert status is False
    assert len(errors) == 3

# Generated at 2022-06-22 06:18:57.820238
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    '''
    This function tests the tokenize_yaml function which parses a given string
    and returns string tokens.
    '''
    # Test case for a string token
    assert tokenize_yaml("hi") == ScalarToken("hi", 0, 1, "hi")
    # Test case for a list token
    assert tokenize_yaml("[1, 2, 3]") == ListToken([1, 2, 3], 0, 8, "[1, 2, 3]")
    # Test case for a dict token
    assert tokenize_yaml("{'hi':1}") == DictToken({'hi':1}, 0, 7, "{'hi':1}")


# Generated at 2022-06-22 06:18:59.115772
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # TODO: Test here
    assert True

# Generated at 2022-06-22 06:19:10.872549
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    value = tokenize_yaml("""
             mappings:
                 - key1: val1
                   key2: val2
             scalars:
                 - scalar1
                 - scalar2
                 - 123
              """)
    assert isinstance(value, DictToken)
    assert len(value.mapping) == 2
    mappings = value["mappings"]
    assert isinstance(mappings, ListToken)
    assert len(mappings) == 1
    mapping = mappings[0]
    assert isinstance(mapping, DictToken)
    assert len(mapping.mapping) == 2
    assert mapping["key1"] == "val1"
    assert mapping["key2"] == "val2"
    scalars = value["scalars"]
    assert isinstance(scalars, ListToken)

# Generated at 2022-06-22 06:19:22.559418
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = CharField(max_length=100)
        age = IntegerField(minimum=0, maximum=150)
        friends = ListField(CharField(max_length=100))

    content = (
        """name: Freddie
        age: 30
        friends:
        - Brian
        - Roger
        - John
        """
    )
    value = validate_yaml(content, Person)
    assert value == (
        {"name": "Freddie", "age": 30, "friends": ["Brian", "Roger", "John"]},
        [],
    )

    class Person(Schema):
        name = CharField(max_length=100)
        age = IntegerField(minimum=0, maximum=150)
        friends = ListField(CharField(max_length=100))


# Generated at 2022-06-22 06:19:33.360286
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    
    # Test valid yaml input
    assert isinstance(tokenize_yaml(""), DictToken)
    assert isinstance(tokenize_yaml("a: 1"), DictToken)
    assert isinstance(tokenize_yaml("a: 1\nb: 2"), DictToken)
    assert isinstance(tokenize_yaml("[1, 2]"), ListToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)

    # Test invalid yaml input
    with pytest.raises(ParseError):
        tokenize_yaml("{")

    # Test valid YAML input with a ParseError edge case
    with pytest.raises(ParseError):
        tokenize_yaml("a:")



# Generated at 2022-06-22 06:19:44.481592
# Unit test for function validate_yaml
def test_validate_yaml():
    # Valid YAML.
    _, errors = validate_yaml(
        """\
first_name: John
last_name: Doe
age: 30
is_staff: true
""",
        {
            "first_name": "typesystem.String",
            "last_name": "typesystem.String",
            "age": "typesystem.Number",
            "is_staff": "typesystem.Boolean",
        },
    )
    # Valid, but unknown key.

# Generated at 2022-06-22 06:19:47.725272
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_input = """
    list:
      - item: 1234
      - item: true
    """
    yaml_output = {'list': [{'item': 1234}, {'item': True}]}
    assert tokenize_yaml(yaml_input) == yaml_output

# Generated at 2022-06-22 06:20:00.320824
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    res = tokenize_yaml('foo')
    assert res.value == 'foo'
    assert res.start == 0
    assert res.end == 2
    assert res.content == 'foo'
    res = tokenize_yaml('foo: bar')
    assert res.value['foo'] == 'bar'
    assert res.start == 0
    assert res.end == 7
    assert res.content == 'foo: bar'
    res = tokenize_yaml('- foo')
    assert res.value == ['foo']
    assert res.start == 0
    assert res.end == 5
    assert res.content == '- foo'
    res = tokenize_yaml('')
    assert len(res) == 0
    assert res.content == ''

# Generated at 2022-06-22 06:20:13.225908
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("[]") == ListToken([], 0, 1)
    assert tokenize_yaml("123") == ScalarToken(123, 0, 2)
    assert tokenize_yaml("'123'") == ScalarToken("123", 0, 4)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3)
    assert tokenize_yaml("123.456") == ScalarToken(123.456, 0, 6)

# Generated at 2022-06-22 06:20:18.727031
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = b'''
    bob:
      name: Bob
      age: 123
      is-alive: true
    '''
    token = tokenize_yaml(content)
    assert token.to_primitive() == {
        'bob': {'age': 123, 'name': 'Bob', 'is-alive': True}
    }



# Generated at 2022-06-22 06:20:29.438354
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert type([1,2]) == type(tokenize_yaml('[1, 2]'))
    assert type({'a': 1}) == type(tokenize_yaml('{a: 1}'))
    assert type(1.0) == type(tokenize_yaml('1.0'))
    assert type(True) == type(tokenize_yaml('true'))
    assert type(True) == type(tokenize_yaml('false'))
    assert type(None) == type(tokenize_yaml('null'))
    assert type('') == type(tokenize_yaml('""'))
    assert type('') == type(tokenize_yaml("''"))


# Generated at 2022-06-22 06:20:34.316744
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('hello: world')
    assert(token.token_at_char(0) == token)
    assert(token.token_at_char(4) == token['hello'])
    assert(token.token_at_char(12) == token['hello'])
    assert(token.token_at_char(22) == token['hello']['v'])

# Generated at 2022-06-22 06:20:40.771353
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """Test for function tokenize_yaml"""
    token = tokenize_yaml("""
    ---
    name: sample
    attr:
      - 1
      - 2
      - 3
    """)
    assert token.value == {
        "name": "sample",
        "attr": [1, 2, 3]
    }



# Generated at 2022-06-22 06:20:48.362086
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), ScalarToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("1.1"), ScalarToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)



# Generated at 2022-06-22 06:20:55.311561
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert (
        tokenize_yaml("") == ""
    ), "Expected empty string to return ''. Got: " + tokenize_yaml("")
    assert (
        tokenize_yaml("foo: bar") == DictToken({"foo": "bar"}, 0, 10)
    ), "Expected 'foo: bar' to return dict token. Got: " + str(tokenize_yaml("foo: bar"))



# Generated at 2022-06-22 06:21:07.357023
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    token = tokenize_yaml("this: a value")
    assert token.value == {"this": "a value"}
    assert token.start_char == 0
    assert token.end_char == 12

    token = tokenize_yaml("this: a value\nother_value: {x: 1}")
    assert token.value == {"this": "a value", "other_value": dict(x=1)}
    assert token.start_char == 0
    assert token.end_char == 30

    token = tokenize_yaml("""
this: "a multiline \\n string"
other_value: {x: 1}
    """)

# Generated at 2022-06-22 06:21:19.374289
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    token = tokenize_yaml('"Hello World"')
    assert 'Hello World' == token.value
    token = tokenize_yaml('42')
    assert 42 == token.value
    token = tokenize_yaml('3.14')
    assert 3.14 == token.value
    token = tokenize_yaml('true')
    assert True == token.value
    token = tokenize_yaml('false')
    assert False == token.value
    token = tokenize_yaml('null')
    assert None == token.value
    token = tokenize_yaml('["a", 42]')
    assert isinstance(token, ListToken)
    assert ['a', 42] == token.value

# Generated at 2022-06-22 06:21:31.032678
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    content = """
    a: 1
    b: 2
    c: 3
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert len(token.value) == 3
    assert isinstance(list(token.value.items())[0][1], ScalarToken)
    assert list(token.value.items())[0][1].value == 1

    # Test integer
    class IntegerSchema(Schema):
        value = Field(type=int)

    token = tokenize_yaml("1")
    (value, messages) = validate_with_positions(token=token, validator=IntegerSchema)
    assert len(messages) == 0

# Generated at 2022-06-22 06:21:46.026357
# Unit test for function validate_yaml
def test_validate_yaml():
    # Check case with no error
    data = '''
    a: 1
    b: 2
    '''
    schema = """
    type: object
    properties:
      a:
        type: integer
      b:
        type: integer
    """
    value, error_messages = validate_yaml(data, schema)
    assert error_messages is None

    # Check case with error
    data = '''
    a: 1
    b: 2
    '''
    schema = """
    type: object
    properties:
      a:
        type: integer
      b:
        type: string
    """
    value, error_messages = validate_yaml(data, schema)

# Generated at 2022-06-22 06:21:53.651512
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer
    from typesystem.base import ErrorMessage

    class Person(Schema):
        age = Integer(minimum=0, maximum=150)

    content = "age: -1"
    value = validate_yaml(content, validator=Person)

    assert value.value is None
    assert value.messages[0] == ErrorMessage(
        text="Must be greater than or equal to 0.",
        code="minimum",
        position=Position(column_no=5, line_no=1, char_index=4),
    )



# Generated at 2022-06-22 06:21:59.943480
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        key: value
        key2: value2
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert len(token.value) == 2
    assert token.value[0].value == "value"
    assert token.value[0].key == "key"
    assert token.value[1].value == "value2"
    assert token.value[1].key == "key2"

# Generated at 2022-06-22 06:22:10.929567
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test empty string
    content = ""
    try:
        token = tokenize_yaml(content)
        assert False, 'tokenize_yaml("") should have raised an error'
    except ParseError:
        pass

    # Test valid YAML
    content = """
    hello: world
    num: 42
    """
    expected = {'hello': 'world', 'num': 42}
    token = tokenize_yaml(content)
    assert token == expected, 'tokenize_yaml("""\nhello: world\nnum: 42\n""")'

    # Test invalid YAML
    content = "hello there"

# Generated at 2022-06-22 06:22:22.025100
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("a: b")
    assert tokenize_yaml("a: 3.2")
    assert tokenize_yaml("a: ~")
    assert tokenize_yaml("a: null")
    assert tokenize_yaml("a: true")
    assert tokenize_yaml("a: false")
    assert tokenize_yaml("a: [1, 2, 3]")
    assert tokenize_yaml("a: {b: c, d: e}")
    assert tokenize_yaml("[1, 2, 3]")
    assert tokenize_yaml("{a: b, c: d}")


# Generated at 2022-06-22 06:22:30.407895
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 0, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 0, content="[]")
    # Scalar
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")
    assert tokenize_yaml("'foo'") == ScalarToken("foo", 0, 4, content="'foo'")
    assert tokenize_yaml('"foo"') == ScalarToken("foo", 0, 4, content='"foo"')
    assert tokenize_yaml("5") == ScalarToken(5, 0, 0, content="5")
    assert tokenize_yaml("5.0") == ScalarToken(5.0, 0, 2, content="5.0")

# Generated at 2022-06-22 06:22:41.802938
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.base import List, String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    class Family(Schema):
        last_name = String()
        members = List(Person)

    class Cast(Schema):
        family = List(Person)

    yaml_content = """
    family:
      - first_name: Homer
        age: "39"
      - first_name: Marge
        last_name: Simpson
        age: "36"
      - first_name: Lisa
        age: "8"
      - first_name: Bart
        age: "10"
      - first_name: Maggie
        age: "1"
    """

    errors = validate_yaml(yaml_content, Cast)

# Generated at 2022-06-22 06:22:52.684496
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Can parse a scalar YAML value
    token = tokenize_yaml("2")
    assert token.type == "scalar"
    assert token.value == 2

    # Can parse a list YAML value
    token = tokenize_yaml("- 1\n- 2")
    assert token.type == "list"
    assert token.value == [1, 2]

    # Can parse a dict YAML value
    token = tokenize_yaml("a: 1\nb: 2")
    assert token.type == "dict"
    assert token.value == {"a": 1, "b": 2}

    # Can handle the corner case where the value is an empty string
    with pytest.raises(ParseError) as exc_info:
        tokenize_yaml("")

# Generated at 2022-06-22 06:22:58.462638
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("foo: 123"), DictToken)

    try:
        tokenize_yaml("{")
    except ParseError as exc:
        assert exc.code == "parse_error"

    try:
        tokenize_yaml("")
    except ParseError as exc:
        assert exc.code == "no_content"


# Generated at 2022-06-22 06:23:09.723811
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        name="Person",
        fields=[
            Field(name="first_name", type="string"),
            Field(name="last_name", type="string"),
            Field(name="age", type="integer"),
        ],
    )

    content = """\
    last_name: 'Brown'
    first_name: 'John'
    age: '37'
    """

    result, errors = validate_yaml(content=content, validator=schema)

    assert result == {
        "first_name": "John",
        "last_name": "Brown",
        "age": 37,
    }


# Generated at 2022-06-22 06:23:21.040235
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import types

    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = types.String(max_length=2)
        age = types.Integer(minimum=18)

    content = """
    name: 'bob'
    age: 23
    """
    value, error_messages = validate_yaml(content, UserSchema)
    assert value == {"name": "bob", "age": 23}
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must have no more than 2 characters."
    assert error_messages[0].code == "max_length"

    content = """
    name: 'bobby'
    age: 15
    """

# Generated at 2022-06-22 06:23:30.130513
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test for empty string
    with pytest.raises(ParseError):
        tokenize_yaml("")

    # test for scalar values
    assert tokenize_yaml("'hi'") == ScalarToken("hi", 0, 3, content="'hi'")
    assert tokenize_yaml("23") == ScalarToken(23, 0, 2, content="23")
    assert tokenize_yaml("23.3") == ScalarToken(23.3, 0, 4, content="23.3")
    assert tokenize_yaml("False") == ScalarToken(False, 0, 5, content="False")
    assert tokenize_yaml("hi") == ScalarToken("hi", 0, 2, content="hi")

    # test for lists

# Generated at 2022-06-22 06:23:40.934555
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "foo:\n  bar:\n    - 1\n    - 2\n    - 3\n"
    token = tokenize_yaml(content)

    assert isinstance(token, DictToken)
    assert token.values == {"foo": {"bar": [1, 2, 3]}}

    # Test handling of a YAML parse error.
    content = "foo: bar: baz"
    position = Position(column_no=7, line_no=1, char_index=6)

    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml(content)

    assert excinfo.value.code == "parse_error"
    assert excinfo.value.position == position

    # Test handling of an empty string.
    content = ""

# Generated at 2022-06-22 06:23:46.544446
# Unit test for function validate_yaml
def test_validate_yaml():
    msg: typing.List[Message] = []
    content = "24"
    validate_yaml(content, Field(type=int))
    validate_yaml(content, Field(type=str))
    content = [1, 2, 3]
    validate_yaml(content, Field(type=list))
    content = {"name": "Homer Simpson"}
    validate_yaml(content, Field(type=dict))
    # print("validate_yaml test ok")

# Generated at 2022-06-22 06:23:52.660236
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        - foo:
            bar: baz
    """)
    assert isinstance(token, ListToken)
    assert isinstance(token.item, DictToken)
    assert token.item.items[0].key.value == "foo"
    assert token.item.items[0].value.value == "baz"


# Generated at 2022-06-22 06:24:01.609705
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Map
    content = """
    a: value
    another: value
    """
    assert type(tokenize_yaml(content)) is DictToken

    # List
    content = """
    - value
    - another value
    """
    assert type(tokenize_yaml(content)) is ListToken

    # String
    content = "A string value."
    assert type(tokenize_yaml(content)) is ScalarToken

    # Integer
    content = "42"
    assert type(tokenize_yaml(content)) is ScalarToken

    # Float
    content = "42.0"
    assert type(tokenize_yaml(content)) is ScalarToken

    # Boolean
    content = "true"
    assert type(tokenize_yaml(content)) is ScalarToken

    # Nil

# Generated at 2022-06-22 06:24:13.941193
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(b"123", int) == (123, [])
    assert (
        len(validate_yaml(b"123", str)[1]) > 0
    )  # validate_with_position raises error
    assert validate_yaml(b"1234", str) == ("1234", [])
    assert (
        len(validate_yaml(b"", int)[1] > 0)
    )  # validate_with_position raises error
    assert validate_yaml(b"", str) == ("", [])
    assert (
        len(validate_yaml(b"", float)[1] > 0)
    )  # validate_with_position raises error
    assert validate_yaml(b"1234.0", float) == (1234.0, [])

# Generated at 2022-06-22 06:24:25.613700
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("[foo, bar]") == ["foo", "bar"]
    assert tokenize_yaml("{foo: bar}") == {"foo": "bar"}

    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml('{foo: bar: foobar}')
    assert str(excinfo.value) == "Unexpected ':'."

    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml('{foo: "bar"''')
    assert str(excinfo.value) == "Unmatched quotes."

    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml('{foo: bar"')
    assert str(excinfo.value)

# Generated at 2022-06-22 06:24:31.869373
# Unit test for function tokenize_yaml
def test_tokenize_yaml():  # pragma: no cover
    assert yaml is not None, "'pyyaml' must be installed."

    assert isinstance(tokenize_yaml(""),  ScalarToken)
    assert isinstance(tokenize_yaml("-"), ListToken)
    assert isinstance(tokenize_yaml("foo: bar"), DictToken)



# Generated at 2022-06-22 06:24:38.671431
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_str = """
    a: 1
    b:
      c:
        - 1
        - 2
        - 3
    d: "d"
    """
    token = tokenize_yaml(yaml_str)
    print(token)
    print(token.to_python())
    print(token['a'])
    print(token['b']['c'][2])
    print(type(token['a']))



# Generated at 2022-06-22 06:25:00.215635
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # empty string raises ParseError
    with pytest.raises(ParseError) as err:
        tokenize_yaml("")
    assert err.value.text == "No content."
    assert err.value.code == "no_content"
    assert err.value.position == Position(line_no=1, column_no=1, char_index=0)
    # simple value
    token = tokenize_yaml("value")
    assert type(token) is ScalarToken
    assert token.value == "value"
    assert token.start == 0
    assert token.end == 4
    assert token.content == "value"
    assert token.get_position(0) == Position(line_no=1, column_no=1, char_index=0)

# Generated at 2022-06-22 06:25:05.718697
# Unit test for function tokenize_yaml

# Generated at 2022-06-22 06:25:07.600641
# Unit test for function validate_yaml
def test_validate_yaml():
    # First assert that the function is in fact defined
    assert validate_yaml



# Generated at 2022-06-22 06:25:08.985937
# Unit test for function validate_yaml
def test_validate_yaml():
    assert isinstance(validate_yaml('{"name":"test"}', Field()), tuple)

# Generated at 2022-06-22 06:25:14.039985
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo:
        bar: baz
    """

    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {
        "foo": {
            "bar": "baz"
        }
    }



# Generated at 2022-06-22 06:25:21.088296
# Unit test for function validate_yaml
def test_validate_yaml():
    import json
    import sys

    content = "foo: 'bar'"

    validator = Field(type="string")

    try:
        value, error_messages = validate_yaml(content, validator)
    except ValidationError as error:
        print(json.dumps(error.as_dict(include_position=True), indent=4, sort_keys=True))
        sys.exit(1)

    if error_messages:
        print(json.dumps(error_messages, indent=4, sort_keys=True))
        sys.exit(1)

    print(json.dumps(value, indent=4, sort_keys=True))


# Generated at 2022-06-22 06:25:33.557105
# Unit test for function validate_yaml
def test_validate_yaml():
    def validator_factory(min: int, max: int) -> typing.Callable[[int], ValidationError]:
        def validator(value: int) -> ValidationError:
            if value < min or value > max:
                return ValidationError(
                    "{value} is not between {min} and {max}", code="out_of_range"
                )

        return validator

    assert validate_yaml(
        content="",
        validator=validator_factory(min=1, max=5),
    ) == (
        None,
        [
            Message(
                text="No content.",
                code="no_content",
                position=Position(line_no=1, column_no=1, char_index=0),
            )
        ],
    )


# Generated at 2022-06-22 06:25:38.873265
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = String()
        age = Integer()

    PersonSchema()
    content = textwrap.dedent(
        """
        name: Jane
        age: 20
    """
    )
    validate_yaml(content, PersonSchema)


# Generated at 2022-06-22 06:25:44.243180
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        field_one = True
        field_two = False

    try:
        validate_yaml("", MySchema)
    except ParseError:
        pass
    else:
        raise AssertionError("Expected ParseError")

# Generated at 2022-06-22 06:25:50.190073
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    class DummySchema(Schema):
        value = Field(type="string")
    content = """value: "abc" """
    value, error_messages = validate_yaml(content, validator=DummySchema)
    assert value == {"value": "abc"}
    assert len(error_messages) == 0



# Generated at 2022-06-22 06:26:06.653675
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer

    # Test basic parsing, with no validation
    token, error_messages = validate_yaml("name: Test, age: 30", String())

    
    assert (token.value == 'Test')
    # Test basic parsing, with no validation
    token, error_messages = validate_yaml("name: Test, age: 30", String())

    assert (token.value == 'Test')
    assert (error_messages == [])

    token, error_messages = validate_yaml("name: Test, age: 30", Integer())

    assert (error_messages != [])
    assert (error_messages[0].code == 'not_integer')

# Generated at 2022-06-22 06:26:18.412839
# Unit test for function validate_yaml
def test_validate_yaml():
    class VerboseSchema(Schema):
        name = "verbose"
        fields = [
            Field(key="name", required=True, primitive_type=str),
            Field(key="age", required=True, primitive_type=int),
            Field(key="favorite_colors", required=False, primitive_type=list),
        ]

    content = """
person:
  name: "Ryan Francis"
  age: 35
  favorite_colors:
    - red
    - green
    - blue
"""

    value, error_messages = validate_yaml(content=content, validator=VerboseSchema)

    assert value["name"] == "Ryan Francis"
    assert value["age"] == 35
    assert value["favorite_colors"] == ["red", "green", "blue"]

    # Error messages should

# Generated at 2022-06-22 06:26:29.617923
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test simple usage
    content = "a: 1\n"
    token = tokenize_yaml(content)
    assert token.value == {"a": 1}
    assert token.value_text == "a: 1"
    assert token.start == 0
    assert token.end == 3

    # test list
    content = "[1, 2, 3]"
    token = tokenize_yaml(content)
    assert token.value == [1, 2, 3]
    assert token.value_text == "[1, 2, 3]"
    assert token.start == 0
    assert token.end == 8

    # test indentation
    content = "- a: 1\n  b: 2\n- a: 3\n  b: 4"
    token = tokenize_yaml(content)

# Generated at 2022-06-22 06:26:33.266663
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    input = '{"key": "value"}'
    token = tokenize_yaml(input)
    print(token)
    assert type(token) == DictToken
    assert token.key_token == 'key'
    assert token.value_token == 'value'


# Generated at 2022-06-22 06:26:45.318509
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("""
    Hello:
      World:
        - 1
        - 2
        - 3
    """).is_equivalent(
        {
            "Hello": {
                "World": [
                    1,
                    2,
                    3,
                ],
            },
        }
    )

    assert_raises_with_message(
        ParseError,
        "Expected ':', found '-'.",
        tokenize_yaml,
        """
        - Hello
        - World
        """,
    )


# Generated at 2022-06-22 06:26:50.525249
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    This function is a unit test for function tokenize_yaml.
    This test will pass if YAML is parsed successfully.

    Returns:
        2: Success.
        3: Fail.
    """

    # Example 1
    example_1 = """
    x: 1
    y: 2
    z:
      - a
      - b
      - c
    """
    token_1 = tokenize_yaml(example_1)
    dict_token_1 = DictToken({'x': 1, 'y': 2, 'z': ["a", "b", "c"]}, \
    start=2, end=43, content=example_1)
    if token_1 == dict_token_1:
        return 2
    else:
        return 3

    # Example 2

# Generated at 2022-06-22 06:27:02.855003
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('{"key": "value", "list": [1, 2, 3]}') is not None
    assert tokenize_yaml('{"key": "value", "list": [1, 2, 3]}').dict_value is not None
    assert tokenize_yaml('{"key": "value", "list": [1, 2, 3]}').list_value is None
    assert tokenize_yaml('{"key": "value", "list": [1, 2, 3]}').int_value is None
    assert tokenize_yaml('{"key": "value", "list": [1, 2, 3]}').float_value is None
    assert tokenize_yaml('{"key": "value", "list": [1, 2, 3]}').str_value is None

# Generated at 2022-06-22 06:27:13.670271
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("foo"), ScalarToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("1.1"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml('"foo"'), ScalarToken)
    

# Generated at 2022-06-22 06:27:17.903547
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    content = """
    foo: bar
    baz: quux
    """
    token = tokenize_yaml(content)
    token.value
    assert token.value == {"foo": "bar", "baz": "quux"}, "Tokenizing failed"


# Generated at 2022-06-22 06:27:23.312524
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        a = Integer()
        b = String()

    errors, value = validate_yaml(
        b"""\
        a: 1
        b: hi
        """,
        validator=TestSchema,
    )

    assert not errors
    assert value == {"a": 1, "b": "hi"}

# Generated at 2022-06-22 06:27:42.067139
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    This function tests validate_yaml function.
    """
    try:
        content = """
            a: 1
            b:
            - 2
            - 3
        """
        schema = Schema({"a": int, "b": [int]})
        value, error_messages = validate_yaml(content, schema)
        assert value == {"a": 1, "b": [2, 3]}
        assert len(error_messages) == 0
    except Exception as e:
        print(e)


# Generated at 2022-06-22 06:27:50.215849
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Setup
    input_yaml_filepath = os.path.join(os.path.dirname(__file__), "sample.yml")
    with open(input_yaml_filepath) as f:
        input_yaml_content = f.read()

    token = tokenize_yaml(input_yaml_content)

    assert isinstance(token, DictToken)
    assert isinstance(token.value["name"], ScalarToken)
    assert token.value["name"].value == "John Doe"

    assert isinstance(token.value["age"], ScalarToken)
    assert token.value["age"].value == 42

    assert isinstance(token.value["hobbies"], ListToken)
    assert isinstance(token.value["hobbies"].value[0], ScalarToken)
    assert token.value

# Generated at 2022-06-22 06:28:01.666943
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(b"null") is None
    assert tokenize_yaml(b"false") is False
    assert tokenize_yaml(b"true") is True
    assert tokenize_yaml(b"123") == 123
    assert tokenize_yaml(b"1.2") == 1.2
    assert tokenize_yaml(b'"string"') == "string"
    assert tokenize_yaml(b"- 1") == [-1]
    assert tokenize_yaml(b"- 1\n- 2") == [-1, -2]
    assert tokenize_yaml(b"{}") == {}
    assert tokenize_yaml(b"{a: 1}") == {"a": 1}

# Generated at 2022-06-22 06:28:05.110868
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Object, fields

    class UserSchema(Schema):
        name = fields.String(max_length=100)
        age = fields.String()

    content = "age: notanumber\nname: jimmy"

    value, errors = validate_yaml(content=content, validator=UserSchema)

    assert errors
    assert "notanumber" not in value
    assert value["name"] == "jimmy"

# Generated at 2022-06-22 06:28:09.211068
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    test: value
    """
    token = tokenize_yaml(content)
    assert token
    assert token.content == content
    assert token.start_index == 2
    assert token.end_index == 15
    assert token["test"]
    assert isinstance(token["test"], ScalarToken)
    assert token["test"].value == "value"


# Unit tests for function validate_yaml

# Generated at 2022-06-22 06:28:19.974840
# Unit test for function validate_yaml
def test_validate_yaml():
    def test(
        content,
        validator,
        expected_value,
        expected_errors,
        expected_error_code=None):
        value, errors = validate_yaml(content, validator)
        assert value == expected_value
        assert len(errors) == len(expected_errors)
        for i, error in enumerate(errors):
            error_code = None
            if expected_error_code:
                error_code = expected_error_code[i]
            assert error == Message(
                code=error_code,
                text=expected_errors[i],
                position=Position(
                    char_index=i,
                    line_no=i,
                    column_no=i,
                ),
            )
