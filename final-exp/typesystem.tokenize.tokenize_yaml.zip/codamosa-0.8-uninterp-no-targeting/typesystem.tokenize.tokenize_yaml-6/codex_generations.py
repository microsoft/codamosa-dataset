

# Generated at 2022-06-22 06:18:38.830543
# Unit test for function validate_yaml
def test_validate_yaml():
    from .test_utils import assert_equals
    value, error_messages = validate_yaml(
        content="""
            a: b
            c: d
            e: f
        """,
        validator={"a": Field(type="string"), "c": Field(type="string")},
    )
    assert_equals(value, {"a": "b", "c": "d", "e": "f"})
    assert_equals(error_messages, [])



# Generated at 2022-06-22 06:18:42.409639
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
    title: Title
    text: Lorem ipsum
    '''
    token = tokenize_yaml(content)
    assert token == {'title': 'Title', 'text': 'Lorem ipsum'}



# Generated at 2022-06-22 06:18:48.958427
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"a": "integer", "b": "string"}, required=["a"])
    content = "a: 1 \n b:   3"
    assert validate_yaml(content, schema) == ({"a": 1, "b": "3"}, [])
    content = "a: 1 \n c: abc"
    value = validate_yaml(content, schema)
    assert isinstance(value[1][0], Message)
    assert value[1][0].code == "missing_required_field"
    assert value[1][0].position == Position(line_no=1, column_no=4, char_index=4)



# Generated at 2022-06-22 06:18:58.827514
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken, ScalarToken, Token

    class TestSchema(Schema):
        order = String(required=True)
        total = Integer(required=True)

    orders = """
- name: order1
  total: 12
- name: order2
  total: 2"""

    validate_yaml(orders, TestSchema)

    broken_orders = """
- name: order1
  total: 12
- name: order2
  total: "two"""

    value, errors = validate_yaml(broken_orders, TestSchema)


# Generated at 2022-06-22 06:19:10.616424
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()

    # Test for a valid YAML string
    content = "name: Manuj"
    validator = Person
    value, error_messages = validate_yaml(content, validator)
    assert value["name"] == "Manuj"
    assert not error_messages
  
    # Test for a invalid YAML string
    content = "name: Manuj\n address: New York"
    validator = Person
    value, error_messages = validate_yaml(content, validator)
    assert value["name"] == "Manuj"
    assert error_messages[0].text == "Unrecognized field 'address'."
    assert error_messages[0].code == "unrecognized_field"
    assert error_messages[0].position.line_no

# Generated at 2022-06-22 06:19:22.234953
# Unit test for function validate_yaml
def test_validate_yaml():
    class MessageSchema(Schema):
        type = "string"
        text = "string"
        has_url = "boolean"
    message = Message(type="error", text="Error message", has_url=False)
    message_yaml = yaml.dump(message.to_dict())
    assert message == MessageSchema.validate(content=message_yaml)

    class ErrorSchema(Schema):
        code = "integer"
        text = "string"
        position = "object"
        extra = "object"

# Generated at 2022-06-22 06:19:27.414789
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yamlStr = """
    name: ramesh
    age: 15
    """
    content = yaml.load(yamlStr,yaml.FullLoader)
    print(content)



# Generated at 2022-06-22 06:19:32.789351
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """{'name': 'Wynn', 'age': 30}"""
    schema = Schema({"name": str, "age": int})
    value, messages = validate_yaml(content, schema)
    assert messages == []
    assert value == {"name": "Wynn", "age": 30}



# Generated at 2022-06-22 06:19:42.881035
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: john\nage: 10"
    validator = Field(type="integer")

    value, errors = validate_yaml(content, validator)
    assert value == 10
    assert len(errors) == 0

    content = "name: john\nage: foo"
    value, errors = validate_yaml(content, validator)
    assert value is None
    assert len(errors) == 1

    content = "name: john\nage: null"
    value, errors = validate_yaml(content, validator)
    assert value is None
    assert len(errors) == 1

    content = "name: john\nage: 0xdeadbeef"
    value, errors = validate_yaml(content, validator)
    assert value is None
    assert len(errors) == 1


# Generated at 2022-06-22 06:19:51.846897
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("Hello") != None
    assert tokenize_yaml("Hello") == "Hello"
    assert tokenize_yaml("{}") != None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") != None
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("[1, 2, 3]") != None
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_yaml("{'a': 1, 'b': 2}") != None

# Generated at 2022-06-22 06:20:08.138255
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    {
        'name': 'John Doe',
        'age': 43,
        'address': {
            'street': '10 Downing Street',
            'city': 'London'
        },
        'spouse': null,
        'children': [],
        'pets': ['cat', 'dog'],
        'foo': [
            {'a': 'b'},
            {'c': 'd'}
        ]
    }
    """

    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert len(token.values) == 9

    assert token.values["name"] == "John Doe"
    assert token.values["age"] == 43
    assert token.values["spouse"] is None

# Generated at 2022-06-22 06:20:18.911885
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Structure
    from typesystem.tokenize.positional_validation import (
        build_token,
        ValueErrorInfo,
    )

    # Field validation error.
    content = """
    ---
    foo: 123
    """
    _, error_messages = validate_yaml(content, String(default="", min_length=5))
    assert error_messages == [
        Message(
            text="Value must be greater than or equal to 5 characters long.",
            code="min_length",
            position=Position(line_no=2, column_no=5, char_index=9),
        )
    ]

    # Field validation error with tokens.
    field = String(default="", min_length=5)

# Generated at 2022-06-22 06:20:31.363009
# Unit test for function validate_yaml
def test_validate_yaml():
    """Unit test for function validate_yaml"""
    import typesystem
    import typesystem.yaml

    schema = typesystem.Schema({"name": "name", "age": "number"})

    # Test basic happy path
    result = typesystem.yaml.validate_yaml("name: test\nage: 16", schema)
    assert result == ({'name': 'test', 'age': 16}, None)

    # Test parse error
    result = typesystem.yaml.validate_yaml("name: test\nage: '16'", schema)
    assert isinstance(result[1], list)
    assert len(result[1]) == 1
    assert isinstance(result[1][0], typesystem.ParseError)
    assert result[1][0].position.line_no == 2

# Generated at 2022-06-22 06:20:39.867426
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.structures import Dict

    class Person(Schema):
        name = String()
        age = Integer()
        position = Dict({"x": Integer(), "y": Integer()})

    content = """\
    name: Joe
    age: 33
    position:
      x: 1
      y: 2
    """
    value, errors = validate_yaml(content=content, validator=Person)
    assert value == {"name": "Joe", "age": 33, "position": {"x": 1, "y": 2}}
    assert errors == []

    content = """\
    name: Joe
    age: "33"
    """

# Generated at 2022-06-22 06:20:50.794642
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test that validated_yaml accepts str and bytes as input, correctly failing with a parse
    # error.
    with pytest.raises(ParseError) as exc_info:
        validate_yaml("1", typing.Any)
    assert exc_info.value.message == "Error parsing field 'root': No root mapping or sequence node found."
    with pytest.raises(ParseError) as exc_info:
        validate_yaml("123", typing.Any)
    assert exc_info.value.message == "Error parsing field 'root': No root mapping or sequence node found."
    with pytest.raises(ParseError) as exc_info:
        validate_yaml("True", typing.Any)
    assert exc_info.value.message == "Error parsing field 'root': No root mapping or sequence node found."

# Generated at 2022-06-22 06:20:59.709999
# Unit test for function validate_yaml
def test_validate_yaml():
    class AddressSchema(Schema):
        street = Field(type="string")
        city = Field(type="string")
        zip_code = Field(type="string")

    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        address = Field(type="dict", required=False, properties=AddressSchema)

    content = """
    name: Ryan
    age: 30
    address:
        street: Example Street
        city: San Francisco
        zip_code: '94103'
    """

    PersonSchema().validate(content)

# Generated at 2022-06-22 06:21:10.362266
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Text
    from typesystem.schemas import Schema

    class ContactSchema(Schema):
        name = Text()

    class ValidationError(Exception):
        pass


# Generated at 2022-06-22 06:21:21.641557
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = types.String()
        age = types.Integer(minimum=13)

    schema = PersonSchema()

    value, errors = validate_yaml(
        b"""
        name: Marcus
        age: 19
    """,
        schema,
    )

    assert errors is None, "Should have no errors"

    assert value == {
        "name": "Marcus",
        "age": 19,
    }

    value, errors = validate_yaml(
        b"""
        name: Marcus
        age: 12
    """,
        schema,
    )

    assert not errors is None, "Should have an error"
    

# Generated at 2022-06-22 06:21:31.486992
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert 'ListToken' == type(tokenize_yaml('[1, 2, 3]')).__name__
    assert 'DictToken' == type(tokenize_yaml('{1: 2}')).__name__
    assert 'DictToken' == type(tokenize_yaml('{}')).__name__
    assert 'DictToken' == type(tokenize_yaml('---\n{}\n...\n')).__name__
    assert 'DictToken' == type(tokenize_yaml('{1: 2, 3: 4}')).__name__
    with pytest.raises(ParseError):
        tokenize_yaml('')
    with pytest.raises(ParseError):
        tokenize_yaml('[')

# Generated at 2022-06-22 06:21:35.098254
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert type(tokenize_yaml('{"a": 1, "b": 2, "c": 3}')) is DictToken



# Generated at 2022-06-22 06:21:48.696236
# Unit test for function validate_yaml
def test_validate_yaml():
    good_yaml = b'{ "a": "b" }'
    schema = typesystem.Dictionary({"a": typesystem.String()})
    value, messages = validate_yaml(good_yaml, schema)
    assert value == {"a": "b"}
    assert not messages

    bad_yaml = b'{ "a": true }'
    schema = typesystem.Dictionary({"a": typesystem.String()})
    value, messages = validate_yaml(bad_yaml, schema)
    assert not value
    assert len(messages) == 1
    assert messages[0]["code"] == "invalid_type"



# Generated at 2022-06-22 06:21:57.982463
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Number

    class YAMLSchema(Schema):
        name = String()
        age = Number()

    content = "name: test\nage: 123"
    value, error_messages = validate_yaml(content, YAMLSchema())

    assert value == {"name": "test", "age": 123}
    assert error_messages == []

    value, error_messages = validate_yaml(content, YAMLSchema(strict=True))

    assert value == {"name": "test", "age": 123}
    assert error_messages == []

    value, error_messages = validate_yaml(content, Number())

    assert value == 123

# Generated at 2022-06-22 06:22:09.715788
# Unit test for function validate_yaml
def test_validate_yaml():
    # Schema for a list of integers
    class IntList(Schema):
        integers = fields.Array(items=fields.Integer())

    content = b"- 1\n- two\n- three\n- 4\n"
    value, errors = validate_yaml(content, IntList)

    # Expect a value of 4 elements, with 2 errors
    assert len(value) == 4
    assert len(errors) == 2

    # Expect 2 errors: one on 'two' and one on 'three'
    assert errors[0].field_name == "integers"
    assert errors[0].index == 1
    assert errors[0].text.startswith('Value "two" is not a valid integer.')
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 4


# Generated at 2022-06-22 06:22:22.468889
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None
    assert isinstance(tokenize_yaml("""{"one": 1}"""), DictToken)
    assert isinstance(tokenize_yaml("""- "one"\n- 1"""), ListToken)
    assert isinstance(tokenize_yaml("""1123"""), ScalarToken)
    assert isinstance(tokenize_yaml("""- 1123"""), ListToken)
    assert isinstance(tokenize_yaml("""- 1\n- 2"""), ListToken)
    assert isinstance(tokenize_yaml("""- 1\n- 2\n"""), ListToken)
    assert isinstance(tokenize_yaml("""- 1\n- 2\n\n"""), ListToken)

# Generated at 2022-06-22 06:22:28.888356
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    simple: list
    complex:
      -
        - a
        - b
      - [c, d]
    """
    token = tokenize_yaml(content)
    assert token == {
        "simple": "list",
        "complex": [["a", "b"], ["c", "d"]],
    }
    # Test error case
    with pytest.raises(ParseError):
        tokenize_yaml("invalid: invalid")


# Generated at 2022-06-22 06:22:41.266430
# Unit test for function tokenize_yaml

# Generated at 2022-06-22 06:22:47.984491
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("foo: bar"), DictToken)
    assert isinstance(tokenize_yaml("- bar"), ListToken)
    assert isinstance(tokenize_yaml("foo"), ScalarToken)
    assert isinstance(tokenize_yaml("'this is a string'"), ScalarToken)
    with pytest.raises(AssertionError):
        tokenize_yaml(b"my bytes")



# Generated at 2022-06-22 06:22:54.880140
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Valid YAML
    valid_yaml = """
    fname: John
    lname: Doe
    age: 42
    interest:
        - food
        - sex
    """
    assert isinstance(tokenize_yaml(valid_yaml), DictToken)
    # Missing colon
    missing_colon = """
    fname John
    lname: Doe
    age: 42
    interest:
        - food
        - sex
    """
    with pytest.raises(ParseError):
        tokenize_yaml(missing_colon)
    # Missing scalar value
    missing_value = """
    fname:
    lname: Doe
    age: 42
    interest:
        - food
        - sex
    """
    with pytest.raises(ParseError):
        tokenize

# Generated at 2022-06-22 06:23:04.261099
# Unit test for function validate_yaml
def test_validate_yaml():
    def validate_string(string, type_):
        value, errors = validate_yaml(string, type_)
        assert not errors, errors
        return value

    # a required integer field
    assert validate_string("1", Field(type="integer")) == 1

    # a required integer field with error
    assert validate_string("1.1", Field(type="integer")).error_dict == {
        "code": "invalid_type",
        "position": {
            "column_no": 2,
            "char_index": 1,
            "line_no": 1,
        },
        "text": "'1.1' is not of type 'integer'.",
    }

    # a required float field with error

# Generated at 2022-06-22 06:23:16.447137
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("[1,2,3]")
    assert isinstance(token, Token)
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3]
    assert token.start == 0
    assert token.end == 7
    assert token.content == "[1,2,3]"

    token = tokenize_yaml("{'a': 1}")
    assert isinstance(token, Token)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1}
    assert token.start == 0
    assert token.end == 7
    assert token.content == "{'a': 1}"

    token = tokenize_yaml("1")
    assert isinstance(token, Token)
    assert isinstance(token, ScalarToken)

# Generated at 2022-06-22 06:23:29.379929
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """---
    a: 1
    b:
        c: 1
        d: false
    e: [1,2,3]
    """
    token = tokenize_yaml(content)
    # First token is a scalar
    assert isinstance(token.children[0], ScalarToken)
    # Second token is a dict
    assert isinstance(token.children[1], DictToken)
    # Third token is a scalar
    assert isinstance(token.children[2], ScalarToken)


# Generated at 2022-06-22 06:23:32.824527
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
  assert yaml is not None, "'pyyaml' must be installed."

  content = '''
    test:
    - item: 1
    - item: 2
  '''
  assert tokenize_yaml(content) == {'test': [{'item': 1}, {'item': 2}]}


# Generated at 2022-06-22 06:23:44.588822
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "int: 2323\nfloat: 23.23\nbool: true\nnull: null"
    token = tokenize_yaml(content)
    assert isinstance(token, dict)
    assert (
        token["int"]
        == ScalarToken(
            "2323", start=0, end=5, content="int: 2323\nfloat: 23.23\nbool: true\nnull: null"
        )
    )
    assert (
        token["float"]
        == ScalarToken(
            "23.23",
            start=9,
            end=14,
            content="int: 2323\nfloat: 23.23\nbool: true\nnull: null",
        )
    )

# Generated at 2022-06-22 06:23:53.631904
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    fields = {"name": {"type": str}}
    schema = Schema(fields)
    content = """
        name: Joe
        age: 30
    """
    token = tokenize_yaml(content)

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=schema)

    assert token.content == content
    assert exc.value.code == "validation_error"
    assert exc.value.messages[0].content == "age"
    assert exc.value.messages[0].position.line_no == 3
    assert exc.value.messages[0].position.column_no == 1

# Generated at 2022-06-22 06:24:05.138102
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class AddressSchema(Schema):
        address = Field(type="string", max_length=40)
        city = Field(type="string")
        country = Field(type="string", enum=["USA", "Canada"])

    class CustomerSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer", optional=True)
        address = Field(type="object", schema=AddressSchema, optional=True)

    customer_yaml = yaml.dump(
        {
            "name": "Jean-Luc",
            "age": 42,
            "address": {"address": "1600 Amphitheatre Parkway", "city": "Mountain View", "country": "USA"},
        }
    )

    # Validate successfully

# Generated at 2022-06-22 06:24:16.455895
# Unit test for function validate_yaml
def test_validate_yaml():
    def validate(content: str, validator: Field) -> typing.Any:
        return validate_yaml(content, validator)

    def validate_schema(content: str, schema_cls: typing.Type[Schema]) -> typing.Any:
        return validate_yaml(content, schema_cls)

    class UserSchema(Schema):
        name = String(max_length=20)
        age = Integer()

    # Validation tests for validators.

    assert validate("my@email.com", Email()) == ("my@email.com", None)

    assert validate("myname", String()) == ("myname", None)

    assert validate("2017", Integer()) == (2017, None)

    assert validate("true", Boolean()) == (True, None)


# Generated at 2022-06-22 06:24:23.503176
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml function.
    """
    schema = typesystem.schema({"name": typesystem.string()})
    yaml_text = "---\n- name: a\n- name: b"
    value, error_messages = validate_yaml(yaml_text, schema)
    assert value == [{"name": "a"}, {"name": "b"}]
    assert len(error_messages) == 0



# Generated at 2022-06-22 06:24:30.938317
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, Text
    # Create schema
    class TestSchema(Schema):
        field1= Text()
        field2= Integer()
    # Create data
    data= """
    field1: new
    field2: 13
    """

    value, *error_messages= validate_yaml(data, validator=TestSchema)
    assert type(value) == dict
    assert value['field1'] == "new"
    assert value['field2'] == 13

    data= """
    field1: "list"
    field2: 1.2
    """

    value, error_messages= validate_yaml(data, validator=TestSchema)
    assert error_messages != []


# Generated at 2022-06-22 06:24:34.920640
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(
        '''
    example:
      0: 1
      1: 2
      2: 3
'''
    )
    assert token
    assert token.value == {"example": {"0": 1, "1": 2, "2": 3}}



# Generated at 2022-06-22 06:24:37.239932
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("name: Mark")
    assert token.value == {"name": "Mark"}



# Generated at 2022-06-22 06:24:52.122159
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem import Schema, fields

    class Pet(Schema):
        name = fields.String()
        age = fields.Integer()
        class_name = "Pet"

    error_messages = []

    # Test a valid YAML object
    content = """
    name: Widget
    age: 123
    """
    results = validate_yaml(content, validator=Pet)
    assert results[0] == {"name": "Widget", "age": 123}

    # Test missing fields
    content = """
    name: Widget
    """
    results = validate_yaml(content, validator=Pet)
    assert len(results[1]) == 1

# Generated at 2022-06-22 06:25:02.096224
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """\
        # A dictionary
        key1: value1
        key2: value2
        key3: value3
    """

    token = tokenize_yaml(content)

    assert token == {
        "key1": "value1",
        "key2": "value2",
        "key3": "value3",
    }

    assert isinstance(token, DictToken)
    token.start == 2
    token.end == 28

    # Test no content.
    try:
        tokenize_yaml("")
    except ParseError as error:
        assert error.text == "No content."
        assert error.code == "no_content"
        assert error.position.line_no == 1
        assert error.position.column_no == 1
        assert error.position.char_index == 0

# Generated at 2022-06-22 06:25:06.921246
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """\
# persons data
- name: "John"
  age: 32
- name: "Jane"
  age: 28
- name: "Tom"
  age: "28"
- name: "Jason"
  age: 99
"""
    validator = Schema([
        {
            "name": "name",
            "type": "string",
        },
        {
            "name": "age",
            "type": "integer",
        },
    ])
    value, errors = validate_yaml(content, validator)
    assert len(errors) == 1
    assert errors[0].type == "integer"
    assert errors[0].text == "Must be an integer."
    # Get the (line, column, character index) of the error.

# Generated at 2022-06-22 06:25:17.625835
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import Boolean, String, Integer, DateTime, List, Dict

    class AddressSchema(Schema):
        street_1 = String(title="Street 1")
        street_2 = String(title="Street 2", required=False)
        city = String(title="City")
        state = String(title="State")
        postal_code = String(title="Postal Code")
        country = String(title="Country")

    class ProfileSchema(Schema):
        name = String(title="Name")
        age = Integer(title="Age", minimum=0, maximum=120)
        email = String(title="Email", format="email")
        address = AddressSchema(title="Address")
        is_cool = Boolean(title="Is Cool")

# Generated at 2022-06-22 06:25:29.238696
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    name: John Doe
    age: 28
    """)
    assert isinstance(token, DictToken)
    assert token.content == """
    name: John Doe
    age: 28
    """
    assert token.start_index == 0
    assert token.end_index == 27

    token = tokenize_yaml('"string"')
    assert isinstance(token, ScalarToken)

    token = tokenize_yaml("42")
    assert isinstance(token, ScalarToken)

    token = tokenize_yaml("42.5")
    assert isinstance(token, ScalarToken)

    token = tokenize_yaml("true")
    assert isinstance(token, ScalarToken)

    token = tokenize_yaml("false")

# Generated at 2022-06-22 06:25:42.623441
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('{"foo": 1}').as_dict() == {"foo": 1}
    assert tokenize_yaml('[1]').as_list() == [1]
    assert tokenize_yaml('"foo"').as_scalar() == "foo"
    assert tokenize_yaml('')

    # Test position tracking
    yaml_content = '''
a:
  b:
    c: 3
'''
    token = tokenize_yaml(yaml_content)
    assert token.get_token("a", "b", "c").char_start == 31
    assert token.get_token("a", "b", "c").char_end == 32
    assert token.get_token("a", "b", "c").line_no == 3

# Generated at 2022-06-22 06:25:46.470494
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = open("../tests/test_data/test_yaml_input.yaml", "r").read()
    token = tokenize_yaml(content)
    assert token.__class__.__name__ == "DictToken"

# Generated at 2022-06-22 06:25:57.783099
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {
            "foo": "integer",
            "bar": "integer",
        }
    )

    assert validate_yaml(b"foo: 1\nbar: 2", validator=schema) == (
        {"foo": 1, "bar": 2},
        [],
    )

    assert validate_yaml(b"foo: 1.1\nbar: 2", validator=schema) == (
        {},
        [
            Message(
                text="Value '1.1' is not valid for field 'foo'",
                code="invalid",
                position=Position(3, 5, 3),
            )
        ],
    )


# Generated at 2022-06-22 06:26:06.791191
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    class MockYAMLLoader:
        def __init__(self, mapping):
            self.mapping = mapping

        def construct_mapping(self):
            return self.mapping

    class MockYAMLNode:
        def __init__(self, start, end):
            self.start_mark = start
            self.end_mark = end

    class MockYAMLMark:
        def __init__(self, index):
            self.index = index

    # Create a fake YAML object

# Generated at 2022-06-22 06:26:15.666443
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test valid YAML
    schema = Schema()
    schema.add_field("count", "integer", min=1, max=10)
    content = "count: 5"
    value, error_messages = validate_yaml(content, schema)
    assert value == 5

    # Test invalid YAML
    schema = Schema()
    schema.add_field("count", "integer", min=1, max=10)
    content = "count: a"
    value, error_messages = validate_yaml(content, schema)
    assert len(error_messages) == 1
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 8
    assert error_messages[0].position.char_index == 7
    assert error_

# Generated at 2022-06-22 06:26:25.485047
# Unit test for function validate_yaml
def test_validate_yaml():
    class SimpleSchema(Schema):
        name = "string"

    content = b"name: 'Dave'"
    validator = SimpleSchema()
    value, error_messages = validate_yaml(content=content, validator=validator)
    assert value == {"name": "Dave"}
    assert error_messages == []

# Generated at 2022-06-22 06:26:31.210926
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    hello:
      - 1
      - 2
      - 3
    """

    schema = typing.Dict[typing.Text, typing.List[int]]

    value, errors = validate_yaml(content, schema)

    assert value == {
        "hello": [1, 2, 3]
    }

    assert errors == []



# Generated at 2022-06-22 06:26:37.894046
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a:
       - 1
       - 2
       - "3"
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.keys == ["a"]
    assert isinstance(token.values["a"], ListToken)
    assert token.values["a"].items == [1, 2, "3"]



# Generated at 2022-06-22 06:26:48.266332
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("name: tarek\nage: 27\n")

    def check_token(
        token: Token,
        expected_start: int,
        expected_end: int,
        expected_content: str = None,
    ) -> None:
        assert isinstance(token, DictToken)
        assert token.start_pos == expected_start
        assert token.end_pos == expected_end
        if expected_content:
            assert token.content == expected_content

    check_token(token, expected_start=0, expected_end=23)
    assert "tarek" == token["name"].value
    assert 27 == token["age"].value

    check_token(token["name"], expected_start=7, expected_end=12)

# Generated at 2022-06-22 06:26:57.419169
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("string") == ScalarToken("string", 0, 6, content="string")
    assert tokenize_yaml("0") == ScalarToken(0, 0, 1, content="0")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")
    assert tokenize_yaml("[0, 1]") == ListToken([0, 1], 0, 5, content="[0, 1]")

# Generated at 2022-06-22 06:27:09.426713
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    dict:
      key1: hello
      key2: world
      key3:
        - foo
        - bar

    list:
      - baz
      - qux
      -
        - 123
        - true
        - null
    """

    result = tokenize_yaml(content)
    assert isinstance(result, DictToken)
    assert list(result) == ["dict", "list"]

    result_dict = result["dict"]
    assert isinstance(result_dict, DictToken)
    assert list(result_dict) == ["key1", "key2", "key3"]

    result_dict_key1 = result_dict["key1"]
    assert isinstance(result_dict_key1, ScalarToken)
    assert result_dict_key1.value == "hello"

   

# Generated at 2022-06-22 06:27:16.506385
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo: bar\n") == DictToken({"foo": "bar"}, 0, 9, content="foo: bar\n")
    assert (
        tokenize_yaml("- 1\n- 2\n")
        == ListToken([1, 2], 0, 6, content="- 1\n- 2\n")
    )
    assert tokenize_yaml("") == DictToken({}, content="")


# Generated at 2022-06-22 06:27:23.453329
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Schema
    from typesystem.message import StringArray
    from typesystem.tokenize.tokens import DictToken, ScalarToken

    class TestSchema(Schema):

        name = String()

    value, error_messages = validate_yaml("name: test", validator=TestSchema)
    assert isinstance(value, DictToken)
    assert value.children["name"] == ScalarToken("test")
    assert error_messages == StringArray()



# Generated at 2022-06-22 06:27:30.987990
# Unit test for function validate_yaml
def test_validate_yaml():
    class YAMLSchema(Schema):
        name = String()
        age = Integer()

    errors, data = validate_yaml('''\
name:
  first: Frank
  last: Schenk
age: 34
''', validator=YAMLSchema)
    assert not errors
    assert data['name'] == {'first': 'Frank', 'last': 'Schenk'}
    assert data['age'] == 34

# Generated at 2022-06-22 06:27:42.859582
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test yaml parsing
    assert tokenize_yaml("{1:2, 3:4}").value == {1: 2, 3: 4}
    assert tokenize_yaml("[1, 2, 3]").value == [1, 2, 3]
    assert tokenize_yaml("1").value == 1
    assert tokenize_yaml("1.0").value == 1.0
    assert tokenize_yaml("true").value == True
    assert tokenize_yaml("null").value == None
    # test exception case
    try:
        tokenize_yaml("{")
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0



# Generated at 2022-06-22 06:27:58.548103
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    args = {'argE': {'argF': 5},
            'argC': 5,
            'argD': True,
            'argA': '5',
            'argB': ['argB1', 'argB2', 'argB3']}

    schema = '''argA:
  type: string
  required: true
  default: 3
argB:
  type: list
  required: true
  default: []
argC:
  type: integer
  required: false
  default: 5
argD:
  type: boolean
  required: false
  default: false
argE:
  type: object
  required: false
  default: {}
  properties:
    argF:
      type: integer
      required: false
      default: 5'''


# Generated at 2022-06-22 06:28:10.089413
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = dict(
        name=str,
        age=int,
        friends=[dict(first_name=str, last_name=str)],
    )
    yaml_schema = """
    name: str
    age: int
    friends:
      - first_name: str
        last_name: str
    """
    data = {
        "name": "Example",
        "age": "toddler",
        "friends": [{"first_name": "Todd", "last_name": str}],
    }
    yaml_data = """
    name: Example
    age: toddler
    friends:
      - first_name: Todd
        last_name: str
    """
    _, messages = validate_yaml(data, schema)
    assert len(messages) == 1

# Generated at 2022-06-22 06:28:16.934496
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    dict_token = tokenize_yaml('{a: 1, b: 2, c: 3}')
    list_token = tokenize_yaml('[1, 2, 3]')
    scalar_token = tokenize_yaml('abc')
    assert dict_token == {'a': 1, 'b': 2, 'c': 3}
    assert list_token == [1, 2, 3]
    assert scalar_token == 'abc'

