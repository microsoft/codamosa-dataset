

# Generated at 2022-06-12 16:12:32.302218
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("1", "int") == (1, None)
    assert validate_yaml("a", "int") == (None, [Message('a is not a valid integer.', 'invalid_type', (), 1, 0, 0)])
    assert validate_yaml("a", "int[]") == (None, [Message('a is not a valid integer.', 'invalid_type', (), 1, 0, 0)])
    assert validate_yaml("[1, 2, 3]", "int") == (None, [Message('Expected a scalar value, got a list.', 'invalid_type', (), 1, 0, 0)])

# Generated at 2022-06-12 16:12:39.494065
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test the validate_yaml function
    """
    assert yaml is not None, "'pyyaml' must be installed."
    class Test1(Schema):
        foo = Validator(validators.String(max_length=3))
        bar = Validator(validators.Integer())


    content = "foo: jeff"
    validator = Test1
    value, errors = validate_yaml(content, validator)
    # we have to have a test case here as the coverage library is not correctly
    # identifying the line as covered
    assert False

# Generated at 2022-06-12 16:12:49.128817
# Unit test for function validate_yaml

# Generated at 2022-06-12 16:13:01.555890
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('') == None
    assert tokenize_yaml('{}') == DictToken(
        {}, start=0, end=1, content='{}')
    assert tokenize_yaml('[a, b, c]') == ListToken(
        ['a', 'b', 'c'], start=0, end=7, content='[a, b, c]')
    assert tokenize_yaml('some string') == ScalarToken(
        'some string', start=0, end=11, content='some string')
    assert tokenize_yaml('123') == ScalarToken(
        123, start=0, end=3, content='123')

# Generated at 2022-06-12 16:13:03.946534
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(b"a: b")
    assert token.value == {"a": "b"}



# Generated at 2022-06-12 16:13:05.210229
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('foo: bar') == {"foo": "bar"}

# Generated at 2022-06-12 16:13:14.761580
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    token = tokenize_yaml('[{"a":"b","c":{"d":[1,{"e":2},{"f":3}],"g":"h"}}]')
    assert token == [
        DictToken(
            {"a": "b", "c": DictToken({"d": [1, DictToken({"e": 2}), DictToken({"f": 3})], "g": "h"})},
            content='[{"a":"b","c":{"d":[1,{"e":2},{"f":3}],"g":"h"}}]',
            start=2,
            end=61,
        )
    ]



# Generated at 2022-06-12 16:13:17.631003
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    import yaml
    class MyValidator(Schema):
        name = String()
        age = Number()

    content = yaml.dump({"name": "joe", "age": 12})
    value, error_messages = validate_yaml(content, MyValidator)
    assert error_messages == []



# Generated at 2022-06-12 16:13:25.943342
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String, Boolean, Schema

    class UserSchema(Schema):
        name = String(min_length=2, max_length=50)
        age = Integer()
        bio = String(required=False)
        admin = Boolean(default=False)
    expected = UserSchema()
    actual = validate_yaml(
        b'name: "Bob"\nage: 42\nbio: "Just another human..."\nadmin: true\n', UserSchema()
    )
    assert expected.name.validate(actual[0]["name"])
    assert expected.age.validate(actual[0]["age"])
    assert expected.bio.validate(actual[0]["bio"])
    assert expected.admin.validate(actual[0]["admin"])



# Generated at 2022-06-12 16:13:35.262972
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    result = tokenize_yaml("{}")
    assert result.value == {}
    result = tokenize_yaml("{'key':'value'}")
    assert result.value == {'key':'value'}
    result = tokenize_yaml("['value1', 'value2']")
    assert result.value == ['value1', 'value2']
    result = tokenize_yaml("true")
    assert result.value == True
    result = tokenize_yaml("3.14")
    assert result.value == 3.14
    result = tokenize_yaml("4")
    assert result.value == 4
    result = tokenize_yaml("null")
    assert result.value == None



# Generated at 2022-06-12 16:13:50.105792
# Unit test for function validate_yaml
def test_validate_yaml():
	# Test valid YAML - returns value and no errors
	yaml_str = """
        a: 
            - 1
            - 2
            - 3
        b:
            x: hello
    """
	schema = Schema(
		properties={"a": List[int], "b": {"properties": {"x": str}}},
		additional_properties=False
	)
	return_val = validate_yaml(yaml_str, schema)
	assert isinstance(return_val, typing.Tuple)
	assert return_val[0] == {'a': [1, 2, 3], 'b': {'x': 'hello'}}
	assert not return_val[1]

	# Test invalid YAML - returns a tuple of errors and no value

# Generated at 2022-06-12 16:14:00.353379
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem
    import yaml

    yaml_data = """
            name: Ashutosh
            email: ashutosh@gmail.com
            dob: 2001-01-01
            age: 17
        """

    class TestSchema(typesystem.Schema):
        name = typesystem.String(max_length=5)
        email = typesystem.String(max_length=10)
        dob = typesystem.Date()
        age = typesystem.Integer()

    value, error_dict = validate_yaml(yaml_data, TestSchema)

# Generated at 2022-06-12 16:14:05.713174
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
- a: 1
- a: 2
- a: 3
    """
    validator = Field(type="integer")
    value, errors = validate_yaml(content, validator)
    print(value)
    print(errors)
    for error in errors:
        print(error.position, error.text)



# Generated at 2022-06-12 16:14:13.256595
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test Validate_YAML function
    """
    from typesystem import String

    string_field = String()  # type: ignore
    value, errors = validate_yaml("content", string_field)
    assert value == "content"
    assert errors == []

    value, errors = validate_yaml("content", String())
    assert value == "content"
    assert errors == []

    value, errors = validate_yaml("content", String(min_length=5))
    assert value == "content"
    assert errors == []

    value, errors = validate_yaml("", String(required=True))
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "required"

    value, errors = validate_yaml(b"content", string_field)

# Generated at 2022-06-12 16:14:18.353757
# Unit test for function validate_yaml
def test_validate_yaml():
    class PetSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    content = """
        - name: Fluffyy
          age: 3
        - name: Beth, age:
            - wrong_age
    """

    errors = validate_yaml(content, PetSchema.as_field())
    assert len(errors) == 7

# Generated at 2022-06-12 16:14:29.086955
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test Validate_yaml will validate a yaml file with a JSON schema"""
    name_schema = {
        "type": "object",
        "properties": {
            "firstname": {
                "type": "string",
                "minLength": 1
            },
            "lastname": {
                "type": "string",
                "minLength": 1
            }
        },
        "required": ["firstname", "lastname"]
    }
    validator = typesystem.from_json(name_schema)
    yaml_test_file = '''
        firstname: John
        lastname: Smith
    '''
    value, error_messages = validate_yaml(yaml_test_file, validator)
    assert len(error_messages) == 0

# Generated at 2022-06-12 16:14:29.911870
# Unit test for function validate_yaml
def test_validate_yaml():
    # TODO: add test
    pass

# Generated at 2022-06-12 16:14:42.036600
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem import String, Integer, Boolean

    field = String(min_length=1, max_length=10)
    value, errors = validate_yaml(b"foo", field)
    assert value == "foo"
    assert not errors

    value, errors = validate_yaml(b"", field)
    assert value is None
    assert errors[0].code == "min_length"

    field = Integer(minimum=-1, maximum=1)
    value, errors = validate_yaml(b"-1", field)
    assert value == -1
    assert not errors

    value, errors = validate_yaml(b"2", field)
    assert value is None
    assert errors[0].code == "maximum"

    field = Boolean()
    value

# Generated at 2022-06-12 16:14:44.979272
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    text = "foo: bar"
    schema = Schema({
        "foo": String()
    })
    valid = validate_yaml(text, schema)
    assert valid == ({'foo': 'bar'}, None), "validates ok"



# Generated at 2022-06-12 16:14:56.630738
# Unit test for function validate_yaml
def test_validate_yaml():
    class User(Schema):
        username_ = String(max_length=100)
        email = String(format="email")
        date_joined = DateTime()

    content = """
        username_: testuser1
        email: a.b@c.com
        date_joined: "2016-01-14T19:30:00+00:00"
    """

    value, errors = validate_yaml(content, User)
    assert not errors
    assert value.username_ == "testuser1"
    assert value.email == "a.b@c.com"
    assert value.date_joined == datetime.datetime(2016, 1, 14, 19, 30, 00)


# Generated at 2022-06-12 16:15:09.858648
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test the `validate_yaml` function.
    """
    from typesystem.schemas import Schema

    class ProductSchema(Schema):
        name = "string", ["required"]
        price = "number", ["required"]
        in_stock = "boolean", ["required"]

    validator = ProductSchema()
    price = "price"
    val = validate_yaml(
        b"""
        name: 'ferrari'
        price: 40
        in_stock: true
        """,
        validator,
    )
    assert val[0] == {
        "name": "ferrari",
        "price": 40,
        "in_stock": True,
    }
    assert val[1] == []

# Generated at 2022-06-12 16:15:21.319077
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    data:
      - name: Test
        quantity: 1
        price: 2.0
        created: "2019-01-01"
      - name: Test 2
        quantity: 2
        price: 5.0
        created: "2019-02-02"
    """
    schema_class = Schema.from_dict(
        {
            "data": [{
                "name": {"type": "string"},
                "quantity": {"type": "integer"},
                "price": {"type": "number"},
                "created": {"type": "datetime"}
            }]
        }
    )
    token = tokenize_yaml(content)


# Generated at 2022-06-12 16:15:28.581137
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"test": str})
    yaml_content = "test: test_test"
    result = validate_yaml(yaml_content, schema)
    assert result[0].get("test") == "test_test"
    assert result[1] == []
    yaml_content = "test: 1"
    result = validate_yaml(yaml_content, schema)
    assert result[0] == {}
    assert result[1][0].message == "May not be of type 'int'."

# Generated at 2022-06-12 16:15:34.853528
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String

    validator = String(max_length=4)

    success, errors = validate_yaml("foo", validator)
    assert not errors, "Expected no errors."
    assert success == "foo", "Expected 'foo' as the result."

    success, errors = validate_yaml("foobar", validator)
    assert errors
    assert len(errors) == 1
    error = errors[0]
    assert error.code == "max_length"



# Generated at 2022-06-12 16:15:46.242030
# Unit test for function validate_yaml
def test_validate_yaml():
    content: str = """
                a:
                    b: "test"
                c:
                    d:
                        - "test"
                        - "test"
                        - "test"
                    e: "test"
    """
    validator = Schema([
        Field(name="a", type="object"),
        Field(name="c", type="object"),
    ])
    expected_value: typing.Dict = {
        "a": {"b": "test"},
        "c": {
            "d": ["test", "test", "test"],
            "e": "test"
        }
    }
    assert validate_yaml(content, validator) == (expected_value, [])



# Generated at 2022-06-12 16:15:50.251337
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Unit test for function validate_yaml
    This function parses and validate a yaml string
    """
    validator = Schema()
    value, errors = validate_yaml(validator=validator, content="")
    assert value == errors == {}



# Generated at 2022-06-12 16:15:58.928963
# Unit test for function validate_yaml
def test_validate_yaml():
    # pylint: disable=line-too-long
    """Test that validate_yaml works as expected."""
    import typesystem

    # Simple parse success.
    validator = typesystem.String()
    value, errors = validate_yaml("string", validator)
    assert errors == []
    assert value == "string"

    # Simple parse failure.
    validator = typesystem.String()
    _, errors = validate_yaml("!!strin", validator)
    assert errors == [
        Message(
            text='did not find expected node content.',
            code='parse_error',
            position=Position(line_no=1, column_no=7, char_index=6),
        )
    ]

    # Simple validation failure.
    validator = typesystem.String(max_length=3)
   

# Generated at 2022-06-12 16:16:07.350781
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = "string"

    value, error_messages = validate_yaml("- hello", validator=MySchema)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 2
    assert (
        error_messages[0].text
        == "Value must be a string, found '-' (scalar type: int)"
    )



# Generated at 2022-06-12 16:16:19.099071
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        fields={"foo": {"type": "string"}, "bar": {"type": "integer"},}
    )

    def validate_yaml(data: str) -> typing.Tuple[typing.Any, typing.Any]:
        token = tokenize_yaml(data)
        return validate_with_positions(token=token, validator=schema)

    value, errors = validate_yaml("foo: 'hello'")
    assert value == {"foo": "hello"}
    assert len(errors) == 0

    value, errors = validate_yaml("foo: 'hello'\nbar: 3")
    assert value == {"foo": "hello", "bar": 3}
    assert len(errors) == 0


# Generated at 2022-06-12 16:16:29.915903
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(b"foo: bar")
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}
    assert token.start == 0
    assert token.end == 7
    assert token.content == "foo: bar"

    token = tokenize_yaml(b"[foo, bar]")
    assert isinstance(token, ListToken)
    assert token.value == ["foo", "bar"]
    assert token.start == 0
    assert token.end == 9
    assert token.content == "[foo, bar]"

    token = tokenize_yaml(b"foo")
    assert isinstance(token, ScalarToken)
    assert token.value == "foo"
    assert token.start == 0
    assert token.end == 2
    assert token.content == "foo"

# Generated at 2022-06-12 16:16:33.093474
# Unit test for function validate_yaml
def test_validate_yaml():
    # FIXME: add tests
    pass
# /Unit test for function validate_yaml

# Generated at 2022-06-12 16:16:38.578024
# Unit test for function validate_yaml
def test_validate_yaml():

    # test that it works with a scalar field
    validator = Field(name="hello", type="string")
    assert validate_yaml("abc", validator) == ("abc", [])
    assert validate_yaml("123", validator) == (
        "123",
        [
            Message(
                text="'123' is not a valid string.",
                code="type_error.string",
                position=Position(char_index=0, column_no=1, line_no=1),
            )
        ],
    )

    # test that it works with a schema
    class Validator(Schema):
        foo = Field(type="string")
        bar = Field(type="integer")

    content = dedent(
        """
        foo: abc
        bar: 123
        """
    )
    assert validate_

# Generated at 2022-06-12 16:16:47.064660
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "1"
    messages = validate_yaml(content, typing.Any)
    assert len(messages) == 0

    content = "abc"
    messages = validate_yaml(content, typing.Any)
    assert len(messages) == 0

    content = "1.1"
    messages = validate_yaml(content, typing.Any)
    assert len(messages) == 0

    content = "[]"
    messages = validate_yaml(content, typing.Any)
    assert len(messages) == 0

    content = "[1, 2]"
    messages = validate_yaml(content, typing.Any)
    assert len(messages) == 0

    content = "{}"
    messages = validate_yaml(content, typing.Any)
    assert len(messages) == 0


# Generated at 2022-06-12 16:16:59.322917
# Unit test for function validate_yaml
def test_validate_yaml():
    # TODO: Should use pytest.parametrize()
    class ValidateTestCase:
        def __init__(
            self,
            content: typing.Union[str, bytes],
            validator: typing.Union[Field, typing.Type[Schema]],
            expected_value: typing.Any,
            expected_messages: typing.List[Message],
        ):
            self.content = content
            self.expected_value = expected_value
            self.expected_messages = expected_messages
            self.validator = validator

            assert isinstance(content, (str, bytes))
            assert isinstance(validator, (Field, type))
            assert isinstance(expected_value, (dict, list, str, int, float, bool))
            assert isinstance(expected_messages, list)


# Generated at 2022-06-12 16:17:06.585562
# Unit test for function validate_yaml
def test_validate_yaml():
    string_yaml = complete_yaml
    value, error_messages = validate_yaml(
        string_yaml, validator=ConcreteSchema
    )
    assert error_messages == []
    assert value == {
        "int_field": 1,
        "float_field": 2.2,
        "text_field": "foo",
        "bool_field": True,
        "dict_field": {"key": "value"},
        "list_field": ["foo", "bar"],
        "uuid_field": str(uuid.uuid4()),
    }



# Generated at 2022-06-12 16:17:09.241778
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("[string]") == ListToken(["string"], 0, 7, "[string]")
    assert tokenize_yaml("{a: a}") == DictToken({"a": "a"}, 0, 5, "{a: a}")



# Generated at 2022-06-12 16:17:20.042670
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    class CustomSafeLoader(SafeLoader):
        pass

    def construct_mapping(loader, node):
        start = node.start_mark.index
        end = node.end_mark.index
        mapping = loader.construct_mapping(node)
        return DictToken(mapping, start, end - 1, content=content)

    def construct_sequence(loader, node):
        start = node.start_mark.index
        end = node.end_mark.index
        value = loader.construct_sequence(node)
        return ListToken(value, start, end - 1, content=content)

    def construct_scalar(loader, node):
        start = node.start_mark.index
        end = node.end_mark.index

# Generated at 2022-06-12 16:17:31.526880
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import yaml

    assert tokenize_yaml('a: 3') == DictToken(
        {"a": ScalarToken(3, 0, 3)}, 0, 3, content="a: 3"
    )
    assert tokenize_yaml('[1, 2]') == ListToken(
        [ScalarToken(1, 0, 2), ScalarToken(2, 3, 5)], 0, 5, content="[1, 2]"
    )
    assert tokenize_yaml('a: 1\nb: 2') == DictToken(
        {
            "a": ScalarToken(1, 0, 3),
            "b": ScalarToken(2, 4, 7),
        },
        0,
        7,
        content="a: 1\nb: 2",
    )

# Generated at 2022-06-12 16:17:32.681914
# Unit test for function validate_yaml
def test_validate_yaml():
    assert(validate_yaml(b"Hello World!", None)) == ("Hello World!", [])

# Generated at 2022-06-12 16:17:45.363517
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Array
    from typesystem.definitions import Boolean, Float, Integer
    from typesystem.schemas import Schema

    class BookSchema(Schema):
        name = String(max_length=100)
        authors = Array(items=String(max_length=100))
        pages = Integer(minimum=1, maximum=10000)
        rating = Float(minimum=0, multiple_of=0.5)
        fiction = Boolean()
        publication_year = Integer(minimum=1800, maximum=2100)

    content = """
    name: War and Peace
    authors:
    - Leo Tolstoy
    - Graeme Gilmore
    pages: 1225
    rating: 9.5
    publication_year: 1869
    fiction: true
    """


# Generated at 2022-06-12 16:17:59.249609
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(max_value=100)

    valid_content1 = "age: 8\nname: 'bob'"
    assert validate_yaml(valid_content1, Person) == ({'age': 8, 'name': 'bob'}, [])

    valid_content2 = "age: 8\nname: 'bob'\n"
    assert validate_yaml(valid_content2, Person.fields["age"]) == (8, [])

    invalid_content1 = "age: 8\nname: 'bob'\nfoo: bar"

# Generated at 2022-06-12 16:18:04.234593
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    key:
        nested: value
    """
    validator = {
        "key": {
            "nested": {"type": "string"},
        }
    }
    (value, errors,) = validate_yaml(content, validator)
    assert not errors
    assert value == {"key": {"nested": "value"}}
    assert isinstance(value["key"]["nested"], ScalarToken)
    assert isinstance(value["key"], DictToken)
    assert isinstance(value, DictToken)



# Generated at 2022-06-12 16:18:15.317870
# Unit test for function validate_yaml
def test_validate_yaml():
    class BookSchema(Schema):
        title = Field(type="string", max_length=100, min_length=2)

        class Meta:
            ordered = True

    # Unit test for a valid input
    yaml_str = """
    title: Anekdote zur Senkung der Arbeitsmoral
    """
    value, errors = validate_yaml(yaml_str, validator=BookSchema)
    assert value == {"title": "Anekdote zur Senkung der Arbeitsmoral"}
    assert errors == []
    # Unit test for a valid input
    yaml_str = """
    title: Anekdote zur Senkung der Arbeitsmoral
    """
    value, errors = validate_yaml(yaml_str, validator=BookSchema)

# Generated at 2022-06-12 16:18:21.108140
# Unit test for function validate_yaml
def test_validate_yaml():
    def build_messages(code: str, message: str, position: int):
        return [Message(code, message, position)]
    assert validate_yaml("{}", Field(type="string")) == ("", build_messages("expected_type", "Expected 'string' value but got 'object'", 0))
    assert validate_yaml("{}", Field(type="integer")) == ("", build_messages("expected_type", "Expected 'integer' value but got 'object'", 0))
    assert validate_yaml("a", Field(type="string")) == ("a", [])
    assert validate_yaml("1", Field(type="integer")) == (1, [])
    assert validate_yaml("3", Field(type="integer")) == (3, [])

# Generated at 2022-06-12 16:18:32.379822
# Unit test for function validate_yaml
def test_validate_yaml():
    import json

    class PersonSchema(Schema):
        name = Field(str, description="Name of a person.")
        age = Field(int, description="Age of a person.")

    yaml_content = """\
    name: 'John Doe'
    age: 43
    """
    content = yaml.safe_load(yaml_content)
    expected_value = content
    expected_error_messages = []
    value, error_messages = validate_yaml(yaml_content, PersonSchema)
    assert json.dumps(value, sort_keys=True) == json.dumps(
        expected_value, sort_keys=True
    )

# Generated at 2022-06-12 16:18:44.089335
# Unit test for function validate_yaml
def test_validate_yaml():
    '''yaml validation of schemas'''

    schema = Schema(
        name=Field(type=str),
        age=Field(type=int),
        sex=Field(type=str, enum=["male", "female"], required=False),
    )
    content = """\
name: "John Doe"
age: 42
sex: male
"""
    value, error_messages = validate_yaml(content=content, validator=schema)
    assert isinstance(value, dict)
    assert len(error_messages) == 0
    assert value == {"name": "John Doe", "age": 42, "sex": "male"}

    content = """\
name: "John Doe"
age: 42
sex: unknown
"""

# Generated at 2022-06-12 16:18:46.831810
# Unit test for function validate_yaml
def test_validate_yaml():
   error = 0
   # Check for successful validation
   content = "name: john"
   validator = Field(name="name", type="string")

# Generated at 2022-06-12 16:18:57.456038
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        content="",
        validator=Field(type="string"),
    ) == (None, [Message(text="No content.", code="no_content", position=Position(1, 1, 0))])

    # Simple string
    assert validate_yaml(
        content="1234",
        validator=Field(type="string"),
    ) == ("1234", [])

    assert validate_yaml(
        content="1234",
        validator=Field(type="integer"),
    ) == (1234, [])

    assert validate_yaml(
        content="-1234",
        validator=Field(type="integer"),
    ) == (-1234, [])


# Generated at 2022-06-12 16:19:02.537538
# Unit test for function validate_yaml
def test_validate_yaml():
    class SimpleSchema(Schema):
        name = Field(str)
        age = Field(int)

    schema = SimpleSchema()
    data = 'name: "blah"\nage: "2"'

    value, errors = validate_yaml(data, schema)
    assert not errors



# Generated at 2022-06-12 16:19:14.322412
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    from typesystem.schemas import Schema


    class UserSchema(Schema):
        name = String(max_length=10)
        age = String(max_length=2)
        email = String(max_length=100)

    instance = '''
    name: Jonny
    age: 21
    email: jonny@fake.com
    '''

    (value, error_messages) = validate_yaml(instance, UserSchema)

# Generated at 2022-06-12 16:19:29.797626
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem.types import *
    from typesystem.schemas import Schema
    import pytest

    class Person(Schema):
        name = String(max_length=20)
        age = Integer()

    person_yaml = """
    name: "Jon Snow"
    age: 16
    """

    # Test that a valid YAML string validates.
    result = validate_yaml(person_yaml, Person)
    assert isinstance(result[0], dict)
    assert isinstance(result[1], list)
    assert len(result[1]) == 0

    # Test that an invalid YAML string fails to validate.
    with pytest.raises(ParseError):
        validate_yaml(":", Person)

# Generated at 2022-06-12 16:19:35.282662
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class TestSchema(Schema):
        title = Field(type="string")
        year = Field(type="integer")

    content = """
    title: "The Shining"
    year: 1980
    """

    value, error_messages = validate_yaml(content, TestSchema)
    assert value == {"title": "The Shining", "year": 1980}
    assert error_messages == []

    content = """
    title: The Shining
    year: 1980
    """
    value, error_messages = validate_yaml(content, TestSchema)
    assert value == {"title": "The Shining", "year": 1980}
    assert error_messages == []

    content = """
    title: The Shining
    year: MKVI
    """

# Generated at 2022-06-12 16:19:41.328932
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = b"""
    ---
    - 0
    - 1.5
    - 10
    - 4.5
    """
    token = tokenize_yaml(content)
    assert token.items == [0, 1.5, 10, 4.5]
    assert token.value == [0, 1.5, 10, 4.5]
    assert token.start == 0
    assert token.end == 32



# Generated at 2022-06-12 16:19:46.873034
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # simple key-value object test
    content = "key:value\n"
    result = tokenize_yaml(content)
    assert isinstance(result, DictToken)
    assert len(result.items) == 1
    assert result.items[0][0] == "key"
    assert result.items[0][1].value == "value"
    # simple sequence test
    content = "- value\n"
    result = tokenize_yaml(content)
    assert isinstance(result, ListToken)
    assert len(result.items) == 1
    assert result.items[0].value == "value"
    # simple list object test
    content = "- key:value\n"
    result = tokenize_yaml(content)
    assert isinstance(result, ListToken)

# Generated at 2022-06-12 16:19:55.415226
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    from typesystem.schemas import Schema

    schema = Schema({"name": String()})
    content = """
    name: 'Alice'
    """
    value, errors = validate_yaml(content, schema)

    assert isinstance(value, dict)
    assert value["name"] == "Alice"
    assert len(errors) == 0

    # invalid
    content = """
    name: Alice
    """
    value, errors = validate_yaml(content, schema)

    assert value is None
    assert len(errors) == 1
    assert errors[0].position == Position(line_no=2, column_no=6)



# Generated at 2022-06-12 16:20:01.799287
# Unit test for function validate_yaml
def test_validate_yaml(): 
    from typesystem import Integer, Schema, String
    class RecordSchema(Schema):
        name = String(max_length=50)
        age = Integer(minimum=0)

    content = """
    {
        name: John Smith
        age: 37
    }
    """

    value, error_messages = validate_yaml(content, RecordSchema)
    assert error_messages == []


# Generated at 2022-06-12 16:20:12.941323
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, List, Dict
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize import validate_yaml
    import yaml

# Generated at 2022-06-12 16:20:16.797766
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        test_field = Field(validators=["required"])
    value, messages = validate_yaml(
    'test_field: abc', 
    TestSchema,
    )
    assert len(messages) == 0


# Generated at 2022-06-12 16:20:26.451728
# Unit test for function validate_yaml
def test_validate_yaml():
    from syntax import (
        ParseError,
        ValidationError,
        _get_position,
        tokenize_yaml,
        validate_yaml,
    )
    from typesystem.fields import Field
    from typesystem.types import String

    validator = Field(type=String)

    # Test empty document
    try:
        validate_yaml(content=b"", validator=validator)
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
        assert exc.code == "no_content"

    # Test empty scalar

# Generated at 2022-06-12 16:20:37.399784
# Unit test for function validate_yaml
def test_validate_yaml():
    class AddressSchema(Schema):
        line1 = types.String(default="Main Street")
        line2 = types.String()
        city = types.String()
        state = types.String()

    class PersonSchema(Schema):
        name = types.String()
        age = types.Integer()
        address = types.Schema(AddressSchema)

    PersonSchema.get_validation_errors(
        {
            "name": "John Doe",
            "age": "blah",
            "address": {
                "line1": "Main Street",
                "line2": None,
                "city": "Denver",
                "state": "CO",
            },
        }
    )
    # [{'code': 'invalid_type',
    #   'position': Position(column_no=8,

# Generated at 2022-06-12 16:20:50.303695
# Unit test for function validate_yaml
def test_validate_yaml():
    import re
    from typesystem.types import Integer, String

    """
    Test validate_yaml with a simple integer field.
    """
    # Test a basic integer field.
    class IntegerField(Field):
        type = "integer"

    errors = validate_yaml(content="12", validator=IntegerField())
    assert errors == []
    errors = validate_yaml(content="0o12", validator=IntegerField())
    assert errors == []
    errors = validate_yaml(content="0x12", validator=IntegerField())
    assert errors == []
    errors = validate_yaml(content="12.0", validator=IntegerField())
    assert len(errors) == 1

# Generated at 2022-06-12 16:21:00.125673
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    price: 3.99
    quantity: 300
    """
    class ProductSchema(Schema):
        price = Field(validators=[min_value(2)])
        quantity = Field(validators=[min_value(100)])

    value, errors = validate_yaml(content.encode('utf-8'), ProductSchema)
    print(value)
    print(errors)
    """
    {'price': 3.99, 'quantity': 300}
    [<typesystem.base.ValidationError object at 0x2171f6c70b8>, <typesystem.base.ValidationError object at 0x2171f6c7208>]
    """


# Generated at 2022-06-12 16:21:06.007918
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""

name: Joe
age: 12
      """

    class UserSchema(Schema):

        name = "string"
        age = "integer"

    user, errors = validate_yaml(content, UserSchema)
    assert isinstance(user, dict)
    assert isinstance(errors, list)
    assert len(errors) == 0



# Generated at 2022-06-12 16:21:17.389054
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test type validation
    assert validate_yaml('a: 1', Field(type=str)) == ("a: 1", [])
    assert validate_yaml('a: 1', Field(type=int)) == (1, [])
    assert validate_yaml('a: 1', Field(type=float)) == (1.0, [])
    assert validate_yaml('a: 1', Field(type=bool)) == (True, [])

    # Test nullable
    assert validate_yaml('a: ~', Field(type=str, nullable=True)) == (None, [])

# Generated at 2022-06-12 16:21:25.594656
# Unit test for function validate_yaml
def test_validate_yaml():

    class ExampleSchema(Schema):
        """
        Example schema for testing.
        """

        prime_numbers = [2, 3, 5, 7]
        integers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

        name = Field(str)
        age = Field(int, description="Age in years", min_value=18)
        prime = Field(int, description="Prime number", enum=prime_numbers)
        count = Field(int, description="List size", min_value=1, max_value=10)
        numbers = Field(
            [int], description="List of integers", min_value=1, max_value=10, enum=integers
        )

    class ExampleSchema2(Schema):
        """
        Example schema for testing.
        """

        name

# Generated at 2022-06-12 16:21:35.735921
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    data = """\
    - foo
    - bar"""

    result = validate_yaml(data, list)
    assert result.value == ["foo", "bar"]

    data = """\
    foo:
      bar: bizz
    """

    result = validate_yaml(data, dict)
    assert result.value == {"foo": {"bar": "bizz"}}

    data = """\
    - foo
    - bar
    - bizz
    """

    result = validate_yaml(data, list)
    assert result.value == ["foo", "bar", "bizz"]

    data = """\
    - foo
    - bar
    - bizz
    """


# Generated at 2022-06-12 16:21:37.150757
# Unit test for function validate_yaml
def test_validate_yaml():
    pass

# Generated at 2022-06-12 16:21:46.914131
# Unit test for function validate_yaml
def test_validate_yaml():
    yml_str = "name: foo\n"
    yml_str += "number: 42\n"
    yml_str += "truthy: true\n"
    yml_str += "falsy: false\n"
    yml_str += "list: [a, b, c]\n"
    yml_str += "none: null\n"
    yml_str += "embedded: {name: embedded, none: null}\n"

    class TestSchema(Schema):
        name: str
        number: int
        truthy: bool
        falsy: bool
        list: typing.List[str]
        none: typing.Any
        embedded: "TestSchema"


# Generated at 2022-06-12 16:21:56.954444
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.base import Message, Position

    class Person(Schema):
        name = String()

    content = u"""
    name:
        - "Alice"
        - "Bob"
    """

    (value, errors) = validate_yaml(content, Person)
    assert isinstance(errors, list)
    assert len(errors) == 1
    error = errors[0]
    assert isinstance(error, Message)
    assert error.code == 'type_error'
    assert error.text == 'Expected a string, got a list.'
    assert isinstance(error.position, Position)



# Generated at 2022-06-12 16:22:05.571141
# Unit test for function validate_yaml
def test_validate_yaml():
    types = '''
    mapping:
        id: string
    '''
    types_schema = Schema.from_string(types, 'types_schema_1')
    assert types_schema
    types = '''
    mapping:
        name: string
    '''
    types_schema = Schema.from_string(types, 'types_schema_2')
    assert types_schema

    types = '''
    mapping:
        age: integer
    '''
    types_schema = Schema.from_string(types, 'types_schema_3')
    assert types_schema

    types = '''
    mapping:
        address:
            mapping:
                city: string
                state: string
    '''