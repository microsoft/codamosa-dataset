

# Generated at 2022-06-12 16:12:27.778545
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    sample = 'title: "Days in the Life"\njournal: The Lancet\nvol: 1'
    assert isinstance(tokenize_yaml(sample), DictToken)



# Generated at 2022-06-12 16:12:37.995708
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_doc = "---\nkey:\n  -item1\n  -item2\nvalue:\n  name:value1\n  name1:value2"
    token = tokenize_yaml(yaml_doc)
    assert len(token.value) == 2
    assert token.value["key"].value[0].value == "item1"
    assert token.value["key"].value[1].value == "item2"
    assert token.value["value"].value["name"].value == "value1"
    assert token.value["value"].value["name1"].value == "value2"
    assert str(token.value["key"]) == "[\n  item1\n  item2\n]"

# Generated at 2022-06-12 16:12:48.400121
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "---\nmeta:\n  title: foo\n  run_date: \"yesterday\"\n  int: 1"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.fields["meta"], DictToken)
    assert token.fields["meta"].fields["title"] == ScalarToken(
        value="foo", start=14, end=20, content=content
    )
    assert token.fields["meta"].fields["run_date"] == ScalarToken(
        value="yesterday", start=25, end=36, content=content
    )
    assert token.fields["meta"].fields["int"] == ScalarToken(
        value=1, start=41, end=43, content=content
    )


# Generated at 2022-06-12 16:12:54.007625
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        foo:
          bar:
            - baz
            - qux
        """
    expected = DictToken({'foo': {'bar': ['baz', 'qux']}},
                         start=2, end=34, content=content)

    token = tokenize_yaml(content)
    assert token == expected


# Generated at 2022-06-12 16:12:57.786396
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"name": str})
    value, errors = validate_yaml(b"{name: invalid}", schema)
    assert not errors
    assert value == {"name": "invalid"}

# Generated at 2022-06-12 16:13:07.705641
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    if isinstance(content, bytes):
        str_content = content.decode("utf-8", "ignore")
    else:
        str_content = content

    if not str_content.strip():
        # Handle the empty string case explicitly for clear error messaging.
        position = Position(column_no=1, line_no=1, char_index=0)
        raise ParseError(text="No content.", code="no_content", position=position)

    class CustomSafeLoader(SafeLoader):
        pass

    def construct_mapping(loader: "yaml.Loader", node: "yaml.Node") -> DictToken:
        start = node.start_mark.index
        end = node.end_mark.index
        mapping = loader.construct_m

# Generated at 2022-06-12 16:13:17.452024
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo: [bar]") == {"foo": ["bar"]}
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("true") is True
    assert tokenize_yaml("false") is False
    assert tokenize_yaml("null") is None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("""
        foo: 123
        """.strip()) == {"foo": 123}
    assert tokenize_yaml("""
        foo: 123
        bar: 456
        """.strip()) == {"foo": 123, "bar": 456}

# Generated at 2022-06-12 16:13:25.850661
# Unit test for function validate_yaml

# Generated at 2022-06-12 16:13:35.194294
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
    anchor_1: &anchor_1
        - 10
        - 20
        - 30
    anchor_2: &anchor_2
        - 40
        - 50
        - 60
    anchor_3: &anchor_3
        - 70
        - 80
        - 90
    all_anchors:
        - *anchor_1
        - *anchor_2
        - *anchor_3
    '''
    token = tokenize_yaml(content)
    assert type(token.value["all_anchors"]) == ListToken
    assert token.value["anchor_1"] == [10, 20, 30]
    assert token.value["anchor_2"] == [40, 50, 60]
    assert token.value["anchor_3"] == [70, 80, 90]

# Generated at 2022-06-12 16:13:47.446355
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
list:
  - a
  - b
  - c

dict:
    key: value
    key2: value2

boolean: true
float: 4.2
int: 0
string: "some string"
null: null
"""
    token = tokenize_yaml(content)
    assert hasattr(token, "content")
    assert token.content == content
    assert token.start == 0
    assert token.end == len(content) - 1

    assert hasattr(token, "tokens")
    assert isinstance(token, DictToken)
    assert token.tokens["list"].tokens == ["a", "b", "c"]
    assert isinstance(token.tokens["list"], ListToken)

# Generated at 2022-06-12 16:13:56.001619
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('string', String(validators=[MinLength(3)])) == ('string', [])
    assert validate_yaml('', String(validators=[MinLength(3)])) == ('', [{'text': 'Shorter than minimum length 3.', 'position': {'line_no': 1, 'column_no': 1, 'char_index': 0}, 'code': 'min_length'}])
    assert validate_yaml('string', String(validators=[Endswith('g')])) == ('string', [])

# Generated at 2022-06-12 16:14:02.878333
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        age = IntegerField()
        name = StringField()

    content = """
    name: Joshua
    age: 100
    """

    value, errors = validate_yaml(content, MySchema())
    assert value == {"name": "Joshua", "age": 100}
    assert errors == []

    content = """
    name: Joshua
    """

    value, errors = validate_yaml(content, MySchema())
    assert value is None
    assert len(errors) == 1
    assert errors[0].text == "Missing required field 'age'."
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 1
    assert errors[0].position.char_index == 8


# Generated at 2022-06-12 16:14:07.415696
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"{a: 'alpha'}"
    class MySchema(Schema):
        a = 'str'
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {'a': 'alpha'}
    assert error_messages is None

# Generated at 2022-06-12 16:14:17.980877
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Field(validators=[validate_yaml])

    try:
        schema.validate("{1:2")
        assert False, "Should have failed to parse"
    except ValidationError as exc:
        msg = exc.to_primitive(full_messages=False)
        expected = {
            "text": '"{1:2" is not a valid YAML string.',
            "code": "parse_error",
            "position": {"start_index": 0, "end_index": 5},
        }
        assert msg == expected

    try:
        schema.validate("{1:2:3}")
        assert False, "Should have failed to parse"
    except ValidationError as exc:
        msg = exc.to_primitive(full_messages=False)

# Generated at 2022-06-12 16:14:28.725825
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml a YAML string or bytestring.
    """
    schema=Schema(properties={"name": Text(max_length=30), "age": Integer(
        minimum=2, maximum=7)})
    content = 'name: "My name", age: 999'
    content = 'name: "My name", age: 999'
    value, errors = validate_yaml(content, schema)
    assert value == {"name": "My name", "age": 999}
    assert len(errors) == 2
    assert errors[0].code == "max_length"
    assert errors[1].code == "maximum"
    
    class PersonSchema(Schema):
        name = Text(min_length=1)
        age = Number(minimum=0)

# Generated at 2022-06-12 16:14:40.721281
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"test": int})
    result, error_messages = validate_yaml(
        """test: foo
        example: 1
        """,
        validator=schema,
    )
    assert error_messages == [
        Message(
            text="Not a valid integer.",
            code="type_error.integer",
            position=Position(line_no=1, column_no=7, char_index=7),
        )
    ]

    result, error_messages = validate_yaml(
        """test: 5
        example: 1
        """,
        validator=schema,
    )
    assert result == {"test": 5, "example": 1}
    assert not error_messages


# Generated at 2022-06-12 16:14:48.172248
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_string = """
    - first_name: John
      last_name: Smith
    - age: 25
    """
    validator = Schema(
        {
            "first_name": Field(required=True),
            "last_name": Field(required=True),
            "age": Field(required=True),
        }
    )
    value, errors = validate_yaml(yaml_string, validator)
    assert len(errors) == 1
    error = errors[0]
    assert isinstance(error, ValidationError)
    assert error.code == "required"
    assert error.message == "Missing required field."
    assert error.path == ["age"]
    assert error.position.char_index == 65
    assert error.position.column_no == 8
    assert error.position.line_no

# Generated at 2022-06-12 16:14:53.774100
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    api_key: '123-456-789'
    """

    expected_value = {"api_key": "123-456-789"}

    value, error_messages = validate_yaml(
        content, {"api_key": "uuid"}
    )
    assert value == expected_value

    # TODO (cliff): Create assertions for error message results

# Generated at 2022-06-12 16:15:04.787680
# Unit test for function validate_yaml
def test_validate_yaml():
    class PhoneBookSchema(Schema):
        def setup_schema(self):
            self.fields = {
                "contact_list": List(
                    fields=Object(
                        fields={"name": String(), "phone": String()},
                        mappings={"name": "name", "phone_number": "phone"},
                    )
                )
            }

    phonebook = """
    contact_list:
    - name: John Smith
      phone: 555-555-5555
    - name: Jane Smith
      phone: 555-555-5556
    """

    phonebook_bad = """
    contact_list:
    - name: John Smith
      phone: 123-456-7890
    - name: Jane Smith
      phone: 555-555-5556
    """


# Generated at 2022-06-12 16:15:10.713941
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: Elmo
    age: 3

    """
    from typesystem import fields
    from typesystem.schemas import Schema

    class Person(Schema):
        name = fields.String(min_length=1)
        age = fields.Integer()

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "Elmo", "age": 3}
    assert not error_messages

# Generated at 2022-06-12 16:15:26.213654
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = Field(String)
        age = Field(Number)

    validator = PersonSchema()
    # If the yaml file is valid, the error_messages returned should be None
    value, error_messages = validate_yaml("{name: John, age: 20}", validator)
    assert error_messages is None
    assert value == {"name": "John", "age": 20}
    # If the yaml file is invalid, the error_messages should be a list of Message
    value, error_messages = validate_yaml("{name: John, age: invalid}", validator)
    assert isinstance(error_messages, list)
    assert len(error_messages) == 1
    assert isinstance(error_messages[0], ValidationError)

# Generated at 2022-06-12 16:15:29.877973
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "foo: bar"
    validator = Field(type="string")
    value, error_messages = validate_yaml(content, validator)
    assert value == "bar"
    assert error_messages == []


# Generated at 2022-06-12 16:15:37.810460
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_str = """
        a: cat
        b:
          - dog
          - walrus
        c:
          d:
            e:
              f: 10
    """
    schema = Schema(
        {
            "a": str,
            "b": [
                {"name": str, "species": str},
                {"name": str, "height": int},
            ],
            "c": {
                "d": {
                    "e": {
                        "f": int,
                    }
                },
            }
        }
    )

    result, error_messages = validate_yaml(yaml_str, schema)


# Generated at 2022-06-12 16:15:49.619699
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(b"""
name: 'John Doe'
age: 30
""", Field(type="object", properties={"name":Field(type="string"), "age":Field(type="integer")}))==({'name': 'John Doe', 'age': 30}, [])

    value, errors = validate_yaml(b"""
name: 'John Doe'
age: 30
""", Field(type="object", required= [ "name" ]))
    assert value=={'name': 'John Doe', 'age': 30}
    assert len(errors)==1
    assert errors[0].text == "Missing a required property: 'name'."
    assert errors[0].code == "missing_property"
    assert errors[0].position == Position(line_no=1, column_no=1, char_index=0)

    value

# Generated at 2022-06-12 16:15:58.436198
# Unit test for function validate_yaml

# Generated at 2022-06-12 16:16:09.949586
# Unit test for function validate_yaml
def test_validate_yaml():
    content = (
        "header:\n"
        "  key_1: value_1\n"
        "  key_2: value_2\n"
        "footer:\n"
        "  key_1: value_1\n"
        "  key_2: value_2\n"
    )

    class Header(Schema):
        key_1 = Field(required=True)
        key_2 = Field(required=True)

    class Footer(Schema):
        key_1 = Field(required=True)
        key_2 = Field(required=True)

    class MySchema(Schema):
        header = Field(Header, required=True)
        footer = Field(Footer, required=True)

    assert validate_yaml(content, MySchema) == content

# Generated at 2022-06-12 16:16:19.010845
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Array

    class IntegerArraySchema(Schema):
        integers = Array(items=String(pattern=r"\d+"))

    yaml_string = """
    integers:
      - 1
      - 2
      - 3
      - 4
      - 5
    """

    value, error_messages = validate_yaml(yaml_string, IntegerArraySchema)
    assert len(error_messages) == 0
    assert value == [1, 2, 3, 4, 5]

# Generated at 2022-06-12 16:16:29.809450
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = Field(type=str)
        age = Field(type=int)

    valid_content = textwrap.dedent(
        """\
        name: foo
        age: 42
        """
    )
    assert validate_yaml(valid_content, MySchema()) == (
        {"name": "foo", "age": 42},
        [],
    )

    invalid_content = """name: foo"""

    value, errors = validate_yaml(invalid_content, MySchema())

    assert value is None
    assert len(errors) == 1
    assert errors[0].__class__ == ValidationError
    assert errors[0].code == "required"
    assert errors[0].path == ["age"]

# Generated at 2022-06-12 16:16:37.711490
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    >>> from typesystem.fields import Integer
    >>> content = """

# Generated at 2022-06-12 16:16:46.490387
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("1", int) == (1, [])
    assert validate_yaml("10", int) == (10, [])

    value, messages = validate_yaml("1", int(max_value=5))
    assert len(messages) == 1
    assert messages[0].code == "max_value"

    value, messages = validate_yaml("[1, 2, 3]", list(items=int))
    assert len(messages) == 0

    value, messages = validate_yaml("[1, 2, 3]", list(items=int(max_value=2)))
    assert len(messages) == 2
    assert messages[0].code == "max_value"
    assert messages[1].code == "max_value"


# Generated at 2022-06-12 16:16:56.423950
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Field(key="name", required=True, type="string")
    value, errors = validate_yaml(b'name: "foo"', schema)
    assert value == {"name": "foo"}
    assert errors == []

    value, errors = validate_yaml(b"name: 2", schema)
    assert value == {"name": 2}
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"



# Generated at 2022-06-12 16:17:06.486772
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        foo_field = Field(type="integer")

    value, error_messages = validate_yaml(
        "foo_field: 100", validator=TestSchema
    )
    assert error_messages == []
    assert value == TestSchema(foo_field=100)

    value, error_messages = validate_yaml("foo_field: invalid", validator=TestSchema)
    assert len(error_messages) == 1
    assert isinstance(error_messages[0], Message)
    assert (
        error_messages[0].text
        == "Value 'invalid' is not currently allowed for field 'foo_field'."
    )
    assert error_messages[0].code == "invalid_type"

# Generated at 2022-06-12 16:17:12.482390
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestValidator(Schema):
        name = Field(type="string")
        age = Field(type="number")
    yaml_content = b"""name: Alice
age: a
"""
    value, error_messages = validate_yaml(content=yaml_content, validator=TestValidator)
    assert error_messages == [
        ValidationError(
            text="Value must be a number.",
            code="type_error.number",
            position=Position(column_no=5, line_no=2, char_index=8),
        )
    ]
    assert value == {}

# Generated at 2022-06-12 16:17:17.377347
# Unit test for function validate_yaml
def test_validate_yaml():
    # Passing validation
    assert validate_yaml("foo: bar", {"foo": "string"}) == ({'foo': 'bar'}, [])

    # Failing validation
    errors = validate_yaml("foo: bar", {"foo": "integer"})[1]
    assert isinstance(errors[0], ValidationError) and errors[0].code == "not_integer"

# Generated at 2022-06-12 16:17:27.310438
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "Text"

    json = '{"name": 12345}'
    value, error_messages = validate_yaml(json, TestSchema)
    assert error_messages == [
        {'message': 'Not a string.', 'code': 'invalid',
        'position': {'line_no': 1, 'column_no': 12, 'char_index': 11}}
    ]

    json = '{"name": "12345", "firstname": "Hamed"}'
    value, error_messages = validate_yaml(json, TestSchema)

# Generated at 2022-06-12 16:17:36.565193
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    raw_yaml = 'first_name: John\nlast_name: "Doe"\nage: 25\nmarried: true\n'
    token = tokenize_yaml(raw_yaml)
    assert token
    assert isinstance(token, DictToken)
    assert isinstance(token[0], ListToken)
    assert isinstance(token[1], ListToken)
    assert isinstance(token[2], ListToken)
    assert isinstance(token[3], ListToken)
    assert isinstance(token[0][0], ScalarToken)
    assert isinstance(token[1][0], ScalarToken)
    assert isinstance(token[2][0], ScalarToken)
    assert isinstance(token[3][0], ScalarToken)
    assert token[0][0].value == "first_name"


# Generated at 2022-06-12 16:17:48.154178
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String, Schema
    from typesystem.tokenize.validation import token_validator_to_schema

    address_schema = token_validator_to_schema(
        validator={"street": String, "zip_code": Integer()}, name="Address"
    )

    class Person(Schema):
        name = String
        age = Integer()
        address = address_schema

    content = """
    name: "John Doe"
    age: 45
    """

# Generated at 2022-06-12 16:17:57.501535
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, validate_yaml
    class PersonSchema(Schema):
        name = String(max_length=10)

    content = '{"name": "Jane Doe"}'
    errors = validate_yaml(content, PersonSchema)
    assert errors == []

    content = '{"name": "Jane Doe Doe Doe Doe Doe Doe Doe Doe Doe Doe"}'
    errors = validate_yaml(content, PersonSchema)
    assert len(errors) == 1

    content = '{"name": "Jane Doe Doe"}'
    errors = validate_yaml(content, PersonSchema)
    assert len(errors) == 1

# Generated at 2022-06-12 16:18:03.425666
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test with a YAML string
    schema = Schema({"name": str})
    value, error_msgs = validate_yaml(content='{"name": "test"}', validator=schema)
    assert value['name'] == 'test'

    # Test with a YAML bytestring
    schema = Schema({"name": str})
    value, error_msgs = validate_yaml(content=b'{"name": "test"}', validator=schema)
    assert value['name'] == 'test'

# Generated at 2022-06-12 16:18:07.819831
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    color: red
    size: large
    """
    validator = Schema({"color": str, "size": str})
    value, error_messages = validate_yaml(content, validator)


# Generated at 2022-06-12 16:18:20.011465
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem.fields import Email, Integer, String

    class UserSchema(Schema):
        name = String(required=True)
        email = Email()
        age = Integer()

    value, errors = validate_yaml(
        content="",
        validator=UserSchema,
    )
    assert errors == [
        Message(
            text="No content.",
            code="no_content",
            type="parse_error",
            position=Position(line_no=1, column_no=1, char_index=0),
        )
    ]

    value, errors = validate_yaml(
        content=b"""""",
        validator=UserSchema,
    )

# Generated at 2022-06-12 16:18:31.146807
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem import Integer

    content = """
    - 2
    - 2.5
    - 1.5
    """

    validator = Integer()

    value, error_messages = validate_yaml(content, validator)
    assert error_messages == [
        Message(
            "Invalid value.",
            "debug",
            position=Position(line_no=2, column_no=7, char_index=9),
            type="error",
        ),
        Message(
            "Invalid value.",
            "debug",
            position=Position(line_no=3, column_no=7, char_index=15),
            type="error",
        ),
    ]



# Generated at 2022-06-12 16:18:37.674607
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    test for validate_yaml for Content-Type: application/yaml
    """
    # testing for non-existent file
    class Test(Schema):
        field = Field(type="string")

    with pytest.raises(ParseError):
        value, error = validate_yaml("", Test)
        
    with pytest.raises(ParseError):
        value, error = validate_yaml("    ", Test)

    # testing for valid file
    value, error = validate_yaml('field: "yaml string"', Test)
    assert value == {"field": "yaml string"}
    assert error == {}

    # testing for invalid yaml file
    value, error = validate_yaml('field: "yaml string"\n---\nfield: "yaml string"', Test)
    assert value

# Generated at 2022-06-12 16:18:40.141439
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a:
      - 1
      - 2
      - 3
    """

    validator = Schema(
        {
            "a": Field([Field(int)]),
        }
    )

    result: typing.Any
    result, error_messages = validate_yaml(content, validator)

    assert result == {"a": [1, 2, 3]}
    assert error_messages == []



# Generated at 2022-06-12 16:18:50.800928
# Unit test for function validate_yaml
def test_validate_yaml():
    
    from typesystem import Schema, fields
    import doctest

    class BookSchema(Schema):
        name = fields.String()
        author = fields.Schema(fields.String(), fields.String())
        price = fields.DDecimal()
        pages = fields.Number()

# Generated at 2022-06-12 16:18:59.220357
# Unit test for function validate_yaml
def test_validate_yaml():
    # No errors on valid content.
    assert not validate_yaml(content="age: 25", validator=Field(name="age", type="integer"))[1]

    # Error message for invalid content.
    assert (
        validate_yaml(content="age: 25", validator=Field(name="age", type="string"))[1]
        == [
            Message(
                text="age: 25.",
                code="invalid",
                position=Position(
                    line_no=1,
                    column_no=1,
                    char_index=0,
                    context="age: 25.",
                ),
            )
        ]
    )

    # Error message for invalid content at a nested position.

# Generated at 2022-06-12 16:19:11.249284
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String, Union

    message_list = []

    def validation_error_handler(message: Message) -> None:
        message_list.append(message)

    schema = Schema(
        fields={"id": Integer(), "name": String(max_length=10)},
        extra_fields=False,
    )

    content = """
        id: 123
        name: daniel
    """

    value, error_messages = validate_yaml(content, schema)
    assert value == {"id": 123, "name": "daniel"}
    assert error_messages == []

    content = """
        id: 123
        name: daniel
        age: 28
    """

    value, error_messages = validate_yaml(content, schema)

# Generated at 2022-06-12 16:19:16.189172
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    assert tokenize_yaml("{}").content == ""
    assert tokenize_yaml("""
        {
            foo: bar
        }
    """).content == """
        {
            foo: bar
        }
    """

    with pytest.raises(ParseError):
        tokenize_yaml("ñ")



# Generated at 2022-06-12 16:19:19.460407
# Unit test for function validate_yaml
def test_validate_yaml():
    from unittest.mock import Mock
    schema = Mock()
    schema.validate.return_value = 'test'
    assert validate_yaml(content='test', validator=schema) == ('test', None)



# Generated at 2022-06-12 16:19:31.536969
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, String, Integer, Number
    from typesystem import fields, schemas

    class MySchema(schemas.Schema):
        name = fields.String(required=True)
        age = fields.Integer(min_value=20, description='must be at least 20.')

    MySchema.validate({'name': 'Bob', 'age': 33})  # No errors

    try:
        MySchema.validate({'name': 'Bob', 'age': 19})
    except ValidationError as error:
        expected_errors = [
            {
                'text': 'must be at least 20.',
                'code': 'min_value',
                'path': ['age'],
                'value': 19,
            }
        ]

# Generated at 2022-06-12 16:19:44.708611
# Unit test for function validate_yaml
def test_validate_yaml():
    class SimpleSchema(Schema):
        number = Field(int)

    SimpleSchema.validate_yaml('number:123')
    SimpleSchema.validate_yaml('number:123', strict_strings=False)
    SimpleSchema.validate_yaml('number:123', strict_strings=True)

    class ComplexSchema(Schema):
        name = Field(str)
        number = Field(int)

    ComplexSchema.validate_yaml('name:foo\nnumber:123')

    class EnumSchema(Schema):
        name = Field(str, enum=['foo', 'bar'])

    EnumSchema.validate_yaml('name:foo')
    EnumSchema.validate_yaml('name:foo', strict_strings=False)

# Generated at 2022-06-12 16:19:55.078342
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        properties={
            "name": Field(type="string"),
            "height": Field(type="number"),
            "favorite_foods": Field(type="array", items=Field(type="string")),
        }
    )
    value, error_messages = validate_yaml(
        """
    name: John Smith
    height: 5' 11"
    favorite_foods:
      - pizza
      - tacos
      - burgers
    """,
        validator=schema,
    )
    assert len(error_messages) == 1
    error = error_messages[0]
    assert isinstance(error, ValidationError)
    assert error.text == 'Value at "height" must be a number.'
    assert error.code == "type_mismatch"
    assert error.position

# Generated at 2022-06-12 16:20:00.840362
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"hello": Field(primitive_type="string")})
    yaml_in = b"""
    hello: hello
    """
    value, error_messages = validate_yaml(content=yaml_in, validator=schema)

    assert value == {"hello": "hello"}
    assert error_messages == []



# Generated at 2022-06-12 16:20:07.519602
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    foo: bar
    bar: baz
    '''

    schema = Schema({"foo": str, "bar": str})
    assert validate_yaml(content, schema) == ({"foo": "bar", "bar": "baz"}, [])

    content = """
    foo: bar
    bar:
      subfield: "a b"
    """
    schema = Schema(
        {
            "foo": str,
            "bar": Schema({"subfield": str}, raise_on_extra_keys=False),
        }
    )
    assert validate_yaml(content, schema) == (
        {"foo": "bar", "bar": {"subfield": "a b"}},
        [],
    )


# Generated at 2022-06-12 16:20:15.416076
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John"
    age:
      years: 30
    """

    class UserSchema(Schema):
        name = types.String()
        age = types.Dict(
            {"years": types.Integer(minimum=0, maximum=150)}
        )

    value, errors = validate_yaml(content, UserSchema)

    assert value == {
        "name": "John",
        "age": {"years": 30},
    }
    assert not errors

# Generated at 2022-06-12 16:20:25.485171
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_content = "name: Joffrey"

    class User(Schema):
        name = fields.String()

    class UserList(Schema):
        users = fields.List(fields.Nested(User))

    value, error_messages = validate_yaml(yaml_content, User)
    assert error_messages == []
    assert value == {"name": "Joffrey"}

    value, error_messages = validate_yaml(yaml_content, UserList)

# Generated at 2022-06-12 16:20:35.610676
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Boolean, String

    field = String(max_length=5)

    message_list = validate_yaml(b"12345", validator=field)

    assert not message_list

    message_list = validate_yaml(b'1234567890"', validator=field)

    assert len(message_list) == 1
    assert message_list[0].code == "too_long"

    message_list = validate_yaml(b"true", validator=Boolean())

    assert len(message_list) == 1
    assert message_list[0].code == "invalid_type"

# Generated at 2022-06-12 16:20:46.684200
# Unit test for function validate_yaml
def test_validate_yaml():
    simple_schema = Schema(
        {
            "name": "string",
            "age": "number",
            "is_happy": "boolean",
            "count": "number",
        }
    )

    complex_schema = Schema(
        {
            "name": "string",
            "address": "object",
            "address.city": "string",
            "address.lines": "list",
            "address.lines[].line": "string",
            "friends": "list",
            "friends[].name": "string",
            "friends[].age": "number",
            "friends[].hobbies": "object",
            "friends[].hobbies.hobby": "string",
        }
    )


# Generated at 2022-06-12 16:20:51.233912
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        a = Field(type_=int)
        b = Field(type_=int)

    value, errors = validate_yaml(
        content='{"a": 123, "b": "not_int"}',
        validator=TestSchema,
    )

    assert errors[0].text == "Expected type 'int', got 'not_int'."
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 16



# Generated at 2022-06-12 16:20:54.594003
# Unit test for function validate_yaml
def test_validate_yaml():
    result = validate_yaml('name: a\na: 123\n', Field(type=int))
    assert result == (123, [])



# Generated at 2022-06-12 16:21:11.300645
# Unit test for function validate_yaml
def test_validate_yaml():
    # Valid YAML
    assert(
        validate_yaml('{"a": 1}', {"a": int}) ==
        ({u'a': 1}, []))

    # Invalid YAML
    assert(
        validate_yaml("a: 1", {"a": int}) ==
        (None, [Message("Missing separator after mapping key.", "missing_separator", 1, 1)]))

    # Invalid schema
    assert(
        validate_yaml("{a: 1}", {"b": int}) ==
        (None, [Message("'a' is not a valid value.", "invalid_value", 1, 0)]))

    # Invalid schema

# Generated at 2022-06-12 16:21:16.047297
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"x": int, "y": float})
    value, errors = validate_yaml(content="x: 1\ny: 2.2", validator=schema)
    assert errors == []
    assert value == {"x": 1, "y": 2.2}


# Generated at 2022-06-12 16:21:24.513081
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    import typesystem
    class Movie(typesystem.Schema):
        title = typesystem.String()
        year = typesystem.Integer()
        director = typesystem.String()

        class Meta:
            title = "Movie"
     
    content = """
    title: The Matrix
    year: 1999
    director: The Wachowskis
    """
    value, error = validate_yaml(content, Movie)
    assert error is not None
    assert error[0].code == "required"

    content = """
    title: "The Matrix"
    year: 1999
    director: The Wachowskis
    """
    value, error = validate_yaml(content, Movie)
    assert error == None 

# Generated at 2022-06-12 16:21:30.676261
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    b: 2
    """
    schema = Schema(a=int, b=int)
    assert validate_yaml(content, schema) == ({"a": 1, "b": 2}, [])

    # Test that we throw a ParseError when parsing fails.
    content = "invalid yaml"
    exception_caught = False
    try:
        validate_yaml(content, schema)
    except ParseError:
        exception_caught = True
    assert exception_caught

    # Test that we throw a ValidationError when validation fails.
    content = """
    a: 1
    b: not an int
    """
    exception_caught = False
    try:
        validate_yaml(content, schema)
    except ValidationError:
        exception_caught

# Generated at 2022-06-12 16:21:37.720293
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    # Parse and validate a YAML string, returning positionally marked error messages
    # Parse valid yaml string and return dict
    yaml_object = '{"first_name": "John", "last_name": "Smith"}'
    value, error_messages = validate_yaml(yaml_object, typing.Any)
    assert value == {"first_name": "John", "last_name": "Smith"}
    assert error_messages == []
    
    # Parse invalid yaml string and return error message
    yaml_object = '{"first_name": "John", "last_name: "Smith"}'
    value, error_messages = validate_yaml(yaml_object, typing.Any)
    assert value == None
    assert error

# Generated at 2022-06-12 16:21:39.130946
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    tokenize_yaml('-123')


# Generated at 2022-06-12 16:21:46.023849
# Unit test for function validate_yaml
def test_validate_yaml():
    test_schema = types.Schema({"age": types.Integer(), "name": types.String()})
    result = validate_yaml(b"{name: test, age: 10}", test_schema)
    assert result[0] == {'name': 'test', 'age': 10}
    assert result[1] == None
    result = validate_yaml(b"{name: test, age: 'a'}", test_schema)
    assert result[0] == None
    assert result[1] != None

# Generated at 2022-06-12 16:21:57.043178
# Unit test for function validate_yaml
def test_validate_yaml():
    def validate_list(list_token: ListToken):
        for index, item in enumerate(list_token):
            if isinstance(item, ScalarToken):
                if item.value > 5:
                    position = Position(
                        line_no=item.start_line_no,
                        column_no=item.start_column_no,
                        char_index=item.start_char_index,
                    )
                    yield ValidationError(
                        text="Item must be smaller than 5.",
                        code="item_too_large",
                        position=position,
                    )
            elif isinstance(item, ListToken):
                yield from validate_list(item)
            else:
                raise ValueError("Invalid list.")

    list_field = Field(validators=[validate_list])

    # Validate a valid list.
    content

# Generated at 2022-06-12 16:22:05.608487
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class SimpleSchema(Schema):
        name = String(min_length=4)

    content = """name: 'Greg'"""
    parsed, errors = validate_yaml(content, Schema)

    assert parsed.name == "Greg"
    assert not errors

    content = """name: ''"""
    parsed, errors = validate_yaml(content, Schema)

    assert not parsed
    assert errors == ({'name': ["Must be at least 4 characters long."]}, [
        Message(
            code="min_length",
            text="Must be at least 4 characters long.",
            context=[["name"]],
            position=Position(char_index=6, column_no=7, line_no=1),
        )
    ])



# Generated at 2022-06-12 16:22:15.458510
# Unit test for function validate_yaml
def test_validate_yaml():
    ''' Test validate_yaml function '''
    from typesystem.types import String, Integer, DateTime
    from typesystem.schemas import Schema

    class ChatMessage(Schema):
        id = Integer(required=True)
        message = String(required=True)
        created_at = DateTime(required=True)

    # Test no content
    #content = b""
    #validator = ChatMessage()
    #expected_value = None
    #expected_error_messages = [
    #    {
    #        'text': 'No content.',
    #        'code': 'no_content',
    #        'position': {
    #            'char_index': 0,
    #            'column_no': 1,
    #            'line_no': 1,
    #        }
    #   