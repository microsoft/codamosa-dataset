

# Generated at 2022-06-12 16:12:31.749247
# Unit test for function validate_yaml
def test_validate_yaml():
    # yaml input with int, float, string and dictionary members
    # input is a string type
    content = \
        """
        start_time: 1536561820
        end_time: 1536561820
        host: "HOST1"
        """
    class MySchema(Schema):
        start_time = Field(type=int)
        end_time = Field(type=int)
        host = Field(type=str)

    # test obj has int, float and string type members
    obj = MySchema()
    # check for correct validation
    value, err_msgs = validate_yaml(content, obj)
    assert not err_msgs, "\n".join([str(m) for m in err_msgs])

    # Unit test for List type
    # yaml input with a list object


# Generated at 2022-06-12 16:12:41.236292
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.1") == ScalarToken(1.1, 0, 3, content="1.1")
    assert tokenize_yaml('"hello"') == ScalarToken("hello", 0, 7, content='"hello"')

# Generated at 2022-06-12 16:12:44.815848
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test the case of an empty file
    empty_file = ""
    token = tokenize_yaml(empty_file)
    assert token == {}, "Empty file"
    # Test the case of a file with a single line of text
    single_line = "single line"
    token = tokenize_yaml(single_line)
    assert token == "single line", "Single line file"
    # Test the case of a file with multiple lines separated by \n
    multiple_lines = "first line\nsecond line"
    token = tokenize_yaml(multiple_lines)
    assert token == "first line\nsecond line", "Multiple lines"
    # Test the case of a file with multiple lines separated with \r\n
    multiple_lines_cr = "first line\r\nsecond line"
    token = tokenize_y

# Generated at 2022-06-12 16:12:53.472306
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Schema(fields={
        'name': str,
        'age': int,
        'is_legal_adult': bool
    })

    assert validate_yaml(
        content = '''
        name: kelly
        age: 49
        is_legal_adult: false
        ''',
        validator = validator,
    ) == (
        {
            'name':'kelly',
            'age': 49,
            'is_legal_adult': False
        },
        []
    )


# Generated at 2022-06-12 16:13:05.088172
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer
    from typesystem.fields import Field, String
    from typesystem.schemas import Schema

    # Simple schema class with a required int field.
    class SimpleSchema(Schema):
        count = Integer(minimum=1, maximum=4)

    # Get the actual value, and the messages in a list.
    good_value, good_messages = validate_yaml("count: 3\n", SimpleSchema)

    # Assert that the value is 3.
    assert good_value == {"count": 3}

    # Assert that there are no messages.
    assert good_messages == []

    # Get the actual value, and the messages in a list.
    bad_value, bad_messages = validate_yaml("count: -1\n", SimpleSchema)

    # Assert that the value

# Generated at 2022-06-12 16:13:16.228927
# Unit test for function validate_yaml
def test_validate_yaml():

    class SimpleSchema(Schema):
        text = Field().string()
        num = Field().integer()
        truthy = Field().boolean()

    # test validation
    value, error = validate_yaml(b'def: abc', SimpleSchema)
    assert error is not None

    value, error = validate_yaml(b'- def: abc', SimpleSchema)
    assert error is not None

    value, error = validate_yaml(
        b'text: asdf\nnum: "1"\ntruthy: False', SimpleSchema
    )
    assert error is None

    value, error = validate_yaml(b'text: asdf\nnum: "1"', SimpleSchema)
    assert error is not None

    # test parsers

# Generated at 2022-06-12 16:13:24.917449
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(key=None, type="string")
    text, errors = validate_yaml(b"foo", field)
    assert text == "foo"
    assert errors == []

    field = Field(key=None, type="integer")
    text, errors = validate_yaml(b"1", field)
    assert text == 1
    assert errors == []

    field = Field(key=None, type="boolean")
    text, errors = validate_yaml(b"true", field)
    assert text is True
    assert errors == []

    field = Field(key=None, type="null")
    text, errors = validate_yaml(b"null", field)
    assert text is None
    assert errors == []

    field = Field(key=None, type="list", items=Field(type="integer"))
    text

# Generated at 2022-06-12 16:13:30.498043
# Unit test for function validate_yaml
def test_validate_yaml():
    #parse example yaml and validate
    s = "process_dataset:\n  name: bla\n  process:\n  - echo foo\n"
    try:
        result, msg = validate_yaml(s, Field(type="object", properties={"name": Field(type="string", required=True)}))
    except Exception:
        #assert no error
        assert False



# Generated at 2022-06-12 16:13:31.980987
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("null") == ScalarToken(None, 1, 1, content="null")

# Generated at 2022-06-12 16:13:39.209466
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    def assert_tokenize(s, value):
        assert tokenize_yaml(s) == value

    assert_tokenize("", ListToken([], 0, -1, content=""))
    assert_tokenize("{}", DictToken({}, 0, 1, content="{}"))
    assert_tokenize("[]", ListToken([], 0, 1, content="[]"))

    assert_tokenize("test", ScalarToken("test", 0, 3, content="test"))
    assert_tokenize("\"test\"", ScalarToken("test", 0, 5, content="\"test\""))

    assert_tokenize("123", ScalarToken(123, 0, 2, content="123"))
    assert_tokenize("-123", ScalarToken(-123, 0, 3, content="-123"))

# Generated at 2022-06-12 16:13:50.568355
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test the validate_yaml function"""
    import typesystem
    import pytest
    class MySchema(typesystem.Schema):
        name = typesystem.String()
        email = typesystem.Email()
        age = typesystem.Integer()
    _, msgs = validate_yaml(b'name: Mark\nemail: mark@example.com\nage: 42', MySchema)
    assert msgs == []
    _, msgs = validate_yaml(b'name: Mark\nemail: mark@example.com\nage: 42\n', MySchema)
    assert msgs == [Message(code='trailing_data', text='Trailing data.', position=Position(char_index=37, column_no=1, line_no=4))]

# Generated at 2022-06-12 16:13:56.055910
# Unit test for function validate_yaml
def test_validate_yaml():
    print(type(validate_yaml(b'YAML allows multiple documents:', 
                             validator=Schema([
                                 Field(int, name='ID', is_required=True),
                                 Field(str, name='Name',  is_required=True, min_length=2, max_length=20)
                             ]))))

# Generated at 2022-06-12 16:13:56.846677
# Unit test for function validate_yaml
def test_validate_yaml():
    raise NotImplementedError  # pragma: no cover

# Generated at 2022-06-12 16:14:08.357570
# Unit test for function validate_yaml
def test_validate_yaml():
    # Example YAML string
    content = """- title: Example Schema
    type: object
    properties:
      # firstName is a string
      firstName:
        type: string
      lastName:
        type: string
      age:
        description: Age in years
        type: integer
      friends:
        type: array
        items:
          $ref: '#/definitions/person'
    required:
      - firstName
      - lastName
    """


# Generated at 2022-06-12 16:14:14.477645
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
     - matrix:
       - name: Linux Trusty
         python: 2.7
         env: TOXENV=py27
       - name: OSX 10.9
         python: 2.7
         env: TOXENV=py27
    """
    schema = Schema(fields=[
      Field(name="matrix", type="array")
    ])
    value, error_messages = validate_yaml(content, schema)
    assert not error_messages
    assert value == [{"matrix": [{"name": "Linux Trusty", "python": 2.7, "env": "TOXENV=py27"}, {"name": "OSX 10.9", "python": 2.7, "env": "TOXENV=py27"}]}]

# Generated at 2022-06-12 16:14:18.700007
# Unit test for function validate_yaml
def test_validate_yaml():
    from .test_cases import build_test_cases

    test_cases = build_test_cases(schema_type="yaml", schema_parse_fn=tokenize_yaml)
    for test_case in test_cases:
        test_case.execute_test_fn(validate_yaml)

# Generated at 2022-06-12 16:14:29.439613
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Test the parse of YAML content
    """
    # test for empty string
    with raises(ParseError, match="No content."):
        tokenize_yaml("")
    # test for invalid YAML
    with raises(ParseError, match="Parse error"):
        tokenize_yaml("a")

    # test for dict
    token = tokenize_yaml("a: 1")
    assert isinstance(token, DictToken)
    assert token.value["a"] == 1

    # test for list
    token = tokenize_yaml("- 1")
    assert isinstance(token, ListToken)
    assert token.value[0] == 1

    # test for scalar
    token = tokenize_yaml("1")
    assert isinstance(token, ScalarToken)

# Generated at 2022-06-12 16:14:41.445387
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.types import Boolean
    from typesystem.tokenize.position import Position

    validator = Schema({"name": String(max_length=5), "is_org": Boolean()})

    content = b"name: 'Foo Bar'\nis_org: true\n"
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "Foo Bar", "is_org": True}
    assert not errors

    content = b"name: 'Foo Bar Baz'\nis_org: true\n"
    value, errors = validate_yaml(content, validator)

# Generated at 2022-06-12 16:14:45.399224
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_content = """
    foo:
        - 1
        - 2
    """

    (value, errors) = validate_yaml(yaml_content, 
        {
            'foo' : Field('array', required=False)
        })

    assert value == { "foo": [1,2] }
    assert errors == []



# Generated at 2022-06-12 16:14:56.724561
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()
    
    content = '''
        name: Jane
        age: 20
    '''
    value, error_messages = validate_yaml(content, Person)
    assert not error_messages
    assert value == {'name':'Jane', 'age':20}
    content = '''
        name: Jane
    '''
    value, error_messages = validate_yaml(content, Person)
    assert error_messages[0] == (
        "The field 'age' is required.\n"
        "    name: Jane\n"
        "    ^^^\n"
        "    age: 20\n"
        "^^^^^^^^^^^^^^^^^^^^^^^^^^^^"
    )

# Generated at 2022-06-12 16:15:10.831972
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer
    from typesystem.schemas import Schema, create_schema_class

    class AddressSchema(Schema):
        street = String(max_length=20)
        number = Integer(minimum=0, maximum=9)
    class PersonSchema(Schema):
        name = String(max_length=10)
        address = AddressSchema
        age = Integer()

    PersonSchema = create_schema_class(PersonSchema)

    address_dict = AddressSchema().serialize({"street":"a","number":10})
    person_dict = PersonSchema().serialize({"name":"b", "address":address_dict, "age":100})
    person_dict_str = yaml.dump(person_dict, default_flow_style=False)
    #print(person_

# Generated at 2022-06-12 16:15:22.695463
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("foo: bar", {"foo": str}) == ({"foo": "bar"}, [])

    value, messages = validate_yaml("foo: bar", {"foo": bool})
    assert value is None
    assert messages == [
        Message(
            text="Must be of type 'boolean'.",
            code="type_error.boolean",
            position=Position(
                line_no=1, column_no=6, char_index=6, line_content="foo: bar"
            ),
        )
    ]

    value, messages = validate_yaml("foo: bar", {"foo": bool, "baz": str})
    assert value is None

# Generated at 2022-06-12 16:15:28.385099
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = DataField(String(min_length=3))

    value, error_messages = validate_yaml(
        """
        name: Bob
    """,
        validator=PersonSchema,
    )

    assert value == {"name": "Bob"}
    assert len(error_messages) == 0



# Generated at 2022-06-12 16:15:35.648502
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    content = """
        field:
            - item 1
            - item 2
            - item 3
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.value["field"], ListToken)
    assert "item 3" == token.value["field"].value[2].value
    assert 0 == token.value["field"].value[2].start_index
    assert 4 == token.value["field"].value[2].end_index


# Generated at 2022-06-12 16:15:48.311803
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Number, Any

    from typesystem.schemas import Schema

    class PetSchema(Schema):
        name = String(required=True)
        age = Number(required=True)
        owner = Any(required=True)

    content = """
    name: kitten
    age: 1
    owner:
      first_name: bob
      last_name: smith
      """

    assert validate_yaml(content, PetSchema) == (
        {
            "name": "kitten",
            "age": 1,
            "owner": {
                "first_name": "bob",
                "last_name": "smith"
            }
        },
        [],
    )


# Generated at 2022-06-12 16:15:57.719138
# Unit test for function validate_yaml
def test_validate_yaml():
    # Case: Valid YAML input
    errors = validate_yaml("example: 'well formed'", Field(type="object"))
    assert len(errors) == 0

    # Case: Invalid YAML input
    errors = validate_yaml("example: well formed", Field(type="object"))
    assert len(errors) == 1
    error = errors[0]
    assert isinstance(error, ParseError)
    assert error.code == "parse_error"

    # Case: Wrong type in JSON input
    errors = validate_yaml("example: '1'", Field(type="boolean"))
    assert len(errors) == 1
    error = errors[0]
    assert isinstance(error, ValidationError)
    assert error.code == "invalid_type"

    # Case: Missing required field in JSON input
    errors

# Generated at 2022-06-12 16:16:03.526226
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_content = '1'

    class MySchema(Schema):
        number = Field(type_=int)

    value, errors = validate_yaml(content=yaml_content, validator=MySchema)

    assert value == {"number": 1}
    assert len(errors) == 0


# Generated at 2022-06-12 16:16:14.200598
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test a scalar value.
    token = tokenize_yaml('"\'&amp; < > "')
    assert token.content == '"\'&amp; < > "'
    assert token.start == 0
    assert token.end == 11
    assert isinstance(token, ScalarToken)

    # Test a list value.
    token = tokenize_yaml("[1,2,3]")
    assert token.content == "[1,2,3]"
    assert token.start == 0
    assert token.end == 5
    assert isinstance(token, ListToken)

    # Test a dict value.
    token = tokenize_yaml("name: Foo")
    assert token.content == "name: Foo"
    assert token.start == 0
    assert token.end == 7

# Generated at 2022-06-12 16:16:17.803257
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "foo: 123"
    validator = Field(types=int)
    # Test the function
    value, validation_error = validate_yaml(content, validator)
    assert value == 123
    assert validation_error == None



# Generated at 2022-06-12 16:16:23.494404
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = String()
        price = Number()
        in_stock = Boolean()

    yaml_test = """
    name: test
    price: 10.0
    in_stock: True
    """

    errors = validate_yaml(yaml_test, TestSchema)

    assert len(errors) == 0


# Generated at 2022-06-12 16:16:31.248210
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        name = String(max_length=50)

    content = """
    name: "Jane"
    """
    value, error_messages = validate_yaml(content, UserSchema)
    assert value == {"name": "Jane"}
    assert error_messages == []


# Generated at 2022-06-12 16:16:37.830157
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {
            "name": str,
            "age": int,
            "hobbies": ListField(str),
            "extra": AnyField(required=False),
        }
    )

    value, error_messages = validate_yaml(
        "name: rick\nage: 9\nhobbies:\n- hockey\n- chess\nextra: null\n", schema
    )
    assert error_messages == []
    assert value == {"name": "rick", "age": 9, "hobbies": ["hockey", "chess"], "extra": None}

    value, error_messages = validate_yaml(
        "name: rick\nage: 9\nhobbies:\n- hockey\n- chess\n", schema
    )
    assert error_messages == []


# Generated at 2022-06-12 16:16:45.016622
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml with a YAML string and validator
    """
    import typesystem.types as types
    from typesystem.schemas import Schema

    content = "key1: value1\nkey2: value2"
    validator = Schema(properties={"key1": types.String(), "key2": types.String()})
    value, error_messages = validate_yaml(content=content, validator=validator)

    assert value == {"key1": "value1", "key2": "value2"}
    assert error_messages == []


# Generated at 2022-06-12 16:16:51.159042
# Unit test for function validate_yaml
def test_validate_yaml():
  token = tokenize_yaml('- name: foo\n  value: 42')
  (value, errors) = validate_with_positions(token, validator=Field(fields={'name': Field(type="string"), 'value': Field(type="integer")}))
  assert value == {'name': 'foo', 'value': 42}, value


# Generated at 2022-06-12 16:17:02.637299
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        name: Jane Doe
        age: 25
        """

    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer(min_value=0)

    value, error_messages = validate_yaml(content, PersonSchema)

    if not error_messages == []:
        raise Exception(error_messages)

    assert value == {
        "name": "Jane Doe",
        "age": 25,
    }

    content = """
        name: Jane Doe
        age: 25
        """

    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer(min_value=26)

    value, error_messages = validate_yaml(content, PersonSchema)


# Generated at 2022-06-12 16:17:10.257097
# Unit test for function validate_yaml
def test_validate_yaml():
    # In the following examples, we use a validator that is a Schema subclass.
    # This is equvalent to using a Field instance.
    class MySchema(Schema):
        my_integer = fields.Integer()

    token, messages = validate_yaml(content="foo", validator=MySchema)
    assert isinstance(token, ScalarToken)
    assert len(messages) == 1
    assert messages[0].code == "expected_type"
    assert messages[0].position.line_no == 1
    assert messages[0].position.column_no == 1
    assert messages[0].position.char_index == 0

    token, messages = validate_yaml(content="45", validator=MySchema)
    assert isinstance(token, ScalarToken)
    assert token.value == 45

# Generated at 2022-06-12 16:17:20.274803
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema

    class PetSchema(Schema):
        type = "object"
        properties = {
            "name": {"type": "string"},
            "owner": {"type": "string"},
            "age": {"type": "integer"},
        }
        required = ["name", "owner"]

    try:
        value, errors = validate_yaml(
            b"""
            name: Spot
            owner: John
            age: 7
            """,
            validator=PetSchema,
        )
    except ParseError as exc:
        print(str(exc))
        print(str(exc.position))
    except ValidationError as exc:
        print(str(exc))
        for error in exc.errors:
            print(error.text)
            print(error.position)


# Generated at 2022-06-12 16:17:31.819023
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from models.yaml import PersonSchema

    data = """id: 1
name: John Smith
hobbies: [swimming, tennis]
friends:
- id: 2
  name: Jane Smith
- id: 3
  name: Bob Smith
"""

    errors = validate_yaml(data, validator=PersonSchema)
    assert len(errors) == 0
    assert errors == []

    data = """id: 100
name: John Smith
hobbies: [swimming, tennis]
friends:
- id: 2
  name: Jane Smith
- id: 3
  name: Bob Smith
"""

    errors = validate_yaml(data, PersonSchema)
    assert len(errors) == 1

# Generated at 2022-06-12 16:17:38.203592
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String

    class TestSchema(Schema):
        name = String(min_length=4)

    result1, errors1 = validate_yaml(
        content="name: \"test\"", validator=TestSchema
    )
    assert result1 == {"name": "test"}
    assert errors1 == [
        {
            "code": "min_length",
            "message": '"name" should be at least 4 characters long.',
            "position": {"column_no": 1, "line_no": 1, "char_index": 0},
            "severity": "error",
            "type": "string",
        }
    ]

    class TestSchema(Schema):
        names = String(format="list")


# Generated at 2022-06-12 16:17:45.659807
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Test for function tokenize_yaml
    """
    # Test with YAML
    yaml_string = """
    foo: yaml
    baz:
      - abc
      - def
    """
    token = tokenize_yaml(yaml_string)
    assert token.content == yaml_string
    assert token["foo"] == "yaml"
    assert token["baz"] == ["abc", "def"]



# Generated at 2022-06-12 16:17:59.769156
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String

    field = String()

    value, errs = validate_yaml("a: string", field)
    assert value == "string"
    assert errs == []

    value, errs = validate_yaml("a: ", field)
    assert errs == [
        Message(
            text="Missing value.",
            code="required",
            position=Position(
                column_no=3, line_no=1, char_index=2,
            ),
        ),
    ]

    value, errs = validate_yaml("a", field)

# Generated at 2022-06-12 16:18:11.034640
# Unit test for function validate_yaml
def test_validate_yaml():
    # Content not valid YAML
    content = """foo:
bar"""
    validator = Schema({"foo": str})
    with pytest.raises(ParseError):
        _, error_messages = validate_yaml(content, validator)
    assert len(error_messages) == 1
    message = error_messages[0]
    assert message.text == "mapping values are not allowed here. Did you forget a colon?"
    assert message.code == "parse_error"
    assert message.position.line_no == 2
    assert message.position.column_no == 1
    assert message.position.char_index == 13

    # Content valid YAML but not valid schema
    content = """foo: True
bar: False"""
    validator = Schema({"foo": str})

# Generated at 2022-06-12 16:18:16.649555
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"foo": {"type": "string"}})
    content = "{foo: bar}"
    value, error_msgs = validate_yaml(content, schema)
    assert value == {}
    assert error_msgs == [
        Message(
            text="Value 'bar' is not a valid string.",
            code="invalid_type",
            position=Position(column_no=6, char_index=5, line_no=1),
        )
    ]

# Generated at 2022-06-12 16:18:23.282711
# Unit test for function validate_yaml
def test_validate_yaml():
    result, errors = validate_yaml('{"name": "foo", "text": "bar"}', Schema({
        "name": {"type": "string", "max_length": 10},
        "text": {"type": "string", "max_length": 10},
    }))
    assert result == {"name": "foo", "text": "bar"}
    assert errors == []

# Generated at 2022-06-12 16:18:33.860638
# Unit test for function validate_yaml
def test_validate_yaml():
    import json
    from collections import namedtuple
    
    from typesystem import Integer
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        my_field = Integer()

    my_schema = MySchema()
    
    class MySchema2(Schema):
        my_field = Integer(required=False)

    my_schema2 = MySchema2()
    
    
    

# Generated at 2022-06-12 16:18:44.435514
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test tokenizing an empty string
    try:
        tokenize_yaml("")
    except ParseError as err:
        assert err.text == "No content."
        # Position should be at the start of line 1, column 1 of empty string
        assert err.position.column_no == 1
        assert err.position.line_no == 1
        assert err.position.char_index == 0
    else:
        assert False, "Exception should be raised"
    
    # Test empty object
    token = tokenize_yaml("{}")
    assert isinstance(token, DictToken)
    assert len(token) == 0
    assert token.start == 0
    assert token.end == 1
    assert token.content == "{}"

    # Test empty array
    token = tokenize_yaml("[]")

# Generated at 2022-06-12 16:18:48.791897
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "yaml: 'foo'"
    result = validate_yaml(content, Field(type="string"))
    assert result == ({"yaml": "foo"}, [])

    content = "yaml: 100"
    result = validate_yaml(content, Field(type="string"))
    assert result == (
        {},
        [Message(text="Value must be a string.", code="type", position=Position(line_no=1, column_no=7, char_index=6))],
    )



# Generated at 2022-06-12 16:18:57.817898
# Unit test for function validate_yaml
def test_validate_yaml():
    text = b"""
    [
        {
            "int_value": 1,
            "bool_value": true,
            "float_value": 1.0,
            "string_value": "1",
            "no_value": null
        }
    ]
    """
    x = validate_yaml(
        content=text,
        validator=List(
            items=Schema(
                fields={
                    "int_value": fields.Integer,
                    "bool_value": fields.Boolean,
                    "float_value": fields.Float,
                    "string_value": fields.String,
                    "no_value": fields.String,
                }
            )
        ),
    )



# Generated at 2022-06-12 16:19:06.485683
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import StandardSchema
    from typesystem import types

    class MySchema(StandardSchema):

        foo = types.String()
        bar = types.Boolean()

    content = """
        foo: 'bar'
        bar: true
    """
    validator = MySchema()
    error_messages = validate_yaml(content, validator)[1]
    assert error_messages is None
    assert validate_yaml(content, validator)[0] == {"foo": "bar", "bar": True}


# Generated at 2022-06-12 16:19:17.355795
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml.
    """
    yaml_schema_fields = {
        "name": str,
        "age": int,
    }
    yaml_schema_str = """
    name: str
    age: int
    """
    yaml_str = """
    name: John Doe
    age: 25
    """
    yaml_str_bad_type = """
    name: John Doe
    age: hello
    """

    # Test validaton of YAML string against YAML schema.
    assert validate_yaml(yaml_str, yaml_schema_str)[1] == []
    assert validate_yaml(yaml_str_bad_type, yaml_schema_str)[1] != []

    # Test validation of YAML string against YAML schema

# Generated at 2022-06-12 16:19:29.797983
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "1"
    validator = Field(type="integer")
    assert validate_yaml(content, validator) == (1, [])

    content = "foo"
    validator = Field(type="integer")
    value, messages = validate_yaml(content, validator)
    print(value)
    print(messages)
    assert isinstance(messages[0], ValidationError)
    assert messages[0].message == "Value is not a valid integer."



# Generated at 2022-06-12 16:19:41.368126
# Unit test for function validate_yaml
def test_validate_yaml():
    class User(Schema):
        username = fields.String(format="slug")
        password = fields.String(min_length=6)

    # Test that a valid YAML string returns a value and empty error messages.
    content = """
    username: rj
    password: rjrules
    """
    value, errors = validate_yaml(content, validator=User)
    assert value is not None
    assert not errors

    # Test that an invalid YAML string raises a ParseError.
    content = "username: rj & password: rjrules"
    with pytest.raises(ParseError):
        validate_yaml(content, validator=User)

    # Test that a valid YAML string with invalid data raises an error.

# Generated at 2022-06-12 16:19:47.875541
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        key:
          - value
          - value2
      """
    validator = Schema([
        {'key': List(String)}
    ])
    value, error_messages = validate_yaml(content, validator)
    assert value == {'key': ['value', 'value2']}
    assert error_messages == {}

# Generated at 2022-06-12 16:19:59.220167
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "TestSchema"
        fields = [
            {"name": "person_id", "type": "integer"},
            {"name": "name", "type": "string"},
            {"name": "age", "type": "integer"},
        ]

    content = """\
        ---
        person_id: 123
        name: John Doe
        age: 33
        """

    value, messages = validate_yaml(content, TestSchema)
    assert len(messages) == 0
    assert value["person_id"] == 123
    assert value["name"] == "John Doe"
    assert value["age"] == 33

    content = """\
        ---
        hello: world
        """

    value, messages = validate_yaml(content, TestSchema)

# Generated at 2022-06-12 16:20:06.429921
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import String, Array

    class BadArrayItem(String):
        pattern = r"^[a-c]$"

    class BadArray(Array):
        items = BadArrayItem()

    class BadRecord(Schema):
        bad_field = BadArray()

    content = """
        bad_field:
            - a
            - b
            - c
            - d
            - e
    """

    value, error_messages = validate_yaml(content=content, validator=BadRecord)

    assert value is None
    assert len(error_messages) == 5

    for error_message in error_messages:
        assert error_message.code == "does_not_match_pattern"
        assert error_message.position.line_no == 7

# Generated at 2022-06-12 16:20:17.833240
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Number

    # Valid string, returns value and error_messages
    assert validate_yaml("3.14", Number()) == (3.14, [])

    # Inalid string, raises validation error
    with pytest.raises(ValidationError):
        _, error_messages = validate_yaml("1.0", Number(minimum=10))
        assert [
            error_message.text
            for error_message in error_messages
            if error_message.code == "minimum"
        ] == ["Must be at least 10."]

    # Invalid string, raises parse error
    with pytest.raises(ParseError):
        _, error_messages = validate_yaml("3.14", Number(minimum=10))
        assert error_messages.text == "No content."
        assert error_

# Generated at 2022-06-12 16:20:27.229279
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"name": str,
                     "age": int,
                     "location": {"lat": float, "long": float}})
    yaml_str = '''
    name: Alex
    age: 23
    location: 
      lat: 45.0
      long: -1
    '''
    content, messages = validate_yaml(yaml_str, schema)
    assert len(messages) == 0
    assert content == {'name': 'Alex', 'age': 23, 'location': {'lat': 45.0, 'long': -1.0}}
    assert content['name'] == 'Alex'
    assert content['age'] == 23
    assert content['location']['lat'] == 45.0
    assert content['location']['long'] == -1.0


# Generated at 2022-06-12 16:20:37.773296
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test empty string
    assert validate_yaml("", str) == ('', Message(code='no_content', text='No content.', position=Position(1, 1, 0)))

    # Test scalar tokens
    assert validate_yaml("hi", str) == ('hi', None)
    assert validate_yaml("123", int) == (123, None)
    assert validate_yaml("123", str) == ('123', None)
    assert validate_yaml("true", bool) == (True, None)
    assert validate_yaml("false", bool) == (False, None)
    assert validate_yaml("1.0", float) == (1.0, None)
    assert validate_yaml("1.0", str) == ('1.0', None)

# Generated at 2022-06-12 16:20:47.776459
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test that validate_yaml works as intended.
    """
    schema = Schema({"a": str})

    assert tokenize_yaml("{a: 'str'}") == {
        "a": ScalarToken("str", 4, 8, content="{a: 'str'}")
    }

    assert validate_yaml("{a: 'str'}", schema) == ({'a': 'str'}, [])

    @schema.validator
    def validator(value: typing.Any, path: typing.List[str]) -> typing.Any:
        # invalid validator
        if int(value["a"]) == 1:
            return value

# Generated at 2022-06-12 16:20:59.316726
# Unit test for function validate_yaml
def test_validate_yaml():
    import os
    import pathlib

    parent_dir = pathlib.Path(__file__).parent.parent
    here = pathlib.Path(__file__)

    params_path = os.path.join(str(parent_dir), "examples", "parameters.yml")
    params_test_path = os.path.join(str(parent_dir), "examples", "parameters_test.yml")
    params_path_str = open(params_path).read()
    params_test_str_raw = open(params_test_path).read()

    # Remove empty lines and trailing whitespace since to prevent problems with generated fixtures
    params_test_str = "\n".join([line.rstrip() for line in params_test_str_raw.split("\n") if line != ""])
    

# Generated at 2022-06-12 16:21:19.412101
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(b"# some content\n", String()) == ("", [])
    try:
        validate_yaml(b"!!python/object", String())
    except ParseError as exc:
        assert exc.text == "found unknown tag '!python/object'; expected a sequence or mapping."
    else:
        assert False  # pragma: no cover
    try:
        validate_yaml(b"a: b", String())
    except ValidationError as exc:
        assert exc.field_name == ""
        assert exc.code == "invalid_type"
        assert exc.text == "expected str, received dict."
    else:
        assert False  # pragma: no cover

# Generated at 2022-06-12 16:21:27.095238
# Unit test for function validate_yaml
def test_validate_yaml():
    import pytest
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String
    from typesystem import SchemaError

    class MySchema(Schema):
        foo = String(allow_blank=True)
        bar = Integer()

    with pytest.raises(SchemaError):
        # Invalid YAML should raise a SchemaError.
        validate_yaml(content='invalid: "yaml"', validator=MySchema)

    value, error_messages = validate_yaml(content="", validator=MySchema)
    assert not error_messages

    value, error_messages = validate_yaml(
        content="""
        foo: yep, that's a string
        bar: 123
        """,
        validator=MySchema,
    )


# Generated at 2022-06-12 16:21:33.461972
# Unit test for function validate_yaml
def test_validate_yaml():
    valid_data = """
    ---
    id: foo
    """

    class SimpleSchema(Schema):
        id = "string"

    value, errors = validate_yaml(valid_data, validator=SimpleSchema)

    assert value is not None
    assert errors is not None
    assert isinstance(errors, list)
    assert len(errors) == 0



# Generated at 2022-06-12 16:21:44.679612
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Testing validate_yaml function
    """
    yaml_str = """
    - id:
        1
        2
    """
    try:
        validate_yaml(content=yaml_str, validator=Schema)
    except ParseError as parse_err:
        assert isinstance(parse_err, ParseError)
        assert isinstance(parse_err.position, Position)
        assert parse_err.position.line_no == 3
        assert parse_err.position.column_no == 5
        assert parse_err.position.char_index == 10
        assert parse_err.code == "parse_error"
        assert parse_err.text == "found duplicate key."



# Generated at 2022-06-12 16:21:52.259131
# Unit test for function validate_yaml
def test_validate_yaml():
    from io import StringIO
    from typesystem import Schema, fields, validate
    from typesystem.exceptions import ValidationError

    # Test case 1
    class DocumentSchema(Schema):
        document = fields.String()

    f = StringIO("document: A")
    
    assert validate_yaml(f.read(), validator=DocumentSchema) == ({"document": "A"}, [])

    # Test case 2
    class DocumentSchema(Schema):
        document = fields.String()

    f = StringIO("document: A\ndocument: B")
    try:
        validate_yaml(f.read(), validator=DocumentSchema)
    except ValidationError as e:
        assert e.message_dict == {
            "document": ["Encountered multiple values for field."]
        }

    # Test

# Generated at 2022-06-12 16:22:02.662963
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    name: "Hello World"
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert len(token.value) == 1
    assert isinstance(token.value["name"], ScalarToken)
    assert token.value["name"].value == "Hello World"

    content = """
    sequence:
    - 1
    - 2
    - 3
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert len(token.value) == 1
    assert isinstance(token.value["sequence"], ListToken)
    assert len(token.value["sequence"].value) == 3
    assert isinstance(token.value["sequence"].value[0], ScalarToken)
    assert token.value

# Generated at 2022-06-12 16:22:08.662496
# Unit test for function validate_yaml
def test_validate_yaml():
    # Valid input
    assert validate_yaml('''
    a:
        b: 1
    c:
        - 2
        - 3
    ''', Schema({
        'a': {'b': 'number'},
        'c': ['number'],
    })) == (
        {'a': {'b': 1}, 'c': [2, 3]},
        []
    )

    # Invalid input