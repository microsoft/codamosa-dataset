

# Generated at 2022-06-12 16:12:31.787509
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
        - hello: world
          a:
            - b
            - c
            - d
        - ef:
            - 1
            - 2
            - 3
    '''

    result = tokenize_yaml(content)


# Generated at 2022-06-12 16:12:41.270688
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.tokenize.tokens import DictToken, ScalarToken
    from typesystem.fields import Integer, String

    class FooSchema(Schema):
        age = Integer()
        name = String()

    def _get_content(content: str) -> bytes:
        return content.encode("utf-8")

    instance = {"name": "Fee", "age": 30}
    token = DictToken(instance, content=instance)
    json_str = json.dumps(instance)
    yaml_str = "name: Fee\nage: 30"
    assert validate_with_positions(token, validator=FooSchema) == (instance, [])
    assert validate_yaml(content=yaml_str, validator=FooSchema) == (instance, [])
    assert validate_

# Generated at 2022-06-12 16:12:44.216731
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(content=b"value: 1")

    assert isinstance(token, DictToken)
    assert isinstance(token[0], ScalarToken)

    token.content == "value: 1"
    scalar_token = token[0]
    scalar_token.content == "1"
    scalar_token.value == 1


# Generated at 2022-06-12 16:12:51.579505
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem import Integer
    from typesystem.schemas import Schema
    class PersonSchema(Schema):
        age = Integer()

    try:
        validate_yaml("{}", PersonSchema)
    except ValidationError as exc:
        assert exc.message == [Message(
            text="This field is required.",
            code="required",
            position=Position(
                line_no=1, column_no=1, char_index=0
            ),
        )]
    else:
        assert False

# Generated at 2022-06-12 16:13:00.475357
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        foo:
            - baz
        spam:
            - eggs
    """)
    assert isinstance(token, DictToken)
    assert token.end_index == 56
    assert token.start_index == 0
    assert len(token.keys()) == 2
    assert token.get("foo") == [ScalarToken("baz", 11, 16, content=str("baz"))]
    assert token["spam"][0].value == "eggs"



# Generated at 2022-06-12 16:13:06.079418
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "name: John"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.content == "name: John"
    assert token.start == 0
    assert token.end == 5
    assert token.fields["name"].content == "John"
    assert token.fields["name"].start == 5
    assert token.fields["name"].end == 10


# Generated at 2022-06-12 16:13:16.288525
# Unit test for function validate_yaml
def test_validate_yaml():
    schema_string = """
    description: A person
    type: object
    properties:
      name:
        type: string
    """

    schema_instance = Schema.from_string(schema_string)

    content = """
    name: John Doe
    """

    _, errors = validate_yaml(content, schema_instance)
    assert errors == []

    content = """
    name: John Doe
    DOB: 1979-10-08
    """

    _, errors = validate_yaml(content, schema_instance)

# Generated at 2022-06-12 16:13:24.986648
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem.fields import String, Integer

    field = String(required=True, pattern=r"^\w+$")
    value, error_messages = validate_yaml(content="abc", validator=field)
    assert value == "abc"
    assert not error_messages

    content = "---\n" "key: abc\n"
    schema = Schema.parse({"key": {"type": "string", "pattern": r"^\w+$"}})
    value, error_messages = validate_yaml(content=content, validator=schema)
    assert value == {"key": "abc"}
    assert not error_messages

    content = "---\n" "key: 123\n"
    value, error

# Generated at 2022-06-12 16:13:30.097240
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(''), Token)
    assert isinstance(tokenize_yaml('str'), Token)
    assert isinstance(tokenize_yaml('str2'), Token)
    assert isinstance(tokenize_yaml('40'), Token)
    assert isinstance(tokenize_yaml('{}'), Token)
    assert isinstance(tokenize_yaml('[]'), Token)
    assert isinstance(tokenize_yaml('{"a": 1}'), Token)
    assert isinstance(tokenize_yaml('{"a": []}'), Token)
    assert isinstance(tokenize_yaml('{"a": [1]}'), Token)
    assert isinstance(tokenize_yaml('{"a": [1,2]}'), Token)

# Generated at 2022-06-12 16:13:41.450123
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    try:
        import yaml
    except:
        raise Exception("pyyaml is a dependency of the function tokeize_yaml, Please install pyyaml.")

    # test integer
    content = '''
    103
    '''
    token = tokenize_yaml(content)
    assert isinstance(token, ScalarToken)
    assert token.value == 103

    # test string
    content = '''
    one
    '''
    token = tokenize_yaml(content)
    assert isinstance(token, ScalarToken)
    assert token.value == "one"

    # test list
    content = '''
    - 1
    - 2
    '''
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert len(token.value) == 2


# Generated at 2022-06-12 16:13:53.951817
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from tests.test_yaml_validation import pet
    from typesystem.tokenize.tokens import ScalarToken

    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("foo"), ScalarToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml("0.5"), ScalarToken)
    assert isinstance(tokenize_yaml("-10"), ScalarToken)
    assert isinstance(tokenize_yaml("-0.5"), ScalarToken)
   

# Generated at 2022-06-12 16:13:58.498305
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String

    content = b"""
        name: Typesystem
        version: '1.1.0'
    """

    validator = String()

    result, messages = validate_yaml(content, validator)

    assert not messages
    assert result == "Typesystem"


# Generated at 2022-06-12 16:14:04.132568
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    input =\
"""
message:
  name: HelloWorld
  inner:
    message:
      name: HelloWorld2
      fields:
        - name: bar
          type: int32
          number: 2
"""
    tok = tokenize_yaml(input)
    assert isinstance(tok, DictToken)
    # TODO: expand this test to cover more cases


# Generated at 2022-06-12 16:14:12.538110
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    data = '''
        name: "John Doe"
        age:  43
        spouse: Jane Doe
        children:
          - Mary Doe
          - Richard Roe
        # address:
        #   123 Main St
        #   Springfield, OR 97477
        pets:
          dog: Spot
        '''
    data_original = data
    d = yaml.load(data, Loader=yaml.Loader)
    d_original = d
    print(type(d))
    print(d)
    class Person(typesystem.Schema):
        name = typesystem.String(min_length=7)
        age = typesystem.Integer(maximum=80)
        spouse = typesystem.String(allow_null=True)
        pets = typesystem.Dictionary(value=typesystem.String())

# Generated at 2022-06-12 16:14:23.321439
# Unit test for function validate_yaml
def test_validate_yaml():
    from typing import Dict, List, Union

    class TestSchema(Schema):
        name = Field(str)
        age = Field(int, required=False)

    validator = TestSchema()
    content = """\
        name: John Smith
        age: 30
    """
    value, errors = validate_yaml(content, validator)
    assert not errors
    assert value == {"name": "John Smith", "age": 30}

    content = """\
        name: John Smith
        age: thirty
    """
    value, errors = validate_yaml(content, validator)
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"

    class TestSchema(Schema):
        name = Field(str)

# Generated at 2022-06-12 16:14:30.481958
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields

    class MessageSchema(Schema):
        body = fields.String(required=True)

    content = """
    - name: "foo"
        body: "Hello, world!"
    - name: "foo"
        body: "Hello, world!"
    """

    messages, errors = validate_yaml(content, MessageSchema)
    assert errors == []
    assert len(messages) == 2
    assert messages[0].body == "Hello, world!"
    assert messages[1].body == "Hello, world!"


# Generated at 2022-06-12 16:14:35.997608
# Unit test for function validate_yaml
def test_validate_yaml():

    content = "foo: bar"
    field = Field(name='foo', description='foo description')
    field.validators = [validate_yaml]
    assert field.validate(content) is True
    assert field.parse_value(content) == 'bar'

# Generated at 2022-06-12 16:14:44.072586
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("\"a\"") == "a"
    assert tokenize_yaml("true") is True
    assert tokenize_yaml("false") is False
    assert tokenize_yaml("null") is None


# Generated at 2022-06-12 16:14:55.540022
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == []
    assert tokenize_yaml("\n") == []
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_yaml("a: 1") == {"a": 1}
    assert tokenize_yaml("a: {}") == {"a": {}}
    assert tokenize_yaml("a:\n  b: []") == {"a": {"b": []}}
    assert tokenize_yaml("[1]\n") == [1]
    assert tokenize_yaml("a: 2") == {"a": 2}
    assert tokenize_yaml("a: b") == {"a": "b"}

# Generated at 2022-06-12 16:14:58.897717
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Test if function tokenize_yaml returns correct output
    """
    content = '{"hello":"world"}'
    assert (tokenize_yaml(content)).value == {'hello': 'world'}


# Generated at 2022-06-12 16:15:12.106640
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content=b"", validator=dict) == (dict(), [])
    assert validate_yaml(content=b'{"a": 42}', validator=dict) == ({"a": 42}, [])

    with pytest.raises(ParseError) as excinfo:
        validate_yaml(content=b"x", validator=dict)
    assert str(excinfo.value) == "ParseError at index 0: Expected '{'. (code: parse_error)"

    with pytest.raises(ValidationError) as excinfo:
        validate_yaml(content=b"{}", validator={"a": int})
    assert str(excinfo.value) == "ValidationError: 'a' is a required field."

# Generated at 2022-06-12 16:15:24.813382
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_content = """
    name: "Foo"
    age: 25
    """
    class TestSchema(Schema):
        name = String()
        age = Integer()
    value, errors = validate_yaml(yaml_content, validator=TestSchema)
    assert value == {
        "name": "Foo",
        "age": 25
    }
    assert errors == []

    yaml_content = """
    name: "Foo"
    age: 25
    """
    class TestSchema(Schema):
        name = String()
        age = String()
    value, errors = validate_yaml(yaml_content, validator=TestSchema)
    assert value is None
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)

# Generated at 2022-06-12 16:15:31.658992
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = String(max_length=10)
        age = Integer()
        catchphrase = String()

    data = """
        name: daniel
        age: 99
        catchphrase: hello there
    """

    value, errors = validate_yaml(data, PersonSchema)
    assert not errors
    assert value == {"name": "daniel", "age": 99, "catchphrase": "hello there"}

# Generated at 2022-06-12 16:15:38.715516
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Unit Tests for the validate_yaml function.
    """
    # Content that should pass validation
    content = "1"
    validator = Field(type="integer")
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == []
    assert value == 1

    content = "a"
    validator = Field(type="string")
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == []
    assert value == "a"

    content = "[1, 2, 3]"
    validator = Field(type="array")
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == []
    assert value == [1, 2, 3]


# Generated at 2022-06-12 16:15:46.565406
# Unit test for function validate_yaml
def test_validate_yaml():
    sample_yaml = """
        foo: hello
        bar: 1
        baz: null
    """
    value, error_messages = validate_yaml(
        sample_yaml,
        {
            "foo": Field(type="string"),
            "bar": Field(type="integer"),
            "baz": Field(type="null"),
        },
    )
    assert value == {"foo": "hello", "bar": 1, "baz": None}
    assert not error_messages

# Generated at 2022-06-12 16:15:47.962808
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("yes: yes") == {'yes': 'yes'}

# Generated at 2022-06-12 16:15:51.119532
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"name": fields.String()})
    content = "name: bob"
    result = validate_yaml(content, schema)
    assert result.value['name'] == 'bob'



# Generated at 2022-06-12 16:15:59.546255
# Unit test for function validate_yaml
def test_validate_yaml():
    
    # Test a valid program
    content = '''
    - type: "create" lang: "python"
      code: |
        def main():
          print("Hello world!")
          
        main()
    '''
    
    # Create a validator for the program
    from typesystem import types

    class Program(Schema):
        type = types.Enum(choices=["create", "delete"])
        lang = types.Enum(choices=["python", "c"])
        code = types.String()

    # Validate the program and check that the result is
    # a 2-tuple of data and an empty list of errors.
    result = validate_yaml(content, validator=Program)

# Generated at 2022-06-12 16:16:08.037883
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_content = """
customer:
    name: Daniel
    phone:
        - 123
        - 456
    age: 18
    """
    class CustomerSchema(Schema):
        name = Field(type=str, min_length=1)
        age = Field(type=int, min_length=1)

    parsed_value, errors = validate_yaml(
        yaml_content,
        validator=CustomerSchema,
    )
    print(parsed_value)
    print(errors)

test_validate_yaml()

# Generated at 2022-06-12 16:16:19.965075
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = fields.String(max_length=100)
        age = fields.Integer(minimum=0, maximum=100)
        is_ok = fields.Boolean()

    # Parse and validate a YAML string, returning positionally marked
    # error messages on parse or validation failures.

    result, error_messages = validate_yaml(
        content='''
        name: value
        age: -1
        is_ok: 1
        ''',
        validator=TestSchema,
    )

    assert result == {
        'name': 'value',
        'age': -1,
        'is_ok': True
    }

# Generated at 2022-06-12 16:16:26.580693
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0)

    value, errors = validate_yaml(
        b"name: Eric\nage: 35",
        TestSchema
    )
    assert errors == []

# Generated at 2022-06-12 16:16:35.538007
# Unit test for function validate_yaml
def test_validate_yaml():
    """Tests for function validate_yaml"""

    init_text = """
input:
  - - "a"
    - "b"
  - - "c"
    - "d"
output:
  - - "aa"
    - "bb"
  - - "cc"
    - "dd"
"""

    yaml_invoke_schema = yaml.load(
"""
input:
  - type: string
output:
  - type: string
""", yaml.SafeLoader)

    yaml_invoke_spec = yaml.load(init_text, yaml.SafeLoader)
    yaml_invoke_model = typing.cast(typing.Dict[str, typing.List[typing.Any]], yaml_invoke_spec)

# Generated at 2022-06-12 16:16:45.461877
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # (1) Test tokenize_yaml with a dict
    dict_test = '{"test": 1, "test2": "1"}'
    dict_test2 = 'test: 1\ntest2: "1"'
    token = tokenize_yaml(dict_test)
    assert isinstance(token, DictToken)
    token2 = tokenize_yaml(dict_test2)
    assert isinstance(token2, DictToken)

    # (2) Test tokenize_yaml with a list
    list_test = "[1, '1']"
    list_test2 = "- 1\n- '1'"
    token = tokenize_yaml(list_test)
    assert isinstance(token, ListToken)
    token2 = tokenize_yaml(list_test2)

# Generated at 2022-06-12 16:16:57.816903
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Array

    class ExampleSchema(Schema):
        name = String()
        tags = Array(items=String(), min_length=1)

    # Validate a valid content
    value, error_messages = validate_yaml(
        content=b"""name: John Smith
tags:
  - male
  - tall
  - handsome
""",
        validator=ExampleSchema(),
    )
    assert value == {
        "name": "John Smith",
        "tags": ["male", "tall", "handsome"],
    }
    assert not error_messages

    # Parse error

# Generated at 2022-06-12 16:17:07.470098
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml with example content, validator
    """
    content = "hello: world\n123: 456\n"
    # convert_to_yaml
    token = tokenize_yaml(content)
    # print(token.as_python())
    # print(token.to_json())
    # print(token.to_yaml())

    from typesystem import ValidationError, Schema, fields
    from typing import Any, List, Union

    class SimpleSchema(Schema):
        """
        Simple example schema for testing
        """
        hello = fields.Text(description="hello world")
        other_field = fields.Integer()

    # validate_with_positions
    validator = SimpleSchema

# Generated at 2022-06-12 16:17:09.241774
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(name={"type": "string"})
    assert validate_yaml(b"name: my_name", schema) == (({"name": "my_name"}, []))

# Generated at 2022-06-12 16:17:17.031435
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String

    content = "foo: bar"

    class Schema(Schema):
        foo = String()

    value, error_messages = validate_yaml(content, validator=Schema)
    assert value == {"foo": "bar"}
    assert len(error_messages) == 0

    content = "foo: 1"

    value, error_messages = validate_yaml(content, validator=Schema)
    assert value == {}
    assert len(error_messages) == 1

# Generated at 2022-06-12 16:17:21.381896
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = {
        'type': 'object',
        'properties': {
            'no': {'type': 'integer'},
            'name': {'type': 'string', 'maxLength': 50},
            'address': {'type': 'string', 'maxLength': 100},
            'city': {'type': 'string', 'maxLength': 50},
            'state': {'type': 'string', 'maxLength': 2},
            'zip': {'type': 'string', 'pattern': '^[0-9]{5}$'},
            'country': {'type': 'string', 'maxLength': 50},
            'tags': {'type': 'array', 'items': {'type': 'string', 'maxLength': 50}}
            }
        }
    schema = Schema.from_dict(schema)

   

# Generated at 2022-06-12 16:17:27.476604
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    validator = Field(name="text", type="string")
    value, __ = validate_yaml(
        content="user: \n  name: Chris Oliver \n  email: excid3@gmail.com",
        validator=validator,
    )
    assert value == "user: \n  name: Chris Oliver \n  email: excid3@gmail.com"



# Generated at 2022-06-12 16:17:36.637884
# Unit test for function validate_yaml
def test_validate_yaml():
    sample_schema = {
        "string_field": {"type": "string"},
        "integer_field": {"type": "integer"},
        "boolean_field": {"type": "boolean"},
        "optional_string_field": {"type": "string", "required": False},
        "list_of_integers": {"type": "array", "items": {"type": "integer"}},
    }
    schema = Schema(schema = sample_schema)
    test_data = \
"""string_field: "abc"
integer_field: "5"
boolean_field: "yes"
list_of_integers: [1,2,3,4,"5"]
"""
    value, error_messages = validate_yaml(test_data, Schema(sample_schema))
    assert error_messages

# Generated at 2022-06-12 16:17:44.611453
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""
    name: Foo
    age: 18
    """
    validator = typing.cast(Schema, typed_schema)

    value, error_messages = validate_yaml(content, validator)

    assert value == {"name": "Foo", "age": 18}
    assert error_messages == []



# Generated at 2022-06-12 16:17:52.943916
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test empty string
    empty_string = ""
    with pytest.raises(ParseError):
        tokenize_yaml(empty_string)

    # yaml content
    yaml_content = """
        name:    Test
        email:   test@example.com
        website: https://example.com
        subjects:
          - Python
          - TypeScript
      """
    # parse the yaml_content
    parsed_content = tokenize_yaml(yaml_content)
    assert isinstance(parsed_content, DictToken)
    assert parsed_content.value == {
        'name': 'Test',
        'email': 'test@example.com',
        'website': 'https://example.com',
        'subjects': ['Python', 'TypeScript']
    }
    # Get the first

# Generated at 2022-06-12 16:18:02.185083
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem

    class Person(typesystem.Schema):
        name = typesystem.String(max_length=100)
        age = typesystem.Integer()

    content = """\
    name: Paul Atreides
    age: 16
    """
    value, errors = validate_yaml(content, Person)
    assert not errors
    assert value == {"name": "Paul Atreides", "age": 16}
    assert value == Person(**value)

    content = """\
    name:
    age: 16
    """
    _, errors = validate_yaml(content, Person)
    assert errors
    assert errors[0].text == "This field may not be blank."

    content = """\
    name: Paul Atreides
    age: 16
    """

# Generated at 2022-06-12 16:18:11.035191
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema, fields

    class PetSchema(Schema):
        name = fields.String()
        age = fields.Integer()
        breed = fields.String()

    yaml_content = """
    name: Mousey
    age: 6
    breed: Mouse
    """

    result = validate_yaml(yaml_content, PetSchema())
    assert result[0] == {"name": "Mousey", "age": 6, "breed": "Mouse"}
    assert result[1] == []



# Generated at 2022-06-12 16:18:19.108037
# Unit test for function validate_yaml
def test_validate_yaml():
    # Valid case
    content = '''
    username: james
    first_name: James
    last_name: Smith
    is_active: true
    '''

    class User(typesystem.Schema):
        username = typesystem.Text(format=typesystem.TextFormat.slug)
        first_name = typesystem.Text(
            max_length=50,
            title='First name',
            description='A user\'s first name.'
        )
        last_name = typesystem.Text(
            max_length=50,
            title='Last name',
            description='A user\'s last name.'
        )
        is_active = typesystem.Boolean()

    value, error_messages = validate_yaml(content, User)

    assert value is not None

# Generated at 2022-06-12 16:18:21.610667
# Unit test for function validate_yaml
def test_validate_yaml():
    token = tokenize_yaml('foo: bar\n')
    assert token == {'foo': 'bar'}

# Generated at 2022-06-12 16:18:32.539130
# Unit test for function validate_yaml
def test_validate_yaml():
    test = """
    schools:
      -   name: SFU
          id: 123
          country: Canada
          address:
              city: Burnaby
              postal:
                  street: University Drive
                  code: V5A 1S6
      -   name: UBC
          id: 567
          country: Canada
          address:
              city: Vancouver
              postal:
                  street: Wesbrook Mall
                  code: V6T 1Z4
    """
    value, messages = validate_yaml(test, Schema)
    # print(messages)

# Generated at 2022-06-12 16:18:44.127175
# Unit test for function validate_yaml
def test_validate_yaml():
    json_result = validate_yaml(
        """
{
  "text": "Foo",
  "boolean": true, 
  "integer": 123, 
  "float": 123.4,    
  "list": [
    "Foo", 
    "Bar"
  ],
  "optional": "baz", 
  "someobject": {
    "a": "b", 
    "c": "d"
  }
  }
""",
        Schema(
            {
                "text": "string",
                "boolean": "boolean",
                "integer": "integer",
                "float": "number",
                "list": "array",
                "optional": "string?=baz",
                "someobject": "object",
            }
        ),
    )

    assert json

# Generated at 2022-06-12 16:18:50.472912
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    #Testing mapping and list
    content = "age: 100\nname: foobar"

    expected_result = DictToken(
        [
            ("age", ScalarToken(100, start=4, end=6, content="age: 100\nname: foobar")),
            (
                "name",
                ScalarToken(
                    "foobar",
                    start=13,
                    end=20,
                    content="age: 100\nname: foobar",
                ),
            ),
        ],
        start=0,
        end=20,
        content="age: 100\nname: foobar",
    )

    assert tokenize_yaml(content) == expected_result

    content = "100\n- foobar\n- foobaz"


# Generated at 2022-06-12 16:18:59.087686
# Unit test for function validate_yaml
def test_validate_yaml():
    validate_yaml(
        content="age:18\n",
        validator=Schema(fields={"age": Field(primitive_type=int, required=True)}),
    )
    # TypeError: __init__() missing 1 required positional argument: 'fields'
    # validate_yaml(content='age:18\n', validator=Schema())
    validate_yaml(
        content="age:18\n",
        validator=Schema(
            fields={"age": Field(primitive_type=int, required=True)},
            strict=True,
        ),
    )
    validate_yaml(
        content="age:18\n",
        validator=Schema(fields={"age": Field(primitive_type=int, required=True)}),
    )



# Generated at 2022-06-12 16:19:07.891717
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestValidator(Schema):
        foo = {"type": int}
        bar = {"type": str, "default": "baz"}

    content = "foo: 123\nbar: abc"
    value, error_messages = validate_yaml(content, TestValidator)

    assert value == {"foo": 123, "bar": "abc"}
    assert len(error_messages) == 0

# Generated at 2022-06-12 16:19:18.443101
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import String, Dict, Boolean, Float, Integer, Any, List
    from typesystem import ValidationError
    class ExampleSchema(Schema):
        name = String(default='myname', min_length=1)
        enabled = Boolean(default=True)
        balance = Float(default=10.0, minimum=0.0)
        age = Integer(default=25, minimum=15)
        address = Dict({"city": String(default='pune'), "zip": String(default='12345')})
        # Array of any type with enums
        status = List(Any, enum=['todo', 'done', 'deleted'])
        # Array of dicts
        hobbies = List(Dict({"name": String(default=""), "type": String(default="")}))

    ###  trigger error

# Generated at 2022-06-12 16:19:24.012162
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(name="test", type=int)

    value, messages = validate_yaml("", field)
    assert value is None
    assert len(messages) == 1

    value, messages = validate_yaml("123", field)
    assert value == 123
    assert not messages

    value, messages = validate_yaml("abc", field)
    assert value == "abc"
    assert len(messages) == 1

    value, messages = validate_yaml("123", Field(type=int, required=False))
    assert value == 123
    assert not messages



# Generated at 2022-06-12 16:19:31.933100
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem.schemas import Schema

    class User(Schema):
        name = String()
        age = Integer()

    content = '\n{"name": "foo", "age": "12"}'
    #content = yaml.load(content)

    value, errors = validate_yaml(content, User)
    assert len(errors) == 1
    error = errors[0]
    assert error.messages == ['Must be a valid integer.']
    assert error.position.line_no == 2
    assert error.position.column_no == 12



# Generated at 2022-06-12 16:19:36.936399
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    class MySchema(Schema):
        id = fields.Integer()
        name = fields.String()
        hobbies = fields.Array()

    s = yaml.dump({'id': 1234, 'name': 'John Smith', 'hobbies': ["hiking", "soccer", "reading"]})
    try:
        validate_yaml(s, MySchema)
    except ValidationError:
        assert False

    try:
        validate_yaml(b"1234", fields.String())
    except TypeError:
        assert False

    try:
        validate_yaml(1234, fields.String())
    except TypeError:
        assert False

    try:
        validate_yaml(s, fields.String())
    except ValidationError:
        assert True



# Generated at 2022-06-12 16:19:45.020024
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields
    from typesystem.exceptions import ValidationErrors

    class Person(Schema):
        name = fields.String(min_length=2)
        age = fields.Integer(minimum=18, maximum=120)

    content = """
    name: Erin
    age: 35
    """
    value, error_messages = validate_yaml(content, Person)

    assert value == {"name": "Erin", "age": 35}
    assert not error_messages.messages

    content = """
    name:
    age: 35
    """
    value, error_messages = validate_yaml(content, Person)

    assert value is None

# Generated at 2022-06-12 16:19:55.415519
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), DictToken)

    assert isinstance(tokenize_yaml("a: 'b'"), DictToken)

    assert isinstance(tokenize_yaml("[1,'a',true]"), ListToken)

    assert isinstance(tokenize_yaml("{a: 1, b: '2'}"), DictToken)

    assert tokenize_yaml("a: 'b'") == DictToken({"a": "b"}, 0, 7, content="a: 'b'")

    assert tokenize_yaml("[1,'a',true]") == ListToken(
        [1, "a", True], 0, 12, content="[1,'a',true]"
    )

    assert tokenize_yaml("{a: 1, b: '2'}") == DictToken

# Generated at 2022-06-12 16:20:05.267405
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed"
    import typesystem
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = typesystem.String()
        age = typesystem.Integer()
    
    my_schema = MySchema()

    # Test for a correct yaml document
    yaml_doc_correct = "name: John\nage: 30"
    value, error_messages = validate_yaml(content=yaml_doc_correct, validator=my_schema)
    assert error_messages == []
    assert value == {'name': 'John', 'age': 30}

    # Test for two error messages when a yaml document is incorrect
    yaml_doc_incorrect = "name: John\nage: abc"
   

# Generated at 2022-06-12 16:20:13.519348
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test that validate_yaml returns empty error_messages if the yaml is valid and non-empty error_messages if not."""
    valid_yaml = "valid: yaml"
    invalid_yaml = "invalid: : yaml"
    field = Field(required=True)
    value, errors = validate_yaml(valid_yaml, field)
    assert len(errors) == 0
    value, errors = validate_yaml(invalid_yaml, field)
    assert len(errors) > 0

# Generated at 2022-06-12 16:20:23.707584
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True
    # from typesystem.fields import String
    # from typesystem.schemas import Schema
    # from typesystem.types import Integer, String

    # class UserSchema(Schema):
    #     id = Integer(description="The user's ID.")
    #     name = String(description="The user's full name.")

    # content = """
    # foo: bar
    # baz: qux
    # """

    # returned_value, returned_errors = validate_yaml(content, validator=UserSchema)

    # assert returned_value is None

    # expected_errors = [
    #     ValidationError(
    #         path=["id"],
    #         code="missing_field",
    #         text="This field is required.",
    #         position=Position(line_no=2, column

# Generated at 2022-06-12 16:20:37.399558
# Unit test for function validate_yaml
def test_validate_yaml():
    m = Schema(fields={"n": int, "a": List[int]})
    assert validate_yaml("n: 123\n a: [1,2,3]", m) == ({"n": 123, "a": [1,2,3]},[])
    assert validate_yaml("n: 123\n a: [1,2,3]", m.fields["n"]) == (123, [])
    assert validate_yaml("n: not_int\n a: [1,2,3]", m) == ({"n": 123, "a": [1,2,3]}, [ValidationError(code="type_error",
        message="Could not cast value to int.", path="n")])

# Generated at 2022-06-12 16:20:47.541282
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = "string"
        age = "integer"

    class Job(Schema):
        title = "string"
        salary = "number"

    class PersonWithJob(Schema):
        person = Person
        job = Job

    # Invalid
    value, errors = validate_yaml(
        """
        person:
          name: Jon
        """,
        validator=PersonWithJob,
    )

    assert value is None
    assert len(errors) == 1
    assert errors[0].text == "Missing required property 'age'."
    assert errors[0].position.char_index == 23

    # Valid

# Generated at 2022-06-12 16:20:58.982324
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem
    import json
    from typesystem.base import Message
    from typesystem.schemas import Schema
    from typesystem.types import String

    class Person(Schema):
        first_name = String()
        last_name = String()
        age = typesystem.Integer()

    content = """
		first_name: Armin
		last_name: Ronacher
		age: 38
	"""

    (value, error_messages) = validate_yaml(content, validator=Person)
    assert value == {
        "first_name": "Armin",
        "last_name": "Ronacher",
        "age": 38
    }
    assert error_messages == []
    
    (value, error_messages) = validate_yaml("", validator=Person)

# Generated at 2022-06-12 16:21:10.554277
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Validator

    class UserValidator(Schema):
        name = String()

    class OtherValidator(Schema):
        name = String(max_length=10)

    content = "name: foo"

    assert validate_yaml(content, UserValidator) == ({'name': 'foo'}, [])
    assert validate_yaml(content, OtherValidator) == (
        {'name': 'foo'},
        [Message(text='Must be 10 characters or fewer.', code='max_length', position=Position(column_no=7, line_no=1, char_index=6))],
    )

# Generated at 2022-06-12 16:21:18.585641
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema.of({"name": types.String()})
    valid_yaml = "name: alex"
    invalid_yaml = "name: ''"
    value, error_messages = validate_yaml(valid_yaml, schema)
    assert value is not None
    assert error_messages is None

    value, error_messages = validate_yaml(invalid_yaml, schema)
    assert value is None
    assert error_messages is not None
    assert len(error_messages) == 1
    assert isinstance(error_messages[0], Message)

# Generated at 2022-06-12 16:21:26.544136
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    assert validate_yaml(content="name: Mark age: 100", validator=Person) == [
        "name",
        "Mark",
        "age",
        100,
    ]

    content = "name: Mark age: 100\n  address: 123 Main Street"
    assert validate_yaml(content=content, validator=Person) == ValidationError(
        errors=[
            {
                "position": Position(line_no=2, column_no=2, char_index=22),
                "text": "Extra content not allowed.",
                "code": "extra_content",
            }
        ]
    )

    content = "name: Mark age: '100'"
    assert validate_yaml(content=content, validator=Person)

# Generated at 2022-06-12 16:21:36.205948
# Unit test for function validate_yaml
def test_validate_yaml():
    from unittest import TestCase, mock
    from unittest.mock import call
    import yaml

    class MyField(Field):
        pass

    class MySchema(Schema):
        pass

    def construct_scalar(loader: "yaml.Loader", node: "yaml.Node") -> ScalarToken:
        start = node.start_mark.index
        end = node.end_mark.index
        value = loader.construct_scalar(node)
        return ScalarToken(value, start, end - 1, content=loader.stream.name)

    yaml.Loader.construct_scalar = construct_scalar
    yaml_content = """
    foo: bar
    """

    ret_value, error_messages = validate_yaml(yaml_content, MySchema)


# Generated at 2022-06-12 16:21:45.532949
# Unit test for function validate_yaml
def test_validate_yaml():
    correct_string = """
    name: Bob
    age: 42
    """
    incorrect_string = """
    foo: bar
    """
    schema = Schema({"name": str, "age": int})
    value, error_msgs = validate_yaml(correct_string, schema)
    assert isinstance(value, dict)
    assert value['name'] == 'Bob'
    assert error_msgs == None
    value, error_msgs = validate_yaml(incorrect_string, schema)
    assert error_msgs is not None
    assert isinstance(error_msgs, list)
    assert len(error_msgs) == 2
    assert isinstance(error_msgs[0], ValidationError)

# Generated at 2022-06-12 16:21:51.295927
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: John Doe
      age: 35
      email: john@example.com
    - name: Jane Doe
      age: 20
      email: jane@example.com
    """
    value, errors = validate_yaml(content, PersonListSchema)
    assert value == [
        Person(name="John Doe", age=35, email="john@example.com"),
        Person(name="Jane Doe", age=20, email="jane@example.com"),
    ]
    assert errors == []



# Generated at 2022-06-12 16:22:01.784687
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields

    # A schema to use for validation.
    class MySchema(Schema):
        foo = fields.String()

    # Validate an invalid document and capture the result.
    content = b"foo: bar\nbaz"
    errors = validate_yaml(content=content, validator=MySchema)

    # Validation errors should be a list of ValidationError instances.
    assert len(errors) == 1
    error = errors[0]
    assert isinstance(error, ValidationError)

    # The error message should contain details about the position of the error.
    text = error.messages[0]
    assert "line 2" in text
    assert "column 8" in text

    # Validate a valid document and capture the result.
    content = b"foo: bar"
    result

# Generated at 2022-06-12 16:22:14.630621
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""
    cars_to_rent:
    - { company: 'Ford', model: 'Fiesta', doors: 4, color: red }
    - { company: 'Ford', model: 'Focus', doors: 5, color: green }
    - { company: 'Ford', model: 'Mondeo', doors: 3, color: blue }
    """

    schema = Schema.of(
        {
            "cars_to_rent": Field(List[Schema.of({"company": str, "model": str})])
        }
    )

    errors = validate_yaml(content, schema)