

# Generated at 2022-06-12 16:12:20.699561
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml('hi'), ScalarToken)
    assert isinstance(tokenize_yaml('1'), ScalarToken)
    assert isinstance(tokenize_yaml('1.1'), ScalarToken)
    assert isinstance(tokenize_yaml('{}'), DictToken)
    assert isinstance(tokenize_yaml('[]'), ListToken)


# Generated at 2022-06-12 16:12:31.862788
# Unit test for function validate_yaml
def test_validate_yaml():
    # yaml.parser.ParserError: while parsing a flow node
    # in "<unicode string>", line 1, column 2:
    #    a: 1
    #    ^
    # expected ':', but found '2'
    # in "<unicode string>", line 4, column 4:
    #    4: 1
    #    ^
    # expected ':', but found '-'
    #
    # Note that the "^" marks on the second and fourth lines above are
    # correct (yaml is counting from 0), but the positions reported in the
    # error messages are column 1, not column 2.
    content = "a: 1\nb: 2\nc: 3\n4: 1\n5: - 2\n6: - 3\n"

# Generated at 2022-06-12 16:12:41.334087
# Unit test for function validate_yaml
def test_validate_yaml():
    # Create a schema used to validate the yaml
    # Create a schema used to validate the yaml
    class MySchema(Schema):
        name = String
        # This is an example of a read only field.
        read_only = String

    # Create an instance of the schema
    schema = MySchema()
    # Create a valid yaml string
    content = """
        name: John
    """
    # Validate the content
    value, error_messages = validate_yaml(content, schema)
    # The value should be a dictionary containing the value of the fields
    assert isinstance(value, dict)

    # There should not be any error messages
    assert len(error_messages) == 0

    # Create an invalid yaml string
    content = """
        myname: John
    """
    # Validate the content

# Generated at 2022-06-12 16:12:46.653486
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert isinstance(tokenize_yaml('{"key": "value"}'), DictToken)
    assert isinstance(tokenize_yaml('["value"]'), ListToken)
    assert isinstance(tokenize_yaml('value'), ScalarToken)
    assert isinstance(tokenize_yaml('1'), ScalarToken)
    assert isinstance(tokenize_yaml('1.0'), ScalarToken)
    assert isinstance(tokenize_yaml('true'), ScalarToken)
    assert isinstance(tokenize_yaml('false'), ScalarToken)
    assert isinstance(tokenize_yaml('null'), ScalarToken)

# Generated at 2022-06-12 16:12:49.738327
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import yaml
    input = "a: 1\nb: 2\n"
    result = yaml.load(input)
    assert result == {'a': 1, 'b': 2}

# Generated at 2022-06-12 16:12:51.645044
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("hello: world") == DictToken(
        {"hello": "world"}, start=0, end=11, content="hello: world"
    )

# Generated at 2022-06-12 16:13:03.847964
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # A list
    assert tokenize_yaml("[1, 2, 3]") == ListToken([1, 2, 3])
    # Another list
    assert tokenize_yaml("[1, 2, 3]") == ListToken([1, 2, 3])
    # A string
    assert tokenize_yaml("abc") == ScalarToken("abc")
    # Another string
    assert tokenize_yaml("abc") == ScalarToken("abc")
    # A dictionary
    assert tokenize_yaml("{1: 2, 3: 4}") == DictToken({1: 2, 3: 4})
    # Another dictionary
    assert tokenize_yaml("{1: 2, 3: 4}") == DictToken({1: 2, 3: 4})


# Generated at 2022-06-12 16:13:10.379203
# Unit test for function validate_yaml
def test_validate_yaml():
    # Writes the arguments to a file
    # Parses the arguments
    # Validates the arguments
    # Returns if arguments are valid or not
    schema = Schema(
        fields={
            "name": {"type": "string"},
            "age": {"type": "integer"},
            "colors": {"type": "list", "items": {"type": "string"}},
            "address": {
                "type": "object",
                "properties": {
                    "street": {"type": "string"},
                    "zip": {"type": "string"},
                },
            },
        }
    )
    with open("example.yml", "w") as file:
        yaml.dump({"name": "Joe", "age": 25, "colors": ["red", "green"]}, file)

# Generated at 2022-06-12 16:13:20.180936
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("123") == ScalarToken(123, 0, 3, content="123")
    assert tokenize_yaml("1.1") == ScalarToken(1.1, 0, 3, content="1.1")
    assert tokenize_yaml("1.23") == ScalarToken(1.23, 0, 4, content="1.23")
    assert tokenize_

# Generated at 2022-06-12 16:13:22.135757
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = b'\xef\xbb\xbf---\nhello: world'
    assert tokenize_yaml(content) == {"hello": "world"}


# Generated at 2022-06-12 16:13:29.457463
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "key: value"

    class TestSchema(Schema):
        key = "string"

    value, _ = validate_yaml(content, TestSchema)

    assert value == {"key": "value"}



# Generated at 2022-06-12 16:13:37.633334
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import (
        Boolean,
        Integer,
        List,
        Object as ObjectField,
        String,
    )
    from typesystem.schemas import Object

    class Pet(Object):
        name = String()
        age = Integer()
        is_happy = Boolean(default=True)

    class User(Object):
        name = String()
        age = Integer()
        pets = List(Pet)

    class UpdateUserSchema(Object):
        name = String(required=False)
        age = Integer(required=False)
        pk = Integer()

    class UpdateUserSchema3(Object):
        username = String(required=False)
        age = Integer(required=False)
        pk = Integer()

    class UpdateUserSchema2(Object):
        name = String(required=False)

# Generated at 2022-06-12 16:13:41.634386
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "foo: bar"
    validator = Field(name="foo", type="string", required=True)
    value, error_messages = validate_yaml(content, validator)
    assert value == "bar"
    assert not error_messages


# Generated at 2022-06-12 16:13:46.182500
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Schema(fields=[{"name": "name", "type": "string"}])
    value, errors = validate_yaml(content="name: foo", validator=validator)
    assert len(errors) == 0
    assert value == {"name": "foo"}


# Generated at 2022-06-12 16:13:49.479576
# Unit test for function validate_yaml
def test_validate_yaml():
    """ Unit test for function validate_yaml """
    field = Field(data_type=str)
    value, error_messages = validate_yaml(content='"a string"', validator=field)
    assert not error_messages
    assert value == 'a string'

# Generated at 2022-06-12 16:13:58.579700
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"name: bob"
    validator = fields.String(name="name")
    value = validate_yaml(content, validator)
    assert value == "bob"

    content = b"name: 123"
    validator = fields.String(name="name")
    _, error = validate_yaml(content, validator)
    assert error.position.line_no == 1
    assert error.position.column_no == 6
    assert error.position.char_index == 5
    assert error.text.startswith("Must be a valid string.")
    assert error.code == "invalid_type"



# Generated at 2022-06-12 16:14:08.711553
# Unit test for function validate_yaml
def test_validate_yaml():
    # both str and yaml.Node
    schema = Schema({"name": {"type": "string"}})
    assert validate_yaml("{name: yaml}", schema) == ({'name': 'yaml'}, [])
    assert isinstance(validate_yaml("{name: yaml}", schema)[0], dict)
    assert isinstance(validate_yaml("{name: yaml}", schema)[1][0], Message)
    assert isinstance(validate_yaml("{name: yaml}", schema)[1][0].position, Position)
    assert validate_yaml("{name: yaml}", schema)[1] == []
    assert validate_yaml("0", schema) == (0, [])
    assert validate_yaml("0", schema)[0] == 0
    assert validate_yaml

# Generated at 2022-06-12 16:14:16.547868
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(b"123", validator=int)
    assert validate_yaml(b"123", validator=float)
    assert validate_yaml(b"123", validator=float)
    assert validate_yaml(b"123", validator=str)
    assert not validate_yaml(b"1 2 3", validator=int)
    assert not validate_yaml(b"123", validator=bool)
    assert not validate_yaml(b"123", validator=dict)
    assert not validate_yaml(b"123", validator=list)

# Generated at 2022-06-12 16:14:25.547694
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml
    assert isinstance(tokenize_yaml("""
---
foo: bar
baz:
    - 1
    - 2
...
"""), DictToken)
    assert isinstance(tokenize_yaml("""
---
- foo
- bar
...
"""), ListToken)
    assert isinstance(tokenize_yaml("""
---
'hello world'
"""), ScalarToken)
    assert isinstance(tokenize_yaml("""
---
1
"""), ScalarToken)
    assert isinstance(tokenize_yaml("""
---
true
"""), ScalarToken)



# Generated at 2022-06-12 16:14:29.210345
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content='{"test": "value"}', validator=Schema({"test": "string"}))[0]
    assert validate_yaml(content='{"test": "value"}', validator=Schema({"test": "number"}))[0] == None

# Generated at 2022-06-12 16:14:38.142337
# Unit test for function validate_yaml
def test_validate_yaml():
    class Book(Schema):
        title = String(max_length=100)
    res, err = validate_yaml(b"""title: my book""", validator=Book())
    assert res == {"title": "my book"}
    assert err == []


# Generated at 2022-06-12 16:14:46.729236
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    This test passes a yaml string and a parser to the validate_yaml function
    to create tokens and parse the string. It asserts the error messages 
    returned are accurate and that the parse was successful.
    """
    content = "name=Peter\nage: 24\n"
    validator = typing.List[typing.Dict[str, typing.Any]]
    result = validate_yaml(content, validator)
    assert result == ([{'name': 'Peter', 'age': 24}], [])
    assert isinstance(result, tuple)
    assert isinstance(result[0], list)
    assert isinstance(result[1], list)
    assert len(result[0]) == 1
    assert len(result[1]) == 0


# Generated at 2022-06-12 16:14:48.949976
# Unit test for function validate_yaml
def test_validate_yaml():
    assert 0
#
# Unit tests for function tokenize_yaml
#

# Test parsing a YAML string.

# Generated at 2022-06-12 16:14:59.732879
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' not installed."

    assert isinstance(
        tokenize_yaml("[one, two, three]"), ListToken
    ), "tokenize_yaml should return list token for list"

    assert isinstance(
        tokenize_yaml("{one: two, three: four}"), DictToken
    ), "tokenize_yaml should return a dictionary token for dictionary"

    assert isinstance(tokenize_yaml("trash"), ScalarToken), (
        "tokenize_yaml should return a scalar token for untyped data"
    )

    assert isinstance(tokenize_yaml("1"), ScalarToken), (
        "tokenize_yaml should return a scalar token for integer"
    )


# Generated at 2022-06-12 16:15:03.602616
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer

    class UserSchema(Schema):
        name = String()
        age = Integer()

    yaml = """
      name: "John"
      """

    value, errors = validate_yaml(yaml, UserSchema)
    assert value == {"name": "John"}

    assert errors == [
        {
            "code": "missing_field",
            "position": Position(
                line_no=2, column_no=8, char_index=11, content=yaml
            ),
            "text": "Field is required.",
            "field": "age",
        }
    ]

# Generated at 2022-06-12 16:15:05.622808
# Unit test for function validate_yaml
def test_validate_yaml():
    '''
    this test should be implemented
    '''
    raise NotImplementedError()

# Generated at 2022-06-12 16:15:12.824682
# Unit test for function validate_yaml
def test_validate_yaml():
    f = Field(type=int)
    msg1, error_list1 = validate_yaml("5", validator=f)
    assert msg1 == 5
    assert error_list1 == []

    msg2, error_list2 = validate_yaml("dummy", validator=f)
    assert msg2 is None
    assert error_list2 == [
        Message(
            text="Value 'dummy' is not of type 'integer'.",
            code="invalid_type",
            position=Position(column_no=1, line_no=1, char_index=0),
        )
    ]

# Generated at 2022-06-12 16:15:24.341188
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        amt_usd: "10.00"
        account_number: -1
    """
    validator = Schema(
        fields={"amt_usd": Field(typ=float), "account_number": Field(typ=int)}
    )
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == [
        Message(
            text="Value should be a float.",
            code="type_error",
            position=Position(column_no=21, line_no=4, char_index=68),
        )
    ]
    assert value.get("account_number") == -1
    assert value.get("amt_usd") == 10.0


# Generated at 2022-06-12 16:15:27.611980
# Unit test for function validate_yaml
def test_validate_yaml():
    input = """
    id: 12345
    item:
      id: 23456
      name: item 1
      price:
        dollars: 10
        cents: 99
    """
    validator = Schema(
        {
            "id": "integer",
            "item": {"id": "integer", "name": "string", "price": {"dollars": "integer", "cents": "integer"}},
        }
    )
    output, errors = validate_yaml(input, validator)
    assert not errors
    assert output == {
        "id": 12345,
        "item": {"id": 23456, "name": "item 1", "price": {"dollars": 10, "cents": 99}},
    }



# Generated at 2022-06-12 16:15:36.661528
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import Text, Integer, Number
    from typesystem.schemas import Schema

    class BasicSchema(Schema):
        name = Text()
        age = Integer()

    content = "name: Foo\nage: 11"

    value, error_messages = validate_yaml(content, validator=BasicSchema)
    assert value == {"name": "Foo", "age": 11}
    assert error_messages == []

    content = "name: Foo"
    value, error_messages = validate_yaml(content, validator=BasicSchema)
    assert value == {"name": "Foo"}

# Generated at 2022-06-12 16:15:52.481987
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    key: value
    keys:
        - value1
        - value2
    nested_dict:
        nested_list:
            - key2: value3
    """

    tokens = tokenize_yaml(content)

    assert tokens == {
        "key": "value",
        "keys": ["value1", "value2"],
        "nested_dict": {"nested_list": [{"key2": "value3"}]},
    }

    assert isinstance(tokens, Token)
    assert isinstance(tokens["key"], Token)
    assert isinstance(tokens["keys"], Token)
    assert isinstance(tokens["keys"][0], Token)
    assert isinstance(tokens["nested_dict"], Token)

# Generated at 2022-06-12 16:16:00.416260
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("123").value == 123
    assert tokenize_yaml("true").value == True
    assert tokenize_yaml("[123, 456]").value == [123, 456]
    assert tokenize_yaml("{'a': 123, 'b': 456}").value == {'a': 123, 'b': 456}
    assert tokenize_yaml("123.45").value == 123.45
    assert tokenize_yaml("null").value == None
    assert tokenize_yaml("null").value == None

    with pytest.raises(ParseError):
        tokenize_yaml("nulll")

    with pytest.raises(ParseError):
        tokenize_yaml("123.")

    with pytest.raises(ParseError):
        tokenize_y

# Generated at 2022-06-12 16:16:11.481817
# Unit test for function validate_yaml
def test_validate_yaml():
    import example  # type: ignore

    try:
        import yaml
    except ImportError:
        yaml = None

    assert yaml is not None, "'pyyaml' must be installed."

    class MySchema(example.YamlSchema):
        pass

    # Test that this runs without error.
    value, error_messages = validate_yaml(  # noqa: F841
        content="""
        name: "Eric Idle"
        """,
        validator=MySchema,
    )

    assert error_messages == []
    assert value == {"name": "Eric Idle"}

    # Test that this runs without error.

# Generated at 2022-06-12 16:16:23.417366
# Unit test for function validate_yaml
def test_validate_yaml():
    # Create schema
    class PersonSchema(Schema):
        age = IntegerField()
        name = StringField()
    # Incorrect data (typo in value of age)
    data = """
        age: 1o
        name: Jo Doe
    """
    # Test
    value, messages = validate_yaml(data, PersonSchema)
    # Test
    assert value == None
    assert isinstance(messages, list)
    assert len(messages) == 1
    assert isinstance(messages[0], ValidationError)
    assert messages[0].text == "Integer value is greater than the maximum allowed value."
    assert messages[0].type == "integer_too_large"
    assert messages[0].position.line_no == 2
    assert messages[0].position.column_no == 7

# Generated at 2022-06-12 16:16:29.232316
# Unit test for function validate_yaml
def test_validate_yaml():
    def get_error(schema, content):
        value, errors = validate_yaml(content, schema)
        return errors[0]

    class TestSchema(Schema):
        field = Field(int)

    schema = TestSchema()

    error = get_error(schema, "field: '3'")
    assert error.text == "Value should be of type 'int'."
    assert error.code == "invalid_type"
    assert error.position.line_no == 1
    assert error.position.column_no == 8

    error = get_error(schema, "fiel: 3")
    assert error.text == "Unknown field name 'fiel'."
    assert error.code == "unknown_field"
    assert error.position.line_no == 1
    assert error.position.column_no == 1



# Generated at 2022-06-12 16:16:36.107262
# Unit test for function validate_yaml
def test_validate_yaml():
    #assert yaml is not None, "'pyyaml' must be installed."
    example_yaml = """
    ---
    name: My dataset
    description: This is a description of my dataset
    data:
        - this
        - is
        - a
        - list
        - of
        - items
    year: 2019
    """
    token = tokenize_yaml(example_yaml)
    validator = Schema(
        {"name": "string", "description": "string", "data": "array", "year": "integer"}
    )
    value, errors = validate_with_positions(token=token, validator=validator)
    assert errors == []



# Generated at 2022-06-12 16:16:45.571042
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    with pytest.raises(ParseError) as excinfo:
        validate_yaml(content="['a string']", validator=Field(type="string"))

    assert str(excinfo.value) == "Syntax error at line 1; column 1."

    value, messages = validate_yaml(content="", validator=Field(type="string"))
    assert value is None
    assert len(messages) == 1
    assert messages[0].text == "No content."
    assert messages[0].position == Position(column_no=1, line_no=1, char_index=0)

    value, messages = validate_yaml(content="[]", validator=Field(type="string"))
    assert value is None

# Generated at 2022-06-12 16:16:52.260775
# Unit test for function validate_yaml
def test_validate_yaml():
    input_yaml = '''
    data:
      - [1, 2, 3]
      - [4, 5, 6]
    '''
    output_value, output_errors = validate_yaml(input_yaml, Field(type="array"))
    assert output_value == {'data': [[1, 2, 3], [4, 5, 6]]}
    assert output_errors == []

# Generated at 2022-06-12 16:17:03.817582
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Int
    from typesystem.schemas import Schema


    class IntWithNameSchema(Schema):
        name = "int_with_name"
        value = Int()
        name = Int()


    content = "value: 1\nname: 2"
    errors = validate_yaml(content, IntWithNameSchema)
    assert len(errors) == 0

    content = "value: 1\nname: a"
    errors = validate_yaml(content, IntWithNameSchema)
    assert len(errors) == 1
    assert errors[0]["type"] == "invalid_type"
    assert errors[0]["token_position"]["line_no"] == 2
    assert errors[0]["token_position"]["column_no"] == 2

# Generated at 2022-06-12 16:17:07.433761
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import fields

    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    yaml = """
    name: john
    age: 20
    """
    assert validate_yaml(yaml, PersonSchema) == ({'name': 'john', 'age': 20}, [])



# Generated at 2022-06-12 16:17:16.901335
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""
    list:
     - item
     - item2
    """

    value, errors = validate_yaml(content, ListToken)
    assert value[0].value == "item"
    assert value[1].value == "item2"

# Generated at 2022-06-12 16:17:26.905392
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml(""), ScalarToken)
    assert isinstance(tokenize_yaml(""), ScalarToken)
    assert isinstance(tokenize_yaml("[1, 2]"), ListToken)
    assert isinstance(tokenize_yaml("[1, 2]"), ListToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("{a: true}"), DictToken)
    assert isinstance(tokenize_yaml("{a: true}"), DictToken)
    assert isinstance(tokenize_yaml("[true, true]"), ListToken)

# Generated at 2022-06-12 16:17:36.304687
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer

    # The below content is the output of `yaml.dump` using a "SafeDumper"
    # with block mode enabled to ensure the examples are easy to read.
    content = """\
    foo: 123
    bar: 321
    baz: 123
    """

    try:
        result, errors = validate_yaml(content, Integer([123, 321]))
    except ParseError as exc:
        assert False, "unexpected parse error: {}".format(exc)

    assert result == {"foo": 123, "bar": 321, "baz": 123}
    assert not errors

    schema = Integer([123, 321], name="Test")
    result, errors = validate_yaml(content, schema)

    assert result == {"Test": 123}
    assert len(errors) == 2

    error = errors

# Generated at 2022-06-12 16:17:47.573157
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    yaml_file = open("tests/test_yaml_file.yml")
    yaml_content = yaml.safe_load(yaml_file)
    yaml_file.close()
    validator = yaml_content["_type"]
    yaml_content["_type"] = None
    yaml_content_string = yaml.dump(yaml_content)

    value, errors = validate_yaml(yaml_content_string, validator)

    expected_output = {'_type': None, '_id': None, '_version': None, '_schema': None,
                        '_client': None, '_links': None}
    assert value == expected_output
    assert isinstance(errors, list)
    assert errors == []

# Generated at 2022-06-12 16:17:59.291628
# Unit test for function validate_yaml
def test_validate_yaml():
    class PostSchema(Schema):
        title = f.String(max_length=100)
        body = f.String(max_length=100)

    content = """\
    ---
    title: "My post"
    body: "Lorem ipsum dolor sit amet"
    """
    parsed_value, error_messages = validate_yaml(content, PostSchema)
    assert parsed_value.get("title") == "My post"
    assert parsed_value.get("body") == "Lorem ipsum dolor sit amet"
    assert error_messages == []

    content = """\
    ---
    title: "My post"
    body: 1234567890123456789012345678901234567
    """
    parsed_value, error_messages = validate_

# Generated at 2022-06-12 16:18:05.830665
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer

    class PersonSchema(Schema):
        id = Integer(description="The user's ID.")

    class PetSchema(Schema):
        owner = PersonSchema(description="The pet's owner.")
        name = String(description="The pet's name.")

    schema = PetSchema

    raw_yaml = """
        owner:
            id: 123
        name: Rover
    """

    VALUE, ERRORS = validate_yaml(raw_yaml, validator=schema)
    assert ERRORS is None

    raw_yaml = """
        owner:
            ids: 123
        name: Rover
    """

    VALUE, ERRORS = validate_yaml(raw_yaml, validator=schema)
    assert ERRORS

# Generated at 2022-06-12 16:18:16.502236
# Unit test for function validate_yaml
def test_validate_yaml():
    class Address(Schema):
        street = Field(type="string")

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="number")
        address = Field(type="object", subtype=Address)

    class Team(Schema):
        team = Field(type="array", subtype=Person)
        team_name = Field(type="string")

    def validate(schema, yaml):
        content = yaml.encode("utf-8")
        return validate_yaml(content, schema)


# Generated at 2022-06-12 16:18:21.455593
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        age = types.Integer()

    content = """age: 30\n"""
    result = validate_yaml(content, validator=TestSchema())
    assert result == ({'age': 30}, [])


# Generated at 2022-06-12 16:18:32.537833
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):

        text = Field(format="text")
        number = Field(format="integer")
        decimal = Field(format="float")
        boolean = Field(format="boolean")
        nullable = Field(format="nullable")

    schema = MySchema()
    content = "text: hello\nnumber: 1\ndecimal: 1.0\nboolean: true\nnullable: None"

    value, errors = validate_yaml(content=content, validator=schema)
    assert not errors, errors
    assert value == {
        "text": "hello",
        "number": 1,
        "decimal": 1.0,
        "boolean": True,
        "nullable": None,
    }


# Generated at 2022-06-12 16:18:34.499034
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, validate
    pass



# Generated at 2022-06-12 16:18:49.141071
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()

    data = textwrap.dedent(
        """\
    name: John Doe
    age: 35
    """
    )

    value, errors = validate_yaml(content=data, validator=Person)

    assert value == {"name": "John Doe", "age": 35}
    assert errors == []

    data = textwrap.dedent(
        """\
    name:
    age: 35
    """
    )

    value, errors = validate_yaml(content=data, validator=Person)


# Generated at 2022-06-12 16:18:52.355034
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content=b'{"foo": "bar"}', validator={"foo": str}) == ({}, [])

# Generated at 2022-06-12 16:18:59.901195
# Unit test for function validate_yaml
def test_validate_yaml():
    # type: () -> None

    import yaml

    from typesystem.fields import String, Integer
    from typesystem.schema import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class YAMLTest(Schema):

        # Test yaml scalar token.
        name = String(max_length=5)

        # Test yaml int token.
        number = Integer(min_value=50)

    yaml_str: str = yaml.dump({"name": "type", "number": 50}).strip()
    value, error_messages = validate_yaml(yaml_str, validator=YAMLTest)

    assert error_messages == []
    assert value == {"name": "type", "number": 50}


# Generated at 2022-06-12 16:19:06.289568
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
layout: post
title: Blogging Like a Hacker
"""
    schema = Schema(
        {
            "layout": Field(str),
            "title": Field(str),
        },
    )
    value, messages = validate_yaml(content, schema)
    assert value == {"layout": "post", "title": "Blogging Like a Hacker"}
    assert messages == []


# Generated at 2022-06-12 16:19:12.450257
# Unit test for function validate_yaml
def test_validate_yaml():
    class User(Schema):
        username = fields.String()

    body = """
    username: ~
    """

    value, error_messages = validate_yaml(body, User)
    assert isinstance(error_messages[0], Message)
    assert isinstance(error_messages[0].position, Position)
    assert error_messages[0].text == "This field is required."

# Generated at 2022-06-12 16:19:20.651490
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import types

    class Pet(Schema):
        name = Field(types.String)
        class Meta:
            unknown = "EXCLUDE"

    content = """
    name:
        Steven
    """
    value, errors = validate_yaml(content, Pet)
    assert type(errors[0]["position"]["line_no"]) == int
    assert errors[0]["position"]["line_no"] == 3
    assert errors[0]["position"]["column_no"] == 8
    assert errors[0]["text"] == 'Expected a string.'
    assert errors[0]["code"] == "invalid_string"

# Generated at 2022-06-12 16:19:33.566463
# Unit test for function validate_yaml
def test_validate_yaml():
    def get_schema():
        return Schema({"name": str, "age": int})

    def expected_err_message(text, code, position):
        return Message(text=text, code=code, position=position)

    # Test parsed tokens
    tokenized_content = tokenize_yaml(
        """
            name: John Doe
            age: 42
        """
    )
    tokenized_value, tokenized_error_messages = validate_with_positions(
        token=tokenized_content, validator=get_schema(),
    )
    assert tokenized_value == {"name": "John Doe", "age": 42}
    assert tokenized_error_messages == []

    # Test raw content
    raw_content = """
        name: John Doe
        age: 42
    """
    raw_

# Generated at 2022-06-12 16:19:39.967517
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Root, fields

    class Person(Schema):
        name = fields.String()
        age = fields.Integer()
        weight = fields.String()

    content = "name: John\nage: 35\nweight: 65kg"
    root = Root(Person)
    value, error_messages = validate_yaml(content, root)
    print(value, error_messages)



# Generated at 2022-06-12 16:19:52.438185
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String
    from typesystem import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    # Simple example
    class BookSchema(Schema):
        title = String()

    data = yaml.dump({'title':'My Great Book'})

    result = validate_yaml(data, BookSchema)
    assert result == ({'title': 'My Great Book'}, [])

    # Simple example but with a validation problem
    class BookSchema(Schema):
        title = String(min_length=10)

    data = yaml.dump({'title':'My Great Book'})
    result = validate_yaml(data, BookSchema)

# Generated at 2022-06-12 16:19:59.950533
# Unit test for function validate_yaml
def test_validate_yaml():

    # class PostSchema(Schema):
    #     username = String(name="username")
    #     data = String(name="data")

    class PostSchema(Schema):
        username = fields.String(name="username")
        data = fields.String(name="data")

    content = """
        username: yunfei
        data: yunfei
        """
    result = validate_yaml(content, PostSchema)
    print(result)


# Command line interface

# Generated at 2022-06-12 16:20:22.613572
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class MySchema(Schema):
        foo = String()
        bar = String(allow_blank=False)

    content = """
        foo: hello
        bar: 1
    """
    result = validate_yaml(content, MySchema)
    assert result[1][0].text == "blank values are not allowed."



# Generated at 2022-06-12 16:20:28.092832
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content_one = "foo: bar"
    token = tokenize_yaml(content_one)
    assert isinstance(token, DictToken)

    content_two = "foo: bar\n baz: qux\n"
    token = tokenize_yaml(content_two)
    assert isinstance(token, DictToken)

    content_three = "- foo\n- bar\n"
    token = tokenize_yaml(content_three)
    assert isinstance(token, ListToken)


# Generated at 2022-06-12 16:20:33.385721
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
title: hello
content: world
'''
    validator = Schema(title=Field(type="string"), content=Field(type="string"))
    assert validate_yaml(content, validator) == ({'title': 'hello', 'content': 'world'}, [])


# Generated at 2022-06-12 16:20:37.105435
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
        a: 1
        b: [ 2, 3, 4 ]
        c: { a: 1, b: 2 }
    '''
    result = validate_yaml(content, Schema({ 'a': int, 'b': List[int], 'c': Dict[unicode, int]}))



# Generated at 2022-06-12 16:20:47.377988
# Unit test for function validate_yaml
def test_validate_yaml():
    # Valid yaml
    content = "first_name: John"
    validator = Schema([Field("first_name")])
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == []
    assert value == {"first_name": "John"}

    # Valid yaml but invalid schema
    content = "first_name: John"
    validator = Schema([Field("middle_name")])
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == [Message("middle_name is required.", code="required")]

    # Invalid yaml, two errors
    content = "first_name: John\n,middle_name: John"
    validator = Schema([Field("middle_name")])
    value, error_messages

# Generated at 2022-06-12 16:20:58.944590
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(name="fields")
    schema = type(
        "Schema",
        (Schema,),
        {"fields": {"name": Field(name="name")}},
    )
    assert isinstance(validate_yaml(b"name:", schema)[0], schema)
    assert isinstance(validate_yaml(b"name:", schema)[1][0], ValidationError)
    assert isinstance(validate_yaml(b"", schema)[0], schema)
    assert isinstance(validate_yaml(b"", schema)[1][0], ValidationError)
    assert isinstance(validate_yaml(b"name: 123", schema)[0], schema)
    assert isinstance(validate_yaml(b"name: 123", schema)[1][0], Message)

# Generated at 2022-06-12 16:21:10.459626
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema, fields

    class TestSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer(min_value=0, max_value=150)
        # key 'key_word' is not defined. raise error message
        invalid_keyword = fields.String()

    content = """
        name: Jimmy
        age: 12
        hobby: baseball
        extra_1:
            -   extra_1_1: Jimmy
                extra_1_2: 12
        """

# Generated at 2022-06-12 16:21:20.564271
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Validate the empty-string case.
    with pytest.raises(ParseError) as excinfo:
        token = tokenize_yaml("")
        print(token)
    assert excinfo.value.code == "no_content"
    assert excinfo.value.text == "No content."
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.char_index == 0

    # Validate a parse error.
    with pytest.raises(ParseError) as excinfo:
        token = tokenize_yaml("a b c")
        print(token)
    assert excinfo.value.code == "parse_error"

# Generated at 2022-06-12 16:21:28.034305
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_error_messages = validate_yaml(
        content="""
        - item
        - 1.0
        - true
        - null
        """,
        validator=ListField(
            items=AnyOfField(
                fields=[
                    StringField(),
                    FloatField(),
                    BooleanField(),
                    NullField(),
                ]
            )
        ),
    )
    assert yaml_error_messages == ([], [])
    
    

# Generated at 2022-06-12 16:21:32.336623
# Unit test for function validate_yaml
def test_validate_yaml():

    yaml_content_input = "name: alice"
    yaml_content_result = validate_yaml(yaml_content_input, {"name" : "string"})
    print(yaml_content_result)






# Generated at 2022-06-12 16:22:00.738809
# Unit test for function validate_yaml
def test_validate_yaml():
  simple_yaml = """\
  schema: object
  properties:
    a:
      type: string
  required:
  - a
  """

  simple_dict = { "a": 1 }

  try:
      value, error_messages = validate_yaml(simple_yaml, simple_dict)
  except Exception as e:
      if type(e) == ValueError:
          print("Pass")
      else:
          print("Fail")

## Run the unit test
test_validate_yaml()

# Generated at 2022-06-12 16:22:07.755480
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import fields, schema

    class UserSchema(schema.Schema):
        name = fields.String()
        email = fields.String()
        age = fields.Integer()

    yaml_content = """
    name: Jane Smith
    email: jsmith@example.com
    age: 25
    """

    assert validate_yaml(yaml_content, UserSchema) == ({
        'name': 'Jane Smith',
        'email': 'jsmith@example.com',
        'age': 25
    }, [])

    yaml_content = """
    name: Jane Smith
    email: jsmith@example.com
    age: twenty-five
    """

    value, errors = validate_yaml(yaml_content, UserSchema)
    assert len(errors) == 1


# Generated at 2022-06-12 16:22:16.333037
# Unit test for function validate_yaml
def test_validate_yaml():
    token = tokenize_yaml(
        """---
    title: "Example Schema"
    type: object
    properties:
        firstName:
            type: string
        lastName:
            type: string
        age:
            description: Age in years
            type: integer
            minimum: 0
    """
    )

    value, errors = validate_yaml(
        b"""---
title: "Example Schema"
type: object
properties:
    firstName:
        type: string
    lastName:
        type: string
    age:
        description: Age in years
        type: integer
        minimum: 0
""",
        token,
    )
    assert value is not None
    assert errors is not None
