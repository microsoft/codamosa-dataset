

# Generated at 2022-06-12 16:12:27.592946
# Unit test for function validate_yaml
def test_validate_yaml():
    test_schema = Schema({"name": str, "age": int})
    result, messages = validate_yaml('{"name": "g", "age": 3}', test_schema)
    assert result == {"name": "g", "age": 3}
    assert messages == []


if __name__ == "__main__":
    test_validate_yaml()

# Generated at 2022-06-12 16:12:30.078362
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_string = "hi: 3"
    token = tokenize_yaml(yaml_string)
    assert(token.value == {'hi': 3})


# Generated at 2022-06-12 16:12:31.910585
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    return


# Generated at 2022-06-12 16:12:36.876803
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        foo = Field(type="string")
        bar = Field(type="integer")

    error = validate_yaml(content='{"foo": "Hello", "bar": "Wrong"}', validator=TestSchema)
    assert error[1] == "\n2:3 unexpected type"

# Generated at 2022-06-12 16:12:46.819520
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # Basic example
    content = """
    a: 1
    """
    expected = DictToken({'a': ScalarToken(1, 3, 3, content=content)}, 0, 3, content=content)
    actual = tokenize_yaml(content)
    assert expected == actual

    # List of scalars
    content = """
    a:
      - 1
      - 2
      - 3
    """
    expected = DictToken({'a': ListToken([1, 2, 3], 3, 11, content=content)}, 0, 11, content=content)
    actual = tokenize_yaml(content)
    assert expected == actual

    # Nested dictionary and list
    content = """
    a:
      b:
        - 1
        - 2
      c: 3
    """

    # Element 0
   

# Generated at 2022-06-12 16:12:52.667442
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "foo: bar"
    validator = {
        "foo": {"type": "string", "max_length": 3}
    }
    value, error_messages = validate_yaml(content, validator)
    error_messages = error_messages[0].as_dict()
    assert error_messages['code'] == 'max_length'
    assert error_messages['position'] == {'column_no': 5, 'char_index': 5, 'line_no': 1}


# Generated at 2022-06-12 16:12:59.045642
# Unit test for function validate_yaml
def test_validate_yaml():
    class User(Schema):
        username = fields.String(max_length=10)
        age = fields.Integer(minimum=18)

    user_input = """
    username: hiroko
    age: 17
    """
    assert validate_yaml(user_input, User) == [
        ("username", "h", 10),
        ("age", "17", 18)
    ]


# Generated at 2022-06-12 16:13:08.516047
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None
    # test a well-formed yaml
    good_yaml = """
    - 1
    - 2
    - 3
    - 4
    """
    assert validate_yaml(good_yaml, ListToken) == ([1, 2, 3, 4], None)

    # test a malformed yaml
    bad_yaml = """
    - 1
    - 2
    - 3
    - 4
    - 5
    #
    #
    - 8
    """

# Generated at 2022-06-12 16:13:18.206563
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('123').value == 123
    assert tokenize_yaml('abc').value == 'abc'
    assert tokenize_yaml('true').value == True
    assert tokenize_yaml('false').value == False
    assert tokenize_yaml('null').value == None
    assert tokenize_yaml('[1,2]').value == [1,2]
    assert tokenize_yaml('{a:1, b:2}').value == {'a':1, 'b':2}
    assert tokenize_yaml('1.1').value == 1.1
    assert tokenize_yaml('1.1').end == 3
    assert tokenize_yaml('1234').start == 0
    assert tokenize_yaml('null').end == 4

# Generated at 2022-06-12 16:13:26.268064
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""
    foo: 
        bar: 1
        baz: 2
    """
    token = tokenize_yaml(content)
    from typesystem import Schema, fields
    
    class FooSchema(Schema):
        bar = fields.IntegerField(minimum=1, maximum=5)
        baz = fields.IntegerField(minimum=1, maximum=5)
    
    value, error_messages = validate_with_positions(token=token, validator=FooSchema(strict=True))

# Generated at 2022-06-12 16:13:34.396778
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    num_rows: 3
    num_cols: 4
    data:
    - - 1.0
      - 2.0
    - - 3.0
      - 4.0
    - - 5.0
      - 6.0
    - - 7.0
      - 8.0
    """
    assert isinstance(tokenize_yaml(content), DictToken)



# Generated at 2022-06-12 16:13:44.402327
# Unit test for function validate_yaml
def test_validate_yaml():
    Field.mutable_defaults = True
    class Person(Schema):
        name: str = Field(max_length=10)
        age: int = Field(minimum=0, maximum=150)
    content = 'name: "John Doe"\nage: "50"\n'
    (value, errors) = validate_yaml(content, Person)
    assert isinstance(value, Person)
    assert value.name == "John Doe"
    assert value.age == 50
    assert len(errors) == 0
    Field.mutable_defaults = False

if __name__ == "__main__":
    test_validate_yaml()

# Generated at 2022-06-12 16:13:51.500865
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        number = "number"

    # Valid payload
    value, errors = validate_yaml(content="number: 1", validator=MySchema)
    assert value == {'number': 1}
    assert not errors

    # Invalid payload
    value, errors = validate_yaml(content="number: foo", validator=MySchema)
    assert errors == [
        Message(
            code="invalid",
            text="Must be a number.",
            position=Position(line_no=1, column_no=7, char_index=7),
        )
    ]

# Generated at 2022-06-12 16:13:54.743727
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('{"name":"bat"}', Schema(properties = {"name": {"type":"string"}})) == ({'name': 'bat'}, [])

# Generated at 2022-06-12 16:13:59.296946
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("", int) == (0, [])
    assert validate_yaml("1", int) == (1, [])
    assert validate_yaml("1.1", int) == (None, [Message("Not an integer.", code="type")])
    assert validate_yaml("1.1", float) == (1.1, [])

# Generated at 2022-06-12 16:13:59.807413
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True



# Generated at 2022-06-12 16:14:02.453518
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_str = "\nage: 2"
    value, errors = validate_yaml(yaml_str, validator=Field(name="age", type="integer"))
    assert value == 2



# Generated at 2022-06-12 16:14:11.348446
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "---\n- name: 'John'\n  age: 30\n- name: 'Jane'\n  age: 25"
    expected = [
        {"name": "John", "age": 30},
        {"name": "Jane", "age": 25},
    ]
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert len(token.value) == 2
    for index, value in enumerate(token.value):
        assert isinstance(value, DictToken)
        assert len(value.value) == 2
        assert value.value["name"].value == expected[index]["name"]
        assert value.value["age"].value == expected[index]["age"]



# Generated at 2022-06-12 16:14:20.060339
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import StringField

    class CatFactSchema(Schema):
        text = StringField()

    content = """
        text: This is a string that is way too long, and should cause an error.
    """

    value, errors = validate_yaml(content, CatFactSchema())
    assert value == None
    assert len(errors) == 1

    content = """
        text: This string is the correct length.
    """

    value, errors = validate_yaml(content, CatFactSchema())
    assert value == {'text': 'This string is the correct length.'}
    assert errors == []

# Generated at 2022-06-12 16:14:26.576537
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") is None
    assert tokenize_yaml("a: 1") == {"a": ScalarToken("1", 2, 2, content="a: 1")}
    assert tokenize_yaml("[1, 2]") == [
        ScalarToken("1", 1, 1, content="[1, 2]"),
        ScalarToken("2", 4, 4, content="[1, 2]"),
    ]



# Generated at 2022-06-12 16:14:39.372210
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """\
    bools:
      - true
      - True
      - y
      - on
      - yes
      - false
      - False
      - n
      - off
      - no
    """
    expected = {
        "bools": [
            True,
            True,
            True,
            True,
            True,
            False,
            False,
            False,
            False,
            False,
        ]
    }
    assert yaml is not None, "'pyyaml' must be installed."
    token = tokenize_yaml(content)
    assert expected == token.value



# Generated at 2022-06-12 16:14:47.415198
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = Field(str)
        count = Field(float)
        # Should return a two-tuple of (value, error_messages)
    correct_values = validate_yaml("name: Juan\ncount: 5.5", MySchema)
    assert correct_values == ({"name": "Juan", "count": 5.5}, [])

    incorrect_values = validate_yaml("name: Juan\ncount: fhjfhjfhj", MySchema)

# Generated at 2022-06-12 16:14:58.258540
# Unit test for function validate_yaml
def test_validate_yaml():
    from . import int_field, list_field, optional_field, string_field
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = string_field()
        age = int_field()
        other_data = optional_field(string_field())

    class PeopleSchema(Schema):
        people = list_field(PersonSchema)

    content = """
    people:
        - name: Alice
          age: 19
          other_data: alice.dat
        - name: Bob
          age: 20
          other_data: bob.dat
    """
    (value, errors) = validate_yaml(content, PeopleSchema)
    assert not errors
    assert value["people"][0]["name"] == "Alice"

# Generated at 2022-06-12 16:15:09.562865
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    from typesystem.fields.object import Object

    # Test basic parsing
    input = "name: The Fonz"
    output = {"name": "The Fonz"}
    assert validate_yaml(input, Object.of({"name": String()})) == (output, [])

    # Test schema validation
    class Person(Schema):
        name = String()
        age = Integer()

    input = "name: The Fonz\nage: 50"
    output = {"name": "The Fonz", "age": 50}
    assert validate_yaml(input, Person) == (output, [])

    # Make sure a validation error is returned when invalid input is provided
    class Person(Schema):
        name = String()
        age = Integer()


# Generated at 2022-06-12 16:15:13.398422
# Unit test for function validate_yaml
def test_validate_yaml():
    with open(os.path.join(os.path.dirname(__file__), "files/test_validate_yaml.yaml"), "rb") as f:
        content = f.read()
        token = tokenize_yaml(content)
        assert token == {'name': 'John Smith', 'age': 30, 'likes': ['Python', 'stouts']}



# Generated at 2022-06-12 16:15:25.151536
# Unit test for function validate_yaml
def test_validate_yaml():
    valid_yaml_string = """
        name: "test"
        age: 45
        """
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(max_value=100)
    value, errors = validate_yaml(content=valid_yaml_string, validator=Person)
    assert value == [{"name": "test", "age": 45}]
    assert errors == []

    invalid_yaml_string = """
        name "test"
        age: 45
        """
    value, errors = validate_yaml(content=invalid_yaml_string, validator=Person)

# Generated at 2022-06-12 16:15:32.322212
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """---
name: Bob
age: 30
languages: [Python, C, C++, Assembly]
coding_as_a_hobby: true
"""
    errors = validate_yaml(
        content,
        Schema(
            {
                "name": str,
                "age": int,
                "languages": [str],
                "coding_as_a_hobby": bool,
            }
        ),
    )
    assert not errors

# Generated at 2022-06-12 16:15:37.659244
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer
    class MySchema(Schema):
        name=String()
        age=Integer(minimum=30)
    content='''
        name: Charles
        age: 40
    '''
    result, error_messages = validate_yaml(content, MySchema)
    assert len(error_messages)==0
    content='''
        name: Charles
        age: 20
    '''
    result, error_messages = validate_yaml(content, MySchema)
    assert len(error_messages)==1


# Generated at 2022-06-12 16:15:47.212735
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.primitives import String

    class User(Schema):
        name = String(max_length=10)

    errors = validate_yaml(
        """{"name": "Lorem ipsum dolor sit amet, consectetur adipiscing elit."}""",
        User,
    )
    assert len(errors) == 1

    error = errors[0]
    assert error.code == "string_too_long"
    assert error.text == "Must have no more than 10 characters."
    assert error.position == Position(
        line_no=1, column_no=31, char_index=30
    )



# Generated at 2022-06-12 16:15:50.427193
# Unit test for function validate_yaml
def test_validate_yaml():
    assert (
        validate_yaml("foo: bar\n", validator=Schema([Field(name="foo", type=str)]))
        == ({"foo": "bar"}, [])
    )



# Generated at 2022-06-12 16:16:00.613546
# Unit test for function validate_yaml
def test_validate_yaml():

    class ExampleSchema(Schema):
        number = Field(type=int)
        string = Field(type=str)

    config = """
    number: 1
    string: string
    """
    assert validate_yaml(config, ExampleSchema) == ({"number": 1, "string": "string"}, [])

    config = """
    number: number
    string: string
    """
    value, messages = validate_yaml(config, ExampleSchema)
    assert value == {"number": "number", "string": "string"}
    assert len(messages) == 1
    message = messages[0]
    assert isinstance(message, ValidationError)
    assert message.text == "Expected a number."
    assert message.code == "type_error"
    assert message.position.line_no == 3
    assert message

# Generated at 2022-06-12 16:16:11.526827
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields
    from pprint import pformat

    class UserSchema(Schema):
        """
        A schema that validates multiple strings
        """

        first_name = fields.String(min_length=1, max_length=10)
        last_name = fields.String(min_length=1, max_length=10)
        age = fields.Integer()

    yaml_string = """
    first_name: Johnny
    last_name: Appleseed
    age: 200
    """

    value, error_messages = validate_yaml(yaml_string, UserSchema)
    assert error_messages == []
    assert value == {
        "first_name": "Johnny",
        "last_name": "Appleseed",
        "age": 200,
    }



# Generated at 2022-06-12 16:16:14.616296
# Unit test for function validate_yaml
def test_validate_yaml():
    f = Field(key="field", type=str)
    assert validate_yaml(b"hello", f) == ('hello', [])


# Generated at 2022-06-12 16:16:23.242713
# Unit test for function validate_yaml
def test_validate_yaml():
    """ Test case: Test validate_yaml functions
        Input parameters: obj = {'name': 'Tester', 'gender':'Female'}
                          schema = PersonSchema
        Expected output  : error_messages = {'name': None, 'gender': 'Must be male or other.'}
    """
    obj = {'name': 'Tester', 'gender':'Female'}
    schema = PersonSchema
    error_messages = {'name': None, 'gender': 'Must be male or other.'}
    assert(validate_yaml(obj, schema) == error_messages)

# Generated at 2022-06-12 16:16:32.558420
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: Alice"
    validator = Schema(
        name=Field(type=str, max_length=10),
    )
    # test for pass with no error in validation
    assert validate_yaml(content=content, validator=validator) == ({'name': 'Alice'}, [])
    # test for fail with error in validation
    content = "name: AliceBob"
    assert validate_yaml(content=content, validator=validator) == ({'name': 'AliceBob'}, [
        ValidationError({'name': 'AliceBob'}, 'Value has a length of 11 but it must have a maximum length of 10.', 'name', 'max_length', 10, 11, [])
    ])

# Generated at 2022-06-12 16:16:40.272380
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    string = String(required=True)
    assert validate_yaml(content=b"", validator=string) == (None, "")
    #error_messages = validate_yaml(content=b"", validator=string)
    #assert "#. " in error_messages
    #assert "Expected type: string." in error_messages


# Generated at 2022-06-12 16:16:44.709702
# Unit test for function validate_yaml
def test_validate_yaml():
    input = """
    age: integer
    name: string
    """
    schema = Schema.from_string(input)
    data = """
    age: 3
    name: 'admin'
    """
    data = validate_yaml(data, schema)
    assert type(data) == typing.Tuple[typing.Any, typing.Dict[str, str]]

# Generated at 2022-06-12 16:16:53.106757
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
name: jeff
age: 21
occupation: programmer
"""
    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer", minimum=18)
        occupation = Field(type="string")

    value, error_messages = validate_yaml(content, PersonSchema)
    assert len(error_messages) == 0
    assert value.name == "jeff"
    assert value.age == 21
    assert value.occupation == "programmer"

# Generated at 2022-06-12 16:16:58.804412
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), DictToken)
    assert isinstance(tokenize_yaml("foo: bar"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("{}"), DictToken)

# class for test_validate_yaml

# Generated at 2022-06-12 16:17:06.549268
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(name="root")
    content = """
definitions:
  hello:
    type: string
    format: email
    pattern: "[a-zA-Z0-9-_.]+@[a-zA-Z0-9-_.]+"
"""
    value, error_messages = validate_yaml(content, validator)
    assert value is None
    assert len(error_messages) == 2
    assert error_messages[0] == Message(text="Invalid string format.", code="invalid")
    assert error_messages[1] == Message(text="Invalid regular expression.", code="invalid")

# Generated at 2022-06-12 16:17:16.376774
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a:
      required: true
    b:
      required: true
    """
    token = tokenize_yaml(content)
    data = {'a': 'test', 'b': 'test'}
    errors = validate_with_positions(token, DummySchema, data)
    assert errors is None

# Generated at 2022-06-12 16:17:26.354125
# Unit test for function validate_yaml
def test_validate_yaml():
    value, errors = validate_yaml(
        yaml_string,
        Schema(
            fields={
                "name": String(max_length=3),
                "first": String(max_length=3),
                "last": String(max_length=3),
                "amount": Float,
                "date": DateTime,
                "is_active": Boolean,
            }
        ),
    )
    print(value)
    content, error_messages = validate_yaml(
        yaml_string, Schema(fields={"email": Email, "last": String})
    )


yaml_string = """
name: hello
first: world
last: !
amount: 1.4
date: 2018-11-27T17:49:57+00:00
is_active: True
"""

# Generated at 2022-06-12 16:17:35.907528
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = str
        email = str
        age = int

    class Book(Schema):
        title = str
        author = Person

    person_str = '''
    name: Bob
    email: bob@gmail.com
    age: 27
    '''

    person_str_invalid = '''
    name: Bob
    email: bob@gmail.com
    age: hello
    '''

    book_str = '''
    title: Cooking Basics for Dummies
    author:
        name: Bob
        email: bob@gmail.com
        age: 27
    '''


# Generated at 2022-06-12 16:17:43.222055
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test function validate_yaml
    """
    from typesystem.error_messages import ErrorMessage

    content = """
        foo: 123
    """
    yaml_schema = Schema(
        foo=Integer(),
    )
    value, error_messages = validate_yaml(content, yaml_schema)
    assert value == {"foo": 123}
    assert error_messages == []



# Generated at 2022-06-12 16:17:52.142927
# Unit test for function validate_yaml
def test_validate_yaml():
    from datetime import datetime
    from pytz import timezone

    from typesystem.fields import String, DateTime, Float, Integer, Boolean
    from typesystem.schemas import Schema

    try:
        import yaml
    except ImportError:  # pragma: no cover
        pytest.skip("pyyaml not installed")

    TIMEZONE = timezone("US/Eastern")

    def fair_weather_field() -> Field:
        return Float(minimum=32)

    class ForecastSchema(Schema):
        temp_lst = fair_weather_field()
        temp_low = fair_weather_field()
        temp_high = fair_weather_field()
        temp_app = fair_weather_field()
        text = String()
        icon = String()

# Generated at 2022-06-12 16:18:01.587418
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Note:
    All the test cases are written to test both the valid and invalid cases. 
    When a valid case is tested, a validator is passed to validate_yaml function and it is expected that no error messages are returned. On the other hand, when an invalid case is tested, a validator is not given, and it is expected that the validation error messages are returned. 
    """
    assert yaml is not None, "'pyyaml' must be installed."

    # Test valid YAML string which contains a list
    test_content = '''
    - 1
    - 2
    - 3
    '''
    token = tokenize_yaml(test_content)
    actual_value, actual_error_messages = validate_with_positions(token=token, validator=None)

# Generated at 2022-06-12 16:18:13.149545
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(type="string")
    content = "{}"
    value, errors = validate_yaml(content, field)
    assert errors[0].code == "no_content"

    content = "null"
    value, errors = validate_yaml(content, field)
    assert errors[0].code == "invalid_type"

    content = "123"
    value, errors = validate_yaml(content, field)
    assert errors[0].code == "invalid_type"

    content = '"123"'
    value, errors = validate_yaml(content, field)
    assert not errors

    content = "abc"
    value, errors = validate_yaml(content, field)
    assert not errors



# Generated at 2022-06-12 16:18:20.216787
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Test case to test the validation of YAML document using tokenize_yaml()
    """
    content = """
    firstName: John
    lastName: Smith
    isAlive: true
    age: 25
    address:
        streetAddress: 21 2nd Street 
        city: New York
        state: NY
    phoneNumbers:
        - type: home
          number: 212 555-1234
        - type: office
          number: 646 555-4567
        - type: mobile
          number: 123 456-7890
    children:
        - firstName: Anna
          lastName: Smith
          age: 5
        - firstName: Samantha
          lastName: Smith
          age: 3
    """

    token = tokenize_yaml(content)

    # Check if the type of token is a dict


# Generated at 2022-06-12 16:18:31.657866
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: test
    other:
        hello: world
    """
    class TestSchema(Schema):
        name = Field(str)
        other = Field(dict)

    # test valid content
    value, errors = validate_yaml(content, TestSchema)
    assert value == {"name": "test", "other": {"hello": "world"}}
    assert errors == []

    # test invalid yaml
    exc = None
    try:
        _, _ = validate_yaml("foo: bar\n  baz: 1\n", TestSchema)
    except ParseError as e:
        exc = e

    assert exc is not None
    assert exc.code == "parse_error"
    assert exc.position.line_no == 2
    assert exc.position.column_no == 3


# Generated at 2022-06-12 16:18:37.275128
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    id:1
    str:str
    list:
        - 1
        - 2
    dict:
        a: 1
        b: 2
    null: null
    '''
    content = content.encode('utf-8')
    MySchema = Schema(
        id = int,
        str = str,
        list = [int],
        dict = {'a': int, 'b': int},
        null = None
    )
    result = validate_yaml(content=content, validator=MySchema)
    print(result)


if __name__ == "__main__":
    test_validate_yaml()

# Generated at 2022-06-12 16:18:46.292871
# Unit test for function validate_yaml
def test_validate_yaml():
	content = '''
name: "John Smith"
age: 45
'''
	class MySchema(Schema):
	    name = String(min_length=2, max_length=150)
	    age = Integer(minimum=1, maximum=130)
	print(validate_yaml(content=content, validator=MySchema))
test_validate_yaml()

# Generated at 2022-06-12 16:18:57.237487
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    a: "abcd"
    b:
        c: "efgh"
    '''
    validator_schema_class = typing.TypeVar('validator_schema_class')
    class ExampleSchema(Schema):
        a = Field(type=str)
        b = Field(type=validator_schema_class)
    class BFieldSchema(Schema):
        c = Field(type=str)
    validator = ExampleSchema()
    validator.fields['b'].validators[0].cls = BFieldSchema
    value, errors = validate_yaml(content, validator)
    print(value)
    print(errors)
    assert(errors == list())

# Generated at 2022-06-12 16:19:02.300243
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema
    from typesystem.fields import Integer, String

    class Person(Schema):
        name = String(max_length=10)
        age = Integer()
        brother = Integer()

    content = b"""
    name: 100
    age: hello
    brother: 10
    """

    # test error messages
    value, error_messages = validate_yaml(content, Person)
    assert error_messages["name"].text == 'Value should not be longer than 10.'
    assert error_messages["age"].text == "Value is not an int."
    assert error_messages["brother"].text == "Value is not an int."

    content = b"""
    name: hello
    age: 10
    brother: 20
    """

    # test value return

# Generated at 2022-06-12 16:19:14.084790
# Unit test for function validate_yaml
def test_validate_yaml():
    good_yaml_string = """
        test_field: 1
        other_field: hello
    """

    class GoodTestType(Schema):
        test_field = fields.Integer()
        other_field = fields.String()

    assert validate_yaml(good_yaml_string, GoodTestType) == {'test_field': 1, 'other_field': 'hello'}

    bad_yaml_string = "test_field: 1\nother_field: hello"

    class BadTestType(Schema):
        test_field = fields.Integer()
        other_field = fields.String()

    message_list = validate_yaml(bad_yaml_string, BadTestType)

    assert message_list[0].text == 'Failure to parse.'

# Generated at 2022-06-12 16:19:22.998258
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Number

    class TestSchema(Schema):
        title = String(max_length=5)
        age = Integer()
        pi = Number(maximum=3.14)

    result, errors = validate_yaml("title: Beethoven\nage: 20", TestSchema)
    assert not errors, errors

    result, errors = validate_yaml("bad_field: something", TestSchema)
    assert errors, errors
    assert errors[0].code == "invalid_field", errors

    result, errors = validate_yaml("title: Beethoven\nage: twenty", TestSchema)
    assert errors, errors
    assert errors[0].code == "type_error", errors


# Generated at 2022-06-12 16:19:34.753003
# Unit test for function validate_yaml
def test_validate_yaml():
    import typing
    from typesystem.fields import Any, Boolean, Integer, Text
    from typesystem.schemas import Schema

    class MySchema(Schema):

        # Example of a custom validator with a positional error message.
        name = Text(validators=[lambda v: {"valid": False, "message": "not good"}])
        age = Integer()

        # Example of a nested schema.
        about = Schema(fields={"name": Text(), "age": Integer()})

        # Example of a Boolean field.
        is_good = Boolean()

        # Example of a field that accepts a choice of scalar values.
        grade = Text(choices=["A", "B", "C"])

        # Example of a field that accepts any value.
        any_value = Any()

        # Example of a field with a custom error message

# Generated at 2022-06-12 16:19:41.593396
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = fields.String()
        age = fields.Integer(minimum=0, maximum=150)

    content = dedent(
        """
    name: Foo
    age: florp
    """
    ).strip()
    value, messages = validate_yaml(content, Person)
    assert isinstance(messages[0], ValidationError)
    assert messages[0].position.line_no == 3
    assert messages[0].position.column_no == 5



# Generated at 2022-06-12 16:19:46.283468
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer

    class MySchema(Schema):
        s = String(max_length=2)
        i = Integer()

    value, errors = validate_yaml(b'---\ns: x\ni: 1', MySchema)
    assert errors == []

    value, errors = validate_yaml(b"---\ns: xxx\ni: 1", MySchema)
    assert errors == [
        Message(
            text="Must have no more than 2 characters.",
            code="max_length",
            position=Position(
                line_no=2, column_no=3, char_index=5,
            ),
        ),
    ]

# Generated at 2022-06-12 16:19:50.972162
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, schema, fields
    from typesystem.errors import StringValidationError

    def _validate_yaml(content: str, validator: typing.Union[Field, typing.Type[Schema]]) -> typing.Any:
        return validate_yaml(content, validator=validator)

    class UserSchema(Schema):
        name = fields.String(required=True, max_length=20, trim_whitespace=True)

    class UserSchemaWithList(Schema):
        users = fields.List(fields.String())

    def _get_message(index: int) -> Message:
        return Message(
            code="required",
            text="This field is required.",
            position=Position(char_index=index, column_no=None, line_no=None),
        )



# Generated at 2022-06-12 16:20:01.839850
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import String, Number, Array, Object

    class Person(Schema):
        name = String(max_length=100)
        age = Number()
        children = Array(items=Object(Person))

    data = """
    name: Fred
    age: 42
    children:
      - name: John
        age: 5
      - name: Jane
        age: 6
    """

    (value, errors) = validate_yaml(data, Person)

    assert not errors
    assert value == {
        "name": "Fred",
        "age": 42.0,
        "children": [
            {"name": "John", "age": 5.0, "children": []},
            {"name": "Jane", "age": 6.0, "children": []},
        ],
    }

# Generated at 2022-06-12 16:20:22.236838
# Unit test for function validate_yaml
def test_validate_yaml():
    from yaml_validator import validate_yaml
    from typesystem import Integer, String, Schema

    class PersonSchema(Schema):
        name = String()
        age = Integer(maximum=100)

    # valid YAML
    content = '''
    name: Daniel Roy Greenfeld
    age: 35
    '''
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {
        'name': 'Daniel Roy Greenfeld',
        'age': 35
    }
    assert error_messages == []

    # invalid YAML
    content = '''
    name: Daniel Roy Greenfeld
    age: 35
    invalid_field: "huh?"
    '''
    value, error_messages = validate_yaml(content, PersonSchema)
    assert error

# Generated at 2022-06-12 16:20:29.416291
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        product:
          name: widget
          description: a widget
          quantity: 5
        customers:
          - name: alice
            age: 10
            favorite_colors:
              - red
              - blue
          - name: bob
            age: 20
            favorite_colors:
              - green
        """
    color_validator = Field(name="color", type_="string", max_length=10)
    customer_validator = Schema(
        name="customer",
        fields=[
            Field(name="name", type_="string", max_length=10),
            Field(name="age", type_="integer", minimum=1, maximum=85),
            Field(name="favorite_colors", type_="array", items=color_validator),
        ],
    )
    schema_valid

# Generated at 2022-06-12 16:20:38.565648
# Unit test for function validate_yaml
def test_validate_yaml():
    """ This test validates that the validate_yaml function captures any errors and returns them in an array
        Furthermore, that the index of the error is correct and the error is of type ParseError or ValidationError
    """
    try:
        from typesystem import types
    except ImportError:
        raise ImportError("This test requires the typesystem package.")

    # Test that a ParseError is returned for an invalid YAML file
    schema = types.Schema(
        name=types.String(min_length=3), email=types.Email(), age=types.Integer(min_value=0)
    )
    yaml_str = """
    name: "Bob"
    email: bob@bob.com
    age: 30
    """

    data, errors = validate_yaml(yaml_str, schema)

# Generated at 2022-06-12 16:20:39.115554
# Unit test for function validate_yaml
def test_validate_yaml():
    pass

# Generated at 2022-06-12 16:20:46.111276
# Unit test for function validate_yaml
def test_validate_yaml(): # type: ignore
    class TestYAMLSchema(Schema): # type: ignore
        class Meta:
            content_type = "application/x-yaml"

        name = StringField(max_length=100)

    content = """
---
name: Test
"""

    (value, errors) = validate_yaml(content, validator=TestYAMLSchema)
    assert value
    assert len(errors) == 0

validate_yaml.__doc__ = validate_with_positions.__doc__

# Generated at 2022-06-12 16:20:52.626197
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
      # This is a comment
      foo: bar
      baz: 1
      qux: false
      quux: null
    """
    def validator(value: typing.Any) -> typing.Any:
        if "baz" in value and value["baz"] not in [1, 3]:
            raise ValidationError(text="Not a valid baz value.")
        return value
    try:
        assert validate_yaml(content, validator) == ({'foo': 'bar', 'baz': 1, 'qux': False, 'quux': None}, [])
    except AssertionError:
        print("Function 'validate_yaml' failed the unit test.")
    else:
        print("Function 'validate_yaml' PASSED the unit test.")
    # test the case that content is empty


# Generated at 2022-06-12 16:20:53.936830
# Unit test for function validate_yaml
def test_validate_yaml():
    pass

# Generated at 2022-06-12 16:21:01.550021
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test that a value's yaml can be validated and parsed successfully.
    """
    import typesystem
    schema = typesystem.Schema(
        fields={
            "name": "string",
            "age": "integer",
            "friends": "array",
            "things": "object",
        }
    )

    value, errors = validate_yaml(
        b"name: Dave\nage: 32\nthings:\n  red: true\n  blue: false", schema
    )

    assert len(errors) == 0
    assert value == {
        "name": "Dave",
        "age": 32,
        "friends": None,
        "things": {"red": True, "blue": False},
    }



# Generated at 2022-06-12 16:21:13.624766
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: Norway
      region: Europe
      capital: Oslo
      climate: Polar
    - name: Japan
      region: Asia
      capital: Tokyo
      climate: Temperate
    """

    class CountrySchema(Schema):
        name = "Country"
        fields = {
            "name": "string",
            "region": "string",
            "capital": "string",
            "climate": "string",
        }

    try:
        yaml.load(content, yaml.FullLoader)
    except yaml.scanner.ScannerError:
        # This schema is invalid as per yaml.SafeLoader
        # So validate_yaml should throw an exception.
        with pytest.raises(ValidationError) as ex:
            validate_yaml(content, CountrySchema)
        
       

# Generated at 2022-06-12 16:21:20.734285
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml
    """
    class Person(Schema):
        name = field(type=str, max_length=3)

    in1 = "name: Hamed"
    out1 = ("Hamed", [])

    in2 = "name: Hamedreza"
    out2 = ("Hamedreza", [Message(text="Must have no more than 3 characters.", code="max_length")])

    return validate_yaml(in1, Person) == out1, validate_yaml(in2, Person) == out2

# Generated at 2022-06-12 16:21:36.720786
# Unit test for function validate_yaml
def test_validate_yaml():
    expected_errors = {
        "text": "Does not match schema. Expected a field called 'name'.",
        "line_no": 3,
        "column_no": 1,
        "code": "missing_key",
    }
    content = """
a: 1
b:
  - 2
  - 3
"""
    schema = Schema(
        name=Field(),
        items=ListField(Field(type="integer")),
    )
    value, error_messages = validate_yaml(content, schema)
    assert error_messages[0].to_dict() == expected_errors



# Generated at 2022-06-12 16:21:44.057543
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None

    content = b"""
        key: value
        another_key:
            - a
            - b
            - c
    """

    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

    first_row = token.value["another_key"][1]
    assert isinstance(first_row, ScalarToken)
    assert first_row.value == "b"
    assert first_row.start == 62
    assert first_row.end == 63



# Generated at 2022-06-12 16:21:53.501759
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem import Integer, String, Array, Enum
    from typesystem import errors 

    content = '''
    name: john
    age: 13
    is_child: true
    location: nyc
    '''

    validator = {
        "name": String(),
        "age": Integer(),
        "is_child": Boolean(),
        "location": Enum(choices=["nyc", "tokyo", "london"])
    }

    value, errors = validate_yaml(content, validator)

    assert value == {
        'name': "john",
        'age': 13,
        'is_child': True,
        'location': 'nyc'
    }
    assert errors == []



# Generated at 2022-06-12 16:22:03.803172
# Unit test for function validate_yaml
def test_validate_yaml():
    # set the validator type
    class PetSchema(Schema):
        name = types.String(required=True)
        age = types.Integer(minimum=0)
        vaccinated = types.Boolean(default=False)
    pet_schema = PetSchema()

    # prepare the content
    test_content = '''
    - name: "동물1"
      age: 3
    - name: "동물2"
      age: 5
      vaccinated: true
    '''
    # test
    value, error_messages = validate_yaml(test_content, pet_schema)
    assert error_messages == []
    # expected value

# Generated at 2022-06-12 16:22:08.847843
# Unit test for function validate_yaml
def test_validate_yaml():
    # test parse error
    with pytest.raises(ParseError):
        validate_yaml("{a: 1, b: [1, 2]}", validator=Schema)

    # test validation error
    with pytest.raises(ValidationError):
        validate_yaml("a: 1\nb: 1", validator=Schema)