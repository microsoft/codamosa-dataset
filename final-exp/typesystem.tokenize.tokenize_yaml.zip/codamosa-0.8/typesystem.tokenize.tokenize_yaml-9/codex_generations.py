

# Generated at 2022-06-12 16:12:24.170419
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("name: John") == DictToken({"name": "John"}, 0, 11)
    assert tokenize_yaml('name: "John"') == DictToken({"name": "John"}, 0, 12)



# Generated at 2022-06-12 16:12:29.680396
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        foo: bar
        baz: [1, 2, 3]
        qux:
            - a
            - z
        """
    result = tokenize_yaml(content)
    assert result == {'foo': 'bar', 'baz': [1, 2, 3], 'qux': ['a', 'z']}


# Generated at 2022-06-12 16:12:39.530249
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test tokenize_yaml() on a simple integer
    token = tokenize_yaml("42")
    assert token.__class__.__name__ == "ScalarToken"
    assert token.start == 0
    assert token.end == 1
    assert token.value == 42
    assert token.content == "42"

    # Test tokenize_yaml() on a list of strings
    token = tokenize_yaml(
        """
        - foo
        - bar
        - baz
    """
    )
    assert token.__class__.__name__ == "ListToken"
    assert token.start == 0
    assert token.end == 30
    assert token.value == ["foo", "bar", "baz"]

# Generated at 2022-06-12 16:12:49.167934
# Unit test for function validate_yaml

# Generated at 2022-06-12 16:13:01.600397
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(b'[1,2,3]', ListField(Field())) == ([1,2,3], [])
    assert validate_yaml(b'[1,2,3,a]', ListField(Field()))[1][0].code == 'type'
    assert validate_yaml(b'{name: 1, age:2}', Schema('x', {'name': Field(), 'age': Field()})) == ({'name': 1, 'age': 2}, [])
    assert validate_yaml(b'{name: 1, age:2}', Schema('x', {'name': ListField(Field()), 'age': Field()}))[1][0].code == 'type'

# Generated at 2022-06-12 16:13:09.491931
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Generate tokens from YAML string
    def _tokenize_yaml(yaml_str):
        tokens = []
        token = tokenize_yaml(yaml_str)
        tokens.append(token)
        while len(tokens)>0:
            token = tokens.pop(0)
            if isinstance(token,DictToken):
                for key,val in token.value.items():
                    tokens.append(val)
            elif isinstance(token,ListToken):
                for val in token.value:
                    tokens.append(val)
            yield token
    # Test function
    def test_yaml(yaml_str):
        vals = []
        for token in _tokenize_yaml(yaml_str):
            vals.append(token.value)
        return vals


# Generated at 2022-06-12 16:13:12.794469
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        name = CharField(max_length=100)
        age = IntegerField(min_value=0)

    content = """
    name: yaml
    age: 1
    """

    UserSchema.validate(content)


# Generated at 2022-06-12 16:13:18.351688
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # case1
    content = "a"
    assert tokenize_yaml(content).content == "a"

    # case2
    content = "a\nb"
    assert tokenize_yaml(content).content == "a\nb"

    # case3
    content = "a\nb"
    assert tokenize_yaml(content).content == "a\nb"

    # case4
    # case5
    content = "  a\n  b"
    assert tokenize_yaml(content).content == "  a\n  b"

    # case6
    # case7
    content = "  a: b\n  c: d"
    assert tokenize_yaml(content).content == "  a: b\n  c: d"

    # case8
    # case9

# Generated at 2022-06-12 16:13:26.375392
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('{a: 1, b: 2}') == {'a': 1, 'b': 2}
    assert tokenize_yaml('[3, 4]') == [3, 4]
    assert tokenize_yaml('null') is None
    assert tokenize_yaml('false') is False
    assert tokenize_yaml('true') is True
    assert tokenize_yaml('2.2') == 2.2
    assert tokenize_yaml('-2.2') == -2.2
    assert tokenize_yaml('-10') == -10
    assert tokenize_yaml('5') == 5
    assert tokenize_yaml('"ajax"') == "ajax"
    assert tokenize_yaml('"fajax"') == "fajax"
    assert tokenize

# Generated at 2022-06-12 16:13:35.492882
# Unit test for function validate_yaml
def test_validate_yaml():

    from typesystem.integer_field import IntegerField
    from typesystem.string_field import StringField

    class Person(Schema):
        name = StringField(length_min=2, length_max=10)
        age = IntegerField(lte=100)

    assert validate_yaml('{"name": "Frank", "age": 32}', Person) == ({'age': 32, 'name': 'Frank'}, [])

# Generated at 2022-06-12 16:13:52.781836
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        notes = Field(type="array", items={"type": "string"})
        stuff = Field(type="object", properties={"foo": {"type": "string"}})

    yaml_str = """
    name: Jazz
    age: 5
    notes:
      - a dog
      - a cat
    stuff:
      foo: bar
    """

    _, errors = validate_yaml(yaml_str, MySchema)
    assert len(errors) == 0

    yaml_str = """
    name: Jazz
    age: five
    notes:
      - a dog
      - a cat
    stuff:
      foo: bar
    """


# Generated at 2022-06-12 16:14:01.613693
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """Unit test for function tokenize_yaml"""
    # test basic scalar values
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("\"hello\"") == ScalarToken("hello", 0, 7, content="\"hello\"")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    # test lists

# Generated at 2022-06-12 16:14:10.165969
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem import Schema

    class Comment(Schema):
        comment = String()

    content = """
    - name: john
      comment: "marry is silly"
    - name: marry
      comment: "john is silly"
    """

    class CommentSchema(Schema):
        name = String()
        comment = String()

    error_messages = validate_yaml(
        content=content, validator=CommentSchema(),
    )
    error_message = error_messages[0]  # type: ValidationError
    print(error_message.text)
    print(error_message.position)

# Generated at 2022-06-12 16:14:12.249024
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    print('ok')


# Generated at 2022-06-12 16:14:22.975028
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content="[]", validator=List(items=Integer())) == ([], [])

    assert validate_yaml(content="", validator=List(items=Integer())) == (
        None,
        [ErrorMessage(text="No content.", code="no_content", position=Position(column_no=1, char_index=0, line_no=1))],
    )

    assert validate_yaml(
        content="[1, ", validator=List(items=Integer())
    ) == (
        None,
        [
            ErrorMessage(
                text="found unexpected end of stream", code="parse_error", position=Position(column_no=5, char_index=4, line_no=1)
            )
        ],
    )


# Generated at 2022-06-12 16:14:32.259269
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema
    from typesystem.base import ErrorMessage, Position
    from typesystem.types import String

    class ExampleSchema(Schema):
        name = String(min_length=5)

    content = "---\nname: a\n"
    value, error_messages = validate_yaml(content, validator=ExampleSchema)
    assert isinstance(error_messages, list)
    assert len(error_messages) == 1
    error = error_messages[0]
    assert isinstance(error, ErrorMessage)
    assert error.text == "Must be at least 5 characters."
    position = Position(column_no=5, line_no=2, char_index=7)
    assert error.position == position
    assert error.code == "min_length"


# Generated at 2022-06-12 16:14:44.484454
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem import Schema, fields

    class PetSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    content = """
    - name: fido
      age: 4
    - name: fluffy
      age: 3
    """
    token = tokenize_yaml(content)

    assert isinstance(token, ListToken)
    assert token.value[0]["name"].value == "fido"

    # Take a pass at parsing some broken YAML.
    try:
        str_content = "this is bad yaml"
        tokenize_yaml(str_content)
    except ParseError as exc:
        assert exc.text == "could not find expected ':'."
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1

# Generated at 2022-06-12 16:14:56.039621
# Unit test for function validate_yaml
def test_validate_yaml():  # type: ignore
    from typesystem.types import Text
    from ..schemas import Schema

    content = """
        a:
            b: foo
        c: [
            bar,
            baz
        ]
        d:
            e:
                f: 1
                g: 1.5
                h: false
                i: true
                j: null
        k: hello
    """
    class Nested(Schema):
        a = Schema(fields={"b": Text()})
        c = Text()

    class ValidateYamlSchema(Schema):
        d = Nested
        k = Text()


# Generated at 2022-06-12 16:15:04.101174
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer

    class Movie(Schema):
        title = String(max_length=100)
        rating = Integer(minimum=1, maximum=10)

    content = """
    title: Pulp Fiction
    rating: 11
    """

    value, error_messages = validate_yaml(content, Movie)

    assert error_messages == [
        Message(
            text="Value 11 is too large.",
            code="max_value",
            position=Position(line_no=3, column_no=8, char_index=25),
        )
    ]

# Generated at 2022-06-12 16:15:13.433259
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Tests the behaviour of validate_yaml
    """
    # Test for parsing errors
    content = "not a yaml string"
    with pytest.raises(Exception) as exception:
        validate_yaml(content, String)
    exception = exception.value
    assert isinstance(exception, ParseError)
    assert exception.code == "parse_error"
    assert exception.text == "found character that cannot start any token."
    assert exception.position.line_no == 1
    assert exception.position.column_no == 6
    assert exception.position.char_index == 5

    yaml_string = "foo: bar"
    with pytest.raises(Exception) as exception:
        validate_yaml(yaml_string, String)
    exception = exception.value

# Generated at 2022-06-12 16:15:27.808915
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        a: This is a string.
        b:
          - This is an item in a list.
          - This too.
        c:
          - This is a list within a list.
            Like so.
          - This is another list within a list.
            Like so.
        d: This is a mapping within a mapping.
          Like so.
        """
    class MySchema(Schema):
        a = Field(type="string")
        b = Field(type="string[]")
        c = Field(type="string[][]")
        d = Field(type="string")
    value, error_messages = validate_yaml(content, MySchema)

# Generated at 2022-06-12 16:15:36.802594
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields
    class ColorSchema(Schema):
        name = fields.String()
        value = fields.String()
    content = """
    - name: red
      value: "#FF0000"
    - name: green
      value: "#00FF00"
    - name: blue
      value: "#0000FF"
    """

    # valid data
    (value, error_messages) = validate_yaml(content, validator=ColorSchema)
    assert not error_messages
    assert value == [
        {'name': 'red', 'value': '#FF0000'},
        {'name': 'green', 'value': '#00FF00'},
        {'name': 'blue', 'value': '#0000FF'},
    ]

    # invalid data

# Generated at 2022-06-12 16:15:48.654219
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(required=True)
        age = Integer(minimum=16, maximum=100)

    # We expect to have the following results
    expected_value = {"name": "James", "age": 16}
    expected_errors: typing.List[ValidationError] = [
        ValidationError(
            field="name",
            code="required",
            text="This field is required.",
            position=Position(line_no=1, column_no=6, char_index=5),
        ),
        ValidationError(
            field="age",
            code="minimum",
            text="Must be at least 1.",
            position=Position(line_no=1, column_no=24, char_index=23),
        ),
    ]


# Generated at 2022-06-12 16:15:57.990889
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = String(max_length=10)
        age = Integer(maximum=150)
    token, errors = validate_yaml('name: "Sascha"\nage: 20', PersonSchema)
    assert token.value['name'] == 'Sascha'
    assert token.value['age'] == 20
    assert errors == None

    token, errors = validate_yaml('name: "Sascha"' + ' '*50 + 'age: 20', PersonSchema)
    assert errors[0].position.char_index == 12
    assert errors[0].position.column_no == 13
    assert errors[0].position.line_no == 1
    assert errors[0].text == "Not a valid dictionary."
    assert errors[0].code == "parse_error"

    token,

# Generated at 2022-06-12 16:15:58.873947
# Unit test for function validate_yaml
def test_validate_yaml():
    # TODO
    return



# Generated at 2022-06-12 16:16:05.957693
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = String(max_length=10)

    content = """
    name: 'aerthyr aerthyr aerthyr aerthyr'
    """
    value, errors = validate_yaml(content, validator=MySchema)

    assert errors[0].code == "max_length"
    assert errors[0].position.line_no == 2

# Generated at 2022-06-12 16:16:16.756548
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken, Token
    content = """foo:
        bar:
            baz: 42
    qux:
        - 1
        - 2
        - 3"""
    root_token = tokenize_yaml(content)
    assert isinstance(root_token, DictToken)
    assert root_token.keys == ['foo', 'qux']
    foo_token = root_token['foo']
    assert isinstance(foo_token, DictToken)
    assert foo_token.keys == ['bar']
    bar_token = foo_token['bar']
    assert isinstance(bar_token, DictToken)
    assert bar_token.keys == ['baz']
    baz_token = bar_token['baz']
    assert isinstance

# Generated at 2022-06-12 16:16:28.010098
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class MySchema(Schema):
        foo = "string"
        bar = "integer"
        baz = "boolean"

    content = """
    foo: foo
    bar: 2
    baz: true
    """
    value, errors = validate_yaml(content, MySchema)
    assert value == {"foo": "foo", "bar": 2, "baz": True}
    assert errors == []

    value, errors = validate_yaml("foo: foo\nbar: true", MySchema)
    assert value == {"foo": "foo"}
    assert len(errors) == 1

    message = errors[0]
    assert message.text == "'true' is not a valid integer."
    assert message.code == ValidationError.C

# Generated at 2022-06-12 16:16:36.367114
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    import typesystem

    # Validates that the validator will work with a type system field.
    class ListOfIntegers(typesystem.Field):
        def __init__(self):
            super().__init__(typesystem.array(typesystem.integer()))

    # Validates that the validator will work with a type system schema.
    class ListOfIntegersSchema(typesystem.Schema):
        value = typesystem.array(typesystem.integer())

    # Any type of content can be passed in, so long as it parses as valid YAML.
    content = """
    - 1
    - 2
    - 3
    - 4
    """
    # Can also pass in bytestrings instead of strings
    # content = b"""
    # -

# Generated at 2022-06-12 16:16:43.928015
# Unit test for function validate_yaml
def test_validate_yaml():
    class CustomSchema(Schema):
        key = Field(int)

    error_messages = validate_yaml(content="key: 12\n", validator=CustomSchema)
    assert error_messages == []

    error_messages = validate_yaml(content="key: 12\n", validator=Field(int))
    assert error_messages == [
        Message(
            text="Data must be of a list.",
            code="invalid_type",
            position=Position(column_no=1, line_no=1, char_index=0),
        )
    ]

# Generated at 2022-06-12 16:16:59.371861
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = "MySchema"
        fields = {"name": "string", "email": "string", "age": "number"}
    content = '''
    name: "John Doe"
    email: "john.doe@example.com"

    age: 42
    '''
    value, error_messages = validate_yaml(content, validator=MySchema)
    assert value == {
        "name": "John Doe",
        "email": "john.doe@example.com",
        "age": 42.0,
    }
    assert error_messages == []

    content = '''
    name: John Doe
    email: john.doe@example.com
    age: 42
    '''

# Generated at 2022-06-12 16:17:08.338449
# Unit test for function validate_yaml
def test_validate_yaml():
    # happy path
    result, errors = validate_yaml(b'foo: "bar"', Schema)
    assert result == {"foo": "bar"}
    assert len(errors) == 0

    # test validating against a field class
    result, errors = validate_yaml(b'foo: 1', Integer)
    assert result == 1
    assert len(errors) == 0

    # test that a parse error is raised
    with pytest.raises(ParseError) as exc_info:
        result, errors = validate_yaml(b'foo: 1:2:3', Integer)
    assert exc_info.value.text == "invalid node structure."
    assert exc_info.value.position.line_no == 1
    assert exc_info.value.position.column_no == 6

# Generated at 2022-06-12 16:17:19.971804
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        first_name = Field(type="string")
    content = """
      first_name: "John"
    """
    value, errors = validate_yaml(content, MySchema)
    assert value == {"first_name": "John"}
    content2 = """
      first_name: "John"
      last_name: "Doe"
    """
    value, errors = validate_yaml(content2, MySchema)
    assert errors == [Message(text="Unknown field name.", code="unknown_field", position=Position(line_no=3,column_no=10,char_index=32))]

"""
Unit tests for function tokenize_yaml

Test cases: 
1. Empty string
2. Invalid yaml
3. Valid yaml
"""

# Test

# Generated at 2022-06-12 16:17:31.483773
# Unit test for function validate_yaml
def test_validate_yaml():
    # arrays
    with pytest.raises(ValidationError) as exc_info:
        validate_yaml("*a", Field(name="test", type="str"))
    assert exc_info.value.messages == [
        Message(
            text="Expected a string.",
            code="type_error.str",
            position=Position(line_no=1, column_no=2, char_index=1),
        )
    ]

    with pytest.raises(ValidationError) as exc_info:
        validate_yaml("*a\n*b", Field(name="test", type="str"))

# Generated at 2022-06-12 16:17:37.859155
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer
    class SchemaTest(Schema):
        age = Integer()

    content = b"""
    name: "daniel"
    age: 42
    """

    result = validate_yaml(content, SchemaTest)
    assert result ==({'age': 42, 'name': 'daniel'}, [])

    class SchemaTest2(Schema):
        age = Integer(minimum=100)

    content2 = b"""
    name: "daniel"
    age: 42
    """

    result = validate_yaml(content2, SchemaTest2)
    assert len(result[1]) == 1
    assert isinstance(result[1][0], ValidationError)
    assert result[1][0].position.line_no == 3

# Generated at 2022-06-12 16:17:42.979366
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b'{"foo": "bar"}'
    class Person(Schema):
        foo = String(required=True)
    value, error = validate_yaml(content, Person)
    assert value == {"foo": "bar"}
    assert error == []


# Generated at 2022-06-12 16:17:51.925227
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Unit test suite for validate_yaml
    """
    import json
    from typesystem.schemas import Schema

    class SchemaYAML(Schema):
        name = "text"
        age = "integer"
        height = "float"

    schema = SchemaYAML()

    yaml_valid = """\
    name: John Doe
    age: 31
    height: 5.9\
    """

    errors = validate_yaml(yaml_valid, schema)
    assert errors is None

    # Make sure the fields are available to validate.
    value, errors = validate_yaml(yaml_valid, schema)
    assert value['name'] == 'John Doe'
    assert errors is None

    # Test errors in the YAML.

# Generated at 2022-06-12 16:18:01.353933
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None
    class TestSchema(Schema):
        name = fields.String(max_length=5)
        age = fields.Integer()

    data = {'name': 'Foobar', 'age': "10"}
    data = yaml.dump(data)
    value, err = validate_yaml(data, TestSchema)
    assert err[0].text == "Ensure this value has at most 5 characters (it has 6)."
    assert err[0].position.line_no == 2
    assert err[0].position.column_no == 5
    assert err[0].position.char_index == 9

    data = {'name': 'Foobar', 'age': 10}
    data = yaml.dump(data)
    value, err = validate_yaml(data, TestSchema)


# Generated at 2022-06-12 16:18:13.513500
# Unit test for function validate_yaml
def test_validate_yaml():
	#input = '''
	#a:
	#	- test1
	#	- test2
	#b:
	#	- test3
	#	- test4
	#'''

	input = '''
a: [1,2]
b: [3,4]
c: 5
d: test
	'''
	

# Generated at 2022-06-12 16:18:20.389821
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"foo": {"type": "string", "required": True}})
    value, errors = validate_yaml(b'{"foo": "bar"}', schema)
    # Check that the returned value gets parsed correctly.
    assert value == {"foo": "bar"}
    # Check that the returned errors gets parsed correctly.
    assert errors == []

    _, errors = validate_yaml(b'{"foo": 42}', schema)
    # Check that the returned errors gets parsed correctly.
    assert errors[0].code == "type_error.string"

    _, errors = validate_yaml(b"{}", schema)
    # Check that the returned errors gets parsed correctly.
    assert errors[0].code == "required"

    _, errors = validate_yaml(b"[foo: 'bar']", schema) 

# Generated at 2022-06-12 16:18:33.754284
# Unit test for function validate_yaml
def test_validate_yaml():

    class DocSchema(Schema):
        title = Field(type="string")
        items = Field(type="list", items=Field(type="string"))

    # Test successful validation of a valid YAML string.
    #assert validate_yaml('{"title": "Hello", "items": ["world"]}', DocSchema) == (
    #    {"title": "Hello", "items": ["world"]},
    #    [],
    #)

    # Test parse error reporting on an invalid YAML string.
    #with pytest.raises(ParseError) as exc_info:
    #    validate_yaml('{"title": "Hello", "items": "world"}', DocSchema)
    #assert exc_info.value.text == "mapping values are not allowed here."
    #assert exc_info.value.code

# Generated at 2022-06-12 16:18:37.486299
# Unit test for function validate_yaml
def test_validate_yaml():
    class NameInput(Schema):
        name = String()
    
    input = NameInput({"name": "Lucas"})
    assert validate_yaml("name: Lucas", input) == (
    {"name": "Lucas"},
    [],
    )


# Generated at 2022-06-12 16:18:48.406367
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem import types
    from typesystem.schemas import Schema
    from typesystem.fields import Field

    class PersonSchema(Schema):
        name = types.String(required=True)
        age = types.Number(required=True)

    class PersonField(Field):
        def validate(self, value: typing.Any) -> typing.Any:
            return value

    class DogSchema(Schema):
        name = types.String(required=True)
        age = types.Number(required=True)

    class DogField(Field):
        def validate(self, value: typing.Any) -> typing.Any:
            return value

    class RelationShipSchema(Schema):
        person = PersonSchema(required=True)
       

# Generated at 2022-06-12 16:18:58.353224
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    from typesystem.schemas import Schema
    from typesystem.fields import Array

    class Article(Schema):
        title = String()

    class ArticleList(Schema):
        articles = Array(of=Article)

    invalid_yaml = "foo: bar"
    invalid_result = validate_yaml(invalid_yaml, validator=ArticleList)
    assert invalid_result[1][0].text == 'While parsing the YAML: expected \'-\', but found \'f\''
    assert invalid_result[1][0].position.line_no == 1
    assert invalid_result[1][0].position.column_no == 1

    valid_yaml = "- title: Foo"
    valid_result = validate_yaml(valid_yaml, validator=ArticleList)
   

# Generated at 2022-06-12 16:19:07.158344
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_code = '''
    -
      name: value
    -
      name: another value
    -
      name:
        - nested
        - value
    '''
    class TestSchema(Schema):
        list_of_dicts = Field(type="list_of_dicts")

    try:
        validate_yaml(yaml_code, validator=TestSchema.fields["list_of_dicts"])
    except ValidationError as exc:
        print(exc)



# Generated at 2022-06-12 16:19:16.919950
# Unit test for function validate_yaml
def test_validate_yaml():

    class UserSchema(Schema):
        username = fields.String(max_length=20)
        age = fields.Integer(minimum=1, maximum=100)

    content = """
    username: aaaaaaaaaaaaaaaaaaaaa
    age: 20
    """

    assert validate_yaml(content, UserSchema) == (
        {
            "username": "aaaaaaaaaaaaaaaaaaaaa",
            "age": 20,
        },
        [
            Message(
                text="Must have no more than 20 characters.",
                code="max_length",
                position=Position(
                    line_no=2, column_no=20, char_index=39, content=content
                ),
            )
        ],
    )

# Generated at 2022-06-12 16:19:22.618048
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {"content": fields.Integer()}
    )

    parsed_value, error_messages = validate_yaml(b"content: abc", schema)
    assert parsed_value is None
    assert len(error_messages) == 3
    assert error_messages[0].text == "Must be an integer."
    assert error_messages[0].position == Position(
        line_no=1, column_no=10, char_index=9
    )



# Generated at 2022-06-12 16:19:34.606695
# Unit test for function validate_yaml
def test_validate_yaml():
    import os
    import warnings

    warnings.filterwarnings("ignore", category=DeprecationWarning)

    schema = Schema(fields={"name": Field(type="string")})

    assert validate_yaml('name: "Alex"', schema) == ({"name": "Alex"}, [])

    content = os.path.dirname(__file__) + "/test_samples/yaml_error.yml"
    with open(content) as fp:
        content = fp.read()


# Generated at 2022-06-12 16:19:43.951531
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class SimpleSchema(Schema):
        field = String()

    content = b'field: "Hello world!"'
    result = validate_yaml(content, SimpleSchema)
    assert result == ({"field": "Hello world!"}, [])

    content = b'field: "Hello world!"\nfield: "World"'
    result = validate_yaml(content, SimpleSchema)

# Generated at 2022-06-12 16:19:47.925940
# Unit test for function validate_yaml
def test_validate_yaml():
    content = 'name: value'
    validator = Field()
    value, error_messages = validate_yaml(content, validator)
    assert value == {'name': 'value'}
    assert error_messages == []

# Generated at 2022-06-12 16:20:01.922647
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Boolean
    from typesystem.schemas import Schema
    from typesystem.utils import strip_whitespace

    class UserSchema(Schema):

        name = String(max_length=100)
        age = Integer(minimum=18)
        active = Boolean()

    content = (
        "name: Dave\n" "age: 26\n" "active: true\n"  # noqa
    )
    value, errors = validate_yaml(content, UserSchema)
    assert value == {"name": "Dave", "age": 26, "active": True}

    # Test a parse failure.

# Generated at 2022-06-12 16:20:08.115867
# Unit test for function validate_yaml
def test_validate_yaml():
    class Movie(Schema):
        title = String(max_length=100)
        year = Int()

    validator = Schema(Movie())
    assert validate_yaml(
        content="""
            - title: "Star Wars: Episode IV - A New Hope"
              year: 1977
            - title: "Star Wars: Episode V - The Empire Strikes Back"
              year: 1980
        """,
        validator=validator,
    ) == (
        tokenize_yaml(content="""
            - title: "Star Wars: Episode IV - A New Hope"
              year: 1977
            - title: "Star Wars: Episode V - The Empire Strikes Back"
              year: 1980
        """),
        [],
    )

# Generated at 2022-06-12 16:20:19.932598
# Unit test for function validate_yaml
def test_validate_yaml():
    # Arrange
    schema = Schema("An example schema", properties={
        "title": Field("document title", type="string", max_length=30),
        "authors": Field("document authors", type="list", max_length=3),
        "published": Field("document publication date", type="date", format="date-time"),
        "nested": Field("nested data", type="dict", properties={
            "key": Field("data key", type="string", max_length=30),
            "value": Field("data value", type="number", maximum=1),
        }),
    })

    # Act

# Generated at 2022-06-12 16:20:29.807365
# Unit test for function validate_yaml
def test_validate_yaml():
    class ProfileSchema(Schema):
        name = fields.String(min_length=3)
        age = fields.Integer(minimum=18)

    yaml_str = 'name: Joe age: 12'
    token = tokenize_yaml(yaml_str)
    result = validate_with_positions(token=token, validator=ProfileSchema)

    if not isinstance(result, tuple):
        assert 'The result of validate_yaml is not a tuple'
    elif not len(result) == 2:
        assert 'The result should have 2 element, but have %d' % len(result)
    else:
        if isinstance(result[1], ValidationError):
            print(result)

# Generated at 2022-06-12 16:20:38.004861
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Schema
    from typesystem.components import AllowAny
    my_schema = Schema(fields=[
        String('id', max_length=256), Integer('age', minimum=0)
    ],
             allow_additional_fields=True)
    my_schema.validate({'id':'1', 'age':'2', 'gender':'male', 'name':'temp'}) is None
    my_message = Message('age', 'This is an age')
    my_schema.validate({'id':'1', 'age':'2', 'gender':'male', 'name':'temp'}) == [my_message]

# Generated at 2022-06-12 16:20:47.966169
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        content="", validator=Schema(properties={"name": String()})
    ) == (None, [Message(text="No content.", code="no_content", position=Position(1, 1, 0))])

    assert validate_yaml(
        content='name: "Tom"', validator=Schema(properties={"name": String()})
    ) == ({"name": "Tom"}, [])


# Generated at 2022-06-12 16:20:59.463552
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(name=Field(type="string"), age=Field(type="integer"))

    content = """
    name: frank
    age: 12
    """

    value, errors = validate_yaml(content, validator=schema)
    assert value == {"name": "frank", "age": 12}
    assert len(errors) == 0

    content = """
    name: frank
    age: foo
    """

    value, errors = validate_yaml(content, validator=schema)
    assert value == None
    assert len(errors) == 1
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5
    assert errors[0].position.char_index == 11

    content = """
    age: 12
    name: frank
    """

   

# Generated at 2022-06-12 16:21:11.041822
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: Some test person
    address:
        street: 123 Main St
        city: Some Town
    age: 123
    """
    validator = Schema(
        [
            Field(name="name", type="string"),
            Field(name="age", type="integer"),
            Field(
                name="address",
                type="object",
                fields=[
                    Field(name="street", type="string"),
                    Field(name="city", type="string"),
                ],
            ),
        ]
    )
    result = validate_yaml(content, validator)
    assert result[0] == {
        'name': 'Some test person',
        'age': 123,
        'address': {
            'street': '123 Main St',
            'city': 'Some Town'
        }
    }


# Generated at 2022-06-12 16:21:19.411496
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        username = String()
        password = String()

    text = "foo:\n  bar:\n    username: a\n    password: 123456"
    (ok, messages) = validate_yaml(text, UserSchema)

    assert not ok
    assert len(messages) == 1

    message = messages[0]
    assert message.text == "bar is not a valid mapping."
    assert message.code == "invalid_mapping"
    assert message.position.char_index == 5
    assert message.position.column_no == 6
    assert message.position.line_no == 2



# Generated at 2022-06-12 16:21:27.192082
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Unit test for function validate_yaml
    """

    class TodoSchema(Schema):
        title = String(max_length=255)

    content = """
    - title: Get milk
    - title: Get eggs
    - title: Get bread
    """

    # Using Schema
    result = validate_yaml(
        content=content.encode(), validator=TodoSchema)
    assert result[1] is None

    # Using Field
    result = validate_yaml(
        content=content.encode(), validator=List(TodoSchema))
    assert result[1] is None

    content = """
    - title: Get milk
    - title:
    - title: Get bread
    """

    # Using Schema

# Generated at 2022-06-12 16:21:37.441662
# Unit test for function validate_yaml
def test_validate_yaml():
    # Error handling for invalid YAML.
    with pytest.raises(Exception) as excinfo:
        validate_yaml("[a, b] hello", TypedList([Str()]))
    e = excinfo.value
    assert e.text == "could not find expected ',' or ']'."
    assert e.position.line_no == 1
    assert e.position.column_no == 7
    assert e.position.char_index == 7
    # yaml.load_all returns a generator.
    assert list(yaml.load_all("[a, b] hello")) == [["a", "b"]]

    # Error handling for valid but incorrect YAML.

# Generated at 2022-06-12 16:21:41.408215
# Unit test for function validate_yaml
def test_validate_yaml():
    from io import StringIO
    yml_val = StringIO("""
        - foo
        - bar
        - 123
    """)
    validator = ListToken([])
    value, errors = validate_yaml(yml_val, validator)
    assert errors == []

# Generated at 2022-06-12 16:21:51.322225
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Function test_validate_yaml
    """
    import typesystem

    class TestSchema(typesystem.Schema):
        """
        Class TestSchema
        """
        num = typesystem.Number(minimum=1, maximum=2)
        text = typesystem.Text(min_length=2)

    value = validate_yaml(b"num: 7\ntext: foo", TestSchema)
    assert isinstance(value, tuple)
    assert isinstance(value[0], dict)
    assert isinstance(value[0]["num"], float)
    assert isinstance(value[0]["text"], str)
    assert len(value[1]) == 2
    assert isinstance(value[1][0], ValidationError)
    assert value[1][0].code == "min_value"

# Generated at 2022-06-12 16:21:57.153856
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    content = '''
    ---
    a: 1
    b:
      - 1
      - 2
    c: 3
    '''
    d = tokenize_yaml(content)
    assert d == {"a": 1, "b": [1, 2], "c": 3}



# Generated at 2022-06-12 16:22:02.975692
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = "Person"
        fields = [
            "first_name",
            "last_name",
            "age",
            "parents",
            "address",
            "lucky_numbers",
            "birthday",
            "children",
        ]

    class AddressSchema(Schema):
        name = "Address"
        fields = ["street", "apt", "city", "state", "zip_code"]


# Generated at 2022-06-12 16:22:04.223485
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml() == None

__all__ = ["tokenize_yaml", "validate_yaml"]

# Generated at 2022-06-12 16:22:14.554919
# Unit test for function validate_yaml
def test_validate_yaml():
    class Coordinate(Schema):
        x = Integer
        y = Integer

    class Point(Schema):
        name = String()
        coordinate = Coordinate

    content = """
    name: point one
    coordinate:
        x: 10
        y: 20
    """

    value, errs = validate_yaml(content, Point)
    assert value == {"name": "point one", "coordinate": {"x": 10, "y": 20}}
    assert errs == []

    class Point2(Schema):
        name = String()
        coordinate = Coordinate

    content2 = """
    name: point one
    coordinate:
        x: hello
        y: 20
    """

    value2, errs2 = validate_yaml(content2, Point2)
    assert value2 is None