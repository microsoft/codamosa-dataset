

# Generated at 2022-06-12 16:12:31.367486
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("0") == ScalarToken(0, 0, 0, content="0")
    assert tokenize_yaml("0.1") == ScalarToken(0.1, 0, 2, content="0.1")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("{1: 2}") == DictToken({1: 2}, 0, 4, content="{1: 2}")

# Generated at 2022-06-12 16:12:40.926397
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml("key: value"), DictToken)
    assert isinstance(tokenize_yaml("[1]"), ListToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)

    assert isinstance(tokenize_yaml("True"), ScalarToken)
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert isinstance(tokenize_yaml("False"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml("Null"), ScalarToken)
    assert isinstance(tokenize_yaml("NULL"), ScalarToken)


# Generated at 2022-06-12 16:12:46.408313
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # Empty string case
    with pytest.raises(ParseError):
        tokenize_yaml("")

    # Empty string with whitespace case
    with pytest.raises(ParseError):
        tokenize_yaml("   \n   \t  ")

    # Invalid string case
    with pytest.raises(ParseError):
        tokenize_yaml("key: value:")

    # String value case
    token = tokenize_yaml("key: value")
    assert isinstance(token, DictToken)
    assert isinstance(token.value["key"], ScalarToken)
    assert token.value["key"].value == "value"

    # Bytestring value case
    token = tokenize_yaml(b"key: value")
    assert isinstance(token, DictToken)
   

# Generated at 2022-06-12 16:12:48.974596
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "hello world"
    validator = Schema({"name": str})
    validate_yaml(content, validator)

# Generated at 2022-06-12 16:12:59.187804
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test for Empty String
    try:
        token = tokenize_yaml('')
    except ParseError as e:
        assert(e.code == 'no_content')

    # Test for Malformed YAML
    try:
        token = tokenize_yaml('{foo: bar')
    except ParseError as e:
        assert(e.code == 'parse_error')

    # Test for valid YAML.
    expected = DictToken({'foo': 'bar'}, 0, 10, content='{"foo": "bar"}')
    actual = tokenize_yaml('{"foo": "bar"}')
    assert(actual == expected)


# Generated at 2022-06-12 16:13:02.225586
# Unit test for function validate_yaml
def test_validate_yaml():
    class SimpleSchema(Schema):
        name = Field(name_="name", required=False, default="cool")
        age = Field(name_="age", required=False, default="43")


    # Test that it succeeds
    value, error = validate_yaml("name: cool\nage: 20", SimpleSchema)
    assert value == {"name": "cool", "age": "20"}
    assert not error

    # Test that it fails
    value, error = validate_yaml("name: cool\nage: forty-three", SimpleSchema)
    assert value == {}
    assert error
    assert error[0]
    assert error[0].position.char_index == 15

# Generated at 2022-06-12 16:13:07.843155
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(title="Person", fields={"name": str, "age": int})
    value, error_messages = validate_yaml(content="name: foo\nage: bar", validator=schema)
    assert error_messages == [
        ValidationError(
            text="Field value must be an integer.",
            code="type_error.integer",
            pointer="/age",
            position=Position(line_no=2, column_no=7, char_index=11),
        )
    ]

# Generated at 2022-06-12 16:13:12.005901
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "dt: 2019-09-04"
    # get the token for the YAML
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    # check the start and end values for the token
    assert token.start == 0
    assert token.end == 16


# Generated at 2022-06-12 16:13:21.773703
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("[1, 2, 3]") == ListToken([1, 2, 3], 0, 7)

    assert tokenize_yaml("[1, 2, 3]\n") == ListToken([1, 2, 3], 0, 8)

    assert tokenize_yaml("{a: 1, b: 2}") == DictToken({"a": 1, "b": 2}, 0, 13)

    assert tokenize_yaml("{a: 1, b: 2}\n") == DictToken({"a": 1, "b": 2}, 0, 15)

    assert tokenize_yaml("{a: 1, b: 'string'}") == DictToken(
        {"a": 1, "b": "string"}, 0, 19
    )


# Generated at 2022-06-12 16:13:26.057674
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Simple scalar validation test.
    content = "123"
    token = tokenize_yaml(content)
    assert token == ScalarToken("123", 0, 2, content=content)

    # Simple scalar validation test.
    content = "213a"
    token = tokenize_yaml(content)
    assert token == ScalarToken("213a", 0, 3, content=content)

    # List validation test.
    content = "- 123\n- 213a\n- 554\n"
    token = tokenize_yaml(content)

# Generated at 2022-06-12 16:13:37.402625
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import Any, String
    from typesystem.fields import Integer, Float
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import Position
    from typesystem.tokenize.tokens import ScalarToken

    class BasicSchema(Schema):
        name = String(max_length=3)
        age = Integer(max_value=100)

    class NestedSchema(Schema):
        name = String(max_length=3)
        basic = BasicSchema

    class BasicListSchema(Schema):
        name = String(max_length=3)
        age = Integer(max_value=100)
        friends = [BasicSchema]

    class NestedListSchema(Schema):
        name = String(max_length=3)
       

# Generated at 2022-06-12 16:13:49.052181
# Unit test for function tokenize_yaml

# Generated at 2022-06-12 16:13:59.721797
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    # Define a Schema (similar to a Django model)
    class UserSchema(Schema):
        name = String()
        age = Integer()

    # Parse and validate a YAML string
    content = """
    - name: Frank
      age: "34"
    - name: Jane
      age: "17"
    """
    errors = validate_yaml(content, validator=UserSchema)
    print(errors)
    # {
    #    # The error messages are positionally marked
    #    'messages': [
    #        {
    #            'code': 'invalid_type',
    #            'message': "Value 'Frank' is not of type 'string'.",
    #            'position':

# Generated at 2022-06-12 16:14:04.981519
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    print("-------Test: tokenize_yaml------")
    token = tokenize_yaml('name: 123\nnumber: 3.14')
    assert token.data == {'name': '123', 'number': 3.14}
    assert token.start == 0
    assert token.end == len('name: 123\nnumber: 3.14')


# Generated at 2022-06-12 16:14:05.575473
# Unit test for function validate_yaml
def test_validate_yaml():
    pass

# Generated at 2022-06-12 16:14:10.682559
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml()
    """
    class Person(Schema):
        name = String()
        age = Integer()

    yaml_str = """
        name: "Peter"
        age: 25
    """
    parsed_yaml, error_messages = validate_yaml(yaml_str, validator=Person)

    assert error_messages == []
    assert parsed_yaml['name'] == 'Peter'
    assert parsed_yaml['age'] == 25

# Generated at 2022-06-12 16:14:15.306356
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"name": {"type": "string", "min_length": 10}})
    content = "name: Neil Armstrong"
    assert not validate_yaml(content=content, validator=schema)[1]
    assert validate_yaml(content=content, validator=schema)[0]["name"] == "Neil Armstrong"

# Generated at 2022-06-12 16:14:26.276280
# Unit test for function validate_yaml
def test_validate_yaml():
    import pytest
    import typesystem
    assert yaml is not None, "'pyyaml' must be installed."

    class UserSchema(typesystem.Schema):
        id = typesystem.Integer()
        display_name = typesystem.String()

    yaml_str = """
    id: 1
    display_name: mvanoes
    """

    actual_value, actual_errors = validate_yaml(yaml_str, validator=UserSchema)
    assert actual_value == {"id": 1, "display_name": "mvanoes"}
    assert not actual_errors

    yaml_str = "12345"

    with pytest.raises(ValidationError) as exc_info:
        actual_value, actual_errors = validate_yaml(yaml_str, validator=UserSchema)

   

# Generated at 2022-06-12 16:14:33.922044
# Unit test for function validate_yaml

# Generated at 2022-06-12 16:14:36.568802
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    first_name: John
    last_name: Smith
    age: 20
    '''
    value, error_messages = validate_yaml(content, PersonSchema)
    print("value, error_messages", value, error_messages)
    # Output:
    # value, error_messages {'first_name': 'John', 'last_name': 'Smith', 'age': 20} []


# Generated at 2022-06-12 16:14:41.991285
# Unit test for function validate_yaml
def test_validate_yaml():
    # Valid input
    content = b"name: bob"
    schema = Schema({"name": str})
    value, error_messages = validate_yaml(content, schema)
    print (value, error_messages)

    # Invalid input
    content = b"name: 1"
    schema = Schema({"name": str})
    value, error_messages = validate_yaml(content, schema)
    print (value, error_messages)

# Generated at 2022-06-12 16:14:46.313244
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        id = fields.Integer(allow_null=True)
        name = fields.String(required=True)
        email = fields.String()

    content = """
    id: 1
    email: test@example.com
    """

    value, errors = validate_yaml(content=content, validator=UserSchema)
    print(value)
    print(errors)

# Generated at 2022-06-12 16:14:57.280841
# Unit test for function validate_yaml
def test_validate_yaml():

    # Parse and validate a YAML string, returning positionally marked error
    # messages on parse or validation failures.

    #content - A YAML string or bytestring.
    #validator - A Field instance or Schema class to validate against.

    #Returns a two-tuple of (value, error_messages)

    str_content = "3"
    expected_result=3
    assert validate_yaml(str_content,'') == expected_result

    str_content = "this is right"
    expected_result="this is right"
    assert validate_yaml(str_content,'') == expected_result

    str_content = "This is right"
    expected_result="This is right"
    assert validate_yaml(str_content, '') == expected_result

    str_content = "this is wrong"


# Generated at 2022-06-12 16:15:08.608988
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.base import Message, ValidationError

    class Person(Schema):
        name = String()

    name = 'John'
    content = "name: {}\n".format(name)
    value, errors = validate_yaml(content, Person)
    assert value['name'] == name
    assert isinstance(errors, list)
    assert len(errors) == 0

    invalid_name = 'J0hn'
    content = "name: {}\n".format(invalid_name)
    value, errors = validate_yaml(content, Person)
    assert isinstance(errors, list)
    assert len(errors) == 1
    assert errors[0].code == 'invalid'

# Generated at 2022-06-12 16:15:11.363627
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """---
name: Test TypeSystem
description: Test TypeSystem
fields:
  - name: num
    type: integer
    min_value: 5
    ..."""
    validate_yaml(content, Schema)


# Generated at 2022-06-12 16:15:23.601888
# Unit test for function validate_yaml
def test_validate_yaml():
    # Given a Schema class representing a person
    class Person(Schema):
        name = String(format="name")
        age = Integer(minimum=18, maximum=99)

    # And some YAML content representing a person
    content = 'name: "John Doe"\nage: 13'

    # If the content is validated against the Schema
    value, error_messages = validate_yaml(content, validator=Person)

    # Then the validation fails, with a single error message indicating the
    # content value for `age` is invalid
    assert not value
    assert isinstance(error_messages, list)
    assert len(error_messages) == 1
    assert isinstance(error_messages[0], ValidationError)
    assert error_messages[0].code == "minimum"
    assert error_messages

# Generated at 2022-06-12 16:15:34.381898
# Unit test for function validate_yaml
def test_validate_yaml():

    def _get_messages(content: str) -> typing.List[Message]:
        return validate_yaml(content=content, validator=Schema)[1]

    class SimpleSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class ListSchema(Schema):
        people = Field(type="list", items=Field(type="string"))

    def test_empty_string():
        errors = _get_messages("")
        assert errors[0].code == "no_content"

    def test_empty_dict():
        errors = _get_messages("{}")
        assert len(errors) == 1
        error = errors[0]
        assert error.code == "required"

    def test_valid_schema():
        errors = _get_messages

# Generated at 2022-06-12 16:15:41.117629
# Unit test for function validate_yaml
def test_validate_yaml():
    content = yaml.dump({"name":"John", "age":30})
    schema = {
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"},
        },
        "required": ["name", "age"],
    }
    value, messages = validate_yaml(content, schema)
    assert value == {"name":"John", "age":30}
    assert messages == []

# Generated at 2022-06-12 16:15:52.354911
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """{
        "key1": "value1",
        "key2": "value2",
    }"""
    token = tokenize_yaml(content)
    print(token)
    assert isinstance(token, DictToken)

    schema = Schema(
        {
            "key1": "string",
            "key2": "string",
        }
    )
    class_validator = schema.fields["key1"]
    instance_validator = schema.fields["key2"]

    value, error_messages = validate_with_positions(token=token, validator=class_validator)
    print(value, error_messages)
    assert value == {'key1': "value1", "key2": "value2"}
    assert error_messages == []

    value, error_messages

# Generated at 2022-06-12 16:16:00.119908
# Unit test for function validate_yaml
def test_validate_yaml():
    def func(a,b):
        return a+b
    
    schema1 = Schema("schema1", {"a": IntType(), "b": StringType()})
    schema2 = Schema("schema2", {"func": UserDefinedType(function=func)})
    
    # Test with schema1
    try:
        value, error_messages = validate_yaml("a:1\nb:2", schema=schema1)
    except Exception as e:
        print(e)
    
    # Test with schema2
    try:
        value, error_messages = validate_yaml("func:1+2", schema=schema2)
        print(value)
    except Exception as e:
        print(e)
        


# Generated at 2022-06-12 16:16:12.646257
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Number, Boolean, Array, Date

    class PersonSchema(Schema):
        name = String()
        age = Integer()
        likes_pizza = Boolean()
        favorite_pizzas = Array(items=String())
        birthday = Date()
        height = Number()

    content = """
        name: John
        age: 20
        likes_pizza: yes
        favorite_pizzas:
            - Hawaiian
            - Cheese
        birthday: 1986-04-28
        height: 5'11"
    """
    token = tokenize_yaml(content)
    value, errors = validate_with_positions(token=token, validator=PersonSchema)
    assert type(value) is dict

# Generated at 2022-06-12 16:16:24.411949
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Unit test for function validate_yaml
    """
    from typesystem.fields import Dict

    class FooSchema(Schema):
        expected_keys = Dict({"foo": str, "bar": int})

    class BarSchema(Schema):
        expected_keys = Dict({"boo": int, "far": str})

    # Bad parse
    try:
        validate_yaml("[1, 2, 3]", validator=FooSchema)
    except ParseError as exc:  # type: ignore
        assert exc.position.line_no == 1

    # Bad validation
    value, error_messages = validate_yaml("{'foo': 2, 'bar': 'baz'}", validator=FooSchema)
    assert len(error_messages) == 1

# Generated at 2022-06-12 16:16:34.422970
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    source = "a: b"
    result = tokenize_yaml(source)
    assert isinstance(result, DictToken)
    assert result.value == {"a": "b"}
    assert result.start_index == 0
    assert result.end_index == 3


source = "a: b"
result = tokenize_yaml(source)
assert isinstance(result, DictToken)
assert result.value == {"a": "b"}
assert result.start_index == 0
assert result.end_index == 3

source = "a:\n  - 1"
result = tokenize_yaml(source)
assert isinstance(result, DictToken)
assert result.value == {"a": [1]}
assert result.start_index == 0
assert result.end_index == 6


# Generated at 2022-06-12 16:16:45.355122
# Unit test for function validate_yaml
def test_validate_yaml():

    # Parse a valid YAML document
    valid_content = """
      books:
        -
          title: The Shining
          author: Stephen King
        -
          title: IT
          author: Stephen King
        -
          title: The Green Mile
          author: Stephen King
        -
          title: The Dark Tower
          author: Stephen King
    """
    expected_parsed_value = {
        "books": [
            {"title": "The Shining", "author": "Stephen King"},
            {"title": "IT", "author": "Stephen King"},
            {"title": "The Green Mile", "author": "Stephen King"},
            {"title": "The Dark Tower", "author": "Stephen King"},
        ]
    }
    expected_errors = []


# Generated at 2022-06-12 16:16:57.672727
# Unit test for function validate_yaml
def test_validate_yaml():
    # First, test with a Field.
    content = "fahrenheit: 212\n"
    field = Field(name="fahrenheit")
    field.validators += [field.validators[0]]
    value, error_messages = validate_yaml(content, field)
    assert value == 212
    assert not error_messages

    # Next, test with a Schema.
    content = (
        "name: Alan\n"
        "age: 34\n"
        "address: |+\n"
        "  Here comes the\n"
        "  address.\n"
        "friends:\n"
        "  - name: Bob\n"
        "    age: 27\n"
        "  - name: Sally\n"
        "    age: 25\n"
    )


# Generated at 2022-06-12 16:17:04.900404
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.validators import Integer, String

    class UserSchema(Schema):
        """A simple example schema."""

        name = String(max_length=100)
        age = Integer(minimum=18, maximum=100)

    content = """
    name: 'foo'
    age: 21
    """
    value, error_messages = validate_yaml(content, validator=UserSchema)
    assert error_messages == []
    assert value == {
        "name": "foo",
        "age": 21
    }

# Generated at 2022-06-12 16:17:08.101149
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    hello: world
    '''
    schema = Schema({"hello": fields.String()})
    value, errors = validate_yaml(content, schema)
    assert errors == [
        ValidationError(text="Missing required field.", code="required", position=None)
    ]



# Generated at 2022-06-12 16:17:15.511098
# Unit test for function validate_yaml
def test_validate_yaml():
    bytestr = b"{key: 1}"
    token = tokenize_yaml(bytestr)
    assert type(token) == DictToken
    class YAMLSchema(Schema):
        name = "YAMLSchema"
        key = Field(str)
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=YAMLSchema)
    bytestr = b"{key: value}"
    token = tokenize_yaml(bytestr)
    assert type(token) == DictToken
    assert validate_with_positions(token=token, validator=YAMLSchema) == ({'key': 'value'}, [])

# Generated at 2022-06-12 16:17:21.862787
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {"a": int, "b": str},
        required=["a"],
        error_messages={"required": "This field is required."}
    )

    errors = validate_yaml(b'{"b":"foo"}', schema)[1]
    assert errors[0].text == "This field is required."
    assert errors[0].position.char_index == 1
    assert errors[0].position.column_no == 1
    assert errors[0].position.line_no == 1

# Generated at 2022-06-12 16:17:25.678372
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "12\n34\n"
    validator = Field(type="integer")
    value, err_messages = validate_yaml(content, validator)

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 16:17:32.513109
# Unit test for function validate_yaml
def test_validate_yaml():
    text = """
    - 10.0
    """
    schema = Schema(fields=[Field("items", items=Field(type="float"))])
    value, errors = validate_yaml(text, schema)
    assert value == [-10.0]



# Generated at 2022-06-12 16:17:35.615095
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    >>> validate_yaml("not yaml", str)
    Traceback (most recent call last):
     ...
    typesystem.tokenize.parse_error.ParseError: Unexpected characters, expected a valid YAML document at line 1 column 1.
    """
    pass



# Generated at 2022-06-12 16:17:46.679363
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    first_name: Bob
    last_name:
      first: Jon
      last: G
    age: 35
    weight: 123.45
    """

    class Person(Schema):
        first_name = Field(type="string")
        last_name = Field(type="string")
        age = Field(type="integer")
        weight = Field(type="number")


    value, error_messages = validate_yaml(content=content, validator=Person)
    assert value == {
        "first_name": "Bob",
        "last_name": "Jon G",
        "age": 35,
        "weight": 123.45,
    }
    assert error_messages == []



# Generated at 2022-06-12 16:17:52.530685
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, parse
    from typesystem_yaml import validate_yaml

    schema = parse(
        """
        type: object
        properties:
            name:
                type: string
            age:
                type: integer
        """,
        format="yaml",
    )

    yaml_content = """
    name: John
    age: 42
    """

    (value, errors) = validate_yaml(yaml_content, schema)
    assert value == {"name": "John", "age": 42}
    assert errors == Message()



# Generated at 2022-06-12 16:18:01.889787
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test scalar
    assert tokenize_yaml("abc") == ScalarToken(value="abc", start=0, end=2, content="abc")

    # test list
    list_ = ListToken(
        [ScalarToken(value=1, start=1, end=1, content="- 1"), ScalarToken(value=2, start=4, end=4, content="- 2")],
        start=0,
        end=6,
        content="- 1\n- 2",
    )
    assert tokenize_yaml("- 1\n- 2") == list_
    assert tokenize_yaml(b"- 1\n- 2") == list_

    # test dict

# Generated at 2022-06-12 16:18:04.953703
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""
    id: 1
    name: John Doe
    """
    validator = typing.Dict[str, typing.Union[str, int]]
    value, error_messages = validate_yaml(content, validator)
    assert value == {"id": 1, "name": "John Doe"}
    assert error_messages == []



# Generated at 2022-06-12 16:18:15.850566
# Unit test for function validate_yaml
def test_validate_yaml():
    class ArtistSchema(Schema):
        name = String(max_length=10)
        age = Integer(gt=21)
        activeYears = Tuple(String(max_length=10), String(max_length=10))

    content = b"""\
name: Michael Jackson
age: 5
activeYears: [1958,2009]
    """

    value, errors = validate_yaml(content=content, validator=ArtistSchema)


# Generated at 2022-06-12 16:18:23.031484
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()

    content = """
    name: Alice
    """
    Person.validate(content)

    content = """
    name: <p></p>
    """
    with pytest.raises(Message) as exc_info:
        Person.validate(content)
    assert ("Encountered an invalid character." in exc_info.value.text)

# Generated at 2022-06-12 16:18:33.682923
# Unit test for function validate_yaml
def test_validate_yaml():
    expected_value = {
        "duration_seconds":      1,
        "optional_nested_dict":  {"foo": "bar"},
        "optional_nested_list":  [1, 2, 3],
    }
    expected_messages = []

    from typesystem.schema import Schema
    from typesystem.number import Number

    class DummySchema(Schema):
        duration_seconds = Number(minimum=0, maximum=60)
        optional_nested_dict = {"required": {"foo": "bar"}}
        optional_nested_list = [None, None, None]

    yaml_content = """
    duration_seconds: 1
    optional_nested_dict:
      foo: bar
    optional_nested_list:
      - 1
      - 2
      - 3
    """

   

# Generated at 2022-06-12 16:18:44.282711
# Unit test for function validate_yaml
def test_validate_yaml():
    # case 1:
    c1_content = 'name: "John"'
    c1_validator = field_types.String(required=False)
    c1_output = ('John', [])
    assert validate_yaml(c1_content, c1_validator) == c1_output

    # case 2:
    c2_content = "name: 'John'"
    c2_validator = field_types.String(required=False)
    c2_errormsg = "Expected string value."
    c2_output = (None, [ValidationError(text=c2_errormsg, code='invalid', position=Position(char_index=13, line_no=1, column_no=14))])
    assert validate_yaml(c2_content, c2_validator) == c2_

# Generated at 2022-06-12 16:18:57.455315
# Unit test for function validate_yaml
def test_validate_yaml():
    class AddressSchema(Schema):
        street_address = fields.String(required=True)
        city = fields.String(required=True)
        state = fields.String(required=True)
        zip = fields.Integer(required=True)

    class PersonSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True)
        address = fields.Nested(AddressSchema)


    data = '''
    name: John
    age: 30
    address:
      street_address: 123 Main St.
      city: Anytown
      state: NY
      zip: 12345
    '''
    value, errors = validate_yaml(data, validator=PersonSchema)


# Generated at 2022-06-12 16:19:09.301518
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    lname: Doe
    fname: John
    '''
    class Person(Schema):
        lname = Field(type="string")
        fname = Field(type="string")

    value, errors = validate_yaml(content, Person)
    assert value == {'lname': 'Doe', 'fname': 'John'}
    assert errors == []

    content = '''
    lname: Doe
    not_fname: should fail
    '''

    value, errors = validate_yaml(content, Person)
    assert value == {'lname': 'Doe'}

    assert len(errors) == 1
    first_error = errors[0]
    assert isinstance(first_error, Message)
    assert first_error.code == "invalid_field"
    assert first

# Generated at 2022-06-12 16:19:13.882693
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
- name: Test 1
  id: 1
  test: true
- name: Test 2
  id: 2
  test: false
    """
    tokens = tokenize_yaml(content)
    assert len(tokens) == 2


# Generated at 2022-06-12 16:19:22.828972
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('attendance:', Field(type="string"))[0] == 'attendance:'
    assert validate_yaml('attendance: 1', Field(type="string"))[0] == 'attendance: 1'
    try:
        assert validate_yaml('{attendance: 1}', Field(type="string"))[0] == 'attendance: 1'
    except ParseError:
        pass
    assert validate_yaml('{"attendance": 1}', Field(type="string"))[0] == '{attendance: 1}'
    assert validate_yaml({'attendance': 1}, Field(type="string"))[0] == "{\'attendance\': 1}"

# Generated at 2022-06-12 16:19:27.169254
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: 'Tomas Ledand'"
    field = Field(name="name", type="string")

    assert validate_yaml(content, field) == (
        "Tomas Ledand",
        [],
    )

# Generated at 2022-06-12 16:19:39.057762
# Unit test for function validate_yaml
def test_validate_yaml():
    from io import StringIO
    from typesystem.schema import validate

    schema = StringIO("""
typing:
  id: integer
  name: string
  age: integer
  dead: boolean
  dob: string
  optional: string

""")

    with open(schema.name) as fd:
        schema = Schema.from_file(fd)
    assert schema.typing.types == {'id': 'integer', 'name': 'string', 'age': 'integer', 'dead': 'boolean', 'dob': 'string', 'optional': 'string'}
    document = StringIO("""---
id: 1
name: 'John Doe'
age: 34
dead: false
dob: '1970-01-01'
""")

# Generated at 2022-06-12 16:19:40.308935
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("- 10", "int") == 10


# Generated at 2022-06-12 16:19:52.769161
# Unit test for function validate_yaml
def test_validate_yaml():
    class MovieSchema(Schema):
        title = StringField(required=True)
        year = IntegerField(required=True)
        minutes = IntegerField(required=True)
        imdb_rating = FloatField(required=True)
        ratings = ListField(StringField, required=True)
        best_scene = ObjectField("SceneSchema")

    class SceneSchema(Schema):
        title = StringField(required=True)
        seconds = IntegerField(required=True)

    movie_content = """
---
title: Citizen Kane
year: 1941
minutes: 119
imdb_rating: 8.4
ratings:
    - Ebert
    - IMDB Top 250
best_scene:
    title: Breakfast montage
    seconds: 514
"""

# Generated at 2022-06-12 16:20:03.202141
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import parse_yaml
    from typesystem.typing import Boolean, Integer, Number, String
    from typesystem.fields import Field

    assert parse_yaml("test: value") == {"test": "value"}

    with pytest.raises(ParseError) as exc:
        parse_yaml("test: 'value'")
    assert exc.value.code == "parse_error"
    assert exc.value.position.line_no == 1
    assert exc.value.position.column_no == 9
    assert exc.value.position.char_index == 8

    class Person(Schema):
        name = Field(String())
        age = Field(Integer())
        height = Field(Number())


# Generated at 2022-06-12 16:20:08.712856
# Unit test for function validate_yaml
def test_validate_yaml():
    # Does not fail when valid
    assert validate_yaml("1", "integer") == (1, None)
    assert validate_yaml("test", "string") == ("test", None)
    assert validate_yaml("true", "boolean") == (True, None)

    # Fails with appropriate messages
    assert validate_yaml("not an integer", "integer") == (None, [{"code": "invalid_type", "text": "Invalid type. Expected 'integer', received 'string'.", "position": "1:1:1", "line": 1, "column": 1, "character": 0}])

# Generated at 2022-06-12 16:20:18.090491
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: Bruce Wayne"
    schema_class = typesystem.Schema.from_string(
        '''
        type: object
        properties:
          name:
            type: string
        additional_properties: false
        ''',
        base_class=typesystem.Schema,
    )
    result = validate_yaml(content=content, validator=schema_class)
    assert result.value == {"name": "Bruce Wayne"}
    assert result.errors == []



# Generated at 2022-06-12 16:20:27.407102
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"title": "string", "age": "integer"})
    assert "integer" == type(schema.fields["age"]).__name__
    assert "title" in schema.fields.keys()  # type: ignore
    assert None == schema.fields["title"].default
    assert None == schema.fields["title"].description
    assert "string" == type(schema.fields["title"]).__name__
    assert None == schema.fields["title"].title

    schema = Schema({"title": "string", "age": "integer"})
    assert "integer" == type(schema.fields["age"]).__name__
    assert "title" in schema.fields.keys()  # type: ignore
    assert None == schema.fields["title"].default

# Generated at 2022-06-12 16:20:37.429134
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = (
        "foo:\n"
        "  bar:\n"
        "    baz: 'boo'\n"
        "  bar: [1, 2, 3]"
    )
    token = tokenize_yaml(content)

    assert token.get("foo").get("bar").get("baz") == "boo"
    assert token["foo"]["bar"][1] == [1, 2, 3]

    with pytest.raises(ParseError) as exc:
        tokenize_yaml("")

    assert exc.value.text == "No content."
    assert exc.value.position == Position(line_no=1, column_no=1, char_index=0)



# Generated at 2022-06-12 16:20:47.541870
# Unit test for function validate_yaml
def test_validate_yaml():
    # Validation Success
    schema = Schema(fields={"name": Field(required=True, type="string")})
    yaml_string = """name: "John Smith" """
    value, error_messages = validate_yaml(yaml_string, validator=schema)
    assert not error_messages
    assert value["name"] == "John Smith"

    # Validation Failure
    schema = Schema(fields={"name": Field(required=True, type="string")})
    yaml_string = """name: 75 """
    value, error_messages = validate_yaml(yaml_string, validator=schema)
    assert error_messages
    print(error_messages[0])

# Generated at 2022-06-12 16:20:51.803993
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    ---
    name: Bob
    age: false
    """
    try:
        validate_yaml(content, validator=Schema(fields={
            "name": String(max_length=5),
            "age": Integer()
        }))
    except ValidationError as err:
        assert(err.messages[0].position.line_no == 4 and err.messages[0].position.column_no == 5)
    else:
        assert(False)



# Generated at 2022-06-12 16:21:01.213981
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    first:
        a: 1
        b: 2
    second:
        a: 1
        c: 3
    '''
    class TestYamlSchema(Schema):
        fields = {
            "first": {"type": "dict", "properties": {"a": {"type": "integer"}}},
            "second": {"type": "dict", "properties": {"a": {"type": "integer"}}},
        }
    schema = TestYamlSchema()
    value, error = validate_yaml(content, schema)
    assert value == {"first": {"a": 1}, "second": {"a": 1}}

# Generated at 2022-06-12 16:21:13.348463
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None

    class PetSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer", minimum=0, maximum=20)
        breed = Field(type="string")
        vaccinated = Field(type="boolean")
    
    content = """name: Spot\nage: 26\nbreed: dalmatian\nvaccinated: true"""
    value, messages = validate_yaml(content, PetSchema)
    assert messages == [
        Message(
            code="maximum",
            text="Must be less than or equal to 20.",
            position=Position(
                char_index=19,
                column_no=3,
                line_no=2
            )
        )
    ]
    # Serialized form is canonical.

# Generated at 2022-06-12 16:21:15.277093
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."


# Generated at 2022-06-12 16:21:18.068145
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
            test:
            - test
            """.encode("utf-8")
    validator = Field(type="array")
    value, errors = validate_yaml(content, validator)
    assert isinstance(value, list)


# Generated at 2022-06-12 16:21:23.196455
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"id: test_id"
    validator = validator = typesystem.Schema.from_fields(
        {"id": typesystem.types.Text(pattern=r"^test_.*$")}
    )

    value, error_messages = validate_yaml(content, validator)

    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == ("The text does not match the expected pattern.")

# Generated at 2022-06-12 16:21:35.792889
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    data = """
    a: 1
    b:
      - 2
      - 3
    c:
      d: 4
    """
    test_data = "a: 1"
    output = tokenize_yaml(test_data)
    assert isinstance(output, DictToken)
    # assert len(output) == 1
    assert output.get_item(0) == ScalarToken(1, 0, 2, content="a: 1")
    # assert output[0] == ScalarToken(1, 0, 2, content="a: 1")

    test_data = "- 1"
    output = tokenize_yaml(test_data)
    assert isinstance(output, ListToken)
    assert len(output) == 1
    assert output[0] == ScalarToken(1, 0, 3, content="- 1")

# Generated at 2022-06-12 16:21:46.397505
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken
    from .test_validation import error_messages  # noqa

    # Test a simple case.
    integer = Integer()
    input_content = "5"
    value, error_messages = validate_yaml(input_content, integer)
    assert value == 5
    assert len(error_messages) == 0

    # Test a case that results in a validation error.
    value, error_messages = validate_yaml("foo", integer)
    assert value == "foo"
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be a valid integer."

# Generated at 2022-06-12 16:21:51.913067
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "this is not valid YAML"

    class MySchema(Schema):
        foo = Field(str)

    value, errors = validate_yaml(content, validator=MySchema)

    assert errors == ParseError(
        code="parse_error", position=Position(column_no=4, line_no=1, char_index=4), text="could not find expected ':'",
    )

# Generated at 2022-06-12 16:22:02.383556
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String

    class BookSchema(Schema):
        title = String()
        author = String()
        year = Integer()

    schema = BookSchema()

    content = """
        title: L'Étranger
        author: Albert Camus
        year: 1942
    """

    value, messages = validate_yaml(content, schema)

    assert value == {
        "title": "L'Étranger",
        "author": "Albert Camus",
        "year": 1942,
    }

    assert not messages

    invalid_content = """
        title: L'Étranger
        author: Albert Camus
        year: 1942
        pages: 158
    """

    _, messages = validate_yaml(invalid_content, schema)

    [error] = messages


# Generated at 2022-06-12 16:22:04.279796
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(
        '''
      author:
        name: Edsger W. Dijkstra
        born: 1927
    '''
    )
    print(token)

test_tokenize_yaml()