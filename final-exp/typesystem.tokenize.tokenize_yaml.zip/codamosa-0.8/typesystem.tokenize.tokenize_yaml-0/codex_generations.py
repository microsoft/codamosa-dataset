

# Generated at 2022-06-12 16:12:22.252055
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test tokenize with a simple dictionary
    content = "test:\n    name: John\n    age: 25\n"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == 33
    assert token.key == "test"
    assert token.value == {'name': 'John', 'age': 25}

    # Test tokenize with a sample yaml document

# Generated at 2022-06-12 16:12:33.075100
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("a: foo") == DictToken({"a": "foo"}, 0, len("a: foo") - 1)
    assert tokenize_yaml("a: foo\n") == DictToken({"a": "foo\n"}, 0, len("a: foo\n") - 1)
    assert tokenize_yaml("a: bar") == DictToken({"a": "bar"}, 0, len("a: bar") - 1)
    assert tokenize_yaml("a: [1, 2]") == DictToken({"a": [1, 2]}, 0, len("a: [1, 2]") - 1)

# Generated at 2022-06-12 16:12:42.023002
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        from typesystem.fields import Integer, String
        from typesystem.schemas import Schema
    except ImportError:  # pragma: no cover
        return


    class UserSchema(Schema):
        first_name = String(max_length=100)
        last_name = String(max_length=100)
        age = Integer(min_value=18)


    value, errors = validate_yaml(
        """
first_name: "John"
last_name: "Doe"
age: 23
""",
        UserSchema,
    )
    assert value == {"first_name": "John", "last_name": "Doe", "age": 23}
    assert errors == []



# Generated at 2022-06-12 16:12:44.822065
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('name: Tokyo')
    assert token == {'name': 'Tokyo'}
    assert isinstance(token, typing.Dict)
    assert isinstance(token, Token)



# Generated at 2022-06-12 16:12:49.069551
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from hypothesis import given
    from hypothesis.strategies import binary
    from hypothesis.strategies import dictionaries
    from hypothesis.strategies import floats
    from hypothesis.strategies import integers
    from hypothesis.strategies import lists
    from hypothesis.strategies import text
    from hypothesis.strategies import builds
    from hypothesis.strategies import none

    # Bytestring should raise a TypeError
    with pytest.raises(TypeError, match="Text input expected"):
        bytes("text", encoding="ascii")

    # Empty string, should raise a ParseError
    with pytest.raises(ParseError, match="No content."):
        tokenize_yaml(str(""))


# Generated at 2022-06-12 16:12:58.947709
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "a: b\nc: d"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.value["a"], ScalarToken)
    assert isinstance(token.value["c"], ScalarToken)

    assert token.value["a"].value == "b"
    assert token.value["c"].value == "d"

    assert token.value["a"].start == 2
    assert token.value["a"].stop == 3
    assert token.value["c"].start == 6
    assert token.value["c"].stop == 7



# Generated at 2022-06-12 16:13:07.704937
# Unit test for function validate_yaml
def test_validate_yaml():
    # this function defines a local function that should be covered
    # by the unit tests
    content = """
        - name: test
          label: Test
          type: string
        """
    validator = Schema.from_fields([
        Field(name="name", type="string", required=True, primary_key=True),
        Field(name="label", type="string", required=True),
        Field(name="type", type="string", required=True),
        ])
    (value, errors) = validate_yaml(content, validator)
    assert value == [{'name': 'test', 'label': 'Test', 'type': 'string'}]
    assert not errors


# Generated at 2022-06-12 16:13:17.452340
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # tokenize_yaml is the first module, so the importing of yaml is implicitly tested
    assert tokenize_yaml("{}") == DictToken(mapping={}, start=0, end=1, content="{}")
    assert tokenize_yaml("[]") == ListToken(value=[], start=0, end=1, content="[]")
    assert tokenize_yaml("test") == ScalarToken(value="test", start=0, end=3, content="test")
    assert tokenize_yaml("3") == ScalarToken(value=3, start=0, end=1, content="3")
    assert tokenize_yaml("3.1415") == ScalarToken(value=3.1415, start=0, end=5, content="3.1415")

# Generated at 2022-06-12 16:13:25.851333
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("null") == ScalarToken(
        None, 0, 3, content="null",
    )

    assert tokenize_yaml("true") == ScalarToken(
        True, 0, 3, content="true",
    )

    assert tokenize_yaml("false") == ScalarToken(
        False, 0, 4, content="false",
    )

    assert tokenize_yaml("3") == ScalarToken(
        3, 0, 1, content="3",
    )

    assert tokenize_yaml("3.14") == ScalarToken(
        3.14, 0, 4, content="3.14",
    )

    assert tokenize_yaml("\"foobar\"") == ScalarToken(
        "foobar", 0, 7, content="\"foobar\"",
    )

# Generated at 2022-06-12 16:13:35.194475
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        foo: bar
        arr:
          - apple
          - orange
    """)
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar", "arr": ["apple", "orange"]}
    assert token.start_index == 2
    assert token.end_index == 47
    assert token.content
    assert len(token.content) == 48

    assert isinstance(token["foo"], ScalarToken)
    assert token["foo"].value == "bar"
    assert token["foo"].start_index == 7
    assert token["foo"].end_index == 10
    assert len(token["foo"].content) == 48
    with pytest.raises(KeyError):
        token["foo"] = 5


# Generated at 2022-06-12 16:13:45.578737
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # The function is a simple wrapper around pyyaml, so not testing all
    # possible cases.
    from typesystem.tokenize.tests.test_tokenize import test_tokenize

    # Test with a YAML string.
    test_tokenize(tokenize_yaml, str_content='{"a":5}')
    test_tokenize(tokenize_yaml, str_content='[1,2,3]')



# Generated at 2022-06-12 16:13:48.997952
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "title: Hey"
    validator = Schema("title", Field("title", str))
    (value, error_messages) = validate_yaml(content, validator)
    assert value == {"title": "Hey"}
    assert error_messages == []



# Generated at 2022-06-12 16:13:58.173190
# Unit test for function validate_yaml
def test_validate_yaml():

    yaml_str = """
    title: Testing
    """
    schema_obj = dict(title=str)
    exp_err_msgs = [
        Message(
            text="Required field is missing.",
            code="missing_field",
            position=Position(
                char_index=11,
                column_no=0,
                line_no=4,
            ),
        ),
    ]
    exp_err_msgs[5].position.line_no
    val, err_msgs = validate_yaml(yaml_str, schema_obj)
    assert exp_err_msgs == err_msgs



# Generated at 2022-06-12 16:14:08.436327
# Unit test for function validate_yaml
def test_validate_yaml():
    # Simple test to check the basics of validate_yaml

    s = """
    schema: car
    car:
        model: Tesla Model X
        year: 2016
        airbags:
            front-side: True
            front-knee: True
            front-window: False
        """
    value, errors = validate_yaml(s, CarSchema())
    assert errors == []

    s = """
    schema: car
    car:
        model: Tesla Model X
        year: 2019
        airbags:
            front-side: True
            front-knee: True
            front-window: False
            """
    value, errors = validate_yaml(s, CarSchema())
    assert len(errors) == 1
    assert errors[0].text == "Must be 2016 or earlier."


# Generated at 2022-06-12 16:14:19.301797
# Unit test for function validate_yaml
def test_validate_yaml():
    class SimpleSchema(Schema):
        name = Field(text())
        age = Field(number())
    assert validate_yaml("name: Bob\nage: 23", SimpleSchema) == ({"name": "Bob", "age": 23}, [])
    v, e = validate_yaml("name: Bob\nage: 23", SimpleSchema)
    assert v == {"name": "Bob", "age": 23}
    assert e == []

    class SimpleSchema(Schema):
        name = Field(text())
        age = Field(number())

# Generated at 2022-06-12 16:14:29.886079
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String

    content = "foo: bar"
    field = String(read_only=True)
    value, errors = validate_yaml(content, field)
    assert not errors
    assert value == {"foo": "bar"}

    content = "foo: bar"
    field = String(read_only=True)
    value, errors = validate_yaml(content, field)
    assert not errors
    assert value == {"foo": "bar"}

    content = "bar"
    field = String(read_only=True)
    value, errors = validate_yaml(content, field)
    assert errors
    assert value == "bar"
    assert errors[0].text == "Invalid YAML: missing mapping token."
    assert errors[0].code == "missing_mapping_token"

# Generated at 2022-06-12 16:14:41.997837
# Unit test for function validate_yaml
def test_validate_yaml():
    class Validator(Schema):
        name = String(max_length=2)
        email = String(max_length=2)
        age = Integer(minimum=10)

    value, errors = validate_yaml(
        content="name: foo\nemail: bar\nage: 20", validator=Validator
    )
    assert value == {"name": "foo", "email": "bar", "age": 20}
    assert len(errors) == 0

    value, errors = validate_yaml(content="age: 20", validator=Validator)
    assert value is None
    assert len(errors) == 3
    assert isinstance(errors[0], ValidationError)
    assert errors[0].code == "required_field"
    assert errors[0].pointer == "/name"

# Generated at 2022-06-12 16:14:44.203744
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
        foo:
          bar: 123
    """)
    assert token.value == {
        "foo": {
            "bar": 123
        }
    }


# Generated at 2022-06-12 16:14:55.689243
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.typing import Number, Text
    from typesystem import Object
    from typesystem.tokenize.positional_validation import (
        parse_and_validate_with_position,
        ParseAndValidateResult,
    )
    from typesystem.tokenize.source import SourceSpan

    class User(Object):
        form = {}
        id = Number(description="id")
        name = Text(description="name")

    content = "hello world"  # Invalid input.
    (_value, errors) = validate_yaml(content, User)
    assert errors[0].text == "Expected dictionary."
    start = SourceSpan(line_no=1, column_no=1, char_index=0)

# Generated at 2022-06-12 16:15:06.446642
# Unit test for function validate_yaml
def test_validate_yaml():
    import functools

    def format_error(error: ValidationError) -> str:
        # Textual representation of an error, using relative line numbers.
        position = error.position.relative_to(error.position.content)
        return f"{position} {error.text}"

    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    validator = PersonSchema()

    # Passing validation.
    content = """
    ---
    name: Alice Smith
    age: 36
    """
    value, errors = validate_yaml(content, validator)
    assert errors == []

    # Failed validation, with errors in multiple lines.
    content = """
    ---
    name:
    age: 36
    """

# Generated at 2022-06-12 16:15:14.598297
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    ip: 192.168.1.1
    mac: 00:0c:29:53:00:e5
    """

    class NetworkInterface(Schema):
        ip = Field(type=str)
        mac = Field(type=str)

    result, errors = validate_yaml(content, validator=NetworkInterface)
    assert errors == []
    assert result == {
        "ip": "192.168.1.1",
        "mac": "00:0c:29:53:00:e5",
    }


# Generated at 2022-06-12 16:15:25.819548
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None
    from typesystem import Integer
    from typesystem.schema import Schema

    class UserSchema(Schema):
        id = Integer(description="The user's ID")
        name = Integer(description="The user's name")

    result = validate_yaml(
        content="""
    - id: 1
    - name: 2
    """,
        validator=UserSchema,
    )
    assert result == (
        [{"id": 1, "name": 2}],
        [],
    )

    # errors
    result = validate_yaml(
        content="""
    - id: 1
    - name: "test"
    """,
        validator=UserSchema,
    )

# Generated at 2022-06-12 16:15:32.877294
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None
    import typesystem

    typesystem.yaml.validate_yaml("""
        maps:
          foo:
            bar: baz
        """, typesystem.Structure({"maps": typesystem.Structure({})})) == \
           ({"maps": {"foo": {"bar": "baz"}}}, "")

    try:
        typesystem.yaml.validate_yaml("foo: bar", typesystem.String())
    except Exception as e:
        print(e)

# Generated at 2022-06-12 16:15:35.685458
# Unit test for function validate_yaml
def test_validate_yaml():
    data = b"hello: world\n"
    value, messages = validate_yaml(data, Schema({"hello": "string"}))
    assert value == {"hello": "world"}
    assert messages == []


# Generated at 2022-06-12 16:15:48.294497
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Dict, Boolean

    class SimpleSchema(Schema):
        x = Integer(required=False, default=1)
        y = String()
        z = Array(String(), min_items=1)

    class ComplexSchema(Schema):
        foo = Dict(sub_schema=SimpleSchema)
        bar = Array(Dict(sub_schema=SimpleSchema))
        baz = Dict(sub_schema=SimpleSchema, required=False)
        baz_array = Array(
            Dict(sub_schema=SimpleSchema), required=False, default=[]
        )
        qux = Boolean(required=False, default=False)


# Generated at 2022-06-12 16:15:57.719035
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test a Schema class
    class TestSchema(Schema):
        name = "text"
        age = "number"
    result = validate_yaml(content=b'name: "Bob"\nage: 5', validator=TestSchema)
    assert result[0] == {'name': 'Bob', 'age': 5}
    assert result[1] == []
    result = validate_yaml(content=b'name: "Bob"\nage: Bob', validator=TestSchema)
    assert result[0] == {'name': 'Bob', 'age': 'Bob'}

# Generated at 2022-06-12 16:16:03.971765
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "a: 1\nb: 2\nc: 3"
    validator = {"a": int, "b": int, "c": int}
    result_tuple = validate_yaml(content=content, validator=validator)
    assert(result_tuple == ({'a': 1, 'b': 2, 'c': 3}, []))

# Generated at 2022-06-12 16:16:08.306439
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String

    content = "foo: bar"
    token = tokenize_yaml(content)
    validator = String()
    validate_yaml(content, validator)
    assert str(token) == content
    #assert validate_with_positions(token=token, validator=validator)[0] == token



# Generated at 2022-06-12 16:16:17.043228
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import String

    result, errors = validate_yaml(
        b"""
            people:
              - name: Brian
              - name: Jeff
        """,
        Schema({"people": [{"name": String()}]}),
    )

    expected_errors = [
        ValidationError(
            code="invalid_type",
            text="The value at 'people' must be a list.",
            position=Position(
                char_index=14, column_no=15, line_no=2
            ),  # start of 'people'
        )
    ]

    assert errors == expected_errors

# Generated at 2022-06-12 16:16:19.424922
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        a:
          b:
            c: Hello
            d: World
    """

    class MySchema(Schema):
        a = Schema({"b": {"c": str, "d": str}})

    value, messages = validate_yaml(content=content, validator=MySchema)
    assert value == {"a": {"b": {"c": "Hello", "d": "World"}}}
    assert [m.code for m in messages] == []


# Generated at 2022-06-12 16:16:27.179101
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "a: b"
    validator = Field(type="string")
    value, messages = validate_yaml(content, validator)
    assert value == {"a": "b"}
    assert messages == []

    content = "a: 1"
    value, messages = validate_yaml(content, validator)
    assert value is None
    assert len(messages) == 1

# Generated at 2022-06-12 16:16:34.073411
# Unit test for function validate_yaml
def test_validate_yaml():
    # str
    try:
        validate_yaml('', '')
    except ValueError:
        pass
    # bytes
    try:
        validate_yaml(b'', '')
    except ValueError:
        pass
    # token
    token = tokenize_yaml('1')
    assert validate_yaml(token, '') == (1, [])
    # token
    token = tokenize_yaml('{}')
    token.start = 0
    assert validate_yaml(token, '') == ({}, [])        

test_validate_yaml()

# Generated at 2022-06-12 16:16:45.361130
# Unit test for function validate_yaml
def test_validate_yaml():
    # pylint: disable=R0201

    class TestSchema(Schema):
        title = String()
        author = String()

    content = """
    title: "The Tragedy of King Lear"
    author: "Shakespeare, William"
    """

    errors = validate_yaml(content, TestSchema)
    assert not errors

    content = """
    title:
    author: "Shakespeare, William"
    """

    errors = validate_yaml(content, TestSchema)
    assert errors[0].text == "A string is required."

    content = """
    title:
    author:
    """

    errors = validate_yaml(content, TestSchema)
    assert errors[0].text == "A string is required."
    assert errors[1].text == "A string is required."




# Generated at 2022-06-12 16:16:57.725027
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer()
        amount = fields.Number(required=True)

    content = "name: Paul\nage: 18\namount: $50.00"
    errors = []
    value, errors = validate_yaml(content, TestSchema)
    assert value == {"name": "Paul", "age": 18, "amount": 50.0}
    assert errors == []

    content = "name: Paul\nage: 18\nAMOUNT: $50.00"
    errors = []
    value, errors = validate_yaml(content, TestSchema)
    assert value == {"name": "Paul", "age": 18}

# Generated at 2022-06-12 16:17:07.399305
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String

    class PetSchema(Schema):
        id = Integer(required=True)
        name = String(min_length=2, max_length=5)

    content = "id: 1 \n name: hello"
    result, error_messages = validate_yaml(content, validator=PetSchema)
    assert result == {"id": 1, "name": "hello"}
    assert error_messages == []

    content = "id: 2 \n name: my name is too long"
    result, error_messages = validate_yaml(content, validator=PetSchema)
    assert result is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Ensure this value has at most 5 characters (it has 22)."
    assert error_

# Generated at 2022-06-12 16:17:12.034854
# Unit test for function tokenize_yaml
def test_tokenize_yaml(): # noqa
    token = tokenize_yaml("""
    foo:
      bar:
        - 1
        - 2
        - 3
    """)
    assert token.get("foo").get("bar").get(0) == ScalarToken("1", 16, 16, content="")
    assert all(
        isinstance(token, Token) for token in token.get("foo").get("bar").get(0, 1000)
    )



# Generated at 2022-06-12 16:17:18.660929
# Unit test for function validate_yaml
def test_validate_yaml():
    TEST_YAML_STRING =\
    """
    # a comment
    description: this is a description
    int_field: 1
    """
    class TestSchema(Schema):
        description = "a description"
        int_field = Field(type="integer")

    validator = TestSchema()

    assert TEST_YAML_STRING.encode('utf-8') == validate_yaml(
                content=TEST_YAML_STRING,
                validator=validator
                )[0]

# Generated at 2022-06-12 16:17:22.046341
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    test validate_yaml with a yaml file
    """
    yaml_file = open("test_yaml.yaml", "r")
    yaml_file_contents = yaml_file.read()

    schema = Schema()
    try:
        assert validate_yaml(content=yaml_file_contents, validator=schema)
    except ValidationError:
        assert False

# Generated at 2022-06-12 16:17:32.716244
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type=str)
    assert validate_yaml("foo", validator) == ("foo", [])
    assert validate_yaml("bar\nbaz", validator) == ("bar\nbaz", [])

    content = "foo\nbar"
    position = Position(column_no=1, line_no=1, char_index=0)
    error = ValidationError('value must be of type "str"', code="type_error")
    assert validate_yaml(content, validator=Field(type=dict)) == (None, [Message(str(error), position)])

    content = "foo: bar"
    position = Position(column_no=1, line_no=1, char_index=0)

# Generated at 2022-06-12 16:17:41.704111
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.validators import MinLength, MaxValue, Required

    class User(Schema):
        name = String(validators=[Required(), MinLength(3)])
        age = Integer(validators=[MaxValue(50)])
    usr = User()
    str1 = "name : testname\nage : 55"
    print(validate_yaml(str1, usr))



# Generated at 2022-06-12 16:17:52.760287
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('{"foo": "Happy"}', {"foo": str}) == ('{"foo": "Happy"}', [])
    assert validate_yaml('{"foo": "Happy"}', {'foo': str}) == ('{"foo": "Happy"}', [])
    assert validate_yaml('{"foo": "Happy"}', {'bar': str}) == ('{"foo": "Happy"}', [])
    assert validate_yaml('{"foo": "Happy"}', {"bar": str}) == ('{"foo": "Happy"}', [])
    assert validate_yaml('{"foo": "Happy"}', {'foo': str, 'bar': str}) == ('{"foo": "Happy"}', [])
    assert validate_yaml('{"key": "value"}', {"key": str, "value": str}) == ('{"key": "value"}', [])


# Generated at 2022-06-12 16:17:59.206327
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer
    import yaml

    good_string = "age: 25"

    bad_string = "age: 25.0"
    
    result = validate_yaml(good_string, Integer())
    assert result[0] == {"age": 25}
    assert len(result[1].messages) == 0

    result = validate_yaml(bad_string, Integer())
    assert result[0] is None
    assert result[1].messages[0].code == "invalid_type"

# Generated at 2022-06-12 16:18:09.572095
# Unit test for function validate_yaml
def test_validate_yaml():
 
    # Test successful parsing and validation with a field
    content = "\n".join(
        [
            '{"age": 30, "name": "John Smith", "friends": ["Jane", "Mark"]}',
        ]
    )

    _schema = {
        "type": "object",
        "properties": {
            "age": {"type": "integer"},
            "name": {"type": "string"},
            "friends": {"type": "array", "items": {"type": "string"}},
        },
    }
    # field = Field(**_schema)
    # value, errors = validate_yaml(content, validator=field)
    # assert errors is None
    # assert value == {  # type: ignore
    #     "age": 30,
    #     "name": "John Smith",
    #

# Generated at 2022-06-12 16:18:18.473827
# Unit test for function validate_yaml
def test_validate_yaml():
    good_yaml = '''
        name: test
        address:
            street: '123 Main Street'
            city: 'Buenos Aires'
    '''
    good_schema = UserSchema(name='Inline address', address=AddressSchema())
    value, messages = validate_yaml(good_yaml, good_schema)
    assert messages == []
    assert isinstance(value, dict)
    assert value['address']['street'] == '123 Main Street'
    bad_yaml = '''
        name: test
        address:
            street: '123 Main Street'
            city: 3987
    '''
    bad_schema = UserSchema(name='Inline address, bad number', address=AddressSchema())

# Generated at 2022-06-12 16:18:24.077995
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("howdy:", Field(String())) == (
        None,
        [
            Message(
                text="No mapping value found for key 'howdy'.",
                code="required",
                position=Position(column_no=6, line_no=1, char_index=5),
            )
        ],
    )

# Generated at 2022-06-12 16:18:34.226726
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        a = typing.Union[str, int, None]
        b = bool
        c = list

    schema = MySchema()

    content = """
    a: 1
    b: true
    c:
        - 1
        - 2
        - 3
    """
    value, errors = validate_yaml(content, schema)
    assert value == {'a': 1, 'b': True, 'c': [1, 2, 3]}
    assert errors == []

    content = "1"
    value, errors = validate_yaml(content, schema)
    assert errors == [Message(text='Parse error.', code='parse_error', position=Position(column_no=2, line_no=1, char_index=1))]


# Generated at 2022-06-12 16:18:44.695240
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test for empty input
    value, errors = validate_yaml("", Field(str))
    assert value == ""
    assert len(errors) == 0

    # Test for invalid input
    value, errors = validate_yaml("some text", Field(str))
    assert not value
    assert len(errors) == 1

    # Test for invalid input
    value, errors = validate_yaml(b"some text", Field(str))
    assert not value
    assert len(errors) == 1

    # Test for valid input
    value, errors = validate_yaml("some text", Field(str))
    assert value == "some text"
    assert len(errors) == 0

    # Test for valid input with trailing whitespace
    value, errors = validate_yaml("some text  ", Field(str))

# Generated at 2022-06-12 16:18:54.470404
# Unit test for function validate_yaml
def test_validate_yaml():
    import sys
    import types
    sys.modules['typesystem'] = types
    sys.modules['typesystem.base'] = types
    sys.modules['typesystem.fields'] = types
    sys.modules['typesystem.schemas'] = types
    sys.modules['typesystem.tokenize.positional_validation'] = types
    sys.modules['typesystem.tokenize.tokens'] = types
    sys.modules['typesystem.utils'] = types


    from typesystem.utils import validate_yaml
    print(validate_yaml("""
    age: 20
    name: Jon
    """, {'age': int, 'name': str}))

# Generated at 2022-06-12 16:19:01.036950
# Unit test for function validate_yaml
def test_validate_yaml():
    ok_content = """
    a: 3
    b: "hello"
    """
    class MySchema(Schema):
        a = typesystem.fields.Integer()
        b = typesystem.fields.String()
    value, errors = validate_yaml(ok_content, MySchema)
    assert value == {"a": 3, "b": "hello"}
    assert errors == []

    error_content = """
    a: Hello
    b: "hello"
    """
    value, errors = validate_yaml(error_content, MySchema)

# Generated at 2022-06-12 16:19:06.192242
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(min_length=5)
        age = Integer(minimum=2)

    content = b"---\nname: John\nage: '5'"
    value, messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 5}
    assert messages == []

# Generated at 2022-06-12 16:19:19.418764
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test validate_yaml() method."""
    from typesystem.fields import Integer, String

    class MySchema(Schema):
        a = Integer()
        b = String()

    content = """
    a: 1
    b: hello
    """
    value, errors = validate_yaml(content, MySchema)
    assert value["a"] == 1
    assert value["b"] == "hello"
    assert not errors

    from typesystem.tokenize.positional_validation import (  # noqa: F401
        Message,
    )

    content = """
   a: 1
   b: hello
   c: 3
    """

# Generated at 2022-06-12 16:19:30.529168
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem import Integer, String
    from typesystem.schemas import Schema

    content = """
    name: john doe
    age: 30
    """

    class UserSchema(Schema):
        name = String(max_length=50)
        age = Integer(minimum=0, maximum=100)

    value, errors = validate_yaml(content, validator=UserSchema)

    assert value == {
        "name": "john doe",
        "age": 30,
    }

    assert isinstance(errors, list)
    assert all(isinstance(error, ValidationError) for error in errors)
    assert not errors


# Generated at 2022-06-12 16:19:37.131373
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    hello: world
    foo:
        - 1
        - 2
        - 3
    """
    validator = Schema({"hello": str, "foo": [int]})
    value, messages = validate_yaml(content, validator)
    assert value == {"hello": "world", "foo": [1, 2, 3]}
    assert len(messages) == 0

# Generated at 2022-06-12 16:19:42.704392
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import sys, os.path
    dir, _ = os.path.split(__file__)
    yamlfile = os.path.join(dir,'example.yaml')
    with open(os.path.join(yamlfile),'r') as f:
        token = tokenize_yaml(f)
    assert isinstance(token,DictToken)
    assert isinstance(token.children['a'],ListToken)


# Generated at 2022-06-12 16:19:49.016919
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.exceptions import ValidationError
    from typesystem.schemas import Schema
    from typesystem.fields import Text

    class User(Schema):
        name = Text(required=True)

    try:
        result, msgs = validate_yaml("name:", User)
    except ValidationError as e:
        msgs = e.messages
    assert len(msgs) == 1

# Generated at 2022-06-12 16:20:00.382669
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_string1 = """item1: 1
item2: 2"""
    yaml_string2 = """item1: A
item2: 2"""
    yaml_string3 = """item1: A
item2: B"""
    yaml_string4 = """item1: 1
item2: B"""
    yaml_string5 = """first_item: 1
second_item: B"""

    class TestSchema(Schema):
        item1 = "integer"
        item2 = "integer"

    class TestSchema1(Schema):
        first_item = "integer"
        second_item = "integer"

    assert validate_yaml(yaml_string1, TestSchema) == (
        [],
        [],
    )

# Generated at 2022-06-12 16:20:04.023956
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = String(required=True)
        description = String(required=True)

    response = validate_yaml(b"name: Test\ndescription: Test", TestSchema)
    assert response == ({'name': 'Test', 'description': 'Test'}, [])


# Generated at 2022-06-12 16:20:16.224614
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test with string
    content = """
    name: John
    last_name: Doe
    age: 20
    """.strip()

    class UserSchema(Schema):
        name = Field(type="string")
        last_name = Field(type="string")
        age = Field(type="integer")

    value, errors = validate_yaml(content, validator=UserSchema)
    assert value == {"name": "John", "last_name": "Doe", "age": 20,}
    assert not errors

    # Test with bytestring
    content = """
    name: Jane
    last_name: Doe
    age: 30
    """.strip().encode()

    value, errors = validate_yaml(content, validator=UserSchema)

# Generated at 2022-06-12 16:20:26.097373
# Unit test for function validate_yaml
def test_validate_yaml():
  content = """
  - 1
  - 2
  - 3
  """
  error = None
  try:
    validate_yaml(content, Field(type=int))
  except Exception as e:
    error = e.args[0]
  assert not error, "validate_yaml returned a message: %s" % error

  content = "3"
  try:
    validate_yaml(content, Field(type=int))
  except Exception as e:
    error = e.args[0]
  assert error == "expected a sequence.", "validate_yaml did not return an error for an invalid value"

  content = """
  - 1
  - 2
  - 3
  """

# Generated at 2022-06-12 16:20:31.168292
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    value = tokenize_yaml('{ "key": "value" }')
    assert isinstance(value, DictToken)
    assert len(value.value) == 1
    assert value.value["key"] == "value"



# Generated at 2022-06-12 16:20:36.593515
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(key="name", type="string")
    content = """
    name: Jane Doe
    """
    value, errors = validate_yaml(content, validator)
    assert value == "Jane Doe"
    assert errors == []



# Generated at 2022-06-12 16:20:43.754656
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        fields=[
            Field(name="foo", description="Foo description"),
            Field(name="bar", description="Bar description"),
            Field(name="baz", description="Baz description"),
        ]
    )
    # Simple YAML string
    data = """
    foo: a
    bar: b
    baz: c
    """
    # No parse or validation errors
    assert validate_yaml(data, schema) == ({}, [])

# Generated at 2022-06-12 16:20:51.368841
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, List
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        first_name = String()
        last_name = String()
        age = Integer()
        friends = List[String]()

    yaml_str = """
    first_name: John
    last_name: Doe
    age: "42"
    friends:
     - Mary
     - Brian
     - Alice
    """
    yaml_str_invalid_age = """
    first_name: Jane
    last_name: Doe
    age: 42.5
    friends:
     - Mary
     - Brian
     - Alice
    """

# Generated at 2022-06-12 16:21:00.825890
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
            id: "jkjlkjlkj"
            name: John Doe
            email: johndoe@example.com
            age: 24 
            """
    errors = validate_yaml(content, UserSchema)
    assert len(errors) == 2
    assert errors[0].code == "required_field" 
    assert errors[0].position == Position(column_no=9,line_no=2,char_index=8)
    assert errors[0].text == "id is required."
    assert errors[1].code == "required_field" 
    assert errors[1].position == Position(column_no=10,line_no=3,char_index=9)
    assert errors[1].text == "name is required."



# Generated at 2022-06-12 16:21:12.948853
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
	# Testing empty string
	test = ''
	assert tokenize_yaml(test) == None
	# Testing dict
	test = '{"hello": "world"}'
	assert type(tokenize_yaml(test)) == DictToken
	# Testing list
	test = '[2.25, 3, 4]'
	assert type(tokenize_yaml(test)) == ListToken
	# Testing int
	test = '10'
	assert type(tokenize_yaml(test)) == ScalarToken
	# Testing float
	test = '2.5'
	assert type(tokenize_yaml(test)) == ScalarToken
	# Testing boolean
	test = 'true'
	assert type(tokenize_yaml(test)) == ScalarToken
	# Testing string
	test = '"hello"'

# Generated at 2022-06-12 16:21:16.558281
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, start=0, end=0, content="{}")
    assert tokenize_yaml("[]") == ListToken([], start=0, end=0, content="[]")
    assert tokenize_yaml("""{"field": 1}""") == DictToken({"field": 1}, start=0, end=14, content="""{"field": 1}""")
    assert tokenize_yaml("""["field"]""") == ListToken(["field"], start=0, end=10, content="""["field"]""")
    assert tokenize_yaml("""1""") == ScalarToken(1, start=0, end=0, content="1")

# Generated at 2022-06-12 16:21:24.330409
# Unit test for function validate_yaml
def test_validate_yaml():
    v = validate_yaml(b"foo: bar", Field(name="foo", type="string"))
    assert v == ("bar", [])

    v = validate_yaml(b"invalid", Field(name="foo", type="string"))
    assert v[1][0].text == "Invalid YAML."
    assert v[1][0].position.line_no == 1
    assert v[1][0].position.column_no == 3

    v = validate_yaml(b"foo: 1", Field(name="foo", type="string"))
    assert v[1][0].text == "Must be of type string."
    assert v[1][0].position.line_no == 1
    assert v[1][0].position.column_no == 9

# Generated at 2022-06-12 16:21:35.289212
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
        - low
        - high

        - fern
        - grass
    '''

    class MockField(Field):
        def __init__(self):
            super().__init__()

        def validate(self, value):
            if value == 'high':
                raise ValidationError('high not allowed')

            return value

    errors = validate_yaml(content, MockField())

    assert len(errors) == 2
    assert errors[0].text == 'high not allowed'
    assert errors[0].code == 'validation_error'
    assert errors[0].position == Position(3, 1, 14)

    assert errors[1].text == 'Invalid value.'
    assert errors[1].code == 'value_error'
    assert errors[1].position == Position(4, 1, 20)



# Generated at 2022-06-12 16:21:43.846449
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - value: 123
      unit: km
    - value: 789
      unit: m
    """

    class LocationSchema(Schema):
        value = Field(type="integer")
        unit = Field(type="string", enum=["m", "km"])

    assert validate_yaml(content, validator=LocationSchema) == (
        [
            {"value": 123, "unit": "km"},
            {"value": 789, "unit": "m"},
        ],
        [],
    )



# Generated at 2022-06-12 16:21:51.714304
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    yaml_content = "name: Jim\n" + "age: 20\n"

    class PersonSchema(Schema):
        name = "PersonSchema"
        properties = {
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }

    result = validate_yaml(yaml_content, PersonSchema)
    assert result == ({"name": "Jim", "age": 20}, [])

    yaml_content = """
        name: Jim
        age: twenty
        """

    result = validate_yaml(yaml_content, PersonSchema)

# Generated at 2022-06-12 16:22:04.417638
# Unit test for function validate_yaml
def test_validate_yaml():
    from typing import List
    from typesystem.exceptions import ValidationError
    
    from typesystem import Schema
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import DateTime
    from typesystem.fields import Datetime
    from typesystem.fields import Time
    from typesystem.fields import Date
    from typesystem.fields import ListOf
    from typesystem.fields import DictOf
    from typesystem.fields import UUID
    from typesystem.fields import URL
    from typesystem.fields import Dict
    from typesystem.fields import Array
    from typesystem.fields import Json
    from typesystem.fields import Enum
    from typesystem.fields import Any
    from typesystem.fields import Object


# Generated at 2022-06-12 16:22:09.104034
# Unit test for function validate_yaml
def test_validate_yaml():
    class FooSchema(Schema):
        foo = Field(type="string")

    value, errors = validate_yaml(b"foo:\n- x", validator=FooSchema)
    assert value == {"foo": ["x"]}
    assert not errors