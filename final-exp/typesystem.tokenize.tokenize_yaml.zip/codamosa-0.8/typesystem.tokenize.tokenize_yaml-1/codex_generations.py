

# Generated at 2022-06-12 16:12:32.859237
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    - a
    - b
    - c
    """
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert token.value == ["a", "b", "c"]
    assert token.start == 3
    assert token.end == 25
    assert token.content == content \
        .strip() \
        .replace(" ", "") \
        .replace("\n", "")


test_validate_yaml_content = """
[
    {
        "a": [1,2,3]
    },
    {
        "a": [1,2,3]
    }
]
"""


# Generated at 2022-06-12 16:12:41.896838
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    schema = Schema(String())

    content = "a string"
    value, errors = validate_yaml(content, schema)

    assert value == "a string"
    assert errors == []

    content = "string"
    value, errors = validate_yaml(content, schema)

    assert value is None
    assert errors == [
        {'code': 'type_error', 'field': '', 'message': "'string' is not of type 'string'", 'position': {'char_index': 0, 'column_no': 1, 'line_no': 1}}
    ]

    content = "!str"
    value, errors = validate_yaml(content, schema)

    assert value is None

# Generated at 2022-06-12 16:12:51.083133
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("true") == ScalarToken(value=True, start=0, end=3, content="true")
    assert tokenize_yaml("{}") == DictToken(value={}, start=0, end=1, content="{}")
    assert tokenize_yaml("[]") == ListToken(value=[], start=0, end=1, content="[]")
    assert tokenize_yaml("0") == ScalarToken(value=0, start=0, end=1, content="0")
    assert tokenize_yaml("1") == ScalarToken(value=1, start=0, end=1, content="1")

# Generated at 2022-06-12 16:12:56.884181
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from yaml.parser import ParserError
    import jinja2
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    # Test that the content of an empty string is handled correctly.
    with pytest.raises(ParseError, match="No content") as exc_info:
        tokenize_yaml("  ")
    assert exc_info.value.code == "no_content"
    assert exc_info.value.position.char_index == 0

    # Test that the content of an empty string is handled correctly.
    with pytest.raises(ParseError, match="No content") as exc_info:
        tokenize_yaml("  \n\n")
    assert exc_info.value.code == "no_content"
    assert exc_info.value.position

# Generated at 2022-06-12 16:12:58.830117
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    data = "test: 'test'"
    parsed = tokenize_yaml(data)
    assert(isinstance(parsed.token_data, dict))
    assert(parsed.token_data == {"test": "test"})
    assert(parsed.content == "test: 'test'")
    assert(parsed.children["test"].content == "'test'")


# Generated at 2022-06-12 16:13:08.376990
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    test_key: test_value
    test_key_2:
      - a
      - b
      - c
    test_key_3: false
    test_key_4: null
    test_key_5: 1234
    test_key_6: 2.33
    test_key_7:
      test_key_8: test_value
    test_key_9: # a comment
      test_key_10: test_value
    """)
    assert isinstance(token, DictToken)

# Generated at 2022-06-12 16:13:15.186859
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import ValidationError, validators
    from typesystem.yaml import validate_yaml
    schema = validators.Dictionary(properties={"age": validators.Integer(minimum=18)})
    assert validate_yaml(content="age: 20", validator=schema) == {"age": 20}
    assert validate_yaml(content="age: 15", validator=schema) == ("age: 15", [ValidationError(code='minimum', text="Must be at least 18.", position=Position(char_index=8, column_no=1, line_no=1))])

# Generated at 2022-06-12 16:13:20.433927
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("hello: world") == DictToken({"hello": "world"}, 0, 12, content="hello: world")
    assert tokenize_yaml("[1234, 1234, 1234, 1234]") == ListToken([1234, 1234, 1234, 1234], 0, 22, content="[1234, 1234, 1234, 1234]")
    assert tokenize_yaml("123") == ScalarToken(123, 0, 2, content="123")
    with pytest.raises(ParseError):
        assert tokenize_yaml("hello: world") == DictToken({"hello": "world"}, 0, 1, content="hello: world")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml

# Generated at 2022-06-12 16:13:27.224767
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("\"\"") == ""
    assert tokenize_yaml("\"foo\"") == "foo"
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("-1") == -1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("-1.0") == -1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None



# Generated at 2022-06-12 16:13:36.110554
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(b'{"one":1, "two": 2}')
    assert isinstance(token, DictToken)
    assert len(token.value) == 2
    assert token.value.get("one") == 1
    assert token.value.get("two") == 2

    token = tokenize_yaml(b"one: 1\ntwo: 2\n")
    assert isinstance(token, DictToken)
    assert len(token.value) == 2
    assert token.value.get("one") == 1
    assert token.value.get("two") == 2

    token = tokenize_yaml(b"one\ntwo\n")
    assert isinstance(token, ListToken)
    assert len(token.value) == 2
    assert token.value.get(0) == "one"

# Generated at 2022-06-12 16:13:51.550132
# Unit test for function validate_yaml
def test_validate_yaml():
    def test_validate_yaml_not_imported():
        yaml = None
        assert True

    def test_bad_validator():
        bad_validator = "foo"
        with pytest.raises(ValidationError):
            validate_yaml(content="", validator=bad_validator)

    def test_bad_content():
        empty_content = ""
        with pytest.raises(ParseError):
            validate_yaml(content=empty_content, validator=str)

    def test_validator_bad_type():
        bad_type_content = b"1"
        with pytest.raises(ValidationError):
            validate_yaml(content=bad_type_content, validator=str)


# Generated at 2022-06-12 16:14:01.203950
# Unit test for function validate_yaml
def test_validate_yaml():
    # Handle the case of an empty string
    with pytest.raises(ParseError) as excinfo:
        validate_yaml("", String())
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.char_index == 0
    assert excinfo.value.code == "no_content"
    assert excinfo.value.text == "No content."

    # Handle a bad parse error.
    with pytest.raises(ParseError) as excinfo:
        validate_yaml("\thello: 42", String())
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.char_index == 0

# Generated at 2022-06-12 16:14:05.216406
# Unit test for function validate_yaml
def test_validate_yaml():
    str_content = 'name: John Doe\n'
    errors = validate_yaml(str_content, Schema({"name": "string"}))
    assert len(errors) == 0



# Generated at 2022-06-12 16:14:12.974602
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: 1
    b:
      - 2
      - 3
    """
    expected = DictToken([
        ('a', ScalarToken(1, 5, 6, content=content)),
        ('b', ListToken([ScalarToken(2, 15, 16, content=content),
                         ScalarToken(3, 21, 22, content=content)], 15, 22, content=content))
        ],
        0,
        24,
        content=content
    )
    assert expected == tokenize_yaml(content)

    content = """
    a: "1"
    b:
      - "2"
      - 3
    """

# Generated at 2022-06-12 16:14:23.764917
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, Schema, String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        id = Integer(minimum=0)
        name = String(min_length=1)
        bio = String(required=False)

    # ## No content
    content = ""
    _, messages = validate_yaml(content, validator=UserSchema)
    assert len(messages) == 1
    assert messages[0].text == "No content."
    assert messages[0].code == "no_content"
    assert (
        messages[0].position.char_index == 0
        and messages[0].position.line_no == 1
        and messages[0].position.column_no == 1
    )

    # ## Parse Error

# Generated at 2022-06-12 16:14:32.696916
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import ValidationError, ValidationErrors
    from typesystem.fields import String, Integer

    field = String()
    validated_value, errors = validate_yaml("randomString", field)

    assert validated_value == "randomString"
    assert errors is None

    field = Integer()
    validated_value, errors = validate_yaml("42", field)

    assert validated_value == 42
    assert errors is None

    # Python3.8 is needed for the error to include the
    # position info.
    try:
        validate_yaml("hello", field)
    except ValidationError as err:
        # ValidationErrors is a class of ValidationError
        # and inherits from `collections.abc.Sequence`
        assert isinstance(err.errors, ValidationErrors)

# Generated at 2022-06-12 16:14:42.963511
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test the case where an error is raised
    content = "blah blah"
    with pytest.raises(ParseError):
        tokenize_yaml(content)

    # Test the case where tokenize_yaml is called with a dictionary
    content = "{ hey: hello, how: are }"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    
    # Test the case where tokenize_yaml is called with a list
    content = "[1, 2, 3]"
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)



# Generated at 2022-06-12 16:14:54.177027
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml for parse and validation error
    """
    yaml_str = '''
        - String
        - String[1]
        - String[2]
        - String[3]
        - String[4]
        - String
    '''
    class TestSchema(Schema):
        field1 = validator.Integer()
        field2 = validator.Boolean()
        field3 = validator.String()

    value, error_messages = validate_yaml(yaml_str, TestSchema)
    assert value is None
    assert len(error_messages) == 3
    assert error_messages[0].text == "Expected a value of type 'integer'."
    assert error_messages[0].code == "invalid_type"
    assert error_messages[1].text

# Generated at 2022-06-12 16:15:05.173367
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # Test tokenization of a scalar value.
    token = tokenize_yaml("value")
    assert isinstance(token, ScalarToken)
    assert token.get_value() == "value"
    assert token.get_start() == 0
    assert token.get_end() == 5

    # Test tokenization of a list value.
    token = tokenize_yaml("- item1\n- item2")
    assert isinstance(token, ListToken)
    assert token.get_value() == ["item1", "item2"]
    assert token.get_start() == 0
    assert token.get_end() == 15

    # Test tokenization of a dict value with a null value in a list.
    token = tokenize_yaml("key: null")
    assert isinstance(token, DictToken)
    assert token

# Generated at 2022-06-12 16:15:14.078375
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Array
    from typesystem.schemas import Schema
    from typesystem.fields import Integer
    import yaml

    class PersonSchema(Schema):
        name = String()
        age = Integer()
        children = Array(String)

    validator = PersonSchema()

    def load_yaml_string(content: str) -> PersonSchema:
        value, error = validate_yaml(content, validator)
        if error:
            print(error)
        return value

    invalid_yaml = """
      name: Ernie
      age: 9
    """
    # The schema expects a children field
    with pytest.raises(ValidationError):
        load_yaml_string(invalid_yaml)


# Generated at 2022-06-12 16:15:24.942459
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    text = """
    # Sample document for Typesystem.

    title: Sample document
    heading:
      - name: sample
        title: The sample heading
      - name: document
        title: The document heading
    """
    token = tokenize_yaml(text)
    assert(isinstance(token, DictToken))
    assert(token.start_index == 16)
    assert(token.end_index == 101)
    assert(token.start_position.line_no == 3)
    assert(token.start_position.column_no == 5)
    assert(token.end_position.line_no == 8)
    assert(token.end_position.column_no == 11)

# Generated at 2022-06-12 16:15:35.539138
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String, Array

    class MySchema(Schema):
        name = String(required=True)
        age = Integer(minimum=0, maximum=100)
        nicknames = Array(items=String())

    yaml_string = """
        name: 'John Doe'
        age: 101
        nicknames:
          - 'admin'
          - 'root'
    """

    value, errors = validate_yaml(yaml_string, MySchema)
    
    assert value == {'name': 'John Doe', 'age': 101, 'nicknames': ['admin', 'root']}
    assert len(errors) == 1
    error: Message = errors[0]
    assert error.code == "field_value_invalid"
    assert error

# Generated at 2022-06-12 16:15:40.116593
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '{"name": "Abhishek"}'
    field = Field(str, name="name", required=True)
    result = validate_yaml(content, field)
    assert result == {"name": "Abhishek"}


# Generated at 2022-06-12 16:15:44.558038
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "123"
    validator = "integer"
    value, error_messages  = validate_yaml(content, validator)
    assert value == 123
    assert error_messages == []



# Generated at 2022-06-12 16:15:54.465351
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('{}') == DictToken({}, 0, 1, content='{}')
    assert tokenize_yaml('{"a": 1}') == DictToken({'a': 1}, 0, 6, content='{"a": 1}')
    assert tokenize_yaml('1') == ScalarToken(1, 0, 0, content='1')
    assert tokenize_yaml('-1') == ScalarToken(-1, 0, 1, content='-1')
    assert tokenize_yaml('1.0') == ScalarToken(1.0, 0, 2, content='1.0')
    assert tokenize_yaml('-1.0') == ScalarToken(-1.0, 0, 3, content='-1.0')
    assert tokenize_yaml('"a"') == Scalar

# Generated at 2022-06-12 16:15:59.607085
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {"name": str, "age": int}
    )

    assert validate_yaml("name: Jane\nage: 25", schema) == ({"name": "Jane", "age": 25}, [])
    assert validate_yaml("{'name': 'Jane', 'age': 25}", schema) == ({"name": "Jane", "age": 25}, [])
    assert validate_yaml("Jane", schema) == (None, [Message("Invalid value.", "type_error", [])])

# Generated at 2022-06-12 16:16:10.830355
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("a") == ScalarToken("a", 0, 1, content="a")
    assert tokenize_yaml("1") == ScalarToken("1", 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken("1.0", 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken("true", 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken("false", 0, 5, content="false")


# Generated at 2022-06-12 16:16:22.740271
# Unit test for function validate_yaml
def test_validate_yaml():
    assert 1 == validate_yaml('{ "foo": "bar" }', Field(type="str"))[0]
    assert 0 == len(validate_yaml('{ "foo": "bar" }', Field(type="str"))[1])
    assert 1 == validate_yaml('[ 1,2]', Field(type="str"))[0]
    assert 0 == len(validate_yaml('[ 1,2]', Field(type="str"))[1])
    assert 1 == validate_yaml('[ 1,2]', Field(type="number"))[0]
    assert 0 == len(validate_yaml('[ 1,2]', Field(type="number"))[1])

# Generated at 2022-06-12 16:16:28.766051
# Unit test for function validate_yaml
def test_validate_yaml():
    import sys
    import os.path
    # Add parent directory to path to make test aware of other modules
    # in this project, both in test and src
    sys.path.append(os.path.join(os.path.dirname(__file__), os.path.pardir))
    from test_typesystem.test_fields import validate_type
    from test_typesystem.test_schemas import validate_schema
    from test_typesystem.test_fields import TestField
    from test_typesystem.test_schemas import TestSchema
    # Test basic types

# Generated at 2022-06-12 16:16:36.716831
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test single-line scalar
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, "foo")

    # Test multi-line scalar
    assert tokenize_yaml("foo\n") == ScalarToken("foo", 0, 3, "foo\n")

    # Test multi-line scalar with indentation
    assert (
        tokenize_yaml("foo\n  bar\n") == ScalarToken("foo\n  bar\n", 0, 10, "foo\n  bar\n")
    )

    # Test list
    assert (
        tokenize_yaml("[foo, bar]") == ListToken(["foo", "bar"], 0, 10, "[foo, bar]")
    )

    # Test list with multi-line value

# Generated at 2022-06-12 16:16:47.404659
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Int
    from typesystem.schemas import Schema
    from typesystem.types import String

    # the yaml.safe_load method can only be used in this way if it is allowed by the yaml
    # specification.  It is possible  to use the json module but we would then be limiting ourselves
    # to the specification in json rather than in yaml.
    class MySchema(Schema):
        a = String()
        b = Int()

    yaml_str = "a: abc\nb: 123\n"
    # value, messages = validate_yaml(yaml_str, MySchema)
    # assert value == {"a": "abc", "b": 123}
    # assert messages == []
    value, messages = validate_yaml(yaml_str, MySchema())
   

# Generated at 2022-06-12 16:16:59.569721
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """ test_tokenize_yaml - test tokenize_yaml function """
    content = """
    key1:
        - value1-1
        - value1-2
    key2:
        - value2-1
    """
    token = tokenize_yaml(content)
    # print("token=%s" % token)
    assert isinstance(token, DictToken)
    assert token.get("key1") is not None
    assert token.get("key2") is not None
    token_key1 = token.get("key1")
    assert isinstance(token_key1, ListToken)
    assert token_key1.start == 35
    assert token_key1.end == 70
    assert token_key1.get_position_in_content(23) == 20
    assert token_key1.get

# Generated at 2022-06-12 16:17:08.510460
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(type="string")
    assert validate_yaml("foo", field)[0] == "foo"
    assert validate_yaml(b"foo", field)[0] == "foo"
    assert len(validate_yaml("foo", field)[1]) == 0
    #
    assert validate_yaml("foo: bar", field)[0] == "foo: bar"
    assert len(validate_yaml("foo: bar", field)[1]) == 1
    assert (
        validate_yaml("foo: bar", field)[1][0].text
        == "Expected a scalar value, but got a dict."
    )
    assert (
        validate_yaml("foo: bar", field)[1][0].code
        == "expected_scalar_value_but_got_dict"
    )

# Generated at 2022-06-12 16:17:15.591516
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"integer": fields.Integer})
    content = "integer: badvalue"
    value, errors = validate_yaml(content, schema)
    assert errors == [
        typesystem.ValidationError(
            code="invalid_type",
            text="Expected {}, got {}.".format(schema.fields["integer"].type, str),
        ),
    ]

# Generated at 2022-06-12 16:17:25.551876
# Unit test for function validate_yaml
def test_validate_yaml():
    output = validate_yaml(
        content=
"""
categories:
    category:
      - 1
      - 2
      - 3
      - 4
      - 5
    category2:
      - 6
      - 7
      - 8
      - 9
      - 0
    category3:
      - true
      - false
""",
        validator=Schema(
            {
                "categories": Field(
                    {
                        "category": Field([Field(int), Field(["category2"])]), "category2": Field([Field(int)]), "category3": Field([Field(bool)])
                    }
                )
            }
        )
    )

# Generated at 2022-06-12 16:17:33.883521
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String

    # Test that validate_yaml works with a YAML string.
    value, errors = validate_yaml("foo", String())
    assert value == "foo"
    assert errors == []

    # Test that validate_yaml works with a YAML bytestring.
    value, errors = validate_yaml(b"foo", String())
    assert value == "foo"
    assert errors == []

    # Test that validate_yaml raises a ParseError on invalid YAML.
    with pytest.raises(ParseError):
        validate_yaml("{1: 2}", String())

# Generated at 2022-06-12 16:17:44.190427
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: test
    b: 2
    c:
        - 1
        - 2
        - 3
    d: '2020-06-10'
    """

    class TestSchema(Schema):
        a = fields.String()
        b = fields.Integer()
        c = fields.List(fields.Integer())
        d = fields.Date()

    result = validate_yaml(content, TestSchema)
    assert not result.is_valid()
    assert len(result.errors) == 1
    assert 'format' in result.errors[0]['code']



# Generated at 2022-06-12 16:17:52.729739
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.validators import Match

    class StarWarsPerson(Schema):
        name = String(max_length=100, validators=[Match(r"^\w+( \w+)*$")])
        age = String()
        job = String()

    errors = validate_yaml(  # type: ignore
        content=b"name: C3PO\nage: 150\njob: protocol droid\n",
        validator=StarWarsPerson,
    )
    assert errors == []


# Generated at 2022-06-12 16:18:02.034176
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from yaml.loader import SafeLoader
    from typesystem.schemas import Schema
    from typesystem.fields import String, Boolean, Field

    class YAMLTest(Schema):
        s = String()
        n = String(nullable=True)
        b = Boolean()
        i = Field(validate=lambda value: value == 123)

    assert validate_yaml(
        content=b'{"s": "foo"}', validator=Field(validate=lambda value: value == 123)
    ) == ({"s": "foo"}, [])


# Generated at 2022-06-12 16:18:07.234925
# Unit test for function validate_yaml
def test_validate_yaml():
    # Establish test case 1
    content1 = '''
    a: [2, 3]
    b: 2
    '''
    class ValidationTest1(Schema):
        a = Field(type=str)
        b = Field(type=str)
    valid1, mess1 = validate_yaml(content=content1, validator=ValidationTest1)
    # Set expected results with validation errors
    valid1_exp = None
    mess1_exp = [Message(
        text='Must be at least 1 characters.',
        code='min_length',
        state=FieldState(
            field=Field(type=str)
            ),
        position=Position(column_no=8, line_no=3, char_index=32),
        )]
    # Assert expected results
    assert valid1 == valid1_

# Generated at 2022-06-12 16:18:18.561601
# Unit test for function validate_yaml
def test_validate_yaml():
    print("Testing function 'validate_yaml'...")
    schema = Schema(
        title="Schema",
        fields=[
            Field(validator="integer", name="id"),
            Field(validator="string", name="title"),
            Field(validator="array", name="tags"),
        ],
    )

    schema.bind_object({
        "id": 1,
        "title": "Example document",
        "tags": [
            "example",
            "test",
        ],
    })

    # Valid YAML string:
    valid_input = b"---\nid: 1\ntitle: Example document\ntags:\n- example\n- test"


# Generated at 2022-06-12 16:18:29.884205
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Schema({"field": Field(str)})
    error_messages = []
    value, error_messages = validate_yaml(b"{field: value}", validator)
    assert not error_messages
    assert value == {"field": "value"}

    value, error_messages = validate_yaml(
        b"{field: value", validator
    )
    assert len(error_messages) == 1
    assert error_messages[0].position == Position(
        line_no=1, column_no=0, char_index=0
    )
    assert error_messages[0].code == "parse_error"
    assert error_messages[0].text == "could not find expected ':'."


# Generated at 2022-06-12 16:18:37.445274
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Schema([Field(type="integer", name="a")])
    assert validate_yaml("a: '5'", validator) == (
        None,
        [
            Message(
                text="Not a valid integer.",
                code="invalid_integer",
                position=Position(line_no=1, column_no=3, char_index=2),
            )
        ],
    )

    assert validate_yaml("a: 5", validator) == ({ "a": 5 }, [])


# Generated at 2022-06-12 16:18:44.244969
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.tokens import ScalarToken, Token

    class Person(Schema):
        name = String()

    person = Person(name='Sola')
    token = ScalarToken('Sola', 1, 1, content='Sola')
    value, errors = validate_with_positions(token, Person.name)
    assert value is 'Sola'
    assert errors is None

# Generated at 2022-06-12 16:18:49.944787
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        age = Integer(min_value=18)

    value, error_messages = validate_yaml(
        """
    name: John
    age: 13
    """,
        MySchema,
    )

    assert value == {"name": "John", "age": 13}
    assert error_messages == [
        Message(
            text="Must be greater than or equal to 18.",
            code="min_value",
            position=Position(line_no=3, column_no=6, char_index=16),
        )
    ]


# Generated at 2022-06-12 16:18:58.822360
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(name="foo", type="string")
    assert validate_yaml('foo: "string"', field) == ({"foo": '"string"'}, [])
    assert validate_yaml('''foo: "string"
bar: "string2"''', field) == ({"foo": '"string"', "bar": '"string2"'}, [])

    field2 = Field(name="bar", type=["string", "null"])
    assert validate_yaml('foo: "string"', field2) == ({"foo": '"string"'}, [])
    assert validate_yaml('foo: "string"', field2) == ({"foo": '"string"'}, [])

    field3 = Field(name="foo", type="string", pattern='^[A-Z]+$')

# Generated at 2022-06-12 16:19:07.635104
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type_=str, max_length=3)
    value, errors = validate_yaml(validator=validator, content='"abc"')
    assert value == "abc"
    assert errors is None
    value, errors = validate_yaml(validator=validator, content='"abcd"')
    assert value == "abcd"
    assert len(errors) == 1
    expected = [
        Message(text="Must have no more than 3 characters.", code="max_length")
    ]
    assert errors == expected

# Generated at 2022-06-12 16:19:18.218893
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        import yaml
        from yaml.loader import SafeLoader
    except ImportError:  # pragma: no cover
        yaml = None  # type: ignore
        SafeLoader = None  # type: ignore

    if yaml is None:
        return

    assert yaml is not None, "'pyyaml' must be installed."

    class CustomSafeLoader(SafeLoader):
        pass

    def construct_mapping(loader: "yaml.Loader", node: "yaml.Node") -> DictToken:
        start = node.start_mark.index
        end = node.end_mark.index
        mapping = loader.construct_mapping(node)
        return DictToken(mapping, start, end - 1, content=str_content)


# Generated at 2022-06-12 16:19:25.244745
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
            name: Jim
            age: 12
            booleans:
                - true
                - false
                - false
                - true
        """
    validator = Schema({
        "name": str,
        "age": int,
        "booleans": [bool]
    })
    result, error_messages = validate_yaml(content=content, validator=validator)
    assert not error_messages, "Should not be any errors"
    assert result["name"] == "Jim"
    assert result["age"] == 12
    assert result["booleans"] == [True, False, False, True]

    content = """
            name: Jim
            age: 12
            booleans:
                - true
                - false
                - false
        """

# Generated at 2022-06-12 16:19:26.849021
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

# Generated at 2022-06-12 16:19:41.102328
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        import yaml
    except ImportError:  # pragma: no cover
        pytest.skip("YAML not installed")

    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema

    content = yaml.safe_load(
        """
        first_name: 'Anne'
        age: null
        last_name: 'Doe'
        height: null
        """
    )

    token = tokenize_yaml(content)
    schema = Schema(
        {
            "first_name": String(),
            "last_name": String(),
            "age": Integer(),
            "height": Integer(),
        }
    )

    value, errors = validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-12 16:19:49.227513
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"name": Field(type="string")})
    assert validate_yaml(b"name: Alice", validator=schema) == ({}, [])
    assert set(validate_yaml(b"name: 123", validator=schema)) == {
        ({}, [Message(text="Must be a str.", code="invalid_type"),]),
        ([Message(text="Must be a str.", code="invalid_type"),], {}),
    }



# Generated at 2022-06-12 16:20:00.590676
# Unit test for function validate_yaml
def test_validate_yaml():
    dataset = []
    dataset.append(('{"hello": "world"}', '{"hello": "world"}', False, '{{{}}}'.format('""')))
    dataset.append(('{"hello": "world"}', '{"hello": "world"}', True, '{{{}}}'.format('""')))
    dataset.append(('{"hello": "world"}', '{"hello": "world"}', False, '{{{}}}'.format('"', "", '"')))
    dataset.append(('{"hello": "world"}', '{"hello": "world"}', True, '{{{}}}'.format('"', "", '"')))
    for d in dataset:
        content, value, should_fail, schema_string = d
        schema = Schema.parse_string(schema_string)

# Generated at 2022-06-12 16:20:07.379438
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test function validate_yaml."""
    from pprint import pprint

    from typesystem import String, Number, Field, Integer, Schema, Choice

    class ExampleSchema(Schema):
        """
        Example schema for testing YAML tokenization and validation.
        """

        name = String()
        age = Integer()
        weight = Number()
        favorite_food = Choice(options=["pizza", "tacos", "ice_cream"])
        employed = Boolean()

    yaml_string = """
    name: Pete
    age: 20
    weight: 180.1
    favorite_food: pizza
    employed: true
    """
    

# Generated at 2022-06-12 16:20:15.229538
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_string = '''
        a:
          - 1
          - 2
        b: 3
    '''
    token = tokenize_yaml(yaml_string)
    assert token.start_pos == 0
    assert token.end_pos == 38
    assert token.value['a'] == [ScalarToken(1, 10, 11), ScalarToken(2, 16, 17)]
    assert token.value['b'] == ScalarToken(3, 23, 24)



# Generated at 2022-06-12 16:20:25.328559
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test scalar value
    result = tokenize_yaml("Hello world")
    assert isinstance(result, ScalarToken)
    assert result.value == "Hello world"

    # Test list value
    result = tokenize_yaml("- Hello\n- World")
    assert isinstance(result, ListToken)
    assert result.value[0] == "Hello"
    assert result.value[1] == "World"

    # Test dict value
    result = tokenize_yaml("Hello: World")
    assert isinstance(result, DictToken)
    assert result.value["Hello"] == "World"

    # Test nested values
    result = tokenize_yaml("key: value\nlist:\n- 1\n- 2\ndict:\n  key: value")
    assert isinstance(result, DictToken)

# Generated at 2022-06-12 16:20:33.425931
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        foo = String()
        bar = String(required=False)

    value, errors = validate_yaml(
        content="""
        foo: hello world
        """,
        validator=TestSchema,
    )
    assert value == {"foo": "hello world"}
    assert not errors

# Generated at 2022-06-12 16:20:38.914733
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schema import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()

    schema = MySchema()
    errors = validate_yaml(content=b'name: Mark\nage: "30"', validator=schema)

    assert errors.list() == [
        {
            "code": "invalid",
            "message": "Enter a whole number.",
            "field": "age",
            "positions": [{"column_no": 5, "line_no": 2, "char_index": 11}],
        }
    ]



# Generated at 2022-06-12 16:20:48.781817
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = field.String(max_length=30)
        nickname = field.String(max_length=20)

    content = """
    name: "James"
    nickname: "Jim"
    """

    schema = MySchema()
    result = validate_yaml(content, schema)
    assert result == ({"name": "James", "nickname": "Jim"}, [])

    content = """
    name: "James and Michael"
    nickname: "Jim"
    """

    schema = MySchema()
    result = validate_yaml(content, schema)

# Generated at 2022-06-12 16:20:59.854989
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem_yaml

    def test_validate_yaml(validator=None, type_="validation"):
        with open("tests/sample.yml") as fp:
            data = fp.read()
        if validator is None:
            validator = typesystem_yaml.Schema.from_string(data)
        value, errors = typesystem_yaml.validate_yaml(data, validator)
        assert value is not None
        assert not errors
        return errors

    def test_validate_yaml_bad_type(validator=None, type_="validation", errors=None):
        with open("tests/sample.yml") as fp:
            data = fp.read()

# Generated at 2022-06-12 16:21:11.203446
# Unit test for function validate_yaml
def test_validate_yaml():
    # Arrange
    content = '''
    name: Test
    age:  10
    '''
    class TestSchema(Schema):
        name = String()
        age = Int()

    # Act
    value, errors = validate_yaml(content, TestSchema)

    # Assert
    assert errors == []
    assert value == {'name': 'Test', 'age': 10}



# Generated at 2022-06-12 16:21:21.202795
# Unit test for function validate_yaml
def test_validate_yaml():
    class Post(Schema):
        title = String(max_length=100)
        body = String(field_type="text")


# Generated at 2022-06-12 16:21:24.177409
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '{"foo": "bar"}'
    validator = Field(type="object", required=["foo"])
    value = validate_yaml(content, validator)
    assert value[0] == {"foo": "bar"}
    assert not value[1]

# Generated at 2022-06-12 16:21:30.497477
# Unit test for function validate_yaml
def test_validate_yaml():
    # Case: Successful validation with no errors
    class MySchema(Schema):
        foo = Field(type="integer")
        bar = Field(type="string")

    content = """
foo: 123
bar: abc
    """
    value, errors = validate_yaml(content, validator=MySchema)
    assert errors == []
    assert value == {"foo": 123, "bar": "abc"}
    assert type(value["foo"]) is int
    assert type(value["bar"]) is str

    # Case: Successful validation with no errors, using key/value as string
    class MySchema2(Schema):
        foo = Field(type="integer")
        bar = Field(type="string")

    content = """
'foo': 123
'bar': abc
    """
    value, errors = validate_

# Generated at 2022-06-12 16:21:37.630810
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a:
        b:
            c:
                d:
                  - 1
                  - 2
    """
    schema = Schema(
        a=Field(
            properties=dict(
                b=Field(
                    properties=dict(
                        c=Field(properties=dict(d=Field(list_of=Field(int, min_length=2)))),
                    )
                )
            )
        )
    )
    value, error_messages = validate_yaml(content, schema)
    assert len(error_messages) == 1
    assert error_messages[0].text == "Length must be at least 2."
    assert error_messages[0].code == "min_length"
    assert error_messages[0].position.line_no == 4

# Generated at 2022-06-12 16:21:47.391848
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        test = Field(str, description="test-description")
        test2 = Field(str, description="test2-description")

    content = '''test: this value is too long
test2: "test2"'''

    errors = validate_yaml(content, TestSchema())


# Generated at 2022-06-12 16:21:49.683320
# Unit test for function validate_yaml
def test_validate_yaml():
    content = yaml.load("-1")
    validator = Field(type=int)
    value, errors = validate_yaml(content, validator)

# Generated at 2022-06-12 16:22:00.612853
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Strin, Integer, Boolean
    from typesystem.schemas import Schema

    class TodoSchema(Schema):
        title = Strin
        done = Boolean
        quantity = Integer(required=False)

    content = "title: Buy milk\ndone: No\n"
    value, errors = validate_yaml(content, validator=TodoSchema)

    assert value == {"title": "Buy milk", "done": False, "quantity": None}
    assert isinstance(errors, list)
    assert len(errors) == 1

    error = errors[0]
    assert isinstance(error, Message)
    assert error.text == "Missing value for quantity."
    assert error.code == "required"
    assert error.position.line_no == 2

# Generated at 2022-06-12 16:22:03.080986
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(required=True, type=int)
    result = validate_yaml(b"21\n", validator)
    assert result == (21, [])



# Generated at 2022-06-12 16:22:12.981172
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "test"

    class TestSchema(Schema):
        title = Field(required=True)
        description = Field(required=True)
        properties = Field(required=True)

    schema = TestSchema()
    value, messages = validate_yaml(
        {
            "title": "Simple API",
            "description": "Sample API using Typesystem",
            "properties": {
                "a": {
                    "type": "string",
                    "title": "A",
                    "description": "A property",
                    "enum": ["a", "b"],
                }
            },
        },
        schema,
    )
