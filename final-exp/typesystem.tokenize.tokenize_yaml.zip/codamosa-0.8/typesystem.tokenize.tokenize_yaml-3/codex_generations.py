

# Generated at 2022-06-12 16:12:36.835474
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import Boolean, String
    from typesystem.schemas import Schema

    class SimpleSchema(Schema):
        field1 = Boolean()
        field2 = String()

    simple_schema = SimpleSchema()

    content = '''field1: False\nfield2: "string"'''
    decoded, error_messages = validate_yaml(content, simple_schema)
    expected_error_messages = []
    assert decoded == {'field1': False, 'field2': 'string'}
    assert error_messages == expected_error_messages

    content = '''field1: None\nfield2: "string"'''
    decoded, error_messages = validate_yaml(content, simple_schema)

# Generated at 2022-06-12 16:12:46.833722
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, DateTime, Float, Boolean

    class AddressSchema(Schema):
        city = String(max_length=30)
        state = String(max_length=2)

    class EventSchema(Schema):
        name = String(max_length=50, min_length=1)
        venue = String(max_length=50)
        event_time = DateTime()
        num_attendees = Integer(minimum=3)
        is_private = Boolean()
        address = AddressSchema()


# Generated at 2022-06-12 16:12:59.092660
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert len(tokenize_yaml("  ")) == 0
    assert len(tokenize_yaml("a: b")) == 1
    assert isinstance(tokenize_yaml("a: b"), DictToken)
    assert len(tokenize_yaml("  a: b  ")) == 1
    assert len(tokenize_yaml("  - a  ")) == 1
    assert isinstance(tokenize_yaml("  - a  "), ListToken)
    assert (
        str(tokenize_yaml("  - a  "))
        == "[ListToken start=2 end=4 value=['a'] content='  - a  ']"
    )

# Generated at 2022-06-12 16:13:07.207027
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Schema({"foo": "integer"})
    value, error_messages = validate_yaml("foo: foo", validator)
    assert error_messages[0].text == "Must be of type 'integer'."
    assert (
        error_messages[0].position.line_no
        == error_messages[0].position.end_line_no
        == 1
    )
    assert (
        error_messages[0].position.column_no
        == error_messages[0].position.end_column_no
        == 5
    )
    assert error_messages[0].position.char_index == 4

# Generated at 2022-06-12 16:13:16.820499
# Unit test for function validate_yaml
def test_validate_yaml():
    class MessageSchema(Schema):
        subject = Field(validators=["required", "min_length:5"])
        body = Field(validators=["max_length:200"])
        language = Field(validators=["one_of:['en', 'fr']"])

    content = """
        subject: Welcome to the site
        body: Hello, this is some yaml!
        language: en
    """

    result = validate_yaml(content, validator=MessageSchema)
    assert result[0] == {
        "subject": "Welcome to the site",
        "body": "Hello, this is some yaml!",
        "language": "en",
    }

# Generated at 2022-06-12 16:13:23.964692
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '{"a":"test"}'
    validator = Schema.of(
        {
            "a": Field(str, description="a test field", required=True),
            "b": Field(str, description="a test field", required=True),
        }
    )

    value, errors = validate_yaml(content, validator)
    assert errors == [
        {
            "code": "required_field",
            "message": "Field 'b' is required.",
            "field": "b",
            "position": Position(char_index=9, line_no=1, column_no=10),
        }
    ]



# Generated at 2022-06-12 16:13:34.437169
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
foo:
    bar: baz
    bar2: "qux"
    bar3: 1234
    bar4: true
    bar5: null
    bar6:
        - item1
        - item2
    bar7:
        - bar8: 1
        - bar9: 2
    bar10:
    -
        item1:
            item2:
                item3: 1234
                item4: "something"
            item5: [1, 2, 3, 4]
        item6:
            - 1234
            - "somthing"
            - true
            - null
            -
                - item1
                - item2
        item7:
            item8: 1
            item9: 2
    bar11: !<tag:yaml.org,2002:str> 123
"""

# Generated at 2022-06-12 16:13:46.549713
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Unit test for function validate_yaml
    """
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    # Basic validation
    content = "string: string"
    schema = {"string": String()}
    value, error_messages = validate_yaml(content, schema)
    assert not error_messages
    assert value == {"string": "string"}

    # Validation error
    content = "string: 123"
    schema = {"string": String()}
    value, error_messages = validate_yaml(content, schema)
    assert len(error_messages) == 1
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 9
    assert error_messages[0].position

# Generated at 2022-06-12 16:13:51.500733
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    try:
        value, error_messages = validate_yaml(content, Field(type='number'))
    except Exception as e:
        print(e)
    print(value)
    print(error_messages)

# Generated at 2022-06-12 16:13:57.492334
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=120)

    content = "name: James\nage: 27"
    person, error_messages = validate_yaml(content, Person)
    assert error_messages == []
    assert person.name == "James"
    assert person.age == 27

# Generated at 2022-06-12 16:14:10.280600
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    good_content = """
        name: 'bear'
        age: 42
        hungry: true
    """
    bad_content = """
        name: 'bear'
        age: 'forty-two'
        hungry: true
    """

    class Bear(Schema):
        name = String()
        age = String()
        hungry = String()

    value, errors = validate_yaml(good_content, Bear)
    assert isinstance(errors, dict)
    assert len(errors) == 0

    value, errors = validate_yaml(bad_content, Bear)
    assert isinstance(errors, dict)
    assert len(errors) == 1

    error = errors["age"]
    assert isinstance(error, ValidationError)
    assert error.code == "type_error.string"

# Generated at 2022-06-12 16:14:21.117811
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_string = """
    -   name: Anshuman
        age: 26
    -   name: Dev
        age: 20
    """
    yaml_values, errors = validate_yaml(yaml_string, Field(type="list")(
                                            Field(type="dict")(
                                                name=Field(type="string"),
                                                age=Field(type="integer")
                                            )
                                        )
                                    )
    assert yaml_values == [
                            {
                                "name": "Anshuman",
                                "age": 26
                            },
                            {
                                "name": "Dev",
                                "age": 20
                            }
                        ]
    assert errors == []

# Generated at 2022-06-12 16:14:31.013110
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = "Person"
        fields = [
            {"key": "name", "type": "text"},
            {"key": "age", "type": "integer"},
            {"key": "hobbies", "type": "array", "items": {"type": "text"}},
        ]

    schema = PersonSchema()
    yaml_str = """
        name: John
        age: 27
        hobbies:
        - hiking
        - swimming
        - climbing
    """
    value, error_messages = validate_yaml(yaml_str, schema)
    assert len(error_messages) == 0
    assert value == {
        "name": "John",
        "age": 27,
        "hobbies": ["hiking", "swimming", "climbing"],
    }


# Generated at 2022-06-12 16:14:43.515443
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test validation success.
    content = """name: Mike
age: 35
is_alive: yes
pet:
  name: Lazy
  type: cat
"""

    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        is_alive = Field(type="boolean")
        pet = Field(type="object")
        pets = Field(type="array", items=Field(type="string"))
        favorite_colors = Field(type="array", items=Field(type="string"))

    class PetSchema(Schema):
        name = Field(type="string")
        type = Field(type="string")

    schema = PersonSchema()
    schema.fields["pet"] = PetSchema()


# Generated at 2022-06-12 16:14:54.983455
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None

    def assert_errors(
        content: str,
        validator: typing.Union[Field, typing.Type[Schema]],
        expected_errors: typing.List[ValidationError],
    ) -> None:
        if isinstance(validator, Field):
            value, actual_errors = validator.validate(content, context={"mode": "yaml"})
        else:
            value, actual_errors = validate_yaml(content, validator)
        assert actual_errors == expected_errors

    # Test simple JSON -> YAML conversion.
    assert_errors(
        '{"foo": "bar"}',
        Schema({"foo": str}),
        [],
    )

    # Test basic YAML parsing.

# Generated at 2022-06-12 16:14:59.472063
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = fields.String(required=True)
        age = fields.Number(required=True)

    content = 'name: "John"\nage: 10'
    value, errors = validate_yaml(content, Person)

    assert not errors
    assert value == {"name": "John", "age": 10}

# Generated at 2022-06-12 16:15:10.593937
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Boolean, Integer, Object, String
    from typesystem import ValidationError
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    class Book(Schema):
        title = String()
        author = Object(Person)

    book_yaml = """
    title: Pride and Prejudice
    author:
        name: Jane Austen
        age: 50
    """

    value, errors = validate_yaml(book_yaml, Book)
    assert value == {
        "title": "Pride and Prejudice",
        "author": {"name": "Jane Austen", "age": 50},
    }
    assert not errors
    value, errors = validate_yaml(book_yaml, Book())

# Generated at 2022-06-12 16:15:16.971267
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_str = '''
    id: 1
    name: "Foo"
    '''
    class Person(Schema):
        id = fields.Integer()
        name = fields.String(max_length=10)

    value, errors = validate_yaml(yaml_str, Person)
    assert value is not None
    assert errors is None


# Generated at 2022-06-12 16:15:23.474065
# Unit test for function validate_yaml
def test_validate_yaml():
    from yaml import load, dump
    content = """
a: 1
b: 2
c: 3
"""
    schema = Schema([
        Field('a'),
        Field('b', validators=[lambda v: v >= 10]),
        Field('c'),
    ])
    output = validate_yaml(content, schema)
    # check for error
    assert len(output[1]) == 1
    assert "b must be greater than or equal to 10" in str(output[1][0])



# Generated at 2022-06-12 16:15:34.259106
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    schema = Schema({"name": String(), "age": Integer()})

    value, errors = validate_yaml(
        """
    name: "John"
    age: 21
    """,
        schema,
    )
    assert value == {"name": "John", "age": 21}
    assert len(errors) == 0

    value, errors = validate_yaml(
        """
    name: "John"
    age: 21
    """,
        schema,
    )
    assert value == {"name": "John", "age": 21}
    assert len(errors) == 0

    value, errors = validate_yaml(
        """
    name: John
    """,
        schema,
    )

# Generated at 2022-06-12 16:15:48.589825
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {
            "id": Integer(),
            "name": String(),
            "is_active": Boolean(),
            "nested": {
                "id": Integer(),
                "bool_value": Boolean(),
                "list_values": [{
                    "id": Integer(),
                    "boolean_value": Boolean(),
                }],
            },
        }
    )

    yaml_content = """
    id: 'invalid'
    name: 'Some name'
    is_active: 'This is not a valid boolean'
    nested:
      id: 'invalid'
      bool_value: 'This is not a valid boolean'
      list_values:
        - {id: 'string'}
        - {id: 1, boolean_value: 'This is not a valid boolean'}
    """



# Generated at 2022-06-12 16:15:57.953239
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Scalar tokens
    assert tokenize_yaml("'Hello'") == ScalarToken("Hello", start=0, end=6)
    assert tokenize_yaml("5") == ScalarToken(5, start=0, end=1)
    assert tokenize_yaml("5.5") == ScalarToken(5.5, start=0, end=3)

    # Dict tokens
    assert tokenize_yaml("{}") == DictToken(dict(), start=0, end=1)
    assert tokenize_yaml("{ hello: world }") == DictToken(
        {"hello": "world"}, start=0, end=16
    )

    # List tokens
    assert tokenize_yaml("[]") == ListToken([], start=0, end=1)

# Generated at 2022-06-12 16:16:09.352728
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import (
        Boolean,
        Enum,
        Integer,
        Number,
        String,
    )
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import PositionError
    from typesystem.tokenize.tokens import ScalarToken
    import pytest
    import yaml

    def make_yaml_token_string(value, **kwargs):
        scalar = ScalarToken(value=value, **kwargs)
        token = tokenize_yaml(yaml.dump(scalar))
        return token

    def make_yaml_token_list(values, **kwargs):
        scalars = [ScalarToken(value=value) for value in values]

# Generated at 2022-06-12 16:16:15.208846
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    An example test function
    """
    class MySchema(Schema):
        text = String(required=True)
        number = Integer()
        date = DateTime()
    validator = MySchema
    content = "text: 'something'"
    (value, error) = validate_yaml(content, validator)
    assert error == []
    return True

# Generated at 2022-06-12 16:16:26.536340
# Unit test for function validate_yaml
def test_validate_yaml():
    # Valid YAML string
    content = """
    id: 1
    title: Test
    """
    token = tokenize_yaml(content)
    class TestSchema(Schema):
        id = Integer()
        title = String()
    value, errors = validate_with_positions(token=token, validator=TestSchema)
    assert value == {'id': 1, 'title': 'Test'}
    assert errors == []

    # Invalid YAML string
    content = """
    id: '1'
    title: Test
    """
    token = tokenize_yaml(content)
    value, errors = validate_with_positions(token=token, validator=TestSchema)
    assert value == {}

# Generated at 2022-06-12 16:16:33.924552
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: 'Taco'"
    assert yaml is not None, "'pyyaml' must be installed."
    print("Using yaml to parse")
    token = tokenize_yaml(content)
    print("Yaml output %s" % token)
    print("pytest.get_content %s " % content)
    print("Yaml output %s" % token)
    print("Yaml output %s" % token)
    print("Yaml output %s" % token)
    print("Yaml output %s" % token)
    print("Yaml output %s" % token)

# Generated at 2022-06-12 16:16:44.749554
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer
    from typesystem.schemas import Schema

    class User(Schema):
        id = Integer(description="User ID")
        name = Integer(description="User name")

    # Create schema
    schema = User()

    # Create content
    yaml_content = """
    id: 123
    name: "name"
    """

    # Validate content
    content, errors = validate_yaml(content=yaml_content, validator=schema)
    assert len(errors) == 1
    assert errors[0].type == "type"
    assert errors[0].path == [
        "name",
    ]
    assert errors[0].code == "invalid_type"



# Generated at 2022-06-12 16:16:57.058601
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = str
        age = int
        height = float
        ok = bool
        null = None

    content = """
    name: greg
    age: 34
    height: 1.82
    ok: True
    null: None
    """
    value, error_messages = validate_yaml(content, TestSchema)
    assert value == {
        "name": "greg",
        "age": 34,
        "height": 1.82,
        "ok": True,
        "null": None,
    }
    assert error_messages == []

    content = """
    name: greg
    age: 34
    height: 1.82
    ok: True
    """
    value, error_messages = validate_yaml(content, TestSchema)
   

# Generated at 2022-06-12 16:17:06.886088
# Unit test for function validate_yaml
def test_validate_yaml():
    # test if work for valid input
    input_yaml = """
tal:
  tal2:
    tal3: 1
"""
    validator = Schema(fields={"tal": Field(type="object", fields={"tal2": Field(type="object", fields={"tal3": Field(type="integer")})})})
    assert validate_yaml(input_yaml, validator) == ({"tal": {"tal2": {"tal3": 1}}}, [])

    # test if work for invalid input
    input_yaml = """
tal:
  tal2:
    tal3: 1
    tal4: 1
"""
    validator = Schema(fields={"tal": Field(type="object", fields={"tal2": Field(type="object", fields={"tal3": Field(type="integer")})})})
   

# Generated at 2022-06-12 16:17:14.175665
# Unit test for function validate_yaml
def test_validate_yaml():
    """ Unit test for function validate_yaml
    """
    from typesystem import String, Integer, Float, Schema
    from typesystem.fields import Array

    class PersonSchema(Schema):
        """ Person Schema
        """
        name = String()
        age = Integer(minimum=0, maximum=100)
        height = Float(exclusiveMaximum=200)
        children = Array(String)

    message = """
        name: Jane
        age: 25
        height: 1.7
        children:
          - John
          - Maria
    """

    value, error_messages = validate_yaml(message, PersonSchema)
    assert value == {
        "name": "Jane",
        "age": 25,
        "height": 1.7,
        "children": ["John", "Maria"],
    }

# Generated at 2022-06-12 16:17:25.184986
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Field(fields={'a':Field(type_hint=int), 'b':Field(type_hint=int)})
    yml = 'a: 1 \nb: 2'
    value, error_messages = validate_yaml(content=yml, validator=schema)
    assert not error_messages
    assert value == {'a':1, 'b':2}
    yml = 'a: 1 \n\n\nb: 2'
    value, error_messages = validate_yaml(content=yml, validator=schema)
    assert not error_messages
    assert value == {'a':1, 'b':2}

# Generated at 2022-06-12 16:17:35.003916
# Unit test for function validate_yaml
def test_validate_yaml():

    # Test that an exception is thrown on an empty string
    with pytest.raises(ParseError):
        validate_yaml("", Field)

    # Test that the right number of errors are returned
    (value, errors) = validate_yaml("foo", str)
    assert 0 == len(errors)

    (value, errors) = validate_yaml("1", Field)
    assert 1 == len(errors)

    (value, errors) = validate_yaml("'foo'", Field)
    assert 1 == len(errors)

    (value, errors) = validate_yaml("foo", Field)
    assert 1 == len(errors)

    (value, errors) = validate_yaml("[1, 'a']", Field)
    assert 1 == len(errors)

    # Test that a parse error is returned on an unexpected token


# Generated at 2022-06-12 16:17:42.009616
# Unit test for function validate_yaml
def test_validate_yaml():
    class XSchema(Schema):
        foo = Integer()

    data = '''
    foo: x
    '''

    value, errors = validate_yaml(data, XSchema)

    assert value is None
    assert len(errors) == 1
    assert errors[0].text == "Expected type 'integer' for value 'x'."
    assert errors[0].code == "invalid"



# Generated at 2022-06-12 16:17:51.207279
# Unit test for function validate_yaml
def test_validate_yaml():
    my_schema = Schema(fields={"name": Field(type="string", max_length=100)})
    valid_yaml = b"""
    ---
    name: Jane Doe
    """

    value, error_messages = validate_yaml(  # type: ignore
        content=valid_yaml, validator=my_schema
    )

    assert value == {"name": "Jane Doe"}
    assert len(error_messages) == 0

    invalid_yaml = b"""
    ---
    name: Jane Doe
    """
    my_schema = Schema(fields={"name": Field(type="string", max_length=1)})
    value, error_messages = validate_yaml(  # type: ignore
        content=invalid_yaml, validator=my_schema
    )



# Generated at 2022-06-12 16:17:55.538654
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    tokenize_yaml('James')
    tokenize_yaml(['James'])
    tokenize_yaml({"name": "James"})
    tokenize_yaml({"name": "James", "grade": 12})
    tokenize_yaml([{'name':'James'}, {'name':'Megan'}])



# Generated at 2022-06-12 16:17:59.507726
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = String()

    content = "name: kim"
    value, messages = validate_yaml(content, MySchema)
    assert len(messages) == 0
    assert value == {"name":"kim"}



# Generated at 2022-06-12 16:18:05.940807
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=15)

    content = """
    {name: 'Mary', age: 17}
    """
    (value, messages) = validate_yaml(content, Person)
    assert value == {"name": "Mary", "age": 17}
    assert len(messages) == 0

    content = """
    {name: 'Mary', age: 17}
    """
    (value, messages) = validate_yaml(content, Person)
    assert value == {"name": "Mary", "age": 17}

    content = """
    {name: 'Mary', age: '17'}
    """
    (value, messages) = validate_yaml(content, Person)

# Generated at 2022-06-12 16:18:16.577491
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        first_name = fields.String(max_length=100)
        last_name = fields.String(max_length=100)
        age = fields.Integer()
        height = fields.Float()

    validator = Person()

    content = """
        first_name: Jesse
        last_name: Jiryu Davis
        age: 29
        height: 1.75
    """
    value, error_messages = validate_yaml(content, validator)

    assert error_messages == []
    assert value == {
        "first_name": "Jesse",
        "last_name": "Jiryu Davis",
        "age": 29,
        "height": 1.75,
    }


# Generated at 2022-06-12 16:18:28.794130
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        foo=Field(type="integer"),
        bar=Field(type="string"),
    )

    result = validate_yaml("""\
foo: 123
bar: abc
""", schema)
    assert result == ({"foo": 123, "bar": "abc"}, [])

    result = validate_yaml("""\
foo: 123
bar: 123
""", schema)
    assert result == (
        {"foo": 123, "bar": 123},
        [
            ValidationError(
                text="Invalid value, expected <class 'str'>.",
                code="invalid",
                path=["bar"],
            )
        ],
    )

    result = validate_yaml("""\
foo: true
bar: abc
""", schema)

# Generated at 2022-06-12 16:18:36.894246
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml

    class TestSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True)

    valid_data = 'name: Roger\nage: 17'
    invalid_data = 'name: Roger\nage: "seventeen"'

    assert type(TestSchema.validate_yaml(valid_data)) is TestSchema

    assert not (TestSchema.validate_yaml(invalid_data) is None)

    assert (TestSchema.validate_yaml(invalid_data)[0] ==
            yaml.parse(valid_data, Loader=yaml.FullLoader))

    assert (type(TestSchema.validate_yaml(invalid_data)[1][0])
            is typesystem.validators.IntegerValidator)

# Generated at 2022-06-12 16:18:43.763081
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '{"name":"John"}'
    token = tokenize_yaml(content)
    ret = validate_with_positions(token=token, validator=Schema({"name": str}))
    assert type(ret[0]) == dict and ret[0]["name"] == "John"
    assert len(ret[1]) == 0



# Generated at 2022-06-12 16:18:54.764283
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = Field(format="email")
        range = Field(type="integer", minimum=10, maximum=20)

    data_to_validate = """
        name: "invalid email"
        range: 5
        """

    value, error_messages = validate_yaml(
        content=data_to_validate, validator=TestSchema
    )

    assert value is None

    assert isinstance(error_messages, Message)

# Generated at 2022-06-12 16:18:58.885993
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    A validator must be instantiated.
    """
    try:
        validate_yaml(
            """
            # This is a comment.
            valid_yaml:
                foo: bar
            """,
            Field(type=str),
        )
    except Exception as e:
        assert type(e) is Exception
    else:
        assert False, "Should raise exception"


# Generated at 2022-06-12 16:19:10.687073
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Number
    from typesystem.types import StringType, NumberType
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = StringType()
        age = NumberType()

    value, error_messages = validate_yaml(
        content="""
            name: Peter
            age: 35
        """,
        validator=MySchema,
    )
    assert value == {"name": "Peter", "age": 35}
    assert error_messages == []

    value, error_messages = validate_yaml(
        content="""
            name: Peter
            age: 35,5
        """,
        validator=MySchema,
    )

# Generated at 2022-06-12 16:19:20.930000
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    - 1
    - [2, 3, 4]
    -
      - 5
      - 6
      - 7
    '''
    validator = ListToken().of(
        [
            ScalarToken().of(int),
            ListToken().of(
                [ScalarToken().of(int), ScalarToken().of(int), ScalarToken().of(int)]
            ),
            ListToken().of(
                [
                    ScalarToken().of(int),
                    ScalarToken().of(int),
                    ScalarToken().of(int),
                ]
            ),
        ]
    )
    assert validate_yaml(content, validator) == ([1, [2, 3, 4], [5, 6, 7]], [])


# Generated at 2022-06-12 16:19:31.846210
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"foo: bar"
    result = validate_yaml(content, Field(type="string"))
    assert result == (u'bar', [])

    content = b"foo: 1"
    result = validate_yaml(content, Field(type="string"))
    assert str(result[1][0]) == 'Invalid value.\n\nExpected a string value, but got {1}.'

    content = b"foo: bar"
    result = validate_yaml(content, Field(type="string", max_length=2))
    assert str(result[1][0]) == 'Invalid value.\n\nValue must not be longer than 2 characters, but got {3}.'

# Generated at 2022-06-12 16:19:42.775530
# Unit test for function validate_yaml
def test_validate_yaml():
    content = (
        '---\n'
        '{}\n'
        '- b\n'
        '- b1\n'
        '- c\n'
        '...\n'
    )
    from typesystem import Schema, fields
    from typesystem import ParseError, ValidationError

    class AnimalSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True)
        species = fields.String(required=True)

    class ZooSchema(Schema):
        animals = fields.Array(
            items=AnimalSchema
        )

    try:
        validate_yaml(
            content=content, validator=ZooSchema
        )
    except (ParseError, ValidationError) as exc:
        messages = exc.mess

# Generated at 2022-06-12 16:19:53.931579
# Unit test for function validate_yaml
def test_validate_yaml():
    # validator
    class TestSchema(Schema):
        title = Field(str, pattern=r"^[a-z]+$")
        age = Field(int)

    content = """
        title: ""
        age: ~
        """
    value, errors = validate_yaml(content, TestSchema)
    assert value is None

# Generated at 2022-06-12 16:20:04.199856
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class CustomDictToken(DictToken):
        def __init__(self, mapping, start, end, content):
            super().__init__(mapping, start, end, content=content)

        @property
        def _child_tokens(self) -> typing.List[Token]:
            return [v for v in self.value.values()]

    def construct_mapping(loader: "yaml.Loader", node: "yaml.Node") -> CustomDictToken:
        mapping = loader.construct_mapping(node)
        start = node.start_mark.index
        end = node.end_mark.index
        return CustomDictToken(mapping, start, end, content="")

    class CustomLoader(SafeLoader):
        pass



# Generated at 2022-06-12 16:20:07.914029
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type="integer")
    content = "10"
    value, error_messages = validate_yaml(content, validator)
    assert value == 10
    assert error_messages is None


# Generated at 2022-06-12 16:20:20.308401
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer

    value, errors = validate_yaml(
        content="""
        - 1
        - 2
        - 3
    """,
        validator=Integer(),
    )
    assert value == [1, 2, 3]
    assert errors == []

    value, errors = validate_yaml(
        content="""
        - "1"
        - 2
        - 3
    """,
        validator=Integer(),
    )
    assert value is None

    assert errors[0].text == 'Invalid type, expected "int" but received "str".'
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 3



# Generated at 2022-06-12 16:20:28.341625
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.tokens import DictToken, ScalarToken
    from typesystem.tokenize.tokens import Token, ListToken

    content = '''
    ---
    v1:
        value: "World"
    v2:
        value:
            - "Hello"
            - "World"
    '''
    tokens = tokenize_yaml(content)
    assert isinstance(tokens, DictToken)
    assert tokens.content == content

    content = '''
    ---
    v1:
        value: "World"
    v2:
        value:
            - "Hello"
            - "World"
    '''
    tokens = tokenize_yaml(content)
    assert isinstance(tokens, DictToken)
    assert tokens.content == content

    content

# Generated at 2022-06-12 16:20:34.521992
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '{"title": "foo"}'
    class MySchema(Schema):
        title = "string"
    validator = MySchema

    value, error_messages = validate_yaml(content, validator)

    assert value == {'title': 'foo'}, 'should be the same'
    assert len(error_messages) == 0, 'should be the same'


# Generated at 2022-06-12 16:20:39.306887
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Boolean, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        bool_field = Boolean()
        int_field = Integer()

    data = """
    bool_field: true
    int_field: 10
    """

    assert validate_yaml(data, MySchema) == ({"bool_field": True, "int_field": 10}, [])
    assert validate_yaml(data, MySchema(only=["bool_field"])) == (
        {"bool_field": True},
        [],
    )

# Generated at 2022-06-12 16:20:45.623442
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        first_name: Mark
        last_name: Jantzen
        age: 36
    """

    class Person(Schema):
        first_name = Field(type="string")
        last_name = Field(type="string")
        age = Field(type="integer")

    assert validate_yaml(content, Person) == ({'first_name': 'Mark', 'last_name': 'Jantzen', 'age': 36}, [])

# Generated at 2022-06-12 16:20:49.236057
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "# This is a comment.\nname: R2-D2\n"
    validator = Field(name="name", required=True)
    value, messages = validate_yaml(content=content, validator=validator)
    assert value == "R2-D2"
    assert len(messages) == 0



# Generated at 2022-06-12 16:20:56.568527
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"number": int, "name": str, "completed": bool})
    content = """
    number: 123
    name: foo
    completed: true
    """
    value, errors = validate_yaml(content=content, validator=schema)
    assert value == {"number": 123, "name": "foo", "completed": True}
    assert errors == []



# Generated at 2022-06-12 16:21:00.878912
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
        name: John Smith
        age: 25
        '''
    try:
        valid, error_list = validate_yaml(content, Person)
    except ParseError:
        print('ParseError!')

    assert len(error_list) == 0
    assert valid.name == 'John Smith'


# Generated at 2022-06-12 16:21:12.987528
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "foo: 'bar'"
    schema = {"foo": {"type": "string"}}

    # Successful validation
    (value, error_messages) = validate_yaml(content, schema)
    assert len(error_messages) == 0

    content = "foo: 'bar"
    schema = {"foo": {"type": "string"}}

    # Unclosed quote causes a parse error
    (value, error_messages) = validate_yaml(content, schema)
    assert len(error_messages) == 1
    assert error_messages[0].text == "while scanning for the next token. expected '<document start>', but found '<scalar>'"

    content = "foo: bar"
    schema = {"foo": {"type": "string"}}
    (value, error_messages) = validate_

# Generated at 2022-06-12 16:21:22.625345
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer

    class PersonSchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John Smith"
    age: 30
    """
    value, errors = validate_yaml(content, PersonSchema())

    assert value == {"name": "John Smith", "age": 30}
    assert errors == []

    content = """
    name: "John Smith"
    age: "thirty"
    """
    value, errors = validate_yaml(content, PersonSchema())

    assert value == {"name": "John Smith", "age": "thirty"}

# Generated at 2022-06-12 16:21:28.537463
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String

    content = """
    - foo
    - bar
    - baz
    """

    errors = validate_yaml(content, String())
    assert errors

# Generated at 2022-06-12 16:21:35.124523
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    a: hello world
    b:
      - true
      - false
      - 1
      - 2
      - 1.1
    '''
    class DemoSchema(Schema):
        a = Field(str)
        b = Field(typing.List[typing.Union[int, float, bool]])
    value, error = validate_yaml(content, DemoSchema)
    assert value == {'a': 'hello world', 'b': [True, False, 1, 2, 1.1]}
    assert error == []

# Generated at 2022-06-12 16:21:46.251251
# Unit test for function validate_yaml
def test_validate_yaml():
    p = Path(__file__).resolve().parent / "test_files"
    good_file = open(p / "good_yaml_file.yml", "r")
    bad_file = open(p / "bad_yaml_file.yml", "r")
    good_content = good_file.read()
    bad_content = bad_file.read()

    class Schema1(Schema):
        class Meta:
            strict = True

        s = String()

    class Schema2(Schema):
        class Meta:
            strict = True

        s = String(min_length=2)

    class Schema3(Schema):
        class Meta:
            strict = True

        s = String(max_length=8)

    class Schema4(Schema):
        class Meta:
            strict

# Generated at 2022-06-12 16:21:57.316290
# Unit test for function validate_yaml
def test_validate_yaml():
    if yaml is not None:
        class SimpleSchema(Schema):
            name = "string"
            age = "integer"

        value, error_messages = validate_yaml(
            content='''name: David
age: 30''',
            validator=SimpleSchema
        )
        assert value == {'name': 'David', 'age': 30}
        assert error_messages == []

        value, error_messages = validate_yaml(
            content='''name: David
age: not an integer''',
            validator=SimpleSchema
        )
        assert value == {'name': 'David', 'age': 'not an integer'}

# Generated at 2022-06-12 16:22:00.523663
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "hello!"
    validator = Field({'sub': str})
    value, error_messages = validate_yaml(content, validator)
    print(value)
    #print(error_messages)


# Generated at 2022-06-12 16:22:07.647836
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test validating a simple yaml snippet
    class TestType(Schema):
        key = Field(str)

    assert validate_yaml(content="key: \"some value\"", validator=TestType) == (
        {"key": "some value"},
        [],
    )

    # Test handling a validation error
    assert validate_yaml(content="key: 42", validator=TestType) == (
        {"key": 42},
        [
            Message(
                text='Must be a <class \'str\'>.',
                code="type_error",
                field=TestType.field("key"),
                position=Position(column_no=6, line_no=1, char_index=4),
            )
        ],
    )

    # Test handling a parse error

# Generated at 2022-06-12 16:22:16.333671
# Unit test for function validate_yaml
def test_validate_yaml():
    from .testcase import test_schema_examples, test_field_examples
    for schema_data in test_schema_examples():
        schema = schema_data.schema
        for data in schema_data.valid_yaml_examples:
            assert validate_yaml(data, schema) == (schema_data.data, [])
        for data in schema_data.invalid_yaml_examples:
            assert isinstance(validate_yaml(data, schema)[1][0], Message)
    
    for field_data in test_field_examples():
        field = field_data.field
        for data in field_data.valid_yaml_examples:
            assert validate_yaml(data, field) == (field_data.data, [])