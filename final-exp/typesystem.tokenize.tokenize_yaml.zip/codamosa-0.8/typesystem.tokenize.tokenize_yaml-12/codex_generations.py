

# Generated at 2022-06-12 16:12:23.519747
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert isinstance(tokenize_yaml("a: 1"), DictToken)


# Generated at 2022-06-12 16:12:33.956980
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "users:\n    - name: bob\n      age: 40\n      active: False"
    validator = Schema(
        {
            "users": [
                {
                    "name": str,
                    "age": int,
                    "active": bool
                },
            ]
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {
        "users": [
            {
                "name": "bob",
                "age": 40,
                "active": False,
            }
        ]
    }
    assert not errors
    content = "invalid: yaml"
    validator = Schema({"invalid": "yaml"})
    _, errors = validate_yaml(content, validator)
    assert errors

# Generated at 2022-06-12 16:12:37.125528
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = u'["a", "b", "c"]'
    assert tokenize_yaml(content) == ["a", "b", "c"]


# Generated at 2022-06-12 16:12:40.805140
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
foo: "bar"
baz: 42
"""
    token = tokenize_yaml(content)
    assert token.get("foo") == "bar"
    assert token.get("baz") == 42

# Generated at 2022-06-12 16:12:45.021653
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    my_yaml="""
name: 'Joseph'
city: 'Austin'
"""
    token = tokenize_yaml(my_yaml)
    token_dict=token.value
    assert token_dict['name'] == 'Joseph'
    assert token_dict['city'] == 'Austin'


# Generated at 2022-06-12 16:12:46.201261
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("test: value") == {'test': 'value'}

# Generated at 2022-06-12 16:12:54.472192
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test tokenizing simple yaml
    assert tokenize_yaml("hello: world") == DictToken({"hello": "world"}, start=0, end=11, content="hello: world")
    # Test tokenizing simple yaml with leading/trailing spaces
    assert tokenize_yaml("hello: world ") == DictToken({"hello": "world"}, start=0, end=11, content="hello: world ")
    # Test tokenizing simple yaml with leading/trailing spaces
    assert tokenize_yaml("hello: world ") == DictToken({"hello": "world"}, start=0, end=11, content="hello: world ")
    # Test tokenizing multiple values

# Generated at 2022-06-12 16:13:05.615805
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content1 = '''
- foo
- bar'''

    content2 = '''
a: 1
b: 2
c: 3'''

    content3 = '''
-
- foo:
    bar: baz'''

    content4 = '''
-
- foo: bar
  bar: baz'''

    content5 = '''
xyz: 123'''

    content6 = '''
- foo
- [1, 2, 3]'''

    content7 = '''
- foo:
    - bar:
        - baz'''

    assert tokenize_yaml(content1) == [
        ScalarToken("foo", 2, 5, content=content1),
        ScalarToken("bar", 8, 12, content=content1),
    ]

    assert tokenize_yaml(content2)

# Generated at 2022-06-12 16:13:16.297772
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """\
greeting: Hello, world!
count: 1
nested:
  a: 1
  b: 2
items:
  - 1
  - 2
  - 3
"""
    validator = Schema(
        {
            "greeting": Field(str),
            "count": Field(int),
            "nested": Field({"a": Field(int), "b": Field(int)}),
            "items": Field([int]),
        }
    )

    value = validate_yaml(content, validator)
    assert value == {
        "greeting": "Hello, world!",
        "count": 1,
        "nested": {"a": 1, "b": 2},
        "items": [1, 2, 3],
    }



# Generated at 2022-06-12 16:13:24.710722
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "foo: bar"
    validator = Field(name="foo", type="string", required=True)
    value, error_messages = validate_yaml(content, validator=validator)
    assert value == "bar"
    assert not error_messages

    content = "foo: 2"
    validator = Field(name="foo", type="string", required=True)
    value, error_messages = validate_yaml(content, validator=validator)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].code == "invalid_type"
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 6


# Generated at 2022-06-12 16:13:41.634579
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    with pytest.raises(ParseError) as exc_info:
        validate_yaml(b"", validator=Field())
    assert exc_info.value.code == "no_content"
    assert exc_info.value.position == Position(
        char_index=0, column_no=1, line_no=1
    )

    with pytest.raises(ParseError) as exc_info:
        validate_yaml("", validator=Field())
    assert exc_info.value.code == "no_content"
    assert exc_info.value.position == Position(
        char_index=0, column_no=1, line_no=1
    )


# Generated at 2022-06-12 16:13:48.740743
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, Object
    from typesystem.exceptions import ValidationError as TypesystemValidationError

    class User(Schema):
        id = Integer()
        name = Integer()

    try:
        content = """
        name: "jeff"
        """
        validate_yaml(content, User)
    except ValidationError as exc:
        assert 'user.name: "jeff" is not an integer.' in str(exc)
    else:
        raise AssertionError("yaml validation failed")

    try:
        content = """
        id: "jeff"
        """
        validate_yaml(content, User)
    except ValidationError as exc:
        assert 'user.id: "jeff" is not an integer.' in str(exc)

# Generated at 2022-06-12 16:13:59.581232
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("abc") == "abc"
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("12.34") == 12.34
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_yaml("{a: 1, b: 2, c: 3}") == {"a": 1, "b": 2, "c": 3}
    # positional error
    try:
        tokenize_yaml("#")
    except ParseError as exc:
        assert exc.position == Position(1, 1, 0)
        assert exc.text == "found character '#' that cannot start any token."
    #

# Generated at 2022-06-12 16:14:09.634082
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test cases to ensure the `validate_yaml` function works as expected.
    """
    class TestSchema(Schema):

        age = Field(type="number")
        name = Field(type="string", max_length=10)
        bio = Field(type="string", required=False, nullable=True)

    # Invalid content
    content = "# This is a YAML comment.\n- name: John"
    value, errors = validate_yaml(content, TestSchema)
    assert value is None
    assert len(errors) == 1
    assert errors[0].text == "This is not a valid YAML document."
    assert errors[0].code == "parse_error"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 1


# Generated at 2022-06-12 16:14:19.924583
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
       basic: basics
          name: sha
          age: 5
          gender: male
    '''
    validator = Field(str)
    token = tokenize_yaml(content)
    v = validate_with_positions(token, validator)
    print(v)
    assert v == {'basic': {'name': 'sha', 'age': 5, 'gender': 'male'}}

    content = """
       basic: basics
          name: sha
          age: 5
          gender: male
    """
    validator = Field(str)
    token = tokenize_yaml(content)
    v = validate_with_positions(token, validator)
    print(v)

# Generated at 2022-06-12 16:14:30.405215
# Unit test for function validate_yaml
def test_validate_yaml():
    class S(Schema):

        n = fields.Float(
            description="Please enter a number between 0 and 1, exclusive.",
            minimum=0,
            maximum=1,
            exclusive_minimum=True,
            exclusive_maximum=True,
        )

    # >>> validate_yaml(b"---\nn: 0.4\n", S)
    # (
    #     {'n': 0.4},
    #     <Collection[0 items]>
    # )
    # >>> validate_yaml(b"---\nn: 0", S)
    # (
    #     None,
    #     <Collection[1 item]>
    # )
    # >>> validate_yaml(b"---\nn: 0.4\n", S)
    # (
    #     {'n': 0.4},


# Generated at 2022-06-12 16:14:42.834626
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None
    assert yaml.__version__.startswith('5')


# Generated at 2022-06-12 16:14:46.498072
# Unit test for function validate_yaml
def test_validate_yaml():
    token = tokenize_yaml("""
      dict:
        a: 2
        b: 3
    """)
    assert validate_with_positions(token=token, validator={'mydict':{'dict': {'a': 'integer', 'b': 'integer'}}}) == ({'dict': {'a': 2, 'b': 3}}, [])


# Generated at 2022-06-12 16:14:57.414614
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    - a
    - b:
      - c
      - d
    """

    try:
        import yaml
        from yaml.loader import SafeLoader
    except ImportError:  # pragma: no cover
        yaml = None  # type: ignore
        SafeLoader = None  # type: ignore

    class CustomSafeLoader(SafeLoader):
        pass

    def construct_mapping(loader: "yaml.Loader", node: "yaml.Node") -> DictToken:
        start = node.start_mark.index
        end = node.end_mark.index
        mapping = loader.construct_mapping(node)
        return DictToken(mapping, start, end - 1, content=content)


# Generated at 2022-06-12 16:15:06.619718
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("test") == "test"
    assert tokenize_yaml("- test1 \n- test2 \n") == ["test1", "test2"]
    assert tokenize_yaml("test1: test2") == {"test1": "test2"}
    struct = tokenize_yaml("""
- test1: 1
- test2: 2
- test3: 3
- test4: 4
""")
    assert struct[0] == {"test1": 1}
    assert struct[1] == {"test2": 2}
    assert struct[2] == {"test3": 3}
    assert struct[3] == {"test4": 4}



# Generated at 2022-06-12 16:15:15.671371
# Unit test for function validate_yaml
def test_validate_yaml():
    # Create a schema for testing
    class SimpleSchema(Schema):
        field1 = 'integer'
        field2 = 'string'

    # Content that should pass validation
    valid_content = """
    field1: 55
    field2: "string"
    """

    # Content that should fail validation
    invalid_content = """
    field1: "should be an int"
    field2: "string"
    """

    # Content that should fail parsing
    unparsable_content = """
    field1: 55
    field2:
    """

    # Test all possible cases
    value, errors = validate_yaml(valid_content, SimpleSchema)
    assert not errors

    value, errors = validate_yaml(invalid_content, SimpleSchema)
    assert errors


# Generated at 2022-06-12 16:15:27.087983
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem.fields import String, Integer, Array, Dict, Boolean
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String(max_length=10)
        age = Integer()
        active = Boolean(default=True)
        email = String(regex=r"\@")
        role = Array(items=String())

    class PersonDictSchema(Schema):
        data = Dict(schema=PersonSchema)

    content = yaml.safe_load(
        'data:\n  name: name\n  age: 26\n  active: true\n  email: example@example.com\n  role: [account manager, data scientist]\n'
    )


# Generated at 2022-06-12 16:15:36.371152
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer

    class BookSchema(Schema):
        title = Integer(description="The title of the book.")
        author = Integer(description="The name of the author.")
        pages = Integer(description="The number of pages")

    value, errors = validate_yaml(
        """
        title: "A Tale of Two Cities"
        author: "Charles Dickens"
        pages: 120
        """,
        BookSchema,
    )

# Generated at 2022-06-12 16:15:46.694568
# Unit test for function validate_yaml
def test_validate_yaml():
    class EmployeeSchema(Schema):
        id = "int"
        name = "str"

    content = "id: 1\nname: Foo Bar\n"
    validated_value, errors = validate_yaml(content, EmployeeSchema)

    assert validated_value == {"id": 1, "name": "Foo Bar"}
    assert not errors
    assert errors == []

    content = "id: 1\nname: Foo Bar\n"
    validated_value, errors = validate_yaml(content, EmployeeSchema)

    assert validated_value == {"id": 1, "name": "Foo Bar"}
    assert not errors

# Generated at 2022-06-12 16:15:52.397935
# Unit test for function validate_yaml
def test_validate_yaml():
    content = 'yaml: "text"'
    class MySchema(Schema):
        yaml = String(required=True)

    value, error = validate_yaml(content, MySchema)
    assert str(error) == "[{'text': 'This field is required.', 'code': 'required', 'line_no': 1, 'column_no': 9, 'char_index': 8}]"
    assert str(value) == "yaml: text"

# Generated at 2022-06-12 16:16:00.363536
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        name = String(max_length=200)
        age = Integer(minimum=1)
        score = Float(minimum=1.0)
        content = String()
        active = Boolean()
        id = Integer()

    user_yaml = """ 
name: John Doe
age: 25
score: 1.23
id: 123
active: true
content:
    Hello World!
"""
    token, messages = validate_yaml(user_yaml, UserSchema)
    assert len(messages) == 0
    assert len(token) == 6
    assert token['name'] == 'John Doe'
    assert token['age'] == 25
    assert token['score'] == 1.23
    assert token['active'] is True
    assert token['id'] == 123
    assert token['content']

# Generated at 2022-06-12 16:16:11.433463
# Unit test for function validate_yaml
def test_validate_yaml():
    s = '''
    is_active: true
    intval: 3
    strval: "some text"
    '''
    
    class MySchema(Schema):
        is_active = Boolean()
        intval = Integer()
        strval = String(pattern=r"\d+")
        
    class MySchema2(Schema):
        is_active = Boolean()
        intval = Integer()
        strval = String(pattern=r"\D+")
        
    class MySchema3(Schema):
        is_active = Boolean()
        intval = Integer()
        strval = String(pattern=r"\D+")
        y = Integer()
        
        
    print(validate_yaml(s, MySchema))

# Generated at 2022-06-12 16:16:23.370363
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem.schemas import Schema
    from typesystem.fields import String

    class YAMLSchema(Schema):
        value = String()

    yaml_str = """value: hello"""
    data, errors = validate_yaml(yaml_str, validator=YAMLSchema)
    assert not errors
    assert data == {"value": "hello"}

    yaml_str = """value: hello\nvalue: world"""
    data, errors = validate_yaml(yaml_str, validator=YAMLSchema)
    assert errors
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 6
    assert errors[0].position.char_index == 16
   

# Generated at 2022-06-12 16:16:33.636494
# Unit test for function validate_yaml
def test_validate_yaml():
    class TypeSchema(Schema):
        field = Field(type="string")

    value, errors = validate_yaml("{}", TypeSchema)
    assert value == {}
    assert errors == [
        ValidationError(
            text="Missing required attribute 'field'.",
            code="missing",
            position=Position(
                line_no=1, column_no=1, char_index=0
            ),
        )
    ]

    value, errors = validate_yaml("{field: 123}", TypeSchema)
    assert value == {"field": "123"}

# Generated at 2022-06-12 16:16:37.197706
# Unit test for function validate_yaml
def test_validate_yaml():
    return validate_yaml("hi", "hello")


# Generated at 2022-06-12 16:16:47.475430
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    # Test with a single field.
    field = String()

    value, errors = validate_yaml("value: 1", field)
    assert value == "1"
    assert not errors

    value, errors = validate_yaml("value: abc", field)
    assert value == "abc"
    assert not errors

    value, errors = validate_yaml("value: true", field)
    assert value is None
    assert len(errors) == 1
    error = errors[0]
    assert isinstance(error, ValidationError)
    assert error.token.content == "true"
    assert error.token.start == 10
    assert error.token.end == 14
    assert error.extra == {"value": "true"}
    assert error.code

# Generated at 2022-06-12 16:16:59.618088
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    import typesystem
    from typesystem.fields import String

    schema = typesystem.Schema(name=typesystem.fields.String())

    # Simple string.
    content = "name: Jane"
    token = tokenize_yaml(content)
    assert token == {"name": "Jane"}

    try:
        tokenize_yaml("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.text == "No content."
        assert exc.position.char_index == 0
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
    else:
        assert False, "Expected error."

    # Bad symbol.

# Generated at 2022-06-12 16:17:08.541361
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    with pytest.raises(AssertionError):
        tokenize_yaml('')

    assert tokenize_yaml('{}').__class__ == DictToken
    assert tokenize_yaml('[]').__class__ == ListToken
    assert tokenize_yaml('1').__class__ == ScalarToken
    assert tokenize_yaml('1.0').__class__ == ScalarToken
    assert tokenize_yaml('true').__class__ == ScalarToken
    assert tokenize_yaml('false').__class__ == ScalarToken
    assert tokenize_yaml('null').__class__ == ScalarToken
    assert tokenize_yaml('"test"').__class__ == ScalarToken
    assert tokenize_yaml('test').__class__ == ScalarToken

# Generated at 2022-06-12 16:17:16.222455
# Unit test for function validate_yaml
def test_validate_yaml():
    class YAMLSchema(Schema):
        first_name = Field(type=str)
        age = Field(type=int)

    def validate_age(value):
        if value < 18:
            raise ValidationError("Must be 18 or older.")

    YAMLSchema.add_field("age", after_validation=[validate_age])

    errors = validate_yaml(
        content="""
        first_name: "John"
        age: 12
        """,
        validator=YAMLSchema,
    )

    assert errors == [
        Message(
            text="Must be 18 or older.",
            code="validation_error",
            position=Position(line_no=3, column_no=11, char_index=31),
        )
    ]

# Generated at 2022-06-12 16:17:26.229990
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):

        name = String()
        age = Number()

    errors = validate_yaml("""
        name: Anshul
        age: 25
    """, PersonSchema)
    assert errors == []

    errors = validate_yaml("""
        name: Anshul
        age: 25X
    """, PersonSchema)
    assert errors != []
    assert errors[0].code == 'type_error'

    errors = validate_yaml("""
        name: Anshul
        age: 25
        address: Delhi
    """, PersonSchema)
    assert errors != []
    assert errors[0].code == 'additional_properties_error'


# Generated at 2022-06-12 16:17:35.811285
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None
    content = '''
    data:
      name: "Erick"
      age: 21
      favoriteBooks:
        - "Harry Potter"
        - "The Bible"
    '''

    class Person(Schema):
        name = "string"
        age = "integer"
        favoriteBooks = "list:string"

    value, error_messages = validate_yaml(content, validator=Person)
    
    assert error_messages == []

    content = '''
    data:
      name: "Erick"
      age: "21"
      favoriteBooks:
        - "Harry Potter"
        - "The Bible"
    '''

    value, error_messages = validate_yaml(content, validator=Person)

# Generated at 2022-06-12 16:17:47.530585
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None
    content = '---\nfoo: "bar"'
    token = tokenize_yaml(content)
    schema = Schema({"foo": str})
    value, error_messages = validate_yaml(content, schema)
    assert isinstance(error_messages, list)
    assert isinstance(error_messages[0], Message)
    assert error_messages[0].code == "parse_error"

    content = '---\nfoo: "bar"\nfoo: "bar"'
    token = tokenize_yaml(content)
    schema = Schema({"foo": str})
    value, error_messages = validate_yaml(content, schema)
    assert isinstance(error_messages, list)
    assert isinstance(error_messages[0], Message)
   

# Generated at 2022-06-12 16:17:59.207669
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    value, errors = validate_yaml(
        """
        name: Bob
        age: 35
        """,
        Person,
    )
    assert value == {"name": "Bob", "age": 35}
    assert errors == {}

    value, errors = validate_yaml("", Person)
    assert value is None
    assert errors == {"": [Message("No content.", code="no_content", position=Position(column_no=1, line_no=1, char_index=0))]}

    value, errors = validate_yaml("{}", Person)
    assert value is None

# Generated at 2022-06-12 16:18:04.426869
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(b"{'hello': 'world'}") == {'hello':'world'}
    assert tokenize_yaml('''{
    'a':{
        'b': 'c',
        'd': [1, 2, 3]
    }
}''') == {'a':{'b': 'c', 'd': [1, 2, 3]}}

    try:
        tokenize_yaml('{')
    except ParseError as e:
        assert e.text == 'expected <block end>, but found \'<document start>\''

# Generated at 2022-06-12 16:18:15.493979
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    import typesystem
    
    class MySchema(Schema):
        title = String()
        price = typesystem.Number(minimum=5, maximum=10)
    
    # Test validation error
    try:
        content = """
        title: My title
        price: 1.9
        """
        with pytest.raises(typesystem.ValidationError) as excinfo:
            validate_yaml(content, MySchema)
    except:
        pytest.fail("YAML Validation Error should be raised")
    else:
        assert len(excinfo.value.messages) == 1

# Generated at 2022-06-12 16:18:29.324648
# Unit test for function validate_yaml
def test_validate_yaml():
    """ Unit test for function validate_yaml """
    
    # Example from https://docs.typesystem.dev/en/stable/parsers.html#yaml
    content = """
    name: Adrian
    age: 23
    pets:
        - name: Foo
          type: Cat
        - name: Bar
          type: Dog
    """

    class Pet(Schema):
        name = fields.String(max_length=25)
        type = fields.String(choices=["Cat", "Dog", "Fish"])

    class Person(Schema):
        name = fields.String(max_length=25)
        age = fields.Integer()
        pets = fields.Array(items=Pet)

    person, errors = validate_content(Person, content)

    assert person.name == "Adrian"
    assert person.age

# Generated at 2022-06-12 16:18:37.158103
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
        - a
        - b
    '''
    validator = Field(type="list", items=Field(type="string"))
    assert validate_yaml(content, validator) == ([["a", "b"]], None)

    content = """
        foo: 1
        bar: 2
    """
    validator = Field(type="dict", fields={"foo": Field(type="integer"), "bar": Field(type="integer")})
    assert validate_yaml(content, validator) == ({"foo": 1, "bar": 2}, None)

    content = """
        a:
          - 2
          - 3
    """
    validator = Field(type="dict", fields={"a": Field(type="list", items=Field(type="integer"))})

# Generated at 2022-06-12 16:18:41.322097
# Unit test for function validate_yaml
def test_validate_yaml():
    result = validate_yaml("""
        {
            "a": 1,
            "b": 2
        }
        """, Schema)
    assert(result == ({"a": 1, "b": 2}, []))



# Generated at 2022-06-12 16:18:43.381967
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    value, errors = validate_yaml("test", String)
    assert value == "test"
    assert not errors



# Generated at 2022-06-12 16:18:54.386700
# Unit test for function validate_yaml
def test_validate_yaml():
    # validate an integer with one error
    value, errors = validate_yaml("1", validator=Field(type=int, max_value=0))
    assert len(errors) == 1
    assert errors[0].type == "max_value"

    # validate a dict with one error
    value, errors = validate_yaml(
        "test: 1", validator=Field(type=dict, fields={"test": Field(type=str)})
    )
    assert len(errors) == 1
    assert errors[0].type == "type"

    # validate a dict with one error and a list with one error

# Generated at 2022-06-12 16:18:57.161315
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"name": str})
    value, errors = validate_yaml("name: 'foo'", schema)
    assert value == {"name": "foo"}
    assert errors == []

test_validate_yaml()

# Generated at 2022-06-12 16:19:02.481610
# Unit test for function validate_yaml
def test_validate_yaml():
    schema_string = "schema: (str, choices=[A, B])"
    # Setup
    value, error_messages = validate_yaml(schema_string,Schema)
    assert value == {"schema": "(str, choices=[A, B])"}
    assert not error_messages
    # Teardown


# Generated at 2022-06-12 16:19:14.323054
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b'\n    customer:\n        job: CEO\n        more_data: false'
    schema = Schema(
        {
            "customer": {"type": "object", "required": True, "properties": {"job": {"type": "string"}}}
        }
    )

    value, errors = validate_yaml(content=content, validator=schema)
    assert not errors
    assert value == {"customer": {"job": "CEO", "more_data": False}}

    content = (
        b'\n    customer:\n        job: CEO\n        more_data: '
        b'{"a": 1, "b": "2", "c": true, "d": null}'
    )

# Generated at 2022-06-12 16:19:19.158800
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    - &ref
      key: value
    - "*ref"
    '''
    value, messages = validate_yaml(
        content=content,
        validator=Schema.of([{"key": str}, str]),
    )
    assert value == [{"key": "value"}, "value"]
    assert len(messages) == 0



# Generated at 2022-06-12 16:19:25.603965
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Unit test for method validate_yaml().
    """
    # Test an example that should raise a validation error.
    invalid_yaml_str = """
    foo: 2
    """
    value_schema_class = schema("ValueSchema", {"foo": fields.Integer()})
    value, errors = validate_yaml(invalid_yaml_str, value_schema_class)
    assert not value
    assert isinstance(errors, list)
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)
    assert errors[0].message == "Must be at most 1."

    # Test an example that should raise a parsing error.
    invalid_yaml_str = """
    foo: "
    foo: 2
    """

# Generated at 2022-06-12 16:19:33.878552
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {"f": Field(validators = [lambda x: float(x) > 3.0])}
    )
    yaml = "---\nf: 3.0"
    value, error_messages = validate_yaml(yaml, schema)
    assert value.f == 3.0
    assert len(error_messages) > 0


# Generated at 2022-06-12 16:19:41.442456
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 42
    """

    class PersonSchema(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    token = tokenize_yaml(content)
    assert token.as_dict() == {'name': 'John Doe', 'age': 42}

    value, errors = validate_yaml(content, PersonSchema)

    assert not errors
    assert value == PersonSchema(name="John Doe", age=42)

# Generated at 2022-06-12 16:19:50.580503
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    data:
        first: 1
        second: 2
    '''
    schema = Schema(
        name="test_schema",
        fields=[
            Field(name="first", type="integer", required=True),
            Field(name="second", type="integer", required=True),
        ],
    )
    value, error_messages = validate_yaml(
        content=content,
        validator=schema,
    )
    assert error_messages == []
    assert value == {'first': 1, 'second': 2}

# Generated at 2022-06-12 16:20:01.628837
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Scalars
    assert tokenize_yaml("123") == ScalarToken(123, 0, 2)
    assert tokenize_yaml("123.4") == ScalarToken(123.4, 0, 4)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3)
    assert tokenize_yaml("Bike") == ScalarToken("Bike", 0, 4)
    assert tokenize_yaml("Bike\n") == ScalarToken("Bike", 0, 4)
    assert tokenize_yaml("Bike\nBike") == ScalarToken("Bike", 0, 4)

# Generated at 2022-06-12 16:20:12.574650
# Unit test for function validate_yaml
def test_validate_yaml():

    class TitleSchema(Schema):
        title = Field(type="string")

    validator = TitleSchema()

    assert validate_yaml("", validator) == ([], [])
    assert validate_yaml("{}", validator) == ([], [])

    errors = validate_yaml("""title: """, validator)
    assert len(errors[0]) == 0
    assert len(errors[1]) == 1
    assert errors[1][0].text == "Missing required field 'title'."

    errors = validate_yaml("""title: "foo" """, validator)
    assert len(errors[0]) == 1
    assert errors[0][0] == "foo"
    assert len(errors[1]) == 0
    assert errors[0][0] == "foo"



# Generated at 2022-06-12 16:20:19.160951
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    content = "a: True\nb: 2"

    class TestSchema(Schema):
        a = Field(type=bool)
        b = Field(type=int)

    validator = TestSchema()
    value, errors = validate_yaml(content, validator)
    assert value == {"a": True, "b": 2}
    assert len(errors) == 0


# Generated at 2022-06-12 16:20:24.538361
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        hello = Field(type="string")
        world = Field(type="boolean")

    validator = TestSchema()

    value, errors = validate_yaml(
        content="hello: 'world'\nworld: true", validator=validator
    )
    assert value["hello"] == "world"
    assert value["world"] is True
    assert len(errors) == 0



# Generated at 2022-06-12 16:20:36.264849
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # test parse error without positions
    content = """
    - a: 1
    - b: 2
    c: 3
    """
    expected_error_message = "Unexpected key 'c' in dictionary."
    try:
        tokenize_yaml(content)
    except ParseError as exc:
        assert exc.text == expected_error_message
        assert exc.position is None
        assert exc.code == "parse_error"
    else:
        raise AssertionError("Expected parsing error.")

    # test parse error with positions
    try:
        token = tokenize_yaml(content)
    except ParseError as exc:
        pass
    else:
        raise AssertionError("Expected parsing error.")
    assert token.start

# Generated at 2022-06-12 16:20:46.316976
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Number

    valid_yaml_str = """
    foo: bar
    """
    invalid_yaml_str = """
    foo: bar
    baz
    """
    schema = Schema(
        properties={
            "foo": String(max_length=10),
            "baz": Number(),
        }
    )
    assert validate_yaml(valid_yaml_str, schema) == ({'foo': 'bar'}, [])
    _, error_messages = validate_yaml(invalid_yaml_str, schema)
    assert len(error_messages) == 1
    assert error_messages[0].position == Position(line_no=3, column_no=9, char_index=18)

# Generated at 2022-06-12 16:20:52.725435
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    content = "hello"
    validator = String(max_length=4)
    token = tokenize_yaml(content)
    value, errors = validate_with_positions(token=token, validator=validator)
    assert value == "hello"
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)
    assert errors[0].code == "max_length"
    assert errors[0].position == Position(1, 6, 5)
    assert errors[0].text == "Must be at most 4 characters long."

    class Person(Schema):
        name = String(required=True)
        age = String()

    person_content = "name: Dmitry\nage: 10"
    person_

# Generated at 2022-06-12 16:21:02.430227
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        foo = Integer()
        bar = String()

    result, errors = validate_yaml(
        content=b"foo: 456\nbaz: 'string'", validator=TestSchema
    )

    assert isinstance(errors, list)
    assert len(errors) == 1

    message = errors[0]
    assert isinstance(message, Message)
    assert message.field_name == "bar"
    assert message.text == "Missing required field."
    assert message.position == Position(
        line_no=0, column_no=0, char_index=0
    )

    result, errors = validate

# Generated at 2022-06-12 16:21:12.491423
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = Field(str)
        age = Field(int)

    content = """
    name: michael
    age: hello
    """
    value, errors = validate_yaml(content, MySchema)
    assert value is None
    assert errors[0].code == ValidationError.CODE_INVALID
    assert len(errors) == 1
    assert errors[0].position.char_index == len(content)
    assert errors[0].position.line_no == 4
    assert errors[0].position.column_no == 5
    assert errors[0].message == "Value must be an integer."



# Generated at 2022-06-12 16:21:20.564249
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem
    content = '''
id: 1
name: "John Smith"
age: 32
address:
  street: "123 South Earl Street"
  city: "Vancouver"
  postal_code: "V6Z 1P8"
'''

    validator = typesystem.Schema(
        {"id": typesystem.Integer(), "name": typesystem.String()}
    )

    value, error_messages = validate_yaml(content, validator)

    assert len(error_messages) == 1
    assert error_messages[0].message == "Additional properties are not allowed."



# Generated at 2022-06-12 16:21:28.689033
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml.
    """

    schema = Schema(
        {
            "name": String,
            "age": Integer,
            "fav_colors": List(String),
            "awesome": Boolean,
        }
    )

    def check_validation(content, expected_value, expected_messages):
        value, messages = validate_yaml(content, schema)
        assert value == expected_value
        assert messages == expected_messages

    content = """
    name: Sam
    age: 30
    fav_colors:
        - red
        - green
        - blue
    awesome: true
    """

# Generated at 2022-06-12 16:21:37.040295
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    content = """
    name: your name
    age: "0"
    """

    assert validate_yaml(content, PersonSchema) == (
        {
            "name": "your name",
            "age": 0,
        },
        [],
    )

    content = """
    name: your name
    """


# Generated at 2022-06-12 16:21:44.319258
# Unit test for function validate_yaml
def test_validate_yaml():

    schema = Schema(fields={"name": {"type": "string", "max_length": 5}})
    value, error_messages = validate_yaml(b"name: foobar", schema)

    assert value == {"name": "foobar"}
    assert error_messages == [
        Message(
            text="foo", code="max_length", field=schema.fields["name"], position=Position(
                line_no=1, column_no=6, char_index=4
            )
        )
    ]



# Generated at 2022-06-12 16:21:53.075205
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Tests the successful case
    contents = """
        key1: value1
        key2: value2
    """
    d = tokenize_yaml(contents)
    assert d.start == 0
    assert d.end == 34
    assert d.content == contents

    # Tests the failure case where there is
    # no content
    try:
        tokenize_yaml("")
    except ParseError as exc:
        assert (exc.text == "No content." and exc.code == "no_content" and
                exc.position.column_no == 1 and exc.position.line_no == 1 and
                exc.position.char_index == 0)
    else:
        raise ValueError("Failed to raise a message. ")

# Generated at 2022-06-12 16:22:03.370898
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("", int) == (None, None)
    assert validate_yaml("", str) == (None, None)
    assert validate_yaml("", bytes) == (b"", None)
    assert validate_yaml("1", int) == (1, None)
    assert validate_yaml("1", str) == ("1", None)
    assert validate_yaml("1", bytes) == (b"1", None)
    assert validate_yaml(1, int) == (1, None)
    assert validate_yaml(1, str) == ("1", None)
    assert validate_yaml(1, bytes) == (b"1", None)
    assert validate_yaml("1", bool) == (True, None)
    assert validate_yaml("true", bool) == (True, None)

# Generated at 2022-06-12 16:22:08.966982
# Unit test for function validate_yaml
def test_validate_yaml():
    class BookSchema(Schema):
        title = Field(type=str)
        author = Field(type=str)
        pages = Field(type=int)
        price = Field(type=float)

    yaml_content = "title: My Book\n"
    result = validate_yaml(yaml_content, validator=BookSchema)
    value, errors = result
    assert errors[0].code == 'missing_field'
    assert errors[0].printed_message == 'Missing field "author".'
    assert errors[1].code == 'missing_field'
    assert errors[1].printed_message == 'Missing field "pages".'
    assert errors[2].code == 'missing_field'
    assert errors[2].printed_message == 'Missing field "price".'