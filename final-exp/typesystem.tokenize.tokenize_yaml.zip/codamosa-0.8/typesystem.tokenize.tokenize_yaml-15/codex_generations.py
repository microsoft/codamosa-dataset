

# Generated at 2022-06-12 16:12:31.329493
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.base import ValidationError
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class Person(Schema):
        age = Integer()
        name = String(max_length=5)

    def test_invalid(content):
        token = tokenize_yaml(content)
        value, errors = validate_with_positions(token=token, validator=Person)
        assert isinstance(errors, list)
        assert not value
        assert len(errors) == 1
        assert isinstance(errors[0], ValidationError)

    test_invalid("name: jane\nfoo: bar")
    test_invalid("name: jane\nage: foobar")
   

# Generated at 2022-06-12 16:12:40.855569
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Scalar tests
    assert tokenize_yaml('"a"') == ScalarToken("a", 0, 2, content='"a"')
    assert tokenize_yaml("'a'") == ScalarToken("a", 0, 2, content="'a'")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("-1") == ScalarToken(-1, 0, 2, content="-1")
    assert tokenize_yaml("1.2") == ScalarToken(1.2, 0, 3, content="1.2")
    assert tokenize_yaml("-1.2") == ScalarToken(-1.2, 0, 4, content="-1.2")
    assert tokenize_yaml("true") == Scalar

# Generated at 2022-06-12 16:12:50.297226
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    assert isinstance(tokenize_yaml(""), ScalarToken)
    assert isinstance(tokenize_yaml("null"), ScalarToken)
    assert isinstance(tokenize_yaml("0"), ScalarToken)
    assert isinstance(tokenize_yaml("false"), ScalarToken)

    assert isinstance(tokenize_yaml("- 0"), ListToken)
    assert isinstance(tokenize_yaml("- 0\n- 1\n- 2"), ListToken)
    assert isinstance(tokenize_yaml("[0, 1, 2]"), ListToken)
    assert isinstance(tokenize_yaml("[0, 1, 2,]"), ListToken)

    assert isinstance(tokenize_yaml("a: b"), DictToken)

# Generated at 2022-06-12 16:12:57.642910
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # testing invalid yaml string
    with pytest.raises(ParseError):
        assert tokenize_yaml('  ---\n- a\n- b\n') == '"  "\n"-"\n"a"\n"- "\n"b"\n'
    # testing valid yaml string
    assert tokenize_yaml('---\n- 1\n- 2\n') == [1,2]



# Generated at 2022-06-12 16:13:07.599321
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 0, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 0, content="[]")
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")
    assert tokenize_yaml("12") == ScalarToken(12, 0, 1, content="12")
    assert tokenize_yaml("12.34") == ScalarToken(12.34, 0, 4, content="12.34")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == Scal

# Generated at 2022-06-12 16:13:17.365413
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    connections:
    - name: dev
      config:
        host: 1.2.3.4
    - name: prod
      config:
        host: 10.10.10.10
    """

    token = tokenize_yaml(content)


# Generated at 2022-06-12 16:13:22.505382
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("foo: \"bar\"")
    assert token == {"foo": "bar"}

    with pytest.raises(ParseError):
        tokenize_yaml("")

    with pytest.raises(ParseError):
        tokenize_yaml("---\nfoo: bar")

    with pytest.raises(ParseError):
        tokenize_yaml("{'foo': 'bar'}")



# Generated at 2022-06-12 16:13:32.409377
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str1 = """
        test1:
            test2:
                test4: 4
            test3: 3
    """
    token = tokenize_yaml(str1)
    assert token.start == 0
    assert token.end == 69
    assert isinstance(token, DictToken)
    assert isinstance(token.value[0], DictToken)
    assert isinstance(token.value[0].value[0], DictToken)
    assert isinstance(token.value[0].value[0].value[0], ScalarToken)
    assert isinstance(token.value[0].value[1], ScalarToken)
    assert token.value[0].value[1].value == '3'

# Generated at 2022-06-12 16:13:36.311186
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""\
    key1: value1
    key2:
      - 1
      - 2
      - 3
    """)
    assert token.to_primitive() == {
        "key1": "value1",
        "key2": [1, 2, 3],
    }



# Generated at 2022-06-12 16:13:41.499394
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "string"
        age = "integer"

    from typesystem.exceptions import ValidationError
    from typesystem.fields import Integer, String

    def test_valid_yaml_data(yaml_data: str, json_data: dict):
        """Unit test for function validate_yaml"""
        # Given:
        schema = TestSchema()

        # When
        res, err = validate_yaml(yaml_data, schema)

        # Then:
        assert err == []
        assert res == json_data

    def test_invalid_yaml_data(
        yaml_data: str, validation_error: ValidationError
    ):
        """Unit test for function validate_yaml"""
        # Given:
        schema = TestSchema()

        # When:

# Generated at 2022-06-12 16:13:56.150289
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"a": Integer()})
    # Test content is YAML string of scalar number
    good_content = "3"
    assert validate_yaml(good_content, schema) == (3, [])
    # Test content is YAML string of unparseable scalar
    bad_content = "Not a number"
    assert validate_yaml(bad_content, schema) == (None, [])
    # Test content is YAML string of dict including scalar number
    good_content = """
    test: 3
    """
    assert validate_yaml(good_content, schema) == ({"test": 3}, [])
    # Test content is YAML string of dict including unparseable scalar
    bad_content = """
    test: Not a Number
    """

# Generated at 2022-06-12 16:14:07.456825
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("1e10") == ScalarToken(1e10, 0, 3, content="1e10")
    assert tokenize_yaml("1e-10") == ScalarToken(1e-10, 0, 4, content="1e-10")
    assert tokenize_yaml("-1") == ScalarToken(-1, 0, 0, content="-1")
    assert tokenize_yaml("-1.0") == ScalarToken(-1.0, 0, 3, content="-1.0")

# Generated at 2022-06-12 16:14:18.079395
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    content = ' '
    validator = {}
    assert validate_yaml(content, validator) == (' ', [{'text': 'No content.', 'code': 'no_content'}])
    content = '- a'
    validator = {}
    assert validate_yaml(content, validator) == ('- a', [{'text': 'YAML decode error. "str" object is not callable.', 'code': 'parse_error'}])
    content = '"a"'
    validator = {}
    assert validate_yaml(content, validator) == ('"a"', [{'text': 'YAML decode error. "str" object is not callable.', 'code': 'parse_error'}])

# Generated at 2022-06-12 16:14:23.169121
# Unit test for function validate_yaml
def test_validate_yaml():
    string = """
    a: b
    """

    errors = validate_yaml(string, Text)
    assert errors == [
        Message(
            text="Invalid value.",
            code="invalid",
            position=Position(line_no=2, column_no=4, char_index=7)
        )
    ]

# Generated at 2022-06-12 16:14:32.361735
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        name = StringField()
        age = IntegerField(minimum=18)

    content = '''
    name: Alex
    age: 24
    '''
    value, errors = validate_yaml(content, UserSchema)
    print(value)
    print(errors)
    assert value == {'name': 'Alex', 'age': 24}
    assert errors == []

    # Invalid age field
    content = '''
    name: Alex
    age: 10
    '''
    value, errors = validate_yaml(content, UserSchema)
    assert value == {}
    assert len(errors) == 1
    print(errors)
    error = errors[0]
    assert isinstance(error, ValidationError)

# Generated at 2022-06-12 16:14:44.522951
# Unit test for function validate_yaml
def test_validate_yaml():
    # DictToken
    #   {"a": "b"}
    #     ScalarToken(a)
    #     ScalarToken(b)
    assert validate_yaml(
        "a: b\n",
        Field(name="a", type_=str, required=False),
    )[0] == "b"
    assert validate_yaml(
        "a: b\n",
        Field(name="a", type_=int, required=False),
    )[1][0].text == (
        "This value must be an integer."
    )

    # ListToken
    #   [1]
    #     ScalarToken(1)
    assert validate_yaml(
        "- 1\n",
        Field(name="a", type_=int, required=False),
    )[0] == 1

# Generated at 2022-06-12 16:14:46.966554
# Unit test for function validate_yaml
def test_validate_yaml():
    with pytest.raises(ValueError):
        validate_yaml("{}", "Invalid")



# Generated at 2022-06-12 16:14:53.311952
# Unit test for function validate_yaml
def test_validate_yaml():
    str = "name: 'Frank'"
    resp = validate_yaml(str,Schema(fields=[Field(name="name", type="string")]))
    resp2 = validate_yaml(str,Field(name="name", type="string"))
    assert resp[0] == resp2[0]
    assert resp[1] == resp2[1]
    assert resp[0] == {'name': 'Frank'}
    assert resp[1] == []

# Generated at 2022-06-12 16:15:04.351838
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test parsing YAML string
    output = tokenize_yaml('{"a": {"b":1, "c":2}, "d":3}')

# Generated at 2022-06-12 16:15:08.997710
# Unit test for function validate_yaml
def test_validate_yaml():
    message = validate_yaml(
    '''{
    "action": "request",
    "amount": 0.1,
    "currency": "AUD",
    "merchant_order_id": "orderid-1234"
    }''',
    )
    assert message is not None


# Generated at 2022-06-12 16:15:19.251584
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    content - A YAML string or bytestring.
    validator - A Field instance or Schema class to validate against.
    """
    content = '{"name": "james", "age": 100}'
    validator = validator.validators.String(name="name")

    if __name__ == "__main__":
        print (validate_yaml(content, validator))

# Generated at 2022-06-12 16:15:30.067446
# Unit test for function validate_yaml
def test_validate_yaml():
    content = " - 1\n - 2\n - 3"
    validator = Field(type="integer", min_length=5)
    _, error_messages = validate_yaml(content, validator)

    token = tokenize_yaml(content)
    _, error_messages2 = validate_with_positions(token, validator)

    assert error_messages == error_messages2
    
    content = " - 1\n - 2\n - 3"
    validator = Field(type="integer")
    _, error_messages = validate_yaml(content, validator)

    token = tokenize_yaml(content)
    _, error_messages2 = validate_with_positions(token, validator)

    assert error_messages == error_messages2


# Generated at 2022-06-12 16:15:34.619506
# Unit test for function validate_yaml
def test_validate_yaml():
    test_schema = Schema({'test_field': {'type': 'string'}}, 'test_schema')
    (value, errors) = validate_yaml(content="""---
test_field: test_value
""", validator=test_schema)
    assert errors == []
    assert value == {'test_field': 'test_value'}



# Generated at 2022-06-12 16:15:44.749273
# Unit test for function validate_yaml
def test_validate_yaml():
    data = "name: John"
    class PersonSchema(Schema):
        name = String(max_length=15)
    value, error = validate_yaml(data, PersonSchema)
    assert error == []
    assert value == {"name": "John"}

    data = "name: John\nage: 37"
    class PersonSchema(Schema):
        name = String(max_length=15)
        age = Integer()
    value, error = validate_yaml(data, PersonSchema)
    assert error == []
    assert value == {"name": "John", "age": 37}

# Generated at 2022-06-12 16:15:54.634371
# Unit test for function validate_yaml
def test_validate_yaml():
    strict_schema = Schema([Field(name="title", type="string"), Field(name="rate", type="number")])
    lax_schema = Schema([Field(name="title", type="string"), Field(name="rate", type="number", required=False)])

    # Parsing is not strict so you also need to check that the correct error
    # messages are returned.
    invalid_yaml_string = """
    - foo
    - bar
    """
    result, messages = validate_yaml(invalid_yaml_string, strict_schema)
    assert len(messages) == 2
    assert issubclass(messages[0].type, ParseError)
    assert issubclass(messages[1].type, ValidationError)
    assert messages[1].code == "missing_field"

    yaml

# Generated at 2022-06-12 16:15:58.960808
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: Bryan
    age: 100
    """
    validator = Schema.of(
        {
            "name": str,
            "age": int,
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "Bryan", "age": 100}
    assert len(errors) == 0



# Generated at 2022-06-12 16:16:05.588618
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "test_validate_yaml"
    validator = Field(name="test_validate_yaml", type="string", required=True)
    value, error_messages = validate_yaml(content, validator)
    print(value)
    print(error_messages)

if __name__ == "__main__":
    test_validate_yaml()

# Generated at 2022-06-12 16:16:16.383314
# Unit test for function validate_yaml
def test_validate_yaml():
    # Create JSON Schema from Type
    class UserSchema(Schema):
        age = Integer(allow_null=True)

    # Create JSON Schema from Field
    class AddressSchema(Schema):
        first_name = String()
        last_name = String()
        user = Object(schema=UserSchema())

    # Test YAML Content
    str_content = """
    first_name: ""
    last_name: "Last Name"
    user:
        age: 14
    """
    # Load YAML
    value, errors = validate_yaml(str_content, AddressSchema())
    errors = [error.to_dict() for error in errors]

# Generated at 2022-06-12 16:16:23.621153
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class AuthorSchema(Schema):
        name = types.String(max_length=100)

    class BookSchema(Schema):
        title = types.String
        published_at = types.Date()
        author = AuthorSchema

    errors = validate_yaml("""
    title: Great Expectations
    author:
      name: Charles Dickens
    """, BookSchema)
    assert len(errors) == 0



# Generated at 2022-06-12 16:16:28.410270
# Unit test for function validate_yaml
def test_validate_yaml():
    validator_schema = type("test_schema", (Schema,), {"foo": str})
    (value, messages) = validate_yaml("""foo: 123""", validator_schema)
    assert value == {"foo": "123"}
    assert len(messages) == 1
    assert messages[0].code == "type_mismatch"
    assert messages[0].position.line_no == 1
    assert messages[0].position.column_no == 4
    assert messages[0].position.char_index == 4
    assert messages[0].text == "Expected string."



# Generated at 2022-06-12 16:16:38.931265
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    b: 2
    c: 3
    """
    class MySchema(Schema):
        a = fields.Integer(max_length=3)
        b = fields.Integer()
        c = fields.Integer()

    schema = MySchema()
    value, error_messages = validate_yaml(content, schema)
    assert error_messages == [
        Message(
            "Value is too large.",
            code="max_length",
            context={"limit_value": 3, "length": 4},
            position=Position(column_no=7, line_no=2, char_index=8),
        ),
    ]

# Generated at 2022-06-12 16:16:46.241802
# Unit test for function validate_yaml
def test_validate_yaml():
    # Given
    content = """
      name: alex
      age: 21
      enabled: true
      """

    class UserSchema(Schema):
        name = "User"
        fields = [
            {"name": "name", "type": "string"},
            {"name": "age", "type": "integer"},
            {"name": "enabled", "type": "boolean"},
        ]

    # When
    result = validate_yaml(content, UserSchema)
    value, messages = result

    # Then
    assert value == {"name": "alex", "age": 21, "enabled": True}
    assert len(messages) == 0


# Generated at 2022-06-12 16:16:58.755544
# Unit test for function validate_yaml
def test_validate_yaml():

    valid_yaml_as_json = {"a": 1, "b": 2, "c": {"list": [1, 2, 3], "a": 1}}
    valid_yaml_as_string = yaml.dump(valid_yaml_as_json)

    input_validator = Field.parse(name="input_validator", type="object", children=[{"name": "a", "type": "number"}])
    output_validator = Field.parse(name="output_validator", type="object", children=[{"name": "a", "type": "number"}])

    value, messages = validate_yaml(valid_yaml_as_string, input_validator)
    assert len(messages) == 0

    value, messages = validate_yaml(valid_yaml_as_string, output_validator)
   

# Generated at 2022-06-12 16:17:07.965624
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "TestSchema"
        properties = [
            Field(name="range", type="range(10, 20)")
        ]

    value, error_messages = validate_yaml("range: 50", validator=TestSchema)
    print(value, error_messages)

    # error
    value, error_messages = validate_yaml("range: 50", validator=TestSchema)

    # good
    value, error_messages = validate_yaml("range: 15", validator=TestSchema)
    print(value, error_messages)

    # good
    value, error_messages = validate_yaml("range: '15'", validator=TestSchema)
    print(value, error_messages)

    # error
    value, error

# Generated at 2022-06-12 16:17:19.896675
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - id: 1
      name: x
    """
    validator = Schema(fields={"id": Field(type="integer"), "name": Field(type="string")})
    value, error_messages = validate_yaml(content=content, validator=validator)
    assert value == [{"id": 1, "name": "x"}]
    assert error_messages == []

    content = """
    - id: 1
      name: x
    - id: 2
      phone: 123-456-7890
      """
    validator = Schema(fields={"id": Field(type="integer"), "name": Field(type="string")})
    value, error_messages = validate_yaml(content=content, validator=validator)

# Generated at 2022-06-12 16:17:31.397509
# Unit test for function validate_yaml
def test_validate_yaml():
    import json
    import pprint
    from .schemas import SimpleSchema
    from .fixtures.yaml_small_example import YAML_SMALL_EXAMPLE
    from .fixtures.yaml_small_example_invalid import YAML_SMALL_EXAMPLE_INVALID
    schema = SimpleSchema()

    def assert_valid(value: typing.Any, yaml_str: str) -> typing.Any:
        value, errors = validate_yaml(yaml_str, schema)
        assert value.to_primitive() == json.loads(yaml_str)
        assert errors == []
        return value, errors

    def assert_invalid(yaml_str: str) -> typing.Any:
        value, errors = validate_yaml(yaml_str, schema)
        assert value

# Generated at 2022-06-12 16:17:37.995534
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, Text
    from typesystem.tokenize.tokens import DictToken, ListToken
    from typesystem.tokenize.positional_validation import _get_field_from_path

    # Test a valid document
    schema = Schema(name="", fields=[Integer(name="x"), Text(name="y")])
    (value, error_messages) = validate_yaml(b"{x: 1, y: 'one'}", schema)
    assert value == {"x": 1, "y": "one"}
    assert error_messages == []

    # Test a dict-field that contains a dict

# Generated at 2022-06-12 16:17:49.085591
# Unit test for function validate_yaml
def test_validate_yaml():
    # test_validate_yaml_invalid_yaml()
    print ("test_validate_yaml_invalid_yaml")
    content = "~~~"
    error_message = Message(text="The document is not valid YAML", code="parse_error", position=None)
    assert validate_yaml(content, None)[1] == [error_message]

    # test_validate_yaml_valid_yaml_no_validator()
    print ("test_validate_yaml_valid_yaml_no_validator")
    content = "foo: bar"
    result, errors = validate_yaml(content, None)
    assert not errors
    assert result == {"foo": "bar"}

    # test_validate_yaml_valid_yaml_valid_validator()

# Generated at 2022-06-12 16:17:59.722079
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "---\n"
    token = tokenize_yaml(content)
    validator = Schema
    assert validate_yaml(content, validator) ==({}, [])

    content = "0\n"
    token = tokenize_yaml(content)
    validator = Schema
    assert validate_yaml(content, validator) == ({}, [])

    content = "\n"
    token = tokenize_yaml(content)
    validator = Schema
    assert validate_yaml(content, validator) == ({}, [])

    content = "1\n"
    token = tokenize_yaml(content)
    validator = Schema
    assert validate_yaml(content, validator) == ({}, [])




# Generated at 2022-06-12 16:18:05.970429
# Unit test for function validate_yaml
def test_validate_yaml():
    print("Test validate_yaml")
    import typesystem
    import typesystem.types as types

    validator = typesystem.Schema(
        {"a": 1, "b": types.DateTime()}, strict=True, unknown=types.Strict()
    )
    value, errors = validate_yaml('{"a": 1, "b": "1/1/19"}', validator)
    print("should be errors {0}".format(errors))
    assert errors == []



# Generated at 2022-06-12 16:18:16.614224
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem.fields import String
    validator = String()
    value, error_messages = validate_yaml(
       "key: test", validator
    )
    assert value == "test"
    validator.min_length = 6
    value, error_messages = validate_yaml(
       "key: test", validator
    )
    print(value, error_messages)

# Generated at 2022-06-12 16:18:23.598448
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    first_name: James
    last_name: Bond
    '''

    class PersonSchema(Schema):
        first_name = fields.String()
        last_name = fields.String()

    value, error_messages = validate_yaml(
        content=content,
        validator=PersonSchema
    )
    print(value)
    print(error_messages)

# Generated at 2022-06-12 16:18:33.995226
# Unit test for function validate_yaml
def test_validate_yaml():
    counter = 0
    # test empty YAML content
    try:
        validate_yaml(content = "", validator = Field())
    except ParseError as e:
        assert e.code == "no_content"
        assert e.text == "No content."
        assert e.position.column_no == 1
        assert e.position.line_no == 1
        assert e.position.char_index == 0
        counter += 1
    assert counter == 1

    counter = 0
    # test YAML content
    try:
        validate_yaml(content = "1", validator = Field())
    except ValidationError as e:
        assert e.code == "type_error"
        assert e.text == "Does not match field definition."
        assert e.position.column_no == 1
        assert e.position

# Generated at 2022-06-12 16:18:44.549509
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        invalid_yaml: this is not yaml!
        """
    validator = Schema(properties={"foo": str})
    with pytest.raises(ParseError) as excinfo:
        validate_yaml(content, validator)
    assert str(excinfo.value) == "Invalid YAML."
    content = """
        foo: bar
        """
    validator = Schema(properties={"foo": str})
    value, errors = validate_yaml(content, validator)
    assert value == {"foo": "bar"}
    assert errors == []
    content = """
        foo: 1
        """
    validator = Schema(properties={"foo": str})
    _, errors = validate_yaml(content, validator)

# Generated at 2022-06-12 16:18:50.493618
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema([AnotherField("foo", required=True)])
    content = "foo: awesome"
    value, messages = validate_yaml(content, schema)
    assert value == "awesome"
    #No error messages ^
    assert messages == []

    schema = Schema([Field("foo", required=True)])
    content = "foo: awesome"
    value, messages = validate_yaml(content, schema)
    assert value == {"foo": "awesome"}
    assert messages == []

    schema = Schema([Field("foo", required=True)])
    content = "foo:\n  bar:\n    baz: awesome\n    qux: 123"
    value, messages = validate_yaml(content, schema)

# Generated at 2022-06-12 16:18:59.088641
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    #Tests with wrong inputs
    with pytest.raises(AssertionError):
        tokenize_yaml(None)
    with pytest.raises(AssertionError):
        tokenize_yaml(True)
    with pytest.raises(AssertionError):
        tokenize_yaml(5)

    #Tests with right inputs
    tokenize_yaml("")
    tokenize_yaml("\n")
    tokenize_yaml("{}")
    tokenize_yaml("[]")
    tokenize_yaml("Hi")
    tokenize_yaml("5")
    tokenize_yaml("5.5")
    tokenize_yaml('"test"')
    tokenize_yaml("{test: test}")

# Generated at 2022-06-12 16:19:08.194092
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """\
        a: b
        c:
          - a
          - b
          - c
        d: null
        e: 102.65
    """
    schema = Schema({"a": str, "c": [str], "d": str, "e": float})
    value, errors = validate_yaml(content, schema)
    assert errors == []
    assert value == {
        "a": "b",
        "c": ["a", "b", "c"],
        "d": "null",
        "e": 102.65,
    }

# Generated at 2022-06-12 16:19:18.754653
# Unit test for function validate_yaml

# Generated at 2022-06-12 16:19:25.452048
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert str(tokenize_yaml("foo: bar")) == "<DictToken keys=['foo'], value=OrderedDict([('foo', 'bar')]), start=0, end=7>"
    assert str(tokenize_yaml("foo: bar\n")) == "<DictToken keys=['foo'], value=OrderedDict([('foo', 'bar')]), start=0, end=8>"
    assert str(tokenize_yaml("1\n2\n3\n")) == "<ListToken value=[1, 2, 3], start=0, end=6>"
    assert str(tokenize_yaml("1\n2\n3\n")) == "<ListToken value=[1, 2, 3], start=0, end=6>"

# Generated at 2022-06-12 16:19:36.744820
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Schema

    class PersonSchema(Schema):
        name = String(max_length=10)

    value, error_messages = validate_yaml(
        content='name: "John Smith"',
        validator=PersonSchema,
    )
    assert len(error_messages) == 1
    assert error_messages[0].text == 'Must have no more than 10 characters.'
    assert error_messages[0].code == 'max_length'
    assert error_messages[0].prop_name == 'name'
    assert error_messages[0].position == Position(
        line_no=1,
        column_no=7,
        char_index=6,
    )
    assert error_messages[0].pointer == '#/name'

# Generated at 2022-06-12 16:19:44.927246
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema([Field(name='number', type='number')])
    content = "number: bad value"
    value, error_messages = validate_yaml(content, schema)
    assert len(error_messages) == 1
    assert error_messages[0].text == "'bad value' is not a number."
    assert error_messages[0].position.char_index == len("number: ")

# Generated at 2022-06-12 16:19:55.307697
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String

    class TestSchema(Schema):
        name = String(max_length=10)
        age = Integer(maximum=100)
        secret = String()

    valid, error_messages = validate_yaml(
        """
        name: John Doe
        age: 35
        secret: should not appear
        """,
        TestSchema,
    )

    assert error_messages == []

    assert valid == {
        "name": "John Doe",
        "age": 35,
    }

    _, error_messages = validate_yaml(
        """
        not a schema
        """,
        TestSchema,
    )

    assert len(error_messages) == 1
    assert isinstance(error_messages[0], Message)
    assert error_messages

# Generated at 2022-06-12 16:20:02.967873
# Unit test for function validate_yaml
def test_validate_yaml():
    class User(Schema):
        name = String(max_length=50)
    content = "name: 1" # invalid data
    field = User
    expected_value, expected_errors = (None, [
        {
            "code": "invalid_type",
            "message": "invalid_type",
            "position": (1, 8),
            "path": ["name"],
            "meta": {"expected_type": "string"},
        }
    ])
    assert validate_yaml(content, field) == (expected_value, expected_errors)

# Generated at 2022-06-12 16:20:14.655634
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema): 
        field_1 = fields.String()

    value, error_messages = validate_yaml(content="""
    field_1: not_string
    """, validator=MySchema)

    assert isinstance(value, dict)
    assert value == {'field_1': 'not_string'}
    assert isinstance(error_messages, list)
    assert len(error_messages) == 1
    assert error_messages[0].text == 'Invalid value.'
    assert error_messages[0].code == 'invalid'
    assert isinstance(error_messages[0].position, Position)
    assert error_messages[0].position.column_no == 4
    assert error_messages[0].position.line_no == 2
    assert error_messages

# Generated at 2022-06-12 16:20:24.850397
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    content = """
    {
      "name": "Dave",
      "age": 23,
      "gender": "male",
      "address": {
        "line1": "1 street",
        "line2": "",
        "postcode": "ZZ9 9ZZ"
      },
      "phone_numbers": []
    }
    """

    from typesystem.fields import String, Integer, Object, Array

    class Address(Schema):
        line1 = String()
        line2 = String(required=False)
        postcode = String()

    class Person(Schema):
        name = String()
        age = Integer()
        gender = String()
        address = Object(Address)
        phone_numbers = Array(String)


# Generated at 2022-06-12 16:20:30.519127
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test for function validate_yaml"""
    from typesystem.types import String, Integer

    class Person(Schema):
      name = String(min_length=3, max_length=50)
      age = Integer(minimum=13, maximum=120)

    yaml_content = """
    name: Bob
    age: 21
    """

    result = validate_yaml(content=yaml_content, validator=Person)
    assert result == ({"name": "Bob", "age": 21}, [])

    class PersonWithEmail(Schema):
      name = String(min_length=3, max_length=50)
      age = Integer(minimum=13, maximum=120)
      email = String(formats=["email"])

    yaml_content = """
    name: Bob
    age: 21
    """



# Generated at 2022-06-12 16:20:34.314566
# Unit test for function validate_yaml
def test_validate_yaml():
    y_str = """
    numbers:
        - 1
        - 2
        - 3
    """
    validate_yaml(y_str, Field(type=int, max_length=2))

# Generated at 2022-06-12 16:20:40.351333
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Schema

    class TestSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    # Successful validation.
    value, error_messages = validate_yaml(
        content="""
        name: test
        age: 18
        """,
        validator=TestSchema,
    )
    assert value == {"name": "test", "age": 18}
    assert not error_messages

    # Invalid data.
    value, error_messages = validate_yaml(
        content="""
        name: test
        age: 200  # too big!
        """,
        validator=TestSchema,
    )
    assert value is None

# Generated at 2022-06-12 16:20:45.705073
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.yaml.validate import validate_yaml
    from typesystem.types import String

    string_field = String(max_length=3)
    content = "foo"
    value, error_messages = validate_yaml(content, string_field)
    assert value == "foo"
    assert type(value) == str
    assert error_messages == []


# Generated at 2022-06-12 16:20:50.149142
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        age = fields.Integer(minimum=0)
    content = b"age: -1\n"
    assert validate_yaml(content, Person) == (None, [
        {'position': {'char_index': 1, 'column_no': 1, 'line_no': 1}, 'message': 'age must be greater than or equal to 0.', 'code': 'min_value'}
    ])



# Generated at 2022-06-12 16:20:57.995193
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer  # type: ignore

    field = Integer(required=True)
    content = "2"
    value, _ = validate_yaml(content, field)
    assert value == 2



# Generated at 2022-06-12 16:21:03.821766
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    dog:
      - name: Bruno
        status: active
        type: German Shepherd

      - name: Rex
        status: deceased
        type: Labrador
    """
    tokens = tokenize_yaml(content)
    tokenized_dict = {
        "dog": [
            {
                "name": "Bruno",
                "status": "active",
                "type": "German Shepherd"
            },
            {
                "name": "Rex",
                "status": "deceased",
                "type": "Labrador"
            }
        ]
    }

    assert isinstance(tokens, DictToken)
    assert tokens.value == tokenized_dict
    assert tokens.content == content
    assert isinstance(tokens.value["dog"], ListToken)

# Generated at 2022-06-12 16:21:15.562880
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem.fields import String, Integer

    # Basic case.
    value, error_messages = validate_yaml(
        content="name: a",
        validator={"name": String()},
    )
    assert {'name': 'a'} == value
    assert error_messages == []

    # Basic parse error.
    value, error_messages = validate_yaml(
        content="name: a\ninvalid_line",
        validator={"name": String()},
    )
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "cannot be deciphered in plain scalar."
    assert error_messages[0].position.line_no == 2

# Generated at 2022-06-12 16:21:23.649975
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """\
- id: 1
  name: john
- id: 2
  name
"""
    class User(Schema):
        id = Integer(min_value=1, max_value=2)
        name = String()

    class UserCollection(Schema):
        users = List(items=User())

    class UserSchema(Schema):
        users = UserCollection()

    value, errors = validate_yaml(content, UserSchema())
    assert errors == [
        ValidationError(
            code="missing",
            text='Missing key "name".',
            position=Position(
                char_index=26, column_no=15, line_no=3
            ),
            key="users",
        )
    ]



# Generated at 2022-06-12 16:21:30.161299
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        field =  String(max_length=10)

    content = '{"field": "hello"}'
    value, error_messages = validate_yaml(content, TestSchema)
    expect_value = {"field": "hello"}
    assert value == expect_value
    assert not error_messages

    content = '{"field": "Hello world!"}'
    value, error_messages = validate_yaml(content, TestSchema)
    expect_error_messages = [
        {
            "text": "Must have no more than 10 characters.",
            "code": "max_length",
            "position": {
                "line_no": 1,
                "column_no": 13,
                "char_index": 12,
            },
        }
    ]
    assert value

# Generated at 2022-06-12 16:21:34.998463
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
            name: test
            age: 5
        '''
    validator = Schema(fields=[
        Field(name='name', type='string'),
        Field(name='age', type='integer')
    ])

    value, error_messages = validate_yaml(content=content, validator=validator)

    assert not error_messages
    assert value == {'name': 'test', 'age': 5}

# Generated at 2022-06-12 16:21:40.429798
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    b: test1
    """
    class TestSchema(Schema):
        a = 123
        b = 'test'
    value, error_messages = validate_yaml(content, TestSchema)
    assert len(error_messages) == 2

# Generated at 2022-06-12 16:21:50.180631
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: 'Alice'
    age: 21
    is_admin: true
    """

    class User(Schema):
        name = Field(type=str)
        age = Field(type=int)
        is_admin = Field(type=bool)

    value, errors = validate_yaml(content=content, validator=User)
    # value = {'name': 'Alice', 'age': 21, 'is_admin': True}

# Generated at 2022-06-12 16:21:58.853433
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Dict, List, Number
    from typesystem.schemas import Schema

    class BaseSchema(Schema):
        class Meta:
            field_classes = [String, Dict, List, Number]

    data = """name: John
    age: 42
    favorite_colors:
        - red
        - blue
        - green
    """

    (result, errors) = validate_yaml(data, BaseSchema)
    if errors:
        print('yaml errors:')
        for item in errors:
            print(item)



# Generated at 2022-06-12 16:22:06.632884
# Unit test for function validate_yaml
def test_validate_yaml():
    class IntegerSchema(Schema):
        num = Field(type="integer", required=True)

    empty_string = ""
    empty_result = validate_yaml(empty_string, validator=IntegerSchema)

    assert isinstance(empty_result, Message)
    assert empty_result.code == "no_content"
    assert empty_result.text == "No content."
    assert empty_result.position.char_index == 0
    assert empty_result.position.column_no == 1
    assert empty_result.position.line_no == 1

    yaml_string = f"""
    num: 10
    """
    value, error_messages = validate_yaml(yaml_string, validator=IntegerSchema)