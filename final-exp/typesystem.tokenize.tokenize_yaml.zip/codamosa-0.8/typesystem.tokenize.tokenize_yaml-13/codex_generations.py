

# Generated at 2022-06-12 16:12:21.678579
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("hello: world") == DictToken({'hello': 'world'}, 0, 10, content='hello: world')
    assert tokenize_yaml("hello: 123") == DictToken({'hello': 123}, 0, 9, content='hello: 123')
    assert tokenize_yaml("- 123") == ListToken([123], 0, 4, content='- 123')
    assert tokenize_yaml("- 123") == ListToken([123], 0, 4, content='- 123')
    assert tokenize_yaml("hello: [\n     123,\n     123\n     ]") == DictToken({'hello': [123, 123]}, 0, 39, content='hello: [\n     123,\n     123\n     ]')

# Generated at 2022-06-12 16:12:29.940707
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_string = """
    foo:
        - bar
        - baz
    """
    root_token = tokenize_yaml(yaml_string)

    assert isinstance(root_token, DictToken)
    assert len(root_token.items) == 1
    value_token = root_token.items[0][1]
    assert isinstance(value_token, ListToken)
    assert value_token.value == ["bar", "baz"]
    assert value_token.start == 6
    assert value_token.end == 30


# Generated at 2022-06-12 16:12:35.870004
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Setup
    content = """
    title: Hello
    list:
      - 11
      - 22
      - 33
    """
    # Exercise
    actual = tokenize_yaml(content)

    # Verify
    assert actual["title"] == "Hello", "Field 'title' not mapped correctly"
    assert actual["list"] == [11, 22, 33], "Field 'list' not mapped correctly"



# Generated at 2022-06-12 16:12:46.741552
# Unit test for function tokenize_yaml
def test_tokenize_yaml():  # pylint: disable=unused-import
    assert yaml is not None, "'pyyaml' must be installed."

    # Test the empty string case.
    with pytest.raises(ParseError) as excinfo:
        tokenize_yaml("")
    message = excinfo.value.messages[0]
    assert isinstance(message, Message)
    assert message.code == "no_content"

    # Test a successful parse.
    content = """
    test1:
      hello: world
    test2:
      hello: world
      foo: bar
    test3: [one, two, three]
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.key == "root"
    assert isinstance(token.value, dict)

# Generated at 2022-06-12 16:12:51.017148
# Unit test for function validate_yaml
def test_validate_yaml():
    validator =  {"elements": {"type": "string"}}
    data = "{elements: [a,b,c]}"
  
    validate_yaml(data, validator)

# Generated at 2022-06-12 16:12:56.840319
# Unit test for function validate_yaml
def test_validate_yaml():
    from yaml import load as yaml_load
    from yaml.scanner import ScannerError as YamlScannerError
    from yaml.parser import ParserError as YamlParserError
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class MySchema(Schema):
        field = String()

    # Asserting valid YAML
    obj, error_messages = validate_yaml(r'field: "hello"', MySchema)
    assert obj == {"field": "hello"}
    assert len(error_messages) == 0

    # Asserting invalid YAML
    with pytest.raises(YamlScannerError) as exc:
        yaml_load(r'field: "hello', Loader=SafeLoader)

# Generated at 2022-06-12 16:12:59.510496
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem.types import String, Integer

    class ExampleSchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: Tyler
    age: 34
    """

    value, error_messages = validate_yaml(content, validator=ExampleSchema)

    assert value == {"name": "Tyler", "age": 34}
    assert not error_messages

# Generated at 2022-06-12 16:13:08.110194
# Unit test for function validate_yaml
def test_validate_yaml():
    #schema = Field(sub_field=Field(sub_field=Field(sub_field=Field(type=int)), type=int), type=int)
    schema = Field(sub_field=Field(sub_field=Field(sub_field=int)), type=int)
    with pytest.raises(ValidationError) as err:
        validate_yaml(content='{"sub_field": {"sub_field": {"sub_field": "yes"}}}', validator=schema)
    assert isinstance(err.value.messages, list)
    assert len(err.value.messages) == 1
    assert err.value.messages[0].code == "invalid_type"

test_validate_yaml()

# Generated at 2022-06-12 16:13:14.669500
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert (tokenize_yaml('foo: bar') == DictToken({'foo': 'bar'}, 0, 10, 'foo: bar'))
    assert (
        tokenize_yaml('- bar: foo\n- foo: bar')
        == ListToken([{'bar': 'foo'}, {'foo': 'bar'}], 0, 22, '- bar: foo\n- foo: bar')
    )
    assert (tokenize_yaml('12345, 12') == ListToken([12345, 12], 0, 8, '12345, 12'))
    assert (tokenize_yaml('12, 12345') == ListToken([12, 12345], 0, 8, '12345, 12'))

# Generated at 2022-06-12 16:13:17.105197
# Unit test for function validate_yaml
def test_validate_yaml():
    result, error_messages = validate_yaml('name: rad')
    assert result == {'name': 'rad'}


# Generated at 2022-06-12 16:13:26.981668
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Unit test for function validate_yaml
    """

    # Test with a schema class.
    # A simple test schema class.
    def assert_no_errors(token, error_messages):
        print("Number of errors: {}".format(len(error_messages)))
        assert len(error_messages) == 0
        return True

    class TestSchema(Schema):
        """
        A test schema
        """
        name = "TestSchema"
        id = "test_schema"
        summary = "Test schema"
        description = "Description of the test schema"
        version = "1.0"
        _ids = {
            "root": "test_schema.yaml",
            "definitions": {
                "TestDef": "#/definitions/TestDef"
            }
        }

# Generated at 2022-06-12 16:13:35.927434
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String

    content = "foo"
    errors = validate_yaml(content, String(max_length=2))[1]
    assert len(errors) == 1

    content = "foo"
    errors = validate_yaml(content, String(max_length=3))[1]
    assert len(errors) == 0

    content = "foo"
    errors = validate_yaml(content, String(max_length=3))[1]
    assert len(errors) == 0

    content = "foo"
    errors = validate_yaml(content, String(max_length=3))[1]
    assert len(errors) == 0

    content = """
        foo:
            - bar
            - baz
        """

# Generated at 2022-06-12 16:13:39.014762
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    print(tokenize_yaml('---\nscalar: "value"\nlist:\n  - 1\n  - 2\n'))

# Generated at 2022-06-12 16:13:45.579124
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
        a:
          - b
          - c
          - d
        e: 2.5
        f: true
        g: null
    '''
    token = tokenize_yaml(content=content)
    assert token.value == {
        "a": ["b", "c", "d"],
        "e": 2.5,
        "f": True,
        "g": None,
    }



# Generated at 2022-06-12 16:13:50.788536
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, Object

    content = b"""
    a: 42
    """

    class Person(Object):
        name = Integer(required=True)

    value, error_messages = validate_yaml(content, Person)
    assert error_messages[0] == Message(
        text="Field 'a' is required.",
        code="required_field",
        position=Position(line_no=2, column_no=5, char_index=11),
    )

# Generated at 2022-06-12 16:13:57.587576
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: bob
    age: 29
    """
    validator = Field(
        name="user", type="object", fields={"name": Field(type="string"), "age": Field(type="integer")}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "bob", "age": 29}
    assert error_messages == []



# Generated at 2022-06-12 16:14:08.356979
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
    validator = Person()
    result = validate_yaml(b"{name: 'John'}", validator)
    value, errors = result
    assert errors == []
    assert value == {'name': 'John'}
    result = validate_yaml(b"{name: 'Th'}", validator)
    value, errors = result
    assert errors == [Message(text='Must be no more than 100 characters.', code='max_length', position=Position(line_no=1, column_no=9, char_index=8))]
    assert value == ValidationError
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 9
    assert errors[0].position.char_index

# Generated at 2022-06-12 16:14:19.301204
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(
        name="name",
        primitive_type=str,
        description="field description",
        required=True,
        validators=[lambda v: len(v) > 0],
    )
    content = b"name: test name\n"
    value = validate_yaml(content, field)
    assert value[0] == "test name"
    assert len(value[1]) == 0

    content = b"name: \n"
    value = validate_yaml(content, field)
    assert value[0] == None
    assert len(value[1]) == 1

    schema = type("Name", (Schema,), {"name": field})
    content = b"name: test name\n"
    value = validate_yaml(content, schema)

# Generated at 2022-06-12 16:14:24.073979
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer

    result, errors = validate_yaml(
        content="""
            foo: 123.0
            bar: "baz"
        """,
        validator={"foo": Integer(), "bar": str},
    )
    print(result)
    print(errors)



# Generated at 2022-06-12 16:14:28.376924
# Unit test for function validate_yaml
def test_validate_yaml():
    text = '{"my_field": "my_value"}'
    schema = type("MySchema", (Schema,), {"my_field": Field(required=True)})
    value, errors = validate_yaml(text, schema)
    assert value == {"my_field": "my_value"}



# Generated at 2022-06-12 16:14:37.940454
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = fields.String(max_length=10)

    test_schema = MySchema()
    test_input= '''
    name: hello
    '''

    value, errors = validate_yaml(test_input, test_schema)

    assert value == {'name': 'hello'}
    assert len(errors) == 0



# Generated at 2022-06-12 16:14:42.963374
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer", required=False)

    assert validate_yaml(
        b"name: Mark\nage: 28", Person
    ) == (
        {"name": "Mark", "age": 28},
        [],
    )



# Generated at 2022-06-12 16:14:49.139717
# Unit test for function validate_yaml
def test_validate_yaml():
 
    # test for error message
    content = """
        name: Gola
        age: 10
    """
    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer()
        a = fields.String()

    value, error = validate_yaml(content, PersonSchema)
    assert error.message == "Additional properties are not allowed ('a' was unexpected)"
    assert error.position.line_no == 4
    assert error.position.column_no == 3

    #test for if no error is produced
    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    value, error = validate_yaml(content, PersonSchema)
    assert value['name'] == 'Gola'
    assert value['age'] == 10

# Generated at 2022-06-12 16:14:59.819001
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from addok.helpers import config
    config.DATA_COLLECTION = "A"

    from addok.core import DB
    from addok.helpers.text import normalize
    DB.flushdb()
    config.AUTOCOMPLETE_LIMIT = 10
    DB.execute_command("FT.CREATE", "idx", "ON", "HASH", "SCHEMA", "name", "text")
    DB.hset("A:city:123", "name", "Tourcoing")
    DB.hset("A:city:234", "name", "Lille")
    DB.hset("A:city:345", "name", "Roubaix")

# Generated at 2022-06-12 16:15:10.909728
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test parsing empty content
    with pytest.raises(ParseError) as exc:
        validate_yaml(b"", Schema)
    assert "No content." in exc.value.text
    assert exc.value.position.line_no == 1
    assert exc.value.position.column_no == 1

    # Test parsing YAML with syntax errors
    with pytest.raises(ParseError) as exc:
        validate_yaml(b"Invalid YAML", Schema)
    assert "mapping values are not allowed here" in exc.value.text
    assert exc.value.position.line_no == 1
    assert exc.value.position.column_no == 14

    # Test parsing YAML with unicode errors
    with pytest.raises(ParseError) as exc:
        validate_y

# Generated at 2022-06-12 16:15:22.777462
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()

    result = validate_yaml(
        content="{{ name: {{}}".encode("utf-8"),
        validator=Person,
    )
    assert result == (
        None,
        [
            Message(
                text="Invalid field definition in dictionary.",
                code="invalid_field",
                position=(Position(column_no=6, line_no=1, char_index=6)),
            )
        ],
    )

    result = validate_yaml(
        content="{{ name: {{}}".encode("utf-8"),
        validator=String(),
    )

# Generated at 2022-06-12 16:15:28.991630
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    company: "Acme"
    people:
      - id: 1
        name: "Alice"
      - id: 2
        name: "Bob"
    """
    class Person(Schema):
        id = Integer()
        name = String()

    class Company(Schema):
        company = String()
        people = List(items=Person)

    Company.validate(content)

# Generated at 2022-06-12 16:15:37.372812
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import get_position_message
    from typesystem.tokenize.positional_validation import get_position_name

    class Person(Schema):
        first_name = String(allow_blank=False)
        last_name = String(allow_blank=False)

    data = b"""
    first_name:
    last_name:
    """

    value, messages = validate_yaml(data, Person)
    assert len(messages) == 2
    names = [get_position_name(message) for message in messages]
    assert "first_name" in names
    assert "last_name" in names
    positions = [get_position_message(message) for message in messages]


# Generated at 2022-06-12 16:15:44.071254
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("2017-01-25") == ScalarToken("2017-01-25", 0, 10, content="2017-01-25")
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[1, 2]") == ListToken([1, 2], 0, 5, content="[1, 2]")

# Generated at 2022-06-12 16:15:46.940388
# Unit test for function validate_yaml
def test_validate_yaml():
    error_messages = validate_yaml(
        content="foo",
        validator=Field(required=True, validators=[lambda x: int(x)])
    )[1]
    assert len(error_messages) == 1
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 1
    assert error_messages[0].position.char_index == 0



# Generated at 2022-06-12 16:15:58.066553
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema
    from typesystem import types

    class CustomSchema(Schema):
        a = String(description="String field.")
        b = Integer(description="Integer field.")
        c = Integer(description="Optional Integer field.", required=False)

    schema = CustomSchema()
    content = b"""
    a: "hello"
    b: 1
    """

    value, errors = validate_yaml(content, schema)
    assert value == {"a": "hello", "b": 1}
    assert not errors

    errors = schema.validate_yaml(content)
    assert not errors

    content = b"""
    a: "hello"
    b: "1"
    """

    value, errors = validate_yaml(content, schema)

# Generated at 2022-06-12 16:16:03.819349
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # test edge case
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}, "tokenize_yaml(\"{{}}\") is not empty"
    assert tokenize_yaml("[]") == [], "tokenize_yaml(\"[]\") is not empty"

# Generated at 2022-06-12 16:16:12.413763
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    yaml_string = '''users:
    - username: bob
      email: bob@bob.com
      age: 33'''

    class UserSchema(Schema):
        username = fields.String()
        email = fields.String()
        age = fields.Integer()

    user_schema = UserSchema()

    user, error_messages = validate_yaml(yaml_string, user_schema)

    assert not error_messages
    assert user['username'] == 'bob'
    assert user['email'] == 'bob@bob.com'
    assert user['age'] == 33



# Generated at 2022-06-12 16:16:16.519599
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "{'age': 30}"
    schema = Schema(age=Field(typ=int))
    assert validate_yaml(content, schema) == ({'age': 30}, [])

# Generated at 2022-06-12 16:16:27.809893
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)
        salary = Field(type=float, required=False)
        is_employee = Field(type=bool, required=False)
    
    # Content - Valid case
    content = '''\
    name: John
    age: 43'''
    result_valid, messages_valid = validate_yaml(content, validator=PersonSchema)

    assert result_valid == {'name': 'John', 'age': 43}
    assert messages_valid == []

    # Content - Invalid case - Missing field
    content = '''\
    name: John'''
    result_invalid, messages_invalid = validate_yaml(content, validator=PersonSchema)

    assert result_invalid is None


# Generated at 2022-06-12 16:16:36.294117
# Unit test for function validate_yaml
def test_validate_yaml():
    content1 = "name: test_name"
    validator1 = Field(name="name", type="string", required=True)

    value1, error_messages1 = validate_yaml(content1, validator1)
    assert value1 == {"name": "test_name"}
    assert len(error_messages1) == 0

    content2 = "age: 20"
    validator2 = Field(name="age", type="integer", required=True)
    # Test for a scalar type mismatch
    value2, error_messages2 = validate_yaml(content2, validator2)
    assert value2 is None
    assert len(error_messages2) == 1
    assert error_messages2[0].code == "type_error"
    assert error_messages2[0].line_no == 1


# Generated at 2022-06-12 16:16:45.708233
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem
    import typesystem.types as types

    class BasicSchema(typesystem.Schema):
        field1 = types.String(max_length=10)
        field2 = types.Integer()

    content = """
    field1: hi
    field2: 5
    """
    value, errors = validate_yaml(content, BasicSchema)
    assert value == {"field1": "hi", "field2": 5}
    assert errors == []

    content = """
    field1: hi
    field2: 'five'
    """

    value, errors = validate_yaml(content, BasicSchema)
    assert value is None

# Generated at 2022-06-12 16:16:49.292574
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "foo: 'bar'"
    validator = fields.String()
    value = validate_yaml(content, validator)
    assert value == ("bar", [])


# Generated at 2022-06-12 16:16:54.594384
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("[1, 2, 3]") == ListToken([1, 2, 3], 0, 8)
    assert tokenize_yaml("{a: 1, b: 2, c: 3}") == DictToken({"a": 1, "b": 2, "c": 3}, 0, 14)
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0)
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3)

# Generated at 2022-06-12 16:17:05.301213
# Unit test for function validate_yaml
def test_validate_yaml():
    class BasicSchema(Schema):
        name = Field(str)
        count = Field(int)

    # Test validation success.
    value, errors = validate_yaml(
        "name: Some Name\ncount: 10", BasicSchema
    )
    assert errors == []
    assert value == {"name": "Some Name", "count": 10}

    # Test validation failure.
    value, errors = validate_yaml(
        "name: Some Name\ncount: invalid", BasicSchema
    )
    assert len(errors) == 1
    assert errors[0].code == "invalid"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 7
    assert errors[0].position.char_index == 18
    assert errors[0].params == {}

    #

# Generated at 2022-06-12 16:17:11.937841
# Unit test for function validate_yaml
def test_validate_yaml():
    result = validate_yaml(b"1", int)
    assert result == (1, None)
    result = validate_yaml(b"1", str)
    assert result[1] == [
        Message(
            text="Expected a string.",
            code="expected_string",
            position=Position(column_no=1, line_no=1, char_index=0),
        )
    ]

# Generated at 2022-06-12 16:17:19.355932
# Unit test for function validate_yaml
def test_validate_yaml():
    contents =[
        """
        name: jay
        age: 25
        """,
        """
        name: jay
        """,
        """
        name: jay 
        age: '25'
        """,
        """
        name: jay 
        """,
        """
        name: jay 
        age: 25
        """,
        """
        name: 'jay'
        age: 25
        """
        ]
    for content in contents:
        value, error = validate_yaml(content, PersonSchema)
        assert error == []


# Generated at 2022-06-12 16:17:30.680957
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test 1.1
    content = "hello: 'world'"
    validator = Schema(
        {
            "hello": str
        },
    )
    value, errors = validate_yaml(content, validator)
    assert errors == []

    # Test 1.2
    content = "hello: world"
    validator = Schema(
        {
            "hello": str
        },
    )
    value, errors = validate_yaml(content, validator)
    assert len(errors) == 1
    assert errors[0].code == "type_error"
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 8
    assert errors[0].position.char_index == 7

    # Test 1.3
    content = "hello: 'world"


# Generated at 2022-06-12 16:17:37.657842
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    import yaml

    yaml_string = """
    example_schema_field:
      - hello
      - world
    example_schema_field2:
      - hello
      - world
    """

    class ExampleSchema(Schema):
        example_field = String(validators=[
            lambda x: x == "hello"
        ])
        example_field2 = String(validators=[
            lambda x: x == "world"
        ])

    res = validate_yaml(content=yaml_string, validator=ExampleSchema)

# Generated at 2022-06-12 16:17:47.868440
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "".join(["""\
        a: 1
        b: 2
        c: xyz
    """])
    content_bytes = bytes(content, encoding='utf-8')
    validator = Schema(
        fields={
            "a": int,
            "b": int,
            "c": str,
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == [
        Message(
            text="Could not parse value 'xyz' as a valid integer.",
            code="invalid_type",
            pointer="$.c",
            start=21,
            end=25,
        ),
    ]

# Generated at 2022-06-12 16:17:59.640390
# Unit test for function validate_yaml
def test_validate_yaml():
    invalid = """
        x: []
        """

    assert validate_yaml(invalid, typing.List[str])[1] == [
        Message(
            text="Expected a value of type 'str'.",
            position=Position(line_no=2, column_no=8, char_index=14),
            code="invalid_type",
        )
    ]

    invalid = """
        x:
          key: hello
        """

    assert validate_yaml(invalid, {"key": str})[1] == [
        Message(
            text="'key' is a required field.",
            position=Position(line_no=3, column_no=11, char_index=27),
            code="invalid_type",
        )
    ]


# Generated at 2022-06-12 16:18:10.842327
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    from typesystem.types import String

    class YAMLSchema(Schema):
        int_field = Integer(required=True)
        str_field = String(required=True)

    validator = YAMLSchema()

    # Passing validation.
    yaml_content = "int_field: 3\nstr_field: 'hello'"
    value, messages = validate_yaml(content=yaml_content, validator=validator)
    assert value == {"int_field": 3, "str_field": "hello"}
    assert messages == []

    # Parse error
    yaml_content = "int_field: 3\nstr_field: 'hello\n'\n"

# Generated at 2022-06-12 16:18:15.231945
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Schema

    class User(Schema):
        name = String
        age = Integer

    content = "name: Jan\nage: 42"
    value, errors = validate_yaml(content, validator=User)
    assert value == {"name": "Jan", "age": 42}
    assert not errors



# Generated at 2022-06-12 16:18:21.057432
# Unit test for function validate_yaml
def test_validate_yaml():
    '''
    This function unit tests for validate_yaml function in tokenize.yaml.py.
    :return: None
    '''
    # Valid yaml string
    content = "name: John\nage: 23"
    validator = Schema.of(
        {"name": Field(str), "age": Field(int)}
    )
    assert validate_yaml(content, validator) == (
        {"name": "John", "age": 23},
        [],
    )

    # YAML parse error, raise ParseError in validate_yaml
    content = "name: John\nage: abc"
    try:
        validate_yaml(content, validator)
    except ParseError:
        assert True
    else:
        assert False
    
    # Validation error, return Validation

# Generated at 2022-06-12 16:18:32.379315
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    import os
    import pytest
    from pathlib import Path

    try:
        file_dir = os.path.dirname(os.path.realpath(__file__))
        parent_dir = os.path.dirname(file_dir)
        # print("parent:", parent_dir)
        path = Path(parent_dir + "/test_data/test_yaml.yaml")
        # print("path:", path)
        with open(path, "r") as infile:
            content = infile.read()
    except FileNotFoundError: # pragma: no cover
        pytest.exit("Error: 'test_yaml.yaml' test data not found.")
        content = ""

    # print("content:",

# Generated at 2022-06-12 16:18:44.950589
# Unit test for function validate_yaml
def test_validate_yaml():
    # a valid string
    content = u"""
    - id: 1
      name: John Smith
    - id: 2
      name: Tom Smith
    """
    validator = typing.List[
        typing.Dict[str, typing.Union[str, int]]
    ]  # this is a valid python validator
    assert validate_yaml(content, validator)[0] == [
        {"id": 1, "name": "John Smith"},
        {"id": 2, "name": "Tom Smith"},
    ]
    assert isinstance(validate_yaml(content, validator)[1], list)
    assert not validate_yaml(content, validator)[1]

    # an invalid string
    content = u"""
    - id: 1
      name: John Smith
    - id: 2
    """

# Generated at 2022-06-12 16:18:50.606367
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)
        age = Integer(minimum=18)

    content = b"""
    name: Luke
    age: 22
    """.strip()
    result = validate_yaml(content, MySchema)
    assert result == ({"age": 22, "name": "Luke"}, [])

    content = b"""
    age: 18
    """.strip()
    result = validate_yaml(content, MySchema)
    assert result == (None, [Message("This field is required.", "required")])

    content = b"""
    name: Luke
    age: 15
    """.strip()
    messages = validate_yaml(content, MySchema)[1]

# Generated at 2022-06-12 16:18:59.170147
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Field(required=True, type="string")

    # Test that the function raises an Error with correct message when the input is invalid
    with pytest.raises(ValidationError) as exc_info:
        validate_yaml(content=b"\x80", validator=schema)

    errors = exc_info.value.errors

    assert isinstance(errors, list)
    assert len(errors) == 1

    error = errors[0]
    assert isinstance(error, ValidationError)
    assert error.code == "invalid_type"
    assert error.text == "Expected a value of type 'string'."

    assert isinstance(error.position, Position)
    assert error.position.line_no == 1
    assert error.position.column_no == 1
    assert error.position.char_index == 0



# Generated at 2022-06-12 16:19:11.201810
# Unit test for function validate_yaml
def test_validate_yaml():
    class DaySchema(Schema):
        number = Field(type="integer")
        name = Field(type="string")

    class WeekSchema(Schema):
        days = Field(type=["list", DaySchema])

    content = """
    days:
    - number: 1
      name: "Monday"
    - number: 2
      name: "Tuesday"
    - number: 3
      name: "Wednesday"
    - number: 4
      name: "Thursday"
    - number: 5
      name: "Friday"
    - number: 6
      name: "Saturday"
    - number: 7
      name: "Sunday"
    """
    data, errors = validate_yaml(content, WeekSchema)
    assert data["days"][2]["number"] == 3
    assert errors == []



# Generated at 2022-06-12 16:19:15.779080
# Unit test for function validate_yaml
def test_validate_yaml():
    from tests.fixtures.schemas import PersonSchema
    errors = validate_yaml(
        b"""
        name: John Smith
        age: 42
        height:
          value: 72
          units: inches
    """,
        validator=PersonSchema,
    )
    assert errors == []


# Generated at 2022-06-12 16:19:22.283312
# Unit test for function validate_yaml
def test_validate_yaml():
    from yaml import dump, load

    class Person(Schema):
        name = fields.String()
        age = fields.Integer()

    def test_validation(value):
        value, errors = validate_yaml(dump(value), Person)
        assert errors == [], "Expected errors to be empty."
        assert value == {'name': 'Jon Snow', 'age': 24}

    test_validation({'name': 'Jon Snow', 'age': 24})
    test_validation(load('{name: Jon Snow, age: 24}'))



# Generated at 2022-06-12 16:19:33.604002
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
        foo: bar
        baz:
            - qux
            - quux
            - quuz
        corge: 4
    '''
    validator = Schema(
        {
            'foo': str,
            'baz': [str],
            'corge': Field(int, gt=3)
        }
    )

    class InvalidSchema(Schema):
        baz = [str]
        corge = Field(int)
    
    invalid_schema = InvalidSchema()

    value, error_messages = validate_yaml(content, validator)
    assert error_messages == []

    value, error_messages = validate_yaml(content, invalid_schema)
    assert len(error_messages) == 1

# Generated at 2022-06-12 16:19:43.542226
# Unit test for function validate_yaml
def test_validate_yaml():
    from parser import validate_content
    from tests.test_parsers import TestParser
    from tests.typesystem_csvs.schema import TestSchema

    class TestSchema(TestSchema):
        parser = TestParser


# Generated at 2022-06-12 16:19:54.365652
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    raw_yaml = '''
            a:
              c: "test"
              d: 42
              e: true
              f: null
              g:
                - 1
                - 2
                - 3
            '''

    token = tokenize_yaml(raw_yaml)
    assert isinstance(token, DictToken)
    assert token.value == {
        "a": {
            "c": "test",
            "d": 42,
            "e": True,
            "f": None,
            "g": [1, 2, 3],
        }
    }

    # Check the scan positions are correct
    assert token.start_index == 1
    assert token.stop_index == 60

    # Check the position information is correct
    assert token.position.line_no == 3

# Generated at 2022-06-12 16:20:04.501626
# Unit test for function validate_yaml
def test_validate_yaml():
    # Validating against a string type should pass
    value, errors = validate_yaml(
        """
        - hello
        - world
        - 123
        - "123"
        - 123.123
        - 123.0
        - true
        - false
        - null
        """,
        validator=str,
    )

# Generated at 2022-06-12 16:20:19.106194
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import Dict, List
    from typesystem.types import Integer, String
    from typesystem.schemas import Schema
    
    # Parse errors
    with pytest.raises(ParseError):
        validate_yaml('{"foo" : "bar"},', Schema({'foo': String()}))

    # Validation Errors
    with pytest.raises(ValidationError):
        validate_yaml('{}', Schema({'foo': String()}))

    # List
    with pytest.raises(ValidationError):
        validate_yaml('{"foo": []}', Schema({'foo': String()}))


# Generated at 2022-06-12 16:20:25.626943
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: This is an example YAML document
    description: This is an example description
    """
    schema = Schema(
        {
            "name": Field(str, required=True),
            "description": Field(str, required=True),
        }
    )
    data, errors = validate_yaml(content, schema)
    assert data == {
        'name': 'This is an example YAML document',
        'description': 'This is an example description'
    }
    assert errors == []



# Generated at 2022-06-12 16:20:33.883472
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    x:
        y:
            z: 0
    """
    validator = Schema(
        {
            "x": {"type": "object"},
            "x.y": {"type": "object"},
            "x.y.z": {"type": "integer"},
        }
    )
    value, errors = validate_yaml(content=content, validator=validator)
    assert len(errors) == 0

# Generated at 2022-06-12 16:20:44.751467
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.typing import (
        Boolean,
        Dict,
        Integer,
        List,
        String,
    )
    from typesystem.fields import BooleanField, DateField, Field

    class MySchema(Schema):
        name = String()
        age = Integer(min_value=0, max_value=100)
        is_happy = Boolean()
        bio = String(required=False)
        home = String(choice=['east', 'west'])
        children = List(items=String())
        pets = Dict(fields={
            'name': String(),
            'birthday': DateField(format="%Y-%m-%d"),
        })

# Generated at 2022-06-12 16:20:51.289698
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Array, validator
    from typesystem import Schema
    from typesystem.fields import Field
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = String()
        friends = Array(String)

    assert isinstance(validate_yaml(b"", String())[0], StringToken)
    assert isinstance(validate_yaml(b"", Person())[0], DictToken)
    assert isinstance(validate_yaml(b"", validator(Person))[0], DictToken)
    assert isinstance(validate_yaml(b"", Field(validator=Person))[0], DictToken)



# Generated at 2022-06-12 16:20:57.327880
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    content = """
    people:
      - name: James
        age: 20
      - name: Abby
        age: 20
        unknown: This is invalid
    """

# Generated at 2022-06-12 16:21:03.027232
# Unit test for function validate_yaml
def test_validate_yaml():
    class CharacterSchema(Schema):
        name = Field(str)
        age = Field(int)
        is_human = Field(bool)
        bio = Field(str, nullable=True)

    good_content = '''
    name: Obi-Wan
    age: 47
    is_human: true
    bio: A venerable Jedi Master of the Galactic Republic.
    '''

    bad_content = '''
    name: Obi-Wan
    age: "47"
    is_human: true
    bio: A venerable Jedi Master of the Galactic Republic.
    '''

    errors = validate_yaml(bad_content, CharacterSchema())

    for error in errors:
        print(error)



# Generated at 2022-06-12 16:21:14.627146
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    input_string = '''
        name: Bob
        age: 34
    '''
    (person, errors) = validate_yaml(input_string, PersonSchema)
    assert person["name"] == "Bob"
    assert person["age"] == 34
    assert not errors

    input_string = '''
        name: ['Bob', 'Jane']
        age: 34
    '''
    (person, errors) = validate_yaml(input_string, PersonSchema)
    assert person["name"] == ["Bob", "Jane"]
    assert person["age"] == 34
    assert not errors


# Generated at 2022-06-12 16:21:21.300887
# Unit test for function validate_yaml
def test_validate_yaml():
    # Initial setup
    schema = Schema(
        fields={"amount": {"type": "number", "required": "True"},}
    )
    incorrect_yaml = '{"amount":"100"}'
    correct_yaml = '{"amount":100}'
    correct_yaml_dict = {"amount":100}
    
    # Testing valid YAML
    value, errors = validate_yaml(correct_yaml, schema)
    print("value:", value)
    assert errors == []
    assert value == correct_yaml_dict

    # Testing invalid YAML
    value, errors = validate_yaml(incorrect_yaml, schema)
    print("value:", value)
    print("errors:", errors)
    assert errors != []

# Generated at 2022-06-12 16:21:28.580210
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "---\n" \
              "- 1\n" \
              "- 'John Smith'\n" \
              "---\n" \
              "1\n"
    token = tokenize_yaml(content)
    # list_token = [
    #     ScalarToken('1', start=3, end=3, content=content),
    #     ScalarToken('John Smith', start=9, end=19, content=content),
    # ]
    # dict_token1 = DictToken({}, start=0, end=0, content=content)
    # dict_token2 = DictToken({}, start=22, end=22, content=content)
    # list_token2 = [
    #     dict_token1, dict_token2,
    # ]
    # assert list_token == [token

# Generated at 2022-06-12 16:21:33.272077
# Unit test for function validate_yaml
def test_validate_yaml():
    """Test validate_yaml function."""
    assert validate_yaml(content="a: b", validator={"a": str}) is not None

# Generated at 2022-06-12 16:21:41.000640
# Unit test for function validate_yaml
def test_validate_yaml():
    class ExampleSchema(Schema):
        name = "string"
        age = "integer"
        weight = "float"

    content = """name: John
age: 32
weight: 425.32
"""

    value, errors = validate_yaml(content, ExampleSchema)

    assert value == {"name": "John", "age": 32, "weight": 425.32}
    assert errors is None



# Generated at 2022-06-12 16:21:50.474778
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "TestSchema"
        fields = [{"name": "test"}]
    errors = validate_yaml("test", validator=TestSchema)
    assert errors is None
    errors = validate_yaml("test", validator=TestSchema(required=True))
    assert errors is None
    errors = validate_yaml("", validator=TestSchema)
    assert len(errors) == 1
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 1
    errors = validate_yaml("", validator=TestSchema(required=True))
    assert len(errors) == 1
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 1
    errors = validate

# Generated at 2022-06-12 16:22:01.364794
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = fields.String(max_length=100)
        age = fields.Integer()

    class FamilySchema(Schema):
        family_name = fields.String()
        members = fields.List(fields.Nested(PersonSchema))

    content = """\
    family_name: Smith
    members:
      - name: Bob Smith
        age: 35
      - name: Sue Smith
        age: 32
    """

    v, err = validate_yaml(content, FamilySchema)
    assert v == {
        'family_name': 'Smith',
        'members': [
            {'name': 'Bob Smith', 'age': 35},
            {'name': 'Sue Smith', 'age': 32},
        ]
    }
    assert err == []


# Unit test

# Generated at 2022-06-12 16:22:10.233099
# Unit test for function validate_yaml
def test_validate_yaml():
    """Validates that function validate_yaml works as expected on test data."""
    from typesystem import Integer, String
    from typesystem.schemas import Schema

    schema = Schema(properties={"foo": String(), "bar": Integer()})

    # Valid YAML, valid schema
    value, errors = validate_yaml(
        b"foo: 'hi'\nbar: 123", validator=schema)
    assert value == {"foo": "hi", "bar": 123}
    assert errors == []

    value, errors = validate_yaml(
        "foo: 'hi'\nbar: 123", validator=schema)
    assert value == {"foo": "hi", "bar": 123}
    assert errors == []

    # Invalid YAML, because of trailing line