

# Generated at 2022-06-12 16:12:31.751791
# Unit test for function validate_yaml
def test_validate_yaml():

    content = """
    # An Employee
    first_name: John
    last_name: Doe
    age: 30
    salary: 10
    """

    class Employee(Schema):
        first_name = fields.String(required=True)
        last_name = fields.String(required=True)
        age = fields.Integer(required=True)
        salary = fields.Float(required=True)

    actual = validate_yaml(content, validator = Employee)
    assert actual[0] == {'first_name': 'John', 'last_name': 'Doe', 'age': 30, 'salary': 10.0}
    assert actual[1] == []

    content = """
    # An Employee
    first_name: John
    last_name: Doe
    age: 30
    salary: abc
    """



# Generated at 2022-06-12 16:12:41.236432
# Unit test for function validate_yaml
def test_validate_yaml():
    _validator = [
        {"type": "string"},
        {"type": "integer"},
        {"type": "number"},
        {"type" : "boolean"},
        {"type" : "null"},
        {"type" : "array"},
        {"type" : "object"},
        {"type" : "string", "format": "date-time"},
        {"type" : "string", "format": "uri"},
        {"type" : "string", "format": "email"},
    ]
    for validator in _validator:
        for value in validator['type'] in ['integer', 'boolean', 'null']:
            content = yaml.dump(value)
            result = validate_yaml(content, validator)
            if isinstance(result, list):
                raise ValueError(result[0])

# Generated at 2022-06-12 16:12:43.988364
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(
        tokenize_yaml("""{
  'a': 1,
  'b': {
    'd': 'e',
    'f': ['a', 'b', 'c']
  },
  'c': {'fred': 'barney'}
}"""),
        DictToken,
    )



# Generated at 2022-06-12 16:12:49.362882
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "field: value"
    validator = Field(type=str)

    assert validate_yaml(content, validator) == ("value", [])

    content = "field:\n- item1\n- item2"
    validator = Field(type=list)

    assert validate_yaml(content, validator) == (["item1", "item2"], [])



# Generated at 2022-06-12 16:12:52.484224
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
a: 1
b: hello
c:
- a
- b
"""
    assert isinstance(tokenize_yaml(content), DictToken)


# Generated at 2022-06-12 16:13:04.465692
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    with pytest.raises(ParseError) as excinfo:
        assert tokenize_yaml("") == ""
    assert excinfo.value.text == "No content."
    assert excinfo.value.code == "no_content"
    assert excinfo.value.position == Position(column_no=1, line_no=1, char_index=0)

    with pytest.raises(ParseError) as excinfo:
        assert tokenize_yaml("\t") == ""
    assert excinfo.value.text == "expected <block end>, but found '\\t' (line 1, column 1)"
    assert excinfo.value.code == "parse_error"
    assert excinfo.value.position == Position(column_no=1, line_no=1, char_index=0)


# Generated at 2022-06-12 16:13:08.292449
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    list: 
        entry1:
            title: "title1"
    """
    class Validator(Schema):
        list = Field(sub_fields={"entry1": Field(sub_fields={"title": Field(str)})})
    value, errors = validate_yaml(content, validator=Validator)
    assert errors == ["entry1"]

# Generated at 2022-06-12 16:13:13.235546
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml(content="""
        key:
          - value
        """)

    assert isinstance(token, DictToken)
    assert token.keys == ["key"]
    assert token.values == [[ScalarToken("value", 3, 14, content="""
        key:
          - value
        """)]]

    with pytest.raises(ParseError):
        tokenize_yaml(content="*")

# Generated at 2022-06-12 16:13:18.906920
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    id: test
    name: Test
    """
    item = """
    id: test
    name: Test
    """
    schema = yaml.load(item, SafeLoader)
    value, errors = validate_yaml(content, schema)
    if errors:
        print(errors)
    assert isinstance(value, dict)
    assert isinstance(errors, list)
    assert not errors

# Generated at 2022-06-12 16:13:23.774123
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"fruit": Field(type="string", enum=["apple", "banana"])})
    content = "fruit: not-a-fruit"
    value, errors = validate_yaml(content, schema)
    assert errors["fruit"][0].text == 'Value "not-a-fruit" is not one of ["apple", "banana"].'
    assert errors["fruit"][0].code == "invalid_choice"

# Generated at 2022-06-12 16:13:30.415665
# Unit test for function validate_yaml
def test_validate_yaml():
    my_content = """
        key1: 2
        key2: 3
    """
    my_validate = validate_yaml(my_content)
    print(my_validate)
    assert(type(my_validate) == type(dict()))


# Generated at 2022-06-12 16:13:38.206342
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    
    class BlogPost(Schema):
        title = String(required=True)
        body = String(required=True)

    content = "title: Hello world\nbody: Lorem ipsum"
    validator = BlogPost()
    value, error_messages = validate_yaml(content=content, validator=validator)
    assert value == {'title': 'Hello world', 'body': 'Lorem ipsum'}
    assert error_messages == []

    content = "title: Hello world\npost: Lorem ipsum"
    validator = BlogPost()
    value, error_messages = validate_yaml(content=content, validator=validator)
    assert value == {}
    assert error_

# Generated at 2022-06-12 16:13:46.787196
# Unit test for function validate_yaml
def test_validate_yaml(): 
    from typesystem.fields import String
    from typesystem.types import Integer

    assert validate_yaml(
        "---\nFoo\nbar: baz\n",
        Field(key="bar", type=Integer),
    )==(None, [Message(text='Expected a int value.', code='invalid_type', position=Position(column_no=7, char_index=13, line_no=3))])
    assert validate_yaml(
        "---\nFoo\nbar: 1\n",
        Field(key="bar", type=Integer),
    )==(1, [])

# Generated at 2022-06-12 16:13:58.551004
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_1 = ""
    yaml_2 = "{}"
    yaml_3 = "{'a': 1, 'b': 1}"
    yaml_4 = "['a', 'b']"
    yaml_5 = "a"
    yaml_6 = "true"
    yaml_7 = "1"
    yaml_8 = "1.1"
    yaml_9 = "null"

    assert not tokenize_yaml(yaml_1).content
    assert tokenize_yaml(yaml_2).content == tokenize_yaml(yaml_3).content
    assert tokenize_yaml(yaml_4).content == tokenize_yaml(yaml_1).content
    assert tokenize_yaml(yaml_5).content

# Generated at 2022-06-12 16:14:04.608295
# Unit test for function validate_yaml
def test_validate_yaml():

    ab_schema = Schema([
        Field('a', repr_type="int"),
        Field('b', repr_type="list"),
    ])

    ab_data = """
        a: 1
        b:
        - 1
        - 2
    """

    errors = validate_yaml(ab_data, ab_schema)

    assert len(errors) == 0, "The errors should be empty."



# Generated at 2022-06-12 16:14:13.871526
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_str = """
        ---
        name: Paul Traylor
        age: 38
        """
    validator = typing.cast(
        typing.Type[Schema],
        type(
            "TestValidator",
            (Schema,),
            {
                "name": Field(str),
                "age": Field(int),
            }
        )
    )

    # assertion that this function works
    value, error_msgs = validate_yaml(yaml_str, validator)

    assert isinstance(value, dict)
    assert "name" in value
    assert "age" in value

    assert isinstance(error_msgs, list)
    assert len(error_msgs) == 0

    # test a bad string

# Generated at 2022-06-12 16:14:21.790522
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: Jane Doe
    age: 52
    """
    from typesystem import field, schema, string

    class Person(schema.Schema):
        name = string.String(max_length=50, description="Name of the person.")
        age = field.Integer(minimum=0, description="Age of person.")

    result = validate_yaml(content, Person)
    assert result is None, "Validation should be successful"

    # validate_with_tokens needs to be tested here
    # as this function is only a wrapper around validate_with_tokens

# Generated at 2022-06-12 16:14:31.489156
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type_name='string', max_length=5)
    assert validate_yaml('', validator) == ('', [])
    assert validate_yaml('abc', validator) == ('abc', [])
    assert validate_yaml('hello', validator) == ('hello', [])
    assert validate_yaml('hello world', validator) == ('hello', [Message(
        text='Text must not be more than 5 characters long.',
        code='max_length',
        position=Position(line_no=1, column_no=8, char_index=7),
    )])

    with pytest.raises(ParseError) as excinfo:
        validate_yaml('abc\nabc', validator)

# Generated at 2022-06-12 16:14:40.161655
# Unit test for function validate_yaml
def test_validate_yaml():
    content = (
        "definitions:\n"
        "- type: foo\n"
        "  name: bar\n"
    )
    token = tokenize_yaml(content)
    value, errors = validate_with_positions(token, validator=Schema)
    assert value == {
        "definitions": [
            {
                "type": "foo",
                "name": "bar",
            },
        ],
    }
    assert errors == []

# Generated at 2022-06-12 16:14:44.268055
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name:
      first: George
      last: Washington
    dob: 1732-02-22
    """
    from tests.schemas.full_user_schema import FullUserSchema

    (value, error_messages) = validate_yaml(content, FullUserSchema)
    assert value["name"]["first"] == "George"
    assert error_messages == []

    content = """
    name:
      first: George
      last: Washington
    dob: George Washington
    """
    (value, error_messages) = validate_yaml(content, FullUserSchema)
    assert len(error_messages) == 1
    assert error_messages[0].code == "invalid_field"

# Generated at 2022-06-12 16:14:57.599636
# Unit test for function validate_yaml
def test_validate_yaml():
	# a test string of yaml
    content = """
    # This is a comment
    name: John
    age: 30
    likes:
        - apples
        - pears
        - lettuce
    """
	# create a schema to call the validate_yaml function
    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Number()
        likes = fields.Array(fields.String())
    # assert that the value returned and the error message are expected
    value, errors = validate_yaml(content, PersonSchema)
    assert value == {
        "name": "John",
        "age": 30,
        "likes": ["apples", "pears", "lettuce"],
    }
    assert not errors


# Generated at 2022-06-12 16:14:58.998612
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

# Generated at 2022-06-12 16:15:10.147695
# Unit test for function validate_yaml
def test_validate_yaml():
    fields = [{'name': 'position', 'type': 'string'}]
    class MySchema(Schema):
        fields = fields
    value, errors = validate_yaml(content="position: now", validator=MySchema)
    assert value['position'] == 'now'
    assert len(errors) == 0
    value, errors = validate_yaml(content="position: 'now", validator=MySchema)
    assert value['position'] == 'now'
    assert len(errors) == 0
    value, errors = validate_yaml(content="position:\n- 'now'\n- 'now'", validator=MySchema)
    assert value['position'] == ['now', 'now']
    assert len(errors) == 0

# Generated at 2022-06-12 16:15:21.844122
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(required=True)
    value, errors = validate_yaml(content="", validator=field)

    assert value is None
    assert errors == [
        Message(
            text="No content.",
            code="no_content",
            position=Position(column_no=1, line_no=1, char_index=0),
        )
    ]

    value, errors = validate_yaml(content="123", validator=field)

    assert value == "123"
    assert errors == []

    value, errors = validate_yaml(
        content="123\n456", validator=field,
    )

    assert value == "123\n456"
    assert errors == []


# Generated at 2022-06-12 16:15:25.319780
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml('[1, 2, 3]'), ListToken)
    assert isinstance(tokenize_yaml('{"a": 1}'), DictToken)

if(__name__ == "__main__"):
    test_tokenize_yaml()

# Generated at 2022-06-12 16:15:35.758919
# Unit test for function validate_yaml
def test_validate_yaml():

    from typesystem.schemas import Schema
    from typesystem.types import Integer
    from typesystem.fields import Field
    from typesystem.tokenize import Token
    from typesystem.tokenize.positional_validation import validate_with_positions

    class CustomSchema(Schema):

        name = Field(type=Integer)

    schema = CustomSchema()

    class CustomToken(Token):
        def __init__(self, value: typing.Any):
            self.value = value

    class CustomDictToken(CustomToken):
        def __getitem__(self, key):
            return self.value[key]

    class CustomIntToken(CustomToken):
        pass

    token = CustomDictToken({"name": CustomIntToken(2)})

# Generated at 2022-06-12 16:15:48.292110
# Unit test for function validate_yaml
def test_validate_yaml():
    from datetime import datetime
    from typesystem.types import DateTime, Integer, String

    class MySchema(Schema):
        name = String(required=True)
        age = Integer(min_value=0, max_value=100)
        updated = DateTime(required=True)

    content = """
---
name: Jane
age: 45
updated: 2018-03-19T16:00:14.508547
"""
    value, errors = validate_yaml(content, validator=MySchema)
    assert value["name"] == "Jane"
    assert value["age"] == 45
    assert value["updated"] == datetime(2018, 3, 19, 16, 0, 14, 508547)
    assert isinstance(value["updated"], datetime)


# Generated at 2022-06-12 16:15:51.077961
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"tag:yaml.org,2002:str\nhello"
    validator = Field(type="string")
    validate_yaml(content, validator)



# Generated at 2022-06-12 16:15:59.026609
# Unit test for function validate_yaml
def test_validate_yaml():
    definition = """
        type: object
        properties:
            name:
                type: string
                description: "Your name"
            email:
                type: string
                format: email
                description: "Your email address"
        additionalProperties: True
    """

    validator = Schema.from_dict(yaml.safe_load(definition))

    content = """
        name: first last
        email: test@test.com
    """

    value, error_messages = validate_yaml(content, validator)

    # pylint: disable=unsupported-assignment-operation
    assert value == {"name": "first last", "email": "test@test.com"}
    assert error_messages == []

# Generated at 2022-06-12 16:16:05.267843
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('{"value": "1"}', Schema(properties={"value": "string"}))[0] == {"value": "1"}
    assert validate_yaml('{"value": "1"}', Schema(properties={"value": "string"}))[1][0].text == "Value must be string."


# Generated at 2022-06-12 16:16:17.044199
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_content = """
        first_name: "Eric"
        last_name: "Idle"
        age: 73
    """

    class PersonSchema(Schema):
        first_name = Field(type="string", required=True)
        last_name = Field(type="string", required=True)
        age = Field(type="integer")

    value, errors = validate_yaml(yaml_content, PersonSchema)

    assert not errors
    assert value.first_name == "Eric"
    assert value.last_name == "Idle"
    assert value.age == 73



# Generated at 2022-06-12 16:16:28.445593
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String
    from typesystem.schemas import Schema
    from typesystem.validators import Minimum, Regex

    class Person(Schema):
        name = String(max_length=8, min_length=2, regex="[a-z]*")
        age = Integer(minimum=0, maximum=100)

    body = "name: Pedro\nage: 25"
    data, errors = validate_yaml(body, Person)

    assert not errors
    assert data == {"name": "Pedro", "age": 25}

    body = "name: John\nage: 132"
    try:
        result = validate_yaml(body, Person)
    except ValidationError as exc:
        assert exc.messages[0].text == "Must be greater than or equal to 0."
        assert exc

# Generated at 2022-06-12 16:16:36.563672
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test that the validate_yaml function returns the expected JSON parse and validation error messages.
    """

    invalid_yaml = """
    not: valid: yaml
    """
    with pytest.raises(ParseError, match=r".*character: line 2, column 8$"):
        validate_yaml(invalid_yaml, validator=None)

    invalid_json = """
    {
        "not": "valid",
        "json": "error"
    }
    """
    with pytest.raises(ParseError, match=r".*character: line 3, column 13$"):
        validate_yaml(invalid_json, validator=None)


# Generated at 2022-06-12 16:16:45.840472
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    import yaml
    from typesystem import Schema, fields, validators
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken, Token
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.yaml import validate_yaml
    from typesystem.tokenize.exceptions import ParseError

    content = "  str: \"string\"\n"

    value, error_messages = validate_yaml(content, fields.String())
    assert isinstance(value, str)
    assert not error_messages

    class Point(Schema):
        x = fields.Integer()
        y = fields.Integer

# Generated at 2022-06-12 16:16:58.101352
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Boolean

    schema = Schema(
        {
            "group": String(required=True),
            "name": String(required=True),
            "enabled": Boolean(required=True),
            "maximum_user_count": Integer(required=True),
        }
    )

    # Valid YAML.
    json_content = """
        group: SomeGroup
        name: SomeName
        enabled: true
        maximum_user_count: 10
    """

    value, error_messages = validate_yaml(json_content, schema)

    assert error_messages == []

# Generated at 2022-06-12 16:17:01.080739
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = String()

    assert validate_yaml(b"{name: \'a\'}", MySchema) == ({"name":"a"}, [])

# Generated at 2022-06-12 16:17:09.390053
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = str

    def get_msg(errors: typing.List[ValidationError]) -> str:
        if errors:
            return str(errors[0])
        else:
            return ""

    # valid yaml
    yaml_valid = """
    name: hello
    """
    assert not get_msg(validate_yaml(yaml_valid, validator=TestSchema)["errors"])

    # invalid yaml
    yaml_invalid = "name: hello"
    assert get_msg(validate_yaml(yaml_invalid, validator=TestSchema)["errors"])

    # invalid schema
    yaml_invalid = """
    name: 1
    """

# Generated at 2022-06-12 16:17:19.118357
# Unit test for function validate_yaml
def test_validate_yaml():
    
    class MySchema(Schema):
        name = String

    schema = MySchema()


    # Happy path
    result = validate_yaml(
        content="name: Value", validator=MySchema
    )
    print(result)
    value = result.value
    print(value)
    assert isinstance(value, dict)
    assert value["name"] == "Value"

    # Badly typed value
    result = validate_yaml(
        content="name: Value", validator=schema
    )
    print(result)
    value = result.value
    print(value)
    


if __name__ == "__main__":
    test_validate_yaml()

# Generated at 2022-06-12 16:17:23.935469
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem import Schema, fields
    # Basic usage
    schema = Schema([
        fields.StringField(name="address"),
        fields.StringField(name="city"),
    ])
    yaml_string = """
    ---
    address: 1215 18th Ave S
    city: Nashville
    zipcode: 37212
    """
    # Parsed value
    assert validate_yaml(yaml_string, schema)[0] == {
        "address": "1215 18th Ave S",
        "city": "Nashville",
    }
    # Errors

# Generated at 2022-06-12 16:17:30.076902
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
            this_is_a_test:
                what: True
                are:
                    - you
                    - doing
                    - here
                this:
                    is crazy: False
    """)
    assert token == {"this_is_a_test": {"what": True, "are": ["you", "doing", "here"], "this": {"is crazy": False}}}



# Generated at 2022-06-12 16:17:37.599376
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(content="""
    foo: 'bar'
    """
    ), DictToken)
    assert isinstance(tokenize_yaml(content="""
    - 1
    - 2
    """
    ), ListToken)

# Generated at 2022-06-12 16:17:42.262020
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: 1
    - 3
    - 5
    """
    validator = {"foo": int, "bar": str}
    assert validate_yaml(content, validator) == ({"foo": 1}, [])



# Generated at 2022-06-12 16:17:49.524308
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_content = "name: Sidney Crosby\nscore: 10"
    schema = typing.cast(
        typing.Type[Schema],
        typing.TypeVar("TSchema", bound=Schema),
    )

    class PlayerSchema(Schema):
        name = Field(type=str)
        score = Field(type=int)

    validation_result = validate_yaml(yaml_content, PlayerSchema)

    assert len(validation_result[1]) == 0
    assert validation_result[0] == {"name": "Sidney Crosby", "score": 10}



# Generated at 2022-06-12 16:18:00.414794
# Unit test for function validate_yaml
def test_validate_yaml():
    # Valid schema
    content = "0"
    validator = "integer"

    expected_value = 0
    expected_errormsg = []
    actual_value, actual_errormsg = validate_yaml(content, validator)

    assert expected_value == actual_value
    assert expected_errormsg == actual_errormsg

    # Invalid schema
    content = "0"
    validator = "string"

    expected_value = 0
    expected_errormsg = [
        ValidationError(
            code="invalid_type",
            text="Value must be of type string.",
            path=["0"],
            position=Position(line_no=1, column_no=1, char_index=0),
            validator=Field("string"),
            value=0,
        )
    ]
    actual_

# Generated at 2022-06-12 16:18:05.003536
# Unit test for function validate_yaml
def test_validate_yaml():
    string = "hello"
    value, error_messages = validate_yaml(string, {
        "name": "test",
        "$schema": "http://json-schema.org/draft-06/schema",
        "title": "Test",
        "type": "object",
        "properties": {
            "content": {
                "type": "string",
            },
        },
        "required": [
            "content",
        ],
    })
    assert string == value
    assert error_messages == []

# Generated at 2022-06-12 16:18:15.890868
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = "text"
        age = "integer"
        
    class Address(Schema):
        street = "text"
        city = "text"
        country = "text"

    class People(Schema):
        people = [Person]
        address = {"type": "object", "properties": {"street": "text", "city": "text", "country": "text"}}

    yaml_string = "people:\n  - name: Joe\n    age: 50\n  - name: Jane\n    age: 51\naddress:\n  street: 123 Example St.\n  city: Example Country\n  country: Example Country"
    # generate incorrect schema to test invalid schema validation

# Generated at 2022-06-12 16:18:24.078926
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_content = '''
    first_name: Jack
    last_name: Black
    '''
    validator = Field(name="last_name", type="string")
    assert(validate_yaml(yaml_content, validator) == ('Black', []))
    validator = Field(name="first_name", type="string")
    assert(validate_yaml(yaml_content, validator) == ('Jack', []))



# Generated at 2022-06-12 16:18:27.857068
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
	# Test no_content
	content = ""
	try:
		token = tokenize_yaml(content)
		assert False, "Should raise ParseError"
	except ParseError as e:
		assert e.code == "no_content"

	# Test parse_error
	content = """
	    this is invalid
	    yaml
	"""
	try:
		token = tokenize_yaml(content)
		assert False, "Should raise ParseError"
	except ParseError as e:
		assert e.code == "parse_error"

	# Test empty_string
	content = """
	    ""
	"""

	token = tokenize_yaml(content)
	assert token.type == "string"

	# Test empty_string_with_quotation_mark
	content

# Generated at 2022-06-12 16:18:29.695488
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    b: 2
    """
    schema = Schema(
        fields={
            'a': fields.Int(),
            'b': fields.Int(),
        }
    )
    value, errors = validate_yaml(content, schema)
    assert not errors

# Generated at 2022-06-12 16:18:36.563725
# Unit test for function validate_yaml
def test_validate_yaml():
    # We don't need to import yaml, but we do need to be sure that typesystem
    # can look up the path, so we replace the __import__ function.
    orig_import = builtins.__import__

    def mock_import(*args, **kwargs):
        if args[0]=="yaml":
            raise ImportError()
        else:
            return orig_import(*args, **kwargs)

    builtins.__import__ = mock_import
    with pytest.raises(AssertionError, match="pyyaml.*must be installed"):
        validate_yaml("", "foo")

    builtins.__import__ = orig_import



# Generated at 2022-06-12 16:18:52.740889
# Unit test for function validate_yaml

# Generated at 2022-06-12 16:18:58.915502
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        name = typesystem.String(min_length=1, max_length=20)
        age = typesystem.Integer(minimum=1, maximum=150)

    user, err = validate_yaml("name: Volodymir\nage: 25\n", UserSchema)
    assert err == []
    assert user == {'name': 'Volodymir', 'age': 25}

    new_user, err = validate_yaml("name: Volodymir\nage: 25\n", UserSchema)
    assert err == []
    assert new_user == user



# Generated at 2022-06-12 16:19:10.687169
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test Schema validation with failing values
    class SimpleObject(Schema):
        name = String(max_length=5, required=True)
        age = Integer(min_value=0)
    obj, errors = validate_yaml("name: 12345678\nage: -2", SimpleObject)
    assert obj == {"name": "12345678"}
    assert errors == [
        Message(
            text="Ensure this value is greater than or equal to 0.",
            code="min_value",
            position=Position(column_no=6, line_no=2, char_index=10),
        ),
    ]

    # Test Field validation with failing values
    field = Integer(min_value=0)
    value, errors = validate_yaml("", field)
    assert value is None

# Generated at 2022-06-12 16:19:16.723607
# Unit test for function validate_yaml
def test_validate_yaml():
    prefix = '''
    geolocation:
      latitude: 49.246292
      longitude: -123.116226
    '''
    body = '''
    address:
      city: Vancouver
      country: Canada
    '''

    schema_class = type('Schema', (Schema,), {
        'geolocation': {
            'latitude': float,
            'longitude': float,
        },
        'address': {
            'city': str,
            'country': str,
        },
    })


# Generated at 2022-06-12 16:19:19.588262
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        import yaml
    except ImportError:  # pragma: no cover
        yaml = None  # type: ignore
    assert yaml is not None, "'pyyaml' must be installed."



# Generated at 2022-06-12 16:19:22.016988
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "5"
    validator = int
    value, error_messages = validate_yaml(content, validator)
    assert not error_messages
    assert value == 5


# Generated at 2022-06-12 16:19:33.734476
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
name: Shohei
age: 18
'''
    validator = Schema([
        Field("name", required=True, type="string"),
        Field("age", required=True, type="integer")
    ])

    value, error_messages = validate_yaml(content, validator)
    assert value == {'name': 'Shohei', 'age': 18}
    assert len(error_messages) == 0

    content = '''
name: Shohei
age: abc
'''
    validator = Schema([
        Field("name", required=True, type="string"),
        Field("age", required=True, type="integer")
    ])
    value, error_messages = validate_yaml(content, validator)
    assert value == None
    assert len(error_messages)

# Generated at 2022-06-12 16:19:37.675401
# Unit test for function validate_yaml
def test_validate_yaml():
    content = u"a: true"
    validator = Schema.from_dict({"a": "boolean"})
    value, err = validate_yaml(content, validator)
    assert value == {"a": True}
    assert not err

# Generated at 2022-06-12 16:19:49.142745
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {"name": {"type": "string", "required": True}, "price": {"type": "number"}}
    )
    value, messages = validate_yaml(content="name: my name", validator=schema)
    assert value == {"name": "my name"}
    assert len(messages) == 1
    assert messages[0].code == "required"
    assert messages[0].position == Position(column_no=1, line_no=1, char_index=0)
    assert messages[0].text == "Field 'price' is required."
    value, messages = validate_yaml(
        content={"name": "my name", "price": "invalid"}, validator=schema
    )
    assert value["price"] == "invalid"
    assert len(messages) == 1


# Generated at 2022-06-12 16:20:00.506466
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "n: 5"
    validator = Schema.parse('{"type": "object", "properties": {"n": {"type": "integer"}}, "required": ["n"]}')
    value, messages = validate_yaml(content=content, validator=validator)
    assert value == {"n": 5}
    assert messages == []

    content = "n: 5.5"
    validator = Schema.parse('{"type": "object", "properties": {"n": {"type": "integer"}}, "required": ["n"]}')
    value, messages = validate_yaml(content=content, validator=validator)
    assert value == {"n": 5}
    assert messages[0].text == "Must be a whole number."

    content = "k: "

# Generated at 2022-06-12 16:20:17.436048
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
key1: value1
key2: value2
"""
    validator = Schema({"key1": Field(str), "key2": Field(str)})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"key1": "value1", "key2": "value2"}
    assert [error.code for error in error_messages] == []
    assert [error.text for error in error_messages] == []
    assert [error.position for error in error_messages] == []

    content = """
key1: value1
"""
    validator = Schema({"key1": Field(str), "key2": Field(str)})
    value, error_messages = validate_yaml(content, validator)
    assert value is None
   

# Generated at 2022-06-12 16:20:26.965168
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Test tokenize_yaml function
    """
    token = tokenize_yaml('hello')
    assert isinstance(token, ScalarToken)
    assert isinstance(token.value, str)

    token = tokenize_yaml(b'hello')
    assert isinstance(token, ScalarToken)
    assert isinstance(token.value, str)

    token = tokenize_yaml('1')
    assert isinstance(token, ScalarToken)
    assert isinstance(token.value, int)

    token = tokenize_yaml('1.0')
    assert isinstance(token, ScalarToken)
    assert isinstance(token.value, float)

    token = tokenize_yaml('1.0e3')
    assert isinstance(token, ScalarToken)

# Generated at 2022-06-12 16:20:36.833894
# Unit test for function validate_yaml
def test_validate_yaml():
    # Given
    class ContactSchema(Schema):
        name = "string"
        age = "integer"
        address = {
            "street": "string",
            "city": "string",
        }

    # When
    yaml_content = """
    name: John Doe
    age: 43
    address:
        street: South Park
        city: London
    """
    # Then
    value, error_messages = validate_yaml(yaml_content, ContactSchema)
    assert value == {
        "name": "John Doe",
        "age": 43,
        "address": {"street": "South Park", "city": "London"},
    }
    assert error_messages == []



# Generated at 2022-06-12 16:20:47.337549
# Unit test for function validate_yaml

# Generated at 2022-06-12 16:20:53.134243
# Unit test for function validate_yaml
def test_validate_yaml():
    content_str = """
    name: "John"
    age: 25
    """
    assert validate_yaml(content_str, Field(type="string", name='name')) == (u'John', None)
    assert validate_yaml(content_str, Field(type="number", name='age')) == (25, None)

    # Issue #938: Fix YAML boolean validation
    content_str = """
    is_admin: true
    """
    assert validate_yaml(content_str, Field(type="boolean", name='is_admin')) == (True, None)

# Generated at 2022-06-12 16:21:01.738741
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.exceptions import ErrorMessage
    from typesystem.fields import Integer

    schema = Integer()
    value, messages = validate_yaml(content="1", validator=schema)
    assert value == 1
    assert messages == []

    value, messages = validate_yaml(content="abc", validator=schema)
    assert messages == [
        ErrorMessage(
            text="Must be an integer.",
            code="type_error.integer",
            position=Position(column_no=2, line_no=1, char_index=1),
            meta={},
        )
    ]

    value, messages = validate_yaml(content="abc", validator=schema, parse_only=True)

# Generated at 2022-06-12 16:21:13.431538
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = String(max_length=10)

    error_messages = validate_yaml(content=b"name: Test", validator=TestSchema)
    assert error_messages == []

    error_messages = validate_yaml(content=b"name: Too Long", validator=TestSchema)
    assert len(error_messages) == 1
    assert isinstance(error_messages[0], ValidationError)
    error = error_messages[0]
    assert error.text == "Ensure this value has at most 10 characters (it has 12)."
    assert error.position.line_no == 1
    assert error.position.column_no == 6
    assert error.position.char_index == 6

# Generated at 2022-06-12 16:21:23.042816
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String

    class Person(Schema):
        first_name = String(required=True)
        last_name = String(required=True)
        age = Integer(required=True)

    content = """
    first_name: "Frodo"
    last_name: "Baggins"
    age: 33
    """

    value, messages = validate_yaml(content, Person)
    assert not messages
    assert value

    content = """
    first_name: "Frodo"
    last_name: ["Baggins"]
    age: 33
    """

    value, messages = validate_yaml(content, Person)
    assert len(messages) == 1
    assert not value
    assert messages[0].code == "invalid_type"
    assert messages[0].text

# Generated at 2022-06-12 16:21:29.759501
# Unit test for function validate_yaml
def test_validate_yaml():

    with pytest.raises(ValidationError) as exc_info:

        errors = validate_yaml(
            """
            -
        -
            a: 1
            b: true
        -
            a: 1
            b: true
            """,
            List(
                items=[
                    Dict(properties={"a": Integer(), "b": Boolean()})
                ]
            )
        )

    #print(errors)
    assert len(exc_info.value.messages) == 1
    assert exc_info.value.messages[0].code == "required"
    assert exc_info.value.messages[0].position.column_no == 3
    assert exc_info.value.messages[0].position.line_no == 3
    assert exc_info.value.messages[0].position.char_

# Generated at 2022-06-12 16:21:37.392979
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("1", int) == (1, [])
    assert validate_yaml("1", float) == (1.0, [])
    assert validate_yaml("1.0", float) == (1.0, [])
    assert validate_yaml("True", bool) == (True, [])
    assert validate_yaml("TRUE", bool) == (True, [])
    assert validate_yaml("null", None) == (None, [])
    assert validate_yaml("null", int) == (None, [])
    assert validate_yaml("null", "abc") == (None, [])
    assert validate_yaml("null", "abc") == (None, [])
    assert validate_yaml("null", Field(type="abc")) == (None, [])
    assert validate_yaml

# Generated at 2022-06-12 16:21:58.682104
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import types
    import pytest

    class TestSchema(Schema):
        name = types.String(required=True, max_length=64)
        slug = types.String(required=True, max_length=64)

    with pytest.raises(ParseError):
        validate_yaml(b"", TestSchema)

    with pytest.raises(ParseError):
        validate_yaml(b"name: test", TestSchema)

    with pytest.raises(ValidationError):
        validate_yaml(b"name: test\nslug: test-1", TestSchema)

    with pytest.raises(ValidationError):
        validate_yaml(b"slug: test\nname: test-1", TestSchema)


# Generated at 2022-06-12 16:22:06.732479
# Unit test for function validate_yaml
def test_validate_yaml():

    # Valid data should pass validation
    class ExampleSchema(Schema):
        field = Field(validators=["string"], required=True)
        field2 = Field(validators=["string"])

    valid_yaml = """
    field: hi
    field: hello
    """
    value, error_messages = validate_yaml(valid_yaml, ExampleSchema)
    assert error_messages == []

    # Invalid data should fail validation
    class ExampleSchema(Schema):
        field = Field(validators=["string"], required=True)
        field2 = Field(validators=["string"])

    invalid_yaml = """
    field: hi
    field: hello
    """
    value, error_messages = validate_yaml(invalid_yaml, ExampleSchema)
    assert error_mess

# Generated at 2022-06-12 16:22:16.068852
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        name: 
            first: "Ben"
            last: "Best"
        favorite_colors:
            - green
            - blue
            - red
        age: 27
    """
    token = tokenize_yaml(content)
    validator = Schema(
        properties={
            "name": Field(
                properties={
                    "first": Field(type="string", max_length=10),
                    "last": Field(type="string", max_length=10),
                }
            ),
            "favorite_colors": Field(items=Field(type="string", enum=["red", "green"])),
            "age": Field(type="integer", minimum=18, maximum=85),
        }
    )
    value, error = validate_yaml(content, validator)
    print(value)