

# Generated at 2022-06-12 16:12:35.638553
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        """
      a: 1
      b: foo
      c: true
      d: false
      e: null
      f: bar
    """,
        Field(type="string")
    ) == (Message(code="type_mismatch", text="Value is not a 'string'.", path=["a"]),)


# Generated at 2022-06-12 16:12:42.313659
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(type=str)
    raw_content = "foo:"
    value, error_messages = validate_yaml(raw_content, validator=field)
    assert value == "foo:"
    assert len(error_messages) == 1
    assert error_messages[0].text == "The current element is not a dictionary or a list."


# Generated at 2022-06-12 16:12:51.129121
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('"a"').value == 'a'
    assert tokenize_yaml('"a"').start == 0
    assert tokenize_yaml('"a"').end == 2
    assert tokenize_yaml('"a"').content == '"a"'
    assert tokenize_yaml('"a"').token_type == 'ScalarToken'
    assert tokenize_yaml('"a"').get_token_position('value') == (0, 2)
    assert tokenize_yaml('"a"').get_token_position('start') == (0, 0)
    assert tokenize_yaml('"a"').get_token_position('end') == (0, 2)
    assert tokenize_yaml('"a"').get_token_position('content') == (0, 2)

# Generated at 2022-06-12 16:12:56.078203
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    hello:
        world: some
    """
    result = tokenize_yaml(content)
    assert type(result) == DictToken
    assert result.value['hello'].value['world'] == "some"


# Generated at 2022-06-12 16:13:04.237080
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: true
    b: [12]
    c:
      d:
        e: {f: "g"}
    """
    token = tokenize_yaml(content)
    assert token.content == content
    assert token.start_char == content.find("a")
    assert token.end_char == content.rfind("}")

    assert token.value["a"] == True
    assert token.value["b"] == [12]
    assert token.value["c"]["d"]["e"]["f"] == "g"



# Generated at 2022-06-12 16:13:05.943798
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
        test: value
        test2: true
    '''
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert isinstance(token['test'], ScalarToken)
    assert isinstance(token['test2'], ScalarToken) 


# Generated at 2022-06-12 16:13:08.459967
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('')
    assert token.start == 0


# Generated at 2022-06-12 16:13:18.163653
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken
    token = tokenize_yaml("")
    assert isinstance(token, ScalarToken) and token.value is None
    token = tokenize_yaml("- 1\n- 2\n- 3")
    assert isinstance(token, ListToken) and token.value == [1, 2, 3]
    token = tokenize_yaml("- 1\n- 2\n- 3")
    assert isinstance(token, ListToken) and token.value == [1, 2, 3]
    token = tokenize_yaml("""
        - a
        - b
        - c""")
    assert isinstance(token, ListToken) and token.value == ["a", "b", "c"]

# Generated at 2022-06-12 16:13:26.004635
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
---
a_dict:
    key1: value1
    key2: value2
        """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.value.get("a_dict"), DictToken)
    assert isinstance(token.value.get("a_dict").value.get("key1"), ScalarToken)
    assert token.value.get("a_dict").value.get("key1").value == "value1"
    assert isinstance(token.value.get("a_dict").value.get("key2"), ScalarToken)
    assert token.value.get("a_dict").value.get("key2").value == "value2"



# Generated at 2022-06-12 16:13:35.330719
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Basic tests for the validate_yaml function.
    """

    # Test that the invalid content raises a ParseError
    invalid_content = u"""example:
    - {"title": "one"}
    - {"title": "two"}
    - "three"
    """

    with pytest.raises(ParseError):
        validate_yaml(invalid_content, None)

    class ExampleValidator(Schema):
        example = ListField(StringField())

    valid_content = u"""example: ["one", "two"]"""

    (value, error_messages) = validate_yaml(valid_content, ExampleValidator)
    assert error_messages == []
    assert value == {"example": ["one", "two"]}

    invalid_content = u"""example: "one" """


# Generated at 2022-06-12 16:13:51.118778
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Boolean, Integer

    class MySchema(Schema):
        field1 = String()
        field2 = Integer(max_value=100)
        field3 = Boolean()

    # Test the happy path
    content = b"field1: hello\nfield2: 99\nfield3: True\n"
    (value, error_messages) = validate_yaml(content, MySchema)
    assert value == {'field1': 'hello', 'field2': 99, 'field3': True}
    assert error_messages == []

    # Test a parse error
    content = b"field1: hello\n\nfield2: 99\nfield3: True\n"

# Generated at 2022-06-12 16:14:00.945166
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        foo: "bar"
        bar: true
        baz: 1
        qux: null
        quux:
          - 1
          - 2
          - 3
        quuux:
          - 1
          - 2
        quuuux:
            - [1,2,3]
            - [4,5,6]
        quuuuux: 
            - 1
            - 2
            - 3
            -
             - 4
             - 5
             - 6
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.keys() == ["foo", "bar", "baz", "qux", "quux", "quuux", "quuuux", "quuuuux"]

# Generated at 2022-06-12 16:14:10.863153
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        title = String(required=True)

    content = """
    - title: Hello!
    - title: How are you?

    """

    errors = validate_yaml(content, validator=TestSchema())
    assert len(errors) == 1
    assert errors[0].code == "required"
    assert errors[0].path == ["title"]
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 3

    content = """
    - title: Hello
    - title: How are you?
    - title: Goodbye

    """


# Generated at 2022-06-12 16:14:21.471318
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Optional, Integer

    schema = Schema(
        {"name": String(), "age": Optional(Integer())},
        strict=False,
    )

    yaml_content = """
        name: Foo Bar
        age: 20
    """
    assert validate_yaml(yaml_content, schema) is None

    yaml_content = """
        name: Foo Bar
        age: 20
        address: null
    """

# Generated at 2022-06-12 16:14:27.104136
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Text
    content = """
    Foo:
      -: Fizz
      -: Buzz
    """
    value, error_messages = validate_yaml(content, Text)
    assert len(error_messages) > 0
    assert error_messages[0].position.line_no == 2
    assert error_messages[0].position.column_no == 4

# Generated at 2022-06-12 16:14:31.415749
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
        id: 2
        name: test
        slug: test
        description: hello
        """

    expected = DictToken(
        {"id": 2, "name": "test", "slug": "test", "description": "hello"},
        0,
        55,
        content=content,
    )

    assert tokenize_yaml(content) == expected



# Generated at 2022-06-12 16:14:43.838906
# Unit test for function validate_yaml
def test_validate_yaml():
    content = open("data/datasource_schema.yaml").read()
    schema = Schema.from_string(content)
    (
        value,
        error_messages,
    ) = validate_yaml(
        open("data/datasource_schema_invalid.yaml").read(), schema
    )
    assert isinstance(value, dict)

# Generated at 2022-06-12 16:14:55.235107
# Unit test for function validate_yaml
def test_validate_yaml():
    class Dog(Schema):
        name = String(required=True)
        age = Integer(required=True)

    value, error_messages = validate_yaml(
        content='''
        name: ringo
        age: 5
        ''',
        validator=Dog,
    )

    assert value == {"name": "ringo", "age": 5}
    assert error_messages == []

    value, error_messages = validate_yaml(
        content='''
        name: ringo
        age: "five"
        ''',
        validator=Dog,
    )

    assert value == {"name": "ringo", "age": "five"}

# Generated at 2022-06-12 16:15:02.926431
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_validator = Field(
        name = 'name',
        type = 'string'
    )
    content = '''
    name: This is yaml'''

    assert validate_yaml(content, yaml_validator) == ('This is yaml', [])
    assert validate_yaml(content, 'name') == ('This is yaml', [])
    assert validate_yaml(content, 'namex') == ('This is yaml', [])
    assert validate_yaml(content, 'namex') == ('This is yaml', [])

# Generated at 2022-06-12 16:15:10.833763
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from copy import copy
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken, Token
    assert isinstance(tokenize_yaml("test"), ScalarToken)
    assert isinstance(tokenize_yaml("test: test"), DictToken)
    assert isinstance(tokenize_yaml("- test"), ListToken)
    assert tokenize_yaml("test: test") == {'test': 'test'}
    assert tokenize_yaml("- test") == ['test']
    assert tokenize_yaml("test") == 'test'



# Generated at 2022-06-12 16:15:21.167501
# Unit test for function validate_yaml
def test_validate_yaml():
    class PhoneNumberSchema(Schema):
        phone_number = Field(str)
        country_code = Field(str, required=False)

    class CustomerSchema(Schema):
        name = Field(str)
        phone_numbers = Field(list, [PhoneNumberSchema])

    validator = CustomerSchema()

    def test(content: str, expected_value: typing.Any, expected_code: str) -> None:
        value, error_messages = validate_yaml(content, validator)
        assert error_messages == []
        assert value == expected_value


# Generated at 2022-06-12 16:15:32.087423
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('"string"') == ScalarToken('string', 0, 7, content='"string"')
    assert tokenize_yaml('1') == ScalarToken(1, 0, 1, content='1')
    assert tokenize_yaml('false') == ScalarToken(False, 0, 5, content='false')
    assert tokenize_yaml('true') == ScalarToken(True, 0, 4, content='true')
    assert tokenize_yaml('null') == ScalarToken(None, 0, 4, content='null')
    assert tokenize_yaml('[1,2]') == ListToken([1, 2], 0, 4, content='[1,2]')

# Generated at 2022-06-12 16:15:37.557193
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
	content = """
prediction: 
  label1: "0.1"
  label2: "0.2"
"""
	token = tokenize_yaml(content)
	assert token["prediction"].start == 17
	assert token["prediction"].end == 51
	assert token["prediction"]["label1"].start == 28
	assert token["prediction"]["label1"].end == 36
	assert token["prediction"]["label2"].start == 38
	assert token["prediction"]["label2"].end == 46

# Generated at 2022-06-12 16:15:41.066674
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "aaa: 1"
    validator = Schema.of({"aaa": int})
    value, errors = validate_yaml(content, validator)
    assert value == {"aaa": 1}
    assert errors == []

# Generated at 2022-06-12 16:15:52.009818
# Unit test for function validate_yaml
def test_validate_yaml():
    from tests.test_validate_tokens import TestSchema
    from .user_input import user_input

    class FullNameSchema(Schema):
        first_name = Field(description="First name")
        last_name = Field(description="Last name")

    class TestSchema(Schema):
        age = Field(description="Age")
        full_name = FullNameSchema(description="Full name")

    def print_errors(errors):
        print("\n".join(['"%s"' % err.text for err in errors]))

    while True:
        content = user_input("Enter YAML to validate: ")
        (value, errors) = validate_yaml(content, validator=TestSchema())
        print_errors(errors)

# Generated at 2022-06-12 16:16:00.119765
# Unit test for function validate_yaml
def test_validate_yaml():
    def format_error_messages(error_messages: typing.List[Message]) -> str:
        """
        Format the error messages in a sorted string of (column, line, text) tuples.

        We sort the messages by line number and column number, so that we have
        a predictable string to test against.
        """
        return ", ".join(
            [
                "({column}, {line}, '{text}')".format(
                    column=message.position.column_no,
                    line=message.position.line_no,
                    text=message.text,
                )
                for message in sorted(
                    error_messages, key=lambda m: (m.position.line_no, m.position.column_no)
                )
            ]
        )



# Generated at 2022-06-12 16:16:11.335910
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    result1 = tokenize_yaml("")
    assert result1 == {}, "test_tokenize_yaml1 failed"
    print("test_tokenize_yaml1 passed")

    result2 = tokenize_yaml("name: John Doe")
    assert result2.keys() == ["name"] and result2["name"] == "John Doe", "test_tokenize_yaml2 failed"
    print("test_tokenize_yaml2 passed")

    result3 = tokenize_yaml("name: John Doe\nage: 27")
    assert result3.keys() == ["name", "age"] and result3["name"] == "John Doe" and result3["age"] == 27, "test_tokenize_yaml3 failed"
    print("test_tokenize_yaml3 passed")

    result4 = tokenize_yaml

# Generated at 2022-06-12 16:16:23.286740
# Unit test for function validate_yaml
def test_validate_yaml():
    s = """
    name: James
    age: 17
    """
    from typesystem.types import String, Integer

    class User(Schema):
        name = String()
        age = Integer()

    try:
        value, errors = validate_yaml(s, User)
    except ParseError:
        assert False, "Expected that this was valid YAML."

    assert len(errors) == 0, "Expected no errors."

    # name field must be a string
    s = """
    name: 3
    age: 17
    """

    try:
        value, errors = validate_yaml(s, User)
    except ParseError:
        assert False, "Expected that this was valid YAML."

    assert len(errors) == 1, "Expected one error."

# Generated at 2022-06-12 16:16:33.553619
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.types import StringType

    class MySchema(Schema):
        name = String(type=StringType(max_length=10))

    value, errors = validate_yaml(b"name: Niklas", MySchema)
    assert value == {"name": "Niklas"}
    assert errors == []

    value, errors = validate_yaml(b"name: NiklasBorg", MySchema)
    assert value is None
    assert isinstance(errors[0], ValidationError)
    assert errors[0].text == "Must be less than or equal to 10 characters."
    assert errors[0].code == "max_length"
    assert errors[0].position.line_no == 1
    assert errors[0].position.column

# Generated at 2022-06-12 16:16:38.465269
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    msg = "No content."
    assert tokenize_yaml(content="") is None
    assert tokenize_yaml(content=" ") is None


# Generated at 2022-06-12 16:16:48.132794
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    name: John Smith
    title: CEO
    """
    token = tokenize_yaml(content)

    assert isinstance(token, DictToken)
    assert isinstance(token.keys[0], ScalarToken)
    assert token.keys[0].value == "name"
    assert token.keys[0].content == content
    assert token.keys[0].start == 2
    assert token.keys[0].end == 7
    assert token.values[0].value == "John Smith"
    assert token.values[0].content == content
    assert token.values[0].start == 10
    assert token.values[0].end == 21



# Generated at 2022-06-12 16:16:53.013443
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        email = String()
        age = Integer()

    content = """
    name: John
    email: john@example.com
    age: 37
    """
    value, error_messages = validate_yaml(content, validator=Person)


# Generated at 2022-06-12 16:17:04.400795
# Unit test for function validate_yaml

# Generated at 2022-06-12 16:17:06.770911
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(name=Field(type=str))
    output = validate_yaml("""name: 'John'""", schema) # type: ignore
    assert output == {'name': 'John'}

# Generated at 2022-06-12 16:17:14.057329
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from ..base.test_utils import match_schema_type

    def assert_token(token: Token, type: type, value: typing.Any) -> None:
        """
        Assert that a token has the expected type, value and positions.
        """
        assert isinstance(token, type)
        assert token.value == value
        assert not token.missing
        assert isinstance(token.start, int)
        assert isinstance(token.end, int)
        if type == ScalarToken:
            assert isinstance(token.content, str)

    yaml_token = tokenize_yaml("22")
    assert_token(yaml_token, ScalarToken, 22)

    yaml_token = tokenize_yaml('"hello"')
    assert_token(yaml_token, ScalarToken, "hello")



# Generated at 2022-06-12 16:17:22.146235
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Unit test for function tokenize_yaml
    """
    assert yaml is not None, "'pyyaml' must be installed."

    yaml_str = r"""
a:
  - 2.0
  - 5
"""
    token = tokenize_yaml(yaml_str)
    assert isinstance(token, DictToken)
    assert isinstance(token[0], DictToken)
    assert isinstance(token[0][0], ScalarToken)
    assert isinstance(token[0][1][0], ScalarToken)
    assert isinstance(token[0][1][1], ScalarToken)


# Generated at 2022-06-12 16:17:32.783269
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Author(Schema):
        name = String()

    # Example 1
    # valid input
    content = """
    author:
        name: foo
    """
    value = validate_yaml(content, validator=Author)
    assert isinstance(value, Author)
    assert value.name == "foo"

    # Example 2
    # invalid input
    content = """
    author:
        name : foo
    """
    result = validate_yaml(content, validator=Author)
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert result[0] is None
    assert len(result[1]) == 1
    assert result[1][0].code == "invalid"

# Generated at 2022-06-12 16:17:38.371114
# Unit test for function validate_yaml
def test_validate_yaml():
    class WithListField(Schema):

        my_list = Field(
            type="list", items={"type": "integer"}
        )

        def after_validate(self, error_messages):
            pass

    value, error_messages = validate_yaml(
        content=b"my_list:\n- 1\n- hello", validator=WithListField
    )
    assert error_messages == [
        Message(
            text="Not a valid integer.",
            code="type_error.integer",
            position=Position(
                line_no=3, column_no=2, char_index=len("my_list:\n- 1\n- ")
            ),
        )
    ]



# Generated at 2022-06-12 16:17:42.062035
# Unit test for function validate_yaml
def test_validate_yaml():
    token = tokenize_yaml("{}")
    result = validate_with_positions(token=token, validator=Schema)
    assert result



# Generated at 2022-06-12 16:17:49.085512
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    # define content
    content="""
        array:
            - foo
            - bar
        """
    # define validator
    class TestValidator(Schema):
    # define validator
        array = Field(type="array", items=Field(type="string"))
    # validate content
    result, errors = validate_yaml(content, validator=TestValidator)
    # check assert
    assert result is not None, "result is None"
    assert errors is None, "errors is not None"



# Generated at 2022-06-12 16:18:01.277266
# Unit test for function validate_yaml
def test_validate_yaml():

    with open('data/simple_yaml.yml', 'r') as f:
        content = f.read()
    
    with open('data/valid_schema.yml', 'r') as f:
        validator = f.read()
    
    class SimpleSchema(Schema):
        name = fields.String()
        slug = fields.String()
        age = fields.Integer()
        height = fields.String()
        weight = fields.Float()

    value, errors = validate_yaml(content, validator)
    # print(value, errors)
    assert value == {'name': 'simon', 'slug': 'simon', 'age': 20, 'height': '5\'8"', 'weight': 150.5}
    assert len(errors) == 0


# Generated at 2022-06-12 16:18:07.818530
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "Alex"
    age: 28
    """
    validator = Schema(name=str, age=int)
    value, error_messages = validate_yaml(content, validator)

    assert value == {"name": "Alex", "age": 28}
    assert error_messages == []



# Generated at 2022-06-12 16:18:13.642992
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""
    name:
      first: Bret
      last: Taylor
    """
    assert validate_yaml(
        content,
        {
            "name": {
                "first": {"type": "string"},
                "last": {"type": "string"},
            }
        },  # type: ignore
    ) == (
        {"name": {"first": "Bret", "last": "Taylor"}},
        [],
    )

# Generated at 2022-06-12 16:18:20.450506
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema([
        {
            'foo': [{
                'bar': String
            }]
        }
    ])

    yaml_string = """
---
foo:
  - bar: 123
  - baz: 123
    """
    token = tokenize_yaml(yaml_string)
    error_messages = validate_with_positions(token, schema)
    assert isinstance(error_messages, list)
    assert len(error_messages) == 1
    assert error_messages[0].code == 'missing_field_error'
    assert error_messages[0].position.line_no == 4
    assert error_messages[0].position.column_no == 3
    assert error_messages[0].text == 'Expected field "bar" to be present.'
    assert error

# Generated at 2022-06-12 16:18:31.937838
# Unit test for function validate_yaml
def test_validate_yaml():
    s = '''
        name: John
        age: 25
        '''
    s = s.encode('utf-8')
    value, err_msgs = validate_yaml(s, Person)
    assert value['name'] == 'John'
    assert value['age'] == 25

    s = '''
        name: John
        '''
    s = s.encode('utf-8')
    value, err_msgs = validate_yaml(s, Person)
    assert value['name'] == 'John'
    assert err_msgs[0].text == "Missing data for required field 'age'."

    p = Person.from_dict({'name': 'John', 'age': 25})
    p.validate()
    s = str(p)
    assert len(s) > 0
    p2 = Person

# Generated at 2022-06-12 16:18:35.970290
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import TYPE_CHECKING
    from typesystem import parse_as_type

    if TYPE_CHECKING:
        from .test_tokenize import sample_yaml
        from .test_tokenize import sample_yaml_validator

    value, messages = validate_yaml(
        sample_yaml, parse_as_type(sample_yaml_validator, "yaml")
    )
    assert value is not None
    assert messages == []

# Generated at 2022-06-12 16:18:37.196932
# Unit test for function validate_yaml
def test_validate_yaml():
    print(validate_yaml('name: "Sam"'))



# Generated at 2022-06-12 16:18:48.033436
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test empty YAML string
    with pytest.raises(ParseError) as excinfo:
        validate_yaml("", str)
    assert excinfo.value.code == "no_content"
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.char_index == 0

    # Test Invalid YAML
    with pytest.raises(ParseError) as excinfo:
        validate_yaml("foo: !!str 101 # Error: did not find expected <document start>", str)
    assert excinfo.value.code == "parse_error"
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.column_no == 18

# Generated at 2022-06-12 16:18:58.000261
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    test:
        - one
        - two
        - three
    """)
    assert token["test"][0].start == 6
    assert token["test"][0].end == 9
    assert token["test"][0].position == Position(
        line_no=3, column_no=7, char_index=14
    )
    assert token["test"][1].start == 13
    assert token["test"][1].end == 16
    assert token["test"][1].position == Position(
        line_no=4, column_no=7, char_index=27
    )
    assert token["test"][2].start == 20
    assert token["test"][2].end == 25

# Generated at 2022-06-12 16:19:02.482213
# Unit test for function validate_yaml
def test_validate_yaml():
    content = 'name: "My Name"'
    validator = Schema("name")
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "My Name"}
    assert error_messages == []


# Generated at 2022-06-12 16:19:17.945631
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = String()
        age = Float()

    result = validate_yaml(b'name: Francie\nage: 12.3\n', MySchema)
    value = result[0]
    assert isinstance(value, dict)
    assert value['name'] == 'Francie'
    assert value['age'] == 12.3
    assert result[1] == []

    result = validate_yaml(b'name: Francie\nage: 12\n', MySchema)
    assert result[1][0].position.line_no == 3
    assert result[1][0].position.column_no == 6
    assert result[1][0].text == 'Value should be a float.'
    assert result[1][0].code == 'invalid_type'

    result = validate

# Generated at 2022-06-12 16:19:25.123568
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(b"", Field()) == (None, [])
    assert validate_yaml(b'foo: "bar"\n', Field()) == ({"foo": "bar"}, [])
    assert validate_yaml(b"foo: bar\n", Field()) == (None, [])
    assert validate_yaml('foo: "bar"\n', Field()) == ({"foo": "bar"}, [])
    assert validate_yaml("foo: bar\n", Field()) == (None, [])
    assert validate_yaml('foo: "bar"\n', Field()) == ({"foo": "bar"}, [])
    assert validate_yaml("foo: bar\n", Field()) == (None, [])
    assert validate_yaml(b"foo: bar\n", Field()) == (None, [])

# Generated at 2022-06-12 16:19:28.830232
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    data = loads("""
        key:
          - value1
          - value2
    """)
    assert tokenize_yaml(data) == {
        'key': [
            'value1',
            'value2'
        ]
    }


# Generated at 2022-06-12 16:19:31.090659
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(content=b"abc") == ScalarToken(value="abc", start=0, end=3)



# Generated at 2022-06-12 16:19:42.411088
# Unit test for function validate_yaml
def test_validate_yaml():
    valid_yaml = """
    sites:
        - name: 'Google'
          url: 'https://www.google.com'
        - name: 'Example'
          url: 'http://www.example.com'
    """

    error_yaml = """
    sites:
        - name: 'Google'
          url: 'www.google.com'  # missing "http://"
        - name: 'Example'
          url: 'http://www.example.com'
    """

    class Site(Schema):
        name = Field(str)
        url = Field(str)

    class Sites(Schema):
        sites = Field(ListField(Site))

    value, error_messages = validate_yaml(
        content=valid_yaml, validator=Sites
    )
    assert error_messages

# Generated at 2022-06-12 16:19:44.942190
# Unit test for function validate_yaml
def test_validate_yaml():
    string = "a"
    assert validate_yaml(string, Field())[0] == "a"

# Generated at 2022-06-12 16:19:55.309647
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Array, Integer, Object, String

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=120)

    class Group(Schema):
        name = String(max_length=10)
        members = Array[Person]()

    data_yaml = """
    name: Acme  # too long
    members:
      - name: Fred
        age: 25
      - name: Mary
        age: 30
      - name: John  # too long
        age: 0  # too small
    """

    def assert_result(result):
        (value, errors) = result
        assert isinstance(errors, list)
        assert len(errors) == 3

# Generated at 2022-06-12 16:20:05.175554
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from jasmine.utils.fields.yaml import YamlString

    def assert_valid(value: typing.Any, yaml_value: typing.Optional[str]=None) -> None:
        if yaml_value is None:
            yaml_value = value
        if isinstance(yaml_value, str):
            messages = validate_yaml(yaml_value, String())
        else:
            messages = validate_yaml(yaml_value, YamlString())
        assert messages[0] == value
        assert not messages[1]


# Generated at 2022-06-12 16:20:11.141858
# Unit test for function validate_yaml
def test_validate_yaml():
    token = tokenize_yaml("a: 1\nb: 2")
    schema = type("Schema", (Schema,), {"a": Field(int), "b": Field(int)})
    assert validate_yaml("a: 1\nb: 2", schema) == ({"a": 1, "b": 2}, [])



# Generated at 2022-06-12 16:20:21.818089
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema([
        Field(name="foo", type="string", nullable=True),
        Field(name="bar", type="string"),
        Field(name="baz", type="list", items={"type": "string"}),
    ])
    content = """
    foo: "bar"
    baz:
        - one
        - two
    """
    result, messages = validate_yaml(content, schema)
    expected_messages = [
        Message(
            text="Missing required field 'bar'.",
            code="missing",
            path=["bar"],
            value=None,
            position=Position(
                line_no=3, column_no=1, char_index=content.index("bar") + 1
            ),
        )
    ]
    assert messages == expected_messages



# Generated at 2022-06-12 16:20:35.531933
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import (
        Boolean,
        Integer,
        Object,
        String,
    )
    source = """
    name: "User"
    age: 10
    active: true
    """
    User = Object.of(
        {"name": String, "age": Integer, "active": Boolean},
        additional_properties=False,
    )
    value, errors = validate_yaml(source, User)
    assert value == {"name": "User", "age": 10, "active": True}
    assert errors == ()


# Generated at 2022-06-12 16:20:45.705021
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        foo = String()
        bar = Integer()

    content = validate_yaml(
        yaml.dump({"foo": "", "bar": 1}),
        validator=MySchema,
    )
    assert content == {"foo": "", "bar": 1}

    with pytest.raises(ValidationError):
        validate_yaml(
            yaml.dump({"foo": "", "bar": "1"}),
            validator=MySchema,
        )

# Generated at 2022-06-12 16:20:51.845569
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()

    data = '''name: John
age: 42'''

    messages = validate_yaml(data, Person)
    assert messages is None

    data = '''name: John
age: 42
not here: yes'''

    messages = validate_yaml(data, Person)
    assert messages == {'messages': [{'code': 'unexpected-field',
                                    'message': 'unexpected field "not here"',
                                    'position': {'column_no': 3,
                                                'line_no': 3,
                                                'char_index': 14}}]}

# Generated at 2022-06-12 16:21:01.214717
# Unit test for function validate_yaml
def test_validate_yaml():
    import yaml
    from typesystem import Schema
    from typesystem import fields
    from typesystem.schemas import yaml_schema

    class TestSchema(Schema):
        name = fields.String(max_length=10)
        count = fields.Integer(minimum=0, maximum=100)

    str_content = """
    name: Sandy
    count: 3
    """

    result_value, result_errors = validate_yaml(str_content, TestSchema)
    assert result_value['name'] == "Sandy"
    assert result_value['count'] == 3
    assert len(result_errors) == 0

    result_value, result_errors = validate_yaml(str_content, yaml_schema(TestSchema))
    assert result_value['name'] == "Sandy"

# Generated at 2022-06-12 16:21:13.356145
# Unit test for function validate_yaml
def test_validate_yaml():
    # Valid YAML should parse and validate successfully.
    content = "foo: 'bar'"
    value, messages = validate_yaml(content, validator={"foo": str})
    assert value == {"foo": "bar"}
    assert not any(messages)

    # Invalid YAML should throw a parse error.
    content = "foo: 'bar"
    with pytest.raises(ParseError) as exc:
        validate_yaml(content, validator={"foo": str})
    assert exc.value.code == "parse_error"
    assert exc.value.text == "mapping values are not allowed here."
    assert exc.value.position == Position(column_no=11, line_no=1, char_index=10)

    # Valid YAML should validate successfully.

# Generated at 2022-06-12 16:21:21.401736
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    # A comment
    # A second comment
    name:
        - "Alice"
    """
    token = tokenize_yaml(content)
    errors = validate_with_positions(token=token, validator=Schema({
        "name": [str]
    }))[1]
    assert errors == [
        Message(
            text="Extra data. Did not expect to find '- \"Alice\"'.",
            code="extra_data",
            position=Position(
                line_no=2, column_no=3, char_index=26,
            ),
        ),
    ]



# Generated at 2022-06-12 16:21:28.650924
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from pytest import raises
    import yaml

    # Define an empty string
    assert tokenize_yaml(content='') == yaml.load(content='', Loader=yaml.FullLoader)
    assert tokenize_yaml(content='') == None

    # Define a YAML string and a python dictionary
    yaml_string = 'legal_names: [{"type": "preferred", "name": "Omar Khayyam"}]'
    yaml_dict = {'legal_names': [{'name': 'Omar Khayyam', 'type': 'preferred'}]}

    # Test the YAML string against the following cases
    # in the function tokenize_yaml
    #
    # case1: content = ''
    # case2: isinstance(content, bytes)
    # case

# Generated at 2022-06-12 16:21:33.935826
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, Schema
    from typesystem.util import TypedDict

    class Pet(Schema):
        name = Integer()

    class Person(Schema):
        pets = TypedDict(Pet)

    content = "name: 1"

    assert validate_yaml(content, Pet) == ({'name': 1}, [])



# Generated at 2022-06-12 16:21:44.104503
# Unit test for function validate_yaml
def test_validate_yaml():

    schema = Schema("test", fields=[
        Field("prop", prop_name="prop"),
    ])

    def check_validation(input, value, errors):
        actual_value, actual_errors = validate_yaml(input, schema)
        assert actual_value == value
        assert actual_errors == errors

    check_validation(input="{}", value={"prop": None}, errors=[])
    check_validation(input="prop: xyz", value={"prop": "xyz"}, errors=[])
    check_validation(input="{prop: xyz}", value={"prop": "xyz"}, errors=[])

# Generated at 2022-06-12 16:21:53.541926
# Unit test for function validate_yaml
def test_validate_yaml():
    message = ""
    assert validate_yaml("", Field()) == (None, [])
    assert validate_yaml("", Field(required=True)) == (None, [])
    assert validate_yaml("hi", Field()) == ("hi", [])
    assert validate_yaml("hi", Field(required=False)) == ("hi", [])
    assert validate_yaml("", Field(required=True)) == (None, [])
    assert validate_yaml("", Field(required=True)) == (None, [])
    message = validate_yaml("hi", Field(required=True))
    assert message == (None, [])


text = """\
#
# This comment should be preserved.
#
name: John Doe
age: 43
spouse:
  name: Jane Doe
  age: 39
  """

#

# Generated at 2022-06-12 16:22:13.987186
# Unit test for function validate_yaml
def test_validate_yaml():
    import sys

    import pytest

    if sys.version_info[0] == 2:  # pragma: no cover
        pytest.skip("YAML tokenization is not supported on Python 2.")

    if yaml is None:  # pragma: no cover
        pytest.skip("pyyaml must be installed.")

    from typesystem import Integer, Object, String

    class User(Object):
        id = Integer()
        name = String(min_length=5)

    schema = User()

    content = u"""
    id: 1
    name: bruce
    """
    value, child_errors = validate_yaml(content, validator=schema)