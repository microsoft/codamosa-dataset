

# Generated at 2022-06-18 12:45:32.656229
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """
    value, errors = validate_yaml(content, MySchema)
    assert errors[0].text == "Must be an integer."
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 4

    content = """
    name: "John"
    age: 30
    """
    value, errors = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": 30}
    assert not errors



# Generated at 2022-06-18 12:45:42.492564
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:45:50.777505
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.1") == ScalarToken(1.1, 0, 3, content="1.1")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:46:01.774997
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: thirty
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be a valid integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=18),
        )
    ]



# Generated at 2022-06-18 12:46:12.364322
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:46:24.735455
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:46:35.584593
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: John Doe
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: John Doe
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: John Doe
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

# Generated at 2022-06-18 12:46:44.254749
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Expected a string.",
            code="invalid",
            position=Position(line_no=2, column_no=7, char_index=14),
        )
    ]

    content = """
    name:
    """

    value, errors = validate_yaml(content, Person)


# Generated at 2022-06-18 12:46:53.334202
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """
    value, error_messages = validate_yaml(content, Person)
    assert error_messages == [
        Message(
            text="Value must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=18),
        )
    ]

# Generated at 2022-06-18 12:47:03.482137
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("'foo'") == "foo"
    assert tokenize_yaml('"foo"') == "foo"
    assert tokenize_yaml("1:2") == {1: 2}

# Generated at 2022-06-18 12:47:17.379622
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:47:28.619033
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("{a: 1}") == {"a": 1}
    assert tokenize_yaml("[1, 2]") == [1, 2]
    assert tokenize_yaml("{a: 1, b: 2}") == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:47:32.092870
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - foo
    - bar
    """
    validator = typing.List[str]
    value, error_messages = validate_yaml(content, validator)
    assert value == ["foo", "bar"]
    assert error_messages == []



# Generated at 2022-06-18 12:47:34.983236
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    - a
    - b
    - c
    """
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert token.value == ["a", "b", "c"]



# Generated at 2022-06-18 12:47:40.696667
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 42
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 42}
    assert errors == []

    content = """
    name: John
    age: forty-two
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be an integer.",
            code="invalid",
            position=Position(line_no=3, column_no=5, char_index=15),
        )
    ]

    content = """
    name: John
    age: 42
    extra: value
    """

    value, errors

# Generated at 2022-06-18 12:47:52.522447
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a: 1") == {"a": 1}
    assert tokenize_yaml("- 1") == [1]
    assert tokenize_yaml("- 1\n- 2") == [1, 2]
    assert tokenize_yaml("- 1\n- 2\n- 3") == [1, 2, 3]
    assert tokenize_y

# Generated at 2022-06-18 12:47:56.397398
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    b: 2
    """
    schema = Schema({"a": int, "b": int})
    value, errors = validate_yaml(content, schema)
    assert value == {"a": 1, "b": 2}
    assert errors == []



# Generated at 2022-06-18 12:48:06.060885
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("a") == ScalarToken("a", 0, 0, content="a")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")

# Generated at 2022-06-18 12:48:17.675290
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("a: 1") == {'a': 1}
    assert tokenize_yaml("a: 1\nb: 2") == {'a': 1, 'b': 2}
    assert tokenize_yaml("a: 1\nb: 2\n") == {'a': 1, 'b': 2}
    assert tokenize_yaml("a: 1\nb: 2\n\n") == {'a': 1, 'b': 2}
    assert tokenize_yaml("a: 1\nb: 2\n\n\n") == {'a': 1, 'b': 2}
    assert tokenize_yaml("a: 1\nb: 2\n\n\n\n") == {'a': 1, 'b': 2}

# Generated at 2022-06-18 12:48:29.239059
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("a: b") == {'a': 'b'}
    assert tokenize_yaml("a: b\nc: d") == {'a': 'b', 'c': 'd'}
    assert tokenize_yaml("a: b\nc: d\n") == {'a': 'b', 'c': 'd'}
    assert tokenize_yaml("a: b\nc: d\n\n") == {'a': 'b', 'c': 'd'}
    assert tokenize_yaml("a: b\nc: d\n\n\n") == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-18 12:48:43.624906
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": 123}
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="invalid_type",
            position=Position(line_no=2, column_no=7, char_index=10),
        )
    ]


# Generated at 2022-06-18 12:48:53.837131
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class MySchema(Schema):
        name = String()

    content = """
    name: "John"
    """

    token = tokenize_yaml(content)
    value, errors = validate_with_positions(token=token, validator=MySchema)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: 123
    """

    token = tokenize_yaml(content)
    value, errors = validate_with_positions(token=token, validator=MySchema)
    assert value is None

# Generated at 2022-06-18 12:49:05.505773
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a: 1") == {"a": 1}
    assert tokenize_yaml("[1, 2]") == [1, 2]
    assert tokenize_yaml("{a: 1}") == {"a": 1}
    assert tokenize_yaml("{a: 1, b: 2}") == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:49:13.449553
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """

    value, error_messages = validate_yaml(content, PersonSchema)
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(
                line_no=3, column_no=5, char_index=len("    name: \"John\"\n")
            ),
        )
    ]

    content = """
    name: "John"
    age: 30
    """


# Generated at 2022-06-18 12:49:20.888976
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test validator
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    # Test content
    content = """
    name: John
    age: 30
    """

    # Test validation
    value, error_messages = validate_yaml(content, TestSchema)

    # Test value
    assert value == {"name": "John", "age": 30}

    # Test error messages
    assert error_messages == []



# Generated at 2022-06-18 12:49:30.224520
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:49:42.104969
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.1") == ScalarToken(1.1, 0, 3, content="1.1")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:49:52.853517
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:50:05.216681
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()

    content = """
    name: John
    age: 25
    height: 1.8
    is_adult: true
    """

    value, errors = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 25,
        "height": 1.8,
        "is_adult": True,
    }
    assert not errors

    content = """
    name: John
    age: 25
    height: 1.8
    is_adult: true
    """


# Generated at 2022-06-18 12:50:09.598631
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(items=Object(Person))

    # Test valid input
    valid_yaml = """
    name: John
    age: 30
    height: 1.8
    is_cool: true
    friends:
      - name: Jane
        age: 25
        height: 1.6
        is_cool: false
        friends: []
      - name: Bob
        age: 27
        height: 1.7
        is_cool: true
        friends: []
    """

# Generated at 2022-06-18 12:50:19.760532
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """
    value, errors = validate_yaml(content, TestSchema)
    assert value == {"name": "John", "age": 30}
    assert errors == [
        Message(
            text="Expected an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=18),
        )
    ]

# Generated at 2022-06-18 12:50:29.319704
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    content = "name: foo"
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "foo"}
    assert error_messages == []

    content = "name: foo\nage: bar"
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "foo"}
    assert error_messages == [
        Message(
            text="'age' is not a valid field.",
            code="invalid_field",
            position=Position(line_no=2, column_no=1, char_index=9),
        )
    ]


# Generated at 2022-06-18 12:50:34.686993
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 30
    """
    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:50:45.468101
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String(max_length=10)

    content = """
    name: John
    """
    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    """
    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John Doe
    """
    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name": "John Doe"}

# Generated at 2022-06-18 12:50:55.661909
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()

    class Address(Schema):
        street = String()
        city = String()
        state = String()
        zipcode = String()

    class PersonWithAddress(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        address = Object(Address)

    class PersonWithAddresses(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        addresses = Array(Object(Address))


# Generated at 2022-06-18 12:51:06.135681
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 42
    """
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

    content = """
    name: "John Doe"
    age: -42
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": -42}

# Generated at 2022-06-18 12:51:14.337193
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: thirty
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5



# Generated at 2022-06-18 12:51:23.605112
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": "thirty"}

# Generated at 2022-06-18 12:51:27.753093
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:51:37.079845
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "20"
    """

    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": 20}
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be an integer."
    assert error_messages[0].code == "invalid_type"
    assert error_messages[0].position.line_no == 3
    assert error_messages[0].position.column_no == 5



# Generated at 2022-06-18 12:51:44.521949
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)

    assert value == {"name": "John", "age": 30}
    assert errors == []



# Generated at 2022-06-18 12:51:52.698104
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 42
    """
    class Person(Schema):
        name = String()
        age = Integer()

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert errors == []

    content = """
    name: John Doe
    age: forty-two
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5
    assert errors[0].position.char_index == 23


# Generated at 2022-06-18 12:51:59.442200
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: test
      age: 20
      is_active: true
    """
    validator = Schema(
        {
            "name": str,
            "age": int,
            "is_active": bool,
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {
        "name": "test",
        "age": 20,
        "is_active": True,
    }
    assert error_messages == []



# Generated at 2022-06-18 12:52:08.523990
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 42
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert errors == []

    content = """
    name: John Doe
    age: -42
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": -42}

# Generated at 2022-06-18 12:52:17.656437
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - a
    - b
    - c
    """
    validator = Field(type="list", items=Field(type="string"))
    value, error_messages = validate_yaml(content, validator)
    assert value == ["a", "b", "c"]
    assert error_messages == []

    content = """
    - a
    - b
    - c
    - d
    """
    validator = Field(type="list", items=Field(type="string"), max_length=3)
    value, error_messages = validate_yaml(content, validator)
    assert value == ["a", "b", "c", "d"]

# Generated at 2022-06-18 12:52:28.040865
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("- a\n- b") == ["a", "b"]

# Generated at 2022-06-18 12:52:39.063177
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be a valid integer."
    assert error_messages[0].position.line_no == 3
    assert error_mess

# Generated at 2022-06-18 12:52:44.355209
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class PeopleObject(Schema):
        people = Object(properties={"person": Person()})

    class PeopleObjectWithRequired(Schema):
        people = Object(properties={"person": Person()}, required=["person"])

    class PeopleObjectWithAdditionalProperties(Schema):
        people = Object(properties={"person": Person()}, additional_properties=True)


# Generated at 2022-06-18 12:52:52.062264
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "string"
        age = "integer"

    content = """
    name: "John"
    age: "30"
    """

    value, error_messages = validate_yaml(content, TestSchema)
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be an integer."
    assert error_messages[0].position.line_no == 3
    assert error_messages[0].position.column_no == 5



# Generated at 2022-06-18 12:52:56.657911
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="invalid",
            position=Position(line_no=2, column_no=7, char_index=11),
        )
    ]


# Generated at 2022-06-18 12:53:11.781436
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String()

    content = """
    name: "test"
    """

    value, error_messages = validate_yaml(content, TestSchema)
    assert value == {"name": "test"}
    assert error_messages == []

    content = """
    name: "test"
    """

    value, error_messages = validate_yaml(content, TestSchema)
    assert value == {"name": "test"}
    assert error_messages == []

    content = """
    name: "test"
    """

    value, error_messages = validate_yaml(content, TestSchema)
    assert value == {"name": "test"}
    assert error_messages

# Generated at 2022-06-18 12:53:22.179936
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert errors == []
    assert value == {"name": "John", "age": 30}

    content = """
    name: John
    age: -30
    """
    value, errors = validate_yaml(content, Person)
    assert len(errors) == 1
    assert errors[0].code == "minimum"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5
    assert errors[0].position.char_index == 16

# Generated at 2022-06-18 12:53:30.930385
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test that a valid YAML string is parsed and validated correctly.
    content = """
    name: John Doe
    age: 42
    """
    schema = Schema(
        {"name": "string", "age": "integer"}
    )
    value, error_messages = validate_yaml(content, schema)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

    # Test that an invalid YAML string is parsed and validated correctly.
    content = """
    name: John Doe
    age: 42
    """
    schema = Schema(
        {"name": "string", "age": "integer", "email": "string"}
    )
    value, error_messages = validate_yaml(content, schema)

# Generated at 2022-06-18 12:53:42.441161
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="invalid_type",
            position=Position(line_no=2, column_no=6, char_index=8),
        )
    ]



# Generated at 2022-06-18 12:53:49.014175
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:53:59.813772
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    b: 2
    """
    class MySchema(Schema):
        a = Field(type="integer")
        b = Field(type="integer")

    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"a": 1, "b": 2}
    assert error_messages == []

    content = """
    a: 1
    b: 2
    """
    class MySchema(Schema):
        a = Field(type="integer")
        b = Field(type="string")

    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:54:10.373346
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert not errors

    content = """
    name:
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].text == "This field is required."
    assert errors[0].code == "required"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 4

    content = """
    name:
    """

# Generated at 2022-06-18 12:54:19.855892
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0, maximum=3.0)
        is_active = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class PeopleObject(Schema):
        people = Object(properties={"name": String()})

    class PeopleObjectWithRequired(Schema):
        people = Object(properties={"name": String()}, required=["name"])

    class PeopleObjectWithAdditionalProperties(Schema):
        people = Object(properties={"name": String()}, additional_properties=True)


# Generated at 2022-06-18 12:54:31.210181
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = Field(type="integer")
    value, errors = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert errors == []

    content = """
    - 1
    - 2
    - "three"
    """
    validator = Field(type="integer")
    value, errors = validate_yaml(content, validator)
    assert value == [1, 2]
    assert errors == [
        ValidationError(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=4, column_no=3, char_index=21),
        )
    ]


# Generated at 2022-06-18 12:54:41.732530
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()
        friends = Array(String())
        address = Object(
            {
                "street": String(),
                "city": String(),
                "state": String(),
                "zip": String(),
            }
        )

    content = """
    name: John Doe
    age: 42
    height: 1.8
    is_active: true
    friends:
        - Jane Doe
        - Joe Doe
    address:
        street: 123 Main St.
        city: Anytown
        state: CA
        zip: 90210
    """



# Generated at 2022-06-18 12:54:54.553911
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("'string'") == "string"
    assert tokenize_yaml('"string"') == "string"
    assert tokenize_yaml("""
        key: value
    """) == {"key": "value"}
    assert tokenize_yaml("""
        - value
    """) == ["value"]

# Generated at 2022-06-18 12:55:05.724102
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0)
        is_active = Boolean()
        hobbies = Array(items=String())
        friends = Array(items=Object(Person))
