

# Generated at 2022-06-18 12:45:35.428362
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0)
        is_active = Boolean()
        friends = Array(items=Object(Person))

    content = """
    name: John Smith
    age: 20
    height: 1.8
    is_active: true
    friends:
    - name: Jane Doe
      age: 20
      height: 1.7
      is_active: true
      friends: []
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:45:44.517141
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: -1
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be greater than or equal to 0.",
            code="minimum",
            position=Position(line_no=3, column_no=5, char_index=14),
        )
    ]

    content

# Generated at 2022-06-18 12:45:49.462804
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = Field(type="integer", min_length=2)
    value, errors = validate_yaml(content, validator)
    assert errors == [
        ValidationError(
            text="Must have at least 2 items.",
            code="min_length",
            position=Position(line_no=2, column_no=1, char_index=4),
        )
    ]

# Generated at 2022-06-18 12:46:01.074990
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        children = Array(items=String())
        is_active = Boolean()

    content = """
    name: John Doe
    age: 42
    children:
      - Jane
      - Joe
      - Jill
    is_active: true
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {
        "name": "John Doe",
        "age": 42,
        "children": ["Jane", "Joe", "Jill"],
        "is_active": True,
    }
    assert error_messages == []


# Generated at 2022-06-18 12:46:08.037592
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John Doe"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: "John Doe"
    age: 42
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

    content = """
    name: "John Doe"
    age: "42"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value

# Generated at 2022-06-18 12:46:20.413514
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(type="string"),
            "age": Field(type="integer", minimum=40),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}

# Generated at 2022-06-18 12:46:26.274878
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "string"
        age = "integer"

    content = """
    name: "John"
    age: 42
    """

    value, errors = validate_yaml(content, TestSchema)
    assert value == {"name": "John", "age": 42}
    assert not errors



# Generated at 2022-06-18 12:46:37.179483
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem import String, Integer, Array, Boolean

    class Person(Schema):
        name = String()
        age = Integer()
        children = Array(items=String())
        alive = Boolean()

    content = """
    name: John
    age: 42
    children:
        - Alice
        - Bob
    alive: true
    """

    value, errors = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 42,
        "children": ["Alice", "Bob"],
        "alive": True,
    }
    assert not errors


# Generated at 2022-06-18 12:46:45.178729
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = Field(type=int)
    value, errors = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert errors == []

    content = """
    - 1
    - 2
    - 3.0
    """
    validator = Field(type=int)
    value, errors = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert errors == [
        ValidationError(
            text="Must be of type 'int'.",
            code="type_error.int",
            position=Position(line_no=4, column_no=3, char_index=15),
        )
    ]


# Generated at 2022-06-18 12:46:56.629318
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    age: 20
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}

# Generated at 2022-06-18 12:47:04.796660
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "20"
    """
    value, errors = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": 20}
    assert len(errors) == 0

    content = """
    name: "John"
    age: "twenty"
    """
    value, errors = validate_yaml(content, MySchema)
    assert value == {"name": "John"}
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
   

# Generated at 2022-06-18 12:47:08.855710
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: bar
    """
    class MySchema(Schema):
        foo = Field(type="string")

    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"foo": "bar"}
    assert error_messages == []

    content = """
    foo: bar
    """
    class MySchema(Schema):
        foo = Field(type="integer")

    value, error_messages = validate_yaml(content, MySchema)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be an integer."
    assert error_messages[0].position.line_no == 2
    assert error_messages[0].position.column_no == 5


# Generated at 2022-06-18 12:47:17.801817
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0)

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: -30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": -30}
    assert errors == [
        ValidationError(
            text="Must be greater than or equal to 0.",
            code="minimum",
            position=Position(line_no=3, column_no=5, char_index=19),
        )
    ]

    content

# Generated at 2022-06-18 12:47:28.945459
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean, Object
    from typesystem.fields import Field
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    class PersonWithChildren(Schema):
        name = String()
        age = Integer()
        children = Array(items=Person())

    class PersonWithChildrenAndPets(Schema):
        name = String()
        age = Integer()
        children = Array(items=Person())
        pets = Array(items=String())

    class PersonWithChildrenAndPetsAndBoolean(Schema):
        name = String()
        age = Integer()
        children = Array(items=Person())
        pets = Array(items=String())
        is_cool = Boolean()


# Generated at 2022-06-18 12:47:36.823022
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Value must be a string."
    assert error_messages[0].position.line_no == 2
    assert error_messages[0].position.column_no == 4



# Generated at 2022-06-18 12:47:48.506709
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("\"foo\"") == "foo"
    assert tokenize_yaml("'foo'") == "foo"
    assert tokenize_yaml("'foo") == "foo"
    assert tokenize_yaml("'foo\nbar'") == "foo\nbar"
    assert token

# Generated at 2022-06-18 12:47:52.522891
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 30
    """
    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name": "John Doe", "age": 30}
    assert errors == []

# Generated at 2022-06-18 12:47:58.363051
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 25
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []



# Generated at 2022-06-18 12:48:03.902851
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: thirty
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5



# Generated at 2022-06-18 12:48:15.637126
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Boolean, Array, Object
    from typesystem.fields import Field
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        is_active = Boolean()

    class People(Schema):
        people = Array(items=Person)

    content = """
    people:
      - name: John
        age: 20
        is_active: true
      - name: Jane
        age: 25
        is_active: false
    """

    value, errors = validate_yaml(content, People)


# Generated at 2022-06-18 12:48:33.421826
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "30"
    """
    value, errors = validate_yaml(content, UserSchema)
    assert value == {"name": "John", "age": 30}
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 6
    assert errors[0].position.char_index == 26

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, UserSchema)


# Generated at 2022-06-18 12:48:44.087297
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: thirty
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5

    content = """
    name: John
    """
    value, errors = validate_yaml(content, Person)
    assert value is None

# Generated at 2022-06-18 12:48:54.314874
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("""
        a: 1
        b: 2
        c: 3
    """) == {'a': 1, 'b': 2, 'c': 3}
    assert tokenize_yaml("""
        - 1
        - 2
        - 3
    """) == [1, 2, 3]


# Generated at 2022-06-18 12:49:05.907394
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="type_error.string",
            position=Position(line_no=2, column_no=6, char_index=11),
        )
    ]

    content = """
    name: 123
    """

# Generated at 2022-06-18 12:49:13.644780
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 3, content="foo")
    assert tokenize_yaml("1.0")

# Generated at 2022-06-18 12:49:24.829235
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        married = Boolean()
        children = Array(String())
        address = Object(
            {"street": String(), "city": String(), "state": String()}
        )

    content = """
    name: John
    age: 30
    height: 1.8
    married: true
    children:
      - John Jr.
      - Jane
    address:
      street: 123 Main St.
      city: New York
      state: NY
    """

    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:49:32.633038
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John Smith
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        ValidationError(
            text="Must have no more than 10 characters.",
            code="max_length",
            position=Position(line_no=2, column_no=7, char_index=13),
        )
    ]


# Generated at 2022-06-18 12:49:38.575197
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:49:50.293524
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: "John"
    age: "30"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert errors == []

    content = """
    name: "John"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}

# Generated at 2022-06-18 12:49:57.157550
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, UserSchema)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """

    value, error_messages = validate_yaml(content, UserSchema)
    assert value is None

# Generated at 2022-06-18 12:50:10.800563
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Dict
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0, maximum=3.0)
        is_active = Boolean()
        hobbies = Array(items=String(max_length=100))
        address = Dict(properties={"city": String(max_length=100)})

    content = """
    name: John Doe
    age: -1
    height: 3.1
    is_active: true
    hobbies:
      - swimming
      - reading
    address:
      city: New York
    """

    value, error_messages = validate_yaml

# Generated at 2022-06-18 12:50:16.442257
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """

    value, errors = validate_yaml(content, Person)
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5
    assert errors[0].position.char_index == 21



# Generated at 2022-06-18 12:50:26.423638
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    value, error_messages = validate_yaml(content, List[int])
    assert value == [1, 2, 3]
    assert error_messages == []

    content = """
    - 1
    - 2
    - "3"
    """
    value, error_messages = validate_yaml(content, List[int])
    assert value == [1, 2, 3]
    assert error_messages == [
        Message(
            text="Expected an integer.",
            code="invalid_type",
            position=Position(line_no=4, column_no=4, char_index=15),
        )
    ]

    content = """
    - 1
    - 2
    - 3
    - 4
    """

# Generated at 2022-06-18 12:50:36.033022
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("{a: 1}") == {"a": 1}
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_yaml("{a: 1, b: 2}") == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:50:41.341473
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:50:52.603140
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0)
        is_active = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class PeopleObject(Schema):
        people = Object(properties={"person": Person()})

    class PeopleObjectWithRequired(Schema):
        people = Object(properties={"person": Person()}, required=["person"])

    class PeopleObjectWithAdditionalProperties(Schema):
        people = Object(properties={"person": Person()}, additional_properties=True)


# Generated at 2022-06-18 12:51:02.637439
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(String())
        spouse = Object(Person)

    class Family(Schema):
        members = Array(Person)

    # Test valid YAML
    valid_yaml = """
    members:
    - name: John
      age: 42
      height: 1.83
      is_adult: true
      children:
      - Jane
      - Jack
      spouse:
        name: Jane
        age: 42
        height: 1.65
        is_adult: true
        children: []
        spouse: null
    """
    value, error

# Generated at 2022-06-18 12:51:11.957190
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()

    content = """
    name: 'John Doe'
    age: '30'
    """
    value, errors = validate_yaml(content, Person)
    assert errors == [
        ValidationError(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=21),
        )
    ]

    content = """
    name: 'John Doe'
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert errors == []
    assert value == {"name": "John Doe", "age": 30}

# Generated at 2022-06-18 12:51:20.997950
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: John"
    validator = Schema({"name": str})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John\nage: 30"
    validator = Schema({"name": str, "age": int})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = "name: John\nage: 30\n"
    validator = Schema({"name": str, "age": int})
    value, error_messages = validate_yaml(content, validator)

# Generated at 2022-06-18 12:51:28.924819
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: John
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert not errors

    content = """
    name: John
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert not errors

    content = """
    name: John
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert not errors

    content = """
    name: John
    """

# Generated at 2022-06-18 12:51:42.281848
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        children = Array(items=String())
        is_adult = Boolean()

    content = """
    name: John
    age: 35
    children:
        - John Jr.
        - Jane
    is_adult: true
    """

    value, errors = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 35,
        "children": ["John Jr.", "Jane"],
        "is_adult": True,
    }
    assert errors == []


# Generated at 2022-06-18 12:51:51.200623
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(String())

    content = """
    name: John
    age: 30
    height: 1.8
    is_cool: true
    friends:
      - Alice
      - Bob
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 30,
        "height": 1.8,
        "is_cool": True,
        "friends": ["Alice", "Bob"],
    }
    assert error_messages == []


# Generated at 2022-06-18 12:52:00.836565
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: thirty
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5
    assert errors[0].position.char_index == 17

    content = """
    name: John
    age: 30
    """

   

# Generated at 2022-06-18 12:52:06.271184
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:52:13.745767
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: John Doe
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert not errors

    content = """
    name: John Doe
    """
    value, errors = validate_yaml(content, String(max_length=5))
    assert value is None
    assert errors == [
        Message(
            text="Must have no more than 5 characters.",
            code="max_length",
            position=Position(line_no=2, column_no=7, char_index=12),
        )
    ]

# Generated at 2022-06-18 12:52:24.217032
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: John
      age: 18
    - name: Jane
      age: 20
    """
    class Person(Schema):
        name = String()
        age = Integer()

    value, errors = validate_yaml(content, Person)
    assert value == [
        {"name": "John", "age": 18},
        {"name": "Jane", "age": 20},
    ]
    assert errors == []

    content = """
    - name: John
      age: 18
    - name: Jane
      age: 20
      height: 5'10"
    """
    value, errors = validate_yaml(content, Person)
    assert value == [
        {"name": "John", "age": 18},
        {"name": "Jane", "age": 20},
    ]

# Generated at 2022-06-18 12:52:32.662907
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(max_length=10)

    content = """
    name: Hello, World!
    """
    value, errors = validate_yaml(content, MySchema)
    assert value == {"name": "Hello, World!"}
    assert len(errors) == 1
    assert errors[0].code == "max_length"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 6



# Generated at 2022-06-18 12:52:38.454269
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    class PersonSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True)

    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:52:45.763350
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: "John"
      age: 30
    - name: "Jane"
      age: 20
    """
    validator = Schema(
        fields={
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == [
        {"name": "John", "age": 30},
        {"name": "Jane", "age": 20},
    ]
    assert error_messages == []



# Generated at 2022-06-18 12:52:57.706412
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0)
        is_cool = Boolean()
        friends = Array(items=String())

    content = """
    name: "John"
    age: 30
    height: 1.75
    is_cool: true
    friends:
      - "Jane"
      - "Joe"
    """

    value, error_messages = validate_yaml(content, validator=MySchema)

# Generated at 2022-06-18 12:53:12.598473
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None

# Generated at 2022-06-18 12:53:23.124916
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - foo
    - bar
    """
    validator = Field(type="array", items=Field(type="string"))
    value, error_messages = validate_yaml(content, validator)
    assert value == ["foo", "bar"]
    assert error_messages == []

    content = """
    - foo
    - bar
    - 123
    """
    value, error_messages = validate_yaml(content, validator)
    assert value == ["foo", "bar", "123"]
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="type_error",
            position=Position(line_no=3, column_no=4, char_index=14),
        )
    ]


# Generated at 2022-06-18 12:53:27.472768
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 43
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 43}
    assert error_messages == []



# Generated at 2022-06-18 12:53:33.201405
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 42
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []



# Generated at 2022-06-18 12:53:43.882106
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert not errors

    content = """
    name: John Doe
    age: -30
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be greater than or equal to 0.",
            code="minimum",
            position=Position(line_no=3, column_no=5, char_index=17),
        )
    ]


# Generated at 2022-06-18 12:53:51.719629
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 4



# Generated at 2022-06-18 12:53:58.058377
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """

    value, errors = validate_yaml(content, Person)
    assert errors == [
        Message(
            text="Not a valid integer.",
            code="invalid",
            position=Position(line_no=3, column_no=5, char_index=20),
        )
    ]

# Generated at 2022-06-18 12:54:05.691291
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()

    class Family(Schema):
        members = Array(items=Person)

    class Family2(Schema):
        members = Array(items=Person)

    class Family3(Schema):
        members = Array(items=Person)

    class Family4(Schema):
        members = Array(items=Person)

    class Family5(Schema):
        members = Array(items=Person)

    class Family6(Schema):
        members = Array(items=Person)

    class Family7(Schema):
        members = Array(items=Person)


# Generated at 2022-06-18 12:54:17.178753
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: John
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John Smith
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must have no more than 10 characters.",
            code="max_length",
            position=Position(line_no=2, column_no=5, char_index=10),
        )
    ]

    content = """
    name: John
    age: 30
    """


# Generated at 2022-06-18 12:54:28.020153
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)
        children = Array(items=String(max_length=100))
        is_adult = Boolean()

    content = """
    name: John Doe
    age: 42
    children:
        - Jane
        - Joe
    is_adult: true
    """

    value, error_messages = validate_yaml(content, Person)

    assert value == {
        "name": "John Doe",
        "age": 42,
        "children": ["Jane", "Joe"],
        "is_adult": True,
    }

    assert error_messages == []


# Generated at 2022-06-18 12:54:41.304864
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("[]") == ListToken([], 0, 1)
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0)
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3)
    assert tokenize_yaml("a: 1") == DictToken({"a": 1}, 0, 4)
    assert tokenize

# Generated at 2022-06-18 12:54:52.252306
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 30
    """
    class Person(Schema):
        name = String()
        age = Integer()

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []

    content = """
    name: "John Doe"
    age: "thirty"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": "thirty"}

# Generated at 2022-06-18 12:55:02.136703
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert len(error_messages) == 1
    assert error_messages[0].text == "Additional properties are not allowed."
    assert error_messages[0].position.line_no == 3
    assert error_messages[0].position.column_no == 1

   

# Generated at 2022-06-18 12:55:13.070722
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert errors == []

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert errors == []

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert errors == []
