

# Generated at 2022-06-18 12:45:28.543732
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0)
        is_active = Boolean()
        friends = Array(items=String())

    content = """
    name: John Doe
    age: 42
    height: 1.75
    is_active: true
    friends:
      - Jane Doe
      - Joe Doe
    """

    value, error_messages = validate_yaml(content, validator=Person)


# Generated at 2022-06-18 12:45:40.111438
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}
    assert tokenize_yaml("- foo") == ["foo"]
    assert tokenize_yaml("- foo\n- bar") == ["foo", "bar"]

# Generated at 2022-06-18 12:45:47.483698
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = Field(type="integer", min_length=1)
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == []

    content = """
    - 1
    - 2
    - 3
    """
    validator = Field(type="integer", min_length=4)
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]

# Generated at 2022-06-18 12:45:58.649408
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("\"foo\"") == "foo"
    assert tokenize_yaml("\"foo\nbar\"") == "foo\nbar"
    assert tokenize_yaml("\"foo\\nbar\"") == "foo\nbar"

# Generated at 2022-06-18 12:46:08.012577
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(items=String())

    content = """
    name: "John"
    age: 42
    height: 1.75
    is_cool: true
    friends:
      - "Jane"
      - "Bob"
    """

    value, errors = validate_yaml(content, validator=MySchema)
    assert value == {
        "name": "John",
        "age": 42,
        "height": 1.75,
        "is_cool": True,
        "friends": ["Jane", "Bob"],
    }
   

# Generated at 2022-06-18 12:46:20.418964
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    content = """
    name: "John Doe"
    """
    value, errors = validate_yaml(content, MySchema)
    assert value == {"name": "John Doe"}
    assert errors == []

    content = """
    name: 123
    """
    value, errors = validate_yaml(content, MySchema)
    assert value is None
    assert errors == [
        ValidationError(
            text="Must be a string.",
            code="invalid_type",
            position=Position(line_no=2, column_no=6, char_index=10),
        )
    ]

    content = """
    name: 123
    """
    value

# Generated at 2022-06-18 12:46:31.535592
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Boolean, Array

    class PersonSchema(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()
        friends = Array(String())

    content = """
    name: "John Doe"
    age: "42"
    height: 1.8
    is_active: true
    friends:
        - "Jane Doe"
        - "Foo Bar"
    """

    value, error_messages = validate_yaml(content, PersonSchema)

# Generated at 2022-06-18 12:46:41.964365
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = "name: John"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = "name: John\nage: 20"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == [
        Message(
            text="'age' is an invalid field.",
            code="invalid_field",
            position=Position(line_no=2, column_no=1, char_index=10),
        )
    ]

    content = "name: John\nage: 20"
    value, errors = validate_y

# Generated at 2022-06-18 12:46:44.945285
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert not errors


# Generated at 2022-06-18 12:46:50.146340
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("- a\n- b") == ["a", "b"]

# Generated at 2022-06-18 12:46:59.847415
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml function
    """
    content = """
    - 1
    - 2
    - 3
    """
    validator = Field(type="array", items=Field(type="integer"))
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == []



# Generated at 2022-06-18 12:47:05.945230
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:47:15.780700
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "string"
        age = "integer"

    content = """
    name: "John"
    age: "20"
    """
    value, error_messages = validate_yaml(content, TestSchema)
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=4, char_index=16),
        )
    ]

    content = """
    name: "John"
    age: "20"
    """
    value, error_messages = validate_yaml(content, TestSchema)

# Generated at 2022-06-18 12:47:27.944345
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 25
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_mess

# Generated at 2022-06-18 12:47:37.518825
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 30
    """
    validator = Schema(
        {"name": str, "age": int}
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 30}
    assert errors == []

    content = """
    name: "John Doe"
    age: "30"
    """
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": "30"}

# Generated at 2022-06-18 12:47:49.233443
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:47:59.251389
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()

    class Team(Schema):
        name = String()
        members = Array(items=Person)

    class TeamWithOptional(Schema):
        name = String()
        members = Array(items=Person, required=False)

    class TeamWithOptionalAndDefault(Schema):
        name = String()
        members = Array(items=Person, required=False, default=[])

    class TeamWithOptionalAndDefaultAndNull(Schema):
        name = String()
        members = Array(items=Person, required=False, default=[], allow_null=True)


# Generated at 2022-06-18 12:48:08.039270
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 20
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert error_messages == []

    content = """
    name: John
    age: twenty
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "twenty"}
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="invalid",
            position=Position(line_no=3, column_no=5, char_index=19),
        )
    ]


# Generated at 2022-06-18 12:48:19.398566
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class MySchema(Schema):
        name = String(max_length=10)

    content = """
    name: "foo"
    """

    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "foo"}
    assert error_messages == []

    content = """
    name: "foo"
    """

    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "foo"}
    assert error_messages == []

    content = """
    name: "foo"
    """

    value, error_messages = validate_

# Generated at 2022-06-18 12:48:31.047120
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:48:48.063973
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = b"name: 'John'"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = b"name: 'John Doe'"
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must have no more than 10 characters.",
            code="max_length",
            position=Position(line_no=1, column_no=6, char_index=5),
        )
    ]


# Generated at 2022-06-18 12:48:57.948820
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Dict

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(String())
        address = Dict(
            {
                "street": String(),
                "city": String(),
                "state": String(),
                "zip": String(),
            }
        )

    content = """
    name: John Doe
    age: 42
    height: 1.85
    is_adult: true
    children:
      - John Jr.
      - Jane
    address:
      street: 123 Main St.
      city: Anytown
      state: NY
      zip: 12345
    """

    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:49:02.616143
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"name": str})
    value, errors = validate_yaml(b'{"name": "foo"}', schema)
    assert value == {"name": "foo"}
    assert errors == []


# Generated at 2022-06-18 12:49:12.119956
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean, Object

    class User(Object):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=100)
        friends = Array(items=String(max_length=10))
        is_active = Boolean()

    content = """
    name: "John"
    age: 25
    friends:
      - "Jane"
      - "Joe"
    is_active: true
    """

    value, error_messages = validate_yaml(content, User)
    assert value == {
        "name": "John",
        "age": 25,
        "friends": ["Jane", "Joe"],
        "is_active": True,
    }
    assert error_messages == []


# Generated at 2022-06-18 12:49:23.163494
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Dict
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0)
        is_admin = Boolean()
        tags = Array(items=String(max_length=10))
        friends = Array(items=String(max_length=10))
        metadata = Dict(properties={"key": String(max_length=10)})


# Generated at 2022-06-18 12:49:31.560894
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be a string."
    assert error_messages[0].code == "type_error.string"
    assert error_messages[0].position.line_no == 2

# Generated at 2022-06-18 12:49:43.022592
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Boolean, Array

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        weight = Float(minimum=0.0)
        is_cool = Boolean()
        friends = Array(items=String())

    content = """
    name: John Doe
    age: 42
    weight: 75.5
    is_cool: true
    friends:
      - Jane
      - Bob
    """

    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:49:53.573819
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class PeopleObject(Schema):
        people = Object(properties={"name": String(), "age": Integer()})

    class PeopleObjectWithRequired(Schema):
        people = Object(properties={"name": String(), "age": Integer()}, required=["name"])

    class PeopleObjectWithAdditionalProperties(Schema):
        people = Object(properties={"name": String(), "age": Integer()}, additional_properties=True)


# Generated at 2022-06-18 12:50:05.892497
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: 123
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be a string.",
            code="invalid",
            position=Position(line_no=2, column_no=7, char_index=13),
        )
    ]

    content = """
    name: "John"
    age: 123
    """
    value, errors = validate_

# Generated at 2022-06-18 12:50:13.883308
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: 123
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        ValidationError(
            text="Must be a string.",
            code="invalid_type",
            position=Position(line_no=2, column_no=5, char_index=11),
        )
    ]

    content = """
    name: 123
    name: "John"
    """

    value,

# Generated at 2022-06-18 12:50:28.384991
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("{foo: bar}") == {'foo': 'bar'}
    assert tokenize_yaml("[foo, bar]") == ['foo', 'bar']

# Generated at 2022-06-18 12:50:38.169873
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 42
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

    content = """
    name: John Doe
    age: -42
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": -42}

# Generated at 2022-06-18 12:50:49.675302
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 42
    """
    class PersonSchema(Schema):
        name = fields.String(max_length=20)
        age = fields.Integer(minimum=0, maximum=100)
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {'name': 'John Doe', 'age': 42}
    assert error_messages == []

    content = """
    name: "John Doe"
    age: 42
    """
    class PersonSchema(Schema):
        name = fields.String(max_length=20)
        age = fields.Integer(minimum=0, maximum=100)
    value, error_messages = validate_yaml(content, PersonSchema)

# Generated at 2022-06-18 12:50:59.581291
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: thirty
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": None}
    assert errors == [
        ValidationError(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=18),
        )
    ]


# Generated at 2022-06-18 12:51:09.662692
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")
    assert tokenize_yaml("'a'")

# Generated at 2022-06-18 12:51:14.154325
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 30
    """
    validator = Schema(
        {"name": str, "age": int}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []


# Generated at 2022-06-18 12:51:23.444671
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """

# Generated at 2022-06-18 12:51:30.218500
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:51:40.630370
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = Field(type="array", items=Field(type="integer"))
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == []

    content = """
    - 1
    - 2
    - 3
    - a
    """
    validator = Field(type="array", items=Field(type="integer"))
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]

# Generated at 2022-06-18 12:51:49.969928
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(items=String())

    content = """
    name: John
    age: 42
    height: 1.82
    is_cool: true
    friends:
      - Jane
      - Bob
    """

    value, errors = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 42,
        "height": 1.82,
        "is_cool": True,
        "friends": ["Jane", "Bob"],
    }
    assert errors == []


# Generated at 2022-06-18 12:52:04.730516
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()

    class Family(Schema):
        members = Array(items=Person)

    class Address(Schema):
        street = String()
        city = String()
        state = String()
        zip_code = String()

    class PersonWithAddress(Schema):
        name = String()
        address = Object(Address)

    class FamilyWithAddress(Schema):
        members = Array(items=PersonWithAddress)

    # Test valid YAML

# Generated at 2022-06-18 12:52:12.173382
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: 20
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert errors == []

    content = """
    name: "John"
    age: "20"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "20"}

# Generated at 2022-06-18 12:52:22.625439
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 25
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_mess

# Generated at 2022-06-18 12:52:33.149832
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert not errors

    content = """
    name: John Doe
    age: -30
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be greater than or equal to 0.",
            code="minimum",
            position=Position(line_no=3, column_no=5, char_index=16),
        )
    ]


# Generated at 2022-06-18 12:52:43.643040
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = "name: John"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = "name: John\nage: 20"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert len(errors) == 1
    assert errors[0].code == "invalid_field"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 1
    assert errors[0].position.char_index == 8


# Generated at 2022-06-18 12:52:55.042718
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()

    class PersonSchema(Schema):
        person = Person()

    # Test valid YAML
    yaml_string = """
    person:
      name: John
      age: 25
      height: 1.75
      is_active: true
    """
    value, error_messages = validate_yaml(yaml_string, PersonSchema)
    assert value == {
        "person": {
            "name": "John",
            "age": 25,
            "height": 1.75,
            "is_active": True,
        }
    }
   

# Generated at 2022-06-18 12:53:00.567226
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """

    value, error_messages = validate_yaml(content, validator=Person)
    assert value == {"name": "John"}
    assert error_messages == []



# Generated at 2022-06-18 12:53:12.488663
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "string"
        age = "integer"
        height = "number"
        weight = "number"
        is_active = "boolean"
        is_admin = "boolean"
        is_superuser = "boolean"

    content = """
    name: "John Doe"
    age: 30
    height: 1.75
    weight: 70.5
    is_active: true
    is_admin: false
    is_superuser: true
    """

    value, error_messages = validate_yaml(content, TestSchema)


# Generated at 2022-06-18 12:53:23.042433
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Boolean, Array, Dict, Schema

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        alive = Boolean()

    class Family(Schema):
        members = Array(items=Person)

    class AddressBook(Schema):
        families = Dict(values=Family)

    content = """
    families:
      Smith:
        members:
          - name: John
            age: 35
            alive: true
          - name: Jane
            age: 32
            alive: true
      Jones:
        members:
          - name: Bob
            age: 12
            alive: true
          - name: Alice
            age: 15
            alive: true
    """

    value, error_messages = validate_

# Generated at 2022-06-18 12:53:31.740155
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = "name: John"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = "name: John Smith"
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "max_length"
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 6
    assert errors[0].position.char_index == 5

    content = "name: John\nname: Smith"
    value, errors = validate_

# Generated at 2022-06-18 12:53:45.764423
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String()

    content = "name: John"
    value, error_messages = validate_yaml(content, validator=PersonSchema)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John\nage: 20"
    value, error_messages = validate_yaml(content, validator=PersonSchema)
    assert value == {"name": "John"}

# Generated at 2022-06-18 12:53:57.166682
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "30"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: "thirty"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be an integer."
    assert error_messages[0].position.line_no == 3
   

# Generated at 2022-06-18 12:54:03.641140
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(max_length=10)

    content = "name: hello world"
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "hello world"}
    assert error_messages == [
        Message(
            text="Value is too long.",
            code="max_length",
            position=Position(line_no=1, column_no=6, char_index=5),
        )
    ]

# Generated at 2022-06-18 12:54:15.129295
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []

    content = """
    name: John Doe
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []

    content = """
    name: John Doe
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:54:25.522502
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: "John"
    age: "thirty"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be an integer."
    assert error_

# Generated at 2022-06-18 12:54:35.958663
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 42
    """
    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name": "John Doe", "age": 42}
    assert not errors

    content = """
    name: John Doe
    age: -42
    """
    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name": "John Doe", "age": -42}
    assert len(errors) == 1
    assert errors[0].code == "minimum"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5

   

# Generated at 2022-06-18 12:54:46.474627
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test that validate_yaml returns a tuple of (value, error_messages)
    from typesystem.fields import String

    value, error_messages = validate_yaml(
        content="""
        name: "John"
        age: 30
        """,
        validator=String(name="name"),
    )
    assert value == "John"
    assert error_messages == []

    value, error_messages = validate_yaml(
        content="""
        name: "John"
        age: 30
        """,
        validator=String(name="age"),
    )
    assert value == 30

# Generated at 2022-06-18 12:54:57.218993
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: John Doe
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: John Doe
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: John Doe
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

# Generated at 2022-06-18 12:55:07.643512
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John Doe"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: 123
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Value must be a string.",
            code="invalid",
            position=Position(line_no=2, column_no=7, char_index=13),
        )
    ]

