

# Generated at 2022-06-18 12:45:33.779787
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("a: 1") == {"a": 1}
    assert tokenize_yaml("- 1") == [1]
    assert tokenize_

# Generated at 2022-06-18 12:45:41.296660
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: John
      age: 20
    - name: Jane
      age: 30
    """
    validator = Schema(
        fields=[
            {"name": "name", "type": "string"},
            {"name": "age", "type": "integer"},
        ]
    )
    value, errors = validate_yaml(content, validator)
    assert errors == []
    assert value == [
        {"name": "John", "age": 20},
        {"name": "Jane", "age": 30},
    ]



# Generated at 2022-06-18 12:45:50.093216
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:46:01.310433
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("a: b") == {'a': 'b'}
    assert tokenize_yaml("a: b\nc: d") == {'a': 'b', 'c': 'd'}
    assert tokenize_yaml("a: b\nc: d\n") == {'a': 'b', 'c': 'd'}
    assert tokenize_yaml("a: b\nc: d\n\n") == {'a': 'b', 'c': 'd'}
    assert tokenize_yaml("a: b\nc: d\n\n\n") == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-18 12:46:11.772206
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(String())

    content = """
    name: "John"
    age: 25
    height: 1.83
    is_cool: true
    friends:
      - "Jane"
      - "Bob"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 25,
        "height": 1.83,
        "is_cool": True,
        "friends": ["Jane", "Bob"],
    }

# Generated at 2022-06-18 12:46:24.192514
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("'foo'") == "foo"
    assert tokenize_yaml('"foo"') == "foo"
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("1.0") == 1.0

# Generated at 2022-06-18 12:46:29.819152
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    yaml_str = """
    - a
    - b
    - c
    """
    token = tokenize_yaml(yaml_str)
    assert isinstance(token, ListToken)
    assert token.value == ["a", "b", "c"]
    assert token.start == 1
    assert token.end == len(yaml_str) - 1
    assert token.content == yaml_str



# Generated at 2022-06-18 12:46:40.405167
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class UserSchema(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()
        tags = Array(String())

    content = """
    name: John Doe
    age: 42
    height: 1.83
    is_active: true
    tags:
      - foo
      - bar
      - baz
    """

    value, errors = validate_yaml(content, UserSchema)

# Generated at 2022-06-18 12:46:51.161950
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        friends = Array(items=String())
        alive = Boolean()

    content = """
    name: John
    age: 30
    friends:
      - Alice
      - Bob
    alive: true
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 30,
        "friends": ["Alice", "Bob"],
        "alive": True,
    }
    assert error_messages == []


# Generated at 2022-06-18 12:47:02.442590
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("[]") == ListToken([], 0, 1)
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4)
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1)
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3)
    assert tokenize_yaml("1e10") == ScalarToken(1e10, 0, 4)
    assert tokenize_

# Generated at 2022-06-18 12:47:15.307605
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: bar
    """
    validator = Field(type="string")
    value, error_messages = validate_yaml(content, validator)
    assert value == "bar"
    assert error_messages == []

    content = """
    foo: bar
    """
    validator = Field(type="integer")
    value, error_messages = validate_yaml(content, validator)
    assert value is None
    assert error_messages == [
        Message(
            text="Expected an integer.",
            code="invalid_type",
            position=Position(line_no=2, column_no=8, char_index=8),
        )
    ]

    content = """
    foo: bar
    """
    validator = Field(type="string", max_length=3)

# Generated at 2022-06-18 12:47:27.900110
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: John
      age: 20
    - name: Jane
      age: 21
    """
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=100)

    value, error_messages = validate_yaml(content, Person)
    assert error_messages == []
    assert value == [
        {"name": "John", "age": 20},
        {"name": "Jane", "age": 21},
    ]

    content = """
    - name: John
      age: 20
    - name: Jane
      age: 21
    - name: Bob
      age: -1
    """
    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:47:37.519263
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=18)
        friends = Array(items=String(max_length=10))
        is_cool = Boolean()

    yaml_content = """
    name: John
    age: 17
    friends:
        - Alice
        - Bob
    is_cool: true
    """

    value, error_messages = validate_yaml(yaml_content, TestSchema)
    assert value == {
        "name": "John",
        "age": 17,
        "friends": ["Alice", "Bob"],
        "is_cool": True,
    }

# Generated at 2022-06-18 12:47:49.250050
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """

# Generated at 2022-06-18 12:47:52.932785
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0)

    content = """
    name: "John Smith"
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Smith", "age": 30}
    assert errors == []

    content = """
    name: "John Smith"
    age: -30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Smith", "age": -30}

# Generated at 2022-06-18 12:48:02.857103
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:48:14.147004
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class PeopleObject(Schema):
        people = Object(properties={"name": String()})

    class PeopleObjectWithRequired(Schema):
        people = Object(properties={"name": String(required=True)})

    class PeopleObjectWithAdditionalProperties(Schema):
        people = Object(
            properties={"name": String()}, additional_properties=Boolean()
        )


# Generated at 2022-06-18 12:48:24.745036
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """

    value, errors = validate_yaml(content, validator=Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    age: 20
    """

    value, errors = validate_yaml(content, validator=Person)
    assert value == {"name": "John", "age": 20}
    assert errors == [
        Message(
            text="Additional properties are not allowed ('age' was unexpected).",
            code="additional_properties",
            position=Position(line_no=3, column_no=5, char_index=17),
        )
    ]

# Generated at 2022-06-18 12:48:35.456306
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None

# Generated at 2022-06-18 12:48:46.445317
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: 'John Doe'
    age: '30'
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": "30"}
    assert error_messages == []

    content = """
    name: 'John Doe'
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}

# Generated at 2022-06-18 12:48:59.197246
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=100)
        is_active = Boolean()
        height = Float(minimum=0.0, maximum=3.0)
        friends = Array(items=String())
        address = Object(properties={"city": String(), "state": String()})

    content = """
    name: "John Doe"
    age: 42
    is_active: true
    height: 1.8
    friends:
        - "Jane Doe"
        - "Foo Bar"
    address:
        city: "New York"
        state: "NY"
    """

    value, error_mess

# Generated at 2022-06-18 12:49:10.592244
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, validator=MySchema)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, validator=MySchema)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """

    value, error

# Generated at 2022-06-18 12:49:22.536794
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean

    class Person(Schema):
        name = String()
        age = Integer()
        children = Array(items=String())
        is_adult = Boolean()

    # Valid YAML
    content = """
    name: John
    age: 30
    children:
        - Alice
        - Bob
    is_adult: true
    """
    value, errors = validate_yaml(content, Person)
    assert errors == []
    assert value == {
        "name": "John",
        "age": 30,
        "children": ["Alice", "Bob"],
        "is_adult": True,
    }

    # Invalid YAML

# Generated at 2022-06-18 12:49:27.384519
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:49:32.699501
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    content = "name: foo"
    value, error_messages = validate_yaml(content, validator=MySchema)
    assert value == {"name": "foo"}
    assert error_messages == []

    content = "name: foo\nage: 20"
    value, error_messages = validate_yaml(content, validator=MySchema)
    assert value == {"name": "foo"}

# Generated at 2022-06-18 12:49:37.129096
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - a
    - b
    - c
    """
    validator = Field(type="list", items=Field(type="string"))
    value, errors = validate_yaml(content, validator)
    assert value == ["a", "b", "c"]
    assert errors == []



# Generated at 2022-06-18 12:49:48.558234
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 42
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert errors == []

    content = """
    name: John Doe
    age: -42
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        ValidationError(
            text="Must be greater than or equal to 0.",
            code="min_value",
            position=Position(line_no=3, column_no=5, char_index=20),
        )
    ]


# Generated at 2022-06-18 12:49:56.434756
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: thirty
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].text == "Must be an integer."
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column

# Generated at 2022-06-18 12:50:08.111612
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_human = Boolean()
        friends = Array(items=String())

    content = """
    name: John
    age: 30
    height: 1.8
    is_human: true
    friends:
      - Alice
      - Bob
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 30,
        "height": 1.8,
        "is_human": True,
        "friends": ["Alice", "Bob"],
    }
    assert error_messages == []

    content

# Generated at 2022-06-18 12:50:13.129294
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": str,
            "age": int,
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:50:25.767320
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == [
        Message(
            text="'age' is an invalid field.",
            code="invalid_field",
            position=Position(line_no=3, column_no=5, char_index=15),
        )
    ]


# Generated at 2022-06-18 12:50:35.541105
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": None}

# Generated at 2022-06-18 12:50:46.456854
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test for valid YAML
    content = '''
    - a
    - b
    - c
    '''
    validator = typing.List[str]
    value, error_messages = validate_yaml(content, validator)
    assert value == ['a', 'b', 'c']
    assert error_messages == []

    # Test for invalid YAML
    content = '''
    - a
    - b
    - c
    - d
    '''
    validator = typing.List[str]
    value, error_messages = validate_yaml(content, validator)
    assert value == ['a', 'b', 'c', 'd']

# Generated at 2022-06-18 12:50:51.703527
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=18, maximum=99)
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

# Generated at 2022-06-18 12:51:01.703736
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert not error_messages

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert len(error_messages) == 1
    assert error_messages[0].code == "unknown_field"
    assert error_messages[0].position.line_no == 3
    assert error_messages[0].position.column_no == 1


# Generated at 2022-06-18 12:51:11.332877
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:51:20.671328
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name:
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="This field is required.",
            code="required",
            position=Position(line_no=2, column_no=2, char_index=7),
        )
    ]

    content = """
    name:
    """
    value, error_messages

# Generated at 2022-06-18 12:51:28.708696
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=15),
        )
    ]


# Generated at 2022-06-18 12:51:34.269788
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 42
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []



# Generated at 2022-06-18 12:51:44.435956
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(max_length=10)

    value, error_messages = validate_yaml(
        content="""
        name: "John Doe"
        """,
        validator=MySchema,
    )
    assert value == {"name": "John Doe"}
    assert error_messages == []

    value, error_messages = validate_yaml(
        content="""
        name: "John Doe"
        """,
        validator=MySchema.fields["name"],
    )
    assert value == "John Doe"
    assert error_messages == []


# Generated at 2022-06-18 12:51:53.929615
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Dict
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0, maximum=3.0)
        is_cool = Boolean()
        friends = Array(items=String(max_length=10))
        pets = Dict(properties={"name": String(max_length=10)})

    content = """
    name: "John Doe"
    age: -1
    height: 3.1
    is_cool: true
    friends:
    - "Jane Doe"
    - "Jill Doe"
    pets:
        name: "Fido"
    """

    value,

# Generated at 2022-06-18 12:52:04.049285
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """

# Generated at 2022-06-18 12:52:11.453693
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "20"
    """
    value, error_messages = validate_yaml(content, Person)
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=19),
        )
    ]

    content = """
    name: "John"
    age: 20
    """
    value, error_messages = validate_yaml(content, Person)
    assert error_messages == []
    assert value == {"name": "John", "age": 20}

# Generated at 2022-06-18 12:52:22.094049
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(max_length=10)

    content = "name: John"
    value, error_messages = validate_yaml(content, validator=UserSchema)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John Smith"
    value, error_messages = validate_yaml(content, validator=UserSchema)
    assert value is None
    assert error_messages == [
        Message(
            text="Must have no more than 10 characters.",
            code="max_length",
            position=Position(line_no=1, column_no=6, char_index=5),
        )
    ]

    content

# Generated at 2022-06-18 12:52:32.385742
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    class MySchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=100)

    content = """
    name: John
    age: 25
    """

    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: -1
    """

    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": -1}

# Generated at 2022-06-18 12:52:38.607280
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: John
      age: 30
    - name: Jane
      age: 25
    """
    validator = Schema(fields={"name": str, "age": int})
    value, error_messages = validate_yaml(content, validator)
    assert value == [{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]
    assert error_messages == []



# Generated at 2022-06-18 12:52:44.150726
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()

    class People(Schema):
        people = Array(items=Person)

    class PeopleObject(Schema):
        people = Object(properties={"name": String(), "age": Integer()})

    class PeopleObjectWithRequired(Schema):
        people = Object(properties={"name": String(), "age": Integer()}, required=["name"])

    class PersonWithNullable(Schema):
        name = String()
        age = Integer(nullable=True)

    class PeopleWithNullable(Schema):
        people = Array(items=PersonWithNullable)


# Generated at 2022-06-18 12:52:55.416299
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Dict
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_human = Boolean()
        friends = Array(items=String())
        details = Dict(properties={"address": String()})

    content = """
    name: "John"
    age: 42
    height: 1.8
    is_human: true
    friends:
        - "Jane"
        - "Joe"
    details:
        address: "123 Main Street"
    """

    value, errors = validate_yaml(content, validator=Person)

# Generated at 2022-06-18 12:53:00.567214
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    b: 2
    """
    class MySchema(Schema):
        a = fields.Integer()
        b = fields.Integer()
    value, errors = validate_yaml(content, MySchema)
    assert value == {"a": 1, "b": 2}
    assert errors == []



# Generated at 2022-06-18 12:53:10.746244
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "string"
        age = "integer"

    content = """
    name: "John"
    age: "25"
    """
    value, error_messages = validate_yaml(content, TestSchema)
    assert value == {"name": "John", "age": 25}
    assert error_messages == [
        Message(
            text="'25' is not of type 'integer'",
            code="invalid_type",
            position=Position(
                line_no=3, column_no=5, char_index=content.find("25")
            ),
        )
    ]



# Generated at 2022-06-18 12:53:23.285771
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()
        friends = Array(String())

    class PersonSchema(Schema):
        person = Object(Person)

    content = """
    person:
        name: "John"
        age: "30"
        height: "1.8"
        is_active: "true"
        friends:
            - "Jane"
            - "Bob"
    """

    value, error_messages = validate_yaml(content, PersonSchema)

# Generated at 2022-06-18 12:53:27.930833
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 42
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []



# Generated at 2022-06-18 12:53:39.352452
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")
    assert tokenize_yaml("123") == ScalarToken(123, 0, 2, content="123")
    assert tokenize_yaml("123.45") == ScalarToken(123.45, 0, 5, content="123.45")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == Scal

# Generated at 2022-06-18 12:53:47.508909
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0)
        is_active = Boolean()
        friends = Array(items=String())

    # Valid YAML
    content = """
    name: John Smith
    age: 30
    height: 1.75
    is_active: true
    friends:
      - Jane Smith
      - Bob Smith
    """
    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:53:58.186047
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        friends = Array(String())
        family = Array(Object(Person))

    yaml_content = """
    name: John
    age: 25
    height: 1.8
    is_adult: true
    friends:
    - Alice
    - Bob
    family:
    - name: Jane
      age: 50
      height: 1.6
      is_adult: true
      friends: []
      family: []
    - name: Jack
      age: 5
      height: 1.2
      is_adult: false
      friends: []
      family: []
    """

    value, error_messages

# Generated at 2022-06-18 12:54:05.768568
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean, Object

    class Person(Schema):
        name = String()
        age = Integer()
        friends = Array(items=String())
        is_active = Boolean()

    class Group(Schema):
        name = String()
        members = Array(items=Object(Person))

    schema = Object(Group)


# Generated at 2022-06-18 12:54:08.524802
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "20"
    """
    value, errors = validate_yaml(content, validator=Person)
    assert errors == [
        Message(
            text="Expected an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=19),
        )
    ]

# Generated at 2022-06-18 12:54:18.567116
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, MySchema)
    assert value is None
    assert error_messages == [
        ValidationError(
            text="Must be a string.",
            code="invalid",
            position=Position(line_no=2, column_no=7, char_index=11),
        )
    ]


# Generated at 2022-06-18 12:54:29.989401
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class PeopleObject(Schema):
        people = Object(properties={"person": Person()})

    class PeopleObjectWithRequired(Schema):
        people = Object(properties={"person": Person()}, required=["person"])

    class PeopleObjectWithAdditionalProperties(Schema):
        people = Object(properties={"person": Person()}, additional_properties=True)


# Generated at 2022-06-18 12:54:34.303637
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 25
    """

    value, error_messages = validate_yaml(content, Person)

    assert value == {"name": "John", "age": 25}
    assert error_messages == []



# Generated at 2022-06-18 12:54:48.340605
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert errors == []

    content = """
    name: John
    age: twenty-five
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "twenty-five"}
    assert errors == [
        ValidationError(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=19),
        )
    ]


# Generated at 2022-06-18 12:54:58.506994
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: bar
    """
    validator = Field(type="string")
    value, errors = validate_yaml(content, validator)
    assert value == "bar"
    assert errors == []

    content = """
    foo: 123
    """
    validator = Field(type="string")
    value, errors = validate_yaml(content, validator)
    assert value is None
    assert len(errors) == 1
    assert errors[0].text == "Must be a string."
    assert errors[0].code == "type_error.string"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 4
    assert errors[0].position.char_index == 7

    content = """
    foo: 123
    """

# Generated at 2022-06-18 12:55:10.000148
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class PeopleObject(Schema):
        people = Object(properties={"person": Person()})

    class PeopleObjectWithRequired(Schema):
        people = Object(properties={"person": Person()}, required=["person"])

    class PeopleObjectWithAdditionalProperties(Schema):
        people = Object(properties={"person": Person()}, additional_properties=True)
