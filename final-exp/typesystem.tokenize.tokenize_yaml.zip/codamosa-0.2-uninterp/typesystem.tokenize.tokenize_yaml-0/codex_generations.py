

# Generated at 2022-06-18 12:45:33.911722
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John Smith"
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Smith", "age": 30}
    assert errors == []

    content = """
    name: "John Smith"
    age: thirty
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Smith", "age": "thirty"}

# Generated at 2022-06-18 12:45:43.743406
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    """

    value, errors = validate_yaml(content, Person)
   

# Generated at 2022-06-18 12:45:47.379885
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - a
    - b
    """
    value, errors = validate_yaml(content, List[str])
    assert value == ["a", "b"]
    assert errors == []



# Generated at 2022-06-18 12:45:52.057266
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("[]") == ListToken([], 0, 1)
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0)
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3)
    assert tokenize_yaml("'string'") == ScalarToken("string", 0, 7)
    assert tokenize_yaml

# Generated at 2022-06-18 12:46:02.828515
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []


# Generated at 2022-06-18 12:46:06.437896
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 42
    """
    class Person(Schema):
        name = String()
        age = Integer()

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []



# Generated at 2022-06-18 12:46:18.891857
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Boolean, Float
    from typesystem.fields import Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        is_cool = Boolean()

    class PersonWithOptionalFields(Schema):
        name = String()
        age = Integer(required=False)
        is_cool = Boolean(required=False)

    class PersonWithDefaultFields(Schema):
        name = String()
        age = Integer(default=42)
        is_cool = Boolean(default=True)

    class PersonWithDefaultFieldsAndOptionalFields(Schema):
        name = String()
        age = Integer(default=42, required=False)
        is_cool = Boolean(default=True, required=False)

   

# Generated at 2022-06-18 12:46:29.905406
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")


# Generated at 2022-06-18 12:46:34.122588
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: 1
    b: 2
    c: 3
    """
    token = tokenize_yaml(content)
    assert token.value == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-18 12:46:43.197992
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_human = Boolean()

    class People(Schema):
        people = Array(items=Person)

    class People2(Schema):
        people = Array(items=Object(properties={"name": String()}))

    class People3(Schema):
        people = Array(items=Object(properties={"name": String(), "age": Integer()}))

    class People4(Schema):
        people = Array(items=Object(properties={"name": String(), "age": Integer(), "height": Float()}))


# Generated at 2022-06-18 12:46:56.956819
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 20
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert errors == []

    content = """
    name: John
    age: twenty
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "twenty"}
    assert errors == [
        ValidationError(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=15),
        )
    ]


# Generated at 2022-06-18 12:47:07.455375
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.1") == ScalarToken(1.1, 0, 3, content="1.1")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:47:17.016201
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: -1
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": -1}

# Generated at 2022-06-18 12:47:28.496925
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "string"
        age = "integer"
        is_active = "boolean"
        weight = "float"
        height = "float"
        created_at = "datetime"
        updated_at = "datetime"
        last_login = "datetime"
        friends = "list"
        address = "dict"


# Generated at 2022-06-18 12:47:34.560277
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: John
      age: 30
    - name: Jane
      age: 25
    """
    validator = Schema(
        fields={"name": Field(type="string"), "age": Field(type="integer")}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == [{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]
    assert error_messages == []



# Generated at 2022-06-18 12:47:44.866450
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("'string'") == "string"
    assert tokenize_yaml("'string with spaces'") == "string with spaces"
    assert tokenize_yaml("'string with \"quotes\"'") == "string with \"quotes\""

# Generated at 2022-06-18 12:47:55.868970
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)
        age = Integer(required=True)
        height = Float(required=True)
        is_cool = Boolean(required=True)
        friends = Array(String, required=True)
        family = Array(Object(Person), required=True)


# Generated at 2022-06-18 12:48:05.511456
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:48:11.148962
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    class Person(Schema):
        name = String()
        age = Integer()

    value, error_messages = validate_yaml(content, Person)
    assert error_messages == []
    assert value == {"name": "John", "age": 30}



# Generated at 2022-06-18 12:48:21.420673
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String()

    content = """
    name: foo
    """
    value, error_messages = validate_yaml(content, TestSchema)
    assert value == {"name": "foo"}
    assert error_messages == []

    content = """
    name: foo
    name: bar
    """
    value, error_messages = validate_yaml(content, TestSchema)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Field 'name' must not be repeated."
    assert error_messages[0].code == "field_repeated"
    assert error_messages[0].position.line_

# Generated at 2022-06-18 12:48:29.476443
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John"
    age: 30
    """
    class PersonSchema(Schema):
        name = String()
        age = Integer()

    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:48:40.031247
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"name": str})
    value, errors = validate_yaml("name: 'John'", schema)
    assert value == {"name": "John"}
    assert errors == []

    value, errors = validate_yaml("name: 123", schema)
    assert value is None
    assert errors == [
        Message(
            text="Value must be of type 'str'.",
            code="type_error.str",
            position=Position(line_no=1, column_no=7, char_index=6),
        )
    ]

    value, errors = validate_yaml("name: 'John'\nage: '30'", schema)
    assert value is None

# Generated at 2022-06-18 12:48:50.201703
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")
    assert tokenize_yaml("123") == ScalarToken(123, 0, 2, content="123")
    assert tokenize_yaml("123.4") == ScalarToken(123.4, 0, 4, content="123.4")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == Scal

# Generated at 2022-06-18 12:49:00.390845
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = "name: John"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John Doe"
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Ensure this value has at most 10 characters (it has 11).",
            code="max_length",
            position=Position(line_no=1, column_no=6, char_index=5),
        )
    ]


# Generated at 2022-06-18 12:49:11.529239
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0)
        is_adult = Boolean()
        children = Array(items=String())
        spouse = Object(properties={"name": String()})

    content = """
    name: John Doe
    age: 30
    height: 1.75
    is_adult: true
    children:
    - John Jr.
    - Jane
    spouse:
      name: Jane Doe
    """
    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:49:22.931759
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Dict
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0)
        height = Float(minimum=0)
        is_cool = Boolean()
        friends = Array(items=String())
        address = Dict(properties={"city": String(), "state": String()})

    content = """
    name: John
    age: 20
    height: 5.5
    is_cool: true
    friends:
      - Alice
      - Bob
    address:
      city: New York
      state: NY
    """

    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:49:31.413970
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {"name": str, "age": int}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {"name": str, "age": int, "gender": str}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}

# Generated at 2022-06-18 12:49:42.922555
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    token = tokenize_yaml(content)
    value, error_messages = validate_with_positions(token=token, validator=Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """
    token = tokenize_yaml(content)
    value, error_messages = validate_with_positions(token=token, validator=Person)
    assert value == {}

# Generated at 2022-06-18 12:49:53.504213
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class User(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()
        friends = Array(items=String())
        address = Object(properties={"city": String(), "state": String()})

    content = """
    name: Jane
    age: 25
    height: 5.5
    is_active: true
    friends:
    - John
    - Mary
    address:
      city: New York
      state: NY
    """

    value, errors = validate_yaml(content, validator=User)

# Generated at 2022-06-18 12:50:05.805048
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: John Doe"
    validator = Schema({"name": str})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = "name: John Doe\nage: 30"
    validator = Schema({"name": str})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe"}
    assert error_messages == [
        Message(
            text="Additional properties are not allowed ('age' was unexpected).",
            code="additional_properties",
            position=Position(line_no=2, column_no=1, char_index=13),
        )
    ]


# Generated at 2022-06-18 12:50:17.973559
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=100)

    content = """
    name: "John"
    age: "30"
    """

    value, errors = validate_yaml(content, UserSchema)
    assert errors == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(
                line_no=3, column_no=5, char_index=len(content.split("\n")[0]) + 1
            ),
        )
    ]

    content = """
    name: "John"
    age: 30
    """

    value, errors = validate_yaml(content, UserSchema)
    assert errors == []

# Generated at 2022-06-18 12:50:23.961320
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "TestSchema"
        fields = [
            Field(name="name", type="string"),
            Field(name="age", type="integer"),
        ]

    content = """
    name: John
    age: 20
    """

    value, error_messages = validate_yaml(content, TestSchema)
    assert value == {"name": "John", "age": 20}
    assert error_messages == []



# Generated at 2022-06-18 12:50:33.618992
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array

    class Person(Schema):
        name = String()
        age = Integer()

    class People(Schema):
        people = Array(items=Person)

    content = """
    people:
      - name: Alice
        age: 25
      - name: Bob
        age: 26
    """

    value, errors = validate_yaml(content, People)
    assert value == {"people": [{"name": "Alice", "age": 25}, {"name": "Bob", "age": 26}]}
    assert errors == []

    content = """
    people:
      - name: Alice
        age: 25
      - name: Bob
        age: "26"
    """

    value, errors = validate_yaml(content, People)

# Generated at 2022-06-18 12:50:44.448143
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("- a\n- b") == ["a", "b"]

# Generated at 2022-06-18 12:50:54.581877
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="invalid",
            position=Position(line_no=2, column_no=6, char_index=8),
        )
    ]


# Generated at 2022-06-18 12:51:05.136928
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Schema

    class UserSchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    content = """
    name: John
    age: 20
    """
    value, errors = validate_yaml(content, UserSchema)
    assert value == {"name": "John", "age": 20}
    assert not errors

    content = """
    name: John
    age: -20
    """
    value, errors = validate_yaml(content, UserSchema)
    assert value == {"name": "John", "age": -20}

# Generated at 2022-06-18 12:51:14.432855
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "TestSchema"
        fields = [
            Field(name="name", type="string"),
            Field(name="age", type="integer"),
        ]

    # Test valid input
    value, errors = validate_yaml(
        content="""
        name: John
        age: 25
        """,
        validator=TestSchema,
    )
    assert value == {"name": "John", "age": 25}
    assert errors == []

    # Test invalid input
    value, errors = validate_yaml(
        content="""
        name: John
        age: 25
        """,
        validator=TestSchema(fields=[Field(name="name", type="string")]),
    )
    assert value == {"name": "John"}

# Generated at 2022-06-18 12:51:23.681734
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - a
    - b
    - c
    """
    validator = Field(type="array", items=Field(type="string"))
    value, errors = validate_yaml(content, validator)
    assert value == ["a", "b", "c"]
    assert errors == []

    content = """
    - a
    - b
    - c
    - d
    """
    validator = Field(type="array", items=Field(type="string"), max_items=3)
    value, errors = validate_yaml(content, validator)
    assert value == ["a", "b", "c", "d"]
    assert len(errors) == 1
    assert errors[0].text == "Must have no more than 3 items."
    assert errors[0].code == "max_items"
   

# Generated at 2022-06-18 12:51:30.349329
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 23
    """

    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John", "age": 23}
    assert error_messages == []

    content = """
    name: John
    age: twenty-three
    """

    value, error_messages = validate_yaml(content, PersonSchema)
    assert value is None

# Generated at 2022-06-18 12:51:40.762993
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = "name: John"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John\nage: 30"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == [
        Message(
            text="Additional properties are not allowed ('age' was unexpected).",
            code="additional_properties",
            position=Position(line_no=2, column_no=1, char_index=11),
        )
    ]


# Generated at 2022-06-18 12:51:53.319340
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 42
    """
    class Person(Schema):
        name = String()
        age = Integer()

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

    content = """
    name: "John Doe"
    age: "42"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": "42"}

# Generated at 2022-06-18 12:52:02.834859
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:52:11.152752
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """


# Generated at 2022-06-18 12:52:21.626906
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: "John"
      age: 25
    - name: "Jane"
      age: 26
    """
    validator = Schema(
        fields={
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == [
        {"name": "John", "age": 25},
        {"name": "Jane", "age": 26},
    ]
    assert error_messages == []

    content = """
    - name: "John"
      age: 25
    - name: "Jane"
      age: "26"
    """

# Generated at 2022-06-18 12:52:32.174135
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        friends = Array(items=String())

    content = """
    name: "John"
    age: 30
    friends:
      - "Jane"
      - "Joe"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 30,
        "friends": ["Jane", "Joe"],
    }
    assert error_messages == []

    content = """
    name: "John"
    age: 30
    friends:
      - "Jane"
      - "Joe"
    """

    value, error_messages = validate_

# Generated at 2022-06-18 12:52:41.920885
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array, Boolean
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String()
        age = Integer()
        friends = Array(String())
        is_active = Boolean()

    content = """
    name: John
    age: 30
    friends:
      - Mary
      - Jane
      - Bob
    is_active: true
    """

    value, error_messages = validate_yaml(content, TestSchema)
    assert value == {
        "name": "John",
        "age": 30,
        "friends": ["Mary", "Jane", "Bob"],
        "is_active": True,
    }
    assert error_messages == []


# Generated at 2022-06-18 12:52:54.122295
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean, Object, Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        friends = Array(items=String(max_length=100))
        alive = Boolean()

    class People(Schema):
        people = Array(items=Person)

    content = """
    people:
    - name: Alice
      age: 20
      friends:
      - Bob
      - Charlie
      alive: true
    - name: Bob
      age: 21
      friends:
      - Alice
      - Charlie
      alive: true
    - name: Charlie
      age: 22
      friends:
      - Alice
      - Bob
      alive: true
    """

    value, error_messages = validate_y

# Generated at 2022-06-18 12:53:04.888286
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a: 1") == {"a": 1}
    assert tokenize_yaml("- 1") == [1]
    assert tokenize_yaml("- 1\n- 2") == [1, 2]
    assert tokenize_yaml("- 1\n- 2\n") == [1, 2]

# Generated at 2022-06-18 12:53:17.368330
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(required=True)
        age = Integer(required=True)

    content = """
    name: "John"
    age: "30"
    """

    value, errors = validate_yaml(content, Person)
    assert errors[0].text == "Must be an integer."
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5

    content = """
    name: "John"
    """

    value, errors = validate_yaml(content, Person)
    assert errors[0].text == "This field is required."
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 1


# Generated at 2022-06-18 12:53:22.737662
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:53:38.573138
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String()
        age = Integer()
        height = Float()
        active = Boolean()
        friends = Array(items=String())

    content = """
    name: John
    age: 25
    height: 1.75
    active: true
    friends:
      - Alice
      - Bob
    """

    value, errors = validate_yaml(content, PersonSchema)
    assert value == {
        "name": "John",
        "age": 25,
        "height": 1.75,
        "active": True,
        "friends": ["Alice", "Bob"],
    }
    assert errors == []


# Generated at 2022-06-18 12:53:46.950250
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String()
        age = Integer()
        friends = Array(items=String())

    content = """
    name: John
    age: 30
    friends:
      - Mary
      - Jane
    """
    value, errors = validate_yaml(content, UserSchema)
    assert value == {
        "name": "John",
        "age": 30,
        "friends": ["Mary", "Jane"],
    }
    assert errors == []

    content = """
    name: John
    age: 30
    friends:
      - Mary
      - Jane
    """
    value, errors = validate_yaml(content, UserSchema)

# Generated at 2022-06-18 12:53:57.749042
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "invalid"
    """

    value, error_messages = validate_yaml(content, MySchema)

    assert value == {"name": "John", "age": "invalid"}
    assert len(error_messages) == 1
    assert isinstance(error_messages[0], ValidationError)
    assert error_messages[0].position.line_no == 3
    assert error_messages[0].position.column_no == 5
    assert error_messages[0].position.char_index == 26



# Generated at 2022-06-18 12:54:05.530081
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:54:17.178896
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()

    class Family(Schema):
        members = Array(items=Person)

    class Family2(Schema):
        members = Array(items=Person)

    class Family3(Schema):
        members = Array(items=Person)

    class Family4(Schema):
        members = Array(items=Person)

    class Family5(Schema):
        members = Array(items=Person)

    class Family6(Schema):
        members = Array(items=Person)

    class Family7(Schema):
        members = Array(items=Person)


# Generated at 2022-06-18 12:54:28.019544
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()

    content = """
    name: "John"
    age: 20
    height: 1.75
    is_cool: true
    """

    value, errors = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 20,
        "height": 1.75,
        "is_cool": True,
    }
    assert errors == []

    content = """
    name: "John"
    age: 20
    height: 1.75
    is_cool: true
    extra: "field"
    """



# Generated at 2022-06-18 12:54:38.855244
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: "John Doe"
    """

    value, errors = validate_yaml(content, validator=Person)
    assert value == {"name": "John Doe"}
    assert not errors

    content = """
    name: "John Doe"
    age: 42
    """

    value, errors = validate_yaml(content, validator=Person)
    assert value == {"name": "John Doe"}

# Generated at 2022-06-18 12:54:49.274149
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(items=String())

    class Family(Schema):
        father = Object(Person)
        mother = Object(Person)
        children = Array(items=Object(Person))


# Generated at 2022-06-18 12:54:59.501872
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Boolean, Float

    class Person(Schema):
        name = String()
        age = Integer()
        is_active = Boolean()
        height = Float()

    content = """
    name: John Doe
    age: 42
    is_active: true
    height: 1.75
    """

    value, error_messages = validate_yaml(content, Person)

    assert value == {
        "name": "John Doe",
        "age": 42,
        "is_active": True,
        "height": 1.75,
    }
    assert error_messages == []


# Generated at 2022-06-18 12:55:11.453220
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John Doe
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must have no more than 10 characters.",
            code="max_length",
            position=Position(line_no=2, column_no=7, char_index=13),
        )
    ]
