

# Generated at 2022-06-18 12:45:19.938154
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(String())
        family = Array(Object(Person))


# Generated at 2022-06-18 12:45:24.143597
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("{a: 1}") == {"a": 1}
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_yaml("{a: 1, b: 2}") == {"a": 1, "b": 2}
    assert tokenize_yaml("[1, 2, 3, 4]") == [1, 2, 3, 4]

# Generated at 2022-06-18 12:45:28.674003
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = Field(type="array", items=Field(type="integer"))
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == []



# Generated at 2022-06-18 12:45:40.235205
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")


# Generated at 2022-06-18 12:45:47.586901
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:45:53.915606
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo: bar
    baz:
      - qux
      - quux
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar", "baz": ["qux", "quux"]}
    assert token.start == 1
    assert token.end == len(content) - 1
    assert token.content == content



# Generated at 2022-06-18 12:46:04.292934
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    assert tokenize_yaml("[1, 2]") == ListToken([1, 2], 0, 5, content="[1, 2]")
    assert tokenize_yaml("{a: 1}") == D

# Generated at 2022-06-18 12:46:16.477678
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == Scal

# Generated at 2022-06-18 12:46:27.957575
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:46:35.613537
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    - name: John
      age: 25
    - name: Jane
      age: 30
    """)
    assert token.start == 0
    assert token.end == 52
    assert token.value == [
        {"name": "John", "age": 25},
        {"name": "Jane", "age": 30},
    ]
    assert token.content == """
    - name: John
      age: 25
    - name: Jane
      age: 30
    """



# Generated at 2022-06-18 12:46:49.384038
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test valid input
    content = """
    foo: bar
    """
    validator = Field(type="string")
    value, error_messages = validate_yaml(content, validator)
    assert value == "bar"
    assert error_messages == []

    # Test invalid input
    content = """
    foo: 123
    """
    validator = Field(type="string")
    value, error_messages = validate_yaml(content, validator)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="type_error.string",
            position=Position(line_no=2, column_no=6, char_index=8),
        )
    ]

    # Test invalid input with multiple errors

# Generated at 2022-06-18 12:47:00.773112
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem
    import yaml

    class Person(typesystem.Schema):
        name = typesystem.String(max_length=100)
        age = typesystem.Integer(minimum=0, maximum=150)

    content = """
    name: John Smith
    age: 25
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Smith", "age": 25}
    assert errors == []

    content = """
    name: John Smith
    age: -25
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Smith", "age": -25}

# Generated at 2022-06-18 12:47:10.875350
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    name: John Doe
    age: 43
    children:
      - Mary
      - Peter
      - Paul
    '''
    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        children = Field(type="array", items=Field(type="string"))

    value, errors = validate_yaml(content, PersonSchema)
    assert value == {
        "name": "John Doe",
        "age": 43,
        "children": ["Mary", "Peter", "Paul"],
    }
    assert errors == []

    content = '''
    name: John Doe
    age: 43
    children:
      - Mary
      - Peter
      - Paul
    '''

# Generated at 2022-06-18 12:47:18.936099
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    foo:
      bar:
        - 1
        - 2
        - 3
    '''
    validator = Schema(
        fields={
            "foo": Field(
                fields={
                    "bar": Field(
                        fields={
                            "0": Field(type="integer"),
                            "1": Field(type="integer"),
                            "2": Field(type="integer"),
                        }
                    )
                }
            )
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {
        "foo": {
            "bar": [
                1,
                2,
                3,
            ]
        }
    }
    assert error_messages == []



# Generated at 2022-06-18 12:47:29.620152
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    class Person(Schema):
        name = String()
        age = Integer()

    class People(Schema):
        people = Array(items=Person)

    # Test a valid YAML string.
    yaml_string = """
        people:
          - name: John
            age: 25
          - name: Jane
            age: 26
    """
    token = tokenize_yaml(yaml_string)
    assert isinstance(token, DictToken)

# Generated at 2022-06-18 12:47:37.326159
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Value must be a string.",
            code="invalid",
            position=Position(line_no=2, column_no=7, char_index=10),
        )
    ]

    content = """
    name: "John"
    age: thirty
    """

    value, errors = validate

# Generated at 2022-06-18 12:47:49.064765
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = "name: John"

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John\nage: 30"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = "name: John\nage: 30\n"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

   

# Generated at 2022-06-18 12:47:59.087405
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()

    content = """
    name: John
    age: 20
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert errors == []

    content = """
    name: John
    age: twenty
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5

    content = """
    name: John
    age: 20
    """

    value, errors = validate_yaml

# Generated at 2022-06-18 12:48:07.848023
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()

    class Family(Schema):
        members = Array(items=Person())

    class Family2(Schema):
        members = Array(items=Person())
        is_active = Boolean()

    class Family3(Schema):
        members = Array(items=Person())
        is_active = Boolean()
        name = String()

    class Family4(Schema):
        members = Array(items=Person())
        is_active = Boolean()
        name = String()
        age = Integer()


# Generated at 2022-06-18 12:48:19.318819
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []


# Generated at 2022-06-18 12:48:34.164886
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test for a valid YAML string
    content = """
    - name: John
      age: 30
      city: New York
    - name: Jane
      age: 20
      city: San Francisco
    """
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)
    assert len(token) == 2
    assert isinstance(token[0], DictToken)
    assert isinstance(token[1], DictToken)
    assert token[0]["name"] == "John"
    assert token[0]["age"] == 30
    assert token[0]["city"] == "New York"
    assert token[1]["name"] == "Jane"
    assert token[1]["age"] == 20
    assert token[1]["city"] == "San Francisco"

    # Test for

# Generated at 2022-06-18 12:48:44.813577
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "20"
    """
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": 20}
    assert error_messages == []

    content = """
    name: John
    age: "twenty"
    """
    value, error_messages = validate_yaml(content, MySchema)
    assert value is None

# Generated at 2022-06-18 12:48:55.081368
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    # Valid case
    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    # Invalid case
    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    # Invalid case
    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:49:07.387786
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: John
    age: 20
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert error_messages == []

    content = """
    name: John
    age: twenty
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Value must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=14),
        )
    ]


# Generated at 2022-06-18 12:49:14.081434
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: "John Doe"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: "John Doe"
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}

# Generated at 2022-06-18 12:49:25.235151
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()

    content = """
    name: John
    age: 25
    height: 1.8
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25, "height": 1.8}
    assert errors == []

    content = """
    name: John
    age: 25
    height: 1.8
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:49:30.377045
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test a valid YAML string
    content = "name: John Doe"
    validator = Schema({"name": str})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe"}
    assert not error_messages

    # Test an invalid YAML string
    content = "name: John Doe\nage: twenty-one"
    validator = Schema({"name": str})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe"}
    assert len(error_messages) == 1
    assert error_messages[0].text == "Field 'age' is not defined."
    assert error_messages[0].code == "field_not_defined"
    assert error_

# Generated at 2022-06-18 12:49:42.309916
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 25
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_mess

# Generated at 2022-06-18 12:49:53.019112
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()

    content = """
    name: John
    age: 30
    height: 1.75
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30, "height": 1.75}
    assert errors == []

    content = """
    name: John
    age: 30
    height: 1.75
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30, "height": 1.75}
    assert errors == []

    content = """
    name: John
    age: 30
    height: 1.75
    """

# Generated at 2022-06-18 12:50:05.262352
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: -1
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        ValidationError(
            text="Must be greater than or equal to 0.",
            code="minimum",
            position=Position(line_no=3, column_no=5, char_index=18),
        )
    ]


# Generated at 2022-06-18 12:50:15.809887
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    age: 20
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}

# Generated at 2022-06-18 12:50:25.851662
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("'string'") == "string"
    assert tokenize_yaml("'string'") == "string"
    assert tokenize_yaml("'string'") == "string"
    assert tokenize_yaml("'string'") == "string"
    assert tokenize_yaml("'string'") == "string"
    assert tokenize_y

# Generated at 2022-06-18 12:50:35.664907
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("{a: 1}") == {'a': 1}
    assert tokenize_yaml("[1]") == [1]
    assert tokenize_yaml("{a: {b: 1}}") == {'a': {'b': 1}}
    assert tokenize_yaml("{a: [1]}") == {'a': [1]}

# Generated at 2022-06-18 12:50:46.792869
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(max_length=10)

    value, errors = validate_yaml(
        content="""
        name: "Hello, World!"
        """,
        validator=MySchema,
    )
    assert value == {"name": "Hello, World!"}
    assert errors == [
        Message(
            text="String is too long.",
            code="max_length",
            position=Position(
                line_no=2, column_no=7, char_index=17,
            ),
        )
    ]


# Generated at 2022-06-18 12:50:56.924577
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=100)

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, UserSchema)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: -30
    """
    value, error_messages = validate_yaml(content, UserSchema)
    assert value == {"name": "John", "age": -30}

# Generated at 2022-06-18 12:51:06.983196
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Dict
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0)
        alive = Boolean()
        friends = Array(items=String())
        family = Dict(properties={"mother": String(), "father": String()})

    content = """
    name: John
    age: 25
    height: 1.8
    alive: true
    friends:
    - Alice
    - Bob
    family:
        mother: Jane
        father: Jack
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:51:16.429693
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: "John"
    age: "30"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert error_messages == []

    content = """
    name: "John"
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None

# Generated at 2022-06-18 12:51:25.437496
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name:
      first: John
      last: Smith
    """

    value, errors = validate_yaml(content, Person)
    assert errors == [
        Message(
            text="'last' is a required field.",
            code="required",
            position=Position(line_no=3, column_no=2, char_index=16),
        )
    ]

    content = """
    name:
      first: John
      last: Smith
      middle:
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:51:33.869667
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: thirty
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        ValidationError(
            text="Must be a valid integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=20),
        )
    ]


# Generated at 2022-06-18 12:51:44.050687
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0)
        is_cool = Boolean()
        friends = Array(items=String())

    class PersonSchema(Schema):
        person = Object(Person)

    content = """
    person:
        name: John
        age: 30
        height: 1.75
        is_cool: true
        friends:
            - Jane
            - Bob
    """
    value, error_messages = validate_yaml(content, PersonSchema)

# Generated at 2022-06-18 12:51:57.208332
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("{a: 1}") == {"a": 1}
    assert tokenize_yaml("[1]") == [1]
    assert tokenize_yaml("{a: {b: 1}}") == {"a": {"b": 1}}
    assert tokenize_yaml("{a: [1]}") == {"a": [1]}
    assert token

# Generated at 2022-06-18 12:52:06.796657
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class MySchema(Schema):
        name = String()

    content = "name: 'foo'"
    token = tokenize_yaml(content)
    assert validate_with_positions(token=token, validator=MySchema) == (
        {"name": "foo"},
        [],
    )

    content = "name: 'foo'\nname: 'bar'"
    token = tokenize_yaml(content)

# Generated at 2022-06-18 12:52:15.124635
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean

    class Person(Schema):
        name = String()
        age = Integer()
        children = Array(items=String())
        is_active = Boolean()

    content = """
    name: John
    age: 42
    children:
      - Alice
      - Bob
    is_active: true
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 42,
        "children": ["Alice", "Bob"],
        "is_active": True,
    }
    assert error_messages == []


# Generated at 2022-06-18 12:52:26.302648
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "30"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: "thirty"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}

# Generated at 2022-06-18 12:52:37.301801
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("'foo'") == "foo"
    assert tokenize_yaml('"foo"') == "foo"

# Generated at 2022-06-18 12:52:43.569934
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test that valid YAML is parsed and validated correctly.
    content = """
    foo: bar
    baz:
      - qux
      - quux
    """
    schema = Schema(
        {
            "foo": str,
            "baz": [str],
        }
    )
    value, error_messages = validate_yaml(content, schema)
    assert value == {"foo": "bar", "baz": ["qux", "quux"]}
    assert not error_messages

    # Test that invalid YAML is parsed and validated correctly.
    content = """
    foo: bar
    baz:
      - qux
      - quux
    """
    schema = Schema(
        {
            "foo": str,
            "baz": [int],
        }
    )

# Generated at 2022-06-18 12:52:48.707482
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - foo: bar
    - foo: baz
    """
    validator = Schema({"foo": str})
    value, error_messages = validate_yaml(content, validator)
    assert value == [{"foo": "bar"}, {"foo": "baz"}]
    assert error_messages == []



# Generated at 2022-06-18 12:52:59.770566
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        friends = Array(items=String())
        alive = Boolean()

    content = """
    name: Bob
    age: 42
    friends:
      - Alice
      - Eve
    alive: true
    """
    value, errors = validate_yaml(content, Person)
    assert value == {
        "name": "Bob",
        "age": 42,
        "friends": ["Alice", "Eve"],
        "alive": True,
    }
    assert errors == []


# Generated at 2022-06-18 12:53:11.782579
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 42
    """
    validator = Schema(
        {"name": str, "age": int}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

    content = """
    name: "John Doe"
    age: "42"
    """
    validator = Schema(
        {"name": str, "age": int}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": "42"}

# Generated at 2022-06-18 12:53:22.232550
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    class Person(Schema):
        name = String()
        age = Integer()

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    class Person(Schema):
        name = String()
        age = Integer()

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    class Person(Schema):
        name = String()
        age = Integer()


# Generated at 2022-06-18 12:53:37.350758
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: "John"
    age: "30"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert errors == []

    content = """
    name: "John"
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert errors == []

    content = """
    name: "John"
    age: 30
    """
    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:53:45.989474
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0)
        is_active = Boolean()
        friends = Array(items=String(max_length=100))
        address = Object(properties={"city": String(max_length=100)})

    content = """
    name: John Doe
    age: 30
    height: 1.75
    is_active: true
    friends:
      - Jane Doe
      - Joe Bloggs
    address:
      city: London
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:53:57.166234
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "25"
    """
    value, errors = validate_yaml(content, Person)
    assert errors == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=20),
        )
    ]

    content = """
    name: "John"
    """
    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:54:05.132548
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = "name: John"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John Doe"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must have no more than 10 characters."
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 6
    assert error_

# Generated at 2022-06-18 12:54:16.768229
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "30"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: "thirty"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}

# Generated at 2022-06-18 12:54:27.655566
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    - 1
    - 2
    - 3
    '''
    validator = Field(type="array", items=Field(type="integer"))
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == []

    content = '''
    - 1
    - 2
    - 3.0
    '''
    validator = Field(type="array", items=Field(type="integer"))
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3.0]

# Generated at 2022-06-18 12:54:38.285493
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(max_length=10)

    content = "name: 'John Doe'"
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = "name: 'John Doe is a very long name'"
    value, error_messages = validate_yaml(content, MySchema)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must have no more than 10 characters."
    assert error_messages[0].code == "max_length"
    assert error_messages[0].position.line

# Generated at 2022-06-18 12:54:43.860116
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []



# Generated at 2022-06-18 12:54:49.170401
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 42
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []



# Generated at 2022-06-18 12:54:57.262392
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        is_active = Field(type="boolean")

    yaml_string = """
    name: John
    age: 20
    is_active: true
    """

    value, error_messages = validate_yaml(yaml_string, TestSchema)

    assert value == {"name": "John", "age": 20, "is_active": True}
    assert error_messages == []



# Generated at 2022-06-18 12:55:12.288447
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: "John"
    age: "30"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}