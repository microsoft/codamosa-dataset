

# Generated at 2022-06-18 12:45:26.229993
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("a: 1") == {'a': 1}
    assert tokenize_yaml("a: 1\nb: 2") == {'a': 1, 'b': 2}
    assert tokenize_yaml("a: 1\nb: 2\n") == {'a': 1, 'b': 2}
    assert tokenize_yaml("a: 1\nb: 2\n\n") == {'a': 1, 'b': 2}
    assert tokenize_yaml("a: 1\n\nb: 2") == {'a': 1, 'b': 2}
    assert tokenize_yaml("a: 1\n\nb: 2\n") == {'a': 1, 'b': 2}

# Generated at 2022-06-18 12:45:37.651207
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")
    assert tokenize_yaml("foo") == Scal

# Generated at 2022-06-18 12:45:46.050767
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")
    assert tokenize_yaml("foo") == Scal

# Generated at 2022-06-18 12:45:56.781934
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = "name: John"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = "name: John\nage: 30"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == [
        ValidationError(
            text="Additional properties are not allowed ('age' was unexpected).",
            code="additional_properties",
            position=Position(line_no=2, column_no=1, char_index=8),
        )
    ]

    content = "name: John\nage: 30"
    value

# Generated at 2022-06-18 12:46:06.194774
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test that tokenize_yaml returns a DictToken when given a YAML string
    # with a single key-value pair.
    assert isinstance(tokenize_yaml("foo: bar"), DictToken)

    # Test that tokenize_yaml returns a ListToken when given a YAML string
    # with a single list.
    assert isinstance(tokenize_yaml("- foo"), ListToken)

    # Test that tokenize_yaml returns a ScalarToken when given a YAML string
    # with a single scalar.
    assert isinstance(tokenize_yaml("foo"), ScalarToken)

    # Test that tokenize_yaml raises a ParseError when given an empty string.
    with pytest.raises(ParseError):
        tokenize_yaml("")

    # Test that tokenize_

# Generated at 2022-06-18 12:46:18.639851
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:46:29.698609
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.1") == ScalarToken(1.1, 0, 2, content="1.1")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:46:40.327270
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("a: b") == {'a': 'b'}
    assert tokenize_yaml("a: b\nc: d") == {'a': 'b', 'c': 'd'}
    assert tokenize_yaml("a: b\nc: d\n") == {'a': 'b', 'c': 'd'}
    assert tokenize_yaml("a: b\nc: d\n\n") == {'a': 'b', 'c': 'd'}
    assert tokenize_yaml("a: b\nc: d\n\n\n") == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-18 12:46:50.673264
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        alive = Boolean()

    content = """
    name: John Doe
    age: 42
    height: 1.83
    alive: true
    """

    value, error_messages = validate_yaml(content, Person)

    assert value == {
        "name": "John Doe",
        "age": 42,
        "height": 1.83,
        "alive": True,
    }
    assert error_messages == []


# Generated at 2022-06-18 12:47:02.404037
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:47:16.309335
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()

    content = """
    name: John
    age: 20
    height: 1.80
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20, "height": 1.8}
    assert error_messages == []

    content = """
    name: John
    age: 20
    height: 1.80
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20, "height": 1.8}

# Generated at 2022-06-18 12:47:27.988773
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    age: 20
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}

# Generated at 2022-06-18 12:47:37.558674
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        friends = Array(items=String())
        is_cool = Boolean()

    content = """
    name: "John"
    age: 42
    friends:
      - "Jane"
      - "Joe"
      - "Jill"
    is_cool: true
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 42,
        "friends": ["Jane", "Joe", "Jill"],
        "is_cool": True,
    }
    assert error_messages == []


# Generated at 2022-06-18 12:47:49.275681
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []


# Generated at 2022-06-18 12:47:59.293911
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: "John Doe"
    age: "30"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert errors == []

    content = """
    name: "John Doe"
    age: "thirty"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": "thirty"}

# Generated at 2022-06-18 12:48:08.082660
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="type_error.string",
            position=Position(line_no=2, column_no=7, char_index=12),
        )
    ]

    content = """
    name: 123
    """

# Generated at 2022-06-18 12:48:19.398782
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String()

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, UserSchema)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, UserSchema)
    assert value == {"name": "John"}

# Generated at 2022-06-18 12:48:23.238529
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []


# Generated at 2022-06-18 12:48:34.203671
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: John
      age: 20
    - name: Jane
      age: 30
    """
    validator = Schema(
        fields={
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == [
        {"name": "John", "age": 20},
        {"name": "Jane", "age": 30},
    ]
    assert error_messages == []

    content = """
    - name: John
      age: 20
    - name: Jane
      age: 30
    - name: Bob
      age: "thirty"
    """

# Generated at 2022-06-18 12:48:44.855215
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert not errors

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert not errors

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert not errors


# Generated at 2022-06-18 12:48:57.783271
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean, Schema
    from typesystem.fields import Field
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)
        children = Array(items=String(max_length=100))
        is_active = Boolean()

    class PersonField(Field):
        def validate(self, value):
            if value["age"] < 18:
                raise ValidationError("Must be 18 or older.")
            return value

    content = """
    name: John Doe
    age: 30
    children:
        - Jane
        - Joe
    is_active: true
    """
    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:49:09.705773
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Boolean, Array, Object, Schema

    class TestSchema(Schema):
        name = String()
        age = Integer()
        is_active = Boolean()
        friends = Array(items=String())
        address = Object(properties={"city": String(), "state": String()})

    content = """
    name: John
    age: 30
    is_active: true
    friends:
      - Mary
      - Jane
    address:
      city: New York
      state: NY
    """

    value, errors = validate_yaml(content, TestSchema)

# Generated at 2022-06-18 12:49:21.076098
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: bar
    """
    value, error_messages = validate_yaml(content, validator=Schema)
    assert error_messages == []
    assert value == {"foo": "bar"}

    content = """
    foo: bar
    baz:
    """
    value, error_messages = validate_yaml(content, validator=Schema)
    assert error_messages == [
        Message(
            text="This field is required.",
            code="required",
            position=Position(
                line_no=3, column_no=5, char_index=len(content.split("\n")[0]) + 1
            ),
        )
    ]

    content = """
    foo: bar
    baz:
    """
    value, error_messages = validate_y

# Generated at 2022-06-18 12:49:30.373071
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    - 1
    - 2
    - 3
    '''
    validator = Field(type="integer", min_value=0)
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == []

    content = '''
    - 1
    - 2
    - 3
    '''
    validator = Field(type="integer", min_value=2)
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]

# Generated at 2022-06-18 12:49:42.310153
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()

    class Family(Schema):
        members = Array(items=Person)

    class Company(Schema):
        name = String()
        employees = Array(items=Person)

    class CompanyFamily(Schema):
        company = Object(Company)
        family = Object(Family)


# Generated at 2022-06-18 12:49:53.018143
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken, ScalarToken

    class TestSchema(Schema):
        name = String()

    token = DictToken({"name": ScalarToken("test")}, 0, 0, content="")
    value, errors = validate_with_positions(token=token, validator=TestSchema)
    assert value == {"name": "test"}
    assert errors == []

    value, errors = validate_yaml(content="name: test", validator=TestSchema)
    assert value == {"name": "test"}
    assert errors == []

    value, errors = validate_yaml(content="name: test", validator=String())
    assert value == "test"
    assert errors == []

# Generated at 2022-06-18 12:50:05.264538
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John"
    age: 30
    """
    validator = Schema({"name": str, "age": int})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: "John"
    age: "30"
    """
    validator = Schema({"name": str, "age": int})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": "30"}

# Generated at 2022-06-18 12:50:09.631749
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("{a: 1}") == {"a": 1}
    assert tokenize_yaml("[1, 2]") == [1, 2]
    assert tokenize_yaml("{a: 1, b: 2}") == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:50:18.556450
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(items=Object(Person))

    content = """
    name: John Doe
    age: 42
    height: 1.85
    is_adult: true
    children:
      - name: Jane Doe
        age: 12
        height: 1.50
        is_adult: false
        children: []
      - name: Bob Doe
        age: 10
        height: 1.40
        is_adult: false
        children: []
    """

    value, error_messages = validate_yaml(content, Person)


# Generated at 2022-06-18 12:50:28.384640
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("foo: bar") == DictToken({"foo": "bar"}, 0, 9, content="foo: bar")
    assert tokenize_yaml("foo: bar\n") == DictToken({"foo": "bar"}, 0, 10, content="foo: bar\n")
    assert tokenize_yaml("foo: bar\n\n") == DictToken({"foo": "bar"}, 0, 11, content="foo: bar\n\n")
    assert tokenize_yaml("foo: bar\n\n\n") == DictToken({"foo": "bar"}, 0, 12, content="foo: bar\n\n\n")

# Generated at 2022-06-18 12:50:41.003182
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = "name: John Doe\nage: 42"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

    content = "name: John Doe\nage: forty-two"
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=2, column_no=5, char_index=15),
        )
    ]

    content = "name: John Doe\nage: forty-two"
   

# Generated at 2022-06-18 12:50:52.318428
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    class Family(Schema):
        members = Array(items=Person)

    content = """
    members:
      - name: John
        age: 30
      - name: Jane
        age: 28
    """
    value, error_messages = validate_yaml(content, Family)
    assert value == {"members": [{"name": "John", "age": 30}, {"name": "Jane", "age": 28}]}
    assert error_messages == []


# Generated at 2022-06-18 12:51:02.312929
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0, maximum=3.0)
        is_human = Boolean()

    content = """
    name: "John"
    age: 30
    height: 1.8
    is_human: true
    """

    value, error_messages = validate_yaml(content, Person)

    assert value == {
        "name": "John",
        "age": 30,
        "height": 1.8,
        "is_human": True,
    }

    assert error_messages == []


# Generated at 2022-06-18 12:51:12.283617
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:51:21.367574
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    class People(Schema):
        people = Array(items=Person)

    content = """
    people:
      - name: Bob
        age: 20
      - name: Alice
        age: 30
      - name: Charlie
        age: 40
    """

    value, errors = validate_yaml(content, People)
    assert value == {
        "people": [
            {"name": "Bob", "age": 20},
            {"name": "Alice", "age": 30},
            {"name": "Charlie", "age": 40},
        ]
    }
    assert errors == []

# Generated at 2022-06-18 12:51:29.149983
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()

    content = """
    name: John
    age: 30
    height: 1.75
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30, "height": 1.75}
    assert not errors

    content = """
    name: John
    age: 30
    height: 1.75
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30, "height": 1.75}
    assert not errors


# Generated at 2022-06-18 12:51:39.510223
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: "John"
      age: 30
    - name: "Jane"
      age: 25
    """
    validator = Schema(
        fields=[
            Field(name="name", type="string"),
            Field(name="age", type="integer"),
        ]
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == [
        {"name": "John", "age": 30},
        {"name": "Jane", "age": 25},
    ]
    assert error_messages == []

    content = """
    - name: "John"
      age: 30
    - name: "Jane"
      age: "25"
    """

# Generated at 2022-06-18 12:51:49.196842
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(str),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value is None

# Generated at 2022-06-18 12:51:58.578117
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """


# Generated at 2022-06-18 12:52:07.982605
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test empty string
    with pytest.raises(ParseError):
        tokenize_yaml("")

    # Test invalid YAML
    with pytest.raises(ParseError):
        tokenize_yaml("{'a': 1")

    # Test valid YAML
    token = tokenize_yaml("{'a': 1}")
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1}

    # Test valid YAML with a list
    token = tokenize_yaml("[1, 2, 3]")
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3]

    # Test valid YAML with a string
    token = tokenize_yaml("'a'")

# Generated at 2022-06-18 12:52:21.032524
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0, maximum=3.0)
        is_active = Boolean()

    class Family(Schema):
        members = Array(items=Person)

    class Family2(Schema):
        members = Array(items=Person)

    class Family3(Schema):
        members = Array(items=Person)

    class Family4(Schema):
        members = Array(items=Person)


# Generated at 2022-06-18 12:52:31.548895
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:52:41.482461
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: -30
    """
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John", "age": -30}

# Generated at 2022-06-18 12:52:53.643932
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 20
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert error_messages == []

    content = """
    name: John
    age: "20"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "20"}

# Generated at 2022-06-18 12:53:03.827397
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: 'John'
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 'John'
    age: '25'
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "25"}

# Generated at 2022-06-18 12:53:16.298756
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: -30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": -30}

# Generated at 2022-06-18 12:53:20.534017
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    b: 2
    """
    validator = Schema({"a": int, "b": int})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"a": 1, "b": 2}
    assert error_messages == []



# Generated at 2022-06-18 12:53:29.965121
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: "John"
    age: 20
    """
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John"}

# Generated at 2022-06-18 12:53:41.602053
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    content = "name: John Doe\nage: 25"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 25}
    assert not errors

    content = "name: John Doe\nage: 25\n"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 25}
    assert not errors

    content = "name: John Doe\nage: twenty-five"
    value, errors = validate

# Generated at 2022-06-18 12:53:50.237508
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = "name: John"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = "name: John\nage: 30"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == [
        ValidationError(
            text="'age' is not a valid field.",
            code="invalid_field",
            position=Position(line_no=2, column_no=1, char_index=10),
        )
    ]

    content = "name: John\nage: 30"

# Generated at 2022-06-18 12:54:02.552495
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String()

    content = """
    name: "test"
    """

    value, errors = validate_yaml(content, TestSchema)
    assert value == {"name": "test"}
    assert errors == []

    content = """
    name: 123
    """

    value, errors = validate_yaml(content, TestSchema)
    assert value is None
    assert errors == [
        ValidationError(
            text="Must be a string.",
            code="invalid_type",
            position=Position(line_no=2, column_no=7, char_index=7),
        )
    ]



# Generated at 2022-06-18 12:54:11.011767
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """

    value, error_messages = validate_yaml(content, Person)
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="type_error.integer",
            position=Position(line_no=3, column_no=5, char_index=17),
        )
    ]

# Generated at 2022-06-18 12:54:16.148886
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": str,
            "age": int,
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:54:26.978966
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Boolean, Array, Object

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        is_active = Boolean()

    class People(Schema):
        people = Array(items=Person)

    content = """
    people:
    - name: John
      age: 30
      is_active: true
    - name: Jane
      age: 25
      is_active: false
    """

    value, error_messages = validate_yaml(content, People)
    assert error_messages == []

# Generated at 2022-06-18 12:54:37.004562
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(String())

    class Family(Schema):
        parents = Array(Object(Person))
        children = Array(Object(Person))


# Generated at 2022-06-18 12:54:48.417124
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:54:58.585797
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String()

    content = """
    name: John
    """

    value, errors = validate_yaml(content, validator=PersonSchema)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, validator=PersonSchema)
    assert value == {"name": "John"}

# Generated at 2022-06-18 12:55:10.082125
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Dict
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0, maximum=3.0)
        is_active = Boolean()
        friends = Array(items=String())
        preferences = Dict(properties={"food": String(), "drink": String()})

    content = """
    name: John Doe
    age: 30
    height: 1.83
    is_active: true
    friends:
    - Alice
    - Bob
    preferences:
      food: pizza
      drink: beer
    """

    value, error_messages = validate_yaml(content, Person)