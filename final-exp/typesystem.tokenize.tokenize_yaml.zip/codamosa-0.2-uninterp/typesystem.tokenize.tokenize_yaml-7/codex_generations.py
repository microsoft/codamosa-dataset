

# Generated at 2022-06-18 12:45:25.605750
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    name: "John"
    age: "30"
    '''
    class Person(Schema):
        name = String()
        age = Integer()

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []



# Generated at 2022-06-18 12:45:37.082469
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}
    assert tokenize_yaml("- foo") == ["foo"]
    assert tokenize_yaml("- foo\n- bar") == ["foo", "bar"]

# Generated at 2022-06-18 12:45:45.616960
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("", validator=Field(type="string")) == (None, [])
    assert validate_yaml("foo", validator=Field(type="string")) == ("foo", [])
    assert validate_yaml("foo", validator=Field(type="integer")) == (None, [])
    assert validate_yaml("foo", validator=Field(type="integer")) == (None, [])
    assert validate_yaml("1", validator=Field(type="integer")) == (1, [])
    assert validate_yaml("1", validator=Field(type="string")) == ("1", [])
    assert validate_yaml("1", validator=Field(type="number")) == (1.0, [])

# Generated at 2022-06-18 12:45:56.031915
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean

    class Person(Schema):
        name = String()
        age = Integer()
        children = Array(items=String())
        is_awesome = Boolean()

    content = """
    name: "John Doe"
    age: 42
    children:
      - "Jane"
      - "Joe"
    is_awesome: true
    """

    value, errors = validate_yaml(content, Person)
    assert value == {
        "name": "John Doe",
        "age": 42,
        "children": ["Jane", "Joe"],
        "is_awesome": True,
    }
    assert errors == []


# Generated at 2022-06-18 12:46:01.062032
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    name: "John Doe"
    age: 42
    '''
    class PersonSchema(Schema):
        name = String()
        age = Integer()
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {'name': 'John Doe', 'age': 42}
    assert error_messages == []

# Generated at 2022-06-18 12:46:11.582476
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:46:24.032722
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:46:34.782274
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        is_active = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class PeopleObject(Schema):
        people = Object(properties={"person": Person()})

    class PeopleObject2(Schema):
        people = Object(properties={"person": Person()}, additional_properties=False)

    class PeopleObject3(Schema):
        people = Object(properties={"person": Person()}, additional_properties=True)

    class PeopleObject4(Schema):
        people = Object(properties={"person": Person()}, additional_properties=String())


# Generated at 2022-06-18 12:46:43.691716
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(max_length=10)

    content = """
    name: "John Doe"
    """
    value, errors = validate_yaml(content, validator=UserSchema)
    assert value == {"name": "John Doe"}
    assert not errors

    content = """
    name: "John Doe"
    """
    value, errors = validate_yaml(content, validator=UserSchema)
    assert value == {"name": "John Doe"}
    assert not errors

    content = """
    name: "John Doe"
    """
    value, errors = validate_yaml(content, validator=UserSchema)
    assert value == {"name": "John Doe"}

# Generated at 2022-06-18 12:46:54.759923
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:47:12.699013
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test for valid YAML
    content = """
    name: John Doe
    age: 43
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {'name': 'John Doe', 'age': 43}
    assert error_messages == []

    # Test for invalid YAML
    content = """
    name: John Doe
    age: 43
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
            "height": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)

# Generated at 2022-06-18 12:47:20.060858
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("- foo") == ["foo"]
    assert tokenize_yaml("- foo\n- bar") == ["foo", "bar"]
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}

# Generated at 2022-06-18 12:47:30.723714
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("{a: 1}") == {"a": 1}
    assert tokenize_yaml("[1, 2]") == [1, 2]
    assert tokenize_yaml("{a: 1, b: 2}") == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:47:37.978526
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String()

    content = """
    name: John
    """

    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    age: 20
    """

    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John"}

# Generated at 2022-06-18 12:47:42.078346
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - a: 1
    - b: 2
    """
    validator = Schema(fields={"a": int, "b": int})
    value, errors = validate_yaml(content, validator)
    assert value == [{"a": 1}, {"b": 2}]
    assert errors == []



# Generated at 2022-06-18 12:47:53.683027
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name": "John", "age": 30}
    assert not errors

    content = """
    name: John
    age: -30
    """

    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name": "John", "age": -30}

# Generated at 2022-06-18 12:48:03.517165
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: bar
    baz:
        - 1
        - 2
        - 3
    """
    validator = Schema(
        {
            "foo": Field(str),
            "baz": Field(list, items=Field(int)),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"foo": "bar", "baz": [1, 2, 3]}
    assert error_messages == []

    content = """
    foo: bar
    baz:
        - 1
        - 2
        - 3
    """
    validator = Schema(
        {
            "foo": Field(str),
            "baz": Field(list, items=Field(int)),
        }
    )
    value, error_

# Generated at 2022-06-18 12:48:15.017408
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:48:19.492778
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert errors == []

    content = """
    name: John Doe
    age: -1
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": -1}
    assert len(errors) == 1
    assert errors[0].code == "minimum"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 4


# Generated at 2022-06-18 12:48:22.373713
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)
        age = String()

    content = """
    name: John
    age:
    """

    value, errors = validate_yaml(content, Person)
    assert errors == [
        Message(
            text="This field is required.",
            code="required",
            position=Position(
                line_no=3, column_no=1, char_index=content.index("age")
            ),
        )
    ]

# Generated at 2022-06-18 12:48:36.791770
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()
        height = Float()
        is_active = Boolean()

    content = """
    name: John
    age: 30
    height: 1.8
    is_active: true
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 30,
        "height": 1.8,
        "is_active": True,
    }
    assert error_messages == []

    content = """
    name: John
    age: 30
    height: 1.8
    is_active: true
    """

    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:48:48.109987
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(String())
        family = Object({"mother": String(), "father": String()})

    content = """
    name: "John"
    age: 30
    height: 1.75
    is_cool: true
    friends:
        - "Jane"
        - "Bob"
    family:
        mother: "Mary"
        father: "John"
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:48:57.993446
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_human = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class PeopleObject(Schema):
        people = Object(properties={"name": String(), "age": Integer()})

    def test_validate_yaml_with_schema(
        content: typing.Union[str, bytes],
        validator: typing.Union[Field, typing.Type[Schema]],
        expected_value: typing.Any,
        expected_error_messages: typing.List[Message],
    ) -> None:
        value, error_messages = validate_yaml(content, validator)
        assert value

# Generated at 2022-06-18 12:49:09.937312
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=150)

    class Pet(Schema):
        name = String()
        age = Integer(minimum=0, maximum=30)

    class Family(Schema):
        parents = Array(items=Object(Person))
        children = Array(items=Object(Person))
        pets = Array(items=Object(Pet))


# Generated at 2022-06-18 12:49:21.353440
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 25
    """
    validator = Schema(
        {"name": str, "age": int}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """
    validator = Schema(
        {"name": str, "age": int}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """

# Generated at 2022-06-18 12:49:30.485863
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String

    content = """
    name: John
    age: 20
    """
    value, error_messages = validate_yaml(content, String())
    assert value == "John"
    assert error_messages == []

    content = """
    name: John
    age: 20
    """
    value, error_messages = validate_yaml(content, String(required=True))
    assert value == "John"
    assert error_messages == []

    content = """
    name: John
    age: 20
    """
    value, error_messages = validate_yaml(content, String(required=False))
    assert value == "John"
    assert error_messages == []

    content = """
    name: John
    age: 20
    """
    value, error_

# Generated at 2022-06-18 12:49:36.859871
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 42
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert errors == []



# Generated at 2022-06-18 12:49:48.365343
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Pet(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)
        weight = Float(minimum=0)
        alive = Boolean()

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)
        pets = Array(items=Object(Pet))

    content = """
    name: John
    age: 42
    pets:
        - name: Fluffy
          age: 10
          weight: 2.5
          alive: true
        - name: Spot
          age: 3
          weight: 10.0
          alive: true
    """


# Generated at 2022-06-18 12:49:56.322600
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: bar
    """
    validator = Field(type="string")
    value, error_messages = validate_yaml(content, validator)
    assert value == "bar"
    assert error_messages == []

    content = """
    foo: 123
    """
    validator = Field(type="string")
    value, error_messages = validate_yaml(content, validator)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be of type 'string'."
    assert error_messages[0].code == "type_error"
    assert error_messages[0].position.line_no == 2
    assert error_messages[0].position.column_no == 4


# Generated at 2022-06-18 12:50:08.025574
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name:
    """
    value, errors = validate_yaml(content, Person)
    assert errors == [
        Message(
            text="This field is required.",
            code="required",
            position=Position(line_no=2, column_no=4, char_index=8),
        )
    ]

    content = """
    name: 123
    """
    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:50:20.563339
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 20
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert error_messages == []

    content = """
    name: John
    age: twenty
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be an integer."
    assert error_messages[0].code == "invalid_type"
    assert error_messages[0].position

# Generated at 2022-06-18 12:50:27.513931
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "20"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert errors == [
        Message(
            text="Expected an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=14),
        )
    ]

# Generated at 2022-06-18 12:50:36.985845
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:50:48.561764
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 20
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert error_messages == []

    content = """
    name: John
    age: twenty
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="invalid",
            position=Position(line_no=3, column_no=5, char_index=15),
        )
    ]

    content = """
    name: John
    age: twenty
    """

# Generated at 2022-06-18 12:50:58.508780
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, validator=Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: "John"
    age: 20
    """
    value, error_messages = validate_yaml(content, validator=Person)
    assert value == {"name": "John", "age": 20}

# Generated at 2022-06-18 12:51:08.814522
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(b"", Field(type="string")) == (None, [])
    assert validate_yaml(b"", Field(type="string", required=True)) == (None, [])
    assert validate_yaml(b"", Field(type="string", required=True, default="foo")) == ("foo", [])
    assert validate_yaml(b"", Field(type="string", required=True, default="foo", nullable=True)) == (None, [])
    assert validate_yaml(b"", Field(type="string", required=True, default="foo", nullable=False)) == ("foo", [])
    assert validate_yaml(b"", Field(type="string", required=True, nullable=True)) == (None, [])

# Generated at 2022-06-18 12:51:13.841254
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 30
    """
    validator = Schema(
        fields={
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:51:23.129971
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(String())

    class Family(Schema):
        members = Array(Person)

    class Family2(Schema):
        members = Array(Person)

    class Family3(Schema):
        members = Array(Person)

    class Family4(Schema):
        members = Array(Person)

    class Family5(Schema):
        members = Array(Person)

    class Family6(Schema):
        members = Array(Person)

    class Family7(Schema):
        members = Array(Person)


# Generated at 2022-06-18 12:51:30.061014
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 30
    """
    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer()
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {'name': 'John Doe', 'age': 30}
    assert error_messages == []

    content = """
    name: "John Doe"
    age: "thirty"
    """
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {'name': 'John Doe', 'age': 'thirty'}

# Generated at 2022-06-18 12:51:34.407952
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    foo:
      bar:
        - 1
        - 2
        - 3
    """)
    assert token.value == {"foo": {"bar": [1, 2, 3]}}
    assert token.start == 0
    assert token.end == 27



# Generated at 2022-06-18 12:51:47.394087
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()
        friends = Array(String())
        family = Array(Object(Person))


# Generated at 2022-06-18 12:51:56.399485
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John Doe"
    age: "42"
    """

    value, error_messages = validate_yaml(content, MySchema)

    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(
                line_no=3, column_no=5, char_index=len("\n    name: \"John Doe\"\n")
            ),
        )
    ]

    assert value == {"name": "John Doe", "age": 42}

# Generated at 2022-06-18 12:52:06.022769
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    class Person(Schema):
        name = String()

    class People(Schema):
        people = List(Person)

    class People2(Schema):
        people = List(Person, min_items=2)

    class People3(Schema):
        people = List(Person, min_items=2, max_items=3)

    class People4(Schema):
        people = List(Person, min_items=2, max_items=3, unique_items=True)

    class People5(Schema):
        people = List(Person, min_items=2, max_items=3, unique_items=True, required=True)

# Generated at 2022-06-18 12:52:13.628948
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array

    class Person(Schema):
        name = String()
        age = Integer()

    class People(Schema):
        people = Array(items=Person)

    content = """
    people:
      - name: Alice
        age: 25
      - name: Bob
        age: 26
    """

    value, errors = validate_yaml(content, People)
    assert value == {"people": [{"name": "Alice", "age": 25}, {"name": "Bob", "age": 26}]}
    assert errors == []

    content = """
    people:
      - name: Alice
        age: 25
      - name: Bob
        age: "26"
    """

    value, errors = validate_yaml(content, People)

# Generated at 2022-06-18 12:52:18.935665
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:52:29.810767
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = "name: John"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John\nage: 30"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert len(error_messages) == 1
    assert error_messages[0].text == "Unknown field."
    assert error_messages[0].code == "unknown_field"
    assert error_messages[0].position.line_no == 2
    assert error_messages[0].position.column

# Generated at 2022-06-18 12:52:40.151846
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("- a\n- b") == ["a", "b"]

# Generated at 2022-06-18 12:52:51.622904
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name:
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "required"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 4

    content = """
    name:
    """

    value, errors = validate_yaml(content, Person)
    assert value is None

# Generated at 2022-06-18 12:52:59.317209
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: John
      age: 25
    - name: Jane
      age: 26
    """
    validator = Schema(
        {
            "name": str,
            "age": int,
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == []
    assert value == [
        {"name": "John", "age": 25},
        {"name": "Jane", "age": 26},
    ]


# Generated at 2022-06-18 12:53:11.335342
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:53:23.746344
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(max_length=10)

    content = "name: hello"
    value, error_messages = validate_yaml(content, validator=MySchema)
    assert value == {"name": "hello"}
    assert error_messages == []

    content = "name: hello world"
    value, error_messages = validate_yaml(content, validator=MySchema)
    assert value is None
    assert error_messages == [
        Message(
            text="Value is too long.",
            code="max_length",
            position=Position(line_no=1, column_no=6, char_index=5),
        )
    ]


# Generated at 2022-06-18 12:53:33.323033
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array

    class Person(Schema):
        name = String()
        age = Integer()

    class People(Schema):
        people = Array(items=Person)

    content = """
    people:
    - name: John
      age: 30
    - name: Jane
      age: 20
    """

    value, error_messages = validate_yaml(content, People)
    assert value == {"people": [{"name": "John", "age": 30}, {"name": "Jane", "age": 20}]}
    assert error_messages == []

    content = """
    people:
    - name: John
      age: 30
    - name: Jane
      age: "twenty"
    """

    value, error_messages = validate_yaml(content, People)

# Generated at 2022-06-18 12:53:43.366546
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """
    value, error_messages = validate_yaml(content, Person)
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=19),
        )
    ]

    content = """
    name: "John"
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert error_messages == []



# Generated at 2022-06-18 12:53:54.765853
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("'a'") == "a"
    assert tokenize_yaml('"a"') == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_y

# Generated at 2022-06-18 12:54:03.845830
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String()

    content = """
        name: "John"
    """
    value, error_messages = validate_yaml(content, UserSchema)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
        name: 123
    """
    value, error_messages = validate_yaml(content, UserSchema)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be a string."
    assert error_messages[0].code == "type_error.string"
    assert error_messages[0].position.line_no == 2

# Generated at 2022-06-18 12:54:15.385118
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = "name: John"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John Doe"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == [
        Message(
            text="Value is too long.",
            code="max_length",
            position=Position(line_no=1, column_no=6, char_index=5),
        )
    ]


# Generated at 2022-06-18 12:54:25.894552
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "30"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: "thirty"
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be an integer.",
            code="type_error.integer",
            position=Position(
                line_no=3, column_no=5, char_index=content.find("age") + 1
            ),
        )
    ]




# Generated at 2022-06-18 12:54:36.210815
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: Alice
      age: 20
    - name: Bob
      age: 30
    """
    validator = Schema(
        fields=[
            Field(name="name", type="string"),
            Field(name="age", type="integer"),
        ]
    )
    value, errors = validate_yaml(content, validator)
    assert not errors
    assert value == [
        {"name": "Alice", "age": 20},
        {"name": "Bob", "age": 30},
    ]

    content = """
    - name: Alice
      age: 20
    - name: Bob
      age: 30
    - name: Charlie
      age: "forty"
    """

# Generated at 2022-06-18 12:54:46.799811
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("a: 1") == {"a": 1}
    assert tokenize_yaml("- 1") == [1]
    assert tokenize_

# Generated at 2022-06-18 12:54:57.368526
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("- a\n- b") == ["a", "b"]

# Generated at 2022-06-18 12:55:11.901872
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()

    class Family(Schema):
        members = Array(items=Person)

    class FamilyWithParents(Schema):
        members = Array(items=Person)
        parents = Object(properties={"father": Person, "mother": Person})
