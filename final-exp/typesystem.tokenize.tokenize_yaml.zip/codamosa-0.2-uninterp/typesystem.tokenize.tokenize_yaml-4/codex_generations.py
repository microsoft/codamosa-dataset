

# Generated at 2022-06-18 12:45:33.126800
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """

# Generated at 2022-06-18 12:45:43.208044
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:45:51.267563
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, DateTime
    from typesystem.schemas import Schema
    from datetime import datetime

    class MySchema(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        created_at = DateTime()

    content = """
    name: "John"
    age: 30
    height: 1.8
    is_cool: true
    created_at: "2019-01-01T00:00:00"
    """

    value, errors = validate_yaml(content, MySchema)

# Generated at 2022-06-18 12:46:02.116779
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 25
    """
    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name": "John", "age": 25}
    assert errors == []

    content = """
    name: John
    age: 25
    """
    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer", min_value=26)

    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name": "John", "age": 25}

# Generated at 2022-06-18 12:46:05.344160
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    a: 1
    b: 2
    """
    token = tokenize_yaml(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content



# Generated at 2022-06-18 12:46:11.724950
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test empty string
    with pytest.raises(ParseError):
        tokenize_yaml("")

    # Test invalid YAML
    with pytest.raises(ParseError):
        tokenize_yaml("{'foo': 'bar'}")

    # Test valid YAML
    assert tokenize_yaml("{foo: bar}") == {"foo": "bar"}



# Generated at 2022-06-18 12:46:24.193858
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("- a\n- b") == ["a", "b"]

# Generated at 2022-06-18 12:46:28.078281
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("""
        a: 1
        b: 2
    """) == {'a': 1, 'b': 2}
    assert tokenize_yaml("""
        - 1
        - 2
    """) == [1, 2]
    assert tokenize_yaml("""
        a:
            b: 1
            c: 2
    """)

# Generated at 2022-06-18 12:46:38.912339
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: 1") == {"a": 1}
    assert tokenize_yaml("- 1") == [1]
    assert tokenize_yaml("a: 1\nb: 2") == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:46:46.408525
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:47:01.756952
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test valid YAML
    content = "name: John Doe"
    validator = Schema({"name": str})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    # Test invalid YAML
    content = "name: John Doe\nage: xyz"
    validator = Schema({"name": str, "age": int})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe"}
    assert len(error_messages) == 1
    assert error_messages[0].text == "Value 'xyz' is not a valid integer."
    assert error_messages[0].position.line_no == 2

# Generated at 2022-06-18 12:47:11.259377
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="type_error.string",
            position=Position(line_no=2, column_no=7, char_index=13),
        )
    ]



# Generated at 2022-06-18 12:47:19.367992
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 25
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_mess

# Generated at 2022-06-18 12:47:29.918301
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("42") == ScalarToken(42, 0, 2, content="42")
    assert tokenize_yaml("3.14") == ScalarToken(3.14, 0, 4, content="3.14")
    assert tokenize_yaml("foo") == Scal

# Generated at 2022-06-18 12:47:37.326506
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 20
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert error_messages == []

    content = """
    name: John
    age: twenty
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be an integer."
    assert error_messages[0].position.line_no == 3
    assert error_messages[0].position.column_no == 5



# Generated at 2022-06-18 12:47:49.019785
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class Family(Schema):
        family_name = String()
        people = Object(properties={"people": People()})

    content = """
    family_name: Smith
    people:
      people:
        - name: Bob
          age: 42
          height: 1.83
          is_adult: true
        - name: Alice
          age: 12
          height: 1.5
          is_adult: false
    """

# Generated at 2022-06-18 12:47:59.041542
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean, Object

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        friends = Array(items=Object(Person))
        alive = Boolean()

    content = """
    name: John Doe
    age: 30
    friends:
      - name: Jane Doe
        age: 29
        friends: []
        alive: true
      - name: Bob Smith
        age: 31
        friends: []
        alive: true
    alive: true
    """

    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:48:03.476066
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:48:14.976095
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    # Test valid YAML
    valid_yaml = """
    name: John Doe
    age: 42
    """
    schema = Object(properties={"name": String(), "age": Integer()})
    value, errors = validate_yaml(valid_yaml, schema)
    assert value == {"name": "John Doe", "age": 42}
    assert errors == []

    # Test invalid YAML
    invalid_yaml = """
    name: John Doe
    age: forty-two
    """
    schema = Object(properties={"name": String(), "age": Integer()})
    value, errors = validate_yaml(invalid_yaml, schema)
    assert value is None

# Generated at 2022-06-18 12:48:25.544191
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ""
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("a: b\nc: d") == {"a": "b", "c": "d"}
    assert tokenize_yaml("a: b\nc: d\n") == {"a": "b", "c": "d"}
    assert tokenize_yaml("a: b\nc: d\n\n") == {"a": "b", "c": "d"}
    assert tokenize_yaml("a: b\nc: d\n\n\n") == {"a": "b", "c": "d"}

# Generated at 2022-06-18 12:48:32.028486
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_human = Boolean()
        friends = Array(String())
        family = Array(Object(Person))

    content = """
    name: John
    age: 30
    height: 1.8
    is_human: true
    friends:
        - Mary
        - Bob
    family:
        - name: Jane
          age: 28
          height: 1.7
          is_human: true
          friends:
            - Mary
            - Bob
          family: []
    """
    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:48:42.986546
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(String())
        family = Object(
            {
                "mother": String(),
                "father": String(),
                "siblings": Array(String()),
            }
        )

    content = """
    name: John
    age: 30
    height: 1.7
    is_cool: true
    friends:
      - Mary
      - Jane
      - Bob
    family:
      mother: Jane
      father: Bob
      siblings:
        - Mary
        - Jane
    """

    value, errors = validate_yaml(content, Person)
    assert not errors

# Generated at 2022-06-18 12:48:52.868871
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:48:59.667450
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: John
      age: 30
    - name: Jane
      age: 20
    """
    validator = Schema(
        {
            "name": str,
            "age": int,
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == [
        {"name": "John", "age": 30},
        {"name": "Jane", "age": 20},
    ]
    assert error_messages == []



# Generated at 2022-06-18 12:49:08.919593
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: "John"
      age: 30
    - name: "Jane"
      age: 20
    """
    validator = Schema(
        fields={
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == []
    assert value == [
        {"name": "John", "age": 30},
        {"name": "Jane", "age": 20},
    ]



# Generated at 2022-06-18 12:49:20.670926
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: bar
    """
    validator = Field(type="string")
    value, error_messages = validate_yaml(content, validator)
    assert value == "bar"
    assert error_messages == []

    content = """
    foo: 123
    """
    validator = Field(type="string")
    value, error_messages = validate_yaml(content, validator)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be of type 'string'.",
            code="invalid_type",
            position=Position(line_no=2, column_no=4, char_index=8),
        )
    ]

    content = """
    foo:
      bar: baz
    """

# Generated at 2022-06-18 12:49:30.029459
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("\"a\"") == "a"
    assert tokenize_yaml("'a'") == "a"
    assert tokenize_yaml("'a'") == "a"
    assert tokenize_yaml("'a'") == "a"

# Generated at 2022-06-18 12:49:41.863957
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "25"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: "25"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: "25"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}

# Generated at 2022-06-18 12:49:52.656738
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = "name: John"
    value, error_messages = validate_yaml(content, validator=Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John\nage: 30"
    value, error_messages = validate_yaml(content, validator=Person)
    assert value == {"name": "John"}
    assert error_messages == [
        Message(
            text="'age' is not a valid field.",
            code="invalid_field",
            position=Position(line_no=2, column_no=1, char_index=10),
        )
    ]


# Generated at 2022-06-18 12:50:04.913818
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == Scal

# Generated at 2022-06-18 12:50:14.826423
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == [
        Message(
            text="Missing required field.",
            code="required",
            position=Position(line_no=3, column_no=1, char_index=13),
        )
    ]


# Generated at 2022-06-18 12:50:24.676746
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """

    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": "thirty"}

# Generated at 2022-06-18 12:50:34.523701
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: "John"
    age: "30"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == [
        Message(
            text="'age' is not a valid field.",
            code="invalid_field",
            position=Position(line_no=3, column_no=1, char_index=15),
        )
    ]


# Generated at 2022-06-18 12:50:45.371506
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []


# Generated at 2022-06-18 12:50:55.580883
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()

    class Family(Schema):
        members = Array(items=Person)

    class Family2(Schema):
        members = Array(items=Object(properties={"name": String()}))

    content = """
    members:
      - name: John
        age: 10
        height: 1.5
        is_adult: false
      - name: Jane
        age: 20
        height: 1.8
        is_adult: true
    """
    value, errors = validate_yaml(content, validator=Family)

# Generated at 2022-06-18 12:51:06.008883
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(String())
        spouse = Object(Person)

    content = """
    name: John
    age: 30
    height: 1.8
    is_adult: true
    children:
    - John Jr.
    - Jane
    spouse:
      name: Jane
      age: 30
      height: 1.7
      is_adult: true
      children: []
      spouse: null
    """

    value, error_messages = validate_yaml(content, validator=Person)

# Generated at 2022-06-18 12:51:15.346296
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"name": str})
    content = "name: John"
    value, errors = validate_yaml(content, schema)
    assert value == {"name": "John"}
    assert not errors

    content = "name: John\nage: 30"
    value, errors = validate_yaml(content, schema)
    assert value == {"name": "John"}
    assert len(errors) == 1
    assert errors[0].code == "unknown_field"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 1

    content = "name: John\nage: 30"
    value, errors = validate_yaml(content, schema, strict=True)
    assert value == {"name": "John"}
    assert len(errors) == 2
    assert errors

# Generated at 2022-06-18 12:51:24.478050
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name:
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="This field is required.",
            code="required",
            position=Position(line_no=2, column_no=2, char_index=6),
        )
    ]

    content = """
    name: John
    age: 30
    """

   

# Generated at 2022-06-18 12:51:31.049777
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 25
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert errors == []

    content = """
    name: John
    age: 25
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert errors == []

    content = """
    name: John
    age: 25
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert errors == []


# Generated at 2022-06-18 12:51:41.404573
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=120)
        height = Float(minimum=0)
        is_active = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class PeopleObject(Schema):
        people = Object(properties={"people": Person()})

    class PeopleObjectWithRequired(Schema):
        people = Object(properties={"people": Person()}, required=["people"])

    class PeopleObjectWithAdditionalProperties(Schema):
        people = Object(properties={"people": Person()}, additional_properties=True)


# Generated at 2022-06-18 12:51:52.027458
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []


# Generated at 2022-06-18 12:52:01.812658
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None

# Generated at 2022-06-18 12:52:10.465931
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema
    from typesystem.types import StringType, IntegerType, FloatType, BooleanType

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()

    class Family(Schema):
        members = Array(items=Person)

    class Family2(Schema):
        members = Array(items=Person, min_items=2)

    class Family3(Schema):
        members = Array(items=Person, max_items=2)

    class Family4(Schema):
        members = Array(items=Person, min_items=2, max_items=3)


# Generated at 2022-06-18 12:52:20.144622
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Boolean, Array, Object, Schema

    class User(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        active = Boolean()
        friends = Array(items=Object(properties={"name": String()}))

    content = """
    name: "John Doe"
    age: 30
    active: true
    friends:
      - name: "Jane Doe"
      - name: "Bob Smith"
    """

    value, errors = validate_yaml(content, User)
    assert value == {
        "name": "John Doe",
        "age": 30,
        "active": True,
        "friends": [{"name": "Jane Doe"}, {"name": "Bob Smith"}],
    }
    assert errors == []



# Generated at 2022-06-18 12:52:31.073417
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    content = """
    name: test
    """

    value, errors = validate_yaml(content, MySchema)
    assert value == {"name": "test"}
    assert errors == []

    content = """
    name: test
    extra: field
    """

    value, errors = validate_yaml(content, MySchema)
    assert value == {"name": "test"}
    assert len(errors) == 1
    assert errors[0].code == "extra_fields"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 1
    assert errors[0].position.char_index == len(content) - 1

# Generated at 2022-06-18 12:52:36.667792
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {"name": str, "age": int}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:52:41.879907
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name:
      first: John
      last: Smith
    """
    validator = Schema(
        {
            "name": {
                "first": Field(str),
                "last": Field(str),
            }
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": {"first": "John", "last": "Smith"}}
    assert error_messages == []



# Generated at 2022-06-18 12:52:49.580397
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo: bar
    baz:
      - qux
      - quux
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar", "baz": ["qux", "quux"]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content


# Generated at 2022-06-18 12:53:00.788334
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Dict
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        friends = Array(items=String())
        address = Dict(properties={"city": String(), "state": String()})

    content = """
    name: John Doe
    age: 42
    height: 1.75
    is_adult: true
    friends:
    - Jane Doe
    - Bob Smith
    address:
        city: New York
        state: NY
    """

    value, error_messages = validate_yaml(content, Person)


# Generated at 2022-06-18 12:53:12.672301
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:53:19.331484
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema({"name": str, "age": int})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

# Generated at 2022-06-18 12:53:28.506939
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: 1") == {"a": 1}
    assert tokenize_yaml("- 1") == [1]
    assert tokenize_yaml("- 1\n- 2") == [1, 2]
    assert tokenize_yaml("- 1\n- 2\n- 3")

# Generated at 2022-06-18 12:53:39.887974
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        active = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class PeopleObject(Schema):
        people = Object(properties={"person": Person()})

    class PeopleObjectWithRequired(Schema):
        people = Object(properties={"person": Person()}, required=["person"])

    class PeopleObjectWithAdditionalProperties(Schema):
        people = Object(
            properties={"person": Person()}, additional_properties=Boolean()
        )


# Generated at 2022-06-18 12:53:44.558980
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 42
    """
    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []



# Generated at 2022-06-18 12:53:55.626538
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 25
    """
    validator = Schema(
        {
            "name": str,
            "age": int,
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 25}
    assert errors == []

    content = """
    name: John
    age: 25
    """
    validator = Schema(
        {
            "name": str,
            "age": int,
            "address": str,
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 25}

# Generated at 2022-06-18 12:54:04.234392
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John Doe"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="invalid",
            position=Position(line_no=2, column_no=7, char_index=9),
        )
    ]



# Generated at 2022-06-18 12:54:15.785619
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_human = Boolean()
        friends = Array(items=Object(Person))

    content = """
    name: John
    age: 42
    height: 1.8
    is_human: true
    friends:
      - name: Jane
        age: 30
        height: 1.7
        is_human: true
        friends: []
      - name: Bob
        age: 50
        height: 1.9
        is_human: true
        friends: []
    """

    value, error_messages = validate_yaml(content, Person)
    assert not error_messages


# Generated at 2022-06-18 12:54:26.614009
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 25
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """


# Generated at 2022-06-18 12:54:36.684717
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John"
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert not errors

    content = """
    name: "John"
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert not errors


# Generated at 2022-06-18 12:54:48.059967
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean, Object

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        friends = Array(items=Object(Person))
        alive = Boolean()

    content = """
    name: John Doe
    age: 42
    friends:
    - name: Jane Doe
      age: 43
      friends: []
      alive: true
    - name: Bob Doe
      age: 44
      friends: []
      alive: true
    alive: true
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:55:01.387565
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Boolean, Float, Array

    class MySchema(Schema):
        name = String()
        age = Integer()
        is_active = Boolean()
        balance = Float()
        tags = Array(items=String())

    yaml_content = """
    name: John Doe
    age: 42
    is_active: true
    balance: 42.0
    tags:
      - foo
      - bar
    """

    value, error_messages = validate_yaml(yaml_content, MySchema)
    assert value == {
        "name": "John Doe",
        "age": 42,
        "is_active": True,
        "balance": 42.0,
        "tags": ["foo", "bar"],
    }

# Generated at 2022-06-18 12:55:07.839447
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """
    value, errors = validate_yaml(content, Person)
    assert errors[0].text == "Must be an integer."
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5



# Generated at 2022-06-18 12:55:17.562709
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(items=String())
        family = Object(properties={"mother": String(), "father": String()})

    content = """
    name: "John"
    age: 25
    height: 1.8
    is_cool: true
    friends:
      - "Jane"
      - "Bob"
    family:
      mother: "Mary"
      father: "Bob"
    """
    value, error_messages = validate_yaml(content, Person)