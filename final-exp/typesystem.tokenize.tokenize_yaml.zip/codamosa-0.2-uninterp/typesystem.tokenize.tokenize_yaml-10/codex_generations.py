

# Generated at 2022-06-18 12:45:27.423264
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("\"foo\"") == "foo"
    assert tokenize_yaml("'foo'") == "foo"
    assert tokenize_yaml("{foo: bar}") == {"foo": "bar"}
    assert tokenize_yaml("{foo: 1}") == {"foo": 1}

# Generated at 2022-06-18 12:45:38.961675
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test valid YAML
    valid_yaml = """
    name: John Doe
    age: 42
    """
    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
    value, error_messages = validate_yaml(valid_yaml, PersonSchema)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

    # Test invalid YAML
    invalid_yaml = """
    name: John Doe
    age: forty-two
    """
    value, error_messages = validate_yaml(invalid_yaml, PersonSchema)
    assert value is None

# Generated at 2022-06-18 12:45:49.332187
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml("""
    - 1
    - 2
    - 3
    """)
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3]
    assert token.start == 0
    assert token.end == 22
    assert token.content == """
    - 1
    - 2
    - 3
    """

    token = tokenize_yaml("""
    foo: bar
    """)
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}
    assert token.start == 0
    assert token.end == 11
    assert token.content == """
    foo: bar
    """

    token = tokenize_yaml("""
    foo:
      bar: baz
    """)

# Generated at 2022-06-18 12:46:01.062321
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()

    class Family(Schema):
        members = Array(items=Person)

    class Family2(Schema):
        members = Array(items=Person, min_items=2)

    class Family3(Schema):
        members = Array(items=Person, max_items=2)

    class Family4(Schema):
        members = Array(items=Person, min_items=2, max_items=2)

    class Family5(Schema):
        members = Array(items=Person, min_items=2, max_items=3)


# Generated at 2022-06-18 12:46:08.015258
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: 1") == {"a": 1}
    assert tokenize_yaml("- 1") == [1]
    assert tokenize_yaml("- 1\n- 2") == [1, 2]

# Generated at 2022-06-18 12:46:20.425422
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == [
        Message(
            text="Additional properties are not allowed ('age' was unexpected).",
            code="additional_properties",
            position=Position(line_no=3, column_no=5, char_index=20),
        )
    ]


# Generated at 2022-06-18 12:46:31.535740
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}

# Generated at 2022-06-18 12:46:41.964661
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None

# Generated at 2022-06-18 12:46:48.286506
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:46:59.225803
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:47:09.862754
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=18)

    content = """
    name: John Doe
    age: 17
    """
    value, errors = validate_yaml(content, Person)
    assert errors == [
        ValidationError(
            text="Must be greater than or equal to 18.",
            code="min_value",
            position=Position(line_no=3, column_no=5, char_index=18),
        )
    ]

# Generated at 2022-06-18 12:47:18.502371
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = Field(type="integer", min_length=1)
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == []

    content = """
    - 1
    - 2
    - 3
    - "four"
    """
    validator = Field(type="integer", min_length=1)
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3, "four"]
    assert len(error_messages) == 1
    assert error_messages[0].position.line_no == 5
    assert error_messages[0].position.column_no == 3

# Generated at 2022-06-18 12:47:29.313822
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Boolean, Array, Object

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        is_active = Boolean()

    class People(Schema):
        people = Array(items=Person)

    content = """
    people:
      - name: John
        age: 30
        is_active: true
      - name: Jane
        age: 40
        is_active: false
    """
    value, errors = validate_yaml(content, People)
    assert value == {
        "people": [
            {"name": "John", "age": 30, "is_active": True},
            {"name": "Jane", "age": 40, "is_active": False},
        ]
    }
    assert errors

# Generated at 2022-06-18 12:47:37.076208
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0, maximum=3.0)
        is_human = Boolean()
        friends = Array(items=String())
        address = Object(properties={"city": String(), "country": String()})

    content = """
    name: John
    age: 25
    height: 1.75
    is_human: true
    friends:
      - Alice
      - Bob
    address:
      city: London
      country: UK
    """

    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:47:48.783032
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean, Object

    class Person(Schema):
        name = String()
        age = Integer()
        friends = Array(items=String())
        alive = Boolean()

    class Family(Schema):
        members = Array(items=Person())

    content = """
    members:
      - name: "Alice"
        age: 30
        friends:
          - "Bob"
          - "Carol"
        alive: true
      - name: "Bob"
        age: 31
        friends:
          - "Alice"
          - "Carol"
        alive: false
    """

    value, error_messages = validate_yaml(content, Family())

# Generated at 2022-06-18 12:47:58.803747
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == [
        ValidationError(
            text="Additional properties are not allowed ('age' was unexpected).",
            code="additional_properties",
            position=Position(line_no=3, column_no=5, char_index=20),
        )
    ]


# Generated at 2022-06-18 12:48:03.245158
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 43
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )

    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 43}
    assert error_messages == []



# Generated at 2022-06-18 12:48:14.685447
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(max_length=10)

    content = """
    name: "John Doe"
    """
    value, error_messages = validate_yaml(content, UserSchema)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: "John Doe"
    """
    value, error_messages = validate_yaml(content, UserSchema)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: "John Doe"
    """
    value, error_messages = validate_yaml(content, UserSchema)

# Generated at 2022-06-18 12:48:25.272497
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    name: John
    age: 25
    '''
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 25}
    assert not errors

    content = '''
    name: John
    age: 25
    '''
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(str),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value is None

# Generated at 2022-06-18 12:48:35.894729
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 42
    """
    class Person(Schema):
        name = String()
        age = Integer()

    value, error_messages = validate_yaml(content, validator=Person)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

    content = """
    name: "John Doe"
    age: "42"
    """
    value, error_messages = validate_yaml(content, validator=Person)
    assert value == {"name": "John Doe", "age": "42"}

# Generated at 2022-06-18 12:48:49.176328
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a\nb") == "a\nb"
    assert tokenize_yaml("a\n  b") == "a\n  b"
    assert tokenize_yaml("a\n  b\n    c") == "a\n  b\n    c"
    assert token

# Generated at 2022-06-18 12:48:59.483171
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 42
    """
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert errors == []

    content = """
    name: "John Doe"
    age: "42"
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=17),
        )
    ]


# Generated at 2022-06-18 12:49:10.832143
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(String())
        family = Array(Object(Person))

    person = Person()

# Generated at 2022-06-18 12:49:21.211404
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """

    value, errors = validate_yaml(content, validator=Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name:
    """

    value, errors = validate_yaml(content, validator=Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "required"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 4



# Generated at 2022-06-18 12:49:30.486774
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:49:42.407408
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "25"}
    assert errors == []

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "25"}
    assert errors == []

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:49:48.413267
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:49:56.347160
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array, Boolean
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=100)
        tags = Array(items=String(max_length=10))
        is_active = Boolean()

    yaml_str = """
    name: "John Doe"
    age: -1
    tags:
      - "foo"
      - "bar"
      - "baz"
    is_active: true
    """

    value, errors = validate_yaml(yaml_str, TestSchema)

# Generated at 2022-06-18 12:50:08.069617
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test that a valid YAML string is parsed and validated correctly.
    content = """
    name: "John Doe"
    age: 42
    """
    validator = Schema(
        {"name": "string", "age": "integer"},
        error_messages={"required": "This field is required."},
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

    # Test that an invalid YAML string is parsed and validated correctly.
    content = """
    name: "John Doe"
    age: "forty-two"
    """

# Generated at 2022-06-18 12:50:15.394784
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:50:22.135712
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = typing.List[int]
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == []



# Generated at 2022-06-18 12:50:31.821437
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test valid YAML
    valid_yaml = """
    name: John Doe
    age: 42
    """
    class Person(Schema):
        name = fields.String()
        age = fields.Integer()

    value, errors = validate_yaml(valid_yaml, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert errors == []

    # Test invalid YAML
    invalid_yaml = """
    name: John Doe
    age: forty-two
    """
    value, errors = validate_yaml(invalid_yaml, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column

# Generated at 2022-06-18 12:50:41.635773
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("- a\n- b") == ["a", "b"]

# Generated at 2022-06-18 12:50:52.762800
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: "John"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}

# Generated at 2022-06-18 12:51:02.758112
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:51:12.714567
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "20"
    """

    value, error_messages = validate_yaml(content, MySchema)
    assert error_messages[0].text == "Must be an integer."
    assert error_messages[0].position.line_no == 3
    assert error_messages[0].position.column_no == 5
    assert error_messages[0].position.char_index == 20

    content = """
    name: "John"
    age: 20
    """

    value, error_messages = validate_yaml(content, MySchema)
    assert error

# Generated at 2022-06-18 12:51:21.890542
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0, maximum=3.0)
        is_active = Boolean()

    class Team(Schema):
        name = String()
        members = Array(items=Object(Person))


# Generated at 2022-06-18 12:51:29.397398
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test validating a YAML string against a Field.
    field = Field(type="string", max_length=3)
    value, error_messages = validate_yaml(content="foo", validator=field)
    assert value == "foo"
    assert error_messages == []

    value, error_messages = validate_yaml(content="foobar", validator=field)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be no more than 3 characters long.",
            code="max_length",
            position=Position(line_no=1, column_no=1, char_index=0),
        )
    ]

    # Test validating a YAML string against a Schema.

# Generated at 2022-06-18 12:51:39.793677
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class MySchema(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(items=String())
        family = Object(properties={"mom": String(), "dad": String()})

    content = """
    name: "John"
    age: 42
    height: 1.8
    is_cool: true
    friends:
        - "Jane"
        - "Bob"
    family:
        mom: "Mary"
        dad: "Peter"
    """

    value, errors = validate_yaml(content, MySchema)


# Generated at 2022-06-18 12:51:49.426717
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, errors = validate_yaml(content, validator=UserSchema)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: "John"
    age: 20
    """
    value, errors = validate_yaml(content, validator=UserSchema)
    assert value == {"name": "John"}

# Generated at 2022-06-18 12:52:01.944490
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test that validate_yaml returns a tuple of (value, error_messages)
    from typesystem import Integer, String, Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "30"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: "thirty"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}

# Generated at 2022-06-18 12:52:10.561652
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean

    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=150)
        friends = Array(items=String())
        alive = Boolean()

    content = """
    name: John
    age: 25
    friends:
      - Alice
      - Bob
    alive: true
    """

    value, errors = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 25,
        "friends": ["Alice", "Bob"],
        "alive": True,
    }
    assert not errors

    content = """
    name: John
    age: 25
    friends:
      - Alice
      - Bob
    alive: true
    extra: field
    """

    value, errors

# Generated at 2022-06-18 12:52:20.826220
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()

    content = """
    name: John
    age: 30
    height: 1.8
    is_adult: true
    """

    value, error_messages = validate_yaml(content, Person)

    assert value == {
        "name": "John",
        "age": 30,
        "height": 1.8,
        "is_adult": True,
    }
    assert error_messages == []

    content = """
    name: John
    age: 30
    height: 1.8
    is_adult: true
    """

    value, error_

# Generated at 2022-06-18 12:52:31.359631
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class Team(Schema):
        name = String()
        people = Array(items=Person())

    class Teams(Schema):
        teams = Array(items=Team())

    class Company(Schema):
        name = String()
        people = Array(items=Person())
        teams = Array(items=Team())

    class Companies(Schema):
        companies = Array(items=Company())

    class Root(Schema):
        people = Array(items=Person())
        teams = Array

# Generated at 2022-06-18 12:52:41.376174
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: John
      age: 30
    - name: Jane
      age: 28
    """
    validator = Schema(
        fields={
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == [
        {"name": "John", "age": 30},
        {"name": "Jane", "age": 28},
    ]
    assert error_messages == []

    content = """
    - name: John
      age: 30
    - name: Jane
      age: 28
    - name: Jack
      age: "twenty-eight"
    """

# Generated at 2022-06-18 12:52:53.525439
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")
    assert tokenize_yaml("foo") == Scal

# Generated at 2022-06-18 12:53:03.729081
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """

# Generated at 2022-06-18 12:53:16.224306
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    """
    value, errors = validate_yaml(content, String())
    assert value == "John"
    assert errors == []

    content = """
    name: John
    """
    value, errors = validate_yaml(content, String(min_length=5))
    assert value == "John"

# Generated at 2022-06-18 12:53:25.973831
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0)
        is_active = Boolean()
        friends = Array(items=Object(Person))

    content = """
    name: John
    age: 30
    height: 1.8
    is_active: true
    friends:
      - name: Alice
        age: 25
        height: 1.6
        is_active: true
        friends: []
      - name: Bob
        age: 27
        height: 1.7
        is_active: false
        friends: []
    """

    value, error_mess

# Generated at 2022-06-18 12:53:37.251125
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 20
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert not error_messages

    content = """
    name: John
    age: twenty
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be an integer."
    assert error_messages[0].position.line_no == 3
    assert error_messages[0].position.column_no == 5


# Generated at 2022-06-18 12:53:44.804366
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 30}
    assert not errors



# Generated at 2022-06-18 12:53:55.979825
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    class Family(Schema):
        members = Array(items=Person)

    content = """
    members:
      - name: Alice
        age: 25
      - name: Bob
        age: 26
    """

    value, errors = validate_yaml(content, validator=Family)
    assert value == {"members": [{"name": "Alice", "age": 25}, {"name": "Bob", "age": 26}]}
    assert errors == []

    content = """
    members:
      - name: Alice
        age: 25
      - name: Bob
        age: 26
      - name: Charlie
        age: "27"
    """

# Generated at 2022-06-18 12:54:04.621387
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None

# Generated at 2022-06-18 12:54:15.894762
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: 'John'
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name:
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="This field is required.",
            code="required",
            position=Position(line_no=2, column_no=4, char_index=11),
        )
    ]



# Generated at 2022-06-18 12:54:26.737462
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "30"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert len(errors) == 0

    content = """
    name: John
    age: "thirty"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3

# Generated at 2022-06-18 12:54:36.827691
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        weight = Float(minimum=0.0)
        is_active = Boolean()
        friends = Array(items=String(max_length=100))

    content = """
    name: John Doe
    age: 25
    weight: 70.5
    is_active: true
    friends:
        - Jane Doe
        - John Smith
    """

    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:54:48.222145
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John Smith
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must have no more than 10 characters.",
            code="max_length",
            position=Position(line_no=2, column_no=7, char_index=12),
        )
    ]

# Generated at 2022-06-18 12:54:58.343527
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 99
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 99}
    assert errors == []

    content = """
    name: John Doe
    age: -1
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": -1}

# Generated at 2022-06-18 12:55:09.230290
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert errors == []

    content = """
    name: John Doe
    age: "thirty"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": "thirty"}