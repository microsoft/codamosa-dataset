

# Generated at 2022-06-18 12:45:25.879623
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = typing.List[int]
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == []



# Generated at 2022-06-18 12:45:37.341709
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("- a\n- b") == ["a", "b"]

# Generated at 2022-06-18 12:45:45.803057
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()
        friends = Array(items=String())
        address = Object(properties={"city": String(), "state": String()})

    content = """
    name: John Doe
    age: 42
    height: 1.88
    is_active: true
    friends:
    - Jane Doe
    - Bob Smith
    address:
      city: San Francisco
      state: CA
    """

    value, errors = validate_yaml(content, UserSchema)

# Generated at 2022-06-18 12:45:51.039257
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == {}
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") is True
    assert tokenize_yaml("false") is False
    assert tokenize_yaml("null") is None
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}
    assert tokenize_yaml("foo: 1") == {"foo": 1}
    assert tokenize_yaml("foo: 1.0") == {"foo": 1.0}

# Generated at 2022-06-18 12:46:01.985407
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = "name: John"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John Doe"
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must have no more than 10 characters."
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 6



# Generated at 2022-06-18 12:46:12.649774
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert not errors

    content = """
    name: 123
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "123"}
    assert errors == [
        Message(
            text="Must be a string.",
            code="invalid",
            position=Position(line_no=2, column_no=6, char_index=11),
        )
    ]

    content = """
    name: 123
    name: 456
    """
    value, errors

# Generated at 2022-06-18 12:46:24.976865
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = typing.List[int]
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == []

    content = """
    - 1
    - 2
    - 3
    - "4"
    """
    validator = typing.List[int]
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == [
        Message(
            text="Expected an integer.",
            code="invalid_type",
            position=Position(line_no=4, column_no=3, char_index=19),
        )
    ]

# Generated at 2022-06-18 12:46:28.738355
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo: bar
    baz:
      - qux
      - quux
    """
    token = tokenize_yaml(content)
    assert token.value == {"foo": "bar", "baz": ["qux", "quux"]}



# Generated at 2022-06-18 12:46:34.933375
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """

    value, errors = validate_yaml(content, Person)
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5



# Generated at 2022-06-18 12:46:43.791952
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("[]") == ListToken([], 0, 1)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3)
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1)
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3)
    assert tokenize_yaml("1.0e10") == ScalarToken(1.0e10, 0, 6)
   

# Generated at 2022-06-18 12:46:58.786655
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        is_cool = Boolean()

    content = """
    name: John
    age: 30
    is_cool: true
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30, "is_cool": True}
    assert errors == []

    content = """
    name: John
    age: 30
    is_cool: true
    extra: value
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30, "is_cool": True}
    assert len(errors) == 1


# Generated at 2022-06-18 12:47:09.571928
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(String())

    class Family(Schema):
        members = Array(Person)

    class Family2(Schema):
        members = Array(Person)

    class Family3(Schema):
        members = Array(Person)

    class Family4(Schema):
        members = Array(Person)

    class Family5(Schema):
        members = Array(Person)

    class Family6(Schema):
        members = Array(Person)

    class Family7(Schema):
        members = Array(Person)


# Generated at 2022-06-18 12:47:18.305741
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name:
      first: John
      last: Smith
    """
    validator = Schema(
        {"name": {"first": str, "last": str}},
        extra_properties="forbid",
        allow_unknown_fields=False,
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": {"first": "John", "last": "Smith"}}
    assert errors == []

    content = """
    name:
      first: John
      last: Smith
    """
    validator = Schema(
        {"name": {"first": str, "last": str}},
        extra_properties="forbid",
        allow_unknown_fields=False,
    )
    value, errors = validate_yaml(content, validator)

# Generated at 2022-06-18 12:47:29.178034
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields

    class Person(Schema):
        name = fields.String(max_length=100)
        age = fields.Integer(minimum=0, maximum=150)

    content = """
    name: "John"
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: "John"
    age: "thirty"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}

# Generated at 2022-06-18 12:47:39.147565
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = Field(type="integer", min_length=3)
    value, errors = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert errors == []

    content = """
    - 1
    - 2
    """
    validator = Field(type="integer", min_length=3)
    value, errors = validate_yaml(content, validator)
    assert value == [1, 2]
    assert errors == [
        ValidationError(
            text="Must have at least 3 items.",
            code="min_length",
            position=Position(line_no=1, column_no=1, char_index=0),
        )
    ]


# Generated at 2022-06-18 12:47:50.992014
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert not errors

    content = """
    name: John
    age: thirty
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(
                line_no=3, column_no=5, char_index=len("\nname: John\n") + 1
            ),
        )
    ]


# Generated at 2022-06-18 12:48:00.964576
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 42
    """
    class Person(Schema):
        name = String()
        age = Integer()

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert errors == []

    content = """
    name: John Doe
    age: 42
    """
    class Person(Schema):
        name = String()
        age = Integer(minimum=18)

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}

# Generated at 2022-06-18 12:48:11.244640
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: "John"
    age: "30"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert error_messages == []

    content = """
    name: "John"
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert error_messages == []

    content = """
    name: "John"
    age: "30"
    """

    value, error_mess

# Generated at 2022-06-18 12:48:21.499880
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}

# Generated at 2022-06-18 12:48:33.421615
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: 42
    """
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": 42}
    assert error_messages == []

    content = """
    name: "John"
    age: "42"
    """
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": "42"}

# Generated at 2022-06-18 12:48:50.639689
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    class Family(Schema):
        members = Array(items=Person)

    content = """
    members:
      - name: Alice
        age: 12
      - name: Bob
        age: 14
    """
    value, error_messages = validate_yaml(content, Family)
    assert error_messages == []
    assert value == {
        "members": [
            {"name": "Alice", "age": 12},
            {"name": "Bob", "age": 14},
        ]
    }


# Generated at 2022-06-18 12:49:00.923974
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()
        friends = Array(String())
        address = Object(
            {
                "street": String(),
                "city": String(),
                "state": String(),
                "zip": String(),
            }
        )

    content = """
    name: John Doe
    age: 42
    height: 1.85
    is_active: true
    friends:
    - Alice
    - Bob
    address:
      street: 123 Main St.
      city: Anytown
      state: CA
      zip: 90210
    """


# Generated at 2022-06-18 12:49:11.330154
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields

    class Person(Schema):
        name = fields.String()
        age = fields.Integer()

    content = """
    name: John
    age: 20
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert errors == []

    content = """
    name: John
    age: twenty
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5



# Generated at 2022-06-18 12:49:22.887733
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 42
    """
    class Person(Schema):
        name = String()
        age = Integer()
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert errors == []

    content = """
    name: John Doe
    age: 42
    """
    class Person(Schema):
        name = String()
        age = Integer()
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert errors == []

    content = """
    name: John Doe
    age: 42
    """
    class Person(Schema):
        name = String()
        age = Integer()
    value, errors = validate

# Generated at 2022-06-18 12:49:31.379152
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("'string'") == "string"
    assert tokenize_yaml("'string with spaces'") == "string with spaces"
    assert tokenize_yaml("'string with\nnewline'") == "string with\nnewline"
    assert tokenize_yaml("'string with\nnewline'") == "string with\nnewline"

# Generated at 2022-06-18 12:49:42.922678
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == {}
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("{a: 1}") == {"a": 1}
    assert tokenize_yaml("{a: 1, b: 2}") == {"a": 1, "b": 2}
    assert tokenize_yaml("[1, 2]") == [1, 2]
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_yaml("{a: 1, b: [1, 2]}") == {"a": 1, "b": [1, 2]}

# Generated at 2022-06-18 12:49:53.502620
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String(max_length=10)

    content = """
    name: "John Doe"
    """
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: "John Doe"
    age: 42
    """
    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John Doe"}

# Generated at 2022-06-18 12:50:05.805789
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []

    content = """
    name: John Doe
    age: -30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None

# Generated at 2022-06-18 12:50:13.826514
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content=b"", validator=Field(type="string")) == (None, [])
    assert validate_yaml(content=b"", validator=Field(type="integer")) == (None, [])
    assert validate_yaml(content=b"", validator=Field(type="number")) == (None, [])
    assert validate_yaml(content=b"", validator=Field(type="boolean")) == (None, [])
    assert validate_yaml(content=b"", validator=Field(type="array")) == (None, [])
    assert validate_yaml(content=b"", validator=Field(type="object")) == (None, [])


# Generated at 2022-06-18 12:50:19.281502
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: Bob
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "Bob"}
    assert errors == []

    content = """
    name: Bob
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "Bob"}
    assert errors == []

    content = """
    name: Bob
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "Bob"}
    assert errors == []

    content = """
    name: Bob
    """

# Generated at 2022-06-18 12:50:36.360743
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem import String

    content = "hello"
    validator = String(max_length=5)
    value, error_messages = validate_yaml(content, validator)
    assert value == "hello"
    assert error_messages == []

    content = "hello"
    validator = String(max_length=4)
    value, error_messages = validate_yaml(content, validator)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be no more than 4 characters."
    assert error_messages[0].code == "max_length"
    assert error_messages[0].position.line_no == 1
    assert error_messages

# Generated at 2022-06-18 12:50:47.583075
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}
    assert tokenize_yaml("- foo") == ["foo"]
    assert tokenize_yaml("- foo\n- bar") == ["foo", "bar"]

# Generated at 2022-06-18 12:50:57.652916
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John"
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: "John"
    age: "30"
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": "30"}

# Generated at 2022-06-18 12:51:07.942864
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        friends = Array(String())
        address = Object(
            {
                "street": String(),
                "city": String(),
                "state": String(),
                "zip": String(),
            }
        )

    content = """
    name: John Doe
    age: 42
    height: 5.9
    is_adult: true
    friends:
      - Jane Doe
      - Joe Doe
    address:
      street: 123 Main St.
      city: Anytown
      state: NY
      zip: 12345
    """

    value, errors = validate_

# Generated at 2022-06-18 12:51:17.003574
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """

# Generated at 2022-06-18 12:51:25.933783
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("[]") == ListToken([], 0, 1)
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0)
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3)
    assert tokenize_yaml("a: 1") == DictToken({"a": 1}, 0, 4)
    assert tokenize

# Generated at 2022-06-18 12:51:29.520707
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    b: 2
    """
    class TestSchema(Schema):
        a = Field(type="integer")
        b = Field(type="integer")

    value, errors = validate_yaml(content, TestSchema)
    assert value == {"a": 1, "b": 2}
    assert errors == []



# Generated at 2022-06-18 12:51:39.935479
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: "John"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: "John"
    age: 20
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}

# Generated at 2022-06-18 12:51:49.536099
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()
        friends = Array(String())
        family = Object(
            {
                "mother": String(),
                "father": String(),
                "siblings": Array(String()),
            }
        )

    content = """
    name: John Doe
    age: 42
    height: 1.8
    is_active: true
    friends:
      - Jane Doe
      - Bob Smith
    family:
      mother: Jane Doe
      father: Bob Smith
      siblings:
        - Jane Doe
        - Bob Smith
    """

    value, errors = validate_yaml

# Generated at 2022-06-18 12:51:59.357938
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "20"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert errors == []

    content = """
    name: John
    age: "20"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert errors == []

    content = """
    name: John
    age: "20"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert errors == []


# Generated at 2022-06-18 12:52:12.982362
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = "name: John Doe\nage: 30"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []

    content = "name: John Doe\nage: -30"
    value, error_messages = validate_yaml(content, Person)
    assert value is None

# Generated at 2022-06-18 12:52:23.458645
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: thirty
    """
    value, errors = validate_yaml(content, Person)
    assert value is None

# Generated at 2022-06-18 12:52:34.703254
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=18)
        height = Float()
        is_adult = Boolean()

    content = """
    name: John
    age: 20
    height: 1.75
    is_adult: true
    """
    value, errors = validate_yaml(content, TestSchema)
    assert value == {
        "name": "John",
        "age": 20,
        "height": 1.75,
        "is_adult": True,
    }
    assert errors == []


# Generated at 2022-06-18 12:52:44.645878
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:52:56.159818
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()
        friends = Array(items=String())
        address = Object(properties={"city": String(), "state": String()})

    content = """
    name: John Doe
    age: 30
    height: 1.8
    is_active: true
    friends:
    - Alice
    - Bob
    address:
      city: New York
      state: NY
    """

    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:53:06.311776
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("[]") == ListToken([], 0, 1)
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0)
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3)
    assert tokenize_yaml("a: 1") == DictToken({"a": 1}, 0, 4)
    assert tokenize

# Generated at 2022-06-18 12:53:18.805931
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:53:27.931545
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert errors == []

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert errors == []

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:53:39.312494
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 25
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert errors == []

    content = """
    name: John
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Missing required field 'age'.",
            code="missing_required_field",
            position=Position(line_no=3, column_no=1, char_index=13),
        )
    ]

    content = """
    name: John
    age: 25
    """


# Generated at 2022-06-18 12:53:47.456029
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Boolean
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()
        active = Boolean()

    content = """
    name: "John Doe"
    age: "42"
    active: true
    """
    value, errors = validate_yaml(content, MySchema)
    assert value == {"name": "John Doe", "age": 42, "active": True}
    assert errors == []

    content = """
    name: "John Doe"
    age: "42"
    active: "true"
    """
    value, errors = validate_yaml(content, MySchema)
    assert value == {"name": "John Doe", "age": 42, "active": True}

# Generated at 2022-06-18 12:54:02.517119
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: -30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": -30}
    assert len(errors) == 1
    assert errors[0].code == "minimum"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 4


# Generated at 2022-06-18 12:54:13.875305
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == [
        Message(
            text="'age' is not a valid field.",
            code="invalid_field",
            position=Position(line_no=3, column_no=1, char_index=15),
        )
    ]


# Generated at 2022-06-18 12:54:23.511014
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert not error_messages

    content = """
    name:
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "This field is required."
    assert error_messages[0].position.line_no == 2
    assert error_messages[0].position.column_no == 4

    content = """
    name:
    """
    value

# Generated at 2022-06-18 12:54:34.185400
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String

    content = "foo: bar"
    validator = String()
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == []
    assert value == "bar"

    content = "foo: bar"
    validator = String(min_length=4)
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == [
        Message(
            text="Must be at least 4 characters long.",
            code="min_length",
            position=Position(line_no=1, column_no=7, char_index=6),
        )
    ]
    assert value == "bar"

    content = "foo: bar"
    validator = String(max_length=2)
    value, error

# Generated at 2022-06-18 12:54:45.017449
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("- a\n- b") == ["a", "b"]

# Generated at 2022-06-18 12:54:52.832275
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: "John"
      age: 30
    - name: "Jane"
      age: 28
    """
    validator = Schema(
        fields={
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == [
        {"name": "John", "age": 30},
        {"name": "Jane", "age": 28},
    ]
    assert error_messages == []



# Generated at 2022-06-18 12:54:57.173546
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: "John"
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert len(error_messages) == 1
    assert error_messages[0].text == "Additional properties are not allowed ('age' was unexpected)."
    assert error_messages[0].code == "additional_properties"

# Generated at 2022-06-18 12:55:07.956555
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0)

    content = """
    name: John
    age: 42
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 42}
    assert not errors

    content = """
    name: John
    age: -42
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        ValidationError(
            text="Must be greater than or equal to 0.",
            code="min_value",
            position=Position(line_no=3, column_no=5, char_index=17),
        )
    ]


# Generated at 2022-06-18 12:55:17.645692
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()

    class Team(Schema):
        name = String()
        members = Array(items=Person)

    class TeamWithOptional(Schema):
        name = String()
        members = Array(items=Person, required=False)

    class TeamWithOptional2(Schema):
        name = String()
        members = Array(items=Person, required=False, default=[])

    class TeamWithOptional3(Schema):
        name = String()
        members = Array(items=Person, required=False, default=lambda: [])
