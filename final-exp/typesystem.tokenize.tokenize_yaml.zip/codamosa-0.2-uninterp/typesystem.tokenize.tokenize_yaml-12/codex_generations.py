

# Generated at 2022-06-18 12:45:25.879885
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:45:37.385195
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")
    assert tokenize_yaml("foo: bar") == DictToken({"foo": "bar"}, 0, 7, content="foo: bar")
    assert tokenize_yaml("- foo") == ListToken(["foo"], 0, 5, content="- foo")
    assert tokenize_yaml("- foo\n- bar") == ListToken(["foo", "bar"], 0, 11, content="- foo\n- bar")
    assert tokenize_yaml("foo: bar\nbaz: qux") == DictToken({"foo": "bar", "baz": "qux"}, 0, 15, content="foo: bar\nbaz: qux")
    assert tokenize_y

# Generated at 2022-06-18 12:45:45.928706
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("""
        a: 1
        b: 2
        c: 3
    """) == {'a': 1, 'b': 2, 'c': 3}
    assert tokenize_yaml("""
        - 1
        - 2
        - 3
    """) == [1, 2, 3]

# Generated at 2022-06-18 12:45:56.511866
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class PeopleObject(Schema):
        people = Object(properties={"name": String(), "age": Integer()})

    class PeopleObjectWithRequired(Schema):
        people = Object(properties={"name": String(), "age": Integer()}, required=["name"])

    class PeopleObjectWithAdditionalProperties(Schema):
        people = Object(properties={"name": String(), "age": Integer()}, additional_properties=True)


# Generated at 2022-06-18 12:46:05.989341
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    content = "name: John"
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John\nage: 30"
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John"}
    assert error_messages == [
        Message(
            text="Additional properties are not allowed ('age' was unexpected).",
            code="additional_properties",
            position=Position(line_no=2, column_no=1, char_index=9),
        )
    ]



# Generated at 2022-06-18 12:46:18.499708
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("'foo'") == "foo"
    assert tokenize_yaml('"foo"') == "foo"
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}
    assert tokenize_yaml("- foo") == ["foo"]
    assert tokenize_y

# Generated at 2022-06-18 12:46:29.572194
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == Scal

# Generated at 2022-06-18 12:46:40.170680
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String()
        age = Integer()
        weight = Float()
        is_active = Boolean()
        tags = Array(items=String())

    yaml_content = """
    name: "John Doe"
    age: 42
    weight: 180.5
    is_active: true
    tags:
        - "foo"
        - "bar"
    """

    value, errors = validate_yaml(yaml_content, TestSchema)

# Generated at 2022-06-18 12:46:50.380521
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml(" ") == None
    assert tokenize_yaml("\n") == None
    assert tokenize_yaml("\n\n") == None
    assert tokenize_yaml("\n\n\n") == None
    assert tokenize_yaml("\n\n\n\n") == None
    assert tokenize_yaml("\n\n\n\n\n") == None
    assert tokenize_yaml("\n\n\n\n\n\n") == None
    assert tokenize_yaml("\n\n\n\n\n\n\n") == None
    assert tokenize_yaml("\n\n\n\n\n\n\n\n") == None
    assert tokenize_y

# Generated at 2022-06-18 12:47:02.163435
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Smith
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Smith", "age": 30}
    assert errors == []

    content = """
    name: John Smith
    age: -30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Smith", "age": -30}

# Generated at 2022-06-18 12:47:17.198804
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """
    value, error_messages = validate_yaml(content, MySchema)
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=19),
        )
    ]

    content = """
    name: "John"
    age: 30
    """
    value, error_messages = validate_yaml(content, MySchema)
    assert error_messages == []



# Generated at 2022-06-18 12:47:28.619541
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(items=String())

    content = """
    name: John
    age: 25
    height: 1.75
    is_adult: true
    children:
        - Jane
        - Joe
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 25,
        "height": 1.75,
        "is_adult": True,
        "children": ["Jane", "Joe"],
    }
    assert error_messages == []

    content

# Generated at 2022-06-18 12:47:38.354954
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("""
    name: "John"
    age: 30
    """, Schema({"name": str, "age": int})) == ({"name": "John", "age": 30}, [])

    assert validate_yaml("""
    name: "John"
    age: 30
    """, Schema({"name": str, "age": str})) == (
        {"name": "John", "age": 30},
        [
            Message(
                text="Must be of type 'str'.",
                code="type_error.str",
                position=Position(line_no=3, column_no=5, char_index=16),
            )
        ],
    )


# Generated at 2022-06-18 12:47:50.134781
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 42
    """
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

    content = """
    name: John Doe
    age: 42
    """
    class Person(Schema):
        name = String(max_length=3)
        age = Integer(minimum=0)

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}

# Generated at 2022-06-18 12:48:00.141954
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class ExampleSchema(Schema):
        name = String()

    content = """
    name: "Hello"
    """
    value, error_messages = validate_yaml(content, ExampleSchema)
    assert value == {"name": "Hello"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, ExampleSchema)
    assert value == {"name": "123"}
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="type_error.string",
            position=Position(line_no=2, column_no=7, char_index=8),
        )
    ]

   

# Generated at 2022-06-18 12:48:04.543534
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert errors == []



# Generated at 2022-06-18 12:48:16.326891
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - a
    - b
    - c
    """
    validator = Field(type="list", items=Field(type="string"))
    value, errors = validate_yaml(content, validator)
    assert value == ["a", "b", "c"]
    assert errors == []

    content = """
    - a
    - b
    - c
    - d
    """
    validator = Field(type="list", items=Field(type="string"), max_length=3)
    value, errors = validate_yaml(content, validator)
    assert value == ["a", "b", "c"]

# Generated at 2022-06-18 12:48:26.766692
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John Smith"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Smith"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "123"}
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="invalid",
            position=Position(line_no=2, column_no=8, char_index=11),
        )
    ]


# Generated at 2022-06-18 12:48:37.368533
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John Doe
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must have no more than 10 characters.",
            code="max_length",
            position=Position(line_no=2, column_no=7, char_index=13),
        )
    ]


# Generated at 2022-06-18 12:48:48.553600
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="invalid",
            position=Position(line_no=2, column_no=7, char_index=11),
        )
    ]

    content = """
    name: 123
    """
    value

# Generated at 2022-06-18 12:49:10.022923
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == [
        Message(
            text="'age' is not a valid field.",
            code="invalid_field",
            position=Position(line_no=3, column_no=1, char_index=10),
        )
    ]


# Generated at 2022-06-18 12:49:19.844719
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "string"
        age = "integer"

    content = """
    name: "John"
    age: "30"
    """
    value, errors = validate_yaml(content, TestSchema)
    assert value == {"name": "John", "age": 30}
    assert len(errors) == 1
    assert errors[0].text == "Must be an integer."
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5
    assert errors[0].position.char_index == 22



# Generated at 2022-06-18 12:49:29.440416
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "123"}
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="invalid",
            position=Position(line_no=2, column_no=6, char_index=8),
        )
    ]


# Generated at 2022-06-18 12:49:41.385030
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = String(max_length=20)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: -30
    """
    value, errors = validate_yaml(content, PersonSchema)
    assert value is None
    assert len(errors) == 1
    assert errors[0].text == "Must be greater than or equal to 0."
    assert errors[0].code == "min_value"
    assert errors[0].position.line_no == 3

# Generated at 2022-06-18 12:49:52.328527
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "30"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "required"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 1

    content = """
    name: John
    age: "foo"
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:50:04.440716
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert errors == []

    content = """
    name: John Doe
    age: -30
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be greater than or equal to 0.",
            code="minimum",
            position=Position(line_no=3, column_no=5, char_index=19),
        )
    ]


# Generated at 2022-06-18 12:50:12.948844
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """

    value, error_messages = validate_yaml(content, validator=Person)
    assert error_messages == []
    assert value == {"name": "John"}

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, validator=Person)
    assert error_messages == [
        Message(
            text="Additional properties are not allowed ('age' was unexpected).",
            code="additional_properties",
            position=Position(line_no=3, column_no=5, char_index=19),
        )
    ]
    assert value

# Generated at 2022-06-18 12:50:19.919009
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test that validate_yaml returns a two-tuple of (value, error_messages)
    content = "a: 1"
    validator = Field(type="string")
    value, error_messages = validate_yaml(content, validator)
    assert value == "a: 1"
    assert error_messages == [
        Message(
            text="Expected a string.",
            code="type_error.string",
            position=Position(column_no=1, line_no=1, char_index=0),
        )
    ]

# Generated at 2022-06-18 12:50:29.477998
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String, Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "42"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 42}
    assert errors == []

    content = """
    name: John
    age: "forty-two"
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        ValidationError(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=15),
        )
    ]


# Generated at 2022-06-18 12:50:39.358135
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = "name: John"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John\nage: 30"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == [
        Message(
            text="'age' is not a valid field.",
            code="invalid_field",
            position=Position(line_no=2, column_no=1, char_index=10),
        )
    ]


# Generated at 2022-06-18 12:50:59.820029
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """
    value, error_messages = validate_yaml(content, Person)
    assert error_messages == [
        Message(
            text="Expected an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=18),
        )
    ]

    content = """
    name: "John"
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert error_messages == []
    assert value == {"name": "John", "age": 30}

# Generated at 2022-06-18 12:51:08.526381
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert not errors

    content = """
    name:
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "required"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 2



# Generated at 2022-06-18 12:51:17.505551
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        fields={
            "name": Field(type="string"),
            "age": Field(type="integer"),
            "address": Field(type="object", fields={"street": Field(type="string")}),
        }
    )

    content = """
    name: John
    age: 30
    address:
      street: Main Street
    """

    value, errors = validate_yaml(content, schema)
    assert value == {
        "name": "John",
        "age": 30,
        "address": {"street": "Main Street"},
    }
    assert errors == []

    content = """
    name: John
    age: 30
    address:
      street: Main Street
    """

    value, errors = validate_yaml(content, schema)

# Generated at 2022-06-18 12:51:26.374719
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 20
    """

    value, error_messages = validate_yaml(content, Person)

    assert value == {"name": "John", "age": 20}
    assert error_messages == []

    content = """
    name: John
    """

    value, error_messages = validate_yaml(content, Person)

    assert value == {"name": "John"}
    assert error_messages == [
        Message(
            text="Missing required field.",
            code="required",
            position=Position(line_no=3, column_no=1, char_index=14),
        )
    ]

    content = """
    name: John
    age: 20
    """

   

# Generated at 2022-06-18 12:51:32.606292
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"name": Field(type="string")})
    value, errors = validate_yaml(content="name:", validator=schema)
    assert value is None
    assert len(errors) == 1
    assert errors[0].text == "Expected a string."
    assert errors[0].code == "type_error.string"
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 7
    assert errors[0].position.char_index == 6



# Generated at 2022-06-18 12:51:41.123933
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: "John Doe"
    age: "thirty-two"
    """
    value, error_messages = validate_yaml(content, validator=MySchema)
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=20),
        )
    ]
    assert value == {"name": "John Doe", "age": "thirty-two"}



# Generated at 2022-06-18 12:51:50.360172
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(String())

    class Family(Schema):
        parents = Array(Object(Person))
        children = Array(Object(Person))


# Generated at 2022-06-18 12:51:59.704879
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = typing.List[int]
    value, errors = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert errors == []

    content = """
    - 1
    - 2
    - 3
    - "a"
    """
    validator = typing.List[int]
    value, errors = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 5
    assert errors[0].position.column_no == 3



# Generated at 2022-06-18 12:52:08.745134
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    class MySchema(Schema):
        name = String()

    # Test a valid YAML string.
    content = "name: foo"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"name": "foo"}
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "foo"}
    assert not error_messages

    # Test a valid YAML bytestring.
    content = b"name: foo"
    token = tokenize_yaml(content)

# Generated at 2022-06-18 12:52:18.046064
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John Doe"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name:
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="This field is required.",
            code="required",
            position=Position(column_no=3, line_no=2, char_index=4),
        )
    ]

    content = """
    name: 123
    """
    value

# Generated at 2022-06-18 12:52:46.661456
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String

    field = String(max_length=3)
    value, errors = validate_yaml(b"foo", field)
    assert value == "foo"
    assert not errors

    value, errors = validate_yaml(b"foobar", field)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "max_length"
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 1
    assert errors[0].position.char_index == 0

    value, errors = validate_yaml(b"foo\nbar", field)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "max_length"
    assert errors[0].position.line_

# Generated at 2022-06-18 12:52:58.561198
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: 1") == {"a": 1}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("- a\n- b") == ["a", "b"]

# Generated at 2022-06-18 12:53:08.648348
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()

    content = """
    name: "John Doe"
    age: 42
    height: 1.75
    is_adult: true
    """

    value, error_messages = validate_yaml(content, Person)

    assert value == {
        "name": "John Doe",
        "age": 42,
        "height": 1.75,
        "is_adult": True,
    }
    assert error_messages == []



# Generated at 2022-06-18 12:53:13.686920
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Float, Boolean, Array, Object, Any

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        friends = Array(items=Any())
        family = Object(properties={"mother": String(), "father": String()})

    content = """
    name: John
    age: 30
    height: 1.8
    is_adult: true
    friends:
      - Jane
      - Bob
    family:
      mother: Jane
      father: Bob
    """

    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:53:20.193781
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test validator
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        is_active = Field(type="boolean")

    # Test content
    content = """
    name: John
    age: 25
    is_active: true
    """

    # Test validate_yaml
    value, error_messages = validate_yaml(content, TestSchema)
    assert value == {"name": "John", "age": 25, "is_active": True}
    assert error_messages == []



# Generated at 2022-06-18 12:53:29.594867
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert not errors

    content = """
    name: John
    age: thirty
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}
    assert errors == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=17),
        )
    ]


# Generated at 2022-06-18 12:53:41.268211
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert errors == []

    content = """
    name: John
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == [
        Message(
            text="Missing required field 'age'.",
            code="missing_field",
            position=Position(line_no=3, column_no=1, char_index=17),
        )
    ]


# Generated at 2022-06-18 12:53:48.476666
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == {}
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("foo") == "foo"
    assert tokenize_yaml("123") == 123
    assert tokenize_yaml("123.4") == 123.4
    assert tokenize_yaml("true") is True
    assert tokenize_yaml("false") is False
    assert tokenize_yaml("null") is None
    assert tokenize_yaml("{foo: bar}") == {"foo": "bar"}
    assert tokenize_yaml("[foo, bar]") == ["foo", "bar"]
    assert tokenize_yaml("foo: bar") == {"foo": "bar"}

# Generated at 2022-06-18 12:53:59.333272
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:54:08.907330
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = "name: John Doe"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = "name: John Doe\nage: 30"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}

# Generated at 2022-06-18 12:54:33.756881
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

# Generated at 2022-06-18 12:54:44.505755
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = Field(type="array", items=Field(type="integer"))
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == []

    content = """
    - 1
    - 2
    - "3"
    """
    validator = Field(type="array", items=Field(type="integer"))
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, "3"]

# Generated at 2022-06-18 12:54:54.451104
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Boolean
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(max_length=100)
        age = Integer()
        is_active = Boolean()

    content = """
    name: John
    age: 30
    is_active: true
    """

    value, errors = validate_yaml(content, UserSchema)
    assert value == {"name": "John", "age": 30, "is_active": True}
    assert errors == []

    content = """
    name: John
    age: 30
    is_active: true
    extra: field
    """

    value, errors = validate_yaml(content, UserSchema)

# Generated at 2022-06-18 12:54:59.698607
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 42
    """
    validator = Schema(
        name=Field(type="string"),
        age=Field(type="integer"),
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert errors == []



# Generated at 2022-06-18 12:55:11.600472
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: -1
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "minimum"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5

    content = """
    name: John
    age: 30
    """

    value,