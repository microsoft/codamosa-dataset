

# Generated at 2022-06-18 12:45:29.214762
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo:
      bar: 1
      baz: 2
    """
    schema = Schema(
        {
            "foo": {
                "bar": Field(int),
                "baz": Field(int),
            }
        }
    )
    value, error_messages = validate_yaml(content, schema)
    assert value == {"foo": {"bar": 1, "baz": 2}}
    assert error_messages == []

    content = """
    foo:
      bar: 1
      baz: 2
    """
    schema = Schema(
        {
            "foo": {
                "bar": Field(int),
                "baz": Field(str),
            }
        }
    )
    value, error_messages = validate_yaml(content, schema)
   

# Generated at 2022-06-18 12:45:35.949544
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:45:42.603077
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {'key': 'value'}
    assert tokenize_yaml("[]") == ['value']
    assert tokenize_yaml("value") == 'value'
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None


# Generated at 2022-06-18 12:45:50.844332
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")


# Generated at 2022-06-18 12:46:01.827425
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:46:08.153600
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("- a\n- b") == ["a", "b"]

# Generated at 2022-06-18 12:46:20.413969
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("- a\n- b") == ["a", "b"]
    assert tokenize_yaml("- a\n- b\n")

# Generated at 2022-06-18 12:46:31.537389
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    a: 1
    b: 2
    """
    validator = Schema({"a": int, "b": int})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"a": 1, "b": 2}
    assert error_messages == []

    content = """
    a: 1
    b: 2
    c: 3
    """
    validator = Schema({"a": int, "b": int})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:46:41.964216
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test validating a YAML string against a Field.
    field = Field(type="string")
    value, error_messages = validate_yaml(content="foo", validator=field)
    assert value == "foo"
    assert error_messages == []

    value, error_messages = validate_yaml(content="123", validator=field)
    assert value is None
    assert error_messages == [
        Message(
            text="Expected a string.",
            code="type_error.string",
            position=Position(column_no=1, line_no=1, char_index=0),
        )
    ]

    # Test validating a YAML string against a Schema.
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

# Generated at 2022-06-18 12:46:52.509426
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        is_active = Boolean()

    class Address(Schema):
        street = String(max_length=100)
        city = String(max_length=100)
        zip_code = String(max_length=10)

    class Company(Schema):
        name = String(max_length=100)
        address = Object(Address)

# Generated at 2022-06-18 12:47:09.056748
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: John Doe
    age: "30"
    """
    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name": "John Doe", "age": 30}
    assert errors == []

    content = """
    name: John Doe
    age: "thirty"
    """
    value, errors = validate_yaml(content, PersonSchema)
    assert value is None

# Generated at 2022-06-18 12:47:17.939218
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert not errors

    content = """
    name: John
    age: thirty
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(
                line_no=3, column_no=5, char_index=len("name: John\n") + 1
            ),
        )
    ]


# Generated at 2022-06-18 12:47:29.025035
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="invalid",
            position=Position(
                line_no=2, column_no=6, char_index=content.index("123")
            ),
        )
    ]


# Generated at 2022-06-18 12:47:38.959801
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    age: 20
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}

# Generated at 2022-06-18 12:47:45.024612
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = """
    foo: bar
    baz:
      - qux
      - quux
    """
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar", "baz": ["qux", "quux"]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content



# Generated at 2022-06-18 12:47:55.996520
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: "John Doe"
    """

    token = tokenize_yaml(content)
    value, error_messages = validate_with_positions(token=token, validator=Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: "John Doe"
    age: 30
    """

    token = tokenize_yaml(content)
    value, error_messages = validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:48:05.625056
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test that a valid YAML string is parsed and validated correctly.
    content = """
    name: John Smith
    age: 25
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Smith", "age": 25}
    assert error_messages == []

    # Test that an invalid YAML string is parsed and validated correctly.
    content = """
    name: John Smith
    age: 25
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
            "gender": Field(str),
        }
    )
    value,

# Generated at 2022-06-18 12:48:17.312798
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test a valid YAML string
    content = "name: John Doe"
    validator = Field(name="name", type="string")
    value, error_messages = validate_yaml(content, validator)
    assert value == "John Doe"
    assert error_messages == []

    # Test an invalid YAML string
    content = "name: John Doe"
    validator = Field(name="name", type="integer")
    value, error_messages = validate_yaml(content, validator)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be an integer."
    assert error_messages[0].code == "invalid_type"
    assert error_messages[0].position.line_no == 1

# Generated at 2022-06-18 12:48:22.268677
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:48:34.125728
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        content="""
        name: John
        age: 20
        """,
        validator=Schema(
            {
                "name": Field(type="string"),
                "age": Field(type="integer"),
            }
        ),
    ) == ({'name': 'John', 'age': 20}, [])


# Generated at 2022-06-18 12:48:49.137004
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: 'John'
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert not errors

    content = """
    name: 'John'
    age: '20'
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert len(errors) == 1
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 1
    assert errors[0].position.char_index == 14

# Generated at 2022-06-18 12:48:59.403324
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, errors = validate_yaml(content, validator=Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: 123
    """
    value, errors = validate_yaml(content, validator=Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be a string.",
            code="invalid",
            position=Position(line_no=2, column_no=6, char_index=11),
        )
    ]

    content = """
    name: "John"
    age: 30
    """
   

# Generated at 2022-06-18 12:49:10.800452
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert not errors

    content = """
    name:
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "required"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 4

    content = """
    name: John
    age: 20
    """

    value, errors = validate_yaml(content, Person)
    assert value is None

# Generated at 2022-06-18 12:49:22.702261
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}

# Generated at 2022-06-18 12:49:26.878553
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo:
      - bar
      - baz
    """
    validator = Schema({"foo": [str]})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"foo": ["bar", "baz"]}
    assert error_messages == []



# Generated at 2022-06-18 12:49:32.219791
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0)

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: -30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": -30}
    assert errors == [
        ValidationError(
            text="Must be greater than or equal to 0.",
            code="minimum",
            position=Position(line_no=3, column_no=5, char_index=17),
        )
    ]

    content

# Generated at 2022-06-18 12:49:43.198323
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()

    # Valid YAML
    content = """
    name: John
    age: 30
    height: 1.8
    is_active: true
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 30,
        "height": 1.8,
        "is_active": True,
    }
    assert error_messages == []

    # Invalid YAML

# Generated at 2022-06-18 12:49:53.715938
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)

    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: "John"
    age: "thirty"
    """

    value, error_messages = validate_yaml(content, Person)

    assert value is None

# Generated at 2022-06-18 12:49:57.127302
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("""
    a: 1
    b: 2
    c: 3
    """) == {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-18 12:50:04.290331
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - a: 1
    - b: 2
    - c: 3
    """
    validator = typing.List[typing.Dict[str, int]]
    value, error_messages = validate_yaml(content, validator)
    assert value == [{"a": 1}, {"b": 2}, {"c": 3}]
    assert error_messages == []



# Generated at 2022-06-18 12:50:15.120657
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(max_length=10)

    content = "name: Hello World"
    value, errors = validate_yaml(content, validator=MySchema)
    assert errors[0].text == "Must have no more than 10 characters."
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 6
    assert errors[0].position.char_index == 6



# Generated at 2022-06-18 12:50:24.996490
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String()
        age = Integer()
        height = Float()

    content = """
    name: John
    age: 30
    height: 1.8
    """

    value, errors = validate_yaml(content, validator=TestSchema)
    assert value == {"name": "John", "age": 30, "height": 1.8}
    assert errors == []

    content = """
    name: John
    age: 30
    height: 1.8
    """

    value, errors = validate_yaml(content, validator=TestSchema)
    assert value == {"name": "John", "age": 30, "height": 1.8}

# Generated at 2022-06-18 12:50:34.686021
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String(max_length=10)

    content = """
    name: "John Doe"
    """
    value, errors = validate_yaml(content, TestSchema)
    assert value == {"name": "John Doe"}
    assert errors == []

    content = """
    name: "John Doe"
    """
    value, errors = validate_yaml(content, String(max_length=5))
    assert value is None
    assert errors == [
        ValidationError(
            text="Must have no more than 5 characters.",
            code="max_length",
            position=Position(line_no=2, column_no=7, char_index=11),
        )
    ]



# Generated at 2022-06-18 12:50:45.467842
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert not errors

    content = """
    name: John
    age: -30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": -30}

# Generated at 2022-06-18 12:50:55.620361
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []

    content = """
    name: John Doe
    age: -30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": -30}

# Generated at 2022-06-18 12:51:06.053459
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=100)

    content = """
    name: John
    age: 25
    """
    value, error_messages = validate_yaml(content, UserSchema)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """
    value, error_messages = validate_yaml(content, UserSchema)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []


# Generated at 2022-06-18 12:51:15.390743
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """

# Generated at 2022-06-18 12:51:20.336988
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = String(max_length=100)
        age = Integer()

    content = """
    name: John Doe
    age: 42
    """

    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []



# Generated at 2022-06-18 12:51:28.484015
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = "name: John"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John\nage: 30"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == [
        Message(
            text="'age' is not a valid field.",
            code="invalid_field",
            position=Position(line_no=2, column_no=1, char_index=8),
        )
    ]


# Generated at 2022-06-18 12:51:38.607964
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=4, char_index=14),
        )
    ]


# Generated at 2022-06-18 12:51:52.147080
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0)
        is_active = Boolean()

    yaml_content = """
    name: John Doe
    age: 32
    height: 1.75
    is_active: true
    """

    value, error_messages = validate_yaml(yaml_content, Person)

# Generated at 2022-06-18 12:52:01.813538
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 43
    """
    validator = Schema(
        {"name": str, "age": int}
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 43}
    assert errors == []

    content = """
    name: John Doe
    age: forty-three
    """
    validator = Schema(
        {"name": str, "age": int}
    )
    value, errors = validate_yaml(content, validator)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5



# Generated at 2022-06-18 12:52:10.467252
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = "name: John Doe\nage: 42"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert errors == []

    content = "name: John Doe\nage: -42"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": -42}
    assert errors == [
        ValidationError(
            text="Must be greater than or equal to 0.",
            code="min_value",
            position=Position(line_no=2, column_no=5, char_index=14),
        )
    ]



# Generated at 2022-06-18 12:52:20.146295
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    content = """
    name: foo
    """
    value, errors = validate_yaml(content, MySchema)
    assert value == {"name": "foo"}
    assert errors == []

    content = """
    name: foo
    """
    value, errors = validate_yaml(content, MySchema(required=["name"]))
    assert value == {"name": "foo"}
    assert errors == []

    content = """
    name: foo
    """
    value, errors = validate_yaml(content, MySchema(required=["age"]))
    assert value == {"name": "foo"}

# Generated at 2022-06-18 12:52:27.568129
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "20"
    """

    value, errors = validate_yaml(content, Person)
    assert errors == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(
                line_no=3, column_no=5, char_index=content.index("20")
            ),
        )
    ]

# Generated at 2022-06-18 12:52:38.572282
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: John Doe
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: John Doe
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: John Doe
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

# Generated at 2022-06-18 12:52:44.131416
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(items=String())
        spouse = Object(properties={"name": String()})

    content = """
    name: John Doe
    age: 42
    height: 1.75
    is_adult: true
    children:
        - Jane
        - Joe
    spouse:
        name: Jane Doe
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:52:55.417066
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class MySchema(Schema):
        name = String()

    content = """
    name: 'John'
    """

    token = tokenize_yaml(content)
    value, error_messages = validate_with_positions(token=token, validator=MySchema)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 'John'
    age: '30'
    """

    token = tokenize_yaml(content)
    value, error_messages = validate_with_positions(token=token, validator=MySchema)

# Generated at 2022-06-18 12:52:59.196059
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: bar
    """
    validator = Field(type="string")
    value, errors = validate_yaml(content, validator)
    assert value == "bar"
    assert errors == []



# Generated at 2022-06-18 12:53:11.197729
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    content = "name: 'John'"
    value, errors = validate_yaml(content, validator=MySchema)
    assert value == {"name": "John"}
    assert not errors

    content = "name: 'John"
    value, errors = validate_yaml(content, validator=MySchema)
    assert value is None
    assert len(errors) == 1
    assert errors[0].text == "could not find expected ':'."
    assert errors[0].code == "parse_error"
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 8

# Generated at 2022-06-18 12:53:21.944399
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:53:30.819319
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Boolean, Array, Object

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        is_active = Boolean()

    class People(Schema):
        people = Array(items=Person)

    content = """
    people:
    - name: John
      age: 30
      is_active: true
    - name: Jane
      age: 25
      is_active: false
    """

    value, errors = validate_yaml(content, People)

    assert value == {
        "people": [
            {"name": "John", "age": 30, "is_active": True},
            {"name": "Jane", "age": 25, "is_active": False},
        ]
    }
    assert errors

# Generated at 2022-06-18 12:53:42.712600
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []

    content = """
    name: John Doe
    age: -1
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": -1}

# Generated at 2022-06-18 12:53:49.198456
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []


# Generated at 2022-06-18 12:53:59.935162
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "30"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: "thirty"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5


# Generated at 2022-06-18 12:54:10.453523
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - foo
    - bar
    """
    validator = Field(type="string", max_length=3)
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == [
        Message(
            text="Must have no more than 3 characters.",
            code="max_length",
            position=Position(line_no=3, column_no=5, char_index=15),
        )
    ]

    content = """
    - foo
    - bar
    """
    validator = Field(type="string", max_length=3)
    value, error_messages = validate_yaml(content, validator)

# Generated at 2022-06-18 12:54:19.935937
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(String())
        spouse = Object(Person)

    content = """
    name: John
    age: 35
    height: 1.75
    is_adult: true
    children:
      - John Jr.
      - Jane
    spouse:
      name: Jane
      age: 32
      height: 1.68
      is_adult: true
      children: []
      spouse:
        name: John
        age: 35
        height: 1.75
        is_adult: true
        children: []
        spouse:
    """

    value

# Generated at 2022-06-18 12:54:25.895806
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 42
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, errors = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert not errors



# Generated at 2022-06-18 12:54:36.210707
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = typing.List[int]
    value, errors = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert errors == []

    content = """
    - 1
    - 2
    - 3
    - "a"
    """
    validator = typing.List[int]
    value, errors = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert errors == [
        ValidationError(
            text="Value 'a' is not a valid integer.",
            code="invalid_type",
            position=Position(line_no=4, column_no=4, char_index=20),
        )
    ]


# Generated at 2022-06-18 12:54:46.800776
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    class Person(Schema):
        name = String()
        age = Integer()

    value, error_messages = validate_yaml(content, Person)
    assert error_messages == []
    assert value == {"name": "John", "age": 30}

    content = """
    name: John
    age: 30
    """
    class Person(Schema):
        name = String()
        age = Integer()

    value, error_messages = validate_yaml(content, Person)
    assert error_messages == []
    assert value == {"name": "John", "age": 30}

    content = """
    name: John
    age: 30
    """
    class Person(Schema):
        name = String()
        age = Integer()

# Generated at 2022-06-18 12:55:02.605082
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    content = """
    name: "foo"
    """
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "foo"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "123"}
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="type_error.string",
            position=Position(line_no=2, column_no=8, char_index=11),
        )
    ]

   

# Generated at 2022-06-18 12:55:13.555360
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()

    # Test valid YAML
    value, errors = validate_yaml(
        content="""
        name: John Doe
        age: 42
        height: 1.75
        is_cool: true
        """,
        validator=Person,
    )
    assert value == {
        "name": "John Doe",
        "age": 42,
        "height": 1.75,
        "is_cool": True,
    }
    assert errors == []

    # Test invalid YAML