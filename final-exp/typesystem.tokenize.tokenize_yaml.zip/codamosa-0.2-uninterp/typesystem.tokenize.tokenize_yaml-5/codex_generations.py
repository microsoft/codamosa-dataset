

# Generated at 2022-06-18 12:45:19.893699
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:45:31.533915
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:45:41.598598
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()

    content = """
    name: John
    age: 25
    height: 1.75
    """

    value, error_messages = validate_yaml(content, Person)

    assert value == {"name": "John", "age": 25, "height": 1.75}
    assert error_messages == []

    content = """
    name: John
    age: 25
    height: 1.75
    """

    value, error_messages = validate_yaml(content, Person)

    assert value == {"name": "John", "age": 25, "height": 1.75}

# Generated at 2022-06-18 12:45:50.180248
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("{a: 1}") == {"a": 1}
    assert tokenize_yaml("[1, 2]") == [1, 2]
    assert tokenize_yaml("{a: 1, b: 2}") == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:46:01.404099
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:46:11.869131
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = "name: foo"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "foo"}
    assert error_messages == []

    content = "name: foo\nage: 20"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "foo"}
    assert error_messages == [
        Message(
            text="'age' is not a valid field.",
            code="invalid_field",
            position=Position(line_no=2, column_no=1, char_index=9),
        )
    ]


# Generated at 2022-06-18 12:46:24.293859
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:46:35.016055
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:46:43.893068
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(String())
        spouse = Object(Person)

    content = """
    name: John Doe
    age: 42
    height: 1.83
    is_adult: true
    children:
      - Jane Doe
      - John Doe Jr.
    spouse:
      name: Jane Doe
      age: 40
      height: 1.75
      is_adult: true
      children: []
      spouse: null
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:46:49.515214
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name:
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="This field is required.",
            code="required",
            position=Position(line_no=2, column_no=2, char_index=6),
        )
    ]

    content = """
    name: John
    age: 30
    """
   

# Generated at 2022-06-18 12:47:03.115493
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """
    value, errors = validate_yaml(content, Person)
    assert errors == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=20),
        )
    ]

    content = """
    name: "John"
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert errors == []

    content = """
    name: "John"
    age: 30
    """
    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:47:13.279685
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 42
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 42}
    assert error_messages == []

    content = """
    name: John
    age: forty-two
    """
    value, error_messages = validate_yaml(content, Person)
    assert value is None

# Generated at 2022-06-18 12:47:20.365302
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test validate_yaml function
    """
    # Test for invalid YAML
    with pytest.raises(ParseError):
        validate_yaml("{", "string")

    # Test for valid YAML
    value, error_messages = validate_yaml("{}", "string")
    assert value == {}
    assert error_messages == []

    # Test for valid YAML with error messages
    value, error_messages = validate_yaml("{}", "integer")
    assert value == {}
    assert len(error_messages) == 1
    assert error_messages[0].text == "Expected an integer."
    assert error_messages[0].code == "type_error.integer"
    assert error_messages[0].position.line_no == 1
    assert error

# Generated at 2022-06-18 12:47:27.083725
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:47:35.387473
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    content = "name: foo"
    value, error_messages = validate_yaml(content, validator=MySchema)
    assert value == {"name": "foo"}
    assert error_messages == []

    content = "name: foo\nname: bar"
    value, error_messages = validate_yaml(content, validator=MySchema)
    assert value == {"name": "foo"}

# Generated at 2022-06-18 12:47:44.154663
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name:
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="This field is required.",
            code="required",
            position=Position(line_no=2, column_no=2, char_index=6),
        )
    ]



# Generated at 2022-06-18 12:47:52.344378
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: John
    """

    token = tokenize_yaml(content)
    value, error_messages = validate_with_positions(token=token, validator=Person)

    assert value == {"name": "John"}
    assert error_messages == []



# Generated at 2022-06-18 12:48:02.281597
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")
    assert tokenize_yaml("foo") == Scal

# Generated at 2022-06-18 12:48:12.760859
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=120)
        height = Float()
        alive = Boolean()

    content = """
    name: John
    age: 30
    height: 1.8
    alive: true
    """
    value, errors = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 30,
        "height": 1.8,
        "alive": True,
    }
    assert not errors


# Generated at 2022-06-18 12:48:23.555256
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="invalid",
            position=Position(line_no=2, column_no=6, char_index=10),
        )
    ]



# Generated at 2022-06-18 12:48:37.408141
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test validator
    class TestSchema(Schema):
        name = "TestSchema"
        fields = [
            Field(name="name", type="string"),
            Field(name="age", type="integer"),
            Field(name="is_active", type="boolean"),
        ]

    # Test valid YAML
    valid_yaml = """
    name: John Doe
    age: 42
    is_active: true
    """
    value, errors = validate_yaml(valid_yaml, TestSchema)
    assert not errors
    assert value == {"name": "John Doe", "age": 42, "is_active": True}

    # Test invalid YAML
    invalid_yaml = """
    name: John Doe
    age: 42
    is_active: true
    foo: bar
    """

# Generated at 2022-06-18 12:48:48.553575
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(items=Object(Person))

    content = """
    name: John
    age: 30
    height: 1.8
    is_adult: true
    children:
      - name: Alice
        age: 3
        height: 0.8
        is_adult: false
        children: []
      - name: Bob
        age: 5
        height: 1.0
        is_adult: false
        children: []
    """
    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:48:58.716891
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []

    content = """
    name: "John Doe"
    age: "30"
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": "30"}
    assert error

# Generated at 2022-06-18 12:49:10.306482
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert errors == []

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert errors == []

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert errors == []


# Generated at 2022-06-18 12:49:22.065306
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=150)
        friends = Array(items=String())
        alive = Boolean()

    content = """
    name: John
    age: 30
    friends:
      - Bob
      - Alice
    alive: true
    """

    value, errors = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 30,
        "friends": ["Bob", "Alice"],
        "alive": True,
    }
    assert errors == []


# Generated at 2022-06-18 12:49:30.889058
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        children = Array(items=Object(Person))

    content = """
    name: John
    age: 35
    height: 1.75
    is_adult: true
    children:
      - name: Mary
        age: 5
        height: 0.5
        is_adult: false
        children: []
      - name: Jane
        age: 7
        height: 0.6
        is_adult: false
        children: []
    """

    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:49:42.206121
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: Jane
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "Jane", "age": 25}
    assert errors == []

    content = """
    name: Jane
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "Jane", "age": 25}
    assert errors == []

    content = """
    name: Jane
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "Jane", "age": 25}
    assert errors == []

# Generated at 2022-06-18 12:49:52.893041
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken, Token

    class Person(Schema):
        name = fields.String()
        age = fields.Integer()

    class Family(Schema):
        members = fields.List(fields.Nested(Person))

    class Family2(Schema):
        members = fields.List(fields.Nested(Person))

    class Family3(Schema):
        members = fields.List(fields.Nested(Person))

    class Family4(Schema):
        members = fields.List(fields.Nested(Person))

    class Family5(Schema):
        members = fields.List(fields.Nested(Person))



# Generated at 2022-06-18 12:50:03.971955
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """

    value, errors = validate_yaml(content, Person)
    assert errors == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=20),
        )
    ]

    content = """
    name: "John"
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert errors == []
    assert value == {"name": "John", "age": 30}



# Generated at 2022-06-18 12:50:12.579632
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:50:20.405964
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = Field(type="array", items=Field(type="integer"))
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == []



# Generated at 2022-06-18 12:50:29.959928
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = "name: John"

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John Doe"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == [
        Message(
            text="Must have no more than 10 characters.",
            code="max_length",
            position=Position(line_no=1, column_no=6, char_index=5),
        )
    ]


# Generated at 2022-06-18 12:50:39.697100
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import (
        get_error_messages,
        get_value,
    )

    class MySchema(Schema):
        name = String()

    content = """
    name: "foo"
    """
    value, error_messages = validate_yaml(content, validator=MySchema)
    assert get_value(value) == {"name": "foo"}
    assert get_error_messages(error_messages) == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, validator=MySchema)
    assert get_value(value) == {"name": "123"}
    assert get_error

# Generated at 2022-06-18 12:50:51.368083
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:51:01.411394
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        friends = Array(items=Object(Person))

    content = """
    name: John
    age: 20
    height: 1.8
    is_adult: true
    friends:
      - name: Jane
        age: 22
        height: 1.7
        is_adult: true
        friends: []
      - name: Bob
        age: 18
        height: 1.9
        is_adult: false
        friends: []
    """

    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:51:11.049306
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array, Boolean
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()
        friends = Array(items=String())
        is_cool = Boolean()

    content = """
    name: "John"
    age: 30
    friends:
      - "Jane"
      - "Bob"
    is_cool: true
    """

    value, errors = validate_yaml(content, MySchema)
    assert value == {
        "name": "John",
        "age": 30,
        "friends": ["Jane", "Bob"],
        "is_cool": True,
    }
    assert errors == []


# Generated at 2022-06-18 12:51:20.413773
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    class Person(Schema):
        name = String()
        age = Integer()

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: thirty
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 4

    content = """
    name: John
    age: 30
    """

# Generated at 2022-06-18 12:51:28.547117
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test valid YAML
    content = """
    - 1
    - 2
    - 3
    """
    validator = typing.List[int]
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == []

    # Test invalid YAML
    content = """
    - 1
    - 2
    - 3
    - "4"
    """
    validator = typing.List[int]
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3, "4"]

# Generated at 2022-06-18 12:51:38.700961
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Dict
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(String())
        other_info = Dict(String())

    yaml_content = """
    name: "John"
    age: 30
    height: 1.8
    is_cool: true
    friends:
      - "Jane"
      - "Bob"
    other_info:
      favorite_color: "blue"
      favorite_food: "pizza"
    """

    value, error_messages = validate_yaml(yaml_content, Person)
    assert error_messages == []

# Generated at 2022-06-18 12:51:48.641582
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test for valid input
    content = """
    name: John Doe
    age: 42
    """
    validator = Schema(
        {"name": str, "age": int}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

    # Test for invalid input
    content = """
    name: John Doe
    age: forty-two
    """
    validator = Schema(
        {"name": str, "age": int}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": "forty-two"}

# Generated at 2022-06-18 12:52:01.813505
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0)
        is_active = Boolean()
        friends = Array(items=String(max_length=10))
        address = Object(properties={"city": String(max_length=10)})

    # Valid YAML

# Generated at 2022-06-18 12:52:10.498173
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean, Object, Schema

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        friends = Array(items=Object(Person))
        alive = Boolean()

    content = """
    name: John
    age: 30
    friends:
        - name: Jane
          age: 25
          friends: []
          alive: true
        - name: Bob
          age: 35
          friends: []
          alive: true
    alive: true
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:52:15.610803
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John"
    age: 30
    """
    class PersonSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=18, maximum=99)

    value, error_messages = validate_yaml(content, PersonSchema)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:52:26.696365
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Expected a string.",
            code="invalid",
            position=Position(line_no=2, column_no=7, char_index=11),
        )
    ]

    content = """
    name: "John"
    age: 30
    """
    value, errors = validate_

# Generated at 2022-06-18 12:52:37.746348
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("{}") == DictToken({}, 0, 1)
    assert tokenize_yaml("[]") == ListToken([], 0, 1)
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1)
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3)
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4)
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5)
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4)
    assert tokenize_yaml("a") == ScalarToken("a", 0, 1)

# Generated at 2022-06-18 12:52:43.478008
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "30"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert not errors

    content = """
    name: John
    age: "thirty"
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5



# Generated at 2022-06-18 12:52:54.884432
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
   

# Generated at 2022-06-18 12:53:05.500731
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Dict

    class MySchema(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(items=String())
        address = Dict(properties={"city": String(), "state": String()})

    content = """
    name: John
    age: 25
    height: 5.5
    is_cool: true
    friends:
      - Jane
      - Bob
    address:
      city: New York
      state: NY
    """

    value, errors = validate_yaml(content, MySchema)

# Generated at 2022-06-18 12:53:17.959202
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert not errors

    content = """
    name: John Doe
    age: -1
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be greater than or equal to 0.",
            code="minimum",
            position=Position(line_no=3, column_no=5, char_index=19),
        )
    ]


# Generated at 2022-06-18 12:53:23.246594
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:53:36.118095
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: -30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be greater than or equal to 0.",
            code="minimum",
            position=Position(line_no=3, column_no=5, char_index=18),
        )
    ]

# Generated at 2022-06-18 12:53:45.595079
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert not errors

    content = """
    name: John Doe
    age: -30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": -30}

# Generated at 2022-06-18 12:53:53.929864
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = "string"
        age = "integer"

    content = """
    name: "John"
    age: "30"
    """

    value, errors = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": 30}
    assert errors == [
        Message(
            text="Value must be of type 'integer'.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=17),
        )
    ]

# Generated at 2022-06-18 12:54:03.281604
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, DateTime, Array, Object
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=130)
        height = Float(minimum=0)
        active = Boolean()
        created = DateTime()
        friends = Array(items=Object(properties={"name": String()}))

    content = """
    name: John
    age: 30
    height: 1.75
    active: true
    created: 2019-01-01T12:00:00Z
    friends:
      - name: Jane
      - name: Bob
    """

    value, error_messages = validate_yaml(content, UserSchema)
    assert error_mess

# Generated at 2022-06-18 12:54:14.764834
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("a: b") == {'a': 'b'}
    assert tokenize_yaml("a: b\nc: d") == {'a': 'b', 'c': 'd'}
    assert tokenize_yaml("a: [1, 2, 3]") == {'a': [1, 2, 3]}
    assert tokenize_yaml("a: 1") == {'a': 1}
    assert tokenize_yaml("a: 1.0") == {'a': 1.0}
    assert tokenize_yaml("a: true") == {'a': True}
    assert tokenize_yaml("a: false") == {'a': False}

# Generated at 2022-06-18 12:54:25.070324
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test for valid input
    content = """
    name: John Doe
    age: 43
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 43}
    assert messages == []

    # Test for invalid input
    content = """
    name: John Doe
    age: forty-three
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": "forty-three"}

# Generated at 2022-06-18 12:54:35.669511
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Boolean, Array, Object

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0)
        is_active = Boolean()

    class People(Schema):
        people = Array(items=Person)

    content = """
    people:
    - name: John
      age: 30
      is_active: true
    - name: Jane
      age: -1
      is_active: false
    """

    value, error_messages = validate_yaml(content, People)


# Generated at 2022-06-18 12:54:46.174847
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: "John Doe"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = """
    name: "John Doe"
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe"}

# Generated at 2022-06-18 12:54:50.574119
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: John Doe\nage: 42"
    validator = Schema(
        {"name": str, "age": int}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []



# Generated at 2022-06-18 12:55:00.054663
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = b"name: 'John'"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = b"name: 'John Doe'"
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must have no more than 10 characters.",
            code="max_length",
            position=Position(line_no=1, column_no=6, char_index=5),
        )
    ]



# Generated at 2022-06-18 12:55:13.492842
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "30"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: "thirty"
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Value must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=18),
        )
    ]
