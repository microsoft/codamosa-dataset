

# Generated at 2022-06-18 12:45:27.669558
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    - name: John
      age: 20
    - name: Jane
      age: 21
    '''
    validator = Schema(
        fields={
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == [
        {"name": "John", "age": 20},
        {"name": "Jane", "age": 21},
    ]
    assert error_messages == []



# Generated at 2022-06-18 12:45:39.251732
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0)
        is_active = Boolean()

    class People(Schema):
        people = Array(items=Person())

    class PeopleObject(Schema):
        people = Object(properties={"person": Person()})

    class PeopleObjectWithRequired(Schema):
        people = Object(properties={"person": Person()}, required=["person"])

    class PeopleObjectWithAdditionalProperties(Schema):
        people = Object(properties={"person": Person()}, additional_properties=True)


# Generated at 2022-06-18 12:45:45.610837
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:45:52.778985
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test valid YAML
    content = """
    name: John
    age: 30
    """
    class Person(Schema):
        name = String()
        age = Integer()
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    # Test invalid YAML
    content = """
    name: John
    age: 30
    """
    class Person(Schema):
        name = String()
        age = Integer(minimum=40)
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}

# Generated at 2022-06-18 12:46:03.484664
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:46:15.360046
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """

    value, error_messages = validate_yaml(content, validator=Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, validator=Person)
    assert value == {"name": "John", "age": 30}

# Generated at 2022-06-18 12:46:26.912596
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}

# Generated at 2022-06-18 12:46:37.809800
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """

# Generated at 2022-06-18 12:46:45.668293
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:46:57.194980
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    content = """
    name: Jane
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "Jane", "age": 30}
    assert error_messages == []

    content = """
    name: Jane
    age: -1
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "Jane", "age": -1}

# Generated at 2022-06-18 12:47:10.833691
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = "name: John"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert not errors

    content = "name: John\nage: 30"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert len(errors) == 1
    assert errors[0].code == "unknown_field"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 1

    content = "name: John\nage: 30"
    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:47:19.131285
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Boolean, Float, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        is_active = Boolean()

    class Address(Schema):
        street = String()
        city = String()
        state = String()
        zipcode = Integer()

    class Company(Schema):
        name = String()
        address = Object(Address)

    class PersonSchema(Schema):
        name = String()
        age = Integer()
        is_active = Boolean()
        company = Object(Company)
        addresses = Array(Object(Address))


# Generated at 2022-06-18 12:47:29.731569
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "30"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: "thirty"
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=19),
        )
    ]


# Generated at 2022-06-18 12:47:37.416037
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: thirty
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="Must be a valid integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=13),
        )
    ]

    content = """
    name: John
    age: 30
    """

    value

# Generated at 2022-06-18 12:47:49.149504
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.1") == ScalarToken(1.1, 0, 2, content="1.1")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:47:59.251440
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test valid YAML
    content = "name: John Doe"
    validator = Schema({"name": String()})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    # Test invalid YAML
    content = "name: John Doe\nage: "
    validator = Schema({"name": String(), "age": Integer()})
    value, error_messages = validate_yaml(content, validator)
    assert value is None
    assert error_messages == [
        Message(
            text="Expected an integer.",
            code="invalid",
            position=Position(line_no=2, column_no=6, char_index=12),
        )
    ]

    #

# Generated at 2022-06-18 12:48:03.048020
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 42
    """
    class Person(Schema):
        name = String()
        age = Integer()

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []



# Generated at 2022-06-18 12:48:14.423022
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test valid YAML
    valid_yaml = """
    name: John Doe
    age: 42
    """
    class PersonSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)

    value, error_messages = validate_yaml(valid_yaml, PersonSchema)
    assert value == {'name': 'John Doe', 'age': 42}
    assert error_messages == []

    # Test invalid YAML
    invalid_yaml = """
    name: John Doe
    age: 42
    """
    class PersonSchema(Schema):
        name = Field(type=str)
        age = Field(type=str)

    value, error_messages = validate_yaml(invalid_yaml, PersonSchema)

# Generated at 2022-06-18 12:48:24.982375
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = "name: John"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = "name: John\nage: 30"
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == [
        ValidationError(
            text="Additional properties are not allowed ('age' was unexpected).",
            code="additional_properties",
            position=Position(line_no=2, column_no=1, char_index=10),
        )
    ]

    content = "name: John\nage: 30"
    value

# Generated at 2022-06-18 12:48:35.653260
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test a simple case
    content = "name: John"
    validator = Schema({"name": String()})
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John"}
    assert error_messages == []

    # Test a case with an error
    content = "name: John"
    validator = Schema({"name": Integer()})
    value, error_messages = validate_yaml(content, validator)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be an integer."
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 6

# Generated at 2022-06-18 12:48:49.136547
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test a valid YAML string
    content = """
    name: John Doe
    age: 42
    """
    validator = Schema(
        {"name": "string", "age": "integer"},
        error_messages={"required": "This field is required."},
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

    # Test an invalid YAML string
    content = """
    name: John Doe
    age: 42
    """
    validator = Schema(
        {"name": "string", "age": "integer"},
        error_messages={"required": "This field is required."},
    )
    value, error_messages = validate_yaml

# Generated at 2022-06-18 12:48:59.402405
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:49:10.799615
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array, Boolean
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        friends = Array(items=String(max_length=100))
        active = Boolean()

    content = """
    name: "John Doe"
    age: "30"
    friends:
        - "Jane Doe"
        - "Bob Smith"
    active: true
    """

    value, error_messages = validate_yaml(content, UserSchema)
    assert value == {
        "name": "John Doe",
        "age": 30,
        "friends": ["Jane Doe", "Bob Smith"],
        "active": True,
    }
    assert error

# Generated at 2022-06-18 12:49:17.694409
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: "John"
    age: "20"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "20"}
    assert error_messages == []



# Generated at 2022-06-18 12:49:27.840789
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, errors = validate_yaml(content, PersonSchema)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: 123
    """
    value, errors = validate_yaml(content, PersonSchema)
    assert value is None
    assert errors == [
        ValidationError(
            text="Must be a string.",
            code="invalid",
            position=Position(line_no=2, column_no=7, char_index=15),
        )
    ]

    content = """
    name: "John"
    age: 123
    """

# Generated at 2022-06-18 12:49:33.056780
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: -30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": -30}

# Generated at 2022-06-18 12:49:43.956720
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(max_length=10)

    content = "name: 'John Doe'"
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    content = "name: 'John Doe is a very long name'"
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"name": "John Doe is a very long name"}

# Generated at 2022-06-18 12:49:54.259017
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="invalid",
            position=Position(line_no=3, column_no=5, char_index=19),
        )
    ]


# Generated at 2022-06-18 12:50:06.584083
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()

    class Family(Schema):
        members = Array(items=Person)

    class Family2(Schema):
        members = Array(items=Person)

    class Family3(Schema):
        members = Array(items=Person)

    class Family4(Schema):
        members = Array(items=Person)

    class Family5(Schema):
        members = Array(items=Person)

    class Family6(Schema):
        members = Array(items=Person)

    class Family7(Schema):
        members = Array(items=Person)


# Generated at 2022-06-18 12:50:12.629679
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: "John"
      age: 30
    - name: "Jane"
      age: 20
    """
    validator = Schema(
        fields=[
            Field(name="name", type="string"),
            Field(name="age", type="integer"),
        ]
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == [
        {"name": "John", "age": 30},
        {"name": "Jane", "age": 20},
    ]
    assert error_messages == []



# Generated at 2022-06-18 12:50:20.251072
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 25
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John", "age": 25}
    assert error_messages == []



# Generated at 2022-06-18 12:50:29.790482
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"name": String()})
    value, errors = validate_yaml(
        content=b"name: 'John Doe'", validator=schema
    )
    assert value == {"name": "John Doe"}
    assert errors == []

    value, errors = validate_yaml(
        content=b"name: 'John Doe'", validator=String()
    )
    assert value == "John Doe"
    assert errors == []

    value, errors = validate_yaml(
        content=b"name: 'John Doe'", validator=Integer()
    )
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].text == "Value must be of type 'integer'."
    assert errors[0].position.line

# Generated at 2022-06-18 12:50:39.660500
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class Person(Schema):
        name = String()
        age = Integer()

    class Family(Schema):
        members = Array(items=Person)

    content = """
    members:
    - name: John
      age: 10
    - name: Mary
      age: 12
    """

    value, error_messages = validate_yaml(content, Family)
    assert value == {"members": [{"name": "John", "age": 10}, {"name": "Mary", "age": 12}]}
    assert error_messages == []


# Generated at 2022-06-18 12:50:51.368178
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "30"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: "thirty"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}

# Generated at 2022-06-18 12:51:01.370078
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 20
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert errors == []

    content = """
    name: John
    age: twenty
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5

    content = """
    name: John
    age: twenty
    """

# Generated at 2022-06-18 12:51:11.012113
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert errors == []

    content = """
    name: John
    age: thirty
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}

# Generated at 2022-06-18 12:51:20.374072
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Boolean
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class Person(Schema):
        name = String()
        age = Integer()
        is_cool = Boolean()

    content = """
    name: "John"
    age: 42
    is_cool: true
    """

    value, errors = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 42,
        "is_cool": True,
    }
    assert errors == []

    content = """
    name: "John"
    age: 42
    is_cool: true
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:51:28.514955
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - a
    - b
    - c
    """
    validator = typing.List[str]
    value, error_messages = validate_yaml(content, validator)
    assert value == ["a", "b", "c"]
    assert error_messages == []

    content = """
    - a
    - b
    - c
    """
    validator = typing.List[int]
    value, error_messages = validate_yaml(content, validator)
    assert value is None
    assert len(error_messages) == 3
    assert error_messages[0].text == "Must be an integer."
    assert error_messages[0].position.line_no == 2
    assert error_messages[0].position.column_no == 3
    assert error_messages

# Generated at 2022-06-18 12:51:37.081806
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean, Schema

    class Person(Schema):
        name = String()
        age = Integer()
        friends = Array(items=String())
        active = Boolean()

    content = """
    name: John Doe
    age: 42
    friends:
    - Jane Doe
    - John Smith
    active: true
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {
        "name": "John Doe",
        "age": 42,
        "friends": ["Jane Doe", "John Smith"],
        "active": True,
    }
    assert error_messages == []



# Generated at 2022-06-18 12:51:42.119875
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 42
    """
    validator = Schema(
        {"name": str, "age": int}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []



# Generated at 2022-06-18 12:51:49.041226
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: 'John Doe'
    age: '30'
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Doe", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:51:58.369734
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Boolean, Array

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        friends = Array(items=String())

    content = """
    name: "John"
    age: 42
    height: 1.83
    is_adult: true
    friends:
      - "Jane"
      - "Bob"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 42,
        "height": 1.83,
        "is_adult": True,
        "friends": ["Jane", "Bob"],
    }
    assert errors == []



# Generated at 2022-06-18 12:52:06.915798
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "20"
    """

    value, errors = validate_yaml(content, Person)
    assert errors == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=20),
        )
    ]

    content = """
    name: "John"
    age: 20
    """

    value, errors = validate_yaml(content, Person)
    assert errors == []
    assert value == {"name": "John", "age": 20}



# Generated at 2022-06-18 12:52:15.282074
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "name: John"
    validator = Field(name="name", type="string")
    value, error_messages = validate_yaml(content, validator)
    assert value == "John"
    assert error_messages == []

    content = "name: John"
    validator = Field(name="name", type="integer")
    value, error_messages = validate_yaml(content, validator)
    assert value == "John"
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be an integer."
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 6
    assert error_messages[0].position.char_index == 6


# Generated at 2022-06-18 12:52:26.462322
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class User(Schema):
        name = String()

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, validator=User)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, validator=User)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, validator=User)
    assert value == {"name": "John"}
    assert error_messages == []

    content

# Generated at 2022-06-18 12:52:37.506587
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 20
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert not errors

    content = """
    name: John
    age: 20
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert not errors

    content = """
    name: John
    age: 20
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert not errors

    content = """
    name: John
    age: 20
    """

# Generated at 2022-06-18 12:52:41.670424
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: "John Doe"
    age: 42
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []



# Generated at 2022-06-18 12:52:53.839037
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name:
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        ValidationError(
            text="This field is required.",
            code="required",
            position=Position(line_no=2, column_no=4, char_index=8),
        )
    ]

    content = """
    name: 123
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:52:59.525023
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John
    age: 30
    """
    schema = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, schema)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []



# Generated at 2022-06-18 12:53:11.607532
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(items=String())

    content = """
    name: John
    age: 42
    height: 1.8
    is_cool: true
    friends:
      - Jane
      - Bob
    """

    value, errors = validate_yaml(content, validator=Person)
    assert value == {
        "name": "John",
        "age": 42,
        "height": 1.8,
        "is_cool": True,
        "friends": ["Jane", "Bob"],
    }
    assert errors == []


# Generated at 2022-06-18 12:53:23.744798
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be an integer."

# Generated at 2022-06-18 12:53:33.323378
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:53:41.558276
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - name: "John"
      age: 30
    - name: "Jane"
      age: 20
    """
    validator = Schema(
        fields={
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == [
        {"name": "John", "age": 30},
        {"name": "Jane", "age": 20},
    ]
    assert error_messages == []



# Generated at 2022-06-18 12:53:48.630631
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = "name: John"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = "name: John\nage: 30"
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert len(error_messages) == 1
    assert error_messages[0].code == "unknown_field"
    assert error_messages[0].position.line_no == 2
    assert error_messages[0].position.column_no == 1


# Generated at 2022-06-18 12:53:59.447968
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("", Field()) == (None, [])
    assert validate_yaml("", Field(required=True)) == (None, [])
    assert validate_yaml("", Field(required=True, default="foo")) == ("foo", [])
    assert validate_yaml("", Field(default="foo")) == ("foo", [])
    assert validate_yaml("", Field(default=None)) == (None, [])
    assert validate_yaml("", Field(default=False)) == (False, [])
    assert validate_yaml("", Field(default=True)) == (True, [])
    assert validate_yaml("", Field(default=0)) == (0, [])
    assert validate_yaml("", Field(default=1)) == (1, [])

# Generated at 2022-06-18 12:54:09.327913
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String()

    content = """
    name: John
    """
    value, errors = validate_yaml(content, UserSchema)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, UserSchema)
    assert value == {"name": "John"}
    assert errors == [
        ValidationError(
            text="Additional properties are not allowed ('age' was unexpected).",
            code="additional_properties",
            position=Position(column_no=2, line_no=3, char_index=16),
        )
    ]

    content

# Generated at 2022-06-18 12:54:13.989923
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test that a valid YAML string is parsed and validated correctly.
    value, errors = validate_yaml(
        content="""
        - name: John
          age: 30
        - name: Jane
          age: 25
        """,
        validator=Schema(
            {
                "name": str,
                "age": int,
            }
        ),
    )
    assert value == [
        {"name": "John", "age": 30},
        {"name": "Jane", "age": 25},
    ]
    assert errors == []

    # Test that an invalid YAML string is parsed and validated correctly.

# Generated at 2022-06-18 12:54:23.646941
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Smith
    age: 35
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John Smith", "age": 35}
    assert errors == []

    content = """
    name: John Smith
    age: -35
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "minimum"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5

    content = """
    name: John Smith
    age: 35
    """

# Generated at 2022-06-18 12:54:33.964798
# Unit test for function validate_yaml
def test_validate_yaml():
    class PersonSchema(Schema):
        name = String(max_length=100)
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """

    value, error_messages = validate_yaml(content, PersonSchema)
    assert error_messages == [
        Message(
            text="Value must be an integer.",
            code="invalid",
            position=Position(
                line_no=3, column_no=5, char_index=content.index("30")
            ),
        )
    ]

    content = """
    name: "John"
    age: 30
    """

    value, error_messages = validate_yaml(content, PersonSchema)
    assert error_messages == []



# Generated at 2022-06-18 12:54:44.749902
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "20"
    """

    value, errors = validate_yaml(content, TestSchema)
    assert value == {"name": "John", "age": 20}
    assert errors == []

    content = """
    name: John
    age: "twenty"
    """

    value, errors = validate_yaml(content, TestSchema)
    assert value == {"name": "John", "age": "twenty"}

# Generated at 2022-06-18 12:54:59.815750
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 20
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert errors == []

    content = """
    name: John
    age: twenty
    """
    value, errors = validate_yaml(content, Person)
    assert value is None

# Generated at 2022-06-18 12:55:11.704614
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 20
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert error_messages == []

    content = """
    name: John
    age: twenty
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "twenty"}
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=3, column_no=5, char_index=17),
        )
    ]
