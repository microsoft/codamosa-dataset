

# Generated at 2022-06-18 12:45:32.354662
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:45:42.233101
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("\"a\"") == "a"
    assert tokenize_yaml("a: 1") == {"a": 1}
    assert tokenize_yaml("- 1") == [1]
    assert tokenize_yaml("- 1\n- 2") == [1, 2]

# Generated at 2022-06-18 12:45:50.580566
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    content = """
    name: John
    age: 25
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "25"}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "25"}
    assert error_messages == []

    content = """
    name: John
    age: 25
    """


# Generated at 2022-06-18 12:46:01.566116
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String()

    content = """
    name: "test"
    """

    value, error_messages = validate_yaml(content, TestSchema)
    assert value == {"name": "test"}
    assert error_messages == []

    content = """
    name:
    """

    value, error_messages = validate_yaml(content, TestSchema)
    assert value is None
    assert error_messages == [
        Message(
            text="This field is required.",
            code="required",
            position=Position(line_no=2, column_no=7, char_index=7),
        )
    ]


# Generated at 2022-06-18 12:46:12.117422
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0)
        is_cool = Boolean()
        friends = Array(items=String())

    content = """
    name: John
    age: 20
    height: 1.75
    is_cool: true
    friends:
      - Alice
      - Bob
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:46:24.467213
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == {}
    assert tokenize_yaml("[]") == []
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("1.0") == 1.0
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("a: b") == {"a": "b"}
    assert tokenize_yaml("- a") == ["a"]
    assert tokenize_yaml("- a\n- b") == ["a", "b"]

# Generated at 2022-06-18 12:46:35.203501
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == ScalarToken(None, 0, 0, content="")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("1.0e10") == ScalarToken(1.0e10, 0, 6, content="1.0e10")
   

# Generated at 2022-06-18 12:46:39.004674
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("\n") == None
    assert tokenize_yaml("\n\n") == None
    assert tokenize_yaml("\n\n\n") == None
    assert tokenize_yaml("\n\n\n\n") == None
    assert tokenize_yaml("\n\n\n\n\n") == None
    assert tokenize_yaml("\n\n\n\n\n\n") == None
    assert tokenize_yaml("\n\n\n\n\n\n\n") == None
    assert tokenize_yaml("\n\n\n\n\n\n\n\n") == None

# Generated at 2022-06-18 12:46:46.463891
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - a
    - b
    - c
    """
    validator = Field(type="list", items=Field(type="string"))
    value, error_messages = validate_yaml(content, validator)
    assert value == ["a", "b", "c"]
    assert error_messages == []

    content = """
    - a
    - b
    - c
    - d
    """
    validator = Field(type="list", items=Field(type="string"), max_length=3)
    value, error_messages = validate_yaml(content, validator)
    assert value == ["a", "b", "c", "d"]

# Generated at 2022-06-18 12:46:57.352302
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.1") == ScalarToken(1.1, 0, 2, content="1.1")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:47:14.123348
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: 123
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "123"}
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="type_error.string",
            position=Position(line_no=2, column_no=6, char_index=10),
        )
    ]


# Generated at 2022-06-18 12:47:20.730155
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Boolean

    class MySchema(Schema):
        name = String()
        age = Integer()
        is_active = Boolean()

    content = """
    name: John
    age: 30
    is_active: true
    """

    value, errors = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": 30, "is_active": True}
    assert errors == []

    content = """
    name: John
    age: 30
    is_active: true
    """

    value, errors = validate_yaml(content, MySchema)
    assert value == {"name": "John", "age": 30, "is_active": True}
    assert errors == []

    content

# Generated at 2022-06-18 12:47:24.667220
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, errors = validate_yaml(content, UserSchema)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: thirty
    """

    value, errors = validate_yaml(content, UserSchema)
    assert value is None

# Generated at 2022-06-18 12:47:32.660134
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: thirty
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "thirty"}

# Generated at 2022-06-18 12:47:39.275135
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(items=String())

    content = """
    name: John
    age: 30
    height: 1.83
    is_cool: true
    friends:
        - Alice
        - Bob
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {
        "name": "John",
        "age": 30,
        "height": 1.83,
        "is_cool": True,
        "friends": ["Alice", "Bob"],
    }
    assert error_messages == []

    content

# Generated at 2022-06-18 12:47:51.068113
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: John
    """

    token = tokenize_yaml(content)
    value, error_messages = validate_with_positions(token=token, validator=Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John Doe
    """

    token = tokenize_yaml(content)
    value, error_messages = validate_with_positions(token=token, validator=Person)
    assert value is None

# Generated at 2022-06-18 12:48:01.000973
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    age: 20
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}

# Generated at 2022-06-18 12:48:11.302746
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    content = """
    name: John Doe
    age: -1
    """

    token = tokenize_yaml(content)
    value, errors = validate_with_positions(token, Person)

    assert value == {"name": "John Doe", "age": -1}
    assert len(errors) == 1
    assert errors[0].text == "Must be greater than or equal to 0."
    assert errors[0].code == "minimum"
    assert errors[0].position.line_no == 3


# Generated at 2022-06-18 12:48:21.539777
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean, Object

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        friends = Array(items=Object(Person))
        alive = Boolean()

    content = """
    name: John Doe
    age: 42
    friends:
      - name: Jane Doe
        age: 39
        friends: []
        alive: true
      - name: Bob Smith
        age: 21
        friends: []
        alive: false
    alive: true
    """

    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:48:33.474454
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test for a valid YAML string
    content = """
    name: "John Doe"
    age: 30
    """
    validator = Schema(
        {
            "name": str,
            "age": int,
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {
        "name": "John Doe",
        "age": 30,
    }
    assert error_messages == []

    # Test for a YAML string with an invalid value
    content = """
    name: "John Doe"
    age: "thirty"
    """
    validator = Schema(
        {
            "name": str,
            "age": int,
        }
    )

# Generated at 2022-06-18 12:48:48.229916
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "Bob"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "Bob"}
    assert not errors

    content = """
    name: 123
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "123"}
    assert len(errors) == 1
    assert errors[0].code == "type_error.string"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 4



# Generated at 2022-06-18 12:48:58.110879
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: "John"
    age: "30"
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert error_messages == []

    content = """
    name: "John"
    age: "30"
    """
    value, error_messages = validate_yaml(content, Person)

# Generated at 2022-06-18 12:49:07.743112
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo:
        bar:
            - 1
            - 2
            - 3
    """
    value, error_messages = validate_yaml(content, Field(type="string"))
    assert value == None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Value must be of type 'string'."
    assert error_messages[0].position.line_no == 3
    assert error_messages[0].position.column_no == 9
    assert error_messages[0].position.char_index == 27


# Generated at 2022-06-18 12:49:14.219961
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "30"
    """
    value, errors = validate_yaml(content, Person)
    assert errors == [
        Message(
            text="String value expected.",
            code="type_error.string",
            position=Position(line_no=3, column_no=5, char_index=19),
        )
    ]

    content = """
    name: "John"
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert errors == []
    assert value == {"name": "John", "age": 30}

    content = """
    name: "John"
    age: "thirty"
    """
    value, errors

# Generated at 2022-06-18 12:49:25.411927
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: "20"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert errors == []

    content = """
    name: "John"
    age: "20"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert errors == []

    content = """
    name: "John"
    age: "20"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert errors == []

    content

# Generated at 2022-06-18 12:49:28.877783
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo:
      bar:
        baz:
          - 1
          - 2
          - 3
    """
    validator = Schema(
        {"foo": {"bar": {"baz": Field(type=int, min_length=3, max_length=3)}}}
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"foo": {"bar": {"baz": [1, 2, 3]}}}
    assert error_messages == []



# Generated at 2022-06-18 12:49:33.700611
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean, Object

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        friends = Array(items=String(max_length=100))
        alive = Boolean()

    class People(Schema):
        people = Array(items=Person)

    content = """
    people:
      - name: John
        age: 30
        friends:
          - Mary
          - Jane
        alive: true
      - name: Jane
        age: 25
        friends:
          - John
          - Mary
        alive: true
      - name: Mary
        age: 28
        friends:
          - John
          - Jane
        alive: true
    """

    value, errors = validate_yaml(content, People)

# Generated at 2022-06-18 12:49:44.378488
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"name": Field(type="string")})
    value, errors = validate_yaml(content=b"name:", validator=schema)
    assert errors == [
        Message(
            text="Expected a string.",
            code="invalid_type",
            position=Position(column_no=6, line_no=1, char_index=5),
        )
    ]

    value, errors = validate_yaml(content=b"name:", validator=Field(type="string"))
    assert errors == [
        Message(
            text="Expected a string.",
            code="invalid_type",
            position=Position(column_no=6, line_no=1, char_index=5),
        )
    ]


# Generated at 2022-06-18 12:49:54.533900
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0)
        is_active = Boolean()

    yaml_content = """
    name: "John Doe"
    age: 30
    height: 1.75
    is_active: true
    """

    value, error_messages = validate_yaml(yaml_content, Person)

    assert value == {
        "name": "John Doe",
        "age": 30,
        "height": 1.75,
        "is_active": True,
    }
    assert error_messages == []


# Generated at 2022-06-18 12:50:06.834742
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(String())
        family = Object({"name": String(), "relation": String()})

    # Valid YAML
    content = """
    name: "John"
    age: 30
    height: 1.8
    is_cool: true
    friends:
      - "Jane"
      - "Bob"
    family:
      name: "Jane"
      relation: "Mother"
    """
    value, errors = validate_yaml(content, Person)

# Generated at 2022-06-18 12:50:21.547637
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array

    class Person(Schema):
        name = String()
        age = Integer()

    class People(Schema):
        people = Array(items=Person)

    yaml_content = """
    people:
      - name: John
        age: 20
      - name: Jane
        age: 30
    """

    value, errors = validate_yaml(yaml_content, People)
    assert value == {
        "people": [
            {"name": "John", "age": 20},
            {"name": "Jane", "age": 30},
        ]
    }
    assert not errors


# Generated at 2022-06-18 12:50:30.512137
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    content = """
    name: John
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert not errors

    content = """
    name: John Doe
    """
    value, errors = validate_yaml(content, Person)
    assert value is None
    assert errors == [
        Message(
            text="String value is too long.",
            code="max_length",
            position=Position(line_no=2, column_no=6, char_index=12),
        )
    ]



# Generated at 2022-06-18 12:50:38.898998
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: "30"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: John
    age: "thirty"
    """

    value, errors = validate_yaml(content, Person)
    assert value is None
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5



# Generated at 2022-06-18 12:50:50.692461
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - 1
    - 2
    - 3
    """
    validator = Field(type="array", items=Field(type="integer"))
    value, error_messages = validate_yaml(content, validator)
    assert value == [1, 2, 3]
    assert error_messages == []

    content = """
    - 1
    - 2
    - 3
    """
    validator = Field(type="array", items=Field(type="string"))
    value, error_messages = validate_yaml(content, validator)
    assert value is None

# Generated at 2022-06-18 12:51:00.754737
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_cool = Boolean()
        friends = Array(String())
        family = Object({"mother": String(), "father": String()})

    yaml_str = """
    name: "John"
    age: 30
    height: 1.75
    is_cool: true
    friends:
        - "Jane"
        - "Bob"
    family:
        mother: "Mary"
        father: "John"
    """

    value, errors = validate_yaml(yaml_str, Person)

# Generated at 2022-06-18 12:51:10.419131
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Array, Boolean, Object

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)

    class People(Schema):
        people = Array(items=Person)

    class PersonWithFriends(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        friends = Array(items=Person)

    class PersonWithFriendsAndEnemies(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        friends = Array(items=Person)
        enemies = Array(items=Person)

    class PersonWithFriendsAndEnemiesAndBoolean(Schema):
        name = String(max_length=10)

# Generated at 2022-06-18 12:51:19.460752
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: "John"
    age: 42
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 42}
    assert not errors

    content = """
    name: "John"
    age: "forty-two"
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": "forty-two"}
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 3
    assert errors[0].position.column_no == 5


# Generated at 2022-06-18 12:51:27.958065
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: bar
    """
    validator = Field(type="string")
    value, error_messages = validate_yaml(content, validator)
    assert value == "bar"
    assert error_messages == []

    content = """
    foo: bar
    """
    validator = Field(type="integer")
    value, error_messages = validate_yaml(content, validator)
    assert value == "bar"
    assert error_messages == [
        ValidationError(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(line_no=2, column_no=4, char_index=7),
        )
    ]

    content = """
    foo: bar
    """

# Generated at 2022-06-18 12:51:37.836745
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert errors == []

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert errors == []

    content = """
    name: John
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 25}
    assert errors == []


# Generated at 2022-06-18 12:51:47.883911
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John Smith"
    """

    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John Smith"}
    assert error_messages == []

    content = """
    name: 123
    """

    value, error_messages = validate_yaml(content, Person)
    assert value is None
    assert error_messages == [
        Message(
            text="Must be a string.",
            code="invalid_type",
            position=Position(line_no=2, column_no=7, char_index=11),
        )
    ]


# Generated at 2022-06-18 12:52:02.707685
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 0, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 2, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 3, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 4, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 3, content="null")


# Generated at 2022-06-18 12:52:11.153447
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: "John"
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = """
    name: "John"
    age: 30
    """

    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John"}
    assert len(errors) == 1
    assert errors[0].code == "unknown_field"
    assert errors[0].position.line_no == 2
    assert errors[0].position.column_no == 1

    content = """
    name: "John"
    """


# Generated at 2022-06-18 12:52:16.527020
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 43
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 43}
    assert error_messages == []



# Generated at 2022-06-18 12:52:27.173125
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John"}

# Generated at 2022-06-18 12:52:35.150679
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name:
      first: John
      last: Smith
    """
    validator = Schema(
        {
            "name": {
                "first": Field(str),
                "last": Field(str),
            }
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == []
    assert value == {
        "name": {
            "first": "John",
            "last": "Smith",
        }
    }



# Generated at 2022-06-18 12:52:44.964021
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Float, Boolean, Array, Object
    from typesystem.fields import Field
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0, maximum=3.0)
        is_human = Boolean()
        friends = Array(items=String())

    class Person2(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0, maximum=3.0)
        is_human = Boolean()
        friends = Array(items=String())

# Generated at 2022-06-18 12:52:56.806396
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = """
    name: John
    """
    value, error_messages = validate_yaml(content, validator=Person)
    assert value == {"name": "John"}
    assert error_messages == []

    content = """
    name: John
    age: 30
    """
    value, error_messages = validate_yaml(content, validator=Person)
    assert value == {"name": "John", "age": 30}

# Generated at 2022-06-18 12:53:06.666529
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    class Address(Schema):
        street = String()
        city = String()
        zip_code = String()

    class User(Schema):
        name = String()
        age = Integer()
        address = Object(Address)

    class User2(Schema):
        name = String()
        age = Integer()
        address = Object(Address, required=False)

    class User3(Schema):
        name = String()
        age = Integer()
        address = Object(Address, required=False, default={})

    class User4(Schema):
        name = String()
        age = Integer()
        address

# Generated at 2022-06-18 12:53:19.181151
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    content = """
    name: "test"
    """

    value, error_messages = validate_yaml(content, validator=MySchema)
    assert value == {"name": "test"}
    assert error_messages == []

    content = """
    name: "test"
    """

    value, error_messages = validate_yaml(content, validator=String())
    assert value == "test"
    assert error_messages == []

    content = """
    name: "test"
    """

    value, error_messages = validate_yaml(content, validator=String(max_length=3))
    assert value == "test"
   

# Generated at 2022-06-18 12:53:28.316571
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")
    assert tokenize_yaml("1") == ScalarToken(1, 0, 1, content="1")
    assert tokenize_yaml("1.0") == ScalarToken(1.0, 0, 3, content="1.0")
    assert tokenize_yaml("true") == ScalarToken(True, 0, 4, content="true")
    assert tokenize_yaml("false") == ScalarToken(False, 0, 5, content="false")
    assert tokenize_yaml("null") == ScalarToken(None, 0, 4, content="null")


# Generated at 2022-06-18 12:53:43.406221
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    - name: "John"
      age: 30
    - name: "Jane"
      age: 20
    '''
    validator = Schema(
        fields={
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == [
        {"name": "John", "age": 30},
        {"name": "Jane", "age": 20},
    ]
    assert error_messages == []



# Generated at 2022-06-18 12:53:54.765736
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float, Boolean, Array, Object
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()

    class People(Schema):
        people = Array(items=Person)

    class PeopleObject(Schema):
        people = Object(properties={"name": String(), "age": Integer()})

    class PeopleObjectWithRequired(Schema):
        people = Object(properties={"name": String(), "age": Integer()}, required=["name"])

    class PeopleObjectWithAdditionalProperties(Schema):
        people = Object(properties={"name": String(), "age": Integer()}, additional_properties=True)


# Generated at 2022-06-18 12:54:03.845052
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        field = String()

    content = "field: value"
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"field": "value"}
    assert error_messages == []

    content = "field: value\nfield: value"
    value, error_messages = validate_yaml(content, MySchema)
    assert value == {"field": "value"}
    assert error_messages == [
        Message(
            text="Additional properties are not allowed ('field' was unexpected).",
            code="additional_properties",
            position=Position(line_no=2, column_no=1, char_index=11),
        )
    ]



# Generated at 2022-06-18 12:54:09.133121
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String()
        age = Integer()

    class FamilySchema(Schema):
        members = Array(items=PersonSchema())

    content = """
    members:
      - name: Alice
        age: 18
      - name: Bob
        age: 20
    """
    value, errors = validate_yaml(content, FamilySchema)
    assert value == {
        "members": [{"name": "Alice", "age": 18}, {"name": "Bob", "age": 20}]
    }
    assert errors == []

    content = """
    members:
      - name: Alice
        age: 18
      - name: Bob
        age: "20"
    """

# Generated at 2022-06-18 12:54:19.057530
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String, Integer, Schema
    from typesystem.tokenize.tokens import ScalarToken

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0)

    content = """
    name: John
    age: 20
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 20}
    assert error_messages == []

    content = """
    name: John
    age: -20
    """
    value, error_messages = validate_yaml(content, Person)
    assert value == {"name": "John", "age": -20}

# Generated at 2022-06-18 12:54:30.510388
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String()
        age = Integer()

    content = """
    name: John
    age: 30
    """

    value, error_messages = validate_yaml(content, UserSchema)
    assert value == {"name": "John", "age": 30}
    assert error_messages == []

    content = """
    name: John
    age: thirty
    """

    value, error_messages = validate_yaml(content, UserSchema)
    assert value is None

# Generated at 2022-06-18 12:54:40.657466
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0)

    content = """
    name: "John"
    age: 30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": 30}
    assert errors == []

    content = """
    name: "John"
    age: -30
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "John", "age": -30}
    assert errors == [
        Message(
            text="Must be greater than or equal to 0.",
            code="minimum",
            position=Position(line_no=3, column_no=5, char_index=17),
        )
    ]



# Generated at 2022-06-18 12:54:50.957827
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    content = """
    name: Bob
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "Bob", "age": 25}
    assert errors == []

    content = """
    name: Bob
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "Bob", "age": 25}
    assert errors == []

    content = """
    name: Bob
    age: 25
    """
    value, errors = validate_yaml(content, Person)
    assert value == {"name": "Bob", "age": 25}
    assert errors == []


# Generated at 2022-06-18 12:54:59.299731
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo:
      bar:
        - 1
        - 2
        - 3
    """
    validator = Schema(
        {
            "foo": {
                "bar": [
                    {
                        "baz": int,
                    }
                ]
            }
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {
        "foo": {
            "bar": [
                {"baz": 1},
                {"baz": 2},
                {"baz": 3},
            ]
        }
    }
    assert error_messages == []



# Generated at 2022-06-18 12:55:05.200840
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    name: John Doe
    age: 42
    """
    validator = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )
    value, error_messages = validate_yaml(content, validator)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

