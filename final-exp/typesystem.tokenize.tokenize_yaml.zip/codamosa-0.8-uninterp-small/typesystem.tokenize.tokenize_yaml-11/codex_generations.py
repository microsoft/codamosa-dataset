

# Generated at 2022-06-26 10:41:55.487299
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None
    content = b'\x7f\xa6\x97\xa7\x13\x02'
    validator = Field()
    value, error_messages = validate_yaml(content, validator)

# Generated at 2022-06-26 10:42:08.259630
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    content = b"foo: bar\nbaz: 1\n"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

    content = b"foo: true\n"
    token = tokenize_yaml(content)
    assert isinstance(token, ScalarToken)
    assert isinstance(token.value, bool)
    assert token.value is True

    content = b"foo: 123\n"
    token = tokenize_yaml(content)
    assert isinstance(token, ScalarToken)
    assert isinstance(token.value, int)
    assert token.value == 123

    content = b"foo: 1.2\n"
    token = tokenize_yaml(content)

# Generated at 2022-06-26 10:42:19.949425
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test cases and expected results

    bytes_0 = b'\x7f\xa6\x97\xa7\x13\x02'
    expected_0 = ScalarToken(
        value=b"\x7f\xa6\x97\xa7\x13\x02",
        start=0,
        end=5,
        content=b"\x7f\xa6\x97\xa7\x13\x02",
    )
    result_0 = tokenize_yaml(bytes_0)
    assert isinstance(result_0, ScalarToken)
    assert result_0.value == expected_0.value
    assert result_0.start == expected_0.start
    assert result_0.end == expected_0.end
    assert result_0.content == expected_0.content



# Generated at 2022-06-26 10:42:32.282251
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=99)
        height = Float(minimum=0)

    content = """
    name: Bob
    age: 42
    height: 1.9
    """
    assert validate_yaml(content=content, validator=Person)[0] == {
        "name": "Bob",
        "age": 42,
        "height": 1.9,
    }

    content = """
    name: Bob
    age: 42
    height:
      feet: 5
      inches: 9
    """
    assert validate_yaml(content=content, validator=Person)[0] == {
        "name": "Bob",
        "age": 42,
        "height": {"feet": 5, "inches": 9},
    }

    content

# Generated at 2022-06-26 10:42:40.235988
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Field(type="string")

    assert validate_yaml("foo", schema) == ("foo", [])
    assert validate_yaml("!foo", schema) == (None, [ParseError(...)])
    assert validate_yaml("123", schema) == (None, [ParseError(...)])

    assert validate_yaml("foo", Field(type="string", max_length=1)) == (
        None,
        [ValidationError(
            text="Length must be less than or equal to 1.",
            code="max_length",
            position=Position(line_no=1, column_no=1, char_index=0),
        )],
    )



# Generated at 2022-06-26 10:42:54.625743
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '409a0e8b57'
    bytes_0 = b'\xbe\x9a\xcb\x12\x92'
    int_0 = 933291300
    bool_0 = True
    bytes_1 = b'\x7f\xa6\x97\xa7\x13\x02'
    assert test_case_tokenize_yaml.__doc__ == tokenize_yaml.__doc__
    assert tokenize_yaml(str_0) == '409a0e8b57'
    assert tokenize_yaml(bytes_0) == [260155610]
    assert tokenize_yaml(int_0) == 933291300
    assert tokenize_yaml(bool_0) is True

# Generated at 2022-06-26 10:42:58.757863
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = "key: 'value'"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.items[0][0], ScalarToken)
    assert token.items[0][0].value == "key"
    assert token.items[0][1].value == "value"



# Generated at 2022-06-26 10:43:03.457326
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    bytes_0 = b"%YAML 1.1\n---\n# example\n-\x1a2.2\n-\r2.2\n"
    token_0 = tokenize_yaml(bytes_0)
    assert type(token_0) is DictToken



# Generated at 2022-06-26 10:43:16.129149
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # AssertionError is raised if a mismatch is detected
    assert yaml is not None, "'pyyaml' must be installed."

    bytes_0 = b'\x7f\xa6\x97\xa7\x13\x02'
    assert tokenize_yaml(bytes_0) == None
    str_0 = '\t\r\n\f\v^\xab\xbf\xee'
    assert tokenize_yaml(str_0) == None
    bytes_1 = b'\x0fw\x14O\x8c\x0e\x94\xb1\x9e\x8c\x1d\x97\xbb'
    assert tokenize_yaml(bytes_1) == None

# Generated at 2022-06-26 10:43:23.622017
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token_0 = tokenize_yaml('{}')
    assert isinstance(token_0, DictToken)
    assert token_0.value == {}
    assert token_0.start == 0
    assert token_0.end == 1
    assert token_0.content == '{}'
    token_1 = tokenize_yaml('[]')
    assert isinstance(token_1, ListToken)
    assert token_1.value == []
    assert token_1.start == 0
    assert token_1.end == 1
    assert token_1.content == '[]'
    token_2 = tokenize_yaml('"string"')
    assert isinstance(token_2, ScalarToken)
    assert token_2.value == '"string"'
    assert token_2.start == 0
    assert token_2

# Generated at 2022-06-26 10:43:39.833504
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(name="name", type="string")
    bytes_0 = b"foo"
    token_0 = tokenize_yaml(bytes_0)
    value_0, error_messages_0 = validate_with_positions(
        token=token_0, validator=validator
    )
    assert value_0 == "foo"
    assert len(error_messages_0) == 0

    bytes_1 = b'["foo"]'
    token_1 = tokenize_yaml(bytes_1)
    value_1, error_messages_1 = validate_with_positions(
        token=token_1, validator=validator
    )
    assert value_1 == ["foo"]
    assert len(error_messages_1) == 0


# Generated at 2022-06-26 10:43:51.444546
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test with a non-YAML string as content.
    def func0(validator: typing.Union[Field, typing.Type[Schema]]) -> typing.Tuple[bool, typing.List[Message]]:
        content_0 = '\x7f\xa6\x97\xa7\x13\x02'
        return validate_yaml(content_0, validator)

    def func1(validator: typing.Union[Field, typing.Type[Schema]]) -> typing.Tuple[bool, typing.List[Message]]:
        content_0 = '\x7f\xa6\x97\xa7\x13\x02'
        return validate_yaml(content_0, validator)
    validator_0 = None

# Generated at 2022-06-26 10:44:00.211010
# Unit test for function validate_yaml
def test_validate_yaml():
    t1 = (
        b'---\n'
        b'"list item 1"\n'
        b'"list item 2"\n'
        b'"list item 3"\n'
        b'"list item 4"\n'
        b'"list item 5"\n'
        b'"list item 6"\n'
        b'...\n'
    )
    token = tokenize_yaml(t1)
    value, messages = validate_with_positions(token=token, validator=Field())

# Generated at 2022-06-26 10:44:09.737569
# Unit test for function validate_yaml
def test_validate_yaml():
    content_0 = 'foo: bar'
    validator_0 = Field(type="string", required=False, title="foo")
    value_0, error_messages_0 = validate_yaml(content=content_0, validator=validator_0)
    content_1 = 'foo: !!str 123'
    validator_1 = Field(type="string", required=False, title="foo")
    value_1, error_messages_1 = validate_yaml(content=content_1, validator=validator_1)
    content_2 = 'foo: 123'
    validator_2 = Field(type="string", required=False, title="foo")
    value_2, error_messages_2 = validate_yaml(content=content_2, validator=validator_2)


# Generated at 2022-06-26 10:44:16.476447
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Number

    class User(Schema):
        name = String()
        age = Number()

    result = validate_yaml(
        "name: John\nage: 20\n",
        validator=User
    )
    assert result == ({
        "name": "John",
        "age": 20,
    }, [])



# Generated at 2022-06-26 10:44:29.722568
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.base import Undefined
    from typesystem.enums import Enum
    from typesystem.types import Text, Integer, Boolean

    class MyEnum(Enum):
        FOO = "foo"

    class MyText(Text):
        pattern = "^[a-z]+$"

    class MySchema(Schema):
        foo = MyText()
        bar = Integer()
        baz = Boolean()
        qux = MyEnum()
        quux = Undefined()


# Generated at 2022-06-26 10:44:41.219848
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Float
    from typesystem.schemas import Schema

    # Parse a simple YAML string.
    content_0 = b'name: Dave\nage: 20'
    value_0, error_messages_0 = validate_yaml(content_0, None)
    assert value_0 == {'name': 'Dave', 'age': 20}
    assert error_messages_0 == []

    # Parse a YAML document that is not valid JSON.
    content_1 = b'name: Dave\nemail: null\nage: 20'
    value_1, error_messages_1 = validate_yaml(content_1, None)
    assert value_1 == {'name': 'Dave', 'email': None, 'age': 20}
    assert error_mess

# Generated at 2022-06-26 10:44:46.903204
# Unit test for function validate_yaml
def test_validate_yaml():
    input_0 = b'\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99'
    output_0 = validate_yaml(input_0, None)
    assert output_0 == (None, None)

# Testing this using a cached fixture to avoid reading from disk for each test

# Generated at 2022-06-26 10:44:54.146201
# Unit test for function validate_yaml
def test_validate_yaml():
    # Setup
    content = b'\x7f\xa6\x97\xa7\x13\x02'
    validator = Field()

    # Exercise
    results = validate_yaml(content, validator)

    # Verify
    want = {}
    assert want == results

# Generated at 2022-06-26 10:44:59.225676
# Unit test for function validate_yaml
def test_validate_yaml():
    typesystem.utils.defer_import_(globals(), "_test_validate_yaml")
    _test_validate_yaml()
# def _test_validate_yaml():
#     assert False, "Need to write this unit test"



# Generated at 2022-06-26 10:45:10.496228
# Unit test for function validate_yaml
def test_validate_yaml():
    var_0 = None
    var_1 = None
    var_0, var_1 = validate_yaml('', None)
    print("Returned: " + repr(var_0) + ", " + repr(var_1))

if __name__ == '__main__':
    test_case_0()
    test_validate_yaml()

# Generated at 2022-06-26 10:45:23.142100
# Unit test for function validate_yaml
def test_validate_yaml():
    import sys
    from pyspark.sql import SparkSession
    from pyspark.sql import Row
    from pyspark.sql import functions as F
    spark = SparkSession.builder.appName("Python Spark SQL basic example").getOrCreate()
    sc = spark.sparkContext
    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.append(cwd)

    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.append(cwd)

    # 1. read in data file
    vehicletext = spark.read.format('csv').options(header='true', inferschema='true').load(sys.argv[1])
    # 2. create temp view of dataframe
    vehicletext.createOrReplaceTempView

# Generated at 2022-06-26 10:45:33.352777
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test that we correctly tokenize the contents of the YAML file.
    with open("tests/cli_files/api.yaml") as stream:
        content = stream.read()
    api_token = tokenize_yaml(content=content)
    assert isinstance(api_token, DictToken)
    assert api_token.keys() == {"openapi", "info", "paths"}

    # Test that we correctly handle malformed YAML.
    with open("tests/cli_files/invalid_yaml.yaml") as stream:
        content = stream.read()
    with pytest.raises(ParseError) as exc_info:
        tokenize_yaml(content=content)
    assert exc_info.type == ParseError
    assert exc_info.value.position.line_no == 1


# Generated at 2022-06-26 10:45:38.989696
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        assert validate_yaml(content=None, validator=None) is None
    except NotImplementedError as exc:
        if str(exc) == 'No default implementation':
            pass
        else:
            raise
    except Exception:
        import traceback
        exstr = traceback.format_exc()
        raise AssertionError(exstr)


# Generated at 2022-06-26 10:45:50.770592
# Unit test for function validate_yaml
def test_validate_yaml():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-26 10:45:54.663491
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String

    assert validate_yaml("a: b", String()) == ("a: b", [])


# Generated at 2022-06-26 10:45:59.344610
# Unit test for function validate_yaml
def test_validate_yaml():
    class Test(Schema):
        document = "Test"
        bar = " asdfsadf "
        foo = Field(required=True)
        q = Field(required=True)

    input_data = """
    foo: 3
    q: true
    """
    value, errors = validate_yaml(input_data, validator=Test)
    assert value == {"foo": 3, "q": True}
    assert not errors

    # Test required.
    input_data = """
    foo: 3
    """
    value, errors = validate_yaml(input_data, validator=Test)
    assert not value
    assert errors

    with pytest.raises(TypeError):
        # Test unknown field.
        input_data = """
        foo: 3
        bar: 4
        """
        value, errors

# Generated at 2022-06-26 10:46:01.245075
# Unit test for function validate_yaml
def test_validate_yaml():
    assert callable(validate_yaml)


# Generated at 2022-06-26 10:46:13.379330
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        # Test with string as first and second argument
        var_0: typing.Any = True
        # Error: Parse 'basic_string' mapping values are not allowed here
        var_0 = validate_yaml(content='"basic_string"', validator='basic_string')
        assert var_0 == True
        var_1: typing.Any = True
        # Error: Parse 'basic_string' mapping values are not allowed here
        var_1 = validate_yaml(content='"basic_string"', validator='basic_string')
        assert var_1 == True
    except (AssertionError) as exc:
        print('Error at line {}'.format(exc.__traceback__.tb_lineno))
        print(exc)
        print(var_0)
        print(var_1)


# Generated at 2022-06-26 10:46:18.413813
# Unit test for function validate_yaml
def test_validate_yaml():
    # Run build_extension (no-op) in build_ext command
    # This is needed to test if the header file is generated
    assert callable(validate_yaml)


# Generated at 2022-06-26 10:46:33.808532
# Unit test for function validate_yaml
def test_validate_yaml():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    try:
        var_0 = tokenize_yaml(">---\\n# Hello world\\nname:\\n  # Some comment\\n  - Alex\\n  - Bob\\n\n")
        var_1 = type(var_0) == DictToken
        assert var_1
    except Exception:
        var_1 = False
        raise


# Generated at 2022-06-26 10:46:34.329709
# Unit test for function validate_yaml
def test_validate_yaml():
    assert va

# Generated at 2022-06-26 10:46:36.114130
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test case 0
    var_0 = None
    assert validate_yaml(content=var_0, validator=var_0) == var_0


# Generated at 2022-06-26 10:46:42.035144
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    var_0 = None

    # Load the YAML fixture data
    with open("typesystem/tests/fixtures/data.yml", "r") as stream:
        try:
            var_0 = yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            print(exc)
    # Print the result of the function
    print(var_0)


# Generated at 2022-06-26 10:46:43.748508
# Unit test for function validate_yaml
def test_validate_yaml():
    print("Test validating YAML")

    # Make sure it's getting to the right place..
    assert test_case_0() is None

# Generated at 2022-06-26 10:46:48.268057
# Unit test for function validate_yaml
def test_validate_yaml():
    # validate_yaml ()
    var_0 = None
    test_case_0()

    try:
        validate_yaml()
    except TypeError:
        var_0 = True

    assert var_0


# Generated at 2022-06-26 10:46:49.164352
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True


# Generated at 2022-06-26 10:46:54.564579
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    input_string = "null"
    token = tokenize_yaml(input_string)
    assert(token.content == input_string)
    assert(token.start == 0)
    assert(token.end == 3)
    assert(token.value == None)


# Generated at 2022-06-26 10:46:59.059929
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '''
    a:
        - b
        - c
'''
    print(".test_tokenize_yaml")
    print("----")
    try:
        print("RESULT: ", tokenize_yaml(content))
    except NameError as e:
        print("RESULT: " + str(e))
    print("----")


# Generated at 2022-06-26 10:47:08.498351
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "completed: true"
    validator = Field(name="completed", type="boolean")
    test_0 = None
    test_1 = None
    try:
        test_0 = validate_yaml(content, validator)
    except (ParseError, ValidationError) as exc:
        test_1 = exc
    assert test_0 is None
    assert type(test_1) is ValidationError


# Generated at 2022-06-26 10:47:21.198312
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'nKE\riji;\tG6@MKpT'
    token_0 = tokenize_yaml(str_0)
    str_1 = '#'
    token_1 = tokenize_yaml(str_1)
    str_2 = '[1, nKE\riji;\tG6@MKpT]'
    token_2 = tokenize_yaml(str_2)
    str_3 = '[nKE\riji;\tG6@MKpT, 2]'
    token_3 = tokenize_yaml(str_3)
    str_4 = '[1, 2, 3]'
    token_4 = tokenize_yaml(str_4)
    str_5 = "[1, 2, 3\n4, 5, 6]"
    token_5 = tokenize

# Generated at 2022-06-26 10:47:32.418833
# Unit test for function validate_yaml
def test_validate_yaml():
    # ScalarToken
    scalar_token1 = ScalarToken(value='abc', start=0, end=2, content='abc')
    scalar_token2 = ScalarToken(value='abc', start=0, end=2, content='abcd')

    # DictToken
    dict_token1 = DictToken({'a': 'b'}, start=5, end=5, content='a: b')
    dict_token2 = DictToken({'a': 'b'}, start=5, end=5, content='a: b\n')
    dict_token3 = DictToken({'a': 'b'}, start=5, end=5, content='a: b\nc:d')

# Generated at 2022-06-26 10:47:38.516781
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('') == None
    assert tokenize_yaml('cl4d3lxtY-XuVj-n') == 'cl4d3lxtY-XuVj-n'
    assert tokenize_yaml('9Wz%c') == '9Wz%c'
    assert tokenize_yaml('  ') == '  '
    assert tokenize_yaml('5r3-5r3-5r3') == '5r3-5r3-5r3'


# Generated at 2022-06-26 10:47:41.371772
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '"ok"'
    validator = Field(type="string")
    result = validate_yaml(content=content, validator=validator)
    assert result.value == 'ok'
    assert len(result.errors) == 0


# Generated at 2022-06-26 10:47:48.390720
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'nKE\riji;\tG6@MKpT'
    token_0 = tokenize_yaml(str_0)
    str_1 = '\t\riji;\tG6@MKpT\n'
    token_1 = tokenize_yaml(str_1)
    str_2 = '\t\riji;\tG6@MKpT\n'
    token_2 = tokenize_yaml(str_2)
    str_3 = '\t\riji;\tG6@MKpT\n'
    token_3 = tokenize_yaml(str_3)
    str_4 = '"\t\riji;\tG6@MKpT\n"'
    token_4 = tokenize_yaml(str_4)


# Generated at 2022-06-26 10:48:01.446341
# Unit test for function validate_yaml
def test_validate_yaml():

    # Example from README.
    class UserSchema(Schema):
        name = String(min_length=3, max_length=10)
        age = Integer(minimum=0, maximum=150)
        registered = Boolean(default=False)

    str_0 = f"""
        name: Bryan
        age: 32
        registered: true
    """
    try:
        value_0, errors_0 = validate_yaml(str_0, UserSchema)
    except Exception as exc_0:
        print(exc_0)
        assert False


# Generated at 2022-06-26 10:48:14.520420
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'K["x/Cn,f3P=N.@M#%&B'
    token_0 = tokenize_yaml(str_0)
    value_0, error_messages_0, _ = validate_yaml(str_0, token_0)
    assert error_messages_0 == []

    str_1 = ''
    token_1 = tokenize_yaml(str_1)
    value_1, error_messages_1, _ = validate_yaml(str_1, token_1)
    assert error_messages_1 == []

    str_2 = 'K["x/Cn,f3P=N.@M#%&B'
    token_2 = tokenize_yaml(str_2)
    value_2, error_messages_2,

# Generated at 2022-06-26 10:48:16.508335
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."


# Generated at 2022-06-26 10:48:19.874094
# Unit test for function validate_yaml
def test_validate_yaml():
    import pytest

    with pytest.raises(TypeError):
        validate_yaml(None, None)


# Generated at 2022-06-26 10:48:23.401381
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content='nKE\riji;\tG6@MKpT', validator=None) == (None, None)
    assert validate_yaml(content=b'', validator=None) == (None, None)
    assert validate_yaml(content='', validator=None) == (None, None)


# Generated at 2022-06-26 10:48:31.694064
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = typing.Any
    content = b'Hello'
    value, errors = validate_yaml(content, validator)

    assert value == 'Hello'
    assert isinstance(errors, list)
    assert not errors

# Generated at 2022-06-26 10:48:38.200119
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_string = """
- 1
- 2
- 3
- 4
- 5
- 6
- 7
    """
    value, error_messages = validate_yaml(yaml_string, validator=list)

    assert error_messages == []



# Generated at 2022-06-26 10:48:46.236726
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'nKE\riji;\tG6@MKpT'
    token_0 = tokenize_yaml(str_0)
    result_0 = validate_yaml(str_0, token_0)
    str_1 = '{c: 4uimb'
    token_1 = tokenize_yaml(str_1)
    result_1 = validate_yaml(str_1, token_1)
    str_2 = '\tdiT2,1<'
    token_2 = tokenize_yaml(str_2)
    result_2 = validate_yaml(str_2, token_2)
    str_3 = 'j0V7\t6;SbW1X8\vn^<'
    token_3 = tokenize_yaml(str_3)

# Generated at 2022-06-26 10:48:51.065674
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test for empty string:
    str_1 = ''
    with pytest.raises(ParseError):
        token_1 = tokenize_yaml(str_1)


# Generated at 2022-06-26 10:49:01.054485
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'mIkGd7\nYvz'
    field_0 = Field(String(max_length=5,min_length=5))
    value, errors = validate_yaml(str_0, field_0)

if __name__ == '__main__':
    # Unit tests for tokenize_yaml
    test_case_0()
    # Unit test for function validate_yaml
    test_validate_yaml()

# Generated at 2022-06-26 10:49:08.170297
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'nKE\riji;\tG6@MKpT'
    token_0 = tokenize_yaml(str_0)
    assert token_0.token_type == 'scalar'
    assert token_0._value == 'nKE\x0biji;\tG6@MKpT'
    str_1 = '1'
    token_1 = tokenize_yaml(str_1)
    assert token_1.token_type == 'scalar'
    assert token_1._value == '1'
    str_2 = '0'
    token_2 = tokenize_yaml(str_2)
    assert token_2.token_type == 'scalar'
    assert token_2._value == '0'
    str_3 = '3.14'
   

# Generated at 2022-06-26 10:49:17.307305
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:49:20.361934
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = parse_schema('{ "type": "string" }')
    str_0 = 'nKE\riji;\tG6@MKpT'
    (value_0, error_messages_0) = validate_yaml(str_0, validator)


# Generated at 2022-06-26 10:49:23.794666
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'nKE\riji;\tG6@MKpT'
    token_0 = tokenize_yaml(str_0)
    val_0, errs_0 = validate_yaml(str_0, ScalarToken)
    assert token_0 == val_0  # 'validate_yaml returned a wrong result.'
    assert errs_0 == []  # 'validate_yaml returned a wrong result.'

# Generated at 2022-06-26 10:49:30.041035
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert token_0 == ScalarToken(
        'nKE\riji;\tG6@MKpT',
        0,
        16,
        content='nKE\riji;\tG6@MKpT'
    )


# Generated at 2022-06-26 10:49:38.413130
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = 'nKE\riji;\tG6@MKpT'
    token_0 = tokenize_yaml(str_0)


# Generated at 2022-06-26 10:49:47.681280
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'nKE\riji;\tG6@MKpT'
    token_0 = tokenize_yaml(str_0)
    assert token_0.value == 'nKE\riji;\tG6@MKpT'
    assert token_0.start_index == 0
    assert token_0.end_index == len(str_0) - 1
    assert token_0.content == str_0

    str_1 = 'nKE\riji;\tG6@MKpT\n'
    token_1 = tokenize_yaml(str_1)
    assert token_1.value == 'nKE\riji;\tG6@MKpT'
    assert token_1.start_index == 0
    assert token_1.end_index == len(str_1)

# Generated at 2022-06-26 10:49:58.731294
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'nKE\riji;\tG6@MKpT'
    token_0 = tokenize_yaml(str_0)
    str_1 = '\n'
    token_1 = tokenize_yaml(str_1)
    str_2 = '\n'
    token_2 = tokenize_yaml(str_2)
    str_3 = '\n'
    token_3 = tokenize_yaml(str_3)
    str_4 = '\n'
    token_4 = tokenize_yaml(str_4)

    test_dict_0 = {
    }

# Generated at 2022-06-26 10:50:06.859728
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test 1
    str_1 = '4\nnKE\riji;\tG6@MKpT'
    token_1 = tokenize_yaml(str_1)

    assert token_1.value == '4\nnKE\riji;\tG6@MKpT'
    assert token_1.start == 0
    assert token_1.end == 9
    assert token_1.content == str_1

    # Test 2
    str_2 = 'Aa,bB'
    token_2 = tokenize_yaml(str_2)

    assert token_2.value == 'Aa,bB'
    assert token_2.start == 0
    assert token_2.end == 5
    assert token_2.content == str_2

    # Test 3

# Generated at 2022-06-26 10:50:11.321008
# Unit test for function validate_yaml
def test_validate_yaml():
    with pytest.raises(AssertionError):
        if sys.version_info[0] < 3:
            test_case_0()


# Generated at 2022-06-26 10:50:15.432100
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    str_0 = 'nKE\riji;\tG6@MKpT'
    token_0 = tokenize_yaml(str_0)



# Generated at 2022-06-26 10:50:27.796864
# Unit test for function validate_yaml
def test_validate_yaml():
    int_str = """123"""
    assert validate_yaml(int_str, Field(type=int)) == (123, [])

    parse_error_str = """
    .
    .
    .
    """
    with pytest.raises(ParseError) as exc_info:
        validate_yaml(parse_error_str, Field(type=int))

    assert exc_info.value.text == "Unexpected '.'."
    assert exc_info.value.code == "parse_error"
    assert exc_info.value.position.line_no == 4
    assert exc_info.value.position.column_no == 2
    assert exc_info.value.position.char_index == 17

    validation_error_str = """123"""

# Generated at 2022-06-26 10:50:35.097624
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test positional error reporting.
    str_0 = 'hello: world\ntest: "hi'
    str_1 = '"""'
    str_2 = '"""'
    str_3 = 'hello: world\ntest: ! "hi'
    str_4 = '"""'
    str_5 = '"""'
    str_6 = "hello: world\ntest: true\n"
    str_7 = "hello: world\ntest: no\n"
    str_8 = "hello: world\ntest: false\n"
    str_9 = "hello: world\ntest: yes\n"
    str_10 = "hello: world\ntest: null\n"
    str_11 = "hello: world\ntest: 'hi'\n"

# Generated at 2022-06-26 10:50:39.357380
# Unit test for function validate_yaml
def test_validate_yaml():
    content = 'nKE\riji;\tG6@MKpT'
    validator = Field()
    assert(validate_yaml(content, validator) == (content, None))


# Generated at 2022-06-26 10:50:43.536732
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(name='first name', required=True)
    content = 'nKE\riji;\tG6@MKpT'
    result_value, result_error_mesgs = validate_yaml(content, validator)
    assert len(result_error_mesgs) == 1
    assert result_error_mesgs[0]['code'] == 'missing_field'


# Generated at 2022-06-26 10:50:51.758680
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'nKE\riji;\tG6@MKpT'
    token_0 = tokenize_yaml(str_0)
    value_0, error_messages_0 = validate_yaml(str_0, token_0)
    assert error_messages_0 == []
    assert value_0 == str_0

# Generated at 2022-06-26 10:51:05.659614
# Unit test for function validate_yaml
def test_validate_yaml():
    class ExampleSchema(Schema):
        name = String(max_length=4)
        age = Integer(min_value=13, max_value=100)

    str_0 = 'name: "John"\nage: 42\n'
    str_1 = 'name: "John"\nage: 13\n'

    str_2 = 'name: "John"\nage: 42\n'
    str_3 = '"John"'

    str_4 = 'name: "John"\nage: 42\n'
    str_5 = 'name: "John"\nage: 101\n'

    str_6 = 'name: "John"\nage: 42\n'
    str_7 = 'name: "John"\nage: 42'  # Missing trailing newline


# Generated at 2022-06-26 10:51:17.583838
# Unit test for function validate_yaml
def test_validate_yaml():
    # arrange
    config = {
        'type': 'object',
        'properties': {
            'title': {'type': 'string', 'maxLength': 10},
            'description': {'type': 'string', 'maxLength': 10},
        },
    }
    str_0 = '''title: "Five"
description: "This is a long description that should fail"
'''

    # act
    res_0 = validate_yaml(str_0, Schema(config))

    # assert
    assert type(res_0) == tuple
    assert str(res_0[0]) == "<Object({'title': 'Five', 'description': 'This is a long description that should fail'})>"

# Generated at 2022-06-26 10:51:28.753823
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem.schemas import Schema
    from typesystem.fields import String

    class UserSchema(Schema):
        name = String(max_length=16)
        email = String(max_length=64)

    schema = UserSchema()

    # Valid
    value, error_messages = validate_yaml(b'name: John\nemail: john@example.com', schema)
    assert value == {'name': 'John', 'email': 'john@example.com'}
    assert error_messages == []

    # Invalid
    value, error_messages = validate_yaml(b'name: Too Long\nemail: john@example.com', schema)

# Generated at 2022-06-26 10:51:39.444561
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Ensure that validators behave as expected.
    value, error_messages = validate_yaml(b'key: value', {'key': 'value'})
    assert value == {'key': 'value'}
    assert error_messages == []

    value, error_messages = validate_yaml(b'key: value', {'key': [True, 1]})
    assert value == {'key': 'value'}