

# Generated at 2022-06-26 10:41:56.151755
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'D\xcas\xe2h\x145\x1d\x86\x8b\x1ftP_\xfb|N'
    token_0 = tokenize_yaml(bytes_0)
    assert token_0['D'] == "s\xe2h"
    assert token_0[145] == "\x86\x8b"
    assert token_0['tP_'] == "\xfb|N"

# Generated at 2022-06-26 10:42:08.607303
# Unit test for function validate_yaml
def test_validate_yaml():
    # Check that an error is raised when content is invalid.
    with pytest.raises(ParseError):
        validate_yaml("invalid", String(max_length=1))

    # Check that an error is raised when content is invalid.
    with pytest.raises(ParseError):
        validate_yaml("---\ninvalid", String(max_length=1))

    # Check that an error is raised when the content is missing.
    with pytest.raises(ParseError):
        validate_yaml("", String(max_length=1))

    # Check that an error is raised when the content is missing.
    with pytest.raises(ParseError):
        validate_yaml("---", String(max_length=1))

    # Check that an error is raised when the content is an empty list.
   

# Generated at 2022-06-26 10:42:20.070732
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(b'a: b') == {'a': 'b'}
    assert tokenize_yaml(b'- c') == ['c']
    assert tokenize_yaml(b'10') == 10
    assert tokenize_yaml(b'- 10') == [10]
    assert tokenize_yaml(b'10.0') == 10.0
    assert tokenize_yaml(b'cat') == 'cat'
    assert tokenize_yaml(b'"cat"') == 'cat'
    assert tokenize_yaml(b'null') is None
    assert tokenize_yaml(b'true') is True
    assert tokenize_yaml(b'false') is False

##
# Test that the validate_with_positions function returns the right validation
# error when the input is an incorrect

# Generated at 2022-06-26 10:42:32.321154
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(name="test", required=True)
    validator = Schema.of([field])

    content = "not yaml"
    with pytest.raises(ParseError) as excinfo:
        validate_yaml(content, validator)
    assert "No content." == excinfo.value.message
    assert "no_content" == excinfo.value.code
    assert "column_no" in excinfo.value.position.keys()
    assert "line_no" in excinfo.value.position.keys()
    assert "char_index" in excinfo.value.position.keys()

    content = """'name' is a required field"""
    value, errors = validate_yaml(content, validator)
    assert value is None
    assert len(errors) == 1

# Generated at 2022-06-26 10:42:41.426620
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('a: 1') == DictToken({'a': '1'}, 0, 5, content='a: 1')
    # Test that an empty string produces a useful error message.
    try:
        tokenize_yaml('')
    except ParseError as exc:
        assert (
            exc.text
            == "No content."
        ), "expected 'No content.', got {!r}".format(str(exc.text))
        assert exc.code == 'no_content', "expected 'no_content', got {!r}".format(str(exc.code))

# Generated at 2022-06-26 10:42:53.062773
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    bytes_0 = b'D\xcas\xe2h\x145\x1d\x86\x8b\x1ftP_\xfb|N'
    class DummmyValidator:
        def validate(self, token: Token) -> typing.Tuple[typing.Any, typing.Any]:
            return token.data, [ValidationError()]
    validator_0 = DummmyValidator()
    value_0, error_messages_0 = validate_yaml(
        bytes_0, validator=validator_0
    )

# Generated at 2022-06-26 10:42:59.400942
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    bytes_1 = b'D\xcas\xe2h\x145\x1d\x86\x8b\x1ftP_\xfb|N'
    token_1 = tokenize_yaml(bytes_1)
    assert token_1.value == bytes_1



# Generated at 2022-06-26 10:43:00.776635
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
  assert True == True


# Generated at 2022-06-26 10:43:06.053146
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '"Hello\nWorld!"'
    validator = Field(type="string", pattern=r"^[A-Z]{5}\n[A-Z]{5}!$")

    # Test with a string
    assert validate_yaml(content, validator)[0] == "Hello\nWorld!"

    # Test with a bytestring
    assert validate_yaml(content.encode(), validator)[0] == "Hello\nWorld!"



# Generated at 2022-06-26 10:43:17.371260
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    assert tokenize_yaml("name: John Smith\n") == {"name": "John Smith"}
    assert tokenize_yaml("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_yaml('{"name": "John Smith"}') == {"name": "John Smith"}

    # Handle empty case.
    try:
        tokenize_yaml("")
        assert False, "Didn't raise on empty input."
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1

    # Handle parse error case. Add an extra line.

# Generated at 2022-06-26 10:43:30.443742
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'D\xcas\xe2h\x145\x1d\x86\x8b\x1ftP_\xfb|N'
    bytes_1 = b'L\xcc\x19z\x8b\x1b\xaf\xf4\xfd\xe4E\x9b\x1b\x86\rH\xcd\xf6\xde[\x1b\xcd\x99\xe9\xdb\xf6\x8d\xbd\x99\xdc\x19\x8d\x07\x9f\x9c\x16\x96\xf2l)\xaa\xb3'

# Generated at 2022-06-26 10:43:41.075776
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import (
        String,
        Integer,
        Boolean,
        DateTime,
        Array,
        Object,
    )
    class Article(Schema):
        title = String()
        published = DateTime()
        is_published = Boolean()
        likes = Integer(minimum=100)
        tags = Array(items=String())
        metadata = Object(properties={'width': Integer(), 'height': Integer()})
        author = Object(properties={'name': String(), 'email': String()}, required=['name'])


# Generated at 2022-06-26 10:43:53.952121
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'D\xcas\xe2h\x145\x1d\x86\x8b\x1ftP_\xfb|N'
    str_0 = 'DàsèhE\x1d\x86\x8b\x1ftP_û|N'
    bytes_1 = b'\x03\x01\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00'
    str_1 = '\x03\x01\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-26 10:43:57.958094
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'D\xcas\xe2h\x145\x1d\x86\x8b\x1ftP_\xfb|N'
    token_0 = tokenize_yaml(bytes_0)
    assert (token_0, []) == validate_yaml(bytes_0, {"type": "string"})



# Generated at 2022-06-26 10:44:09.150278
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'D\xcas\xe2h\x145\x1d\x86\x8b\x1ftP_\xfb|N'

# Generated at 2022-06-26 10:44:16.896304
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b'[{]\n'
    validator = Field()
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == [
        Message(
            message="An array was expected, but got a dict.",
            code="invalid_type",
            column_no=2,
            line_no=2,
            char_index=1,
        )
    ]
    assert value == {}

# Generated at 2022-06-26 10:44:29.981184
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'D\xcas\xe2h\x145\x1d\x86\x8b\x1ftP_\xfb|N'
    token_0 = tokenize_yaml(bytes_0)
    bytes_1 = b'D\xcas\xe2h\x145\x1d\x86\x8b\x1ftP_\xfb|N'
    token_1 = tokenize_yaml(bytes_1)
    bytes_2 = b'D\xcas\xe2h\x145\x1d\x86\x8b\x1ftP_\xfb|N'
    token_2 = tokenize_yaml(bytes_2)

# Generated at 2022-06-26 10:44:41.357946
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem
    import random
    import types
    import datetime
    import typesystem.schemas
    import typesystem.fields

    random.seed(848507)
    suffixes = [b'', b'\n', b'\r', b'\r\n', b'\r\n  \n', b'\r\n  \r']

    def generate_token_0(depth=0):
        if depth > 3:
            return ScalarToken(b'', 0, 0, content=b'')
        if random.random() < 0.9:
            if random.random() < 0.8:
                return DictToken({}, 0, 0, content=b'')
            return ListToken([], 0, 0, content=b'')

# Generated at 2022-06-26 10:44:48.977091
# Unit test for function validate_yaml
def test_validate_yaml():
    import uuid
    import json
    import base64

    def encode_bytes_as_json(bytes_content: bytes) -> str:
        """Encode a bytestring content as a JSON string, handling special
        character encoding.
        """
        return json.dumps(
            base64.b64encode(bytes_content).decode("utf-8"), ensure_ascii=False
        )

    validator = Field(type_name="string")

    bytes_0 = b'D\xcas\xe2h\x145\x1d\x86\x8b\x1ftP_\xfb|N'
    value_0, errors_0 = validate_yaml(
        content=bytes_0, validator=validator
    )

# Generated at 2022-06-26 10:45:00.792694
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"{'id': '123', 'name': null}"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)
    validator = typing.cast(
        typing.Type[Schema],
        typing.cast(typing.Any, type(typing.cast(Schema, typing.Any))),
    )
    values, error_messages = validate_yaml(content, validator)
    assert len(error_messages) == 1
    assert isinstance(error_messages[0], Message)
    assert error_messages[0].code == "no_id"

# Generated at 2022-06-26 10:45:11.721820
# Unit test for function validate_yaml
def test_validate_yaml():
    validator_0 = DateFormat(format="%Y-%m-%dT%H:%M:%S")
    validator_1 = IntegerFormat(format="int32")
    validator_2 = PrimitiveFormat(format="byte")
    validator_3 = FloatFormat(format="double")
    validator_4 = BooleanFormat()
    validator_5 = NumberFormat(format="float")
    validator_6 = StringFormat(format="email")
    validator_7 = StringFormat(format="binary")
    validator_8 = StringFormat(format="password")
    validator_9 = StringFormat(format="byte")
    validator_10 = StringFormat(format="date")
    validator_11 = StringFormat(format="date-time")
    validator_12 = StringFormat(format="uuid")


# Generated at 2022-06-26 10:45:23.664053
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    class TestSchema(Schema):
        pass
    class TestField(Field):
        pass
    str_0 = 'T4XW\\UK(\t~v9]PGH'
    expected_0 = (
        Message(
            text='',
            code='validation_error',
            position=Position(column_no=None, line_no=None, char_index=None),
        ),
    )
    value_0, error_messages_0 = validate_yaml(str_0, TestSchema)
    assert error_messages_0 == expected_0
    str_1 = 'T4XW\\UK(\t~v9]PGH'

# Generated at 2022-06-26 10:45:28.487019
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(properties={"a": {"type": "string"}})
    value, error_messages = validate_yaml("a: A", schema)
    assert not error_messages
    assert value == {"a": "A"}

# Generated at 2022-06-26 10:45:34.523049
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        assert validate_yaml(content='[1, 2]', validator=ListDef([IntegerDef()]))
    except Exception as exc:
        print('validate_yaml() raised Exception when it should not')
        raise exc


# Generated at 2022-06-26 10:45:40.769991
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "42"
    token_0 = tokenize_yaml(str_0)
    assert token_0.value == '42'
    assert token_0.start_index == 0
    assert token_0.end_index == 1
    assert str_0[token_0.start_index:token_0.end_index + 1] == token_0.content



# Generated at 2022-06-26 10:45:51.640054
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {
            "data": {"name": str, "age": int},
            "meta": {
                "page": int,
                "pages": int,
                "next": {"url": str, "page": int},
                "prev": {"url": str, "page": int},
            },
        },
        description="A data page.",
    )
    value_0, error_messages_0 = validate_yaml(
        content=b"", validator=schema,
    )
    assert error_messages_0 == [
        Message(
            type="error",
            text="No content.",
            code="no_content",
            position=Position(column_no=1, line_no=1, char_index=0),
        )
    ]
    value_1, error_

# Generated at 2022-06-26 10:45:56.734883
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type="string", max_length=32)
    content = "Simple string."
    value, errors = validate_yaml(content, validator)
    assert value == content
    assert not errors


# Generated at 2022-06-26 10:46:04.113287
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '#\\%\t\x00\n\x0b\x0b\x00\x0b\x0c\x00\x1e\x00'
    token_0 = tokenize_yaml(str_0)
    assert token_0.start_index == 0
    assert token_0.end_index == 13
    assert token_0.content == str_0


# Generated at 2022-06-26 10:46:14.541819
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'T4XW\\UK(\t~v9]PGH'
    token_0 = tokenize_yaml(str_0)

    class Schema_0(Schema):
        field = 'T4XW\\UK(\t~v9]PGH'

    str_1 = 'T4XW\\UK(\t~v9]PGH'
    token_1 = tokenize_yaml(str_1)

    class Schema_1(Schema):
        field = 'T4XW\\UK(\t~v9]PGH'

    str_2 = 'T4XW\\UK(\t~v9]PGH'
    token_2 = tokenize_yaml(str_2)


# Generated at 2022-06-26 10:46:24.547611
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = 'T4XW\\UK(\t~v9]PGH'
    token_0 = tokenize_yaml(str_0)

    assert token_0.content == str_0

    str_1 = '\n\n  Hello\n\n   World\n'
    token_1 = tokenize_yaml(str_1)

    assert token_1.content == str_1

    str_2 = '\n\n  Hello\n\n   World\n'
    token_2 = tokenize_yaml(str_2)

    str_3 = '\n\n Hello\n\n  World\n'
    token_3 = tokenize_yaml(str_3)

    assert token_2.content == str_2
    assert token_3.content == str_3



# Generated at 2022-06-26 10:46:36.207671
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test parsing YAML files.
    input_0 = """
    A: B
    C: D
    """
    schema_0 = Schema(
        fields={
            "A": Field(required=True),
            "C": Field(required=True),
            "E": Field(required=True),
        }
    )
    value_0, error_messages_0 = validate_yaml(input_0, validator=schema_0)
    assert len(error_messages_0) == 1
    assert error_messages_0[0].text == "Missing required field 'E'."
    assert error_messages_0[0].position.line_no == 3
    assert error_messages_0[0].position.column_no == 0
    input_1 = '"a string"'
    schema_

# Generated at 2022-06-26 10:46:46.263598
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = 'T4XW\\UK(\t~v9]PGH'
    str_1 = 'n5;5B'
    str_2 = '{"4":"4"}'
    str_3 = '{4:4}'
    str_4 = '{"4":4}'
    str_5 = '{"4": null}'
    str_6 = '{"": 4}'
    str_7 = '{"4": "4"}'
    str_8 = '{"4": 4}'
    str_9 = '{"4": "4", "5": "5"}'
    str_10 = '{"4": 4, "5": "5"}'
    str_11 = '{"4": 4, "5": 5}'
    str_12 = 'n5;5B'
    str_

# Generated at 2022-06-26 10:46:53.135697
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'T4XW\\UK(\t~v9]PGH'
    token_0 = tokenize_yaml(str_0)
    value_0, error_messages_0 = validate_yaml(content=str_0, validator=token_0)
    assert value_0 == 'T4XW\\UK(\t~v9]PGH'
    assert error_messages_0 == []


# Generated at 2022-06-26 10:46:56.303420
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert token_0 == ScalarToken(str_0, 0, len(str_0) - 1, content=str_0), 'incorrect value for token_0'


# Generated at 2022-06-26 10:47:08.178329
# Unit test for function validate_yaml
def test_validate_yaml():
    func_name = 'validate_yaml'
    file_name = 'validate_yaml'
    # Load test cases
    stream = io.open('test_cases/%s.json' % file_name, 'r', encoding='utf-8')
    test_cases = json.loads(stream.read())
    is_pass = 0
    case_num = 0
    for test_case in test_cases:
        case_num += 1
        print('Unit test for %s, case number %d:' % (func_name, case_num))
        is_pass = 1
        info = test_case['info']
        expect = test_case['expect']
        # test

# Generated at 2022-06-26 10:47:16.779324
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String, Integer, Boolean, Float

    class DemoSchema(Schema):
        string = String()
        integer = Integer()
        boolean = Boolean()
        float = Float()

    content = """
    string: demo
    integer: 1
    boolean: true
    float: 2.1
    """

    errors = validate_yaml(content, DemoSchema)
    assert not errors



# Generated at 2022-06-26 10:47:19.007403
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    pass

# Generated at 2022-06-26 10:47:27.266902
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'T4XW\\UK(\t~v9]PGH'
    assert repr(validate_yaml(str_0, None)[1][0]) == repr({'text': '{}'.format('Could not parse YAML.'), 'code': 'no_content', 'position': {'column_no': 2, 'line_no': 1, 'char_index': 1}})

# Generated at 2022-06-26 10:47:39.911733
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "foo: bar\n"
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, DictToken)
    assert len(token_0) == 1
    assert token_0["foo"].value == "bar"
    assert token_0["foo"].start_column == 6
    assert token_0["foo"].end_column == 9
    assert len(token_0["foo"]) == 4

    token_0 = tokenize_yaml(b"foo: bar\n")
    assert isinstance(token_0, DictToken)

    str_1 = "foo:\n- bar\n- baz\n"
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, DictToken)

# Generated at 2022-06-26 10:47:44.424709
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'T4XW\\UK(\t~v9]PGH'
    token_0 = tokenize_yaml(str_0)
    str_1 = 'T4XW\\UK(\t~v9]PGH'
    token_1 = tokenize_yaml(str_1)
    expected = None
    actual = validate_yaml(str_1, token_1)
    assert actual == expected



# Generated at 2022-06-26 10:47:52.762866
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:47:59.796000
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'T4XW\\UK(\t~v9]PGH'
    class Schema_0(Schema):
        str_0 = str

    value, error_messages = validate_yaml(str_0, Schema_0)
    assert error_messages == {}

###


# Generated at 2022-06-26 10:48:03.984730
# Unit test for function validate_yaml
def test_validate_yaml():
    assert isinstance(validate_yaml(content=str, validator=Field), typing.Tuple)
    assert isinstance(validate_yaml(content=bytes, validator=Field), typing.Tuple)
    assert isinstance(validate_yaml(content=str, validator=Schema), typing.Tuple)
    assert isinstance(validate_yaml(content=bytes, validator=Schema), typing.Tuple)



# Generated at 2022-06-26 10:48:12.630100
# Unit test for function validate_yaml
def test_validate_yaml():
    # Case 1
    try:
        str_1 = '{a:b}'
        token_1 = tokenize_yaml(str_1)
    except Exception as e:
        ErrorIndication = True
    else:
        ErrorIndication = False
    assert ErrorIndication is True, 'unexpected behaviour'
    # Case 2
    try:
        str_2 = '{a:c}'
        token_2 = tokenize_yaml(str_2)
    except Exception as e:
        ErrorIndication = True
    else:
        ErrorIndication = False
    assert ErrorIndication is True, 'unexpected behaviour'
    # Case 3

# Generated at 2022-06-26 10:48:17.972421
# Unit test for function validate_yaml
def test_validate_yaml():
    # Ensure function raises error for empty string
    with pytest.raises(ParseError):
        validate_yaml('', 'field')
        validate_yaml('', 'schema')
    # Ensure function raises error for missing colon
    with pytest.raises(ParseError):
        validate_yaml('name', 'field')
        validate_yaml('name', 'schema')
    # Ensure function raises error for missing colon of node
    with pytest.raises(ParseError):
        validate_yaml('name:', 'field')
        validate_yaml('name:', 'schema')


# Generated at 2022-06-26 10:48:22.192367
# Unit test for function validate_yaml
def test_validate_yaml():
    ctx = load_fixture("keyword_arguments.yaml")
    value, errors = validate_yaml(ctx.source, ctx.schema)
    assert not errors
    assert value == {
        "title": "Bar",
        "publisher": "Foo",
        "publication_date": datetime(2017, 1, 1),
    }



# Generated at 2022-06-26 10:48:30.401811
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'T4XW\\UK(\t~v9]PGH'
    token_0 = tokenize_yaml(str_0)
    validator = Field()
    value, errors = validate_yaml(str_0, validator)


if __name__ == "__main__":
    test_case_0()
    test_validate_yaml()

# Generated at 2022-06-26 10:48:35.291435
# Unit test for function validate_yaml
def test_validate_yaml():
    import os
    return_value = os.system('python3 $WORKSPACE/python-project/test_validate_yaml.py')
    assert return_value == 0


# Generated at 2022-06-26 10:48:37.253089
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test type
    assert isinstance(validate_yaml(content='content', validator=Field), tuple)

# Generated at 2022-06-26 10:48:46.013215
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = "MySchema"
        age = Field(type="integer")

    token = tokenize_yaml(b'{"age": 50}')
    assert validate_yaml(b'{"age": 50}', MySchema) == ({"age": 50}, [])

    token = tokenize_yaml(b'{"age": "50"}')
    assert validate_yaml(b'{"age": "50"}', MySchema) == ({"age": "50"}, [])
    assert validate_yaml(b'{"age": 50}', "integer") == (50, [])

    token = tokenize_yaml(b'["not", "an", "object"]')

# Generated at 2022-06-26 10:49:04.739387
# Unit test for function validate_yaml
def test_validate_yaml():
    value, errs = validate_yaml({}, DictToken({'a': 1}, start=0, end=0, content={}))
    if value != {'a': 1}:
        raise ValueError('invalid value')
    if len(errs) != 0:
        raise ValueError('invalid errors')
    value, errs = validate_yaml(0, IntToken(1, start=0, end=0, content={}))
    if value != 1:
        raise ValueError('invalid value')
    if len(errs) != 0:
        raise ValueError('invalid errors')

# Generated at 2022-06-26 10:49:11.801790
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = '!h_!r5r5'
    token_1 = tokenize_yaml(str_1)
    assert type(token_1) == DictToken
    assert token_1.content == str_1
    assert token_1.start == 0
    assert token_1.end == 7
    return None


# Generated at 2022-06-26 10:49:16.979426
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class MySchema(Schema):
        name = String()

    value, errors = validate_yaml(content='{name: ""}', validator=MySchema)

# Generated at 2022-06-26 10:49:25.901685
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'T4XW\\UK(\t~v9]PGH'
    str_1 = '\t;X\\Lx/a{R\\Lw>Y\t'
    str_2 = '?\t\nsBW\t'
    str_3 = '\n'
    str_4 = '@(U=35Rf\n'
    str_5 = 'u\n'
    str_6 = '\tW_0u\n'
    str_7 = '\t'
    str_8 = '\tG\t\n'
    str_9 = '\t\n'
    str_10 = '\t\n'
    str_11 = '\tG\t\n'
    str_12 = '\t\n'

# Generated at 2022-06-26 10:49:37.335471
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:49:44.990488
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None
    assert callable(tokenize_yaml)

    str_2 = "some_string: 'a string'    \n\n  # comment"
    token_2 = tokenize_yaml(str_2)
    assert type(token_2) == DictToken
    assert token_2.start == 0
    assert token_2.end == 34

    str_3 = "1.2\n"
    token_3 = tokenize_yaml(str_3)
    assert type(token_3) == ScalarToken
    assert token_3.start == 0
    assert token_3.end == 3

    try:
        token_4 = tokenize_yaml(5)
    except TypeError:
        pass

    str_5 = '"a string\n'

# Generated at 2022-06-26 10:49:55.630344
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # Assert exceptions, calls, and types for tokenize_yaml
    assert str_0 == "T4XW\\UK(\t~v9]PGH"
    with pytest.raises(ParseError):
        tokenize_yaml(str_0)

    # Assertions with/without PyYAML installed.
    if yaml is None:  # pragma: no cover
        with pytest.raises(NotImplementedError):
            tokenize_yaml(str_0)
    else:
        tokenize_yaml(str_0)



# Generated at 2022-06-26 10:50:08.395874
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'R|>t#}h"v*8D`W0GG'
    value_0, errors_0 = validate_yaml(str_0, str)
    assert not errors_0
    assert value_0 == str_0
    str_1 = '?nV7iU6/!$%m8r>x'
    value_1, errors_1 = validate_yaml(str_1, str)
    assert not errors_1
    assert value_1 == str_1
    str_2 = 'G`f_Q2q-1&Uzwue'
    value_2, errors_2 = validate_yaml(str_2, str)
    assert not errors_2
    assert value_2 == str_2

# Generated at 2022-06-26 10:50:20.260606
# Unit test for function validate_yaml
def test_validate_yaml():

    # No error, no error messages
    value, error_messages = validate_yaml(
        validator=Field(),
        content="""
        - a
        - b
        - c
        """,
    )
    assert error_messages == []
    assert value == ["a", "b", "c"]

    # Unexpected 'z' in error messages
    value, error_messages = validate_yaml(
        validator=Field(),
        content="""
        - a
        - b
        - c
        - z
        """,
    )
    assert len(error_messages) == 1

# Generated at 2022-06-26 10:50:29.080241
# Unit test for function validate_yaml
def test_validate_yaml():
    with pytest.raises(ParseError):
        validate_yaml("", str)
    assert validate_yaml("", str) == (None, [])
    assert validate_yaml("", int) == (None, [])
    with pytest.raises(ParseError):
        validate_yaml("", Schema)
    assert validate_yaml("", Schema) == (None, [])
    with pytest.raises(ValidationError):
        validate_yaml('{', str)
    assert validate_yaml('{', str) == (None, [])
    assert validate_yaml('{', int) == (None, [])
    with pytest.raises(ValidationError):
        validate_yaml('{', Schema)

# Generated at 2022-06-26 10:50:54.888280
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    str_0 = '{a: 1, b: "abc"}'
    str_1 = '{a: 1, b: "abc"}'
    dict_0 = {'a': 1, 'b': 'abc'}
    dict_1 = {'a': '1', 'b': 'abc'}
    class Schema_0(Schema):
        foo = Field(type="object", properties={"a": Field(type="integer"), "b": Field(type="string")})
    validator_0 = Schema_0()
    value_1, error_messages_1 = validate_yaml(str_0, validator_0)

    assert dict_1 == value_1
    assert [] == error_messages_1
    validator_

# Generated at 2022-06-26 10:51:07.638211
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = 'T4XW\\UK(\t~v9]PGH'
    token_0 = tokenize_yaml(str_0)
    str_1 = 'vFtV9A&'
    token_1 = tokenize_yaml(str_1)
    str_2 = '0hD\n\\XK\\FKB#'
    token_2 = tokenize_yaml(str_2)
    str_3 = 'nX\tf'
    token_3 = tokenize_yaml(str_3)
    str_4 = 'Z\toztj_'
    token_4 = tokenize_yaml(str_4)
    str_5 = '\"[\\O\"'
    token_5 = tokenize_yaml(str_5)

# Generated at 2022-06-26 10:51:13.092945
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'T4XW\\UK(\t~v9]PGH'
    token_0 = tokenize_yaml(str_0)
    assert False == isinstance(token_0, DictToken)

    str_1 = '"\\""'
    token_1 = tokenize_yaml(str_1)
    assert False == isinstance(token_1, ScalarToken)

    str_2 = 'd\tF"\\""'
    token_2 = tokenize_yaml(str_2)
    assert False == isinstance(token_2, ListToken)

    str_3 = 'a"Z"!'
    token_3 = tokenize_yaml(str_3)
    assert True == isinstance(token_3, ListToken)



# Generated at 2022-06-26 10:51:26.631451
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'T4XW\\UK(\t~v9]PGH'
    token_0 = tokenize_yaml(str_0)

# Generated at 2022-06-26 10:51:38.592082
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'T4XW\\UK(\t~v9]PGH'
    token_0 = tokenize_yaml(str_0)
    __, errors = validate_yaml(str_0, token_0)
    assert len(errors) == 1
    assert errors[0].code == 'invalid_type'
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 1
    assert errors[0].position.char_index == 0
    str_1 = '{'
    token_1 = tokenize_yaml(str_1)
    __, errors = validate_yaml(str_1, token_1)
    assert len(errors) == 1
    assert errors[0].code == 'parse_error'
    assert errors[0].position.line