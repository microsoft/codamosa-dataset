

# Generated at 2022-06-26 10:41:44.448644
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert True # TODO: implement your test here



# Generated at 2022-06-26 10:41:55.583801
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'YL#\xaa'
    errors_0 = validate_yaml(bytes_0, None)
    # Actual error message may vary depending on platform and locale so we
    # simply test for the presence of the necessary fields.
    assert "code" in errors_0[1][0]
    assert "text" in errors_0[1][0]
    assert "position" in errors_0[1][0]
    assert "code" in errors_0[1][1]
    assert "text" in errors_0[1][1]
    assert "position" in errors_0[1][1]


# Generated at 2022-06-26 10:42:08.330101
# Unit test for function validate_yaml
def test_validate_yaml():
    def init_validator(
        *, description: typing.Optional[str] = None,
    ) -> typing.Type[Schema]:
        class Validator(Schema):
            @property
            def _schema_name(self) -> str:
                return "test"

        return Validator

    def init_content(
        *,
        text: typing.Optional[str] = None,
    ) -> typing.Union[str, bytes]:
        content = text or ""
        return content


# Generated at 2022-06-26 10:42:12.094024
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test arguments
    content = ""
    validator = ""

    # Execution
    with pytest.raises(Exception):
        result = validate_yaml(content, validator)

# Generated at 2022-06-26 10:42:19.767467
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None
    assert SafeLoader is not None

    bytes_0 = b'YL#\xaa'
    token_0 = tokenize_yaml(bytes_0)

    # Test that the value of the token contains the expected value.
    expected_0 = b'YL#\xaa'
    value_0 = token_0.value
    assert value_0 == expected_0

    # Test that the start position of the token contains the expected value.
    expected_1 = 0
    start_0 = token_0.start
    assert start_0 == expected_1

    # Test that the end position of the token contains the expected value.
    expected_2 = 4
    end_0 = token_0.end
    assert end_0 == expected_2

    # Test that the token contains the expected content string.
    expected

# Generated at 2022-06-26 10:42:24.442471
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    with pytest.raises(ParseError) as error:
        bytes_0 = b'YL#\xaa'

        token_0 = tokenize_yaml(bytes_0)


# Generated at 2022-06-26 10:42:26.619151
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert False  # TODO: implement your test here

test_case_0()

# Generated at 2022-06-26 10:42:36.050235
# Unit test for function validate_yaml
def test_validate_yaml():
    class BasicSchema(Schema):
        country = Field(type='text')
        state = Field(type='text')
        city = Field(type='text')

    content = """
    country: United States
    state: California
    city: San Francisco
    """
    BasicSchema.validate(content)

    content = """
    country: United States
    state: California
    city: San Francisco
    - city: Los Angeles
      state: California
    """
    value, errors = validate_yaml(content, validator=BasicSchema)
    assert errors[0].code == "error_non_dict_value"

    content = """
    country: United States
    state: California
    - city: San Francisco
      bad_field: value
    """

# Generated at 2022-06-26 10:42:37.184659
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), Token)


# Generated at 2022-06-26 10:42:41.914020
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        i = Field(type="integer")

    # Test.
    value, messages = validate_yaml(b"i: foo", validator=TestSchema)
    assert value == {}

    # Test.
    value, messages = validate_yaml(b"i: 123", validator=TestSchema)
    assert value["i"] == 123

    # Teardown.

# Generated at 2022-06-26 10:42:58.074109
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert not sys.warnoptions
    assert yaml is not None, "'PyYAML' must be installed."

    assert all(
        isinstance(token, ScalarToken)
        for token in tokenize_yaml(str_0)
    ), "Tokenize scalar tokens."

    assert all(
        isinstance(token, ListToken)
        for token in tokenize_yaml(str_1)
    ), "Tokenize list tokens."

    assert all(
        isinstance(token, DictToken)
        for token in tokenize_yaml(str_2)
    ), "Tokenize dict tokens."

    assert all(
        isinstance(token, DictToken)
        for token in tokenize_yaml(str_3)
    ), "Tokenize dict tokens."


# Generated at 2022-06-26 10:43:07.285138
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, Integer, String, Array

    class MySchema(Schema):
        foo = Integer()
        bar = String()

    yaml_str = """\
foo: 3
bar: hi
"""
    value, error_messages = validate_yaml(yaml_str, MySchema())
    assert value == {"foo": 3, "bar": "hi"}
    assert not error_messages

    yaml_str = """\
foo:
  1
  2
  3
"""
    value, error_messages = validate_yaml(yaml_str, {"foo": Array(Integer())})
    assert value == {"foo": [1, 2, 3]}
    assert not error_messages

    yaml_str = """\
foo:
  1
  2
  3
"""
   

# Generated at 2022-06-26 10:43:17.821357
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '{}'
    token_0 = tokenize_yaml(str_0)
    assert token_0.start_index == 0
    assert token_0.end_index == 1
    assert isinstance(token_0, DictToken)
    assert token_0.value == {}

    str_1 = '[]'
    token_1 = tokenize_yaml(bytes(str_1, 'UTF-8'))
    assert token_1.start_index == 0
    assert token_1.end_index == 1
    assert isinstance(token_1, ListToken)
    assert token_1.value == []

    str_2 = '"foo"'
    token_2 = tokenize_yaml(str_2)
    assert token_2.start_index == 0
    assert token_2.end

# Generated at 2022-06-26 10:43:29.204536
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '}]Ea'
    token_0 = tokenize_yaml(str_0)
    str_1 = 'person:'
    token_1 = tokenize_yaml(str_1)
    str_2 = 'person:'
    token_2 = tokenize_yaml(str_2)
    str_3 = 'person'
    token_3 = tokenize_yaml(str_3)
    str_4 = 'person'
    token_4 = tokenize_yaml(str_4)
    str_5 = 'person:'
    token_5 = tokenize_yaml(str_5)
    str_6 = 'person:'
    token_6 = tokenize_yaml(str_6)
    str_7 = 'person:'

# Generated at 2022-06-26 10:43:30.137919
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert callable(tokenize_yaml)

# Generated at 2022-06-26 10:43:36.498192
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "hello"
    field_0 = Field(type="string")
    value_0, error_messages_0 = validate_yaml(str_0, field_0)
    assert value_0 == "hello"
    assert len(error_messages_0) == 0
    str_1 = '"\''
    field_1 = Field(type="string")
    value_1, error_messages_1 = validate_yaml(str_1, field_1)
    assert value_1 == "\"'"
    assert len(error_messages_1) == 0
    str_2 = '"/'
    field_2 = Field(type="string")
    value_2, error_messages_2 = validate_yaml(str_2, field_2)

# Generated at 2022-06-26 10:43:48.946180
# Unit test for function validate_yaml
def test_validate_yaml():
    camelia = yaml.CSafeLoader.add_constructor(
        'tag:yaml.org,2002:python/none',
        lambda loader, node: None)
    data1 = """
    - {bool: true, None: null, str: apple}
    - {str: banana}
    -
      - {str: cat}
      - {str: dog}
    - [{str: egg}, {str: flower}]
    - {nested: {str: nested}, str: top}
    """

# Generated at 2022-06-26 10:43:55.662899
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '}]Ea'

    # Call function tokenize_yaml
    with pytest.raises(ParseError) as error:
        tokenize_yaml(str_0)

    assert str(error.value) == 'Parse error at line 1, column 3:\n\'}\' found where <dict>, <list>, <str> or <float> expected.'


# Generated at 2022-06-26 10:44:08.391963
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "9"
    token_0 = tokenize_yaml(str_0)
    value_0, error_messages_0 = validate_yaml(str_0, Field(type="integer"))
    assert value_0 == 9
    assert error_messages_0 == {}
    str_1 = '"abc"'
    token_1 = tokenize_yaml(str_1)
    value_1, error_messages_1 = validate_yaml(str_1, Field(type="integer"))
    assert value_1 == "abc"

# Generated at 2022-06-26 10:44:12.019248
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    try:
        assert 1
    except AssertionError:
        raise AssertionError(str(1))



# Generated at 2022-06-26 10:44:30.162149
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem
    str_0 = '[true, true]'
    validator_1 = typesystem.Array(items=typesystem.Boolean())
    assert validate_yaml(str_0, validator_1) == ([True, True], [])

    str_0 = '[true]'
    validator_1 = typesystem.Array(items=typesystem.Boolean(required=True))
    assert validate_yaml(str_0, validator_1) == ([True], [])

    str_0 = '[null, null]'
    validator_1 = typesystem.Array(items=typesystem.Boolean(required=True))

# Generated at 2022-06-26 10:44:39.399555
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '{}'
    token_0 = tokenize_yaml(str_0)
    str_1 = '[0, 1]'
    token_1 = tokenize_yaml(str_1)
    str_2 = '{"b": 1, "a": 2}'
    token_2 = tokenize_yaml(str_2)


    assert_equals(type(token_0), DictToken)
    assert_equals(type(token_1), ListToken)
    assert_equals(type(token_2), DictToken)



# Generated at 2022-06-26 10:44:47.794286
# Unit test for function validate_yaml
def test_validate_yaml():
    class FooSchema(Schema):
        foo = Field(str)
        bar = Field(str)

    content = b"---\n{1:2, 2:3}"
    result = validate_yaml(content, FooSchema)
    assert result[1] == [ValidationError(code='type', text='Must be of type string.', position=Position(column_no=2, char_index=3, line_no=2), params={'type': 'str'})]

# Generated at 2022-06-26 10:44:58.175312
# Unit test for function validate_yaml
def test_validate_yaml():
    # Check if function return the expected result.
    assert validate_yaml(
        str_0, validator=validator
    ) == test_validate_yaml.expected_result
    # Check if function produces expected error message.
    try:
        validate_yaml(str_0, validator=validator)
    except AssertionError as e:
        assert test_validate_yaml.expected_error in str(e)


# Generated at 2022-06-26 10:45:00.099755
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '}]Ea'
    value_0, messages_0 = validate_yaml(str_0)
    print(value_0)

# Generated at 2022-06-26 10:45:01.635304
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert callable(tokenize_yaml)

# Generated at 2022-06-26 10:45:11.438243
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(validators=["length_is_1"])
    value, error_messages = validate_yaml("test", field)
    assert value == "test"
    assert len(error_messages) == 1
    message = error_messages[0]
    assert message == Message(
        text="Length must be 1.",
        code="length_is_1",
        position=Position(line_no=1, column_no=2, char_index=1),
    )

# Generated at 2022-06-26 10:45:21.962356
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    validator = Field(int)
    str_0 = '"123"'
    value_0, errors_0 = validate_yaml(str_0, validator)

    assert errors_0 == [
        Message(
            text="Expected a JSON integer.",
            code="invalid_type",
            type_name="integer",
            position=Position(char_index=0, column_no=1, line_no=1),
        )
    ]

    str_1 = '123'
    value_1, errors_1 = validate_yaml(str_1, validator)

    assert value_1 == 123
    assert errors_1 == []

    str_2 = '---\n- 1\n- 2\n- 3\n'

# Generated at 2022-06-26 10:45:32.751307
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = ""
    str_1 = "a"
    str_2 = "a:b"
    str_3 = "a:az"
    str_4 = "a: b"
    str_5 = "a: bz"
    value_0, position_0 = validate_yaml(str_0, str)
    value_1, position_1 = validate_yaml(str_1, str)
    value_2, position_2 = validate_yaml(str_2, str)
    value_3, position_3 = validate_yaml(str_3, str)
    value_4, position_4 = validate_yaml(str_4, str)
    value_5, position_5 = validate_yaml(str_5, str)
  # assert value_1 == str_1
 

# Generated at 2022-06-26 10:45:37.990604
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '"123"\n'
    validator = int
    res_0 = validate_yaml(str_0, validator)
    assert res_0[0] == 123 and len(res_0[1]) == 0

    str_1 = '"123"\n'
    validator = float
    res_1 = validate_yaml(str_1, validator)
    assert res_1[0] == 123.0 and len(res_1[1]) == 0

    str_2 = '"123"\n'
    validator = str
    res_2 = validate_yaml(str_2, validator)
    assert res_2[0] == "123" and len(res_2[1]) == 0

    str_3 = '123\n'
    validator = str
   

# Generated at 2022-06-26 10:45:52.566387
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_0 = '@'
    class Schema_0(Schema):
        a = Field()
    try:
        token_0 = tokenize_yaml(yaml_0)
    except ParseError:
        pass
    else:
        raise RuntimeError
    try:
        value_0, errors_0 = validate_yaml(yaml_0, Schema_0)
    except ParseError:
        pass
    else:
        raise RuntimeError
    yaml_0 = 'a: 123'
    token_0 = tokenize_yaml(yaml_0)
    class Schema_0(Schema):
        a = Field()
    value_0, errors_0 = validate_yaml(yaml_0, Schema_0)
    assert value_0 == {'a': 123}


# Generated at 2022-06-26 10:46:02.769956
# Unit test for function validate_yaml
def test_validate_yaml():
    str1 = '''
      bar:
        foo: bar
      foo:
        bar: baz
    '''
    str2 = '''
      foo:
        bar: baz
      bar:
        foo: bar
    '''
    foo = Field(type='string', required=True)
    bar = Field(type='string', required=True)
    FooSchema = Schema(fields={'foo': foo, 'bar': bar})
    value1, errors1 = validate_yaml(str1, FooSchema)
    value2, errors2 = validate_yaml(str2, FooSchema)

# Generated at 2022-06-26 10:46:14.199490
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_1 = '\n   \n'
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, ScalarToken)
    assert token_1.value == '\n   \n'
    assert token_1.start == 0
    assert token_1.end == 6
    assert token_1.content == '\n   \n'

    str_2 = '---\n- one\n- two\n- three\n'
    token_2 = tokenize_yaml(str_2)
    assert isinstance(token_2, ListToken)
    assert isinstance(token_2[0], ScalarToken)
    assert token_2[0].value == 'one'
    assert token_2[0].start == 4

# Generated at 2022-06-26 10:46:24.448806
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    str_0 = '\t  - abc\n  - cde\n'
    token_0 = tokenize_yaml(str_0)

    assert isinstance(token_0, ListToken)
    assert token_0.data == ['abc', 'cde']
    assert token_0.start == 0
    assert token_0.end == 15
    assert token_0.end - token_0.start == 15
    assert token_0.content == str_0

    token_1 = token_0.data[0]
    assert isinstance(token_1, ScalarToken)
    assert token_1.start == 5
    assert token_1.end == 9
    assert token_1.end - token_1.start == 4
    assert token_1.data == 'abc'

# Generated at 2022-06-26 10:46:31.825634
# Unit test for function validate_yaml
def test_validate_yaml():
    from .schema_0 import schema_0 as schema
    str_0 = '''
      name: Art Vandelay
      occupation: Importer/Exporter
    '''
    value_0, messages_0 = validate_yaml(content=str_0, validator=schema)
    assert value_0 == {
        'name': 'Art Vandelay',
        'occupation': 'Importer/Exporter'
    }
    assert messages_0 == []


# Generated at 2022-06-26 10:46:37.740797
# Unit test for function validate_yaml
def test_validate_yaml():
    validation_result = validate_yaml(
        content='"a"\n',
        validator=str,
    )
    assert validation_result == ('a', [])
    validation_result = validate_yaml(
        content='"a"\n',
        validator=typing.List[str],
    )
    assert validation_result == (
        ['a'],
        [
            ValidationError(
                text='Expected list but got scalar.',
                code='invalid_type',
                position=Position(
                    line_no=1,
                    column_no=3,
                    char_index=2,
                ),
            ),
        ]
    )

# Generated at 2022-06-26 10:46:46.942731
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "---\n- `1 + 1`\n- `2 + 2`\n"
    token_0 = tokenize_yaml(str_0)
    str_0 = "---\n- one\n- two\n- three\n"
    token_0 = tokenize_yaml(str_0)
    token_1 = tokenize_yaml(str_0)
    str_0 = "--- {a: b}\n"
    token_0 = tokenize_yaml(str_0)
    token_1 = tokenize_yaml(str_0)
    str_0 = "--- [a, b]\n"
    token_0 = tokenize_yaml(str_0)
    str_0 = "--- `a`\n"
    token_0 = tokenize_

# Generated at 2022-06-26 10:46:58.830136
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "a: 1\nb: 2\n"
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, Token) and isinstance(token_0, DictToken)
    assert token_0.content == str_0
    str_1 = "a: 1\nb: []\n"
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, Token) and isinstance(token_1, DictToken)
    assert token_1.content == str_1
    str_2 = "a: 1\nb: [1, 2, 3]\n"
    token_2 = tokenize_yaml(str_2)

# Generated at 2022-06-26 10:47:13.317116
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:47:23.582956
# Unit test for function validate_yaml
def test_validate_yaml():
    # Case 0
    str_0 = '}]Ea'
    token_0 = tokenize_yaml(str_0)
    validator_0 = token_0
    with pytest.raises(ParseError):
        validate_yaml(str_0, validator_0)
    # Case 1
    str_1 = '["a","b","c"]'
    token_1 = tokenize_yaml(str_1)
    validator_1 = token_1
    (value_1, error_messages_1) = validate_yaml(str_1, validator_1)
    assert value_1 == ['a', 'b', 'c']
    assert error_messages_1 == []
    # Case 2
    str_2 = '{"a":"b","c":"d"}'
    token_

# Generated at 2022-06-26 10:47:40.722379
# Unit test for function tokenize_yaml

# Generated at 2022-06-26 10:47:44.012253
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content=0, validator=0) is None
    assert validate_yaml(content='', validator=0) is None
    assert validate_yaml(content=[], validator=0) is None
    assert validate_yaml(content={}, validator=0) is None


# Generated at 2022-06-26 10:47:52.306361
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # Test
    str_0 = '}]Ea'
    token_0 = tokenize_yaml(str_0)
    assert token_0.start == 0
    assert token_0.end == 4
    assert token_0.children[0].value == '}'
    assert token_0.children[0].start == 0
    assert token_0.children[0].end == 0
    assert token_0.children[1].value == ']'
    assert token_0.children[1].start == 1
    assert token_0.children[1].end == 1
    assert token_0.children[2].value == 'E'
    assert token_0.children[2].start == 2
    assert token_0.children[2].end == 2
    assert token_0.children[3].value == 'a'


# Generated at 2022-06-26 10:48:03.671033
# Unit test for function validate_yaml
def test_validate_yaml():
    # Check for invalid content
    str_0 = '}]Ea'
    with pytest.raises(Exception) as exception_info_0:
        validate_yaml(str_0, str_0)
    assert exception_info_0.type is ParseError
    assert exception_info_0.value.code == 'parse_error'
    assert exception_info_0.value.text == 'could not find expected \':\' or \',\' while scanning a simple key.'
    assert exception_info_0.value.position == Position(column_no=1, line_no=1, char_index=0)
    # Check for invalid content
    str_1 = 'Ea'
    with pytest.raises(Exception) as exception_info_1:
        validate_yaml(str_1, str_1)
   

# Generated at 2022-06-26 10:48:11.735111
# Unit test for function validate_yaml
def test_validate_yaml():
    # this is a simple test case that is known to return an error
    str_0 = '}]Ea'
    validator_0 = String()
    value_0, error_messages_0 = validate_yaml(str_0, validator_0)
    assert len(error_messages_0) == 2
    assert isinstance(error_messages_0[0], ParseError)
    assert isinstance(error_messages_0[1], ValidationError)
    assert error_messages_0[0].position == Position(4, 4, 4)
    assert error_messages_0[1].position == Position(4, 4, 4)



# Generated at 2022-06-26 10:48:23.730293
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    try:
        str_0 = '}]Ea'
        token_0 = tokenize_yaml(str_0)
    except Exception as e:
        assert type(e) in [ParseError]
        assert 'Ea' in str(e)

    try:
        str_0 = '""'
        token_0 = tokenize_yaml(str_0)
    except Exception as e:
        assert False, 'Failed to parse a valid string'

    try:
        str_0 = '"a"'
        token_0 = tokenize_yaml(str_0)
    except Exception as e:
        assert False, 'Failed to parse a valid string'


# Generated at 2022-06-26 10:48:33.865015
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('a: 1') == {'a': 1}
    assert tokenize_yaml('a: 1\nb: 2') == {'a': 1, 'b': 2}
    assert tokenize_yaml('a: 1\nb: 2\n') == {'a': 1, 'b': 2}
    assert tokenize_yaml('a: 1\nb: 2\n\n') == {'a': 1, 'b': 2}
    assert tokenize_yaml('a: 1\nb: 2\n\n\n') == {'a': 1, 'b': 2}
    assert tokenize_yaml('a: 1\nb: 2\n\n\n\n') == {'a': 1, 'b': 2}

# Generated at 2022-06-26 10:48:43.905144
# Unit test for function validate_yaml
def test_validate_yaml():
    class UnlabeledSchema(Schema):
        a = Field(validators=[validate_yaml("yam")], position="start")
        b = Field(validators=[validate_yaml("yam")], position="end")

    try:
        validate_yaml("yam", Field(validators=UnlabeledSchema()))
    except ValidationError:
        pass

    class IntegerSchema(Schema):
        minimum = Field(validators=[validate_yaml("yam")], position="start")

    try:
        validate_yaml("yam", Field(validators=IntegerSchema()))
    except ValidationError:
        pass



# Generated at 2022-06-26 10:48:46.504351
# Unit test for function validate_yaml
def test_validate_yaml():
    if __name__ == '__main__':
        pass
# ################# END CLASSES ########################

# Generated at 2022-06-26 10:48:57.586919
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    # Empty string
    str_0 = ''
    token_0 = tokenize_yaml(str_0)
    assert (token_0.type == Token.INVALID)

    # Invalid YAML
    str_1 = '{{}}Ea'
    token_1 = tokenize_yaml(str_1)
    assert (token_1.type == Token.INVALID)

    # Scalar Token
    str_2 = 'hello'
    token_2 = tokenize_yaml(str_2)
    assert (isinstance(token_2, ScalarToken))
    assert (token_2.type == Token.SCALAR)
    assert (token_2.value == str_2)

# Generated at 2022-06-26 10:49:09.532516
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '}]Ea'
    token_0 = tokenize_yaml(str_0)
    ret_0 = validate_yaml(str_0, "passthru")

    assert ret_0[0] == token_0
    assert ret_0[1] == []



# Generated at 2022-06-26 10:49:17.800819
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = '}'
    validator_1 = type('DummyValidator', (object,), {})()
    value_1, error_messages_1 = validate_yaml(str_1, validator_1)
    assert error_messages_1 and error_messages_1[0].code == 'parse_error'

    str_2 = '"abc"'
    validator_2 = type('DummyValidator', (object,), {})()
    value_2, error_messages_2 = validate_yaml(str_2, validator_2)
    assert error_messages_2 and error_messages_2[0].code == 'parse_error'

    str_3 = '123'
    validator_3 = Field(name='DummyField', type='string')
    value_3

# Generated at 2022-06-26 10:49:24.397742
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    input_str_1 = 'a: b'
    input_str_2 = "a: 'b'"
    input_str_3 = "a: 'b\nc'"
    input_str_4 = "a: 'b\nc'"
    input_str_5 = "a: 'b\nc'"
    input_str_6 = "a: 'b\nc'"
    input_str_7 = "a: 'b\nc'"
    output_dict_1 = {'a': 'b'}
    output_dict_2 = {'a': 'b'}
    output_dict_3 = {'a': 'b\nc'}
    output_dict_4 = {'a': 'b\nc'}
    output_dict_5 = {'a': 'b\nc'}
    output_dict_6

# Generated at 2022-06-26 10:49:36.650693
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Assert that when called with string input that it returns a Token.
    str_1 = '{"test", 42}'
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, Token)
    assert token_1.start_position == 0
    assert token_1.end_position == 11
    assert token_1.content == str_1

    # Assert that when called with a byte input that it returns a Token.
    bytes_1 = b'{"test", 42}'
    token_2 = tokenize_yaml(bytes_1)
    assert isinstance(token_2, Token)
    assert token_1.start_position == 0
    assert token_1.end_position == 11
    assert token_1.content == str_1

    # Assert that calling with an empty

# Generated at 2022-06-26 10:49:38.024464
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Check the expected result versus the actual result.
    assert tokenize_yaml == token_0

# Generated at 2022-06-26 10:49:40.192340
# Unit test for function validate_yaml
def test_validate_yaml():
    assert False, "Mock"

# Generated at 2022-06-26 10:49:44.911032
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        '{ "foo": "bar" }',
        {
            "foo": {
                "type": "string",
                "description": "The foo field.",
                "title": "The foo field.",
                "default": "bar",
            }
        },
    ) == ({'foo': 'bar'}, None)

# Generated at 2022-06-26 10:49:57.643763
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    str_0 = '}]'  # noqa: E501;
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, Token)
    assert str_0[token_0.start : token_0.end + 1] == str_0
    str_1 = '\nkey: value\n'  # noqa: E501;
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, DictToken)
    assert isinstance(token_1.mapping, dict)
    str_2 = "['one', 'two']\n"  # noqa: E501;
    token_2 = tokenize_yaml(str_2)

# Generated at 2022-06-26 10:50:02.086844
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('"947")') == ScalarToken('"947")', start=0, end=6, content='"947")')


# Generated at 2022-06-26 10:50:15.866864
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('1') == ScalarToken(1, 0, 0, content='1')
    assert tokenize_yaml('1.1') == ScalarToken(1.1, 0, 2, content='1.1')
    assert tokenize_yaml('1E1') == ScalarToken(10.0, 0, 2, content='1E1')
    assert tokenize_yaml('a') == ScalarToken('a', 0, 0, content='a')
    assert tokenize_yaml('"a"') == ScalarToken('a', 0, 2, content='"a"')
    assert tokenize_yaml("'a'") == ScalarToken('a', 0, 2, content="'a'")

# Generated at 2022-06-26 10:50:29.326357
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Positive case: if the parsed value validates, the value is returned.
    value = validate_yaml(content='"Test"', validator=str)
    assert value == 'Test'

    # Negative case: if the parsed value fails validation, the expected error
    # messages are returned (not the parsed value).
    errors = validate_yaml(content='"Test"', validator=int)
    assert errors == [
        ValidationError(
            text="Expected type 'int' but received 'str'.",
            code="type_mismatch",
            position=Position(column_no=1, line_no=1, char_index=0),
        )
    ]

    # Negative case: if the parsed value fails validation, the expected error
    # messages

# Generated at 2022-06-26 10:50:35.596365
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:50:40.388697
# Unit test for function validate_yaml
def test_validate_yaml():
    result = validate_yaml(
        content=b'{\"key\": 2}',
        validator={'key': int} # type: ignore
    )

    assert result == ({'key': 2}, None)



# Generated at 2022-06-26 10:50:49.631768
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '''"1"'''
    tokens_0 = tokenize_yaml(str_0)
    field_0 = String()
    ret_0 = validate_yaml(str_0, field_0)
    str_1 = "''"
    tokens_1 = tokenize_yaml(str_1)
    ret_1 = validate_yaml(str_1, field_0)
    str_2 = '''"2"'''
    tokens_2 = tokenize_yaml(str_2)
    ret_2 = validate_yaml(str_2, field_0)




# Generated at 2022-06-26 10:50:53.596478
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '{}'
    validator = Schema({"a": int})
    expected_value = {"a": None}
    value, error_messages = validate_yaml(content, validator)
    assert value == expected_value
    assert error_messages[0].text == "This value should be an integer."

# Generated at 2022-06-26 10:50:57.136285
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '}]Ea'
    token_0 = tokenize_yaml(str_0)



# Generated at 2022-06-26 10:51:08.429710
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    
    assert str(tokenize_yaml("")) == "None"
    assert str(tokenize_yaml("---")) == "None"
    assert str(tokenize_yaml("--- ")) == "None"
    assert str(tokenize_yaml("  --- ")) == "None"
    assert str(tokenize_yaml("null")) == "None"
    assert str(tokenize_yaml("~")) == "None"
    assert str(tokenize_yaml("trUe")) == "True"
    assert str(tokenize_yaml("fAlSe")) == "False"
    assert str(tokenize_yaml("0")) == "0"
    assert str(tokenize_yaml("-0")) == "0"
    assert str(tokenize_yaml("42")) == "42"
    assert str

# Generated at 2022-06-26 10:51:13.504726
# Unit test for function validate_yaml
def test_validate_yaml():
    str_content = "something"
    assert validate_yaml(
        content=str_content,
        validator=Field(type="string", label="Foo", description="A foo"),
    ) == (
        "something",
        [],
    )

    content = b"---\nmessage: hello\n"
    assert validate_yaml(
        content=content,
        validator=Field(type="string", label="Foo", description="A foo"),
    ) == ("hello", [])

    str_content = "something"
    assert validate_yaml(
        content=str_content,
        validator=Field(
            type="string", label="Foo", description="A foo", default="something"
        ),
    ) == ("something", [])



# Generated at 2022-06-26 10:51:26.908028
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        title = 'Test Schema'
        const = {'type': 'string', 'const': 'a'}
        maximum = {'type': 'number', 'maximum': 10}

    str_0 = '}]Ea'
    res = validate_yaml(str_0, TestSchema)
    assert res.data == None
    assert res.error_messages == [Message(text='Parse error.', code='parse_error',
                                          position=Position(line_no=1, column_no=1,
                                                            char_index=0))]
    value, error_messages = validate_yaml(str_0, TestSchema)
    assert value == None

# Generated at 2022-06-26 10:51:36.653023
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '{}'
    token_0 = tokenize_yaml(str_0)
    assert token_0 == {}, "'YAML' content failed"
    str_1 = '[1, 2, 3]'
    token_1 = tokenize_yaml(str_1)
    assert token_1 == [1, 2, 3], "'YAML' content failed"
    str_2 = 'a: 1'
    token_2 = tokenize_yaml(str_2)
    assert token_2 == {'a': 1}, "'YAML' content failed"