

# Generated at 2022-06-26 10:41:58.336757
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "test_str"
    validator_0 = String()
    value_0, error_messages_0 = validate_yaml(str_0, validator_0)
    str_1 = "test_str"
    validator_1 = String()
    error_messages_1 = validate_yaml(str_1, validator_1)


# Generated at 2022-06-26 10:42:04.525494
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize.tests.test_data import test_data_0
    d_0 = test_data_0['dict_0']
    t_0 = test_data_0['t_0']
    token_0 = tokenize_yaml(d_0)
    assert token_0 == t_0

# Generated at 2022-06-26 10:42:12.017174
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '\n\n87.ha\n\nt'
    expected = ListToken([87.0, 'ha', 't'], 0, len(str_0) - 1, content=str_0)
    assert tokenize_yaml(str_0) == expected
    str_1 = '1\n-1\n0\n'
    expected = ListToken([1, -1, 0], 0, len(str_1) - 1, content=str_1)
    assert tokenize_yaml(str_1) == expected
    str_2 = '{name: kR5*\n, 4p%X: 1, mIH: 0, u/: false, K: [{}, {}, {}, {}]}'

# Generated at 2022-06-26 10:42:21.470791
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('9fiW<r9N\r9q(}y^', '9fiW<r9N\r9q(}y^') == '9fiW<r9N\r9q(}y^'

    assert validate_yaml(tokenize_yaml('9fiW<r9N\r9q(}y^'), '9fiW<r9N\r9q(}y^') == '9fiW<r9N\r9q(}y^'

    assert validate_yaml('9fiW<r9N\r9q(}y^', '{"text": "#"}') == '{"text": "#"}'

    assert validate_yaml(tokenize_yaml('9fiW<r9N\r9q(}y^'), '{"text": "#"}')

# Generated at 2022-06-26 10:42:26.848708
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml('9fiW<r9N\r9q(}y^', 'Zl)bF*=_}{,gFsP"') == (97.25821147732969, [])
    assert validate_yaml('v+VXBkz#M|', '$DH8fvD`C}l@Kf3') == (42.4375, [])
    assert validate_yaml('m\r>vIHfO', 'j(L3$Z^8') == (28.60097370398015, [])
    assert validate_yaml('2T\r', '%W]{v!V7zj>E\x7f$') == (0, [])

# Generated at 2022-06-26 10:42:33.963675
# Unit test for function validate_yaml
def test_validate_yaml():
    # Example of content
    content = '9fiW<r9N\r9q(}y^'
    # Example of validator
    validator = Field()

    value, errors = validate_yaml(content=content, validator=validator)
    assert value is None
    assert len(errors) == 1
    assert errors[0].message == "string is not in a recognized format."
    assert errors[0].code == "invalid"
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 1
    assert errors[0].position.char_index == 0

# Generated at 2022-06-26 10:42:40.288822
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '9fiW<r9N\r9q(}y^'
    class Schema_0(Schema):
        pass
    (value_0, error_messages_0) = validate_yaml(str_0, Schema_0)
    assert value_0 == {'9fiW<r9N\r9': '9q(}y^'}
    assert error_messages_0 == {}


# Generated at 2022-06-26 10:42:54.665050
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = 'j}sYsI;e9T'
    str_1 = 'c qI#'
    str_2 = '}rz'
    str_3 = 'i_'
    str_4 = 'jD'
    str_5 = 'I'
    str_6 = '\r'
    str_7 = ' s'
    str_8 = '\t'
    str_9 = 'Z'
    str_10 = '\x1e'
    str_11 = '\x13'
    str_12 = '\x00'
    str_13 = '\x1e'
    str_14 = 'h'
    str_15 = '\x09'
    str_16 = '4'
    str_17 = 'N'

# Generated at 2022-06-26 10:42:58.501402
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '9fiW<r9N\r9q(}y^'
    token_0 = tokenize_yaml(str_0)


# Generated at 2022-06-26 10:42:59.561384
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('3') is not None


# Generated at 2022-06-26 10:43:16.091773
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    print('Testing function tokenize_yaml')
    assert "function" == type(tokenize_yaml).__name__

    # Test case:
    try:
        tokenize_yaml(test_case_0())
        print('test case 0: pass!')
    except:
        print('test case 0: fail!')
    # Test case:
    try:
        tokenize_yaml(test_case_1())
        print('test case 1: pass!')
    except:
        print('test case 1: fail!')
    # Test case:
    try:
        tokenize_yaml(test_case_2())
        print('test case 2: pass!')
    except:
        print('test case 2: fail!')
    # Test case:

# Generated at 2022-06-26 10:43:19.722733
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # Testing case with positional arguments.
    tokenize_yaml(content='9fiW<r9N\r9q(}y^')

    # Testing case with mixed positional and keyword arguments.
    tokenize_yaml(content='9fiW<r9N\r9q(}y^', )



# Generated at 2022-06-26 10:43:30.204795
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    str_0 = '9fiW<r9N\r9q(}y^'
    str_1 = "e'g*\t>|@"
    str_2 = 'w=L-_o'
    str_3 = 'X9M3#'
    str_4 = 'R\ra#'
    str_5 = '6U-{6x'
    str_6 = ');omn'
    str_7 = 'e?pshM'
    str_8 = 'm!-4dY'
    str_9 = 'Zw5.5=S'
    str_10 = 'yR'
    str_11 = 'zH=-'
    str_12 = '\tw'
    str_13

# Generated at 2022-06-26 10:43:36.556722
# Unit test for function validate_yaml
def test_validate_yaml():
    str_2 = "A81TA8"
    str_3 = "^"
    str_4 = "5PbU6i"
    str_5 = "A81TA8"
    str_6 = "^"
    str_7 = "5PbU6i"

    # set up
    str_1 = str(str_2)
    str_8 = str(str_7)
    str_9 = str(str_6)
    str_10 = str(str_5)
    str_11 = str(str_4)
    str_12 = str(str_3)
    str_0 = str(str_2)
    str_0 = str(str_11)
    str_0 = str(str_12)

# Generated at 2022-06-26 10:43:49.017641
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    str_0 = '[{"title":"Fruit Salad","ingredients":["Apple","Orange","Banana"],"instructions":["Mix it all together"],"nutrition":{"calories":200,"fat":{"quantity":1,"unit":"g"}},"prepTime":{"quantity":5,"unit":"min"},"cookTime":{"quantity":10,"unit":"min"},"serves":{"quantity":4,"unit":"people"}},{"title":"Pizza","ingredients":["Flour","Water","Yeast"],"instructions":["Mix it all together","Stretch into shape","Bake"],"nutrition":{"calories":300,"fat":{"quantity":10,"unit":"g"}},"prepTime":{"quantity":5,"unit":"min"},"cookTime":{"quantity":20,"unit":"min"},"serves":{"quantity":1,"unit":"people"}}]'
    # Call

# Generated at 2022-06-26 10:43:58.979557
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    class CustomSafeLoader(SafeLoader):
        pass

    def construct_mapping(loader: "yaml.Loader", node: "yaml.Node") -> DictToken:
        start = node.start_mark.index
        end = node.end_mark.index
        mapping = loader.construct_mapping(node)
        return DictToken(mapping, start, end - 1, content=str_content)

    def construct_sequence(loader: "yaml.Loader", node: "yaml.Node") -> ListToken:
        start = node.start_mark.index
        end = node.end_mark.index
        value = loader.construct_sequence(node)
        return ListToken(value, start, end - 1, content=str_content)


# Generated at 2022-06-26 10:44:10.542722
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '9fiW<r9N\r9q(}y^'
    lst_0 = list()
    for item in str_0:
        lst_0.append(item)
    str_1 = ''
    for item in lst_0:
        str_1 += item
    str_0 = str_1

    test_list_0 = list(str_0)
    test_list_1 = list(test_list_0)
    test_list_1.reverse()
    str_0 = ''.join(test_list_1)
    print(str_0)
    assert str_0 == 'y^}(q9\rN9r<Wif9'

# Generated at 2022-06-26 10:44:16.278114
# Unit test for function validate_yaml
def test_validate_yaml():
    result = validate_yaml(content=None, validator=None)
    assert result is None

    result = validate_yaml(content=None, validator=None)
    assert result is None

    result = validate_yaml(content=None, validator=None)
    assert result is None



# Generated at 2022-06-26 10:44:29.647594
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from random import randint
    from random import uniform
    import string
    def get_rand_string(max_size):
        max_size = 20
        return ''.join(random.choice(string.ascii_letters) for _ in range(max_size))
    SIZE = 10
    min_val = 0
    max_val = 127

# Generated at 2022-06-26 10:44:41.180202
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    start = time.time()
    #Case 0
    str_0 = '9fiW<r9N\r9q(}y^'
    assert tokenize_yaml(str_0) == None
    #Case 1
    str_1 = 'Tr1"w[d]oT8T2klA'
    assert tokenize_yaml(str_1) == None
    #Case 2
    str_2 = 'J2Q\x0b\x0bS"\\"9'
    assert tokenize_yaml(str_2) == None
    #Case 3
    str_3 = '3iEZ\x0bY<}@B)w'
    assert tokenize_yaml(str_3) == None
   

# Generated at 2022-06-26 10:44:47.460256
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '9fiW<r9N\r9q(}y^'
    token_0 = tokenize_yaml(str_0)

# Generated at 2022-06-26 10:44:54.611318
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        {'gender': 'Male', 'age': '28.6', 'name': 'Janet', 'last_name': 'Reed', 'email': 'jreed@gmail.com'}, Person,
        ) is True


# Generated at 2022-06-26 10:45:00.411774
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'ZB`s#wW\x0bH\x16C\x0c\x7fH\x0c\x7fH\x0bHCA'
    token_0 = tokenize_yaml(str_0)
    val_0, errs_0 = validate_yaml(str_0, token_0)


# Generated at 2022-06-26 10:45:06.261944
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '9fiW<r9N\r9q(}y^'
    token_0 = tokenize_yaml(str_0)
    schema = Schema(fields={})

    value, error_messages = validate_yaml(token_0, schema=schema)



# Generated at 2022-06-26 10:45:13.263533
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field()
    yaml_str = 'this is yaml'
    rt = validate_yaml(yaml_str, field)
    assert rt == ('this is yaml', None)
    yaml_str = 'foo: bar\n'
    rt = validate_yaml(yaml_str, field)
    assert rt == ({'foo': 'bar'}, None)
    yaml_str = '["foo", "bar"]'
    rt = validate_yaml(yaml_str, field)
    assert rt == (['foo', 'bar'], None)

# Generated at 2022-06-26 10:45:18.059915
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '1'
    validator_0 = typesystem.fields.Integer

    value, errors = validate_yaml(str_0, validator_0)
    assert value == 1
    assert len(errors) == 0

# Generated at 2022-06-26 10:45:23.203808
# Unit test for function validate_yaml
def test_validate_yaml():
    test_str = "---\nfoo: bar\n"
    schema = Schema(
        {"foo": Field(type="string")}
    )
    value, errors = validate_yaml(
        content=test_str, validator=schema,
    )
    assert value == {'foo': 'bar'}
    assert errors == []


# Generated at 2022-06-26 10:45:33.351794
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '9fiW<r9N\r9q(}y^'
    str_1 = '@9Y~]8"2OXd_H'
    str_2 = 'B<8w)>i}x(H\x03'
    str_3 = 'PiA*~]\x1988uI='
    str_4 = '`{=y7R9a\x08._'
    token_0 = tokenize_yaml(str_0)
    token_1 = tokenize_yaml(str_1)
    token_2 = tokenize_yaml(str_2)
    token_3 = tokenize_yaml(str_3)
    token_4 = tokenize_yaml(str_4)

# Generated at 2022-06-26 10:45:34.723054
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert True


# Generated at 2022-06-26 10:45:37.156352
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    try:
        assert True
    except: # pragma: no cover
        pytest.fail("Unit tests for tokenize_yaml are not yet implemented.")



# Generated at 2022-06-26 10:45:44.738140
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '|M!7`*=+b'
    output = tokenize_yaml(content)
    assert output is not None


# Generated at 2022-06-26 10:45:53.505435
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test the case where 'content' is a string.
    str_0 = '|M!7`*=+b'
    token_0 = tokenize_yaml(str_0)
    assert token_0.start == 0
    assert token_0.end == 8
    assert token_0.value == '|M!7`*=+b'
    assert token_0.type == 'scalar'
    assert token_0.content == str_0
    assert token_0.position == Position(line_no=1, column_no=1, char_index=0)

    # Test the case where 'content' is a bytestring.
    str_1 = '~N?<r5N5g1'
    token_1 = tokenize_yaml(str_1)
    assert token_1.start

# Generated at 2022-06-26 10:45:56.807484
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    try:
        assert tokenize_yaml is not None
    except:
        print('Failure: test_tokenize_yaml')


# Generated at 2022-06-26 10:46:04.141330
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = 'key: value'
    token_0 = tokenize_yaml(str_1)
    assert isinstance(token_0, DictToken)
    assert token_0.value == {'key': 'value'}
    assert token_0.start == 0
    assert token_0.end == 10
    value_1, error_messages_1 = validate_with_positions(token_0, str)
    assert value_1 == '{key: value}'
    assert error_messages_1 is None

    str_2 = '''
    key: value
    '''
    token_1 = tokenize_yaml(str_2)
    assert isinstance(token_1, DictToken)
    assert token_1.value == {'key': 'value'}

# Generated at 2022-06-26 10:46:08.683914
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    str_0 = '|M!7`*=+b'
    token_0 = tokenize_yaml(str_0)
    str_1 = '@!%f#2PzKb'
    token_1 = tokenize_yaml(str_1)
    str_2 = '{nZr'
    token_2 = tokenize_yaml(str_2)
    str_3 = '#N0'
    token_3 = tokenize_yaml(str_3)
    str_4 = '"3.0"mJ'
    token_4 = tokenize_yaml(str_4)
    str_5 = '3.0kgP'
    token_5 = tokenize_yaml(str_5)

# Generated at 2022-06-26 10:46:21.621146
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '|M!7`*=+b'
    token_0 = tokenize_yaml(str_0)
    assert token_0 == ScalarToken('|M!7`*=+b', 0, 8, content='|M!7`*=+b')

    str_1 = '%vN8M<W6:NU!w'
    token_1 = tokenize_yaml(str_1)
    assert token_1 == ScalarToken('%vN8M<W6:NU!w', 0, 11, content='%vN8M<W6:NU!w')

    str_2 = '56xf8W'
    token_2 = tokenize_yaml(str_2)

# Generated at 2022-06-26 10:46:31.537835
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '|M!7`*=+b'
    str_1 = ''
    dict_0 = {'a': {'b': {'c': [1, 2, 3], 'd': [4, 5, 6], 'e': [7, 8, 9]}}}
    token_0 = tokenize_yaml(str_0)
    with pytest.raises(AssertionError):
        token_0 = tokenize_yaml(str_1)
    token_1 = tokenize_yaml(dict_0)


# Generated at 2022-06-26 10:46:38.297289
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("test", Field(str)) == ("test", [])
    assert validate_yaml("test", Field(str, min_length=3)) == ("test", [])
    assert validate_yaml("test", Field(str, min_length=5)) == (
        None,
        [
            Message(
                text='Shorter than minimum length.',
                code="min_length",
                position=Position(column_no=0, char_index=0, line_no=1),
            )
        ],
    )

    # Test that error position is correct when parsing fails.
    with pytest.raises(ParseError) as exc_info:
        validate_yaml("[", Field(list, items=Field(str)))

# Generated at 2022-06-26 10:46:39.001644
# Unit test for function validate_yaml
def test_validate_yaml():
    pass

# Generated at 2022-06-26 10:46:47.393197
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # Test cases for function tokenize_yaml #

    # Test case 0
    str_0 = '|M!7`*=+b'
    token_0 = tokenize_yaml(str_0)
    assert token_0._content == '|M!7`*=+b'
    assert token_0._start == 0
    assert token_0._end == 9
    assert token_0._type == 'scalar'


# Generated at 2022-06-26 10:46:57.407179
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '{foo: bar}'
    class TestSchema(Schema):
        foo = Field(required=True)
    try:
        val_0, errors_0 = validate_yaml(str_0, TestSchema)
    except ValidationError as exc_0:
        assert exc_0.message.code == 'required'

# Generated at 2022-06-26 10:47:08.622646
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type="integer", min_value=1)
    str_0 = '|M!7`*=+b'
    str_1 = '1'
    str_2 = '2'
    str_3 = '0'
    str_4 = '3'
    str_5 = '-1'
    str_6 = 'a'
    str_7 = '12.3'
    str_8 = '-12.3'
    str_9 = '-0.12'
    str_10 = '-0.0'
    str_11 = 'true'
    str_12 = 'false'
    str_13 = 'a'
    str_14 = ''
    str_15 = '\t'
    str_16 = '\n'
    str_17 = ' '
   

# Generated at 2022-06-26 10:47:20.436698
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    #token_0 = tokenize_yaml('|M!7`*=+b')
    assert token_0 == ScalarToken('|M!7`*=+b', 0, 9, content='|M!7`*=+b')
    assert token_0.__str__() == '|M!7`*=+b'

    token_1 = tokenize_yaml('!')
    assert token_1 == ScalarToken('!', 0, 0, content='!')
    assert token_1.__str__() == '!'

    str_2 = '{}'
    token_2 = tokenize_yaml(str_2)
    assert token_2 == DictToken({}, 0, 1, content='{}')
    assert token_2.__str__() == '{}'

    str_3

# Generated at 2022-06-26 10:47:32.044049
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '|M!7`*=+b'
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, ScalarToken)
    assert token_0.value == '|M!7`*=+b'
    assert token_0.start == 0
    assert token_0.end == len(str_0) - 1

    str_1 = '`abcde`'
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, ScalarToken)
    assert token_1.value == str_1
    assert token_1.start == 0
    assert token_1.end == len(str_1) - 1


# Generated at 2022-06-26 10:47:40.775770
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == Token(None, 0, -1)

    # Example 0: {"name": "John", "age": 42}
    str_0 = "{name: John, age: 42}"
    token_0 = tokenize_yaml(str_0)
    position_0_0 = _get_position(str_0, index=0)
    position_0_1 = _get_position(str_0, index=6)
    position_0_2 = _get_position(str_0, index=10)
    position_0_3 = _get_position(str_0, index=14)
    position_0_4 = _get_position(str_0, index=19)
    position_0_5 = _get_position(str_0, index=22)
    position_0_

# Generated at 2022-06-26 10:47:46.561632
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        "", Field(type="string"),
    ) == (None, [
        Message(
            code='missing',
            text='Expected a value.',
            position=Position(line_no=1, column_no=1, char_index=0),
        ),
    ])
    assert validate_yaml(
        "", Field(type="integer"),
    ) == (None, [
        Message(
            code='missing',
            text='Expected a value.',
            position=Position(line_no=1, column_no=1, char_index=0),
        ),
    ])

# Generated at 2022-06-26 10:47:48.581716
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = '|M!7`*=+b'
    token_1 = tokenize_yaml(str_1)
    result_0 = validate_yaml(str_1, token_1)

# Generated at 2022-06-26 10:48:01.698055
# Unit test for function validate_yaml
def test_validate_yaml():
    class AnimalSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    token = tokenize_yaml("name: cat\nage: 123")
    assert token.value["name"] == "cat"
    assert token.value["age"] == 123

    value, error_messages = validate_yaml("name: cat\nage: 123", AnimalSchema)
    assert value["name"] == "cat"
    assert value["age"] == 123
    assert len(error_messages) == 0

    value, error_messages = validate_yaml("name: cat", AnimalSchema)
    assert value["name"] == "cat"
    assert "age" not in value
    assert len(error_messages) == 1
    error = error_messages[0]

# Generated at 2022-06-26 10:48:14.522371
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '|M!7`*=+b'
    token_0 = tokenize_yaml(str_0)
    check_0 = ScalarToken('|M!7`*=+b', 0, 8)
    assert token_0 == check_0

    str_1 = '=l+n0'
    token_1 = tokenize_yaml(str_1)
    check_1 = ScalarToken('=l+n0', 0, 4)
    assert token_1 == check_1

    str_2 = '"\n    \r\r\n  \n  \r\r\n"'
    token_2 = tokenize_yaml(str_2)

# Generated at 2022-06-26 10:48:17.293319
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|M!7`*=+b'
    token_0 = tokenize_yaml(str_0)
    assert token_0.content[token_0.start_index:token_0.end_index+1] == str_0


# Generated at 2022-06-26 10:48:30.313571
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|M!7`*=+b'

    # Positive test cases (examples) with successful validation
    assert validate_yaml(str_0, validator=None) is None

    # Additional implementation checks, if necessary (cover more corner cases)
    assert validate_yaml(str_0, validator=None) is None # Additional implementation checks, if necessary (cover more corner cases)


# Generated at 2022-06-26 10:48:43.587715
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|M!7`*=+b'
    token_0 = tokenize_yaml(str_0)
    # AssertionError: assert 'str_1' == 'str_0'
    str_1 = '|M!7`*=+b'
    token_1 = tokenize_yaml(str_1)
    # AssertionError: assert 'token_1' == 'token_0'
    str_2 = '|M!7`*=+b'
    token_2 = tokenize_yaml(str_2)
    # AssertionError: assert 'token_2' == 'token_0'
    str_3 = '|M!7`*=+b'
    token_3 = tokenize_yaml(str_3)
    # AssertionError:

# Generated at 2022-06-26 10:48:49.275827
# Unit test for function validate_yaml
def test_validate_yaml():
    with pytest.raises(ParseError) as exception_info:
        result_0, error_messages_0 = validate_yaml('|M!7`*=+b', 'z"d')
    assert exception_info.value.text == 'No content.'
    assert exception_info.value.position.column_no == 1
    assert exception_info.value.position.line_no == 1
    assert str(exception_info.value.position) == 'CharIndex: 0 LineNo: 1 ColumnNo: 1'
    assert exception_info.value.code == 'no_content'
    assert exception_info.value.position.char_index == 0

# Generated at 2022-06-26 10:48:58.508305
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = ""
    token_0 = tokenize_yaml(str_0)
    assert token_0 == None
    str_1 = "---\ntest: 'test'\n\n\n"
    token_1 = tokenize_yaml(str_1)
    assert token_1 == {'test': 'test'}
    str_2 = '+-7|-0@\x0b8l`W'
    token_2 = tokenize_yaml(str_2)
    assert token_2 == ['+-7', -0, '@\x0b8l`W']
    str_3 = "++Ea\x15\x1e{\x1f*l\x15\x16"
    token_3 = tokenize_yaml(str_3)
    assert token_

# Generated at 2022-06-26 10:49:07.570487
# Unit test for function validate_yaml
def test_validate_yaml():

    schema = Schema.from_fields({"name": Field(str), "age": Field(int)})
    # no errors
    value, errors = validate_yaml(
        "age: 10\nname: test", schema
    )  # type: ignore
    assert value == {"name": "test", "age": 10}
    assert not errors

    # expected field missing
    value, errors = validate_yaml(
        "name: test", schema
    )  # type: ignore
    assert value == {"name": "test"}
    assert errors == [
        {
            "text": "Missing required key 'age'",
            "code": "missing_key",
            "position": Position(char_index=10, line_no=2, column_no=1),
        }
    ]

    # extra field
    value,

# Generated at 2022-06-26 10:49:09.606630
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("foo", str) == ("foo", None)


# Generated at 2022-06-26 10:49:17.830002
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '|M!7`*=+b'
    token_0 = tokenize_yaml(str_0)
    assert token_0.value == '|M!7`*=+b'
    assert token_0.start_index == 0
    assert token_0.end_index == 10
    assert token_0.start_mark.line_no == 1

    str_1 = '''
# comment
foo: bar
'''
    token_1 = tokenize_yaml(str_1)
    assert token_1.value == {'foo': 'bar'}
    assert token_1.start_index == 0
    assert token_1.end_index == 23
    assert token_1.start_mark.line_no == 1


# Generated at 2022-06-26 10:49:18.465944
# Unit test for function validate_yaml
def test_validate_yaml():
    assert callable(validate_yaml)

# Generated at 2022-06-26 10:49:22.480859
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*.E!'
    Field_0 = Field(format="int")
    value_0, error_messages_0 = validate_yaml(str_0, Field_0)
    str_1 = ''
    Field_1 = Field(format="int")
    value_1, error_messages_1 = validate_yaml(str_1, Field_1)

# Generated at 2022-06-26 10:49:27.490087
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b'{foo: 123, bar: 456}'
    validator = Validator1()
    value, error_messages = validate_yaml(content, validator)



# Generated at 2022-06-26 10:49:45.687548
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|M!7`*=+b'
    token_0 = tokenize_yaml(str_0)
    str_1 = '|M!7`*=+b'
    token_1 = tokenize_yaml(str_1)
    str_2 = '|M!7`*=+b'
    token_2 = tokenize_yaml(str_2)
    str_3 = '|M!7`*=+b'
    token_3 = tokenize_yaml(str_3)
    str_4 = '|M!7`*=+b'
    token_4 = tokenize_yaml(str_4)
    str_5 = '|M!7`*=+b'
    token_5 = tokenize_yaml(str_5)
   

# Generated at 2022-06-26 10:49:54.053678
# Unit test for function validate_yaml
def test_validate_yaml():
    # Case 0
    str_0 = '|M!7`*=+b'
    validator_0 = typesystem.String(max_length=2)
    value_0, errors_0 = validate_yaml(str_0, validator_0)
    assert isinstance(value_0, ScalarToken) and isinstance(errors_0, list)


# Generated at 2022-06-26 10:49:54.716170
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert True

# Generated at 2022-06-26 10:50:07.972773
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    from typesystem.base import ValidationError

    try:
        validate_yaml('{"x": "foo"}', String())
    except ValidationError as err:
        assert err.as_json() == {
            "x": [{"code": "invalid_type", "text": "Expected 'str' but received 'dict'."}]
        }

    try:
        validate_yaml('{"x": "foo"}', String())
    except ValidationError as err:
        assert err.as_json() == {
            "x": [{"code": "invalid_type", "text": "Expected 'str' but received 'dict'."}]
        }


# Generated at 2022-06-26 10:50:11.271528
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|M!7`*=+b'
    validator_0 = None
    expected_0 = (None, (('str_0', None), None))
    (value_0, error_messages_0) = validate_yaml(str_0, validator_0)
    assert (value_0, error_messages_0) == expected_0


# Generated at 2022-06-26 10:50:18.318769
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = ''
    validator_0 = ''
    assert validate_yaml(str_0, validator_0) == None
    str_1 = ''
    validator_1 = ''
    assert validate_yaml(str_1, validator_1) == None
    str_2 = ''
    validator_2 = ''
    assert validate_yaml(str_2, validator_2) == None
    str_3 = ''
    validator_3 = ''
    assert validate_yaml(str_3, validator_3) == None

# Generated at 2022-06-26 10:50:23.895108
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '--- {"bar": "baz", "foo": "qux"}'
    token_0 = tokenize_yaml(str_0)
    validator_0 = {"foo": str, "bar": str}
    value_0, error_messages_0 = validate_yaml(str_0, validator_0)

# Generated at 2022-06-26 10:50:33.401391
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = \
        '---\n' \
        'typesystem: \n' \
        '  properties:\n' \
        '    name: \n' \
        '      type: string\n' \
        '      max_length: 1\n'
    token_0 = tokenize_yaml(str_0)
    validator = Schema(
        {
            "name": str,
            "typesystem": Schema(
                {
                    "properties": {
                        "name": Field(type=str, max_length=1),
                    }
                }
            ),
        }
    )
    value_0, error_messages_0 = validate_yaml(str_0, validator)

# Generated at 2022-06-26 10:50:43.744285
# Unit test for function validate_yaml
def test_validate_yaml():
    # Arrange
    validator = Field(type_=str)
    str_0 = '|M!7`*=+b'
    str_1 = '"m'
    str_3 = ''

    # Act
    result_0 = validate_yaml(str_0, validator)
    result_1 = validate_yaml(str_1, validator)
    result_2 = validate_yaml(str_3, validator)

    # Assert
    assert result_0[0] == '|M!7`*=+b'
    assert result_0[1] == []
    assert result_1[0] == 'm'

# Generated at 2022-06-26 10:50:55.144692
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '- a: 1\n'
    token_0 = tokenize_yaml(str_0)
    assert type(token_0) == ListToken
    assert token_0.value == [{'a': 1}]
    assert token_0.start == 0
    assert token_0.end == 8
    assert token_0.content == str_0

    str_1 = 'a: 1\n'
    token_1 = tokenize_yaml(str_1)
    assert type(token_1) == DictToken
    assert token_1.value == {'a': 1}
    assert token_1.start == 0
    assert token_1.end == 8
    assert token_1.content == str_1

    str_2 = '1\n'
    token_2 = tokenize_

# Generated at 2022-06-26 10:51:03.242355
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test calls to internal functions
    token_0 = tokenize_yaml('|')
    str_1 = '|'
    token_1 = tokenize_yaml(str_1)



# Generated at 2022-06-26 10:51:10.427674
# Unit test for function validate_yaml
def test_validate_yaml():
    errors = validate_yaml("", Field())
    assert len(errors) == 1

    errors = validate_yaml("{}", Field())
    assert len(errors) == 2

    try:
        validate_yaml("[]")
    except Exception as err:
        assert type(err) == ParseError

# Generated at 2022-06-26 10:51:13.751296
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = b"name: John Doe\n"
    token = tokenize_yaml(content)
    assert token.data == {"name": "John Doe"}



# Generated at 2022-06-26 10:51:20.885132
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|M!7`*=+b'
    token_0 = tokenize_yaml(str_0)
    value_0, error_messages_0 = validate_yaml(str_0, "")
    assert str_0 is value_0


# Generated at 2022-06-26 10:51:29.533235
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '|M!7`*=+b'
    token_0 = tokenize_yaml(str_0)
    assert token_0.start_index == 0
    assert token_0.end_index == 10
    assert isinstance(token_0, ScalarToken)
    assert token_0.content == str_0
    assert token_0.value == str_0
    assert token_0.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token_0.end_position == Position(column_no=11, line_no=1, char_index=10)


# Generated at 2022-06-26 10:51:39.690808
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # Test 0
    str_0 = '|M!7`*=+b'
    token_0 = tokenize_yaml(str_0)

    # Test 1
    str_1 = '|M!7`*=+b'
    token_1 = tokenize_yaml(str_1)

    # Test 2
    str_2 = '|M!7`*=+b'
    token_2 = tokenize_yaml(str_2)

    # Test 3
    str_3 = '|M!7`*=+b'
    token_3 = tokenize_yaml(str_3)

    # Test 4
    str_4 = '|M!7`*=+b'
    token_4 = tokenize_yaml(str_4)
