

# Generated at 2022-06-26 10:41:46.534739
# Unit test for function validate_yaml
def test_validate_yaml():
    # If the type of the validator parameter is valid, the returned
    # value is the expected result.
    content = None
    validator = None
    assert validate_yaml(content, validator) == (None, [])
    # If the type of the validator parameter is invalid, its value
    # is not passed to the validator function.
    content = None
    validator = None
    assert validate_yaml(content, validator) == (None, [])

# Generated at 2022-06-26 10:41:58.673137
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        '{"name": "Mortimer Mooperson", "email": "morty42@mooperson.net"}',
        "email",
    ) == (
        '{"name": "Mortimer Mooperson", "email": "morty42@mooperson.net"}',
        None,
    )

    assert validate_yaml(
        '{"name": "Samantha Glass", "email": "samantha.glass@example.com"}',
        "email",
    ) == ('{"name": "Samantha Glass", "email": "samantha.glass@example.com"}', None)


# Generated at 2022-06-26 10:42:06.797624
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed to run tests."
    assert tokenize_yaml(b"") == []
    assert tokenize_yaml(b"- foo") == ["foo"]
    assert tokenize_yaml(b"foo: |-\n  bar\n  baz") == {"foo": "bar\nbaz"}
    assert tokenize_yaml(b"a b") == "a b"



# Generated at 2022-06-26 10:42:17.783305
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """
    Tests stringify

    See http://yaml.org/type/null.html
    """
    bytes_0 = b'---\n- a\n- b\n- c\n'
    expected_1 = ListToken([ScalarToken('a', 3, 3), ScalarToken('b', 5, 5), ScalarToken('c', 7, 7)], 0, 7)
    actual_1 = tokenize_yaml(bytes_0)
    assert actual_1 == expected_1, "Expected a list of 3 ScalarTokens but got: {}".format(actual_1)



# Generated at 2022-06-26 10:42:31.538919
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    content = b""
    expected_token = None
    expected_error_messages = [
        Message(
            text="No content.",
            code="no_content",
            position=Position(column_no=1, line_no=1, char_index=0),
        ),
    ]
    try:
        token = tokenize_yaml(content)
    except ValidationError as exc:
        token = exc.token

# Generated at 2022-06-26 10:42:41.934266
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert tokenize_yaml("") is None
    assert tokenize_yaml("[]") == ListToken([])
    assert tokenize_yaml("[1]") == ListToken([ScalarToken(1)])
    assert tokenize_yaml("[1, 2]") == ListToken([ScalarToken(1), ScalarToken(2)])
    assert (
        tokenize_yaml("[1, 2, 3]") == ListToken([ScalarToken(1), ScalarToken(2), ScalarToken(3)])
    )
    assert tokenize_yaml("{}") == DictToken({})
    assert tokenize_yaml('{"a": 1}') == DictToken({"a": ScalarToken(1)})


# Generated at 2022-06-26 10:42:55.005490
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test for the function with
    # str content
    content = '--\n-12345\n- yes\n- false\n- null\n- 2013-10-12\n- null\n'
    token = tokenize_yaml(content)
    assert isinstance(token, yaml.nodes.SequenceNode)
    assert isinstance(token, ListToken)
    assert token.content == content
    assert token.type == 'list'
    assert token.start == 0
    assert token.end == 97 
    assert token.tags == []
    assert token.value == [-12345, True, False, None, datetime.date(2013, 10, 12), None]
    assert token[0].value == -12345
    assert token[0].start == 3
    assert token[0].end == 8

# Generated at 2022-06-26 10:43:06.088616
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    bytes_0 = b''
    token_0 = tokenize_yaml(bytes_0)
    assert isinstance(token_0, DictToken)

    bytes_1 = b'1'
    token_1 = tokenize_yaml(bytes_1)
    assert isinstance(token_1, ScalarToken)

    bytes_2 = b'1\n2'
    token_2 = tokenize_yaml(bytes_2)
    assert isinstance(token_2, ListToken)

    bytes_3 = b'- 1\n- 2'
    token_3 = tokenize_yaml(bytes_3)
    assert isinstance(token_3, ListToken)

    bytes_4 = b'1: 1\n2: 2'
    token_4 = tokenize_yaml(bytes_4)

# Generated at 2022-06-26 10:43:10.983861
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    bytes_0 = b"{key1: value1, key2: value2}"
    token_0 = tokenize_yaml(bytes_0)



# Generated at 2022-06-26 10:43:12.403376
# Unit test for function validate_yaml
def test_validate_yaml():
    assert callable(validate_yaml)

# Generated at 2022-06-26 10:43:28.413205
# Unit test for function validate_yaml
def test_validate_yaml():
    import io

    import typesystem
    from typesystem import types

    class TestRecordSchema(typesystem.Schema):
        words = types.Text()

    sample_yaml = io.BytesIO(bytes("""\
    words: Hello world
    """, "utf8"))

    result_0, error_messages_0 = validate_yaml(sample_yaml, TestRecordSchema)

    expected_result_0 = None
    assert result_0 == expected_result_0
    assert error_messages_0 is None



# Generated at 2022-06-26 10:43:34.255207
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = None
    str_1 = "title"
    bytes_1 = str_1.encode()
    assert isinstance(bytes_1, bytes)
    str_2 = "description"
    bytes_2 = str_2.encode()
    assert isinstance(bytes_2, bytes)
    str_3 = "type"
    bytes_3 = str_3.encode()
    assert isinstance(bytes_3, bytes)
    str_4 = "object"
    bytes_4 = str_4.encode()
    assert isinstance(bytes_4, bytes)
    str_5 = "properties"
    bytes_5 = str_5.encode()
    assert isinstance(bytes_5, bytes)
    str_6 = "name"
    bytes_6 = str_6.encode()


# Generated at 2022-06-26 10:43:46.145414
# Unit test for function validate_yaml
def test_validate_yaml():
    if yaml is None:
        assert True
        return
    bytes_0 = b'1'
    token_0 = tokenize_yaml(bytes_0)
    token_1 = tokenize_yaml(bytes_0)
    str_0 = "E"
    str_1 = "A name is required"
    str_2 = "A name is required"
    def func_0():
        (value_0, value_1) = validate_yaml(bytes_0, Field(name=str_0))
    assert func_0() is None
    def func_1():
        (value_0, value_1) = validate_yaml(bytes_0, Field(name=str_0))
    assert func_1() is None
    def func_2():
        (value_0, value_1) = validate

# Generated at 2022-06-26 10:43:55.328721
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema0(Schema):
        name = "TestSchema0"
        foo = {"type": "string"}

    bytes_0 = b"foo: bar"
    value_0, error_messages_0 = validate_yaml(bytes_0, TestSchema0)
    assert value_0 == {"foo": "bar"}
    assert error_messages_0 == []

    bytes_1 = b"foo: bar"
    error_messages_1 = validate_yaml(bytes_1, TestSchema0)
    assert error_messages_1 == []

    class TestSchema1(Schema):
        name = "TestSchema1"
        foo = {"type": "string", "max_length": 2}

    bytes_2 = b"foo: bar"
    error_messages_2 = validate

# Generated at 2022-06-26 10:44:08.181277
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    bytes_0 = b';\nk0: v0\nk1:\n    v1.0\n    v2.0\nk2: v2\n'
    token_0 = tokenize_yaml(bytes_0)
    str_0 = str(token_0)
    assert str_0 == 'DictToken(mapping=[("k0", v0), ("k1", ListToken(value=[v1.0, v2.0])), ("k2", v2)], start=0, end=32, content=;\nk0: v0\nk1:\n    v1.0\n    v2.0\nk2: v2\n)'
    dict_0 = dict(token_0)

# Generated at 2022-06-26 10:44:12.401840
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = None
    validator_0 = None
    value_0, error_messages_0 = validate_yaml(bytes_0, validator_0)

# Generated at 2022-06-26 10:44:20.664644
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None
    assert validate_yaml(b"", validator=str) == (None, [])
    # Assert error message when required field is missing
    class MySchema(Schema):
        name = str


# Generated at 2022-06-26 10:44:31.168849
# Unit test for function validate_yaml
def test_validate_yaml():
    with pytest.raises(AssertionError) as error_0:
        validate_yaml(bytes_0, token_0)

    with pytest.raises(AssertionError) as error_1:
        validate_yaml(str_0, token_0)

    with pytest.raises(AssertionError) as error_2:
        validate_yaml(str_0(), token_0)

    with pytest.raises(TypeError) as error_3:
        validate_yaml(str_0, str_0)

    with pytest.raises(TypeError) as error_4:
        validate_yaml(str_0, str_0())

    with pytest.raises(Exception) as error_5:
        validate_yaml(str_0, token_0())


#

# Generated at 2022-06-26 10:44:42.750693
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type="string")
    bytes_0 = b'string'
    value, error_messages_0 = validate_yaml(bytes_0, validator)
    assert value == "string"
    assert len(error_messages_0) == 0
    bytes_0 = "string"
    value, error_messages_0 = validate_yaml(bytes_0, validator)
    assert value == "string"
    assert len(error_messages_0) == 0
    bytes_0 = b'2'
    value, error_messages_0 = validate_yaml(bytes_0, validator)
    assert value is None
    assert len(error_messages_0) == 1
    assert isinstance(error_messages_0[0], ValidationError)
    assert error_messages

# Generated at 2022-06-26 10:44:53.601368
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    msg = "Param. expected type: {}, actual type: {}"
    msg0 = msg.format(type(None), type(0))
    with pytest.raises(AssertionError, match=msg0):
        tokenize_yaml(0)
    msg1 = msg.format(type(None), type(bool))
    with pytest.raises(AssertionError, match=msg1):
        tokenize_yaml(bool)
    msg2 = msg.format(type(None), type(list))
    with pytest.raises(AssertionError, match=msg2):
        tokenize_yaml(list)



# Generated at 2022-06-26 10:45:00.178513
# Unit test for function validate_yaml
def test_validate_yaml():
    assert isinstance(validate_yaml(bytes_0,()), tuple) == True
    assert isinstance(validate_yaml(bytes_0,(Schema,)), tuple) == True
    assert isinstance(validate_yaml(bytes_0,()), tuple) == True

# Generated at 2022-06-26 10:45:02.311001
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml.__doc__
    assert validate_yaml("", "")

# Generated at 2022-06-26 10:45:05.922029
# Unit test for function validate_yaml
def test_validate_yaml():
    assert callable(validate_yaml), 'Function "validate_yaml" is not callable'
# End of unit test for function validate_yaml


# Generated at 2022-06-26 10:45:11.934572
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_0 = b''
    bytes_0 = b''
    validator_0 = 'foo'
    value_0, error_messages_0 = validate_yaml(yaml_0, validator_0)
    validator_1 = "foo"
    validator_2 = {"foo": "bar"}
    validator_3 = [{"foo": "bar"}, "baz"]
    value_1, error_messages_1 = validate_yaml(yaml_0, validator_3)


# Generated at 2022-06-26 10:45:13.316345
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 10:45:22.492340
# Unit test for function validate_yaml
def test_validate_yaml():
    # Instance for class Field
    obj_Field = Field(int, required=True)
    # Instance for class Field
    obj_field = Field(int, required=False)
    # Instance for class str
    obj_str = str

    result = validate_yaml(bytes_0, obj_Field)
    assert result == (None, [])
    result = validate_yaml(bytes_0, obj_field)
    assert result == (None, [])
    result = validate_yaml(bytes_0, obj_str)
    assert result == (None, [])

# Generated at 2022-06-26 10:45:31.582451
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_content = b"""
    valid_key:
        - "a"
        - "b"
    invalid_key: 1
    """
    field = Field(validators=[])
    expected = [
        {
            "field": "",
            "messages": [
                {
                    "text": '"1" is not a valid list.',
                    "code": "invalid_type",
                    "position": {"column_no": 13, "char_index": 48, "line_no": 3},
                }
            ],
        }
    ]
    assert expected == validate_yaml(yaml_content, field)


# Generated at 2022-06-26 10:45:34.530937
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(str)
    assert validate_yaml(b'', validator) == ("", [])


# Generated at 2022-06-26 10:45:39.580954
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Test case where the value is the correct type

    # Test case where the value is the wrong type

    # Test case where the value is malformed

    # Test case where there is a custom validator

    # Test case where there are two custom validators



# Generated at 2022-06-26 10:45:42.833876
# Unit test for function validate_yaml
def test_validate_yaml():
    # Parse and validate a YAML string, returning positionally marked error
    # messages on parse or validation failures.
    assert 0 == 0


# Generated at 2022-06-26 10:45:53.723498
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        field_1 = String()
        field_2 = String()

    str_0 = """
field_1: a
field_2: b
"""

    assert validate_yaml(str_0, TestSchema) == (  # type: ignore
        {"field_1": "a", "field_2": "b"},
        [],
    )

    class TestSchema(Schema):
        field_1 = String()
        field_2 = String(validators=[MinLength(1)])

    # Test a validation error with bad data.
    str_0 = """
field_1: a
"""


# Generated at 2022-06-26 10:45:58.665147
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '\t1'
    str_1 = '""'
    str_2 = 'a'
    str_3 = '{\t"a\t":\n-\t1\n-\t2\n-\t3\n}'
    str_4 = '{\t"a\t":\n-\t1\n-\t2\n-\t3\n}'
    str_5 = '{\t"a\t":\n-\t1\n-\t2\n-\t3\n}'
    str_6 = '{\t"a\t":\n-\t1\n-\t2\n-\t3\n}'

# Generated at 2022-06-26 10:46:06.886688
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    str_0 = '*x|U53'
    assert validate_yaml(str_0, Field()) == {'text': "Unable to parse YAML.", 'code': 'parse_error', 'position': {'line_no': 1, 'char_index': 1, 'column_no': 1}}

# Generated at 2022-06-26 10:46:13.284440
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '*x|U53'
    validator = Field(typing.List[str])
    meta = {'unknown': ['Taste']}
    input_ = (content, validator)
    expected_output = ([], [Message(code='unknown', meta=meta, position=Position(char_index=0, line_no=1, column_no=1))])
    actual_output = validate_yaml(*input_)
    assert actual_output == expected_output


# Generated at 2022-06-26 10:46:24.187052
# Unit test for function validate_yaml
def test_validate_yaml():
    # Ensure that errors are raised for invalid types

    # This should be fine
    validate_yaml("foo: bar",  {"foo": str})

    # This should not be fine
    with pytest.raises(ValidationError) as excinfo:
        validate_yaml("foo: 123",  {"foo": str})
    assert excinfo.value.full_messages()[0].text == "Expected str, not 123."

    # This should be fine
    token = tokenize_yaml("foo: bar\nbar: foo")
    assert token == {'foo': 'bar', 'bar': 'foo'}

    # This should be fine
    token = tokenize_yaml("foo: bar\nbar: foo")
    assert token == {'foo': 'bar', 'bar': 'foo'}

    # This should not be

# Generated at 2022-06-26 10:46:34.857281
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem.fields import String
    from typesystem.types import Enum
    from typesystem.schemas import Schema

    MySchema = Schema("MySchema", {"name": String(max_length=5, enum=Enum("a", "b"))})

    (result, messages) = validate_yaml("name: c", MySchema)
    assert result == "c"
    assert len(messages) == 1
    assert messages == [
        Message(
            text="Value must be one of '['a', 'b']'.",
            code="value_error.enum",
            kind="value_error",
            position=Position(line_no=1, column_no=6, char_index=5),
        )
    ]



# Generated at 2022-06-26 10:46:36.035919
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml


# Generated at 2022-06-26 10:46:46.131223
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*x|U53'
    # The 'tokenize_yaml' function should return a 'Token' object.
    token_0 = tokenize_yaml(str_0)

# Generated at 2022-06-26 10:46:48.894989
# Unit test for function validate_yaml
def test_validate_yaml():


    str_0 = '*x|U53'
    validator = Field(name='A', type='boolean')
    value,  messages = validate_yaml(str_0, validator)

# Generated at 2022-06-26 10:46:59.736775
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type="integer")
    str_0 = '*x|U53'
    with pytest.raises(ParseError):
        validate_yaml(str_0, validator)

    str_0 = '*x|U53'
    (value_0, error_messages_0) = validate_yaml(str_0, validator)
    assert (error_messages_0[0].message) == 'Invalid integer.'

    with pytest.raises(ParseError):
        validate_yaml(str_0, validator)

    str_0 = '*x|U53'
    (value_0, error_messages_0) = validate_yaml(str_0, validator)
    assert (error_messages_0[0].message) == 'Invalid integer.'

   

# Generated at 2022-06-26 10:47:13.397383
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*x|U53'
    token_0 = tokenize_yaml(str_0)
    value_0, errors_0 = validate_yaml(str_0, validator=Field())
    # value_0 = []
    # errors_0 = []
    assert value_0 == []
    assert errors_0 == []
    # str_1 = '*x|U53'
    # token_1 = tokenize_yaml(str_1)
    # value_1, errors_1 = validate_yaml(str_1, validator=Field(required=True))
    # value_1 = []
    # errors_1 = []
    # assert value_1 == []
    # assert errors_1 == []
    str_2 = '*x|U53'
    token_2 = tokenize

# Generated at 2022-06-26 10:47:23.617523
# Unit test for function validate_yaml
def test_validate_yaml():
    # StringIO object is needed when reading YAML from a string
    from io import StringIO

    str_0 = '''
    - name: "One"
      value: 1
    - name: "Two"
      value: 2
    - name: "Three"
      value: 3
    '''
    str_1 = '''
    - One
    - Two
    - Three
    '''
    str_2 = '''
    - name: "Four"
      value: 4
      description: "A description"
    '''

    yaml_str = StringIO(str_0)
    yaml_data = yaml.load(yaml_str)


# Generated at 2022-06-26 10:47:33.324426
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Test content was parsed as the appropriate token type.
    assert isinstance(token_0, ListToken)

    # Test positional validation works as expected.
    value_0, errors_0 = validate_yaml(
        content=str_0, validator=fields.Array(items=fields.Integer(), min_items=2)
    )
    assert value_0 is None
    assert isinstance(errors_0[0], ValidationError)
    # Test error messages contain the correct position data.
    assert errors_0[0].position.char_index == 0
    assert errors_0[0].position.line_no == 1
    assert errors_0[0].position.column_no == 1
    assert errors_0[1].position.char_index == 5


# Generated at 2022-06-26 10:47:42.576811
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*x|U53'
    validator_0 = Boolean()
    value_0, error_messages_0 = validate_yaml(str_0, validator_0)
    validator_1 = Boolean()
    value_1, error_messages_1 = validate_yaml(str_0, validator_1)
    assert value_1 is None
    assert error_messages_1[0].code == "invalid_type"
    assert error_messages_1[0].position.char_index == 0
    assert error_messages_1[0].position.column_no == 1
    assert error_messages_1[0].position.line_no == 1
    assert error_messages_1[0].text == "Value is not a boolean."



# Generated at 2022-06-26 10:47:54.466043
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class A(Schema):
        x = Field(required=True)

    # Parse and validate a string successfully.
    value, errors = validate_yaml("x: 3", A)
    assert value == {"x": 3}
    assert errors == []

    # Handle invalid types.
    value, errors = validate_yaml("x: 7", A)
    assert value == {"x": 7}
    assert errors == []

    value, errors = validate_yaml("x: '7'", A)
    assert value == {"x": "7"}

# Generated at 2022-06-26 10:48:04.651001
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test case 0
    instance_0 = '*x|U53'
    instance_1 = '*x|U53'
    error_messages_0 = False
    assert validate_yaml(instance_0, instance_1) == error_messages_0
    # Test case 1
    instance_0 = '\xe2\x85\xab\x5b5\xcc\xc1O\x8c\xb2\xbc\xd6\x93\x8f\x1f\xdd\x10\x83\x06\xfe\xf7'

# Generated at 2022-06-26 10:48:08.700061
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # yaml: v1.2
    assert tokenize_yaml("true") == True
    # yaml: v1.2
    assert tokenize_yaml("false") == False
    # yaml: v1.2
    assert tokenize_yaml("null") == None
    # yaml: v1.2
    assert tokenize_yaml("0") == 0
    # yaml: v1.2
    assert tokenize_yaml("123") == 123
    # yaml: v1.2
    assert tokenize_yaml("-123") == -123
    # yaml: v1.2
    assert tokenize_yaml("123.45") == 123.45
    # yaml: v1.2
    assert tokenize_yaml("-123.45") == -123.45
    # y

# Generated at 2022-06-26 10:48:10.272362
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("[1, 2]", list) == ([1, 2], [])


# Generated at 2022-06-26 10:48:15.002127
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '*x|U53'
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, ListToken)



# Generated at 2022-06-26 10:48:19.587785
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "key: value"
    validator = typing.Dict
    assert validate_yaml(str_0, validator) == ({'key': 'value'}, [])


# Generated at 2022-06-26 10:48:34.892784
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("", Field(type="string")) == ("", [])
    assert validate_yaml("string", Field(type="string")) == ("string", [])
    assert validate_yaml("string", Field(type="string", max_length=4)) == ("string", [])
    assert validate_yaml("string", Field(type="string", max_length=3)) == (
        "string",
        [
            Message(
                text="Value is longer than the maximum length of 3.",
                code="max_length",
                start=0,
                end=6,
            )
        ],
    )
    assert validate_yaml("string", Field(type="string", min_length=3)) == ("string", [])

# Generated at 2022-06-26 10:48:45.358676
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '{ hello: world }'
    validator_0 = Schema(fields={'hello': str})
    value_0, err_0 = validate_yaml(str_0, validator_0)
    assert isinstance(err_0, typing.List[Message])
    assert value_0 == {'hello': 'world'}
    assert err_0 == []

    str_1 = 'not a real yaml document'
    validator_1 = Schema(fields={'hello': str})
    with pytest.raises(ParseError):
        _ = validate_yaml(str_1, validator_1)

    str_2 = '1'
    validator_2 = Schema(fields={'hello': int})

# Generated at 2022-06-26 10:48:57.075564
# Unit test for function validate_yaml
def test_validate_yaml():
    # Failure case
    try:
        str_0 = '*x|U53'
        token_0 = tokenize_yaml(str_0)
        # Failure case where expected type <type 'list'> does not match actual type <type 'dict'>
        val_0: typing.Union[Token, str] = token_0
        rval_0 = validate_yaml(val_0, list)
        assert False
    except ValidationError as exc_0:
        assert str(exc_0) == 'Value is not a list: *x|U53.'
        assert exc_0.code == 'invalid_type'
        assert exc_0.field == 'typeof'
        assert exc_0.position == Position(column_no=8, char_index=7, line_no=1)

    # Success case

# Generated at 2022-06-26 10:49:03.661475
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = typesystem.Schema(
        fields={"name": typesystem.String(max_length=10), "age": typesystem.Number(maximum=150)}
    )
    data = {"name": "Jane", "age": 30}
    str_data = yaml.dump(data)
    value, errors = validate_yaml(str_data, schema)
    assert value == data
    assert len(errors) == 0

# Generated at 2022-06-26 10:49:12.272046
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*x|U53'
    str_1 = '*x|U53'
    token_0 = tokenize_yaml(str_0)
    str_2 = '*x|U53'
    token_1 = validate_yaml(content=str_2,validator=token_0)
    assert type(token_1) == typing.Tuple[type(token_0), typing.List[Message]]


# Generated at 2022-06-26 10:49:18.660712
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*x|U53'
    ret_0 = validate_yaml(str_0, )
    assert(ret_0 == None)

    str_1 = '3'
    ret_1 = validate_yaml(str_1, )
    assert(ret_1 == None)



# Generated at 2022-06-26 10:49:21.855766
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '{}'
    validator = '{}'
    assert validate_yaml(content, validator) == ('{}', '{}')


# Generated at 2022-06-26 10:49:34.133293
# Unit test for function validate_yaml
def test_validate_yaml():
    content_0 = b'\xE6\x97\xA5\xE6\x9C\xAC\xE8\xAA\x9E'
    validator_0 = Schema()
    value_0, error_messages_0 = validate_yaml(content_0, validator_0)
    content_1 = b'\xE6\x97\xA5\xE6\x9C\xAC\xE8\xAA\x9E'
    validator_1 = Schema()
    value_1, error_messages_1 = validate_yaml(content_1, validator_1)


# Generated at 2022-06-26 10:49:38.703834
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(name="x", fields=[Field(name="x", validators=[])])
    value, messages = validate_yaml('- "5"', schema)
    assert messages == []


# Generated at 2022-06-26 10:49:42.607667
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content=str_0,
        validator=validator) == (value, error_messages)

# Generated at 2022-06-26 10:49:54.421359
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*x|U53'
    str_1 = '*x|U53'
    test_0 = validate_yaml(content=str_0, validator=Field(type="string"))
    assert test_0[0] == None
    test_1 = validate_yaml(content=str_1, validator=Field(type="string"))
    assert test_1[0] == None


# Generated at 2022-06-26 10:49:55.835830
# Unit test for function validate_yaml
def test_validate_yaml():
    assert False, 'Not implemented'


# Generated at 2022-06-26 10:50:04.784683
# Unit test for function validate_yaml
def test_validate_yaml():
    # Set up one test case
    try:
        str_0 = '*x|U53'
        token_0 = tokenize_yaml(str_0)
        validator_0 = None # TODO: make a more realistic validator for the input
        value_0, err_0 = validate_yaml(token_0, validator_0)
    except Exception as e:
        print(e)

# Generated at 2022-06-26 10:50:17.484557
# Unit test for function validate_yaml
def test_validate_yaml():
    class UserSchema(Schema):
        name = "User"
        fields = {"email": "email"}

    with pytest.raises(ParseError) as exc_info:
        validate_yaml(content="{}", validator=UserSchema)

    assert exc_info.value.position == Position(column_no=1, line_no=1, char_index=0)

    with pytest.raises(ValidationError) as exc_info:
        validate_yaml(content="email: invalid", validator=UserSchema)

    assert exc_info.value.position == Position(column_no=7, line_no=1, char_index=6)
    assert exc_info.value.code == "format_error"


# Generated at 2022-06-26 10:50:20.610318
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '*x|U53'
    token_0 = tokenize_yaml(str_0)
    assert token_0 is not None


# Generated at 2022-06-26 10:50:25.747870
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(["name", "age", "married"])
    content = "name: Bob\nage: 35\nmarried: True"
    value, error_messages = validate_yaml(content, validator=schema)
    assert value == {"name": "Bob", "age": 35, "married": True}
    assert error_messages == []


# Generated at 2022-06-26 10:50:38.423309
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test a failing case.
    str_0 = '*x|U53'
    # Double check the parse error.
    try:
        tokenize_yaml(str_0)
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "while scanning a simple key\n  in 'string', line 1, column 1\n"
        assert exc.code == "parse_error"
    # Check the validation error.
    value_0, error_messages_0 = validate_yaml(str_0, String())
    assert not value_0

# Generated at 2022-06-26 10:50:49.821049
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = '#'
    validator_1 = Field(name='name_1', type_name='str', nullable=True, min_length=1, max_length=None, re_pattern=None, format=None, description=None, default=None, choices=None, title=None, not_empty=None, enum='abc', enum_multiple=None, minimum=None, maximum=None, exclusive_minimum=None)
    val_1, messages_1 = validate_yaml(validator=validator_1, content=str_1)
    assert messages_1[0].position.line_no == 1
    assert messages_1[0].position.column_no == 1
    assert messages_1[0].position.char_index == 0
    str_2 = '-----------------\n'
    validator_2 = Field

# Generated at 2022-06-26 10:50:56.868832
# Unit test for function validate_yaml
def test_validate_yaml():

    str_0 = '-  a: 1\n-  b: 2\n-  c: 3'
    list_0 = [{'a': 1}, {'b': 2}, {'c': 3}]
    schema_0 = typing.List[typing.Dict[str, int]]
    value_0, error_messages_0 = validate_yaml(str_0, schema_0)

    assert (value_0 == list_0)
    assert (error_messages_0 == [])

    str_1 = '{"a": 1}'
    dict_1 = {'a': 1}
    schema_1 = typing.Dict[str, int]
    value_1, error_messages_1 = validate_yaml(str_1, schema_1)


# Generated at 2022-06-26 10:51:08.343014
# Unit test for function validate_yaml
def test_validate_yaml():
    content_0 = b'YWJj\n'
    validator_0 = str
    assert (validate_yaml(content_0, validator_0) == (b'abc\n', []))
    str_1 = '*x|U53'
    token_1 = tokenize_yaml(str_1)
    content_1 = b'\n'
    validator_1 = str
    assert (validate_yaml(content_1, validator_1) == (b'\n', []))
    str_2 = 'W8mD'
    token_2 = tokenize_yaml(str_2)

# Generated at 2022-06-26 10:51:19.142202
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*x|U53'
    field_0 = Field(str_0)
    str_1 = '*x|U53'
    field_1 = Field(str_1)
    str_2 = '*x|U53'
    field_2 = Field(str_2)
    str_3 = '*x|U53'
    field_3 = Field(str_3)
    str_4 = '*x|U53'
    field_4 = Field(str_4)
    str_5 = '*x|U53'
    field_5 = Field(str_5)
    str_6 = '*x|U53'
    field_6 = Field(str_6)
    str_7 = '*x|U53'
    field_7 = Field(str_7)

# Generated at 2022-06-26 10:51:20.802928
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert True is not False


# Generated at 2022-06-26 10:51:29.513859
# Unit test for function validate_yaml
def test_validate_yaml():
    from typing import List

    # Test the case where the content is a string, and the validator is a Field
    content = '*x|U53'
    validator = Field(name="yaml_test", data_type="str")
    expected_value = '*x|U53'
    expected_error_messages = [] # type: List[Message]
    actual_value, actual_error_messages = validate_yaml(content, validator)
    assert actual_value == expected_value
    assert actual_error_messages == expected_error_messages

    # Test the case where the content is a string, and the validator is a Schema
    content = '*x|U53'
    validator = Schema
    expected_value = None

# Generated at 2022-06-26 10:51:33.519676
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Basic test case for typesystem.tokenize.yaml.tokenize_yaml
    assert tokenize_yaml is not None
