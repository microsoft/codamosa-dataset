

# Generated at 2022-06-26 10:42:06.633464
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = ' *uB3uX:*M>j[V4'
    token_0 = tokenize_yaml(str_0)
    str_1 = '"*uB3uX:*M>j[V4"'
    token_1 = tokenize_yaml(str_1)


# Generated at 2022-06-26 10:42:18.653665
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test exception raised for no argument
    try:
        validate_yaml()
        assert False
    except TypeError:
        assert True


    # Test assertion error raised for content not valid str or bytes
    try:
        validate_yaml({})
        assert False
    except AssertionError:
        assert True


    # Test yaml parsing and invalid validator error
    try:
        validate_yaml('some yaml string', 'not valid validator')
        assert False
    except AssertionError:
        assert True


    # Test no error
    assert validate_yaml('some yaml string', Field()) == (
        'some yaml string',
        [],
    )



# Generated at 2022-06-26 10:42:31.700894
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Loading content 0 to 14
    str_0 = 'kFp+%cxm#r"dQ2,MTg'
    token_0 = tokenize_yaml(str_0)
    assert type(token_0) == DictToken

    # Loading content 1 to 14
    str_1 = '{}'
    token_1 = tokenize_yaml(str_1)
    assert type(token_1) == DictToken

    # Loading content 2 to 14
    str_2 = '---\n    -\n     - a\n     - b\n    -\n     - c\n     - d'
    token_2 = tokenize_yaml(str_2)
    assert type(token_2) == ListToken

    # Loading content 3 to 14

# Generated at 2022-06-26 10:42:41.990616
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    str_0 = "---\nhello: world\n"
    token_0 = tokenize_yaml(str_0)
    assert type(token_0) == DictToken
    assert token_0.value == {'hello': 'world'}
    assert token_0.start == 3
    assert token_0.end == 16
    assert token_0.content == "---\nhello: world\n"
    # Make sure tokenization of None is supported, but string values are
    # not.
    str_1 = "---\nhello: null\n"
    token_1 = tokenize_yaml(str_1)
    assert type(token_1) == DictToken
    assert token_1.value == {'hello': None}

# Generated at 2022-06-26 10:42:55.042124
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    str_0 = ' *uB3uX:*M>j[V4'
    token_0 = tokenize_yaml(str_0)
    validator_0 = Field("string")
    assert validate_with_positions(token_0, validator_0) == (String(" *uB3uX:*M>j[V4"), [])

    str_1 = '\n  - 6\n  - E)7Q{E_\n  - 2\n'
    token_1 = tokenize_yaml(str_1)
    validator_1 = Field("list", items=Field("number"))

# Generated at 2022-06-26 10:42:58.900937
# Unit test for function validate_yaml
def test_validate_yaml():
    # TODO: assert actual result is returned
    value, messages = validate_yaml(content="", validator=None)
    assert messages == []
    assert value is None

# Generated at 2022-06-26 10:43:07.552004
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test Cases
    yaml_0 = '`gp\nV7(u^k\.$'
    expect_token_0 = []
    actual_token_0 = tokenize_yaml(yaml_0)

    # Boundary Test Cases
    yaml_1 = None
    actual_token_1 = tokenize_yaml(yaml_1) # should raise a "TypeError: Object of type 'NoneType' is not JSON serializable" exception

    # Boundary Test Cases
    yaml_2 = r'{"key": "value",}' # the last value is '}' instead of '}', this should raise an error
    actual_token_2 = tokenize_yaml(yaml_2)  # should raise a ParseError exception

    # Boundary Test Cases

# Generated at 2022-06-26 10:43:17.870979
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    with pytest.raises(ParseError):
        str_1 = ' *uB3uX:*M>j[V4'
        token_1 = tokenize_yaml(str_1)
        str_2 = '"""""'
        token_2 = tokenize_yaml(str_2)
        str_3 = '"""""'
        token_3 = tokenize_yaml(str_3)
    with pytest.raises(ParseError):
        str_4 = '"*uB3uX:*M>j[V4"'
        token_4 = tokenize_yaml(str_4)
        str_5 = '"*'
        token_5 = tokenize_yaml(str_5)

# Generated at 2022-06-26 10:43:29.204089
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test case 0
    str_0 = ' *uB3uX:*M>j[V4'
    token_0 = tokenize_yaml(str_0)

    assert token_0 is not None, "tokenize_yaml returned unexpected result: token_0 is None"
    assert isinstance(token_0, ScalarToken), "tokenize_yaml returned unexpected result: token_0 is not instance of ScalarToken"
    assert token_0.value == ' *uB3uX:*M>j[V4', "tokenize_yaml returned unexpected result: value of token_0 is not \" *uB3uX:*M>j[V4\""

# Generated at 2022-06-26 10:43:40.774418
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "a: 1"
    str_1 = "# a: 1"
    str_2 = "a: 1\nb: 2"
    str_3 = "a: - 1"
    str_4 = "a: - 1\n  - 2"
    str_5 = "a:\n  - 1\n  - 2"
    str_6 = ""
    str_7 = "a: {b: 1 }"
    str_8 = "a: {b: 1 }\n    d: 2"
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, ScalarToken)
    assert token_0.value == 1
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, ScalarToken)
   

# Generated at 2022-06-26 10:43:58.921095
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    str_0 = ' *uB3uX:*M>j[V4'
    assert tokenize_yaml(str_0) == ScalarToken(' *uB3uX:*M>j[V4', 0, 14, content=str_0)
    str_0 = '%^!P*2G*<X[1f53a'
    assert tokenize_yaml(str_0) == ScalarToken('%^!P*2G*<X[1f53a', 0, 14, content=str_0)
    str_0 = '"I6<>U_9PvV8WL<A'
    assert tokenize_yaml(str_0) == ScalarToken('I6<>U_9PvV8WL<A', 0, 14, content=str_0)

# Generated at 2022-06-26 10:44:08.487801
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '{you: 5}'
    token_0 = tokenize_yaml(str_0)
    if isinstance(token_0, DictToken):
        assert token_0.value == {'you':5}
    else:
        assert False
    str_1 = '[1,2,3,4]'
    token_1 = tokenize_yaml(str_1)
    if isinstance(token_1, ListToken):
        assert token_1.value == [1,2,3,4]
    else:
        assert False


# Generated at 2022-06-26 10:44:19.617550
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    foo: 1
    bar: true
    """.strip()
    value, errors = validate_yaml(
        content,
        {
            "foo": {"type": "integer"},
            "bar": {"type": "boolean"},
        },
    )
    assert value == {"foo": 1, "bar": True}
    assert not errors

    errors = validate_yaml(
        content, {"foo": {"type": "integer"}, "bar": {"type": "integer"}}
    )[1]
    assert errors[0].text == "Value must be of type 'integer'."
    assert errors[0].code == "invalid_type"
    assert errors[0].position.column_no == 8
    assert errors[0].position.line_no == 3



# Generated at 2022-06-26 10:44:25.874095
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'K<n/5/5[ZS/&"92E'
    str_1 = 'e.N_^<'
    str_2 = 'H?#w"Bt.'
    str_3 = '&"\x93\xae\x8f\x86\x9c'
    str_4 = 'W)Ov2'
    str_5 = '\xfb\xa5\x0f\xbb\xbf\x8d\x14\x97\x85\xad\xdc\x90\xb6\x11\xa7'
    str_6 = '\x19\xdd_\xd8\xdb\xeb\xcd\x19\xf0\x11\x97'

# Generated at 2022-06-26 10:44:28.564236
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = ' *uB3uX:*M>j[V4'
    assert tokenize_yaml(content) is not None


# Generated at 2022-06-26 10:44:36.332176
# Unit test for function validate_yaml
def test_validate_yaml():
  str_0 = ' {message:"hello world"} '
  validator_0 = Schema(fields=[
       Field(name="message", type="string")])
  value_0, message_0 = validate_yaml(str_0, validator_0)

  assert value_0 == {'message': 'hello world'}
  assert message_0 == None


# Generated at 2022-06-26 10:44:40.263236
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(b'hello\xabworld')
    assert tokenize_yaml(b'\x00\x01\x02\x03\x04\x05')
    assert tokenize_yaml(b'- \xef\xbb\xbf')


# Generated at 2022-06-26 10:44:53.301545
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '1.5wu9'
    token_0 = tokenize_yaml(str_0)

    str_1 = '[j5t[],Bn}#\t=n(gPf@7P~d.`"\n*m|-m#)2T'
    token_1 = tokenize_yaml(str_1)

    str_2 = '[BB`z+g{U|%6J9Y3+B:C,\n&-R>]!jS.J#I^'
    token_2 = tokenize_yaml(str_2)

    str_3 = 'wSjS'
    token_3 = tokenize_yaml(str_3)

    str_4 = '|]~K\nMvc'
    token_4 = tokenize_y

# Generated at 2022-06-26 10:44:57.967286
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    assert isinstance(tokenize_yaml(str()), ScalarToken), "tokenize_yaml() failed\n"



# Generated at 2022-06-26 10:45:05.933536
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from filecmp import cmp
    from .test_data import JSON_DATA_PATH, TOKEN_DATA_PATH
    import os
    import json

    with open(JSON_DATA_PATH, 'r') as f:
        data = json.load(f)

    for json_str in data:
        token = tokenize_yaml(json_str)
        if (not os.path.exists(TOKEN_DATA_PATH)):
            os.makedirs(TOKEN_DATA_PATH)
        with open(TOKEN_DATA_PATH + "/tokens.yaml", "a") as f:
            f.write("- " + str(token) + "\n")


# Generated at 2022-06-26 10:45:23.603867
# Unit test for function validate_yaml
def test_validate_yaml():
    def test_validate_yaml_inner(c, v, m, e, p):
        assert isinstance(c, str)
        assert isinstance(v, Field) or issubclass(v, Schema)
        assert isinstance(m, list)
        assert isinstance(e, dict)
        assert isinstance(p, dict)

    class HotelSchema(Schema):
        name = Field(str)
        stars = Field(int)
        address = Field(str)
        postcode = Field(str)
        location = Field(str)


# Generated at 2022-06-26 10:45:33.536179
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = ' *uB3uX:*M>j[V4'
    token_0 = tokenize_yaml(str_0)
    assert token_0 == ' *uB3uX:*M>j[V4'

    str_1 = '\nABC\nDEF\nGHI\n'
    token_1 = tokenize_yaml(str_1)
    assert token_1 == 'ABC\nDEF\nGHI\n'

    str_2 = '\nABC\nDEF\nGHI\nJKL\n'
    token_2 = tokenize_yaml(str_2)
    assert token_2 == 'ABC\nDEF\nGHI\nJKL\n'

    str_3 = '{}'
    token_3 = tokenize_

# Generated at 2022-06-26 10:45:47.045160
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    str_0 = ' *uB3uX:*M>j[V4'
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, DictToken)
    assert token_0.index == 0
    assert token_0.end_index == 13
    assert token_0.value == OrderedDict()
    assert token_0.content == str_0
    assert isinstance(token_0[0], ScalarToken)
    assert token_0[0].index == 1
    assert token_0[0].end_index == 5
    assert token_0[0].value == 'uB3uX'
    assert isinstance(token_0[1], ScalarToken)
    assert token_0

# Generated at 2022-06-26 10:45:57.341442
# Unit test for function validate_yaml
def test_validate_yaml():
    schema_str = """
    type: object
    properties:
      name:
        type: string
        maxLength: 100
      age:
        type: integer
    """
    data = {
        "name": "foo",
        "age": 10
    }
    schema = typesystem.Schema(schema_str)
    data_str = yaml.dump(data)
    result = validate_yaml(data_str, schema)
    assert result.is_valid

# Generated at 2022-06-26 10:46:04.250969
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = ' *uB3uX:*M>j[V4'
    token_0 = tokenize_yaml(str_0)

    # Verify that value == ScalarToken
    assert isinstance(token_0, ScalarToken)

    # Verify that content[token_0.start:token_0.end] == str_0
    assert str_0 == str_0[token_0.start:token_0.end]

    # Verify that position.line_no == 1
    assert 1 == _get_position(str_0, token_0.start).line_no

    # Verify that position.column_no == 1
    assert 1 == _get_position(str_0, token_0.start).column_no

    # Verify that position.char_index == 0

# Generated at 2022-06-26 10:46:12.635436
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = ' *uB3uX:*M>j[V4'
    token_0 = tokenize_yaml(str_0)
    assert token_0.content == str_0
    assert token_0.start == 0
    assert token_0.end == len(str_0) - 1
    assert token_0.children == [
        ScalarToken(' *uB3uX', 0, 7, str_0),
        ScalarToken(':*M>j[V4', 8, 14, str_0),
    ]



# Generated at 2022-06-26 10:46:22.302270
# Unit test for function validate_yaml
def test_validate_yaml():
    #
    # Test schema validation.
    #
    # The class below inherits from the default Schema class and adds a few
    # custom attributes to customize validation behaviour.
    #

    class TestSchema(Schema):
        # Sets the error code prefix.
        code_prefix = "test_schema"

        def _validate_mapping_name(self, name: str, value: typing.Any) -> None:
            if name not in self.mapping:
                raise ValidationError(
                    text=f"Invalid key: '{name}'.", code="invalid_key",
                )



# Generated at 2022-06-26 10:46:31.294871
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = ' *uB3uX:*M>j[V4'
    token_0 = tokenize_yaml(str_0)
    value_0, error_messages_0 = validate_yaml(str_0, validator=Field())
    assert value_0 == token_0.value
    assert len(error_messages_0) == 1
    assert error_messages_0[0].position == token_0.start_position
    assert error_messages_0[0].code == ErrorCodes.INVALID_TYPE

# Generated at 2022-06-26 10:46:43.859985
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = ' *uB3uX:*M>j[V4'
    # Fails to parse because of improperly escaped content, due to
    # https://github.com/yaml/pyyaml/pull/159/files
    error_0 = {'code': 'parse_error', 'text': 'Invalid escape sequence.',
               'position': Position(column_no=6, line_no=1, char_index=6)}
    # str_1 = """{
    #   "person": null,
    # }"""
    # error_1 = {'code': 'invalid_data_type',
    #            'text': 'Must be a boolean.',
    #            'position': Position(column_no=14, line_no=2,
    #                                 char_index=14)}
    # str_

# Generated at 2022-06-26 10:46:48.931423
# Unit test for function validate_yaml
def test_validate_yaml():
    content = ' *uB3uX:*M>j[V4'
    positional_validation = validate_yaml(content, content)
    print(positional_validation)



if __name__ == "__main__":
    test_case_0()
    test_validate_yaml()

# Generated at 2022-06-26 10:47:06.329034
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'test_schema'
    dict_0 = dict()
    dict_0['type'] = str_0
    dict_1 = dict()
    dict_1['type'] = str_0
    dict_1['required'] = True
    dict_2 = dict()
    dict_2['type'] = str_0
    dict_2['required'] = True
    dict_2['blank'] = True
    list_0 = list()
    list_0.append(dict_0)
    list_0.append(dict_1)
    list_0.append(dict_2)
    dict_3 = dict()
    dict_3['properties'] = list_0
    dict_3['required'] = list()
    dict_3['required'].append('required:false')

# Generated at 2022-06-26 10:47:19.611501
# Unit test for function validate_yaml
def test_validate_yaml():
    # Create a dummy schema and test the validator
    class MySchema(Schema):
        first = int
        last = str
        # Create a function that returns a ValidationError
        def validate_first(self, value):
            if value < 100:
                raise ValidationError("Value must be >= 100")
        # Create a function that returns a ValidationError
        def validate_last(self, value):
            if value != "Smith":
                raise ValidationError("Value must be 'Smith'")

    schema = MySchema()

    valid_input = '{first: 100, last: "Smith"}'
    invalid_input = '{first: 99, last: "Smith"}'
    invalid_input_2 = '{first: 100, last: "Jones"}'

    # Testing valid input

# Generated at 2022-06-26 10:47:31.584583
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "test_schema"
    str_1 = "test_schema"
    str_0 = str_0 + str_1
    str_0 = 'null'
    str_1 = 'null'
    str_0 = str_0 + str_1
    str_1 = 'null'
    str_0 = str_0 + str_1
    str_0 = 'null'
    str_1 = 'null'
    str_0 = str_0 + str_1
    str_0 = 'null'
    str_1 = 'null'
    str_0 = str_0 + str_1
    str_0 = 'null'
    str_1 = 'null'
    str_0 = str_0 + str_1
    str_0 = 'null'

# Generated at 2022-06-26 10:47:40.240186
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:47:47.400914
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:47:52.560048
# Unit test for function validate_yaml
def test_validate_yaml():
    # test_case_0 = u'{"foo": "bar"}'
    # test_schema = Schema('{"test": 123}')
    # t0 = tokenize_yaml(test_case_0)
    # v0 = validate_with_positions(t0, test_schema)
    # assert v0 == True
    return True


# Generated at 2022-06-26 10:48:03.783478
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test_schema = {
        "name": "string",
        "age": "integer",
        "address": {
            "city": "string",
            "country": "string",
        },
        "grades": ["integer"],
        "is_student": "boolean",
        "num_credits": "number",
        "friends": [{"name": "string", "age": "integer"}],
        "enemies": [{"name": "string", "age": "integer"}],
        "aliases": ["string"],
        "status": "null",
    }
    schema = Schema(test_schema)

# Generated at 2022-06-26 10:48:12.563090
# Unit test for function validate_yaml
def test_validate_yaml():
    
    # check if 'pyyaml' is installed
    assert yaml is not None, "'pyyaml' must be installed."
    print(">> test case 0: ")
    str_0 = '''
        test: 1
    '''
    str_1 = ''
    validator = test_case_0()
    result_0 = validate_yaml(str_0, validator)
    assert result_0[0] == {'test': 1}, "Test case 0 failed"
    assert result_0[1] == [], "Test case 0 failed"
    print("Test case 0 passed")
    print(">> test case 1: ")
    result_1 = validate_yaml(str_1, validator)
    assert result_1[0] == {}, "Test case 1 failed"

# Generated at 2022-06-26 10:48:20.820080
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "test_schema"
    token = tokenize_yaml(str_0)
    assert isinstance(token, ScalarToken)
    assert token.value == "test_schema"
    assert token.start == 0
    assert token.end == len("test_schema") - 1
    assert token.content == "test_schema"
    assert token.get_text() == "test_schema"

# Generated at 2022-06-26 10:48:33.429177
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # empty string
    str_0 = ""
    value_0, messages_0 = validate_yaml(str_0, test_schema)
    assert messages_0[0].text == "No content."
    assert messages_0[0].code == "no_content"
    assert messages_0[0].position.line_no == 1
    assert messages_0[0].position.column_no == 1
    assert value_0 == {}

    # invalid types
    str_1 = "test_schema"

    value_1, messages_1 = validate_yaml(str_1, test_schema)
    assert messages_1[0].text == "Invalid types."
    assert messages_1[0].code == "invalid_types"
    assert messages_1[0].position.line_no == 1
    assert messages

# Generated at 2022-06-26 10:48:42.685326
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test_0 = 'test_schema'
    test_1 = 'test_schema2'
    expected_0 = test_0
    expected_1 = test_1
    actual_0 = tokenize_yaml(test_0)
    actual_1 = tokenize_yaml(test_1)
    assert_equals(actual_0, expected_0)
    assert_equals(actual_1, expected_1)


# Generated at 2022-06-26 10:48:48.060614
# Unit test for function validate_yaml
def test_validate_yaml():
    test_cases = [
        ("""
        name: test_schema
        type: object
        properties:
            id:
                type: integer
            name:
                type: string
        """, Message(name='test_schema', id='', name=''))
    ]
    for (str_0, expected) in test_cases:
        result = validate_yaml(str_0, Person)
        assert result == expected, "Expected: %s, but got: %s" % (expected, result)

test_validate_yaml()

# Generated at 2022-06-26 10:48:59.430740
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
  # assert validate_with_positions(token=tokenize_yaml(content='key0: value0'), validator='{key0: value0}')[0] == True
  # assert validate_with_positions(token=tokenize_yaml(content='{key0: value0}'), validator='{key0: value0}')[0] == True
  assert tokenize_yaml(content='{key0: value0}') == {'key0': 'value0'}
  # assert validate_with_positions(token=tokenize_yaml(content='key0: value0'), validator='{key0: value0}')[0] == True
  # assert validate_with_positions(token=tokenize_yaml(content='{key0: value0} key1: value1'), validator='{key

# Generated at 2022-06-26 10:49:01.543551
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert True
    token = tokenize_yaml(str_0)


# Generated at 2022-06-26 10:49:14.512656
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'test_schema'

# Generated at 2022-06-26 10:49:23.210772
# Unit test for function validate_yaml
def test_validate_yaml():

    try:
        _yaml = yaml
    except NameError:
        _yaml = None

    class TestSchema(Schema):
        int_field = Field(type="integer")
        str_field = Field(type="string")

    def test_parse_error():
        content = "{'int_field': 123, 'str_field' '123'}"
        (value, error_messages) = validate_yaml(content, TestSchema)
        assert not error_messages

    if _yaml is None:
        raise RuntimeError('Need yaml for this test.')

# Generated at 2022-06-26 10:49:31.149027
# Unit test for function validate_yaml
def test_validate_yaml():
    data = "Hello there, friend."

    try:
        validate_yaml(data, validator='Invalid')
    except Exception as exception_0:
        assert type(exception_0) == ParseError

if __name__ == '__main__':
    test_case_0()
    test_validate_yaml()

# Generated at 2022-06-26 10:49:33.134395
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'test_schema'
    str_1 = 'test_schema'

# Generated at 2022-06-26 10:49:46.071130
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "[1, 2, 3]\n"
    str_1 = "[\n    1, \n    2, \n    3\n]\n"
    str_2 = '{"a": 1, "b": "hello", null: [1, "two", true, false], "d": {"e": true}}\n'
    str_3 = '{"a": 1, "b": "hello", null: [1, "two", true, false], "d": {"e": true}}'
    str_4 = '{"a": 1, "b": "hello", null: [1, "two", true, false], "d": {"e": true}}'

    assert len(tokenize_yaml(str_0)) == 3
    assert len(tokenize_yaml(str_1)) == 3
    assert len

# Generated at 2022-06-26 10:49:58.172816
# Unit test for function validate_yaml
def test_validate_yaml():
    # Initialize varibles
    schema = Schema(
        [
            Field(name="name", type="string"),
            Field(name="age", type="integer"),
            Field(name="siblings", type="integer"),
        ]
    )
    str_0 = "name: 'The Doctor'\nage: 900\nsiblings: 0"
    str_1 = "name: 'The Doctor'\nage: 900"
    str_2 = "name: 'The Doctor'\nage: 900\nsiblings: 0\nfoo: bar"
    str_3 = "name: 'The Doctor'\nage: 900\nsiblings: 0\n- foo: bar"
    str_4 = "name: 'The Doctor'\nage: 900\nsiblings: 0\n- name: foo"

# Generated at 2022-06-26 10:50:03.912086
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = 'test_schema'


# Generated at 2022-06-26 10:50:10.275154
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test case with invalid arguments.
    # str_0 = 'test_schema'
    # Test case with valid arguments.
    # str_0 = 'test_schema'

    # Validate a YAML string, returning positionally marked error messages on parse or validation failures.
    validate_yaml()

    

# Generated at 2022-06-26 10:50:16.099928
# Unit test for function validate_yaml
def test_validate_yaml():
    # Given
    str_0 = 'test_schema'

    # When
    # When
    try:
        assert validate_yaml(str_0, str)
    # Then
    except ValidationError:
        assert True

    try:
        assert validate_yaml(str_0, str)
    except TypeError:
        assert True


# Generated at 2022-06-26 10:50:27.017257
# Unit test for function validate_yaml
def test_validate_yaml():
    # This is just a dummy test to check whether the test infrastructure works.
    assert validate_yaml([1, 2, 3], validator=[]) == ([1, 2, 3], [])
    assert validate_yaml(["test", "string"], validator=[]) == (["test", "string"], [])
    assert validate_yaml(["test", "string", {"test_key": "test_value"}], validator=[]) == (["test", "string", {"test_key": "test_value"}], [])
    assert validate_yaml(["test", "string", {"test_key": "test_value"}, [1, 2, 3]], validator=[]) == (["test", "string", {"test_key": "test_value"}, [1, 2, 3]], [])

# Generated at 2022-06-26 10:50:30.984703
# Unit test for function validate_yaml
def test_validate_yaml():
    # Input arguments
    str_content = 'test_schema' # type: str
    validator = 'test_validator' # type: typing.Union[Field, typing.Type[Schema]]

    # Return type test
    assert isinstance(validate_yaml(str_content, validator), tuple)


# Generated at 2022-06-26 10:50:39.758207
# Unit test for function validate_yaml
def test_validate_yaml():
    # Example 1
    try:
        str_0 = {"test_schema": {'type': 'integer'}}
    except Exception as inst:
        print(inst)
    except TypeError as inst:
        print(type(inst))
        print(inst.args)
        print(inst)
    except AttributeError as inst:
        print(type(inst))
        print(inst.args)
        print(inst)
    except KeyError as inst:
        print(type(inst))
        print(inst.args)
        print(inst)
    except IndexError as inst:
        print(type(inst))
        print(inst.args)
        print(inst)
    except NameError as inst:
        print(type(inst))
        print(inst.args)
        print(inst)

# Generated at 2022-06-26 10:50:50.641276
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'test_schema'
    str_1 = '[int]'
    str_2 = '1, 2'
    str_6 = '[int]'
    str_7 = '1, 2'
    str_8 = 'string'
    str_9 = '"string"'
    str_10 = 'number'
    str_11 = '1'
    str_12 = 'integer'
    str_13 = '1'
    str_14 = 'boolean'
    str_15 = 'yes'
    str_16 = 'null'
    str_17 = 'null'
    str_18 = 'object'
    str_19 = '{}'
    str_20 = 'array'
    str_21 = '[]'
    str_22 = 'oneOf'
    str_23 = '[string]'

# Generated at 2022-06-26 10:50:57.091321
# Unit test for function validate_yaml
def test_validate_yaml():

    print("Start test")

    # Test Cases
    
    # Case 0
    #
    # "Content" is an invalid schema
    
    content = 'test_schema'
    validator = File
    try:
        value, error = validate_yaml(content=content, validator=validator)
    except Exception as e:
        print(e)
        if str(e) == "No content.":
            pass
        else:
            print("Case 0 failed")
            print("Raised wrong exception")
            exit(3)


    print("Case 0 passed")

    # Case 1
    #
    # "Content" is a valid schema
    
    content = '''
    name: 
      first_name: John
      last_name: Smith
    '''.lstrip()
    validator = File
   

# Generated at 2022-06-26 10:51:08.429394
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = '''
        name: example
        age: 2
    '''
    str_2 = '''
        name: example
        age: 2
        too_many_fields: True
    '''
    str_3 = '''
        name: example
    '''
    str_4 = '1234'
    str_5 = '''
        name: example
        age: 2
        extra_field: True
    '''

    class ExampleSchema(Schema):
        name = {"type": "string"}
        age = {"type": "integer"}

    assert validate_yaml(str_1, ExampleSchema) == ({'name': 'example', 'age': 2}, [])

# Generated at 2022-06-26 10:51:12.017446
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(str_0) == tokenize_yaml(str_0)


# Generated at 2022-06-26 10:51:27.672279
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test case with normal input
    validator = Schema(field_a=Field(type="number"), field_b=Field(type="string"))

    str_0 = '''
    field_a: 1
    field_b: "foo"
    '''

    (result, errors) = validate_yaml(str_0, validator)
    assert result == {'field_a': 1, 'field_b': 'foo'}
    assert not errors

    # Test case with normal input
    validator = Schema(field_a=Field(type="integer"), field_b=Field(type="string"))

    str_1 = '''
    field_a: 1
    field_b: "foo"
    '''

    (result, errors) = validate_yaml(str_1, validator)

# Generated at 2022-06-26 10:51:39.121748
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema


    class TestSchema(Schema):
        title = String(max_length=50)
        score = Integer(minimum=0, maximum=100)

    validator = TestSchema()
    content_0 = "title: hello\nscore: '100'"
    validator_0 = TestSchema()
    content_1 = "title: hello\nscore: 100"
    validator_1 = TestSchema()
    content_2 = 'title: hello\nscore: "100"'
    validator_2 = TestSchema()

