

# Generated at 2022-06-26 10:41:59.317629
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_0 = '''
        name: Someone
        email: user@example.com
    '''
    validator_0 = Schema(
        {
            "name": Field(type="string"),
            "email": Field(type="string"),
        }
    )
    bytes_0 = yaml_0.encode()
    value_0, error_messages_0 = validate_yaml(
        bytes_0, validator_0
    )

# Generated at 2022-06-26 10:42:09.744128
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('foo: "bar"') == {'foo': 'bar'}
    assert tokenize_yaml(b'foo: "bar"') == {'foo': 'bar'}
    assert tokenize_yaml(1) == 1
    assert tokenize_yaml(1.0) == 1.0
    assert tokenize_yaml(True) is True
    assert tokenize_yaml([1, 2]) == [1, 2]
    assert tokenize_yaml({"foo": "bar"}) == {'foo': 'bar'}
    with pytest.raises(ParseError) as err:
        tokenize_yaml(None)
    assert err.value.code == "no_content"



# Generated at 2022-06-26 10:42:13.518030
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = None
    validator_0 = None
    value_0, error_messages_0 = validate_yaml(bytes_0, validator_0)


# Generated at 2022-06-26 10:42:21.995038
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = None
    validator_0 = None
    value_0, error_messages_0 = validate_yaml(bytes_0, validator_0)
    assert value_0 is None and len(error_messages_0) == 1

    bytes_0 = "foo"
    validator_0 = None
    value_0, error_messages_0 = validate_yaml(bytes_0, validator_0)
    assert value_0 is None and len(error_messages_0) == 1

    bytes_0 = "123"
    validator_0 = None
    value_0, error_messages_0 = validate_yaml(bytes_0, validator_0)
    assert value_0 is None and len(error_messages_0) == 1


# Generated at 2022-06-26 10:42:26.040787
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = None
    validator_0 = None
    value_0, error_messages_0 = validate_yaml(bytes_0, validator_0)


# Generated at 2022-06-26 10:42:27.595252
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(None)



# Generated at 2022-06-26 10:42:37.013420
# Unit test for function validate_yaml
def test_validate_yaml():
    # Normal case (example.com/validate_yaml)
    str_0 = 'a: {b: c}'
    schema_0 = Schema({'fields': {'a': {'fields': {'b': {'type': 'string'}}}}})
    assert validate_yaml(str_0, schema_0) == (
        {'a': {'b': 'c'}},
        [],
    )


# Generated at 2022-06-26 10:42:43.566705
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test case
    str_0 = """key: value
- a
- b
- c
"""
    dict_1 = {"key": "value", "0": "a", "1": "b", "2": "c"}
    bytes_0 = str_0.encode()
    token_0 = tokenize_yaml(bytes_0)
    # Test assertions
    assert token_0 == dict_1

    # Test case
    str_0 = """key: value
- a
- b
- c"""
    dict_1 = {"key": "value", "0": "a", "1": "b", "2": "c"}
    bytes_0 = str_0.encode()
    token_0 = tokenize_yaml(bytes_0)
    # Test assertions
    assert token_0 == dict_1



# Generated at 2022-06-26 10:42:55.613707
# Unit test for function tokenize_yaml
def test_tokenize_yaml():  # type: () -> None
    import yaml  # type: ignore

    class CustomSafeLoader(yaml.SafeLoader):
        pass

    def construct_mapping(loader, node):
        return DictToken(loader.construct_mapping(node), 0, 0)

    def construct_sequence(loader, node):
        return ListToken(loader.construct_sequence(node), 0, 0)

    def construct_scalar(loader, node):
        return ScalarToken(loader.construct_scalar(node), 0, 0)

    CustomSafeLoader.add_constructor(
        yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, construct_mapping
    )


# Generated at 2022-06-26 10:43:06.088563
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Test with a YAML string.
    data = {
        "name": "Jane",
        "age": 23,
        "friends": [
            {"name": "Alice", "age": 23},
            {"name": "Bob", "age": 25},
        ],
    }
    yaml_str = yaml.dump(data).strip()
    token = tokenize_yaml(yaml_str)
    assert token.value == data

    # Test with a YAML bytestring.
    yaml_bytes = yaml.dump(data).encode("utf-8")
    token = tokenize_yaml(yaml_bytes)
    assert token.value == data


# Generated at 2022-06-26 10:43:17.780170
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test for expected value exceptions
    try:
        validate_yaml(1, Field(name="hi"))
    except Exception:
        pass

    # Test for expected value exceptions
    try:
        validate_yaml(1, Field(name="hi"))
    except Exception:
        pass

    # Test for expected value exceptions
    try:
        validate_yaml(1, Field(name="hi"))
    except Exception:
        pass

    # Test for expected value exceptions
    try:
        validate_yaml(1, Field(name="hi"))
    except Exception:
        pass

    # Test for expected value exceptions
    try:
        validate_yaml(1, Field(name="hi"))
    except Exception:
        pass

# Generated at 2022-06-26 10:43:29.174277
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = None
    bytes_0 = None
    token_0 = tokenize_yaml(bytes_0)
    str_1 = "test"
    bytes_1 = None
    token_1 = tokenize_yaml(bytes_1)
    str_2 = "test"
    bytes_2 = None
    token_2 = tokenize_yaml(bytes_2)
    str_3 = "test"
    bytes_3 = None
    token_3 = tokenize_yaml(bytes_3)
    str_4 = "test"
    bytes_4 = None
    token_4 = tokenize_yaml(bytes_4)
    str_5 = "test"
    bytes_5 = None
    token_5 = tokenize_yaml(bytes_5)
    str_6 = "test"


# Generated at 2022-06-26 10:43:32.949233
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert tokenize_yaml("") == None


# Generated at 2022-06-26 10:43:43.285405
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Line and column numbers are zero-based.
    start = Position(line_no=0, column_no=0, char_index=0)
    end = Position(line_no=0, column_no=4, char_index=4)

    field = Field(type="string")
    token = ScalarToken("value", start, end)
    value = field.validate(token)
    assert value == "value"

    # Test with a schema.
    schema = Schema(properties={"name": Field(type="string")})
    token = DictToken({"name": "value"}, start, end)
    value, error_messages = validate_yaml("", schema)
    assert value == {}

# Generated at 2022-06-26 10:43:44.071502
# Unit test for function validate_yaml
def test_validate_yaml():
    pass

# Generated at 2022-06-26 10:43:56.094988
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    bytes_0 = b''
    try:
        token_0 = tokenize_yaml(bytes_0)
    except ParseError as exc:
        text_0 = exc.text
        code_0 = exc.code
        position_0 = exc.position
        assert text_0 == "No content."
        assert code_0 == "no_content"
        assert position_0.column_no == 1
        assert position_0.line_no == 1
        assert position_0.char_index == 0
    else:
        raise AssertionError("No exception raised")
    bytes_1 = b'1'
    token_1 = tokenize_yaml(bytes_1)
    assert token_1.before == 0
    assert token_1.after == 1
    assert token_1.content == "1"

# Generated at 2022-06-26 10:43:58.622908
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('') == None



# Generated at 2022-06-26 10:44:09.382112
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test case 1
    bytes_1 = "this is not yaml"
    type_1 = str
    result_1 = validate_yaml(bytes_1, type_1)
    assert type(result_1) is tuple
    assert type(result_1[0]) is bool
    assert type(result_1[1]) is list
    assert result_1[0] is False
    assert result_1[1][0].position.line_no == 1
    assert result_1[1][0].position.column_no == 1
    assert result_1[1][0].position.char_index == 0
    assert result_1[1][0].code == "parse_error"
    assert result_1[1][0].text == "could not find expected ':'"

    # Test case 2

# Generated at 2022-06-26 10:44:12.934684
# Unit test for function validate_yaml
def test_validate_yaml():
    content = None
    validator = None
    (value, error_messages) = validate_yaml(content, validator)


# Generated at 2022-06-26 10:44:16.516259
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    bytes_0 = b"\x00\x01\x02\x03\x04\x05\x06\x07"
    token_0 = tokenize_yaml(bytes_0)


# Generated at 2022-06-26 10:44:25.682296
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = ''
    position_0 = Position(column_no=1, line_no=1, char_index=0)
    text_0 = 'No content.'
    code_0 = 'no_content'
    exc_info_0 = None
    try:
        tokenize_yaml(str_0)
    except ParseError as exc_info_0:  
        pass
    
    assert exc_info_0.text == text_0
    assert exc_info_0.position == position_0
    assert exc_info_0.code == code_0

    str_1 = '\t\t'
    position_1 = Position(column_no=3, line_no=1, char_index=2)
    text_1 = 'Expected YAML, but found: <EOF>'


# Generated at 2022-06-26 10:44:27.707128
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '-Y\t'
    token_0 = tokenize_yaml(str_0)


# Generated at 2022-06-26 10:44:35.676631
# Unit test for function validate_yaml
def test_validate_yaml():

    str_0 = '-Y\t'
    str_1 = '-Y\n'
    str_2 = '-Y\r'
    str_3 = '-Y '
    str_4 = '-Y-'
    str_5 = '---'
    str_6 = '---\n'
    str_7 = '---\r'
    str_8 = '---\t'
    str_9 = '----'
    str_10 = '-Y'
    str_11 = '---\n---\n---\n'
    str_12 = '---\n---\n---'
    str_13 = '---\n---\n'
    str_14 = '---\n---'

# Generated at 2022-06-26 10:44:41.286375
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '-Y\t'
    token_0 = tokenize_yaml(str_0)
    str_1 = '-Y\t'
    token_1 = tokenize_yaml(str_1)
    str_2 = '-Y\t'
    token_2 = tokenize_yaml(str_2)
    str_3 = '-Y\t'
    token_3 = tokenize_yaml(str_3)



# Generated at 2022-06-26 10:44:48.936827
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test with a scalar value
    str_0 = '"Hello"'
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, ScalarToken)
    assert token_0.start == 0
    assert token_0.stop == 7
    assert token_0.content == str_0

    # Test with a list value
    str_1 = '- 1\n- 2\n- 3'
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, ListToken)
    assert token_1.start == 0
    assert token_1.stop == 13
    assert token_1.content == str_1

    # Test with a dictionary value
    str_2 = 'a: 1\nb: 2'
    token_2 = tokenize_

# Generated at 2022-06-26 10:44:59.549047
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '-Y\t'
    str_1 = '-Y\t'
    str_2 = '[]'
    token_0 = tokenize_yaml(str_0)
    token_1 = tokenize_yaml(str_1)
    token_2 = tokenize_yaml(str_2)
    value, errors = validate_with_positions(token_0, None)
    value, errors = validate_with_positions(token_1, token_2)

# Generated at 2022-06-26 10:45:10.494487
# Unit test for function validate_yaml
def test_validate_yaml():
    content_str = "name: Adam\n"
    content_bytes = content_str.encode("utf-8")
    field_0 = Field("name", description="A name.")
    assert validate_yaml(content_str, field_0) == ("Adam", [])
    assert validate_yaml(content_bytes, field_0) == ("Adam", [])

    validate_yaml("{}", field_0)
    validate_yaml("[]", Field("name", description="A name.", required=True))

    field_1 = Field("age", description="An age.", required=True)
    field_2 = Field("name", description="A name.", required=True)
    validate_yaml("{name: Adam}", field_1)
    validate_yaml("{name: Adam}", field_2)
    validate

# Generated at 2022-06-26 10:45:21.941992
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '"string"'
    token_0 = tokenize_yaml(str_0)
    assert token_0.value == "string"
    assert token_0.start_index == 0
    assert token_0.end_index == 7
    assert token_0.type == ScalarToken

    str_1 = '"string1\nstring2"'
    token_1 = tokenize_yaml(str_1)
    assert token_1.value == "string1\nstring2"
    assert token_1.start_index == 0
    assert token_1.end_index == 15
    assert token_1.type == ScalarToken


# Generated at 2022-06-26 10:45:26.051097
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Field(type="string")
    content = '"hello"'
    value, errors = validate_yaml(content, schema)
    assert value == "hello"
    assert not errors

# Generated at 2022-06-26 10:45:31.136344
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token_0 = tokenize_yaml('-Y   ')
    assert isinstance(token_0, ListToken)
    assert isinstance(str(token_0), str)
    assert token_0.end == 4
    assert token_0.start == 0
    assert token_0.value[0] == 'Y'
    assert isinstance(token_0.value, list)


# Generated at 2022-06-26 10:45:49.457438
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String

    class Book(Schema):
        title = String(min_length=10, max_length=50)
        isbn = Integer(minimum=1)

    # Scenarios for ParseError
    content = '"title": "The Go Programming Language", "isbn": 01345806594'
    result = validate_yaml(content, Book)
    assert result.value == {'title': 'The Go Programming Language', 'isbn': 1345806594}

# Generated at 2022-06-26 10:46:01.695262
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None
    str_0 = '-Y\t'
    try:
        token_0 = tokenize_yaml(str_0)
        assert False
    except ParseError:
        pass
    str_0 = '-Y\n\t'
    try:
        token_0 = tokenize_yaml(str_0)
        assert False
    except ParseError:
        pass
    str_0 = '-Y\n\n'
    try:
        token_0 = tokenize_yaml(str_0)
        assert False
    except ParseError:
        pass
    str_0 = '-Y\n\n\t'
    try:
        token_0 = tokenize_yaml(str_0)
        assert False
    except ParseError:
        pass

# Generated at 2022-06-26 10:46:13.798048
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'Y'
    str_1 = '"'
    str_2 = '"Y"'
    str_3 = 'Y\n'
    str_4 = 'Y\t'
    str_5 = 'Y\t\n'
    str_6 = 'Y\t\n  '
    str_7 = 'Y\t\n  \t'
    str_8 = 'Y\t\n  \t\n'
    str_9 = 'Y\t\n  \t\nY'
    str_10 = 'Y\t\n  \t\nY\n'
    str_11 = 'Y\t\n  \t\nY\n  '
    str_12 = 'Y\t\n  \t\nY\n  \t'
    str_

# Generated at 2022-06-26 10:46:24.296618
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '-Y\t'
    str_1 = b'-Y\t'
    validators_0 = [Field(type="integer"),Field(type="string")]
    validators_1 = [Field(type="float"),Field(type="string")]
    validators_2 = [Field(type="boolean"),Field(type="string")]
    validators_3 = [Field(type="integer"),Field(type="string")]
    validators_4 = [Field(type="float"),Field(type="string")]
    validators_5 = [Field(type="boolean"),Field(type="string")]
    validators_6 = [Field(type="integer"),Field(type="string")]
    validators_7 = [Field(type="float"),Field(type="string")]
    validators_8

# Generated at 2022-06-26 10:46:35.128327
# Unit test for function validate_yaml
def test_validate_yaml():
    # A yaml schema to use as a validator.
    yaml_schema_0 = {
        'type': 'object',
        'additionalProperties': True,
        'properties': {
            'foo': {
                'type': 'string',
            },
            'bar': {
                'type': 'integer',
            },
            'baz': {
                'type': 'array',
                'items': {
                    'type': 'number',
                },
            },
        },
        'required': [
            'foo',
        ],
    }

    value, errors = validate_yaml(content='{"bar": 2, "baz": [0]}', validator=yaml_schema_0)

    assert errors[0].code == 'required'

# Generated at 2022-06-26 10:46:45.666842
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '-Y\t'
    token_0 = tokenize_yaml(str_0)
    assert type(token_0) == yaml.constructor.SafeConstructorError
    assert token_0.problem == "found unexpected '\\t' while scanning a single quoted scalar"
    assert token_0.problem_mark.line == 0
    assert token_0.problem_mark.column == 3
    assert token_0.problem_mark.buffer == str_0
    str_1 = '-Y\t'
    token_1 = tokenize_yaml(str_1)
    assert type(token_1) == yaml.constructor.SafeConstructorError
    assert token_1.problem == "found unexpected '\\t' while scanning a single quoted scalar"
    assert token_1.problem_mark.line

# Generated at 2022-06-26 10:46:55.976417
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('') == None
    assert tokenize_yaml('Y') == ScalarToken('Y', 0, 0)
    assert tokenize_yaml('[Y]') == ListToken(['Y'], 0, 2)
    assert tokenize_yaml('{Y:Y}') == DictToken({'Y': 'Y'}, 0, 4)
    assert tokenize_yaml('Y\n') == ScalarToken('Y\n', 0, 1)
    assert tokenize_yaml('\n') == ScalarToken('\n', 0, 0)
    assert tokenize_yaml('Y\nY') == ScalarToken('Y\nY', 0, 3)

# Generated at 2022-06-26 10:46:57.709489
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True, 'A test for validate_yaml'
    pass

# Generated at 2022-06-26 10:47:08.758222
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    try:
        from .fixtures import (
            YAML,
            VALIDATOR,
            INVALID_VALUE,
            INVALID_VALUE_ERROR_CODE,
            INVALID_VALUE_ERROR_TEXT,
            INVALID_VALUE_ERROR_POSITION,
        )
    except ImportError:
        return

    value, messages = validate_yaml(YAML, VALIDATOR)

    assert value is not None
    assert messages is None

    value, messages = validate_yaml(INVALID_VALUE, VALIDATOR)

    assert value is None
    assert messages is not None
    assert len(messages) == 1
    assert messages[0].code == INVALID_VALUE_ERROR_CODE

# Generated at 2022-06-26 10:47:20.495340
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = """
    {
      "title": "Example Schema",
      "type": "object",
      "properties": {
        "firstName": {
          "type": "string"
        },
        "lastName": {
          "type": "string"
        },
        "age": {
          "description": "Age in years",
          "type": "integer",
          "minimum": 0
        }
      },
      "required": ["firstName", "lastName"]
    }
    """
    validator_0 = Field(schema={"type": "integer"}, required=True)
    value_0, error_messages_0 = validate_yaml(str_0, validator_0)
    # test if validate_yaml is throwing correct error

# Generated at 2022-06-26 10:47:29.696702
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '-Y\t'
    validator_1 = Field(name='', validators=[])
    field_2 = validator_1
    str_3, error_messages_4 = validate_yaml(str_0, field_2)



# Generated at 2022-06-26 10:47:41.008066
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = 'a: 1'
    str_1 = 'a: \'1\''
    str_2 = 'a: "1"'
    str_3 = 'a: null'
    str_4 = 'a: false'
    str_5 = 'a: true'
    str_6 = 'a: []'
    str_7 = 'a: [1, 2, 3]'
    str_8 = 'a: [1, 2, 3]'
    str_9 = 'a: []'
    str_10 = 'a: [1, 2, 3]'
    str_11 = 'a: [1, 2, 3]'
    str_12 = 'a: {}'
    str_13 = 'a: {a: 1, b: 2}'

# Generated at 2022-06-26 10:47:42.718985
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '-Y\t'
    token_0 = tokenize_yaml(str_0)



# Generated at 2022-06-26 10:47:54.552367
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '-Y\t'
    token_0 = tokenize_yaml(str_0)
    validator_0 = ScalarToken
    (value_0, error_messages_0) = validate_yaml(str_0, validator_0)
    assert value_0 == None
    str_1 = ''
    token_1 = tokenize_yaml(str_1)
    validator_1 = ScalarToken
    (value_1, error_messages_1) = validate_yaml(str_1, validator_1)
    assert value_1 == None
    str_2 = '-Y\t'
    token_2 = tokenize_yaml(str_2)
    validator_2 = Int
    (value_2, error_messages_2) = validate_yaml

# Generated at 2022-06-26 10:48:04.677252
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    if isinstance(content, bytes):
        str_content = content.decode("utf-8", "ignore")
    else:
        str_content = content

    if not str_content.strip():
        # Handle the empty string case explicitly for clear error messaging.
        position = Position(column_no=1, line_no=1, char_index=0)
        raise ParseError(text="No content.", code="no_content", position=position)

    class CustomSafeLoader(SafeLoader):
        pass

    def construct_mapping(loader, node):
        start = node.start_mark.index
        end = node.end_mark.index
        mapping = loader.construct_mapping(node)

# Generated at 2022-06-26 10:48:10.199618
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(type="string")
    value, errors = validate_yaml("foo", field)
    assert value == "foo"
    assert errors == []

    value, errors = validate_yaml(12, field)
    assert value == 12
    assert errors[0].position.char_index == 0
    assert errors[0].code == "type_error"



# Generated at 2022-06-26 10:48:23.194497
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '---a\n'
    validator_0 = DictToken({'a': ListToken([])}, 0, 3, content=str_0)
    try:
        val_1, err_1 = validate_yaml(str_0, validator_0)
    except ValidationError as exc_1:
        err_1 = exc_1.messages

    str_1 = '---\n'
    validator_1 = DictToken({}, 0, 2, content=str_1)
    try:
        val_2, err_2 = validate_yaml(str_1, validator_1)
    except ValidationError as exc_2:
        err_2 = exc_2.messages

    str_2 = '---\n-a'

# Generated at 2022-06-26 10:48:33.404549
# Unit test for function validate_yaml
def test_validate_yaml():
    class Song(Schema):
        title = Field(str)
        length = Field(int)

    class Album(Schema):
        title = Field(str)
        songs = Field(types=[Song])

    album_data = {
        "title": "Fertility",
        "songs": [
            {"title": "Red", "length": "short"},
            {"title": "Blue", "length": "long"},
        ],
    }
    yaml_str = yaml.dump(album_data)
    yaml_str = yaml_str.replace("-", "- ")
    data, errors = validate_yaml(yaml_str, validator=Album)

    assert errors[0].position.line_no == 4
    assert errors[0].position.column_no == 4
    assert errors[0].position

# Generated at 2022-06-26 10:48:44.811746
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '-Y\t'
    token_0 = tokenize_yaml(str_0)
    assert token_0.start_position == 0
    assert token_0.end_position == 2
    assert token_0.value == ["Y"]
    str_1 = '-Y\t1'
    token_1 = tokenize_yaml(str_1)
    assert token_1.start_position == 0
    assert token_1.end_position == 4
    assert token_1.value == ["Y"]
    str_2 = 'A\t'
    token_2 = tokenize_yaml(str_2)
    assert token_2.start_position == 0
    assert token_2.end_position == 2
    assert token_2.value == "A"

# Generated at 2022-06-26 10:48:56.055702
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:49:14.472453
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '-Y\t'
    token = tokenize_yaml(content)
    token_len = len(token.value)
    assert token_len == 1, "'token_len' should be '1'"
    token_0 = token.value[0]
    assert token_0.content is not None, "'token_0.content' should not be 'None'"
    assert token_0.end == 0, "'token_0.end' should be '0'"
    assert token_0.start == 0, "'token_0.start' should be '0'"
    token_0_value = token_0.value
    assert token_0_value == '-Y\t', "'token_0_value' should be '-Y\\t'"


# Generated at 2022-06-26 10:49:25.006282
# Unit test for function validate_yaml
def test_validate_yaml():
    def test_case_0():
        content = '[{"name": "Jim", "age": 31}, {"name": "John"}]'
        validator = typing.cast(Schema, typing.Type[Schema])(
            {
                "items": {
                    "properties": {
                        "name": {"type": "string", "format": "full-name"},
                        "age": {"type": "integer", "minimum": 0, "maximum": 150},
                    },
                    "required": ["name"],
                }
            }
        )
        result = validate_yaml(content, validator)

# Generated at 2022-06-26 10:49:32.813109
# Unit test for function validate_yaml
def test_validate_yaml():
    
    assert callable(validate_yaml)
    assert isinstance(validate_yaml("test", int), tuple)
    assert isinstance(validate_yaml("test", int)[0], int)
    assert isinstance(validate_yaml("test", int)[1], list)
    assert isinstance(validate_yaml("test", int)[1][0], Message)

# Generated at 2022-06-26 10:49:36.092317
# Unit test for function validate_yaml
def test_validate_yaml():
    with pytest.raises(ParseError):
        validate_yaml('-Y\t', 'hello')



# Generated at 2022-06-26 10:49:44.090603
# Unit test for function validate_yaml
def test_validate_yaml():
    class Sample(Schema):
        text = Field(type="string")
        number = Field(type="integer")
    data = {'text':'The quick brown fox jumped over the lazy dog', 'number':123}
    data_text = 'text: The quick brown fox jumped over the lazy dog\nnumber: 123'
    value, error_messages = validate_yaml(data_text, Sample)
    assert value == data
    assert error_messages == None

# Generated at 2022-06-26 10:49:57.363184
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b'{"name": "Foo"}'
    validator = Schema
    value, errors = validate_yaml(content, validator)
    assert value == {'name': 'Foo'}
    assert errors == []
    content = b'{"name": "Foo", "age": "bar"}'
    validator = Schema
    value, errors = validate_yaml(content, validator)
    assert value == {'name': 'Foo', 'age': 'bar'}
    assert errors == []
    content = b'{"name": "Foo", "age": "bar"}'
    validator = Schema
    value, errors = validate_yaml(content, validator)
    assert value == {'name': 'Foo', 'age': 'bar'}
    assert errors == []
    content = b

# Generated at 2022-06-26 10:50:03.614227
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        str_0 = '-Y\t'
        assert validate_yaml(str_0,validator) == ('', ['ValidationError at l1, c4'])
    except Exception as e:
        print(str(e))


# Generated at 2022-06-26 10:50:16.671136
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    content = '- Y'
    actual = tokenize_yaml(content)
    expected = ListToken(
        [ScalarToken("Y", 1, 2, content=content)], position=0, end_position=2, content=content
    )
    assert actual == expected

    assert yaml is not None, "'pyyaml' must be installed."

    content = "- Y"
    actual = tokenize_yaml(content)
    expected = ListToken(
        [ScalarToken("Y", 1, 2, content=content)], position=0, end_position=2, content=content
    )
    assert actual == expected

    assert yaml is not None, "'pyyaml' must be installed."

    content = "-Y"

# Generated at 2022-06-26 10:50:27.276208
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import String
    from typesystem.tokenize.tests.test_recursive import RecursiveSchema

    field = String(required=True)
    schema = RecursiveSchema.of(field)

    str_0 = '---\n- value: "this is a test"\n'
    try:
        value_0, error_messages_0 = validate_yaml(str_0, schema)
    except ValidationError as e:
        e.to_json()

    str_1 = '---\n- value: this is a test\n'
    try:
        value_1, error_messages_1 = validate_yaml(str_1, schema)
    except ValidationError as e:
        e.to_json()


# Generated at 2022-06-26 10:50:30.573150
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml('{a: 1}'), DictToken)
    assert isinstance(tokenize_yaml("[1, 2]"), ListToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)


# Generated at 2022-06-26 10:50:39.227497
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(str) == ListToken([], 0, -1, content='str')



# Generated at 2022-06-26 10:50:50.326584
# Unit test for function validate_yaml
def test_validate_yaml():
    value_0, error_0 = validate_yaml("-", "")
    value_1, error_1 = validate_yaml("+@!^", "")
    value_2, error_2 = validate_yaml("-Jt]X", "")
    value_3, error_3 = validate_yaml("-", "")
    value_4, error_4 = validate_yaml("-", "")
    value_5, error_5 = validate_yaml("-", "")
    value_6, error_6 = validate_yaml("-", "")
    value_7, error_7 = validate_yaml("-", "")
    value_8, error_8 = validate_yaml("3.4", "")
    value_9, error_9 = validate_yaml("", "")
   

# Generated at 2022-06-26 10:50:57.012104
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '-Y\t'
    field_1 = Field('test')
    result_0 = validate_yaml(str_0, field_1)
    assert result_0 == (['Y'], [])
    str_1 = '---\n-Y\t'
    result_1 = validate_yaml(str_1, field_1)
    assert result_1 == (['Y'], [])
    str_2 = '---\n-Y\t\n'
    result_2 = validate_yaml(str_2, field_1)
    assert result_2 == (['Y'], [])
    str_3 = '---\n-Y\t\n '
    result_3 = validate_yaml(str_3, field_1)

# Generated at 2022-06-26 10:51:00.002122
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '-Y\t'
    assert tokenize_yaml(str_0)


# Generated at 2022-06-26 10:51:09.398396
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Bytes literal test
    str_0 = b'Y'
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, ScalarToken)
    assert token_0.value == True
    assert token_0.start == 0
    assert token_0.end == 0
    assert token_0.content == "Y"
    assert token_0.position == Position(
        line_no=1, column_no=1, char_index=0
    )

    # Unicode literal test
    str_0 = 'Y'
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, ScalarToken)
    assert token_0.value == True
    assert token_0.start == 0
    assert token_0.end == 0

# Generated at 2022-06-26 10:51:18.702012
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test the failure case
    try:
        tokenize_yaml('')
    except ParseError as e:
        assert e.position.column_no == 1
        assert e.position.line_no == 1
        assert e.position.char_index == 0
        assert e.text == 'No content.'
        assert e.code == 'no_content'
    except:
        assert False
    else:
        assert False

    # Test a case where a token is not expected
    try:
        tokenize_yaml('scalar')
    except ParseError as e:
        assert e.position.column_no == 1
        assert e.position.line_no == 1
        assert e.position.char_index == 0
        assert e.text == 'Got top-level scalar.'

# Generated at 2022-06-26 10:51:20.211895
# Unit test for function validate_yaml
def test_validate_yaml():
    raise NotImplementedError



# Generated at 2022-06-26 10:51:23.615113
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '-Y\t'
    token_0 = tokenize_yaml(str_0)



# Generated at 2022-06-26 10:51:26.701556
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '-Y\t'
    token_0 = tokenize_yaml(str_0)


# Generated at 2022-06-26 10:51:38.627462
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "merge: false"
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, DictToken)
    assert isinstance(token_0[0], ScalarToken)
    assert token_0[0].value == "false"
    assert token_0[0].start == 9
    assert token_0[0].end == 14
    assert token_0[0].content == str_0
    assert token_0.start == 0
    assert token_0.end == 14
    assert token_0.content == str_0

    str_1 = "merge: false"
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, DictToken)
    assert isinstance(token_1[0], ScalarToken)