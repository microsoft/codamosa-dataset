

# Generated at 2022-06-26 10:42:06.923321
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test case 0.
    bytes_0 = None
    token_0 = tokenize_yaml(bytes_0)
    assert token_0 is not None
    # Test case 1.
    bytes_1 = b""
    token_1 = tokenize_yaml(bytes_1)
    assert token_1 is not None
    # Test case 2.
    bytes_2 = b'{"foo": "bar"}'
    token_2 = tokenize_yaml(bytes_2)
    assert token_2 is not None
    # Test case 3.
    bytes_3 = b'[{"foo": "bar"}, {"foo": "baz"}]'
    token_3 = tokenize_yaml(bytes_3)
    assert token_3 is not None
    # Test case 4.
    bytes_4 = b"3.14"

# Generated at 2022-06-26 10:42:19.573748
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    def check_against_validator(
        content: typing.Union[str, bytes],
        validator: typing.Union[Field, typing.Type[Schema]],
        expected_is_valid: bool,
        expected_value: typing.Any,
    ):
        """
        Parse and validate a YAML string, returning positionally marked error
        messages on parse or validation failures.

        content - A YAML string or bytestring.
        validator - A Field instance or Schema class to validate against.

        Returns a two-tuple of (value, error_messages)
        """
        assert yaml is not None, "'pyyaml' must be installed."

        token = tokenize_yaml(content)
        value, error_messages = validate_with_positions(token=token, validator=validator)


# Generated at 2022-06-26 10:42:32.056698
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None
    assert tokenize_yaml("foo\n") == None
    assert tokenize_yaml("foo\nbar") == None
    assert tokenize_yaml("foo: bar") == None
    assert tokenize_yaml("foo: false\nbar: true") == None
    assert tokenize_yaml("foo: \n bar: \n ") == None
    assert tokenize_yaml("foo:\n bar:\n ") == None
    assert tokenize_yaml("foo:\n bar:\n") == None
    assert tokenize_yaml("foo: -\n bar: -\n") == None
    assert tokenize_yaml("foo: -\n bar: -\n") == None

# Generated at 2022-06-26 10:42:42.121321
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from collections import OrderedDict

    content_0 = b''
    value_0, errors_0 = validate_yaml(content_0, Field())
    assert value_0 is None
    assert len(errors_0) == 1
    assert errors_0[0].code == 'no_content'
    assert errors_0[0].message == 'No content.'
    assert errors_0[0].path == []
    assert errors_0[0].position.line_no == 1
    assert errors_0[0].position.column_no == 1
    assert errors_0[0].position.char_index == 0

    content_1 = b'1'
    value_1, errors_1 = validate_yaml(content_1, Field())
    assert value_1 == 1
    assert len(errors_1) == 0

   

# Generated at 2022-06-26 10:42:49.364795
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        str_0 = "---"
        token_0 = tokenize_yaml(str_0)
    except ParseError as exc_0:  # type: ignore
        msg_0 = exc_0.messages
    else:  # pragma: no cover
        msg_0 = None



# Generated at 2022-06-26 10:42:57.066847
# Unit test for function validate_yaml
def test_validate_yaml():
    content_0 = "test"
    validator_0 = float
    value, error_messages = validate_yaml(content_0, validator_0)
    assert value == 0.0
    assert error_messages == [
        Message(
            code="invalid_type",
            text="Expected type 'float' but got type 'str'.",
            position=Position(char_index=0, column_no=1, line_no=1),
        )
    ]

    content_1 = "test"
    validator_1 = float
    try:
        value, error_messages = validate_yaml(content_1, validator_1)
    except Exception as e:
        assert type(e) == ValueError

    content_2 = ""
    validator_2 = float

# Generated at 2022-06-26 10:42:59.108881
# Unit test for function validate_yaml
def test_validate_yaml():
    token_0 = validate_yaml("- 'hello'", None)


# Generated at 2022-06-26 10:43:07.618253
# Unit test for function validate_yaml
def test_validate_yaml():
    # Check that a Validator instance is instantiated.
    schema = Schema()
    assert isinstance(schema, Schema)

    # Empty YAML input
    content_0 = b''
    validator_0 = Float()
    result_0 = validate_yaml(content_0, validator_0)
    assert isinstance(result_0, tuple)
    assert len(result_0) == 2
    value_0, messages_0 = result_0
    assert value_0 is None
    assert len(messages_0) == 1
    assert isinstance(messages_0, list)
    assert isinstance(messages_0[0], Message)
    assert messages_0[0].text == 'No content.'
    assert messages_0[0].code == 'no_content'

# Generated at 2022-06-26 10:43:11.735833
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Ensure that the function runs without error.
    assert yaml is not None
    test_case_0()


# Generated at 2022-06-26 10:43:18.934789
# Unit test for function validate_yaml
def test_validate_yaml():
    value_0, errs_0 = validate_yaml(
        "foo",
        Schema,
        validator=lambda d: DictToken(d, 0, 3, content="foo"),
    )
    assert value_0 == {"": ""}
    assert errs_0 == [
        ValidationError(
            message=Message(
                text="Must be a dict.",
                code="invalid_type",
                position=Position(line_no=1, column_no=1, char_index=0),
            )
        )
    ]

    value_1, errs_1 = validate_yaml(
        "foo",
        Schema,
        validator=lambda d: ListToken(d, 0, 3, content="foo"),
    )
    assert value_1 == []

# Generated at 2022-06-26 10:43:38.252807
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert_equals(tokenize_yaml("{}"), tokenize_yaml("{}"))
    assert_equals(tokenize_yaml("{}"), tokenize_yaml("{}"))
    assert_equals(tokenize_yaml("{}"), tokenize_yaml("{}"))
    assert_equals(tokenize_yaml("{}"), tokenize_yaml("{}"))
    assert_equals(tokenize_yaml("{}"), tokenize_yaml("{}"))
    assert_equals(tokenize_yaml("{}"), tokenize_yaml("{}"))


# Generated at 2022-06-26 10:43:46.185990
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_string = """
    list:
        - item1
        - item2
        - item3
    """
    field = Field(type="string")
    validator = Schema(fields={"list": Field(type="list", items=field)})
    value, error_messages = validate_yaml(yaml_string, validator=validator)
    assert not error_messages
    assert value == {"list": ["item1", "item2", "item3"]}

# Generated at 2022-06-26 10:43:48.833379
# Unit test for function validate_yaml
def test_validate_yaml():
    validate_yaml(content=None, validator=None, expected_value=None, expected_error=None)


# Generated at 2022-06-26 10:43:58.895426
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test parsing valid content.
    content = '{"foo": "bar"}'
    schema = {"foo": str}

    value, errors = validate_yaml(content, schema)
    assert value == {"foo": "bar"}
    assert errors == []

    # Test parsing invalid content.
    content = "invalid"
    schema = {"foo": str}

    with pytest.raises(ParseError):
        validate_yaml(content, schema)

    # Test validating content with validation errors.
    content = '{"foo": "bar"}'
    schema = {"foo": int}

    value, errors = validate_yaml(content, schema)
    assert value is None
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)

# Generated at 2022-06-26 10:44:11.164439
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "name: a-/name"
    validator_0 = Field(name="name", type="string", pattern="^[A-Za-z0-9-_]+$")
    token_0 = tokenize_yaml(str_0)
    result_0 = validate_with_positions(token=token_0, validator=validator_0)
    assert result_0 == ({'name': 'a-/name'},
                        [ValidationError(text="pattern does not match.", code='invalid_pattern', position=Position(column_no=6, char_index=1, line_no=1))])

    str_1 = "& 'hello'"
    validator_1 = Field(name="name", type="string")
    token_1 = tokenize_yaml(str_1)
   

# Generated at 2022-06-26 10:44:16.279142
# Unit test for function validate_yaml
def test_validate_yaml():
    schema_0 = Schema('', {'name': 'string'})
    value_0 = '{"name":"test"}'
    result_0 = validate_yaml(value_0, schema_0)
    assert result_0[0] == {'name': 'test'}

# Generated at 2022-06-26 10:44:20.386313
# Unit test for function validate_yaml
def test_validate_yaml():
    # str_1 = "& 'hello'"
    # val = validate_yaml(str_1)
    # assert val is None
    pass

# Generated at 2022-06-26 10:44:25.185473
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem.schemas

    class Book(typesystem.schemas.Schema):
        title = typesystem.String(max_length=100)
        published = typesystem.Integer()

    yaml_content = """
    title: '1984'
    published: 1949
    """

    try:
        validate_yaml(yaml_content, Book)
    except ValidationError as exc:
        assert str(exc) == "{\n    'published': 'Must be greater than or equal to 1980.',\n    'title': 'Must be at most 20 characters.'\n}"



# Generated at 2022-06-26 10:44:30.689963
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String
    from typesystem.schemas import Schema

    class Person(Schema):
        class Meta:
            nullable = True

        name = String()
        age = Integer()

    content = """
  name: "John"
  age: 30
"""

    person, errors = validate_yaml(content, validator=Person)

    assert errors == []
    assert isinstance(person, Person)
    assert person.name == "John"
    assert person.age == 30



# Generated at 2022-06-26 10:44:41.677511
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, Integer, String, Boolean, Float

    class A(Schema):
        s = String(max_length=3)
        i = Integer()
        f = Float()
        b = Boolean()

    str_0 = "s: 'hello', i: 1, f: 3.14, b: false"
    assert validate_yaml(str_0, A) == ({"s": "hel", "i": 1, "f": 3.14, "b": False}, [])

    str_1 = "s: 'hello', i: 1, f: 3.14, b: false"
    result, errors = validate_yaml(str_1, A)
    assert result == {"s": "hel", "i": 1, "f": 3.14, "b": False}

# Generated at 2022-06-26 10:44:46.398199
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_ = "& 'hello'"
    token = tokenize_yaml(str_)
    assert token


# Generated at 2022-06-26 10:44:49.116001
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "& 'hello'"
    token_0 = tokenize_yaml(str_0)
    assert int(token_0.start_offset) == 0
    assert int(token_0.end_offset) == 2
    assert token_0.content == "& 'hello'"


# Generated at 2022-06-26 10:44:50.009649
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True

# Generated at 2022-06-26 10:44:59.387956
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "& 'hello'"
    token_0 = tokenize_yaml(str_0)
    field_0 = token_0._yaml["document"]
    text_0 = field_0.start_mark.line
    str_1 = "1.20"
    token_1 = tokenize_yaml(str_1)
    field_1 = token_1._yaml["document"].end_mark.index

# Generated at 2022-06-26 10:45:10.408451
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = Field(str)
    schema = MySchema()

    # test yaml with valid data
    expected_value = {'name': 'foo'}
    str_0 = "name: foo"
    value, errors = validate_yaml(str_0, schema)
    assert value == expected_value
    assert errors is None

    # test yaml with no valid data
    expected_errors = [Message.error(
        text='Expected a string.', code='type', position=Position(
            line_no=1, column_no=2, char_index=1)
        )
    ]
    str_0 = "name: 42"
    value, errors = validate_yaml(str_0, schema)
    assert value is None
    assert errors == expected_errors

   

# Generated at 2022-06-26 10:45:23.107672
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import yaml
    from yaml.loader import SafeLoader

    assert yaml is not None
    assert SafeLoader is not None

    class CustomSafeLoader(SafeLoader):
        pass

    def construct_mapping(loader, node):
        start = node.start_mark.index
        end = node.end_mark.index
        mapping = loader.construct_mapping(node)
        return DictToken(mapping, start, end - 1, content="& 'hello'")

    def construct_sequence(loader, node):
        start = node.start_mark.index
        end = node.end_mark.index
        value = loader.construct_sequence(node)
        return ListToken(value, start, end - 1, content="& 'hello'")

    def construct_scalar(loader, node):
        start = node.start

# Generated at 2022-06-26 10:45:28.145078
# Unit test for function validate_yaml
def test_validate_yaml():

    # Setup
    string = "string"
    validator = Field(type="string")
    expected = (string, [])

    # Execute
    actual = validate_yaml(string, validator)

    # Verify
    assert actual == expected

# Generated at 2022-06-26 10:45:36.276018
# Unit test for function validate_yaml
def test_validate_yaml():
    result = validate_yaml(
        b"""title: Example Schema
type: object
properties:
  firstName:
    type: string
  lastName:
    type: string
  age:
    description: Age in years
    type: integer
    minimum: 0
required:
- firstName
- lastName""",
        Schema,
    )
    assert len(result[1]) == 0



# Generated at 2022-06-26 10:45:48.971555
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "& 'hello'"
    value_0, error_messages_0 = validate_yaml(str_0, Field())
    assert len(error_messages_0) == 1
    assert error_messages_0[0].code == "parse_error"
    assert error_messages_0[0].text == "while scanning a simple key in '<unicode string>', line 1, column 1\nexpected '?', but found '&' in '& 'hello''."
    assert error_messages_0[0].line_no == 1
    assert error_messages_0[0].column_no == 0
    assert error_messages_0[0].char_index == 0
    assert error_messages_0[0].context is None

# Generated at 2022-06-26 10:45:55.338856
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "|\n  hello, world"
    token_0 = tokenize_yaml(str_0)
    assert token_0.value == ["hello", "world"]
    assert token_0.start == 0
    assert token_0.end == 15



# Generated at 2022-06-26 10:46:12.305644
# Unit test for function validate_yaml
def test_validate_yaml():
    value, errors = validate_yaml("test", Schema())
    assert value == "test"
    assert len(errors) == 0

    value, errors = validate_yaml("10", "integer")
    assert value == 10
    assert len(errors) == 0

    value, errors = validate_yaml("10", "string")
    assert len(errors) == 0
    assert value == "10"

    value, errors = validate_yaml("10", "number")
    assert len(errors) == 0
    assert value == 10

    # Errors are returned as a list of Message objects.
    value, errors = validate_yaml("abc", "integer")
    assert not isinstance(errors, list)
    assert len(errors) == 1
    assert errors[0].type == "INVALID_TYPE"

# Generated at 2022-06-26 10:46:23.811731
# Unit test for function validate_yaml
def test_validate_yaml():
    class ValueSchema(Schema):
        x = Field(type="number")
        y = Field(type="number")

    class ValueField(Field):
        def _serialize(self, value: typing.Any, **kwargs: typing.Any) -> typing.Any:
            return {"x": value, "y": value}

        def _deserialize(self, value: typing.Any, **kwargs: typing.Any) -> typing.Any:
            return value["x"]

        def validate(self, value: typing.Any, **kwargs: typing.Any) -> typing.Any:
            return ValueSchema().validate({"x": value, "y": value})

    yaml_str = """
- key: value
-
    key: value
"""

# Generated at 2022-06-26 10:46:34.018888
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    str_0 = "hello: world"
    token_0 = tokenize_yaml(str_0)
    assert (
        token_0.tokens["hello"].value == "world"
    )  # test for case where value is a str

    str_1 = "hello: 123"
    token_1 = tokenize_yaml(str_1)
    assert (
        token_1.tokens["hello"].value == 123
    )  # test for case where value is an int

    str_2 = "hello: 123.456"
    token_2 = tokenize_yaml(str_2)
    assert (
        token_2.tokens["hello"].value == 123.456
    )  # test for case where

# Generated at 2022-06-26 10:46:43.895401
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "& 'hello'"
    token_0 = tokenize_yaml(str_0)
    assert token_0
    assert token_0.start == 0
    assert token_0.end == len(str_0) - 1

    str_1 = "&'hello'"
    token_1 = tokenize_yaml(str_1)
    assert token_1
    assert token_1.start == 0
    assert token_1.end == len(str_1) - 1

    str_2 = "&'hello'\n&'world'"
    token_2 = tokenize_yaml(str_2)
    assert token_2
    assert type(token_2) == ListToken
    assert len(token_2) == 2
    for value in token_2:
        assert type(value) == D

# Generated at 2022-06-26 10:46:49.966831
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = """
    test:
        hello: world
    """
    class Schema0(Schema):
        test = Field(sub_fields={"hello": Field()})
    value_1, errors_1 = validate_yaml(str_1, validator=Schema0)
    assert len(errors_1) == 0

# Generated at 2022-06-26 10:47:00.117609
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "['foo', 'bar', 'baz']"
    token_0 = tokenize_yaml(str_0)
    assert token_0[0] == 'foo'
    str_1 = "[1, 2, 4, 7, 11, 16]"
    token_1 = tokenize_yaml(str_1)
    assert token_1[0] == 1
    str_2 = '{"foo": 1, "bar": 2, "baz": 3}'
    token_2 = tokenize_yaml(str_2)
    assert token_2["foo"] == 1
    str_3 = "!!timestamp '2002-12-14T21:59:43.1Z'"
    token_3 = tokenize_yaml(str_3)

# Generated at 2022-06-26 10:47:02.674807
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('key: "value"') == {'key': 'value'}



# Generated at 2022-06-26 10:47:05.746869
# Unit test for function validate_yaml
def test_validate_yaml():
  
    # str_0 = "& 'hello'"
    # token_0 = tokenize_yaml(str_0) # Error
    # print(token_0)
    
    str_1 = [{'name': 'George'}, {'name': 'Nimoy'}]
    token_1 = tokenize_yaml(str_1) # Correct
    print(token_1)


# Generated at 2022-06-26 10:47:17.871169
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class PersonSchema(Schema):
        """
        A Typesystem schema representing the person type.
        """

        first_name = Field(type=str)
        last_name = Field(type=str)
        age = Field(type=int)

    valid_yaml = """
        first_name: Bob
        last_name: Smith
        age: 25
    """

    valid_yaml_with_extra_field = """
        first_name: Bob
        last_name: Smith
        age: 25
        extra_field: 1
    """

    field_not_a_string_yaml = """
        first_name: 1
        last_name: Smith
        age: 25
    """


# Generated at 2022-06-26 10:47:25.827827
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.base import Field
    from typesystem import Integer

    class TestSchema(Schema):
        generic_field = Integer()

    validator = Field.create(TestSchema)

    str_0 = '1\n'
    message_0 = validate_yaml(str_0, validator)

    str_1 = 'a'
    message_1 = validate_yaml(str_1, validator)

    str_2 = '- 1\n- a'
    message_2 = validate_yaml(str_2, validator)

    str_3 = '{a: b }'
    message_3 = validate_yaml(str_3, validator)

    str_4 = '"hello"'
    message_4 = validate_yaml(str_4, validator)

# Generated at 2022-06-26 10:47:40.474534
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "& 'hello'"
    value_0, errors_0 = validate_yaml(str_0, scalar)
    str_1 = "True"
    value_1, errors_1 = validate_yaml(str_1, scalar)
    str_2 = "42"
    value_2, errors_2 = validate_yaml(str_2, scalar)
    str_3 = "None"
    value_3, errors_3 = validate_yaml(str_3, scalar)
    str_4 = "2.5"
    value_4, errors_4 = validate_yaml(str_4, scalar)
    str_5 = "True"
    value_5, errors_5 = validate_yaml(str_5, scalar)
    str_6 = "False"


# Generated at 2022-06-26 10:47:46.301609
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    content = '\n  - 0\n  - "hello"\n  - \n'
    validator = typing.List[typing.Any]
    result = validate_yaml(
        content=content,
        validator=validator,
    )
    assert type(result) == tuple
    assert len(result) == 2
    assert type(result[0]) == typing.List
    for item in result[0]:
        assert type(item) == typing.Any
    assert type(result[1]) == typing.List
    for item in result[1]:
        assert type(item) == Message
    content = '\n  - 0\n  - "hello"\n  - \n'

# Generated at 2022-06-26 10:47:57.794074
# Unit test for function validate_yaml
def test_validate_yaml():
    str1 = "& 'hello'"
    str2 = "'hello'"
    str3 = "& 'hello': 'world'"
    str4 = "& 'hello':"
    str5 = "& 'hello': 'world'\n& 'hello': 'world'"
    str6 = "& 'hello': 'world'\n& 'hello'\n& 'hello'"
    str7 = "& 'hello': 'world'\n& 'hello'\n& 'hello': 'world'\n& 'hello': 'world'"
    str8 = "& 'hello': 'world'\n& 'hello'\n& 'hello': 'world'\n& 'hello': 'world'\n& 'hello': 'world'"

# Generated at 2022-06-26 10:48:09.802954
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class Person(Schema):
        name = (
            "name",
            Field().string(required=True, pattern="^[A-Z]+[a-z]*$"),
        )

    person = Person()
    assert person.is_valid({"name": "Fred"})
    assert person.is_valid({"name": "Wilma"})
    assert person.is_valid({"name": "Barney"})
    assert not person.is_valid({"name": "homer"})
    assert not person.is_valid({})
    assert not person.is_valid({"name": ""})
    assert not person.is_valid({"name": None})

    yaml_str = "name: Fred"

# Generated at 2022-06-26 10:48:23.128038
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    assert tokenize_yaml("hello") == "hello"
    assert tokenize_yaml("6") == 6
    assert tokenize_yaml("-9") == -9
    assert tokenize_yaml("6.45") == 6.45
    assert tokenize_yaml("-9.45") == -9.45
    assert tokenize_yaml("true") is True
    assert tokenize_yaml("false") is False
    assert tokenize_yaml("null") is None
    assert tokenize_yaml("-true") is -True
    assert tokenize_yaml("+false") is +False
    assert tokenize_yaml("-null") is -None


# Generated at 2022-06-26 10:48:33.344349
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:48:41.920556
# Unit test for function validate_yaml
def test_validate_yaml():
    # test case 0
    validator = typing.Sequence[str]
    value, errors = validate_yaml(str_0, validator) 
    assert value == token_0
    assert errors == [
        Message(
            code="parse_error",
            message="No content.",
            position=Position(
                char_index=0,
                line_no=1,
                column_no=1,
            ),
        ),
    ]



# Generated at 2022-06-26 10:48:54.909282
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test that a bytestring works.
    value, error = validate_yaml(b"1234", int)
    assert value == 1234
    assert error == []

    # Test that a unicode string works.
    value, error = validate_yaml("1234", int)
    assert value == 1234
    assert error == []

    # Test that a string with a parse error returns an appropriate error
    # message.
    value, error = validate_yaml("not a number", int)
    assert value == None
    assert len(error) == 1
    assert error[0].text.startswith("Could not parse")
    assert error[0].position.line_no == 1
    assert error[0].position.column_no == 1
    assert error[0].position.char_index == 0

    # Test that a string

# Generated at 2022-06-26 10:49:06.120872
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test parse and validation using both a Field and Schema validator.
    """

    # Test valid YAML with a Field validator.
    valid_yaml_0 = b"234"
    error_messages_0 = validate_yaml(valid_yaml_0, validator=Field(name="integer_field"))[1]
    assert not error_messages_0
    valid_yaml_1 = b"123"
    error_messages_1 = validate_yaml(valid_yaml_1, validator=Field(name="integer_field"))[1]
    assert not error_messages_1

    # Test invalid YAML with a Field validator.
    invalid_yaml_0 = b"~"  # An invalid YAML integer.
    error_messages_2 = validate_y

# Generated at 2022-06-26 10:49:09.908083
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml("3", Field(int)) == (3, [])
    assert validate_yaml("3", Field(str)) == (None, [])

# Generated at 2022-06-26 10:49:24.293531
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "name: 'Bob'\n"
    assert validate_yaml(content=str_0, validator=Schema)
    assert not validate_yaml(content=str_0, validator=Field)
    str_0 = "---\n{'name': 'Bob'}\n"
    assert validate_yaml(content=str_0, validator=Schema)
    assert not validate_yaml(content=str_0, validator=Field)
    str_0 = "{'name': 'Bob'}"
    assert validate_yaml(content=str_0, validator=Schema)
    assert not validate_yaml(content=str_0, validator=Field)
    str_0 = "\n\n\n{'name': 'Bob'}"

# Generated at 2022-06-26 10:49:36.615375
# Unit test for function validate_yaml
def test_validate_yaml():
    # Valid input
    object_metadata = """
# This is a sample metadata object
id: 123
is_active: true
name: John Doe
tags:
  - "user"
  - "active"
"""
    token_0 = tokenize_yaml(object_metadata)
    assert isinstance(token_0, DictToken) and isinstance(token_0.value, dict)
    assert token_0.value["id"] == 123
    assert token_0.value["is_active"] is True
    assert token_0.value["name"] == "John Doe"
    assert list(token_0.value["tags"]) == ["user", "active"]
    # Invalid input

# Generated at 2022-06-26 10:49:44.318495
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "{'foo': 'bar'}"
    str_1 = "{'foo': 'baz'}"
    str_2 = "{'foo': 'bax'}"
    str_3 = "{'foo': 'bax', 'bar': 'baz'}"
    str_4 = "{'foo': 'bax', 'bar': 'baz'}"
    str_5 = "{'foo': 'bax', 'bar': 'baz', 'baz': 'foo'}"
    token_0 = tokenize_yaml(str_0)
    token_1 = tokenize_yaml(str_1)
    token_2 = tokenize_yaml(str_2)
    token_3 = tokenize_yaml(str_3)
    token_4 = tokenize_yaml(str_4)
    token

# Generated at 2022-06-26 10:49:54.767149
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Schema, fields

    class Movie(Schema):
        title = fields.String(max_length=200)
        year = fields.Integer(minimum=1900, maximum=2099)

    content = """
    title: Blade Runner
    year: 1982
    """

    value, error_messages = validate_yaml(content, Movie)

    assert value == {
        "title": "Blade Runner",
        "year": 1982,
    }

    assert error_messages == []



# Generated at 2022-06-26 10:50:08.006792
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "pyyaml must be installed"
    content_0 = b'name: "Arthur Dent"\n'
    content_1 = b"name: \"Arthur Dent\"\n"
    content_2 = b"name: 'Arthur Dent'\n"
    content_3 = b"name: ! \"Arthur Dent\"\n"
    content_4 = b'name: ! "Arthur Dent"\n'
    content_5 = b"name: ! 'Arthur Dent'\n"
    content_6 = b"name: ! Arthur Dent\n"
    content_7 = b"name: Arthur Dent\n"
    content_8 = b"name: Arthur Dent\n"
    content_9 = b"name: Arthur Dent\n"
    content_10 = b"name: Arthur Dent\n"
   

# Generated at 2022-06-26 10:50:13.196518
# Unit test for function validate_yaml
def test_validate_yaml():
    assert ("{'key': 'value'}" == validate_yaml(content=b"key: value\n", validator=dict))
    assert ("hello" == validate_yaml(content="Hello", validator=str))
    assert (-10 == validate_yaml(content="-10", validator=int))
    assert (4444 == validate_yaml(content=b"4444", validator=int))
    assert (3.14 == validate_yaml(content="3.14", validator=float))
    assert (True == validate_yaml(content=b"true", validator=bool))
    assert (False == validate_yaml(content="false", validator=bool))
    assert (None == validate_yaml(content=b"null", validator=type(None)))


# Generated at 2022-06-26 10:50:19.812485
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        id = fields.Integer()
        name = fields.String()
        age = fields.Integer(required=False)
        salary = fields.Number(required=False)
        married = fields.Boolean(required=False)

    content = '''
id: 1
name: Alex
age: 42
salary: 9999.99
married: True
'''
    value, error_dict = validate_yaml(content, Person)
    assert error_dict == {}
    assert value == {
        "id": 1,
        "name": "Alex",
        "age": 42,
        "salary": 9999.99,
        "married": True,
    }



# Generated at 2022-06-26 10:50:28.947916
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = ''
    str_1 = 'True'
    str_2 = 'None'
    str_3 = '12'
    str_4 = '12.4'
    str_5 = 'Hello world'
    str_6 = '[]'
    str_7 = '{}'
    str_8 = '[1, true, None, 12, 12.4]'
    str_9 = '{a: 1, b: true, c: None, d: 12, e: 12.4}'

    def _v(content: str, validator: typing.Union[Field, typing.Type[Schema]]):
        try:
            value, errors = validate_yaml(content, validator)
        except (ParseError, ValidationError):
            return (False, None)

# Generated at 2022-06-26 10:50:35.208813
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "& 'hello'"
    validator_0 = str

    token_0 = tokenize_yaml(str_0)
    value_0, error_messages_0 = validate_with_positions(
        token_0, validator_0
    )
    assert value_0 == "hello"
    assert error_messages_0 == []



# Generated at 2022-06-26 10:50:38.936448
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "& 'hello'"
    token_0 = tokenize_yaml(str_0)
    assert token_0 == {'*': 'hello'}



# Generated at 2022-06-26 10:50:54.245928
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = '''hello: world

bar:
  - foo
  - bar
'''
    class TestSchema(Schema):
        hello = "str"
        bar = "list[str]"
    validator_1 = TestSchema()
    (value, error_messages) = validate_yaml(str_1, validator_1)
    assert error_messages == []
    class TestSchema_2(Schema):
        hello = "str?"
        bar = "list[str]"
    validator_2 = TestSchema_2()
    (value_2, error_messages_2) = validate_yaml(str_1, validator_2)

# Generated at 2022-06-26 10:51:02.877955
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "& 'hello'"
    token_0 = tokenize_yaml(str_0)
    val_0, err_0 = validate_yaml(str_0, ScalarToken)
    assert err_0[0]['text'] == 'No alias @ &.'
    assert err_0[0]['position'].column_no == 0
    assert err_0[0]['position'].line_no == 1
    assert err_0[0]['position'].char_index == 0

    str_1 = "!!str 0"
    token_1 = tokenize_yaml(str_1)
    val_1, err_1 = validate_yaml(str_1, ScalarToken)
    assert err_1[0]['text'] == 'No tag ! !.'

# Generated at 2022-06-26 10:51:07.262307
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "& 'hello'"
    tokenize_yaml(str_0)
    str_1 = "some&'hello'"
    tokenize_yaml(str_1)


# Generated at 2022-06-26 10:51:18.237316
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "& 'hello'"
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, ScalarToken)
    assert token_0.value == "& 'hello'"
    assert token_0.text == "& 'hello'"
    assert token_0.start == 0
    assert token_0.end == 10
    assert token_0.position.line_no == 1
    assert token_0.position.column_no == 1
    assert token_0.position.char_index == 0

    str_1 = "& 'hello'\n& 'hello'"
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, ListToken)
    assert token_1.value[0].value == "& 'hello'"
    assert token_

# Generated at 2022-06-26 10:51:23.532616
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = """
      "hello"
      world   # comment
    """

    str_1 = "1"

    str_2 = "1.0"

    str_3 = "1e10"

    str_4 = "a"

    str_5 = "True"

    str_6 = "null"

    str_7 = "1.0"

    str_8 = "1e10"

    str_9 = "a"

    str_10 = "True"

    str_11 = "null"

    str_12 = """
        key: "value"
    """

    str_13 = """
      key1: "value1"
      key2: "value2"
      key3: "value3"
    """


# Generated at 2022-06-26 10:51:28.462226
# Unit test for function validate_yaml
def test_validate_yaml():
    # Define the validator (Schema) for the body of the request.
    class Person(Schema):
        name = String(max_length=20)
        age = Integer()
        alive = Boolean()
    # Define a simple JSON request body.
    payload = '{"name": "Mark", "age": "27", "alive": "true"}'
    (value, error_messages) = validate_yaml(payload, Person)
    assert not error_messages

# Generated at 2022-06-26 10:51:39.364029
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "& 'hello'"
    token_0 = tokenize_yaml(str_0)
    field_0 = Field(type="string")
    value_0, errors_0 = validate_yaml(str_0, field_0)
    str_1 = "this string is too long"
    token_1 = tokenize_yaml(str_1)
    field_1 = Field(type="string", max_length=10)
    value_1, errors_1 = validate_yaml(str_1, field_1)
    str_2 = "3"
    token_2 = tokenize_yaml(str_2)
    field_2 = Field(type="string", max_length=10)
    value_2, errors_2 = validate_yaml(str_2, field_2)


