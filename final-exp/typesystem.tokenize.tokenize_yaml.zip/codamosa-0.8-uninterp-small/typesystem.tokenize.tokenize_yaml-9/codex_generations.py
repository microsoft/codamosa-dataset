

# Generated at 2022-06-26 10:41:55.276878
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('# comment\n') == None
    assert tokenize_yaml('? # comment\n') == None
    assert tokenize_yaml('? # comment\n:') == None
    assert tokenize_yaml(None) == None
    assert tokenize_yaml(None) == None



# Generated at 2022-06-26 10:41:59.519414
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '1<sSwWX\n!v.QI'
    token_0 = tokenize_yaml(str_0)
    validate_yaml(str_0, token_0)


# Generated at 2022-06-26 10:42:10.326458
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    Test that validating YAML works as expected.
    """
    class TestField(Field):
        def validate(self, value):
            if value != "hello":
                raise ValidationError(
                    text="Not a hello!", code="not_hello", position=value.position
                )

    value, errors = validate_yaml("hello", TestField())
    assert errors == []
    assert value == ScalarToken(value="hello", start=0, end=5, content="hello")

    value, errors = validate_yaml("bye", TestField())
    assert errors == [
        Message(text="Not a hello!", code="not_hello", position=Position(2, 3, 1))
    ]
    assert value == ScalarToken(value="bye", start=2, end=5, content="\nbye")




# Generated at 2022-06-26 10:42:19.088800
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    str_0 = "I am a string"
    validator_0 = Field(type='string', min_length=7)
    value_0, errors_0 = validate_yaml(str_0, validator_0)
    assert len(errors_0) == 0

    str_1 = "I am a string"
    validator_1 = Field(type='string', max_length=2)
    value_1, errors_1 = validate_yaml(str_1, validator_1)
    assert len(errors_1) == 1

    str_2 = "I am a string"
    validator_2 = Field(type='string', pattern="I am")

# Generated at 2022-06-26 10:42:27.595389
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = """
            Type: AWS::CloudFormation::Stack
            Properties:
              TemplateURL:
                Fn::GetAtt:
                  - PublicSubnetConfig
                  - Outputs.PublicSubnetConfigURL
            """
    token_0 = tokenize_yaml(str_0)
    validator = Field(type="dict")
    validator.validate(token_0.value)



# Generated at 2022-06-26 10:42:36.519838
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_1 = '1<sSwWX\n!v.QI'
    token_0 = tokenize_yaml(str_1)
    assert token_0.start == 0
    assert token_0.end == 11
    assert token_0.content == str_1
    assert token_0.position() == (1, 1)
    str_2 = '---\n- a\n- b\n- c\n- d\n'
    token_1 = tokenize_yaml(str_2)
    assert token_1.start == 4
    assert token_1.end == 48
    assert token_1.content == str_2
    assert token_1.position() == (1, 5)
    str_3 = '---\na: b'

# Generated at 2022-06-26 10:42:41.036701
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'name: hello\n'
    field_0 = Field(name='name', type='string')
    error_messages_0 = validate_yaml(str_0, field_0)
    print(error_messages_0)
    assert error_messages_0 == ([], {'name': 'hello'})




# Generated at 2022-06-26 10:42:54.666547
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '\'<K1\x1f\x0b!\x00\x14\''
    str_1 = '1<sSwWX\n!v.QI'
    str_2 = 'h,V>\x1b!3\x0c,\x1f'
    str_3 = '\'<K1\x1f\x0b!\x00\x14\''
    str_4 = '1<sSwWX\n!v.QI'
    str_5 = 'h,V>\x1b!3\x0c,\x1f'
    str_6 = '\'<K1\x1f\x0b!\x00\x14\''

# Generated at 2022-06-26 10:43:01.118338
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '1<sSwWX\n!v.QI'
    Field_0 = Field(name='Field 0', type='integer')
    # Call function validate_yaml
    (value_0, error_messages_0) = validate_yaml(content=str_0, validator=Field_0)
    # Check return type
    assert isinstance(error_messages_0, list)
    # Check return value
    assert error_messages_0 == []
    # Check type of element in returned list
    assert isinstance(error_messages_0[0], Message)

# Generated at 2022-06-26 10:43:07.564089
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '1<sSwWX\n!v.QI'
    token_0 = tokenize_yaml(str_0)
    value_0, errors_0 = validate_yaml(str_0, Field)
    value_1, errors_1 = validate_yaml(str_0, Field)


# Generated at 2022-06-26 10:43:16.128571
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '1<sSwWX\n!v.QI'
    str_1 = '1<sSwWX\n!v.QI'
    value_0, error_messages_0 = validate_yaml(str_0, str_1)
    assert value_0.endswith('QI')
    assert error_messages_0.endswith('I')


# Generated at 2022-06-26 10:43:23.622860
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = 'GK"`w'
    token_0 = tokenize_yaml(str_0)
    str_1 = '\u001c'
    token_1 = tokenize_yaml(str_1)
    str_2 = '#'
    token_2 = tokenize_yaml(str_2)
    str_3 = '\u000a'
    token_3 = tokenize_yaml(str_3)
    str_4 = '\u0001\u0000'
    token_4 = tokenize_yaml(str_4)
    str_5 = 'MjtO\u001bN\u0001'
    token_5 = tokenize_yaml(str_5)
    str_6 = '\u0016\u0013\u0013'
    token_

# Generated at 2022-06-26 10:43:28.374711
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'J.\nh\n'
    str_1 = 'b-h\x02\r\r\r\r\r\r\r\r\r'
    str_2 = ''
    token_0 = tokenize_yaml(str_0)
    token_1 = tokenize_yaml(str_1)
    token_2 = tokenize_yaml(str_2)

# Generated at 2022-06-26 10:43:40.614976
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '1<sSwWX\n!v.QI'
    token_0 = tokenize_yaml(str_0)
    result_0 = validate_with_positions(token_0, int)
    assert result_0 == (1, None)
    str_1 = '1<sSwWX\n!v.QI'
    token_1 = tokenize_yaml(str_1)
    result_1 = validate_with_positions(token_1, str)
    assert result_1 == ('1<sSwWX\n!v.QI', None)
    str_2 = '1<sSwWX\n!v.QI'
    token_2 = tokenize_yaml(str_2)

# Generated at 2022-06-26 10:43:43.815256
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '1<sSwWX\n!v.QI'
    assert tokenize_yaml(str_0) is not None


# Generated at 2022-06-26 10:43:55.885479
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '  1.2\n true\n\n -1\n'
    token_0 = tokenize_yaml(str_0)
    assert token_0.value == ScalarToken(1.2, 0, 3, content=str_0).value
    assert token_0.start == ScalarToken(1.2, 0, 3, content=str_0).start
    assert token_0.end == ScalarToken(1.2, 0, 3, content=str_0).end
    assert token_0.content == ScalarToken(1.2, 0, 3, content=str_0).content
    assert token_0.value == ScalarToken(1.2, 0, 3, content=str_0).value

# Generated at 2022-06-26 10:44:08.495961
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = ''
    token_0 = tokenize_yaml(str_0)
    assert type(token_0) == ScalarToken
    assert token_0.start == 0
    assert token_0.end == -1
    assert token_0.value == ''
    str_1 = '{}'
    token_1 = tokenize_yaml(str_1)
    assert type(token_1) == DictToken
    assert token_1.start == 0
    assert token_1.end == 1
    str_2 = '[]'
    token_2 = tokenize_yaml(str_2)
    assert type(token_2) == ListToken
    assert token_2.start == 0
    assert token_2.end == 1
    str_3 = '{:}'

# Generated at 2022-06-26 10:44:19.616294
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '1<sSwWX\n!v.QI'
    value_0 = tokenize_yaml(str_0)
    str_1 = 'J;0F[hv%5!$ '
    value_1 = tokenize_yaml(str_1)
    str_2 = '2,(J4M4+^)q\x1a'
    value_2 = tokenize_yaml(str_2)
    str_3 = '1<sSwWX\n!v.QI'
    value_3 = tokenize_yaml(str_3)
    str_4 = '+/ 5-gvx=*\x0f'
    value_4 = tokenize_yaml(str_4)

# Generated at 2022-06-26 10:44:25.848707
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '0,yB7N&k#\ngVf 0u'
    str_1 = ''
    str_2 = 'im;O%&j\n>x8MtE'
    str_3 = '\n$&jF\ng'
    str_4 = '\n+q8>H\nN$'
    str_5 = 'f `G\nH+j'
    str_6 = 'hWh5\nsE'
    str_7 = '\n#X~\njE;'
    str_8 = 'VQmx\n%'
    str_9 = '\nX\n'
    str_10 = '\n#<"7\nw$'
    str_11 = '\nq'

# Generated at 2022-06-26 10:44:34.175075
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # We have no way of generating test cases programmatically for
    # tokenize_yaml, so we just write them by hand.
    str_0 = '1<sSwWX\n!v.QI'
    token_0 = tokenize_yaml(str_0)
    str_1 = '\t"%^\t\n>\u000a\u001er/'
    token_1 = tokenize_yaml(str_1)
    str_2 = 'e dPQo\t\u0019T&\n\u0009\u0001\n\u0003\u000b\u000bC\u0001\u0015\u0012\u0009\u0007\u0003.\u0011\u0015M'
    token_2 = tokenize_yaml

# Generated at 2022-06-26 10:44:42.342856
# Unit test for function validate_yaml
def test_validate_yaml():
    test_schema = Schema({"a": str})
    str_content = b"{b: 1}"
    value, errors = validate_yaml(str_content, test_schema)

# Generated at 2022-06-26 10:44:45.588238
# Unit test for function validate_yaml
def test_validate_yaml():
    str1 = '1'
    str2 = 'f'
    assert(validate_yaml(str1, "int") == 1);
    assert(validate_yaml(str2, "float") == 1);
    assert(validate_yaml(str2, "int") == 0);

# Generated at 2022-06-26 10:44:50.194804
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '1<sSwWX\n!v.QI'
    field_0 = Field(type_='string')
    res_0 = validate_yaml(str_0, field_0)
    assert isinstance(res_0, tuple)
    assert isinstance(res_0[0], str)
    assert isinstance(res_0[1], list)
    assert isinstance(res_0[1][0], ValidationError)

# Generated at 2022-06-26 10:45:03.340107
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '1<sSwWX\n!v.QI'
    str_1 = '\x00\t\n\r\x7f\x80\u0080\uffff'
    str_2 = '\x00\t\n\r\x7f\x80\u0080\uffff'
    str_3 = '\x00\t\n\r\x7f\x80\u0080\uffff'
    str_4 = '\x00\t\n\r\x7f\x80\u0080\uffff'
    field_0 = Field(type="string")
    assert field_0.validate(str_0) == "1<sSwWX\n!v.QI"

# Generated at 2022-06-26 10:45:04.738422
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    test_case_0()


# Generated at 2022-06-26 10:45:12.216610
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    #assert yaml is not None, "'pyyaml' must be installed."

    if isinstance(str_0, bytes):
        str_content = str_0.decode("utf-8", "ignore")
    else:
        str_content = str_0

    if not str_content.strip():
        # Handle the empty string case explicitly for clear error messaging.
        position = Position(column_no=1, line_no=1, char_index=0)
        raise ParseError(text="No content.", code="no_content", position=position)

    class CustomSafeLoader(SafeLoader):
        pass

    def construct_mapping(loader: "yaml.Loader", node: "yaml.Node") -> DictToken:
        start = node.start_mark.index
        end = node.end_mark.index
       

# Generated at 2022-06-26 10:45:23.820543
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = 'true'
    token_1 = tokenize_yaml(content)
    expected = ScalarToken(True, 0, 3, content)
    assert token_1 == expected

    content = '- true\n- false\n- 1\n- 2'
    token_1 = tokenize_yaml(content)
    expected = ListToken([True, False, 1, 2], 0, 20, content)
    assert token_1 == expected

    content = '{"a": "b"}'
    token_1 = tokenize_yaml(content)
    expected = DictToken({"a": "b"}, 0, 8, content)
    assert token_1 == expected

    content = ""
    with pytest.raises(ParseError):
        token_1 = tokenize_yaml(content)

    content = "{"

# Generated at 2022-06-26 10:45:24.506103
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert True



# Generated at 2022-06-26 10:45:33.800315
# Unit test for function validate_yaml
def test_validate_yaml():

    # Expected schema to be used for test
    class TestSchema(Schema):
        test_field = Field(validation='is_string')

    # Test for empty string
    assert validate_yaml('', TestSchema) == (None, [ValidationError(
        text='No content.',
        code='no_content',
        position=Position(
            line_no=1,
            column_no=1,
            char_index=0
        ))])

    # Test for correct string with correct schema
    assert validate_yaml('test_field: "a"', TestSchema) == (TestSchema({'test_field': 'a'}), [])

    # Test for incorrect string with correct schema

# Generated at 2022-06-26 10:45:47.464931
# Unit test for function validate_yaml
def test_validate_yaml():

    # Schema definition
    class Person(Schema):
        id = Field(type="integer")
        name = Field(type="string")
        age = Field(type="integer")

    schema = Person()

    # Validating valid data
    data = '''
        {
            "id": 1,
            "name": "John Doe",
            "age": 40
        }
    '''
    decoded_data = validate_yaml(data, schema)

    assert decoded_data.id == 1
    assert decoded_data.name == "John Doe"
    assert decoded_data.age == 40

    # Validating invalid data
    # Change the name type to integer

# Generated at 2022-06-26 10:46:02.171309
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b'{"example": "foo"}'
    validator = {"example": "string"}

    value, messages = validate_yaml(content, validator)
    assert value == {"example": "foo"}
    assert messages == []

    # Test invalid YAML.
    content = b'{"example": "foo"'
    validator = {"example": "string"}
    error_message = verify_error(content, validator)
    assert error_message.code == "parse_error"
    assert error_message.text == "expected '}', but found '<stream end>'."

    # Test invalid document structure.
    content = b'{"example": "foo"}'
    validator = {"example": "string", "example2": "string"}
    error_message = verify_error(content, validator)
    assert error_message

# Generated at 2022-06-26 10:46:13.979155
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test with a simple field.
    validator = Field(name="a", type="string")
    value, messages = validate_yaml("a: 100", validator=validator)
    assert value == 100
    assert messages == [
        Message(
            text="Expected type 'string', got value '100'.",
            code="type_error.string",
            position=Position(column_no=4, line_no=1, char_index=3),
        )
    ]

    # Test with a simple schema.
    class User(Schema):
        name = Field(type="string", nullable=False)
        age = Field(type="integer", nullable=False)

    value, messages = validate_yaml("name: Edward\nage: 40", validator=User)

# Generated at 2022-06-26 10:46:18.874747
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    bytes_0 = b'>\xafF\xb6h\xca%\xaf\xdeQss%~8`'
    token_0 = tokenize_yaml(bytes_0)


# Generated at 2022-06-26 10:46:20.797651
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = '{"a":1}'
    token = tokenize_yaml(content)
    assert token.content is not None


# Generated at 2022-06-26 10:46:27.326524
# Unit test for function validate_yaml
def test_validate_yaml():
    content_0 = "---\nfoo: 'Bar'"
    validator_0 = Schema(fields={"foo": Field(type="string")})
    value_0, errors_0 = validate_yaml(content_0, validator_0)
    assert errors_0 == []

# Generated at 2022-06-26 10:46:36.410261
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = (
        b"""
        # Some comment.
        key_0: value_0 # Some comment.
        key_1: !bool value_1
        key_2: !bytes value_2
        key_3: !float value_3
        key_4: !int value_4
        key_5: !null value_5
        key_6: [1, 2, 3]
        key_7:
            key_0: value_0
            key_1: value_1
            key_2: value_2
            key_3: value_3
            key_4: value_4
            key_5: value_5
            key_6: [1, 2, 3]
        key_8: ~
        """
    )
    token_0 = tokenize_yaml(content)

# Generated at 2022-06-26 10:46:41.678798
# Unit test for function validate_yaml
def test_validate_yaml():
    schema_0 = Schema(fields={"foo": {"type": "string"}})
    value_0, errors_0 = validate_yaml(
        b"foo: bar\n", validator=schema_0)
    assert value_0 == {"foo": "bar"}
    assert len(errors_0) == 0


# Generated at 2022-06-26 10:46:43.988620
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None
    assert type(validate_yaml("", Field())) == tuple


# Generated at 2022-06-26 10:46:55.335719
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # '{''foo': [1, 2, 3], ''bar': True}'
    bytes_0 = b"\x7b\x22\x66\x6f\x6f\x22\x3a\x20\x5b\x31\x2c\x20\x32\x2c\x20\x33\x5d\x2c\x20\x22\x62\x61\x72\x22\x3a\x20\x54\x72\x75\x65\x7d"
    token_0 = tokenize_yaml(bytes_0)

# Generated at 2022-06-26 10:47:07.484162
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.schemas import Schema

    class BookSchema(Schema):
        title = Field(type=str)
        author = Field(type=str)
        price = Field(type=float)

    # String tests:
    assert tokenize_yaml({}) == DictToken(dict())
    assert tokenize_yaml([]) == ListToken(list())
    assert tokenize_yaml("123") == ScalarToken("123")
    assert tokenize_yaml("123.12") == ScalarToken(123.12)
    assert tokenize_yaml("True") == ScalarToken(True)
    assert tokenize_yaml("no") == ScalarToken(False)
    assert tokenize_yaml("null") == ScalarToken(None)
    assert tokenize_yaml("null") == ScalarToken

# Generated at 2022-06-26 10:47:21.049213
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test with Python byte string
    bytes_0 = b'foo: bar baz: qux\n'
    bytes_1 = b'---\n foo: bar\n baz: qux\n'
    token_0 = tokenize_yaml(bytes_0)
    token_1 = tokenize_yaml(bytes_1)

    # Test with Python string
    str_0 = '---\n foo: bar\n baz: qux\n'
    str_1 = '---\n foo: bar\n baz: "qux"\n'
    token_2 = tokenize_yaml(str_0)
    token_3 = tokenize_yaml(str_1)

    # Test for error handling

# Generated at 2022-06-26 10:47:32.346815
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'>\xafF\xb6h\xca%\xaf\xdeQss%~8`'
    bytes_1 = b'\x9c\xc3\x8c\xbb\xdf'
    str_2 = '\t%\x9b\x9b\x90\xec\xda\x13\x92\x88\x96\x0b<'
    str_3 = '\xc8\xa8\xa2\x04\x7f[v\x8a\x1a\x9eY\xc5\x83\x81\xfa\x0cB'

# Generated at 2022-06-26 10:47:38.598594
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    bytes_0 = b'>\xafF\xb6h\xca%\xaf\xdeQss%~8`'
    ret_0 = tokenize_yaml(bytes_0)
    assert ret_0 == '>\xafF\xb6h\xca%\xaf\xdeQss%~8`'


# Generated at 2022-06-26 10:47:46.275508
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types.boolean import Boolean
    from typesystem.types.string import String

    class TestSchema(Schema):
        x = Boolean()
        y = String()

    errors = validate_yaml(b"", TestSchema)
    assert errors.as_dict() == {
        "code": "no_content",
        "line_no": 1,
        "column_no": 1,
        "char_index": 0,
        "text": "No content.",
        "path": [],
    }

    errors = validate_yaml(b"x: true\ny: 1", TestSchema)

# Generated at 2022-06-26 10:47:55.989305
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"foo: bar"
    field = Field(type="string")
    token = tokenize_yaml(content)

    from typesystem.fields import Field

    class TestSchema(Schema):
        foo = Field(type="string")

    assert validate_yaml(content, field) == {
        "value": "bar",
        "error_messages": [],
    }
    assert validate_yaml(content, TestSchema) == {
        "value": {"foo": "bar"},
        "error_messages": [],
    }
    assert validate_yaml(content, TestSchema(strict=True)) == {
        "value": {"foo": "bar"},
        "error_messages": [],
    }

    content = "foo: false"
    value, error_messages = validate

# Generated at 2022-06-26 10:48:05.935266
# Unit test for function validate_yaml
def test_validate_yaml():
    value, error_message = validate_yaml(
        b"foo: bar\n", {"foo": {"type": "string"}}
    )
    assert value == {"foo": "bar"}
    assert error_message == []

    _, error_message_2 = validate_yaml(b"foo: false\n", {"foo": {"type": "boolean"}})
    assert isinstance(error_message_2[0], Message)
    assert error_message_2[0].code == "value_error.type"
    assert error_message_2[0].position == Position(char_index=6, column_no=7, line_no=1)



# Generated at 2022-06-26 10:48:12.996685
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    - a
    - b
    - c
    """
    validator = typing.List[Field]
    expected_value = [
        ScalarToken(value="a", start=6, end=7, content=content),
        ScalarToken(value="b", start=9, end=10, content=content),
        ScalarToken(value="c", start=12, end=13, content=content),
    ]
    value, error_messages = validate_yaml(content, validator)
    assert value == expected_value
    assert not error_messages



# Generated at 2022-06-26 10:48:17.025702
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"foo: bar: baz"
    validator = Field(key="foo", type="string")
    value_errors = validate_yaml(content, validator)
    assert type(value_errors) is tuple
    assert len(value_errors) == 2
    assert type(value_errors[0]) is str
    assert type(value_errors[1]) is list


# Generated at 2022-06-26 10:48:25.276741
# Unit test for function validate_yaml
def test_validate_yaml():

    # Test Schema
    class Address(Schema):
        city = String(max_length=100)

    class User(Schema):
        name = String(max_length=100)
        email = Email(max_length=100)
        address = Compound(Address)

    # Test data
    data = """
        name: John Doe
        email: john@example.com
        address:
            city: New York
    """

    # Value is parsed from YAML
    value, error_messages = validate_yaml(data, User)
    assert value == {
        "name": "John Doe",
        "email": "john@example.com",
        "address": {"city": "New York"},
    }
    assert len(error_messages) == 0

    # Invalid data

# Generated at 2022-06-26 10:48:36.445679
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'stuff'
    token_0 = tokenize_yaml(bytes_0)
    errors_0 = validate_yaml(content=bytes_0, validator=Field(type=str))
    messages_0 = [
        Message(
            text="Extra data not permitted.",
            code="extra_data",
            type="value_error",
            position=Position(column_no=1, char_index=0, line_no=1),
        )
    ]
    assert errors_0 == messages_0
    bytes_1 = b""
    token_1 = tokenize_yaml(bytes_1)
    errors_1 = validate_yaml(content=bytes_1, validator=Field(type=str))

# Generated at 2022-06-26 10:48:45.322655
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = typing.Union[Field, typing.Type[Schema]]
    content = typing.Union[str, bytes]
    assert validate_yaml(content, validator)


# Generated at 2022-06-26 10:48:55.144349
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = b'hello: "world"\nlist:\n- item1\n- item2\n'
    token = tokenize_yaml(content)
    assert token.start_mark.line_no == 1
    assert token.start_mark.column_no == 0
    assert token.end_mark.line_no == 5
    assert token.end_mark.column_no == 8
    assert isinstance(token, DictToken)
    assert isinstance(token.items[0][0], ScalarToken)
    assert token.items[0][0].value == "hello"
    assert isinstance(token.items[1][1], ListToken)



# Generated at 2022-06-26 10:48:59.634472
# Unit test for function validate_yaml
def test_validate_yaml():
    content = ""
    validator = "validator"
    expected = None
    expected = (None, [])
    result = validate_yaml(content, validator)
    assert result == expected



# Generated at 2022-06-26 10:49:07.906037
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # Test with the arg: None
    assert tokenize_yaml(None) == None

    # Test with the arg: "", b""
    assert tokenize_yaml(b"") == DictToken(dict(), 0, 0, content=b"")
    assert tokenize_yaml("") == DictToken({}, 0, 0, content="")

    # Test with the arg: "---\n  name: test\n  value: 3\n  flag: True\n"
    assert tokenize_yaml("---\n  name: test\n  value: 3\n  flag: True\n") == DictToken({'name': 'test', 'value': 3, 'flag': True}, 0, 34, content="---\n  name: test\n  value: 3\n  flag: True\n")

    # Test

# Generated at 2022-06-26 10:49:11.931176
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(b"asd", int) == (False, [Message(text="Invalid type.")])
    assert validate_yaml(b"123", int) == (123, [Message(text="Invalid type.")])

# Generated at 2022-06-26 10:49:24.088736
# Unit test for function validate_yaml
def test_validate_yaml():
    # cases
    case_0_input_0 = '[]'
    case_0_input_1 = typing.TypeVar('Field', bound='Field')
    case_0_output = ([], [])
    case_1_input_0 = '{}'
    case_1_input_1 = typing.TypeVar('Field', bound='Field')
    case_1_output = ({}, [])
    case_2_input_0 = '[true]'
    case_2_input_1 = typing.TypeVar('Field', bound='Field')
    case_2_output = ([True], [])
    case_3_input_0 = '[false]'
    case_3_input_1 = typing.TypeVar('Field', bound='Field')
    case_3_output = ([False], [])
    case_4_input_0

# Generated at 2022-06-26 10:49:36.507111
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test cases associated with evaluating the function validate_yaml
    # (with valid-schema-001)
    schema_1 = Schema(type='string')
    value_1 = validate_yaml(b'value: foo', schema_1)[0]
    assert value_1 is not None, 'If there were no errors, the token should be returned.'
    assert value_1 == "foo", 'The value should be "foo"'

    # Test cases associated with evaluating the function validate_yaml
    # (with valid-schema-002)
    schema_2 = Schema(type=['integer', 'string'])
    value_2, errors_2 = validate_yaml(b'value: foo', schema_2)
    assert value_2 is not None, 'If there were no errors, the token should be returned.'
    assert errors_

# Generated at 2022-06-26 10:49:44.212887
# Unit test for function validate_yaml
def test_validate_yaml():
    from operator import eq

    from typesystem.fields import Int

    # Test valid integer.
    _result, _error_messages = validate_yaml(b'3', Int())
    assert _result == 3
    assert not _error_messages

    # Test invalid integer.
    _result, _error_messages = validate_yaml(b'A', Int())
    assert _result is None
    assert isinstance(_error_messages[0], ValidationError)
    assert _error_messages[0].position.line_no == 1
    assert _error_messages[0].position.column_no == 1
    assert _error_messages[0].position.char_index == 0
    assert _error_messages[0].message == "Enter a whole number."

    # Test invalid integer and line numbering.
    _result

# Generated at 2022-06-26 10:49:57.434089
# Unit test for function validate_yaml
def test_validate_yaml():
    # TODO: Test cases with multiple error locations when that works.
    assert validate_yaml(content=b"", validator=yaml_field) == (None, [])
    assert validate_yaml(content=b"a", validator=yaml_field) == (None, [])
    assert validate_yaml(content=b"{}", validator=yaml_field) == ({}, [])
    assert validate_yaml(content=b"", validator=yaml_schema_type) == (None, [])
    assert validate_yaml(content=b"a", validator=yaml_schema_type) == (None, [])
    assert validate_yaml(content=b"{}", validator=yaml_schema_type) == ({}, [])


# Generated at 2022-06-26 10:49:58.916939
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml("") == None



# Generated at 2022-06-26 10:50:05.767159
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    try:
        from typesystem.tokenize.test.test_tokenize_yaml import test_case_0

        test_case_0()
    except:
        assert False


# Generated at 2022-06-26 10:50:15.281858
# Unit test for function validate_yaml
def test_validate_yaml():
    # set up
    content = '{"name": "Jane", "age": 28}'
    # expected
    expected_value = {'name': 'Jane', 'age': 28}
    expected_messages = []  # type: typing.List[Message]
    # execution
    result_value, result_messages = validate_yaml(content, {"name": str, "age": int})
    # check result
    assert expected_value == result_value
    assert result_messages == expected_messages

# Generated at 2022-06-26 10:50:26.910820
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(b"", Schema) == ({}, [])
    assert validate_yaml(b"", Field) == (None, [])
    assert validate_yaml(b"?", Field) == (None, [])
    with pytest.raises(ValidationError) as excinfo:
        validate_yaml(b"?", Schema)
    assert excinfo.value.error_messages == [
        Message(
            text="Expected a mapping.",
            code="invalid",
            position=Position(column_no=2, line_no=1, char_index=1),
        )
    ]
    with pytest.raises(ValidationError) as excinfo:
        validate_yaml(b"", Field(required=True))

# Generated at 2022-06-26 10:50:39.357368
# Unit test for function validate_yaml
def test_validate_yaml():
    value, messages = validate_yaml(b"{}", Schema)
    assert value == {}
    assert not messages
    value, messages = validate_yaml(b"{}", Schema(fields={"foo": Field()}))
    assert value == {"foo": None}
    assert not messages

    with pytest.raises(ValidationError) as exc_info:
        validate_yaml(b"{}", Schema(fields={"foo": Field(required=True)}))
    assert exc_info.value.as_dict() == {
        "type": "ValidationError",
        "code": "required",
        "text": "Required value is missing.",
        "position": {"line_no": 1, "column_no": 2, "char_index": 1},
    }


# Generated at 2022-06-26 10:50:43.662654
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"max_length": 10})
    data = "A" * 12

    _, error_messages = validate_yaml(data, validator=schema)

    assert error_messages[0] == Message(
        code="max_length",
        text="Must have no more than 10 characters.",
        position=Position(line_no=1, column_no=1, char_index=0),
    )

# Generated at 2022-06-26 10:50:55.144636
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test with a YAML string
    content = "some-key: some-value\nsome-other-key: some-other-value"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

    # Test with a YAML bytestring
    content = b"some-key: some-value\nsome-other-key: some-other-value"
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

    # Test with a list field
    content = b"- 1\n- 2\n- 3"
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)

    # Test with a scalar field
    content = b"some-value"

# Generated at 2022-06-26 10:51:04.272293
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_1 = b'>\xafF\xb6h\xca%\xaf\xdeQss%~8`'
    bytes_2 = b'\xa1\xce\x0e\x07\xa4\x9e\xd0\xdf\xdd\xac\xe2\x0c\x8e\x11'
    bytes_3 = b'\x8d\xed\xad\x88\xfa\x8d\xd5\x05\x9b\x06\x13\x0f\x0b\x07'
    bytes_4 = b'\x9e\xe9\x8a\xab\xdd\xcb\xb0\xd8\x0c\x06\x9d\x9a\x13\x17'

# Generated at 2022-06-26 10:51:05.651160
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert token_0 == token_1

# Generated at 2022-06-26 10:51:17.584291
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test content from Python's test_yaml
    str_0 = "- home: Bangalore\n  hobbies: [playing, reading]\n" + "  married: No\n"
    token_0 = tokenize_yaml(str_0)
    str_1 = "- home: Cochin\n  hobbies: [singing, dancing]\n" + "  married: Yes\n"
    token_1 = tokenize_yaml(str_1)
    assert token_0["hobbies"]._start == 22
    assert token_0["hobbies"]._end == 43
    assert token_1["married"]._start == 44
    assert token_1["married"]._end == 54

    str_2 = "entry1: {home: Bangalore, hobbies: [playing, reading], married: No}\n"
    token_

# Generated at 2022-06-26 10:51:28.753488
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'$\xe7\xaa\x9d\xb2\xba\xfa\xfb\xd1\xda\x03\xb2\xaaD\xe1\x7f\x19'
    str_0 = "---\nkey: value\n"
    str_1 = "--- !!map\n? str\n: int\n"
    str_2 = "--- !!map\n? !!str \"str\"\n: !!int 42\n"
    str_3 = "--- >\xafF\xb6h\xca%\xaf\xdeQss%~8`\n"
    str_4 = "--- \n42\n"
    str_5 = "--- \n42.0\n"

# Generated at 2022-06-26 10:51:40.038206
# Unit test for function validate_yaml
def test_validate_yaml():
    def check_validate_yaml(input, expected):
        error = None
        try:
            output = validate_yaml(input, expected)
        except Exception as e:
            error = e.__str__()
        assert (error == None), 'Got unexpected exception: ' + error
        assert (output == expected), 'Expected: ' + str(expected) + ', but got: ' + str(output)
    check_validate_yaml(b'', (None, []));
    check_validate_yaml(b'5', (None, []));
    check_validate_yaml(b'0.0', (None, []));
    check_validate_yaml(b'~', (None, []));
    check_validate_yaml(b'true', (None, []));