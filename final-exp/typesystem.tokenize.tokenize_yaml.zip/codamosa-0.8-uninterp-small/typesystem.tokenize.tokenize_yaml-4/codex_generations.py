

# Generated at 2022-06-26 10:41:53.698958
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    bytes_0 = b'\xec'
    token_0 = tokenize_yaml(bytes_0)
    assert token_0.pos_start == 0 and token_0.pos_end == 0 and token_0.content == bytes_0

    str_0 = '{'
    token_1 = tokenize_yaml(str_0)
    assert token_1.pos_start == 0 and token_1.pos_end == 0 and token_1.content == str_0

    str_1 = ""
    token_2 = tokenize_yaml(str_1)
    assert token_2.pos_start == 0 and token_2.pos_end == 0 and token_2.content == str_1

    str_2 = "hello!"


# Generated at 2022-06-26 10:42:01.106763
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert SafeLoader is not None, "'pyyaml' must be installed."

    bytes_0 = b'\xec'
    token_0 = tokenize_yaml(bytes_0)
    token_0.content == '\xec'
    token_0.start == 0
    token_0.end == 0

    str_1 = '\xec'
    str_2 = 'mapping'
    str_3 = '~'
    token_1 = tokenize_yaml(str_1)
    token_2 = tokenize_yaml(str_2)
    token_3 = tokenize_yaml(str_3)
    token_1.value == '\xec'
    token_2.value == 'mapping'
   

# Generated at 2022-06-26 10:42:10.857722
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content=b"\xec", validator=Field(type="string")) == (None, [{'code': 'parse_error', 'id': None, 'message': 'could not determine a constructor for the tag \'tag:yaml.org,2002:binary\'.', 'location': ''}])
    assert validate_yaml(content="""
        # This is a comment
        name: "John Smith" # This is another comment
        age: '23'
        """, validator=Field(type="string")) == (None, [{'code': 'parse_error', 'id': None, 'message': 'found unknown tag: name:1', 'location': 'name'}, {'code': 'parse_error', 'id': None, 'message': 'found unknown tag: age:3', 'location': 'age'}])


# Generated at 2022-06-26 10:42:12.249519
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert True



# Generated at 2022-06-26 10:42:21.549613
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    try:
        validate_yaml(b"", Field())
        assert False, "This should fail."
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "No content."
        assert exc.code == "no_content"

    try:
        validate_yaml(b"bad_yaml", Field())
        assert False, "This should fail."
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "found character 'b' that cannot start any token."
        assert exc.code == "parse_error"

# Generated at 2022-06-26 10:42:26.908603
# Unit test for function validate_yaml
def test_validate_yaml():
    assert _get_position(content="a\nbb\nccc\nddddd\neeeeeee", index=3) == Position(
        column_no=1, line_no=3, char_index=3
    )

    assert _get_position(content="a\nbb\nccc\nddddd\neeeeeee", index=12) == Position(
        column_no=1, line_no=5, char_index=12
    )

    assert _get_position(content="a\nbb\nccc\nddddd\neeeeeee", index=13) == Position(
        column_no=2, line_no=5, char_index=13
    )


# Generated at 2022-06-26 10:42:40.078496
# Unit test for function validate_yaml
def test_validate_yaml():

    # Validate a simple dictionary.
    class Address(Schema):
        city = Field(type="string")
        street = Field(type="string")

    class Person(Schema):
        address = Field(type="object", schema=Address)
        name = Field(type="string")
        age = Field(type="number")

    data = """\
    name: John
    age: 30
    address:
      street: Main St
      city: Boston
    """

    value, messages = validate_yaml(data, validator=Person)
    assert value == {
        "address": {"city": "Boston", "street": "Main St"},
        "age": 30.0,
        "name": "John",
    }
    assert not messages

    # Fail validation.

# Generated at 2022-06-26 10:42:54.587069
# Unit test for function validate_yaml
def test_validate_yaml():

    # TEST 1: Handle valid YAML
    content_1 = b'\xec\x94\xa1\xec'
    validator_1 = Field(validators=[])
    result_1 = validate_yaml(
        content_1,
        validator_1,
    )
    assert type(result_1) is (tuple, list)
    assert len(result_1) == 2
    assert type(result_1[0]) is ScalarToken
    assert type(result_1[1]) is (tuple, list)
    assert len(result_1[1]) == 0

    # TEST 2: Handle YAML parsing errors
    content_2 = b'\xec\x94\xa1\xec'
    validator_2 = Field(validators=[])
    result_2 = validate_y

# Generated at 2022-06-26 10:43:05.911667
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None

    assert isinstance(tokenize_yaml("{}"), DictToken)
    assert isinstance(tokenize_yaml("[]"), ListToken)
    assert isinstance(tokenize_yaml("1"), ScalarToken)

    with pytest.raises(ParseError):
        tokenize_yaml('[1, "two"]')

    with pytest.raises(ParseError):
        tokenize_yaml("")

    with pytest.raises(ParseError):
        tokenize_yaml('"invalid"')

    with pytest.raises(ParseError):
        tokenize_yaml("not a YAML mapping\n")

    with pytest.raises(ParseError):
        tokenize_yaml("{}\nnot a YAML mapping")



# Generated at 2022-06-26 10:43:14.457156
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Parameter "content"
    # Call function "tokenize_yaml"
    try:
        tokenize_yaml()
        # If function call returns normally,
        # it is considered an error.
        raise Exception(
            "Expected error not raised"
        )
    except TypeError as e:
        # Verify exception is expected one.
        assert str(e) == """tokenize_yaml() missing 1 required positional argument: 'content'"""



# Generated at 2022-06-26 10:43:30.675613
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.tokenize.schemas import BaseSchema
    
    class TestSchema(BaseSchema):
        field_0 = Field(type=int, required=True)
    
    
    
    
    
    # Test with positional errors.
    content_0 = b'field_0:\n    100\n'
    value_0, error_messages_0 = validate_yaml(content_0, TestSchema)
    if error_messages_0 != []:
        text_0 = error_messages_0[0].text
        code_0 = error_messages_0[0].code
        position_0 = error_messages_0[0].position
    else:
        text_0 = None  # type: ignore
        code_0 = None  # type: ignore
        position_0

# Generated at 2022-06-26 10:43:41.205805
# Unit test for function validate_yaml
def test_validate_yaml():
    # Ensure that a parse error is raised for a YAML string
    # with a syntax error.
    def try_parse_error():
        str_0 = '|j^]v9d<'
        token_0 = tokenize_yaml(str_0)
    assert_raises(ParseError, try_parse_error)

    class TestSchema(Schema):
        name = "Test"
        fields = {
            "foo": Field(str),
            "bar": Field(int),
            "baz": Field(bool),
        }

    yaml_str = """
        foo: hello world
        bar: 1
        baz: true
    """

    # Ensure that the parsed value is returned on a successful validation.

# Generated at 2022-06-26 10:43:42.385241
# Unit test for function validate_yaml
def test_validate_yaml():
    assert False, "Test not implemented"



# Generated at 2022-06-26 10:43:51.030741
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '{[(<|'
    token_0 = tokenize_yaml(str_0)
    str_1 = 'n\x17Ps'
    token_1 = tokenize_yaml(str_1)
    str_2 = '"o\\>|\\bp\x15\x18'
    token_2 = tokenize_yaml(str_2)
    str_3 = '"\\C\\|B'
    token_3 = tokenize_yaml(str_3)


# Generated at 2022-06-26 10:43:58.117537
# Unit test for function validate_yaml
def test_validate_yaml():
    content_0 = 'r\xfa\x18\x1a\xdb\xc0\xee\x85\xcd'
    result_0, messages_0 = validate_yaml(content=content_0, validator=int)
    assert result_0 == 6780187270801806564
    assert messages_0 == []

# Generated at 2022-06-26 10:44:04.807149
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '"Line 1\\nLine 2\\nLine 3"'
    validator = Field(type="string", format="multiline")
    assert validate_yaml(content, validator) == (
        'Line 1\nLine 2\nLine 3',
        None,
    )



# Generated at 2022-06-26 10:44:18.285729
# Unit test for function validate_yaml
def test_validate_yaml():

    class SomeSchema(Schema):
        a = Field(required=True, description="hello")
        b = Field(required=True, description="world")

    str_1 = b'{"a": 3, "b": 4.0}'
    tuple_1 = validate_yaml(str_1, SomeSchema)
    assert (tuple_1 == ({'a': 3, 'b': 4.0}, []))
    str_2 = b'{"a": 3.0, "b": 4.0}'
    tuple_2 = validate_yaml(str_2, SomeSchema)
    assert (tuple_2 == ({'a': 3, 'b': 4.0}, []))
    str_3 = b'{"a": "3", "b": "4.0"}'
    tuple_3 = validate_y

# Generated at 2022-06-26 10:44:30.596962
# Unit test for function validate_yaml
def test_validate_yaml():
    # Asserts that the following inputs and outputs match.

    schema = Schema("test_validate_yaml", [
        Field("string", description="string description", type="string"),
        Field("int", description="integer description", type="integer")
    ])

    # Valid data
    input_0 = b'{"string": "hello world", "int": 10}'
    output_0 = ({"string": "hello world", "int": 10}, [])
    assert output_0 == validate_yaml(input_0, schema)

    # Invalid data
    input_1 = b'string'
    with pytest.raises(ParseError) as exception_info:
        validate_yaml(input_1, schema)
    assert exception_info.value.text == "expected '<document start>', but found Scalar."


# Generated at 2022-06-26 10:44:41.397943
# Unit test for function validate_yaml
def test_validate_yaml():
    import os
    import pickle
    import pytest

    # If the expected output doesn't exist, save it
    if not os.path.exists('./test_cases/test_validate_yaml_out'):
        with open('./test_cases/test_validate_yaml_in', 'rb') as f:
            test_cases = pickle.load(f)
        with open('./test_cases/test_validate_yaml_out', 'wb') as f:
            pickle.dump(test_cases, f)
    else:
        with open('./test_cases/test_validate_yaml_out', 'rb') as f:
            test_cases = pickle.load(f)


# Generated at 2022-06-26 10:44:50.983307
# Unit test for function validate_yaml
def test_validate_yaml():
    test_input_0 = '|j^]v9d<'
    test_value_0 = validate_yaml(test_input_0, test_input_0)
    test_input_1 = '|j^]v9d<'
    test_value_1 = validate_yaml(test_input_1, test_input_1)
    test_input_2 = '|j^]v9d<'
    test_value_2 = validate_yaml(test_input_2, test_input_2)
    test_input_3 = '|j^]v9d<'
    test_value_3 = validate_yaml(test_input_3, test_input_3)

# Generated at 2022-06-26 10:45:01.095189
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '+@[gN'
    str_1 = 'H|]x+'
    str_2 = '/`\x7f'

    try:
        validate_yaml(str_0, str_1)
    except ValidationError as exc:
        messages = exc.messages
    else:
        assert False

    try:
        validate_yaml(str_0, str_2)
    except ParseError as exc:
        messages = exc.messages
    else:
        assert False

# Generated at 2022-06-26 10:45:10.918442
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|j^]v9d<'
    validator_0 = typesystem.fields.String()
    (value_0, messages_0) = validate_yaml(str_0, validator_0)
    str_1 = 'gQ2C!3[n'
    validator_1 = typesystem.fields.String()
    (value_1, messages_1) = validate_yaml(str_1, validator_1)
    str_2 = '0AQ8}t@$'
    validator_2 = typesystem.fields.String()
    (value_2, messages_2) = validate_yaml(str_2, validator_2)
    str_3 = '!)hD/wV7'
    validator_3 = typesystem.fields.String()

# Generated at 2022-06-26 10:45:12.345428
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True  # pragma: no cover

# Generated at 2022-06-26 10:45:22.895320
# Unit test for function validate_yaml
def test_validate_yaml():
    import typesystem
    import pytest

    class Person(typesystem.Schema):
        name = typesystem.String(max_length=200)
        age = typesystem.Integer(minimum=0)

    person_schema = Person()
    result = validate_yaml("name: Alice\nage: 21", person_schema)
    assert result == ({"name": "Alice", "age": 21}, None)
    with pytest.raises(ParseError):
        validate_yaml("I'm not a valid YAML document.", person_schema)
    with pytest.raises(ValidationError):
        validate_yaml("name: 'Alice'", person_schema)

# Generated at 2022-06-26 10:45:27.616202
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b'_%1+>u}'
    validator = Field()
    value, error_messages = validate_yaml(content, validator)
    assert error_messages == []


# Generated at 2022-06-26 10:45:34.921320
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test missing values
    msg = Message(code='missing', text='Missing a required field: "full_name".', position=Position(column_no=1, line_no=1, char_index=0),)
    error_messages_0 = [msg]
    token_0 = tokenize_yaml("")
    value_0, error_messages_1 = validate_with_positions(token=token_0, validator=TestSchema)
    assertEqual(error_messages_0, error_messages_1)
    # Test invalid values
    msg_1 = Message(code='invalid_type', text='"full_name" must be a string type.', position=Position(column_no=1, line_no=1, char_index=0),)

# Generated at 2022-06-26 10:45:47.864831
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = ""
    str_1 = " "
    str_2 = "a"
    validator = Field()

    assert validate_yaml(content = str_0, validator = validator) == (None, [
        Message(text="No content.", code="no_content", position=Position(column_no=1, line_no=1, char_index=0))
    ])
    assert validate_yaml(content = str_1, validator = validator) == ("", [
        Message(text="Expected a value.", code="null_value", position=Position(column_no=2, line_no=1, char_index=1))
    ])

# Generated at 2022-06-26 10:46:00.978714
# Unit test for function validate_yaml
def test_validate_yaml():

    class TestSchema(Schema):
        my_field = Field(type="string")

    value, error_messages = validate_yaml(
        content='{myField: 123}', validator=TestSchema
    )
    assert value == {"my_field": "123"}
    assert [m.text for m in error_messages] == [
        "Value must be of type 'string'."
    ]

    value, error_messages = validate_yaml(
        content='{myFielX: 123}', validator=TestSchema
    )
    assert value == {}
    assert [m.text for m in error_messages] == [
        "Object key 'myFielX' not found."
    ]


# Generated at 2022-06-26 10:46:08.978957
# Unit test for function validate_yaml
def test_validate_yaml():
    content_0 = '<\bK&'
    validator_0 = Field(required=True, primitive_type=str)
    value_0, error_messages_0 = validate_yaml(content_0, validator_0)
    assert value_0 is None
    assert isinstance(error_messages_0[0], ValidationError)



# Generated at 2022-06-26 10:46:22.065104
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|j^]v9d<'
    token_0 = tokenize_yaml(str_0)

    try:
        _, error_messages = validate_yaml(
            content=token_0, validator=Field(type="number")
        )
    except ValidationError as exc:
        error_messages = [message.to_dict() for message in exc.messages]


# Generated at 2022-06-26 10:46:35.196187
# Unit test for function validate_yaml
def test_validate_yaml():

    assert yaml is not None, "'pyyaml' must be installed."


    class User(Schema):
        name = String()


    str_0 = '|j^]v9d<'
    value_0, error_msgs_0 = validate_yaml(str_0, User)
    assert value_0 is None, 'expected: %s but got: %s' % (None, value_0)


# Generated at 2022-06-26 10:46:45.735994
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '\n123\n\n'
    value_0, messages_0 = validate_yaml(str_0, field=Field(type="integer"))
    assert(value_0 == 123)
    assert(len(messages_0) == 0)
    str_1 = '\n123\n\n'
    value_1, messages_1 = validate_yaml(str_1, field=Field(type="string"))
    assert(value_1 is None)
    assert(len(messages_1) == 1)
    message_0 = messages_1[0]
    assert(message_0.code == 'invalid_type')
    assert(message_0.text == 'Must be a string.')
    assert(message_0.full_text == 'Must be a string.')

# Generated at 2022-06-26 10:46:56.016184
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|j^]v9d<'
    token_0 = tokenize_yaml(str_0)
    assert token_0.start == 0, "Validating value of string '|j^]v9d<'"
    assert token_0.end == 7, "Validating value of string '|j^]v9d<'"
    assert token_0.value == '|j^]v9d<', "Validating value of string '|j^]v9d<'"
    assert token_0.content == '|j^]v9d<', "Validating value of string '|j^]v9d<'"
    str_1 = '\n\n\n'
    token_1 = tokenize_yaml(str_1)

# Generated at 2022-06-26 10:47:02.901748
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '|j^]v9d<'
    token_0 = tokenize_yaml(str_0)
    assert token_0.value == '|j^]v9d<'
    assert token_0.start == 0
    assert token_0.end == 7
    assert token_0.content == '|j^]v9d<'


# Generated at 2022-06-26 10:47:11.811137
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test schema class
    class TestSchema(Schema):
        a: str
        b: int
        c: typing.Optional[str]

    # Test content and expected value
    str_0 = 'a: foo\nb: 100\nc: bar'
    value_0 = TestSchema({'a': 'foo', 'b': 100, 'c': 'bar'})

    # Test str_0 against TestSchema
    (value, errors) = validate_yaml(str_0, TestSchema)
    assert value == value_0
    assert errors == []

    # Test schema field
    field = Field(key='a', required=True, type=str)

    # Test content and expected value
    str_1 = 'foo'
    value_1 = 'foo'

    # Test str_1 against schema field

# Generated at 2022-06-26 10:47:21.459307
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize import tokens

    assert yaml is not None, "'pyyaml' must be installed."

    assert tokenize_yaml("hello") == ScalarToken(
        value="hello", start=0, end=4, content="hello"
    )
    assert tokenize_yaml("true") == ScalarToken(
        value=True, start=0, end=3, content="true"
    )
    assert isinstance(tokenize_yaml("true"), ScalarToken)
    assert tokenize_yaml("[1, 2, 3]") == ListToken(
        value=[1, 2, 3], start=0, end=7, content="[1, 2, 3]"
    )
    assert isinstance(tokenize_yaml("[1, 2, 3]"), ListToken)
    assert tokenize_

# Generated at 2022-06-26 10:47:23.562782
# Unit test for function validate_yaml
def test_validate_yaml():
    assert 1 == 1
    pass


# Generated at 2022-06-26 10:47:26.456597
# Unit test for function validate_yaml
def test_validate_yaml():
    assert isinstance(validate_yaml(str_0, token_0), tuple)


# Generated at 2022-06-26 10:47:34.669959
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|j^]v9d<'
    validator_0 = Field(str)
    value, errors = validate_yaml(str_0, validator_0)
    assert errors[0].position.column_no == 1
    assert errors[0].position.line_no == 1
    assert errors[0].position.char_index == 0
    assert errors[0].text == "Unable to parse YAML."
    assert errors[0].code == "parse_error"

    str_0 = "  Line1\nLine2\nLine3"
    validator_0 = Field(str)
    value_0, errors = validate_yaml(str_0, validator_0)
    assert value_0 == "  Line1\nLine2\nLine3"
    assert errors == []



# Generated at 2022-06-26 10:47:43.506051
# Unit test for function validate_yaml
def test_validate_yaml():
    c0 = 'dwT{tu'
    c1 = '[-]xg'
    c2 = 'hY,p|'
    c3 = 'VT&U6'
    c4 = '-0Q2I'
    c5 = '`:5:5'
    c6 = '+<-y9'
    c7 = '!a@!z'
    c8 = '4^;g<'
    c9 = 'E*SvS'
    v0 = Field(name='A', type='string', min_length=2)
    v1 = Field(name='B', type='array', items=Field(name='A', type='string', max_length=3))

# Generated at 2022-06-26 10:47:55.834849
# Unit test for function validate_yaml
def test_validate_yaml():
    def string_field() -> Field:
        return Field(type=str)

    def number_field() -> Field:
        return Field(type=float)

    def list_field() -> Field:
        return Field(type=list)

    def dict_field() -> Field:
        return Field()

    class TestSchema(Schema):
        name = string_field()

    class TestListSchema(Schema):
        users = list_field().of_type(TestSchema)

    class TestDictSchema(Schema):
        stats = dict_field().of_type(TestSchema)

    def test_valid_yaml():
        yaml_content = """
name: John
"""
        value, error_messages = validate_yaml(yaml_content, validator=TestSchema)

# Generated at 2022-06-26 10:48:07.914774
# Unit test for function validate_yaml
def test_validate_yaml():
    content = ""
    validator = Field()

    (result, error_messages) = validate_yaml(content, validator)

    assert error_messages == [
        Message(
            text="No content.",
            code="parse_error",
            position=Position(char_index=0, column_no=1, line_no=1),
        )
    ]

    assert result is None

    content = "123"
    validator = Field(type="integer", min_length=5)

    (result, error_messages) = validate_yaml(content, validator)


# Generated at 2022-06-26 10:48:16.244801
# Unit test for function validate_yaml
def test_validate_yaml():
    assert 'validate_yaml' in globals()  # required by Tup
    assert 'tokenize_yaml' in globals()  # required by Tup

    str_0 = '[1, 2, 3], (1, 2, 3), [abc: val]'
    token_0 = tokenize_yaml(str_0)
    value, error_messages = validate_yaml(str_0, list)
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 1
    assert error_messages[0].code == 'parse_error'
    assert error_messages[0].text == 'while scanning a block scalar'
    assert error_messages[0].position.char_index == 0
    assert error_messages[1].position.line

# Generated at 2022-06-26 10:48:25.085086
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    int_field = Field(description="description", name="name")
    int_field.validate(value=1)
    int_field.validate(value=2)
    int_field.validate(value=3)

    float_field = Field(description="description", name="name")
    float_field.validate(value=1.0)
    float_field.validate(value=2.0)
    float_field.validate(value=3.0)

    schema = Schema(description="description", name="name")
    schema.fields = {
        "a": int_field,
        "b": float_field,
    }

    int_field = Field(description="description", name="name")
    int_field.valid

# Generated at 2022-06-26 10:48:36.356687
# Unit test for function validate_yaml
def test_validate_yaml():
    class FooSchema(Schema):
        name = fields.StringField(description="Field description.")
        age = fields.IntegerField(description="Field description.")
    str_0 = '''name: gxkI'Hp
age: -j^]v9d<'''
    token_0 = tokenize_yaml(str_0)
    assert [str(x) for x in token_0.error_messages] == [
        'Expected "name" to be a string.',
        'Expected "age" to be an integer.',
    ]
    value, error_messages = validate_yaml(str_0, FooSchema)

# Generated at 2022-06-26 10:48:41.721610
# Unit test for function validate_yaml
def test_validate_yaml():
    print('test_validate_yaml')

# Generated at 2022-06-26 10:48:54.750384
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = typing.TypeVar('schema', bound='BaseSchema')
    class BaseSchema(Schema):
        text = Field(type='string', name='text')
        intval = Field(type='integer', name='intval')

    str_0 = 'text: this is a string\nintval: 20'
    value_0, errors_0 = validate_yaml(str_0, BaseSchema)

    str_1 = 'text: this is a string\nintval: twenty'
    value_1, errors_1 = validate_yaml(str_1, BaseSchema)

    str_2 = 'text: this is a string\n'
    value_2, errors_2 = validate_yaml(str_2, BaseSchema)

    str_3 = 'intval: 20\n'
    value

# Generated at 2022-06-26 10:48:56.761265
# Unit test for function validate_yaml
def test_validate_yaml():
    print("\nTesting validate_yaml")


# Generated at 2022-06-26 10:49:02.868636
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestValidator(Schema):
        foo = Field(typing.Optional[str])

    assert (
        validate_yaml(
            '''foo: bar''',
            validator=TestValidator
        )
        ==  # noqa: E123
        ({'foo': 'bar'}, [])
    )



# Generated at 2022-06-26 10:49:14.751190
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|j^]v9d<'
    str_1 = 'nj23<x_'
    str_2 = '~3H4j+aM'
    str_3 = 'Y3d\'H!c'
    str_4 = 'fye;z'
    str_5 = ''
    assert isinstance(validate_yaml(str_0, str_1), tuple)
    assert isinstance(validate_yaml(str_2, str_3), tuple)
    assert isinstance(validate_yaml(str_4, str_5), tuple)

if __name__ == '__main__':
    test_case_0()
    test_validate_yaml()

# Generated at 2022-06-26 10:49:25.980774
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Schema(
        {
            "foo": Field(str),
            "bar": Field(str),
            "baz": Field(str, required=False),
        },
        required=["foo", "bar"],
    )

    content = """
    foo: hello
    bar: goodbye
    """
    value = validate_yaml(content, validator)
    assert value == ({"bar": "goodbye", "foo": "hello"}, [])

    content = """
    foo: hello
    bar: goodbye
    foobar: goodbye
    """

    value = validate_yaml(content, validator)
    assert len(value[1]) == 1
    assert value[1][0].text == "Additional properties are not allowed: foobar."


# Generated at 2022-06-26 10:49:30.664078
# Unit test for function validate_yaml
def test_validate_yaml():
    # Asserts that validate_yaml returns the result of the function 'validate_with_positions'
    assert validate_with_positions == validate_yaml

# Generated at 2022-06-26 10:49:35.122388
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = 'name: "John"'
    validator_1 = {'name': str}
    value_1, error_messages_1 = validate_yaml(str_1, validator_1)
    assert(value_1 == {'name': 'John'})
    assert(len(error_messages_1) == 0)

# Generated at 2022-06-26 10:49:36.596466
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert True



# Generated at 2022-06-26 10:49:47.090946
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '|j^]v9d<'
    token_0 = tokenize_yaml(str_0)
    assert token_0.token_type == "DictToken"
    str_1 = '123.456'
    token_1 = tokenize_yaml(str_1)
    assert token_1.token_type == "ScalarToken"
    str_2 = '123'
    token_2 = tokenize_yaml(str_2)
    assert token_2.token_type == "ScalarToken"
    str_3 = '123.456'
    token_3 = tokenize_yaml(str_3)
    assert token_3.token_type == "ScalarToken"
    str_4 = '123.456'
    token_4 = tokenize_yaml

# Generated at 2022-06-26 10:49:52.490558
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = String(required=True)
    value, error_messages = validate_yaml('hello', validator)
    assert value == 'hello'
    assert not error_messages


# Generated at 2022-06-26 10:50:00.096104
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|j^]v9d<'
    error_result_0 = validate_yaml(str_0, str)
    print(error_result_0)
    str_1 = '}=x!9P$\x0cRg\x0c'
    error_result_1 = validate_yaml(str_1, str)
    print(error_result_1)
    str_2 = '5zY 5~L\x0c4O'
    error_result_2 = validate_yaml(str_2, str)
    print(error_result_2)
    str_3 = '|j^]v9d<'
    error_result_3 = validate_yaml(str_3, str)
    print(error_result_3)

# Generated at 2022-06-26 10:50:06.844372
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '|j^]v9d<'
    validator = 'PbD<'
    assert validate_yaml(content, validator) == (
        False,
        [
            Message(
                text="No content.",
                code="no_content",
                position=Position(line_no=1, column_no=1, char_index=0),
            )
        ],
    )

# Generated at 2022-06-26 10:50:18.467832
# Unit test for function validate_yaml
def test_validate_yaml():

    content = "foo: bar"
    validator = Field()
    value, errors = validate_yaml(content, validator)
    assert value == {"foo": "bar"}
    assert errors == []

    content = "foo: !foo [1, 2, 3]"
    validator = Field(scalar_kinds=("int", "string"))
    value, errors = validate_yaml(content, validator)
    assert value == {"foo": "!foo [1, 2, 3]"}
    assert errors == []

    content = "foo: 1"
    validator = Field(scalar_kinds=("string",))
    value, errors = validate_yaml(content, validator)

# Generated at 2022-06-26 10:50:28.312093
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    str_0 = "num: '123'"
    validator_0 = Field(type="integer")
    result = validate_yaml(str_0, validator_0)
    assert result == (123, [])

    str_1 = 'num: "123"'
    validator_1 = Field(type="integer")
    result_1 = validate_yaml(str_1, validator_1)
    assert result_1 == (123, [])

    str_2 = "num: 123"
    validator_2 = Field(type="integer")
    result_2 = validate_yaml(str_2, validator_2)
    assert result_2 == (123, [])

    str_3 = "num: '123'"
    validator

# Generated at 2022-06-26 10:50:32.164317
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True



# Generated at 2022-06-26 10:50:43.493172
# Unit test for function validate_yaml
def test_validate_yaml():

    class Address(Schema):
        address = Field(types=str)
        city = Field(types=str)
        zip_code = Field(types=int)

    class Customer(Schema):
        email = Field(types=str)
        name = Field(types=str)
        age = Field(types=int)
        address = Field(types=Address)

    class CustomerV3(Schema):
        email = Field(types=str)
        name = Field(types=str)
        age = Field(types=int)

    class CustomerV2(Schema):
        name = Field(types=str)
        email = Field(types=str)
        address = Field(types=Address, required=False)

    class CustomerV1(Schema):
        name = Field(types=str)

# Generated at 2022-06-26 10:50:55.117060
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|j^]v9d<'
    token_0 = tokenize_yaml(str_0)
    validator_0 = String(max_length=36)
    value_0, errors_0 = validate_yaml(str_0, validator_0)
    assert value_0 is None
    assert len(errors_0) == 1
    assert isinstance(errors_0[0], ValidationError)
    assert errors_0[0].text == 'Must be smaller than 36 characters.'
    assert errors_0[0].field == 'data'
    assert errors_0[0].code == 'max_length'
    assert errors_0[0].position == Position(1, 1, 0)
    validator_1 = String(min_length=36)
    value_1, errors_1 = validate

# Generated at 2022-06-26 10:51:07.725242
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|j^]v9d<'
    token_0 = tokenize_yaml(str_0)
    assert token_0 == str_0
    str_1 = '|j^]v9d<'
    token_1 = tokenize_yaml(str_1)
    assert token_1 == str_1
    str_2 = '|j^]v9d<'
    token_2 = tokenize_yaml(str_2)
    assert token_2 == str_2
    str_3 = '|j^]v9d<'
    token_3 = tokenize_yaml(str_3)
    assert token_3 == str_3
    str_4 = '|j^]v9d<'
    token_4 = tokenize_yaml(str_4)

# Generated at 2022-06-26 10:51:13.155374
# Unit test for function validate_yaml
def test_validate_yaml():

    import random
    from typesystem import (
        Integer,
        Object,
        String,
    )
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String()
        age = Integer()

    # Test an empty string case.
    try:
        validate_yaml(content="", validator=TestSchema)
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
        assert str(exc) == "ParseError at 1:1 (0): No content."

    # Test a valid case.
    content = """
    name: Testie
    age: 20
    """


# Generated at 2022-06-26 10:51:17.035539
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = 'q3}Z>'
    token = tokenize_yaml(str_1)

    assert token.content == str_1

# Generated at 2022-06-26 10:51:28.523461
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '|j^]v9d<'
    token_0 = tokenize_yaml(str_0)
    str_1 = 't[f=G7YB'
    token_1 = tokenize_yaml(str_1)
    str_2 = '\n  A:]w0Y'
    token_2 = tokenize_yaml(str_2)
    str_3 = 'n1&\n  g'
    token_3 = tokenize_yaml(str_3)
    str_4 = '5=t[k7V'
    token_4 = tokenize_yaml(str_4)
    str_5 = 'Kl'
    token_5 = tokenize_yaml(str_5)
    str_6 = 'p'
    token_6 = token

# Generated at 2022-06-26 10:51:34.287245
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '|j^]v9d<'
    value_0, errors_0 = validate_yaml(
        str_0, validator=Field(name="test", type="text", min_length=10)
    )

# Generated at 2022-06-26 10:51:46.582279
# Unit test for function validate_yaml