

# Generated at 2022-06-26 10:41:58.516227
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class MyField(Field):
        def validate(self, value):
            raise ValidationError("Invalid.")

    content = "hello: world\n"
    result, messages = validate_yaml(content, MyField())
    assert isinstance(result, DictToken)
    assert isinstance(messages, list)
    assert len(messages) == 1
    assert messages[0].text == "Invalid."

    class MySchema(Schema):
        name = MyField()

    content = "name: world\n"
    result, messages = validate_yaml(content, MySchema)
    assert isinstance(result, DictToken)
    assert isinstance(messages, list)
    assert len(messages) == 1

# Generated at 2022-06-26 10:42:09.866675
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = 'foo: bar'
    errors_1 = validate_yaml(str_1, validator=Schema)
    assert errors_1 == [Message(text="Expected a dict.", code="required")]
    str_2 = 'foo: bar'
    errors_2 = validate_yaml(str_2, validator=Field)
    assert errors_2 == [Message(text="Expected a dict.", code="required")]
    str_3 = 'foo: bar'
    errors_3 = validate_yaml(str_3, validator=Schema)
    assert errors_3 == [Message(text="Expected a dict.", code="required")]
    str_4 = 'foo: bar'
    errors_4 = validate_yaml(str_4, validator=Field)

# Generated at 2022-06-26 10:42:14.445276
# Unit test for function tokenize_yaml

# Generated at 2022-06-26 10:42:21.164876
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    class CustomSafeLoader(SafeLoader):
        pass

    def construct_mapping(loader: "yaml.Loader", node: "yaml.Node") -> DictToken:
        start = node.start_mark.index
        end = node.end_mark.index
        mapping = loader.construct_mapping(node)
        return DictToken(mapping, start, end - 1, content=str_content)

    def construct_sequence(loader: "yaml.Loader", node: "yaml.Node") -> ListToken:
        start = node.start_mark.index
        end = node.end_mark.index
        value = loader.construct_sequence(node)
        return ListToken(value, start, end - 1, content=str_content)

   

# Generated at 2022-06-26 10:42:21.828376
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert False # FIXME


# Generated at 2022-06-26 10:42:33.410102
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*"$4Bf!D'
    token_0 = tokenize_yaml(str_0)
    assert token_0 is not None
    try:
        ParseError = validate_yaml(str_0, str_0)
    except ParseError as error:
        assert error is not None
    token_1 = tokenize_yaml(str_0)
    assert token_1 is not None
    try:
        ParseError = validate_yaml(str_0, str_0)
    except ParseError as error:
        assert error is not None
        assert error.code == 'parse_error'
        assert error.text == 'mapping values are not allowed here.'
        assert error.position is not None
        assert error.position.line_no == 1

# Generated at 2022-06-26 10:42:42.140306
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from yaml.scanner import ScannerError
    from yaml.parser import ParserError

    with pytest.raises(ParseError):
        tokenize_yaml("")
    with pytest.raises(ParseError):
        tokenize_yaml("{")
    with pytest.raises(ParseError):
        tokenize_yaml("[")
    with pytest.raises(ParseError):
        tokenize_yaml("[1, 2, 3")
    with pytest.raises(ParseError):
        tokenize_yaml("[1, 2, 3 ")
    with pytest.raises(ParseError):
        tokenize_yaml("[1, 2, 3   ")

# Generated at 2022-06-26 10:42:55.106970
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # check that the first 32 characters in str_0 correspond to the first
    # 32 characters in token_0.value and that these characters are the
    # start (index 0) of token_0.content
    str_0 = '*"$4Bf!D'
    token_0 = tokenize_yaml(str_0)
    assert str_0[0:32] == token_0.value
    assert 0 == token_0.start
    assert len(str_0) - 1 == token_0.end
    assert str_0 == token_0.content

    # check that the first 31 characters in str_1 correspond to the first
    # 31 characters in token_1.value and that these characters are the
    # start (index 0) of token_1.content

# Generated at 2022-06-26 10:43:05.421032
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    with pytest.raises(ParseError):
        empty_str = ""
        tokenize_yaml(empty_str)

    assert tokenize_yaml("a") == "a"
    assert tokenize_yaml("'a'") == "a"
    assert tokenize_yaml('"a"') == "a"
    assert tokenize_yaml("1") == 1
    assert tokenize_yaml("3.2") == 3.2
    assert tokenize_yaml("True") is True
    assert tokenize_yaml("y") is True
    assert tokenize_yaml("Yes") is True
    assert tokenize_yaml("False") is False
    assert tokenize_yaml("n") is False
    assert tokenize_

# Generated at 2022-06-26 10:43:11.771195
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '''
    user:
      name: str
    '''
    str_1 = '''
    user:
      name2: str
    '''
    fields_0 = {'name': 'string'}
    fields_1 = {'name2': 'string'}
    expected_0 = (
        {'user': {'name': 'str'}},
        [],
    )
    expected_1 = (
        {'user': {'name2': 'str'}},
        [],
    )

# Generated at 2022-06-26 10:43:28.079779
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Parse error.
    str_0 = """a:
  b:
    c: 4738
"""
    str_1 = """a:
  b:
    c: 4738
"""
    # Parse error.
    str_2 = """a:
  b:
    c: 4738
  d:
    e: -7
"""
    str_3 = """a: *yyc
"""
    str_4 = """a: *yyc
b:
  - 8
  - 7
  - 6
c:
  d:
    e:
      f: false
      g: null
      h: 221
"""
    str_5 = """a: 8
b: yyc
c:
  - 5
  - 3
"""

# Generated at 2022-06-26 10:43:36.253457
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Setup
    str_0 = '"123440"\n'

    # Invoke function
    token_0 = tokenize_yaml(str_0)

    # Check for correct output
    assert token_0.value == "123440"
    assert token_0.start == 1
    assert token_0.end == 8



# Generated at 2022-06-26 10:43:48.698164
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*"$4Bf!D'
    token_0 = tokenize_yaml(str_0)
    token_0 = tokenize_yaml(str_0)
    str_1 = '*"$4Bf!D'
    str_2 = '*"$4Bf!D'
    token_1 = tokenize_yaml(str_2)
    content_1 = str_2
    token_2 = tokenize_yaml(content_1)
    str_3 = '*"$4Bf!D'
    str_4 = '*"$4Bf!D'
    token_3 = tokenize_yaml(str_4)
    str_5 = '*"$4Bf!D'

# Generated at 2022-06-26 10:43:56.504475
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('null') is None
    assert tokenize_yaml('true') is True
    assert tokenize_yaml('! True | false') is False
    assert tokenize_yaml('3.14') == 3.14
    assert tokenize_yaml('1.2+3.4') == 1.2 + 3.4
    assert tokenize_yaml('"Foo"') == "Foo"
    assert tokenize_yaml("'Foo'") == "Foo"
    assert tokenize_yaml("'Foo\nBar'") == "Foo\nBar"
    assert tokenize_yaml("'''Foo\nBar'''") == "Foo\nBar"

# Generated at 2022-06-26 10:44:08.746789
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "abc"
    position_0 = Position(column_no=1, line_no=1, char_index=0)
    scalar_0 = ScalarToken("abc", 0, 2, str_0)

    token_0 = tokenize_yaml(str_0)
    assert token_0.value == scalar_0.value
    assert token_0.start_byte == scalar_0.start_byte
    assert token_0.end_byte == scalar_0.end_byte
    assert token_0.content == scalar_0.content
    assert token_0.get_position(0) == position_0

    str_1 = "- abc"
    position_1 = Position(column_no=2, line_no=1, char_index=1)
    position_2 = Position

# Generated at 2022-06-26 10:44:19.720548
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Testing if tokenize_yaml throws an exception when yaml is not installed.
    import pytest
    with pytest.raises(ImportError):
        assert tokenize_yaml(None)
    assert tokenize_yaml('"hello world"') == ScalarToken('hello world', 0, 12)
    assert tokenize_yaml('5') == ScalarToken('5', 0, 1)
    assert tokenize_yaml('5.5') == ScalarToken('5.5', 0, 3)
    assert tokenize_yaml('null') == ScalarToken('null', 0, 4)
    assert tokenize_yaml('true') == ScalarToken('true', 0, 4)
    assert tokenize_yaml('false') == ScalarToken('false', 0, 5)

# Generated at 2022-06-26 10:44:25.952147
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = "[{'a': 0, 'b': [1, 2]}, 1, 2, 3]"
    token_0 = tokenize_yaml(str_0)
    list_0 = [
        DictToken({'a': ScalarToken(0, 3, 3, content=str_0), 'b': ListToken([ScalarToken(1, 11, 11, content=str_0), ScalarToken(2, 14, 14, content=str_0)], 10, 15, content=str_0)}, 2, 16, content=str_0), 
        ScalarToken(1, 18, 18, content=str_0), 
        ScalarToken(2, 21, 21, content=str_0), 
        ScalarToken(3, 24, 24, content=str_0)
    ]

# Generated at 2022-06-26 10:44:37.818496
# Unit test for function validate_yaml
def test_validate_yaml():
    class Example(Schema):
        name = "string"

    assert validate_yaml(
        content="name: Alex", validator=Example
    ) == ({"name": "Alex"}, None)

    errors = validate_yaml(content="name: 123", validator=Example)[1]
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)
    assert errors[0].position.char_index == 6
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 7
    assert errors[0].code == "string"
    assert errors[0].text == "Must be of type 'string'."


# Generated at 2022-06-26 10:44:40.904242
# Unit test for function validate_yaml
def test_validate_yaml():
    test_case_0()
    print("Pass")


if __name__ == "__main__":
    test_validate_yaml()

# Generated at 2022-06-26 10:44:45.489171
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    try:
        assert tokenize_yaml is not None
    except:
        print("Could not import tokenize_yaml from: {}".format(__name__))
        raise
    


# Generated at 2022-06-26 10:45:02.457952
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*"$4Bf!D'
    str_1 = '...'
    str_2 = '] :@'
    str_3 = '?'
    str_4 = '*'
    str_5 = '*^#'
    str_6 = 'y'
    str_7 = 'h'
    str_8 = '...'
    str_9 = '^)1'
    str_10 = 'l'
    str_11 = 'K'
    str_12 = 'z'
    str_13 = '2'
    str_14 = 'R+'
    str_15 = 'm'
    str_16 = 'z'
    str_17 = '$'
    str_18 = '6'
    str_19 = ')'
    str_20 = ''


# Generated at 2022-06-26 10:45:11.454808
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test case 0
    str_0 = '#1.0\n#Hello\nname: John Doe\nage:  43\nchildren:\n    -\n        name: Alice\n        age: 5\nname:\n-\n    name: Alice\n    age: 5\n    name: Alice\n    age: 5\n    children:\n        name: Alice\n        age: 5\n        name: Alice\n        age: 5\n        name: Alice\n        age: 5\n        children:\n            name: Alice\n            age: 5\n'
    str_1 = 'name: John Doe\nage: 43\nchildren:\n    - name: Alice\n      age: 5\n    - name: Bob\n      age: 8\n'

# Generated at 2022-06-26 10:45:20.452847
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "a"
    str_1 = 3
    token_0 = tokenize_yaml(str_0)
    token_1 = tokenize_yaml(str_1)
    ret_0, ret_1 = validate_yaml(str_0, token_0)
    ret_2, ret_3 = validate_yaml(str_1, token_1)
    assert ret_0 == "a"
    assert ret_1 is None
    assert ret_2 == 3
    assert ret_3 is None

# Generated at 2022-06-26 10:45:32.050399
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = "TestSchema"
        fields = {"value": Field(type="string")}

    integer_field = Field(type="integer")
    string_field = Field(type="string")

    # Test cases with a schema.
    schema = TestSchema()
    content = "value: foo"
    value, errors = validate_yaml(content, validator=schema)
    assert value == {"value": "foo"}
    assert errors == []

    content = "value: foo\n"
    value, errors = validate_yaml(content, validator=schema)
    assert value == {"value": "foo"}
    assert errors == []

    content = "value: 3\n"
    value, errors = validate_yaml(content, validator=schema)
    assert value

# Generated at 2022-06-26 10:45:41.063683
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*"$4Bf!D'
    list_0 = ['F', '!', '"', 'D', '$', 'B', '4']
    value_0, error_messages_0 = validate_yaml(str_0, list_0)
    str_1 = '[]'
    dict_0 = {}
    value_1, error_messages_1 = validate_yaml(str_1, dict_0)
    str_2 = '[]'
    list_1 = []
    value_2, error_messages_2 = validate_yaml(str_2, list_1)
    list_2 = ['F', '!', '"', 'D', '$', 'B', '4']

# Generated at 2022-06-26 10:45:51.752028
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import MetaSchema
    from typesystem import String
    from typesystem import fields
    content = """
    {
      "username": 123,
      "email": "jane@doe.com",
      "profile": null
    }
    """
    validator = MetaSchema()
    value, messages = validate_yaml(content, validator)
    content = "123"
    validator = fields.String()
    value, messages = validate_yaml(content, validator)
    content = "foobar"
    validator = fields.String()
    value, messages = validate_yaml(content, validator)
    content = "foobar"
    validator = fields.String(min_length=3)
    value, messages = validate_yaml(content, validator)

# Generated at 2022-06-26 10:46:02.690527
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*"$4Bf!D'
    token_0 = tokenize_yaml(str_0)
    assert token_0 == (*"$4Bf!D", 0, 9, '')
    str_1 = '\n#\n'
    token_1 = tokenize_yaml(str_1)
    assert token_1 == ('#', 1, 1, '')
    str_2 = '\n"\n'
    token_2 = tokenize_yaml(str_2)
    assert token_2 == ('', 1, 1, '')
    str_3 = '\n\'\n'
    token_3 = tokenize_yaml(str_3)
    assert token_3 == ('', 1, 1, '')

# Generated at 2022-06-26 10:46:14.173024
# Unit test for function validate_yaml
def test_validate_yaml():
    content_0 = ("*'$4Bf!D")
    validator_0 = "8y/_&5!3Kdg?k+"
    result_0 = validate_yaml(content_0, validator_0)

    content_1 = ("P!J'CM2e{C")
    validator_1 = ("*'$4Bf!D")
    result_1 = validate_yaml(content_1, validator_1)

    content_2 = "A+8]jM'e"
    validator_2 = "8y/_&5!3Kdg?k+"
    result_2 = validate_yaml(content_2, validator_2)

    content_3 = "P!J'CM2e{C"

# Generated at 2022-06-26 10:46:15.370652
# Unit test for function validate_yaml
def test_validate_yaml():
    with pytest.raises(ValueError):
        validate_yaml("abc", "abc")

# Testing with validator of type Field and valid data

# Generated at 2022-06-26 10:46:20.071478
# Unit test for function validate_yaml
def test_validate_yaml():
    # Tests for function validate_yaml.

    # Test 1
    class Validator1(Schema):
        a = Field(type="integer", strict=True)

    str_1 = "a: 'hello'"
    value_1, errors_1 = validate_yaml(str_1, Validator1)
    assert (
        errors_1[0].text == "Field a is not an integer."
        and errors_1[0].code == "not_integer"
        and errors_1[0].position.line_no == 1
        and errors_1[0].position.column_no == 5
        and errors_1[0].position.char_index == 4
        and len(errors_1) == 1
    )
    assert value_1 is None

    # Test 2

# Generated at 2022-06-26 10:46:34.125731
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*"$4Bf!D'
    validator_0 = 'yaml'
    str_1 = '*"$4Bf!D'
    validator_1 = b'yaml'
    str_2 = '*"$4Bf!D'
    validator_2 = bytearray('yaml', 'utf-8')
    validator_3 = 42
    validator_4 = [42]
    validator_5 = {42: 42}
    str_6 = '*"$4Bf!D'
    validator_6 = {'yaml': 42}
    str_7 = '*"$4Bf!D'
    validator_7 = {42: {'yaml': 42}}
    str_8 = '*"$4Bf!D'

# Generated at 2022-06-26 10:46:43.895698
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_str = """\
    # Top level heading.
    ---
    # Second level text.
    This is some text.

    # Third level text.
    More text.
    """

    items = [
        Message(text="Second level text.", code="illegal_heading_level"),
        Message(text="Third level text.", code="illegal_heading_level"),
        Message(text="Third level text.", code="no_heading_content"),
    ]

# Generated at 2022-06-26 10:46:52.458420
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*"$4Bf!D'
    value_0, error_messages_0 = validate_yaml(str_0, str)
    assert error_messages_0[0].text == "invalid literal for int() with base 10: '*\"$4Bf!D'"
    assert error_messages_0[0].code == "parse_error"
    assert error_messages_0[0].position.line_no == 1
    assert error_messages_0[0].position.column_no == 1
    assert error_messages_0[0].position.char_index == 0


# Generated at 2022-06-26 10:47:05.985020
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # str_0 - main
    str_0 = '*"$4Bf!D'
    assert tokenize_yaml(str_0).__class__.__name__ == "ListToken"
    # str_1 - main
    str_1 = '---\nkey: value\n'
    assert tokenize_yaml(str_1).__class__.__name__ == "DictToken"
    # str_2 - main
    str_2 = 'bool_true: True\n'
    assert tokenize_yaml(str_2).__class__.__name__ == "ScalarToken"
    # str_3 - main
    str_3 = 'null: ~\n'
    assert tokenize_yaml(str_3).__class__.__name__ == "ScalarToken"
    #

# Generated at 2022-06-26 10:47:17.872117
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(fields={"foo": {"type": "string"}})

    data = "foo: bar"
    result = validate_yaml(content=data, validator=schema)
    assert result == ({"foo": "bar"}, [])

    data = "not a dict"
    result = validate_yaml(content=data, validator=schema)
    assert result == (
        None,
        [
            Message(
                text="Expected a mapping for dictionary value",
                code="type_error.dict",
                position=Position(column_no=1, line_no=1, char_index=0),
            )
        ],
    )

    data = "foo: 1"
    result = validate_yaml(content=data, validator=schema)

# Generated at 2022-06-26 10:47:25.781239
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = fields.String()

    assert validate_yaml(b"name: foo", validator=MySchema) == (
        {"name": "foo"},
        None,
    )

    try:
        validate_yaml(b"", validator=MySchema)
    except ParseError as exc:
        text = str(exc)
        position = exc.position
        assert text == "No content."
        assert position == Position(column_no=1, line_no=1, char_index=0)

    try:
        validate_yaml(b"foo", validator=MySchema)
    except ParseError as exc:
        text = str(exc)
        position = exc.position

# Generated at 2022-06-26 10:47:30.090435
# Unit test for function validate_yaml
def test_validate_yaml():
    assert_raises(ParseError, validate_yaml, "* '$4Bf!D", "*'$4Bf!D")
    assert_raises(TypeError, validate_yaml, "*'$4Bf!D", "*'$4Bf!D", "* '$4Bf!D")

# Generated at 2022-06-26 10:47:41.093520
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Test case #0
    str_0 = '*"$4Bf!D'
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, ScalarToken)
    assert isinstance(token_0._value, str)
    assert token_0._content == str_0
    assert token_0._start == 0
    assert token_0._end == len(str_0) - 1

    # Test case #1
    str_1 = '- 1\n- 3\n- 5\n- 7\n'
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, ListToken)

# Generated at 2022-06-26 10:47:46.805587
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*"$4Bf!D'
    str_1 = '*"$4Bf!D'
    str_2 = '*"$4Bf!D'
    str_3 = '*"$4Bf!D'
    str_4 = '*"$4Bf!D'
    str_5 = '*"$4Bf!D'
    str_6 = '*"$4Bf!D'
    str_7 = '*"$4Bf!D'
    str_8 = '*"$4Bf!D'
    
    str_9 = '*"$4Bf!D'
    str_10 = '*"$4Bf!D'
    str_11 = '*"$4Bf!D'

# Generated at 2022-06-26 10:47:59.135421
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test yaml parsing with a simple string.
    str_0 = "foobar"

    token_0 = tokenize_yaml(str_0)
    assert token_0.get_value() == "foobar"

    # Test yaml parsing with a complex object.
    str_1 = """
        letter: a
        number: 2
        boolean: true
        >-
            multiline: here
            is a long: message
    """

    t = tokenize_yaml(str_1)

    assert t.letter.value == "a"
    assert t.number.value == 2
    assert t.boolean.value is True
    assert t.multiline.value == "here\nis a long"
    assert t.message.value == ""


# Generated at 2022-06-26 10:48:12.587193
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:48:13.104264
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True

# Generated at 2022-06-26 10:48:20.978810
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b'foo: bar\n'
    validator = Schema.from_fields({"foo": Field()})
    value = validate_yaml(content, validator)
    assert value == ({"foo": "bar"}, [])

    content = b"- 1\n- bar\n"
    validator = Field(int)
    value = validate_yaml(content, validator)
    assert value == (
        [1, "bar"],
        [
            ValidationError(
                text="Value 'bar' is not a valid integer.",
                code="type_error.integer",
                position=Position(line_no=2, column_no=3, char_index=5),
            )
        ],
    )

    content = b"---\nfoo: bar\n"
    validator = Schema.from_

# Generated at 2022-06-26 10:48:33.534073
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:48:43.486097
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(b"a: 1\nb: 2") == DictToken(
        {"a": ScalarToken(1, 2, 2, content="a: 1\nb: 2"), "b": ScalarToken(2, 5, 5, content="a: 1\nb: 2")}, 1, 7, content="a: 1\nb: 2"
    )
    assert tokenize_yaml(b"a: 1\nb: 2\n") == DictToken(
        {"a": ScalarToken(1, 2, 2, content="a: 1\nb: 2\n"), "b": ScalarToken(2, 5, 5, content="a: 1\nb: 2\n")}, 1, 8, content="a: 1\nb: 2\n"
    )

# Generated at 2022-06-26 10:48:50.487530
# Unit test for function validate_yaml
def test_validate_yaml():
    # TypeError - Expected validator to be of type `Union[typesystem.Field, type]`,
    # but got `builtins.int` (type `builtins.int`).
    try:
        validate_yaml(content='Kzm', validator=5)
        raise AssertionError()
    except TypeError:
        pass

    # ParseError - No content.
    try:
        validate_yaml(content='', validator=validator_0)
        raise AssertionError()
    except ParseError:
        pass

    # ParseError - Expected a tag or !, but got '{'.
    try:
        validate_yaml(content='{', validator=validator_0)
        raise AssertionError()
    except ParseError:
        pass

    # ParseError

# Generated at 2022-06-26 10:48:58.868877
# Unit test for function validate_yaml
def test_validate_yaml():
    class Color(Schema):
        name = String()
        hex = String()

    class Product(Schema):
        name = String()
        description = String(required=False)
        colors = List(items=Color())

    content_0 = ("- name: Red\n" "  hex: F00\n" "- name: Green\n" "  hex: 0F0\n" "- name: Blue\n" "  hex: 00F")
    assert len(content_0) == 117
    value_0, error_messages_0 = validate_yaml(content_0, Product())
    assert len(error_messages_0) == 0

# Generated at 2022-06-26 10:49:07.686783
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import String
    from typesystem.schema import SchemaMeta

    value = "this is a test"
    str_value = yaml.dump(value)
    validator = String()

    # Test with a Field instance
    parsed_value, error_messages = validate_yaml(
        str_value, validator=validator)
    assert parsed_value == value
    assert error_messages == []

    # Test with a Schema class
    class TestSchema(Schema, metaclass=SchemaMeta):
        str_field = String()

    parsed_value, error_messages = validate_yaml(
        str_value, validator=TestSchema)
    assert parsed_value == {"str_field": value}
    assert error_messages == []



# Generated at 2022-06-26 10:49:17.136835
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class WeatherSchema(Schema):
        # A list of type `str`
        weather = ListField(StringField())

        # A string value
        description = StringField()

    # Test a valid value.
    str_0 = (
        "weather:\n"
        "  - rain\n"
        "  - sun\n"
        "description: 'Mostly sunny'\n"
    )
    success, messages = validate_yaml(str_0, validator=WeatherSchema)
    assert success is True
    assert messages == []
    assert success.weather == [ScalarToken("rain", 4, 4, content=str_0),
                               ScalarToken("sun", 5, 5, content=str_0)]

# Generated at 2022-06-26 10:49:25.941878
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    def test_case(content: str, validator: typing.Type[Schema]):
        try:
            value, error_messages = validate_yaml(content, validator)
        except (ParseError, ValidationError) as exc:
            error_messages = exc.messages
            value = []
        for message in error_messages:
            assert isinstance(message, Message)
            assert message.text
            assert message.position
            assert message.position.char_index >= 0
            assert message.position.line_no >= 1
            assert message.position.column_no >= 1
            assert message.code
            if message.context:
                assert isinstance(message.context, dict)
        return value, error_messages


# Generated at 2022-06-26 10:49:39.154845
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:49:41.727282
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '---\n'
    str_1 = '---\n- *"$4Bf!D\n'
    token_1 = tokenize_yaml(str_1)
    token_0 = tokenize_yaml(str_0)

# Generated at 2022-06-26 10:49:47.193292
# Unit test for function validate_yaml
def test_validate_yaml():
    # Example 1 from issue #1
    test_yaml_str = '---\nfailure_msg: "Invalid value."\nerror_msg: "Invalid value."\n'

    test_yaml_dict = {'failure_msg': 'Invalid value.', 'error_msg': 'Invalid value.'}

    test_yaml_field = Field(name='test_yaml', type='string')

    test_yaml_tuple = (test_yaml_dict, [Message(text='Invalid value.', code='invalid')])

    assert validate_yaml(test_yaml_str, test_yaml_field) == test_yaml_tuple


# Generated at 2022-06-26 10:49:58.646366
# Unit test for function validate_yaml
def test_validate_yaml():
    class IntegerSchema(Schema):
        foo = Field(type="integer")

    value, error_messages = validate_yaml(
        content="foo: 'string'", validator=IntegerSchema
    )
    assert error_messages == [
        Message(
            code="invalid_type",
            text="Field must be of type 'integer'.",
            position=Position(column_no=5, line_no=1, char_index=5),
        )
    ]

    class SubSchema(Schema):
        bar = Field(type="string", max_length=0)

    class MainSchema(Schema):
        foo = Field(type="string", max_length=0)
        bar = Field(type=SubSchema)


# Generated at 2022-06-26 10:50:01.946566
# Unit test for function validate_yaml
def test_validate_yaml():
    assert(isinstance(validate_yaml('*"$4Bf!D', 'str'), typing.Any))

# Generated at 2022-06-26 10:50:15.866213
# Unit test for function validate_yaml
def test_validate_yaml():
    # Testing with tokenize_yaml()
    str_0 = '*"$4Bf!D'
    token_0 = tokenize_yaml(str_0)
    assert type(token_0) == ScalarToken
    assert token_0.start == 0
    assert token_0.end == 8
    assert token_0.value == '*"$4Bf!D'
    assert token_0.content == str_0


    str_1 = '1.12e4'
    token_1 = tokenize_yaml(str_1)
    assert type(token_1) == ScalarToken
    assert token_1.start == 0
    assert token_1.end == 6
    assert token_1.value == 11200.0
    assert token_1.content == str_1

    str_2

# Generated at 2022-06-26 10:50:26.945837
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*"$4Bf!D'

# Generated at 2022-06-26 10:50:39.369200
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*"$4Bf!D'

    messages = validate_yaml(str_0, typing.Any)

# Generated at 2022-06-26 10:50:45.359132
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_schema = {
        "name": "card",
        "fields": [{"name": "name", "type": "string"}, {"name": "text", "type": "string"}],
    }
    yaml_string = """
        - card:
            name: "Some card"
            text: "Some text"
        - card:
            name: "Another card"
            text: "Some text"
    """
    test_value_0 = validate_yaml(yaml_string, yaml_schema)
    assert test_value_0.get('message') is None


# Generated at 2022-06-26 10:50:55.508789
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml(b'*"$4Bf!D') == b'*"$4Bf!D'
    assert tokenize_yaml(b'') == b''
    assert tokenize_yaml(b'\x00\x1c\x16\xc0\t') == b'\x00\x1c\x16\xc0\t'
    assert tokenize_yaml('*"$4Bf!D') == '*"$4Bf!D'
    assert tokenize_yaml('*"$4Bf!D') == '*"$4Bf!D'
    assert tokenize_yaml('*"$4Bf!D') == '*"$4Bf!D'
    assert tokenize_yaml(b'') == b''
    assert tokenize

# Generated at 2022-06-26 10:51:09.452240
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schema import Schema
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.validators import min_length

    class MySchema(Schema):

        name = String(max_length=10, min_length=5, required=True)
        age = Integer(min_value=5, max_value=10, required=True)

    input_0 = "name: Tom\nage: 12"
    output_0 = ({"name": "Tom", "age": 12}, [])
    assert validate_yaml(input_0, MySchema) == output_0

    input_1 = "name: Tom"
    output_1 = ({"name": "Tom"}, [])
    assert validate_yaml(input_1, MySchema) == output

# Generated at 2022-06-26 10:51:18.702020
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = 'scalar'
    token_0 = tokenize_yaml(str_0)
    str_1 = 'true'
    token_1 = tokenize_yaml(str_1)
    str_2 = 'false'
    token_2 = tokenize_yaml(str_2)
    str_3 = '""'
    token_3 = tokenize_yaml(str_3)
    str_4 = 'null'
    token_4 = tokenize_yaml(str_4)
    str_5 = '123'
    token_5 = tokenize_yaml(str_5)
    str_6 = '1.5'
    token_6 = tokenize_yaml(str_6)
    str_7 = '{}'
    token_7 = tokenize_yaml

# Generated at 2022-06-26 10:51:19.306083
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml == "validate_yaml"

# Generated at 2022-06-26 10:51:29.153290
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content_0 = "foo: bar"
    assert tokenize_yaml(content_0) == {'foo': 'bar'}
    content_1 = "foo: 'bar'"
    assert tokenize_yaml(content_1) == {'foo': 'bar'}
    content_2 = 'foo: "bar"'
    assert tokenize_yaml(content_2) == {'foo': 'bar'}
    content_3 = 'foo: !bar'
    assert tokenize_yaml(content_3) == {'foo': 'bar'}
    content_4 = 'foo: !!bar'
    assert tokenize_yaml(content_4) == {'foo': 'bar'}
    content_5 = "foo: bar\nbaz: qux"

# Generated at 2022-06-26 10:51:39.570834
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '*"$4Bf!D'
    str_1 = '%f!O1<)j'
    str_2 = 'L/z#Z*4p'
    str_3 = '@d$^y{&N'
    str_4 = '%bL\nx\n'
    str_5 = '*7K\nF\n'
    str_6 = 'T\n!\n8\n'
    str_7 = '\n'
    str_8 = '\n'
    str_9 = '\n'
    str_10 = '\n'
    validator = None # type: typing.Union[Field, typing.Type[Schema]]
    error_code = 'parse_error'
    error_text = 'End quote not found.'
   