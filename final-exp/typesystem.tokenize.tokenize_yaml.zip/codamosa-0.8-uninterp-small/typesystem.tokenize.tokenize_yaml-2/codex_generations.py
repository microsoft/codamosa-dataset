

# Generated at 2022-06-26 10:41:49.602691
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert 1 == 1 # TODO: implement your test here


# Generated at 2022-06-26 10:41:59.967760
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = 'eh1ZW71'
    token_0 = tokenize_yaml(str_0)
    str_1 = 'RgDRP0nT'
    token_1 = tokenize_yaml(str_1)
    str_2 = 'P'
    token_2 = tokenize_yaml(str_2)
    str_3 = 'Yl6ltFFo'
    token_3 = tokenize_yaml(str_3)
    str_4 = 'dDV7Cm'
    token_4 = tokenize_yaml(str_4)
    str_5 = '0c43l'
    token_5 = tokenize_yaml(str_5)
    str_6 = 'x8rBO'

# Generated at 2022-06-26 10:42:10.507869
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'eh1ZW71'
    token_0 = tokenize_yaml(str_0)
    assert token_0.serialize() == "eh1ZW71"

    str_1 = 'rWnPvU5'
    token_1 = tokenize_yaml(str_1)
    assert token_1.serialize() == "rWnPvU5"

    str_2 = "dmNgDHX\n"
    token_2 = tokenize_yaml(str_2)
    assert token_2.serialize() == "dmNgDHX\n"

    str_3 = "e1bzYOH\n"
    token_3 = tokenize_yaml(str_3)

# Generated at 2022-06-26 10:42:12.138737
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert True


# Generated at 2022-06-26 10:42:13.809648
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Remove once cases have been added.
    assert False  # pragma: no cover



# Generated at 2022-06-26 10:42:20.730058
# Unit test for function validate_yaml
def test_validate_yaml():
    # Validator: string
    validator_1 = Field(type='string')
    # Data: string
    data_1 = 'eh1ZW71'
    # Result
    result_1 = validate_yaml(data_1, validator_1)
    assert result_1 == (data_1, [])
    # Data: string
    data_1 = 'eh1ZW71'
    # Result
    result_1 = validate_yaml(data_1, validator_1)
    assert result_1 == (data_1, [])
    # Data: string
    data_2 = '010'
    # Result
    result_2 = validate_yaml(data_2, validator_1)
    assert result_2 == (data_2, [])
    # Data: integer
    data_3 = 0

# Generated at 2022-06-26 10:42:32.613975
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Tests that the function raises an error when given a blank YAML string.
    assert isinstance(tokenize_yaml(""), ScalarToken)
    with pytest.raises(ParseError, match="No content."):
        tokenize_yaml(" ")
    with pytest.raises(ParseError, match="expected <block end>, but found '\\n'"):
        tokenize_yaml("\n")
    with pytest.raises(ParseError, match="could not find expected ':'"):
        tokenize_yaml("{key: value}")

    # Tests that the function properly parses scalars .
    assert isinstance(tokenize_yaml('"string"'), ScalarToken)
    assert isinstance(tokenize_yaml("123"), ScalarToken)

# Generated at 2022-06-26 10:42:41.696694
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '2'
    token_0 = tokenize_yaml(str_0)
    assert type(token_0) == ScalarToken
    assert token_0.value == 2
    assert token_0.start == 0
    assert token_0.end == 1
    assert token_0.content == '2'
    str_1 = '0.0'
    token_1 = tokenize_yaml(str_1)
    assert type(token_1) == ScalarToken
    assert token_1.value == 0.0
    assert token_1.start == 0
    assert token_1.end == 3
    assert token_1.content == '0.0'
    str_2 = '3.14159265359'
    token_2 = tokenize_yaml(str_2)
    assert type

# Generated at 2022-06-26 10:42:54.896576
# Unit test for function validate_yaml
def test_validate_yaml():
    import sys
    import io
    from typesystem.schemas import Schema
    from typesystem.fields import String, Text, Integer, Number, Boolean
    class MySchema(Schema): 
        name = String()
        description = Text()
        age = Integer()
        height = Number()
        is_active = Boolean()


# Generated at 2022-06-26 10:43:06.060532
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    str_2 = '5JAxK7'
    token_2 = tokenize_yaml(str_2)
    assert isinstance(token_2, ScalarToken)

    str_1 = 'eIkKj'
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, ScalarToken)

    str_6 = '0'
    token_6 = tokenize_yaml(str_6)
    assert isinstance(token_6, ScalarToken)

    str_8 = '[0]'
    token_8 = tokenize_yaml(str_8)
    assert isinstance(token_8, ListToken)

    str_3 = '?\n'
    token_3 = tokenize

# Generated at 2022-06-26 10:43:12.852173
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True


# Generated at 2022-06-26 10:43:27.288620
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Test that schema validation works on YAML content.
    class SomeSchema(Schema):
        a = Field("a")
        b = Field(["b", "B"])
        c = Field("c", required=False)

    content = "a: hello\nb: world\nc: null"
    value, errors = validate_yaml(content, SomeSchema)
    assert value == {"a": "hello", "b": "world", "c": None}
    assert errors == []

    # Test that field validation works on YAML content.
    field = Field("a")
    content = "a: hello"
    value, errors = validate_yaml(content, field)
    assert value == "hello"
    assert errors == []

    #

# Generated at 2022-06-26 10:43:40.227394
# Unit test for function validate_yaml
def test_validate_yaml():
    # Create a schema for testing
    class TestSchema(Schema):
        field_0 = Field(type="integer", required=True, description="Test description")
    field_0 = TestSchema['field_0']
    # Create a bytes string and parse it
    bytes_0 = b'\xa7*]\xb3\xf0q#\x85'
    token_0 = tokenize_yaml(bytes_0)

    # Test when the token is of the correct type
    assert validate_yaml(bytes_0, field_0)[0] is not None

    # Test when the token is not of the correct type
    bytes_1 = b'\xcd\xa6\x07\xa5\x03\x7f'
    assert validate_yaml(bytes_1, field_0)[0] is None
   

# Generated at 2022-06-26 10:43:51.063746
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = Field(str)

    assert validate_yaml(content="name: Foo", validator=TestSchema) == (
        {"name": "Foo"},
        [],
    )

    with pytest.raises(ParseError) as exc:
        validate_yaml(content="invalid: yaml", validator=TestSchema)
    assert exc.value.code == "parse_error"
    assert exc.value.text == "mapping values are not allowed here."
    assert exc.value.position.column_no == 1

    with pytest.raises(ValidationError) as exc:
        validate_yaml(content="", validator=TestSchema)
    assert exc.value.code == "required"

# Generated at 2022-06-26 10:43:54.102361
# Unit test for function validate_yaml
def test_validate_yaml():
    assert isinstance(validate_yaml(
        content=b"---\n    - 1\n    - 2\n", validator=list), tuple)


# Generated at 2022-06-26 10:43:58.799734
# Unit test for function validate_yaml
def test_validate_yaml():
    class Employee(Schema):
        name = Field(str)
        age = Field(int)
    # bytes_0 = b"\xa7*]\xb3\xf0q#\x85"
    validator = Employee()
    bytes_1 = b"name: Alex\nage: 20"
    value, error_messages = validate_yaml(bytes_1, validator)
    assert isinstance(value, dict)
    assert isinstance(error_messages, list)

# Generated at 2022-06-26 10:44:08.777045
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = String()

    validate_yaml("", Person)

    class Person(Schema):
        name = String()

    try:
        validate_yaml("", Person)
    except ValidationError as exc:
        error = exc.as_dict()
        assert error == {
            "errors": [
                {"code": "missing_required_field", "field": "name", "text": "Field is required."}
            ],
            "field_errors": {"name": [{"code": "missing_required_field", "text": "Field is required."}]},
            "value": {},
        }
    else:
        assert False, "Did not raise validation error."

# Generated at 2022-06-26 10:44:19.719813
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'\xa7*]\xb3\xf0q#\x85'
    token_0 = tokenize_yaml(bytes_0)

    schema_0 = Schema(fields={"crypto_key": {"type": "string"}, "email": {"type": "string"}, "uid": {"type": "string"}})
    error_messages_0 = validate_yaml(bytes_0, schema_0)
    assert error_messages_0 == []

    schema_1 = Schema(fields={"crypto_key": {"type": "string"}, "email": {"type": "string"}, "uid": {"type": "int"}})
    error_messages_1 = validate_yaml(bytes_0, schema_1)

# Generated at 2022-06-26 10:44:30.928953
# Unit test for function validate_yaml
def test_validate_yaml():
    import json

    from decimal import Decimal
    from copy import deepcopy
    from typesystem.fields import (
        Array,
        Boolean,
        Date,
        DateTime,
        Dictionary,
        Float,
        Integer,
        Number,
        Object,
        String,
        Time,
        Union,
    )
    from typesystem.schemas import Schema
    from typesystem.tokenize import validate_yaml

    class TestSchema(Schema):
        field1 = String(description="A string field.")
        field2 = Integer(description="An integer field.")
        field3 = Number(description="A number field.")
        field4 = Boolean(description="A boolean field.")
        field5 = DateTime(description="A datetime field.")
        field6 = Date(description="A date field.")
        field7 = Time

# Generated at 2022-06-26 10:44:42.140454
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    sample_yaml = """
    greeting: hello
    name: world
    """

    class User(Schema):
        greeting = Field(type=str)
        name = Field(type=str)

    # Valid yaml and valid schema
    value, errors = validate_yaml(sample_yaml, validator=User)
    assert value == {"greeting": "hello", "name": "world"}
    assert len(errors) == 0

    # Invalid yaml
    value, errors = validate_yaml("{", validator=User)
    assert value is None

# Generated at 2022-06-26 10:44:52.979092
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Boolean
    from typesystem.schemas import Schema

    class MySchema(Schema):
        field = Boolean()

    result = validate_yaml("field: foo", MySchema)
    assert result == (
        None,
        [
            Message(
                text="Value is not a valid boolean.",
                code="invalid_type",
                position=Position(
                    line_no=1, column_no=5, char_index=5),
            )
        ],
    )



# Generated at 2022-06-26 10:45:03.973922
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"name": str, "age": int})
    value, messages = validate_yaml(b"name: john\nage: 42", schema)
    assert value == {"name": "john", "age": 42}
    assert not messages

    value, messages = validate_yaml(b"age: 42", schema)
    assert value is None
    assert len(messages) == 1
    message_0 = messages[0]
    assert message_0.field_name == "name"
    assert message_0.text == "This field is required."
    assert message_0.code == "required"
    assert message_0.position.line_no == 1
    assert message_0.position.column_no == 1
    assert message_0.position.char_index == 0



# Generated at 2022-06-26 10:45:09.671061
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    bytes_0 = b'\xe2Q\x9bn\x89\xb8\xd5\xcf\xe2\xab\xed\xa8'
    token_0 = tokenize_yaml(bytes_0)


# Generated at 2022-06-26 10:45:22.752041
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_1 = b'/\xd0\x00\x1d\x14\x00'
    schema_1 = typesystem.Schema(content=bytes_1)
    str_2 = 'M\xfd\xde\r\xe5\xcb\xec\x10\xf2O\xb0\xa3\xa0\x17H\xb9\x86\xf9\x01\x00\x0c\x00\xff\xff\xff\xff\xff\xff\xff\xff\x00\x00\x00\xee\x8c\x93I\x1a'
    schema_1.test(str_2)
    bytes_3 = b'\xcd\xb4\xcd\x03R\x00'
    schema_1.test(bytes_3)

# Generated at 2022-06-26 10:45:30.832698
# Unit test for function validate_yaml
def test_validate_yaml():
    error_messages = validate_yaml("{}", schema_field_0)
    assert error_messages == [], "Expected 'error_messages' to be [], got %r" % error_messages
    error_messages = validate_yaml("---", schema_field_0)
    assert error_messages == [], "Expected 'error_messages' to be [], got %r" % error_messages


schema_class_0 = Schema
schema_field_0 = None  # type: Field

# Generated at 2022-06-26 10:45:32.686330
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert callable(tokenize_yaml)


# Generated at 2022-06-26 10:45:38.544671
# Unit test for function validate_yaml
def test_validate_yaml():
    # Example of YAML content
    yaml_content = b"""
        name: Robert
        """

    # Example of YAML schema
    class PersonSchema(Schema):
        name = Field(type="string", required=True)

    value, error_messages = validate_yaml(yaml_content, PersonSchema())

    assert value == {'name': 'Robert'}
    assert not error_messages



# Generated at 2022-06-26 10:45:50.588810
# Unit test for function validate_yaml
def test_validate_yaml():
    content_0 = '---\n- 1\n- 2\n- 3\n'
    validator_0 = list
    value_0, error_messages_0 = validate_yaml(content_0, validator_0)
    assert error_messages_0 == []
    assert value_0 == [1, 2, 3]

    content_1 = ''
    validator_1 = int
    value_1, error_messages_1 = validate_yaml(content_1, validator_1)
    assert len(error_messages_1) == 1
    assert error_messages_1[0] == Message(text='No content.', code='no_content', position=Position(line_no=1, column_no=1, char_index=0))
    assert value_1 is None

    content_

# Generated at 2022-06-26 10:46:01.412266
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'\xa7*]\xb3\xf0q#\x85'
    token_0 = tokenize_yaml(bytes_0)
    class T(Schema):
        x: str
    t = T()
    try:
        validate_yaml(bytes_0, t)
        assert False, "Should have raised a ValidationError"
    except ValidationError as error:
        assert error.messages == [
            Message(
                text="Value must be of type 'string'.",
                code="type_error.string",
                position=Position(char_index=0, column_no=1, line_no=1),
            )
        ]


# Generated at 2022-06-26 10:46:10.982365
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'\xdas\xe0\xee\xd0\x00\xed\xe3\x8c'
    str_0 = str(bytes_0, encoding='utf-8')
    token_0 = tokenize_yaml(bytes_0)
    value, error_messages = validate_yaml(content=bytes_0, validator=str)
    assert value == str_0
    assert isinstance(error_messages, list)
    assert len(error_messages) == 0


# Generated at 2022-06-26 10:46:18.670403
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        a = Field(type="boolean")

    # Test case 1
    bytes_0 = b'\xa7*]\xb3\xf0q#\x85'
    value_1, error_messages_1 = validate_yaml(bytes_0, TestSchema)
    assert value_1 == {'a': True}
    assert error_messages_1 == []

    # Test case 2
    bytes_2 = b'3\r\r'
    value_3, error_messages_3 = validate_yaml(bytes_2, TestSchema)
    assert value_3 is None

# Generated at 2022-06-26 10:46:21.986175
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'\xa7*]\xb3\xf0q#\x85'
    token_0 = tokenize_yaml(bytes_0)
    assert token_0 == b"\xa7*]\xb3\xf0q#\x85"



# Generated at 2022-06-26 10:46:25.423002
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # Test case 0
    try:
        test_case_0()
    except:  # noqa: E722
        pass



# Generated at 2022-06-26 10:46:35.577798
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    class Person(Schema):
        name = (
            "string",
            {
                "max_length": 10,
                "min_length": 10,
                "nullable": False,
                "pattern": "^\\d{3,}$",
            },
        )
        age = ("integer", {"gte": 0, "lte": 100})

    validator_0: Field = MarshalField(Person)

    content_0 = b'\xa7*]\xb3\xf0q#\x85'
    value_0, errors_0 = validate_yaml(content_0, validator_0)
    error_0: ValidationError = errors_0[0]
    messages_0: typing.List[Message] = error_0

# Generated at 2022-06-26 10:46:45.936523
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    from typesystem import String, Integer
    from typesystem.fields import Any, Object
    from typesystem.schemas import Schema

    # Handle the empty string case explicitly for clear error messaging.
    content = ""
    validator = String(max_length=10)
    value, error_messages = validate_yaml(content, validator)
    assert not value  # type: ignore
    assert error_messages == [
        Message(
            text="No content.",
            code="no_content",
            position=Position(column_no=1, line_no=1, char_index=0),
        )
    ]

    # empty string
    content = b""
    validator = String(max_length=10)
    value, error_mess

# Generated at 2022-06-26 10:46:56.151727
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'\xa7*]\xb3\xf0q#\x85'
    token_0 = tokenize_yaml(bytes_0)
    class SchemaA(Schema):
        a = Integer()
        b = String()
    schemaA_0 = SchemaA()
    valueA_0, errorsA_0 = validate_yaml(bytes_0, schemaA_0)
    assert errorsA_0[0].text == "'int' object has no attribute 'b'"
    assert errorsA_0[0].position.column_no == 1
    assert errorsA_0[0].position.line_no == 1
    assert errorsA_0[0].position.char_index == 0
    class SchemaB(Schema):
        a = Integer()
    schemaB_0 = SchemaB()

# Generated at 2022-06-26 10:47:08.061901
# Unit test for function validate_yaml
def test_validate_yaml():
    # A byte string that should raise a parse error.
    invalid_bytes_content = b"testing: [123"
    try:
        # token_0 = tokenize_yaml(invalid_bytes_content)
        token_0 = validate_yaml(invalid_bytes_content, Field)
        raise AssertionError("Expected ParseError to be raised.")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.char_index == 11
        assert exc.position.line_no == 1
        assert exc.position.column_no == 12
        assert exc.text == "expected ']', but found '<stream end>'"

    class SimpleSchema(Schema):
        foo = Field(type="integer")

    # A string that should raise a validation error.
   

# Generated at 2022-06-26 10:47:20.348194
# Unit test for function validate_yaml
def test_validate_yaml():
    class Foo(Schema):
        field = Field(type="string", max_length=100)

    content_0 = "field: this is a string"
    value_0, error_messages_0 = validate_yaml(content_0, Foo)
    assert value_0 is not None
    assert error_messages_0 == []

    class Foo(Schema):
        field = Field(type="string", max_length=100)

    content_0 = "field: this is a string"
    content_1 = "field: the string is too long"
    content_2 = "field: this is not a string"
    try:
        validate_yaml(content_0, Foo)
    except ValidationError:
        pass
    else:
        assert False

# Generated at 2022-06-26 10:47:32.008080
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b"\xcf\xe0\x15\xaf\x94\x9b\xd4\x06\x88g\xdc\xeb\x80"
    bytes_1 = b"\xf9\xcd\x7f\xe6\xfd\x1a\xec\x1b\xd7\xa5\xa9\xed"
    bytes_2 = b"\xa5x\x1a\xb3\xd3\xc3\xdez\x9d\x89\xa7\x85\x8c\xac\xb1/\xc9\xa5\x92\x0f"

# Generated at 2022-06-26 10:47:39.745751
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.integer import Integer

    content = b'\xa7*]\xb3\xf0q#\x85'
    validator = Integer()
    returned_value, error_messages = validate_yaml(content, validator)
    assert returned_value is None
    error_messages_list = to_list(error_messages)
    error_0 = error_messages_list[0]
    assert error_0.text == "Expected an integer."
    assert error_0.code == "invalid_type"
    assert error_0.position.line_no == 1
    assert error_0.position.column_no == 1
    assert error_0.position.char_index == 0

# Generated at 2022-06-26 10:47:54.248295
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'\xa7*]\xb3\xf0q#\x85'
    class Class_0(Schema):
        pass
    result_0, result_1 = validate_yaml(bytes_0, Class_0)
    bytes_1 = b'\xb5\xbc\x9c\xdf\xa6\xeb'
    token_1 = tokenize_yaml(bytes_1)
    class Class_1(Schema):
        pass
    result_2, result_3 = validate_yaml(bytes_1, Class_1)
    bytes_2 = b'\x86\x8c\x95]\x86\x8c'
    token_2 = tokenize_yaml(bytes_2)
    class Class_2(Schema):
        pass
    result

# Generated at 2022-06-26 10:48:05.866689
# Unit test for function validate_yaml
def test_validate_yaml():
    class ExampleSchema(Schema):
        name = "ExampleSchema"
        fields = [
            Field(key="a", type="string"),
            Field(key="b", type="integer"),
            Field(key="c", type="number"),
            Field(key="d", type="boolean"),
            Field(key="e", type="null"),
            Field(key="f", type="string", validators=["pattern"]),
        ]

    string_data = """
    a: "foo"
    b: 12
    c: 12.34
    d: true
    e: null
    f: "bar"
    """

    bytes_data = string_data.encode("utf-8")

    # Test that a valid value parses.
    assert validate_yaml(string_data, ExampleSchema)

# Generated at 2022-06-26 10:48:15.350933
# Unit test for function validate_yaml
def test_validate_yaml():
    #
    # All of these fields are optional:
    class User(Schema):
        name = String(max_length=255)
        email = String(min_length=6)

    result_0, error_messages_0 = validate_yaml(
        b"email: '  john@example.com\n'\nname: 'John Smith '", User
    )
    result_1, error_messages_1 = validate_yaml(
        b"name: 'John Smith '  \nemail: 'john@example.com'", User
    )
    result_2, error_messages_2 = validate_yaml(
        b"'john@example.com' # Name: John Smith", User
    )

# Generated at 2022-06-26 10:48:24.802637
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Array, Boolean, Integer, Number, Object, String

    from .validation_cases import (
        INVALID_DATA_CASES,
        INVALID_OUTPUT_CASES,
        VALID_DATA_CASES,
    )

    schema = Object({"foo": Array(Integer(), min_items=2)}, strict=True)
    value, errors = validate_yaml(VALID_DATA_CASES[0], schema)
    assert value == {"foo": [1, 2]}
    assert errors == []

    schema = Object(
        {"name": String(max_length=5), "age": Integer(minimum=13, maximum=99)},
        strict=False,
    )

# Generated at 2022-06-26 10:48:36.220703
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.fields import Array
    from typesystem.types import Integer

    field = Array(items=Integer())

    content = b"foo: bar"
    value, _ = validate_yaml(content, field)
    assert value == "foo: bar"

    content = b"foo: 1"
    value, _ = validate_yaml(content, field)
    assert value == b"foo: 1"

    content = b"foo: bar"
    value, _ = validate_yaml(content, field)
    assert value == "foo: bar"

    value, _ = validate_yaml(b"", field)
    assert value == b""


# Generated at 2022-06-26 10:48:45.702965
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type="string")
    content = b"hello"
    value, error_messages = validate_yaml(content, validator)
    assert value == "hello"
    assert len(error_messages) == 0
    content = b"- hello"
    value, error_messages = validate_yaml(content, validator)
    assert value == "- hello"
    assert len(error_messages) == 1
    message_0 = error_messages[0]
    assert isinstance(message_0, ValidationError)
    assert message_0.code == "invalid_type"
    assert message_0.text == "Must be a string."
    assert message_0.context["expected_type"] == "string"
    assert message_0.context["actual_type"] == "unsupported"

# Generated at 2022-06-26 10:48:50.579348
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'\xa7*]\xb3\xf0q#\x85'
    assert isinstance(validate_yaml(bytes_0, Str()), tuple)


# Generated at 2022-06-26 10:48:58.889931
# Unit test for function validate_yaml
def test_validate_yaml():
    from tests.validators import (
        Car,
        CarSchema,
        Person,
        PersonSchema,
        SimplePersonSchema,
    )

    content_0: bytes = b"""
    name: Jane Doe
    age: 25
    """
    (simple_data_0, errors_0) = validate_yaml(SimplePersonSchema, content=content_0)
    assert errors_0 == []

    content_1: bytes = b"""
    name: Jane Doe
    age: 25
    """
    (person_data_0, errors_1) = validate_yaml(PersonSchema, content=content_1)
    assert errors_1 == []


# Generated at 2022-06-26 10:49:01.126431
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test TypeError if 'validator' was not a Field or Schema.
    # We expect a type error for this.
    try:
        validate_yaml("{}", str())
    except TypeError:
        pass
    else:
        raise AssertionError("Should have thrown a TypeError")


# Generated at 2022-06-26 10:49:03.683113
# Unit test for function validate_yaml
def test_validate_yaml():
    # type: () -> None

    content = b"foo: bar"
    validator = Field(type="string")
    value, error_messages = validate_yaml(content, validator)
    assert value == {"foo": "bar"}
    assert error_messages == []



# Generated at 2022-06-26 10:49:11.497894
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
        1.0
    """
    validator = Field(type="number")
    value, error_messages = validate_yaml(content, validator)
    assert value == 1.0
    assert error_messages == []



# Generated at 2022-06-26 10:49:23.914568
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem import Integer, String

    class PersonSchema(Schema):
        name = String()
        age = Integer()

    schema = PersonSchema()

    content = b"""
name: Phil
age: 34
"""
    value, errors = validate_yaml(content, schema)
    assert value == {"name": "Phil", "age": 34}

    content = b"""
name: Phil
age: whoops
"""
    _, errors = validate_yaml(content, schema)
    assert len(errors) == 1
    error = errors[0]
    assert error.code == "type_error.integer"
    assert error.position.line_no == 3
    assert error.position.column_no == 0
    assert error.pointer == "/age"

    content = b"""
name: Phil
aaaa: 34
"""


# Generated at 2022-06-26 10:49:26.256303
# Unit test for function validate_yaml
def test_validate_yaml():
    assert False  # TODO: implementation of test


# Generated at 2022-06-26 10:49:37.471623
# Unit test for function validate_yaml
def test_validate_yaml():
    print("Running test for function validate_yaml")
    from typesystem.fields import String
    from typesystem.validators import min_length

    assert (
        validate_yaml('''foo: "bar"''', {"foo": String(validators=[min_length(3)])})
        == ({"foo": "bar"}, [])
    )

    # test string received
    assert (
        validate_yaml(
            '''foo: "bar"''', String(validators=[min_length(3)])
        )
        == ("bar", [])
    )

    # test string received
    assert (
        validate_yaml(
            b'''foo: "bar"''', String(validators=[min_length(3)])
        )
        == ("bar", [])
    )


# Generated at 2022-06-26 10:49:38.314186
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True


# Generated at 2022-06-26 10:49:47.640807
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b"foo: bar\n"
    bytes_1 = b"foo-bar"
    class Schema_0(Schema):
        foo = "text"

    class Schema_1(Schema):
        foo = "text"

    class Schema_2(Schema):
        foo = "text"

    class Schema_3(Schema):
        foo = "text"

    class Schema_4(Schema):
        foo = "text"

    class Schema_5(Schema):
        foo = "text"

    class Schema_6(Schema):
        foo = "text"

    class Schema_7(Schema):
        foo = "text"

    value_0, error_messages_0 = validate_yaml(bytes_0, Schema_0)

# Generated at 2022-06-26 10:49:52.161454
# Unit test for function validate_yaml
def test_validate_yaml(): 
    assert validate_yaml(b'\xa7*]\xb3\xf0q#\x85', Field(name="", type="integer")) == (1996845426, [])

# Generated at 2022-06-26 10:49:58.812474
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import CharField, IntegerField

    class TestSchema(Schema):
        number = IntegerField()
        name = CharField()

    bytes_0 = b'\xa7*]\xb3\xf0q#\x85'
    value_0, error_messages_0 = validate_yaml(bytes_0, TestSchema)
    assert type(error_messages_0[0]) is Message
    assert value_0 == [(5, "kevin")]


if __name__ == "__main__":  # pragma: no cover
    test_case_0()

# Generated at 2022-06-26 10:50:05.971768
# Unit test for function validate_yaml
def test_validate_yaml():

    from typesystem import String, Integer, Schema

    class Pet(Schema):
        name = String()
        age = Integer()

    content = "name: kitty\nage: 8\n"
    data = validate_yaml(content, Pet)

    assert data.value == {"name": "kitty", "age": 8}
    assert data.errors == []



# Generated at 2022-06-26 10:50:18.073097
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None
    assert yaml.__version__ == "3.13"

    assert callable(validate_yaml)

    content = b'["foo", 1, true, false, null, {}, [], 2.0]'
    validator = typing.Any

    value_0, error_messages_0 = validate_yaml(content, validator)
    assert value_0 == ["foo", 1, True, False, None, {}, [], 2.0]
    assert error_messages_0 == []

    content = b"not a list"
    with pytest.raises(ParseError) as exc_info:
        validate_yaml(content, validator)

    error_0 = exc_info.value
    text_0 = error_0.text

# Generated at 2022-06-26 10:50:28.560832
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema({"foo": Field(type="string")})
    # Test valid case
    value, error_messages = validate_yaml(b"{foo: bar}", schema)
    assert value == {"foo": "bar"}

    # Test invalid case
    value, error_messages = validate_yaml(b"{foo: 100}", schema)
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be a string."

    # Test parsing error
    with pytest.raises(ParseError) as exc:
        validate_yaml(b"{foo: bar", schema)
    assert exc.value.text == "Unexpected end of input."

# Generated at 2022-06-26 10:50:35.373261
# Unit test for function validate_yaml
def test_validate_yaml():
    class EmptySchema(Schema):
        pass

    data = ""
    empty_schema = EmptySchema(strict=False)
    expected_errors = [
        Message("No content.", code="no_content"),
    ]
    expected_return = (None, expected_errors)
    assert validate_yaml(data, empty_schema) == expected_return

    # Using a field, not a schema
    class NameField(Field):
        pass

    name_field = NameField()
    expected_errors = [
        Message("No content.", code="no_content"),
    ]
    expected_return = (None, expected_errors)
    assert validate_yaml(data, name_field) == expected_return

    # Using a field, not a schema
    class NameField(Field):
        pass


# Generated at 2022-06-26 10:50:45.142922
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:50:55.447372
# Unit test for function validate_yaml
def test_validate_yaml():
    class TestSchema(Schema):
        name = str

    with pytest.raises(TypeError) as excinfo:
        validate_yaml(b"", TestSchema)
    assert "a Field instance, not a Schema class" in str(excinfo.value)

    class TestSchema(Schema):
        name = str

    value, errors = validate_yaml(b"", TestSchema())

    assert value == {}
    assert errors == []

    class TestSchema(Schema):
        name = str()

    value, errors = validate_yaml(b"", TestSchema())

    assert value == {}
    assert errors == []

    class TestSchema(Schema):
        name = str(required=True)

    with pytest.raises(ValidationError) as excinfo:
        validate_y

# Generated at 2022-06-26 10:50:56.369732
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True

# Generated at 2022-06-26 10:51:04.295505
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.base import ValidationError
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError

    field_0 = Integer(name='some_int', required=True)
    with raises(ValidationError) as excinfo:
        field_0.validate_with_context(token_0, {}, 'some_int')

    assert issubclass(ValidationError, ValueError)

# Generated at 2022-06-26 10:51:11.334433
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'\xa7*]\xb3\xf0q#\x85'
    token_0 = tokenize_yaml(bytes_0)
    assert token_0 == b'\xa7*]\xb3\xf0q#\x85'


# Generated at 2022-06-26 10:51:16.773604
# Unit test for function validate_yaml
def test_validate_yaml():
    bytes_0 = b'\xa7*]\xb3\xf0q#\x85'
    class schema_0(Schema):
        num = None # type: int

    # Call function and check result
    try:
        result = validate_yaml(bytes_0, schema_0)
    except Exception as e:
        print("Exception when calling function validate_yaml:")
        print(e)
        assert False



# Generated at 2022-06-26 10:51:28.431873
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:51:39.336913
# Unit test for function validate_yaml
def test_validate_yaml():
    assert "pyyaml" in sys.modules
    assert "typesystem" in sys.modules
    try:
        import yaml
    except ImportError:
        # No YAML installed, so skip this test
        return
    assert yaml is not None
    from typesystem.types import Integer
    from typesystem.schemas import Schema
    from typesystem.base import MessageType

    class Person(Schema):
        name = Integer()

    value, errors = validate_yaml(b"name: 42", validator=Person)
    assert value == {"name": 42}
    assert len(errors) == 0

    value, errors = validate_yaml(b"name: bob", validator=Person)
    assert value is None
    assert len(errors) == 1
    assert isinstance(errors[0].message, Message)
