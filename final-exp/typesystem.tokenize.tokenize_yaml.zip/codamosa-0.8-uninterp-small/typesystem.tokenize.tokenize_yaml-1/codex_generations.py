

# Generated at 2022-06-26 10:41:51.288926
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True

# Generated at 2022-06-26 10:42:00.501175
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test cases from generated from Typesystem's test cases
    assert validate_yaml(b"123", 123) == (123, [])
    assert validate_yaml(b"276.1", 276.1) == (276.1, [])
    assert validate_yaml(b"this is a string", "this is a string") == ("this is a string", [])
    assert validate_yaml(b"true", True) == (True, [])
    assert validate_yaml(b"null", None) == (None, [])
    assert validate_yaml(b"{}", {}) == ({}, [])
    assert validate_yaml(b"[]", []) == ([], [])

    assert validate_yaml(b"12.3", 123) == (12.3, [])

# Generated at 2022-06-26 10:42:04.192227
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content_0 = '\x00\x84k\x00\x08'
    any_0 = tokenize_yaml(content_0)

    content_1 = '\x00\x84k\x00\x09'
    any_1 = tokenize_yaml(content_1)

    content_2 = '\x00\x84k\x00\x08'
    any_2 = tokenize_yaml(content_2)

    content_3 = '\x00\x84k\x00\x07'
    any_3 = tokenize_yaml(content_3)

    content_4 = '\x00\x84k\x00\t'
    any_4 = tokenize_yaml(content_4)


# Generated at 2022-06-26 10:42:05.086728
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert callable(tokenize_yaml)



# Generated at 2022-06-26 10:42:08.878291
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    bytes_0 = b'\x03\xce\xecO\xe2\xc7\xd5-\x8f\xec\x0c\xe6\x9c\xcc\xf1\x05\xc6\x10l\x88\xae\x94\x1b9\x8c\xbfe\x01\xb2'

# Generated at 2022-06-26 10:42:16.159560
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = b"{'foo': 1.5, 'bar': [1, 2, 3], 'baz': []}"
    value, messages = validate_yaml(content, {str: {"foo": float}})

    assert value == {"foo": 1.5, "bar": [1, 2, 3], "baz": []}
    assert not messages


# Generated at 2022-06-26 10:42:23.060847
# Unit test for function validate_yaml
def test_validate_yaml():
    test_passed = True

    try:
        bytes_0 = b'\x10\xdc\xf5'
        any_0 = validate_yaml(bytes_0, bytes_0)
    except Exception:
        test_passed = False

    try:
        bytes_0 = b'\x10\xdc\xf5'
        any_0 = validate_yaml(bytes_0, bytes_0)
    except Exception:
        test_passed = False

    try:
        str_0 = '\x00\x05\x10'
        any_0 = validate_yaml(str_0, str_0)
    except Exception:
        test_passed = False


# Generated at 2022-06-26 10:42:34.000052
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # Initializer.
    from typesystem.fields import Integer, String
    from typesystem.schemas import SchemaMeta
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    # Start if-branch 0
    if True:
        # Type assignement.
        tokenize_yaml_0_0 = str
        tokenize_yaml_0_1 = bytes
        tokenize_yaml_0_2 = typing.Union[str, bytes]
        tokenize_yaml_0_3 = yaml
        tokenize_yaml_0_4 = None
        tokenize_yaml_0_5 = str
        tokenize_yaml_0_6 = Exception
        tokenize_yaml_0_7 = bytes
        tokenize_yaml_0_8 = bytes


# Generated at 2022-06-26 10:42:42.689061
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Assigning to scalar_0
    scalar_0 = tokenize_yaml("123,456.789")
    assert scalar_0.value == '123,456.789'
    assert scalar_0.start == 0
    assert scalar_0.end == 11
    assert scalar_0.content == '123,456.789'
    # Assigning to dict_0
    dict_0 = tokenize_yaml("""\
    foo: bar
    baz: qux
    """)
    # Assigning to scalar_1
    scalar_1 = dict_0.mapping['foo']
    assert scalar_1.value == 'bar'
    assert scalar_1.start == 8
    assert scalar_1.end == 11

# Generated at 2022-06-26 10:42:55.312770
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert (
        tokenize_yaml(
            b"\x9d\x9a\xec\x0c\x1c\x14\xfd\xf2\xbd\xbd\x1b\x00\x0e\x05\xfb\xa4\x06\x04\x07\x0e\x0f\x1f\x14\x0b"
        )
        == b"M"
    )
    assert tokenize_yaml(b"") is None
    assert tokenize_yaml(b"\xd2\xa7\x19J\xaa\xa6\x9f\x98\x06\xa8\x0c\x07\x1d") == "\x00"

# Generated at 2022-06-26 10:43:07.410691
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Simple valid example.
    content = b'name: "Fred"'
    token, _ = validate_yaml(content=content, validator=Schema)
    assert token.content == {"name": "Fred"}
    # Invalid parse.
    try:
        # Invalid parse example.
        content = b'name: "Fred"'
        validate_yaml(content=content, validator=Field(type="string"))
    except ParseError as exc:
        assert exc.text == "Unexpected content."
        assert exc.code == "parse_error"
        assert isinstance(exc.position, Position)
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0


# Generated at 2022-06-26 10:43:16.861926
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = '}q%8S Ohfq9yU37*='
    str_2 = '"\ufeff"'
    str_3 = '\u0018'
    str_4 = '\\""'
    str_5 = '!'
    str_6 = '0.0'
    str_7 = '1.0'
    str_8 = '12345'
    str_9 = '12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890'
    str_10 = '1.7976931348623157e+308'
    str_11 = '1.7976931348623157e+309'
    str_12

# Generated at 2022-06-26 10:43:24.649788
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test case 0
    str_0 = '}q%8S Ohfq9yU37*='
    token_0 = tokenize_yaml(str_0)
    value_0, error_messages_0 = validate_yaml(str_0, token_0)
    assert type(value_0) == ScalarToken
    assert type(error_messages_0) == list


# Generated at 2022-06-26 10:43:37.326691
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '{\n    "key": "value",\n    "nested": {\n        "key": "value"\n    }\n}'
    dict_0 = {
        "key": "value",
        "nested": {
            "key": "value"
        }
    }
    dict_0_val, dict_0_message = validate_yaml(str_0, dict)
    bool_0 = dict_0_val == dict_0
    assert bool_0
    assert dict_0_message is None

# Generated at 2022-06-26 10:43:45.890957
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content="", validator=Field()) == (None, [])

    field_0 = Field()
    field_0.name = 'j^'
    field_0.validators = [
        lambda t: (t, [])
    ]
    field_0.required = True
    field_0.read_only = True
    value, err = validate_yaml(content="", validator=field_0)
    assert err[0].text == "This field is required."



# Generated at 2022-06-26 10:43:48.871277
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '}q%8S Ohfq9yU37*='
    token_0 = tokenize_yaml(str_0)


# Generated at 2022-06-26 10:43:56.632233
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '}q%8S Ohfq9yU37*='
    try:
        validate_yaml(str_0, None)
        assert False, "ValidationError not raised"
    except ValidationError as exc:
        assert exc.code == "parse_error", "exc.code != 'parse_error'"
        assert exc.text == "found character '}' that cannot start any token.", "exc.text != 'found character '}' that cannot start any token.'"
        assert exc.position == Position(char_index=0, column_no=1, line_no=1), "exc.position != Position(char_index=0, column_no=1, line_no=1)"

# Generated at 2022-06-26 10:44:08.806879
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '1'
    validator_0 = int
    (val_0, error_messages_0) = validate_yaml(str_0, validator_0)

    str_1 = '1.0'
    validator_1 = float
    (val_1, error_messages_1) = validate_yaml(str_1, validator_1)

    str_2 = 'test'
    validator_2 = str
    (val_2, error_messages_2) = validate_yaml(str_2, validator_2)

    str_3 = '[1, 2, 3]'
    validator_3 = list
    (val_3, error_messages_3) = validate_yaml(str_3, validator_3)


# Generated at 2022-06-26 10:44:19.719722
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml
    from typesystem import String, Integer
    from typesystem.schemas import Schema

    class FooSchema(Schema):
        name = String()
        age = Integer()

    content = "name: Jon Snow\nage: 38"
    value, error_messages = validate_yaml(content, FooSchema)
    assert value == {"name": "Jon Snow", "age": 38}
    assert error_messages == []
    content = "name: Jon Snow\nage: 38.5"
    value, error_messages = validate_yaml(content, FooSchema)
    assert error_messages == [Message(text="Invalid value.", code="invalid_value")]

    content = "name: Jon Snow\nbar: Jon Snow"

# Generated at 2022-06-26 10:44:25.965178
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:44:34.876709
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '(^`\n;'
    Field_0 = Field(required=True)
    value_0, error_messages_0 = validate_yaml(str_0, Field_0)
    assert len(value_0) < len(error_messages_0)


# Generated at 2022-06-26 10:44:44.169640
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field()
    content = ""
    value, errors = validate_yaml(content, validator)
    assert isinstance(errors, typing.List)
    assert len(errors) == 1
    assert isinstance(errors[0], Message)
    assert isinstance(errors[0].position, Position)
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 1
    assert errors[0].position.char_index == 0
    assert errors[0].text == "No content."
    assert errors[0].code == "no_content"
    assert errors[0].required
    assert errors[0].name == "root"
    assert value is None

    validator = Field(key="value")
    content = "value: foo\n"
    value, errors = validate_

# Generated at 2022-06-26 10:44:47.180835
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '  xkJ}'
    token_0 = tokenize_yaml(str_0)


# Generated at 2022-06-26 10:45:01.839687
# Unit test for function validate_yaml
def test_validate_yaml():
    content_0 = '?$2!r\x1b?Z]\x0bz'
    validator_0 = List[str]
    value_0, errors_0 = validate_yaml(content_0, validator_0)
    content_1 = '\t\x1e\x1d\x11\x1a\x1b\x1e'
    validator_1 = List[str]
    value_1, errors_1 = validate_yaml(content_1, validator_1)
    content_2 = 'G<XQr~\x14\x0c\x17\x0e\x1f\x1a\x0e\x0c'
    validator_2 = List[str]

# Generated at 2022-06-26 10:45:14.308487
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert tokenize_yaml('YtJbeEGH;?-#lgBt*') == None
    assert tokenize_yaml('"%c5bDR&?*n') == None
    assert tokenize_yaml('p"=1Cx}') == None
    assert tokenize_yaml('0{0|?<N5>5N') == None
    assert tokenize_yaml('A-k[q"yn|!!') == None
    assert tokenize_yaml('yAO.Rxk)B2Q#^') == None
    assert tokenize_yaml('s2@zx3T\n%&') == None
    assert tokenize_yaml('&Y%BON1h;$*') == None
    assert tokenize_yaml('*n\\1%%') == None


# Generated at 2022-06-26 10:45:24.645996
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '}q%8S Ohfq9yU37*='
    value_0 = b"\xfa\xe9\xec\x06\xda\xa1\xd3\xdc"
    token_0 = tokenize_yaml(value_0)
    content_0 = '{"name": "Banner", "age": 31}'
    schema_0 = {
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer", "minimum": 18, "maximum": 65},
        },
    }
    field_0 = Field(schema=schema_0)
    value_1 = validate_yaml(content_0, field_0)

# Generated at 2022-06-26 10:45:27.156612
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '}q%8S Ohfq9yU37*='
    validator = {}
    value = validate_yaml(content, validator)
    assert value

# Generated at 2022-06-26 10:45:35.739854
# Unit test for function validate_yaml
def test_validate_yaml():
  try:
    validator = int
    yaml_or_json = '{"key":123}'
    value, error = validate_yaml(yaml_or_json, validator)
    assert value == 123
    assert error is None
  except Exception as e:
    raise Exception(
        f"""
        Failed with argument
        yaml_or_json = {yaml_or_json}
        validator = {validator}
        Exception = {e}
        """)



# Generated at 2022-06-26 10:45:36.797102
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert True


# Generated at 2022-06-26 10:45:46.027367
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type="string")

    str_0 = 'sua\n  sj: "pipi\n  "\n  lululu: "lalala"'
    value_0, error_messages_0 = validate_yaml(str_0, validator)
    
    assert value_0 == {'sua': {'sj': 'pipi\n  ', 'lululu': 'lalala'}}
    assert error_messages_0 == []


# Generated at 2022-06-26 10:45:52.739783
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '}q%8S Ohfq9yU37*='
    token_0 = tokenize_yaml(str_0)


# Generated at 2022-06-26 10:46:02.822048
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '{"a": {"b": [{"c": "d"}]}, "e": "f"}'
    class SimpleListSchema(Schema):
        a = Field(sub_fields={"b": Field(sub_fields={"c": Field()})})
        e = Field()

    result = validate_yaml(str_0, SimpleListSchema)
    assert result == ({'a': {'b': [{'c': 'd'}]}, 'e': 'f'}, [])

    # Test with a schema that has been initialized with data
    schema = SimpleListSchema(
        {"a": {"b": [{"c": "d"}]}, "e": "f"}
    )

    result = validate_yaml(str_0, schema)

# Generated at 2022-06-26 10:46:13.250035
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '}q%8S Ohfq9yU37*='
    token_0 = tokenize_yaml(str_0)
    class TestSchema(Schema):
        name = Field(str, required=True)

    value, error_messages = validate_yaml(str_0, TestSchema)
    assert error_messages == [
        Message(
            code="invalid_type",
            text="Expected one of (str, unicode, bytes).",
            position=Position(
                line_no=1, column_no=1, char_index=0, tokens=[token_0]
            ),
        )
    ]
    assert value is None



# Generated at 2022-06-26 10:46:24.186582
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    str_0 = ']DYmWgVvxFtHm2QrLmh]z8@phEbZc%f"9X&*O'
    token_0 = tokenize_yaml(str_0)
    str_1 = 'sH+4X=Y6LJ2PxL<3q]w6'
    token_1 = tokenize_yaml(str_1)
    str_2 = '"Tn,{FcJ`S"H:ytA_n^)'
    token_2 = tokenize_yaml(str_2)
    str_3 = 'g:bRL/G@dK&&Jf^A,9(8V'
    token_3 = tokenize_

# Generated at 2022-06-26 10:46:28.575610
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '''
    foo:
        - 1
        - 2
    '''
    error_text = validate_yaml(content, Schema)
    assert error_text


# Generated at 2022-06-26 10:46:35.957829
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '}q%8S Ohfq9yU37*='
    token_0 = tokenize_yaml(str_0)
    assert token_0.start == 0
    assert token_0.end == 16
    str_1 = '{- 8+'
    token_1 = tokenize_yaml(str_1)
    assert token_1.start == 0
    assert token_1.end == 5
    str_2 = 'Z"z(2?{'
    token_2 = tokenize_yaml(str_2)
    assert token_2.start == 0
    assert token_2.end == 6


# Generated at 2022-06-26 10:46:46.067629
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None
    assert yaml.__version__ == "5.1"
    str_0 = '}q%8S Ohfq9yU37*='
    str_1 = ",=_y)5'@+e],^K"
    str_2 = "A$E![9X4_H:F[c2"
    str_3 = "Eg*C,h{}-Z?C]K)R"
    str_4 = "H5,N.w;k)cNv/?jW"
    str_5 = "Q2'j:qq&W>nvHm\"b"
    str_6 = "TKQ}:1>NZ^1V7%|6"

# Generated at 2022-06-26 10:46:49.182688
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '}q%8S Ohfq9yU37*='
    token_0 = tokenize_yaml(str_0)
    assert validate_yaml(str_0, token_0) == (), "Test Failed"

# Generated at 2022-06-26 10:46:59.844767
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '{key: value, key2: value2}'
    str_1 = '{key1: {key1: {key1: {key1: {key1: value}}}}}'
    str_2 = '{key1: {key1: {key1: {key1: {key1: value}}}}}'
    str_3 = '{key1: [value1, value2, value3]}'
    str_4 = '{key1: [value1, value2, value3]}'
    str_5 = '{key1: [value1, value2, value3]}'
    str_6 = '[1, 2, 3, 4, 5]'
    str_7 = '[1, 2, 3, 4, 5]'
    str_8 = '[1, 2, 3, 4, 5]'
   

# Generated at 2022-06-26 10:47:13.330383
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '''
        apiVersion: v1
          kind: Pod
            metadata:
              name: hello-world
              namespace: default
            spec:
              containers:
                - name: hello-world
                  image: hello-world
        '''
    validator_0 = Field(type="map", required=True, items=Field(type="string"))
    ret_0, err_0 = validate_yaml(str_0, validator_0)
    assert err_0 is None
    str_1 = 'oh5A6L5_Vu//}6S f7V#yM6g!7J 8B'
    validator_1 = Field(type="map", required=True, items=Field(type="string"))

# Generated at 2022-06-26 10:47:20.701971
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        assert validate_yaml() == 'Expected a type of str, bytes, bytearray, but got NoneType.'
    except AssertionError:
        raise AssertionError("Expected AssertionError to be raised.")


# Generated at 2022-06-26 10:47:22.653068
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True


# Generated at 2022-06-26 10:47:32.832522
# Unit test for function validate_yaml
def test_validate_yaml():
    # Case 1
    string = "foo: bar"
    field = Field(type="string")
    value, error_messages = validate_yaml(string, field)
    assert value == "bar"
    assert error_messages == []
    # Case 2
    string = "{'foo': 1}"
    field = Field(type="integer")
    value, error_messages = validate_yaml(string, field)
    assert value == 1
    assert error_messages == []
    # Case 3
    string = "[3, 2, 1]"
    field = Field(type="integer")
    value, error_messages = validate_yaml(string, field)
    assert value == [3, 2, 1]
    assert error_messages == []
    # Case 4
    string = "true"

# Generated at 2022-06-26 10:47:39.661573
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '5'
    str_1 = '3'
    validator_0 = Field(format="int32")
    validator_1 = Field(format="float")
    value_0, error_messages_0 = validate_yaml(str_0, validator_0)
    value_1, error_messages_1 = validate_yaml(str_1, validator_1)
    assert value_0 == 5
    assert len(error_messages_0) == 0
    assert value_1 == 3.0
    assert len(error_messages_1) == 0


# Generated at 2022-06-26 10:47:46.989665
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = '- 4 EJ'
    str_2 = '+P@'
    str_3 = 'Ej+'
    str_4 = ';{?3.YmC'
    str_5 = '{BBAws(cfEhwI}W'
    str_6 = '- xNwE$K2(U6g'
    str_7 = '8K/Wx'
    str_8 = 'CYEL'
    str_9 = 'z.%cB'
    str_10 = 'g(cl;@jK,a'
    str_11 = '{0-t&:Vq"*XZ|'
    str_12 = 'u}I.K`-Y3'
    str_13 = 'K9IW'

# Generated at 2022-06-26 10:47:56.231844
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = ''
    assert validate_yaml(str_0=="",Fie) == ValueError


if __name__ == '__main__':
    str_0 = '}q%8S Ohfq9yU37*='
    token_0 = tokenize_yaml(str_0)
    str_1= '''
    a:
    - b
    - c
    '''
    token_1 = tokenize_yaml(str_1)
    str_2 = '''
    a:
    - b
    - c
    -
      - 
      -
      - d
      - e
    '''
    token_2 = tokenize_yaml(str_2)

# Generated at 2022-06-26 10:48:08.438708
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test for positional error message reporting.
    str_0 = """
- name: Fred
- age: 22
- does_not_exist: 32
- name: Molly
- age: 21
- does_not_exist: 43
"""
    class UserSchema(Schema):
        name = "User"
        fields = {
            "name": Field(type="string", min_length=5),
            "age": Field(type="integer"),
        }

    value, error_messages = validate_yaml(str_0, UserSchema)
    assert len(value) == 2
    assert len(error_messages) == 2
    assert error_messages[0].text == 'No such field: "does_not_exist".'
    assert error_messages[0].code == "does_not_exist"

# Generated at 2022-06-26 10:48:12.094756
# Unit test for function validate_yaml
def test_validate_yaml():
    field = Field(name="foo", type="string")
    error = None

    try:
        value, errors = validate_yaml(
            '{"foo": "bar"}', field
        )  # Expected to fail, value is not a string
    except ValidationError as exc:
        error = exc

    assert error is not None


# Generated at 2022-06-26 10:48:17.902786
# Unit test for function validate_yaml
def test_validate_yaml():
    with raises(ParseError):
        validate_yaml(b'', Field())
    with raises(ParseError):
        validate_yaml('}q%8S Ohfq9yU37*=', Field())


# Generated at 2022-06-26 10:48:22.343411
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    arg0 = yaml.load("""!!python/tuple ['scalar', ['list', 'of', 'scalars']]""")
    res0 = tokenize_yaml("""!!python/tuple ['scalar', ['list', 'of', 'scalars']]""")
    assert (arg0==res0)



# Generated at 2022-06-26 10:48:37.298705
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '{}'
    token_0 = tokenize_yaml(str_0)
    assert token_0 == {}

    str_1 = '{"key_0": "value_0"}'
    token_1 = tokenize_yaml(str_1)
    assert token_1 == {"key_0": "value_0"}

    str_2 = '{"key_0": []}'
    token_2 = tokenize_yaml(str_2)
    assert token_2 == {"key_0": []}

    str_3 = '{"key_0": ["value_0", "value_1"]}'
    token_3 = tokenize_yaml(str_3)
    assert token_3 == {"key_0": ["value_0", "value_1"]}


# Generated at 2022-06-26 10:48:45.170811
# Unit test for function validate_yaml
def test_validate_yaml():
    # assert yaml is not None, "'pyyaml' must be installed."
    str_0 = '{% for animal in animals: %}\n  {{ animal }} is awesome!\n{% endfor %}'
    token_0 = tokenize_yaml(str_0)
    assert token_0.start == 0
    assert token_0.end == len(str_0) - 1
    assert token_0.children[0].start == 3
    assert token_0.children[0].end == 12
    assert token_0.children[1].start == 14
    assert token_0.children[1].end == 54
    assert token_0.children[2].start == 56
    assert token_0.children[2].end == len(str_0) - 2
    # Case 1
    str_1 = ''
   

# Generated at 2022-06-26 10:48:56.264882
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test with an object instance
    class TestSchema(Schema):
        my_field = Field(type=int, required=True)

    assert validate_yaml('my_field: 1', TestSchema) == ({"my_field": 1}, [])
    assert validate_yaml('my_field: "test"', TestSchema) == (None, [Message(text="Must be of type 'int'.", code="type_error", position=Position(line_no=1, column_no=8, char_index=9))])
    assert validate_yaml('', TestSchema) == (None, [Message(text="This field is required.", code="required", position=Position(line_no=1, column_no=1, char_index=0))])

# Generated at 2022-06-26 10:49:06.753759
# Unit test for function validate_yaml
def test_validate_yaml():
  Schema = typing.TypeVar('Schema', bound='Schema')
  class NewType:
    pass
  new_type = NewType()
  new_type.Schema = Schema
  try:
    from yaml import CLoader as Loader, CDumper as Dumper
  except ImportError:
    from yaml import Loader, Dumper
  class Field(typing.Generic[Schema], typing.Protocol):
    schema: object
    name: typing.Optional[str]
    errors: typing.List[ValidationError]
    error_messages: typing.List[Message]
    validate: typing.Callable[[typing.Any], typing.Any]
  field = Field()
  class IntegerField(Field, typing.Generic[Schema]):
    def __init__(self):
      pass

# Generated at 2022-06-26 10:49:13.609933
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    for case in [test_case_0]:
        try:
            case()

        except ParseError as exc:
            print("Parse error: {}".format(exc))

        except ValidationError as exc:
            print("Validation error: {}".format(exc))

        except Exception as exc:
            print("Unexpected exception: {}".format(exc))

# Generated at 2022-06-26 10:49:21.109402
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '}q%8S Ohfq9yU37*='
    token_0 = tokenize_yaml(str_0)
    validator_1 = types.Union[bool, str, None]
    value_1, messages_1 = validate_yaml(str_0, validator_1)
    assert value_1 == None
    assert messages_1 == ['None']


# Generated at 2022-06-26 10:49:26.956777
# Unit test for function validate_yaml
def test_validate_yaml():
    assert tokenize_yaml("foo") == ScalarToken("foo", 0, 2, content="foo")
    assert tokenize_yaml("{}") == DictToken({}, 0, 1, content="{}")
    assert tokenize_yaml("[]") == ListToken([], 0, 1, content="[]")

    with pytest.raises(ParseError, match="No content."):
        tokenize_yaml("")

    with pytest.raises(ParseError, match="Unexpected end of line"):
        tokenize_yaml("\n")

    with pytest.raises(ParseError, match="Did not find expected alphabetic"):
        tokenize_yaml("\n  ")

    with pytest.raises(ParseError, match="Expected a key"):
        tokenize

# Generated at 2022-06-26 10:49:37.773571
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = ''
    str_1 = '"f5ghQ`(a:8gKC]'
    str_2 = '"f5ghQ`(a:8gKC]'
    str_3 = 'S_VuQt9F~7V3kqE('
    str_4 = 'bA@[1uMkS:V(2"9~'
    str_5 = 'bA@[1uMkS:V(2"9~'
    str_6 = 'bA@[1uMkS:V(2"9~'
    str_7 = '@:!8&24)U(Z}CQZ '
    str_8 = '@:!8&24)U(Z}CQZ '

# Generated at 2022-06-26 10:49:42.527158
# Unit test for function validate_yaml
def test_validate_yaml():

    class TestValidator(Field):
        def validate(self, value: typing.Any) -> typing.Any:
            raise ValidationError("Test validation error.")

    str_0 = '}q%8S Ohfq9yU37*='
    result_0 = validate_yaml(str_0, TestValidator)
    value, error_messages = result_0

    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Test validation error."



# Generated at 2022-06-26 10:49:48.568075
# Unit test for function validate_yaml
def test_validate_yaml():
    # Try to validate against a Schema that requires a list with a validator
    # named 'field_1' that requires a list.

    # Create a schema validator with a field named 'field_1' that requires
    # a string.
    class SchemaA(Schema):
        field_1 = String(required=True)

    # Create the string to be validated.
    str_0 = 'field_1: [1, 2]'

    # Create expected messages for the error codes.
    message_1 = 'The value must be a string.'

    # Try to validate against the schema.
    token_0 = tokenize_yaml(str_0)

    # Create the expected error messages.

# Generated at 2022-06-26 10:49:58.547898
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    token = tokenize_yaml(b'foo: bar')
    value, error_messages = validate_yaml(b'foo: bar', token)
    assert value == {'foo': 'bar'}
    assert not error_messages
    token = tokenize_yaml('{name: Jane, age: 25}')
    value, error_messages = validate_yaml(b'{name: Jane, age: 25}', token)
    assert value == {'name': 'Jane', 'age': 25}
    assert not error_messages



# Generated at 2022-06-26 10:50:03.084008
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    assert isinstance(yaml, (type(None), typing.ModuleType))


# Generated at 2022-06-26 10:50:04.596341
# Unit test for function validate_yaml
def test_validate_yaml():
    token = tokenize_yaml('{}')

# Generated at 2022-06-26 10:50:17.426659
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    try:
        str_0 = 'TshLkH%c7.j`'
        token_0 = tokenize_yaml(str_0)
    except ParseError as exc_0:
        assert exc_0.position.line_no == 1
        assert exc_0.position.column_no == 1
        assert exc_0.position.char_index == 0
        assert str(exc_0) == 'Parse error at line 1 column 1 (char 0): No content.'
    try:
        str_1 = '1\ni'
        token_1 = tokenize_yaml(str_1)
    except ParseError as exc_1:
        assert exc_1.position.line_no == 2
        assert exc_1.position.column_no == 1
        assert exc_1.position.char_index

# Generated at 2022-06-26 10:50:21.837793
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '}q%8S Ohfq9yU37*='
    validator_0 = Field(name='', type='string')
    result_0 = validate_yaml(content=str_0, validator=validator_0)


# Generated at 2022-06-26 10:50:29.828509
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(name="foo", type="int")
    value, errors = validate_yaml('foo: abc', validator)
    assert errors[0].text == "Invalid integer value."
    assert errors[0].code == "invalid_integer_value"
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 9
    assert errors[0].position.char_index == 8
    assert value is None

    validator = Field(name="foo", type="string")
    value, errors = validate_yaml('foo: 2', validator)
    assert errors[0].text == "Invalid value. Expected a string."
    assert errors[0].code == "invalid_value"
    assert errors[0].position.line_no == 1

# Generated at 2022-06-26 10:50:38.779710
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    assert validate_yaml(b"name: foo", MySchema) == ({"name": "foo"}, [])

    with pytest.raises(ValidationError) as exc_info:
        validate_yaml(b"name: 123", MySchema)

    error_messages = exc_info.value.messages
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be a string."
    assert error_messages[0].code == "invalid_type"
    assert error_messages[0].position == Position(
        line_no=1, column_no=7, char_index=6
    )



# Generated at 2022-06-26 10:50:39.920984
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True == True


# Generated at 2022-06-26 10:50:50.752926
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = str('fI_0bv4!W3Mh')
    str_2 = str('0C8W#')
    str_3 = str('@6aZ')
    str_4 = str('%DbzX6')
    str_5 = str('hU6*o l*')
    str_6 = str('m)2QJ5R5H')
    str_7 = str('g$pvxNY*7P')
    str_8 = str('G#1XV')
    str_9 = str('C#-&$')
    str_10 = str('f\'')
    str_11 = str('Yz')
    str_12 = str('eIw-')
    str_13 = str('K')

# Generated at 2022-06-26 10:50:52.930025
# Unit test for function validate_yaml
def test_validate_yaml():
    yaml_0 = 'jx&x\'[a$'
    value_0, error_messages_0 = validate_yaml(yaml_0, Field)


# Generated at 2022-06-26 10:51:05.846404
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b"""name: Fred
age: 123
sex: Male
employed: true
"""
    class Person(Schema):
        name = String(required=True)
        age = Integer(required=True)
        sex = String()
        employed = Boolean()

    value, error_messages = validate_yaml(content, validator=Person)
    assert value == {
        "name": "Fred",
        "age": 123,
        "sex": "Male",
        "employed": True,
    }
    assert not error_messages



# Generated at 2022-06-26 10:51:17.642907
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '{"Hello": 1, "data": "JSON"}'
    str_1 = '{"Hello": [2, "JSON"], "data": "YAML"}'
    str_2 = '{"Hello": {"JSON": "YAML"}, "data": "JSON"}'
    str_3 = '{"Hello": 1, "data": "JSON", "JSON": "YAML"}'
    str_4 = '{"hello": "world"}'
    str_5 = '{"hello": "world", "data": ["JSON", "YAML"]}'
    str_6 = '{"hello": "world", "data": ["JSON", "YAML"], "JSON": {"hello": "world"}}'

    # JSON data

# Generated at 2022-06-26 10:51:28.779951
# Unit test for function validate_yaml
def test_validate_yaml():
    try:
        if yaml:
            str_0 = '"Pj/W@/vw>~\x17'
            token_0 = tokenize_yaml(str_0)
        else:  # pragma: no cover
            raise ImportError()
    except (ParseError, TypeError, ValueError):
        pass

# Generated at 2022-06-26 10:51:39.470622
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    msg_0 = Message(
        text="Parse error: 'while scanning a simple key\n in \"<unicode string>\", line 1, column 1:\n}\n^\nunexpected '}'\n': 'while scanning a simple key\n in \"<unicode string>\", line 1, column 1:\n}\n^\nunexpected '}'\n'",
        code='parse_error',
        position=Position(
            line_no=1,
            column_no=1,
            char_index=0
        )
    )
    str_0 = '}'