

# Generated at 2022-06-26 10:41:53.742872
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert isinstance(tokenize_yaml(""), ScalarToken)
    assert tokenize_yaml("true") == True
    assert tokenize_yaml("false") == False
    assert tokenize_yaml("null") == None
    assert isinstance(tokenize_yaml("1"), ScalarToken)
    assert isinstance(tokenize_yaml("-1"), ScalarToken)
    assert isinstance(tokenize_yaml("1.1"), ScalarToken)
    assert isinstance(tokenize_yaml("-1.1"), ScalarToken)
    assert isinstance(tokenize_yaml("'a'"), ScalarToken)
    assert isinstance(tokenize_yaml("\"a\""), ScalarToken)
    assert isinstance(tokenize_yaml(""" "a" """), ScalarToken)

# Generated at 2022-06-26 10:41:55.031874
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True


# Generated at 2022-06-26 10:42:01.497282
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    content_0 = b'a: b'
    value_0, errors_0 = validate_yaml(content_0, {"a": "string"})
    assert errors_0 == []
    assert value_0 == {"a": "b"}

    content_1 = b'a: b'
    value_1, errors_1 = validate_yaml(content_1, {"a": "string"})
    assert errors_1 == []
    assert value_1 == {"a": "b"}

    content_2 = b''
    value_2, errors_2 = validate_yaml(content_2, {"a": "string"})
    assert len(errors_2) == 1
    assert errors_2[0].position == Position(column_no=1, line_no=1, char_index=0)
    assert errors_2

# Generated at 2022-06-26 10:42:08.222584
# Unit test for function validate_yaml
def test_validate_yaml():
    content_0 = b'\xca\xa2\xa8\x88\x10\x8d'
    validator_0 = re.compile('^((?:[a-z0-9]+(?:[\\.\\-][a-z0-9]+)*))\\.com$')

    # Call validate_yaml with arguments content_0 and validator_0.
    assert True # TODO: implement your test here



# Generated at 2022-06-26 10:42:19.918679
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    input_str = """
        abc: 123
    """
    token_0 = tokenize_yaml(input_str)
    token_1 = tokenize_yaml(input_str)
    assert token_0 == token_1
    assert token_0.end - token_0.start == len(input_str)

    input_str = """
        abc: 123
        def: 456
    """
    token_0 = tokenize_yaml(input_str)
    token_1 = tokenize_yaml(input_str)
    assert token_0 == token_1
    assert token_0.end - token_0.start == len(input_str)

    input_str = """
        - 123
        - 456
    """
    token_0 = tokenize_yaml(input_str)


# Generated at 2022-06-26 10:42:32.245009
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    """Test the tokenize_yaml function"""
    content = b"hello: world"
    assert getattr(tokenize_yaml(content), "start", None) == 0
    assert getattr(tokenize_yaml(content), "end", None) is None
    assert getattr(tokenize_yaml(content), "content", None) == "hello: world"
    assert getattr(tokenize_yaml(content).value, "hello", None) == "world"
    assert getattr(tokenize_yaml(content).value, "start", None) == 0
    assert getattr(tokenize_yaml(content).value, "end", None) is None
    assert getattr(tokenize_yaml(content).value, "content", None) == "hello: world"


# Generated at 2022-06-26 10:42:34.247141
# Unit test for function validate_yaml
def test_validate_yaml():
    result = validate_yaml(b'F\xfb', Field)
    assert result == (None, [])



# Generated at 2022-06-26 10:42:41.251696
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert callable(tokenize_yaml)

    content = b'[{foo: bar}, {spam: eggs}]'
    token = tokenize_yaml(content)
    assert isinstance(token, ListToken)

    content = b'\xEF\xBB\xBFfoo: bar'
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)

    content = b'\xEF\xBB\xBFfoo: bar'
    token = tokenize_yaml(content)
    assert isinstance(token, DictToken)


# Generated at 2022-06-26 10:42:41.975908
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert callable(tokenize_yaml)



# Generated at 2022-06-26 10:42:46.674535
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # TODO: Implement test
    result = tokenize_yaml(bytes_0)
    assert token_0 == result, "Did not return the expected result."


# Generated at 2022-06-26 10:43:04.790060
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test with a simple validator that expects a sequence.
    schema = typing.cast(Schema, Schema.of(typing.List[int]))

    value, errors = validate_yaml(content="- 1\n- 2\n- 3", validator=schema)
    assert value == [1, 2, 3]
    assert not errors

    value, errors = validate_yaml(content="- 1", validator=schema)
    assert value == [1]
    assert not errors

    value, errors = validate_yaml(content="", validator=schema)
    assert value == []
    assert not errors

    value, errors = validate_yaml(content="invalid", validator=schema)
    assert value is None
    assert len(errors) == 1

# Generated at 2022-06-26 10:43:16.790824
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    
    class TestSchema(Schema):
        p = Field(key="p")
        q = Field(key="q")
        d = Field(key="d")
        s = Field(key="s")

    test_case_0(
        validator=TestSchema,
        result=({'p': '6Bm>[\tJ\\$a', 'q': '6Bm>[\tJ\\$a', 'd': '6Bm>[\tJ\\$a', 's': '6Bm>[\tJ\\$a'}, [])
    )

# Generated at 2022-06-26 10:43:28.641596
# Unit test for function validate_yaml
def test_validate_yaml():
    assert _get_position("#", -1) == Position(1, 2, 1)
    assert _get_position("\t#", -1) == Position(1, 3, 2)
    assert _get_position("#\n", -1) == Position(2, 2, 2)
    assert _get_position("#\n\t", -1) == Position(2, 3, 3)
    assert _get_position("#\n\t\t#", -1) == Position(2, 4, 4)
    assert _get_position("#\n\t\t", -1) == Position(2, 4, 4)
    assert _get_position("#\n\t\t\n\t", -1) == Position(3, 3, 6)

# Generated at 2022-06-26 10:43:40.645087
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '7\n'
    str_1 = '6Bm>[\tJ\\$a'
    str_2 = 'l\n'
    str_3 = '2pi'
    str_4 = ''
    str_5 = 'm%\n'
    str_6 = 'true'
    str_7 = 'false'
    str_8 = 'null\n'
    str_9 = '"foo"'
    str_10 = '5\n'
    str_11 = '- 1\n'
    str_12 = 'foo: bar\n'
    str_13 = '- 1\n- 2\n'
    str_14 = 'foo: bar\nbar: baz\n'
    token_0 = tokenize_yaml(str_0)
    token_1

# Generated at 2022-06-26 10:43:47.043575
# Unit test for function validate_yaml
def test_validate_yaml():
    with pytest.raises(ParseError):
        validate_yaml("{", str)
    value, errors = validate_yaml("", str)
    assert len(errors) == 1
    value, errors = validate_yaml("not-a-number", float)
    assert len(errors) == 1
    value, errors = validate_yaml("unknown-type: test", float)
    assert len(errors) == 1



# Generated at 2022-06-26 10:43:50.014356
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    content = b'foo\ndef: "bar"'
    assert isinstance(tokenize_yaml(content), DictToken)



# Generated at 2022-06-26 10:43:55.070341
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '6Bm>[\tJ\\$a'
    token_0 = tokenize_yaml(str_0)
    str_0 = ''''''
    token_1 = tokenize_yaml(str_0)
    

# Generated at 2022-06-26 10:44:08.036606
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '7V-RaNl+|b9piN0\nJ`'
    token_0 = tokenize_yaml(str_0)
    str_1 = '_m&^|c%F+\nnU`'
    token_1 = tokenize_yaml(str_1)
    str_2 = 'M+Dx\x0bq3~2zJ:g'
    token_2 = tokenize_yaml(str_2)
    str_3 = 'o;F\x14\t/Ri/'
    token_3 = tokenize_yaml(str_3)
    str_4 = '-kM/i=?Xh\x1cQ'
    token_4 = tokenize_yaml(str_4)
    assert token_0 == token

# Generated at 2022-06-26 10:44:19.446048
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."
    field_0 = Field(serialized_name="_sk", deserialized_name="sk")
    field_1 = Field(serialized_name=")6", deserialized_name="6")
    field_2 = Field(serialized_name="f&F", deserialized_name="fF")
    field_3 = Field(serialized_name="el{", deserialized_name="el")
    field_4 = Field(serialized_name="Rw&M", deserialized_name="RwM")
    field_5 = Field(serialized_name="Cv[", deserialized_name="Cv")
    field_6 = Field(serialized_name="E(S", deserialized_name="ES")
    field_7

# Generated at 2022-06-26 10:44:25.683394
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Test for str and bytes input
    str_input = '{"key":"value"}'
    bytes_input = str_input.encode('utf-8')
    token_str = tokenize_yaml(str_input)
    token_bytes = tokenize_yaml(bytes_input)
    assert type(token_str) is type(token_bytes)

    # Test for ScalarToken
    str_1 = 'abc'
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, ScalarToken)

    # Test for ListToken
    str_2 = '["abc", "def" ]'
    token_2 = tokenize_yaml(str_2)
    assert isinstance(token_2, ListToken)

    # Test for DictToken

# Generated at 2022-06-26 10:44:41.146817
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '6Bm>[\tJ\\$a'
    token_0 = tokenize_yaml(str_0)
    str_1 = '\n\n  "5x'
    token_1 = tokenize_yaml(str_1)
    str_2 = '\n\n12\n\n'
    token_2 = tokenize_yaml(str_2)
    str_3 = '\n\n-\n'
    token_3 = tokenize_yaml(str_3)
    str_4 = '\n\n-\n  -\n'
    token_4 = tokenize_yaml(str_4)
    str_5 = '\n\n-\n  -\n    a: 7\n'
    token_5 = tokenize_y

# Generated at 2022-06-26 10:44:48.851880
# Unit test for function tokenize_yaml
def test_tokenize_yaml():

    # test_0
    str_0 = '6Bm>[\tJ\\$a'
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, ScalarToken)
    assert token_0.value == str_0
    assert token_0.start == 0
    assert token_0.end == 10

    # test_1
    str_1 = 'test_value'
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, ScalarToken)
    assert token_1.value == str_1
    assert token_1.start == 0
    assert token_1.end == 10

    # test_2
    str_2 = '100.2'
    token_2 = tokenize_yaml(str_2)
   

# Generated at 2022-06-26 10:44:56.299165
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '6Bm>[\tJ\\$a'
    token_0 = tokenize_yaml(str_0)
    # AssertionError: Invalid token: ScalarToken(6Bm>[\tJ\$a, -1, -1)



# Generated at 2022-06-26 10:45:03.973548
# Unit test for function validate_yaml
def test_validate_yaml():
    content = _get_valid_yaml()
    value, error_messages = validate_yaml(content, "address")
    assert value is not None
    assert value.get("street") == "1600 Amphitheatre Parkway"
    assert value.get("city") == "Mountain View"
    assert value.get("state") == "CA"
    assert value.get("zip") == "94043"
    assert error_messages == []



# Generated at 2022-06-26 10:45:13.628989
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = """a: b
c: d"""
    schema_0 = {
        "type": "object",
        "properties": {
            "a": {"type": "string"},
            "c": {"type": "string"},
        },
        "additionalProperties": False,
    }
    value_0, errors_0 = validate_yaml(str_0, schema_0)
    token_0 = tokenize_yaml(str_0)
    assert value_0 == {"a": "b", "c": "d"}
    assert errors_0 == []
    assert isinstance(token_0, DictToken)
    assert token_0.content == str_0


# Generated at 2022-06-26 10:45:22.653758
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    with pytest.raises(ParseError):
        tokenize_yaml('too late')

    with pytest.raises(ParseError):
        tokenize_yaml('A\nB')

    with pytest.raises(ParseError):
        tokenize_yaml('- A\n- B\n-C')

    with pytest.raises(ParseError):
        tokenize_yaml('A :\n  B')

    with pytest.raises(ParseError):
        tokenize_yaml('0: A')

    # dict
    value,

# Generated at 2022-06-26 10:45:33.106822
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:45:35.925842
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '6Bm>[\tJ\\$a'
    token_0 = tokenize_yaml(str_0)


###
# Tests below this point are generated by script.
###


# Generated at 2022-06-26 10:45:48.811321
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test that validate_yaml raises a ValidationError if called with
    # invalid YAML content.
    schema = Schema([])
    with pytest.raises(ValidationError) as excinfo:
        validate_yaml("{}", schema)

    # Test that validate_yaml raises a ValidationError if called with
    # valid YAML content that does not validate against schema.

# Generated at 2022-06-26 10:45:50.980231
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    pytest.skip("TODO: Write tests")



# Generated at 2022-06-26 10:46:03.690367
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '{'
    token_0 = tokenize_yaml(str_0)

    value, errors = validate_yaml(
        content="{}", validator=Schema
    )  # type: typing.List[Message]
    assert len(errors) == 0

    errors = validate_yaml(content="", validator=Field)
    assert len(errors) == 1
    assert errors[0].code == "no_content"
    assert errors[0].text == "No content."

    errors = validate_yaml(content="abc", validator=Field)
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].text == "Expected a dictionary."
    assert errors[0].position.line_no == 1

# Generated at 2022-06-26 10:46:09.072884
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = 'FoDbCeW@\t'
    token_0 = tokenize_yaml(str_0)
    assert token_0 is not None
    assert len(token_0) == 11



# Generated at 2022-06-26 10:46:10.264413
# Unit test for function validate_yaml
def test_validate_yaml():
    pass


# Generated at 2022-06-26 10:46:22.841170
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        field_A = Field(description="description text")
        field_B = Field(description="description text")

    validator = MySchema()

    str_0 = '6Bm>[\tJ\\$a'
    assert validate_yaml(str_0, validator) == (None, [])
    assert validate_yaml(str_0, validator) == (None, [])
    assert validate_yaml(str_0, validator) == (None, [])

    str_1 = '!@'
    assert validate_yaml(str_1, validator) == (None, [])

    str_2 = '&_^'
    assert validate_yaml(str_2, validator) == (None, [])

# Generated at 2022-06-26 10:46:34.363635
# Unit test for function validate_yaml
def test_validate_yaml():
    typed_schema = Schema({"a": int, "b": float, "c": str})

    str_0 = "a: -3\nb: 3.2\nc: foo"
    token_0 = tokenize_yaml(str_0)

    str_1 = 'a: hello\nb: 5\nc: world'
    token_1 = tokenize_yaml(str_1)

    str_2 = 'a: 5\nb: world\nc: 5'
    token_2 = tokenize_yaml(str_2)

    str_3 = 'a: 3.2\nb: 5\nc: world'
    token_3 = tokenize_yaml(str_3)

    str_4 = 'a: 5\nb: hello\nc: world'
    token_4 = tokenize_yaml

# Generated at 2022-06-26 10:46:44.142668
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '6Bm>[\tJ\\$a'
    token_0 = tokenize_yaml(str_0)
    str_1 = '%[M'
    token_1 = tokenize_yaml(str_1)
    str_2 = '5'
    token_2 = tokenize_yaml(str_2)
    str_3 = 'm9\tS'
    token_3 = tokenize_yaml(str_3)
    str_4 = '\nN@]\t'
    token_4 = tokenize_yaml(str_4)
    str_5 = '|'
    token_5 = tokenize_yaml(str_5)
    str_6 = '\"\t'
    token_6 = tokenize_yaml(str_6)
   

# Generated at 2022-06-26 10:46:55.425461
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        name = String()

    # Parse and validate a valid string.
    token_1, errors_1 = validate_yaml("name: Foo", validator=MySchema)
    assert not errors_1

    # Parse and validate an invalid string.
    token_2, errors_2 = validate_yaml(
        "name: \n" '  "Foo"', validator=MySchema
    )
    assert len(errors_2) == 1
    assert errors_2[0].text == "Invalid top-level value type."
    assert errors_2[0].code == "invalid_type"
    assert errors_2[0].position.line_no == 1
    assert errors_2[0].position.column_no == 0  # zero-based index
    assert errors_

# Generated at 2022-06-26 10:47:07.552601
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '[id: number, string: "hi", array: ["hi", "bye"], boolean: true, boolean: false, array: ["hi", "bye", "ok", "ok", "hi", "bye", "bye", "hi", "hi", "hi", "bye"], string: "hello", string: "hi", array: ["bye", "ok", "ok", "bye", "ok", "bye", "ok", "ok", "ok"], string: "bye", string: "bye", string: "bye", array: ["hi", "hi", "hi", "hi", "bye"], string: "hi", string: "bye", boolean: true, boolean: true, boolean: true, boolean: true, boolean: false, boolean: false, boolean: false, boolean: false]'
    token_0 = tokenize_yaml(str_0)

    str_

# Generated at 2022-06-26 10:47:19.731134
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.types import String
    field = String()

    # Parse and validate a YAML string, returning positionally marked error
    # messages on parse or validation failures.

    # content - A YAML string or bytestring.
    # validator - A Field instance or Schema class to validate against.

    # Returns a two-tuple of (value, error_messages)
    assert isinstance(
        validate_yaml('6Bm>[\tJ\\$a', field),
        (str, typing.List[Message])
    )
    assert isinstance(
        validate_yaml('6Bm>[\tJ\\$a', field),
        (bytes, typing.List[Message])
    )



# Generated at 2022-06-26 10:47:21.760955
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
  assert tokenize_yaml(None) == None



# Generated at 2022-06-26 10:47:31.353135
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    str_0 = '6Bm>[\tJ\\$a'
    str_1 = '6Bm>[\tJ\\$a'
    token_0 = tokenize_yaml(str_0)
    token_1 = tokenize_yaml(str_1)
    assert token_0.start == 0
    assert token_0.end == 8
    assert token_1.start == 0
    assert token_1.end == 8

# Generated at 2022-06-26 10:47:39.994431
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '[\n  1,\n  2,\n  3,\n  4\n]'
    token_0 = tokenize_yaml(str_0)
    value_0, errors_0 = validate_yaml(str_0, {"type": "array"})
    assert errors_0 == []
    assert value_0 == [1, 2, 3, 4]
    value_1, errors_1 = validate_yaml(b'{"field": "openapi", "version": 3}', {"type": "object"})
    assert errors_1 == []
    assert value_1 == {'field': 'openapi', 'version': 3}

# Generated at 2022-06-26 10:47:43.357279
# Unit test for function validate_yaml
def test_validate_yaml():
    token_0 = tokenize_yaml('{}')
    validator_1 = ScalarToken
    value_0 = validate_yaml(token_0, validator_1)
    str_1 = value_0[0]
    str_2 = value_0[1]


# Generated at 2022-06-26 10:47:52.915539
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        """
    example:
      name: John Doe
      email: john@example.com
      age:
        years: 30
        months: 4
      friends:
        - name: Jane Smith
          email: jane@example.com
          age:
            years: 29
            months: 9
        - name: Bob Jones
          email: bob@example.com
          age:
            years: 32
            months: 2
    """,
        Schema,
    )[0]["example"]["friends"][0]["name"] == "Jane Smith"



# Generated at 2022-06-26 10:47:56.541726
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '%$f`2&~n'
    token_0 = tokenize_yaml(str_0)


# Generated at 2022-06-26 10:48:00.061808
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '6Bm>[\tJ\\$a'
    validator_0 = Field(name='a')
    value_0, error_messages_0 = validate_yaml(str_0, validator_0)


# Generated at 2022-06-26 10:48:00.930517
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True == True

# Generated at 2022-06-26 10:48:01.736534
# Unit test for function validate_yaml
def test_validate_yaml():
    assert 1 == 1

# Generated at 2022-06-26 10:48:14.520658
# Unit test for function validate_yaml
def test_validate_yaml():
    class Person(Schema):
        name = StringField()
        age = IntegerField(maximum=100)

    person = Person({"name": "Jan", "age": "10"})
    assert person.is_valid()
    assert not person.errors

    person = Person({"name": "Jan"})
    assert not person.is_valid()
    assert person.errors

    msg = person.errors[0]
    assert isinstance(msg, ValidationError)
    assert msg.code == "missing_field"
    assert msg.field == "age"

    person = Person({"name": "Jan", "age": 1000})
    assert not person.is_valid()
    assert person.errors

    msg = person.errors[0]
    assert isinstance(msg, ValidationError)

# Generated at 2022-06-26 10:48:22.533140
# Unit test for function validate_yaml
def test_validate_yaml():
    content = """
    fruit:
      - banana: manzana
    """
    validator = Field(type="object", properties={"fruit": {"type": "array"}})

    with pytest.raises(ParseError) as exc_info:
        validate_yaml(content, validator)

    assert exc_info.value.text == "Expected a sequence item."
    assert exc_info.value.position.line_no == 2
    assert exc_info.value.position.column_no == 10



# Generated at 2022-06-26 10:48:36.447138
# Unit test for function validate_yaml
def test_validate_yaml():
    assert (True, []) == validate_yaml(
        """
        integer: "123"
        """,
        validator=Field(type="integer"),
    )

    assert (
        False,
        [
            ValidationError(
                text="'integer' is not of a type(s) integer",
                code="type_error.integer",
                position=Position(
                    char_index=10, column_no=11, line_no=2,
                ),
                value="'123'",
            ),
        ],
    ) == validate_yaml(
        """
        integer: "123"
        """,
        validator=Field(type="number"),
    )


# Generated at 2022-06-26 10:48:44.929049
# Unit test for function validate_yaml
def test_validate_yaml():
    validator = Field(type="string")
    yaml_string = '{"name": "Bob"}'
    expected_result = ('{"name": "Bob"}', [])
    actual_result = validate_yaml(yaml_string, validator)
    assert actual_result == expected_result
    yaml_string = '{"name": 123}'
    expected_result = ('{"name": 123}', [ValidationError(code='type', path=['name'], position=Position(char_index=8), text='"123" is not of type "string"')])
    actual_result = validate_yaml(yaml_string, validator)
    assert actual_result == expected_result

# Generated at 2022-06-26 10:48:52.976623
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '{\n  "a": true\n}'
    validator_0 = None
    value_0, error_messages_0 = validate_yaml(str_0, validator_0)
    return value_0, error_messages_0


if __name__ == "__main__":
    value_0, error_messages_0 = test_validate_yaml()
    print(value_0, error_messages_0)

# Generated at 2022-06-26 10:48:59.634908
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '6Bm>[\tJ\\$a'
    token_0 = tokenize_yaml(str_0)
    # We expect an ParseError to be raised with this invalid YAML string.
    try:
        validate_yaml(str_0, None)
    except ParseError:
        pass

# Generated at 2022-06-26 10:49:04.283728
# Unit test for function validate_yaml
def test_validate_yaml():
    value, messages = validate_yaml(
        content=b"a: b\nc: d\ne: 1\n", validator={"a": "string", "c": "string", "e": "string"}
    )
    assert value == {"a": "b", "c": "d", "e": "1"}
    assert messages == []



# Generated at 2022-06-26 10:49:16.086371
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(content=None, validator=None) == (None, [])
    # Validate a schema with no fields
    schema = type("EmptySchema", (Schema,), {})
    test_content = "foo: bar\n"
    value, errors = validate_yaml(content=test_content, validator=schema)
    assert isinstance(value, DictToken)
    assert not errors

    # Validate a schema with a single field
    class TestSchema(Schema):
        field_a = Field(required=True)

    test_content = "field_a: test_value\n"
    value, errors = validate_yaml(content=test_content, validator=TestSchema)
    assert isinstance(value, DictToken)

# Generated at 2022-06-26 10:49:25.616577
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "'6Bm>[\\tJ\\$a"
    content = content.encode('utf-8')
    validator = "4Z%Q-=B?Y"
    validator = validator.encode('utf-8')
    var = validate_yaml(content, validator)
    assert var == (b'\x36\x42\x6d\x3e\x5b\x09\x4a\x5c\x24\x61', [])
    str_1 = '#F\\oWgZ'
    token_1 = tokenize_yaml(str_1)
    assert token_1 is not None
    str_2 = 'C\rE^h'
    token_2 = tokenize_yaml(str_2)
    assert token_2 is not None


# Generated at 2022-06-26 10:49:37.213207
# Unit test for function validate_yaml
def test_validate_yaml():
    content_0 = b"foo"
    validator_0 = {
        'type': 'object',
        'required': ['a'],
        'patternProperties': {'.': {'type': 'string'}},
        'additionalProperties': False,
    }
    value_0, error_messages_0 = validate_yaml(content_0, validator_0)
    assert value_0 == b"foo"
    assert error_messages_0 == [
        Message(
            text="'a' is a required property.",
            code="incomplete",
            position=Position(column_no=1, line_no=1, char_index=0),
        ),
    ]

    content_1 = b"foo: bar"

# Generated at 2022-06-26 10:49:44.869152
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '6Bm>[\tJ\\$a'
    token_0 = tokenize_yaml(str_0)
    assert token_0.value == '6Bm>[\tJ\\$a'
    assert token_0.start_index == 0
    assert token_0.end_index == 11
    assert token_0.content == '6Bm>[\tJ\\$a'
    assert token_0.start_position.line_no == 1
    assert token_0.start_position.column_no == 1
    assert token_0.start_position.char_index == 0
    assert token_0.end_position.line_no == 1
    assert token_0.end_position.column_no == 12
    assert token_0.end_position.char_index == 11
    assert token

# Generated at 2022-06-26 10:49:46.708373
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert callable(tokenize_yaml)




# Generated at 2022-06-26 10:49:56.141048
# Unit test for function validate_yaml
def test_validate_yaml():
    number: typing.Any
    str_0 = '6Bm>[\tJ\\$a'
    (number, error_messages_0) = validate_yaml(str_0, typing.Any)
    str_1 = '6Bm>[\tJ\\$a'
    (number, error_messages_1) = validate_yaml(str_1, typing.Any)


# Generated at 2022-06-26 10:49:58.706790
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True == True  # TODO: implement your test here


# Generated at 2022-06-26 10:50:05.065572
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '6Bm>[\tJ\\$a'
    value, messages = validate_yaml(str_0, validator=token_0)
    if len(messages) != 1:
        raise AssertionError("Failed to validate YAML string")


# Generated at 2022-06-26 10:50:17.658132
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # Test with bytes
    str_0 = '6Bm>[\tJ\\$a'
    token_0 = tokenize_yaml(str_0.encode("utf-8"))
    assert isinstance(token_0, ScalarToken)
    assert token_0.content is None

    # Test with str
    str_1 = '6Bm>[\tJ\\$a'
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, ScalarToken)
    assert token_1.content is not None

    # Test with str
    str_2 = """key: value"""
    token_2 = tokenize_yaml(str_2)

# Generated at 2022-06-26 10:50:22.034970
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '6Bm>[\tJ\\$a'
    token_0 = tokenize_yaml(str_0)
    validator_0 = String()
    assert validate_yaml(str_0, validator_0) == (str_0, [])

# Generated at 2022-06-26 10:50:29.911238
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '6Bm>[\tJ\\$a'
    value_0, error_messages_0 = validate_yaml(str_0, "")
    str_1 = '8W12:^eo\tH'
    value_1, error_messages_1 = validate_yaml(str_1, "")
    str_2 = '`qj;  S8'
    value_2, error_messages_2 = validate_yaml(str_2, "")
    str_3 = 'aWwZpM'
    value_3, error_messages_3 = validate_yaml(str_3, "")
    str_4 = 'O<x?J'
    value_4, error_messages_4 = validate_yaml(str_4, "")
   

# Generated at 2022-06-26 10:50:33.688072
# Unit test for function validate_yaml
def test_validate_yaml():
    class Schema0(Schema):
        field_0 = Field(validators=[])

    str_0 = '6Bm>[\tJ\\$a'
    value, error_messages = validate_yaml(str_0, Schema0)

# Generated at 2022-06-26 10:50:42.456216
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        a = int

    content = b"a: 1"
    value, messages = validate_yaml(content=content, validator=MySchema)
    assert len(messages) == 0
    assert value == {"a": 1}

    content = b"a: 'not an int'"
    value, messages = validate_yaml(content=content, validator=MySchema)
    assert len(messages) == 1
    message = messages[0]
    assert isinstance(message, ValidationError)
    assert message.position.char_index == 3



# Generated at 2022-06-26 10:50:54.934580
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = "foo: bar"
    schema_0 = Schema(fields={"foo": Field(type="number")})
    assert validate_yaml(str_0, schema_0) == (
        None,
        Message(
            text="Field foo is of type number, but we received the value 'bar'.",
            code="invalid_type",
            position=Position(1, 6),
        ),
    )
    str_1 = "foo: bar"
    schema_1 = Schema(fields={"foo": Field(type="number")})

# Generated at 2022-06-26 10:51:07.638061
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    # str_0 = "{\n    \"not_email\": \"foo\",\n    \"not_required\" : \"baz\"\n}"
    # validator_0 = List(items=Email())
    # value_0, error_messages_0 = validate_yaml(str_0, validator_0)
    # # assert value_0 == 'foo'
    # # assert error_messages_0 == 'bar'
    # assert value_0 == ['foo', 'bar']
    # assert error_messages_0 == [
    #     'not_email',
    #     'not_required',
    # ]

    str_1 = "{\n    \"not_email\": \"foo\"\n}"
    validator_1 = Dict

# Generated at 2022-06-26 10:51:11.488048
# Unit test for function validate_yaml
def test_validate_yaml():
    assert Token is not None


# Generated at 2022-06-26 10:51:19.305372
# Unit test for function validate_yaml
def test_validate_yaml():
    assert validate_yaml(
        b"---\n- 1\n- 2\n- 3\n",
        validator=typing.List[int],
    ) == ([1, 2, 3], [])


# Generated at 2022-06-26 10:51:25.828031
# Unit test for function validate_yaml
def test_validate_yaml():
    # Parse and validate a YAML string, returning positionally marked error
    # messages on parse or validation failures.
    # 
    #     content - A YAML string or bytestring.
    #     validator - A Field instance or Schema class to validate against.
    # 
    #     Returns a two-tuple of (value, error_messages)
    # 
    #     The given validator is validated against the parsed content and
    #     either a list of error messages is returned or the parsed content is
    #     returned.
    str_0 = '6Bm>[\tJ\\$a'
    token_0 = tokenize_yaml(str_0)
    str_1 = '3qN1"`:'
    token_1 = tokenize_yaml(str_1)
    str_2

# Generated at 2022-06-26 10:51:30.978118
# Unit test for function validate_yaml
def test_validate_yaml():
    content = b'6Bm>[\tJ\\$a'  # type: ignore
    validator = Field()  # type: ignore
    assert validate_yaml(content, validator)



# Generated at 2022-06-26 10:51:39.980039
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '6Bm>[\tJ\\$a'
    field_0 = Field()
    value_0, error_msg_0 = validate_yaml(str_0, field_0)