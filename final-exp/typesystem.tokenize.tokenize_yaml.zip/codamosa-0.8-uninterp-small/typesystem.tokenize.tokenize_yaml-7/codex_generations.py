

# Generated at 2022-06-26 10:41:49.672040
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert True == True


# Generated at 2022-06-26 10:41:59.992446
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '{"a": 1'
    field_0 = Field(required=True, type="integer")
    str_1, error_messages = validate_yaml(str_0, field_0)
    str_2 = '{"a": 1, "b": 2}'
    field_1 = Field(required=True, type="integer")
    field_2 = Field(required=False, type="string")
    schema_0 = type('schema_0', (Schema, ), {'fields': {'a': field_1, 'b': field_2}})
    str_3, error_messages_0 = validate_yaml(str_2, schema_0)
    assert str_3 == {'a': 1, 'b': '2'}
    assert error_messages_0 == []
    str

# Generated at 2022-06-26 10:42:10.507286
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Tests assume that `pyyaml` is installed.
    assert yaml is not None, "'pyyaml' must be installed."

    # Test empty content case.
    assert tokenize_yaml("") is None

    # Test string content case.
    assert tokenize_yaml('a: "foobar"') == {'a': 'foobar'}

    # Test int content case.
    assert tokenize_yaml('a: 1') == {'a': 1}

    # Test float content case.
    assert tokenize_yaml('a: 1.1') == {'a': 1.1}

    # Test boolean content case.
    assert tokenize_yaml('a: true') == {'a': True}

    # Test null content case.

# Generated at 2022-06-26 10:42:20.802240
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    str_0 = ""
    with pytest.raises(ParseError) as exc_info:
        token_0 = tokenize_yaml(str_0)
    error_msg_0 = str(exc_info.value)
    assert error_msg_0 == "No content. Location: 1, 1"

    str_1 = "foo: bar"
    with pytest.raises(ParseError) as exc_info:
        token_1 = tokenize_yaml(str_1)
    error_msg_1 = str(exc_info.value)
    assert error_msg_1 == "in \"<unicode string>\", line 1, column 5: expected <block end>, but found ':'."


# Generated at 2022-06-26 10:42:26.376500
# Unit test for function validate_yaml
def test_validate_yaml():
    class Test(Schema):
        name = "Test"

# Generated at 2022-06-26 10:42:35.926876
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = """---
a: 1
b: 2
c: 3
d:
  e: 4
  f: 5
  g:
    h: 6
    i: 7
  j:
    - k: 8
    - l: 9
"""
    token_0 = tokenize_yaml(str_0)
    assert token_0.value == {"a": 1, "b": 2, "c": 3, "d": {"e": 4, "f": 5, "g": {"h": 6, "i": 7}, "j": [{"k": 8}, {"l": 9}]}}
    assert token_0.start == 0
    assert token_0.end == 99
    assert token_0.content == str_0
    assert token_0.key == ""
    assert token_0.path == ()



# Generated at 2022-06-26 10:42:40.198367
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = ':'
    token_0 = tokenize_yaml(str_0)

    # Test for tokenize_yaml function
    assert token_0 == {}, "Expected: {}, but got: {}".format({}, token_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 10:42:53.235153
# Unit test for function validate_yaml
def test_validate_yaml():
    assert issubclass(ParseError, ValidationError)
    assert issubclass(ParseError, ParseError)
    token = tokenize_yaml('some: "value"')
    token = tokenize_yaml('''\
some: "value"
other:
    - "value1"
    - "value2"
''')
    token = tokenize_yaml('''\
some: "value"
other:
    - "value1"
    - "value2"
''')
    token = tokenize_yaml('''\
foo:
    bar:
        - "value1"
        - "value2"
''')

# Generated at 2022-06-26 10:43:03.735156
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    import sys
    import io

    saved_stdin = sys.stdin
    saved_stdout = sys.stdout
    try:
        sys.stdout = io.StringIO()
        str_0 = ':'
        token_0 = tokenize_yaml(str_0)
        sys.stdin = saved_stdin
        sys.stdout = saved_stdout
        assert False
    except:
        sys.stdin = saved_stdin
        sys.stdout = saved_stdout
        pass

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 10:43:16.274259
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    str_0 = '"value1"\n'
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, ScalarToken)

    str_1 = '12345\n'
    token_1 = tokenize_yaml(str_1)
    assert isinstance(token_1, ScalarToken)

    str_2 = '- "value1"\n- "value2"\n'
    token_2 = tokenize_yaml(str_2)
    assert isinstance(token_2, ListToken)
    assert token_2[0].value == "value1"

    str_3 = 'key1: "value1"\nkey2: "value2"\n'
    token_

# Generated at 2022-06-26 10:43:22.446365
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True


# Generated at 2022-06-26 10:43:31.261942
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = 'key: val'
    token_0 = tokenize_yaml(str_0)
    validator_0 = {'type': 'boolean'}
    validator_0 = Schema(validator_0)
    str_1 = """
# creates a list of counts with length equal to the length of the
# first list.
- [1, 2, 3]
- &id001 [4, 5, 6]
- *id001
- 7
-
-
-
       """
    token_1 = tokenize_yaml(str_1)
    validator_1 = {'type': 'boolean'}
    validator_1 = Schema(validator_1)

# Generated at 2022-06-26 10:43:38.292151
# Unit test for function validate_yaml
def test_validate_yaml():

    from typesystem import String, Integer

    class ExampleSchema(Schema):
        value = String(max_length=10)
        count = Integer(minimum=1)

    value, errors = validate_yaml(
        'value: hello\n' 'count: 1',  # type: ignore
        validator=ExampleSchema,
    )

    assert value == {"value": "hello", "count": 1}
    assert errors == []



# Generated at 2022-06-26 10:43:48.654415
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema


    class TestSchema(Schema):
        field_1 = Integer()
        field_2 = String()


    str_0 = '''field_1: 0\nfield_2: test'''
    value_0, errors_0 = validate_yaml(str_0, TestSchema)
    assert value_0 == {"field_1": 0, "field_2": "test"}
    assert not errors_0

    str_1 = '''field_2: test\nfield_1: 0'''
    value_1, errors_1 = validate_yaml(str_1, TestSchema)
    assert value_1 == {"field_1": 0, "field_2": "test"}
    assert not errors_1



# Generated at 2022-06-26 10:43:56.476607
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    assert isinstance(tokenize_yaml("name: foo"), DictToken)

    assert isinstance(tokenize_yaml('name: "foo"'), DictToken)

    assert isinstance(tokenize_yaml("name: 'foo'"), DictToken)

    assert isinstance(tokenize_yaml("name: |\n  foo\n  bar"), DictToken)

    assert isinstance(tokenize_yaml("name: |+\n  foo\n  bar"), DictToken)

    assert isinstance(tokenize_yaml("name: |-\n  foo\n  bar"), DictToken)

    assert isinstance(tokenize_yaml("name: 123"), DictToken)


# Generated at 2022-06-26 10:43:58.399003
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True


# Generated at 2022-06-26 10:44:09.306817
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = ':'
    token_0 = tokenize_yaml(str_0)

    assert isinstance(token_0, DictToken) == True
    assert token_0.start == 0
    assert token_0.end == 0
    assert token_0.children == {}
    assert token_0[0].start == 0
    assert token_0[0].end == 0
    assert token_0[0].children == {}

    str_4 = ': {color: red, name: Cat}'
    token_4 = tokenize_yaml(str_4)

    assert isinstance(token_4, DictToken) == True
    assert token_4.start == 0
    assert token_4.end == 23
    assert token_4.children == {'color': 'red', 'name': 'Cat'}


# Generated at 2022-06-26 10:44:12.858514
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = ':'
    token_0 = tokenize_yaml(str_0)
    assert token_0 == {}



# Generated at 2022-06-26 10:44:20.765681
# Unit test for function validate_yaml
def test_validate_yaml():
    func = validate_yaml
    str_0 = ''
    str_1 = '3'
    str_2 = '---\n- - - 5\n- - yes'
    str_3 = '!!int 5'
    str_4 = 'true false'
    str_5 = '{ first: 1, second: 2 }'
    type_0 = type
    type_1 = type
    validator_0 = type_0
    validator_1 = type_1

    return_value_0 = func(content=str_0, validator=validator_0)
    error_0 = return_value_0[1][0]

    return_value_1 = func(content=str_1, validator=validator_1)
    error_1 = return_value_1[1][0]

    return_

# Generated at 2022-06-26 10:44:31.198119
# Unit test for function validate_yaml
def test_validate_yaml():
    import tempfile
    import yaml
    import os
    import subprocess
    import sys
    import typesystem

    # basic test of syntax validation
    assert validate_yaml(1, typesystem.String())[1][0].code == "type_error"
    assert validate_yaml("hello", typesystem.Integer())[1][0].code == "type_error"
    assert (
        validate_yaml("{}", typesystem.Dictionary({}))[1][0].code == "invalid_key_error"
    )
    assert (
        validate_yaml(
            "{'hello': 'world', 'foo': 'bar'}",
            typesystem.Dictionary({"hello": typesystem.String()}),
        )[1][0].code == "invalid_key_error"
    )

# Generated at 2022-06-26 10:44:47.909667
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test for normalization of integer types
    assert validate_yaml(content=':', validator=int) == (0, [])
    assert validate_yaml(content='-1', validator=int) == (-1, [])
    assert validate_yaml(content='0', validator=int) == (0, [])
    assert validate_yaml(content='1', validator=int) == (1, [])
    # Test for normalization of float types
    assert validate_yaml(content=':', validator=float) == (0.0, [])
    assert validate_yaml(content='-1', validator=float) == (-1.0, [])
    assert validate_yaml(content='0', validator=float) == (0.0, [])

# Generated at 2022-06-26 10:45:02.338285
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = 'value: 1'
    dict_0 = {'value': 1}
    token_0 = tokenize_yaml(str_0)
    assert token_0 == dict_0

    str_1 = '- 1'
    list_1 = [1]
    token_1 = tokenize_yaml(str_1)
    assert token_1 == list_1

    str_2 = 'value: {}'
    dict_2 = {'value': {}}
    token_2 = tokenize_yaml(str_2)
    assert token_2 == dict_2

    str_3 = 'value: []'
    dict_3 = {'value': []}
    token_3 = tokenize_yaml(str_3)
    assert token_3 == dict_3

    str_4 = ' '

# Generated at 2022-06-26 10:45:06.948376
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = ': '
    token_0 = tokenize_yaml(str_0)
    value_0, error_messages_0 = validate_yaml(str_0, validator=Field(str))



# Generated at 2022-06-26 10:45:20.414486
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = ':{}:value:{}'
    validator_0 = (Field(name='test', primitive_type=str, description='test',
        serialization_options={}, constraints=[], internal=False), ':')

    value, error_message = validate_yaml(str_0, validator_0)
    assert value == 'value'
    assert error_message == []

    str_1 = ':{}:value:{}'
    validator_1 = (Field(name='test', primitive_type=list, description='test',
        serialization_options={}, constraints=[], internal=False), ':')

    value, error_message = validate_yaml(str_1, validator_1)
    assert value == ['value']
    assert error_message == []

    str_2 = ':{}:value:{}'


# Generated at 2022-06-26 10:45:26.977143
# Unit test for function validate_yaml
def test_validate_yaml():
    token = tokenize_yaml('{"a": "b"}')
    validator = Schema.of({"a": Field()})
    assert validate_with_positions(token=token, validator=validator, return_value=True) == (
        {"a": "b"},
        None,
    )

# Generated at 2022-06-26 10:45:34.682704
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = (
        '{'
        '  "name": "John Doe",'
        '  "age": 43,'
        '  "address": {'
        '    "street": "10 Downing Street",'
        '    "city": "London"'
        '  }'
        '}'
    )
    expected = {
        "name": "John Doe",
        "age": 43,
        "address": {
            "street": "10 Downing Street",
            "city": "London",
        },
    }
    token_0 = tokenize_yaml(str_0)
    assert token_0.as_dict_token() == expected, "Value does not match"

# Generated at 2022-06-26 10:45:47.596155
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.base import Message, ParseError, Position, ValidationError
    from typesystem.fields import Field
    from typesystem.schemas import Schema

    assert yaml is not None, "'pyyaml' must be installed."

    class Example(Schema):
        hello = Field(type="string")

    json_str = "---\nhello: world\n"
    result = validate_yaml(json_str, validator=Example)
    expected = (
        {
            "hello": "world"
        },
        [],
    )
    assert result == expected

    json_str = "hello: world\n"
    result = validate_yaml(json_str, validator=Example)

# Generated at 2022-06-26 10:46:00.943827
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = '{}'
    token_0 = tokenize_yaml(str_0)
    assert isinstance(token_0, DictToken)

    # Test case where content is bytestring
    bytes_0 = b'{foo: bar}'
    token_1 = tokenize_yaml(bytes_0)
    assert isinstance(token_1, DictToken)

    # Test a good scalar token
    str_1 = 'foo'
    token_2 = tokenize_yaml(str_1)
    assert isinstance(token_2, ScalarToken)
    assert token_2.value == 'foo'

    # Test a good array token
    str_2 = '- foo - bar'
    token_3 = tokenize_yaml(str_2)

# Generated at 2022-06-26 10:46:07.617643
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    from typesystem.tokenize import tokenize_yaml as f
    content = str('\n')
    assert f(content) == None
    content = str('\n')
    assert f(content) == None
    content = str('number: 1\n')
    assert f(content) == None


# Generated at 2022-06-26 10:46:12.746076
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import Integer

    yaml_0 = "1"
    # Validate string content against an Integer field.
    value, error_messages = validate_yaml(yaml_0, field=Integer())
    # Assert that the error messages list is empty.
    assert error_messages == []
    # Assert that the parsed value equals the input value.
    assert value == 1


# Generated at 2022-06-26 10:46:21.329436
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '""'
    assert validate_yaml(str_0,str) == '""'

if __name__ == "__main__":
    test_validate_yaml()

# Generated at 2022-06-26 10:46:33.847307
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test for YAML parse error
    str_0 = "{" 
    validator_0 = Schema(fields={"a": int})
    try:
        result_0 = validate_yaml(str_0, validator_0)
    except ParseError as exc_0:
        assert exc_0.text == "mapping values are not allowed here"
        assert exc_0.code == "parse_error"
        assert exc_0.position == Position(column_no=1, line_no=1, char_index=0)

    # Test for YAML validation error
    str_1 = "a: 1"
    validator_1 = Schema(fields={"b": int})
    value_1, error_messages_1 = validate_yaml(str_1, validator_1)

# Generated at 2022-06-26 10:46:43.748904
# Unit test for function validate_yaml
def test_validate_yaml():
    assert yaml is not None, "'pyyaml' must be installed."

    from typesystem.fields import String

    with pytest.raises(ParseError) as exc_info:
        validate_yaml(":", String())

    assert exc_info.value.code == "parse_error"
    assert exc_info.value.position == Position(
        column_no=1, line_no=1, char_index=0
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_yaml("1", String())

    assert exc_info.value.text == "Must be of type 'str'."
    assert exc_info.value.code == "type_error.str"

# Generated at 2022-06-26 10:46:55.181656
# Unit test for function tokenize_yaml

# Generated at 2022-06-26 10:46:57.990392
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    # Empty string / None cases
    with pytest.raises(ParseError):
        tokenize_yaml(str_0)

    # TODO: add more tests!


# Generated at 2022-06-26 10:47:07.973963
# Unit test for function validate_yaml
def test_validate_yaml():
    class MySchema(Schema):
        number = Field(type="integer")
        text = Field(type="string")

    str_0 = "number: 123\ntext: hello world"
    result_0 = validate_yaml(str_0, validator=MySchema)

    assert result_0.value is not None
    assert len(result_0.errors) == 0

    str_1 = "number: '123'\ntext: hello world"
    result_1 = validate_yaml(str_1, validator=MySchema)

    assert result_1.value is not None
    assert len(result_1.errors) == 1


# Generated at 2022-06-26 10:47:20.324959
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = ':hello'
    token_0 = tokenize_yaml(str_0)
    token_1 = token_0.value
    str_1 = ':hello'
    assert str_1 == token_1
    str_2 = ':world'
    token_2 = tokenize_yaml(str_2)
    token_3 = token_2.value
    str_3 = ':world'
    assert str_3 == token_3
    str_4 = 'key:value'
    token_4 = tokenize_yaml(str_4)
    token_5 = token_4.value
    assert type(token_5) == typing.List
    assert type(token_5[0]) == DictToken
    token_6 = token_5[0].value

# Generated at 2022-06-26 10:47:29.855844
# Unit test for function validate_yaml
def test_validate_yaml():
	str_1 = ':'
	msg_1 = [
			Message(
					text='expected a "{" character or a "[" character.',
					code='invalid_token',
					position=Position(column_no=1, char_index=0, line_no=1),
					),
			]
	(val_1, msg_1) = validate_yaml(str_1, validator=None)
	assert val_1 == None and msg_1 == msg_1


# Generated at 2022-06-26 10:47:31.787407
# Unit test for function validate_yaml
def test_validate_yaml():
    assert False

# Generated at 2022-06-26 10:47:41.586446
# Unit test for function validate_yaml

# Generated at 2022-06-26 10:47:45.658332
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "4"
    validator = Field(required=True)
    value, errors = validate_yaml(content, validator)
    assert value == 4
    assert not errors



# Generated at 2022-06-26 10:47:50.462053
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'name: Alice'
    schema_0 = Schema(fields={'name': Field(name='name', type='string')})
    fn_0 = lambda: validate_yaml(str_0, schema_0)
    fn_1 = lambda: validate_yaml(str_0, schema_0)
    assert fn_0() == fn_1(), 'The function did not return the expected value.'


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 10:48:02.987242
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = ''
    str_1 = 'foo'
    str_2 = '["a", "b"]'
    str_3 = '4'
    str_4 = '"4"'
    str_5 = '{"foo": "bar"}'
    str_6 = '{"foo": [1, 2, 3]}'
    str_7 = 'foo: bar\nbaz: bat'

    assert validate_yaml(str_0, None) == (None, [])
    assert validate_yaml(str_1, None) == (None, [])
    assert validate_yaml(str_2, None) == (None, [])
    assert validate_yaml(str_3, None) == (None, [])
    assert validate_yaml(str_4, None) == (None, [])

# Generated at 2022-06-26 10:48:10.074234
# Unit test for function validate_yaml
def test_validate_yaml(): 
    schema_0 = Schema(fields=[
        Field(name="what", type="str"),
    ])
    str_0 = 'what: "hello"'
    value_0, errors_0 = validate_yaml(str_0, schema_0)
    assert errors_0 == []

# Generated at 2022-06-26 10:48:23.194174
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    str_0 = 'a: b\nc: d\ne: f'
    token_0 = tokenize_yaml(str_0)
    assert token_0.start == 0
    assert token_0.end == 13
    assert token_0.find_child(["a"]).content == "b"
    assert token_0.find_child(["c"]).content == "d"
    assert token_0.find_child(["e"]).content == "f"
    assert token_0.find_child(["a"]).position.line_no == 1
    assert token_0.find_child(["a"]).position.column_no == 2
    assert token_0.find_child(["a"]).position.char_index == 1
    assert token_0.find_child(["c"]).position.line_

# Generated at 2022-06-26 10:48:33.404526
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.primitives import StringType

    class UserSchema(Schema):
        first_name = String(required=True)
        last_name = String(required=False)

    yaml_str = 'first_name: Tyler'
    (user, errors) = validate_yaml(yaml_str, validator=UserSchema())
    assert type(user) == dict
    assert user['first_name'] == 'Tyler'
    assert errors is None

    yaml_str = 'first_name: Tyler\nlast_name: Hobbs'
    (user, errors) = validate_yaml(yaml_str, validator=UserSchema())
    assert type(user) == dict

# Generated at 2022-06-26 10:48:44.811589
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test error handling on an empty YAML string.
    str_0 = ""
    error_0 = None

    try:
        token_0 = validate_yaml(str_0, validator=Schema)
    except ValidationError as err:
        error_0 = err

    assert error_0 is not None
    assert error_0.code == 'parse_error'
    assert error_0.text == 'found character \':\' that cannot start any token.'

    # Test error handling on an invalid YAML string.
    str_1 = ":"
    error_1 = None

    try:
        token_1 = validate_yaml(str_1, validator=Schema)
    except ValidationError as err:
        error_1 = err

    assert error_1 is not None
    assert error_1.code

# Generated at 2022-06-26 10:48:56.055175
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema.of(
        {
            "name": str,
            "age": int,
            "height": float,
            "is_goodboy": bool,
            "is_null": None,
        }
    )
    valid_payload = """name: Harry
age: 11
height: 4.7
is_goodboy: true
is_null: null
"""
    value, messages = validate_yaml(valid_payload, schema)
    assert value == {
        "name": "Harry",
        "age": 11,
        "height": 4.7,
        "is_goodboy": True,
        "is_null": None,
    }
    assert messages == []

    # In this case, the YAML parser will convert the True and False values to
    # "true" and "false".

# Generated at 2022-06-26 10:49:06.664704
# Unit test for function validate_yaml
def test_validate_yaml():
    # Test the case where the validator is a Field
    content_1 = b"{}"
    validator_1 = Field(type="boolean", required=True)

# Generated at 2022-06-26 10:49:16.711121
# Unit test for function validate_yaml
def test_validate_yaml():
    str_1 = (
        """
a:
  c: 1
  d: true
"""
    )
    str_2 = (
        """
a:
  c: "Hello World!"
  d: true
"""
    )
    str_3 = (
        """
a:
  c: "Hello World!"
  d: true
"""
    )
    class MySchema(Schema):
        a = {
            "c": fields.String(min_length=10),
            "d": fields.Boolean(),
        }
    schema_0 = MySchema()
    (value_0, error_messages_0) = validate_yaml(str_1, schema_0)
    (value_1, error_messages_1) = validate_yaml(str_2, schema_0)


# Generated at 2022-06-26 10:49:35.239786
# Unit test for function validate_yaml
def test_validate_yaml():

    field = Field(type="string")
    assert validate_yaml('hello', field) == ('hello', None)

    field = Field(type="string")
    assert validate_yaml('', field) == ('', None)

    field = Field(type="string", min_length=3)
    assert validate_yaml('hello', field) == ('hello', None)

    field = Field(type="string", min_length=3)
    assert validate_yaml('2', field) == (
        '2',
        [ValidationError(
            text="Must have at least 3 characters.",
            code="min_length",
            token=ScalarToken('2', 0, 0, content='2'),
            context=field
        )],
    )


# Generated at 2022-06-26 10:49:46.606553
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.schemas import Schema

    assert yaml is not None, "'pyyaml' must be installed."

    # Test case string 0
    str_0 = ""
    # Test case validator 0
    class validator_0(Schema):
        pass


    # Function test case 0
    assert validate_yaml(str_0, validator_0) == (None, [{'code': 'no_content', 'position': {'column_no': 1, 'line_no': 1, 'char_index': 0}, 'text': 'No content.'}])

    # Test case string 1
    str_1 = ":\n"
    # Test case validator 1
    class validator_1(Schema):
        pass


    # Function test case 1

# Generated at 2022-06-26 10:49:51.293227
# Unit test for function validate_yaml
def test_validate_yaml():
    content = "content"
    validator = Field()
    expected = ({},['Missing error code.'])
    result = validate_yaml(content, validator)
    assert result == expected

# Generated at 2022-06-26 10:49:52.248570
# Unit test for function validate_yaml
def test_validate_yaml():
    assert True

# Generated at 2022-06-26 10:49:56.789708
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '''---
a: 1
'''
    class MySchema(Schema):
        field_a = Field(required=True)


    value, errors = validate_yaml(str_0, validator=MySchema)
    assert value == {'a': 1}
    assert not errors


# Generated at 2022-06-26 10:49:58.356933
# Unit test for function validate_yaml
def test_validate_yaml():
    assert False


# Generated at 2022-06-26 10:50:05.774844
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'hello world!'
    validator_0 = 'str'
    value_0, error_messages_0 = validate_yaml(str_0, validator_0)

    str_1 = 'hello world!'
    validator_1 = 'int'
    value_1, error_messages_1 = validate_yaml(str_1, validator_1)

# Generated at 2022-06-26 10:50:10.196618
# Unit test for function validate_yaml
def test_validate_yaml():
    content = '{"name": "foo"}'
    validator = typing.Type[Schema]
    assert validate_yaml(content, validator) == None


# Generated at 2022-06-26 10:50:19.386665
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = '''
    foo: bar
    bar: foo
    '''

    assert tokenize_yaml(str_0) == {
        "foo": "bar",
        "bar": "foo"
    }

    assert validate_yaml(str_0, Schema({"foo": "string", "bar": "string"})) == ({
        "foo": "bar",
        "bar": "foo",
    }, [])

    str_1 = "foo:"
    token_1 = tokenize_yaml(str_1)


# Generated at 2022-06-26 10:50:25.431453
# Unit test for function validate_yaml
def test_validate_yaml():
    schema = Schema(
        {
            "address": {"type": "string"},
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "notes": {"type": "string"},
        }
    )

    schema.validate_yaml(
        content=b"""
first_name: John
last_name: Doe
address: 1234 Main St.
notes:
  """
    )

# Generated at 2022-06-26 10:50:39.185256
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = """a: b"""
    try:
        error_messages = validate_yaml(str_0, QueryParameters)
    except ValidationError as exc:
        error_messages = exc.messages
    for error_message in error_messages:
        assert error_message.position.char_index == 3 and error_message.position.line_no == 1, error_message.position
        assert error_message.text == "Value must be an object with keys 'b', 'c'." and error_message.code == "invalid", error_message
    try:
        error_messages = validate_yaml(str_0, QueryParameters)
    except ValidationError as exc:
        error_messages = exc.messages
    for error_message in error_messages:
        assert error_message.position.char

# Generated at 2022-06-26 10:50:50.325129
# Unit test for function validate_yaml
def test_validate_yaml():
    """
    This tests the function validate_yaml.
    """
    str_0 = "hello"
    field_0 = Field(validation="string")
    value_0, error_messages_0 = validate_yaml(str_0, field_0)
    assert(value_0 == "hello")
    assert(error_messages_0 == [])

    field_1 = Field(validation="integer")
    value_1, error_messages_1 = validate_yaml(str_0, field_1)
    assert(value_1 == "hello")
    assert(len(error_messages_1) == 1)
    assert(error_messages_1[0].text == "Value must be an integer.")

    field_2 = Field(validation="float")
    value_2, error_messages

# Generated at 2022-06-26 10:50:57.012185
# Unit test for function tokenize_yaml
def test_tokenize_yaml():
    token = tokenize_yaml('')
    assert isinstance(token, ScalarToken)
    assert token._value == ''
    assert token._start_pos == 0
    assert token._end_pos == 0
    assert token._content == ''

    token = tokenize_yaml('  ')
    assert isinstance(token, ScalarToken)
    assert token._value == '  '
    assert token._start_pos == 0
    assert token._end_pos == 1
    assert token._content == '  '

    token = tokenize_yaml('\n')
    assert isinstance(token, ScalarToken)
    assert token._value == '\n'
    assert token._start_pos == 0
    assert token._end_pos == 0
    assert token._content == '\n'

    token = tokenize_y

# Generated at 2022-06-26 10:51:05.239003
# Unit test for function validate_yaml
def test_validate_yaml():
    str_0 = 'name: "Joe"'
    validator_0 = None
    value_0: typing.Any
    error_messages_0: typing.List[Message] = validate_yaml(str_0, validator_0)

    str_1 = 'name: "Joe"'
    validator_1 = Field(required=True)
    value_1: typing.Any
    error_messages_1: typing.List[Message] = validate_yaml(str_1, validator_1)

# Generated at 2022-06-26 10:51:07.892975
# Unit test for function validate_yaml
def test_validate_yaml():
    assert False, "TODO: Write test case for validate_yaml"
    assert True


# Generated at 2022-06-26 10:51:14.823960
# Unit test for function validate_yaml
def test_validate_yaml():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    data = b"""
    name: John
    """
    result = validate_yaml(data, validator=Person)
    assert result == ({"name": "John"}, [])


from typesystem import DynamicField



# Generated at 2022-06-26 10:51:17.431327
# Unit test for function validate_yaml
def test_validate_yaml():
    with pytest.raises(ParseError):
        validate_yaml(':', Field())



# Generated at 2022-06-26 10:51:27.025958
# Unit test for function validate_yaml
def test_validate_yaml():
    value = '''
    hello: world
    hello2: world2
    '''
    validator = Schema(fields={"hello2": Field(type="string", max_length=20)})
    output = validate_yaml(value, validator)
    assert(isinstance(output, tuple))
    assert(len(output) == 2)
    assert(isinstance(output[0], dict))
    assert(isinstance(output[1], list))
    assert(isinstance(output[1][0], Message))
    assert(output[1][0].code == "max_length")


# Generated at 2022-06-26 10:51:38.804571
# Unit test for function validate_yaml
def test_validate_yaml():
    data = {}
    validators = {}
    assert validate_yaml(data, validators) == ({}, [])

    data = None
    validators = {}
    assert validate_yaml(data, validators) == (None, [])

    data = ""
    validators = {}
    with pytest.raises(ParseError):
        validate_yaml(data, validators)

    data = ":"
    validators = {}
    with pytest.raises(ParseError):
        validate_yaml(data, validators)

    data = """
    %YAML 1.1
    ---
    !!map {
      ? !!str "0"
      : !!str "1",
    }
    """
    validators = {}