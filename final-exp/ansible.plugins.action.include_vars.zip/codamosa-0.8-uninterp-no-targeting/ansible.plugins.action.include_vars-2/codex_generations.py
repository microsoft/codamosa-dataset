

# Generated at 2022-06-21 02:27:05.149191
# Unit test for constructor of class ActionModule
def test_ActionModule():
    this_class = ActionModule()
    assert hasattr(this_class, 'run')
    assert hasattr(this_class, '_traverse_dir_depth')
    assert hasattr(this_class, '_load_files_in_dir')
    assert hasattr(this_class, '_load_files')
    assert hasattr(this_class, '_ignore_file')
    assert hasattr(this_class, '_set_root_dir')
    assert hasattr(this_class, '_set_args')
    assert hasattr(this_class, '_set_dir_defaults')
    assert hasattr(this_class, '_is_valid_file_ext')
    assert hasattr(this_class, 'VALID_FILE_EXTENSIONS')

# test _is_valid_file_ext method


# Generated at 2022-06-21 02:27:16.653446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Tests ActionModule run method
    Returns:
        dict: test results
    """

    # Setup
    ## Fake input
    module_input = {"action": "include_vars", "extensions": ["yml", "yaml"], "ignore_files": []}
    ## Fake task
    task = {"action": {"name": "include_vars", "args": module_input}}
    ## Fake module_path
    module_path = 'ansible.plugins.action.include_vars'
    ## Fake shared_loader_obj
    shared_loader_obj = "an object of class SharedPluginLoader (see class definition in ansible/plugins/__init__.py)"
    ## Fake task_vars
    task_vars = {"test": "data1"}
    ## Fake play context

# Generated at 2022-06-21 02:27:21.984102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action.VALID_FILE_EXTENSIONS, list)
    assert isinstance(action.VALID_DIR_ARGUMENTS, list)
    assert isinstance(action.VALID_FILE_ARGUMENTS, list)
    assert isinstance(action.VALID_ALL, list)

# Generated at 2022-06-21 02:27:33.433753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None)

    module._task.args = dict()
    module._task.args['dir'] = 'test/test_dir'
    module._task.args['depth'] = 0
    module._task.args['files_matching'] = '.*\.yml'
    module._task.args['ignore_files'] = '.*\.yml'
    module._task.args['extensions'] = 'yml'
    module._task.args['ignore_unknown_extensions'] = False

    module._set_args()

    assert module.source_dir == 'test/test_dir'
    assert module.depth == 0
    assert module.files_matching == '.*\.yml'
    assert module.ignore_files == '.*\.yml'
    assert module.valid_extensions == 'yml'

# Generated at 2022-06-21 02:27:34.796690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:27:44.365236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    assert ActionModule, 'ActionModule does not exist'

    am = ActionModule(None, None, C.DEFAULT_HASH_BEHAVIOUR, False, PlayContext())
    assert am, 'Failed to create ActionModule object'

    assert hasattr(am, 'show_content'), 'ActionModule object has no attribute show_content'
    am.show_content = True

    assert hasattr(am, 'included_files'), 'ActionModule object has no attribute included_files'
    am.included_files = []

    assert hasattr(am, 'VALID_ALL'), 'ActionModule object has no attribute VALID_ALL'

# Generated at 2022-06-21 02:27:48.910601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(discover_plugins=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:27:52.338005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = dict()
    args['name'] = 'my_var'
    args['file'] = '../test_vars.yml'
    current_task = dict()
    current_task['args'] = args
    test_obj = ActionModule(current_task, {})
    assert test_obj.return_results_as_name == 'my_var'


# Generated at 2022-06-21 02:27:56.486831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule('')
        ActionModule._set_dir_defaults()
    except Exception as e:
        print(e)
        print('Test failed')


test_ActionModule()

# Generated at 2022-06-21 02:28:03.499867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    if 'TEST_INCLUDE_VARS' in os.environ:
        from ansible.plugins.action.include_vars import ActionModule
        r_val = {
            'ansible_facts': {},
            'ansible_included_var_files': [],
            '_ansible_no_log': True
        }

        # Test with empty arguments
        i_val = {
            'args': {
                'name': None,
                '_raw_params': None,
                'file': None,
                'dir': None,
                'files_matching': None,
                'ignore_files': None,
                'hash_behaviour': None
            }
        }
        action = ActionModule(i_val, i_val['args'])

# Generated at 2022-06-21 02:28:30.478722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None


# Generated at 2022-06-21 02:28:38.695782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole

    TASK_NAME = 'include_vars'
    SOURCE_DIR = 'test_dir'
    SOURCE_FILE = 'test_file'
    DEPTH = 0
    FILES_MATCHING = 'match_me'
    IGNORE_FILES = 'ignore_me'
    DATA = {'ignore_files': IGNORE_FILES}

    task = Task()
    task_args = {}
    task._role = IncludeRole()
    task.args = task_args

    action_module = ActionModule(task, task_args)
    action_module._task.args = DATA

    assert action_module.transfers_files == False

    assert action_module.VALID_FILE_EXTENS

# Generated at 2022-06-21 02:28:39.440597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO
    assert True



# Generated at 2022-06-21 02:28:51.588211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create class instance
    action = ActionModule()
    # set_context:
    # task - allow access to the task object
    action._task = {'args': {'hash_behaviour': False, 'name': None, 'file': None, '_raw_params': 'file1.yaml'}}
    # loader - allow access to the loader object
    action._loader = {}
    # file_loader - allow access to the file_loader object
    action._loader._loader = {}
    # role - allow access to the role object
    action._task._role = {'_role_path': '/home/user/roles/example_role/vars'}
    # data_loader - allow access to the data_loader object

# Generated at 2022-06-21 02:29:03.805342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import shutil
    import sys
    import tempfile
    import unittest
    from ansible import constants as C
    from ansible.module_utils._text import to_text
    TESTCASE_DIR = os.path.dirname(__file__)
    TESTCASE_DATA_DIR = os.path.join(TESTCASE_DIR, 'data')
    TESTCASE_TMP_DIR = os.path.join(TESTCASE_DIR, 'tmp')
    TESTCASE_TMP_DATA_DIR = os.path.join(TESTCASE_TMP_DIR, 'data')
    if not os.path.exists(TESTCASE_TMP_DIR):
        os.makedirs(TESTCASE_TMP_DIR)

# Generated at 2022-06-21 02:29:04.832020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = dict()
    assert result


# Generated at 2022-06-21 02:29:12.374199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # For instance variable 'show_content'
    assert actionModule.show_content == True

    # For instance variable 'included_files'
    assert actionModule.included_files == []

    # For method '_set_root_dir'
    # Test case 1:
    actionModule.source_dir = 'vars/main.yml'
    actionModule._task._role = None
    actionModule.source_dir = actionModule._set_root_dir()
    assert actionModule.source_dir == 'vars/main.yml'

    # Test case 2:
    actionModule.source_dir = 'vars/main.yml'
    actionModule

# Generated at 2022-06-21 02:29:14.120144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:29:25.903068
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:29:27.865954
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # returns the plugin instance
    action_plugin = ActionModule()

    # verify that run method returns a dictionary
    assert isinstance(action_plugin.run(), dict)

# Generated at 2022-06-21 02:30:18.680837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert hasattr(obj, 'run')
    assert hasattr(obj, 'VALID_FILE_EXTENSIONS')
    assert hasattr(obj, 'VALID_DIR_ARGUMENTS')
    assert hasattr(obj, 'VALID_FILE_ARGUMENTS')
    assert hasattr(obj, 'VALID_ALL')


# Generated at 2022-06-21 02:30:31.776086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # check with valid dir args
    actionModule = ActionModule(dict(), dict())
    actionModule._task.args = {'dir':'path', 'name':'name', 'hash_behaviour':'hash'}
    actionModule._task.action = 'name'
    actionModule._task._role = None
    actionModule._task._ds = None
    actionModule.run()

    # check with valid file args
    actionModule = ActionModule(dict(), dict())
    actionModule._task.args = {'file': 'path', 'name': 'name', 'hash_behaviour': 'hash'}
    actionModule._task.action = 'name'
    actionModule._task._role = None
    actionModule._task._ds = None
    actionModule.run()

    # check with valid dir and file args

# Generated at 2022-06-21 02:30:35.679503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action_module = ActionModule()
    assert test_action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert test_action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert test_action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert test_action_module.VALID_ALL == ['name', 'hash_behaviour']


#Unit test for set_dir_defaults of class ActionModule

# Generated at 2022-06-21 02:30:37.236751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit tests
    pass

# Generated at 2022-06-21 02:30:44.927498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    test_ActionModule_run() function:
        1. test run function with invalid directory
        2. test run function with invalid file
    '''
    # create a mock class
    class MockActionModule(ActionModule):
        pass

    # create a mock class
    class MockActionBase(ActionBase):
        pass
    
    # create a mock class
    class MockActiobVars(ActionVarsModule):
        pass
    
    # test with invalid directory
    mockActiobVars = MockActiobVars()
    mockActiobVars._task._role = None
    mockActiobVars._task._ds._data_source = "test.yml"

# Generated at 2022-06-21 02:30:52.975133
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.play_context as play_context
    import ansible.playbook.task_include as task_include
    import ansible.vars.manager as variant_manager

    play_context_object = play_context.PlayContext(remote_addr='192.168.122.76')
    task_include_object = task_include.TaskInclude()

    action_object = ActionModule(task=task_include_object, connection=None, play_context=play_context_object, loader=None, templar=None, shared_loader_obj=None)

    assert 'action_base.py' in action_object.__class__.__module__

# Generated at 2022-06-21 02:30:59.022665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #test_vars = [{'file':'test_file'}]
    #test_task_vars = [{'test':'test'}]
    test_obj = ActionModule()
    #test_obj.run(tmp=None,task_vars=test_task_vars)
    test_obj.run()



# Generated at 2022-06-21 02:31:11.830798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest

    import ansible.utils.vars

    class BaseTest(unittest.TestCase):
        def setUp(self):
            import ansible.plugins.action.include_vars

            _action = ansible.plugins.action.include_vars.ActionModule(None)
            _action._task = self.mock_task()
            _action._loader = self.mock_loader()
            self._action = _action

        def mock_task(self):
            class Task:
                def __init__(self, args):
                    self.args = args

                def _role(self):
                    if '_role' in self.args:
                        class Role:
                            def __init__(self, role_path):
                                self._role_path = role_path


# Generated at 2022-06-21 02:31:12.909931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:31:22.079129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # call method run with various parameters and check the return value

    # Create a mock task.
    from ansible.playbook.task import Task
    task = Task()

    # Create a mock role.
    from ansible.playbook.role.definition import RoleDefinition
    role = RoleDefinition()
    role._role_path = "/usr/share/ansible/roles/role1"
    task._role = role

    # Create a mock loader.
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # Create a mock inventory.
    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager()

    # Create a mock variable manager.
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()

    # Create a mock datastructure.


# Generated at 2022-06-21 02:33:29.823125
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Preperations for test for method run of class ActionModule
    # ============================================================================================
    from ansible.plugins.action.include_vars import ActionModule as include_vars_ActionModule
    from ansible.plugins.loader import action_loader

    action_plugin = action_loader.get('include_vars', class_only=True)
    if action_plugin is None:
        action_plugin = action_loader.get(include_vars_ActionModule)

    action = action_plugin(
        task=dict(),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # ============================================================================================


# Generated at 2022-06-21 02:33:40.420026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    source_dir = None
    source_file = None
    return_results_as_name = None
    depth = None
    files_matching = None
    ignore_files = None
    valid_extensions = None
    hash_behaviour = None
    args = {'name': return_results_as_name, 'dir': source_dir, 'file': source_file, 'depth': depth, 'files_matching': files_matching,\
            'ignore_files': ignore_files, 'extensions': valid_extensions, 'hash_behaviour': hash_behaviour}
    test_instance = ActionModule(None, None, None, None, None, None, args, None, None)

# Generated at 2022-06-21 02:33:42.307708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    # TODO
    '''
    pass

# Generated at 2022-06-21 02:33:43.930829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print ("test_ActionModule")
    assert ActionModule('test_task', dict(), dict())



# Generated at 2022-06-21 02:33:51.156002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(None, None, None)
    assert mod.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert mod.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert mod.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-21 02:33:59.458085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest

    class CallBackModule:
        def __init__(self):
            self.results = None
            self.results_file = None
            self.results_all = None
            self.results_dir_defaults = None
            self.results_dir_no_defaults = None

        def set_results(self, results):
            self.results = results

        def set_results_file(self, results):
            self.results_file = results

        def set_results_all(self, results):
            self.results_all = results

        def set_results_dir_defaults(self, results):
            self.results_dir_defaults = results

        def set_results_dir_no_defaults(self, results):
            self.results_dir_no_defaults = results


# Generated at 2022-06-21 02:34:08.795935
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    actionModule = ActionModule(None, None, None, None, None, None)
    actionModule._set_args()

    actionModule.source_dir = './test_files'
    actionModule.files_matching = 'file[0-9]'
    actionModule.ignore_files = 'file1'
    actionModule.valid_extensions = ['yaml']

    actionModule._set_root_dir()
    assert(actionModule.source_dir == './test_files')

    actionModule.depth = 2

    for root_dir, filenames in actionModule._traverse_dir_depth():
        assert(root_dir == './test_files')
        assert(filenames == ['file2', 'file3', 'file4', 'file5'])


# Generated at 2022-06-21 02:34:13.168256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Running unittest of ActionModule constructor')
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)
    print(action_module)

# Generated at 2022-06-21 02:34:16.081431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:34:27.214971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    import ansible.utils.vars
    import tempfile
    import shutil
    import os
    import random
    import string

    random_identifier = ''.join(random.SystemRandom().choice(string.ascii_lowercase) for _ in range(20))
    tmpdir = tempfile.mkdtemp()
    root_dir = os.path.join(tmpdir, 'testdir_{0}'.format(random_identifier))

    varsdir = os.path.join(root_dir, 'vars')
    os.makedirs(varsdir)

    with open(os.path.join(varsdir, 'testfile_{0}.yml'.format(random_identifier)), 'w') as testfile:
        testfile.write('testvar: testval1')
    
   