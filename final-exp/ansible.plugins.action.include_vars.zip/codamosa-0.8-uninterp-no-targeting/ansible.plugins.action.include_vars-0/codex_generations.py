

# Generated at 2022-06-21 02:26:51.767411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am

# Generated at 2022-06-21 02:27:04.951458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_self = ActionModule()
    tmp_dir = '/tmp/'
    task_vars = dict()
    args = {
        'name': 'return_results_as_name',
        'dir': 'source_dir',
        'file': 'source_file',
        '_raw_params': '_raw_params',
        'depth': 'depth',
        'files_matching': 'files_matching',
        'ignore_files': 'ignore_files',
        'extensions': 'extensions',
        'ignore_unknown_extensions': 'ignore_unknown_extensions',
        'hash_behaviour': 'hash_behaviour'
    }
    mock_self._task.args = args

    # Test for method run with directory source
    # source_dir is not None
    # depth is not None
    #

# Generated at 2022-06-21 02:27:16.559059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text

    def mock_get_file_contents(filename):
        return to_text("""
                test:
                    test_dict:
                        - 'test_dict'
                    test_int: 1
                    test_string: 'test str'
                test_list:
                    - 'test 1'
                    - 'test 2'
                test_string: 'test str'
            """), True


# Generated at 2022-06-21 02:27:23.628490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    _set_dir_defaults()
    """
    am = ActionModule()
    am.ignore_files = {'a': 'b'}
    assert am._set_dir_defaults() == {'failed': True, 'message': "{'a': 'b'} must be a list"}

    am.ignore_files = 'a, b'
    assert am._set_dir_defaults() == None
    assert am.ignore_files == ['a,', 'b']

    am.ignore_files = ['a', {'b': 'c'}]
    assert am._set_dir_defaults() == None
    assert am.ignore_files == ['a', {'b': 'c'}]
    """
    _set_args()
    """
    am2 = ActionModule()

# Generated at 2022-06-21 02:27:25.399609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(dict())
    assert obj


# Generated at 2022-06-21 02:27:26.457893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule(dict(), dict())
    assert t

# Generated at 2022-06-21 02:27:38.023836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def _get_action_instance(action_class):
        """ Return an instance of an action class.
            Required for testing constructor of an action class.
        Args:
            action_class: The action class to test.
        Returns:
            Instance of the action class.
        """
        class args(object):
            def __init__(self):
                self.file = ''
                self.name = ''
                self.depth = 0
                self.files_matching = ''
                self.ignore_files = ''
                self.extensions = []
                self.ignore_unknown_extensions = False
                self.hash_behaviour = ''

        class Task(object):
            def __init__(self):
                self._ds = None
                self._role = None
                self._ds = ''
                self.args = args()

# Generated at 2022-06-21 02:27:44.555807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.executor.task_queue_manager import TaskQueueManager

    class TestModule(ActionModule):

        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj


# Generated at 2022-06-21 02:27:45.427492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:27:46.308545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:28:11.900886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:28:15.053956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, '__module__')
    assert hasattr(ActionModule, '__name__')

# Generated at 2022-06-21 02:28:25.225350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test of run() in class ActionModule
    """
    # Execute run
    result = ActionModule.run("", {})
    # Test assertion
    assert result == {'ansible_included_var_files': [], 'ansible_facts': {}, '_ansible_no_log': False}

    # Execute run
    result = ActionModule.run("", {'debug': ""})
    # Test assertion
    assert result == {'ansible_included_var_files': [], 'ansible_facts': {}, '_ansible_no_log': False}

    # Execute run
    result = ActionModule.run("", {'ansible_debug': ""})
    # Test assertion

# Generated at 2022-06-21 02:28:33.366650
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-21 02:28:46.432056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.utils.vars import combine_vars

    def load_my_data(self, data, file_name=None, show_content=True):
        return data

    def noop_unload(self, data, file_name=None):
        return ''

    results = {}
    ActionBase._configure_module = noop_unload
    ActionBase._execute_module = noop_unload
    ActionBase._remove_tmp_path = noop_unload
    ActionBase._load_name_to_path = noop_unload
    ActionBase._create_tmp_path = noop_unload

    class Task:
        def __init__(self):
            self.args = {}

        def set_args(self, args):
            self.args = args


# Generated at 2022-06-21 02:28:58.594472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('method ActionModule.run ...', end='')

    class MockModule(object):
        def __init__(self):
            self.task = MockTask()

    class MockTask(object):
        def __init__(self):
            self.args = {
                '_raw_params': '',
                'name': '',
                'extensions': '',
                'ignore_files': '',
                'files_matching': '',
                'ignore_unknown_extensions': False,
                'hash_behaviour': None,
                'dir': '',
                'file': '',
            }
            self._role = MockRole(self)

    class MockRole(object):
        def __init__(self, task):
            self._task = task
            self._role_path = ''

    # Test case 1

# Generated at 2022-06-21 02:29:06.107517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test the run method of class ActionModule for the following cases:
    
    #1. When depth argument is used
    #2. When files_matching argument is used
    #3. When ignore_files argument is used
    #4. When ignore_unknown_extensions argument is used
    #5. When extensions argument is used
    """
    class TestActionModule(ActionModule):
        def __init__(self):
            self._task = Task()
            self._task.args = {
                'name': None,
                'hash_behaviour': C.DEFAULT_HASH_BEHAVIOUR,
                'dir': None,
                '_raw_params': None
            }
            self._task._role = Role()
            self._task._role._role_path = "test/role"
            self._task._ds

# Generated at 2022-06-21 02:29:15.447454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create an inventory object and a var_manager object
    host_list = [
        'testhost'
    ]

    inventory = InventoryManager(host_list=host_list)
    var_manager = VariableManager(inventory)
    task = Task()
    task._role = None
    task._ds = None
    action = ActionModule(task, {'param': 'value'}, None)

    # no parameter
    assert action.run({})['ansible_facts'] == {}

# Generated at 2022-06-21 02:29:16.349362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:29:16.883056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:30:13.319586
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fqn_class = "ansible.plugins.action.include_vars.ActionModule"
    patcher = AnsibleActionPatcher(fqn_class, "run")

    patcher.mock_module_helper = MockModuleUtilsModule()
    patcher.mock_class = MockAnsibleModule(
        fqn_class,
        run_args={},
        tmp=None,
        task_vars=None,
        result={},
        exit_json_args={},
        exit_json_kwargs={},
        exit_json_return_value=None,
        fail_json_args={},
        fail_json_kwargs={},
        fail_json_return_value=None,

    )
    patcher.assert_not_called = False
    patcher.test()




# Generated at 2022-06-21 02:30:24.914574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule.
    """
    am = ActionModule()
    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert am.VALID_ALL == ['name', 'hash_behaviour']

    assert am.hash_behaviour is None
    assert am.return_results_as_name is None
    assert am.source_dir is None
    assert am.source_file is None
    assert am.depth is None
    assert am.files_matching is None
   

# Generated at 2022-06-21 02:30:25.494535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:30:26.411200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:30:34.184638
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    return_results_as_name = 'vlan'
    source_file = '../ansible/playbooks/vars/vlans.yml'
    hash_behaviour = 'merge'
    depth = 0
    files_matching = '.yml'
    ignore_files = 'vlans.yml'
    ignore_unknown_extensions = False
    valid_extensions = ['yml', 'yaml']

    _task_vars = dict()

    _task = dict()
    _task['_role'] = dict()
    _task['_ds'] = dict()

    _task_args = dict()
    _task_args['file'] = source_file
    _task_args['name'] = return_results_as_name
    _task_args['hash_behaviour'] = hash_behaviour
    _

# Generated at 2022-06-21 02:30:44.036772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import sys
    import pytest
    import mock
    import json

    sys.modules['ansible.modules.system.setup'] = __import__('ansible.modules.system.setup')
    sys.modules['ansible.plugins.connection.ssh'] = __import__('ansible.plugins.connection.ssh')
    from ansible.modules.system.setup import ActionModule
    from ansible.plugins.action.include_vars import ActionModule as include_vars

    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.compat.tests import unittest

    class TestIncludeVars(unittest.TestCase):
        def test_include_vars_file(self):

            module = MagicMock(name="module_obj")

# Generated at 2022-06-21 02:30:53.855201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Unit test: method run()
    task = struct()
    task.args = {'dir': 'dir2', 'depth': 3, 'files_matching': '*.a', 'ignore_files': ['a'], 'name': 's', 'hash_behaviour': 'merge'}
    task_vars = struct()
    a = ActionModule(task, task_vars)
    assert a.source_dir == 'dir2'
    assert a.depth == 3
    assert a.files_matching == '*.a'
    assert a.ignore_files == ['a']
    assert a.return_results_as_name == 's'
    assert a.hash_behaviour == 'merge'
    assert a.valid_extensions   == ['yaml', 'yml', 'json']

# Generated at 2022-06-21 02:30:57.233430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:30:58.802891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    assert False

# Generated at 2022-06-21 02:31:10.038618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(dir(ActionModule))
    print(ActionModule.__name__)
    print(ActionModule.__dict__)
    print(type(ActionModule))
    print(type(ActionModule()))
    print(ActionModule.__bases__)
    print(ActionModule.__doc__)
    print(ActionModule.__module__)
    print(ActionModule.__weakref__)
    obj = ActionModule()
    print(obj)
    print(obj.__str__())
    print(obj.__class__)
    print(obj.__dict__)
    print(obj.__del__)


# Generated at 2022-06-21 02:33:13.968841
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act_mod = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_path=None, shared_loader_obj=None, templar=None, ansible_version_info=None)
    assert act_mod


# Generated at 2022-06-21 02:33:27.404230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ This method tests the return values of method run of class ActionModule
        on valid and invalid input files.
    """

    # Used in testing and initialized here

# Generated at 2022-06-21 02:33:39.398469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=MockTask,
        connection=MockConnection,
        play_context=MockPlayContext,
        loader=MockLoader,
        templar=MockTemplar,
        shared_loader_obj=MockSharedLoaderObj()
    )

    # test ActionModule._set_dir_defaults
    setattr(action_module, 'depth', 0)
    setattr(action_module, 'files_matching', None)
    setattr(action_module, 'ignore_files', None)
    setattr(action_module, 'ignore_files', None)
    action_module._set_dir_defaults()
    assert action_module.depth == 0
    assert action_module.matcher is None
    assert action_module.ignore_files is list()
    set

# Generated at 2022-06-21 02:33:44.301113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = module.run()
    assert result['failed'] == False
    assert result['_ansible_no_log'] == False
    assert result['ansible_included_var_files'] == ""
    assert result['ansible_facts'] == ""
    assert result['message'] == "Module invoked ok"

# Generated at 2022-06-21 02:33:45.123104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__

# Generated at 2022-06-21 02:33:46.271079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:33:56.720916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader = None
    variable_manager = None
    task_vars = None
    task = None
    action_plugin = ActionModule(loader=loader, variable_manager=variable_manager, task=task)

    assert action_plugin.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_plugin.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_plugin.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_plugin.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-21 02:34:06.042248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_module = ActionModule(None, None, load_on_init=False)
    assert test_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert test_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert test_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert test_module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-21 02:34:08.464590
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test ActionModule constructor
    assert not ActionModule(task=None).task

# Generated at 2022-06-21 02:34:09.530347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass