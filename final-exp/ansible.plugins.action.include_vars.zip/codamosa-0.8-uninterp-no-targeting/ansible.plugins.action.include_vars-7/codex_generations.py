

# Generated at 2022-06-21 02:26:55.703567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    act_mod = ActionModule("", {}, {}, {}, {}, "")
    assert act_mod.run() == {}

# Generated at 2022-06-21 02:26:57.309919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-21 02:27:07.139868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock

    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.action as action_plugin

    mock_task = mock.MagicMock()
    mock_task._role = None
    mock_task.ds = None
    mock_task.args = {
        '_raw_params': '../../vars/main.yml'
    }

    action_module = ActionModule(mock_task, {})
    with mock.patch.object(action_module, '_loader', mock.MagicMock(return_value=plugin_loader.ActionModuleLoader.get('vars', True))) as mock_loader:
        mock_loader.load_from_file.return_value = ({'test': 'value'}, False)

        returned_results = action_module.run(task_vars=dict())



# Generated at 2022-06-21 02:27:16.653502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.task_include as t
    filename = "./test/test_include_vars.yml"
    data = to_text(open(filename).read(), errors='surrogate_or_strict')
    temp_task = t.TaskInclude(included_file=data, task_ds=dict(action=dict(name='include_vars', args=dict(name="test_output", dir="./test/vars"))), role=None, task_path=filename, role_path=filename)
    assert temp_task is not None
    assert isinstance(temp_task, t.TaskInclude)

# Test for _set_dir_defaults method of class ActionModule

# Generated at 2022-06-21 02:27:20.065753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    # pylint: disable=protected-access
    fake_task = FakeTask()
    action_module = ActionModule(fake_task, dict())
    assert action_module
    assert action_module._task == fake_task


# Generated at 2022-06-21 02:27:21.107723
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass

# Generated at 2022-06-21 02:27:29.637159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert (am._task.args.get('file', None)) is None
    assert am.source_file == None
    assert am.source_dir == None
    assert am.return_results_as_name == None
    assert (am._task.args.get('depth', None)) is None
    assert am.depth == None
    assert (am._task.args.get('files_matching', None)) is None
    assert am.files_matching == None
    assert (am._task.args.get('ignore_files', None)) is None
    assert am.ignore_files == None
    assert (am._task.args.get('name', None)) is None
    assert am.return_results_as_name == None

# Generated at 2022-06-21 02:27:39.260601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError
    from ansible.plugins.action.copy import ActionModule
    from ansible.module_utils._text import to_text
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar


# Generated at 2022-06-21 02:27:40.167548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No method test for class ActionModule
    return

# Generated at 2022-06-21 02:27:44.919248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def testmethod(self):
        pass

    obj = ActionModule()
    obj.__class__.run = testmethod
    obj.run()



# Generated at 2022-06-21 02:28:18.906526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock class ActionBase
    class MockActionBase():
        class MockResult:
            def __init__(self, **kwargs):
                self.__dict__.update(kwargs)

        def __init__(self, *args, **kwargs):
            self._task = MockActionBase.MockTask(*args, **kwargs)

        class MockTask:
            def __init__(self, *args, **kwargs):
                self.args = {
                    'dir': 'vars'
                }
                self._ds = MockActionBase.MockTask.MockDataSource()
                self._role = None

            class MockDataSource:
                def __init__(self, *args, **kwargs):
                    self._data_source = 'roles/test_role/tasks/main.yml'


# Generated at 2022-06-21 02:28:20.390411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('no unit test code')

# Generated at 2022-06-21 02:28:22.027735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule({},{},True,{})
    assert isinstance(a,ActionModule)

# Generated at 2022-06-21 02:28:25.092853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-21 02:28:27.143931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement test_ActionModule_run
    pass


# Generated at 2022-06-21 02:28:34.234571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-21 02:28:36.092288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-21 02:28:47.602053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(MockActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)

        def _set_dir_defaults(self):
            return super(MockActionModule, self)._set_dir_defaults()

        def _set_args(self):
            return super(MockActionModule, self)._set_args()

        def _set_root_dir(self):
            return super(MockActionModule, self)._set_root_dir()

        def _traverse_dir_depth(self):
            return super(MockActionModule, self)._traverse_dir_depth()

       

# Generated at 2022-06-21 02:29:00.786635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest

    # Helper function to create an instance of the ActionModule class with
    # settings that are appropriate for testing run()
    def create_instance(sourcedir=None, sourcefile=None, task_vars=None):
        actionplugin = ActionModule()
        task = mock()
        task._role = mock()
        task._role._role_path = 'roles/test'
        task._ds = mock()
        task._ds._data_source = 'tasks/test.yml'
        task.args = dict()
        if sourcedir:
            task.args['dir'] = sourcedir
        if sourcefile:
            task.args['file'] = sourcefile
        actionplugin._task = task
        actionplugin._filter_terms = []
        actionplugin._loader = DictDataLoader({})

# Generated at 2022-06-21 02:29:09.803364
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[dict(action=dict(module='test', args=''), register='shell_out')]
    )
    play = Play

# Generated at 2022-06-21 02:30:04.408028
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule
    # Instance module with fake option
    module = ActionModule()
    module._task = object()
    module._task.args = {
        'file': "test_file",
        'name': "test_name",
        'ignore_files': "test_ignore_files",
        'ignore_unknown_extensions' : False
    }
    # Unit test for method run of class ActionModule
    # Instance module with fake option
    module._task._role = object()
    module._task._role._role_path = "role_path"
    module._task._ds = object()
    module._task._ds._data_source = "data_source"

    from ansible.utils.path import unfrackpath
    unfrackpath("fake_path")
    path_exists_orig

# Generated at 2022-06-21 02:30:08.720535
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Test ActionModule'''
    #pylint: disable=no-self-use
    module = ActionModule()
    module._set_dir_defaults()
    # TODO
    # for test

# Generated at 2022-06-21 02:30:11.437048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Tests that ActionModule is constructed correctly
    """
    # Setup
    action = ActionModule({}, {})

    # Assert
    assert isinstance(action, ActionModule)


# Generated at 2022-06-21 02:30:12.848680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 02:30:16.654155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    # test: skip_files_matching='*.json'

    action.run()
    # test: file='file/path.ext'

# Generated at 2022-06-21 02:30:18.455296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None



# Generated at 2022-06-21 02:30:19.292572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:30:29.828332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None)
    assert (action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'])
    assert (action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'])
    assert (action.VALID_FILE_ARGUMENTS == ['file', '_raw_params'])
    assert (action.VALID_ALL == ['name', 'hash_behaviour'])


# Generated at 2022-06-21 02:30:34.806188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(loader=None, templar=None, shared_loader_obj=None)
    a._task = None
    a.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 02:30:41.618142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(dict(
        include_role=dict(
            tasks_from='tasks',
            name='test_role'
        )
    ), None, None)
    assert module.run(tmp='/var/tmp', task_vars=dict()) == module.run(tmp='/var/tmp', task_vars=dict(test_role={'test_role_var': 'test_role_var'}))


# Generated at 2022-06-21 02:32:43.121036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert actionmodule is not None

# Generated at 2022-06-21 02:32:53.831304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import sys
    import pytest, unittest
    sys.modules['_ansible_module_include_vars'] = unittest
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class MyTaskQueueManager(TaskQueueManager):
        def __init__(self, queue=None, inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None):
            print ('This is my task')

# Generated at 2022-06-21 02:33:01.604286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test 1
    # test case: dir field is filled, depth field is given a value, files_matching field is not filled
    # test expectation: dirs should be 1, files should be 0, depth should equal to given value, files_matching should be None
    my_action = ActionModule()
    my_task = class_mock_task()
    my_task.args = {'dir':'test_case_1', 'depth':'test_case_1_depth'}
    my_action._task = my_task
    my_action._set_args()
    assert (1, 0) == (my_action.depth, my_action.files_matching)
    # test 2
    # test case: dir field is filled, files_matching field is given a value, depth field is not filled
    # test expectation: d

# Generated at 2022-06-21 02:33:04.106183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # NOTE: These parameters are for testing purpose,
    #       and should be updated if necessary.
    tmp_dir = "/tmp"
    task_vars = dict()
    task_vars['ansible_verbosity'] = 10

    am = ActionModule(tmp_dir, task_vars)
    print(am)

# unit test for the run() method

# Generated at 2022-06-21 02:33:07.034147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('setup', 'null_command') == ActionModule('setup', 'null_command')
    assert ActionModule('setup', 'null_command') != ActionModule('setup', 'action_echo')


# Generated at 2022-06-21 02:33:09.410294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-21 02:33:17.220290
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert type(action_module) == ActionModule
    assert type(action_module.VALID_FILE_EXTENSIONS) == list
    assert type(action_module.VALID_DIR_ARGUMENTS) == list
    assert type(action_module.VALID_FILE_ARGUMENTS) == list
    assert type(action_module.VALID_ALL) == list
    assert len(action_module.VALID_FILE_EXTENSIONS) > 0


# Generated at 2022-06-21 02:33:20.885965
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(load_options=dict())
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-21 02:33:23.641762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None

# Generated at 2022-06-21 02:33:37.110800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # (ActionModule, task_vars=None)
    #    Creates an instance of ActionModule, validates the task args,
    #    and sets the instance variables from the args
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    ds = {
        'role': None,
        '_role': None,
        'vars': {
            'ignore_files': ['ignore_me.txt'],
            'depth': 0,
            'dir': '/home/asanabria/ansible/testdir',
            'name': 'test'
        },
        '_ds': {
            '_data_source': 'test'
        }

    }
    var_manager = VariableManager()
