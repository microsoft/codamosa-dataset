

# Generated at 2022-06-21 02:27:05.738873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_instance = ActionModule()
    assert test_instance.depth == 0
    assert test_instance.files_matching is None
    assert test_instance.ignore_files is None
    assert test_instance.matcher is None
    assert test_instance.return_results_as_name is None
    assert test_instance.source_dir is None
    assert test_instance.ignore_unknown_extensions == False
    assert test_instance.hash_behaviour is None
    assert test_instance.VALID_DIR_ARGUMENTS == [
        'dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'
    ]
    assert test_instance.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert test_instance.VALID_ALL

# Generated at 2022-06-21 02:27:16.800621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = MockTask()
    mock_task._role = None
    mock_task._ds = None
    # test for run method with passing of dict for _raw_params
    action_module = ActionModule()
    action_module.set_task(mock_task)

    mock_task.args = {'_raw_params': 'test.yml'}

    action_module.run()
    assert action_module.return_results_as_name is None

    # test for run method with passing of string for _raw_params
    mock_task.args = {'_raw_params': 'test.yml'}

    action_module.run()
    assert action_module.return_results_as_name is None

    # test for run method with passing of dict for file

# Generated at 2022-06-21 02:27:25.873699
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    :return:
    """
    import ansible.playbook.role.definition
    import ansible.playbook.task
    import ansible.utils.plugin_docs

    import __main__ as main
    try:
        reload(main)
    except NameError:
        try:
            from importlib import reload
            reload(main)
        except ImportError:
            from imp import reload
            reload(main)

    _ds = ansible.playbook.role.definition.RoleDefinition(
        name='test_role',
        path='/tmp/test_role',
        playbook=None,
        from_files=[]
    )


# Generated at 2022-06-21 02:27:36.676465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.task as task
    from ansible.playbook.play_context import PlayContext

    # test __init__ with given parameters
    play_context = PlayContext()
    task_obj = task.Task()
    task_obj._role = task.Task()
    task_obj._role._role_path = 'roles_path'
    test_obj = ActionModule(task_obj, play_context, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(test_obj, ActionModule)

    # test __init__ with default parameters
    play_context = PlayContext()
    task_obj = task.Task()
    test_obj = ActionModule(task_obj, play_context, loader=None, templar=None, shared_loader_obj=None)
   

# Generated at 2022-06-21 02:27:37.978314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:27:38.789815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:27:47.076358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import shutil
    import tempfile
    import yaml
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping

    def create_yml(dirname, filename, data):
        """ Utility function to create yml files from dict.
        """
        if not path.exists(dirname):
            raise Exception('{0} must be a valid directory'.format(dirname))
        filepath = path.join(dirname, filename)
        with open(filepath, 'w+') as f:
            f.write(yaml.dump(data, default_flow_style=False))

    def clean_test_files(test_files):
        """ Utility function to remove test files after test has finished.
        """

# Generated at 2022-06-21 02:27:54.262384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import sys
    import unittest

    # These tests are skipped because they require the constructor of ActionModule
    # class to be public. When the constructor is private (default), the tests can
    # be ran. To run these tests, change the constructor from private to public
    # (remove "__" from "def __init__(self, task, connection, play_context,
    # loader, templar, shared_loader_obj)"
    #
    # This is not recommended because this may cause issues in the future if the 
    # constructor is modified in the future.

# Generated at 2022-06-21 02:28:03.811381
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:28:13.203390
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # initialize a task
  class MockTask:
    def __init__(self, _args):
      self.args = _args
    def __getitem__(self, key):
      return self.args[key]
  args = {
    'hash_behaviour': 'merge',
    'name': 'any',
    'dir': 'playbooks/vars',
    'depth': 0,
    'files_matching': '.yml$',
    'ignore_files': ['main.yml'],
    'extensions': [],
    'ignore_unknown_extensions': False,
  }
  task = MockTask(args)
  class MockTaskDS:
    def __init__(self, _data_source):
      self._data_source = _data_source

# Generated at 2022-06-21 02:28:42.144808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test for constructor of class ActionModule.
    """
    tmp_path = '/tmp/test_ActionModule'
    task_vars = dict()
    action_module = ActionModule(tmp_path, task_vars)
    assert action_module._task is None

# Generated at 2022-06-21 02:28:47.464595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    filename = '../../library/include_vars.py'
    actionModule = ActionModule()
    assert filename == actionModule._task.data._original_file, \
        'Incorrect actionmodule config file {}'.format(actionModule._task.data._original_file)

# Generated at 2022-06-21 02:28:54.793884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test __init__()
    module = ActionModule()
    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions',
                                          'ignore_unknown_extensions']
    assert module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module.VALID_ALL == ['name', 'hash_behaviour']
    assert not module.TRANSFERS_FILES
    assert module.included_files == []
    assert not module.show_content


# Generated at 2022-06-21 02:29:03.421550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    # test: ActionModule.__init__(self, task, connection, play_context, loader, templar, shared_loader_obj)
    # exception: AnsibleError('Invalid type for "extensions" option, it must be a list')
    task = {}
    connection = {}
    play_context = {}
    loader = {}
    templar = {}
    shared_loader_obj = {}
    test = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)



# Generated at 2022-06-21 02:29:04.041350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:29:11.868737
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # If a file is passed then it should run _load_files method
    # Args:
    #   tmp: Not used
    #   task_vars: Not used
    # Returns:
    #   Dictionary which contains key 'ansible_facts' & 'ansible_included_var_files'
    # Exception:
    #   AnsibleError: raised if 'dir' & 'file' are passed or
    #                if '_raw_params' is not present
    task_vars = {}
    tmp = None

    # _set_args() is called
    # _set_root_dir() is not called as source_dir is not present
    # _load_files() is called with filename as 'test.yaml' as source_file is provided
    #  _loader.load() is called with data from 'test.yaml'

# Generated at 2022-06-21 02:29:19.873849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    patcher = mock.patch('ansible.plugins.action.ActionBase')

    mock_base = patcher.start()

    AM = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert type(AM) == ActionModule

    patcher.stop()

# Generated at 2022-06-21 02:29:28.313756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Constructor of ActionModule works as expected
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    host = Host(name="localhost")
    group = Group(name="test_group")
    group.add_host(host)
    task = Task()
    play_context.prompt = None

    # initialize module

# Generated at 2022-06-21 02:29:37.515886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    import sys
    import tempfile

    sys.stdout = StringIO()
    sys.stderr = StringIO()
    module_args = dict(
        file='/etc/ansible/hosts',
        name='foo'
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )


# Generated at 2022-06-21 02:29:49.226981
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    # Test constructor

# Generated at 2022-06-21 02:30:34.932855
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule) == type


# Generated at 2022-06-21 02:30:42.257155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-21 02:30:49.133010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None, None, 'include_vars', None, None, None, None)
    print(module.run())
    print(module.run(tmp='test', task_vars={'test': {'test': {}, 'test2': {}}},))
    print(module.run(task_vars={'test': {'test': {}, 'test2': {}}},))

# Run unit tests if executed
if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:31:01.279328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

# Generated at 2022-06-21 02:31:06.540405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #    Testing __init__
    a = ActionModule(load_name = 'name', task = 'task', connection = 'conn', play_context = 'play_context', loader = 'loader', shared_loader_obj = 'shared_loader_obj')
    assert a.name == 'name'
    assert a.task == 'task'
    assert a.connection == 'conn'
    assert a.play_context == 'play_context'
    assert a.loader == 'loader'
    assert a.shared_loader_obj == 'shared_loader_obj'



# Generated at 2022-06-21 02:31:10.777072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert len(ActionModule.VALID_FILE_EXTENSIONS) == 3
    assert len(ActionModule.VALID_DIR_ARGUMENTS) == 6
    assert len(ActionModule.VALID_FILE_ARGUMENTS) == 2
    assert len(ActionModule.VALID_ALL) == 2

# Generated at 2022-06-21 02:31:14.942941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'
    assert ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-21 02:31:15.649390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()



# Generated at 2022-06-21 02:31:22.259290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest

    # Test Variables
    ACTION_MODULE_NAME = ActionModule.__name__
    ACTION_PATH = '../../../lib/ansible/plugins/action/'

    # Test Logic
    # Test Case 1: The ActionModule class exists
    import imp
    action_path = ACTION_PATH + ACTION_MODULE_NAME + '.py'
    try:
        imp.load_source(ACTION_MODULE_NAME, action_path)
    except IOError:
        raise unittest.SkipTest('Could not find %s' % action_path)
    from ansible.plugins.action.include_vars import ActionModule

    # Test Case 2: The ActionModule class has method run
    assert hasattr(ActionModule, 'run'), "ActionModule class does not have run method."

# Generated at 2022-06-21 02:31:28.301767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    myactionmodule = ActionModule()
    assert(myactionmodule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'])
    assert(myactionmodule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'])
    assert(myactionmodule.VALID_FILE_ARGUMENTS == ['file', '_raw_params'])
    assert(myactionmodule.VALID_ALL == ['name', 'hash_behaviour'])

# Generated at 2022-06-21 02:33:32.669848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-21 02:33:37.003184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'include_vars'
    action_module_cls = ActionModule
    action_module = action_module_cls(module_name, None)
    assert module_name == action_module._task.action

# Generated at 2022-06-21 02:33:42.866486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule(
        task=MockTask,
        connection=MockConnection,
        play_context=MockPlayContext,
        loader=MockLoader()
    )

    # Test1: Passing a source_dir
    action_module._task.args = {
        'name': 'test_name',
        'dir': 'test_dir',
        'depth': 0,
        'files_matching': 'test_files_matching',
        'ignore_files': 'test_ignore_files',
        'ignore_unknown_extensions': False,
        'extensions': list(),
        'hash_behaviour': 'test_hash_behaviour',
    }
    action_module._set_dir_defaults = Mock()
    action_module._set_dir_defaults.return_value

# Generated at 2022-06-21 02:33:43.696868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:33:55.815293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	action_module = ActionModule(task=dict(args=dict(name='test', file='test.yml')))
	assert action_module.run(task_vars=dict())['ansible_facts']['test'] == None, 'Should return empty dictionary if there is no file test.yml'

	assert action_module.run(task_vars=dict(test=dict(a=1, b=2)))['ansible_facts']['test'] == {'a': 1, 'b': 2}, 'Should return dictionary with keys a and b if there is no file test.yml'

	action_module = ActionModule(task=dict(args=dict(name='test', file='invalid_file.txt')))

# Generated at 2022-06-21 02:34:00.443198
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ds = '/dev/null'
    path = '/dev/null'
    task = type('Task', (object,), {})()

    am = ActionModule(task, ds, path)

# Generated at 2022-06-21 02:34:07.112925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test data
    action = 'include_vars'
    source_dir = 'test_dir'
    source_file = 'test_file'
    source_file_ext = 'test_file_ext'
    source_file_no_ext = 'test_file_no_ext'
    source_file_unknown_ext = 'test_file_unknown_ext'
    root_dir = 'test_dir'
    files_matching = 'test_file'
    depth = 0
    ignore_unknown_extensions = False
    ignore_file_ext = 'test_file_ext'
    ignore_file_no_ext = 'test_file_no_ext'
    ignore_file_unknown_ext = 'test_file_unknown_ext'

# Generated at 2022-06-21 02:34:07.979126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:34:18.574330
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit tests for method run of class ActionModule"""

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.include_vars import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # source_dir = None, source_file = None
    task_vars = dict()
    play_context = PlayContext()
    loader = DataLoader()
    templar = Templar(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=None)
    valid_file_extensions = ['yaml', 'yml', 'json']
    source_file = '/home/travis/build/ansible/ansible/my_name.yml'


# Generated at 2022-06-21 02:34:25.991419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    basic.ANSIBLE_VERSION = "2.4.3"
    ansible_module = AnsibleModule(argument_spec=dict(_raw_params=dict(required=True)))
    inclusion_object = ActionModule(ansible_module, dict())
    inclusion_object.run(tmp=None, task_vars=dict())
    inclusion_object.run(task_vars=dict())