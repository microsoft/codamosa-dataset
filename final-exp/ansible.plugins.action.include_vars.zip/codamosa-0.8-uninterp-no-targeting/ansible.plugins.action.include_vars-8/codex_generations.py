

# Generated at 2022-06-21 02:26:57.609387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(dict())
    # Tests class object has been created
    assert am
    # Tests class variable has been created
    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

# Generated at 2022-06-21 02:27:07.257254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Init plugin to test its method run """

    class Task:
        """ Class to simulate Task class of Ansible """

        def __init__(self, args):
            self.args = args

    class Role:
        pass

    class TaskDS:
        def __init__(self):
            self._data_source = 'tests/test_ansible_vars/test_role/tasks/main.yml'

    class Loader:
        """ Class to simulate loader class of Ansible """

        def __init__(self):
            pass

        def load(self, data, file_name, show_content):
            return data

        def _get_file_contents(self, filename):
            with open(filename, 'rb') as f:
                b_data = f.read()
                show_content = True

            return b

# Generated at 2022-06-21 02:27:17.329536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task

    # Test class constructor
    test_class = type('ActionModuleTest', (ActionModule, ), {})

    # Check if class constructor is working properly
    result = test_class.run(ActionModule({}, {}, 1), None, None, 0)
    if result['failed'] == True:
        return False

    # Test if get_dir (private function) is working properly
    task = Task()
    task.args = {'dir' : 'test_dir'}
    test_class = type('ActionModuleTest', (ActionModule, ), {'_task' : task})
    test_class = test_class(task, {})
    test_class._set_root_dir()

# Generated at 2022-06-21 02:27:19.256321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionModule)

# Generated at 2022-06-21 02:27:21.275425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """
    #TODO: implement test
    pass

# Generated at 2022-06-21 02:27:30.258440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import io
    import tempfile
    module_utils_result = {
        'ansible_included_var_files': [],
        'ansible_facts': None,
        '_ansible_no_log': False
    }
    role_path = 'test/test_files'
    action = ActionModule(dict(action=dict(name='include_vars', dir='/vars')),
                          task=dict(args=dict(name='test_results')),
                          datastructure=dict(_role=dict(_role_path=role_path)))

    result = action.run(task_vars=dict())
    del result['ansible_facts']
    assert result == module_utils_result

    role_path = 'test/test_files'

# Generated at 2022-06-21 02:27:37.694522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from mock import Mock, patch
    from nose.tools import assert_equal
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.action import ActionBase
    
    module = ActionModule(Mock(spec=ActionBase), {})
    module.runner = Mock(spec=ActionBase.Runner)
    module.runner.get_loader.return_value = AnsibleLoader
    
    with patch('ansible.module_utils.basic.AnsibleModule') as mock_basic_module:
        module.run()
        mock_basic_module.assert_called_once()

# Generated at 2022-06-21 02:27:46.241108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    del tmp  # tmp no longer has any effect

    if task_vars is None:
        task_vars = dict()

    self.show_content = True
    self.included_files = []

    # Validate arguments
    dirs = 0
    files = 0
    for arg in self._task.args:
        self._task.args = {'dir': 'roles/role1/vars'}
        if arg in self.VALID_DIR_ARGUMENTS:
            dirs += 1
        elif arg in self.VALID_FILE_ARGUMENTS:
            files += 1
        elif arg in self.VALID_ALL:
            pass
        else:
            raise AnsibleError('{0} is not a valid option in include_vars'.format(to_native(arg)))

   

# Generated at 2022-06-21 02:27:57.864121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes
    from ansible.parsing import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import os
    import yaml

    # Create a test directory that contains the file/s to be loaded.
    test_data_dir = 'test_include_vars_files_files'
    if PY2:
        test_data_dir = to_bytes(test_data_dir)
    os.makedirs(test_data_dir)

    # Create/write a test file that contains our variables. 'var_to_add.yml'
    # This file will be imported.
    test_data

# Generated at 2022-06-21 02:28:01.289223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=mock.MagicMock(), connection=mock.MagicMock(), play_context=mock.MagicMock(), loader=mock.MagicMock(), templar=mock.MagicMock(), shared_loader_obj=mock.MagicMock())


# Generated at 2022-06-21 02:28:18.910449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-21 02:28:27.761977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Mock these functions
    def mock_run(playbook, **kwargs):
        pass

    def test_loader(data, file_name=None, show_content=True):
        return data

    def mock_ds(*args):
        pass

    # TODO: Mock these constants
    C.DEFAULT_HASH_BEHAVIOUR = None
    C.DEFAULT_HASH_BEHAVIOUR_STRICT = None
    C.DEFAULT_HASH_MERGE_BEHAVIOUR = None
    C.DEFAULT_HASH_MERGE_BEHAVIOUR_STRICT = None

    # Run the constructor
    action_module = ActionModule(mock_ds, mock_run)

    # Test fields
    assert action_module._task == mock_ds
    assert action_module._loader == test_

# Generated at 2022-06-21 02:28:29.327821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None)

# Generated at 2022-06-21 02:28:38.218107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    # Set up a dummy task
    variable_manager = VariableManager()
    loader = DataLoader()
    options = dict()
    options['connection'] = 'local'
    options['module_path'] = ''
    options['forks'] = 1
    options['become'] = None
    options['become_method'] = None
    options['become_user'] = None
    options['check'] = False
    options['diff'] = False
    play_context = PlayContext(options, variable_manager, loader)
    play_context.basedir = '/path/to/basedir'
    play_context

# Generated at 2022-06-21 02:28:41.343448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # ActionModule class has one instance method "run".
    assert hasattr(ActionModule, 'run') and callable(getattr(ActionModule, 'run'))

# Generated at 2022-06-21 02:28:42.166717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:28:53.659832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # test for invalid arguments
    task_args = {'invalid_argument': 'invalid'}
    task_vars = {}
    action_module._task = MagicMock()
    action_module._task.args = task_args

    with pytest.raises(AnsibleError) as excinfo:
        action_module.run(task_vars)
    assert to_native(excinfo.value) == 'invalid_argument is not a valid option in include_vars'

    # test for invalid hash_behaviour
    task_args = {'hash_behaviour': 'invalid'}
    action_module._task.args = task_args
    with pytest.raises(AnsibleError) as excinfo:
        action_module.run(task_vars)


# Generated at 2022-06-21 02:28:55.236780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('task')

# Generated at 2022-06-21 02:29:00.565465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock
    def _mock_task():
        class MockTask:
            _ds = None
            _role = None
            args = dict()

        return MockTask()

    _mock_task._ds = '/path/to/playbook/roles/role/vars/main.yml'
    _mock_task._role = [1]

    def _mock_loader(data):
        class MockLoader:
            data = dict()

            def load(self, data, file_name, show_content):
                return self.data
            def _get_file_contents(self, filename):
                return self.data

        return MockLoader()

    results = dict()
    results['file'] = 'content'

    # Create object to test
    action_module = ActionModule()
    action_module._

# Generated at 2022-06-21 02:29:09.818946
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:29:32.815463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit tests for the constructor of the class ActionModule
    """
    actionModule = ActionModule()
    assert actionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert actionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert actionModule.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-21 02:29:39.431907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule_instance = ActionModule(
        task=None,
        connection=None,
        _play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert None == actionModule_instance.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 02:29:51.114347
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:29:53.621045
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module =  ActionModule()
    action_module.run()

# Generated at 2022-06-21 02:30:04.161228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test case for method run of class ActionModule, when
    _is_valid_file_ext is False
    """
    task_vars = {}
    action_plugin = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_plugin._set_args = MagicMock()
    action_plugin._set_dir_defaults = MagicMock()
    action_plugin._set_root_dir = MagicMock()
    action_plugin._traverse_dir_depth = MagicMock()
    action_plugin._load_files_in_dir = MagicMock(return_value=({True}, {'message':"Unknown extension of file: ./sample1.json"}, {'sample1.json': {'key' : 'value'}}))

# Generated at 2022-06-21 02:30:05.729954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:30:13.647215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    assert result.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'], "Invalid VALID_FILE_EXTENSIONS"
    assert result.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'], "Invalid VALID_DIR_ARGUMENTS"
    assert result.VALID_FILE_ARGUMENTS == ['file', '_raw_params'], "Invalid VALID_FILE_ARGUMENTS"
    assert result.VALID_ALL == ['name', 'hash_behaviour'], "Invalid VALID_ALL"

# Generated at 2022-06-21 02:30:21.702085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._set_root_dir()
    module._set_dir_defaults()

    if module._traverse_dir_depth:
        pass
    else:
        return False

    if module._ignore_file():
        pass
    else:
        return False

    if module._is_valid_file_ext():
        pass

    else:
        return False

    module._load_files()
    module._load_files_in_dir()

    # if module._find_needle()
    # module._set_args()
    # module.run()

    return True

# Generated at 2022-06-21 02:30:22.671665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:30:30.896008
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor with action argument
    action = 'action'
    task = dict()
    connection = dict()
    play_context = dict()
    loader = dict()
    templar = dict()
    shared_loader_obj = dict()
    try:
        instance = ActionModule(action, task, connection, play_context,
                                loader, templar, shared_loader_obj)
        assert isinstance(instance, ActionModule)
    except Exception as e:
        raise Exception(e)


# Generated at 2022-06-21 02:30:47.467916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Tests all methods of the ActionModule class
    Args:
        Nothing
    Return:
        Nothing
    """
    a = ActionModule()


# Generated at 2022-06-21 02:30:54.063913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    print("Running unit test for constructor of class ActionModule")

    # Setup mocks
    mock_task = type('', (), {})()
    mock_loader = type('', (), {})()
    mock_data = type('', (), {})()
    mock_task.args = {}

    action_module = ActionModule(mock_task, mock_loader, mock_data)

    print("Successfully created object from class ActionModule")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:31:01.949395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit testing for method run of class ActionModule
    """
    class MockTask:
        def __init__(self, args_dict = {}):
            self.args = args_dict

    class MockDS:
        def __init__(self, data_source):
            self._data_source = data_source

    # Test 1: include_vars with dir option
    AM = ActionModule(MockTask(args_dict = {'dir': './test/unit/plugins/action/vars1'}), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    actual = AM.run(task_vars=None)
    assert 'ansible_facts' in actual.keys()
    assert actual.get('ansible_facts').get('foo') == 'bar'

# Generated at 2022-06-21 02:31:09.851624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Construct a ActionModule object
    action_module = ActionModule()

    # Test attributes for valid values
    assert isinstance(action_module.VALID_FILE_EXTENSIONS, list)
    assert isinstance(action_module.VALID_DIR_ARGUMENTS, list)
    assert isinstance(action_module.VALID_FILE_ARGUMENTS, list)
    assert isinstance(action_module.VALID_ALL, list)



# Generated at 2022-06-21 02:31:17.881555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert am.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-21 02:31:19.048380
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-21 02:31:22.040876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    action_module._task = dict()
    action_module._task['args'] = dict()
    action_module._task['args']['dir'] = 'test'
    action_module.run()

# Generated at 2022-06-21 02:31:29.860261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os

    test_dir = os.path.dirname(os.path.realpath(__file__)) + '/test_files'

    module = __import__('ansible.modules.utilities.logic.include_vars', fromlist=['ActionModule'])
    action_module = getattr(module, 'ActionModule')
    loader = module.ActionBase._loader_class(None, '', False, None)
    action = action_module(loader=loader, task=None, connection=None, play_context=None, loader_path='/etc/ansible/roles/test/', shared_loader_obj=None)


# Generated at 2022-06-21 02:31:41.108518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_task_vars = dict()
    fake_tmp = dict()
    fake_tmp = dict()
    fake_tmp = dict()
    fake_self = dict()
    fake_self = dict()
    fake_tmp = dict()

    def fake_show_content(*args, **kwargs):
        print('fake_show_content')

    def fake_traverse_dir_depth(*args, **kwargs):
        print('fake_traverse_dir_depth')
    fake_self.traverse_dir_depth = fake_traverse_dir_depth

    def fake_load_files(*args, **kwargs):
        print('fake_load_files')

    fake_self.load_files = fake_load_files
    fake_self.show_content = fake_show_content
    fake_self.included_

# Generated at 2022-06-21 02:31:47.332828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert isinstance(module, ActionModule)

# Generated at 2022-06-21 02:32:38.715863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class AnsibleTask:
        def __init__(self, *args):
            self.args = args[1]

    my_args = dict()
    my_args['dir'] = 'tests/unittests/'
    my_args['depth'] = 4
    my_args['ignore_files'] = "a*"
    my_args['extensions'] = 'yaml'
    assert isinstance(ActionModule(AnsibleTask(None, my_args), dict()), ActionModule)

# Generated at 2022-06-21 02:32:50.496356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.include_vars import ActionModule
    class Mock_task:
        def __init__(self):
            mock_args = {}
            mock_args['file'] = 'abs_path_to_file'
            self.args = mock_args

    class Mock_loader:
        def get_basedir(self, mock_ds):
            return 'abs_path_to_basedir'

    class Mock_ds:
        _data_source = 'abs_path_to_dir/file'

        def get_basedir(self):
            return 'abs_path_to_dir'

    class Mock_role:
        def __init__(self):
            self._role_path = 'abs_path_to_role_dir'


# Generated at 2022-06-21 02:32:55.662864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = {
            'ansible_debug': True,
            'ansible_verbosity': 0
        }
    task = TestTask()
    test_run = action_module.run(tmp=None, task_vars=task_vars)

    right_result = {
        'ansible_facts': {
            'include_vars': {
                'ansible_host': 'myhost.com',
                'ansible_ssh_pass': 'pass123'
            }
        },
        'changed': False,
        'failed': False
    }
    for key in right_result:
        assert test_run[key] == right

# Generated at 2022-06-21 02:32:56.756884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:32:58.084104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_instance = ActionModule()
    return test_instance

# Generated at 2022-06-21 02:33:07.179434
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  assert am.TRANSFERS_FILES == False
  assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
  assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
  assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
  assert am.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-21 02:33:09.063707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(ActionModule(), ActionModule(), 'test')
    assert action_module is not None
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:33:18.080912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.module_utils.facts.namespace as ansible_module_namespace
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.vars.manager import VariableManager

    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible_collections.ansible.netcommon.plugins.action.network import ActionModule as NetworkActionModule

    mod_args_parser = ModuleArgsParser(task=None, args_loader=None)
    mod_args = mod_args_parser.parse_args(dict(), ignore_errors=False)
    vars_mgr = VariableManager(loader=None, inventory=None, version_info=NetworkActionModule.version_info)

# Generated at 2022-06-21 02:33:28.863919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Public interface constructor
    class_name = ActionModule()
    assert class_name.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert class_name.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert class_name.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert class_name.VALID_ALL == ['name', 'hash_behaviour']

     # Private interface method
    try:
        class_name.run()
    except TypeError as e:
        assert 'run() takes at least 2 arguments (1 given)' in e.message

# Generated at 2022-06-21 02:33:30.901425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._set_dir_defaults() is None


# Generated at 2022-06-21 02:34:47.051319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule # Constructor defined


# Generated at 2022-06-21 02:34:58.623716
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    class ActionModule(ActionBase):
        def _set_args(self):
            self.hash_behaviour = self._task.args.get('hash_behaviour', None)
            self.return_results_as_name = self._task.args.get('name', None)
            self.source_dir = self._task.args.get('dir', None)
            self.source_file = self._task.args.get('file', None)
            if not self.source_dir and not self.source_file:
                self.source_file = self._task.args.get('_raw_params')
                if self.source_file:
                    self.source_file = self.source_file.rstrip('\n')


# Generated at 2022-06-21 02:35:06.131200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule('include_vars', 'dir', '\n'.join(['name: Fred', 'age: 20']), {'name': 'Alice', 'age': 30}, 'key:{{some_var}}', None)
    result = module.run()
    assert result == dict(ansible_facts=dict(name='Fred', age='20'), ansible_included_var_files=[], _ansible_no_log=True)


# Generated at 2022-06-21 02:35:18.031802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    progress_callback = None
    new_stdin = None
    module_name = None
    module_args = None
    loader, _, _ = (
        None, None, None,
    )
    action_module = ActionModule(
        progress_callback, new_stdin, module_name, module_args, loader,
    )

    assert isinstance(action_module, ActionModule)
    assert isinstance(action_module.VALID_FILE_EXTENSIONS, list)
    assert isinstance(action_module.VALID_DIR_ARGUMENTS, list)
    assert isinstance(action_module.VALID_FILE_ARGUMENTS, list)
    assert isinstance(action_module.VALID_ALL, list)

# Generated at 2022-06-21 02:35:28.565993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import ansible.plugins.action.include_vars
    import sys
    import re
    sys.modules['ansible.plugins.action.include_vars'] = ansible.plugins.action.include_vars
    from ansible.plugins.action.include_vars import ActionModule

    class Test_ActionModule_run(unittest.TestCase):
        def test_run(self):
            with self.assertRaises(AnsibleError) as cm:
                ActionModule._set_args(self)
            self.assertEqual(str(cm.exception), '<include_vars>: neither dir nor file was given')

            self._task.args = {'file': 'test.yml'}
            self._task.args['hash_behaviour'] = 'merge'
            self._task

# Generated at 2022-06-21 02:35:30.047851
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule().TRANSFERS_FILES

# Generated at 2022-06-21 02:35:39.331121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action

    action_module = action.ActionModule()
    action_module._task = dict()
    action_module._task['args'] = dict()
    action_module._task['args']['dir'] = "."
    action_module._task['action'] = dict()
    action_module._task['action']['module_name'] = "include_vars"
    action_module._task['action']['args'] = dict()
    action_module._task['action']['args']['dir'] = "."
    action_module._task['action']['args']['hash_behaviour'] = "merge"
    action_module._task['action']['args']['name'] = "test"

# Generated at 2022-06-21 02:35:43.591302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, templar=None, shared_loader_obj=None)
    assert(action_module)

# Generated at 2022-06-21 02:35:50.185265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    options = {'hosts': [], 'host_vars': [], 'host_patterns': []}

    # test case 1:
    # - passing valid argument to ActionModule() constructor
    # - passing directory, 'dir' and 'depth' as arguments
    # - passing 'name' argument (return_results_as_name)

    task = {'args': {'dir': '/usr/local/ansible/test/invalid', 'depth': 2, 'name': 'test_result'}}
    action_module = ActionModule(task, options)
    assert action_module._task.args == task['args']

    task = {'args': {'dir': '/usr/local/ansible/test/invalid', 'depth': -1, 'name': 'test_result'}}
    action_module = ActionModule(task, options)

# Generated at 2022-06-21 02:35:53.516718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    print('ActionModule_run unit test')
