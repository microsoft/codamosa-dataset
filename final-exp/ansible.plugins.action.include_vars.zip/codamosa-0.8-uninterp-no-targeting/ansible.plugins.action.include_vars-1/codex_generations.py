

# Generated at 2022-06-21 02:26:52.253015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-21 02:27:04.993186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action_module._task is None
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None

    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']


# Generated at 2022-06-21 02:27:16.590581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test the run method of class ActionModule.
    """
    import ansible.module_utils.basic
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    test_source_dir = path.join(path.dirname(path.realpath(__file__)), "fixtures", "vars")


# Generated at 2022-06-21 02:27:25.791427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader as pl
    import ansible.module_utils.connection as connection
    import ansible.utils.vars as vars
    import ansible.vars.manager as manager
    import ansible.parsing.dataloader as dataloader
    import ansible.errors as errors
    import ansible.constants as constants
    import ansible.compat.six as six
    import ansible.module_utils.six as module_six
    import ansible.plugins.action as action

    for ext in ['yaml', 'yml', 'json']:
        assert ext in ActionModule.VALID_FILE_EXTENSIONS


# Generated at 2022-06-21 02:27:27.735467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    am = ActionModule()
    am._set_dir_defaults()

# Generated at 2022-06-21 02:27:28.621050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 02:27:35.693679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_instance = ActionModule()

    assert module_instance.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module_instance.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert module_instance.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module_instance.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-21 02:27:38.019023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-21 02:27:38.907251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:27:45.089188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    #TODO Fix these unit tests.

# Generated at 2022-06-21 02:28:17.924291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(
        task=None, connection=None, play_context=None, loader=None, templar=None, share_loader_obj=True
    )
    assert(actionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'])
    assert(actionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'])
    assert(actionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params'])
    assert(actionModule.VALID_ALL == ['name', 'hash_behaviour'])


# Generated at 2022-06-21 02:28:26.141846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' test function run of class ActionModule '''
    import ansible.plugins.action
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-21 02:28:34.568821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from os import path
    from ansible.playbook.task import Task
    from ansible.playbook import Play
    from ansible.module_utils.six import string_types
    from ansible.template import Templar
    from ansible.module_utils.common._collections_compat import Mapping, MutableSequence, MutableSet, MutableMapping
    import ansible.constants as C
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text, to_native
    # object initialization
    task = Task('include_vars unittest')
    #variable initialization
    task._role = Play()

# Generated at 2022-06-21 02:28:35.845989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:28:47.494229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.include_vars as action_object
    import ansible.plugins.action.include_vars as action_object
    import ansible.constants as constants_object
    import ansible.utils.plugin_docs as plugin_docs_object
    import ansible.utils.vars as vars_object
    import ansible.utils.vars as vars_object

    # Set class member of ActionModule_instance
    ActionModule_instance = action_object.ActionModule()
    ActionModule_instance.VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    ActionModule_instance.VALID_FILE_ARGUMENTS = ['file', '_raw_params']
    ActionModule_instance.VAL

# Generated at 2022-06-21 02:28:55.925098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Sample ansible_facts used as base
    base_dict = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': {
                'g': 5,
                'h': 6,
                'i': 7
            },
        },
    }

    # Sample ansible_facts used as update
    update_dict = {
        'a': 10,
        'b': 20,
        'c': {
            'd': 30,
            'e': 40,
            'f': {
                'g': 50,
                'h': 60,
                'i': 70
            },
        },
        'j': 8,
        'k': 9
    }

    # Sample ansible_facts used as deep update


# Generated at 2022-06-21 02:29:05.371562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import sys

    def _run_action_module(task, task_vars, args):
        action_module = ActionModule(task, task_vars)
        action_module._set_args()
        results = action_module.run(task_vars=task_vars)
        return results

    args = {
        'file': 'variables.yml',
        'name': 'var_dict'
    }

# Generated at 2022-06-21 02:29:12.713056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockTask:
        def __init__(self, args):
            self.args = args

    # test with dir option
    args = dict()
    args['dir'] = 'my_vars_dir'
    mock_task = MockTask(args)

    class MockTaskDS:
        def __init__(self, data_source):
            self._data_source = data_source

    class MockTaskRole:
        ROLE_PATH = 'role_path'

        def __init__(self, role_path):
            self._role_path = role_path

    class MockActionModule:
        def __init__(self, task, task_ds, task_role):
            self._task = task
            self._task._ds = task_ds
            self._task._role = task_role


# Generated at 2022-06-21 02:29:22.259207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.action.include_vars import ActionModule

    task = TaskInclude()

    play_context = PlayContext()

    try:
        assert ActionModule(task, play_context) is not None
    except Exception as e:
        raise AssertionError(e)

# Generated at 2022-06-21 02:29:35.284168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.module_utils.ansible_release import __version__

    from ansible.plugins.callback.default import CallbackModule

    mock_task = Task()
    mock_task.action = 'test_include_vars'
    mock_task.args = {'dir': 'test/test_include_vars/vars',
                      'files_matching': '.*json$'}
    mock_task.register = 'something'
    mock_task._role = None
    mock_task._ds = None
    mock_task._parent = None

    mock_task_

# Generated at 2022-06-21 02:30:28.444127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor with the correct action
    assert (ActionModule(
        task=Task(dict(action='include_vars', args=dict(file='test'))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        share_loader_obj=False)
        )


# Generated at 2022-06-21 02:30:31.951423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\nActionModule test")
    print("Expect: Execute run method with a tmp and task_vars in parameter, return a dict")

    tmp = None
    task_vars = dict()
    a = ActionModule()
    a.run(tmp, task_vars)
    print("\n")


# Generated at 2022-06-21 02:30:33.005051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:30:34.516958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-21 02:30:35.394703
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert ActionModule.run

# Generated at 2022-06-21 02:30:44.419935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    cwd = os.getcwd()
    basepath = os.path.join(cwd, 'test_include_vars_action')
    src_dir = os.path.join(basepath, 'vars')

# Generated at 2022-06-21 02:30:53.631435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = '{}:22'.format(os.environ.get('HOST_IP'))
    ssh_pass = os.environ.get('HOST_PASS')
    runner = ansible.runner.Runner(
        pattern='%s' % host, forks=10,
        module_name='ping', module_path='/path/to/mymodules',
        remote_user='vagrant', private_key_file='/path/to/private_key',
        host_list='test/integration/inventory',
        module_args='',
    )
    expected_data = {'runner': runner, 'module_name': 'ping'}
    assert ActionModule(runner=runner, module_name='ping') == expected_data


# Generated at 2022-06-21 02:31:01.615212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionBase
    task = dict()
    task['args'] = dict()
    task['args']['dir'] = 'dir_in'
    task_vars = dict()
    role_path = 'role_path'
    role = dict()
    role['_role_path'] = role_path
    import ansible.playbook.role.definition
    role_definition = ansible.playbook.role.definition.RoleDefinition.load(
        path.join(role_path),
        'role',
        loader=False,
        variable_manager=False
    )
    import ansible.playbook.task
    task_instance = ansible.playbook.task.Task()
    task_instance._role = role_definition
    role_definition._task = task_instance
    acm = Action

# Generated at 2022-06-21 02:31:08.609380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    from ansible.utils.vars import combine_vars

    test_object = ActionModule(
        task=mock.MagicMock(), connection=mock.MagicMock(),
        play_context=mock.MagicMock(), loader=mock.MagicMock(),
        templar=mock.MagicMock(), shared_loader_obj=None)

    # Test for mix of file and directory arguments

# Generated at 2022-06-21 02:31:19.758070
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeActionModule:
        def __init__(self):
            self.args = {'files_matching': None,
                         'extensions': ['json', 'yaml', 'yml'],
                         'ignore_files': None,
                         'depth': 0,
                         'name': 'my_results',
                         'dir': '.',
                         'ignore_unknown_extensions': False
                         }
            self.include_role = None
            self._role = None

    class FakeTask:
        def __init__(self):
            self.action = 'include_vars'

# Generated at 2022-06-21 02:33:20.004536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()
    assert actionmodule, "Not instantiated"

# Generated at 2022-06-21 02:33:21.634284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), None, None, None)

# Generated at 2022-06-21 02:33:22.922442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:33:30.941828
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test setup
    test_ActionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    class task:
        def __init__(self):
            self.args = dict()
            self.args['file'] = 'test_data/test_file.yml'
            self.args['name'] = None
            self.args['hash_behaviour'] = None

    class role:
        def __init__(self):
            self._role_path = 'test_data'

    class task_ds:
        def __init__(self):
            pass

        def _data_source(self):
            return self.data_source

    test_Role = role()
    test_Ds = task_ds()
    test_

# Generated at 2022-06-21 02:33:36.457475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_var1 = {'test_var' : 'test_val'}
    setattr(ActionModule, '_templar', test_var1)
    assert isinstance(ActionModule, ActionModule)
    assert isinstance(ActionModule._templar, dict)


# Generated at 2022-06-21 02:33:44.517068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(),'testActionModule',{'hash_behaviour':'test_hash_behaviour', 'name':'test_name', 'dir':'test_dir', 'file':'test_file', '_raw_params':'test_raw_params', 'depth':'test_depth', 'files_matching':'test_files_matching', 'ignore_files':'test_ignore_files', 'extensions':'test_extensions'})

# Generated at 2022-06-21 02:33:54.023696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Start testing ActionModule constructor")

    action_mod = ActionModule()

    assert type(action_mod.VALID_FILE_EXTENSIONS[0]) is str
    assert type(action_mod.VALID_DIR_ARGUMENTS[0]) is str
    assert type(action_mod.VALID_FILE_ARGUMENTS[0]) is str
    assert type(action_mod.VALID_ALL[0]) is str
    print("Passed testing ActionModule constructor")

test_ActionModule()


# Generated at 2022-06-21 02:33:56.314590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, 'Not completed'

# Generated at 2022-06-21 02:33:58.333560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action.run()


# Generated at 2022-06-21 02:34:08.120390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import action
    action_plugin = action.ActionModule(None, None, {})
    assert action_plugin.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_plugin.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_plugin.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_plugin.VALID_ALL == ['name', 'hash_behaviour']
