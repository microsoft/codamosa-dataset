

# Generated at 2022-06-21 02:26:56.771743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:26:59.433839
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

# Generated at 2022-06-21 02:27:07.850476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def fake_caller_data_source(arg):
        return "/fake/ansible_include_vars_test_role/test/test.yml"

    task = mock.Mock()

    # task.args has the arguments passed to include_vars
    task.args = {u'name': u'vars', u'hash_behaviour': u'merge', u'dir': u'vars', u'files_matching': u'test1.yml', u'ignore_files': u'', u'extensions': u'yaml, yml, json'}

    task._role = mock.Mock()
    task._ds = mock.Mock()
    task._ds._data_source = mock.Mock(side_effect = fake_caller_data_source)

# Generated at 2022-06-21 02:27:17.480359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules.system.include_vars
    import ansible.plugins.action
    
    # Create an instance of ansible.modules.system.include_vars.ActionModule
    actmod = ansible.modules.system.include_vars.ActionModule()
    
    # Assign values to the variables
    actmod.source_dir = 'tests/unit/testdata/vars'
    actmod.depth = -2
    actmod.ignore_files = 'a.yml'
    actmod.ignore_unknown_extensions = True
    actmod.valid_extensions = ['yaml', 'yml']
    actmod.return_results_as_name = 'result_name'

    # Call the method run
    result = actmod.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 02:27:18.336522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:27:24.597662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(ActionBase)
    assert actionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert actionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert actionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert actionModule.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-21 02:27:35.395843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.task.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.template.template import AnsibleTemplate

    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.connection = 'smart'
    play_context.password = None

# Generated at 2022-06-21 02:27:37.281741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:27:39.836531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

# Generated at 2022-06-21 02:27:52.975799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule
        1. Create an instance of class ActionModule and set the required
           attributes.
        2. Call the run method of class ActionModule and compare the
           output with expected output.
    """
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.include_role import ActionModule
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-21 02:28:27.705681
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:28:29.251051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:28:29.736708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:28:37.148217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C

    class TestPlaybookExecutor(PlaybookExecutor):
        def __init__(self, *args):
            super(TestPlaybookExecutor, self).__init__(*args)
        def _load_included_file(self, included_file, *args):
            pass

    class TestTaskQueueManager(TaskQueueManager):
        def __init__(self, *args):
            super(TestTaskQueueManager, self).__init

# Generated at 2022-06-21 02:28:48.227226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor Method
    action_module = ActionModule(
        task=None, connection=None, play_context=None, loader=None,
        templar=None, shared_loader_obj=None
    )
    assert isinstance(action_module, ActionModule)

    # Attribute VALID_FILE_EXTENSIONS as Tuple
    assert isinstance(action_module.VALID_FILE_EXTENSIONS, tuple)
    if hasattr(action_module.VALID_FILE_EXTENSIONS, '__iter__'):
        for extension in action_module.VALID_FILE_EXTENSIONS:
            assert isinstance(extension, str)
    else:
        raise AssertionError("VALID_FILE_EXTENSIONS is not iterable")

    # Attribute VALID_DIR_ARGUMENTS as Tuple


# Generated at 2022-06-21 02:28:53.659727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    action_module = ansible.plugins.action.ActionModule(
        task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None
    )
    assert isinstance(action_module, ansible.plugins.action.ActionModule)

# Generated at 2022-06-21 02:28:57.900020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def _find_needle(self, directory, filename):
        return 'TEST'

    def _get_file_contents(self, filename):
        return 'TEST', True

    ActionModule._find_needle = _find_needle
    ActionModule._loader._get_file_contents = _get_file_contents

    am = ActionModule(dict(), None, None, None, None)
    am.source_dir = 'TEST'
    assert am.source_dir == 'TEST'

    am.source_file = 'TEST'
    assert am.source_file == 'TEST'

    am.depth = 'TEST'
    assert am.depth == 'TEST'

    am.files_matching = 'TEST'
    assert am.files_matching == 'TEST'


# Generated at 2022-06-21 02:28:58.833065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:29:05.190253
# Unit test for constructor of class ActionModule
def test_ActionModule():
	class Test:
		args = {'name': 'test', 'hash_behaviour': 'replace'}
	task = Test()

	action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

	assert action_module.return_results_as_name == 'test'
	assert action_module.hash_behaviour == 'replace'


# Generated at 2022-06-21 02:29:16.402674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock some args
    module_args = dict()
    module_args['src'] = 'var.yml'
    module_args['name'] = 'test'
    module_args['hash_behaviour'] = 'merge'
    host_name = 'localhost'

    # create an instance of ActionModule
    loader_mock = dict()
    _ds = dict()
    _ds['_data_source'] = 'test'
    loader_mock['_ds'] = _ds
    inventory_mock = dict()
    inventory_mock['hostname'] = host_name
    inventory_mock['vars'] = dict()
    inventory_mock['vars'][host_name] = dict()
    inventory_mock['vars'][host_name]['test'] = "test2"
    task_m

# Generated at 2022-06-21 02:30:09.906675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    task_vars = {}
    assert(m.run(tmp=None, task_vars=None))

# Generated at 2022-06-21 02:30:12.573344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module
    print('ActionModule constructor completed')


# Generated at 2022-06-21 02:30:22.811019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            self.args = kwargs

        def run(self):
            try:
                return super(MockActionModule, self).run()
            except Exception as e:
                failed = True
                err_msg = to_native(e)
                return {
                    'failed': failed,
                    'message': err_msg
                }
    # Test dir argument
    # Test invalid directory
    source_dir_fail = '/invalid_dir'
    source_dir_pass = 'vars'
    action_module_pass = MockActionModule(dir=source_dir_pass, hash_behaviour='replace')
    action_module_fail = MockActionModule(dir=source_dir_fail, hash_behaviour='replace')
   

# Generated at 2022-06-21 02:30:33.019749
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:30:39.562916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, '_set_dir_defaults'), 'missing function _set_dir_defaults'
    assert hasattr(ActionModule, '_set_args'), 'missing function _set_args'
    assert hasattr(ActionModule, 'run'), 'missing function run'
    assert hasattr(ActionModule, '_traverse_dir_depth'), 'missing function _traverse_dir_depth'
    assert hasattr(ActionModule, '_ignore_file'), 'missing function _ignore_file'
    assert hasattr(ActionModule, '_is_valid_file_ext'), 'missing function _is_valid_file_ext'
    assert hasattr(ActionModule, '_load_files'), 'missing function _load_files'

# Generated at 2022-06-21 02:30:49.866421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action
    import json
    import os
    import tempfile
    from ansible.playbook.play_context import PlayContext
    from ansible import constants as C
    from ansible.inventory.host import Host
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.parsing.dataloader import DataLoader
    # AnsibleContext is used to initialize HostVarsVars object and TaskExecutor object
    # AnsibleContext is initialized in ansible.executor.task_executor
    from ansible.context import AnsibleContext
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-21 02:31:01.693704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext

    class FakeModule:
        def __init__(self, task_vars, loader):
            self._task_vars = task_vars
            self._loader = loader

        def get_loader(self):
            return self._loader

    #
    # Try with deprecated way of setting arguments
    #
    class FakeTask:
        def __init__(self):
            self.deprecated_args = None
            self.args = None
            self._role = None

    class FakeRole:
        def __init__(self, role_path):
            self._role_path = role_path

    class FakeRolePath:
        def __init__(self):
            self.vars_root = '/roles/role_path/vars'


# Generated at 2022-06-21 02:31:02.238022
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:31:08.049694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    a._set_dir_defaults()
    assert a.depth == 0
    assert a.ignore_files == []
    assert a.matcher is None

    a.depth = 1
    a.matcher = re.compile(r'.*')
    a.ignore_files = 'foo'
    a._set_dir_defaults()
    assert a.depth == 1
    assert a.ignore_files == ['foo']
    assert a.matcher is not None

# Generated at 2022-06-21 02:31:19.278721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.action.include_vars import ActionModule

    add_all_plugin_dirs()

    results = {
        "ansible_included_var_files": [],
        "ansible_facts": {},
        "failed": False,
        "message": "",
        "_ansible_no_log": True,
    }

    task = {
        "args": {
        },
        "action": "include_vars"
    }

    task_vars = {
        "ansible_facts": {},
    }

    am = ActionModule(task, {})
    action_result = am.run(task_vars=task_vars)

    assert results == action_result

# Generated at 2022-06-21 02:33:29.590118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError()

# Generated at 2022-06-21 02:33:40.331328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create variables for test
    failed = False
    err_msg = ''
    updated_results = {}
    results = {'test': 'test'}
    scope = {}
    scope['results'] = results
    task_vars = {}

    # Create return variable
    final_return = {}
    final_return['failed'] = failed
    final_return['message'] = err_msg
    final_return['ansible_included_var_files'] = []
    final_return['ansible_facts'] = scope
    final_return['_ansible_no_log'] = False

    # Create task and task_ds
    task = mock.Mock()
    task.args = {}
    task.args['file'] = '../test/test_files/test.json'

    task_ds = mock.Mock()
   

# Generated at 2022-06-21 02:33:41.198844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:33:48.400616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setting up action
    action_file = path.join(path.dirname(path.abspath(__file__)), 'action', 'include_vars.py')
    action_data = open(action_file).read()
    action_data = action_data.replace('self._task.args.', 'self.args.').replace('self._task.get_args().', 'self.args.')
    action_data = compile(action_data, action_file, 'exec')

    # setting up environment
    task_vars = {'ansible_facts': {'foo': 'bar'}}

    # setting class attributes
    _task = object()
    setattr(_task, '_role', None)


# Generated at 2022-06-21 02:33:55.619900
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = type('mock_task', (object,), {
        'args': {
            '_raw_params': 'test.yaml',
            'hash_behaviour': 'merge',
            'name': 'test_vars'
        }
    })

    mock_task_ds = type('mock_task_ds', (object,), {
        '_data_source': 'ansible/test/test.yaml'
    })

    mock_task._ds = mock_task_ds

    mock_task._role = type('mock_role', (object,), {
        '_role_path': 'ansible/test/'
    })


# Generated at 2022-06-21 02:34:02.779402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_args = dict()

    mockobj = mock.MagicMock()
    mockobj.run.return_value = dict()

    module_args['hash_behaviour'] = 'replace'
    module_args['name'] = 'facts'
    module_args['dir'] = '/path/to/dir/1'
    module_args['ignore_files'] = '*_ignore_dir*'
    module_args['files_matching'] = '.*_ignore_dir.*'
    module_args['extensions'] = 'txt'

    mockobj._task = dict()
    mockobj._task['args'] = module_args
    mockobj._task['_role'] = None

    am = ActionModule(mockobj)

    try:
        am.run()
    except AnsibleError as e:
        assert str(e)

# Generated at 2022-06-21 02:34:08.119971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_dict = {}
        action_module = ActionModule(test_dict, test_dict, test_dict, test_dict)
        if action_module:
            return 0
        else:
            return 1
    except:
        return 1
        

# Generated at 2022-06-21 02:34:18.627372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	# instantiation of argument
	mock_argument = {
		"source_file": "./demo.yaml"
	}
	# instantiation of task_vars
	mock_task_vars = {}

	# instantiation of class ActionModule
	result = ActionModule(mock_argument, mock_task_vars)

	# testing run method
	assert result.run() == {
		'_ansible_no_log': True, 
		'changed': False, 
		'failed': False, 
		'ansible_included_var_files': ['./demo.yaml'], 
		'ansible_facts': {
			'key1': 'value1', 
			'key2': 'value2'
		}
	}



# Generated at 2022-06-21 02:34:27.920956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    import os
    import sys
    import json

    # mocked object
    class MockTask(object):

        _role = None
        _ds = None

        def __init__(self, args):
            self.args = args

    # mocked object
    class MockRole(object):

        _role_path = None

        def __init__(self):
            pass

    # mocked object
    class MockDS(object):

        _data_source = None

        def __init__(self):
            pass

    # return value of module_executor

# Generated at 2022-06-21 02:34:31.092871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)