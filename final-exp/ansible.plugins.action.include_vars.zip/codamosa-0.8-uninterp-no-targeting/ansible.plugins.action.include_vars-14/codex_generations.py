

# Generated at 2022-06-21 02:27:05.590806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    test the ActionModule constructor
    """
    from ansible.plugins.action import ActionBase
    from ansible.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    task_ds = dict(action=dict(module='include_vars', name='test', dir='vars'))
    task = Task.load(task_ds)
    block = Block()
    task._parent = block
    ti = TaskInclude()
    ti.load(task_ds)
    task._parent = ti
    assert isinstance(ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None), ActionBase)

# Generated at 2022-06-21 02:27:16.743354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    from ansible.module_utils.six import StringIO

    from .mock import MagicMock, patch

    from ansible.module_utils.common._collections_compat import Mapping

    from ansible_collections.notstdlib.moveitallout.tests import unittest

    # Mocking AnsibleTaskVarsModule._load_file
    # AnsibleTask.run()
    # AnsibleModule._load_params
    class AnsibleRunner:
        def __init__(self):
            self.return_results_as_name = None
            self.source_dir = None
            self.source_file = None
            self.depth = None
            self.files_matching = None
            self.ignore_unknown_extensions = False
            self.ignore_files = None

# Generated at 2022-06-21 02:27:25.847755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary role directory
    tmprole = tempfile.mkdtemp(dir=tmpdir)

    # Create a temporary directory containing a file
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    fd = open(os.path.join(tmpdir2, 'test1'), 'w')
    fd.close()

    # Create a role in tmpdir
    role1 = tempfile.mkdtemp(dir=tmprole)

    # Create a role directory vars
    role_vars = tempfile.mkdtemp(dir=role1)

    # test1.yml in role vars directory

# Generated at 2022-06-21 02:27:38.019199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    # hash_behaviour must be explicitly set to None, because C.DEFAULT_HASH_BEHAVIOUR is commit
    # Defaults in the code below only set values explicitly when they differ from the default

# Generated at 2022-06-21 02:27:46.378389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import os.path as path
    import shutil

    from ansible.plugins.action.include_vars import ActionModule

    # Create temporary directory structure to be used as data source
    test_data_source = path.join(os.getcwd(), '__test_data_source')
    test_data_source_var_a = path.join(test_data_source, 'vars', 'a.yml')
    test_data_source_var_b = path.join(test_data_source, 'vars', 'b.yml')
    os.makedirs(path.join(test_data_source, 'vars'))
    # set up config for test data source

# Generated at 2022-06-21 02:27:48.913484
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(loader=None, task=None, connection=None, play_context=None,
                        loader_args=None, templar=None, shared_loader_obj=None)



# Generated at 2022-06-21 02:27:55.747003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    print("actionModule")
    print(actionModule)
    print("actionModule._task.args")
    print(actionModule._task.args)

    source_dir = "/Users/davidlai/code/github/ansible-role-test/roles/python36/vars/main.yml"
    actionModule._task.args = {'dir': source_dir, 'depth': 0}
    print("actionModule._task.args")
    print(actionModule._task.args)
    task_vars = {}
    print("actionModule.run")
    print(actionModule.run(task_vars=task_vars))


# Generated at 2022-06-21 02:28:05.114002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test the run method of class ActionModule.
        Generate a random filename for each test and a matching name for the
        dict to be returned by _load_files.
    """
    from ansible.plugins.action.include_vars import ActionModule as include_vars
    from ansible.module_utils import basic
    from ansible.module_utils.pycompat24 import get_exception
    import random
    import string

    obj = include_vars(dict(), basic.AnsibleModule, '', True, '', True)

    # Test the run method with file extension specified
    file_ext = ['yaml', 'yml', 'json']

    for ext in file_ext:
        filename = ''.join(random.choice(string.ascii_lowercase + string.digits) for x in range(7))


# Generated at 2022-06-21 02:28:12.668045
# Unit test for constructor of class ActionModule
def test_ActionModule():

    print("Testing constructor of class ActionModule")
    action_module = ActionModule(load_params=(), task_ds=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    if action_module is None:
        raise RuntimeError("Unable to create ActionModule")


"""
Execute unit tests
"""
if __name__ == '__main__':

    try:

        test_ActionModule()

    except RuntimeError as error:

        print(error)

    else:

        print("All unit tests passed")

# Generated at 2022-06-21 02:28:23.346960
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task_vars = dict()

    # Test case with file and role
    mock_task = Mock(spec=['_role'])
    mock_task._role = Mock(spec=['_role_path'])
    mock_task._role._role_path = './roles/test'
    mock_task.args = {
        'file': './roles/test/vars/test1.yml'
    }

    action_module = ActionModule(mock_task, task_vars)
    action_module._find_needle = Mock(return_value='./roles/test/vars/test1.yml')
    action_module._load_files = Mock(return_value=(False, '', {'foo': 'bar'}))


# Generated at 2022-06-21 02:28:48.029943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:28:50.906943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule = ActionModule()
    test_ActionModule._task.args['dir'] = './tests/files/vars'
    test_ActionModule.run()

# Generated at 2022-06-21 02:28:54.393241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

# Generated at 2022-06-21 02:29:04.823019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import runpy
    import tempfile
    
    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create temporary ansible.cfg
    with open(path.join(tmpdir, 'ansible.cfg'), 'w') as f:
        f.write('[defaults]\nroles_path = {}\n'.format(tmpdir))
    # Create temporary playbook

# Generated at 2022-06-21 02:29:13.475410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # mock_task = {'args': {'_raw_params': './test/test.yml'}}
    # am = ActionModule(mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # assert am.source_dir == './test/test.yml'
    # assert am.source_file == './test/test.yml'
    pass


# Generated at 2022-06-21 02:29:16.123060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    res = ActionModule.run('', '')
    assert res is None

# Generated at 2022-06-21 02:29:26.696302
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    globals()['C'] = OpenStruct()

    #dir
    C.DEFAULT_HASH_BEHAVIOUR = 'replace'
    task_vars = {'test_1': 'default_value'}

    #valid_dir
    args = {'dir': 'data',
            'hash_behaviour': 'replace'
           }

    module = ActionModule(args)
    module._task = OpenStruct()
    module._task._role = OpenStruct()
    module._task._role._role_path = 'data/role'
    module._task._ds = OpenStruct()
    module._task._ds._data_source = 'data/role/tasks/main.yml'
    module._task.action = 'include_vars'
    module._task.args = args

    module._loader = OpenStruct()
   

# Generated at 2022-06-21 02:29:29.017549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global action_module
    action_module = ActionModule()


# Generated at 2022-06-21 02:29:30.141472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
        pass


# Generated at 2022-06-21 02:29:31.516159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:30:20.585698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    file = ActionModule()
    assert file.VALID_FILE_ARGUMENTS == ['file', '_raw_params']

# Generated at 2022-06-21 02:30:30.494383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    sets_instance_variables = ["VALID_FILE_EXTENSIONS", "VALID_DIR_ARGUMENTS",
                               "VALID_FILE_ARGUMENTS", "VALID_ALL",
                               "show_content", "source_dir",
                               "depth", "ignore_files", "included_files",
                               "return_results_as_name", "source_file"]
    action_module = ActionModule()
    for instance in sets_instance_variables:
        assert hasattr(action_module, instance) == True



# Generated at 2022-06-21 02:30:41.582184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    obj_task = Task()
    obj_task._role = ''
    obj_task.args = {'dir': './test/unit/additional_vars', 'depth': 1, 'name': 'test_vars', 'files_matching': '^.*$'}

    obj_block = Block()
    obj_block.block  = [obj_task]
    obj_block.root_block  = True

    obj_action_module = ActionModule(obj_task, obj_block)

    return obj_action_module

# Generated at 2022-06-21 02:30:51.329197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    import ansible.plugins
    import ansible.plugins.loader
    import tempfile
    import shutil
    import yaml

    test_path = '/tmp/ansible_modules_test/include_vars'
    temp_path = tempfile.mkdtemp(prefix='ansible_test_modules_', dir=test_path)

    # Generate role directory structure
    role_path = tempfile.mkdtemp(prefix='test_role_', dir=temp_path)
    task_path = path.join(role_path, 'tasks')
    vars_path = path.join(role_path, 'vars')

# Generated at 2022-06-21 02:30:52.680752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()

# Generated at 2022-06-21 02:31:00.008733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Attempts to run the function
    # Throws an exception if the function is not found
    if not hasattr(ActionModule, 'run'):
        raise Exception('Method run in class ActionModule not found')
    # Throws an exception if the method is not callable
    if not callable(getattr(ActionModule, 'run')):
        raise Exception('Method run in class ActionModule not callable')
    # Returns true if the method can be run
    return True


# Generated at 2022-06-21 02:31:00.970039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()

# Generated at 2022-06-21 02:31:12.666360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from unittest.mock import Mock

    def _create_task(role, raw_params, path, args, ds=None):
        class _MockTask:
            def __init__(self, role, raw_params, path, args, ds):
                self._role = role
                self._raw_params = raw_params
                self._ds = ds
                self.args = dict()
                self.args['_raw_params'] = raw_params
                self.args['path'] = path
                self.args.update(args)

        class _MockRole:
            def __init__(self, role_path):
                self._role_path = role_path

        class _MockDS:
            def __init__(self, ds):
                self._data_source = ds

# Generated at 2022-06-21 02:31:15.702428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    if not isinstance(action_module, ActionModule):
        raise AssertionError()


# Generated at 2022-06-21 02:31:23.082563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Empty case, nothing is passed and therefore the defaults are used.
    try:
        test = ActionModule()
    except Exception as e:
        raise AssertionError('Constructor of class ActionModule failed: {0}'.format(e))

    # ActionModule does not support constructor with arguments and therefore this should fail.
    try:
        test = ActionModule(name='test', arguments={'dir': '/root/test/dir'})
    except Exception as e:
        raise AssertionError('Constructor of class ActionModule failed: {0}'.format(e))

# Generated at 2022-06-21 02:33:25.185438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:33:26.691855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:33:39.395122
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import ModuleLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    my_vars = {
        'myvar': {
            'one': 1
        }
    }
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    variable_manager._extra_vars = my_vars

# Generated at 2022-06-21 02:33:49.366616
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Tests the constructor of class ActionModule
    """
    def test_init(mocker):
        class _task_mocker(object):
            def __init__(self):
                self.action = 'include_vars'
                self.args = dict(
                    file='test.yml',
                    _raw_params='test2.yml'
                )

        class _ds_mocker(object):
            def __init__(self):
                self._data_source = 'test3.yml'

        class _role_mocker(object):
            def __init__(self):
                self._role_path = '/tmp/test/'

        class _task_ds(object):
            def __init__(self):
                self._ds = _ds_mocker()


# Generated at 2022-06-21 02:33:55.883063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create objects to satisfy call to run method
    args = {
        '_task': object(),
        '_connection': object(),
        '_play_context': object(),
        'loader': object(),
        'templar': object(),
        'shared_loader_obj': object(),
    }
    am = ActionModule(**args)
    # Call run method with minimal available data
    am.run()

# Generated at 2022-06-21 02:34:02.209567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act_mod = ActionModule()
    if isinstance(act_mod, ActionModule):
        print('Test Success: Base class constructor was called properly')
    else:
        print('Test Failure: Base class constructor was not called properly')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:34:03.664014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # this is a placeholder.
    assert True

# Generated at 2022-06-21 02:34:05.060644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    p = ActionModule()
    assert p


# Generated at 2022-06-21 02:34:07.765898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO (mjm): implement me
    pass


# Generated at 2022-06-21 02:34:08.672260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True