

# Generated at 2022-06-21 02:27:00.583094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-21 02:27:06.502724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate object of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Set instance variable action_module.source_dir
    action_module.source_dir = "./vars"
    # Call method run
    result = action_module.run()
    # Assert
    assert(result['failed'] is False)
    assert(result['ansible_facts']['message'] == "Hello world!")

# Generated at 2022-06-21 02:27:17.064494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(load_vars_from_main_file=False)
    module._task.args = {
        'name': 'unittest',
        'dir': 'test/files/files_in_dir',
        'depth': 0,
        'files_matching': r'(?:.*\.yml|.*\.yaml)',
        'ignore_files': ['ignore_me.yml'],
        'extensions': ['yaml'],
        'ignore_unknown_extensions': True
    }

    module._set_args()
    module._set_root_dir()
    module._set_dir_defaults()

    result = module.run(task_vars={})

# Generated at 2022-06-21 02:27:25.977370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeTask:
        def __init__(self):
            self.args = {
                'param': 'value'
            }

    class FakeLoader:
        def __init__(self):
            self._data = {'param': 'value'}

        def load(self, path, show_content=False):
            return self._data

    class FakeTaskVars:
        def __init__(self):
            self.param = 'value'

    class FakeDS:
        def __init__(self):
            self._data_source = '/path/to/default'

    class FakeRole:
        def __init__(self):
            self._role_path = '/path/to/role'

    class FakeOptions:
        def __init__(self):
            self.connection = 'local'


# Generated at 2022-06-21 02:27:36.718574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_task = dict(
        args=dict(
            dir='some_dir',
        ),
    )
    fake_loader = dict()
    fake_play = dict(
        basedir='some_dir',
    )
    module = ActionModule(fake_task, fake_loader, fake_play)
    module_params = dict(
        dir='some_dir',
        ignore_unknown_extensions=False,
        hash_behaviour='replace',
        extensions=['yml', 'yaml', 'json'],
    )
    assert module._task.args == module_params
    assert module.depth == 0

    fake_task = dict(
        args=dict(
            file='some_file',
        ),
    )
    fake_loader = dict()

# Generated at 2022-06-21 02:27:42.197594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None).VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule(None, None).VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule(None, None).VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-21 02:27:43.312145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:27:50.273070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing")
    a = ActionModule("Dummy", "Dummy")
    assert a._task.args['file'] == "a/b/c/d.yml"
    assert a._task.args['_raw_params'] == "a/b/c/d.yml"
    assert a.source_file == "a/b/c/d.yml"

# Generated at 2022-06-21 02:28:01.622178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock objects
    params = {
        'dir': 'dir1',
        'depth': 2,
        'ignore_files': 'file1'
    }
    tmp = None
    task_vars = {
        'role_path': 'role1'
    }
    action_base = ActionBase()
    dummy_loader = 'dummy_loader'
    action_base._loader = dummy_loader
    action_base._task = {
        '_role': {
            '_role_path': 'role_path'
        }
    }
    action_module = ActionModule()
    action_module._task.args = params
    action_module._task._ds = {
        '_data_source': 'data_source1/'
    }

# Generated at 2022-06-21 02:28:06.225632
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Arrange
    module = ActionModule(None, None, None, None)
    # Act
    actual = module.run()
    # Assert
    assert( isinstance(actual, dict) )



# Generated at 2022-06-21 02:28:31.893858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-21 02:28:44.607180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # action_module_class is a global variable defined in ansible.module_utils.basic.AnsibleModule
  action_module_class = ActionModule
  # source_file is a global variable defined in ansible.module_utils.basic.AnsibleModule
  source_file = 'asd/test.yml'

  # mock_task is a global variable defined in ansible.mock.patch
  # mock_task is a MagicMock class
  # type(mock_task) -> MagicMock
  mock_task = mock_task

  # mock_task.args is a MagicMock class
  # type(mock_task.args) -> MagicMock
  # type(mock_task.args.get('name')) -> MagicMock
  mock_task.args.get('name').return_value = None


# Generated at 2022-06-21 02:28:56.698204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task that has a valid data source
    mock_task = MockTask()
    mock_task._ds = MockDatasource("/home/mock_task/tasks/main.yml")

    # Create a mock ActionModule
    mock_action_module = MockActionModule(mock_task)

    # Create a dict with valid directory args
    dir_args = dict(dir="/home/mock_task/tasks/vars/main.yml")

    # Call method run of ActionModule
    mock_action_module.run(task_vars=dict(), **dir_args)

    # Get return value of run()
    result = mock_action_module.run()

    # Assert that the return value is as expected

# Generated at 2022-06-21 02:29:05.624028
# Unit test for method run of class ActionModule
def test_ActionModule_run():  # type: () -> None
    from ansible.playbook.play_context import PlayContext

    module = ActionModule(play_context=PlayContext())
    setattr(module, "_task", "no task")

    results = dict()
    results['ansible_facts'] = dict()
    results['ansible_facts']['inventory_hostname'] = 'test'
    results['ansible_facts']['foo'] = 'bar'
    results['ansible_included_var_files'] = ['test_vars_1.yml', 'test_vars_2.yml']

    test_file = 'test_vars_1.yml'
    test_filename = 'test_vars.yml'
    test_file_loader = 'test_vars_3.yml'
    test_file_loader

# Generated at 2022-06-21 02:29:16.641966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.include_vars import ActionModule
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    add_all_plugin_dirs()

    task = Task()
    task._role = Role()
    task._role.name = 'myrole'
    task._role._role_path = '/home/zhujie/src/ansible/test/roles/myrole'

    task_vars = dict()
    play_context = PlayContext()

# Generated at 2022-06-21 02:29:24.528159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None
    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-21 02:29:35.977125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    from ansible.utils.vars import combine_vars
    from ansible.plugins.action.include_vars import ActionModule
    from ansible.module_utils.common._collections_compat import Mapping
    # Declare variables required to test run()
    return_results_as_name = 'master'
    source_dir = '/tmp/source_dir'
    err_msg = 'some error'
    # Test Case 1: source_dir is invalid

# Generated at 2022-06-21 02:29:45.508763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task_vars for use in test
    task_vars = dict(
        main_test_var='test_var_val',
        main_test_list=['main_item_1', 'main_item_2'],
        main_test_dict=dict(
            main_dict_key1='main_dict_val1',
            main_dict_key2='main_dict_val2',
        ),
        test_var='test_var_val',
        test_list=['item_1', 'item_2'],
    )

    # create a mock _task for use in test

# Generated at 2022-06-21 02:29:46.375677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 02:29:53.634805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # load_data returns a dict
    def load_data(data):
        return dict(name="test")

    # _get_file_contents returns a tuple (test string, bool)
    def _get_file_contents(filename):
        return ("test", True)

    # _get_file_metadata(loader, filename, file_search=True) returns a dict
    source_dir = "src"
    source_file = "source_file"
    depth = 0
    matcher = re.compile(r'{0}'.format(""))
    ignore_files = list()

    # _get_file_metadata returns a dict
    def _get_file_metadata(loader, filename, file_search=True):
        return dict()

    # _get_role_path returns a path

# Generated at 2022-06-21 02:30:37.982766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    print('Not implemented')

# Generated at 2022-06-21 02:30:45.120898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec = dict(
            dir = dict(type='str'),
            depth = dict(type='int', default = 0),
            files_matching = dict(type='str', default = None),
            ignore_files = dict(type='list', default = list()),
            extensions = dict(type='list', default = ['yml', 'yaml', 'json']),
            file = dict(type='str', default = None),
            name = dict(type='str', default = None),
            ignore_unknown_extensions = dict(type='bool', default = False),
            hash_behaviour = dict(type='str', default = None)
        )
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    task_vars = dict()



# Generated at 2022-06-21 02:30:54.690921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os

    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = 'library'
            self.forks = 1
            self.become = None
            self.become_method = None
            self.become_user = None
            self.check = False
            self.listhosts = None
            self.listtasks = None
            self.listtags = None
            self.syntax = None


# Generated at 2022-06-21 02:31:00.305677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert type(action_module) == ActionModule

    # instance variables
    variables = ['VALID_FILE_EXTENSIONS', 'VALID_DIR_ARGUMENTS', 'VALID_FILE_ARGUMENTS', 'VALID_ALL']
    assert all(action_module.__dict__.get(variable) is not None for variable in variables)


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:31:12.404138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._task.args.get('hash_behaviour', None) is None
    assert action_module._task.args.get('name', None) is None
    assert action_module._task.args.get('dir', None) is None
    assert action_module._task.args.get('file', None) is None
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']

# Generated at 2022-06-21 02:31:21.267765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.vars import ActionModule
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import plugin_loader

    loader = DataLoader()

    group = Group()
    group.name = 'testgroup'
    group.vars = {}

    host = Host()

# Generated at 2022-06-21 02:31:29.383374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.release import __version__

    source_dir = './test/action_plugins/test_include_vars_dir'
    source_file = './test/action_plugins/test_include_vars_file.yml'

    class Task_Mock(Task):
        _role = None

    play_context = PlayContext()
    play_context.remote_addr = 'cluster'
    play_context.connection = 'ssh'
    play_context.remote_user = 'ubuntu'
    play_context.password = 'VMBox.9'
    play_context.port = 22


# Generated at 2022-06-21 02:31:39.580319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    action = ActionModule()
    assert isinstance(action, ActionBase)
    assert isinstance(action._task, TaskQueueManager)
    assert isinstance(action._task._block, PlaybookExecutor)
    assert isinstance(action._task._loader, DataLoader)
    assert isinstance(action._task._variable_manager, VariableManager)

# Generated at 2022-06-21 02:31:51.362447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  """ Unit test for method run of class ActionModule
  """

  # Try to change the current working directory
  current_dir = os.path.abspath(os.path.dirname(__file__))
  os.chdir(current_dir)

  # Load configuration from YAML
  with open('../../configuration.yml', 'r') as f:
    cfg = yaml.load(f)

  # Set environment variable ANSIBLE_HOST_KEY_CHECKING to False
  os.environ['ANSIBLE_HOST_KEY_CHECKING'] = 'False'

  # Create Ansible inventory object
  hosts = set()
  for line in open('../../inventory/hosts'):
    if len(line) > 1 and line[0] != '#':
      hostname = line.strip().split()

# Generated at 2022-06-21 02:31:52.739970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule


# Generated at 2022-06-21 02:33:44.112947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME
    pass



# Generated at 2022-06-21 02:33:45.198422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test creation of ActionModule without parameters."""

    assert ActionModule()


# Generated at 2022-06-21 02:33:46.509240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 02:33:57.548159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # arrange
    module_name = 'test_module'
    module_args = {
        'file': 'test/files/test_file.yml',
        'name': 'test_results',
        '_raw_params': 'test/files/test_file.yml'
    }
    task_name = 'test_task'

    # mock
    task = MockTask(name=task_name, args=module_args)
    am = ActionModule(task, module_name)
    am._create_tmp_path = lambda: '/tmp'

    # act
    result = am.run()

    # assert
    assert 'ansible_facts' in result
    assert result['ansible_facts']['test_results'] == {'key1': 'value1'}

# Generated at 2022-06-21 02:33:58.776230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:34:08.497533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule"""

    def _get_module_args(module_name='include_vars', **kwargs):
        """ Get the arguments for the module """

        args = dict(
            name='the_var',
            dir='/etc/ansible/facts.d',
        )

        args.update(kwargs)

        task = dict(
            action=dict(
                module=module_name,
                args=args,
                )
        )
        return task

    def _get_ansible_module(**kwargs):
        """ Get an instance of the AnsibleModule """

        task = dict(
            args=dict(
                name='the_var',
                dir='/etc/ansible/facts.d',
            )
        )


# Generated at 2022-06-21 02:34:09.526084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:34:19.041389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n# Unit test ActionModule_run()\n")

    # Create a FakeModule
    fake_module = FakeModule()

    # Create a FakeAnsibleLoader
    fake_loader = FakeAnsibleLoader()

    # Create a FakePlayContext
    fake_play_context = FakePlayContext()

    # Create a FakeTask
    fake_task = FakeTask()

    # Create an ActionModule
    action_module = ActionModule(task=fake_task, connection=None, play_context=fake_play_context, loader=fake_loader, templar=None, shared_loader_obj=None)

    # Run the method "run" and assert if it does not fail
    try:
        action_module.run(task_vars={})
    except Exception as e:
        print(str(e))
        assert False

# Generated at 2022-06-21 02:34:27.938495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set the test arguments
    args = {
        'name': 'ansible_facts',
        'dir': '/path/to/dir'
    }

    # set the test fixtures
    task_vars = dict()
    tmp = None
    source_dir = '/path/to/dir'

    # mock the object
    am = ActionModule()
    am._task.args = args
    am._set_root_dir = lambda: True
    am._set_args = lambda: True
    am._set_dir_defaults = lambda: True
    am._traverse_dir_depth = lambda: True
    am._load_files_in_dir = lambda dir, files: True
    am._loader._get_file_contents = lambda path: True
    am.run(tmp, task_vars)

# Generated at 2022-06-21 02:34:30.486488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None
