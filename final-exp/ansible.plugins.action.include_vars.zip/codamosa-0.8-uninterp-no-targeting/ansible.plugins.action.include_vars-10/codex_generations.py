

# Generated at 2022-06-21 02:26:56.144940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a._loader, object)



# Generated at 2022-06-21 02:27:00.024617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' ActionModule class constructor'''
    class ActionModule_constructor(ActionModule):

        def __init__(self):
            '''
            Constructor of class ActionModule
            '''
            self.show_content = True
            self.included_files = []

    actionmodule_main = ActionModule_constructor()

    assert actionmodule_main.show_content == True
    assert actionmodule_main.included_files == []


# Generated at 2022-06-21 02:27:07.024908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    import collections
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    action = ActionModule(module)
    for i in ['yml', 'yaml', 'json']:
        assert action._is_valid_file_ext('test.{0}'.format(i)) == True
    assert action._is_valid_file_ext('test.abc') == False

# For unit testing
if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:27:17.234537
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # prepare parameters
    class FakeTask:
        def __init__(self):
            self.args = {
                    'dir': 'test/data/test_dir',
                    'depth': 1,
                    'files_matching': '.*.yml',
                    'ignore_files': '.*main.yml',
                    'hash_behaviour': 'replace',
                    'name': None,
                    'extensions': 'yaml',
                    'extended': True
            }

    class FakeDS:
        def __init__(self):
            self._data_source = 'test/data/'

    class FakeRole:
        def __init__(self):
            self._role_path = 'test/data/test_dir'

    class FakePlaybook:
        def __init__(self):
            self.vars = {}


# Generated at 2022-06-21 02:27:18.237128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: mock object and test
    pass

# Generated at 2022-06-21 02:27:26.377734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test
    test_ActionModule = ActionModule(
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None
    )

    # Test passing a single file
    file_name = 'test.yml'
    test_ActionModule.source_file = file_name
    result = test_ActionModule.run()
    assert result['ansible_included_var_files'] == [file_name]

    # Test passing multiple files
    file_names = ['test.yml', 'test2.yml']
    test_ActionModule.source_file = file_names
    result = test_ActionModule.run()
    assert set(result['ansible_included_var_files']) == set(file_names)

    # Test passing a directory
   

# Generated at 2022-06-21 02:27:36.438707
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Note: can import modules here or set them up
    #       as class variables and initialize them in the setup() method.
    #       For example:
    #
    # class TestActionModule(unittest.TestCase):
    #
    #     def setUp(self):
    #         self.module = ActionModule()
    #
    #     def test_parse_date_1(self):
    #         ''' Test success scenario for parse_date method'''
    #         date = "April 1, 2014"
    #         parsed_date = self.module.parse_date(date)
    #         self.assertEqual(parsed_date, datetime.datetime(2014, 4, 1, 0, 0))

    pass

# Generated at 2022-06-21 02:27:45.435948
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:27:46.886067
# Unit test for constructor of class ActionModule
def test_ActionModule():
   assert type(ActionModule(dict(), dict())) is ActionModule


# Generated at 2022-06-21 02:27:48.158508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task={"args": {"name": "test_data", "hash_behaviour": None}})

# Generated at 2022-06-21 02:28:17.936941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(actionModule, ActionModule)

# Generated at 2022-06-21 02:28:26.686543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source_dir = "test/vars"
    source_file = "test/vars/main.yml"
    depth = 1
    depth2 = 2
    depth_zero = 0
    files_matching = ""
    ignore_files = ["*.yml"]
    extensions_var = ["yml"]
    hash_behaviour = "merge"
    return_results_as_name = "data"
    
    task_vars = {"foo": "bar"}
    tmp = "tmp"
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 02:28:29.406878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule("task").run(task_vars=dict())['ansible_facts'] is None

# Generated at 2022-06-21 02:28:34.892786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module.VALID_ALL == ['name', 'hash_behaviour']



# Generated at 2022-06-21 02:28:47.198804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
        Unit Tests for method ActionModule.run
    """
    # Test 1
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager

    variable_manager = VariableManager
    loader = action_loader
    variable_manager = VariableManager()
    loader = action_loader
    variable_manager._fact_cache = dict()
    variable_manager._extra_vars = dict()

    ansible_module = AnsibleModule({
        '_ansible_check_mode': False,
        '_ansible_debug': False,
        '_ansible_diff': False,
        '_ansible_no_log': False
    })

    ansible_

# Generated at 2022-06-21 02:28:47.716133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:28:50.153562
# Unit test for constructor of class ActionModule
def test_ActionModule():
    acm = ActionModule()
    assert len(acm.VALID_ALL) == 2



# Generated at 2022-06-21 02:28:52.834647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-21 02:29:02.337946
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert type(actionModule) == ActionModule
    assert actionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert actionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert actionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert actionModule.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-21 02:29:10.668290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-21 02:30:03.681565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

# Generated at 2022-06-21 02:30:13.781864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule
    """

    import os
    import sys
    import shutil
    import tempfile
    import unittest

    from ansible.module_utils import six
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase

    from ansible.utils.vars import combine_vars

    from ansible.plugins.action.include_vars import ActionModule

    class TestActionBase(unittest.TestCase):

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file_dir = os.path.join(self.test_dir, 'test_include_vars')

# Generated at 2022-06-21 02:30:23.562783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action_mod = ActionModule()

    assert test_action_mod.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

    assert ('dir' in test_action_mod.VALID_DIR_ARGUMENTS) and ('depth' in test_action_mod.VALID_DIR_ARGUMENTS)
    assert ('files_matching' in test_action_mod.VALID_DIR_ARGUMENTS) and ('ignore_files' in test_action_mod.VALID_DIR_ARGUMENTS)
    assert ('extensions' in test_action_mod.VALID_DIR_ARGUMENTS) and ('ignore_unknown_extensions' in test_action_mod.VALID_DIR_ARGUMENTS)


# Generated at 2022-06-21 02:30:30.945029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module.VALID_FILE_EXTENSIONS, list), "VALID_FILE_EXTENSIONS must be a list"
    assert isinstance(action_module.VALID_DIR_ARGUMENTS, list), "VALID_DIR_ARGUMENTS must be a list"
    assert isinstance(action_module.VALID_FILE_ARGUMENTS, list), "VALID_FILE_ARGUMENTS must be a list"
    assert isinstance(action_module.VALID_ALL, list), "VALID_ALL must be a list"

# Generated at 2022-06-21 02:30:43.119351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.modules.source_control.mercurial import _eval_params as eval_params
    from ansible.module_utils.six import ensure_str as ensure_str
    from ansible.module_utils._text import to_text
    from ansible import context
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    from ansible.utils.vars import combine_vars
    import os,sys
    
    # check if

# Generated at 2022-06-21 02:30:44.314988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(None, None), ActionModule)

# Generated at 2022-06-21 02:30:54.035121
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.common.collections import ImmutableDict
    # Initialize _task and _task_vars
    _task = type('obj', (object,), {'_role': removed, '_ds': 'some/path/some_file.yml', 'args': { '_raw_params': 'some/path/some_file.yml'}})
    _task_vars = ImmutableDict()

    # Verify that an error is raised when you mix file and dir arguments

# Generated at 2022-06-21 02:31:01.949746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # Test method run with no args
    assert action_module.run() == {
        'failed': False,
        'ansible_facts': {},
        'ansible_included_var_files': [],
        '_ansible_no_log': True
    }

    # Test method run with multiple args
    assert action_module.run(task_vars={'test_vars': {'var_one': 'one', 'var_two': 'two'}}) == {
        'failed': False,
        'ansible_facts': {'test_vars': {'var_one': 'one', 'var_two': 'two'}},
        'ansible_included_var_files': [],
        '_ansible_no_log': True
    }

#

# Generated at 2022-06-21 02:31:05.273018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    play_context = PlayContext()
    play_context.check_mode = False
    action = action_loader.get('include_vars', play_context=play_context)
    return action
    

# Generated at 2022-06-21 02:31:08.636184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(args=dict(dir=dict(extensions=['yml', 'yaml'], files_matching='\d{1,}', ignore_files=['vars']))))
    res = module.run()
    assert res.get('message') == None
    assert isinstance(res.get('ansible_facts'), dict)


# Generated at 2022-06-21 02:33:14.074837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:33:15.549762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:33:17.161886
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, None, None)

# Generated at 2022-06-21 02:33:29.089983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock task
    task =  MagicMock()
    args = {'name': None, 'dir': '/home/ansible/demo/files'}
    task.args = args

    # Mock task object
    task_object = MagicMock()
    task_object.get_vars.return_value = {'name': 'Allen'}
    task_object.copy.return_value = {'name': 'Allen-2'}
    task_object.run.return_value = {'name': 'Allen'}

    # Mock task_ds
    task_ds = MagicMock()
    task_ds._data_source = '/home/ansible/demo/tasks/foo.yml'

    task.task_ds = task_ds

    # Mock role
    role = MagicMock()
    role._role

# Generated at 2022-06-21 02:33:30.530772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-21 02:33:40.680036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    # Set all instance variables
    # Assert if these variables are the same as what is expected
    action_module_test = ActionModule()
    action_module_test.TRANSFERS_FILES = False
    action_module_test.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
    action_module_test.VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    action_module_test.VALID_FILE_ARGUMENTS = ['file', '_raw_params']
    action_module_test.VALID_ALL = ['name', 'hash_behaviour']
    action_module_test.hash_behaviour = None
    action

# Generated at 2022-06-21 02:33:44.052279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(dict(), dict(), dict(), dict())
    if not isinstance(am, ActionModule):
        raise AssertionError('class ActionModule has not been created properly')

# Generated at 2022-06-21 02:33:56.171374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = {
        'action': 'include_vars',
        'name': 'ansible_facts',
        'args': {
            'file': 'ansible-facts.yml'
        }
    }
    mock_ds = {
        '_data_source': {
            'module_name': 'include_vars',
            'module_vars': {
                'file': 'ansible-facts.yml'
            }
        },
        '_role_name': 'include_vars'
    }
    mock_ds.update(mock_task)
    mock_task['_ds'] = mock_ds
    mock_task['_ds']['_data_source'] = 'tasks/main.yml'

# Generated at 2022-06-21 02:34:07.530438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ unit test for constructor of class ActionModule
    """
    # arrange
    task_vars = {
        'ansible_verbosity': 3,
        'ansible_version': '1.8.5',
        'ansible_version_full': '1.8.5',
        'ansible_version_major': '',
        'ansible_version_minor': '',
        'ansible_version_revision': '',
        'ansible_version_string': 'v1.8.5'
    }


# Generated at 2022-06-21 02:34:09.726332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionModule)