

# Generated at 2022-06-21 02:27:05.772350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()

    # Set _task.args
    am._task.args = {}
    am._task.args['vars'] = '/home/asanabria/git/asanabria/ansible-tests/tasks/vars'
    am._task.args['hash_behaviour'] = None

    am.run()
    results = am.results

    assert results['ansible_facts']['test_var'] == 'test_var_value'
    assert results['ansible_facts']['test_var2'] == 'test_var2_value'
    assert results['ansible_included_var_files'] == ['/home/asanabria/git/asanabria/ansible-tests/tasks/vars/test-var.yml']

# Generated at 2022-06-21 02:27:12.684054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # obj_path
    path = "/tmp/ansible_include_vars_payload.data"

    # Create a test obj
    fd = open(path, "w")
    fd.write("""
    {
        "USERNAME": "DUMMY_USERNAME",
        "PASSWORD": "DUMMY_PASSWORD",
        "HOST_IP": "DUMMY_HOST_IP",
        "HOST_NAME": "DUMMY_HOST_NAME",
        "PORT": "DUMMY_PORT"
    }
    """)
    fd.close()

    # Set up task vars
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block

# Generated at 2022-06-21 02:27:23.979670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={
        'file': {'type': 'str'},
        '_raw_params': {'type': 'str'},
        'name': {'type': 'str'},
        'depth': {'type': 'int'},
        'files_matching': {'type': 'str'},
        'ignore_files': {'type': 'list'},
        'extensions': {'type': 'list'},
        'ignore_unknown_extensions': {'type': 'bool'},
        'dir': {'type': 'str'},
        'hash_behaviour': {'type': 'str'}
    })

# Generated at 2022-06-21 02:27:25.400122
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-21 02:27:27.288681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert isinstance(actionModule, ActionModule)


# Generated at 2022-06-21 02:27:37.636038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with patch('ansible.plugins.action.ActionModule') as mock:
        f_obj = type('Fobj', (object,), {'_task': type('object', (object,), {'args': {'_raw_params': None} }) })()
        mock._find_needle.return_value = None
        obj = mock()
        obj.run(None, None)
        assert mock._find_needle.call_count == 1

    f_obj = type('Fobj', (object,), {'_task': type('object', (object,), {'args': {'_raw_params': 'file.yml'} }) })()
    with patch('ansible.plugins.action.ActionModule') as mock:
        mock._find_needle.return_value = 'file.yml'
        obj = mock()


# Generated at 2022-06-21 02:27:46.208141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Mocked values for class attributes
    task = type('task', (), {})()
    task.args = {'file': 'b/a/c.py',
                 'hash_behaviour': 'merge',
                 'name': 'results',
                 '_raw_params': None}
    task._role = type('role', (), {})()
    task._role._role_path = 'b/c'
    task._ds = type('ds', (), {})()
    task._ds._data_source = 'b/c/a/main.yml'
    source_dir = 'b/c/a'

    # Mocked values for load_files_in_dir
    root_dir = 'b/c'
    var_files = ['a', 'main.yml']

# Generated at 2022-06-21 02:27:53.788177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult
    from ansible.task_vars import TaskVars
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task

# Generated at 2022-06-21 02:27:54.306680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return 0

# Generated at 2022-06-21 02:28:01.148155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global cwd, task_vars
    cwd = os.getcwd()
    task_vars = dict()
    try:    
        test_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        if test_module:
            print("test successful")
    except Exception:
        print("test unsuccessful")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:28:24.883034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:28:32.346250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext

    args = dict(dir='dir', depth=1, file='file', files_matching='files_matching', ignore_files='ignore_files', extensions='yml', ignore_unknown_extensions=False, name='name', hash_behaviour='merge')
    action_module = ActionModule(None, None, args, play_context=PlayContext())

    action_module.run()

# Generated at 2022-06-21 02:28:45.304817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.ec2 import ec2_connect
    from ansible.plugins.loader import action_loader
    import json
    import os

    # Load test data
    loader = DataLoader()
    current_dir = os.path.dirname(__file__)
    source_file = current_dir + '/test_data/test_action_module.yaml'

# Generated at 2022-06-21 02:28:57.161014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # In case of files
    ActionModule._set_args = lambda x: None
    ActionModule._set_args.__doc__ = None
    
    ActionModule.source_file = 'test_source_file'
    ActionModule.hash_behaviour = None
    ActionModule.return_results_as_name = None
    ActionModule.source_dir = None
    ActionModule.depth = None
    ActionModule.files_matching = None
    ActionModule.ignore_unknown_extensions = False
    ActionModule.ignore_files = None
    ActionModule.valid_extensions = ['yaml', 'yml', 'json']

    # Test for ActionBase.run
    ActionBase.run = lambda x, tmp=None, task_vars=None: True
    ActionModule.run()

    # Test for ActionBase.run
    Action

# Generated at 2022-06-21 02:29:05.759635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.network_os = 'aix'
    play_context.remote_addr = 'localhost'
    task = Task()
    task._role = None

# Generated at 2022-06-21 02:29:16.697173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    os_mock = mock.MagicMock()
    os_mock.path.join.return_value = 'test'
    sys_mock = mock.MagicMock()
    sys_mock.modules.get.return_value = os_mock
    os_mock.path.dirname.return_value = 'test_dirname'
    os_mock.path.isfile.return_value = True
    mock_module = mock.MagicMock()
    mock_module.exists.return_value = True
    mock_datasource_loader = mock.MagicMock()
    mock_datasource_loader.exists.return_value = True
    mock_module.loader = mock_datasource_loader
    mock_playbook = mock.MagicMock()
    mock_playbook._ds = mock

# Generated at 2022-06-21 02:29:26.894532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import os

    import ansible
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    from ansible.plugins.action import ActionModule
    class Mock_ActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar,
                     shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self.shared_loader_obj = shared_loader_obj


# Generated at 2022-06-21 02:29:33.861565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing action module class against invalid arguments
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    try:
        action_module._set_args()
        assert False, 'Exception not raised'
    except AnsibleError as e:
        assert 'is not a valid option in include_vars' in e.message



# Generated at 2022-06-21 02:29:35.385018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:29:36.205969
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:30:23.786878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, object)

# Generated at 2022-06-21 02:30:29.718391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules

    # ansible.runner._create_global_tmp_dir()
    ansible.modules.load_module_utils('include_vars')
    # task_vars = {}
    # result = ActionModule.run(None, tmp, task_vars)
    # assert result is not None

# Generated at 2022-06-21 02:30:31.050724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:30:43.150299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="")
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    module_name = "ping"
    module_args = {}
    module_kwargs = {}


# Generated at 2022-06-21 02:30:43.743166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:30:53.598452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock class AnsibleTaskVars
    class AnsibleTaskVars:
        def __init__(self, args):
            self.args = args

    # Mock class AnsibleModule
    class AnsibleModule:
        def __init__(self, task_vars):
            self._task = AnsibleTaskVars(task_vars)

    # Mock class AnsibleModuleArgs
    class AnsibleModuleArgs:
        def __init__(self, name, dir, depth, files_matching, ignore_files, extensions, ignore_unknown_extensions,
                     hash_behaviour, _raw_params, file=None):
            self.name = name
            self.dir = dir
            self.depth = depth
            self.files_matching = files_matching
            self.ignore_files = ignore_files
            self.extensions

# Generated at 2022-06-21 02:31:03.002946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules.system
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.callback import CallbackBase
    import tempfile
    import shutil
    import json
    import os


# Generated at 2022-06-21 02:31:06.909130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing class ActionModule')
    print('Creating an instance of class ActionModule')
    action_module = ActionModule()
    print('Created an instance of class ActionModule')

# Generated at 2022-06-21 02:31:11.548814
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action_module = ActionModule(
        task=dict(
            args=dict(
                file='{{ lookup("file", "hostvars/{{ inventory_hostname }}/host_var_file") }}'
            )
        )
    )

    assert test_action_module.run(task_vars=dict(
        inventory_hostname='localhost'
    ))

# Generated at 2022-06-21 02:31:16.404435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule_instance = ActionModule()
    actionModule_instance._task.args['file'] = '../'
    assert not actionModule_instance.run()
    actionModule_instance._task.args['file'] = '.'
    assert not actionModule_instance.run()
    actionModule_instance._task.args['file'] = './'
    assert not actionModule_instance.run()
    actionModule_instance._task.args['file'] = 'test.yml'
    assert not actionModule_instance.run()
    actionModule_instance._task.args['file'] = 'test.yaml'
    actionModule_instance.VALID_FILE_EXTENSIONS = ['yml']
    assert actionModule_instance.run()


# Generated at 2022-06-21 02:33:30.219285
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test to validate the following args
    #     dir, name, hash_behaviour, extensions
    class MyTask(object):
        ''' Mock task class to return args '''
        def __init__(self, args):
            self.args = args


    def _make_global_args(dir, name, hash_behaviour, extensions):
        return dict(dir=dir, name=name, hash_behaviour=hash_behaviour, extensions=extensions)

    def _make_task(dir, name, hash_behaviour, extensions):
        args = _make_global_args(dir, name, hash_behaviour, extensions)
        return ActionModule(MyTask(args), dict())

    class MyRole(object):
        ''' Mock task class to return args '''

# Generated at 2022-06-21 02:33:32.414613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # assert that test_ActionModule is called by nosetests
    assert True

# Generated at 2022-06-21 02:33:38.630659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = {}
    tmp = None
    task_vars = {'a': 'b'}
    
    return_value = ActionModule().run(tmp, task_vars)
    assert return_value == {'_ansible_no_log': False, 'ansible_facts': {}, 'ansible_included_var_files': [], 'failed': True, 'msg': 'No source file specified for include_vars'}

# Generated at 2022-06-21 02:33:42.246439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    act_mod = ActionModule(dict(), dict(), False, None)
    act_mod._set_dir_defaults()
    act_mod.run()


# Generated at 2022-06-21 02:33:44.974329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_object = ActionModule()
    assert isinstance(test_object, ActionModule), "ActionModule should be of type 'ActionModule'"

# Generated at 2022-06-21 02:33:49.982377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _task = dict()
    _task['vars'] = dict()
    _task['args'] = dict()
    _task['args']['_raw_params'] = './test-module'
    return ActionModule(_task, dict(), False)

# Generated at 2022-06-21 02:33:58.990715
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:33:59.878857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 02:34:08.975825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager
    # Local imports
    from action_plugins.include_vars import ActionModule

    class Options():
        def __init__(self, vars_file, vars_file_depth):
            self.name = None
            self.depth = vars_file_depth
            self.extensions = ['yml']
            self.ignore_files = False
            self.hash_behaviour = 'merge'
            self.files_matching = None
            self.file = None
            self.dir = vars_file


# Generated at 2022-06-21 02:34:12.149013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule('test', 'test', 'test')
    assert isinstance(actionModule, ActionModule)