

# Generated at 2022-06-21 02:27:01.909092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.include_vars as module
    import ansible.module_utils.common.path
    import ansible.module_utils.common.collections

    class Task:
        def __init__(self):
            self._role = Role()
            self.args = dict()
            self.args['file'] = '/etc/ansible/test.yml'

    class Role:
        def __init__(self):
            self._role_path = '/home/ansible/myrole'

    class DataSource:
        def __init__(self):
            self._data_source = '/home/ansible/roles/common/tasks/main.yml'

    class Plugin(object):
        def __init__(self):
            self.name = 'include_vars'


# Generated at 2022-06-21 02:27:07.243802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing construction of ActionModule
    action_module = ActionModule(action_name='test_ActionModule', a_task=None,
                                 data='test data')

    assert action_module.action_name == 'test_ActionModule'


# Generated at 2022-06-21 02:27:14.266493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(
        task=dict(action=dict(args=dict(name='newname', _raw_params='/home/joe/myscript.yml', hash_behaviour='merge')))
    )
    assert x.return_results_as_name == 'newname'
    assert x.source_file == '/home/joe/myscript.yml'
    assert x.hash_behaviour == 'merge'

# Generated at 2022-06-21 02:27:22.214732
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.collections.ansible.community.plugins.module_utils.basic as basic
    from ansible.collections.ansible.community.plugins.module_utils.basic import AnsibleModule
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import ansible.plugins.loader as loader
    myargs = dict()
    myargs['name'] = 'test'
    myargs['ignore_unknown_extensions'] = False
    am = ActionModule(dict(), dict(), basic.AnsibleModule, 'test', 'test', myargs, [], loader)
    assert isinstance(am, ActionModule)
    assert(am.hash_behaviour == 'replace')
    assert(am.return_results_as_name == 'test')
    assert(am.source_dir == None)

# Generated at 2022-06-21 02:27:22.914930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-21 02:27:33.022065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.block as block
    import ansible.playbook.task as task
    import ansible.playbook.role as role
    import ansible.playbook.handler_task_include as handler_task_include
    import ansible.playbook.task_include as task_include
    import ansible.parsing.dataloader as dataloader
    from ansible.vars import VariableManager
    from ansible.inventory import Host, Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os
    import sys

    # Create a DataLoader
    loader = dataloader.DataLoader()

    # Create VariableManager
   

# Generated at 2022-06-21 02:27:41.259555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml import objects
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import ActionModuleLoader
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar


# Generated at 2022-06-21 02:27:50.980379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    src_dir = "vars"
    src_file = "var_file.yml"
    test_plugin = ActionModule()
    test_plugin._set_args()
    test_plugin._set_dir_defaults()
    test_plugin._set_root_dir()
    test_plugin.source_dir = src_dir
    test_plugin.source_file = src_file

    test_plugin.run()
    assert test_plugin.source_dir == src_dir
    assert test_plugin.source_file == src_file

# Generated at 2022-06-21 02:27:56.663226
# Unit test for constructor of class ActionModule
def test_ActionModule():

    _loader = '_loader'
    _templar = '_templar'
    _shared_loader_obj = {'no_log': False}

    class Task():
        def __init__(self, args, role, ds):
            self.args = args
            self._role = role
            self._ds = ds

    class DataSource():
        def __init__(self, data_source):
            self._data_source = data_source

    class Role():
        def __init__(self, role_path):
            self._role_path = role_path

    def run(self, tmp=None, task_vars=None):
        pass

    loader_mock = create_autospec(_loader)
    templar_mock = create_autospec(_templar)


# Generated at 2022-06-21 02:27:58.148896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:28:30.625820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    global pass_task_vars
    task_vars = pass_task_vars
    am = ActionModule()
    am.run(task_vars=task_vars)

if __name__ == '__main__':
    # Unit test for module ActionModule
    pass_task_vars = dict()
    print("Running unit tests")
    test_ActionModule_run()
    print("Passed unit tests")

# Generated at 2022-06-21 02:28:38.750018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unittest for method run of class ActionModule

    '''
    ##################################################
    # get the temp dir and fill it with dummy files
    tmp = tempfile.mkdtemp()
    name1 = os.path.join(tmp, "file1.yaml")
    name2 = os.path.join(tmp, "file2.yaml")
    name3 = os.path.join(tmp, "file3.yaml")
    with open(name1, "w") as f:
        f.write("var1: foo\n")
    with open(name2, "w") as f:
        f.write("var2: bar\n")
    with open(name3, "w") as f:
        f.write("var1: baz\n")

    # get the paths of the

# Generated at 2022-06-21 02:28:50.799129
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Create a new task
    task = Task()
    task._role = None
    task._ds = None

    # Create a new dataloader
    loader = DataLoader()

    # Create a new variable manager
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a new action module

# Generated at 2022-06-21 02:28:52.552299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)


# Generated at 2022-06-21 02:29:03.585539
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source_dir = 'test/suite/lib_utils/vars_loader/'
    source_file = 'test/suite/lib_utils/vars_loader/vars/main.yml'
    assert ActionModule.run(source_dir, '') == {"test_var2": 2, "test_var": "foo"}, "Error in ActionModule.run()"
    assert ActionModule.run(source_file, '') == {"test_var": "foo"}, "Error in ActionModule.run()"
    assert ActionModule.run(source_file, 'name=test_vars_name') == {"test_vars_name": {"test_var": "foo"}}, "Error in ActionModule.run()"


# Generated at 2022-06-21 02:29:15.613077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from pprint import pprint
    from collections import namedtuple

    FakeTask = namedtuple('FakeTask', ['args', '_role', '_ds'])
    args = {'dir': 'mdts_vars',
            'depth': 1,
            'extensions': ['yaml', 'yml'],
            'name': 'ansible_fact',
            'ignore_files': ['*.j2', '*.jnj'],
            'ignore_unknown_extensions': True}
    args2 = {'dir': 'mdts_vars',
            'depth': 1,
            'extensions': ['yaml', 'yml'],
            'name': 'new_fact',
            'ignore_files': ['*.j2', '*.jnj'],
            'ignore_unknown_extensions': True}
   

# Generated at 2022-06-21 02:29:17.816469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor import task_result

    ActionModule()

# Generated at 2022-06-21 02:29:27.474436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.task
    import ansible.utils.vars

    task_ds = ansible.playbook.task.Task()
    task_ds._role = ansible.playbook.role.RoleInclude()
    # add some content to task_ds._role, otherwise AttributeError: 'RoleInclude' object has no attribute 'role_name'
    # would be raised
    task_ds._role.role_name = 'some_role_name'
    task_ds._role._role_path = 'some_role_path'
    # add some content to task_ds._role, otherwise AttributeError: 'RoleInclude' object has no attribute '_role_path'
    # would be raised
    task_ds._ds = ansible.parsing.dataloader.DataLoader()
    task_ds._

# Generated at 2022-06-21 02:29:29.016810
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-21 02:29:34.169092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    module_path = 'ansible.plugins.action.include_vars.ActionModule'
    with patch(module_path) as mock_module:
        # Act
        mock_inst = mock_module.return_value
        mock_inst.run()
        # Assert
        mock_inst.run.assert_called_once()


# Generated at 2022-06-21 02:30:22.072852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var1 = "test"
    test_class = ActionModule(var1)
    assert test_class._task == var1

# Generated at 2022-06-21 02:30:32.786685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os
    import mock

    class ModuleUtilsMixin:
        @property
        def _ROLE_PATH(self):
            return '.'

    # Create a fake PlayContext object as return value for PlayContext.load()
    # and inject as return value for PlayContext.load()
    class PlayContext:
        def load(self):
            return self

        def __init__(self):
            self.new_task_uuid = '123-123-123'

    context_mock = mock.Mock()
    context_mock.new_task_uuid = '123-123-123'

    # Create a fake Task object as return value for Task.load()
    class Task:
        def load(self, attr, cache=True):
            return self


# Generated at 2022-06-21 02:30:39.237758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils import template as template_utils
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    class MockTask(object):
        def __init__(self, args):
            self.args = args

    class MockPlay(object):
        def __init__(self, role):
            self._role = role

    class MockRole(object):
        def __init__(self, role_path):
            self._role_path = role_path


# Generated at 2022-06-21 02:30:40.835069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_plugin = ActionModule(None, None)
    assert isinstance(action_plugin, ActionModule)

# Generated at 2022-06-21 02:30:42.126738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-21 02:30:52.088059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # the task is supposed to have been created and the necessary attributes assigned by the Ansible task engine
    task=MockTask()

    # set up the action module and call the run method to simulate ansible calling the module
    action_module=ActionModule(task, connection=None, play_context=MockPlayContext(), loader=MockLoader(), templar=MockTemplar(), shared_loader_obj=None)
    results = action_module.run(tmp=None, task_vars=dict())
    
    # verify that the results are as expected
    assert(results['failed'] == False)
    assert(results['ansible_included_var_files'] == ['vars/test_var.yaml'])
    assert(results['ansible_facts']['value'] == 'hello')

# Generated at 2022-06-21 02:31:02.392864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys

    from ansible.plugins.action.include_vars import ActionModule
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    try:
        import yaml
    except ImportError:
        raise AnsibleError("yaml is not installed")

    class MockTask(Task):
        def __init__(self, task_vars, task_args, task_name=None):
            self._task_vars = task_vars
            self._task_args = task_args

# Generated at 2022-06-21 02:31:09.226562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext

    task = Task()
    task._role = RoleContext()
    task.args = {'dir': 'test/test_vars', 'depth': 0, 'ignore_files': ['bad.*', 'good(1|2).*'], 'ignore_unknown_extensions': True}
    task._role._role_path = 'test'
    _action_module = ActionModule(task, PlayContext(), '/path/to/ansible/lib')
    _action_module.run(task_vars={})

# Generated at 2022-06-21 02:31:10.619548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('test')

# Generated at 2022-06-21 02:31:11.420169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:33:29.270265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Tests run method of class ActionModule."""
    module_name = 'include_vars'
    task_name = 'include_vars'
    task_vars = {}

    # Initialize module with valid parameters
    module = ActionModule(task=dict(name=task_name, args={}),
                            connection=None,
                            runner_queue=None,
                            loader=None,
                            templar=None,
                            shared_loader_obj=None)

    # Execute test case
    result = module.run(task_vars=task_vars)
    assert result['failed'] == True
    assert result['message'] == 'expected a source path but no source provided'

    # Initialize module with valid parameters

# Generated at 2022-06-21 02:33:40.209435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import tempfile
    import shutil

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    temp_dir = tempfile.mkdtemp()
    temp_file = tempfile.mkstemp()


# Generated at 2022-06-21 02:33:51.494937
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:34:02.402293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

    source = './test/unit/modules/include_vars/files'

    # Since the action plugin loads based on class name, we need to construct
    # the class name within this module otherwise the test will attempt

# Generated at 2022-06-21 02:34:03.210340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return True

# Generated at 2022-06-21 02:34:10.236816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-nested-blocks

    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from units.mock.loader import DictDataLoader

    from units.compat import unittest
    from units.compat.mock import MagicMock, patch

    class ActionModuleRunTest(unittest.TestCase):

        def setUp(self):

            self.loader = DictDataLoader({})

# Generated at 2022-06-21 02:34:15.083195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock

    class TestActionModule(ActionModule):
        def __init__(self):
            self.action = TestActionModule.__name__
            self.action_args = dict()
            self.action_args['name'] = 'test'
            self.action_args['dir'] = '/test'
            self.action_args['depth'] = 0
            self.action_args['files_matching'] = '*.test'
            self.action_args['ignore_files'] = 'test1.test'
            self.action_args['ignore_unknown_extensions'] = False
            self.action_args['hash_behaviour'] = 'merge'
            self.depth = 0
            self.files_matching = self.action_args['files_matching']

# Generated at 2022-06-21 02:34:26.976676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call constructor to generate ActionModule object
    #       ActionModule(self, task, connection, play_context, loader, templar, shared_loader_obj)
    #       shared_loader_obj: The shared object has been created by calling task_loader.py, load_tasks()
    print("test_ActionModule()")
    module_path = os.path.dirname(os.path.abspath(__file__)) + "/../../action_plugins/include_vars.py"
    module_spec = importlib.util.spec_from_file_location("include_vars", module_path)
    module = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(module) # Load module from file

# Generated at 2022-06-21 02:34:37.489498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
        Check that the fields of the class instantiated by constructor are properly initialised.
        No specific tested values, just that field exist and are not None
    """
    target = ActionModule()
    assert isinstance(target.VALID_FILE_EXTENSIONS, list)
    assert isinstance(target.VALID_DIR_ARGUMENTS, list)
    assert isinstance(target.VALID_FILE_ARGUMENTS, list)
    assert isinstance(target.VALID_ALL, list)
    assert target.show_content is True
    assert target.included_files is not None
    assert target.hash_behaviour is None
    assert target.return_results_as_name is None
    assert target.source_dir is None
    assert target.source_file is None

# Generated at 2022-06-21 02:34:38.325019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True