

# Generated at 2022-06-21 02:27:04.865801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert action_module.VALID_ALL == ['name', 'hash_behaviour']
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.TRANSFERS_FILES is False



# Generated at 2022-06-21 02:27:16.523952
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test a successful run with non-role
    module = ActionModule()

    task = object()
    setattr(module, '_task', task)

    role = object()
    setattr(task, '_role', role)

    ds = object()
    setattr(task, '_ds', ds)

    data_source = '/'
    setattr(ds, '_data_source', data_source)

    args = dict()
    args['file'] = '2013/tmp.yml'
    setattr(task, 'args', args)

    tmp = None
    task_vars = None

    results = module.run(tmp, task_vars)
    assert results['ansible_facts']['hash_behaviour'] == 'replace'
    assert results['ansible_facts']['use_default']

# Generated at 2022-06-21 02:27:23.628159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import BytesIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    class Task(object):
        def __init__(self):
            self.args = dict()
            self._role = None

        @property
        def _ds(self):
            return self._role

    class Role(object):
        def __init__(self, role_path):
            self._role_path = role_path

    class DataSource(object):
        def __init__(self, data_source):
            self._data_source = data_source

    var_mgr = VariableManager()
    var_mgr.set_inventory(Inventory(loader=DataLoader()))
    var_mgr

# Generated at 2022-06-21 02:27:25.731582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call the constructor of class ActionModule
    action_module = ActionModule(None, None)
    assert action_module


# Generated at 2022-06-21 02:27:30.563614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for ActionModule class """
    fake_loader = object()
    fake_ds = object()
    fake_task_ds = object()
    my_action_module = ActionModule(fake_loader, fake_ds, fake_task_ds)

    assert isinstance(my_action_module, ActionBase)

# Generated at 2022-06-21 02:27:39.656068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test with both 'dir' and '_raw_params' parameter
    # Success case
    mod = ActionModule()
    mod.VALID_FILE_EXTENSIONS = ['yml']
    mod._task.args = {'dir': 'vars', 'extensions': 'yml'}
    mod._task._role = type('', (object,), {'_role_path': '/tmp'})
    mod._set_dir_defaults()
    mod._set_root_dir()
    mod.depth = 1
    mod._loader = type('', (object,), {'load': lambda self, d, f, show: {'a': 1}, '_get_file_contents': lambda self, f: ('', True)})()
    mod.show_content = True

# Generated at 2022-06-21 02:27:44.774836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert a.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert a.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert a.VALID_ALL == ['name', 'hash_behaviour']

test_ActionModule()

# Generated at 2022-06-21 02:27:51.406590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_obj = ActionModule()

    # Check the default value, _set_dir_defaults is not called when source_file is set
    assert test_obj.depth == 0
    assert test_obj.ignore_files == None
    assert test_obj.matcher == None

    test_obj.source_file = "test_data/test_case_1.yml"
    test_obj.run()

    # Check the default value, _set_dir_defaults is not called when source_file is set
    assert test_obj.depth == 0
    assert test_obj.ignore_files == None
    assert test_obj.matcher == None


# Generated at 2022-06-21 02:27:52.809067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:28:02.374126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def test_for_valid_yml_file(a, b, c):
        files = open(b, 'r').readlines()
        for file in files:
            if file[0] != ' ':
                assert a.run(task_vars = dict(), tmp = '.', file = file)

    def test_for_valid_extension_file(a, b, c):
        files = open(b, 'r').readlines()
        for file in files:
            if file[0] != ' ':
                assert a.run(task_vars = dict(), tmp = '.', file = file)
                file = file.rstrip('\n')
                assert a.run(task_vars = dict(), tmp = '.', file = file)


# Generated at 2022-06-21 02:28:27.631296
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:28:37.380564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock obj
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task._role = Mock()
    action_module._task._role._role_path = ''
    action_module._task._ds = Mock()
    action_module._task._ds._data_source = ''
    action_module._task.args = Mock()
    action_module._task.args.get = Mock()
    action_module._loader = Mock()
    action_module._loader._get_file_contents = Mock()
    action_module._loader.load = Mock()

    # mock method load of obj _loader
    def load(data, file_name, show_content):
        return file_name

    action_module._loader.load = load

    # mock method _get_file_contents of obj _

# Generated at 2022-06-21 02:28:37.988485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:28:48.458772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_ActionModule_run:
    #  - dir
    #  - depth
    #  - files_matching
    #  - ignore_files
    #  - extensions
    #  - ignore_unknown_extensions
    # ===========
    #  - file
    #  - hash_behaviour
    #  - name
    #  - _raw_params
    #  - no dir, no file
    #  - dir, file
    #  - dir, _raw_params
    #  - file, _raw_params
    #  - dir, _raw_params, file
    #  - file, _raw_params, dir

    print('Testing class ActionModule: method run.')
    print('')

    # test_ActionModule_run:
    #  - dir
    #  - depth


# Generated at 2022-06-21 02:29:01.813781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MyTask:
        def __init__(self, args):
            self.args = args

    class MyRole:
        def __init__(self, role_path):
            self._role_path = role_path

    class MyDataSource:
        def __init__(self, data_source):
            self._data_source = data_source

    class MyLoader:
        def __init__(self, data, file_name, show_content):
            self.data = data
            self.file_name = file_name
            self.show_content = show_content

        def load(self, data, file_name, show_content):
            return data

    # case: _is_valid_file_ext, (test_file, valid_extensions)
    case = {}

# Generated at 2022-06-21 02:29:10.290693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def __init__(self, _task, connection, play_context, debug_msg):
            self._task = _task
            self._connection = connection
            self._play_context = play_context
            self._debug_msg = debug_msg
            self._loader = None

    class MockTask:
        class _role:
            _role_path = '..'

        _ds = False

        def __init__(self, _role, _ds, args):
            self._role = _role
            self._ds = _ds
            self.args = args

    class MockDS:
        _data_source = '..'

        def __init__(self, _data_source):
            self._data_source = _data_source


# Generated at 2022-06-21 02:29:13.522938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert ActionModule is not None
    except AssertionError as e:
        print(e)
        print("could not construct ActionModule")
        exit(1)
    else:
        print("pass: construct ActionModule")


# Generated at 2022-06-21 02:29:25.682938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def _equal(args, params, sources, results, role_path=None, task_ds='/library/main.yml', expected_result=None, expected_err=None, expected_ds=None, task_loader=None, task_vars=None, task_tmp=None):
        result = dict()
        err_msg = None
        ds = None

        # create class instance
        #   ActionModule instance
        action_module = ActionModule(dict(), dict())

        # set attributes and instance variables
        #   task
        action_module._task = _ActionModuleTask(args, role_path, task_loader)
        #   task_vars
        if task_vars is None:
            task_vars = dict()
        #   tmp
        if task_tmp is None:
            task_tmp = dict()



# Generated at 2022-06-21 02:29:27.677912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit tests for the constructor of class ActionModule. """

    # Happy path
    am = ActionModule(None, None, None, None)

    # No parameters
    am1 = ActionModule()

# Generated at 2022-06-21 02:29:32.597715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError
    from ansible.playbook.task import Task
    from ansible.template import Templar

    task_args = dict(
        file='filename.yml',
        name='datastore',
    )

    hostvars = dict(
        ansible_connection='local',
        ansible_host='127.0.0.1',
        ansible_user='root',
        ansible_password='password'
    )


# Generated at 2022-06-21 02:30:25.192292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert hasattr(ActionModule, 'TRANSFERS_FILES')
    assert isinstance(ActionModule.VALID_FILE_EXTENSIONS, list)
    assert hasattr(ActionModule, 'VALID_DIR_ARGUMENTS')
    assert hasattr(ActionModule, 'VALID_FILE_ARGUMENTS')
    assert hasattr(ActionModule, 'VALID_ALL')
    assert hasattr(ActionModule, 'run')
    assert hasattr(ActionModule, '_set_dir_defaults')


# Generated at 2022-06-21 02:30:26.482735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    This is a functional test for the method ActionModule.run.
    '''
    pass

# Generated at 2022-06-21 02:30:27.034392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:30:34.348016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(ActionBase())

    action_module._set_args = lambda self: None
    action_module._set_dir_defaults = lambda self: None
    action_module._set_root_dir = lambda self: None
    action_module._traverse_dir_depth = lambda self: lambda: (['dir1', 'dir2'], ['dir1/var1.yml', 'dir2/var2.yml'])
    action_module._ignore_file = lambda self, filename: False
    action_module._is_valid_file_ext = lambda self, filename: True
    action_module._load_files_in_dir = lambda self, dir, var_files: (False, '', {'test': 'data'})
    action_module._find_needle = lambda self, needle, haystack: hay

# Generated at 2022-06-21 02:30:35.257925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:30:44.374628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for class ActionModule
    # returns dictionary

    module = ActionModule
    test_name = 'local_data.yml'
    test_dir = 'vars'
    test_file = 'local_data.yml'
    test_raw_params = 'local_data'
    test_hash_behavior_default = C.DEFAULT_HASH_BEHAVIOUR
    test_return_results_as_name = 'local_data'
    # create an object of class ActionModule
    test_action = module()
    test_module_name = 'include_vars'
    # create a task object
    test_task = ansible.playbook.task_include.TaskInclude('loop', test_name, test_action)
    # initialize the attributes of the task object

# Generated at 2022-06-21 02:30:51.692675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #1 Path
    path_to_run = '/usr/lib/python2.7/site-packages/ansible/plugins/action/include_vars.py'
    #2 Init class
    instance_class = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    #3 Run function
    out_result = instance_class.run()
    #4 Test result
    assert out_result is None, 'Failed to test run function of class ActionModule'


# Generated at 2022-06-21 02:30:56.633016
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_object = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    return test_object


# Generated at 2022-06-21 02:31:00.150097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # check type of object
    assert isinstance(action_module, ActionModule)




# Generated at 2022-06-21 02:31:12.338873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.cli
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.play

    pb_vars = {}
    loader = ansible.cli.CLI.setup_loader()
    inv = Inventory(loader=loader, variable_manager=ansible.inventory.manager.VariableManager(), host_list=[])

# Generated at 2022-06-21 02:33:13.018235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-21 02:33:20.228573
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test for ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    task = None
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None
    actionModObj = module_include_vars.ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # test for run(tmp=None, task_vars=None)
    tmp = None
    task_vars = None
    assert isinstance(actionModObj.run(tmp, task_vars), dict)

    # # test for exceptions
    # print("Testing for exceptions")
    #
    # # test for AnsibleError
    # print("Testing for AnsibleError")



# Generated at 2022-06-21 02:33:30.244554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    td = {}
    am = ActionModule(td, td)
    # print(am.return_results_as_name)
    # print(am.source_dir)
    # print(am.source_file)
    # print(am.depth)
    # print(am.files_matching)
    # print(am.ignore_unknown_extensions)
    # print(am.ignore_files)
    # print(am.valid_extensions)
    # print(am._set_dir_defaults())
    # print(am._set_root_dir())
    # print(am._traverse_dir_depth())
    # print(am._ignore_file('file_to_ignore'))
    # print(am._is_valid_file_ext('.yml'))
    # print(am._load_files

# Generated at 2022-06-21 02:33:40.603259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    [ansible@control01 playbooks]$ cat inventory 
    [local_hosts]
    127.0.0.1
    '''
    _task_ds = """
        - name: Dump variables
          vars:
            app_groups:
              - alans
              - alexan
              - regis
          hosts: local_hosts
          gather_facts: False
          connection: local
          tasks:
            - include_vars:
                dir: test_vars_1/
                ignore_unknown_extensions: True
                extensions:
                  - yml
                  - yaml
          """
    _task = _task_ds
    _task_vars = {
    }
    _loader = None
    _variable_manager = None
    _task_args = {
    }


# Generated at 2022-06-21 02:33:43.497751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule({'name': 'test_name', 'ignore_files': '.pyc', 'extensions': '.py'})

#test_ActionModule()

# Generated at 2022-06-21 02:33:55.634849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import var_cache_loader


# Generated at 2022-06-21 02:33:56.460986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:33:57.977389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_obj = ActionModule()

# Generated at 2022-06-21 02:34:05.516811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run() == {'ansible_facts': {}, 'ansible_included_var_files': [], '_ansible_no_log': True, 'failed': False}
    assert module.run(task_vars={'foo': 'bar'}) == {'ansible_facts': {}, 'ansible_included_var_files': [], '_ansible_no_log': True, 'failed': False}

# Generated at 2022-06-21 02:34:10.962014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    print('ActionModule object created')

# when called using `-m` option
if __name__ == '__main__':
    test_ActionModule()