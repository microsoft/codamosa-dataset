

# Generated at 2022-06-21 02:27:00.158549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_list import HandlerTaskList
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    import json

    def _create_task(name):
        return Task.load(dict(
            name=name,
            include_vars=dict(
                file='test.yml',
            )
        ))


# Generated at 2022-06-21 02:27:08.079092
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:27:15.358285
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test to initialize a ActionModule, test that it is an instance of the ActionModule
    # and that it is an instance of the ActionBase
    action_module_test = ActionModule(
        task = dict(),
        connection = dict(),
        play_context = dict(),
        loader = dict(),
        shared_loader_obj = dict(),
        templar = dict())
    assert isinstance(action_module_test, ActionModule)
    assert isinstance(action_module_test, ActionBase)



# Generated at 2022-06-21 02:27:18.929024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    tmp = None
    action_module = ActionModule(None, task_vars=task_vars, tmp=tmp)
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-21 02:27:19.741009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 02:27:20.896744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-21 02:27:22.124572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Return the ActionModule object
    :return: obj
    """
    obj = ActionModule()
    return obj

# Generated at 2022-06-21 02:27:31.658491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create and initialize ActionModule object
    obj = ActionModule()

    # Create and initialize sample task
    from ansible.task import Task
    task = Task()

    # Create and initialize sample play context
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext(play=None, options=None, variable_manager=None, loader=None)

    # Run method run of class ActionModule
    return obj.run(task_vars=None, task=task, play_context=play_context)

# Generated at 2022-06-21 02:27:40.365123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    # Create mock openssl_dhparam_facts.ActionModule object
    action_module = openssl_dhparam_facts.ActionModule(None, None, None, None, None, None, None)
    # Create mock openssl_dhparam_facts.ActionBase object to set as super.run return value
    action_base = openssl_dhparam_facts.ActionBase(None, None, None, None, None, None, None)
    action_base.run = MagicMock(return_value='action_base_run_return_value')
    action_module.__class__.run = MagicMock(return_value=action_base.run)
    # Patch _set_args method of ActionModule
    patch_set_args = patch.object(action_module, '_set_args')
    patch_set_args

# Generated at 2022-06-21 02:27:43.312236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    assert "ActionModule" in str(t)

# Generated at 2022-06-21 02:28:08.303063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add unit test for method run of class ActionModule
    pass


# Generated at 2022-06-21 02:28:09.163724
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:28:19.466581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ACTION = {
        'name': 'Vars',
        'module': 'include_vars',
        'args': {
            'include_tasks': 'tasks/main.yml',
            'file': 'conf/custom.yml',
            '_raw_params': 'conf/custom.yml',
            'name': 'my_vars',
            'hash_behaviour': 'replace',
            'dir': 'conf/custom',
            'depth': 0,
            'files_matching': '.*.custom.*',
            'ignore_files': '.custom.ignore',
            'extensions': ['yaml', 'yml', 'json'],
            'ignore_unknown_extensions': False
        }
    }
    LOADER = 'ansible.parsing.dataloader.DataLoader'


# Generated at 2022-06-21 02:28:28.236117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockTask(object):
        def __init__(self):
            self.args = dict()
            self.play = dict()
            self.play.setdefault('vars', dict())

    class MockFile(object):
        def __init__(self):
            self.name = 'test_action_module'
            self.filename = 'fakefile_test'
            self.contents = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
            self.vars_files = list()
            self.show_content = True

    class MockFileLoader(object):
        def __init__(self):
            self.files = dict()

        def get_basedir(self, name):
            return 'basedir_test'


# Generated at 2022-06-21 02:28:34.129703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    datadir = os.getcwd()
    loader = DataLoader(path_prefix=datadir)
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory('{}/../../tests/inventory'))

    task = Task()
    task.action = 'include_vars'
    task.args = {'file': '../../tests/data/facts.json'}

    am = ActionModule(loader=loader, task=task, variable_manager=variable_manager)
    assert(am)



# Generated at 2022-06-21 02:28:36.020865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:28:47.566368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.loader as loader
    import ansible.plugins.action as action
    import ansible.utils.vars as vars
    import ansible.errors as errors
    import ansible.module_utils._text as text
    import ansible.module_utils.basic as basic
    import ansible.utils as utils
    from ansible.module_utils.six import string_types
    import os
    import pytest

    ActionModule = action.ActionModule
    AnsibleError = errors.AnsibleError
    combine_vars = vars.combine_vars
    to_text = text.to_text
    to_native = basic.to_native
    path = utils.path
    os = utils.os


# Generated at 2022-06-21 02:28:53.660209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule.
    '''
    class testActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            pass

    test_ActionModule = testActionModule(loader=None, task=None, connection=None, play_context=None, loader_args=None, templar=None, shared_loader_obj = None)

    # TODO
    assert True



# Generated at 2022-06-21 02:28:55.467964
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    task_vars = dict()
    # Action
    result = ActionModule().run(task_vars=task_vars)
    # Assertions
    assert result['failed'] == True
    assert result['message'] is not None


# Generated at 2022-06-21 02:28:55.850740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:29:44.498951
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    if six.PY2:
        test_loader = AnsibleLoader()
    else:
        test_loader = DataLoader()
    test_action_mod = ActionModule(loader=test_loader)
    test_action_mod.run(task_vars={})

# Generated at 2022-06-21 02:29:52.976664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_obj = ActionModule()
    action_obj.source_dir = "./"
    action_obj.depth = 0
    action_obj.files_matching = ".yml"
    action_obj.ignore_files = ""
    action_obj.valid_extensions = ["yml", "yaml", "json"]
    action_obj.ignore_unknown_extensions = False
    action_obj.return_results_as_name = None
    action_obj.show_content = True
    action_obj.hash_behaviour = None
    assert isinstance(action_obj.run(tmp = None, task_vars = None), dict)


# Generated at 2022-06-21 02:29:57.481522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = None
    task_vars = None

    result = action_module.run(tmp, task_vars)

    return


# Generated at 2022-06-21 02:30:04.210919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create mocks
    mock_play_context = {
        '_hostname': 'testhostname',
        '_ip_addresses': ['testipaddress'],
        '_remote_addr': 'testremoteaddr',
        '_port': 'testport',
        '_remote_user': 'testremoteuser',
        '_password': 'testpassword',
        '_connection_user': 'testconnectionuser',
        '_become': False,
        '_become_method': 'testbecomemethod',
        '_become_user': 'testbecomeuser',
        '_network_os': 'testnetworkos',
        '_shell': 'testshell',
        '_timeout': 'testtimeout',
    }


# Generated at 2022-06-21 02:30:08.015713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule('ansible.plugins.action.include_vars.include_vars', '/tmp/test.tmp', dict())
    return module


# Generated at 2022-06-21 02:30:15.166654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Adding a method to make the test work with Ansible 2.9
    # without changing the source code
    class Loader:
        def __init__(self):
            pass
        def _get_file_contents(self, filename):
            return 'test_content'
        def load(self, filename, file_name, show_content):
            return filename
        
    # Setting up variables to mock the test

# Generated at 2022-06-21 02:30:23.563476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionBase)
    assert action_module.name == 'include_vars'
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-21 02:30:31.391032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj1 = ActionModule()
    assert hasattr(obj1, 'run') is True
    assert hasattr(obj1, 'show_content') is True
    assert obj1.show_content is True
    assert hasattr(obj1, 'included_files') is True
    assert hasattr(obj1, '_set_args') is True
    assert hasattr(obj1, '_traverse_dir_depth') is True
    assert hasattr(obj1, '_load_files') is True
    assert hasattr(obj1, '_load_files_in_dir') is True
    assert hasattr(obj1, '_is_valid_file_ext') is True
    assert hasattr(obj1, '_ignore_file') is True
    assert hasattr(obj1, '_set_dir_defaults') is True


# Generated at 2022-06-21 02:30:43.207909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    c = ActionModule({'dir': '/test_dir', 'depth': 5}, 'test_task')
    
    if c.source_dir != "/test_dir":
        raise Exception("source_dir not set correctly")
    if c.depth != 5:
        raise Exception("depth not set correctly")
    
    c = ActionModule({'file': "test_file.txt"}, 'test_task')
    if c.source_file != "test_file.txt":
        raise Exception("source_file not set correctly")
    
    c = ActionModule({'_raw_params': "test_file.txt"}, 'test_task')
    if c.source_file != "test_file.txt":
        raise Exception("source_file not set correctly")


# Generated at 2022-06-21 02:30:47.469326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(ActionBase)
    assert len(actionModule.VALID_FILE_EXTENSIONS) == 3
    assert len(actionModule.VALID_DIR_ARGUMENTS) == 6
    assert actionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']

# Generated at 2022-06-21 02:32:51.473632
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert(action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'])
    assert(action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'])
    assert(action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params'])
    assert(action_module.VALID_ALL == ['name', 'hash_behaviour'])

# Generated at 2022-06-21 02:33:00.456491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'], "ActionModule.VALID_FILE_EXTENSIONS is incorrect"
    assert actionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'], "ActionModule.VALID_DIR_ARGUMENTS is incorrect"
    assert actionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params'], "ActionModule.VALID_FILE_ARGUMENTS is incorrect"
    assert actionModule.VALID_ALL == ['name', 'hash_behaviour'], "ActionModule.VALID_ALL is incorrect"

# Generated at 2022-06-21 02:33:09.562885
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # init class
    test_obj = ActionModule()
    # init instance variable
    test_obj.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
    test_obj.VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    test_obj.VALID_FILE_ARGUMENTS = ['file', '_raw_params']
    test_obj.VALID_ALL = ['name', 'hash_behaviour']
    # call method
    test_obj._set_args()
    # Assert error message
    assert test_obj.valid_extensions == ['yaml', 'yml', 'json']

# Generated at 2022-06-21 02:33:10.774978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action._set_args()

# Generated at 2022-06-21 02:33:19.470194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=unused-variable
    # Test creating an instance of ActionModule with no arguments
    am = ActionModule()
    # Check if the value of VALID_DIR_ARGUMENTS is correct
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    # Check if the value of VALID_FILE_ARGUMENTS is correct
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    # Check if the value of VALID_ALL is correct
    assert am.VALID_ALL == ['name', 'hash_behaviour']
    # Check if the value of VALID_FILE_EXTENSIONS is correct
    assert am.VALID_FILE_

# Generated at 2022-06-21 02:33:29.971676
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def create_module_instance(name='include_vars', source_dir='vars', depth=0):
        from ansible.playbook.play_context import PlayContext
        from ansible.playbook.task import Task
        from ansible.playbook.task_include import TaskInclude
        from ansible.template import Templar

        play_context = PlayContext()
        templar = Templar(loader=None, variables=dict() )

        return ActionModule(
            play_context=play_context,
            task=TaskInclude(
                action=name,
                task=Task(),
                terms=[source_dir, depth],
                ignore_errors=False
            ),
            loader=None,
            templar=templar,
            shared_loader_obj=None
        )


# Generated at 2022-06-21 02:33:40.492649
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = {}
    source_dir = {}
    source_file = {}
    show_content = True
    included_files = []
    return_results_as_name = {}
    depth = {}
    files_matching = {}
    ignore_unknown_extensions = {}
    ignore_files = []
    valid_extensions = []
    task_vars = {}
    tmp = None
    instance = action_module.ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    return instance

## Unit test for method load_files_in_dir
#def test_set_dir_defaults():
#    root_dir = ''
#    var_files = ''
#    instance = action_module.ActionModule(task, connection, play_context, loader, templar

# Generated at 2022-06-21 02:33:48.186163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule_obj = ActionModule()
    actionModule_obj.included_files = ['file1.yml']
    actionModule_obj.source_dir = '/tmp'

    actionModule_obj._set_root_dir()
    actionModule_obj.source_dir = 'tests/unit/modules/action/vars/test_dir'

    actionModule_obj._set_dir_defaults()
    actionModule_obj.depth = 0

    results = dict()
    for root_dir, var_files in actionModule_obj._traverse_dir_depth():
        failed, err_msg, updated_results = actionModule_obj._load_files_in_dir(root_dir, var_files)
        if failed:
            break
        results.update(updated_results)


# Generated at 2022-06-21 02:33:48.801998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:33:56.967297
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    """
    from ansible.plugins.loader import action_loader

    task_ds = mock.MagicMock()
    task_ds._data_source = "./test/test_data_source"
    task_mock = mock.MagicMock()
    task_mock._ds = task_ds

    loader_mock = mock.MagicMock()
    inventory_mock = mock.MagicMock()
    variable_manager_mock = mock.MagicMock()
    play_context_mock = mock.MagicMock()

    # constructor with args