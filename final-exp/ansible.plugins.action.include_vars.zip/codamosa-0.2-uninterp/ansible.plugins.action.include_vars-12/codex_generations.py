

# Generated at 2022-06-17 09:10:01.003241
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:10:10.736304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a mock task
    task = MockTask()
    # create a mock loader
    loader = MockLoader()
    # create a mock play
    play = MockPlay()
    # create a mock play context
    play_context = MockPlayContext()
    # create a mock role
    role = MockRole()
    # create a mock role context
    role_context = MockRoleContext()
    # create a mock task_ds
    task_ds = MockTaskDS()
    # create a mock task_ds
    task_ds_role = MockTaskDSRole()
    # create a mock task_ds
    task_ds_role_vars = MockTaskDSRoleVars()
    # create a mock task_ds
    task_ds_role_vars_main = MockTaskDSRoleVarsMain()
    # create a mock task_ds


# Generated at 2022-06-17 09:10:12.730658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement
    pass


# Generated at 2022-06-17 09:10:18.787470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.include_vars import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.errors import AnsibleError

# Generated at 2022-06-17 09:10:20.697706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:10:31.013512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:10:34.818401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 09:10:38.525363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:10:48.734081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import is_complex_variable
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash_duplicate_key
    from ansible.utils.vars import merge_hash_overwrite
    from ansible.utils.vars import merge_hash_overwrite_du

# Generated at 2022-06-17 09:10:51.541048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 09:11:17.816349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:11:30.724656
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:11:41.861189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text

# Generated at 2022-06-17 09:11:43.007567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:11:53.323947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock action module
    action_module = ActionModule(task, loader, play_context)
    # Create a mock task vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock source dir
    source_dir = MockSourceDir()
    # Create a mock source file
    source_file = MockSourceFile()
    # Create a mock hash behaviour
    hash_behaviour = MockHashBehaviour()
    # Create a mock return results as name
    return_results_as_name = MockReturnResultsAsName()
    # Create a mock depth
    depth = Mock

# Generated at 2022-06-17 09:11:59.351890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of class ActionModule
    action_module = ActionModule()

    # Create a mock object of class Task
    task = Task()

    # Create a mock object of class Role
    role = Role()

    # Create a mock object of class DataSource
    data_source = DataSource()

    # Create a mock object of class TaskExecutor
    task_executor = TaskExecutor()

    # Create a mock object of class TaskResult
    task_result = TaskResult()

    # Create a mock object of class TaskExecutor
    task_executor = TaskExecutor()

    # Create a mock object of class PlayContext
    play_context = PlayContext()

    # Create a mock object of class Play
    play = Play()

    # Create a mock object of class Playbook
    playbook = Playbook()

    # Create a mock object of

# Generated at 2022-06-17 09:12:10.454282
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:12:15.826433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:12:17.446712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:12:23.531749
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:13:20.188437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Set the instance variable VALID_FILE_EXTENSIONS
    action_module.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
    # Set the instance variable VALID_DIR_ARGUMENTS
    action_module.VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    # Set the instance variable VALID_FILE_ARGUMENTS
    action_module.VALID_FILE_ARGUMENTS = ['file', '_raw_params']
    # Set the instance

# Generated at 2022-06-17 09:13:28.210279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of ActionModule
    action_module = ActionModule()

    # create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # create an instance of AnsibleTaskResult
    ansible_task_result = AnsibleTaskResult()

    # set the attributes of ansible_task
    ansible_task._role = None
    ansible_task._ds = None
    ansible_task.args = {'dir': 'vars', 'depth': 0, 'files_matching': None, 'ignore_files': None, 'extensions': ['yaml', 'yml', 'json'], 'ignore_unknown_extensions': False}

    # set the attributes of ansible_task_result
    ansible_task_result.ansible_facts = {}
    ansible_task_result._ansible_no_

# Generated at 2022-06-17 09:13:28.751076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:13:37.323470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:13:38.987132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:13:39.618774
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:13:47.248174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text

# Generated at 2022-06-17 09:13:49.181581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:13:50.554048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 09:13:56.683685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:15:53.867046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:16:00.816196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock role
    role = MockRole()
    # Create a mock data source
    data_source = MockDataSource()
    # Create a mock task ds
    task_ds = MockTaskDS()
    # Create a mock task args
    task_args = MockTaskArgs()
    # Create a mock task args
    task_args2 = MockTaskArgs2()
    # Create a mock task args
    task_args3 = MockTaskArgs3()
    # Create a mock task args
    task_args4 = MockTaskArgs4()
    # Create a mock task args
    task_args5 = MockTaskArgs5()
    # Create a

# Generated at 2022-06-17 09:16:02.658120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:16:03.775115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:16:09.298377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 09:16:16.542196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:16:19.658831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass


# Generated at 2022-06-17 09:16:21.974709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict())

# Generated at 2022-06-17 09:16:23.961419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:16:31.586042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule.VALID_ALL == ['name', 'hash_behaviour']
