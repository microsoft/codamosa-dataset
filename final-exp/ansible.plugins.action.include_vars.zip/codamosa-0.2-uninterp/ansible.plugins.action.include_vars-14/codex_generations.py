

# Generated at 2022-06-17 09:10:00.844228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Test with dir

# Generated at 2022-06-17 09:10:07.863863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:10:11.722265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:10:20.378344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:10:33.670556
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:10:42.227556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:10:43.191415
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:10:46.064323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:10:46.874864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:10:47.960291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_ActionModule_run()
    # TODO: implement this test
    pass

# Generated at 2022-06-17 09:11:15.906306
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:11:26.285579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars


# Generated at 2022-06-17 09:11:35.760733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for method run of class ActionModule
    # Setup
    action_module = ActionModule()
    action_module._task = MockTask()
    action_module._task.args = {'file': 'test_file'}
    action_module._task._role = MockRole()
    action_module._task._role._role_path = 'test_role_path'
    action_module._task._ds = MockDataSource()
    action_module._task._ds._data_source = 'test_data_source'
    action_module._loader = MockLoader()
    action_module._loader.load = Mock(return_value=True)
    action_module._loader._get_file_contents = Mock(return_value=True)
    action_module._find_needle = Mock(return_value=True)
    action_module

# Generated at 2022-06-17 09:11:44.749101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:11:45.717925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-17 09:11:54.289414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test for dir
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['test_var'] = 'test_value'
    task_vars['ansible_facts']['test_var2'] = 'test_value2'
    task_vars['ansible_facts']['test_var3'] = 'test_value3'
    task_vars['ansible_facts']['test_var4'] = 'test_value4'
    task_vars['ansible_facts']['test_var5'] = 'test_value5'
    task_vars['ansible_facts']['test_var6'] = 'test_value6'

# Generated at 2022-06-17 09:11:55.088841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:11:55.921374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-17 09:11:58.550397
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:11:59.386662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:12:44.631832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:12:49.944277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 09:12:50.869530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:12:59.258195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:13:03.920215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for constructor
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 09:13:04.548360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:13:14.469296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:13:15.436939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:13:23.493083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:13:35.966498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play
    play = MockPlay()
    # Create a mock role
    role = MockRole()
    # Create a mock task_ds
    task_ds = MockTaskDS()
    # Create a mock action
    action = MockAction()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule
    action_module = ActionModule(task, loader, play, role, task_ds, action, task_vars, result)

    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock source_dir
    source_dir = MockSourceDir()
   

# Generated at 2022-06-17 09:15:17.457623
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:15:20.755605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test_name', 'test_path')

# Generated at 2022-06-17 09:15:22.789733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    """
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 09:15:24.236041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:15:31.553054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:15:40.802250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = dict()
    task.args['file'] = 'test.yml'
    task.args['name'] = 'test'
    task.args['hash_behaviour'] = 'merge'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock action module
    action_module = ActionModule(task, loader)

    # Create a mock task vars
    task_vars = dict()
    task_vars['test'] = dict()
    task_vars['test']['test1'] = 'test1'
    task_vars['test']['test2'] = 'test2'

    # Run the method
    result = action_module.run(task_vars=task_vars)

    # Assert the

# Generated at 2022-06-17 09:15:50.644720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:15:51.687099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:16:05.713182
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:16:15.531308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.utils.vars import combine_vars
