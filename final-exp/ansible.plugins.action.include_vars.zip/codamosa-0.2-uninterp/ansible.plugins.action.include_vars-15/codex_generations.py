

# Generated at 2022-06-17 09:10:01.410182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:10:07.657099
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:10:12.260309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:10:20.378399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:10:22.529911
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:10:24.246935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 09:10:35.805898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:10:37.127056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:10:38.445579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:10:48.707725
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:11:21.280744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module

# Generated at 2022-06-17 09:11:31.653037
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:11:32.305609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:11:39.714084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:11:46.759795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:11:54.775938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock action module
    action_module = ActionModule(task, loader, play_context)
    # Create a mock task vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock source dir
    source_dir = MockSourceDir()
    # Create a mock source file
    source_file = MockSourceFile()
    # Create a mock depth
    depth = MockDepth()
    # Create a mock files matching
    files_matching = MockFilesMatching()
    # Create a mock ignore files
    ignore_files = MockIgnoreFiles()
    # Create a

# Generated at 2022-06-17 09:12:06.384150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                dir='/path/to/dir',
                depth=0,
                files_matching='*.yml',
                ignore_files='*.yml',
                extensions=['yml', 'yaml'],
                ignore_unknown_extensions=False,
                name='test_name',
                hash_behaviour='replace'
            )
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

# Generated at 2022-06-17 09:12:07.583797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict())

# Generated at 2022-06-17 09:12:09.867124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 09:12:10.960361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:13:01.660907
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:13:11.997458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with dir argument
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['test_fact'] = 'test_value'
    task_vars['ansible_facts']['test_fact_2'] = 'test_value_2'
    task_vars['ansible_facts']['test_fact_3'] = 'test_value_3'
    task_vars['ansible_facts']['test_fact_4'] = 'test_value_4'
    task_vars['ansible_facts']['test_fact_5'] = 'test_value_5'
    task_vars['ansible_facts']['test_fact_6'] = 'test_value_6'
    task_v

# Generated at 2022-06-17 09:13:14.220529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:13:17.493667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor of class ActionModule
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:13:33.183361
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:13:37.121727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:13:38.592878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict())

# Generated at 2022-06-17 09:13:42.728659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass


# Generated at 2022-06-17 09:13:51.392236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import zip
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash_duplicate_key
    from ansible.utils.vars import merge_hash_overwrite_duplicate_key
    from ansible.utils.vars import merge_hash_overwrite_du

# Generated at 2022-06-17 09:14:01.209417
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:15:40.935470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass


# Generated at 2022-06-17 09:15:45.931475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for method run of class ActionModule
    #
    # The following input values will be used for testing this method:
    #
    # Returns:
    #
    # This method will return the following value:
    #
    pass

# Generated at 2022-06-17 09:15:47.540906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:15:54.415065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:16:01.228389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class MockTask:
        def __init__(self, args):
            self.args = args

    class MockPlay:
        def __init__(self, role):
            self._role = role

    class MockRole:
        def __init__(self, role_path):
            self._role_path = role_path

    class MockDS:
        def __init__(self, data_source):
            self._data_source = data_source


# Generated at 2022-06-17 09:16:03.041745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:16:04.162057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict())

# Generated at 2022-06-17 09:16:14.666139
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:16:26.478176
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:16:27.735329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add unit tests for method run of class ActionModule
    pass