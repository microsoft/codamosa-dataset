

# Generated at 2022-06-17 09:09:50.568429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:10:01.854901
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:10:07.700245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.errors import AnsibleError
    import os
   

# Generated at 2022-06-17 09:10:15.756347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                dir='/tmp/',
                depth=0,
                files_matching='*.yml',
                ignore_files='*.yml',
                extensions='yml',
                ignore_unknown_extensions=False,
                name='test_name',
                hash_behaviour='replace'
            )
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

# Generated at 2022-06-17 09:10:16.852568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:10:25.719871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the class ActionModule
    mock_ActionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock object for the class AnsibleError
    mock_AnsibleError = AnsibleError(msg=None)

    # Create a mock object for the class AnsibleError
    mock_AnsibleError = AnsibleError(msg=None)

    # Create a mock object for the class AnsibleError
    mock_AnsibleError = AnsibleError(msg=None)

    # Create a mock object for the class AnsibleError
    mock_AnsibleError = AnsibleError(msg=None)

    # Create a mock object for the class AnsibleError

# Generated at 2022-06-17 09:10:32.226837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(dict(name='test', dir='/tmp', depth=1, files_matching='*.yml', ignore_files=['*.yml'], extensions=['yml']), dict(ANSIBLE_MODULE_ARGS=dict(name='test', dir='/tmp', depth=1, files_matching='*.yml', ignore_files=['*.yml'], extensions=['yml'])))
    assert action_module.return_results_as_name == 'test'
    assert action_module.source_dir == '/tmp'
    assert action_module.depth == 1
    assert action_module.files_matching == '*.yml'
    assert action_module.ignore_files == ['*.yml']
    assert action_module.valid_extensions == ['yml']

# Generated at 2022-06-17 09:10:36.624661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:10:42.541719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:10:43.765762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:11:12.392271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:11:13.289547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:11:15.495130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:11:23.110198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:11:24.365145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:11:32.262582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:11:34.495198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass


# Generated at 2022-06-17 09:11:35.431303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:11:39.446956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:11:46.244627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:12:24.583719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')


# Generated at 2022-06-17 09:12:32.180640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 1
    # Test case with invalid arguments
    # Expected result: AnsibleError
    # Actual result: AnsibleError
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['ansible_included_var_files'] = list()
    task_vars['ansible_facts']['ansible_included_var_files'].append('/tmp/test_dir/test_file.yml')
    task_vars['ansible_facts']['ansible_included_var_files'].append('/tmp/test_dir/test_file2.yml')

# Generated at 2022-06-17 09:12:41.191188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock action module
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock source_dir
    source_dir = 'test_source_dir'

    # Create a mock source_file
    source_file = 'test_source_file'

    # Create a mock depth
    depth = 0

    # Create a mock files_matching
    files_matching = None

    # Create a mock ignore_files
    ignore_files = None

    # Create a mock valid_extensions

# Generated at 2022-06-17 09:12:44.967963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict())

# Generated at 2022-06-17 09:12:56.567174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import b
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import range

# Generated at 2022-06-17 09:13:01.071204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:13:08.739663
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:13:15.928395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:13:19.750195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 09:13:21.035988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:14:05.577764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:14:06.155054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:14:21.604107
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:14:25.802927
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:14:37.889471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'file': 'test_file.yml'}
    task.args = {'dir': 'test_dir'}
    task.args = {'name': 'test_name'}
    task.args = {'hash_behaviour': 'test_hash_behaviour'}
    task.args = {'_raw_params': 'test_raw_params'}
    task.args = {'depth': 'test_depth'}
    task.args = {'files_matching': 'test_files_matching'}
    task.args = {'ignore_files': 'test_ignore_files'}
    task.args = {'ignore_unknown_extensions': 'test_ignore_unknown_extensions'}

# Generated at 2022-06-17 09:14:38.838078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:14:41.189542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:14:47.915710
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import tempfile
    import shutil
    import unittest
    import yaml
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars

    class TestActionModule(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mk

# Generated at 2022-06-17 09:14:49.270337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:14:49.846771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:16:38.022127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:16:44.657093
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:16:48.797578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this test
    pass

# Generated at 2022-06-17 09:16:49.474604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:16:59.779573
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:17:00.937366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:17:08.476772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor of class ActionModule
    # Arrange
    # Act
    action_module = ActionModule()
    # Assert
    assert action_module is not None


# Generated at 2022-06-17 09:17:09.709934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 09:17:19.120745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 1
    # Test case with dir and depth
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['ansible_local'] = dict()
    task_vars['ansible_facts']['ansible_local']['test_var'] = 'test_value'

    task_vars['ansible_facts']['ansible_local']['test_var_2'] = 'test_value_2'

    task_vars['ansible_facts']['ansible_local']['test_var_3'] = 'test_value_3'

    task_vars['ansible_facts']['ansible_local']['test_var_4'] = 'test_value_4'

    task_

# Generated at 2022-06-17 09:17:30.597843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']
