

# Generated at 2022-06-17 09:10:02.331755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock module
    module = MockModule()

    # Create a mock role
    role = MockRole()

    # Create a mock ds
    ds = MockDS()

    # Create a mock role
    role = MockRole()

    # Create a mock task
    task = MockTask()

    # Create a mock task
    task = MockTask()

    # Create a mock task
    task = MockTask()

    # Create a mock task
    task = MockTask()

    # Create a mock task
    task = MockTask()

    # Create a mock task
    task = MockTask()

    # Create a mock task
    task = MockTask()

    # Create a mock task
    task = MockTask()

   

# Generated at 2022-06-17 09:10:03.231437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:10:06.399283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:10:15.158523
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:10:15.871042
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:10:24.159601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:10:35.735379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock play context object
    play_context = MockPlayContext()
    # Create a mock role object
    role = MockRole()
    # Create a mock data source object
    data_source = MockDataSource()
    # Create a mock data source object
    data_source = MockDataSource()
    # Create a mock task object
    task = MockTask()
    # Create a mock role object
    role = MockRole()
    # Create a mock data source object
    data_source = MockDataSource()
    # Create a mock task object
    task = MockTask()
    # Create a mock role object
    role = MockRole()
    # Create a mock data source object
    data_source = MockDataSource()

# Generated at 2022-06-17 09:10:37.124134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-17 09:10:38.788096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass


# Generated at 2022-06-17 09:10:41.288324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:11:16.904294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:11:18.113202
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:11:32.041722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.plugins.action.include_vars import ActionModule

    class TestActionModule(unittest.TestCase):
        def setUp(self):
            self.am = ActionModule(
                task=dict(
                    args=dict(
                        file='/tmp/test_include_vars.yml'
                    )
                ),
                connection=None,
                play_context=None,
                loader=None,
                templar=None,
                shared_loader_obj=None
            )

        def test_run(self):
            if PY3:
                builtins_open = 'builtins.open'
           

# Generated at 2022-06-17 09:11:37.270356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:11:44.468452
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    import json
    import os


# Generated at 2022-06-17 09:11:53.877695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:11:54.669711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict())

# Generated at 2022-06-17 09:11:56.107829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Write unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:11:59.716930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:12:10.804044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock role
    role = MockRole()
    # Create a mock data source
    data_source = MockDataSource()
    # Create a mock task ds
    task_ds = MockTaskDS()
    # Create a mock task args
    task_args = MockTaskArgs()
    # Create a mock task args
    task_args_2 = MockTaskArgs2()
    # Create a mock task args
    task_args_3 = MockTaskArgs3()
    # Create a mock task args
    task_args_4 = MockTaskArgs4()
    # Create a mock task args
    task_args_5 = MockTaskArgs5()


# Generated at 2022-06-17 09:13:06.860220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:13:16.275370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import action_loader

    # Create a mock task
    task = Task()
    task._role = RoleInclude()
    task._role._role_path = '/home/user/ansible/roles/test_role'
    task._ds = {'_data_source': '/home/user/ansible/roles/test_role/tasks/main.yml'}

# Generated at 2022-06-17 09:13:19.246733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:13:33.777805
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:13:45.204008
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with dir
    task = dict(
        action=dict(
            module='include_vars',
            args=dict(
                dir='/path/to/dir',
                depth=2,
                files_matching='*.yml',
                ignore_files='*.ignore',
                extensions=['yml', 'yaml'],
                ignore_unknown_extensions=True,
                name='test_name',
                hash_behaviour='merge'
            )
        )
    )
    tmp = None
    task_vars = dict()
    result = ActionModule(task, tmp).run(task_vars=task_vars)
    assert result['ansible_included_var_files'] == []
    assert result['ansible_facts'] == {}
    assert result['_ansible_no_log']

# Generated at 2022-06-17 09:13:48.909028
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:13:50.278347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:13:54.751006
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), '/path/to/ansible/lib/ansible/modules/core/', '/path/to/ansible/lib/ansible/modules/core/', '/path/to/ansible/lib/ansible/modules/core/', '/path/to/ansible/lib/ansible/modules/core/')


# Generated at 2022-06-17 09:13:55.827332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-17 09:13:56.923735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:15:54.825941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(dict(), dict(), False, '/tmp/ansible_include_vars_payload')
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:15:55.661811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:15:58.127617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:16:10.107638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                dir='/path/to/dir',
                depth=0,
                files_matching='',
                ignore_files='',
                extensions=['yaml', 'yml', 'json'],
                ignore_unknown_extensions=False,
                name='',
                hash_behaviour=''
            )
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

# Generated at 2022-06-17 09:16:18.443772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '127.0.0.1'
    play_context.connection = 'local'
    play_context.port = 22

# Generated at 2022-06-17 09:16:31.493275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock action module
    action_module = MockActionModule(task)

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Set the loader and templar
    action_module._loader = loader
    action_module._templar = templar

    # Set the task_vars
    action_module._task_vars = task_vars

    # Set the source_dir
    action_module.source_dir = 'vars'

    # Set the depth
    action_module.depth = 0

    # Set the files_matching
    action_module.files_

# Generated at 2022-06-17 09:16:38.249714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:16:39.108365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:16:45.238206
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:16:57.729873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader

    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 10
            self.remote_user = 'root'
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
           