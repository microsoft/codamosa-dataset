

# Generated at 2022-06-17 09:09:56.393905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:10:05.909826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    # Create a mock object for the class ActionModule
    mock_ActionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock object for the class Task
    mock_Task = MagicMock()
    mock_Task.args = {'name': 'test_name', 'hash_behaviour': 'test_hash_behaviour', 'dir': 'test_dir', 'depth': 'test_depth', 'files_matching': 'test_files_matching', 'ignore_files': 'test_ignore_files', 'extensions': 'test_extensions', 'ignore_unknown_extensions': 'test_ignore_unknown_extensions'}

    # Create a mock object for the class Role
    mock_Role = MagicM

# Generated at 2022-06-17 09:10:07.670926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor
    assert ActionModule(dict(), dict(), dict())

# Generated at 2022-06-17 09:10:11.939209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Test the constructor
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:10:23.444809
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars


# Generated at 2022-06-17 09:10:35.190658
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:10:36.998503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-17 09:10:38.066931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:10:48.707223
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(dict(), dict(), False, '/path/to/ansible/lib')
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']
    assert action_module.hash_behaviour == None
    assert action_module.return_results_as_name == None
    assert action_module.source_dir == None

# Generated at 2022-06-17 09:10:55.598536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with dir argument
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['test_fact'] = 'test_fact_value'
    task_vars['ansible_facts']['test_fact_2'] = 'test_fact_value_2'
    task_vars['ansible_facts']['test_fact_3'] = 'test_fact_value_3'
    task_vars['ansible_facts']['test_fact_4'] = 'test_fact_value_4'
    task_vars['ansible_facts']['test_fact_5'] = 'test_fact_value_5'

# Generated at 2022-06-17 09:11:22.083257
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:11:23.594321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:11:33.710670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import _thread
    from ansible.module_utils.six.moves import _dummy_thread
    from ansible.module_utils.six.moves import _threading_local
    from ansible.module_utils.six.moves import queue

# Generated at 2022-06-17 09:11:43.298410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:11:53.322400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task._role = MockRole()
    task._ds = MockDS()
    task._ds._data_source = '/home/user/ansible/playbooks/test.yml'
    task._ds._data_source_path = '/home/user/ansible/playbooks/test.yml'
    task._ds._data_source_basedir = '/home/user/ansible/playbooks'
    task._ds._data_source_filename = 'test.yml'
    task._ds._data_source_fullpath = '/home/user/ansible/playbooks/test.yml'
    task._ds._data_source_run_list = ['test.yml']
    task._ds._data_source_run_list_index = 0
    task._ds._

# Generated at 2022-06-17 09:11:57.606821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:12:00.918390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:12:07.458298
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:12:09.714591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:12:10.854584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:13:01.548640
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:13:03.924296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:13:06.578507
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 09:13:07.614450
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:13:08.785477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 09:13:10.914624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:13:22.654962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    ############################################################################
    # Create a mock task
    task = MockTask()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock action module
    action_module = ActionModule(task, loader)
    # Create a mock task vars
    task_vars = dict()
    # Create a mock tmp
    tmp = None
    ############################################################################

    # Test 1:
    ############################################################################
    # Create a mock task args

# Generated at 2022-06-17 09:13:33.019721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor of class ActionModule
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:13:37.121319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:13:43.900970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:15:32.872094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:15:41.381557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(dict(), dict())
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']
    assert action_module.TRANSFERS_FILES == False
    assert action_module.show_content == True
    assert action_module.included_files == []
    assert action_module.hash_behaviour == None
    assert action_module

# Generated at 2022-06-17 09:15:53.711429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock play context object
    play_context = MockPlayContext()
    # Create a mock role object
    role = MockRole()
    # Create a mock role path object
    role_path = MockRolePath()
    # Create a mock data source object
    data_source = MockDataSource()
    # Create a mock data source object
    data_source = MockDataSource()
    # Create a mock task object
    task_ds = MockTaskDS()
    # Create a mock task object
    task_ds_ds = MockTaskDSDS()
    # Create a mock task object
    task_ds_ds_data_source = MockTaskDSDSDataSource()
    # Create a mock task object
    task_ds

# Generated at 2022-06-17 09:15:55.198747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:16:07.077702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:16:09.840301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 09:16:16.612487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:16:21.477619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test_action', 'test_task', 'test_connection', 'test_play_context', 'test_loader', 'test_templar', 'test_shared_loader_obj')

# Generated at 2022-06-17 09:16:22.553912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:16:31.423548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule.VALID_ALL == ['name', 'hash_behaviour']
