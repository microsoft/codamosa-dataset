

# Generated at 2022-06-17 09:09:57.293174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:09:58.976677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test_task', file_vars_lookup=False)

# Generated at 2022-06-17 09:10:01.574874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:10:02.683861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:10:03.908967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:10:13.201780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock role
    role = MockRole()
    # Create a mock data source
    data_source = MockDataSource()
    # Create a mock task ds
    task_ds = MockTaskDS()
    # Create a mock task args
    task_args = MockTaskArgs()
    # Create a mock task args
    task_args_2 = MockTaskArgs2()
    # Create a mock task args
    task_args_3 = MockTaskArgs3()
    # Create a mock task args
    task_args_4 = MockTaskArgs4()
    # Create a mock task args
    task_args_5 = MockTaskArgs5()


# Generated at 2022-06-17 09:10:24.120778
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:10:25.628889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:10:33.549857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock action module object
    action_module = ActionModule(task, loader, display)

    # Create a mock task_vars object
    task_vars = dict()

    # Create a mock tmp object
    tmp = None

    # Call method run of class ActionModule
    result = action_module.run(tmp, task_vars)

    # Assert the result

# Generated at 2022-06-17 09:10:37.024527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:11:05.015404
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:11:16.103663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:11:17.914433
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:11:31.939882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import tempfile
    import shutil
    import yaml
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase

# Generated at 2022-06-17 09:11:36.924533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with invalid arguments
    try:
        action_module = ActionModule(dict(), dict())
        assert False
    except AnsibleError:
        assert True

    # Test with valid arguments
    action_module = ActionModule(dict(dir='/tmp'), dict())
    assert action_module.source_dir == '/tmp'

# Generated at 2022-06-17 09:11:39.318849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:11:49.922872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:12:00.519383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-17 09:12:01.596421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-17 09:12:04.346579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module


# Generated at 2022-06-17 09:12:57.896786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import ansible.plugins.action.include_vars
    import ansible.utils.vars
    import ansible.utils.template
    import ansible.utils.unsafe_proxy
    import ansible.utils.unsafe_proxy.AnsibleUnsafeText
    import ansible.utils.unsafe_proxy.AnsibleUnsafeBytes
    import ansible.utils.unsafe_proxy.AnsibleUnsafeHost
    import ansible.utils.unsafe_proxy.AnsibleUnsafePersistentDict
    import ansible.utils.unsafe_proxy.AnsibleUnsafeDict
    import ansible.utils.unsafe_proxy.AnsibleUnsafeList
    import ansible.utils.unsafe_proxy.AnsibleUnsafeLookup
    import ansible.utils.unsafe_

# Generated at 2022-06-17 09:13:01.269070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:13:05.040204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor of class ActionModule
    # Arrange
    action_module = ActionModule()
    # Act
    # Assert
    assert action_module is not None


# Generated at 2022-06-17 09:13:16.304747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(dict(), dict())
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']
    assert action_module.hash_behaviour is None
    assert action_module.return_results_as_name is None
    assert action_module.source_dir is None
    assert action_module.source_file is None

# Generated at 2022-06-17 09:13:29.158950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    import os
    import json
    import pytest


# Generated at 2022-06-17 09:13:31.167104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:13:38.575787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with dir argument
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['test_fact'] = 'test_fact_value'
    task_vars['ansible_facts']['test_fact_2'] = 'test_fact_value_2'
    task_vars['ansible_facts']['test_fact_3'] = 'test_fact_value_3'
    task_vars['ansible_facts']['test_fact_4'] = 'test_fact_value_4'
    task_vars['ansible_facts']['test_fact_5'] = 'test_fact_value_5'

# Generated at 2022-06-17 09:13:42.366989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:13:43.973423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for method run of class ActionModule
    # Arrange
    # Act
    # Assert
    pass

# Generated at 2022-06-17 09:13:47.914271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:15:29.913043
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:15:31.149357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:15:40.529510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 09:15:53.043735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play
    play = MockPlay()

    # Create a mock role
    role = MockRole()

    # Create a mock data source
    data_source = MockDataSource()

    # Create a mock task_ds
    task_ds = MockTaskDS()

    # Create a mock role_path
    role_path = MockRolePath()

    # Create a mock role_name
    role_name = MockRoleName()

    # Create a mock role_path
    role_path = MockRolePath()

    # Create a mock role_name
    role_name = MockRoleName()

    # Create a mock role_path
    role_path = MockRolePath()

    # Create a mock role_name
    role

# Generated at 2022-06-17 09:16:00.270155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Set the loader attribute of action_module
    action_module._loader = loader

    # Set the task attribute of action_module
    action_module._task = task

    # Set the args attribute of task
    task.args = {'dir': 'test_dir', 'depth': 0, 'files_matching': '.*', 'ignore_files': '.*', 'extensions': ['yaml', 'yml', 'json'], 'ignore_unknown_extensions': False, 'name': None, 'hash_behaviour': None}

    # Call the run method of action_module
    action_module.run()

    # Assert that the method _set

# Generated at 2022-06-17 09:16:11.702302
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:16:12.323798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:16:20.057920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']
    assert action_module.TRANSFERS_FILES == False
    assert action_module.show_content == True
    assert action

# Generated at 2022-06-17 09:16:22.044997
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')

# Generated at 2022-06-17 09:16:23.472179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test')