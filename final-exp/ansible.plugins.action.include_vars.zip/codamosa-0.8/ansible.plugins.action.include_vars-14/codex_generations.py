

# Generated at 2022-06-11 11:53:09.123216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching',
                                                 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-11 11:53:10.785452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    x = ActionModule()
    # TODO: implement test
    assert True


# Generated at 2022-06-11 11:53:12.685876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # initiate obj
    obj = ActionModule()
    # check if obj is of class
    assert isinstance(obj, ActionModule)

# Generated at 2022-06-11 11:53:19.451478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.__dict__.update({'_task': {'args': {'hash_behaviour': 'merge', 'name': None, 'dir': '/some/path', 'depth': 0, 'files_matching': None, 'extensions': ['yaml', 'yml', 'json'], 'ignore_unknown_extensions': True, 'ignore_files': ['*.example', '*.sample']}}})
    action_module._set_dir_defaults()
    action_module.__dict__.update({'source_dir': '/some/path'})
    action_module._set_root_dir()
    action_module.__dict__.update({'source_dir': '/some/path'})
    action_module._traverse_dir_depth()
    action_module.__dict__

# Generated at 2022-06-11 11:53:31.924356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # When: The method run of ActionModule is called with a valid directory and a set depth
    # Then: The output is a dict with the correct entries
    import ansible.utils.vars as vars_
    from ansible.module_utils.six import PY3
    import os
    import filecmp
    import tempfile
    import shutil
    import sys
    if PY3:
        from importlib import reload
    
    # set variables/data structures for directory/file loading
    ignore_fs = []
    if sys.platform != 'win32':
        ignore_fs = ["[A-C]*", ".*"]
    files_matching = ".*py$"

    # set variables for directory/file loading with depth
    depth = 1
    ignore_files = ".*pyc$"

    # set variables for dictionary/

# Generated at 2022-06-11 11:53:43.197825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.six.moves.builtins import __builtin__
    import ansible.utils.template as template

    # class __builtin__ is replaced with a stub to generate consistent test results
    class BuiltinStub(object):
        def __getattr__(self, attr):
            return getattr(__builtin__, attr)

    class MockActionBase(ActionBase):
        def __init__(self):
            self._task = MockTask()
            self._task_vars = dict()
            self._templar = template.Templar()
            self._loader = MockFileLoader()

    class MockTask(object):
        def __init__(self):
            self._role = MockRole()
            self._ds = Mock

# Generated at 2022-06-11 11:53:47.618142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case 1
    mock_imp = Mock()
    mock_imp.ActionBase = ActionBase
    mock_imp.ActionBase.__file__ = '/ansible/plugins/action/__init__.py'
    mock_obj = MagicMock(spec=mock_imp.ActionBase)
    mock_obj._task.args = {
        'name': None,
        'dir': None,
        'file': '/tmp/test_file.yml',
        '_raw_params': '/tmp/test_file.yml',
        'extensions': None,
        'ignore_files': None,
        'files_matching': None,
        'ignore_unknown_extensions': None,
        'depth': None,
        'hash_behaviour': None
    }
    mock_obj._task._role.__dict

# Generated at 2022-06-11 11:53:50.414671
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    return action_module


# Generated at 2022-06-11 11:53:51.446433
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # ToDo:
    pass

# Generated at 2022-06-11 11:53:52.154703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:54:15.782244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:54:26.275319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.executor.task_queue_manager
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.vars.manager

    # Create an Executor
    tqm = ansible.executor.task_queue_manager.TaskQueueManager(
        inventory=None,
        variable_manager=ansible.vars.manager.VariableManager(),
        loader=None,
        options=None,
        passwords=None,
    )

    # Create a Play

# Generated at 2022-06-11 11:54:28.954297
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionModule)
    assert hasattr(module, 'show_content')
    assert module.show_content

# Generated at 2022-06-11 11:54:37.398456
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()

    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name','hash_behaviour']
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-11 11:54:38.698520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 11:54:49.510171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = 'new_host'
    task = {'action': {'__ansible_module__': 'include_vars'},
            'args': {'ignore_unknown_extensions': False,
                     'file': 'hosts.yml',
                     'name': 'hosts'},
            'delegate_to': host,
            'delegate_facts': True,
            'register': 'new_host'}
    task_ds = {'_data_source': './lib/ansible/modules/extras/monitoring/nagios/nagios_host.py',
               '_role_path': '/etc/ansible/roles/common'}
    role = {'_role_path': '/etc/ansible/roles/common'}

# Generated at 2022-06-11 11:54:50.229621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return

# Generated at 2022-06-11 11:54:57.644166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionBase)
    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-11 11:55:02.883461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionBase
    from ansible.parsing.dataloader import DataLoader

    path = __file__.rsplit('/', 1)[0]
    loader = DataLoader()
    variable_manager = None
    action = ActionModule(loader=loader, variable_manager=variable_manager)
    assert isinstance(action, ActionBase)



# Generated at 2022-06-11 11:55:10.932157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(dict(), dict(), {'name': None}), ActionModule)
    assert isinstance(ActionModule(dict(), dict(), {'name': 'params'}), ActionModule)
    assert isinstance(ActionModule(dict(), dict(), {'dir': '/tmp'}), ActionModule)
    assert isinstance(ActionModule(dict(), dict(), {'file': '/tmp/test.yml'}), ActionModule)
    assert isinstance(ActionModule(dict(), dict(), {'_raw_params': '/tmp/test.yml'}), ActionModule)

# Generated at 2022-06-11 11:55:58.885605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source_dir = re.compile(r'/home/test/')
    source_file = re.compile(r'vars/main.yml')
    depth = 0
    files_matching = re.compile(r'\w+\.yml')
    ignore_files = re.compile('^main\.yml$')

# Generated at 2022-06-11 11:56:04.911199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader

    a = action_loader.get('include_vars', class_only=True)
    b = action_loader.get('include_vars')
    assert 'include_vars' == a._load_name
    assert 'include_vars' == b._load_name
    assert not b.TRANSFERS_FILES


# Generated at 2022-06-11 11:56:05.910026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test instantiation
    assert ActionModule()

# Generated at 2022-06-11 11:56:16.416921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    am = ActionModule()
    # Create a task
    task = {
        'args': {
            'dir': './test_dir/',
            'name': 'test_var'
        }
    }
    # Set task to instance variable _task
    am._task = task
    # Call method run on instance of class ActionModule
    res = am.run()
    # Assert that result returned is the same as the expected result

# Generated at 2022-06-11 11:56:20.764446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext 

    task_vars={'var1': 'test'}
    obj = ActionModule(task=Task(), connection=None, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    obj._task.args = {
        'file': 'test',
        'name': 'test'
    }
    obj.source_dir = None
    obj.source_file = None
    obj.return_results_as_name = None
    obj.show_content = False
    obj.depth = None
    obj.files_matching = None
    obj.ignore_unknown_extensions = False
    obj.ignore_files = None

# Generated at 2022-06-11 11:56:24.343965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am._task = mock_task()
    am._task._role = mock_role()
    am.run(task_vars={})

# Generated at 2022-06-11 11:56:35.055314
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock the methods of class ActionModule that depend on other classes
    def module_loader(module_loader_self, module_path, module_args, task_vars=None, template_vars=None, module_compression=None, persist_files=False, delete_remote_tmp=True, connection=None, exec_once=False, no_log=False, force_handlers=False, role_name=None, role_params=None):
        return {'a': 'A'}

    ActionModule.run = module_loader


# Generated at 2022-06-11 11:56:40.134677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules.system
    mock_ansible_module = ansible.modules.system.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    module = ActionModule(mock_ansible_module, task_vars=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-11 11:56:41.416075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-11 11:56:44.075929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert actionModule.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-11 11:58:35.133330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-11 11:58:43.456784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit test init
    # set up the Mocks
    # mock the TaskDS
    task_ds = type('ds', (object,), {'_data_source': 'path_to/fake_playbook'})
    task_ds._data_source = 'path_to/fake_playbook'
    # mock the RoleDS
    role_ds = type('ds', (object,), {'_role_path': 'path_to/fake_role'})
    role_ds._role_path = 'path_to/fake_role'
    # mock the Task
    task = type('task', (object,), {})
    task._role = role_ds
    task._ds = task_ds

# Generated at 2022-06-11 11:58:53.455235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # creating mock task
    mock_task = type('test', (), {})
    mock_task.__setattr__('args', {'hah_behaviour': None,
                                   'name': None,
                                   'file': None,
                                   '_raw_params': None,
                                   'dir': None,
                                   'depth': None,
                                   'files_matching': None,
                                   'ignore_files': None,
                                   'extensions': None,
                                   'ignore_unknown_extensions': None})

    mock_task.__setattr__('action', 'include_vars')
    mock_task.__setattr__('_role', None)
    mock_task.__setattr__('_ds', None)

    # creating mock task_vars
    mock_task_vars = dict()



# Generated at 2022-06-11 11:59:03.327340
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action import ActionModule

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            del tmp  # tmp no longer has any effect
            return super(TestActionModule, self).run(task_vars=task_vars)

    class TestTask:
        class TestTaskDS:
            _data_source = '/home/myuser/playbook.yaml'
        _ds = TestTaskDS()
        class TestTaskRole:
            _role_path = '/home/myuser/roles/role_name/'
        _role = TestTaskRole()

        def __init__(self, task_args):
            self.args = task_args

    role_name = 'roles/role_name/vars'

# Generated at 2022-06-11 11:59:04.171571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-11 11:59:04.992037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 11:59:16.997648
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import ActionModuleLoader
    from ansible.template import Templar
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.utils.vars import combine_vars
    import io

    Playbook = None
    var_manager = None


# Generated at 2022-06-11 11:59:18.028936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 11:59:28.945388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    attrs = dict(
        VALID_FILE_EXTENSIONS=['yml'],
        VALID_DIR_ARGUMENTS=[],
        VALID_FILE_ARGUMENTS=['file'],
        VALID_ALL=[],
    )
    am = ActionModule(dict(), dict(), attrs)

    # test ActionModule._set_args
    am._task = dict(
        args = dict(
            file = 'vars.yml',
        )
    )
    am._set_args()
    assert am.source_file == am._task.args.get('file')

    # test ActionModule._set_root_dir
    am._task._role = dict(
        _role_path = 'role_path',
    )
    am._set_root_dir()
    assert am.source_file

# Generated at 2022-06-11 11:59:37.349813
# Unit test for constructor of class ActionModule
def test_ActionModule():
  config = dict()
  task = dict()
  task['name'] = "test"
  task['action'] = dict()
  task['action']['_uses_shell'] = False
  task['action']['args'] = dict()
  task['action']['args']['dir'] = "/path/to/dir"
  task['action']['args']['depth'] = 0
  task['action']['args']['files_matching'] = None
  task['action']['args']['ignore_files'] = list()
  task['action']['args']['extensions'] = ['yaml', 'yml', 'json']
  task['action']['args']['ignore_unknown_extensions'] = False
  task['action']['args']['file'] = None
