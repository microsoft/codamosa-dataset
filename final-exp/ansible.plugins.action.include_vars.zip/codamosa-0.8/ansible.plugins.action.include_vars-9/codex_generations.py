

# Generated at 2022-06-11 11:53:00.149342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:53:04.118466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # simple test
    module = ActionModule(
        task=dict(
            args=dict(
                file='/tmp/test_ActionModule_run.yaml'
            )
        )
    )
    module.run()

# Generated at 2022-06-11 11:53:04.474876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:53:05.601152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert ActionModule.run() == 0

# Generated at 2022-06-11 11:53:14.194611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Variable Definitions
    args = {
        'dir': 'test_dir',
        'depth': 0,
        'files_matching': 'host_vars.*',
        'ignore_files': 'mac_hosts',
        'extensions': 'yml',
        'ignore_unknown_extensions': True
    }
    mocker = MagicMock()
    mocker.return_value = ('', True)
    mocker.side_effect = [
        ('', True),
        ('', True),
        ('', True),
        ('', True),
        ('', True),
        ('', True),
        ('', True),
        ('', True),
        ('', True),
        ('', True),
        ('', True),
        ('', True)
    ]

# Generated at 2022-06-11 11:53:15.410484
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert isinstance(obj, ActionBase)


# Generated at 2022-06-11 11:53:17.302856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 11:53:29.758079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants
    import ansible.module_utils.six
    import ansible.module_utils._text
    ansible.constants = reload(ansible.constants)
    ansible.module_utils.six = reload(ansible.module_utils.six)
    ansible.module_utils._text = reload(ansible.module_utils._text)

    from ansible.compat.tests.mock import mock_open
    from ansible.module_utils.six.moves import builtins
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    from units.mock.loader import DictDataLoader

    from os import path
    from uuid import uuid4
    from sys import version_

# Generated at 2022-06-11 11:53:31.292982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule("dir", dict("some", "value")) is not None


# Generated at 2022-06-11 11:53:35.066166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']

# Generated at 2022-06-11 11:53:59.272627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO
    pass

# Generated at 2022-06-11 11:54:03.168422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(name='test_module', task_vars={})
    print(repr(action_module))
    print(str(action_module))

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 11:54:13.173420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_args = {'_raw_params': 'asd.yml'}
    class Task():
        def __init__(self):
            self._role = None
            self._ds = object()
            self.args = module_args
    class ActionModuleTest(ActionModule):
        def __init__(self, task=None):
            self._task = task
            self._connection = None
            self._loader = None
            self._templar = None
            self._shared_loader_obj = None
    class _ds():
        def __init__(self):
            self._data_source = 'a/b/c.yml'
    class _role():
        def __init__(self):
            self._role_path = 'd'
    class TaskTest(object):
        _role = _role()
       

# Generated at 2022-06-11 11:54:24.057940
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import collections
    import ansible.plugins
    import ansible.plugins.action.include_vars
    import ansible.utils.vars
    import ansible.utils.unsafe_proxy
    import ansible.parsing.dataloader
    import ansible.playbook.role.definition
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils import plugin_docs

    class _Task(object):
        def __init__(self, args):
            self.args = args

        def _role(self):
            return None

    class _Role(RoleDefinition):
        def __init__(self):
            self._role_path = 'my_role_path'


# Generated at 2022-06-11 11:54:28.052401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test default
    a = ActionModule()
    assert a.TRANSFERS_FILES == False

    # Test initialization
    a = ActionModule({'test': 'test'}, {'test': 'test'})
    assert a.TRANSFERS_FILES == False

# Generated at 2022-06-11 11:54:28.712625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return None

# Generated at 2022-06-11 11:54:29.369176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:54:39.621284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=DataLoader(),
        options=None,
        passwords=None,
        stdout_callback='default'
    )

    # Add plugin path
    add_all_plugin_dirs()

    # Create a play to work with

# Generated at 2022-06-11 11:54:40.564201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError("Test not implemented yet")

# Generated at 2022-06-11 11:54:41.600258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:55:26.435350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:55:35.545199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def test_module_defaults(self):
        assert self.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
        assert self.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
        assert self.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
        assert self.VALID_ALL == ['name', 'hash_behaviour']

    # Create instance
    action_module = ActionModule()

    # test constructor
    test_module_defaults(action_module)


# Generated at 2022-06-11 11:55:37.148858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_raises(AnsibleError, ActionModule, None)

# Generated at 2022-06-11 11:55:47.935238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    import ansible.plugins.action.include_vars as include_vars
    from ansible.plugins.action.include_vars import ActionModule

    action_module = ActionModule("test", "test")
    assert isinstance(action_module, include_vars.ActionModule)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module

# Generated at 2022-06-11 11:55:52.744707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    # TODO: Implement tests for ActionModule
    # module = ActionModule(task=Task(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # assert module is not None
    pass


# Generated at 2022-06-11 11:56:03.051423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import pytest

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.errors import AnsibleError
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult

    from ansible.modules.extras.cloud.rackspace.rax import rax_facts
    from ansible.modules.cloud.rackspace.rax import rax_facts
    from ansible.modules.cloud.rackspace.rax_clb import rax_clb_attachment
    from ansible.modules.cloud.rackspace.rax_clb import rax_clb_

# Generated at 2022-06-11 11:56:13.137592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.module_utils.basic
    import ansible.module_utils.common.collections
    import ansible.plugins.loader
    from ansible.playbook.task import Task

    testPlay = ansible.playbook.play.Play().load({
        'name': 'testPlay',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [{
            'action': 'include_vars',
            'dir': './test_data/',
            'ignore_files': ['*.ignore']
        }]
    }, variable_manager=None, loader=None)
    testTask = testPlay.get_task_by_name('action')

# Generated at 2022-06-11 11:56:13.788370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:56:20.716509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action.VALID_ALL, list) is True, 'VALID_ALL must be list'
    assert isinstance(action.VALID_DIR_ARGUMENTS, list) is True, 'VALID_DIR_ARGUMENTS must be list'
    assert isinstance(action.VALID_FILE_ARGUMENTS, list) is True, 'VALID_FILE_ARGUMENTS must be list'
    assert isinstance(action.VALID_FILE_EXTENSIONS, list) is True, 'VALID_FILE_EXTENSIONS must be list'

# Generated at 2022-06-11 11:56:32.500300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a valid instance of ActionModule class
    # ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    AM = ActionModule(None, None, None, None, None, None)
    # Verify class attributes were set by constructor
    assert AM.TRANSFERS_FILES == False
    assert AM.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert AM.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert AM.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert AM.VALID_ALL == ['name', 'hash_behaviour']
    # Verify _set_dir

# Generated at 2022-06-11 11:58:14.506021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(name='test_ActionModule') is not None

# Unit Test for _set_dir_defaults

# Generated at 2022-06-11 11:58:17.482798
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    if not path.exists('tests/utils/src/vars/main.yml'):
        mkdir('tests/utils/src')
        mkdir('tests/utils/src/vars')
        touch('tests/utils/src/vars/main.yml')
    test = ActionModule({},{})
    test.run()

# Generated at 2022-06-11 11:58:17.954614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-11 11:58:26.425105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Check the module ActionModule.run
    """
    import string
    import random

    def randomString(stringLength=10):
        """Generate a random string of fixed length """
        letters = string.ascii_letters
        return ''.join(random.choice(letters) for i in range(stringLength))

    #
    # Check run with sources
    #
    def _test_load_files(tmp, task_vars, source_file, source_dir, rf_result, rf_failed, rf_message):
        """
        Check the method run with sources
        """
        rf_obj = ActionModule(rf_task, tmp)

        if rf_failed:
            assert rf_obj.run(tmp, task_vars)["failed"] == rf_failed
            assert rf_

# Generated at 2022-06-11 11:58:27.813878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_under_test = ActionModule('hostname')
    assert ansible_under_test

# Generated at 2022-06-11 11:58:36.067434
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:58:44.202546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()

    # when the source_dir is provided in the args
    source_dir = '/path/to/dir'
    args = {'dir': source_dir}

    # when the source_dir is not present
    source_dir = None
    args = {'dir': source_dir}

    try:
        am.run(args)
    except Exception:
        pass

    # when valid_extensions is not a list
    args = {'valid_extensions': 'ext'}

    try:
        am.run(args)
        pass
    except ValueError:
        pass

    # when both dir and file arguments are present
    args = {'dir': '/path/to/dir', 'file': '/path/to/file'}


# Generated at 2022-06-11 11:58:45.406070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module != None


# Generated at 2022-06-11 11:58:57.252570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    # Create our play context
    context = PlayContext()

    # Create our task
    task = Task()

    # Make name of task 'include_vars'
    task._role = None
    task._parent = None
    task._ds = None
    task._task_deps = []
    task._block = None
    task._role_params = {}
    task.action = 'include_vars'
    task.args = dict()
    task.delegate_to = None
    task.loop = None
    task.notify = []
    task.loop_control = {}
    task.register = None


# Generated at 2022-06-11 11:58:58.020532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import doctest
    doctest.testmod()