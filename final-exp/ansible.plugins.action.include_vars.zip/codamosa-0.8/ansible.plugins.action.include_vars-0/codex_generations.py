

# Generated at 2022-06-11 11:53:07.995393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import json
    # Add the path to the current working directory to the system path
    sys.path.append('.')

    # We can't import the module directly because it depends on the running
    # Ansible configuration to be present as well as the role directories.
    # So we just load the module directly
    with open('library/include_vars.py') as f:
        mod = f.read()

    mod = compile(mod, 'library/include_vars.py', 'exec')
    exec(mod)

    # Construct an object for the class ActionModule
    action_module = ActionModule()
    # Construct a task and set the properties of the task

# Generated at 2022-06-11 11:53:08.413792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:53:09.279359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a.run(task_vars={})

# Generated at 2022-06-11 11:53:17.177552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import pathlib

    sys.path.append(str(pathlib.Path(__file__).parent.parent))
    
    from ansible.plugins.action.include_vars import ActionModule

    action_vars = ActionModule(
        task=dict(args=dict()),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict(),
    )
    task_vars = {}
    result = action_vars.run(
        task_vars=task_vars,
    )
    assert result.rules == {}
    assert result.fact_names == []


# Generated at 2022-06-11 11:53:24.805554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
        Unit test function to test constructor of class ActionModule

        Returns:
            instance: returns instance of ActionModule
    """
    task = dict()
    connection = dict()
    play_context = dict()
    loader = dict()
    templar = dict()
    shared_loader_obj = dict()
    action_name = 'include_vars'
    task_vars = dict()
    instance = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    return instance

# Generated at 2022-06-11 11:53:37.321549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    import ansible.utils.template as template

    # Test with a directory
    test_dir = dict()
    test_dir["dir"] = "./unit/modules/include_vars/directory"
    test_dir["ignore_files"] = ['main.yml']
    test_dir["ignore_unknown_extensions"] = False
    test_dir["name"] = "test_dir_return"


# Generated at 2022-06-11 11:53:45.096230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader as plugin_loader
    from ansible.utils.vars import combine_vars

    class C(object):
        def __init__(self):
            self.role_result = None

    loader_mock = plugin_loader.ActionModuleLoader('/tmp', 'a', None)
    action_module = ActionModule(loader_mock, task=C())

    assert action_module._loader._data_source == '/tmp'
    assert action_module._loader._basedir == '/tmp'

    assert action_module._task.role_result == None



# Generated at 2022-06-11 11:53:47.276188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:53:48.649550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionModule)



# Generated at 2022-06-11 11:53:59.473293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_class = ActionModule(dict(play=dict(playbook='playbook.yml')))
    test_class._set_dir_defaults()
    assert not test_class.depth
    assert not test_class.files_matching
    assert not test_class.ignore_files
    assert test_class.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert test_class.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert test_class.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert test_class.VALID_ALL == ['name', 'hash_behaviour']
    assert not test_class.hash_

# Generated at 2022-06-11 11:54:34.946282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_object = ActionModule()

    #match_found = re.match(r'hi', "hi there")
    #assert match_found

    test_object.__dict__['_task'] = {}
    test_object._task.__dict__['args'] = {}
    test_object._task.args['file'] = 'testfile'
    test_object._task.args['name'] = 'test'

    test_object.__dict__['_loader'] = {}
    test_object._loader.__dict__['_basedir'] = '/tmp'
    test_object._loader._get_file_contents = lambda a: "a: 1"

    assert 'ansible_included_var_files' in test_object.run()

# Generated at 2022-06-11 11:54:42.665518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    passed = True
    failed = False
    failed_msg = ''
    failed_msg = 'test failed!'
    passed_msg = 'test passed!'
    # initializing action module for testing
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # initialize empty task
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    task = Task()
    play_context = PlayContext()
    templar = Templar(loader, variables=dict())

    # initialize task vars

# Generated at 2022-06-11 11:54:45.156739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    assert t is not None
    assert t._task_vars is None
    assert t.show_content is True

# Generated at 2022-06-11 11:54:46.285154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Function run not implemented
    pass


# Generated at 2022-06-11 11:54:57.645681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock for test
    task_vars = dict()
    loader = mock.MagicMock()
    def_val = mock.MagicMock()
    def_val.DEFAULT_HASH_BEHAVIOUR = "replace"
    def_val.DEFAULT_HASH_BEHAVIOUR = "replace"
    def_val.DEFAULT_HASH_BEHAVIOUR = "replace"
    # Set up test for success
    tmp = ""
    task = mock.MagicMock()
    task._role = mock.MagicMock()
    task._ds = mock.MagicMock()
    task._ds._data_source = "test_data_source"
    task._role._role_path = "test_role_path"

# Generated at 2022-06-11 11:55:04.893635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_args = {'name': 'ansible_loaded_vars', 'hash_behaviour': 'replace', '_raw_params': '../../../../../../etc/passwd'}
    test_include_vars = ActionModule(None, test_args, None)
    assert test_include_vars.hash_behaviour == 'replace'
    assert test_include_vars.return_results_as_name == 'ansible_loaded_vars'
    assert test_include_vars.source_dir == None
    assert test_include_vars.source_file == '../../../../../../etc/passwd'


# Generated at 2022-06-11 11:55:17.040164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    try:
        VariableManager.__module__ = 'ansible.vars.manager'
    except:
        pass
    task = Task().load({'action': {'__use_supplied_args': True,
                                   'module': 'include_vars',
                                   '_raw_params': 'tweak.yml'}})
    play_context

# Generated at 2022-06-11 11:55:27.470408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # arrange
    action = ActionModule()
    action._task.args = {
        'file': 'test.yml',
        'name': 'result',
        'ignore_files': '*.example'
    }

# Generated at 2022-06-11 11:55:28.853698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('host', 'user', 'pass', 'test', 'key')

# Generated at 2022-06-11 11:55:31.403210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Use for debugging
    # import ipdb
    # ipdb.set_trace()
    test_action_module = ActionModule('test', dict())
    assert test_action_module

# Generated at 2022-06-11 11:56:32.348789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Unit test for constructur of class ActionModule
    '''
    print("\n === UNIT TEST: ActionModule constructor ===")

    test_result = {}

    task_vars = {}
    # error: no file or dir
    try:
        task = type('', (), {})()
        task._ds = type('', (), {'_data_source': None})
        task._role = type('', (), {'_role_path': None})
        task.args = {'_raw_params': ''}
        action = ActionModule(task, task_vars)
        action.run(task_vars=task_vars)
        test_result.update({'test 1': False})
    except AnsibleError:
        test_result.update({'test 1': True})

    # error: file and dir specified


# Generated at 2022-06-11 11:56:37.664161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    input_data = dict()
    input_data['_task'] = dict()
    input_data['_task']['args'] = dict()
    input_data['_task']['args']['file'] = None
    input_data['_task']['args']['_raw_params'] = None

    with pytest.raises(AnsibleError):
        ActionModule(input_data)

# Generated at 2022-06-11 11:56:39.171201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(dict(), dict()), ActionModule)

# Generated at 2022-06-11 11:56:39.825033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:56:40.813135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: !!!
    pass

# Generated at 2022-06-11 11:56:41.945873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None)
    assert action_module is not None

# Generated at 2022-06-11 11:56:51.810352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize the search paths for task plugins
    # and create an empty argument spec
    module_utils_path = "../../../module_utils"  # ansible/module_utils
    builtin_module_utils_path = "../../../ansible/module_utils" # ansible/lib/ansible/module_utils
    search_paths = []
    search_paths.append(path.join(path.dirname(path.realpath(__file__)), module_utils_path))
    search_paths.append(path.join(path.dirname(path.realpath(__file__)), builtin_module_utils_path))
    argument_spec = {}

    # Create mock Role object
    mock_role = MockRole()
    # Create mock Task object
    mock_task = MockTask(mock_role)


# Generated at 2022-06-11 11:56:52.891800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 11:57:04.009601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlaybookPlay
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    display = Display()

    loader= DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['myhost'])

# Generated at 2022-06-11 11:57:05.332487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule
    # pass
    pass

# Generated at 2022-06-11 11:59:19.406235
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict
    import os
    import shutil

    action_module = ActionModule(Dummy(AnsibleModule), ImmutableDict())

    # Create dummy directory and files
    package_root = os.path.abspath(os.path.dirname(__file__))
    test_root = os.path.dirname(package_root)
    temp_dir = os.path.join(test_root, 'temp_dir')
    shutil.rmtree(temp_dir, True)
    os.mkdir(temp_dir)

    # Create test dir
    test_dir = os.path.join(temp_dir, 'vars')
    os.mkdir(test_dir)


# Generated at 2022-06-11 11:59:23.463567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-11 11:59:25.391126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_object = ActionModule()
    assert isinstance(action_module_object, ActionModule)

# Generated at 2022-06-11 11:59:30.003381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def _run(task_args, task_vars):
        am = ActionModule(None, task_args, task_vars)
        return am.run(None, task_vars)
    def _traverse_dir_depth(task_args, task_vars):
        am = ActionModule(None, task_args, task_vars)
        return am._traverse_dir_depth()
    task_path = '/path/to/task_file.yml'
    role_path = '/path/to/role'
    current_file = 'include_vars.yml'
    def _get_file_contents(filename):
        data = filename
        show_content = True
        if filename == 'ignore_file.yml':
            data = ''
        return data, show_content

# Generated at 2022-06-11 11:59:35.704299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-11 11:59:37.725555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule({'name': 'test_action_module'}, {'vars': {}})
    action_module.run({}, {})

# Generated at 2022-06-11 11:59:38.468408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 11:59:48.886650
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Set up class
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context._technique = 'ansible.builtin.include_vars'
    play_context._task = dict()

# Generated at 2022-06-11 11:59:57.935763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source_dir = "/path/to/dir"
    source_file = "/path/to/file"
    return_results_as_name = "var_name"
    depth = 0
    files_matching = ".*\\.ext$"
    ignore_files = ["file1.yml", "file2.yml", "file3.yml"]
    valid_extensions = ["yaml", "json"]
    ignore_unknown_extensions = False


# Generated at 2022-06-11 12:00:09.199996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(dict(path = 'path_foo',
                               depth = 'depth_foo',
                               files_matching = 'files_matching_foo',
                               ignore_files = 'ignore_files_foo',
                               extensions = 'extensions_foo',
                               ignore_unknown_extensions = 'ignore_unknown_extensions_foo'))
    assert module.run() == dict(ansible_facts = dict(),
                                ansible_included_var_files = list(),
                                failed = True,
                                message = 'Invalid type for "extensions" option, it must be a list')