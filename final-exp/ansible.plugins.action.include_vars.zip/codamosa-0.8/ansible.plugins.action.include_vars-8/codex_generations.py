

# Generated at 2022-06-11 11:53:06.474695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # ActionBase()
    actionBase = ActionBase()
    assert actionBase is not None
    assert hasattr(actionBase, 'run')
    assert hasattr(actionBase, '__init__')

    # ActionModule()
    actionModule = ActionModule()
    assert actionModule is not None

    assert actionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert actionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert actionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert actionModule.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-11 11:53:08.668157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = main()

    assert result['ansible_included_var_files']
    assert not result['failed']
    assert result['_ansible_no_log']
    assert result['ansible_facts']
    assert result['ansible_facts']['name'] == 'TEST_VAR_FILE'



# Generated at 2022-06-11 11:53:09.332163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, 'No unit tests for this module yet'

# Generated at 2022-06-11 11:53:10.303433
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:53:11.861249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Instantiated an _ActionModule object
    '''
    assert ActionModule()


# Generated at 2022-06-11 11:53:20.620522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit tests for ActionModule class
    """
    from ansible.parsing.mod_args import ModuleArgsParser
    module_args = {}
    module_args['file'] = 'vars/main.yml'
    action_mod = ActionModule(None, None, ModuleArgsParser(module_args))
    try:
        action_mod._set_args()
    except Exception as e:
        assert True, '_set_args() raised unexpected exception: {}'.format(e)
    else:
        assert not action_mod.source_dir, '_set_args() did not set source_dir'
        assert action_mod.source_file == 'vars/main.yml', \
            '_set_args() did not set source_file properly'

# Generated at 2022-06-11 11:53:32.985674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class DummyConfig:
        def __init__(self, noop):
            self.noop = noop
    def setup_module(m):
        global TASK, HOSTNAME, PLAY_CONTEXT, LOADER, MOCK_PATH
        m.TASK = {
            'action': {
                'module': 'include_vars',
                'name': 'blah',
                'args': {
                    'dir': '/tmp',
                    'depth': 1,
                    'ignore_files': '*.txt',
                    'extensions': 'yaml, yml',
                    'hash_behaviour': 'replace'
                }
            }
        }
        m.HOSTNAME = 'blah'
        m.HOSTVARS = dict()
        m.PLAY_CONTEXT = {'noop': False}

# Generated at 2022-06-11 11:53:44.036578
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import sys
    import shlex
    import tempfile
    import shutil
    import unittest
    import copy
    import random
    import string
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars

    class FakeModule(object):
        def __init__(self, args):
            self.args = args

    class FakeTask(object):
        def __init__(self, args, ds, role):
            self.args = args
            self._ds = ds
            self._role = role

    class FakeRole(object):
        def __init__(self, role_path):
            self._role_path = role_path

    class FakeDS(object):
        def __init__(self, data_source):
            self._data_source

# Generated at 2022-06-11 11:53:50.730455
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        VALID_FILE_EXTENSIONS = ['txt']

        # return a dictionary of any file from the test directory
        # this allows the test to work relative to the test directory
        # and not the directory where the script is run from
        def _loader(self, *args, **kwargs):
            return {'results': 'test'}

        def _find_needle(self, *args, **kwargs):
            return path.join(self.source_dir, 'test')


# Generated at 2022-06-11 11:54:02.060646
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def dummy_loader_get_file_contents(filename):
        test_data = dict()
        test_data[path.join(root_dir, 'test1.json')] = "{ \"meta\": { \"name\": \"test1\", \"description\": \"desc1\" }, \"files\": { \"filename1\": \"text1\", \"filename2\": \"text2\" } }"
        test_data[path.join(root_dir, 'test2.json')] = "{ \"meta\": { \"name\": \"test2\", \"description\": \"desc2\" }, \"files\": { \"filename3\": \"text3\", \"filename4\": \"text4\" } }"
        b_data = test_data[filename]
        show_content = True
        return b_data, show_content

    from ansible.playbook.play_context import PlayContext
   

# Generated at 2022-06-11 11:54:32.704570
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # proper argument setting
    task_vars = dict()
    task_vars['temp_var'] = 12
    module = ActionModule(dict(), task_vars=task_vars)

    assert module.run() == 0 # successful execution
    assert module.run() == 0 # successful execution
    assert module.run() == 0 # successful execution
    assert module.run() == 0 # successful execution
    assert module.run() == 0 # successful execution
    assert module.run() == 0 # successful execution


# Generated at 2022-06-11 11:54:41.606581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from argparse import Namespace

    from ansible.playbook.play_context import PlayContext
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    action_module = ActionModule(
        task=Namespace(args={}),
        connection=None,
        _play_context=PlayContext(
            connection_user='test',
            become_method='test',
            become_user='test',
            check_mode=True,
            diff_mode=True,
            passwords={}
        ),
        loader=AnsibleCollectionLoader(),
        templar=None,
        shared_loader_obj=None
    )

    action_module._task.args = {}

# Generated at 2022-06-11 11:54:53.124162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    module_name = 'include_vars'
    mod = __import__(module_name)
    reload(mod)
    module = getattr(mod, 'ActionModule')()
    module._task.args['file'] = 'hello.yml'
    module._task.args['name'] = 'load_results'
    module._task.args['_raw_params'] = 'hello.yml'

    # Action
    actual = module.run()

    # Assert

# Generated at 2022-06-11 11:55:02.962482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = type('', (), {'_role':None})
    action_module._task._role = type('', (), {'_role_path':None})
    action_module._task.args = {}
    action_module._task._ds = type('', (), {'_data_source':None})
    action_module._loader = type('', (), {'load':None, '_get_file_contents':None})
    action_module._loader._get_file_contents = lambda x: None
    action_module._traverse_dir_depth = lambda x: None
    action_module._load_files = lambda x, y: None
    action_module.run()

ActionModule.run = test_ActionModule_run

# Generated at 2022-06-11 11:55:03.546206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:55:14.741369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Dummy data for testing
    tmp = None
    task_vars = {'test_key': 'test_value'}
    tmp = None
    task_vars = {'test_key': 'test_value'}
    action_module = ActionModule(tmp, task_vars=task_vars)
    # Assert the correctness of the result
    expected_result = {
        'ansible_facts': {
            'test_key': 'test_value'
        },
        'ansible_included_var_files': [],
        'changed': False,
        '_ansible_no_log': True
    }
    result = action_module.run(tmp, task_vars=task_vars)
    assert result == expected_result


# Generated at 2022-06-11 11:55:15.847343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Test class constructor
    pass


# Generated at 2022-06-11 11:55:26.675377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.common.collections import ImmutableDict

    play_source =  dict(
        name = 'Ansible Play',
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='include_vars', args=dict(dir='vars/test', extensions=['yml']))),
        ]
    )
    play = Play().load(play_source, variable_manager=dict(), loader=dict())

# Generated at 2022-06-11 11:55:37.618557
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import unittest
    import tempfile
    import os
    import shutil
    import time
    from ansible.module_utils import basic

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.tmpsingle = tempfile.mkdtemp()
            self.test_dir = os.path.join(self.tmpdir, 'test_dir')
            self.test_dir_two = os.path.join(self.test_dir, 'test_dir_two')
            self.test_yaml = os.path.join(self.test_dir, 'test.yml')
            self.test_yaml_two = os.path.join(self.test_dir_two, 'test_two.yml')


# Generated at 2022-06-11 11:55:45.437645
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    #assert isinstance(am, ActionBase) == True
    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert am.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-11 11:56:32.716283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:56:34.122583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 11:56:36.782940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionBase()) is ActionBase

if __name__ == '__main__':
    test_ActionModule()

# print("Yaml file: ", ActionModule)

# Generated at 2022-06-11 11:56:37.400980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return True

# Generated at 2022-06-11 11:56:45.677554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a class object
    a = ActionModule()

    # set source_dir
    a.source_dir = "../../../../library/include_vars"
    assert a.source_dir

    # set source_file
    a.source_file = "../../../../library/include_vars"
    assert a.source_file

    # set depth
    a.depth = 0
    assert a.depth == 0

    a.depth = 1
    assert a.depth == 1

    a.depth = 2
    assert a.depth == 2

    # set files_matching
    a.files_matching = "*.yml"
    assert a.files_matching

    a.files_matching = "*.yaml"
    assert a.files_matching


# Generated at 2022-06-11 11:56:54.492586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    """
    task_args = dict()
    am = ActionModule(None, task_args, None)
    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-11 11:56:59.780555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for ActionModule constructor
    """
    my_action = ActionModule(
        task=dict(action=dict()),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert my_action is not None

# Generated at 2022-06-11 11:57:00.876308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # simple assert to test coverage of method run
    assert True

# Generated at 2022-06-11 11:57:08.889252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        pass

    module_instance = TestActionModule(None, None)
    assert module_instance is not None
    assert module_instance.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module_instance.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert module_instance.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module_instance.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-11 11:57:12.405370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader = None
    templar = None
    shared_loader_obj = None
    args = dict()
    task_uuid = None
    action = ActionModule(loader, templar, shared_loader_obj, args, task_uuid)
    return action

# Generated at 2022-06-11 11:59:06.572279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()


# Generated at 2022-06-11 11:59:18.656347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test for method run of class ActionModule
    """

    import mock
    import __builtin__ as builtins # pylint: disable=import-error

    # We want to perform these tests with a mocked version of the module,
    # and also with a version using the real ActionModule.

    action_module_mock = mock.MagicMock(spec=ActionModule)
    action_module_real = ActionModule(task=mock.MagicMock(), connection=mock.MagicMock(), play_context=mock.MagicMock(), loader=mock.MagicMock(), templar=mock.MagicMock(), shared_loader_obj=mock.MagicMock())

    # pylint: disable=line-too-long
    # Test set up
    ansible_mock = mock.MagicMock()
   

# Generated at 2022-06-11 11:59:20.868295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    pass

# Generated at 2022-06-11 11:59:24.697770
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    play_context = PlayContext()
    action = ActionModule(play_context, {})
    assert isinstance(action, ActionModule)

# Generated at 2022-06-11 11:59:27.127078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule()
    assert test.VALID_FILE_EXTENSIONS[0] == "yaml"
# Unit tests for the run method

# Generated at 2022-06-11 11:59:29.478087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {'name': 'test'}
    action = ActionModule(task, '/path/to/somewhere', 'loader', 'templar')
    assert action


# Generated at 2022-06-11 11:59:35.812579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    loader.set_basedir('fixtures/t/roles/test_role/')
    variable_manager.extra_vars = {'role_path': 'fixtures/t/roles/test_role/'}

    task = Task()
    task._role = None
    task.args = {'file': 'fixtures/t/roles/test_role/vars/main.yml'}

# Generated at 2022-06-11 11:59:46.294408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Dummy AnsibleTask object
    from ansible.playbook.task import Task
    from ansible.playbook import Play
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.module_utils.six import string_types

    handler = Handler()
    block = Block()
    block.block  = [handler]
    play_context = PlayContext()
    play_rec = Play()
    play_rec._included_files = [IncludedFile('ignore_files_test.yml')]
    play_rec._based

# Generated at 2022-06-11 11:59:55.405900
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common._collections_compat import OrderedDict
    module_args = OrderedDict()
    module_args['file'] = 'tommy/test.yaml'
    action_module = ActionModule('')
    # call _set_args
    action_module._set_args()
    # call_set_root_dir
    action_module._set_root_dir()
    assert action_module.source_dir is None, action_module.source_dir
    assert action_module.source_file == "tommy/test.yaml"
    assert action_module.depth is None
    assert action_module.files_matching is None
    assert action_module.ignore_files is None
    assert action_module.valid_extensions == ["yaml", "yml", "json"]

# Generated at 2022-06-11 12:00:04.030692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    # test of variables
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action.VALID_ALL == ['name', 'hash_behaviour']
    assert action.TRANSFERS_FILES == False

# test of _set_dir_defaults