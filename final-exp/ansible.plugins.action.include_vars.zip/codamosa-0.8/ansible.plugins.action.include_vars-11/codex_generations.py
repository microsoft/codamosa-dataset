

# Generated at 2022-06-11 11:53:02.236688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert isinstance(actionModule, ActionModule)

# Generated at 2022-06-11 11:53:06.119328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule(loader=None,
                       connection=None,
                       _task=None,
                       play_context=None,
                       loader_path=None,
                       shared_loader_obj=None,)

test_ActionModule()

# Generated at 2022-06-11 11:53:07.104939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am != None

# Generated at 2022-06-11 11:53:12.152459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    mock_self = MockActionModule()
    
    # Act
    mock_self.run()
    
    # Assert
    assert mock_self.source_dir is None
    assert mock_self.source_file == 'var/main.yml'
    assert mock_self.return_results_as_name is None
    assert mock_self.depth is None
    assert mock_self.files_matching is None
    assert mock_self.ignore_files is None
    assert mock_self.valid_extensions == ['yaml', 'yml', 'json']
    assert mock_self.show_content is True
    assert mock_self.included_files == []
    assert mock_self._task.args.get('name') is None

# Generated at 2022-06-11 11:53:15.709430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_module = ActionModule(None, dict())
    return (
        test_module.VALID_FILE_EXTENSIONS,
        test_module.VALID_DIR_ARGUMENTS,
        test_module.VALID_FILE_ARGUMENTS,
        test_module.VALID_ALL,
    )


# Generated at 2022-06-11 11:53:18.116773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-11 11:53:25.455366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    pc = PlayContext()
    loader = DataLoader()
    task = Task()
    task._role = None
    task._ds = 'File'
    task._ds._data_source = '/path/to/file'

    return ActionModule(
        task,
        pc,
        loader
    )

# Generated at 2022-06-11 11:53:26.238472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:53:26.974729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:53:28.784794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass

# Generated at 2022-06-11 11:53:55.981586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict())

# Generated at 2022-06-11 11:53:56.663619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:53:59.385057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
# class ActionModule_run_test(unittest.TestCase):
#     def test_run(self):
#         self.fail("Not implemented")


# Generated at 2022-06-11 11:54:10.767411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.executor.task_result import TaskResult
    from ansible.executor import ResultCallback
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-11 11:54:21.093734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MyLoader:
        def __init__(self):
            self.all_vars = {"a": 1, "b": 2, "c": 3}

        def _get_file_contents(self, filename):
            return "abcd", True

        def load(self, data, file_name, show_content):
            return data

    class Task:
        def __init__(self, args, role):
            self.args = args
            self._role = role

    class Role:
        def __init__(self, role_path):
            self._role_path = role_path

    class Host:
        def __init__(self, name):
            self.name = name

        def get_vars(self):
            return {"var1": 1, "var2": 100}


# Generated at 2022-06-11 11:54:32.032111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Config
    tmp = None
    source_dir = '/my/project/dir/'
    source_file = '/my/project/dir/test.yml'
    depth = 0
    files_matching = 'test.yml'
    ignore_files = ['test2.yml']
    valid_extensions = ['json']
    hash_behaviour = None
    return_results_as_name = 'all_data'

    my_obj = ActionModule()

    # Attributes
    my_obj.depth = depth
    my_obj.files_matching = files_matching
    my_obj.ignore_files = ignore_files
    my_obj.valid_extensions = valid_extensions
    my_obj.hash_behaviour = hash_behaviour

# Generated at 2022-06-11 11:54:32.765207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return

# Generated at 2022-06-11 11:54:37.295327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act_mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert act_mod.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert act_mod.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert act_mod.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-11 11:54:46.694978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(
        task=dict(),
        connection=None,
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    ), dict())
    assert isinstance(action, ActionModule)
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions',
                                          'ignore_unknown_extensions']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action.VALID_ALL == ['name', 'hash_behaviour']
    assert action.matcher is None



# Generated at 2022-06-11 11:54:49.658898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Run unit test for method run of class ActionModule """
    # Load fake a file
    # Ensure we raise exception if we hit an error with args

# Generated at 2022-06-11 11:55:50.377410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os, sys
    import yaml
    from ansible.module_utils.six import PY3

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    test_data_directory = os.path.join(os.path.dirname(__file__), 'test_data')
    test_file_path = os.path.join(test_data_directory, 'test_file.yml')
    test_dir = os.path.join(test_data_directory, 'test_dir')

    # Write a test data file
    with open(test_file_path, 'w') as fh:
        fh.write("test_data:\n    - test\n    - test2\n")

    # Create the test directory

# Generated at 2022-06-11 11:55:57.893277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Check create/setup of ActionModule class"""
    action = ActionModule(dict(action='include_vars', module_args=dict(dir='test_dir')))
    action.show_content = False
    action.included_files = []
    # this is a new process, we do not want to try to load files
    # from the cache
    action._task._role = None
    action._task._ds = None

    assert isinstance(action, ActionModule)
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']

# Generated at 2022-06-11 11:55:59.294326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """
    raise NotImplementedError

# Generated at 2022-06-11 11:56:09.964775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import textwrap
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import ansible.module_utils.six.moves.builtins

    # create a temporary directory and write line1.txt
    tmp_dir = tempfile.mkdtemp()
    line1 = textwrap.dedent("""This line will be returned in error message""")
    write_to_file(tmp_dir, 'line1.txt', line1)

    # create a second temporary directory, with a nested directory, and write line2.txt
    tmp_dir2 = tempfile.mkdtemp()
    nested_dir = path.join(tmp_dir2, 'nested')
    write_to_file(nested_dir, 'line2.txt', line2)

    # create a temporary file

# Generated at 2022-06-11 11:56:19.917506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    from ansible.errors import AnsibleError

    # Prepare test files
    tmp_dir = tempfile.mkdtemp()
    role_dir = os.path.join(tmp_dir, 'roles', 'testrole')
    os.makedirs(role_dir)

    test_file_1 = os.path.join(role_dir, 'var', 'main.yml')
    with open(test_file_1, 'w') as f:
        f.write("""
            ---
            foo: 1
        """)

    test_file_2 = os.path.join(role_dir, 'vars', 'main.yml')

# Generated at 2022-06-11 11:56:32.295875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    filename = 'setup.yml'
    _loader = None
    _templar = None
    _shared_loader_obj = None
    _action = ActionModule(_loader, _templar, _shared_loader_obj)
    assert _action._task._ds is None
    assert _action._task._role is None
    assert _action._loader is None
    assert _action._templar is None
    assert _action._shared_loader_obj is None
    assert _action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert _action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']

# Generated at 2022-06-11 11:56:38.949750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    TEST_CASE = {
    "action": "include_vars",
    "args": {
        "_raw_params": "test.yml"
    }
}

    # Test initializing ActionModule
    module = ActionModule(TEST_CASE, None)
    module.setup()

    # Test __set_args
    module._set_args()
    assert module.source_file != None
    assert module.source_file == "test.yml"
    assert module.source_dir == None

# Generated at 2022-06-11 11:56:41.373977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test constructor of class ActionModule
    test_obj_1 = ActionModule()
    # test constructor of class ActionModule
    test_obj_2 = ActionModule()

# Generated at 2022-06-11 11:56:51.077066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule.
    """
    import json
    import yaml
    # Ansible test vars.
    ansible_test_vars = dict()
    # The actual task.
    ansible_task = dict()
    ansible_task['vars'] = dict()
    ansible_task['vars']['files_matching'] = '.*\.json'
    ansible_task['vars']['dir'] = '../test'
    ansible_task['vars']['name'] = 'test'
    # The actual task arguments.
    ansible_task['args'] = dict()
    ansible_task['args']['dir'] = '../test'
    ansible_task['args']['files_matching'] = '.*\.json'
    ansible_task

# Generated at 2022-06-11 11:56:52.739617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module



# Generated at 2022-06-11 11:59:01.392153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)



# Generated at 2022-06-11 11:59:07.501714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import unittest

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            self.valid_args = ['dir', 'depth', 'file_matching', 'extensions', 'ignore_files', 'ignore_unknown_extensions']
            self.valid_file_args = ['file', '_raw_params']

        def test_valid_args(self):
            values = [x for x in ActionModule.VALID_FILE_ARGUMENTS if x not in self.valid_file_args]
            values.extend([x for x in ActionModule.VALID_DIR_ARGUMENTS if x not in self.valid_args])
            values.extend([x for x in ActionModule.VALID_ALL if x not in ['name', 'hash_behaviour']])
           

# Generated at 2022-06-11 11:59:11.318995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    obj_run = obj.run()

    assert obj_run is not None
    assert obj_run['message'] is not None

# Generated at 2022-06-11 11:59:12.044294
# Unit test for constructor of class ActionModule
def test_ActionModule():
	assert True

# Generated at 2022-06-11 11:59:13.076041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-11 11:59:16.281155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-11 11:59:17.712303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule()

    assert action_module_obj is None

# Generated at 2022-06-11 11:59:28.645371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import yaml

    expected = {
        "ansible_included_var_files": [
            "../../../../ansible/plugins/action/test_data/dir/vars/vars.yml"
        ],
        "ansible_facts": {
            "first": "var",
            "second": "var2"
        },
        "_ansible_no_log": False
    }

    input_args = {
        "dir": "test_data/dir"
    }

    action_obj = ActionModule()

    action_obj._task = MockTask()
    action_obj._task._role = MockRole()
    action_obj._task._role._role_path = 'test_data/dir'

    result = action_obj.run(task_vars=dict())


# Generated at 2022-06-11 11:59:33.669024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Tests if the constructor of the class ActionModule works.
    '''
    tmp = None
    module_vars = {}
    task_vars = {}
    loader = None
    play_context = {}
    new_stdin = None
    testModuleAction = ActionModule(
       tmp,
        module_vars,
        task_vars,
        loader,
        play_context,
        new_stdin
    )
    assert isinstance(testModuleAction, ActionModule)


# Generated at 2022-06-11 11:59:34.706044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(action=None)