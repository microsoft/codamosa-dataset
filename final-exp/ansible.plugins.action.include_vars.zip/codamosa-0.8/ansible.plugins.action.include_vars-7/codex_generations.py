

# Generated at 2022-06-11 11:52:58.649149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:53:02.649338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    # Add initialization code here
    action_module = ActionModule()

    # Mock class methods and attributes here

    # Add code to test execution of run method
    action_module.run(task_vars=None)



# Generated at 2022-06-11 11:53:11.578596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Setup the class and return an instance of the class.
    Args:
        depth (int): The depth of the directory tree to traverse.
    """
    class_args = {
        'file': '/tmp/test.yml',
        'dir': 'test_dir',
        'depth': 0,
        'files_matching': None,
        'ignore_files': None,
        'extensions': ['yml', 'yaml'],
        'ignore_unknown_extensions': False,
        'return_results_as_name': None,
        'hash_behaviour': 'replace'
    }
    action_mod = ActionModule(class_args)
    assert isinstance(action_mod, ActionModule)


# Generated at 2022-06-11 11:53:16.828953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionBase)
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-11 11:53:29.224554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    p = Play()
    p.post_validate()
    play_context = PlayContext()
    t = ActionModule(p, play_context, DataLoader(), {})
    assert t._task._role._role_path == None
    assert t.depth == None
    assert t.files_matching == None
    assert t.hash_behaviour == None
    assert t.included_files == []
    assert t.ignore_files == None
    assert t.return_results_as_name == None
    assert t.show_content == True
    assert t.source_dir == None
    assert t

# Generated at 2022-06-11 11:53:36.461980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockTask():
        def __init__(self):
            self.args = {}

    class MockExecutor():
        def __init__(self):
            self.loader = None
        def get_loader(self):
            return self.loader

    mocked_executor = MockExecutor()
    mocked_task = MockTask()
    a = ActionModule(mocked_executor, mocked_task, file_name=__file__, tree=None)
    assert type(a) is ActionModule

# Generated at 2022-06-11 11:53:37.581182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:53:46.581324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am._task = Mock()
    am._task.args = {}
    am._task.args['file'] = 'test.yml'
    am._loader = Mock()
    am._loader.load = Mock(return_value = {'test':'value'})
    am._connection = Mock()
    am._connection.shell = Mock(return_value = {'test':'value'})
    assert am.run(task_vars = {}) == {
        'ansible_facts': {'test':'value'},
        'changed': False,
        'ansible_included_var_files': ['test.yml'],
        '_ansible_no_log': False
    }


# Generated at 2022-06-11 11:53:57.409749
# Unit test for constructor of class ActionModule
def test_ActionModule():
    required_args = {
        '_ansible_no_log': True,
        '_ansible_verbose_always': True,
        '_ansible_version': '2.4.0.0',
        '_ansible_module_name': 'include_vars',
        '_ansible_loop_var': 'play_hosts',
        '_ansible_playbook_file': '/opt/ansible/playbooks/test/test.yml',
        '_ansible_playbook_dir': '/opt/ansible/playbooks/test',
        'app': 'app',
        '_ansible_play_batch': ['localhost'],
        'dir': '/tmp/',
        'name': 'test_var'
    }

    fake_task = lambda: None
    fake_task.args = required

# Generated at 2022-06-11 11:53:57.852557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:54:31.710700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a test object of class ActionModule
    action_module = ActionModule()

    # test the VALID_FILE_EXTENSIONS
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

    # test the VALID_DIR_ARGUMENTS
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']

    # test the VALID_FILE_ARGUMENTS
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']

    # test the VALID_ALL
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-11 11:54:32.131527
# Unit test for constructor of class ActionModule
def test_ActionModule():
	assert True

# Generated at 2022-06-11 11:54:38.503637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    test_dir = os.path.dirname(os.path.abspath(__file__))
    test_file = os.path.join(test_dir, "test.json")
    test_dir = os.path.join(test_dir, "vars")
    args = dict()
    args['file'] = test_file
    #args['dir'] = test_dir
    task_args = dict()
    task_args['args'] = args
    task_args['task_vars'] = {}
    task_args['loader'] = None
    task_args['templar'] = None
    task_args['_ansible_no_log'] = False
    task_args['_ansible_verbosity'] = 0
    task_args['_ansible_debug'] = False
    task_args

# Generated at 2022-06-11 11:54:49.197521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.include_vars as include_vars

    action_module = include_vars.ActionModule()
    action_module._setup_action()

    assert action_module.VALID_FILE_EXTENSIONS[0] == 'yaml'
    assert action_module.VALID_FILE_EXTENSIONS[1] == 'yml'
    assert action_module.VALID_FILE_EXTENSIONS[2] == 'json'
    assert action_module.VALID_DIR_ARGUMENTS[0] == 'dir'
    assert action_module.VALID_DIR_ARGUMENTS[1] == 'depth'
    assert action_module.VALID_DIR_ARGUMENTS[2] == 'files_matching'

# Generated at 2022-06-11 11:54:57.465446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run'), 'ActionModule has no run'
    assert hasattr(ActionModule, 'TRANSFERS_FILES'), 'ActionModule has no TRANSFERS_FILES'
    assert hasattr(ActionModule, 'VALID_ALL'), 'ActionModule has no VALID_ALL'
    assert hasattr(ActionModule, 'VALID_DIR_ARGUMENTS'), 'ActionModule has no VALID_DIR_ARGUMENTS'
    assert hasattr(ActionModule, 'VALID_FILE_ARGUMENTS'), 'ActionModule has no VALID_FILE_ARGUMENTS'

# Generated at 2022-06-11 11:55:03.457751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    run automated tests for class ActionModule
    """
    params = {'dir': 'vars/', 'depth': 1, 'files_matching': 'var_[.]yml', 'ignore_files': ['main.yml'], 'extensions': ['yml', 'yaml'], 'ignore_unknown_extensions': False, 'name': 'vars_test'}
    task = {'args': params}
    action = ActionModule(task, {})
    action._set_args()
    assert action.source_dir == params['dir']
    assert action.depth == params['depth']
    assert action.files_matching == params['files_matching']
    assert action.ignore_files == params['ignore_files']
    assert action.valid_extensions == params['extensions']
    assert action.ignore_unknown

# Generated at 2022-06-11 11:55:04.066173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:55:04.647795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:55:16.707292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence

    def get_config(data, key, value=None):
        if value is None:
            value = data

        if is_sequence(value):
            value = to_bytes(value[0])

        config._config[key] = value

    def get_ansible_module(tasks=None):
        if tasks is None:
            tasks = list()

        class AnsibleModuleFake(object):
            def __init__(self):
                self.params = dict()

            def fail_json(self, *args, **kwargs):
                raise Exception('AnsibleModuleFake.fail_json')

        class PlayContextFake(object):
            def __init__(self):
                self.check

# Generated at 2022-06-11 11:55:17.415225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:56:03.116922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()

# Generated at 2022-06-11 11:56:06.105822
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    """
    module = ActionModule()

    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-11 11:56:06.737152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 11:56:17.299040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    try:
        ActionModule()
    except Exception as e:
        assert isinstance(e, TypeError)

    # Test with non 'Task' object
    try:
        ActionModule('test')
    except Exception as e:
        assert isinstance(e, TypeError)

    # Test with another object
    class object():
        def __init__(self):
            pass

    obj = object()
    try:
        ActionModule(obj)
    except Exception as e:
        assert isinstance(e, TypeError)

    # Test with valid 'Task' object as argument
    class Task():
        def __init__(self):
            self._role = self

        def _get_role_path(self):
            return 'test'
    obj = Task()
    module = ActionModule(obj)
   

# Generated at 2022-06-11 11:56:22.746698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_actionmodule = ActionModule()
    assert test_actionmodule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert test_actionmodule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert test_actionmodule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert test_actionmodule.VALID_ALL == ['name', 'hash_behaviour']
    assert test_actionmodule.TRANSFERS_FILES == False

# Generated at 2022-06-11 11:56:33.840273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockRole(object):
        def __init__(self):
            self._role_path = ''
    class MockDS(object):
        def __init__(self):
            self._data_source = ''
    class MockTask(object):
        def __init__(self):
            self._role = MockRole()
            self._ds = MockDS()
    class MockLoader(object):
        def __init__(self):
            pass

        def _get_file_contents(self):
            return True, True

        def load(self, data, file_name, show_content):
            return True
    class MockTaskResult(object):
        def __init__(self):
            pass

        def set_status(self, status):
            return True


# Generated at 2022-06-11 11:56:43.260484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    play_context = PlayContext()
    play_context._ansible_no_log = True

    task = Task()
    task._ds = ""
    task._uuid = ""
    task._role = ""
    task._play = ""
    task.action = 'include_vars'

# Generated at 2022-06-11 11:56:43.794729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:56:44.339803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()

# Generated at 2022-06-11 11:56:46.352673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 11:58:39.572813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a.dir()


# Generated at 2022-06-11 11:58:47.986623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Executing {}".format("test_ActionModule_run"))
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars

    # Set role and role base

# Generated at 2022-06-11 11:58:53.139883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(
        action=dict(
            module='include_vars',
            args=dict(
                file='/etc/hosts'
            )
        )
    )
    result = ActionModule(task, {})
    assert result is not None

# Unit tests for methods of class ActionModule

# Generated at 2022-06-11 11:58:57.531573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None


# Generated at 2022-06-11 11:58:59.137610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance of ActionModule
    module_instance = ActionModule()
    assert module_instance is not None

# Generated at 2022-06-11 11:59:06.098925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """

    test case for run method of class ActionModule
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    test_action = ActionModule(Task(), VariableManager(), False, PlayContext())
    test_action.VALID_FILE_EXTENSIONS = ['yaml']
    test_action._task.args = {'dir': 'dir/dir/dir', 'ignore_files': 'ignore'}
    test_action._task._role = None
    test_action.source_dir = 'dir/dir/dir'
    test_action.files_matching = None
    test_action.follow = False
    test_action.depth = 0
    test_action

# Generated at 2022-06-11 11:59:08.786720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule("test", "test", {}, False)
    assert action_module is not None

# Generated at 2022-06-11 11:59:09.513605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return True

# Generated at 2022-06-11 11:59:16.777248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(
        task=dict(
            _role=dict(
                _role_path='D:/Work/project/ansible-fundamentals/ansible-roles/role-1/'),
            args=dict(
                file='main.yml'
            )
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    return actionModule

# Generated at 2022-06-11 11:59:27.777134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = {
        'dir': path.join(path.dirname(__file__), 'fixtures', 'collection_of_yaml'),
        'hash_behaviour': 'replace',
        'name': 'var_dir_loaded',
        'extensions': ['yml', 'yaml'],
        'ignore_unknown_extensions': True,
    }

    host = 'localhost'
    t = dict(
        delegate_to='localhost',
        run_once=True,
        # connection='local',
    )
    hostvars = dict()

    # Create mock variable manager and loader
    variable_manager = ansible.vars.VariableManager()
    variable_manager.set_host_variable(host, hostvars)
    loader = ansible.parsing.dataloader.DataLoader()

    # Mock