

# Generated at 2022-06-11 11:53:10.394777
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import load_extra_vars
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = load_extra_vars(loader=loader, options=None)

# Generated at 2022-06-11 11:53:17.927490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = {}
    # Test without args
    with pytest.raises(AnsibleError):
        action = ActionModule(None, task_args, load_args=True)
        action.run(None, None)

    # Test with empty args
    with pytest.raises(AnsibleError):
        action = ActionModule(None, {'_raw_params': ''}, load_args=True)
        action.run(None, None)

    # Test with mixed file and dir args
    with pytest.raises(AnsibleError):
        task_args = {'file': 'test.yaml', 'dir': 'test_dir'}
        action = ActionModule(None, task_args, load_args=True)
        action.run(None, None)

    # Test with invalid file argument

# Generated at 2022-06-11 11:53:29.966773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    action = ActionModule(None, task_vars)
    assert action is not None
    action._task.args.update({'dir': '.'})
    action._set_root_dir()
    assert action.source_dir == '.', action.source_dir
    action._task.args['dir'] = 'vars'
    action._set_root_dir()
    assert action.source_dir == 'vars'
    action._task.args['dir'] = 'tasks'
    action._set_root_dir()
    assert action.source_dir == 'tasks'
    action._task.args['dir'] = 'files'
    action._set_root_dir()
    assert action.source_dir == 'files'


# Generated at 2022-06-11 11:53:41.445357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import builder
    from ansible.plugins.loader import action_loader
    from ansible.utils.listify import listify_lookup_plugin_terms

    # list of extensions, that is the same for ActionModule
    ext = ['yaml', 'yml', 'json']

    # creating class instances
    a = action_loader.get('include_vars', class_only=True)
    b = builder.PluginLoader()
    d = dict()

    # load data
    data, tmp = b._load_plugins('./test/files/test_data', 'action')
    d = data[0]
    d_copy = dict()
    d_copy = d.copy()


    # test case 1
    # if the task is not valid, exception must be raised
    # in the error message, there must

# Generated at 2022-06-11 11:53:49.467089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """

    # I create a test task
    task = {}
    task['name'] = 'play'
    task['action'] = {}
    task['action']['module'] = 'include_vars'
    task['action']['args'] = {}
    task['action']['args']['dir'] = './test/test_plugin_include_vars/'
    task['action']['args']['name'] = 'staff'

    # I create an instance of ActionModule
    obj = ActionModule(task, '/home/bender/ansible/')
    obj._task._ds = {}
    obj._task._ds._data_source = './test/test_plugin_include_vars/playbook.yml'

# Generated at 2022-06-11 11:53:51.308330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return ActionModule('/some/path/to/file', dict(a=1), dict(b=2))

# Generated at 2022-06-11 11:53:52.390589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:54:04.011578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.constants import DEFAULT_MODULE_NAME

    t = Task()
    t._role = None
    t._ds = 'a/b/c/d/e/vars/test_var.yml'
    t.action = DEFAULT_MODULE_NAME
    t.args = {'file': 'test_var.yml'}
    t.name = 'test'

    c = PlayContext()

    task_result = TaskResult(host=None, task=t)

# Generated at 2022-06-11 11:54:13.561754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ test_ActionModule(dict, AnsibleFileFinder)
    """
    # Load vars from a directory
    # depth set to 0
    # ignore_files = ['main.yml']
    # files_matching = '^doc.*'
    # extensions = ['yaml']
    action_module = ActionModule({'name': 'test_vars', 'hash_behaviour': 'replace', 'dir': './test/unit/fixtures/test/vars', 'depth': 0, 'files_matching': '^doc.*', 'ignore_files': 'main.yml', 'extensions': 'yaml'}, None)
    results = action_module.run()
    assert results['ansible_facts']['test_vars'] == {'doc_one': 'one', 'doc_two': 'two'}
   

# Generated at 2022-06-11 11:54:19.674785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # assert_raises does not raise a ValueError in the following statement
    # assert_raises(ValueError, ActionModule, {'file': 'path/to/file'})
    import pytest
    with pytest.raises(ValueError):
        print("\nTesting constructor of class ActionModule")
        ActionModule({'file': 'path/to/file'})

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-11 11:54:55.016086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.six import PY3

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    import ansible.parsing.yaml.objects
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.include_vars import ActionModule

    def fake_tqdm(iterable, *args, **kwargs):
        return iterable

    old_tqdm = ansible.parsing.yaml.objects.tqdm
    ansible.parsing.yaml.objects.tqdm = fake_tqdm
    old_hash_behaviour = ansible.constants.DEFAULT_HASH

# Generated at 2022-06-11 11:55:04.567469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = 'localhost'
    port = 10022
    user = 'ubuntu'
    passwd = 'use1pass'

    async_wrapper = None
    connection = 'smart'
    platform = None
    timeout = 10
    ssh = None
    become = False
    become_method = 'sudo'
    become_user = 'root'
    gather_facts = 'yes'
    module_name = 'ping'
    module_args = ''
    module_vars = dict()
    task_vars = dict()
    forks = 100
    pattern = 'all'
    inventory = None
    loader = None
    variable_manager = None
    stdout_callback = None


# Generated at 2022-06-11 11:55:16.707935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleError
    import sys
    import json
    import os
    sys.path.append("..")
    # pylint: disable=abstract-class-little-used,too-few-public-methods,import-error
    class objectview(object):
        def __init__(self, d):
            self.__dict__ = d
        # pylint: disable=abstract-class-little-used,

# Generated at 2022-06-11 11:55:27.247518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class AnsibleModule():
        def run_command(self, args):
            print(args)

    class DeprecatedModule():
        def run_command(self, args):
            print(args)

    def get_host_list(self):
        host_list = []
        host_list.append('host1')
        host_list.append('host2')
        return host_list

    class Task():
        def __init__(self):
            self.args = {
                'dir': '/etc/ansible/inventory',
                'depth': 1,
                'files_matching': '.*\.yml',
                'ignore_files': ['test.yml'],
                'extensions': 'yml,yaml',
                'ignore_unknown_extensions': False,
                'name': 'var'
            }



# Generated at 2022-06-11 11:55:38.282826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class C:
        a = None
        b = None
        c = None
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    class A(ActionModule):
        def init(self, task, connection, play_context, loader, templar, shared_loader_obj):
            pass
        def run(self, tmp=None, task_vars=None):
            pass
        def _load_files(self, filename):
            pass
        def _load_files_in_dir(self, root_dir, var_files):
            pass
        def _ignore_file(self, filename):
            pass
        def _traverse_dir_depth(self):
            pass
        def _set_args(self):
            pass


# Generated at 2022-06-11 11:55:48.969713
# Unit test for constructor of class ActionModule
def test_ActionModule():

    def test_args():
        args = dict()
        args['dir'] = 'dir1'
        args['depth'] = 2
        args['files_matching'] = '.yml'
        args['ignore_files'] = 'file1.yml'
        args['extensions'] = 'yml'
        args['ignore_unknown_extensions'] = False
        return args

    def test_task_vars():
        return dict()

    def test_task_loader():
        return 'test_task_loader'

    def test_task_templar():
        return 'test_task_templar'

    def test_task_shared_loader_obj(task_loader):
        return task_loader

    result = dict()
    result['failed'] = True
    result['message'] = 'test_failed_message'


# Generated at 2022-06-11 11:55:52.575082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Initial
    action_module = ActionModule("ansible.modules.test.test_action_module")
    action_module.run()

    #When
    action_module.run()

    #Then
    assert action_module.run()


# Generated at 2022-06-11 11:55:53.562282
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__

# Generated at 2022-06-11 11:55:54.201102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 11:55:54.807035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:56:46.801132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockTask(object):
        def __init__(self):
            self.args = {'dir': 'dir'}

    class MockPlay(object):
        def __init__(self):
            self.vars = {}

    class MockRole(object):
        def __init__(self):
            self._role_path = 'role_path'

    class MockDS(object):
        def __init__(self):
            self._data_source = 'data_source'

    class MockTaskDS(object):
        def __init__(self):
            self._ds = MockDS()

    class MockRoleTask(object):
        def __init__(self):
            self._role = MockRole()
            self._ds = MockDS()

    class MockPlayDS(object):
        def __init__(self):
            self

# Generated at 2022-06-11 11:56:47.947030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act_mod = ActionModule()

# Generated at 2022-06-11 11:56:51.753010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    results = mod.run()
    assert results == {u'ansible_facts': {}, u'_ansible_no_log': True, u'ansible_included_var_files': []}


# Generated at 2022-06-11 11:56:52.841959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-11 11:57:03.958033
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Task to be tested
    task = dict()
    task['action'] = dict()
    task['action']['__ansible_arguments__'] = list()
    task['action']['__ansible_arguments__'].append('include_vars')
    task['action']['__ansible_arguments__'].append('=')
    task['action']['__ansible_arguments__'].append('file')
    task['action']['__ansible_arguments__'].append('=')
    task['action']['__ansible_arguments__'].append('{{ lookup("env", "USER") }}')
    task['name'] = 'include vars test'
    task['_ansible_parsed'] = True
    task['_ansible_check_mode'] = False
   

# Generated at 2022-06-11 11:57:04.609879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(False)


# Generated at 2022-06-11 11:57:05.217225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 11:57:12.857760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.include_vars import ActionModule

    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    action_module._task = object()
    action_module._task.args = dict(
        name=None,
        dir=None,
        file=None,
        _raw_params=None,
        depth=None,
        files_matching=None,
        ignore_files=None,
        ignore_unknown_extensions=False,
        extensions=None,
        hash_behaviour=None,
        test_argument="parameter"
    )


# Generated at 2022-06-11 11:57:13.436939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:57:15.278779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: We do not have the good class to test the method.
    pass

# Generated at 2022-06-11 11:59:20.701258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.task.action import TaskAction
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import os

    # Create objects to create an instance of the ActionModule class.
    play_context = PlayContext()
    play_context._task = TaskAction(dict())
    play_context._task._ds = 'include_vars'
    play_context._task._role = None
    play_context._task.args = {'_raw_params': 'test_raw_params.yaml'}


# Generated at 2022-06-11 11:59:23.261555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, {}, None, '_ansible_tmp')
    assert action_module is not None


# Generated at 2022-06-11 11:59:24.384444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert str(ActionModule) == 'ansible.plugins.action.include_vars.ActionModule'
# EOF

# Generated at 2022-06-11 11:59:26.049651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    print(action.run())


# Generated at 2022-06-11 11:59:34.169341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Task(object):
        def __init__(self):
            self.args = {'file': 'first.yml'}

    class Play(object):
        def __init__(self):
            self.connection = 'local'
            self.vars = {
                'foo': 'bar'
            }
            self.basedir = '/home'
            self.playbook_basedir = None

    class Connection(object):
        def __init__(self):
            self.local = True

    class Loader(object):
        def __init__(self):
            self.vars = {
                'foo': 'bar'
            }

        def load(self, contents, file_name, show_content=False):
            return {'var1': 'value1'}


# Generated at 2022-06-11 11:59:44.452933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''this unit test will execute all the test cases defined in the class ActionModule'''

    # creating task object
    task = ActionModule()

    # creating test cases.
    test_cases = \
        '''
        test_valid_file_extensions : to test the function '_is_valid_file_ext(self, source_file)'
        test_ignore_files : to test the function '_ignore_file(self, filename)'
        test_set_dir_defaults : to test the function '_set_dir_defaults(self)'
        test_set_args : to test the function '_set_args(self)'
        test_traverse_dir_depth : to test the function '_traverse_dir_depth(self)'
        '''
    # printing the test cases

# Generated at 2022-06-11 11:59:46.888564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_param = 'file'
    result = ActionModule(test_param)
    assert result.source_file == test_param

# Generated at 2022-06-11 11:59:47.486037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 11:59:56.644075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.vars import ActionModule

    # Setup mocks
    obj = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, templar=None, shared_loader_obj=None)
    def mock__set_dir_defaults(*args, **kwargs):
        return
    obj._set_dir_defaults = mock__set_dir_defaults
    def mock__set_args(*args, **kwargs):
        return
    obj._set_args = mock__set_args
    def mock__set_root_dir(*args, **kwargs):
        return
    obj._set_root_dir = mock__set_root_dir
    def mock__traverse_dir_depth(*args, **kwargs):
        return
    obj._tra

# Generated at 2022-06-11 12:00:03.625132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fakeVars = {}
    fakeDataSource = 'example/data/source'
    fakeRolePath = 'example/role'
    fakeDS = object()
    fakeDS._data_source = fakeDataSource
    fakeTask = object()
    fakeTask._role = object()
    fakeTask._role._role_path = fakeRolePath
    fakeTask._ds = fakeDS
    am = ActionModule(fakeTask, fakeVars)
    assert am
    assert am.TRANSFERS_FILES == False