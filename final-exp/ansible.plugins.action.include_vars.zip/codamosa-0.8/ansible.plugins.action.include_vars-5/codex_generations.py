

# Generated at 2022-06-11 11:52:56.952384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:53:01.331417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule()
    assert action_mod.VALID_FILE_EXTENSIONS is not None
    assert action_mod.VALID_DIR_ARGUMENTS is not None
    assert action_mod.VALID_FILE_ARGUMENTS is not None
    assert action_mod.VALID_ALL is not None


# Generated at 2022-06-11 11:53:02.547157
# Unit test for constructor of class ActionModule
def test_ActionModule():
  return ActionModule(dict())

# Generated at 2022-06-11 11:53:03.523189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:53:05.037720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule
    assert False

# Generated at 2022-06-11 11:53:05.758568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-11 11:53:07.105237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: add unit test
    pass

test_ActionModule_run()

# Generated at 2022-06-11 11:53:13.055517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-11 11:53:18.531367
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile

    test_module = ActionModule()

    task = dict()
    task['args'] = dict()
    task['_role'] = None

    ds = dict()
    ds['_data_source'] = tempfile.tempdir + "/library/roles/role_two/tasks/main.yml"
    task['_ds'] = ds

    test_module._task = task
    test_module._task._role = None

    assert test_module.run()

# Generated at 2022-06-11 11:53:19.704999
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-11 11:53:49.572423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data_source = "/path/to/playbook.yaml"
    task_vars = dict()

    task_data = dict(
        args=dict(
            dir="test/data",
            hash_behaviour="merge",
            name="test_from_dir",
            depth=2,
            extensions=["yaml"],
            files_matching="main.yaml"
        )
    )

    module = ActionModule(task_data, data_source)
    module._task._ds = module
    result = module.run(task_vars)

    assert result['ansible_included_var_files'] == [
        '/Users/spring/Projects/ansible/lib/ansible/modules/utilities/logic/include_vars/test/data/main.yaml'
    ]


# Generated at 2022-06-11 11:54:00.705226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os.path
    import sys
    import unittest

    class TaskMock(object):
        def __init__(self, args, role_path=None, role=None, ds=None):
            self.args = args
            self.role_path = role_path
            self.role = role
            self.ds = ds

    class RoleMock(object):
        def __init__(self, role_path=None):
            self.role_path = role_path

    class DsMock(object):
        def __init__(self, data_source=None):
            self.data_source = data_source
            self.type = 'Task'


# Generated at 2022-06-11 11:54:11.500325
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # initialize required input for ActionModule.run()
    task_vars = dict(foo='bar')
    tmp = None
    inject = dict(foo='bar')
    connection_info = dict(foo='bar')
    
    # initialize attributes of ActionModule.run()
    runner_connection = dict(foo='bar')
    loader_vars = dict(foo='bar')
    play_context = PlayContext()
    
    # initialize attributes of ActionBase.run()
    connection = dict(foo='bar')
    runner

# Generated at 2022-06-11 11:54:12.596994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-11 11:54:13.174003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:54:24.064382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    import ansible.plugins.loader as plugin_loader

    display = Display()
    variable_manager = VariableManager(loader=None, inventory=None)
    myblock = Block(
        parent_block=None,
        role=None,
        task_include=None,
        use_block=None,
        implicit=False,
        strict=False,
    )
    mytask = TaskInclude(
        block=myblock,
        task=None,
        role=None,
        task_include=None,
        args=dict(),
        role_params={},
    )


# Generated at 2022-06-11 11:54:34.202065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test ActionModule.
    """
    import ansible.playbook.play_context
    from ansible.playbook.task import Task

    play_context = ansible.playbook.play_context.PlayContext()
    task = Task()
    task._role = None
    task._play = None
    task._parent = None
    task.action = 'include_vars'
    task._ds = 'vars'
    task.args = {
        'file': '../test_files/test_vars.yml',
        'name': 'test_vars',
        'hash_behaviour': 'replace'
    }
    action_module = ActionModule(task, play_context)
    action_module.run()

# Generated at 2022-06-11 11:54:41.866468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_object = ActionModule(None, None, None, None, None)
    # test to see if the 'VALID_FILE_EXTENSIONS' variable is populated
    assert 'yml' in action_module_object.VALID_FILE_EXTENSIONS
    assert 'yaml' in action_module_object.VALID_FILE_EXTENSIONS
    assert 'json' in action_module_object.VALID_FILE_EXTENSIONS

    # test to see if the 'VALID_DIR_ARGUMENTS' variable is populated
    assert 'dir' in action_module_object.VALID_DIR_ARGUMENTS
    assert 'depth' in action_module_object.VALID_DIR_ARGUMENTS
    assert 'files_matching' in action_module_object.VALID_DIR_ARGUMENTS
   

# Generated at 2022-06-11 11:54:43.873520
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:54:55.394198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic

    action_module = ActionModule(
        dict(
            _task=dict(
                args=dict(
                    name='test_name',
                    file='_raw_params',
                    depth=1,
                    files_matching='test_file',
                    ignore_files='ignore_file',
                    extensions='test_ext',
                    ignore_unknown_extensions=True
                )
            ),
            _task_vars=dict(
                test_task_vars=True
            )
        ),
        basic._ANSIBLE_ARGS
    )

    # Normal run
    action_module.run()

    # No source_dir or source_file provided.
    # The code already handles this by passing the raw_params to source_file

# Generated at 2022-06-11 11:55:49.810324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._task.args = {'dir': r'C:\Test\include_vars\test'}
    action._task.args.update({'hash_behaviour': None})
    action._task.args.update({'name': None})

# Generated at 2022-06-11 11:55:57.565309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance = ActionModule()
    assert(instance.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'])
    assert(instance.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'])
    assert(instance.VALID_FILE_ARGUMENTS == ['file', '_raw_params'])
    assert(instance.VALID_ALL == ['name', 'hash_behaviour'])
    assert(instance.source_dir is None)
    assert(instance.source_file is None)
    assert(instance.depth is None)
    assert(instance.files_matching is None)
    assert(instance.ignore_files is None)
    assert(instance.valid_extensions is None)


# Generated at 2022-06-11 11:55:58.158294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:56:08.794345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar
    import ansible.constants as C
    import ansible.cli.adhoc
    import ansible.cli.playbook
    import ansible.utils.plugin_docs as plugin_docs

    # These are the things that our test class is expecting to

# Generated at 2022-06-11 11:56:18.903866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.VALID_DIR_ARGUMENTS = ['dir']
    facter_dir = '/projects1/ansible/ansible/file_include/facter'
    facter_additional_facts_dir = '/projects1/ansible/ansible/file_include/facter/additional_facts/'
    facter_facts_d_dir = '/projects1/ansible/ansible/file_include/facter/facts.d/'
    results = dict()
    source_dir = facter_dir
    source_file = facter_additional_facts_dir + 'gce.rb'

    # create action module object
    action_module = ActionModule('/projects1/ansible/ansible/file_include/test.yml', 'test', 'play')

    # create action module attributes
    # action

# Generated at 2022-06-11 11:56:20.183045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(dict(), dict())
    assert action_module

# Generated at 2022-06-11 11:56:32.348316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """

    Run test for class ActionModule
    This test case is for the run method.
    """
    import ansible.playbook
    import ansible.playbook.task
    import ansible.utils
    import ansible.vars
    import os
    from ansible.template import Templar
    from ansible.utils import context_objects as co

    class DataLoaderFake():
        class _files():
            def __init__(self):
                self.files = [
                    ('first_file', '{"a" : "{{ a }}"}'),
                    ('second_file', '{"b" : "{{ b }}"}')
                ]

            def __iter__(self):
                return self

            def next(self):
                try:
                    return self.files.pop()
                except IndexError:
                    raise StopIteration


# Generated at 2022-06-11 11:56:33.792253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None, None, None, None, None)
    action.run()

# Generated at 2022-06-11 11:56:36.041855
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Verify that ActionModule is a subclass of object
    Returns:
        Boolean
    """
    return issubclass(ActionModule, object)


# Generated at 2022-06-11 11:56:44.770988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(
                action=dict(
                    module='include_vars', args=dict(file='test_include_vars.yml')
                ),
                register='shell_out'
            )
        ]
    )


# Generated at 2022-06-11 11:58:40.356564
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # setup
    task_vars = dict()
    source = 'tests/unit/fixtures/include_vars/'
    source_dir = source + 'dir'
    filename = 'tests/unit/fixtures/include_vars/dir/main.yaml'
    depth = 2
    files_matching = 'main.yaml'
    ignore_files = list()
    valid_extensions = ['yaml', 'yml']

    # call
    instance = ActionModule()
    instance.source_dir = source_dir
    instance.depth = depth
    instance.files_matching = files_matching
    instance.ignore_files = ignore_files
    instance.valid_extensions = valid_extensions
    result = instance.run(task_vars=task_vars)

    # test

# Generated at 2022-06-11 11:58:48.724914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            pass

    t = TestActionModule(dict(
        action=dict(),
        namespace=dict(),
        task_vars=dict(),
        inject=dict(),
        args=dict(
            hash_behaviour=None,
            name=None,
            dir=None,
            depth=None,
            files_matching=None,
            ignore_files=None,
            extensions=None,
            ignore_unknown_extensions=False,
            file=None,
            _raw_params=None,
        ),
        _task=dict(),
        _ds = dict(),
        _loader=dict()
    ))

# Generated at 2022-06-11 11:59:00.743595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from nose.tools import ok_
    from ansible.executor import task_result
    from ansible.playbook.task import Task

    play_context = dict(
        basedir='/home/ac/acme/sample',
        remote_addr='localhost'
    )
    task_ds = dict(
        _role=None,
        _role_path='/home/ac/acme/sample/roles/common',
        _ds='common.yml',
        _data_source='/home/ac/acme/sample/roles/common/tasks/main.yml'
    )
    task_tmp_path = '/home/ac/acme/sample/tmp'

# Generated at 2022-06-11 11:59:11.326717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    sys.modules['_ansible_test_mock'] = __import__('unit_test_mock')
    import _ansible_test_mock as mock
    from ansible.playbook.block import Block

    task_vars = dict()
    task_vars['role_name'] = 'test_role'
    task_vars['my_var'] = 'my_value'

    loader_mock = mock.LoaderMock()

    class TaskMock:
        """ Mock of class Task """
        name = "include_vars_mock"

# Generated at 2022-06-11 11:59:12.451066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule,"run")

# Generated at 2022-06-11 11:59:23.262469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    param_dict = {
        'dir': './test/test_include_vars/vars',
        'ignore_files': ['test.yml']
    }

    test_class_instance = ActionModule()
    test_class_instance._task = MockTask()
    test_class_instance._task._role = MockRole()
    test_class_instance._task._role.files_matching = None
    test_class_instance._set_args()
    test_class_instance._set_root_dir()
    test_class_instance._set_dir_defaults()

    test_class_instance._find_needle = lambda x, y: y
    test_class_instance._load_files = lambda x: (False, '', {'test_key': 'test_value'})
    test_class_instance._tra

# Generated at 2022-06-11 11:59:32.534591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    assert ActionModule
    assert hasattr(ActionModule, '_find_needle')
    assert hasattr(ActionModule, '_set_dir_defaults')
    assert hasattr(ActionModule, '_set_args')
    assert hasattr(ActionModule, 'run')
    assert hasattr(ActionModule, '_traverse_dir_depth')
    assert hasattr(ActionModule, '_ignore_file')
    assert hasattr(ActionModule, '_is_valid_file_ext')
    assert hasattr(ActionModule, '_load_files')
    assert hasattr(ActionModule, '_load_files_in_dir')
    assert hasattr(ActionModule, '_set_root_dir')

# Generated at 2022-06-11 11:59:42.613453
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:59:43.924621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionModule)

# Generated at 2022-06-11 11:59:44.636086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass