

# Generated at 2022-06-11 11:53:04.008066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionBase) is True

# Generated at 2022-06-11 11:53:13.055294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys, os
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.callback.default import CallbackModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    class Options:
        connection = 'local'
        module_path = ''
        forks = 100
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False
        listhosts = None
        listtasks = None
        listtags = None
        syntax = None
        vault_password = None
        verbosity = 3
        start_at_

# Generated at 2022-06-11 11:53:15.256291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a class object
    obj = ActionModule()
    # Check if the class object is an instance of class ActionBase
    assert isinstance(obj, ActionBase)

# Generated at 2022-06-11 11:53:16.162827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 11:53:16.748937
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:53:25.675884
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source_dir = 'tests/test_data/vars'
    source_file = 'tests/test_data/vars/file.yml'
    action_module = ActionModule(dict(), dict())
    action_module._set_dir_defaults()
    action_module._set_args()
    action_module.source_dir = source_dir
    action_module.source_file = source_file
    action_module._set_root_dir()

    results, included_files = action_module.run()
    assert isinstance(results, dict)
    assert included_files == [source_file]

# Generated at 2022-06-11 11:53:38.087819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    # Test set dir args
    module._task.args = dict()
    module._task.args['dir'] = 'test_dir'
    module._task.args['depth'] = 1
    module._task.args['files_matching'] = '.*\.yml'
    module._task.args['ignore_files'] = '.*_ignore.yml'
    module._task.args['extensions'] = ['yml', 'yaml', 'json']
    module._task.args['ignore_unknown_extensions'] = True
    module._set_args()
    assert module.source_dir == 'test_dir'
    assert module.depth == 1
    assert module.files_matching == '.*\.yml'
    assert module.ignore_files == ['_ignore.yml']

# Generated at 2022-06-11 11:53:47.441703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    module_name = 'ansible.plugins.action.include_vars'
    module_path = __import__(module_name, fromlist=["ActionModule"])
    module_obj = module_path.ActionModule()
    module_obj._task = MockTask()
    module_obj._task._ds = MockDS()
    module_obj._task._ds._data_source = "tasks/main.yml"
    module_obj._task._ds._data_source = "tasks/main.yml"
    module_obj._task._role = MockRole()
    module_obj._task._role._role_path = "/path/to/roles/test_role"
    module_obj._set_args()
    module_obj._set_dir_defaults()
    module_obj._set_root

# Generated at 2022-06-11 11:53:55.662094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule('test_task', 'test_connection', 'test_play_context', 'test_loader', 'test_templar', 'test_shared_loader_obj')
    assert actionModule._task.action == 'test_task'
    assert actionModule._connection.connection == 'test_connection'
    assert actionModule._play_context.name == 'test_play_context'
    assert actionModule._loader.name == 'test_loader'
    assert actionModule._templar.name == 'test_templar'
    assert actionModule._shared_loader_obj.name == 'test_shared_loader_obj'

# Generated at 2022-06-11 11:53:56.347290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:54:21.743493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test ActionModule.__init__
    assert ActionModule is not None



# Generated at 2022-06-11 11:54:31.603070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # verify source_file
    assert ActionModule._set_args(None, 'file', 'myfile.yaml') == "myfile.yaml"
    # verify source_dir
    assert ActionModule._set_args(None, 'dir', 'mydir/') == "mydir/"
    # verify source_dir
    assert ActionModule._set_args(None, 'dir', './mydir') == "./mydir"
    # verify other
    assert ActionModule._set_args(None, 'file', 'myfile.yaml') == "myfile.yaml"
    # verify not valid argument
    assert ActionModule._set_args(None, 'file', 'myfile.yaml', 'notvalidargument') == "notvalidargument"

# Generated at 2022-06-11 11:54:41.017003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")

    class FakeTask:
        def __init__(self):
            self.args = {'hash_behaviour': None, 'name': None, 'dir': None, '_raw_params': '/home/test/test.yml'}

    class FakeActionModule:
        def __init__(self):
            self._task = FakeTask()
            self.check_mode = False
            self._loader = None
            self._find_needle = lambda self, dir, file: file
            self._set_root_dir = lambda self: None

    action_object = FakeActionModule()

    class FakeAnsibleModule:
        def __init__(self, tmp, task_vars):
            self.params = action_object._task.args
            self.tmp = tmp
            self.task

# Generated at 2022-06-11 11:54:52.458402
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test: assert object is instance of class
    task = ActionModule()
    assert isinstance(task, ActionModule)

    # test: assert task._task._ds is './test/unit/test_library/test_actions/test_include_vars.yml'
    task._task._ds = './test/unit/test_library/test_actions/test_include_vars.yml'

    # test: assert task.source_dir is None
    task.source_dir = None

    # test: assert task.source_file is './test/unit/test_library/test_vars/include_vars_source_file.yml'
    task.source_file = './test/unit/test_library/test_vars/include_vars_source_file.yml'

    # test: assert task

# Generated at 2022-06-11 11:55:02.766776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule
    """
    # TODO: test 'ActionModule._match_ignore_paths'
    from ansible.plugins.loader import action_loader
    action_class = action_loader.get('include_vars')
    action_module = action_class()

    action_module._task = FilePathsStub() # 'action_module' object has no attribute '_task'
    action_module.runner = FilePathsStub() # 'action_module' object has no attribute 'runner'

    # TODO: test 'action_module._set_root_dir'

    action_module.VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    action_module.VALID_

# Generated at 2022-06-11 11:55:04.274292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(loader=None, task=None, connection=None)
    assert module is not None

# Generated at 2022-06-11 11:55:16.232881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    from ansible.utils.vars import combine_vars

    # Test for incorrect input: dir and file options are used at the same time
    task_vars = dict()
    source_dir = tempfile.mkdtemp()
    action = ActionModule(dict(dir=source_dir, file="some_file"), tempfile.mkstemp()[1], tempfile.mkdtemp(), task_vars)
    assert 'You are mixing file only and dir only arguments, these are incompatible' in action.run()['message']

    # Test for incorrect input: input files are not dictionaries
    valid_extensions = ['yaml']

# Generated at 2022-06-11 11:55:26.223806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']
    assert action_module._reset_state() == None

# Generated at 2022-06-11 11:55:29.259516
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert obj not in [None,False]


# Generated at 2022-06-11 11:55:39.988575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    self = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    self._task = None
    self._task._role._role_path = ""
    self._task._ds = None
    self._task._ds._data_source = ""
    self._task.args = {
        'dir': None,
        'file': '',
        'depth': 0,
        'files_matching': '',
        'ignore_files': [],
        'ignore_unknown_extensions': False,
        'name': '',
        'hash_behaviour': None,
        'extensions': []
    }
    self.source_dir = ""
    self.source_file = ""
    self.depth = 0
   

# Generated at 2022-06-11 11:56:31.101596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    param = {}
    acme = ActionModule(dict(ANSIBLE_MODULE_ARGS=param), dict())
    result = acme.run()
    assert result['ansible_facts'] == {}
    assert result['failed'] == False
    assert result['_ansible_no_log'] == True

# Generated at 2022-06-11 11:56:41.078221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_ansible_vars = dict()
    test_ansible_vars['hostvars'] = dict()
    test_ansible_vars['hostvars']['server1'] = dict()
    test_ansible_vars['hostvars']['server1']['service1'] = dict()
    test_ansible_vars['hostvars']['server1']['service1']['servername'] = 'server1'
    test_ansible_vars['hostvars']['server1']['service1']['servicename'] = 'service1'
    test_ansible_vars['hostvars']['server2'] = dict()
    test_ansible_vars['hostvars']['server1']['service2'] = dict()
    test

# Generated at 2022-06-11 11:56:41.940653
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:56:51.809647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    import uuid
    import os

    # Create an ActionModule class object
    c = ActionModule()

    # Create an ansible task object
    class Task:
        class _ds:
            def __init__(self):
                self._data_source = "test"
        def __init__(self):
            self._ds = self._ds()
    t = Task()

    # Create a dict object to be passed as args to the run function
    dir_uuid = str(uuid.uuid4())
    file_uuid = str(uuid.uuid4())

# Generated at 2022-06-11 11:57:03.019139
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_module = ActionModule(
        task={"action": {"args": {"dir": "test_dir", "depth": "0", "files_matching": "", "ignore_files": "", "extensions": "yml"}}},
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert test_module.source_dir == "test_dir"
    assert test_module.depth == "0"
    assert test_module.files_matching == ""
    assert test_module.ignore_files == ""
    assert test_module.valid_extensions == 'yml'
    assert test_module.ignore_unknown_extensions == False
    assert test_module.hash_behaviour == None
    assert test_

# Generated at 2022-06-11 11:57:11.541327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    path = "test_path"
    task_vars = dict()
    action_module = ActionModule(path, task_vars)

    assert action_module._default_vars is None
    assert action_module._task.args == {}
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions',
                                                 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']
    assert action_module._task._ds is None
    assert action_

# Generated at 2022-06-11 11:57:12.092648
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:57:13.048210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:57:16.920036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ret = {
        'ansible_facts': {
            'A': 'ansible',
            'B': 'test'
        },
        'ansible_included_var_files': ['/test/test1.yml','/test/test2.yml']
    }



# Generated at 2022-06-11 11:57:26.710099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict()
    task['vars'] = dict()
    task['vars']['role_path'] = '/home/ansible/roles/cloudtest'
    task['vars']['role_name'] = 'cloudtest'

    args = dict()
    args['dir'] = 'vars'
    args['depth'] = 2
    args['ignore_files'] = ['*.yml']
    args['name'] = 'vars'

    new_action_module=ActionModule(task,args)
    assert args['dir'] == new_action_module.source_dir
    assert args['depth'] == new_action_module.depth
    assert args['name'] == new_action_module.return_results_as_name
    assert task['vars']['role_name'] == new_action_module._task

# Generated at 2022-06-11 11:59:27.083726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule("action_plugins/include_vars.py", "action_plugins", None, None, None, "/Users/liuliang/temp/t/action_plugins", "include_vars", None)
    assert actionModule is not None

# Generated at 2022-06-11 11:59:28.772377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.TRANSFERS_FILES == False



# Generated at 2022-06-11 11:59:37.043220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    source_dir = '/path/to/dir'
    depth = 0
    files_matching = 'blah'
    ignore_files = ['foo', 'bar']
    valid_extensions = ['yaml', 'json']
    hash_behaviour = 'merge'
    source_file = '/path/to/file'
    return_results_as_name = 'name'

    action_module = ActionModule()
    action_module._set_dir_defaults()
    action_base = ActionBase()
    vm = VariableManager()
    inventory = InventoryManager(host_list=[])
    play_

# Generated at 2022-06-11 11:59:47.596657
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook import Play
    from ansible.playbook import Playbook
    # Create Task object with empty args dict
    task = Task()
    task._role = None
    task._ds = None
    task._parent = Task()
    task._role = Task()
    task._ds = Task()
    task._task_include = TaskInclude()
    task._task_include._parent = TaskInclude()
    task._task_include._play = Play()
    task._task_include._play._playbook = Playbook()

    # Create ActionModule object
    am = ActionModule(task, dict())

    # Update the task args with the source dir argument
    task.args = dict()
    task.args

# Generated at 2022-06-11 11:59:56.793247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    task_vars = {}
    options = {
        '_raw_params' : 'vars/main.yml',
        'hash_behaviour': 'replace'
    }
    task = {
        'args': options
    }

    module._task = task

    # Mock methods

    class _ds:
        @staticmethod
        def _data_source():
            return './'

    class _role:
        @staticmethod
        def _role_path():
            return './'

    module._ds = _ds
    module._role = _role

    module._set_dir_defaults = lambda: None
    module._set_args = lambda: None
    module._set_root_dir = lambda: None
    module._traverse_dir_depth = lambda: []
    module._

# Generated at 2022-06-11 12:00:04.671606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']


# Generated at 2022-06-11 12:00:14.344921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an object of the class ActionModule
    am = ActionModule()
    # create a dictionary
    results = {}

    # create an object of the class Task
    task = MagicMock()

    # set _task variable in the ActionModule class
    am._task = task

    # set args variable in the Task class
    task.args = {
        'hash_behaviour': '',
        'name': '',
        'dir': '',
        'file': '',
        'depth': '',
        'files_matching': '',
        'ignore_unknown_extensions': '',
        'ignore_files': '',
        'extensions': '',
    }

    # set _role variable in the Task class
    task._role = ''

    # set _ds variable in the Task class
    task._ds = ''



# Generated at 2022-06-11 12:00:21.255606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.include_vars
    from ansible.plugins.action.include_vars import ActionModule
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    import ansible.constants as C
    from ansible.errors import AnsibleError
    import os
    import tempfile

    def mock_path_exists(path):
        return True

    def mock_get_loader(self, path):
        return self._loader


# Generated at 2022-06-11 12:00:30.014434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    source_dir = "/my/dir"
    hash_behaviour = "replace"
    return_results_as_name = "myname"
    files_matching = "file.*"
    depth = 1
    ignore_files = ["*.bak"]
    ignore_unknown_extensions = True
    valid_extensions = ["yml","yaml"]
    source_file = "/my/file.yml"
    _raw_params = source_file
    role_path = "//role/path"
    role_vars_path = "/role/path/vars/main.yml"
    data_source_path = "/my/data/source/path"
    current_dir = "/my/data/source"

# Generated at 2022-06-11 12:00:39.724716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    import ansible.executor.task_queue_manager as T

    module_name = 'include_vars'

    # Create a ActionModule instance with _task
    my_task = TaskInclude(
        play=dict(name='test', hosts=[], roles=[], vars=[], tasks=[])
    )
    my_task._role = dict()
    my_task._ds = dict()
    my_task._role._role_path = "tests/unit/modules/include_vars_dir/"
    my_task._ds._data_source = "tests/unit/modules/include_vars_dir/main.yml"

    my_