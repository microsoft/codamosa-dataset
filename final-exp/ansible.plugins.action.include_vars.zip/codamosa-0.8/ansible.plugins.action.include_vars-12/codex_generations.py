

# Generated at 2022-06-11 11:52:58.339967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:52:58.974224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:53:02.142398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('copy', {'a': 1, 'b': 2})
    assert(action.name == 'copy')
    assert(action.args == {'a': 1, 'b': 2})

# Generated at 2022-06-11 11:53:11.824433
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    fail_msg = ""
    f = ActionModule()

    # This test generates an AnsibleError as the arg 'files_matching' must be a string
    args = dict()
    args['files_matching'] = [1, 2, 3]
    args['file'] = '/path/to/my_file.yml'
    task_vars = dict()
    with pytest.raises(AnsibleError) as e:
        # This test generates an AnsibleError as the arg 'files_matching' must be a string
        f.run(task_vars=task_vars, **args)
    assert "files_matching must be a string" in to_text(e.value)


    # This test generates an AnsibleError as the arg 'extensions' must be a list

# Generated at 2022-06-11 11:53:18.848734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Run the test unit for method run of class ActionModule.
    """
    # Without hash_behaviour
    module = MockActionModule()
    module._task = MockTask()
    module._task._ds = MockDatasource()
    module._task._ds._data_source = "/tmp/test-include-vars-role/tasks/main.yml"
    module._task.args = {
        'name': 'test_include_vars',
        'dir': 'tests/files/valid_dir',
        'ignore_files': ['main.yml']
    }
    module.run()

# Generated at 2022-06-11 11:53:31.293936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # some random data to use as input
    task = {
        '_attributes': {
            ('a', 'b'): {
                'string': 'the value of a/b/string',
                'int': 1,
                'dict': {
                    'a': {'a': 1, 'b': 2, 'c': 3},
                    'b': ['a', 1, 'b', 2, 'c', 3],
                    'c': {'a': 'a', 'b': 'b', 'c': 'c'}
                }
            }
        }
    }

    # expected_result is the expected output from run() method

# Generated at 2022-06-11 11:53:36.336289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test objects
    fake_task = type("FakeTask", (object,), {
        "_role": None,
        "_ds": None,
        "args": {
            "name": None,
            "file": None,
            "_raw_params": None,
            "hash_behaviour": None,
            "dir": None,
            "depth": None,
            "files_matching": None,
            "ignore_files": None,
            "ignore_unknown_extensions": False
        }
    })


# Generated at 2022-06-11 11:53:40.890834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of the ActionModule
    action_module = ActionModule()
    # Check if the object is an instance of `ActionModule`
    assert isinstance(action_module, ActionModule)
    # Check if the object is an instance of `ActionBase`
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-11 11:53:49.176415
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    path_to_file = 'resources/var_file.yml'
    with open(path_to_file, 'r') as f:
        yml_data = f.read()

    action = ActionModule({'_ansible_no_log': False, '_ansible_verbosity': 2, '_ansible_syslog_facility': 'LOG_USER',
                           '_ansible_debug': False})
    action._loader = DictDataLoader({path_to_file: yml_data})
    action._task = Task()
    action._task.args = {'file': path_to_file}
    action._task.action = 'include_vars'
    action._shared_loader_obj = False

    result = action.run(task_vars={})

# Generated at 2022-06-11 11:53:50.167225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:54:14.201621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:54:24.883394
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up a valid  environment
    task_vars = dict(foo='bar')
    tmp = path.join(C.DEFAULT_LOCAL_TMP, 'ansible_test.tmp')
    role_path = path.join(tmp, 'roles', 'foo', 'vars')

    args = dict(
        _raw_params=path.join(role_path, 'main.yml')
    )

    # Create _task
    from ansible.playbook.task import Task
    _task = Task()
    _task._role = object()
    _task._role._role_path = path.join(tmp, 'roles', 'foo')
    _task.args = args

    # Create _loader
    from ansible.parsing.dataloader import DataLoader
    _loader = DataLoader()


# Generated at 2022-06-11 11:54:26.588306
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('test_action_module', {}, {}, {})

test_ActionModule()

# Generated at 2022-06-11 11:54:34.144059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert hasattr(ActionModule, 'show_content')
    assert hasattr(ActionModule, 'included_files')
    assert hasattr(ActionModule, 'VALID_FILE_EXTENSIONS')
    assert hasattr(ActionModule, 'VALID_DIR_ARGUMENTS')
    assert hasattr(ActionModule, 'VALID_FILE_ARGUMENTS')
    assert hasattr(ActionModule, 'VALID_ALL')


# Generated at 2022-06-11 11:54:35.069230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:54:41.330221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {'a': 'foo'}
    ansible_args = {'dir': 'inventory/group_vars/',
                    'depth': 0,
                    'files_matching': "*var_file.yml",
                    'ignore_files': ".*,*var_file.yml",
                    'ignore_unknown_extensions': False}
    action = ActionModule()
    action._task = {'args': ansible_args}
    result = action.run(task_vars=task_vars)
    assert result['ansible_facts']['bar_var'] == 'bar'

# Generated at 2022-06-11 11:54:42.316726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-11 11:54:43.521710
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:54:54.914644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup some arguments
    args = {
        "name": "test1",
        "hash_behaviour": "replace",
        "file": "/etc/ansible/vars/test1.yaml"
    }

    # Create an instance of the module
    module = ActionModule(load_from_file=False, arguments=args, task_ds=dict())

    # Create an instance of an AnsibleTask
    task = AnsibleTask(load_from_file=False, task_ds=dict())

    # Set the module task
    module._task = task

    # Assign role to task
    module._task._role = None

    # Create a loader object

# Generated at 2022-06-11 11:55:04.503745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins.action import ActionBase
    
    class FakeTask:
        def __init__(self, args):
            self.args = args

        def _get_action_args(self):
            return self.args

    class FakeModule:
        def __init__(self, action_name, action_args):
            self.action_name = action_name
            self.action_args = action_args

        def _get_action_args(self):
            return self.action_args

    class FakePlayContext:
        def __init__(self, tmp_path, task_vars=None, variable_manager=None):
            self.tmp_path = tmp_path
            self.task_vars = task_vars
            self.variable

# Generated at 2022-06-11 11:55:58.148059
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:56:01.508038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    results = ActionModule.run(None, None)
    expected = {'ansible_facts': {}, 'ansible_included_var_files': []}
    assert expected == results

# Generated at 2022-06-11 11:56:05.203952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fixture for this test case
    fixture = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert False == fixture.run()

# Generated at 2022-06-11 11:56:06.509761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a


# Generated at 2022-06-11 11:56:17.076760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task = dict()
    _task['args'] = dict()
    _task['args']['files_matching'] = 'vars.yaml$'
    _task['args']['dir'] = '/home/asa/ansible/ansible-module-vars-2.3.0.0/test/unit/tmp/vars/test'
    _task['args']['depth'] = 1
    _task['args']['name'] = 'results'
    _task['args']['ignore_files'] = '.*'
    _task['args']['extensions'] = ['yaml']
    _task['_role'] = dict()

# Generated at 2022-06-11 11:56:21.311895
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert am.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-11 11:56:22.543638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-11 11:56:25.910983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task_ds=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-11 11:56:27.922467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Running unit tests for ActionModule.run()')
    # Execute run method

    # Check results

# Generated at 2022-06-11 11:56:38.259083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_values = [
        {'name': 'name', 'hash_behaviour': 'hash_behaviour', 'source_dir': 'source_dir', 'source_file': 'source_file', 'depth': 'depth', 'files_matching': 'files_matching', 'ignore_unknown_extensions': 'ignore_unknown_extensions', 'ignore_files': 'ignore_files', 'valid_extensions': 'valid_extensions', '_task': {'_ds': {'_data_source': '_data_source'}, '_role': {'_role_path': '_role_path'}}}
    ]

# Generated at 2022-06-11 11:58:31.619409
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    test_dir = os.path.dirname(os.path.abspath(__file__))
    role_path = path.join(test_dir,'../role_test/roleA')
    task = dict()
    task['vars'] = dict()
    task['vars']['task_vars'] = dict()
    task['args'] = dict()
    task['args']['dir'] = 'vars'
    action_module = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task._role = dict()
    action_module._task._role._role_path = role_path
    action_module._set_root_dir()
    assert action_module.source_dir

# Generated at 2022-06-11 11:58:39.693037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing that source_dir is not set and raises an AnsibleError
    # This can be improved when _set_dir_defaults is re-written to
    # handle this situation.
    return_values = dict(
        failed=False,
        changed=False,
        _ansible_verbose_always=True,
        _ansible_no_log=False,
        ansible_included_var_files=[],
        ansible_facts=dict()
    )

    action_module = ActionModule()
    action_module._task = FakeTask()
    action_module._task.args = {}
    action_module._set_dir_defaults()
    action_module._set_args()
    action_module.ACTION_WARNINGS = []
    action_module.ACTION_DEPRECATIONS = []
    action_module.ACTION

# Generated at 2022-06-11 11:58:42.700260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module is not None

# Generated at 2022-06-11 11:58:52.389567
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    obj = ActionModule()
    tmp = None
    # 1. check_type_arguments: return error if arguments are invalid
    task_vars = {
        'ansible_env': {
            'password': 'secret'
        }
    }

# Generated at 2022-06-11 11:58:53.191277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:59:03.196218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def _task_vars(vars):
        return {'name': '', 'vars': vars}

    # dir
    _task_args = {
        'dir': 'dir', 'depth': 0, 'files_matching': None,  'ignore_files': None, 'extensions': None,
        'ignore_unknown_extensions': False
    }
    _task_run_args = {
        'task_vars': _task_vars({'name': '', 'vars': {'a': 'alpha', 'b': 'bravo'}})
    }


# Generated at 2022-06-11 11:59:14.717440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os.path

    from ansible.errors import AnsibleError
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader

    class AnsiblePlay(object):
        def __init__(self):
            self.ROOT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../')

        def get_variable_manager(self):
            return VariableManager()

    class AnsibleTask(object):
        def __init__(self):
            self.args = {
                'dir': 'vars_dir/'
            }
            self._role = AnsibleRole()

   

# Generated at 2022-06-11 11:59:15.764866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a != None

# Generated at 2022-06-11 11:59:26.717543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a simple dictionary with name of the member defined in class ActionModule
    task_vars = dict(vars=dict(
        name='new_name',
        hash_behaviour='replace',
        dir='.',
        depth=1,
        files_matching=None,
        ignore_files='7',
        extensions='yaml,yml,json',
        ignore_unknown_extensions=False,
        file='vars.yml',
        _raw_params='vars.yml',
    ))
    # Create a simple dictionary with name of the member defined in class ActionBase
    task = dict(
        role=None,
        args=dict(),
        _role=None,
        _ds=dict(_data_source='/templates'),
        delegate_to='new_name'
    )

# Generated at 2022-06-11 11:59:34.482088
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import unittest
    import os
    import sys

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            # Adjust sys.path to allow importing ansible.module_utils.basic and
            # ansible.module_utils.facts.
            sys.path.insert(0, os.path.abspath('..'))
            sys.path.insert(0, os.path.abspath('../..'))
            global ActionModule
            from ansible.plugins.action.include_vars import ActionModule

        def tearDown(self):
            # Restore sys.path
            sys.path.pop(0)
            sys.path.pop(0)
            self.action_module = None
