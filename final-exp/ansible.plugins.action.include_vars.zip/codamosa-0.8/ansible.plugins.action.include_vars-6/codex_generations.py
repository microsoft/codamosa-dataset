

# Generated at 2022-06-11 11:53:00.597478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:53:10.645866
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:53:12.188265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'task', 'loader', 'templar', 'shared_loader_obj')

# Generated at 2022-06-11 11:53:17.302233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-11 11:53:21.130995
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module = ActionModule(None, None)
    except Exception as err:
        print(err)
        raise err

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 11:53:33.629312
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    task = Task()
    # Adding params to task
    task.args = {
        'dir': 'vars'
    }
    task_ds = task._ds
    if hasattr(task, '_ds'):
        delattr(task, '_ds')
    task._ds = task_ds

    play_context = PlayContext()
    play_context.check_mode = False
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    variable_manager.set_nonpersistent_facts(variable_manager._fact_cache)


# Generated at 2022-06-11 11:53:35.012375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:53:45.343370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up a fake module, for testing purposes
    class FakeModule():
        def __init__(self, args):
            self.args = args
    # Set up a fake loader, for testing purposes
    class FakeLoader():
        def __init__(self, results):
            self.results = results
        def load(self, data, file_name=None, show_content=False):
            return self.results
    # Set up a fake datastore, for testing purposes
    class FakeDatastore():
        def __init__(self, data_source):
            self._data_source = data_source
    # Set up a fake role, for testing purposes
    class FakeRole():
        def __init__(self, role_path):
            self._role_path = role_path

# Generated at 2022-06-11 11:53:57.366014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import shutil
    import sys

    # Mock the args passed to the execute method of the super class
    class MockArgs(dict):
        def __init__(self):
            self._raw_params = None
            self.dir = None
            self.file = None
            self.files_matching = None
            self.ignore_files = None
            self.depth = None
            self.name = None
            self.hash_behaviour = None

    class MockVars(dict):
        def __init__(self):
            pass        

    def create_yaml_file(filename, file_content):
        with open(filename, 'w') as f:
            for line in file_content:
                f.write(line + '\n')


# Generated at 2022-06-11 11:54:09.006089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Import necessary moduls
    import unittest
    from unittest.mock import Mock
    from unittest.mock import MagicMock
    from ansible.utils.vars import combine_vars

    # Set all necessary arguments for ActionModule.run
    # result = run(self, tmp=None, task_vars=None)
    # result = run(self, tmp=None, task_vars=None)
    # result = dict(); result['ansible_facts']; result['ansible_included_var_files']; result['_ansible_no_log']
    # tmp is not used
    tmp = None

    # task_vars is a dict()
    task_vars = dict()

    # Mock structure for args of run
    # result['ansible_facts'].update(loaded_data)

# Generated at 2022-06-11 11:54:42.386476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_text
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.utils.vars import isidentifier
    from ansible.vars.manager import VariableManager

    class MyActionModule(ActionModule):
        TRANSFERS_FILES = False

        VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
        VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']

# Generated at 2022-06-11 11:54:43.622397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #precondition
    pass

# Generated at 2022-06-11 11:54:55.015349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_data = {'ansible_facts': {'test_key': 'test_value'}}
    am = ActionModule(dict())
    am.included_files = ['test_file']
    am.show_content = True
    assert am.run() == {'ansible_included_var_files': ['test_file'],
                        '_ansible_no_log': False,
                        'ansible_facts': {},
                        'failed': True,
                        'message': 'include_vars requires at least one of these parameters: dir, file'}

    with pytest.raises(AnsibleError):
        am.run(task_vars=dict(am_ret=test_data))

    # dir
    test_vars = dict(am_ret=dict(ansible_facts=dict()))
   

# Generated at 2022-06-11 11:55:04.597372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor for ActionModule:
    #def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):

    from ansible.plugins import module_loader, connection_loader
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleParserError
    import pytest
    # Task
    action = 'include_vars'
    args = {'name': 'var_name'}
    delegate_to = None
    loop = None

# Generated at 2022-06-11 11:55:05.220891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:55:17.503038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test to test method run of class ActionModule.
        Args:
            filename (str): The source file.

        Returns:
            Tuple (bool, str, dict)
    """
    import json
    import logging

    import pytest

    from ansible.executor.task_result import TaskResult
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.parsing.vault import VaultLib

    # Define files and directories
    file = "test.yml"
    test_value = 5
    test_value_2 = 1
    test_module_dir = 'test_module_dir'
    test_

# Generated at 2022-06-11 11:55:22.221015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import tempfile
    from ansible import context
    from ansible.errors import AnsibleError
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.include_vars import ActionModule
    from ansible.utils.vars import combine_vars
    from pytest import raises

# Generated at 2022-06-11 11:55:30.429980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.module_utils.basic 
    import ansible.module_utils.facts 
    import ansible.module_utils.parsing.convert_bool 
    import ansible.module_utils.six 
    import ansible.module_utils.urls 
    import ansible.module_utils.netconf 
    import ansible.module_utils.network.common.utils 
    import ansible.module_utils.network.icx.icx 
    import ansible.module_utils.urls 
    import ansible.module_utils.urls 
    import ansible.module_utils.urls 
    import ansible.module_utils.urls 
    import ansible.module_utils.urls 
    import ansible.module_utils.urls 
    import ansible.module

# Generated at 2022-06-11 11:55:38.628467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = ansible.parsing.dataloader.DataLoader()
    action_module._task._role = ansible.parsing.dataloader.DataLoader()
    action_module._task._ds = ansible.parsing.dataloader.DataLoader()
    # act
    res = action_module.run()
    # assert
    assert res is not None, 'result should not be None'
    assert res['ansible_included_var_files'] == [], 'result should not be empty'

# Generated at 2022-06-11 11:55:49.360738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # an inventory/hosts/group vars files
    test_path = "./test/unit"
    # an include vars role
    role_path = "./test/unit/roles/include_vars_role"


# Generated at 2022-06-11 11:56:45.895436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    variable_manager = VariableManager()
    variable_manager.set_inventory(None)

    test_path = path.join(path.dirname(__file__), 'test_data')

    test_play = Play.load(dict(), variable_manager=variable_manager, loader=None, use_handlers=False)

    test_task = Task()
    test_task._

# Generated at 2022-06-11 11:56:57.058401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit tests for ActionModule constructor.
    """
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars

# Generated at 2022-06-11 11:56:59.572730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()

    assert obj.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

# Generated at 2022-06-11 11:57:09.432898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dirs = 0
    files = 0
    for arg in exception.args:
        if arg in VALID_DIR_ARGUMENTS:
            dirs += 1
        elif arg in VALID_FILE_ARGUMENTS:
            files += 1
        elif arg in VALID_ALL:
            pass
        else:
            raise AnsibleError('{0} is not a valid option in include_vars'.format(to_native(arg)))

    if dirs and files:
        raise AnsibleError("You are mixing file only and dir only arguments, these are incompatible")

    # set internal vars from args
    self._set_args()

    results = dict()
    if self.source_dir:
        self._set_dir_defaults()
        self._set_root_dir()

# Generated at 2022-06-11 11:57:18.707817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from units.mock.loader import DictDataLoader
    import pytest


# Generated at 2022-06-11 11:57:25.650363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(
        task=dict(
            _ds=dict(
                _data_source='/var/lib/awx/projects/files/myfile'
            ),
            args=dict(
                file='/var/lib/awx/projects/files/myfile',
                _raw_params='/var/lib/awx/projects/files/myfile'
            )
        )
    )
    assert mod.source_dir is None
    assert mod.source_file == '/var/lib/awx/projects/files/myfile'

# Generated at 2022-06-11 11:57:26.243446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ TODO """

# Generated at 2022-06-11 11:57:27.646965
# Unit test for constructor of class ActionModule
def test_ActionModule():
	# Object type test
	assert isinstance(ActionModule("test.data"), dict)

# Generated at 2022-06-11 11:57:28.373258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:57:37.891062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests import unittest

    ans_return = {
        'ansible_facts': {
            'var_to_include': {'key': 'value'}
        },
        'failed': False,
        '_ansible_no_log': True
    }

    def _get_task_args(*args, **kwargs):
        return {'file': './tests/include1.yml'}

    def _check_args(self, key, value):
        assert key in self._task.args
        assert self._task.args[key] == value

    def _task_vars_set(self, key, value):
        assert key in self._task.vars
        assert self._task.vars[key] == value


# Generated at 2022-06-11 11:58:43.458352
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:58:53.414447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' generate a mock task, and then tests various paths through the run() '''
    # setup the ActionModule and task with a valid combination of dir and depth
    am = ActionModule()
    task = mock.Mock()
    task.args = {
        'dir': 'test/test_action_module/testdata',
        'name': 'test_name',
        'ignore_files': ['.*.yml'],
        'depth': 1
    }
    am._task = task
    am._set_root_dir = mock.Mock()
    am._traverse_dir_depth = mock.Mock()
    am._load_files_in_dir = mock.Mock()

# Generated at 2022-06-11 11:59:03.319087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.args = {
        "dir": "/home/user/ansible-playbook/vars",
        "name": "test_name",
        "depth": 1234,
        "files_matching": "main.yml",
        "ignore_files": "ignore_files",
        "ignore_unknown_extensions": True,
        "extensions": [".yml"],
        "hash_behaviour": "merge",
        "_raw_params": "raw_params"
    }
    module._set_args()
    assert module.hash_behaviour == 'merge'
    assert module.return_results_as_name == 'test_name'
    assert module.source_dir == '/home/user/ansible-playbook/vars'
    assert module.source_file

# Generated at 2022-06-11 11:59:14.917932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Create an instance of ActionModule class and check if all the instance
    variables are correct.
    '''
    try:
        import ansible
    except Exception:
        print('Error: unable to import ansible.')
        exit(1)
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    pb = Playbook()
    play_context = PlayContext()

    play_context.clear_facts = False

# Generated at 2022-06-11 11:59:19.203821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test the constructor of class ActionModule"""
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition

    task = Task()
    task._role = RoleDefinition()
    task._role._role_path = '/home/vagrant/test'
    task._ds = PlayContext()
    task._ds._data_source = '/home/vagrant/test/vars/file.yaml'
    task._ds._playbook_dir = '/home/vagrant/test'

    task.args = dict(
        dir='/home/vagrant/test'
    )

    assert ActionModule(task, dict()).source_dir == '/home/vagrant/test'


# Generated at 2022-06-11 11:59:19.920538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:59:30.484354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    sys.path.append("../")
    from ansible import context
    import ansible.plugins.action.include_vars
    from ansible.utils.vars import merge_hash
    from ansible_collections.ansible.netcommon.plugins.action import include_vars

    context._init_global_context(loader=None)

    task_vars = dict()
    source_dir = "."

    am = include_vars.ActionModule(None, None, None, None, None, None)
    print(am.run(tmp=None, task_vars=task_vars))

    source_dir = "./tests"
    am.source_dir = source_dir
    print(am.run(tmp=None, task_vars=task_vars))


# Generated at 2022-06-11 11:59:31.700332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert(action is not None)

# Generated at 2022-06-11 11:59:37.391687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert am.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-11 11:59:46.806996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)

    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'], module.VALID_FILE_EXTENSIONS
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'], module.VALID_DIR_ARGUMENTS
    assert module.VALID_FILE_ARGUMENTS == ['file', '_raw_params'], module.VALID_FILE_ARGUMENTS
    assert module.VALID_ALL == ['name', 'hash_behaviour'], module.VALID_ALL


# Generated at 2022-06-11 12:00:45.111456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import shutil
    import sys
    import yaml

    class TestActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            super(TestActionModule, self).__init__(*args, **kwargs)
            self._task_vars = {}

        def run(self, *args, **kwargs):
            return super(TestActionModule, self).run(task_vars=self._task_vars, *args, **kwargs)

    class TestLoader:
        def __init__(self):
            self.files = {}

        def load(self, data, file_name=None, show_content=True):
            return yaml.load(data)


# Generated at 2022-06-11 12:00:50.294723
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action = ActionModule()
    assert isinstance(test_action, ActionBase)
    assert isinstance(test_action.VALID_FILE_EXTENSIONS, list)
    assert isinstance(test_action.VALID_DIR_ARGUMENTS, list)
    assert isinstance(test_action.VALID_FILE_ARGUMENTS, list)
    assert isinstance(test_action.VALID_ALL, list)
    assert test_action.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:00:51.588842
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # name is required by ActionBase
    m = ActionModule({'name': 'test'})
    return m

# Generated at 2022-06-11 12:00:57.863555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task:
        def __init__(self, args):
            self.args = args

    class Play:
        def __init__(self):
            self.vars = {}

    class PlayContext:
        def __init__(self, vars):
            self.vars = vars

    def get_vars(self, *args, **kwargs):
        return self.vars

    PlayContext.get_vars = get_vars

    class Role:
        def __init__(self, role_path):
            self.role_path = role_path

    class DataSource:
        def __init__(self, data_source):
            self.data_source = data_source

    class TaskDS:
        def __init__(self, ds):
            self._ds = ds


# Generated at 2022-06-11 12:00:58.319347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:01:04.935620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostvars = {"ansible_connection": "local"}
    loader = None
    play_context = None
    task_vars = {"ansible_connection": "local"}
    task = ActionModule(hostvars, loader, play_context, task_vars)
    task_vars["ansible_connection"] = "local"
    task._task.args = {'dir': 'tasks'}
    task._task.args = {'file': 'tasks/main.yml', '_raw_params': 'tasks/main.yml'}
    out = task.run(task_vars=task_vars)
    assert out['_ansible_no_log'] == True

# Generated at 2022-06-11 12:01:13.220576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_values = {
        'hash_behaviour': None,
        'return_results_as_name': None,
        'source_dir': '/usr/local',
        'source_file': None,
        'depth': None,
        'files_matching': None,
        'ignore_unknown_extensions': False,
        'ignore_files': ['*.py', '*.pyc'],
        'valid_extensions': ['yaml', 'yml', 'json']
    }
    test_result = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert isinstance(test_result.VALID_FILE_EXTENSIONS, list)
    assert isinstance

# Generated at 2022-06-11 12:01:20.752712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict()
    task['args'] = dict()
    task['args']['dir'] = "dir"
    task['args']['depth'] = 2
    task['args']['files_matching'] = 'files_matching'
    task['args']['extensions'] = 'extensions'
    task['args']['ignore_files'] = 'ignore_files'
    task['args']['ignore_unknown_extensions'] = 'ignore_unknown_extensions'

    test_case = ActionModule(task, dict())

    assert(test_case.hash_behaviour == None)
    assert(test_case.return_results_as_name == None)
    assert(test_case.ignore_unknown_extensions == 'ignore_unknown_extensions')


# Generated at 2022-06-11 12:01:28.179289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Run tests for class ActionModule.
    """
    import pytest

    from ansible.template import Templar

    from ansible.vars import VariableManager

    from ansible.utils.vars import combine_vars

    from ansible.utils.unsafe_proxy import wrap_var, AnsibleUnsafeText

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition

    variable_manager = VariableManager()

    # Create a faked out task object. Add a valid task object to the
    # playbook, add dataloader, PlayContext and connection
    # attributes to the object.
    task_obj = TaskInclude()


# Generated at 2022-06-11 12:01:30.229530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    kwargs = {}
    kwargs['action'] = ActionModule()
    #kwargs['action'].set_task({'args':{'file':'./data/cisco/ios_facts.yaml'}})