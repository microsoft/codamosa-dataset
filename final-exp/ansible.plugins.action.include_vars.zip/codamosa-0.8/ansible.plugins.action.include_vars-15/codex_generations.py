

# Generated at 2022-06-11 11:53:05.888517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.include_vars as include_vars

    object_ = include_vars.ActionModule('test_task', 'test_play', dict(), 0, dict())
    assert object_._task.args.get('file', None) is None
    assert object_._task.args.get('dir', None) is None
    assert object_._task.args.get('name', None) is None

# Generated at 2022-06-11 11:53:10.960397
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Define a class to use
    class task(object):
        def __init__(self):
            self.args = dict()
    class play(object):
        def __init__(self):
            self.vars = dict()
    class tqm(object):
        def __init__(self):
            self.name = "sample"
    class loader(object):
        def __init__(self):
            pass
        def load(self, value, file_name=None, show_content=False):
            return dict()

    # Create instances
    loader_instance = loader()
    tqm_instance = tqm()
    play_instance = play()
    task_instance = task()
    task_instance._role = play_instance
    task_instance._ds = play_instance
    task_instance.args

# Generated at 2022-06-11 11:53:21.286266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_dir = 'dir'
    test_depth = 0
    test_files_matching = 'yml'
    test_ignore_files = ['.gitignore', '.*']
    test_extensions = ['yaml', 'yml']
    test_ignore_unknown_extensions = False
    test_name = 'name'
    test_hash_behaviour = 'replace'

    # Test the constructor when source_dir is set and all the arguments have been passed by the user
    arg_vals_source_dir = dict()
    arg_vals_source_dir['dir'] = test_dir
    arg_vals_source_dir['depth'] = test_depth
    arg_vals_source_dir['files_matching'] = test_files_matching
    arg_vals_source_dir['ignore_files'] = test_ignore_

# Generated at 2022-06-11 11:53:22.728835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_obj = ActionModule()

# Generated at 2022-06-11 11:53:35.227225
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class FakeTaskVars(object):
        def __init__(self, **kwargs):
            self.__dict__ = kwargs

    #
    # Test with simple params by file
    #
    module = ActionModule()
    module._task_vars = FakeTaskVars(
        playbook_dir='/home/user/ansible/project',
        playbook_file='/home/user/ansible/project/site.yml'
    )

# Generated at 2022-06-11 11:53:36.409492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass  # TODO: write unit test

# Generated at 2022-06-11 11:53:40.937244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    this_action = ActionModule()
    result = this_action.run(None, None)
    assert result['message'] == ('Missing required arguments: file')

    result = this_action.run(None, {'ansible_verbosity': 3})
    assert result['message'] == ('Missing required arguments: file')

# Generated at 2022-06-11 11:53:41.603721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:53:42.276256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:53:46.661148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This is a unit test for the method run of class ActionModule.
    """
    # initialize a class ActionModule and create the function _set_args
    class_ActionModule = ActionModule()
    class_ActionModule._set_args = ActionModule._set_args
    class_ActionModule.VALID_FILE_EXTENSIONS = ActionModule.VALID_FILE_EXTENSIONS
    class_ActionModule.VALID_DIR_ARGUMENTS = ActionModule.VALID_DIR_ARGUMENTS
    class_ActionModule.VALID_FILE_ARGUMENTS = ActionModule.VALID_FILE_ARGUMENTS
    class_ActionModule.VALID_ALL = ActionModule.VALID_ALL
    class_ActionModule._set_dir_defaults = ActionModule._set_dir_defaults
    class_ActionModule._tra

# Generated at 2022-06-11 11:54:20.945020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit tests for the run method of the ActionModule class """
    import pytest
    from ansible.plugins.action.include_vars import ActionModule
    from ansible.module_utils.six import string_types

    # Create our own action module object
    apm = ActionModule(
        task=dict(vars=dict()),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    test_vars = dict(
        foo=dict(
            bar=dict(
                baz=True
            )
        ),
        test=True
    )


# Generated at 2022-06-11 11:54:24.924548
# Unit test for constructor of class ActionModule
def test_ActionModule():
	actionmodule = ActionModule(ActionModule)
	print("Test Passed: ActionModule")
try:
	if __name__ == '__main__':
		test_ActionModule()
except:
	print("ActionModule Test failed")
	raise


# Generated at 2022-06-11 11:54:36.207056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance = ActionModule()

    print(instance.VALID_FILE_EXTENSIONS)
    print(instance.VALID_DIR_ARGUMENTS)
    print(instance.VALID_FILE_ARGUMENTS)
    print(instance.VALID_ALL)

    #print(instance.VALID_DIR_ARGUMENTS.index('dir'))
    #print(instance.VALID_DIR_ARGUMENTS[0])
    #print(instance.VALID_DIR_ARGUMENTS[0:])
    #print(instance.VALID_DIR_ARGUMENTS[:3])
    #print(instance.VALID_DIR_ARGUMENTS[1:3])

    #print(instance.VALID_FILE_ARGUMENTS.index('file'))
    #print(instance.VALID_FILE

# Generated at 2022-06-11 11:54:36.848273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:54:43.568768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook import Play
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence
    import ansible.constants as C
    import ansible.module_utils.six as six


# Generated at 2022-06-11 11:54:54.967031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test Configurations
    module_arguments_file_only = {
        "_raw_params": "test_file.yml"
    }

    module_arguments_dir_only = {
        "dir": "./",
        "extensions": "yml"
    }

    module_arguments_dir_only_not_exist = {
        "dir": "./not_exist_dir",
        "extensions": "yml"
    }

    module_arguments_file_only_not_exist = {
        "_raw_params": "./not_exist_file.yml"
    }

    task_vars = dict()

    # Initiate and run

# Generated at 2022-06-11 11:55:04.536274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

# Generated at 2022-06-11 11:55:05.480435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:55:17.800707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock objects
    mock_tmp = None
    mock_task_vars = None
    mock_show_content = True
    mock_included_files = []
    mock_return_results_as_name = None
    mock_source_dir = None
    mock_source_file = None
    mock_depth = None
    mock_files_matching = None
    mock_ignore_unknown_extensions = False
    mock_ignore_files = None
    mock_valid_extensions = ['yaml', 'yml', 'json']
    mock_hash_behaviour = None
    mock_loader = 'mock_loader'
    mock_task = 'mock_task'

    # create object
    obj = ActionModule(mock_task, mock_loader, mock_tmp)
    # set attributes

# Generated at 2022-06-11 11:55:27.974943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule.
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from __main__ import display
    from ansible.inventory.host import Host

    yml_content = b"""
    x: 172.16.1.1
    y: 127.0.0.1
    """

    class ActionModuleTest(ActionModule):
        pass

    results = dict()
    mocker.patch('ansible.utils.vars.combine_vars', lambda x, y, z, w=None: results.update(y))
    mocker.patch('ansible.module_utils._text.to_text', lambda x, y: x)

# Generated at 2022-06-11 11:56:21.990509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        {"ansible_facts":{}},
        {"name":"test_name",
         "hash_behaviour":C.DEFAULT_HASH_BEHAVIOUR,
         "dir":"test_dir",
         "depth":0,
         "files_matching":"test_file_matching",
         "ignore_files":["test_ignore_files"],
         "ignore_unknown_extensions":False,
         "extensions":["yaml", "yml", "json"],
         "_ansible_no_log":True,
         "_ansible_verbosity":0,
         "ansible_check_mode":True,
         "ansible_version":{}
        }
    )
    assert am.return_results_as_name == "test_name"

# Generated at 2022-06-11 11:56:23.158054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:56:24.024379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:56:26.338429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action_module = ActionModule()
    assert isinstance(test_action_module, ActionModule)

# Generated at 2022-06-11 11:56:36.693531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Testing wether the instances inside the action module are properly set
    assert action_module.show_content
    assert not action_module.included_files
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-11 11:56:38.256725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add test case
    pass


# Generated at 2022-06-11 11:56:46.019198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    :return:
    '''
    action_module = ActionModule(None, None, None, None, None, None)
    # Constant VALID_FILE_EXTENSIONS
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    # Constant VALID_DIR_ARGUMENTS
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    # Constant VALID_FILE_ARGUMENTS
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    # Constant VALID_ALL
    assert action_module.VALID_ALL

# Generated at 2022-06-11 11:56:46.987011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'

# Generated at 2022-06-11 11:56:47.715799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass

# Generated at 2022-06-11 11:56:59.152514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # module_utils.basic.py
    class FakeTask():
        def __init__(self):
            self.args = {
                'file': 'main.yml',
                'hash_behaviour': 'replace',
            }
    # module_utils.basic.py
    class FakeDS():
        def __init__(self):
            self._data_source = '/home/user/main.yml'
    # module_utils.facts.py
    class FakeRole():
        def __init__(self):
            self._role_path = '/home/user/'
    fake_task = FakeTask()
    fake_ds = FakeDS()
    fake_ds._data_source = '/home/user/main.yml'
    fake_role = FakeRole()
    fake_task._ds = fake_ds
    fake

# Generated at 2022-06-11 11:59:00.260467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:59:06.794108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    change_attributes = {
        'source_dir':'/path/to/source_dir',
        'source_file':'source_file',
        'depth':0,
        'files_matching':'regex',
        'ignore_files':['ignore1','ignore2'],
        'valid_extensions':['ext1','ext2'],
        'hash_behaviour':'merge',
        'return_results_as_name':'name',
        'ignore_unknown_extensions':True
    }
    for attribute, value in change_attributes.items():
        setattr(action_module,attribute,value)

# Generated at 2022-06-11 11:59:18.167456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class_mock_action_module = ActionModule('fake_task', 'fake_connection', 'fake_play_context', 'fake_loader', 'fake_templar', 'fake_shared_loader_obj')
    assert isinstance(class_mock_action_module, ActionModule)
    assert isinstance(class_mock_action_module.VALID_FILE_EXTENSIONS, list)
    assert isinstance(class_mock_action_module.VALID_DIR_ARGUMENTS, list)
    assert isinstance(class_mock_action_module.VALID_FILE_ARGUMENTS, list)
    assert isinstance(class_mock_action_module.VALID_ALL, list)


# Generated at 2022-06-11 11:59:29.155846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    context = PlayContext()

    block = Block()
    block._role = RoleInclude()
    block._role._role_path = '/home/foo/roles/foobar'
    block._ds = block._role._role_path

    task = Task()
    task._role = block._role
    task._ds = block._ds
    task._block = block


# Generated at 2022-06-11 11:59:37.725384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    task_vars['extra_vars'] = dict()
    task_vars['extra_vars']['ansible_fact'] = 'ansible fact'

    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None,
                                 templar=None, shared_loader_obj=None)

    # Arrange
    # Here we are mocking various attributes which are accessed inside
    # ActionModule.run(...) method.
    # We want to be sure that ActionModule.run(...) uses data from these
    # attributes.

    # Arrange: setup attributes
    action_module._task = lambda: None
    action_module._task._role = lambda: None
    action_module._task._role._role_path = lambda: None
    action_module

# Generated at 2022-06-11 11:59:38.420214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 11:59:39.091790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule())

# Generated at 2022-06-11 11:59:49.425516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import find_plugin, get_all_plugin_loaders
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar
    from ansible.executor import playbook_executor
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    import ansible.constants as C

    # Load required test vars
    plugin_loader = find_plugin(ActionBase)
   

# Generated at 2022-06-11 11:59:53.958742
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock _loader and _task
    _loader = object()
    _task = object()
    _task.args = {"dir" : "dir", "depth" : 0, "name" : "name", "hash_behaviour" : None}

    # Create instance of class ActionModule
    action_module = ActionModule(_loader, _task)
    action_module.run()

# Generated at 2022-06-11 11:59:54.528968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass