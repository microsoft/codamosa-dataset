

# Generated at 2022-06-11 11:53:10.441928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.executor.task_result
    task_result = ansible.executor.task_result
    import ansible.executor.task_queue_manager
    task_queue_manager = ansible.executor.task_queue_manager
    import ansible.inventory.host
    host = ansible.inventory.host
    import ansible.playbook.play
    play = ansible.playbook.play
    import ansible.playbook.task
    task = ansible.playbook.task
    import ansible.playbook.play_context
    play_context = ansible.playbook.play_context
    import ansible.template
    template = ansible.template
    import ansible.vars.manager
    vars_manager = ansible.vars.manager

    # Testing with depth argument
    host_vars

# Generated at 2022-06-11 11:53:11.370757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:53:18.558685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.vault import VaultSecret
    from ansible.plugins.loader import get_all_plugin_loaders
    TestingActionModule = ActionModule(
        None,
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert TestingActionModule._task is None
    assert TestingActionModule._connection is None
    assert TestingActionModule._play_context is None
    assert TestingActionModule._loader is None
    assert TestingActionModule._templar is None
    assert TestingActionModule._shared_loader_obj is None
    assert isinstance(TestingActionModule._loader, type(get_all_plugin_loaders()))


# Generated at 2022-06-11 11:53:30.980220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test of the method "run" of class "ActionModule"
    '''
    # pylint: disable=no-member
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements

    task_vars = dict()
    result = dict()
    err_msg = None
    ansible_included_var_files = None
    ansible_facts = None
    _ansible_no_log = None
    failed = False
    module = ActionModule(None, task_vars)

    # test when source_dir and source_file is None
    module.source_dir = None
    module.source_

# Generated at 2022-06-11 11:53:42.416898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # The callable obj to be set to the TaskExecutor _tmp_action_class_obj in the test_init() function test
    class FakeActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            del tmp  # tmp no longer has any effect
            if task_vars is None:
                task_vars = dict()
            self.source_file = self._task.args.get('file', None)
            if self.source_file:
                self.source_file = self.source_file.rstrip('\n')
            result = super(FakeActionModule, self).run(task_vars=task_vars)
            print(result)
            return result
    # Set the FakeActionModule to be the ActionModule
    return FakeActionModule


# Generated at 2022-06-11 11:53:43.776703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_task = ActionModule({})
    assert my_task

# Generated at 2022-06-11 11:53:49.893398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible = {"host_list" : "localhost",
               "module_name" : "ActionModule",
               "module_args" : "foo"}
    task_vars = {}
    tmp = ""
    action_module = ActionModule(ansible, task_vars, tmp)
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-11 11:53:52.142184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module, "Failed to instantiate the ActionModule class"


# Generated at 2022-06-11 11:53:57.014451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """test if ActionModule.run() returns correct result
    """
    # prepare
    tmp = None
    task_vars = None
    # run
    result = ActionModule.run(tmp, task_vars)
    # assert
    assert result == (True, 'No file/dir specified')


# Generated at 2022-06-11 11:54:08.369494
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import load_plugins
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars

    loader = DataLoader()


# Generated at 2022-06-11 11:54:41.991366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    a = action_loader.get('include_vars', class_only=True)
    aresult = ActionModule(dict(
        dir='dir',
        depth='0',
        files_matching='files_matching',
        ignore_files='ignore_files',
        extensions='extensions',
        ignore_unknown_extensions=True,
        file='file',
        _raw_params='_raw_params',
        name='name',
        hash_behaviour='hash_behaviour',
    ))
    assert aresult.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

# Generated at 2022-06-11 11:54:53.524274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.tests.unit.mock.loader import DictDataLoader
    from ansible_collections.ansible.community.plugins.action import ActionModule


# Generated at 2022-06-11 11:54:56.257023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.VALID_FILE_EXTENSIONS == [
        'yaml',
        'yml',
        'json'
    ]

# Generated at 2022-06-11 11:54:57.465060
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-11 11:55:04.468366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        am = ActionModule()
    except Exception as e:
        assert False, "%s raised" % e
    # test default values
    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert am.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-11 11:55:16.515665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    source_file = 'test/unit/modules/action/test_include_vars.yml'
    play_context = PlayContext()
    play_context.CLIARGS = dict()
    play_context.CLIARGS['module_path'] = 'test/unit/modules/action'
    play_context.CLIARGS['remote_user'] = 'test'
    play_context.CLIARGS['connection'] = 'test'
    play_context.basedir = 'test/unit'


# Generated at 2022-06-11 11:55:17.216442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:55:21.008308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    am.run(tmp=None, task_vars=None)

# Generated at 2022-06-11 11:55:29.810862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Task:
        def __init__(self, args, _role=None, _ds=None):
            self.args = args
            self._role = _role
            self._ds = _ds

    class Role:
        def __init__(self, _role_path="/roles/some_role"):
            self._role_path = _role_path

    class DataSource:
        def __init__(self, _data_source="/some_playbook/some_play.yml"):
            self._data_source = _data_source

    action_module = ActionModule(Task({"file": "test_file.yml"}), "/roles/some_role", "/roles/some_role", 1)
    action_module._set_args = lambda: None

# Generated at 2022-06-11 11:55:40.623276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    import mock
    import os
    import sys

    class _Task(object):
        def __init__(self):
            self.args = {
                'dir': 'test/test_include_vars/vars',
                'depth': '2'
            }

    class _DS(object):
        def __init__(self):
            self._data_source = 'test/test_include_vars/main.yml'

    class _Role(object):
        def __init__(self):
            self._role_path = "test/test_include_vars"

    class _ActionBase(object):
        def __init__(self):
            self._task = _Task()
            self._task._role = _Role()
            self._task._ds = _DS()

    our_An

# Generated at 2022-06-11 11:56:37.341391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup ActionModule instance
    # No need to mock anythings, as this function do not use "self" variable.
    # This function only creates an instance of class ActionModule.
    # For that reason we can simply call the real constructor of class ActionModule.
    actionModule = ActionModule(task=None, connection=None, play_context=None,
                                loader=None, templar=None, shared_loader_obj=None)

    # When ActionModule._set_dir_defaults
    #   - with self.ignore_files = 'test'
    #   - with self.ignore_files = ['test']
    #   - with self.ignore_files = {'test':'test'}
    #   Then self.ignore_files should be ['test']
    actionModule.ignore_files = 'test'
    actionModule._set_

# Generated at 2022-06-11 11:56:45.176966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    args = {'dir': 'test/unit/modules/include_vars/vars_directory'}
    action_module = ActionModule(None, args, None)

    # When
    result = action_module.run()

    # Then
    assert result['ansible_facts'] == {'test_1': 'success', 'test_2': 'success'}
    assert result['ansible_included_var_files'] == ['test/unit/modules/include_vars/vars_directory/test_1.yml',
                                                    'test/unit/modules/include_vars/vars_directory/test_2.yml']
    assert result['_ansible_no_log'] is True



# Generated at 2022-06-11 11:56:56.293558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule class constructor')
    import sys
    sys.path.append('..')

    # Dummy ActionModule class to use as a dummy task
    class dummy_ActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return {}

    # Create a dummy task and set the data source to 'test', to prevent the source file from being included
    task = dummy_ActionModule()
    task.set_loader(None)
    task._task = None
    task._task_ds = None
    task._task_ds = 'test'

    # Test constructor with only required arguments
    task.action_set_args({'file': 'test_include_vars.yml'})
    assert task._task.args['file'] == 'test_include_vars.yml'

   

# Generated at 2022-06-11 11:57:06.903932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Use `ansible-playbook --syntax-check` to validate your playbook,
    # then call unittest.main()
    #class TestMyIncludeVars(unittest.TestCase):
    #    def setUp(self):
    #        self.loader = DataLoader()
    #        self.variable_manager = VariableManager()
    #        self.inventory = Inventory(loader=self.loader,
    #                                    variable_manager=self.variable_manager,
    #                                   

# Generated at 2022-06-11 11:57:07.978716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:57:08.631065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return

# Generated at 2022-06-11 11:57:09.950241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict())


# Generated at 2022-06-11 11:57:19.125760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This function is without parameters, but the first parameter is required to run this test
    If you want test this function, please input the parameters
    """
    #logger = logging.getLogger()
    #logger.setLevel(logging.DEBUG)
    #ch = logging.StreamHandler()
    #ch.setLevel(logging.DEBUG)
    #formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    #ch.setFormatter(formatter)
    #logger.addHandler(ch)

    # initialize
    rs = {}
    rs['failed'] = False
    rs['msg'] = ''

    # get parameters

# Generated at 2022-06-11 11:57:29.157539
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule_ins = ActionModule()
    ansible_vars = {
        "path": "/home/ansible/playbook/vars",
        "_raw_params": "/home/ansible/playbook/vars/main.yml",
        "ignore_errors": True,
        "free_form": "/home/ansible/playbook/vars/main.yml"
    }
    def _task(**kwargs):
        _task.__dict__.update(kwargs)
        return _task
    _task.__dict__.update({"args": ansible_vars})
    # Task object that has a dict of arguments
    test_ActionModule_ins._task = _task()
    # AnsibleVars object that has a dict of ansible_facts
    test_ActionModule_ins._ansible

# Generated at 2022-06-11 11:57:36.356993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict()).VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule(dict(), dict()).VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule(dict(), dict()).VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule(dict(), dict()).VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-11 11:59:44.547782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_args = {
        'dir': '/home/user/',
        '_raw_params': '/etc/ansible/file',
        'file': '/etc/ansible/file',
        'other_arg': 'some value'
    }

# Generated at 2022-06-11 11:59:54.125184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins

    results = dict()
    task_vars = dict()
    item = {
        'args': {
            'name': 'my_var',
            'hash_behaviour': 'merge',
            'file': 'my_include_file.yaml'
        },
        'action': 'include_vars'
    }

    ####################################################################################################################
    # Test 1
    yield (
        "Test 1: No file given, source_file not set, source_dir not set",
        {},
        None,
        item,
        task_vars,
        None,
        {
            'message': 'No files were found when processing include_vars', 'failed': True
        }
    )

    ####################################################################################################################
    # Test 2

# Generated at 2022-06-11 12:00:04.478470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    test_ActionModule_run() returns the results of the method run in an
    ActionModule class.
    '''

    # Assign values to instance variables variable_manager, loader, templar
    # and shared_loader
    variable_manager = object()
    loader = object()
    templar = object()
    shared_loader = object()

    # Create an instance of the abstract class ActionBase
    actionbase = ActionBase()

    # Set the instance variables variable_manager, loader, templar and
    # shared_loader of the instance actionbase
    actionbase._shared_loader_obj = loader
    actionbase._loader = loader
    actionbase._templar = templar
    actionbase._shared_loader = shared_loader

    # Assign value to module_name instance variable of class ActionBase
    actionbase._

# Generated at 2022-06-11 12:00:05.518798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tested
    return True

# Generated at 2022-06-11 12:00:12.018031
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-11 12:00:19.314018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule
    Args:
        None
    Returns:
        None
    Raises:
        None
    """
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Make a call to method _set_dir_defaults, called from method run, with no parameters
    action_module._set_dir_defaults()

    # Make a call to method _set_args, called from method run, with no parameters
    action_module._set_args()

    # Make a call to method run, with parameters tmp=tmp_file, task_vars=task_vars
    action_module.run(tmp=tmp, task_vars=task_vars)


# Generated at 2022-06-11 12:00:29.305426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from os import path
    from ansible.plugins.loader import action_loader
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.compat.tests.mock import patch

    # Create instance and assign values to instance variables
    action_mod = action_loader.get('include_vars', task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_mod._task.args = {
        'dir': '.'
    }
    action_mod._task._role = object()
    action_mod._task._role._role_path = '/path/to/a/role/dir'
    action_mod._task._ds = object()

# Generated at 2022-06-11 12:00:30.204380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('This is a unit test')
    return False

# Generated at 2022-06-11 12:00:38.936408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ test_ActionModule checks if ActionModule constructor works
    """
    task = {'action': {'name': 'test'}, 'args': {'name': 'test_name'}}
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.return_results_as_name == 'test_name'
    assert action_module.source_dir == None
    assert action_module.depth == None
    assert action_module.files_matching == None
    assert action_module.ignore_files == None
    assert action_module.valid_extensions == ['yaml', 'yml', 'json']

# Generated at 2022-06-11 12:00:46.468186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        'test',
        {'hash_behaviour': 'merge'},
        load_plugins=False,
        runner_cache=None,
        task_uuid=None,
        task_vars=dict()
    )
    assert action

    action = ActionModule(
        'test',
        {'hash_behaviour': 'replace'},
        load_plugins=False,
        runner_cache=None,
        task_uuid=None,
        task_vars=dict()
    )
    assert action

    action = ActionModule(
        'test',
        {'hash_behaviour': 'stupid'},
        load_plugins=False,
        runner_cache=None,
        task_uuid=None,
        task_vars=dict()
    )
    assert action