

# Generated at 2022-06-23 08:08:12.876001
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-23 08:08:13.483238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:08:23.073520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Args for ActionBase
    class Task():
        def __init__(self, args):
            self.args = args

    task = Task(
        args={
            'hash_behaviour': None,
            'name': None,
            'dir': None,
            'file': '/etc/ansible/ansible.cfg'
        }
    )

    # Args for class ActionModule
    # Don't actually want self.__init__ to run
    self = Task(
        args={
            'hash_behaviour': None,
            'name': None,
            'dir': None,
            'file': '/etc/ansible/ansible.cfg'
        }
    )

    # Make sure that we're testing what we think we're testing
    assert isinstance(self, ActionModule)

    # _set_args()

# Generated at 2022-06-23 08:08:33.436454
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:08:34.921197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('ActionModule test')
    assert True

# Generated at 2022-06-23 08:08:38.891425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.show_content == True
    assert module.included_files == []

# Generated at 2022-06-23 08:08:40.361931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert(isinstance(a, ActionModule))

# Generated at 2022-06-23 08:08:40.991918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule()

# Generated at 2022-06-23 08:08:50.067416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test when only file arg is specified and it exists
    def _mock_get_file_contents(self, filename):
        return (b'{"key": "value"}', True)

    def _mock__get_file_contents_empty(self, filename):
        return ('{}', True)

    class MockTask:
        def __init__(self, args):
            self.args = args

        @property
        def _role(self):
            return None

    class MockRole:
        def __init__(self, role_path):
            self._role_path = role_path

    class MockDS:
        def __init__(self, data_source):
            self._data_source = data_source

    class MockLoader:
        def __init__(self):
            self._get_file_contents

# Generated at 2022-06-23 08:08:56.235628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('localhost', {}, {'playbook_dir': __file__})
    assert action
    assert action._task
    assert action._connection
    assert action._play_context
    assert action._loader
    assert action._templar
    assert action._shared_loader_obj
    assert action._connection_info
    assert action._task.action == 'include_vars'
    assert action._task.args == {}

# Generated at 2022-06-23 08:09:07.723340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts

    action_module = ActionModule()

    task = None
    result = {}
    src_dir = '/home/testf/'
    action_module.run(task, task_vars={'test': 'test'})
    if action_module:
        print('test_ActionModule_run', 'success')
    else:
        print('test_ActionModule_run', 'failed')

    # test src dir is not exist
    action_module._task.args = {'dir': src_dir, 'depth': 0}
    action_module._set_root_dir()
    action_module._set_dir_defaults()
    result = action_module.run(task, task_vars={'test': 'test'})

# Generated at 2022-06-23 08:09:08.855501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionBase)

# Generated at 2022-06-23 08:09:20.531074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict()
    task['args'] = dict()
    task['_task'] = dict()
    task['_task']['args'] = dict()
    task['_task']['args']['hash_behaviour'] = None
    task['_task']['args']['name'] = None
    task['_task']['args']['dir'] = None
    task['_task']['args']['file'] = 'folder/file1.yml'
    task['_task']['args']['_raw_params'] = 'folder/file1.yml'
    task['_task']['args']['depth'] = 0
    task['_task']['args']['files_matching'] = None

# Generated at 2022-06-23 08:09:28.347753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # checking the static variables of class ActionModule
    assert ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:09:30.345836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, type)


# Generated at 2022-06-23 08:09:37.761860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    input_Task = {}
    input_Task['role'] = {'path': '/path/to/role'}
    input_data_source = '/path/to/role/my/data.yml'
    input_ds = {'_data_source': input_data_source}
    input_Task['ds'] = input_ds
    input_args = {'file': 'my/vars/main.yml', 'name': 'test_results'}
    input_Task['args'] = input_args
    result = ActionModule(input_Task, {})
    expected_result = {'ansible_included_var_files': [],
                       'ansible_facts': {'test_results': {}},
                       '_ansible_no_log': True}
    assert result.run() == expected_result

    input_

# Generated at 2022-06-23 08:09:42.297629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    """
    from ansible.module_utils import basic
    action_module = ActionModule(task=dict(args=dict()), connection=None,
                                 play_context=basic.AnsiblePlayContext(), loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-23 08:09:51.837891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os.path
    # Test case 1
    action_module = ActionModule()
    results = action_module.run(task_vars = None)


    assert results['ansible_included_var_files'] == []
    assert results['ansible_facts'] == {}
    assert results['_ansible_no_log'] == True

    # Test case 2
    action_module = ActionModule()
    action_module._task = type('a', (object,), {'_role': type('a', (object,), {'_role_path': 'tasks/vars'})})
    action_module._task._task_vars = type('a', (object,), {'role_path': 'tasks/vars'})
    #action_module.__init__()
    action_module._task._ds = type

# Generated at 2022-06-23 08:09:58.877832
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:10:06.094988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule.VALID_ALL == ['name', 'hash_behaviour']
    assert ActionModule.TRANSFERS_FILES == False

# Generated at 2022-06-23 08:10:11.693561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Tests the constructor of this class
    """
    action_module = ActionModule()
    assert type(action_module) is ActionModule
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

# Generated at 2022-06-23 08:10:22.185989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # If module_utils/vars.py not present, exit
    if not path.exists('library/module_utils/vars.py'):
        raise IOError("Test ActionModule_run failed: test case not implemented")

    # Declare path of valid_extensions
    valid_extensions = ['yaml', 'yml', 'json']

    # Open file vars.py and extract the dictionary
    f = open('library/module_utils/vars.py', 'r')
    data = f.read()
    dictionary = eval(data)

    # Test the code

# Generated at 2022-06-23 08:10:30.044258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()
    assert actionmodule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert actionmodule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert actionmodule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert actionmodule.VALID_ALL == ['name', 'hash_behaviour']

# unit test for method _is_valid_file_ext()

# Generated at 2022-06-23 08:10:31.357360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None, None, None)
    action.run()

# Generated at 2022-06-23 08:10:40.113919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    loader, inventory, variable_manager = (None, None, None)
    pc = PlayContext(loader=loader, variable_manager=variable_manager, inventory=inventory)
    t = dict(action='include_vars', _raw_params='file=main.yaml', args=dict(file='main.yaml'), module_args=dict(file='main.yaml'))
    am = ActionModule(t, pc, loader, variable_manager, inventory)
    assert am.source_file == 'main.yaml'

# Generated at 2022-06-23 08:10:47.033761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class fake_ds(object):
        pass

    class fake_self(object):
        _ds = fake_ds()

        def __init__(self):
            self._task = fake_self()

        def __getattr__(self, name):
            return self.__dict__[name]

        def __setattr__(self, name, value):
            self.__dict__[name] = value

        def error(self, msg):
            raise AnsibleError(to_native(msg))

    fake_self._ds._data_source = './lib/ansible/modules/utilities/logic/include_vars.py'
    fake_self._role = fake_ds()
    fake_self._role._role_path = '/home/user/roles/test'

# Generated at 2022-06-23 08:10:58.769902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.action.include_vars import ActionModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(),
            dir=dict(),
            depth=dict(),
            ignore_unknown_extensions=dict(type='bool'),
            ignore_files=dict(type='list'),
            extensions=dict(type='list'),
            files_matching=dict(),
            hash_behaviour=dict(default=None, choices=['merge', 'replace']),
        ),
        supports_check_mode=False
    )


# Generated at 2022-06-23 08:10:59.406342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:11:00.023198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:11:07.896819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os, tempfile, shutil, json
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    class Options(object):
        """
        Options class stub
        """
        verbosity = 1
        sudo_user = None
        listhosts = None
        listtasks = None
        listtags = None
        syntax = None
        connection = None
        module_path = None
        forks = None
        remote_user = None
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        sc

# Generated at 2022-06-23 08:11:19.342628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._set_dir_defaults()
    assert action_module.depth == 0
    assert action_module.files_matching is None
    assert action_module.ignore_files == list()
    assert action_module.matcher is None

    action_module.ignore_files = ['.foo', '*.bar']
    action_module.files_matching = '*.yml'
    action_module.depth = 2
    action_module._set_dir_defaults()

    assert action_module.depth == 2
    assert action_module.files_matching == '*.yml'

# Generated at 2022-06-23 08:11:19.996377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:11:23.290794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # perform unit test with unittest
    return None

# Unit test with pytest
# def test_ActionModule_run():
#    if __name__ == '__main__':
#        unittest.main()


# Generated at 2022-06-23 08:11:25.027414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    w = ActionModule()
    w.run()
    assert True == True


# Generated at 2022-06-23 08:11:26.531673
# Unit test for method run of class ActionModule
def test_ActionModule_run():

  action = ActionModule()
  assert action.run() == None

# Generated at 2022-06-23 08:11:27.671936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule(dict())
    except Exception:
        print(Exception)

# Generated at 2022-06-23 08:11:35.109084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    module = ActionModule(
        task=dict(role='role', args=dict(file='file.yml')),
        connection=dict(),
        play_context=PlayContext(),
        loader=DataLoader(),
        templar=Play()._variable_manager,
    )

    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']

# Generated at 2022-06-23 08:11:43.763051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, '_set_dir_defaults')
    assert hasattr(ActionModule, '_set_args')
    assert hasattr(ActionModule, 'run')
    assert hasattr(ActionModule, '_traverse_dir_depth')
    assert hasattr(ActionModule, '_ignore_file')
    assert hasattr(ActionModule, '_is_valid_file_ext')
    assert hasattr(ActionModule, '_load_files')
    assert hasattr(ActionModule, '_load_files_in_dir')

# Generated at 2022-06-23 08:11:47.286857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:11:58.895747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # For testing purposes, create an ActionModule object, a PlayContext object and a Task object
    am = ActionModule()
    pc = PlayContext()
    task = Task()
    # Task needs a loader and loader needs a Task
    task._loader = DataLoader()
    task._loader._task = task
    # Task needs an inventory
    task.set_loader(task._loader)
    task.set_play_context(pc)
    # PlayContext needs a variable_manager
    vm = VariableManager()
    pc.variable_manager = vm
    # VariableManager needs a DataLoader and an Inventory
    dl = DataLoader()
    inv = Inventory(loader = dl, variable_manager = vm, host_list = [])
    vm.set_inventory(inv)
    # ActionModule needs a task and a play_context

# Generated at 2022-06-23 08:12:00.381885
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), 'test', 'test', 'test')


# Generated at 2022-06-23 08:12:09.083511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.VALID_ALL == ['name', 'hash_behaviour']
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert not action.TRANSFERS_FILES


# Generated at 2022-06-23 08:12:10.093533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-23 08:12:21.271110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.loader

    def mock_show_content(*args, **kwargs):
        raise Exception("eliminating diff of playbook output")

    def mock_get_file_contents(*args, **kwargs):
        if args[0] == "file1":
            return "{'a': 1}", False
        elif args[0] == "file2":
            return "{'b': 2}", False
        elif args[0] == "file3":
            return "{'c': 3}", False

    def mock_load(data, *args, **kwargs):
        return eval(data)

    def mock_find_needle(*args, **kwargs):
        return "needle"

    actor = ansible.plugins.loader.action_loader.get("include_vars", class_only=True)

# Generated at 2022-06-23 08:12:24.135367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def func():
        action_module = ActionModule()
        return action_module

    action_module = func()
    assert action_module
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-23 08:12:32.431365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    source_dir = '~/my-source-dir'
    source_file = '~/my-source-file.yml'
    depth = 1
    files_matching = '.yml'
    ignore_files = 'ignore_me.yml'
    extensions = 'yml'

    # when: instantiation without arguments
    instance = ActionModule()
    assert instance.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert instance.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert instance.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert instance.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-23 08:12:42.484523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test the run method of class ActionModule.
    """

# Generated at 2022-06-23 08:12:44.787847
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Module should not fail in any case 
    return

# Generated at 2022-06-23 08:12:45.714489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:12:58.534580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize
    source_dir = "test_vars_dir"
    source_file = "test_vars"
    name = "test_name"
    file_matching = "test"
    name_matching = "test"
    ignore_files = ['test_*']
    depth = 100
    extensions = ['yml']
    return_results_as_name = "test_return_name"

    # Constructor
    module = ActionModule(ActionBase, dict(
        dir=source_dir,
        file=source_file,
        depth=depth,
        files_matching=file_matching,
        name=name,
        ignore_files=ignore_files,
        extensions=extensions,
        name=return_results_as_name
    ))

    module._set_args()
    module

# Generated at 2022-06-23 08:12:59.228588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:13:08.089683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # NOTE: This test currently fails because the _loader module is not mocked correctly.
    # Test for case: Input parameters are invalid
    #     - Validate arguments
    #         + Test for case: dirs and files (incompatible).
    #     - Test for case: dir does not exist
    #     - Test for case: dir is not directory
    #     - Test for case: file does not exist
    #     - Test for case: file is not a file
    #     - Test for case: invalid ignore_files (not a list)
    #     - Test for case: invalid extensions (not a list)
    pass


# Generated at 2022-06-23 08:13:20.484619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile

    file1_name = 'test1.yml'
    file1_contents = '{"test1": "test value1"}'

    file2_name = 'test2.yml'
    file2_contents = '{"test2": "test value2"}'

    file3_name = 'test3.yml'
    file3_contents = '{"test3": "test value3"}'

    file4_name = 'test4.yml'
    file4_contents = '{"test4": "test value4"}'

    file5_name = 'test5.yml'
    file5_contents = '{"test5": "test value5"}'

    file6_name = 'test6.yml'

# Generated at 2022-06-23 08:13:29.501369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_include import IncludeRole
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()

# Generated at 2022-06-23 08:13:30.580402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
        

# Generated at 2022-06-23 08:13:31.549983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:13:33.333251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)



# Generated at 2022-06-23 08:13:34.484385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-23 08:13:35.784212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('src/action_plugins/include_vars.py', {'name': 'test'})

# Generated at 2022-06-23 08:13:36.324517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:13:45.454136
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:13:46.135785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:13:56.238101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' test run method of class ActionModule '''

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    action_module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=PlayContext(),
    )

    # test source_dir
    action_module.set_runner(
        runner_type='sync',
        host=None,
        task_uuid='',
        loader=None,
        variable_manager=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-23 08:13:58.343517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod_instant = ActionModule()
    assert isinstance(mod_instant, ActionModule)

# Generated at 2022-06-23 08:13:59.532433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict())

# Generated at 2022-06-23 08:14:09.509291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up args
    args = dict()
    args['hash_behaviour'] = 'merge'
    args['name'] = 'test'
    args['file'] = '/etc/ansible/test.yml'

    # init class instance
    obj = ActionModule()
    obj._task = obj
    obj._task.args = args

    # set up tmp, task_vars
    tmp = {}
    task_vars = dict()

    # call method run
    result = obj._task.run(tmp, task_vars)

    # assert result
    assert result['ansible_facts']['test']['some_key'].strip() == 'some_value'



# Generated at 2022-06-23 08:14:19.538547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    for v in (('dir',), ('file',), ('hash_behaviour',), ('ignore_files',), ('ignore_unknown_extensions',), ('extensions',), ('name',)):
        assert v in am.VALID_FILE_ARGUMENTS or v in am.VALID_DIR_ARGUMENTS or v in am.VALID_ALL
    assert not am.TRANSFERS_FILES
    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    for v in (('dir',), ('depth',), ('files_matching',), ('ignore_files',), ('extensions',), ('ignore_unknown_extensions',)):
        assert v in am.VALID_DIR_ARGUMENTS

# Generated at 2022-06-23 08:14:30.303014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make fake self._loader return content of readme file
    class fake_self_loader():
        def __init__(self):
            self.data = {'readme': 'data readme'}

        def load(self, file_name):
            return self.data[file_name]

        def set_data(self, file_name, data):
            self.data[file_name] = data

    fake_cls = fake_self_loader()
    fake_cls.set_data('test.yml',  {'var1': 'value1', 'var2': 'value2', 'var3': 'value3'})
    fake_cls.set_data('test.yaml', {'var4': 'value4', 'var5': 'value5', 'var6': 'value6'})
    fake_

# Generated at 2022-06-23 08:14:39.602070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize class
    action_object = ActionModule()

    # Check if the input directory is empty
    try:
        action_object._set_args()
        action_object.source_dir = None
        action_object.source_file = None
        assert(action_object._set_args() == None)
    except:
        print("test_ActionModule 1: Input directory is empty")

    # Check if the source file exists
    try:
        action_object.source_file = './test2.json'
        action_object._set_args()
        assert(action_object._set_args() == None)
    except:
        print("test_ActionModule 2: Source file does not exist")

    # Check if the input directory exists

# Generated at 2022-06-23 08:14:41.695723
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  start = 1
  end = 100
  step = 2
  assert start + end + step == 103

# Generated at 2022-06-23 08:14:52.001114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import shutil
    import tempfile
    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.utils.vars import combine_vars

    class TestActionModuleRun(unittest.TestCase):
        """ Test Case class for ansible.plugins.action.include_vars.ActionModule._run method. """
        def tearDown(self):
            """ Deletes the temporary directory and all its contents. """
            if self.tmp_dir:
                shutil.rmtree(self.tmp_dir)

        def setUp(self):
            """ Create temporary directory, variable manager, and a temporary
                inventory. """
            self.tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 08:14:52.675545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:14:57.804091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.include_vars import ActionModule

    # Set up
    test_actionmodule = ActionModule(None, None, None, None)
    setattr(test_actionmodule, 'run', ActionModule.run)

    # Test
    test_actionmodule.run(3)

    # Tear Down
    # test_actionmodule.teardown()

# Generated at 2022-06-23 08:15:03.389002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule.
        This is called by test_runner.py
    """
    # test if include_vars raises a FatalException
    # with an invalid arg
    action = ActionModule()
    try:
        action.run(tmp={}, task_vars={})
    except Exception as e:
        assert isinstance(e, AnsibleError), \
            "Excepted fatal exception for invalid arg, got: " + type(e)

# Generated at 2022-06-23 08:15:15.620562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test returning result as name
    from ansible.plugins import action
    from ansible.plugins.action.include_vars import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.facts import Facts
    from ansible.plays.play import Play
    from ansible.parsing.dataloader import DataLoader

    class TestPlayBookVariableManager:
        def __init__(self):
            pass

    options = 'test_inventory'
    loader = DataLoader('abc')
    display = action.ActionBase._configured_for_display()


# Generated at 2022-06-23 08:15:16.553214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(dict(), dict())
    assert am

# Generated at 2022-06-23 08:15:18.184072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Should return failed with message 'dir' parameter is missing.
    # Invalid argument supplied.
    pass


# Generated at 2022-06-23 08:15:19.402333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('___ActionModule___')
    test_case_ActionModule_1()


# Generated at 2022-06-23 08:15:32.360270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit tests for method run of class ActionModule """

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager
    from ansible.plugins.strategy import ActionModule
    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.clean import clean_facts
    from ansible.utils.display import Display
    from ansible.cli.playbook.play_context import PlayContext

    from units.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase

    class ActionModuleTests(ModuleTestCase):
        """ test class ActionModule """

        def setUp(self):
            """ test setup """


# Generated at 2022-06-23 08:15:44.823946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing a ActionModule object for testing
    action_module = ActionModule()

    # Mocking constructor parameters of class ActionModule
    action_module._connection = 'connection'
    action_module._play_context = 'play_context'
    action_module._loader = 'loader'
    action_module._templar = 'templar'

    # Passing the arguments of run to the instance variable
    action_module._task = 'task'
    action_module._task.args = {'name': '', 'hash_behaviour': None, 'dir': '', 'depth': None, 'files_matching': None, 'ignore_files': None, 'extensions': ['yaml', 'yml', 'json'], 'file': 'test', '_raw_params': ''}

# Generated at 2022-06-23 08:15:45.522752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:15:56.628932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    paths = {'test_file': 'file.txt', 'test_file2': 'file2.txt'}
    for test in paths:
        for name in paths:
            for case in [True, False]:
                if case:
                    paths[name] = paths[name].upper()
                else:
                    paths[name] = paths[name].lower()

        test_file = paths['test_file']
        test_file2 = paths['test_file2']

        # test passing the `file` arg
        task = {
            'args': {
                'file': test_file
            }
        }
        module = ActionModule(task, {})
        assert module._task.args['file'] == test_file

        # test passing the `_raw_params` arg

# Generated at 2022-06-23 08:15:58.463156
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    pass

# Generated at 2022-06-23 08:16:07.214609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        load_from_file_module_path='/path/to/module',
        task=dict(action=dict(module_name='include_vars'))
    )
    assert action.VALID_ALL == ['name', 'hash_behaviour']
    assert action.VALID_DIR_ARGUMENTS == [
        'dir', 'depth', 'files_matching',
        'ignore_files', 'extensions', 'ignore_unknown_extensions'
    ]
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']

# Generated at 2022-06-23 08:16:19.721709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

if __name__ == '__main__':
    import os, sys, unittest
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from test import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    from ansible.module_utils._text import to_bytes
    import json

    ##################################################
    # Unit tests for method run of class ActionModule
    ##################################################
    class ActionModuleTestCase(ModuleTestCase):

        def setUp(self):
            super(ActionModuleTestCase, self).setUp()
            self.module_patcher = patch('ansible.plugins.action.include_vars.ActionModule')
            self.mock_module = self.module_patcher.start()

# Generated at 2022-06-23 08:16:27.372984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import yaml
    test_dir = '/some/dir'
    test_dir_exists = True
    test_file_contents = b'canonical: Yaml Ain\'t Markup Language'
    test_file = '/some/dir/some_file.yaml'
    test_task = mock.Mock()
    test_task.args = {'dir': test_dir}
    test_task._ds = mock.Mock()
    test_task._ds._data_source = '/some/dir/some_file.yaml'
    test_task._role = mock.Mock()
    test_task._role._role_path = '/some/dir'
    test_loader = mock.Mock()

# Generated at 2022-06-23 08:16:28.551523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a.run()

# Generated at 2022-06-23 08:16:39.319683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    from .fixtures.ActionModule import ActionModule
    from .fixtures.ActionModule.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 08:16:40.678817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, type)


# Generated at 2022-06-23 08:16:48.676276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    var_files = ['test1.yml', 'test2.yml']

    expected_results = {
        'test1': 'foo'
    }

    results = action_module._load_files_in_dir('', var_files)
    assert results == (False, '', expected_results)

    expected_results = {
        'test1': 'foo',
        'test2': 'bar'
    }

    results = action_module._load_files_in_dir('', var_files)
    assert results == (False, '', expected_results)

# Generated at 2022-06-23 08:16:58.141943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import play_context

    play_context._play_context = PlayContext()

    params = dict()
    params.update(dir='vars')
    params.update(files_matching='(.*).yml')
    params.update(ignore_files='main.yml')

    test_task = dict(
        action=dict(
            module='include_vars',
            args=params
        ),
        register='my_vars',
        when=None,
        delegate_to='local',
        loop=None,
        loop_control=None
    )

# Generated at 2022-06-23 08:16:58.774518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:17:11.435101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task():
        def __init__(self):
            self.args = dict()
    class Playbook():
        def __init__(self):
            self.vars = dict()
    class Play():
        def __init__(self):
            self.vars = dict()
            self.file_name = ''
    class Role():
        def __init__(self):
            self.name = ''
            self.path = ''
    class Includer():
        def __init__(self):
            self.vars = dict()
            self.file_name = ''

    class DS():
        def __init__(self):
            self.vars = dict()
            self._data_source = ''

    class Loader():
        def __init__(self):
            self.vars = dict()


# Generated at 2022-06-23 08:17:12.098280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 08:17:13.507158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup class
    print('test_ActionModule_run has been depreciated. This is a placeholder')

# Generated at 2022-06-23 08:17:17.890779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    ActionModule('include_vars',
                 {'_task': 'include_vars',
                  'args': {'file': 'test.yaml',
                           '_raw_params': 'test.yaml'}},
                 {'name': 'result'}
                 ).run()

# Generated at 2022-06-23 08:17:27.761331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY3
    import ansible.module_utils.basic
    if PY3:
        # Test action module for Python 3
        import io

        class ModuleTest(object):
            def __init__(self):
                self.params = {
                    'dir': '/tmp/dir1',
                    'extensions': ['yml']
                }
                self.loader = ansible.module_utils.basic.AnsibleModule(
                    argument_spec=dict(),
                    supports_check_mode=True
                )

            def fail_json(self, *args, **kwargs):
                self.exit_args = args
                self.exit_kwargs = kwargs
                raise Exception('fail_json')


# Generated at 2022-06-23 08:17:39.305191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict(ansible_facts=dict())
    try:
        mod = ActionModule(
            dict(action=dict(module_name='include_vars',
                             module_args=dict(dir='/tmp'),
                             task_uuid='1234'
                             )
                 ),
            task_uuid='1234'
        )
        mod.run(tmp, task_vars=task_vars)
    except AnsibleError as e:
        assert e.message == 'dir must be a list'


# Generated at 2022-06-23 08:17:48.635560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys, os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib'))
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'lib'))

    from ansible.utils.vars import combine_vars
    from ansible.plugins.action.include_vars import ActionModule
    module_args = {'file': 'test_file.yml'}
    action = ActionModule(None, module_args)

# Generated at 2022-06-23 08:17:51.017512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, None)
    assert actionModule is not None

# Generated at 2022-06-23 08:17:56.666163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.constants as C
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import fragment_loader

    loader = fragment_loader()
    inventory = [
        'localhost ansible_connection=local ansible_python_interpreter="/usr/bin/env python"',
    ]
    host = 'localhost'
    tasks = []
    tasks.append(
        {
            'action': {
                '__ansible_module__': 'include_vars',
                '__ansible_arguments__': 'file=test.yml'
            },
            'name': 'include_vars test',
            'register': 'ansible_vars'
        }
    )
    loader.path_exists.return_value = True

# Generated at 2022-06-23 08:17:57.607081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:18:00.150174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)

    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-23 08:18:02.868056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This code doesn't work
    #instance = ActionModule()
    #result = instance.run()
    pass



# Generated at 2022-06-23 08:18:04.938780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)



# Generated at 2022-06-23 08:18:10.319742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''
    # Arrange
    actionBase = ActionBase()
    variables = dict()
    actionModule = ActionModule(actionBase, variables)
    # Act
    actionModule.run()
    # Assert
    pass


# Generated at 2022-06-23 08:18:20.481926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(dir='dir', name='name')
    action = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.depth is None
    assert action.files_matching is None
    assert action.ignore_files is None
    assert action.valid_extensions == ['yaml', 'yml', 'json']
    assert action.hash_behaviour is None
    assert action.return_results_as_name is None
    assert action.source_dir == 'dir'
    assert action.source_file is None
