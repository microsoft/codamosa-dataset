

# Generated at 2022-06-23 08:08:21.897084
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:08:30.481456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test of constructor of class ActionModule
    '''
    import ansible.playbook.block as block

    task_ds = block.Block()
    task_ds._role = None
    task = block.Block()
    task._ds = task_ds
    task._role = None

    params = {'file': 'test_file',
              'name': 'test_name',
              'dir': 'test_dir',
              'hash_behaviour': 'test_hash_behaviour',
              'depth': 'test_depth',
              'files_matching': 'test_files_matching',
              'ignore_files': 'test_ignore_files',
              'ignore_unknown_extensions': 'test_ignore_unknown_extensions',
              'extensions': 'test_extensions'}


# Generated at 2022-06-23 08:08:37.715239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    A= ActionModule(None, None)

    assert A.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert A.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert A.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert A.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:08:47.863824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.modules.source_control.git import ActionModule

    # SetUp for test_ActionModule_run.
    # test_case_4
    test_case_4 = dict()
    test_case_4['file'] = 'test/test_cases/test_ActionModule_run/test_case_4/main.yml'

    test_case_4_expected = dict()
    test_case_4_expected['failed'] = False
    test_case_4_expected['_ansible_no_log'] = True
    test_case_4_expected['_ansible_verbose_always'] = True
    test_case_4_expected['ansible_facts'] = {'ul_mapping': {'USA': ['Montana', 'Oregon', 'Texas', 'Washington']}}
    test_case_4_expected

# Generated at 2022-06-23 08:08:57.735442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Ensure that ActionModule.run() raises AnsibleError
    # when ActionModule._task.args contains invalid option
    am = ActionModule(load_name='', task=MockTask(args={'file': 'file1'}))
    assert am.run() == {'ansible_facts': {},
                    'ansible_included_var_files': ['/tmp/file1.yml'],
                    'changed': False,
                    'invocation': {'module_args': {'file': 'file1'}},
                    '_ansible_no_log': False}



# Generated at 2022-06-23 08:09:08.206995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Replace this mock data with appropriate data and rerun test
    mock_tmp = None

# Generated at 2022-06-23 08:09:08.994968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule().run()



# Generated at 2022-06-23 08:09:19.745941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if not sys.version_info >= (3, 0):
        raise pytest.skip()
    actmodobj = ActionModule(None, dict(), None)
    actmodobj._set_args()

    # normal run
    with pytest.raises(AnsibleError):
        actmodobj.run()

    actmodobj = ActionModule(None, dict(_raw_params='somefile.yaml'), None)
    actmodobj._set_args()
    actmodobj.run()

    actmodobj = ActionModule(None, dict(ignore_unknown_extensions=True, dir='/tmp', extension=['yml'], depth=2), None)
    actmodobj._set_args()
    actmodobj.run()


# Generated at 2022-06-23 08:09:20.842818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:09:31.898397
# Unit test for constructor of class ActionModule
def test_ActionModule():
    given_task_name = "my_task"
    given_task_args = {'arg1':'val1', 'arg2':'val2'}
    given_task_action = "action"
    given_task_ds = ""
    given_task_tmp = None
    given_task_delegate_to = "localhost"
    given_task_delegate_facts = False
    given_task_loop = True
    given_task_notify = []
    given_task_register = "my_register"
    given_task_run_once = False
    given_task_until = []
    given_task_changed_when = []
    given_task_failed_when = []
    given_task_any_errors_fatal = []
    given_task_no_log = False


    # given mock for

# Generated at 2022-06-23 08:09:39.142628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import yaml
    import json
    import jinja2
    import tempfile
    import shutil
    import random
    import string

    class Module(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class DS(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class Task(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class Role(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-23 08:09:40.067794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'

# Generated at 2022-06-23 08:09:43.109138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
        assert True, 'ActionModule() not raising AnsibleError on no args'
    except AnsibleError:
        assert False, 'ActionModule() should not raise AnsibleError on no args'

# Unit tests

# Generated at 2022-06-23 08:09:44.453176
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 08:09:45.280167
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule.run()

# Generated at 2022-06-23 08:10:01.034390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    source_dir = origin_path + "/ansible/files/test_vars"
    # source_dir2 = origin_path + "/ansible/files/test_vars/test_vars"
    source_file = "test_vars.yml"
    name = "test_name"

    # test with success
    # am._task.args = {'dir': source_dir, 'name': name}
    # am.run()
    # print (am._task.args)
    # am._task.args = {'_raw_params': source_file, 'name': name}
    # am.run()
    # print (am._task.args)
    # am._task.args = {'file': source_file, 'name': name}
    # am.run()
   

# Generated at 2022-06-23 08:10:08.724696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_case is a dict, contains the function name, arguments and expected result
    test_case = {
        'func_name': 'run',
        'args': {
            '_raw_params': "./vars",
            'name': 'facts',
            'extensions': ['yml', 'yaml', 'json'],
        },
        'expected': {'failed': True, 'message': 'vars/ does not exist'}
    }
    action_module = ActionModule()
    result = getattr(action_module, test_case['func_name'])(**test_case['args'])
    assert result == test_case['expected']

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:10:18.839176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play

    class MockTaskInclude(TaskInclude):
        def __init__(self, role=None, task=None):
            self._role = role
            self._task = task

        def _load_included_file(self, include_file):

            class MockRole:
                def __init__(self):
                    self._role_path = '/tmp/'
            mock_role = MockRole

# Generated at 2022-06-23 08:10:26.034345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ This test is not meant to be exhaustive. It only tests the run
    method.


    """

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    from ansible.plugins.loader import module_loader

    mock_loader = module_loader.ModuleLoader(None)

    def mock_task_exit_args(self, keys, args):
        return True

    def mock_add_tqm_variables(self, inject, play=None):
        return True

    def mock_set_loader(self, value):
        self._loader = value

    class MockIncludeVarModule(ActionModule):

        def __init__(self):
            self._task = Task()


# Generated at 2022-06-23 08:10:29.317795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._set_dir_defaults() is None
    assert module._set_args() is None


# Generated at 2022-06-23 08:10:39.739521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule. """
    # Create a fake _task instance. We cannot mock _task because it is not a class, so we have to create an alternative
    # solution.
    faketask = type('ActionModule', (object,), {
        '_role': None,
        '_ds': type('ActionModuleDataSource', (object,), {
            '_data_source': '/home/fakeuser/fakeproject/fake_tasks_file.yml'
        })
    })()

    # Create a fake _task instance. We cannot mock _task because it is not a class, so we have to create an alternative
    # solution.

# Generated at 2022-06-23 08:10:40.576436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

# Generated at 2022-06-23 08:10:50.019675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    import ansible.modules.system
    import ansible.playbook.role.definition
    import ansible.playbook.task

    # print(ansible.utils.plugin_docs.get_action_documentation(ansible.plugins.action))

    # mock data
    class AnsibleModule(object):
        def __init__(self, *args, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    class MockPlaybookTask(object):
        def __init__(self, *args, **kwargs):
            self.args = {}
            self.args.update(kwargs)

    class MockPlaybookRoleDefinition(object):
        def __init__(self, *args, **kwargs):
            self.name = k

# Generated at 2022-06-23 08:10:50.847950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:10:54.603465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    InjectorModule = ActionModule.load_module('injector')
    assert isinstance(InjectorModule, ActionModule)

# Unit test to load_file

# Generated at 2022-06-23 08:10:55.732315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule() is not None

# Generated at 2022-06-23 08:10:57.444227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None)
    assert isinstance(am, ActionModule)



# Generated at 2022-06-23 08:10:58.037871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:11:00.191793
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create an actionModule object
    action_module = ActionModule(None, None, None, None)

    print("Test passed")

# Generated at 2022-06-23 08:11:02.575371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-23 08:11:13.882454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ast
    import ansible.plugins.action.include_vars
    # verify a new object is created
    obj = ansible.plugins.action.include_vars.ActionModule('/foo/bar/baz', '/usr/bin/ansible', False)
    
    # set attributes
    obj.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
    obj.VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    obj.VALID_FILE_ARGUMENTS = ['file', '_raw_params']
    obj.VALID_ALL = ['name', 'hash_behaviour']
    

# Generated at 2022-06-23 08:11:14.391695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:11:15.054831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:11:25.240772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Prepare the test
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.facts import defaultdict
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader

    parameters = {
        'name': 'a',
        'file': "./tests/integration/final/vars.yml",
        '_raw_params': "./tests/integration/final/vars.yml",
        'hash_behaviour': "replace",
    }

    source_of_data = "./tests/integration/final/tasks/main.yml"

# Generated at 2022-06-23 08:11:26.711367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
    except Exception:
        assert False


# Generated at 2022-06-23 08:11:28.030799
# Unit test for constructor of class ActionModule
def test_ActionModule():

    obj = ActionModule()
    if obj is None:
        return False

    return True



# Generated at 2022-06-23 08:11:33.973566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # testing the run() method
    module = AnsibleModule(argument_spec={})
    module.params = {'dir':'/some/path/to/files'}
    action_module = ActionModule(module, 'some_directory_name')
    assert action_module.run() is not None

# Generated at 2022-06-23 08:11:36.437309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict(), dict())

# Generated at 2022-06-23 08:11:43.199930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.source_dir = "/tmp/ansible/deploy/roles/centos7-tomcat8-deploy/vars"
    # print(module._traverse_dir_depth())
    
if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-23 08:11:54.758811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test object of class AnsibleModule
    MockModule = utils.mock_ansible_module
    mock_module = MockModule()
    # Populate the necessary module attributes
    mock_module.params = {
        'file': 'file/path/to/main.yml',
        'name': 'test_name',
        'ignore_files': ['ignored.yml']
    }
    mock_module.check_mode = False
    mock_module.no_log = False
    
    # Create a test object of class ActionModule inheriting from the test object of
    # class AnsibleModule
    action_module = ActionModule(mock_module)
    
    filepath_to_main = 'tests/fixtures/main.yml'

# Generated at 2022-06-23 08:12:04.984622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test object
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.utils.display import Display

    host_obj = Host(name='localhost')
    group_obj = Group(name='test_group')
    group_obj.add_host(host_obj)

    play_context = PlayContext()
    display = Display()
    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-23 08:12:06.207069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None
    assert issubclass(ActionModule, ActionBase)


# Generated at 2022-06-23 08:12:16.222344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest.mock as mock

    filename = "/etc/hosts"
    root_dir = "/etc"
    var_files = ['hosts']

    class MockTask():
        class MockDS():
            _data_source = "/root/ansible/library/include_vars.py"
        _ds = MockDS()

        def __init__(self):
            self._role = mock.MagicMock()
            self._role._role_path = "/root/ansible/library"

        def set_args(self, args):
            self.args = args

        def set_loader(self, loader):
            self._loader = loader

    class MockLoader():
        def __init__(self, data):
            self.data = data

        def _get_file_contents(self, filename):
            return self

# Generated at 2022-06-23 08:12:26.754348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = Mock()
    task.args = {'dir': '/root/ansible-playbooks/tests/test_vars_files', 'name': 'dummy_name'}
    task._role = None
    task.args = {'depth': 2, 'files_matching': '.*', 'ignore_files': ['.*path.yml']}
    task.args = {'extensions': ['json', 'yml']}
    task._ds = {'_data_source': 'playbooks/site.yml'}
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(task_vars=None)

# Generated at 2022-06-23 08:12:27.931115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(dict(), dict())
    assert module is not None

# Generated at 2022-06-23 08:12:28.497547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:12:40.022720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data_source = '/home/username/example/main.yml'
    task_ds = {}
    task_ds['_ds'] = data_source
    task_ds['_role'] = {'_role_path' : '/home/username/example'}

    task_args = {}
    task_args['dir'] = 'vars'
    task_args['depth'] = '1'
    task_args['files_matching'] = 'compute'
    task_args['ignore_files'] = ['main.yml']
    task_args['extensions'] = ['yaml', 'yml']
    task_args['ignore_unknown_extensions'] = False

    task = {}
    task['_ds'] = task_ds
    task['args'] = task_args
    task_vars = {}


# Generated at 2022-06-23 08:12:44.071796
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = type('obj', (object,), {'args': {'dir': '/path/directory', 'depth': 0, 'files_matching': 'file_name', 'ignore_files': '', 'extensions': ['yml', 'yaml', 'json'], 'ignore_unknown_extensions': False}})
    am = ActionModule(task, {})
    assert isinstance(am, ActionModule)


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:12:52.504437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test input
    task_vars = dict()
    q = ActionModule(task_vars)

    # Test outputs
    output_tuple = q.run()
    output = output_tuple[1]

    # Test comparison
    assert isinstance(output, dict)
    assert output['failed'] == True
    assert output['message'] == 'missing required arguments: file, dir'


# Generated at 2022-06-23 08:12:53.210224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:12:53.819044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return True

# Generated at 2022-06-23 08:12:54.666690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action1 = ActionModule()
    assert action1


# Generated at 2022-06-23 08:13:05.849800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = dict(name='127.0.0.1')
    task = dict(
        name='include_vars',
        options=dict(
            dir='/tmp/ansible_test/',
            ignore_files=['test_file1.yml'],
            extensions=['yml']
        ),
        action='include_vars',
        args=dict(dir='/tmp/ansible_test/', ignore_files=['test_file1.yml'], extensions=['yml'])
    )

    task_ds = dict(
        _role=None,
        _ds=dict(
            _data_source='/tmp/ansible_test'
        )
    )

# Generated at 2022-06-23 08:13:18.733202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit under test
    uut = ActionModule(
        task={"args": {"name": "arg_name", "hash_behaviour": "hash_behaviour", "dir": "arg_dir", "depth": "arg_depth",
                       "files_matching": "arg_files_matching", "ignore_files": "arg_ignore_files",
                       "extensions": "arg_extensions", "ignore_unknown_extensions": True, "file": "arg_file",
                       "_raw_params": "arg__raw_params"}},
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    expected_err_msg = "no_err_msg"

# Generated at 2022-06-23 08:13:27.451345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_name = '127.0.0.1'
    connection = ansible.connection.Connection(host_name)
    task = ansible.playbook.task.Task()
    loader = ansible.parsing.dataloader.DataLoader()
    try:
        tmp = None
        task_vars = dict()
        #obj = ansible.plugins.action.ActionBase(connection, task, tmp, task_vars)
        obj = ActionModule(connection, task, tmp, task_vars, loader)
        assert(obj.run(tmp, task_vars) == None)
    except:
        print("test_ActionModule_run failed")

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-23 08:13:32.093530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionModule)
    assert isinstance(am.VALID_FILE_EXTENSIONS, list)
    assert isinstance(am.VALID_DIR_ARGUMENTS, list)
    assert isinstance(am.VALID_FILE_ARGUMENTS, list)
    assert isinstance(am.VALID_ALL, list)

# Generated at 2022-06-23 08:13:43.240009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    variables = dict()
    variables['ANSIBLE_VERBOSITY'] = 0
    variables['ANSIBLE_NOCOLOR'] = None
    variables['ANSIBLE_FORCE_COLOR'] = False
    variables['ANSIBLE_HOST_KEY_CHECKING'] = False
    variables['ANSIBLE_DISPLAY_ARGS_TO_STDOUT'] = False
    variables['ANSIBLE_STDOUT_CALLBACK'] = None
    variables['ANSIBLE_ASYNC_DIR'] = None
    variables['ANSIBLE_MODULE_ARGS'] = dict()
    variables['ANSIBLE_MODULE_ARGS']['ANSIBLE_MODULE_ARGS'] = dict()
    variables['ANSIBLE_MODULE_ARGS']['ANSIBLE_MODULE_ARGS']['vars_files'] = None

# Generated at 2022-06-23 08:13:50.405924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:13:54.562434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    action_module_obj = ActionModule()
    task_vars = dict()
    assert action_module_obj != 'Invalid'
    try:
        action_module_obj.run(task_vars=task_vars)
        assert False
    except AnsibleError as e:
        assert True

# Generated at 2022-06-23 08:13:55.209009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:13:56.033160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:14:07.515130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    task_vars = variable_manager.get_vars(play=dict(vars=dict()))

    am = ActionModule(
        task=dict(action=dict(dir='tests/fixtures/vars_dir/',
                              extensions='yaml',
                              hash_behaviour='merge',
                              name='my_vars')),
        connection=dict(),
        play_context=dict(),
        loader=loader,
        templar=None,
        shared_loader_obj=None
    )

    am.setup

# Generated at 2022-06-23 08:14:08.877391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True



# Generated at 2022-06-23 08:14:10.481608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionModule)

# Generated at 2022-06-23 08:14:11.121307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:14:15.354175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule({
        "module_setup": True,
        "args": {
            "name": "testing"
        }
    }, {})
    return action_module is not None


# Generated at 2022-06-23 08:14:26.020254
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # mock PlayContext
    pc = PlayContext()
    pc.new_stdin = False
    pc.become = True
    pc.become_method = 'sudo'
    pc.become_user = 'user'
    # mock Task
    t = Task(connection='local', sudo=True)
    # mock Role
    r = Role(path='')
    # mock Datasource
    ds = DataSource(path='', run_add_on=False)
    # mock TaskInclude
    task_include = TaskInclude('include_vars', True, ds, None, r)
    task_include._task_vars = dict()
    task_include._play_context = pc
    task_include._parent_role = r
    task_include._role_context = None

# Generated at 2022-06-23 08:14:30.663527
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    results = dict()
    failed = False
    err_msg = ''

    filename = 'test_filename'
    validate_extensions = True

    failed, err_msg, loaded_data = self._load_files(
        filename,
        validate_extensions
    )

    results.update(loaded_data)

    return failed, err_msg, results

# Generated at 2022-06-23 08:14:38.988781
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert obj._set_dir_defaults() is None
    assert obj._set_args() is None
    assert obj.run('','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','', '','') is None

# Generated at 2022-06-23 08:14:39.678070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:14:41.799012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.vars import ActionModule
    actionModule = ActionModule()
    assert actionModule

# Generated at 2022-06-23 08:14:42.727024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:14:43.380673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:14:54.153541
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    filename = "unittest_file_name.yml"
    # Test for source_dir
    test_dirname = "test_dirname"
    
    # Test for source_file
    test_file = "test_file"
    test_file_path = "path"

    tmp = None
    task_vars = dict()
    
    action_module = ActionModule()

    # Test with good path
    test_dir = path.join(path.dirname(__file__), test_dirname)

    # Test with bad path
    test_dir_invalid = path.join(path.dirname(__file__), "invalid_dirname")

    # Test with good file
    test_file_good = path.join(path.dirname(__file__), "vars", test_file)

    #

# Generated at 2022-06-23 08:14:54.747873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:15:04.336851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test: ActionModule.run')

    import unittest
    import inspect
    import sys
    import os
    import tempfile
    import shutil

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

            self._task = ActionModule()
            self._task.__dict__ = {'_role': None}

            self._task.args = {'dir': None}


        def test_set_dir_defaults(self):
            action = ActionModule()
            action.VALID_FILE_EXTENSIONS = ['yml']

            action.ignore_files = None
            action._set_dir_defaults()
            self.assertEqual(action.matcher, None)

# Generated at 2022-06-23 08:15:12.247871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_class = ActionModule()
    task = {}
    task['args'] = {}

    task['args']['name'] = 'all'
    task['args']['file'] = './files/vars/test.yml'
    action_module_class.task = task
    action_module_class.loader._data_source = './files/vars/test.yml'
    action_module_class.run()



# Generated at 2022-06-23 08:15:21.136871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import module_loader
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible import context
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    module_name = 'include_vars'
    loader = module_loader._find_plugin(module_name)
    assert loader is not None
    task = Task()
    task._role = None
    task._ds = None
    task_vars = dict()
    block = Block()
    block._role = None
    block._ds = None
    block._parent = None
    task._block = block

# Generated at 2022-06-23 08:15:32.811501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Testing method run on ActionModule Class"""

    # Checking module run function with a sample task
    task = {"name": "include vars", "args": {"ignore_files": False, "hash_behaviour": "replace", "extensions": "yml", "files_matching": False, "depth": 0, "name": None, "ignore_unknown_extensions": False, "dir": "./collection_examples/ansible_collections/test_ns/test_coll/plugins/modules", "_ansible_check_mode": False, "ignore_hidden": True}}
    task_vars = {"vars": {}}
    action_module = ActionModule(task, task_vars)
    action_module.run()

    # Checking module run function with a task which
    # contains invalid argument in the task

# Generated at 2022-06-23 08:15:34.136059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:15:40.591922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file with provided name and some text in it
    open(tmpdir + '/some_file.yml', 'a').close()
    open(tmpdir + '/some_other_file.txt', 'a').close()

    # Create the task

# Generated at 2022-06-23 08:15:48.923077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock
    task_vars = dict()
    action_base_mock = ActionBase()
    action_base_mock.run(task_vars=task_vars)
    action_base_mock.cleanup(task_vars=task_vars)

    # Create a dict with the desired arguments
    task_vars = dict(
        name='facts',
        dir='vars/'
    )
    action_module = ActionModule()
    action_module.run(task_vars=task_vars)

# Generated at 2022-06-23 08:15:52.869953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule({'action': 'include_vars', 'args': {'dir': '/tmp', 'ignore_files': ['*.swp'], 'name': 'result', 'hash_behaviour': 'merge'}})

# Generated at 2022-06-23 08:16:00.097146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.plugins import module_loader, lookup_loader

    def get_test_task(**kwargs):
        play_context = PlayContext()
        play_context.connection = 'local'
        play_context.deprecated_allow_unsafe_lookups = False
        play_context._remote_addr = '127.0.0.1'
        task = Task()
        task._role = Role()
        task._block = Block()
        task._role._role_path = './test/roles/test_role'

# Generated at 2022-06-23 08:16:11.509995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a._task.args = {'file': 'test_file.yml', 'name': 'test_name'}
    a._set_args()
    a.source_file = 'test_file.yml'
    del a._task._role
    del a._task._ds
    a._loader.find_file_in_search_path = lambda file_name, search_path: file_name
    a._loader._get_file_contents = lambda filename: (b'data', True)
    a._loader.load = lambda data, file_name, show_content: {'test': True}
    result = a.run()
    assert result['ansible_facts']['test_name']['test'] == True
    assert result['ansible_included_var_files'][0]

# Generated at 2022-06-23 08:16:23.078034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    import ansible.module_utils.basic
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook
    import ansible.inventory.manager
    import ansible.constants

    # Initialize Ansible constants, it is required to use action_loader.
    ansible.constants.set_constants()

    # Setup basics
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = ansible.inventory.manager.InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-23 08:16:32.285569
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None,'include_vars','a','b','c','d','e','f')
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']



# Generated at 2022-06-23 08:16:39.635793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'])
    assert(ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'])
    assert(ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params'])
    assert(ActionModule.VALID_ALL == ['name', 'hash_behaviour'])


# Generated at 2022-06-23 08:16:40.052662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:16:48.733561
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest

# Generated at 2022-06-23 08:16:55.178797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t_ds=''
    t_role=''
    t_task=''
    t_loader=''
    t_play_context=''
    t_shared_loader_obj=''
    t_variable_manager=''
    t_loader_obj=ActionModule(t_ds,t_role,t_task,t_loader,t_play_context,t_shared_loader_obj,t_variable_manager)
    return t_loader_obj

# Generated at 2022-06-23 08:17:02.963699
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test of function ActionModule : "__init__(self, task, connection, play_context, loader, templar, shared_loader_obj)"
    """
    # try:
    #     am = ActionModule(0, 0, 0, 0, 0, 0)
    #     print('\nConstructor: No errors!')
    # except Exception as e:
    #     print('\nConstructor error: ' + str(e))
    pass


# Generated at 2022-06-23 08:17:11.111422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    actionModule._set_dir_defaults()
    actionModule._set_args()
    actionModule._set_root_dir()
    actionModule._traverse_dir_depth()
    actionModule._ignore_file("stam")
    actionModule._load_files("stam")
    actionModule._load_files_in_dir("stam", "stam")
    actionModule.run()

# Generated at 2022-06-23 08:17:20.541620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import json
    import os
    import yaml
    a = ActionModule(task=json.loads(sys.argv[1]), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    a.VALID_ALL = []
    a._set_dir_defaults()
    a._set_args()
    a.source_dir = os.path.dirname(os.path.abspath(sys.argv[2]))
    results = {}
    err_msg = ""
    failed = False

# Generated at 2022-06-23 08:17:22.779430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    temp_action_module = ActionModule()
    assert temp_action_module is not None

# Generated at 2022-06-23 08:17:37.984687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_release import __version__ as A_VER
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    loader = DataLoader()

    task_vars = dict(foo='bar')
    variable_manager = VariableManager()
    variable_manager.extra_vars = task_vars
    t = dict(
        args = dict(
            _raw_params = 'var.yml'
        ),
        _role = None,
        _ds = dict(_data_source = '../../../../../unit/modules/utility/include_vars_test/var.yml')
    )

# Generated at 2022-06-23 08:17:46.395961
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, '_set_dir_defaults')
    assert hasattr(ActionModule, '_set_root_dir')
    assert hasattr(ActionModule, '_traverse_dir_depth')
    assert hasattr(ActionModule, '_ignore_file')
    assert hasattr(ActionModule, '_is_valid_file_ext')
    assert hasattr(ActionModule, '_load_files')
    assert hasattr(ActionModule, '_set_args')


# Generated at 2022-06-23 08:17:47.392374
# Unit test for constructor of class ActionModule
def test_ActionModule():
	assert(ActionModule("test_task") is not None)

# Generated at 2022-06-23 08:17:58.851450
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts

    facts = Facts(dict(foo='bar'))
    action = ActionModule(dict(), dict(), dict(), dict(), facts)
    action.VALID_FILE_EXTENSIONS = ['yaml', 'yml']
    action.VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    action.VALID_FILE_ARGUMENTS = ['file', '_raw_params']
    action.VALID_ALL = ['name', 'hash_behaviour']
    action._task.args = dict(dir=dict(foo='bar'), depth=1, files_matching='foo', ignore_files=4, extensions='bar', ignore_unknown_extensions=False)
    action._

# Generated at 2022-06-23 08:18:11.666004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tempfile 
    import shutil 
    import os 
    tmp_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(tmp_dir,'vars'))
    with open(os.path.join(tmp_dir,'vars/1.yml'),'w') as f:
        f.write('a: 1')
    with open(os.path.join(tmp_dir,'vars/2.yml'),'w') as f:
        f.write('b: 2')
    task_vars = dict()
    am = ActionModule(dict(), task_vars)
    am.run(task_vars=task_vars) # this will fail, because dir has not been supplied
    task_args = dict()
    task_args['dir'] = os.path