

# Generated at 2022-06-23 08:08:22.586235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Assign
    source_dir = '/tmp/ansible_include_vars'
    depth = 1
    files_matching = "*.yml"
    ignore_files = ["ignore_this.yml"]
    valid_extensions = ['yml', 'yaml']
    # Arrange. Create the necessary files for the test
    import os
    import shutil

    if os.path.exists(source_dir):
        shutil.rmtree(source_dir)

    os.makedirs(source_dir)
    content_dir1 = """---
a:
  - item1
  - item2
  - item3
  - item4
b: 'hello world'
c:
  d: deny
  e: '{{ var1 }}'
"""

# Generated at 2022-06-23 08:08:30.516843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for initializing ActionModule class
    action_module = ActionModule()
    assert hasattr(action_module, '_set_dir_defaults')
    assert hasattr(action_module, '_set_args')
    assert hasattr(action_module, 'run')
    assert hasattr(action_module, '_traverse_dir_depth')
    assert hasattr(action_module, '_ignore_file')
    assert hasattr(action_module, '_is_valid_file_ext')
    assert hasattr(action_module, '_load_files')
    assert hasattr(action_module, '_load_files_in_dir')
    assert hasattr(action_module, '_set_root_dir')

# Generated at 2022-06-23 08:08:31.297671
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-23 08:08:39.327581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.task import Task

    tests = []

    # source_dir exists, returns dict

# Generated at 2022-06-23 08:08:44.902869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Unit tests for ActionModule
    try:
        # Created the object with the required argument
        module_ = ActionModule(dict(), None, None, '', '')
    except TypeError as err:
        print("TypeError occurred: " + err.args[0])
    else:
        print("No TypeError occurred")
    # Created the object without the required argument
    module_ = ActionModule(None, None, None, '', '')


# Generated at 2022-06-23 08:08:52.660539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    import mock
    import ansible.errors
    import ansible.constants

    # Create objects for testing
    class Task(object):
        def __init__(self, _data, _role, _ds):
            self._data = _data
            self._role = _role
            self._ds = _ds
    class Role(object):
        def __init__(self, _role_path):
            self._role_path = _role_path

    # Create data and some expected results
    data = {
        'name': 'TestName',
        'hash_behaviour': 'merge',
        'dir': '/tmp',
        'depth': 2,
        'files_matching': 'test',
        'ignore_files': [],
        'extensions': 'yaml'
    }
    data

# Generated at 2022-06-23 08:09:04.765249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    # The following command is used to execute the unit test and will output the test results
    # To run the test execute the following command: python -m unittest discover -s ./test/unit/module/ -p '*_test.py'
    # To run the unit test for the class ActionModule execute the following command: python -m unittest discover -s ./test/unit/module/ -p '*_test.py' -t . -v
    # To run the unit test for the test case test_ActionModule_run execute the following command: python -m unittest discover -s ./test/unit/module/ -p '*_test.py' -t . -v test_ActionModule.ActionModuleTests.test_ActionModule_run
    # Note 1: The discovery of tests is done by unittest and is based

# Generated at 2022-06-23 08:09:12.717586
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    path_to_module_under_test = 'ansible.plugins.action.include_vars'
    module_under_test = None
    try:
        module_under_test = __import__(path_to_module_under_test, fromlist=[''])
    except ImportError:
        return 1
    # Check if class ActionModule exist
    class_under_test = None
    try:
        class_under_test = getattr(module_under_test, 'ActionModule')
    except AttributeError:
        return 1
    # Check if method run of class ActionModule exist
    if not hasattr(class_under_test, 'run'):
        return 1
    return 0



# Generated at 2022-06-23 08:09:23.517701
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
            task = dict(
                args = dict(
                    dir = '/root/t',
                    file = 'test.yml',
                    dir2 = '.',
                    hash_behaviour = 'replace',
                    name = 'test',
                    depth = 0,
                    files_matching = '*',
                    ignore_files = ['regex1', 'regex2'],
                    extensions = ['yml'],
                    ignore_unknown_extensions = False),
                )
            )
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module._task.args['dir'] == '/root/t'
    assert action_module._task.args['file'] == 'test.yml'
    assert action_module._task.args

# Generated at 2022-06-23 08:09:33.880091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestModule(ActionModule):
        def _find_needle(self, directory, file):
            return 'test'

        def _traverse_dir_depth(self):
            return [('test_root', ['test'])]

        def _set_root_dir(self):
            self.source_dir = 'test'

        def _set_dir_defaults(self):
            self.depth = 0

    class TestTask():
        def __init__(self, role):
            self._role = role

# Generated at 2022-06-23 08:09:42.942630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(dict(action=dict(dir=''), args=dict(dir=''), task=dict(args=dict(dir=''))))
    assert a.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert a.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert a.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert a.VALID_ALL == ['name', 'hash_behaviour']



# Generated at 2022-06-23 08:09:52.312030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # we need to mock some things for the unit test to work
    action_module_class = ActionModule
    # create mock variables for things which have the same name as task_vars and loader.
    task_vars = ['task_vars', 'loader']
    loader = ['task_vars', 'loader']

    # create an object of class ActionModule
    action_module = action_module_class(task_vars, loader)

    # start testing method run()
    root_dir = "test_dir"
    current_depth = 0

    # create a mock object with walk() method, which is used to iterate over the source directory
    class MockWalk(object):
        def __init__(self):
            self.walk_iter = 0

# Generated at 2022-06-23 08:10:01.265806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules.extras.old_files.include_vars
    action = ansible.modules.extras.old_files.include_vars.ActionModule()
    action._task = mock()
    from ansible.module_utils.basic import AnsibleModule
    ansible_mod = AnsibleModule()
    ansible_mod.params = {'var': 'test', 'hash_behaviour': 'merge'}
    action._task.args = ansible_mod.params
    action._set_args()
    action.run(tmp='test_tmp', task_vars='test_task_vars')


# Generated at 2022-06-23 08:10:09.382697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    exec(open("./include_vars.py").read())
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    action_module.set_loader(object)
    action_module.set_task(object())
    action_module._task.args = dict()
    # The source_dir must exist and be a directory
    action_module._task.args['dir'] = '.'
    action_module.run(tmp=None, task_vars=dict())
    # The source_file must exist
    action_module._task.args['file'] = 'README.md'

# Generated at 2022-06-23 08:10:19.884058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_dir = 'test_dir'
    if not path.exists(test_dir):
        print('Creating test_dir')
        os.mkdir(test_dir)
    if not path.exists(test_dir + '/vars'):
        print('Creating vars')
        os.mkdir(test_dir + '/vars')
    test_file = 'test_file'
    if not path.exists(test_file):
        print('Creating test_file')
        open(test_file, 'a').close()
    if not path.exists(test_dir + '/vars/test_file'):
        print('Creating vars/test_file')
        open(test_dir + '/vars/test_file', 'a').close()

# Generated at 2022-06-23 08:10:30.712029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up data
    loader_mock = MagicMock(spec=DataLoader)
    def _get_file_contents_mock(path):
        return path, True

    loader_mock._get_file_contents = MagicMock(spec=_get_file_contents_mock)

    task_vars_mock = dict()
    tmp_mock = None

    task_ds_mock = MagicMock()
    task_ds_mock._data_source = 'tasks/main.yml'

    task_mock = MagicMock()
    task_mock._role = None
    task_mock._ds = task_ds_mock
    bool_mock = MagicMock()
    bool_mock.true = True
    task_mock._role = bool_mock

# Generated at 2022-06-23 08:10:41.755965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Method to test the run method of class ActionModule
    """
    # Not able to mock the class variables of the class ActionModule
    # Hence, I am creating a generic class which inherits the same properties
    # as that of ActionModule
    class ActionModuleNew(ActionModule):
        """ Class inheriting all the properties from class ActionModule
        """
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._shared_loader_obj = shared_loader_obj
            self._templar = templar
            self.included_files = []
            self.return_results_as_name = None

    task_vars = {}

# Generated at 2022-06-23 08:10:51.739221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict


# Generated at 2022-06-23 08:10:53.217148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule()

# Generated at 2022-06-23 08:11:02.932227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule()

    # test passing invalid _raw_params
    task = dict()
    task['action'] = dict()
    task['action']['args'] = dict()
    task['action']['args']['name'] = 'test_name'
    task['action']['args']['_raw_params'] = 'test_params'
    actionmodule._task = task
    assert actionmodule.run()

    # test passing valid _raw_params
    actionmodule._task['action']['args']['_raw_params'] = os.path.realpath(os.path.join(os.path.dirname(__file__), '../fixtures/include_vars/vars.yml'))
    assert actionmodule.run()

    # test passing valid file

# Generated at 2022-06-23 08:11:13.976971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if PY3:
        from io import StringIO
        unicode = str
    else:
        from StringIO import StringIO

    test_playbook_path = __file__.split(path.sep)[:-1]
    test_playbook_path = path.sep.join(test_playbook_path)
    yml_test_file = open(test_playbook_path+path.sep+"test_include_vars.yml", "r+")
    module = AnsibleModule(argument_spec={'_raw_params': dict(type='str', required=True)}, supports_check_mode=True)

# Generated at 2022-06-23 08:11:24.350175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task = dict()
    _task['args'] = dict()
    _task['args']['dir'] = 'test'
    _task['args']['depth'] = 0
    _task['args']['files_matching'] = 'hello_world'
    _task['args']['ignore_files'] = '.*'
    _task['args']['extensions'] = 'yaml'
    _task['_role'] = None
    _task['_ds'] = None

    _t = dict()
    _t['ansible_included_var_files'] = []
    _t['ansible_facts'] = dict()
    _t['_ansible_no_log'] = False

    a = ActionModule()
    a._task = _task
    a.run(task_vars=_t)

# Generated at 2022-06-23 08:11:26.976855
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule is not None, "Test failed due to instance not being created for class ActionModule"
    print("test_ActionModule completed successfully")


# Generated at 2022-06-23 08:11:34.702168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock
    import os

    task = mock.Mock()
    args = dict()
    args['name'] = 'test'
    args['depth'] = 1
    args['extensions'] = ["yaml", "yml", "json"]
    task.args = args

    _task = mock.Mock()
    task._task = _task
    _task._role = "test"
    _role = mock.Mock()
    _task._role._role_path = _role._role_path = os.path.dirname(os.path.abspath(__file__))
    _task._ds = _ds = mock.Mock()
    _task._ds._data_source = _ds._data_source = os.path.dirname(os.path.abspath(__file__))

    return task




# Generated at 2022-06-23 08:11:46.596454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest

    class TestActionModule(unittest.TestCase):
        def test_run(self):
            import sys, tempfile
            from ansible import utils
            class Fake_Loader(object):
                def load(self, data, file_name, show_content=True):
                    return data
                def _get_file_contents(self, datafile):
                    return datafile, False
            class Fake_DS(object):
                def __init__(self, data_source):
                    self._data_source = data_source
                def _get_source_from_directive(self, directive, item):
                    return item.split('/')[-1]

# Generated at 2022-06-23 08:11:58.380558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    load_files = []
    def load_files_func(filename):
        load_files.append(filename)
        return False, '', {'results':'test_ActionModule_run'}

    try:
        action = ActionModule("", {"ansible_facts":{}}, {}, {}, {})
    except ansible.errors.AnsibleError as e:
        raise e
    action._loader.load_from_file = load_files_func
    action._set_root_dir = lambda x: None
    role = {
        '_role_path':"/path/to/file"
    }
    action._task = {
        '_role':role
    }
    action._task._ds = {
        '_data_source':"/path/to/file"
    }

# Generated at 2022-06-23 08:12:06.296292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'
    assert ActionModule.__doc__ == 'Loads variables into the context by ' \
                                   'reading a file or recursively reading a ' \
                                   'directory. '
    assert ActionModule.TRANSFERS_FILES == False
    assert ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files',
                                                'extensions', 'ignore_unknown_extensions']
    assert ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule.valid_extensions == ActionModule.VALID_FILE_EXTENSIONS
    assert ActionModule.VAL

# Generated at 2022-06-23 08:12:16.295009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Test a wrong plugin name
    try:
        ActionModule(None, None, None, None, None)
        assert 0
    except TypeError:
        pass

    #Test a wrong action name
    try:
        ActionModule({"connection": ["local"], "name": ["action_1"], "module_name": "include_vars_1"}, None, None, None, None)
        assert 0
    except TypeError:
        pass

    #Test a wrong module args configuration
    #Test with no args
    try:
        ActionModule({"name": ["action_1"], "module_name": "include_vars"}, None, None, None, None)
        assert 0
    except TypeError:
        pass
    #Test with non-dict args

# Generated at 2022-06-23 08:12:26.793698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    from ansible.module_utils.six import StringIO

    sys_module = __import__('sys')
    old_module = sys_module.modules.get('sys', None).modules.get('stdin', None)
    sys_module.modules['sys'].stdin = StringIO('foo')

    class TestActionModule(unittest.TestCase):
        """ Test class for the ActionModule object. """

        def __init__(self, *args, **kwargs):
            unittest.TestCase.__init__(self, *args, **kwargs)

        def setUp(self):
            pass

        def tearDown(self):
            sys_module.modules['sys'].stdin = old_module


# Generated at 2022-06-23 08:12:34.525251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instances
    class TestModule():
        def __init__(self, args):
            self._args = args
    class TestTask():
        def __init__(self, args):
            self._args = args
    class TestDataSource():
        def __init__(self, data_source):
            self._data_source = data_source
    class TestRole():
        def __init__(self, role_path):
            self._role_path = role_path
    test_module = TestModule({
        'name': 'all_facts',
        'hash_behaviour': 'replace',
        '_raw_params': '../files/ansible_facts.yml'
    })

# Generated at 2022-06-23 08:12:43.458137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_module_loader = '/test/module/loader'
    test_module_utils_path = '/test/module/utils/path'
    test_task_args = {'file': 'test_file'}

    am = ActionModule(test_module_loader, test_module_utils_path, test_task_args)

    assert am.TRANSFERS_FILES == False
    assert am._transfer_file == None
    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert am

# Generated at 2022-06-23 08:12:46.858057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']



# Generated at 2022-06-23 08:12:55.365284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = {'file': 'main.yml', 'extensions': 'yml'}
    action = ActionModule(None, args, False, False, '.')
    action._set_args()
    assert action.source_dir is None
    assert action.source_file == 'main.yml'
    assert action.depth is None
    assert action.files_matching is None
    assert action.ignore_files is None
    assert action.valid_extensions == ['yml']

# Generated at 2022-06-23 08:12:56.852780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

# Generated at 2022-06-23 08:13:08.014062
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Initialize input parameters
    test_vars = {}

    test_in_task = [
        {'name': 'test_in_task', 'dir': '/test_dir_in_task', 'extensions': 'yml,yaml'},
        {'test_file_param': 'test_in_task', 'file': 'test_in_task', 'depth': 1, 'extensions': 'yml,yaml',
         'ignore_unknown_extensions': True},
        {'file': 'test_in_task', 'depth': 1, 'ignore_unknown_extensions': True}
    ]


# Generated at 2022-06-23 08:13:10.317349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Fill in
    pass


# Generated at 2022-06-23 08:13:12.190977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:13:21.910001
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module
    assert action_module.TRANSFERS_FILES == False
    assert 'dir' in action_module.VALID_DIR_ARGUMENTS
    assert 'depth' in action_module.VALID_DIR_ARGUMENTS
    assert 'files_matching' in action_module.VALID_DIR_ARGUMENTS
    assert 'ignore_files' in action_module.VALID_DIR_ARGUMENTS
    assert 'extensions' in action_module.VALID_DIR_ARGUMENTS
    assert 'ignore_unknown_extensions' in action_module.VALID_DIR_ARGUMENTS
    assert 'file' in action_module.VALID_FILE_ARGUMENTS
    assert '_raw_params' in action_module.VALID_FILE

# Generated at 2022-06-23 08:13:24.484421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:13:35.628685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    # Create temporary directory with vars files
    import os, tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create a sub directory
        path = os.path.join(tmpdirname, 'subdir')
        os.mkdir(path)

        # Create some files
        with open(os.path.join(tmpdirname, 'file1.yaml'), 'w') as f:
            f.write('b: 1\n')

        with open(os.path.join(tmpdirname, 'file2.yaml'), 'w') as f:
            f.write('b: 2\n')


# Generated at 2022-06-23 08:13:42.341843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case 1
    class MockTask(object):
        def __init__(self):
            self.args = {'hash_behaviour': 'merge',
                         'name': 'ansible_facts',
                         'ignore_files': ['*.pyc'],
                         'dir': '/home/ansible/include_vars/test/vars',
                         'depth': '2',
                         'files_matching': '.*',
                         'ignore_unknown_extensions': False,
                         'extensions': ['yml', 'yaml']
                        }
            self._role = None

    test_obj = ActionModule()
    test_obj._task = MockTask()

    # Test case 2

# Generated at 2022-06-23 08:13:49.090932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None
    assert module.VALID_ALL is not None
    assert module.VALID_FILE_EXTENSIONS is not None
    assert module.VALID_DIR_ARGUMENTS is not None
    assert module.VALID_FILE_ARGUMENTS is not None
    assert module.TRANSFERS_FILES is not None



# Generated at 2022-06-23 08:13:49.971478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-23 08:13:51.588467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    #assert False
    pass

# Generated at 2022-06-23 08:13:52.566904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:14:00.791169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #import ansible.plugins.action.include_vars as action_include_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins import module_loader


# Generated at 2022-06-23 08:14:11.697748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    fake_role = None
    if path.exists(path.join(path.dirname(__file__), 'include_vars_dir', 'roles', 'include_dir')):
        fake_role = path.join(path.dirname(__file__), 'include_vars_dir', 'roles', 'include_dir')


# Generated at 2022-06-23 08:14:18.946277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Constructor of class ActionModule
    '''
    am = ActionModule()
    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert am.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-23 08:14:28.398687
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Testing ArgumentError: if dirs and files:

    source_dir = 'test_dir'
    source_file = 'test_file'

    task = {
        'args': {
            'dir': source_dir,
            'file': source_file
        }
    }

    am = ActionModule(task, {})

    failed = False
    err_msg = ''

    try:
        am.run()
    except AnsibleError as e:
        failed = True
        err_msg = to_native(e)

    assert failed
    assert err_msg == 'You are mixing file only and dir only arguments, these are incompatible'

    # Testing ActionError: if source_file:
    source_file = 'test_file'


# Generated at 2022-06-23 08:14:28.792937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise Exception()

# Generated at 2022-06-23 08:14:31.754541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    mod.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 08:14:43.275934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_dir = 'test/unit/plugins/action/test_action_include_vars/module_dir'
    data_source = 'test/unit/plugins/action/test_action_include_vars/module_dir/main.yml'
    role_path = 'test/unit/plugins/action/test_action_include_vars/roles/test_role'
    data_source_path = 'test/unit/plugins/action/test_action_include_vars/roles/test_role/tasks/main.yml'
    # Constructor 1
    action_module = ActionModule(
        task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None
    )
    # Constructor 2
    action_module.get_loader()

# Generated at 2022-06-23 08:14:44.640733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__.startswith("Load yml files recursively from")

# Generated at 2022-06-23 08:14:55.392679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.inventory.group import Group

    add_all_plugin_dirs()
    loader = DataLoader()
    h = Host(name='hostname')
    g = Group('groupname')

    add_all_plugin_dirs()
    loader = DataLoader()

# Generated at 2022-06-23 08:15:04.774806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(argument_spec=dict())
    module.fail_json = lambda **kwargs: print(kwargs)
    module.params = dict(
        name={'aliases': [u'b', u'c']},
        hash_behaviour='merge',
        dir='./vars',
        depth=0,
        ignore_files=['pulp.yml', 'private.yml'],
        extensions=['yml', 'yaml', 'json'],
        ignore_unknown_extensions=True,
    )
    connection = Connection()
    play_context = PlayContext()
    play_context.connection = connection
    play_context.network_os = 'eos'
    play_context.remote_addr = '192.168.1.1'
    play_context.port = 22


# Generated at 2022-06-23 08:15:09.940383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def test_helper(module):
        assert module.run() == {
            'ansible_facts': {},
            'ansible_included_var_files': [],
            '_ansible_no_log': False,
            'failed': False,
        }

    # Test ActionModule without any options passed
    action = ActionModule(dict(), dict())
    test_helper(action)

    # Test ActionModule with the only valid option 'name' passed
    action = ActionModule(dict(), dict(name='test'))
    test_helper(action)

    # Test ActionModule with all valid options passed
    action = ActionModule(dict(), dict(name='test', hash_behaviour='merge'))
    test_helper(action)

# Generated at 2022-06-23 08:15:21.502672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar
    import io
    import json

    class TestActionModule(ActionModule):
        pass

    class TestVariableManager:
        def __init__(self):
            self.vars = dict()

        def get_vars(self, loader, play, task, include_hostvars=True):
            return self.vars

    class TestTask(Task):
        def __init__(self, args):
            self.args = args
            self.action = 'include_vars'
            self._role = None


# Generated at 2022-06-23 08:15:22.381311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return ActionModule()

# Generated at 2022-06-23 08:15:23.778819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)


# Generated at 2022-06-23 08:15:24.476082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    res = True
    return res

# Generated at 2022-06-23 08:15:35.646286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action.include_vars import ActionModule

    class FakeDS:
        def __init__(self):
            self._data_source = './tasks/main.yml'

    class FakeTask:
        def __init__(self):
            self._ds = FakeDS()

    class FakeRole:
        def __init__(self):
            self._role_path = './tasks'

    class FakeTask:
        def __init__(self):
            self._role = FakeRole()
            self._ds = FakeDS()
            self.args = dict()

    fake_task = FakeTask()
    fake_task.args = dict()


# Generated at 2022-06-23 08:15:37.374979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test constructor with different values
    ActionModule()


# Generated at 2022-06-23 08:15:40.860969
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None
    assert isinstance(action, ActionModule)



# Generated at 2022-06-23 08:15:47.705068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    plugin_name = 'include_vars'
    dir_args = ['dir', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    file_args = ['file', '_raw_params']
    all_args = ['name', 'hash_behaviour']

    for arg in dir_args:
        params = {arg: '/tmp'}
        am = ActionModule(name=plugin_name, task=MockTask(params=params), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    for arg in file_args:
        params = {arg: 'file.ext'}

# Generated at 2022-06-23 08:15:57.475594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test a good path
    source_dir = 'vars'
    source_file = 'main.yml'
    extensions = ['yaml', 'yml']

# Generated at 2022-06-23 08:15:59.286826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-23 08:16:10.837030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialization
    action_module = ActionModule()
    action_module.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
    action_module.VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    action_module.VALID_FILE_ARGUMENTS = ['file', '_raw_params']
    action_module.VALID_ALL = ['name', 'hash_behaviour']

    # Assertion for validation of constructor of class ActionModule
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

# Generated at 2022-06-23 08:16:22.569791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    path = 'ansible/tests/unit/mock/include_vars'
    inventory = InventoryManager(loader=DataLoader(), sources=path)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    task_vars = {'first_key': 10, 'second_key': 20, 'third_key': 30}
    loader = 'ansible/tests/unit/mock/include_vars/vars/main.yml'
    task_vars.update({'first_key': 10, 'second_key': 20, 'third_key': 30})
    args = {'_raw_params': loader}

# Generated at 2022-06-23 08:16:28.759461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import combine_vars

    assert ActionModule.TRANSFERS_FILES == False

    # VALID_FILE_EXTENSIONS
    assert isinstance(ActionModule.VALID_FILE_EXTENSIONS, list)
    assert 'yaml' in ActionModule.VALID_FILE_EXTENSIONS
    assert 'yml' in ActionModule.VALID_FILE_EXTENSIONS
    #assert 'yaml' or 'yml' or 'json' in ActionModule.VALID_FILE_EXTENSIONS

    # VALID_DIR_ARGUMENTS
    assert isinstance(ActionModule.VALID_DIR_ARGUMENTS, list)
    assert 'dir' in ActionModule.VALID_DIR_ARGUMENTS

# Generated at 2022-06-23 08:16:32.107379
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert action_module
    return action_module

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-23 08:16:34.939691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        model_object = ActionModule(None, None, None, None)
        model_object.run()
    except Exception as error:
        raise error

# Generated at 2022-06-23 08:16:44.466552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create instance of task
    from ansible.playbook.task import Task
    t = Task()

    # Create instance of action module
    from ansible.plugins.action.include_vars import ActionModule
    mod = ActionModule(t, {}, [])

    # Test that the instance was created correctly
    assert mod._task == t
    assert mod._connection is None
    assert mod._play_context is None
    assert mod._loader is None
    assert isinstance(mod.VALID_FILE_EXTENSIONS, list)
    assert isinstance(mod.VALID_DIR_ARGUMENTS, list)
    assert isinstance(mod.VALID_FILE_ARGUMENTS, list)
    assert isinstance(mod.VALID_ALL, list)

# Generated at 2022-06-23 08:16:55.731593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with directory option
    t = {"name": "test", "dir": "test_dir"}
    m = ActionModule(t)
    m._set_args()
    assert m.hash_behaviour is None
    assert m.return_results_as_name == "test"
    assert m.source_dir == "test_dir"
    assert m.source_file is None
    assert m.ignore_files is None
    assert m.depth is None
    assert m.files_matching is None
    assert m.ignore_unknown_extensions is False
    assert m.valid_extensions == ["yaml", "yml", "json"]

    # Test with file option
    t = {"name": "test", "file": "test_file"}
    m = ActionModule(t)
    m._set_args()
   

# Generated at 2022-06-23 08:16:56.881642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError

# Generated at 2022-06-23 08:17:00.424550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create object of class ActionModule
    obj = ActionModule()
    # Validate attributes of class ActionModule
    # TODO: Add asserts to validate the initial values of the attributes of class ActionModule
    assert False


# Generated at 2022-06-23 08:17:12.702115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook import play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory()

    source_file = __file__.replace('.pyc', '.py')
    print(source_file)

    task = Task()
    task.action = 'include_vars'
    # test "file" argument
    task.args = dict(file=source_file)

    play_context = play.PlayContext()

    pm = ActionModule(task, play_context, variable_manager, loader)
    results = pm.run(task_vars={})


# Generated at 2022-06-23 08:17:14.173742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionModule().run()
    assert(result is None)

# Generated at 2022-06-23 08:17:22.820426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # arrange
    import os
    import sys
    import tempfile
    import yaml
    import textwrap
    import mock

    # _set_dir_defaults
    def test_set_dir_defaults():
        # arrange
        action_module = ActionModule(task=mock.MagicMock(), connection=mock.MagicMock(), play_context=mock.MagicMock(), loader=mock.MagicMock(), templar=mock.MagicMock(), shared_loader_obj=mock.MagicMock())
        action_module._task.args = {}
        
        # act
        action_module._set_dir_defaults()

        # assert
        assert action_module.depth == 0
        assert action_module.matcher == None
        assert action_module.ignore_files == []

        # arrange


# Generated at 2022-06-23 08:17:31.997508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock the class
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # assign the attribute for unit test
    am.show_content = False


# Generated at 2022-06-23 08:17:34.479804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for run function of class ActionModule"""
    ac = ActionModule(None, None)

# Generated at 2022-06-23 08:17:36.782374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if __name__ == "__main__":
        pass


# Generated at 2022-06-23 08:17:40.301757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(type(ActionModule))
    # d.run()

# Generated at 2022-06-23 08:17:43.283190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run(tmp='tmp', task_vars='task_vars')
    # add test to check returned object


# Generated at 2022-06-23 08:17:44.807035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act_mod = ActionModule()
    assert isinstance(act_mod, ActionModule)

# Generated at 2022-06-23 08:17:45.948866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    inst = ActionModule()
    inst.run()

# Generated at 2022-06-23 08:17:49.065675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:17:55.688200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This is a fake task object with fake role object
    fake_task = type('obj', (object,), {})()
    fake_role = type('obj', (object,), {})()
    fake_role._role_path = "roles/some_role"
    fake_task._role = fake_role
    fake_task._ds = None
    fake_task.args = {"file":"some_file"}

    fake_task._load_datasource = None
    fake_task._ds = "test/test_include_vars.py"
    fake_task._ds_local_path = "test/test_include_vars.py"
    fake_role._role_path = "test"

    # Create an instance of ActionModule object
    # and call run with fake task object
    action_module = ActionModule()


# Generated at 2022-06-23 08:17:56.883440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-23 08:18:00.441214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockModule(ActionModule):
        def __init__(self):
            pass
    obj = MockModule()
    assert obj.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert obj.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert obj.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert not obj.VALID_ALL


# Generated at 2022-06-23 08:18:08.882233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader as loader
    plugin = loader.get_plugin('action', 'include_vars')
    assert isinstance(plugin.VALID_FILE_EXTENSIONS, list)
    assert isinstance(plugin.VALID_DIR_ARGUMENTS, list)
    assert isinstance(plugin.VALID_FILE_ARGUMENTS, list)
    assert isinstance(plugin.VALID_ALL, list)
    assert plugin.TRANSFERS_FILES is False


# Generated at 2022-06-23 08:18:17.196797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # ActionModule_run() returns {'ansible_facts': {}, 'ansible_included_var_files': [filepath], '_ansible_no_log': False, 'failed': True} when filepath does not exist
    # Assume that filepath does not exist
    test_obj = ActionModule()
    test_obj._task.args['file'] = 'filepath'

    ret = test_obj.run()
    assert ret['ansible_facts'] == {}
    assert ret['ansible_included_var_files'] == ['filepath']
    assert ret['_ansible_no_log'] == False
    assert ret['failed'] == True