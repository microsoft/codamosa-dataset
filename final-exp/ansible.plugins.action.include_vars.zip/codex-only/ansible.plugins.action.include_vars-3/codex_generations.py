

# Generated at 2022-06-23 08:08:12.476007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule(None, None, None)
    assert isinstance(action_module_obj, ActionModule)

# Generated at 2022-06-23 08:08:17.059265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test ActionModule constructor...")
    a = ActionModule()
    if a:
        print("ActionModule class initialized successfully")

# Generated at 2022-06-23 08:08:18.411071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am

# Generated at 2022-06-23 08:08:31.015542
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence

    action_module = ActionModule()

    # Test for method _ignore_file
    print('Testing _ignore_file method')
    action_module._task.args = {'ignore_files': ['*.BAK']}
    action_module.ignore_files = action_module._task.args['ignore_files']
    assert action_module._ignore_file('file.bak') is True
    action_module._task.args = {'ignore_files': ['*.BAK', '*.bak']}
    action_module.ignore_files = action_module._task.args['ignore_files']
    assert action_module._ignore_file('file.bak') is True
   

# Generated at 2022-06-23 08:08:37.388733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module.TRANSFERS_FILES == False
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:08:38.832524
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule



# Generated at 2022-06-23 08:08:39.953118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError

# Generated at 2022-06-23 08:08:40.893994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass



# Generated at 2022-06-23 08:08:44.295093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test method can't be called because the test method of class ActionBase
    # calls run method which calls the run method of class ActionMoudle
    # which is being tested here.
    # Hence, this test method is not called.
    pass

# Generated at 2022-06-23 08:08:45.741512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)


# Generated at 2022-06-23 08:08:50.632030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:09:01.766839
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    the_host = 'test_host'
    def _read_data_from_file(file):
        with open(file, 'r') as file:
            return file.read()
    the_block = Block.load(_read_data_from_file('../test/test_playbook.dat'), the_host, loader=None, variable_manager=None)
    the_task = the_block.block[0]
    the_role = Role()

# Generated at 2022-06-23 08:09:10.676251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def return_values(self):
        # return self._task.args
        # return self._task.vars
        return self._task._ds.get_vars()

    def return_self_task_args(self):
        return self._task.args

    import re
    import mock
    from ansible.utils.vars import combine_vars

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    def return_self_task_vars(self):
        return self._task.vars

    def return_self_task_ds_get_vars(self):
        return self._task._ds.get_vars()


# Generated at 2022-06-23 08:09:22.632766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.config.manager import ConfigManager
    from ansible.utils.display import Display

    # Data for testing path in dir
    test_dir_path = '../tests/vars_plugins/test_dir'

    # Data for testing

# Generated at 2022-06-23 08:09:31.012175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source_dir_data = """
---\n
rundeck1:\n
  host: rundeck.example.com\n
  port: 4440\n
"""
    source_dir_file_name = "rundeck.yml"
    root_dir = "/etc/ansible"

    valid_extensions = ["txt", "yml"]
    expected_results = {"rundeck1":{"host":"rundeck.example.com", "port":4440}}

    class _Args(object):
        def __init__(self, dir=None, depth=0, files_matching=None, ignore_files=None, vars=1, _raw_params=None):
            self.dir = dir
            self.depth = depth
            self.files_matching = files_matching
            self

# Generated at 2022-06-23 08:09:38.607514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import ActionLoader
    from ansible.vars.manager import VariableManager
    import pytest

    task_vars = {'foo': 'bar'}
    play_context = PlayContext()

    test_dir = '/tmp/'
    test_file = 'foo.yml'
    test_file_path = path.join(test_dir, test_file)
    test_file_content = 'foo: bar\n'

    from ansible.plugins.action import ActionBase
    class _ActionModule(ActionBase):
        _CONNECTION_PLUGIN_CLASS = None
        _WRAPPED_MODULES = None


# Generated at 2022-06-23 08:09:39.584396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:09:40.737674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Success case
    results = ActionModule()
    assert results is not None

# Generated at 2022-06-23 08:09:50.866190
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Stubbed out function
    def _loader__get_file_contents(self, filename):
        b_data = dict()
        show_content = dict()
        return b_data, show_content

    # Stubs
    def _task__role():
        _role = dict()
        _role['_role_path'] = '/some/path/to/role'
        return _role

    # Stubbed out class
    class _ActionModule():
        pass

    # Stubbed out function
    def _task__ds():
        _ds = dict()
        _ds['_data_source'] = '/some/path'
        return _ds

    # Stubbed out function
    def _traverse_dir_depth():
        current_root = '/some/path/to/role/vars/'

# Generated at 2022-06-23 08:09:52.682443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-23 08:09:53.383161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:09:59.213449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_args = {
        u'username': u'foo',
        u'password': u'bar',
        u'module_name': u'mymodule'
    }

    tmp_args = {
        u'ANSIBLE_MODULE_ARGS': task_args
    }

    module = ActionModule(dict(), tmp_args)
    assert(module)

# Generated at 2022-06-23 08:10:02.182147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    newobj = ansible.plugins.action.ActionModule('task', dict(action='test'), False, '/path/to/directory', False, None)
    assert newobj


# Generated at 2022-06-23 08:10:08.133622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 1: dir is set and readable
    # inputs
    action_module_obj = ActionModule("", "", "", "")
    action_module_obj._task._role._role_path = "role/path"
    action_module_obj._loader._get_file_contents=lambda x:("{'test': 'test'}", True)
    action_module_obj._task.args = {"dir": "test"}
    action_module_obj._task.args["depth"] = 1
    action_module_obj.run(task_vars={})


# Generated at 2022-06-23 08:10:19.196197
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule('task', 'play', 'args', 'loader', 'templar', 'shared_loader_obj')
    action_module._task.ds = {'role': 'test_role'}
    action_module._task._role = {'role_path': 'test_path/test_role'}
    action_module._task._role.ds = {'role_path': 'test_path'}

    # Testing directory
    action_module._task.args = {'dir': 'test_dir', 'depth': '1'}
    action_module._set_args()
    action_module._set_dir_defaults()
    action_module._set_root_dir()
    data = action_module._traverse_dir_depth()
    assert action_module.ignore_files == []
    assert action_

# Generated at 2022-06-23 08:10:20.567356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None


# Generated at 2022-06-23 08:10:28.434173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = '''
    - action:
        include_vars:
          dir: playbooks/vars
          name: foo
          ignore_files:
            - 'main\.yml'
            - '01_main\.yml'
    '''

    am = ActionModule(t)
    # Name should be a string
    name = am.return_results_as_name
    assert isinstance(am.return_results_as_name, string_types)
    # ignore_files should be a list, not a dict
    assert isinstance(am.ignore_files, list)



# Generated at 2022-06-23 08:10:36.366911
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def get_valid_dir_arguments():
        return ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']

    def get_valid_file_arguments():
        return ['file', '_raw_params']

    def get_valid_all():
        return ['name', 'hash_behaviour']

    def get_tmp_result():
        return {'ansible_facts': {'vars': {'a': 1, 'b': 2, 'c': 3, 'd': 4}}}

    def get_tmp_task_vars():
        return {'a': 1, 'b': 2}

    def get_file_content(filepath):
        with open(filepath, 'r') as f:
            return f.read()

    import unittest


# Generated at 2022-06-23 08:10:44.943035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(dict(
        name='MockTest',
        dir='vars',
        depth=0,
        files_matching='^.*\.yml$',
        ignore_files='^.*\.ignore$',
        extensions=['yml']),
        task=dict(
            args=dict(
                dir='vars',
                depth=0,
                files_matching='^.*\.yml$',
                ignore_files='^.*\.ignore$',
                extensions=['yml']
            )
        )
    )

    module._set_dir_defaults()
    module._set_root_dir()
    module._set_args()

    # Check if the _set_dir_defaults function works
    assert not module.depth
    assert module.files_matching
    assert not module.ignore

# Generated at 2022-06-23 08:10:49.518564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionModule)
    assert isinstance(a._task, dict)
    assert isinstance(a._connection, dict)
    assert isinstance(a._play_context, dict)
    assert isinstance(a._play, dict)
    assert isinstance(a._loader, dict)

# Generated at 2022-06-23 08:10:50.110972
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:10:51.527925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:11:02.318008
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n test_ActionModule_run start")
    # test case: source_dir exist, depth set, dict containing list of ignore files
    # 1. set default values, if not provided
    # 2. if source_dir does not exists, raise failed
    # 3. if source_dir is not a directory, raise failed
    # 4. for each root_dir,var_files in sorted_walk:
    #       if current_depth <= self.depth or self.depth == 0:
    #           current_files.sort()
    #           yield (current_root, current_files)
    # 5. start iterating through files in a directory
    # 6. check if files are to be ignored
    # 7. load files
    # 8. update results
    # 9. return results

    # set initial values

# Generated at 2022-06-23 08:11:07.516414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict()).VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule(dict(), dict()).VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule(dict(), dict()).VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule(dict(), dict()).VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:11:19.188729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import pkgutil

    path = os.path.dirname(__file__)
    path = os.path.join(path, "../action_plugins")

    # load action module dynamically
    class_str = pkgutil.get_data(__package__, "include_vars.py")
    class_str = class_str.decode('utf-8')
    class_str = class_str.replace('from ansible.module_utils.basic import *\n', 'from ansible.module_utils.basic import AnsibleModule\n')
    class_str = class_str.replace('\nfrom ansible.module_utils._text import to_native, to_text\n', '')

# Generated at 2022-06-23 08:11:29.073823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.parsing.yaml

    assert hasattr(ansible.parsing.yaml, 'safe_load')
    assert hasattr(ansible.parsing.yaml, 'safe_dump')
    assert hasattr(ansible.parsing.yaml, 'load')
    assert hasattr(ansible.parsing.yaml, 'dump')
    assert hasattr(ansible.parsing.yaml, 'load_all')
    assert hasattr(ansible.parsing.yaml, 'FullLoader')
    assert hasattr(ansible.parsing.yaml, 'SafeLoader')
    assert hasattr(ansible.parsing.yaml, 'FullLoader')
    assert hasattr(ansible.parsing.yaml, 'SafeLoader')

# Generated at 2022-06-23 08:11:39.285932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert am.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:11:41.837062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test for constructor of class ActionModule"""
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:11:52.324962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.role.include import IncludeRole
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils import context_objects as co

    with co.GlobalContext(basedir=os.getcwd()):
        loader = DataLoader()
        task_ds = dict(action=dict(module='vars', args=dict(name='foo')))
        task_ds['action']['args']['file'] = 'file1.yml'
        task_ds['action']['args']['_raw_params'] = 'file1.yml'
        task_ds = AnsibleVaultEncryptedUnicode.from_plaintext(task_ds, vault_password='ansible')

# Generated at 2022-06-23 08:12:02.149745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ActionModuleTest(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(ActionModuleTest, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)

    ActionModuleTest(task={}, connection={}, play_context={}, loader={}, templar={}, shared_loader_obj={})

# Generated at 2022-06-23 08:12:02.956274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 08:12:09.613800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestAction(ActionModule):
        def run(self, tmp=None, task_vars=None):
            warnings = []

            assert self._task.args['hash_behaviour'] is None
            assert self._task.args['name'] is None
            assert self._task.args['dir'] == '/tmp'
            assert self._task.args['files_matching'] is None
            assert self._task.args['ignore_files'] is None
            assert self._task.args['extensions'] == ['yaml', 'yml', 'json']

            return {
                'failed': False,
                'warnings': warnings,
                'ansible_facts': {
                    'foo': 'bar'
                }
            }


# Generated at 2022-06-23 08:12:20.915103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Prerequisites
    module_return = {
        'ansible_facts': {
            'a': 'b',
            'c': 'd'
        }
    }

    # Test
    mock_am = ActionModule()
    mock_am._task = mock.Mock(name="_task")
    mock_am._task.args = {
        'name': 'my_facts',
        'dir': '/path/to/dir',
        'depth': 2,
        'files_matching': '^file_[\d]+\.yml$',
        'ignore_files': '^file_ignore.*'
    }
    mock_am._task._ds = mock.Mock(name="_ds")
    mock_am._task._ds._data_source = '/path/to/dir/main.yml'
   

# Generated at 2022-06-23 08:12:32.139438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Load the vars in a directory
    action_module = ActionModule(dict(
        _task=dict(
            args=dict(
                dir='vars',
                depth=1
            )
        ),
        _loader=Loader()
    ))
    results = action_module.run()
    assert isinstance(results, dict)
    assert results['ansible_included_var_files']
    assert results['ansible_facts']
    assert results['_ansible_no_log']

    # Load the vars in a file
    action_module = ActionModule(dict(
        _task=dict(
            args=dict(
                file='vars/test.yaml'
            )
        ),
        _loader=Loader()
    ))
    results = action_module.run()

# Generated at 2022-06-23 08:12:32.857144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ """
    pass

# Generated at 2022-06-23 08:12:42.777916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_args = dict(
        file='test_include_vars.yml'
    )

    source_file = 'test_include_vars.yml'
    task = dict(
        action = dict(
            module = 'include_vars',
            args = task_args
        )
    )
    module_args = dict()

    ansible_vars = dict()
    tmp = None
    loader = None
    test_action_mod = ActionModule(task, connection=None, play_context=None, loader=loader, templar=None, shared_loader_obj=None)
    task_vars = dict()
    test_action_mod._loader.set_basedir('/tmp/test/')
    result = test_action_mod.run(tmp, task_vars)

# Generated at 2022-06-23 08:12:54.672598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import module_utils
    from ansible.utils.vars import combine_vars
    a = ActionModule()
    assert a is not None
    assert a.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert a.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert a.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert a.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:12:57.753020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule()
    if not isinstance(test,ActionModule):
       print("Unit test for constructor of class ActionModule[FAILED]")
    else:
       print("Unit test for constructor of class ActionModule[PASSED]")

# Generated at 2022-06-23 08:13:08.911087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars

    # Create an instance of ActionModule
    action_module = ActionModule(None, None)

    # Set base attributes
    action_module._task = None
    action_module._loader = None
    action_module._templar = None

    # Create a task
    task = {}

    # Set task attributes
    task['args'] = {'down': 'stack'}
    task['delegate_to'] = None
    task['action'] = 'include_vars'
    # Set task's args attribute

# Generated at 2022-06-23 08:13:18.824230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Basic test for ActionModule
    """
    module = ActionModule()
    assert len(module.VALID_FILE_EXTENSIONS) == 3, "Invalid VALID_FILE_EXTENSIONS"
    assert len(module.VALID_DIR_ARGUMENTS) == 6, "Invalid VALID_DIR_ARGUMENTS"
    assert len(module.VALID_FILE_ARGUMENTS) == 2, "Invalid VALID_FILE_ARGUMENTS"
    assert len(module.VALID_ALL) == 2, "Invalid VALID_ALL"
    return True


# Generated at 2022-06-23 08:13:22.040720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test if ActionModule works as expected
    '''
    # Test normal constructor
    am = ActionModule(dict(
        name='test',
        env=dict(
            ANSIBLE_ACTION_PLUGINS='../action_plugins',
            ANSIBLE_LIBRARY='../module_utils'
        )
    ), '../')
    assert am is not None

# Generated at 2022-06-23 08:13:24.776575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:13:29.178851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method `run` of class ActionModule.
    '''
    result = ActionModule.run(self, task_vars=None)
    self.assertIsNotNone(result)
    self.assertIsInstance(result, dict)


# Generated at 2022-06-23 08:13:37.168285
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # First test
    task_vars = {'a_var': 'a_data'}
    action_module = ActionModule(load_count=1, task_vars=task_vars)
    action_module._task.args = {'name': 'new_var_name', 'hash_behaviour': None,
                                'dir': '/etc', 'depth': '2', 'files_matching': '*',
                                'ignore_files': ['*.pyc'], 'extensions': ['yml'],
                                'ignore_unknown_extensions': False}
    action_module.show_content = False
    action_module.included_files = []
    action_module.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
    action_module._set_dir_defaults()

# Generated at 2022-06-23 08:13:41.958029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import unittest
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY3
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar


# Generated at 2022-06-23 08:13:42.643933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:13:50.947910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    args = dict(file="../test_playbooks/vars.yml", _raw_params="../test_playbooks/vars.yml")
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["../test_playbooks/hosts"])
    variable_manager.set_inventory(inventory)
    play_source = {"name": "test", "hosts": "localhost", "gather_facts": "no",
                   "tasks": [{"action": "include_vars", "args": args}]}

    play = Play().load

# Generated at 2022-06-23 08:14:00.817269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module='include_vars', args=dict(_raw_params='TEST_HOSTS')))
    a = ActionModule(task, None)

    assert(a._task.args['_raw_params'] == 'TEST_HOSTS')
    task = dict(action=dict(module='include_vars', args=dict(file='TEST_HOSTS')))
    a = ActionModule(task, None)
    assert(a._task.args['file'] == 'TEST_HOSTS')
    task = dict(action=dict(module='include_vars', args=dict(file='test_hosts.yml')))
    a = ActionModule(task, None)
    assert(a._task.args['file'] == 'test_hosts.yml')

# Generated at 2022-06-23 08:14:11.697216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # To test the run method, we first need to instantiate the class.
    # The class requires a variable called task_vars, which is a dictionary.
    # We don't need to use that variable in our own run tests, but we still need to pass it as an argument.
    # Since dictionaries are mutable and can be changed later, we can just pass an empty dictionary.
    # This is probably not the best way to handle this, but it will work for now.
    action_module_instance = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    
    # Set the arguments for our test instance.
    # We don't need to test all the arguments because it is all handled in the same way.
    # Just test one.
    action_module_

# Generated at 2022-06-23 08:14:18.412584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert a.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert a.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert a.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-23 08:14:27.700166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock of class ansible.module_utils.basic.AnsibleModule
    class MockAnsibleModule(object):

        def __init__(self, **kwargs):
            self.params = kwargs

        def exit_json(self, **kwargs):
            self.exit_json_kwargs = kwargs

    # mock of class ansible.plugins.action.ActionBase
    class MockActionBase(object):

        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

        def run(self, *args, **kwargs):
            self.run_args = args
            self.run_kwargs = kwargs
            return self.run_return

    # mock of class ansible.parsing.dataloader

# Generated at 2022-06-23 08:14:40.183608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    loader = FakeLoader()
    FILE_PATH = '/path/to/file.yml'
    HASH_BEHAVIOUR = 'merge'
    IGNORE_FILES = ['.git', '.svn']
    IGNORE_UNKNOWN_EXTENSIONS = False
    ROOT_DIR = '/path/to/dir'
    DEPTH = 2
    FILES_MATCHING = 'abc'
    SOURCE_DIR = ROOT_DIR
    VALID_EXTENSIONS = ['yml', 'yaml']
    VARS_NAME = 'my_vars'


# Generated at 2022-06-23 08:14:50.731556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os

    import pytest
    from ansible.errors import AnsibleError
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.six import string_types

    from ansible_collections.allensdk.custom_modules.plugins.actions.include_vars import ActionModule

    # We should be able to run the code on a file with a valid extension
    class FakeLoader:
        def _get_file_contents(self, filename):
            return '{"testkey": "testvalue"}', True

        def load(self, data, file_name, show_content):
            return data

    class FakeTask:
        def __init__(self):
            self.args = {}

# Generated at 2022-06-23 08:15:01.040079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import connection_loader, become_loader, action_loader

    loader = action_loader.get('include_vars', class_only=True)
    assert issubclass(loader, ActionModule)

    # test case 1. return_results_as_name not specified
    task_vars = dict()
    inventory = dict()
    loader = TaskQueueManager(
        inventory=inventory,
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback=None,
        run_tree=False,
        forks=None,
        module_path=None,
        task_uuid=None,
        transport='local'
    )
    action = loader.action_loader

# Generated at 2022-06-23 08:15:13.709466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config = {'roles': 'roles/', 'tasks': 'tasks/', 'action': 'tasks',
              'name': 'tasks/main.yml', 'action_plugins': 'action_plugins/',
              'module_utils': 'module_utils/', 'tags': ['foo'], 'task':
                  {'args': {'name': 'foo', 'hash_behaviour': 'merge'}}}
    config['task']['args']['dir'] = 'roles/test/vars'
    path = 'test-module-path/'
    loader = 'test-module-loader'
    variable_manager = None
    display = 'test-module-display'
    task_vars = {}

    action_module = ActionModule(config, path, loader, variable_manager, display)
    action_

# Generated at 2022-06-23 08:15:14.738296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(1, 2, 3, 4, 5)
    assert True

# Generated at 2022-06-23 08:15:22.530004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.plugins.loader import action_loader

    def _create_task(name, task_args=None, task_action=None):
        _play_context = FakePlayContext()
        _play_context._play_context.update(task_action)
        return FakeTask(name, task_args, _play_context)

    def _create_loader(task_data=None):
        # create temporary file with task_data which is used by FakeTaskLoaderBase during initialization
        if task_data:
            import tempfile
            _temp_file = tempfile.NamedTemporaryFile(delete=False)
            _temp_file.write(to_bytes(task_data))

# Generated at 2022-06-23 08:15:23.927276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return ActionModule, dict(direct=dict(dir='/tmp/', depth=1))

# Generated at 2022-06-23 08:15:33.663996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #mock_ansible_module = mock.Mock()
    #mock_ansible_module.params = {'name': 'test_name',
    #                              'file': 'test_file.yml'}

    #mock_task = mock.Mock()
    #mock_task._role = None
    #mock_task.args = {'file': 'test_file.yml'}
    #mock_task.ds = 'test_ds'
    #mock_task._ds = 'test_ds'

    #am = ActionModule(mock_ansible_module, mock_task, tmp=None)
    #am.run()
    assert True

# Generated at 2022-06-23 08:15:45.252830
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def get_mock_task():
        ansible_mock_task = dict()
        ansible_mock_task['args'] = dict()
        ansible_mock_task['args']['file'] = 'mock_file.yml'
        ansible_mock_task['args']['dir'] = 'mock_dir'
        ansible_mock_task['args']['hash_behaviour'] = 'merge'
        ansible_mock_task['args']['name'] = 'mock_name'
        ansible_mock_task['args']['depth'] = 'mock_depth'
        ansible_mock_task['args']['files_matching'] = 'mock_files_matching'

# Generated at 2022-06-23 08:15:47.560518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None


# Generated at 2022-06-23 08:15:49.351694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert ActionModule()
        assert isinstance(ActionModule(), ActionModule)
    except Exception:
        sys.exit(1)
    sys.exit(0)

# Generated at 2022-06-23 08:15:50.265319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:15:58.709624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.include_vars import ActionModule
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    test_ActionModule = ActionModule(
        task=dict(),
        connection=dict(),
        _play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    test_task_vars = HostVars(play=dict(
       name='play',
       hosts=dict(),
       _ds=dict(),
       _role=dict(
           _role_path='/path/to/roles/role_name',
           name='role_name'
       ),
       _variable_manager=VariableManager()
    ))

# Generated at 2022-06-23 08:16:01.256917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return ActionModule('task', 'play_context', 'loader', 'templar', 'shared_loader_obj')

# Generated at 2022-06-23 08:16:07.041013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import utils
    from ansible.module_utils.six import iteritems
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    test_context = dict()

    test_vars = dict()

    test_task = None

    test_loader = utils.plugins.loader.get("action",'include_vars')
    test_templar = utils.plugins.action.get("include_vars")

    test_play_context = dict()
    test_play_context['action'] = 'include_vars'

    templar = test_templar(play_context=test_play_context, new_stdin=None, loader=test_loader)

    templar._available_variables = test_vars


# Generated at 2022-06-23 08:16:19.577673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Initializing the action module
    action = ActionModule(dict(task=Task(), connection='local', play_context=dict(basedir='/home/ansible/test_dir/')))

    # generate task_vars
    task_vars = dict(a=dict(b=dict(c=1)))
    action.run(task_vars=task_vars)

    # generate expected result

# Generated at 2022-06-23 08:16:25.169779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-23 08:16:32.381639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule(None, None, None)
    t._task.args['file'] = 'myfile'
    t.VALID_FILE_EXTENSIONS.append('myext')
    t.VALID_FILE_EXTENSIONS.append('myext2')
    t._set_args()
    assert t.source_file == 'myfile'
    assert t.valid_extensions == ['yaml', 'yml', 'json', 'myext', 'myext2']

# Generated at 2022-06-23 08:16:33.424805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule
    

# Generated at 2022-06-23 08:16:35.120757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-23 08:16:44.609952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_ActionModule: uses _task, which is a member of ActionBase.
    # _task uses the following members of Task, which are defined by init_runner_args()
    # ansible_version, ansible_facts_modified, ansible_no_log, ansible_check_mode, ansible_diff
    # We define all of these members, in addition to args
    args = dict()
    args['hash_behaviour'] = 'merge'
    args['name'] = 'Name'
    args['file'] = 'file'
    args['_raw_params'] = '_raw_params'
    ansible_no_log = False
    ansible_check_mode = False
    ansible_diff = False

# Generated at 2022-06-23 08:16:45.285788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:16:53.789808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance = ActionModule()
    assert instance
    assert instance.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert instance.VALID_ALL == ['name', 'hash_behaviour']
    assert instance.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert instance.VALID_FILE_ARGUMENTS == ['file', '_raw_params']


# Generated at 2022-06-23 08:17:06.161372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import unittest

    class TestActionModule(unittest.TestCase):
        def setUp(self):
            self.mock_task_vars = {
                'ansible_user': 'ansible',
                'ansible_password': 'ansible',
                'ansible_port': 22,
                'ansible_ssh_user': 'ansible',
                'ansible_ssh_pass': 'ansible',
                'ansible_ssh_port': 22,
                'ansible_connection': 'local',
                'ansible_python_interpreter': '/usr/bin/python',
                'ansible_connection_cache': {},
                'ansible_play_batch': [],
                'ansible_play_hosts': [],
                'ansible_check_mode': False
            }

# Generated at 2022-06-23 08:17:07.396497
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict())

# Generated at 2022-06-23 08:17:18.232154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import shutil
    import tempfile

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars

    # Need to create a mock task and PlayContext

    # Make a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Use different directory to test depth
    tmp_dir2 = tempfile.mkdtemp()

    # Create a fake file with contents
    f_h1 = open(os.path.join(tmp_dir, 'test.yml'), "w")

# Generated at 2022-06-23 08:17:27.920732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.module_docs as module_docs
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback import callbacks
    class CallbackModule(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(CallbackModule, self).__init__(*args, **kwargs)

# Generated at 2022-06-23 08:17:38.245127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # fake task
    args = {'dir': './tests/support', 'ignore_unknown_extensions': True}
    task = type('', (),{'args': args})()
    # fake loader
    loader = type('', (),{})()
    # fake play context
    play_context = type('', (),{})()
    # fake action module
    action_module = ActionModule(task, play_context, loader=loader)
    # does not return anything
    action_module.run()

# Generated at 2022-06-23 08:17:48.557499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import load_extra_vars
    from ansible.plugins.callback import CallbackBase

    loader = DataLoader()

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 08:17:51.019515
# Unit test for constructor of class ActionModule
def test_ActionModule():
     print('The constructor test')
     assert ActionModule() != None

# Generated at 2022-06-23 08:17:56.653630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test data
    yml_data = {
        "msg": [
            "Hello",
            "World"
        ]
    }

    # configuraton of mocks
    test_class = ActionModule(None, None, None, None)
    test_class.run()
    raise NotImplementedError("Unable to test the run method of ActionModule")

# Generated at 2022-06-23 08:18:05.721196
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create mock result object
    result = dict()

    # create mock action plugin object
    action_module = ActionModule(None, None, None, None)

    # create mock task object
    task = dict()
    task['args'] = dict()
    # create mock options object
    options = dict()
    options['hash_behaviour'] = 'merge'
    options['name'] = ''
    options['dir'] = '/home/username/ansible-files/'
    options['depth'] = 1
    options['files_matching'] = '.*'
    options['extensions'] = ['yml', 'yaml']
    options['ignore_files'] = ['*.example', '*.orig']
    options['ignore_unknown_extensions'] = False

    task['args'] = options

    # create mock task_vars object
   

# Generated at 2022-06-23 08:18:11.346560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # successful run of method run.
    source_dir = '../tests/roles/'
    action_module = ActionModule(None, {'dir': source_dir}, None, None)
    task_vars = dict()
    tmp = None
    result = action_module.run(tmp, task_vars)
    assert result['ansible_included_var_files'] == ['../tests/roles/example_role/vars/main.yml']
    assert result['ansible_facts'] == {'role_vars': {'role_var': 'yes'}}
    assert not result['failed']

    # test for an exception scenario where the argument of method run is neither a file or a dir.