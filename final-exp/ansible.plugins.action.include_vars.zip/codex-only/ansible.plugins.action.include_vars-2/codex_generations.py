

# Generated at 2022-06-23 08:08:20.923549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-23 08:08:30.059212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import json
    import logging
    import sys
    import tempfile
    import yaml

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text, to_native
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.include_vars import ActionModule

    logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger(__name__)

    yml_data = {'test_var_file': 'bar'}

    #####################################
    # Unit test for directory traversal #
    #####################################

    # Test directory traversal with depth set to 0
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 08:08:38.465844
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from collections import namedtuple
    from ansible.module_utils.common.collections import ImmutableDict
    module_utils_path = C.DEFAULT_MODULE_UTILS_PATH
    data_source = "playbook.yml"
    task_vars = ImmutableDict({'_ansible_module_u_tils': module_utils_path})
    role_path = "/Users/ajsanabria/playbooks/roles/arista"
    data_source = "playbook.yml"
    # Create Role object to pass as a property to Task class object.
    Role = namedtuple('Role', '_role_path')
    role_obj = Role(role_path)

# Generated at 2022-06-23 08:08:39.610365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-23 08:08:49.199218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockTask:
        def __init__(self):
            self.args = {'extensions': ['yaml', 'yml', 'json'],
                         'ignore_files': ['main.yml', 'main.yaml']}

    class MockDS:
        def __init__(self):
            self._data_source = "a/b"

    class MockRole:
        def __init__(self):
            self._role_path = "a/b"

    class MockLoader:
        def load(self, b_data, **kwargs):
            return b_data

        def _get_file_contents(self, fn):
            return "Data", True

    class MockTaskFunctions:
        def _execute_module(self, conn, data, task_vars, *args, **kwargs):
            return

# Generated at 2022-06-23 08:09:01.153601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import shutil
    import sys

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult

    context=PlayContext()
    task=Task()
    task_result=TaskResult(task, context)

    source_file=tempfile.mkstemp(suffix=".yml")
    source_file_path=source_file[1]

    source_data='''
    - hosts: all
      tasks:
        - debug: var=foo
  '''

    source_file_handle=open(source_file_path, 'w+')
    source_file_handle.write(source_data)
    source_file_handle.close()

    source_dir=tempfile.mk

# Generated at 2022-06-23 08:09:10.263448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setting up the mock arguments and context
    tmp = None
    task_vars = {'ansible_facts': {'a': 'b'},
                 'ansible_facts_modified': False,
                 'ansible_facts_cacheable': False,
                 'ansible_env': {'a': 'b'},
                 'ansible_console_color': 'auto'}
    tmp_path = '~/.ansible/tmp/ansible-tmp-1498579539.9-258020654049053/'

    module_name = 'vars_test'
    module_path = 'rolename/library/test.py'
    module_args = '{"test": "test"}'
    task_args = '{"test": "test"}'

    action_base = ActionBase()
    action_base._

# Generated at 2022-06-23 08:09:11.307005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None

# Generated at 2022-06-23 08:09:22.844283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    from collections import namedtuple
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    host = Host(name="localhost")
    play_context = PlayContext()
    variable_manager = VariableManager()

    task_vars_block1 = {
        "roles_path": "../ansible/roles",
        "ansible_connection": "local",
        "ansible_ssh_user": "root",
        "ansible_ssh_pass": "virtualeth"
    }
    task_vars_block

# Generated at 2022-06-23 08:09:23.443713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:09:26.076565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test = ActionModule()
        assert test.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    except AttributeError:
        assert False, 'Something went wrong with initialisation of class.'

# Generated at 2022-06-23 08:09:35.568532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # test case 1: include_vars, dir option
    play_context = PlayContext()
    templar = Templar(loader=None, variables=None)
    task_include = TaskInclude(block=dict(rescue=[], always=[], vars=[]), role=None, task_includes=dict())
    task_vars = dict()

    test_action_module = ActionModule(
        task=task_include,
        connection=None,
        play_context=play_context,
        loader=None,
        templar=templar,
        shared_loader_obj=None
    )

# Generated at 2022-06-23 08:09:36.637409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:09:45.580002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play

    from ansible.playbook.task import Task
    task = Task()
    task._role = None
    task._ds = 'test.yml'

    # Execute constructor of class ActionModule
    action = ActionModule(task, dict(ignore_unknown_extensions=False, extensions='yaml'))

    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action.VALID_ALL == ['name', 'hash_behaviour']

    #

# Generated at 2022-06-23 08:09:51.626166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test for method run of class `ActionModule`
    """
    obj = ActionModule()
    print(obj.run())

# Generated at 2022-06-23 08:09:58.445592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule.ActionModule(load_paths=['/foo'], task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']

test_ActionModule()

# Generated at 2022-06-23 08:10:05.070978
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test execution with option dir
    task_vars = dict()
    source_dir = ""
    task_vars["ansible_included_var_files"] = []
    task_vars["ansible_facts"] = dict()
    task_vars["ansible_included_var_files"] = []
    module = ActionModule()
    module.run(source_dir, task_vars)

    # Test execution with option file
    source_file = ""
    module.run(source_dir, task_vars)

# Generated at 2022-06-23 08:10:05.636019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:10:18.107509
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:10:27.907989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up a TaskExecutor
    task = MockTask()
    task._role = MockRole("/test/role/path")
    task._ds._data_source = "/test/role/path/tasks/main.yml"
    task._ds._play = MockPlay("testplay")
    task._ds._task = MockTask("testtask")
    task._ds._play._ds = task._ds
    loader = MockLoader()
    task_vars = MockTaskVars()
    tmp = MockTmp()

    # test 1: test run with directory source
    # set up test run() args
    task.args = {
        "dir": "/test/dir/path",
        "name": "testrun1",
        "hash_behaviour": "replace"
    }

# Generated at 2022-06-23 08:10:28.670062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:10:31.726137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 1
    setattr(ActionModule, "run", run)
    assert run(self, task_vars=None) == ansible_included_var_files

# Generated at 2022-06-23 08:10:42.962729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, {})
    assert ActionModule(None, {'hash_behaviour': 'merge'})
    assert ActionModule(None, {'name': 'tests'})
    assert ActionModule(None, {'dir': '/tmp/directory'})
    assert ActionModule(None, {'dir': '/tmp/directory', 'depth': 3})
    assert ActionModule(None, {'dir': '/tmp/directory', 'files_matching': 'test\\.yml'})
    assert ActionModule(None, {'dir': '/tmp/directory', 'ignore_files': ['.git'], 'extensions': ['yaml', 'yml']})
    assert ActionModule(None, {'dir': '/tmp/directory', 'ignore_files': ['.git']})

# Generated at 2022-06-23 08:10:45.814962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._get_action_name() == 'include_vars'
    assert ActionModule._get_action_name() == ActionModule.__name__
    assert ActionModule._get_action_name() == ActionModule.__class__.__name__

# Generated at 2022-06-23 08:10:50.892986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible
    from ansible.utils.vars import AnsibleVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    #from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.action import ActionBase
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    #AnsibleVars = AnsibleVars()
    loader = DataLoader()
    #var_manager = VariableManager()
    inventory = Inventory(loader, host_list='localhost')
    play_source

# Generated at 2022-06-23 08:11:00.527173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test that the constructor of ActionModule create the class with the right parameters """
    test_loader = C.ANSIBLE_LOADER_CLASS()
    test_task = C.ANSIBLE_TASK_CLASS()
    test_play_context = C.ANSIBLE_PLAY_CONTEXT_CLASS()

    tmp_s = ActionModule(loader=test_loader, task=test_task, play_context=test_play_context)

    tmp_dir_arguments = tmp_s.VALID_DIR_ARGUMENTS
    assert 'dir' in tmp_dir_arguments
    assert 'depth' in tmp_dir_arguments
    assert 'files_matching' in tmp_dir_arguments
    assert 'ignore_files' in tmp_dir_arguments
    assert 'extensions' in tmp_dir_arguments

# Generated at 2022-06-23 08:11:08.477025
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import os
    import tempfile
    from ansible.plugins.loader import action_loader

    test_file = '''- hosts: all
      tasks:
          - include_vars:
              dir: tests/test_action_modules/test_include_vars/test_vars
              files_matching: ".*.yml"
              extensions:
                  - yml
                  - yaml
              name: test_include_vars_result'''
    temp_dir = tempfile.mkdtemp()
    test_file_name = os.path.join(temp_dir, 'test.yaml')
    with open(test_file_name, 'w') as f:
        f.write(test_file)

# Generated at 2022-06-23 08:11:19.696971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.executor.task_result as task_result
    import ansible.plugins.loader as plugins_loader

    task_executor = plugins_loader.get('action', 'include_vars')

    my_action = task_executor()

    my_action._task.args = {
        'file': '/tmp/tests/test',
        'name': 'test_include_vars',
        'hash_behaviour': 'merge',
        'ignore_unknown_extensions': True
    }
    my_action._task.action = 'include_vars'
    my_action._task.role = None

    data_source = 'file.yaml'

# Generated at 2022-06-23 08:11:20.319183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:11:30.078298
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.parsing.splitter import parse_kv
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from tempfile import TemporaryDirectory

    # create inventory
    source = '''
    localhost
    '''
    inventory = InventoryManager(loader=None, sources=source)
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # create temp directory
    with TemporaryDirectory() as tempdir:
        test_dir = path.join(tempdir, 'test_dir')
        os.mkdir(test_dir)

# Generated at 2022-06-23 08:11:43.586915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # call without fail
    module = ActionModule(dict(task=dict(args=dict(file='test.yml'))), dict(file=True))
    module._loader._get_file_contents = lambda x, y: (x, y)
    module._set_args = lambda: None
    module._find_needle = lambda x, y: y
    assert module.run(dict(), dict()) == dict(ansible_facts=dict(), ansible_included_var_files=[], _ansible_no_log=True)

    # call with fail
    module = ActionModule(dict(task=dict(args=dict(file='test.yml'))), dict(file=True))
    module._loader._get_file_contents = lambda x, y: (x, y)

# Generated at 2022-06-23 08:11:46.843217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(name='test')
    assert am.name == 'test'
    assert am.TRANSFERS_FILES == False



# Generated at 2022-06-23 08:11:58.603683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #    def run(self, tmp=None, task_vars=None):
    # Test passing dir only arguments
    mock_task = MagicMock()
    mock_task._role = None
    mock_task._ds = None
    mock_task._ds._data_souce = None
    mock_task.args = dict(dir='dir_only_arguments_test')
    mock_task.args['depth'] = 1
    mock_task.args['files_matching'] = r'[0-9]*'
    mock_task.args['ignore_files'] = ['ignore_file_1', r'[^\d]*123']
    mock_task.args['ignore_unknown_extensions'] = False
    mock_task.args['extensions'] = ['yml']


# Generated at 2022-06-23 08:11:59.192808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:12:07.087115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    controller = ActionModule({'dir': 'dir_value', 'ignore_files': ['ignore_files_value']}, {'include_vars': {'dir': 'dir_value'}, 'ignore_files': ['ignore_files_value']})

    assert controller._task.args.get('dir') == 'dir_value'
    assert controller._task.args.get('ignore_files') == ['ignore_files_value']

    controller._set_args()
    assert controller.source_dir == 'dir_value'

    controller._set_root_dir()
    assert controller.source_dir == 'dir_value'

    controller._set_dir_defaults()
    assert controller.depth == 0
    assert controller.ignore_files == ['ignore_files_value']

    controller.source_file = 'file_value'
    assert controller.source

# Generated at 2022-06-23 08:12:17.058481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    import ansible.module_utils.facts as facts

    if facts.LOWERCASE_SYSTEM:
        facts.LOWERCASE_SYSTEM = None

    C.DEFAULT_HASH_BEHAVIOUR = 'merge'
    C.HASH_BEHAVIOUR = 'merge'
    C.DEFAULT_HASH_BEHAVIOUR = 'replace'
    C.HASH_BEHAVIOUR = 'replace'

    assert C.DEFAULT_HASH_BEHAVIOUR is not None and C.HASH_BEHAVIOUR is not None and C.DEFAULT_HASH_BEHAVIOUR == C.HASH_BEHAVIOUR == 'replace'
    # assert type(C.DEFAULT_HASH_BEHAVIOUR) == type(C.H

# Generated at 2022-06-23 08:12:27.112558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Given
    actionModule = ActionModule()
    actionModule._task = {'args': {'file': 'test.yml'}}
    actionModule._task.module_defaults = {}
    actionModule._task.noop_task = False
    actionModule._task.role = None
    actionModule._task.loop = None
    actionModule._task._role = None
    actionModule._task._ds = None
    actionModule._task.loop_control = {'loop': None}

    actionModule._task._ds = {'_data_source': '/path/to/profile/tasks/vars/test.yml'}

    #When
    result = actionModule.run()

    #Then
    assert result['ansible_facts']['test1'] == 'value1'

# Generated at 2022-06-23 08:12:30.840940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_ActionModule = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    return test_ActionModule

# Unit test to get right source file

# Generated at 2022-06-23 08:12:39.900340
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # make sure the constructor is working properly
    role = MockRole()
    task = MockTask(role)
    module = ActionModule(task, task_vars=dict())

    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-23 08:12:49.594706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import PluginLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import wrap_var

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    host = Host(name="localhost")
    group = Group

# Generated at 2022-06-23 08:13:00.784656
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.cli import CLI
    import ansible.constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    C.HOST_KEY_CHECKING = False
    cli = CLI(args=['localhost', '-i', './tests/inventory.ini'])

# Generated at 2022-06-23 08:13:05.594361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(), "test_fakeinventory", "test_fakeplay", C.DEFAULT_LOADER, C.DEFAULT_VARIABLE_MANAGER, C.DEFAULT_HASH_BEHAVIOUR)
    assert action
    assert action.depth is None


# Generated at 2022-06-23 08:13:07.534134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 08:13:19.060905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.common._collections_compat import MutableMapping
    import ast
    import json

    class ActionModule_run_Test(ActionBase):
        def __init__(self, action_name):
            self.action_name = action_name
        def run(self, tmp=None, task_vars=None):
            return super(ActionModule_run_Test, self).run(tmp, task_vars)


# Generated at 2022-06-23 08:13:25.098310
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys, yaml

    from ansible.plugins.loader import action_loader
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.utils.vars import combine_vars

    from units.mock.loader import DictDataLoader

    path = 'ansible.plugins.action.include_vars'
    mod = sys.modules[path]
    mod.ActionBase = ActionBase
    mod.ActionModule = ActionModule
    mod.ActionModule.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']

# Generated at 2022-06-23 08:13:26.141512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:13:30.357794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = MockTask()
    task.run = lambda *args, **kwargs: {}
    task._role = NotImplemented

    action = ActionModule(task, MockConnection())
    assert action._task is task
    assert action._connection is None
    assert action._play_context is task._play_context

# Generated at 2022-06-23 08:13:36.182196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(dict(task=dict(args=dict()), _task_fields=dict()), {})
    assert am.run(task_vars=dict()) == dict(ansible_facts=dict(), ansible_included_var_files=[], _ansible_no_log=True)

# Generated at 2022-06-23 08:13:36.875614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:13:45.875020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    from ansible.playbook.role.include import Include
    from ansible.playbook.task import Task
    from collections import namedtuple

    Option = namedtuple('Option', ('value', 'attrs'))

    class TestTask(Task):
        def __init__(self, args):
            super(TestTask, self).__init__(None, None)
            self._ds = None
            self._role = None
            self.args = args

    class TestInclude(Include):
        def __init__(self, task, play_context, loader, templar, shared_loader_obj, **kwargs):
            super(TestInclude, self).__init__(task, play_context, loader, templar, shared_loader_obj)


# Generated at 2022-06-23 08:13:52.474212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:13:53.123256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:13:54.837381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(1, 2, '', '', '', '', dict())
    return am

# Generated at 2022-06-23 08:13:55.523862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:13:57.443367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule() is not None


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:14:03.695222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:14:13.323851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'include_vars'
    tasks_module = module_utils.get_module_path(module_name)

    module_args = {}
    module_args["file"] = "/etc/ansible/roles/test/vars/main.yml"

    result = {}
    exec_module(tasks_module, module_args=module_args, result=result)

    expected_result = {"ansible_facts": {"testvar": "testval"},
                       "changed": False,
                       "_ansible_no_log": True,
                       "ansible_included_var_files": [
                           "/etc/ansible/roles/test/vars/main.yml"
                       ]
                      }

    assert result == expected_result


# Generated at 2022-06-23 08:14:14.016133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:14:16.044373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(True)

# Generated at 2022-06-23 08:14:17.003332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:14:23.790272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert a.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert a.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert a.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-23 08:14:24.443401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:14:28.041228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # needs to run "make test" for this.
    # no unit test for now, a real integration test is needed
    pass

# Generated at 2022-06-23 08:14:29.724554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ create an instance of ActionModule
    """
    action_module = ActionModule()


# Generated at 2022-06-23 08:14:35.192191
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    task = dict(
        action = 'include_vars',
        args = dict(
            name = 'test_role_vars',
            dir = 'vars/main.yml'
        )
    )

    task_ds = dict(
        action = 'include_vars',
        args = dict(
            name = 'test_role_vars',
            file = 'main.yml'
        )
    )

    task_ds_raw = dict(
        action = 'include_vars',
        args = dict(
            name = 'test_role_vars',
            _raw_params = '/tmp/test_data.yml'
        )
    )


# Generated at 2022-06-23 08:14:41.700484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    actionModule = ActionModule()
    task_vars = {"ansible_os_family": "Linux"}
    source_dir = "/etc"
    depth = 0
    ignore_files = ["test.yml", "test1.yml"]
    ignore_unknown_extensions = False
    valid_extensions = ["yaml", "yml", "json"]
    extensions = 'yaml'
    args = {"dir": source_dir, "depth": depth, "ignore_files": ignore_files, "ignore_unknown_extensions": ignore_unknown_extensions, "extensions": extensions}
    actionModule._task = MockObject()
    actionModule._task.args = args
    actionModule._set_args()
    actionModule._set_dir_defaults()
    actionModule._set_root_dir()
   

# Generated at 2022-06-23 08:14:45.948474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test1 = ActionModule()
    assert test1.VALID_ALL == ['name', 'hash_behaviour']
    assert test1.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert test1.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert test1.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

# Generated at 2022-06-23 08:14:56.324071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock parameters
    tmp = None
    task_vars = {'ansible_shell_type': 'csh'}

    # mock class
    class MockActionBase(object):
        def __init__(self, *args, **kwargs):
            pass

        def run(self, tmp, task_vars):
            return {'foo': 'bar'}

    # mock class
    class MockActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            pass

        def _find_needle(self, haystack, needle):
            return "zenoss_vars.yml"

        def _set_dir_defaults(self):
            pass

        def _set_args(self):
            self.source_dir = '/tmp/'
            self.source_file = None


# Generated at 2022-06-23 08:15:05.228708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    role = "testdata/roles/include_vars_role"
    include_vars_action = ActionModule(dict(), dict(), False)
    include_vars_action._task = dict()
    include_vars_action._task['_role'] = dict()
    include_vars_action._task['_role']._role_path = role
    setattr(include_vars_action._task['_role'], '_role_path', role)
    include_vars_action._set_root_dir()
    assert include_vars_action.source_dir == 'testdata/roles/include_vars_role/vars'
    setattr(include_vars_action._task['_role'], '_role_path', role + '/meta')
    include_vars_action._set_root

# Generated at 2022-06-23 08:15:16.818381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    from mock import patch, call, Mock
    from ansible.utils import plugin_docs

    with patch.object(plugin_docs, 'get_docstring') as mock_get_docstring:
        mock_get_docstring.return_value = 'Test docstring\n'
        sys.modules['ansible'] = Mock(**{'__file__': '/usr/lib/python2.7/site-packages/ansible/__init__.pyc'})
        sys.modules['ansible.module_utils'] = Mock(**{'__file__': '/usr/lib/python2.7/site-packages/ansible/module_utils/__init__.pyc'})

# Generated at 2022-06-23 08:15:24.289060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.network.common.tests.unit.compat.mock import Mock
    from ansible.module_utils.network.common.tests.unit.compat.mock import patch

    from ansible.module_utils.network.common.tests.unit.plugins.modules.utils import set_module_args
    from ansible.plugins.loader import ActionModuleLoader

    action = ActionModule(
        task=Mock(),
        connection=Mock(),
        play_context=Mock(),
        loader=Mock(wraps=ActionModuleLoader()),
        templar=Mock(),
        shared_loader_obj=Mock(),
    )

    set_module_args({
        'file': 'vars.yml'
    })


# Generated at 2022-06-23 08:15:26.081389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule is not None

# Generated at 2022-06-23 08:15:36.519688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars, load_options_vars

    # initializing needed objects
    loader = DataLoader()
    options_vars = load_options_vars(['--extra-vars', '{"api_username": "admin", "api_password": "password123"}', '--syntax-check'])
    options_

# Generated at 2022-06-23 08:15:38.574896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Test constructor of class ActionModule'''
    assert(ActionModule is not None)



# Generated at 2022-06-23 08:15:39.280225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:15:47.230929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # runs tests for class ActionModule method run
    import unittest
    from ansible.playbook.task import Task
    from ansible.parsing.vault import VaultAES256
    # class to run tests
    class MockTask(Task):
        def __init__(self):
            self._ds = {}
            self._ds['_ansible_vault'] = {}
            self._ds['_ansible_vault']['password'] = VaultAES256('ansible')
            self._ds['_ansible_vault']['password'].password = 'ansible'
            self._ds['_ansible_vault']['password'].vaults = {}

# Generated at 2022-06-23 08:15:49.033795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if ActionModule.__doc__ is None:
        print('The class ActionModule has no docstring')
    else:
        print('The class ActionModule has a docstring')


# Generated at 2022-06-23 08:16:01.254246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 1: test with invalid param '_raw_parmas'
    task = Object()
    task._role = Object()
    task._role._role_path = 'roles/test'
    task.args = dict()
    task.args['_raw_params'] = 'hosts'
    task.args['name'] = 'test'

    task._ds = Object()
    task._ds._data_source = 'hosts'

    action = ActionModule()
    action._task = task

    results = action.run()
    assert results['failed']

    # Test case 2: test with valid param 'file'
    task.args['file'] = 'hosts'
    results = action.run()

# Generated at 2022-06-23 08:16:12.652101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars import VariableManager


# Generated at 2022-06-23 08:16:17.135625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(test_action_module, ActionModule)

# Generated at 2022-06-23 08:16:18.363836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:16:19.472695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    AM = ActionModule()


# Generated at 2022-06-23 08:16:27.276266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = {'args': {'file': '/var/tmp/test.yaml', 'name': 'output', 'hash_behaviour': 'replace'}}
    tmp = '/tmp/test'
    result = {'failed': False, 'changed': False, 'ansible_included_var_files': ['test.yaml'], '_ansible_verbose_always': 'yes'}
    test_instance = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = {'root': '/var/tmp', 'home': '/home/user'}
    test_instance._find_needle = MagicMock()
    test_instance._find_needle.return_value = '/var/tmp/test.yaml'

# Generated at 2022-06-23 08:16:31.897813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('\n##############################################')
    print('Testing ActionModule.run():')
    print('##############################################\n')
    # Need to set up a playbook
    # Need to set up action
    # Need to play action
    # Need to get results
    return


# Generated at 2022-06-23 08:16:32.436279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:16:37.828518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {}

    params = {}
    params['dir'] = '/path/to/dir'
    params['depth'] = 0
    params['files_matching'] = '*.txt'

    action = ActionModule(task, params)

    assert action.source_dir == '/path/to/dir'
    assert action.depth == 0
    assert action.files_matching == '*.txt'

# Generated at 2022-06-23 08:16:46.322788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import shutil
    import sys
    import tempfile
    import unittest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    # Used in all test_*_dir functions
    TEST_ARGS_DIR = dict(
        dir='vars',
        depth=1,
    )
    # Used in the test_*_file functions
    TEST_ARGS_FILE = dict(
        file="file.yml",
        _raw_params="file.yml",
    )
    # Used in all test cases
    TEST_VARS = {}


# Generated at 2022-06-23 08:16:47.854635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:16:50.818845
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule.TRANSFERS_FILES == False
    action = ActionModule()
    assert action != None


# Generated at 2022-06-23 08:16:53.295672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_object = ActionModule()

    # execute method run with vars
    # test_object.run(vars=dict())
    pass

# Generated at 2022-06-23 08:16:54.249877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), "")

# Generated at 2022-06-23 08:17:06.428455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockActionModule:

        def __init__(self):
            self.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
            self.VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
            self.VALID_FILE_ARGUMENTS = ['file', '_raw_params']
            self.VALID_ALL = ['name', 'hash_behaviour']

            self._task_vars = {}

        def _traverse_dir_depth(self):
            """ Recursively iterate over a directory and sort the files in
                alphabetical order. Do not iterate pass the set depth.
                The default depth is unlimited.
            """
            current_depth = 0
            sorted_

# Generated at 2022-06-23 08:17:07.245549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:17:08.904780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test constructor of class 'ActionModule'
    """
    ActionModule()

# Generated at 2022-06-23 08:17:19.196721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    provider = dict(
        inventory=InventoryManager(loader=DataLoader(), sources=''),
        variable_manager=VariableManager(loader=DataLoader()),
        loader=DataLoader(),
        passwords={}
    )
    play_context = PlayContext()
    play_context.remote_user = 'my_user'
    play_context.remote_addr = '192.168.100.10'

# Generated at 2022-06-23 08:17:26.272254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest, yaml, os, tempfile, shutil, mock, json
    from ansible.module_utils.six import PY3
    if PY3:
        builtins_name = 'builtins'
    else:
        builtins_name = '__builtin__'

    # Set the fixture vars
    # parametrize method is used and vars file is given as input
    @pytest.fixture(scope="module",params=['./tests/fixtures/vars/vars_file.yml'])
    def setup_vars_file(request):
        split_path = request.param.split('/')
        yield split_path[-1], request.param

    # parametrize method is used and vars file is given as input

# Generated at 2022-06-23 08:17:39.948582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.env = dict()
    am.env['ANSIBLE_COLLECTIONS_PATHS'] = [
        "/home/ansible/collections",
    ]
    am._task = {'args': {'name': 'test', 'file': 'test.yml'}}

    am._loader = {'_basedir': '/home/ansible'}
    am.run()

    am._task = {'args': {'name': 'test', 'file': 'test.yml', 'hash_behaviour': 'merge'}}
    am.run()

    am._task = {'args': {'name': 'test', 'file': 'test.yml', 'hash_behaviour': 'replace'}}
    am.run()


# Generated at 2022-06-23 08:17:49.216413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    """
    # pylint: disable=protected-access
    class MockActionModule(ActionModule):
        """ mock class of ActionModule
        """
        def __init__(self, _task):
            self._task = _task
    class MockTask():
        """ mock class of Task
        """
        def __init__(self):
            self._task = self
            self.args = {
                'dir': '',
                'depth': None,
                'files_matching': None,
                'ignore_files': None,
                'extensions': ['yaml'],
                'ignore_unknown_extensions': True,
            }
    mock_task = MockTask()
    mock_action_module = MockActionModule(mock_task)
    assert mock_action_module._

# Generated at 2022-06-23 08:17:52.767523
# Unit test for method run of class ActionModule
def test_ActionModule_run():  # noqa
    set_module_args({
        'file': 'test_file',
    })
    module = ActionModule()
    module.run()

# Generated at 2022-06-23 08:17:55.075367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:18:04.963871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule('test', {})
    assert actionmodule.files_matching is None
    assert actionmodule.ignore_files is None
    assert actionmodule.ignore_unknown_extensions is False
    assert actionmodule.return_results_as_name is None
    assert actionmodule.source_dir is None
    assert actionmodule.source_file is None
    assert actionmodule.valid_extensions == ['yaml', 'yml', 'json']

    actionmodule = ActionModule('test', {'dir':'','ignore_files': '','_raw_params': ''})
    assert actionmodule.files_matching is None
    assert actionmodule.ignore_files is None
    assert actionmodule.ignore_unknown_extensions is False
    assert actionmodule.return_results_as_name is None
    assert actionmodule.source_dir == ''

# Generated at 2022-06-23 08:18:10.052376
# Unit test for constructor of class ActionModule
def test_ActionModule():

	action_module = ActionModule()
	assert action_module is not None
	assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'], 'The file extensions are set to the wrong strings'



# Generated at 2022-06-23 08:18:19.776621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from .mock.connection import Connection

    mock_loader = DictDataLoader({})
    mock_loader.set_basedir("/home/user/ansible")
    mock_task_ds = DataSourceWithRole("/home/user/ansible", Connection())

    my_task = Task(
        action=ActionModule(
            task=Task(),
            connection=None,
            _play_context=PlayContext(),
            loader=mock_loader,
            _task_ds=mock_task_ds,
            shared_loader_obj=None
        ),
        args={'ignore_files': "main"}
    )

    my_task.args = {'dir': "tests/unit/modules/action/files/vars", 'depth': 0, 'files_matching': None}