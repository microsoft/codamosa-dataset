

# Generated at 2022-06-23 08:08:13.952688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test if object constructor works without error and it is an instance of the class.
    """
    action_module = ActionModule(task=action_module_task)
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-23 08:08:16.193678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert m is not None


# Generated at 2022-06-23 08:08:18.409532
# Unit test for constructor of class ActionModule
def test_ActionModule():
	action_module = ActionModule(None,None,None,None)


# Generated at 2022-06-23 08:08:26.360946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    action = ActionModule(task=dict(action='include_vars', args=dict(name='data', file=dict(name='data1.yaml'))))
    action.loader = dict()
    action.loader['_find_needle'] = lambda *args: 'data1.yaml'
    action.loader['_get_file_contents'] = lambda *args: ("""
        hello: world
        """, True)
    action.loader['load'] = lambda *args: dict(hello='world')
    assert action.run()['ansible_facts']['data']['hello'] == 'world'

# Generated at 2022-06-23 08:08:33.441019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.plugins.action import ActionBase

    source_dir = TestActionModule.test_dir
    depth = 0
    files_matching = '.*.yml'
    valid_extensions = ['yml', 'yaml']
    return_results_as_name = 'test'

    # Create test data
    results = {
        'foo': 'bar',
        'baz': {
            'name': 'ansible',
            'age': 99,
            'job': 'devops'
        }
    }

    # Initialize necessary classes to test ActionModule
    play_source = dict

# Generated at 2022-06-23 08:08:40.290905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instace of ActionModule
    class ActionModule(ActionModule):
        pass

    # Assign values to required variables
    am = ActionModule()
    am.show_content = True
    am.included_files = []
    #am.return_results_as_name = ''
    return_results_as_name = 'failed'
    am.source_dir = './test/files/dir'

    # Create a dictionary that contains all possible arguments that can be passed to run
    task_vars = {}
    tmp = None

    # Call run method with some arguments
    result = am.run(tmp, task_vars)

    # Print the value returned by run, this will be the value of test
    print ("------------------------------------------")
    print ("Expected: failed: False, message: ''")

# Generated at 2022-06-23 08:08:47.489843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible = Ansible()
    ansible._loader = DataLoader()
    ansible._tqm = TaskQueueManager(0, None)
    assert ActionModule(task=Task(action=dict(name='include_vars', args=dict(file='/Users/linuxdynasty/shopping_list.yml'))), connection=None, play_context=PlayContext(), loader=ansible._loader, templar=None, shared_loader_obj=None)._task.action.args['file'] == '/Users/linuxdynasty/shopping_list.yml'


# Generated at 2022-06-23 08:08:57.624802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule()
    assert action_mod.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'], "Validation of valid dir arguments are incorrect"
    assert action_mod.VALID_FILE_ARGUMENTS == ['file', '_raw_params'], "Validation of valid file arguments are incorrect"
    assert action_mod.VALID_ALL == ['name', 'hash_behaviour'], "Validation of valid all arguments are incorrect"


# Generated at 2022-06-23 08:09:08.716023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.virtual.openvz import OpenVZFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.selinux import SELinuxFactCollector
    from ansible.module_utils.facts.virtual.chroot import ChrootFactCollector
    from ansible.module_utils.facts.virtual.lxc import LXCFactCollector
    from ansible.module_utils.facts.virtual.kvm import KVM

# Generated at 2022-06-23 08:09:20.481619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_arg = {
        'ignore_files': ['.gitkeep'],
        'depth': 0,
        'hash_behaviour': 'merge',
        'name': 'test_name',
        'dir': 'test_dir',
    }
    test_task = {'args': test_arg}
    test_loader = 'test_loader'
    test_templar = 'test_templar'
    test_shared_loader_obj = 'test_shared_loader_obj'
    test_action = ActionModule(test_task, test_loader, test_templar, test_shared_loader_obj)
    assert test_action._task.args == test_arg
    assert test_action._loader == test_loader
    assert test_action._templar == test_templar
    assert test_action

# Generated at 2022-06-23 08:09:22.786991
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule._task.action == "include_vars"
   

# Generated at 2022-06-23 08:09:33.193382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = {}
    add_host = {}
    add_host['_raw_params'] = 'test'
    add_host['hash_behaviour'] = 'merge'
    add_host['name'] = 'test'
    add_host['extensions'] = ['yaml', 'yml', 'json']
    add_host['ignore_unknown_extensions'] = True
    add_host['ignore_files'] = ['.example']
    test_obj = ActionModule(add_host, task_vars, loader=None, templar=None, shared_loader_obj=None)
    assert test_obj.hash_behaviour == 'merge'
    assert test_obj.return_results_as_name == 'test'

# Generated at 2022-06-23 08:09:44.586023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.parsing.dataloader
    import ansible.playbook.task
    import ansible.inventory.host
    import ansible.vars.manager
    import ansible.vars.hostvars
    from ansible.utils.vars import combine_vars

    host = ansible.inventory.host.Host("localhost")
    host.name = "localhost"
    host.vars = dict()
    host.vars.update({
        "ansible_python_interpreter": "/usr/bin/env python"
    })
    host.groups = ["test-group"]
    task = ansible.playbook.task.Task()
    task.args = dict()
    task.args.update({
        "file": "test_data",
    })
    task.vars = dict()
   

# Generated at 2022-06-23 08:09:47.941147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict())

# Generated at 2022-06-23 08:10:01.149093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import pytest
    from ansible.plugins.action import ActionModule
    from ansible.errors import AnsibleError
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash

    data_loader = DataLoader()
    variable_manager = VariableManager()
    play_source =  dict(
            name = "Ansible Play test_ActionModule_run for ActionModule",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = []
        )

# Generated at 2022-06-23 08:10:09.262468
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:10:10.306757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # todo
    assert True

# Generated at 2022-06-23 08:10:20.686680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionModule)
    assert isinstance(action._task.args, dict)
    assert len(action._task.args) == 0
    action._task.args['extensions'] = 'yaml'
    assert value_error('extensions must be a list')
    action._task.args['extensions'] = ['yaml']
    assert value_error('extensions must be a list')
    action._task.args['extensions'] = ['yaml', 'yml']
    assert value_error('Invalid type for "extensions" option, it must be a list')

# Generated at 2022-06-23 08:10:31.270078
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test case 1:
    test_module = ActionModule()
    params = {"action": "_ansible/action_plugins/include_vars/", "_ansible_verbosity": 0, "ansible_version": {"full": "2.9.11", "major": 2, "minor": 9, "revision": 11, "string": "2.9.11", "version": [2, 9, 11]}, "async": 5, "inventory_sources": ["/etc/ansible/hosts"], "should_handle_exception": True}
    task_vars = {'inventory_dir': '/etc/ansible', 'playbook_dir': '/etc/ansible/playbooks'}
    results = test_module.run(task_vars=task_vars)


# Generated at 2022-06-23 08:10:42.516270
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import MagicMock
    with patch.object(ActionBase, 'run') as mock_actionbase_run:
        mock_actionbase_run.return_value = {'failed': False}
        mock_task = MagicMock()
        mock_task.args = {
            'name': '',
            'files_matching': '',
            'ignore_files': '',
            'dir': '',
            'depth': 0,
            'ignore_unknown_extensions': False,
            'extensions': ['yml'],
        }
        # Test for constructor
        test_obj = ActionModule(mock_task, MagicMock())
        assert test_obj is not None


# Generated at 2022-06-23 08:10:53.285323
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C


    class FakeTask:
        def __init__(self, data):
            self.data = data
            self.args = data['args']

        def _role(self):
            return None

    #Testcase 1
    #returns a dict
    data = {'args': {'file': '~/ansible/test/test_action_module/host_vars/host1'}}

    fake_task = FakeTask(data)
    instance = ActionModule('~/ansible/plugins/action/vars.py', fake_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_result = instance.run()

    assert isinstance(action_result, dict)

# Generated at 2022-06-23 08:11:02.489464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test ActionModule.run method """
    action_module_instance = ActionModule(dict(), dict())

    # Test ActionModule.run with normal case of source_dir
    action_module_instance.source_dir = './test/data/dir'
    action_module_instance.depth = 0
    action_module_instance.ignore_files = ''
    result = action_module_instance.run()
    assert result['ansible_facts']['a.yaml'] == 'value1'
    assert result['ansible_facts']['b.yaml'] == 'value2'
    assert result['ansible_facts']['c.yaml'] == 'value3'
    assert result['ansible_facts']['d.yaml'] == 'value4'

    # Test ActionModule.run with invalid source_dir
    action

# Generated at 2022-06-23 08:11:13.884012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.plugins.loader import get_all_plugin_loaders

    # return a fake task object
    class FakeTask(Task):
        def __init__(self, name, play_context, loader, shared_loader_obj, options=None, variable_manager=None, loader_cache=None):
            super(FakeTask, self).__init__(name, play_context, shared_loader_obj, variable_manager, loader_cache)
            self._role = None
            self._ds = FakeDataSource()
            self.loader = FakeLoader()

    class FakeDataSource():
        def __init__(self):
            self._data_source = "/tmp"

    # return a fake loader object
    class FakeLoader():
        def __init__(self):
            self._plugin_

# Generated at 2022-06-23 08:11:16.123473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-23 08:11:16.981626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()       # pylint: disable=E0110


# Generated at 2022-06-23 08:11:21.267576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return_results_as_name = 'return_results_as_name'
    source_dir = 'source_dir'
    source_file = 'source_file'
    depth = 'depth'
    files_matching = 'files_matching'
    ignore_files = ''
    extensions = 'extensions'
    valid_extensions = ['yaml']
    hash_behaviour = 'hash_behaviour'
    args = {
        return_results_as_name: return_results_as_name,
        source_dir: source_dir,
        source_file: source_file,
        depth: depth,
        files_matching: files_matching,
        ignore_files: ignore_files,
        extensions: extensions,
        hash_behaviour: hash_behaviour,
    }
    _task = MyTask()

# Generated at 2022-06-23 08:11:23.113627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    AM = ActionModule(None, None, None, '/')
    AM._task = None
    AM.run()

# Generated at 2022-06-23 08:11:32.243499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    class CallbackModule(CallbackBase):
        def __init__(self):
            self.results = []

        def v2_runner_on_ok(self, result, **kwargs):
            self.results += result._result
            host = result._host.get_name()

       

# Generated at 2022-06-23 08:11:33.423088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError()

# Generated at 2022-06-23 08:11:46.294839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for run method of class ActionModule
    """
    print("Testing run method of ActionModule class")

    # Initializing required variables
    tmp = None
    task_vars = {
        'user_name': 'ansible',
        'gid': 2000,
        'active': False,
        'uid': 2000,
        'group': 'ansible'
    }

    # Constructing mock object of the class
    mock_self = ActionModule()
    mock_self._task = MagicMock()
    mock_self._set_dir_defaults = MagicMock(return_value=None)
    mock_self._set_root_dir = MagicMock(return_value=None)
    mock_self._traverse_dir_depth = MagicMock(return_value=[('/etc/ansible', [])])


# Generated at 2022-06-23 08:11:47.683258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    isinstance(ActionModule, ActionBase)

# Generated at 2022-06-23 08:11:59.069957
# Unit test for constructor of class ActionModule
def test_ActionModule():
    input_args = {
        'name': 'set_fact',
        'hash_behaviour': 'replace',
        'dir': 'vars/',
        'depth': '2',
        'ignore_files': '[a-zA-Z]*.yaml',
        'extensions': ('yaml', 'yml', 'json'),
        'ignore_unknown_extensions': True
    }
    action_module = ActionModule(dict(), 'playbook', 'vars', input_args)
    assert action_module
    assert action_module._set_args() == None
    assert action_module.hash_behaviour == 'replace'
    assert action_module.return_results_as_name == 'set_fact'
    assert action_module.source_dir == 'vars/'

# Generated at 2022-06-23 08:12:05.527977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module.VALID_FILE_EXTENSIONS, list)
    assert isinstance(action_module.VALID_DIR_ARGUMENTS, list)
    assert isinstance(action_module.VALID_FILE_ARGUMENTS, list)
    assert isinstance(action_module.VALID_ALL, list)

# Generated at 2022-06-23 08:12:15.063631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task, TaskInclude
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)
    task = Task()
    task._role = RoleDefinition()

# Generated at 2022-06-23 08:12:26.009422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests.mock import MagicMock, patch
    from ansible.module_utils import basic
    mock_module = MagicMock(spec=basic.AnsibleModule)
    mock_module.params = {'file': '/my/filename'}

    source_file_mock = MagicMock(spec=basic.AnsibleModule)
    source_file_mock.params = {'file': '/my/filename'}

    mock_task = MagicMock()
    mock_task.args = {'file': '/my/filename'}
    mock_task.async_val = 43

    mock_task._role = MagicMock()
    mock_task._role._role_path = '/my/role'

    mock_loader = MagicMock()
    mock_loader.load = MagicMock

# Generated at 2022-06-23 08:12:27.410649
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:12:28.032454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:12:35.451981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing
    # test_dir_with_extensions_parameter_with_yml
    task_vars = dict()
    source_dir = './test/unit/include_vars/inputs/test_dir_with_extensions_parameter/vars/'
    source_file = None
    return_results_as_name = None
    depth = 0
    files_matching = None
    ignore_files = None
    ignore_unknown_extensions = False
    valid_extensions = ['yml']
    hash_behaviour = 'replace'


# Generated at 2022-06-23 08:12:41.358721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule_object = ActionModule(None, None)
    assert actionmodule_object.run(tmp=None, task_vars=None) == {
                                                                'ansible_facts': {},
                                                                'ansible_included_var_files': [],
                                                                'failed': True,
                                                                'message': '',
                                                                '_ansible_no_log': True}


# Generated at 2022-06-23 08:12:42.901860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module != None

# Generated at 2022-06-23 08:12:57.138852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list='localhost,')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 08:12:58.174189
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Create an instance without errors
  ActionModule()

# Generated at 2022-06-23 08:13:12.560193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # module for testing
    # this is the bare minimum for __init__ to work
    class FakeModule():
        def __init__(self, module_name='fake_module'):
            self._name = module_name
    
    # task for testing
    class FakeTask():
        def __init__(self):
            self._name = 'fake_task'
            self.args = {
                'file' : 'test/host_vars/host_var',
                '_raw_params' : 'test/host_vars/host_var.yaml',
                'name' : 'test_var',
                'hash_behaviour' : 'replace'
            }
    
    # loader for testing
    class FakeLoader():
        def __init__(self):
            pass
        

# Generated at 2022-06-23 08:13:19.709743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock objects
    action_base = ActionBase()
    module = ActionModule()
    module._task = action_base
    module._task.args = {}
    module._task.args['file'] = 'file'

    # Success test
    result = module.run(tmp=None)
    assert result['ansible_facts'] == {}

    # Failure test for invalid file
    module._task.args['file'] = ''
    result = module.run(tmp=None)
    assert result['ansible_facts'] == {}


# Generated at 2022-06-23 08:13:21.148327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()

# Generated at 2022-06-23 08:13:23.778456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_path=None, templar=None, shared_loader_obj=None)
    return mod

# Generated at 2022-06-23 08:13:24.587897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:13:35.793698
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # TODO
    # Add test for _set_root_dir method
    module_path = 'ansible.plugins.action.include_vars'

    # Mocking Modules
    # Mocking AnsibleModule
    mock_AnsibleModule = MagicMock()
    mock_AnsibleModule.return_value = mock_AnsibleModule
    mock_AnsibleModule.run_command.return_value = 'output', 'error', 1
    sys.modules['ansible.utils.module_docs_fragments'] = MagicMock()
    sys.modules['ansible.module_utils.six'] = MagicMock()
    sys.modules['ansible.plugins.lookup'] = MagicMock()
    sys.modules['ansible.plugins.loader'] = MagicMock()
    sys.modules['ansible.plugins']

# Generated at 2022-06-23 08:13:41.013830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ###########################################################################
    #
    # Test case that checks the functionality of the run method of the
    # ActionModule class.
    #
    #   * Checks if a dictionary with the correct structure is returned
    #   * Checks if the correct error message is returned if an unknown option
    #     is given to the action
    #   * Checks if the correct error message is returned if a directory is
    #     given as an argument but there is a file_only argument
    #   * Checks if the correct error message is returned if a file is given
    #     as an argument but there is a dir_only argument
    #
    ###########################################################################
    # Initialize the action module
    action_module = ActionModule()
    action_module._task = mock_Task()
    action_module._set_args = mock_set_args
    action_

# Generated at 2022-06-23 08:13:49.046512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import ansible.plugins
    from ansible.plugins.action import ActionBase

    class ActionModuleMock(ActionModule):
        VALID_FILE_EXTENSIONS = ['yaml']

        def _set_dir_defaults(self):
            pass

        def _set_args(self):
            pass

        def _set_root_dir(self):
            pass

        def _traverse_dir_depth(self):
            yield ("", ["test.yaml"])

        def _ignore_file(self, filename):
            pass

        def _is_valid_file_ext(self, source_file):
            return True

        def _load_files(self, filename, validate_extensions=False):
            return (False, "", dict(test="test"))


# Generated at 2022-06-23 08:13:51.829791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        _ = ActionModule()
    except Exception:
        assert True, "Action_Module can't be created"
    assert True, "Action_Module can be created"

# Generated at 2022-06-23 08:14:00.285656
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.executor import task_queue_manager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayObj
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars

    variable_manager = VariableManager()
    loader = DataLoader()
    results_callback = task_queue_manager.TaskQueueManager()

# Generated at 2022-06-23 08:14:01.772737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()
    print(actionmodule.VALID_ALL)

# Generated at 2022-06-23 08:14:02.448174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:14:12.830079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    argv = dict()
    argv['name'] = 'test_name'
    argv['dir'] = 'test_dir'
    argv['hash_behaviour'] = 'test_hash_behaviour'
    argv['file'] = 'test_file'
    argv['depth'] = 'test_depth'
    argv['files_matching'] = 'test_files_matching'
    argv['ignore_files'] = 'test_ignore_files'
    argv['ignore_unknown_extensions'] = 'test_ignore_unknown_extensions'
    argv['extensions'] = 'test_extensions'

    act = ActionModule(argv)
    assert act.hash_behaviour == 'test_hash_behaviour'
    assert act.return_results_as_name == 'test_name'
   

# Generated at 2022-06-23 08:14:24.253808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    import ansible.plugins.loader
    import ansible.plugins.action

    # monkey patch _load_action_plugin
    ansible.plugins.action._load_action_plugin = lambda name, class_name=None: ActionModule

    # monkey patch open function
    ActionModule.open = lambda self, path: open(path, 'rb')

    # monkey patch _get_file_contents
    ansible.plugins.loader._get_file_contents = lambda path: (b'write_files\n - content: ""\n   path: ""\n', True)

    mock_task_args = {'_raw_params': 'invalid_file'}

# Generated at 2022-06-23 08:14:26.698675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-23 08:14:37.573431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.display import Display


# Generated at 2022-06-23 08:14:48.476819
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import yaml
    from ansible.module_utils.six import StringIO

    action = ActionModule({}, {})

    with open("test_vars.yml", "w+") as f:
        f.write("1: 1\n2:\n  - a\n  - b\n  - c\n")

    task_vars = {
        'playbook_dir': os.getcwd(),
        'role_path': '/tmp/roles/my_role'
    }

    # Test bad file extension
    result = action.run(task_vars=task_vars,
                        **dict(file="test_vars.yml", extensions=["yaml", "yml"]))
    assert result['failed']

# Generated at 2022-06-23 08:14:49.636155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-23 08:14:50.994555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_obj = ActionModule()
    assert test_obj

# Generated at 2022-06-23 08:14:56.477055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ansible_module = ActionModule()
    test_task_vars = dict()
    test_source_dir = 'vars'
    test_depth = 0
    test_files_matching = r'_file'
    test_ignore_files = list()
    test_valid_extensions = ['yaml', 'yml', 'json']
    test_hash_behaviour = None
    test_return_results_as_name = None

    test_json_data_expected = {
        "data": {
            "key1": "value1",
            "key2": "value2"
        },
        "key3": "value3",
        "key4": "value4"
    }

# Generated at 2022-06-23 08:15:03.381481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action=ActionModule()
    taskVars={
        'source_dir':'',
        'source_file':'',
        '_raw_params':'',
        'file': None,
        'dir': None,
        'depth': None,
        'files_matching': None,
        'ignore_files': None,
        'extensions': ['yaml', 'yml', 'json']
    }
    result = action.run(task_vars=taskVars)
    assert(result['ansible_included_var_files'] is not None)

# Generated at 2022-06-23 08:15:05.892860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    source = ActionModule({})
    assert isinstance(source, ActionModule)


# Generated at 2022-06-23 08:15:12.349967
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()
    module._set_dir_defaults()
    module._set_args()
    module._set_root_dir()
    task_vars = dict()
    module.run(task_vars=task_vars)

    module = ActionModule()
    task_vars = dict()
    module.run(task_vars=task_vars)


# Generated at 2022-06-23 08:15:13.055990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:15:13.674612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:15:24.695764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock object 
    class Mock_ActionBase(ActionBase):
        def __init__(self, *args, **kwargs):
            self.results = {}

        def run(self, *args, **kwargs):
            task_vars = {}
            if 'task_vars' in kwargs:
                task_vars = kwargs['task_vars']
            if args:
                task_vars = args[0]

            if task_vars.get('ansible.executor.module_vars.params', {}).get('hash_behaviour', None):
                self.results['changed'] = False    
            return self.results

    class Mock_TaskDS(object):
        def __init__(self, *args, **kwargs):
            self._data_source = []
        

# Generated at 2022-06-23 08:15:29.671006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    # set method variables
    module._task = None
    module._task._ds = None
    module._task._ds._data_source = None
    module._task._ds._data_source = None
    module._task._ds._data_source = None

# Generated at 2022-06-23 08:15:35.380673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # get _execute_module function
    source_file = "/root/ansible_ws/roles/local/tasks/main/main.yml"
    #source_file = "../roles/local/tasks/main/main.yml"
    module_name = "include"
    task_ds = {
        "name": "include_vars",
        "include_vars": {
            "_raw_params": "{{ " + source_file + "}}"
        }
    }
    _execute_module = ActionModule._execute_module
    def my_execute_module(self, module_name=None, module_args=None, task_vars=None, tmp=None):
        return _execute_module(self, module_name, module_args, task_vars, tmp)

    ActionModule._execute

# Generated at 2022-06-23 08:15:36.578356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-23 08:15:48.333472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    del sys.argv[1:]
    sys.argv += ['--tree', 'out/lookup_plugins', '--hosts', 'localhost', '--module-path', 'lib/ansible/modules/', '--extra-vars', '@data/beatbox_config', '--connection', 'local', 'beatbox']
    from ansible.playbook.play_context import PlayContext

    from ansible import constants as C
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-23 08:15:51.656526
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:15:56.331992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    def mock_exit(self, return_value=None):
        '''Mocking OSExit'''
        pass
    import ansible.plugins.action as action
    #exit is mocked to avoid exiting
    action.ActionBase._exit = mock_exit
    am = action.ActionModule(None, C)
    am.run(tmp=None, task_vars=None)
    return 0


# Generated at 2022-06-23 08:16:09.072660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import shutil
    import copy
    import tempfile
    import json
    import yaml

    # Create temp dir
    tmp_dir = tempfile.mkdtemp()
    template_root_dir = os.path.join(tmp_dir, 'template_root')
    cond_root_dir = os.path.join(tmp_dir, 'conditional')
    target_root_dir = os.path.join(tmp_dir, 'target_root')


# Generated at 2022-06-23 08:16:10.065370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action.run()


# Generated at 2022-06-23 08:16:10.706744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:16:14.776557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test for method run of class ActionModule
    """
    tmp = None
    task_vars = dict()
    # tmp no longer has any effect
    # Parameter tmp(required=False, default=None)
    assert tmp == None

    # Parameter task_vars(required=False, default=None)
    assert task_vars == dict()

    module = ActionModule()
    assert module.run(tmp, task_vars) == None



# Generated at 2022-06-23 08:16:24.681445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockVC(object):
        def __init__(self, task_vars=None):
            self.task_vars = task_vars if task_vars else dict()
            self.src = '/tmp/ansible/test_action_module/'
            self.expected_result = {
                "run_id": "2f9c4d4f-4ae4-40a7-abc5-3b093f031271",
                "output": "Great success",
                "runtime": "100",
                "type": "VCRUN"
            }

# Generated at 2022-06-23 08:16:25.336128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return 0

# Generated at 2022-06-23 08:16:34.749530
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule(None)
  assert isinstance(am, ActionModule), 'ActionModule creation failed'
  assert isinstance(am.VALID_FILE_EXTENSIONS, list), 'VALID_FILE_EXTENSIONS should be a list'
  assert isinstance(am.VALID_DIR_ARGUMENTS, list), 'VALID_DIR_ARGUMENTS should be a list'
  assert isinstance(am.VALID_FILE_ARGUMENTS, list), 'VALID_FILE_ARGUMENTS should be a list'
  assert isinstance(am.VALID_ALL, list), 'VALID_ALL should be a list'

# Generated at 2022-06-23 08:16:44.320079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Test with source_dir
    args = {'depth': 0}
    file_system = {
            'test_dir': {
                'test1.yml': 'key: val1',
                'test2.yml': 'key: val2',
                'test3.yml': 'key: val3',
                'test4.yml': 'key: val4',
                'test5.yml': ''
                }
            }
    test_obj = ActionModule(None, None, args, None, None, file_system, None, None)
    test_obj._set_args()
    test_obj._set_root_dir()
    test_obj._set_dir_defaults()
    result = test_obj.run(None, None)

# Generated at 2022-06-23 08:16:45.781290
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:16:57.007518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    task = Task()
    task.args = {
        'hash_behaviour': 'merge',
        'name': 'facts',
        'dir': './',
        'depth': 0,
        'files_matching': '',
        'ignore_files': ['.tar'],
        'ignore_unknown_extensions': True,
        'extensions': ['yml', 'yaml']
    }

    action_module = ActionModule(task, None)
    assert isinstance(action_module, ActionModule)

    task.args = {
        'hash_behaviour': 'merge',
        'name': 'facts',
        'file': './my_file.yml',
    }
    action_module = ActionModule(task, None)

# Generated at 2022-06-23 08:17:09.334232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Tests the method run of class ActionModule.
    This method will be run by nosetests tool.
    """
    # Create the object test_obj of type ActionModule
    test_obj = ActionModule()

    # Create the object test_class of type AnsibleModule
    test_class = object()

    # Filter the dict test_param and store it in the dict test_param1

# Generated at 2022-06-23 08:17:11.737291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(dict(), None, None, None)
    assert action_module is not None


# Generated at 2022-06-23 08:17:22.824060
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global ActionModule
    with open("testdata.yml", "w") as f:
        f.write("---\n - test1\n - test2\n")
    assert(ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'])
    assert(ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'])
    assert(ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params'])
    assert(ActionModule.VALID_ALL == ['name', 'hash_behaviour'])


# Generated at 2022-06-23 08:17:37.985240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor import task_executor
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    import os
    basedir=os.getcwd()
    filename='test_case.yml'
    depth=2
    var_files=[filename]
    root_dir=basedir
    results = dict()
    failed = False
    # err_msg = ''
    task = Task()
    task._role = namedtuple('Role', ['_role_path'])
    task._role._role_path = None
    task

# Generated at 2022-06-23 08:17:40.093935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:17:41.075059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule(task=None).run()

# Generated at 2022-06-23 08:17:49.990054
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def test_failure_input_with_dict(mocker):
        test_failure_input = {
            'ignore_files': {'test': 'test'},
            'foo': 'bar',
            'action': 'include_vars'
        }

        mocked_fail_json = mocker.patch('builtins.fail_json', side_effect=AnsibleError)

        action_module = ActionModule()
        action_module._task = mocker.Mock()
        action_module._task.args = test_failure_input
        action_module.run()

        mocked_fail_json.assert_called_once_with(
            msg='ignore_files must be a list',
            exception=None,
            **test_failure_input
        )


# Generated at 2022-06-23 08:17:50.933335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:17:55.909996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = {'file': 'ModuleAction_test_run.yml'}
    task_vars = {}
    ActionModule.run(task_args, task_vars)
    assert task_vars['module_action_test_run'] == 'ModuleAction_test_run'


# Generated at 2022-06-23 08:17:56.867486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """

    :return:
    """

# Generated at 2022-06-23 08:17:58.733789
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #ActionModule_run has been tested in unit test test_action_module_include_vars_role_path
    assert True == True

# Generated at 2022-06-23 08:18:11.667180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    from ansible.module_utils.six import string_types
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    def get_play_context(path=None, basedir=None):
        context = dict()
        context['run_once'] = False
        context['verbosity'] = 5
        if not path:
            path = '/home/ansible/hosts.yml'