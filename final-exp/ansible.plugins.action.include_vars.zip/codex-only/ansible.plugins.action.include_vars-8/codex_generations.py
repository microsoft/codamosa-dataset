

# Generated at 2022-06-23 08:08:19.186993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    from ansible.constants import DEFAULT_HASH_BEHAVIOUR
    from ansible.module_utils.six import PY3

    class TestActionModule(ActionModule):
        def _set_dir_defaults(self):
            pass

        def _set_args(self):
            pass

        def _pipe(self):
            return list()

        def _find_needle(self, dir_name, source_file):
            return self.source_file

        def _traverse_dir_depth(self):
            for i in self.source_dir_files:
                yield (None, self.source_dir_files[i])

        def _load_files(self, filename, validate_extensions=False):
            return False, None, dict()


# Generated at 2022-06-23 08:08:28.729667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import action_loader
    from ansible.parsing.dataloader import DataLoader

    test_ActionModule = action_loader.get('include_vars', class_only=True)

    # construct args

# Generated at 2022-06-23 08:08:37.542644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    from ansible.module_utils.basic import AnsibleModule

    test_args = dict(
        name = None,
        dir = 'test/files',
        extensions = ['.yaml', '.yml'],
        ignore_unknown_extensions = False
    )


# Generated at 2022-06-23 08:08:47.815232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    # ctx = MagicMock()
    # task = ctx.task
    # task.args = MagicMock()
    # task.args.get.return_value = "name1"
    # task.args.update.return_value = None
    # task._role = None
    #
    # task._ds = MagicMock()
    # task._ds = "_data_source"
    # task._ds._data_source = MagicMock()
    # task._ds._data_source.split.return_value = ['', '', '', '', '', '', '']
    # task._ds._data_source.join.return_value = "ds1"
    #
    # res = am.run(ctx=ctx)
    # print("action = %s" % res)
   

# Generated at 2022-06-23 08:09:00.971971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    sys.path.append(os.getcwd())
    from action_plugins.include_vars import ActionModule

    test_instance = ActionModule(dict(), dict(), "/tmp/a/roles/test", "/tmp/a/roles/test/tasks/main.yml")
    test_instance.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
    test_instance.VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    test_instance.VALID_FILE_ARGUMENTS = ['file', '_raw_params']
    test_instance.VALID_ALL = ['name', 'hash_behaviour']

    test_instance._task

# Generated at 2022-06-23 08:09:10.115160
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Source directory contains the following files:
    - main.yml
    - files/
    - files/1.yml
    - files/2.yml
    - files/3.yml
    - files/sub_files/
    - files/sub_files/1.yml
    - files/sub_files/2.yml
    - files/sub_files/3.yml
    - main.yml
    '''
    test_action_module = ActionModule(dict(DEPTH='2', files_matching='^.*\.yml$', extensions='yml'))
    # First test
    test_action_module.source_dir = "./files"

# Generated at 2022-06-23 08:09:20.014792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: fix this unit test

    # def _set_dir_defaults(self):
    #
    # def _set_args(self):
    #
    # def _set_root_dir(self):
    #
    # def _traverse_dir_depth(self):
    #
    # def _ignore_file(self, filename):
    #
    # def _is_valid_file_ext(self, source_file):
    #
    # def _load_files(self, filename, validate_extensions=False):
    #
    # def _load_files_in_dir(self, root_dir, var_files):
    pass

# Generated at 2022-06-23 08:09:26.460937
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert isinstance(action_module, ActionModule)
    assert action_module.valid_extensions == ['yaml', 'yml', 'json']
    assert action_module.valid_dir_arguments == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.valid_file_arguments == ['file', '_raw_params']
    assert action_module.valid_all == ['name', 'hash_behaviour']


# Generated at 2022-06-23 08:09:35.817182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    src_dir = 'test'
    depth = 0
    files_matching = None
    ignore_files = None
    valid_extensions = None
    err_msg = 'test\n'
    matcher = None
    show_content = True
    included_files = ['test']
    return_results_as_name = None
    hash_behaviour = None
    source_dir = None
    source_file = 'test'
    depth = None
    files_matching = None
    ignore_files = None
    valid_extensions = None
    stop_iter = False
    stop_iter2 = False
    file_type = 'test'
    m = ActionModule(True, False)
    m._set_args()
    m._set_dir_defaults()
    m._set_root_dir()
    m

# Generated at 2022-06-23 08:09:41.172405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('ActionModule_run')
    # initialize vars
    # set up arguments
    # call the method
    # check if failed
    # check if the message is not failed
    # check if the err_msg is empty
    # check if loaded_data is true
    # check if the returned value is a dict
    # check if the returned value includes the loaded content

    print('ActionModule_run passed')


# Generated at 2022-06-23 08:09:44.560356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test module constructor
    """
    action_module_instance = ActionModule()
    assert action_module_instance


# Generated at 2022-06-23 08:09:52.937094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import StringIO

    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.vars import combine_vars

    from ansible.utils.vars import combine_vars

    import sys

    save_stdout = sys.stdout

# Generated at 2022-06-23 08:10:04.511710
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = __import__('ansible.plugins.action').plugins.action.ActionModule()
    action_module.__dict__['_task'] = __import__('ansible.playbook.task').Task()
    action_module.__dict__['_task'].__dict__['_ds'] = __import__('ansible.parsing.dataloader').DataLoader()
    action_module.__dict__['_task'].__dict__['_ds'].__dict__['_search_path'] = ['/home/nodetest/test']
    action_module.__dict__['_task'].__dict__['_ds'].__dict__['_basedir'] = '/home/nodetest/test'
    action_module.__dict__['_task'].__dict__['_ds'].__

# Generated at 2022-06-23 08:10:12.049755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create action module object
    a = ActionModule(loader=None, temporary_path=None, connection=None, play_context=None, loader_path=None, basedir=None, task_uuid=None, task=None)
    d = dict()
    d['hosts'] = [{'hostname': 'localhost', 'ip': '127.0.0.1', 'port': 22 }]
    d['vars'] = {'var1': 'value1', 'var2': 'value2'}
    d['_raw_params'] = 'vars/test1.yml'

    # create task which contains args
    t = task.Task(action=a, args=d)
    a.task_vars = d
    a._task = t

    # test run method of ActionModule
    #r = a.

# Generated at 2022-06-23 08:10:22.525667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.task as task_klass
    import ansible.playbook.task_include as task_include_klass
    import ansible.playbook.block as block_klass
    import ansible.playbook.role as role_klass
    import ansible.playbook.play_context as play_context_klass

    play_context = play_context_klass.PlayContext()
    src = '/path/to/role'
    role = role_klass.RoleInclude(play=[], role_path = src)
    block = block_klass.Block(role=role)

    task = task_klass.Task()
    task._role = role
    task._ds = task_include_klass.TaskInclude(block=block, task_include=role)


# Generated at 2022-06-23 08:10:23.423204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 08:10:24.677455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:10:33.487158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ActionModule' == ActionModule.__name__
    assert 'plugins.action' == ActionModule.__module__
    assert 'ActionBase' == ActionModule.__bases__[0].__name__
    assert 'action' == ActionModule.TYPE
    assert not ActionModule.BYPASS_HOST_LOOP
    assert not ActionModule.BYPASS_HOST_LOOP_ON_UNREACHABLE
    assert not ActionModule.TRANSFERS_FILES
    assert 'ansible.constants' == C.__name__
    assert 'C' == C.__name__

# Generated at 2022-06-23 08:10:43.271068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    task_vars = dict()
    task_vars['var'] = 'hello'
    task_vars['namespace'] = dict()
    task_vars['namespace']['hello'] = 'world'
    task_vars['dictionary'] = dict()
    task_vars['dictionary']['key'] = 'value'
    task_vars['dictionary']['key_string'] = 'string_value'
    task_vars['dictionary']['key_integer'] = '100'
    task_vars['dictionary']['key_boolean_true'] = 'True'
    task_vars['dictionary']['key_boolean_false'] = 'False'
    task_vars['list'] = list()
    task_

# Generated at 2022-06-23 08:10:44.178962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 08:10:55.995003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.loader import add_all_plugin_dirs

    module_args = dict()
    module_args['dir'] = 'test/test.dir'
    module_args['_raw_params'] = 'test/test.yml'
    module_args['ignore_files'] = '*.txt'
    module_args['ignore_unknown_extensions'] = True
    module_args['extensions'] = 'yml'

    add_all_plugin_dirs()
    _mocked_task = dict()
    _mocked_task['args'] = module_args
    _mocked_self = dict()
    _mocked_self['_task'] = _mocked_task

    # Testing

# Generated at 2022-06-23 08:11:03.250416
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
        test_ActionModule: Performs unit test for ActionModule constructor.
    '''
    class MockModule:
        def __init__(self, args):
            self.args = args

    task_obj = MockModule({'name': 'test', 'depth': 0, 'files_matching': None, 'ignore_files': '', 'extensions': ['yaml', 'yml'], '_raw_params': 'test/test.yml'})
    loader_obj = None
    tempdir_obj = None
    try:
        action_obj = ActionModule(task_obj, loader_obj, tempdir_obj)
        if action_obj is not None:
            return True
        else:
            return False
    except Exception as _:
        return False


# Generated at 2022-06-23 08:11:14.168075
# Unit test for constructor of class ActionModule
def test_ActionModule():

    TASK = {
        'name': 'test_vars',
        'action': {'module': 'include_vars',
                   'args': {
                       'dir': 'vars',
                       'depth': '2',
                       'files_matching': 'test.yaml',
                       'ignore_files': 'bad.yaml',
                       'extensions': ['yaml', 'yml'],
                       'ignore_unknown_extensions': True
                   }
                   }
    }

    task_ds = {
        '_ds': {
            '_data_source': 'test.yaml'
        }
    }
    task_ds['_ds'].update(task_ds)


# Generated at 2022-06-23 08:11:15.243437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:11:25.526335
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Initialise ActionModule instance
    ActionModule_inst_for_test = ActionModule()

    # Set basic attributes of ActionModule instance
    ActionModule_inst_for_test.TRANSFERS_FILES = False
    ActionModule_inst_for_test.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
    ActionModule_inst_for_test.VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    ActionModule_inst_for_test.VALID_FILE_ARGUMENTS = ['file', '_raw_params']
    ActionModule_inst_for_test.VALID_ALL = ['name', 'hash_behaviour']
    ActionModule_inst_for_test.show

# Generated at 2022-06-23 08:11:33.862172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import pytest
    import yaml
    import os

    filename = os.path.join(os.path.dirname(__file__), 'data', 'var_files_1')

    class MockModuleArg(object):
        def __init__(self, dict):
            self.__dict__ = dict

        def __getitem__(self, key):
            return self.__dict__[key]

    class MockTask(object):
        def __init__(self):
            self.args = MockModuleArg({'file': filename,
                                       'name': None,
                                       'ignore_files': [],
                                       'hash_behaviour': None,
                                       'extensions':
                                           ['yml']})

    cls = ActionModule('tmp', MockTask(), 'localhost', 'file')
    cl

# Generated at 2022-06-23 08:11:36.383432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:11:47.142251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class AnsibleTask():

        def __init__(self, args, role=None, ds=None):
            self.args = args
            self._role = role
            self._ds = ds

    class AnsibleLoader():

        def __init__(self, file_name):
            self.file_name = file_name

        def load(self, data, file_name=None, show_content=None):
            return self.file_name

        def _get_file_contents(self, filename):
            data = ''
            show_content = True
            return data, show_content

    class AnsibleRole():

        def __init__(self, role_path):
            self._role_path = role_path

    class AnsibleDS():

        def __init__(self, data_source):
            self._data

# Generated at 2022-06-23 08:11:58.847163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for ActionModule constructor
    Args:
        None
    Returns:
        Module instance
    """
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    def _mock_task(name, args, src=False, role_src=False, tmp=None, task_vars=None):
        task = Task()

        task._role = None
        if role_src:
            role_name = 'include_vars_role'
            role_path = 'unit_tests/ansible/include_vars_role'
            role = Role()
            role._role_name = role_name
            role._role_path = role_path
            task._role = role

        task._ds = None

# Generated at 2022-06-23 08:11:59.978523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(TypeError):
        ActionModule()

# Generated at 2022-06-23 08:12:02.325070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initializes the class with the module
    action = ActionModule()
    assert action is not None


# Generated at 2022-06-23 08:12:05.312867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(dict(), dict(), dict())
    assert a is not None


# Generated at 2022-06-23 08:12:06.334229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:12:07.984369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for ActionModule.run
    assert True

# Generated at 2022-06-23 08:12:18.763867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class MockTask(Task):
        def __init__(self):
            self._role = False
            self._ds = False

    def _create_action(arg_list, role_path=None, loader=None):
        play_context = dict(
            basedir=path.join(path.dirname(__file__), 'data')
        )

# Generated at 2022-06-23 08:12:28.085819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_data = {
        'ignore_files': ['some_file.some_extension']
    }

    state_data = {
        'role_path': '/path/to/role'
    }

    loader_data = {
        '_basedir': '/ansible/playbook/dir'
    }

    task_ds_data = {
        '_data_source': '/path/to/some/file.yml'
    }

    task_args_data = {
        'dir': 'vars/',
        'extensions': ['yml'],
        'ignore_files': ['main.yml'],
        'ignore_unknown_extensions': True
    }

    action_module = ActionModule()

    action_module._task = FakeTask(task_args_data)
    action_module._task

# Generated at 2022-06-23 08:12:39.642186
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Set the instance variable to test for.
    test_source_dir = './test_dir'
    # Set the valid extensions for use in the test
    extensions = ['yml', 'yaml']

    # Set the instance variable to test for.
    test_source_file = './test_dir/vars.yml'
    valid_dir_args = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    valid_file_args = ['file', '_raw_params']
    valid_all = ['name', 'hash_behaviour']
    # Initialize the ActionModule class
    test_class = ActionModule(dict(), None, None)
    # Set the instance variable
    test_class.source_dir = test_source_dir
    # Test that

# Generated at 2022-06-23 08:12:41.440009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:12:44.438893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    src = ('[{"file": "fake-file.yml"}]')
    dest = ('[{"file": "fake-file.yml"}]')
    assert src == dest, "Error in constructor input"

# Generated at 2022-06-23 08:12:57.369287
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module_args = {
        'name': 'my_result',
        'dir': 'vars',
        'depth': 2,
        'files_matching': '*.yml',
        'ignore_files': '*l[0-9]*.yml',
        'hash_behaviour': 'merge'
    }
    test_this = ActionModule(
        task_ds=dict(),
        connection_ds=dict(),
        play_context=dict(
            basedir='/data/home/travis/build/Stouts/Stouts.ansible/playbooks/stouts.release'),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert test_this.run(task_vars={}) is not None

# Generated at 2022-06-23 08:13:11.424449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    class ArgSpec(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.iteritems():
                setattr(self, k, v)

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    # Inject test values into ActionModule instance
    test_task = Task()

# Generated at 2022-06-23 08:13:13.483213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Generate a test instance of ActionModule with TaskInstance
    """
    pass

# Generated at 2022-06-23 08:13:20.967019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Monkey patching: do not exit in case of failure
    import __builtin__
    real_exit = __builtin__.exit
    __builtin__.exit = lambda x: None

    from ansible.plugins.action.include_vars import ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-23 08:13:21.678598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:13:23.301043
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert isinstance(action, ActionModule)

# Generated at 2022-06-23 08:13:33.497924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """  Unit tests for include_vars/action_plugins/include_vars.py run method
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    yaml_test_res = """
---
test_res: 'first_res'
"""
    yaml_test_res_1 = """
---
test_res: 'second_res'
"""
    yaml_test_res_2 = """
---
test_res_2: 'second_res'
"""

# Generated at 2022-06-23 08:13:40.686635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\nRunning UnitTest for method {} of class {}".format('run', 'ActionModule'))
    # Test setup
    from tempfile import mkdtemp
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    # Create a fake task and args
    task = AnsibleModule(argument_spec=dict(
        _raw_params='test.yml',
        dir='test_dir',
        name='var',
        hash_behaviour='merge',
    ))
    t_vars = dict(
        test_var='test',
    )
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleVaultEnc

# Generated at 2022-06-23 08:13:42.027284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:13:53.566423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.ansible_artifactory_utils import AnsibleArtifactory
    args = {
        'depth': 2,
        'files_matching': '^test$',
        'ignore_files': ['main\\.yml'],
        '_raw_params': 'test.yml',
        'hash_behaviour': 'merge',
        'extensions': ['yml', 'yaml']
    }

    am = ActionModule(None, AnsibleArtifactory(args))
    am._set_args()

    # Test values
    assert am.hash_behaviour == 'merge'
    assert am.return_results_as_name is None
    assert am.source_dir is None
    assert am.source_file == 'test.yml'
    assert am.depth == 2
   

# Generated at 2022-06-23 08:14:01.488970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.errors import AnsibleUndefinedVariable

# Generated at 2022-06-23 08:14:02.974735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import types
    assert type(ActionModule()) is ActionModule


# Generated at 2022-06-23 08:14:04.582729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-23 08:14:14.180545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeModule():
        def __init__(self):
            self.args = {"name": 'something'}

    class FakeTask():
        def __init__(self):
            self.ds = None
            self._ds = None
            self._role = None
            self.args = {"name": 'something'}

    class FakePlay():
        def __init__(self):
            self._role = None

    class FakeDS():
        def __init__(self):
            self._data_source = "something"

    class FakeRole():
        def __init__(self):
            self._role_path = "something"

    class FakeDS():
        def __init__(self):
            self._data_source = "something"

    module = FakeModule()
    task = FakeTask()
    task._ds = FakeDS()

# Generated at 2022-06-23 08:14:22.965681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:14:23.965522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass


# Generated at 2022-06-23 08:14:36.541658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test to see if the function is able to successfully run if called with both dir and file args
    from ansible.module_utils.six import StringIO
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    play_context.check_mode = False
    loader = DataLoader()
    task_vars = dict()
    temp_stdout = StringIO()
    old_stdout = None

    # test to see if the function is able to successfully run if dir not exists
    action_module = ActionModule(loader=loader, task=None, connection=None, play_context=play_context,
                                 shared_loader_obj=None, templar=None)

# Generated at 2022-06-23 08:14:38.141950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:14:38.873512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert False

# Generated at 2022-06-23 08:14:49.569128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize parameters
    task = dict()
    task['args'] = dict()
    task['args']['hash_behaviour'] = 'merge'
    task['args']['name'] = 'results'
    task['args']['dir'] = 'path/to/dir'
    task['args']['file'] = 'path/to/file'
    task['args']['depth'] = 0
    task['args']['files_matching'] = ''
    task['args']['ignore_files'] = ''
    task['args']['extensions'] = 'yaml'
    task['args']['ignore_unknown_extensions'] = True

    task_vars = dict()
    task_vars['result'] = dict()

    tmp = None


# Generated at 2022-06-23 08:15:00.321608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test for method ActionModule.run"""
    # Unit test for class ActionModule.
    # The fixtures are from ansible/test/units/modules/utility/

    # test for input directory.
    data_dir = os.path.dirname(__file__) + '/../../../../'
    test_dir = data_dir + 'test/units/modules/utility/action_plugins/var_files/input_dir'
    tmp_dir = data_dir + 'test/units/modules/utility/action_plugins/var_files/tmp_dir'

    if not os.path.exists(tmp_dir):
        os.mkdir(tmp_dir)

    # test for input file.

# Generated at 2022-06-23 08:15:07.626202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase

# Generated at 2022-06-23 08:15:12.572492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create test ActionModule
    test_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create test variables
    test_vars = {
        "test_var1": None,
        "test_var2": None
    }

    test_task_vars = {
        "test_var1": "test_var1_value"
    }


# Generated at 2022-06-23 08:15:17.024429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert am.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:15:18.300908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    """
    pass

# Generated at 2022-06-23 08:15:21.482162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:15:23.493590
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Start testing ActionModule.")
    actionModule = ActionModule()
    assert actionModule.run()

# Generated at 2022-06-23 08:15:24.138046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:15:27.765436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module


# Generated at 2022-06-23 08:15:29.722164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    return action


# Generated at 2022-06-23 08:15:35.221465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test class ActionModule
    '''
    action = ActionModule()
    assert not action.depth
    assert not action.files_matching
    assert not action.ignore_files
    assert not action._task._role
    assert not action.hash_behaviour
    assert not action.return_results_as_name
    assert not action.source_dir
    assert not action.source_file
    assert action.valid_extensions
    assert action.show_content
    assert not action.included_files
    assert action.source_dir != '.'
    assert action.source_dir != '..'
    assert action.source_dir != ''
    assert not '\n' in action.source_file
t_ActionModule = 'test_ActionModule'



# Generated at 2022-06-23 08:15:37.058300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # action_plugin_class = ActionModule()
    print("Test class ActionModule")

# Generated at 2022-06-23 08:15:48.667774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of ActionModule
    am = ActionModule()
    # params
    d = {'a':1, 'b':2}
    # load_params
    am.load_params(d)
    # load_declared_module_args
    am.load_declared_module_args(d)
    # fail_json
    am.fail_json(d)
    # from_module
    am.from_module(d)
    # warn
    am.warn(d)
    # load_file_common_arguments
    am.load_file_common_arguments(d)
    # set_rw_permissions_for_all
    am.set_rw_permissions_for_all(d)
    # set_default_file_permissions

# Generated at 2022-06-23 08:15:50.541312
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule
    assert result.__name__ == 'ActionModule'

# Generated at 2022-06-23 08:15:58.621014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    source_dir = 'test/test_dir'

    actionmodule.source_dir = source_dir

    results = {}
    results = actionmodule.run(tmp=None, task_vars=results)

    for root_dir, filenames in actionmodule._traverse_dir_depth():
        failed, err_msg, updated_results = (actionmodule._load_files_in_dir(root_dir, filenames))
        if failed:
            return
        results.update(updated_results)

    assert len(results.keys()) == 0
    assert len(actionmodule.included_files) == 0

# Generated at 2022-06-23 08:16:10.260866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.include_vars import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create objects needed for run method
    task = Task()
    task_vars = dict()
    play_context = PlayContext()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=task_vars)

# Generated at 2022-06-23 08:16:15.403038
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # fail if no tmp set
    am = ActionModule()
    assert(am.TRANSFERS_FILES == False)
    assert(am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'])
    assert(am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'])
    assert(am.VALID_FILE_ARGUMENTS == ['file', '_raw_params'])
    assert(am.VALID_ALL == ['name', 'hash_behaviour'])

# Generated at 2022-06-23 08:16:25.033183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create mock
    mock_loader = mock.MagicMock()
    mock_loader._get_file_contents.return_value = ('data', True)
    
    mock_task = mock.MagicMock()
    mock_task._role = None
    
    mock_ds = mock.MagicMock()
    mock_ds._data_source = ''
    mock_task._ds = mock_ds
    

# Generated at 2022-06-23 08:16:25.652857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:16:36.973989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os, sys
    test_dir = os.path.dirname(__file__)
    sys.path.insert(0, os.path.join(test_dir, '../../'))
    from ansible.plugins.action.include_vars import ActionModule
    test_module = ActionModule(task=None, connection=None, play_context=None, loader=None, shared_loader_obj=None, path_loader=None)

    test_module._set_args()
    test_module._set_root_dir()

    for root_dir, var_files in test_module._traverse_dir_depth():
        failed, err_msg, loaded_data = test_module._load_files_in_dir(root_dir, var_files)
        if failed:
            break

    assert failed == False
    assert err

# Generated at 2022-06-23 08:16:45.954512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize a AnsibleModule
    import ansible.module_utils.common as moduleCommon
    moduleCommon = moduleCommon

# Generated at 2022-06-23 08:16:57.039974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pudb
    import StringIO
    import sys
    import unittest

    sys.modules['ansible.utils.vars'] = __import__('ansible.utils.vars', fromlist=['vars'])

    from ansible.utils.vars import combine_vars

    class ActionBase():
        class Task():
            class DataLoader():
                def __init__(self):
                    self.task_vars = {}

                def get_basedir(self):
                    return ""

                def load_from_file(self, file_name):
                    return open(file_name).read()

            class Role():
                def __init__(self):
                    self.role_path = ""

            class AnsibleVars():
                def __init__(self):
                    self._data_source = ""


# Generated at 2022-06-23 08:16:58.484386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dut = ActionModule()
    dut.run()


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-23 08:16:59.720554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:17:03.267457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)



# Generated at 2022-06-23 08:17:14.801983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    ActionModule class run unit test stub.
    """
    if not isinstance(ActionModule.run, types.FunctionType):
        raise TypeError("ActionModule.run should be defined as a function")
    if not isinstance(ActionModule.run.__doc__, str):
        raise TypeError("ActionModule.run's doc should be defined as a string")

    # class properties can contain doc
    if not ActionModule.__doc__:
        raise TypeError("ActionModule should have a docstring")
    if not ActionModule.__module__:
        raise TypeError("ActionModule should have a module")
    if not ActionModule.__name__:
        raise TypeError("ActionModule should have a name")

    # class init, can contain doc

# Generated at 2022-06-23 08:17:17.341130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:17:27.525459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic

    # Dummy task_vars for testing
    task_vars = dict()

    # Dummy AnsibleModule for testing
    am = basic.AnsibleModule(
        argument_spec=dict(
            dir=dict(required=False),
            file=dict(required=False),
            name=dict(required=False),
            hash_behaviour=dict(required=False),
            depth=dict(required=False, type='int'),
            files_matching=dict(required=False),
            ignore_files=dict(required=False, type='list')
        )
    )
    am._ansible_no_log = False
    am._ansible_debug = False
    am._ansible_verbosity = 0
    am._ansible_socket_timeout = 10
    am

# Generated at 2022-06-23 08:17:41.953497
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import imp
    import os
    import sys
    import types
    import unittest

    def get_test_vars(tmpdir, vars_file_content, extras = {}):
        if isinstance(tmpdir, str):
            tmpdir = os.path.abspath(tmpdir)
        module_vars_file = '{}/{}'.format(tmpdir, 'test.test')
        with open(module_vars_file, 'w') as f:
            f.write(vars_file_content)

# Generated at 2022-06-23 08:17:42.598919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:17:43.517146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == False

# Generated at 2022-06-23 08:17:51.229219
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_modlib.test.tools import MockModule

    task_vars = dict()
    task_vars['test'] = {'key': 'value'}

    mock_module = MockModule()
    mock_module.params = task_vars

    mock_action_module = ActionModule(mock_module)
    mock_action_module._set_args()

    assert(not mock_action_module.run()['failed'])

    task_vars = dict()
    task_vars['test'] = {'key': 'value'}

    mock_module = MockModule()
    mock_module.params = task_vars
    mock_module.args = {}
    mock_module.args['name'] = 'hostvars'


# Generated at 2022-06-23 08:17:57.808762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:18:04.283908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.include_vars import ActionModule
    # initialize ansible task_vars
    task_vars = dict()
    add_plugin_vars = dict()
    add_plugin_vars['include_vars'] = dict()
    # set ansible plugin_vars
    add_plugin_vars['include_vars']['hash_behaviour'] = 'replace'
    add_plugin_vars['include_vars']['name'] = 'file1'
    add_plugin_vars['include_vars']['dir'] = '/root/roles/test/vars'
    add_plugin_vars['include_vars']['depth'] = 0

# Generated at 2022-06-23 08:18:06.030188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    assert action is not None

# Generated at 2022-06-23 08:18:15.992897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import pytest
    TESTING_MODULE = 'ansible.plugins.action.include_vars'
    module_name = TESTING_MODULE.split('.')[-1]

    # Initialize ActionModule instance
    test_class = ActionModule(dict(), dict())

    # Place where test-cases will be stored
    test_cases = list()

    # ------------------------------------------------------------------------------------------------------------------
    # Case: A valid directory with files in it.
    # ------------------------------------------------------------------------------------------------------------------
    test_case_name = 'Invalid dir with files in it'
    test_arguments = dict(
        dir='/tmp/test_include_vars_run'
    )
    test_returns = dict(
        failed=True,
        message='/tmp/test_include_vars_run directory does not exist'
    )
    test_