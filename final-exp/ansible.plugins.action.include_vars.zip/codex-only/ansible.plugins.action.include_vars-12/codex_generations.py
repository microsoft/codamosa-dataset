

# Generated at 2022-06-23 08:08:20.739860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = None
    action_module._loader = None
    action_module.show_content = True
    action_module.included_files = []
    action_module._set_dir_defaults()
    action_module.source_dir = None
    action_module.source_file = None
    action_module.depth = None
    action_module.files_matching = None
    action_module.ignore_files = None
    action_module.ignore_unknown_extensions = False
    action_module.valid_extensions = ['yaml', 'yml', 'json']
    action_module.hash_behaviour = None
    action_module.return_results_as_name = None
    assert action_module.run(None, None)


# Generated at 2022-06-23 08:08:22.655781
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionBase)

# Generated at 2022-06-23 08:08:23.577795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(1,2)



# Generated at 2022-06-23 08:08:29.707999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    test_args = {
        'file': '/path/to/file.yml'
    }
    # When
    test_object = ActionModule({'args': test_args})
    test_object.run()
    # Then
    path_to_file = test_object._task.args.get('file', None)
    assert path_to_file == '/path/to/file.yml'

# Generated at 2022-06-23 08:08:38.290284
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:08:39.152557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:08:45.609751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Negative case
    instance = ActionModule()
    try:
        instance._set_args()
    except Exception as e:
        assert type(e) == AnsibleError
        assert e.message == 'vars is not a valid option in include_vars'

    # Negative case
    instance = ActionModule()
    try:
        instance._set_args()
    except Exception as e:
        assert type(e) == AnsibleError
        assert e.message == 'vars is not a valid option in include_vars'

# Generated at 2022-06-23 08:08:51.929815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-23 08:09:03.110199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule
    """
    # Execute method run of class ActionModule with a mocked object for self._loader
    # and return_results_as_name = the_new_name and a mocked object for task_vars
    # that returns a dict with the key new_name_key and the value new_name_value.
    action_module = ActionModule(self=Mock(
        _loader=Mock(list_dir=lambda path: ['not_matching_file1', 'not_matching_file2', 'matching_file']),
    ), task=Mock(args=dict(
        name='the_new_name',
        file='/a_directory/matching_file',
        hash_behavior='replace',
        files_matching='matching_file',
    )))
    result

# Generated at 2022-06-23 08:09:04.337159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:09:11.701950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import shutil
    import tempfile
    from ansible.module_utils import basic
    from ansible.module_utils.six import iteritems
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.action.include_vars import ActionModule

    # Initialization

# Generated at 2022-06-23 08:09:19.111486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(''))
    variable_manager.set_extra_vars({'test': 'fail'})
    variable_manager.set_extra_vars('{"test": "fail"}')

    module = ActionModule(play_context=PlayContext(), variable_manager=variable_manager)
    module.run()

# Generated at 2022-06-23 08:09:20.244610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 08:09:21.164632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass


# Generated at 2022-06-23 08:09:22.786793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-23 08:09:31.108923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import string_types
    # for example, this will run
    import sys
    #sys.stdin = open(r"test_data/test_include_vars/test_include_vars.json")
    #sys.stdin = open(r"test_data/test_include_vars/test_include.json")

# Generated at 2022-06-23 08:09:38.664456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    from ansible.module_utils.six import BytesIO

    class MockDataSource():

        def __init__(self):
            self.current_dir = "ansible/test/units/modules/test"

        def get(self, path):
            self.current_dir = path
            return "test"

        def get_content(self, path):
            pass

        def get_content_from_file(self, *args):
            pass

        def get_content_from_provider(self, *args):
            pass

        def get_file(self, _):
            pass

        def get_string(self, _):
            pass

        def is_file(self, _):
            pass

        def is_directory(self, _):
            pass


# Generated at 2022-06-23 08:09:49.228376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict(), dict())
    action._task_vars = dict()

    # Test when dir is not provided and file is provided
    action._task.args = dict(
        dir=None,
        file=None,
        _raw_params='inventory/host_vars/test.yml'
    )

    action._set_args()
    assert not action.source_dir
    assert action.source_file == 'inventory/host_vars/test.yml'

    # Test when dir is provided and file is not provided
    action._task.args = dict(
        dir='inventory/group_vars/all',
        file=None,
        _raw_params=None
    )

    action._set_args()
    assert action.source_dir == 'inventory/group_vars/all'
   

# Generated at 2022-06-23 08:09:53.318993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(load_data_file=[DATA_FILE], load_task=[TASK_FILE], load_playbook=[PLAYBOOK_FILE])


# Generated at 2022-06-23 08:10:05.209332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with open('test/unit/module_utils/test_ansible_module_include_vars.yaml', 'r') as f:
        data = f.read()


# Generated at 2022-06-23 08:10:05.792434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return True

# Generated at 2022-06-23 08:10:18.232609
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Initialize class object
    action_obj = ActionModule()

    # Initialize dict object with all required key-value pair
    task_object = dict()

    task_object['args'] = dict()
    task_object['args']['hash_behaviour'] = 'replace'
    task_object['args']['name'] = 'replace'
    task_object['args']['dir'] = 'import/multipart'
    task_object['args']['depth'] = 0
    task_object['args']['files_matching'] = '*.yaml'
    task_object['args']['ignore_files'] = 'ignore_files'
    task_object['args']['ignore_unknown_extensions'] = 'ignore_unknown_extensions'

# Generated at 2022-06-23 08:10:25.093366
# Unit test for constructor of class ActionModule
def test_ActionModule():
  global_task_vars = {'foo': 'bar'}
  task_action = ActionModule(
    task = {'args': {'name': 'var_name', 'hash_behaviour': 'replace'}},
    connection = None,
    play_context = {},
    loader = None,
    templar = None,
    shared_loader_obj = None)
  results = task_action.run(task_vars=global_task_vars)
  assert results['ansible_included_var_files'] == []
  assert results['ansible_facts']['var_name']['foo'] == 'bar'
  assert results['failed'] == False
  assert results['_ansible_no_log'] == True

# Generated at 2022-06-23 08:10:34.909815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(
        action=dict(
            module='include_vars',
            args=dict(
                dir='tests/resources',
                depth=0,
                _raw_params='tests/resources',
                extensions=['yml'],
            ),
        ),
    )

    action_plugin = ActionModule(task, task_vars=dict())
    result = action_plugin.run(None, dict())
    assert result['ansible_facts']['test_list_var'] == [1, 2, 3]
    assert result['ansible_facts']['test_dict_var'] == {'key': 'value'}
    assert result['ansible_facts']['test_string_var'] == 'value'

# Generated at 2022-06-23 08:10:36.227321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-23 08:10:44.586094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = type('', (), {})()
    task.args = {
        'dir': 'fake_dir',
        'depth': 1,
        'files_matching': 'fake_regex',
        'ignore_files': 'fake_ignore',
        'name': 'fake_name',
        'hash_behaviour': 'fake_hash'
    }
    new_act = ActionModule(task, dict())
    assert new_act.depth == 1
    assert new_act.files_matching == 'fake_regex'
    assert new_act.ignore_files == 'fake_ignore'
    assert new_act.return_results_as_name == 'fake_name'
    assert new_act.hash_behaviour == 'fake_hash'


# Generated at 2022-06-23 08:10:45.485723
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'

# Generated at 2022-06-23 08:10:57.090587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class dummy_task:
        def __init__(self):
            self.args = dict()
            self._ds = dict()
    class dummy_loader:
        def load(self, data, file_name='<string>', show_content=False):
            if show_content:
                return dict(key1='value1', key2='value2')
            else:
                return dict()
        def _get_file_contents(self, filename):
            return True, True
    class dummy_action:
        def __init__(self):
            self.name = True
            self.hash_behaviour = None
            self.return_results_as_name = None
            self.source_dir = None
            self.source_file = None
            self.depth = None
            self.files_matching = None
            self

# Generated at 2022-06-23 08:10:57.719921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:11:06.509969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook import Play, Playbook
    from ansible.plugins.callback import CallbackBase
    test_playbook = Playbook.load('test/unit/loader/get_vars/ansible-get-vars-role_include.yml',
                                  variable_manager=VariableManager(), loader=DataLoader())

# Generated at 2022-06-23 08:11:14.841086
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Unit test #1
    arguments = {'file': '/home/home/kolla-ansible/ansible/roles/zabbix-server/templates/zabbix_server.conf.j2'}

    # Unit test #2
    #arguments = {'dir': '/home/home/kolla-ansible/ansible/roles/zabbix-server/templates'}

    task = ActionModule(arguments)
    result = task.run()

    print(result)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:11:15.505115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:11:17.942292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:11:19.544505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    print(action_module.run())

# Generated at 2022-06-23 08:11:29.368575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    # Test files matching
    action_module.files_matching = 'test'
    assert(action_module.files_matching == 'test')
    # Test dir
    action_module.source_dir = 'test'
    assert(action_module.source_dir == 'test')
    # Test source file
    action_module.source_file = 'test'
    assert(action_module.source_file == 'test')
    # Test ignore files
    action_module.ignore_files = 'test'
    assert(action_module.ignore_files == 'test')
    # Test depth
    action_module.depth = 'test'
    assert(action_module.depth == 'test')
    # Test extensions
    action_module.valid_extensions = 'test'

# Generated at 2022-06-23 08:11:43.325269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 1: Test the run method with _raw_params as the only argument
    # Pass: test_ActionModule_run
    test1 = {'_raw_params': 'test.yaml'}
    test_obj = ActionModule(dict(), dict(), False, test1)
    test_obj.show_content = True
    test_obj.included_files = []
    test_obj.source_file = 'test.yaml'
    test_obj.hash_behaviour = None
    test_obj.return_results_as_name = None
    test_obj.source_dir = None
    test_obj.depth = None
    test_obj.files_matching = None
    test_obj.ignore_unknown_extensions = False
    test_obj.ignore_files = None
    test_obj.valid_extensions

# Generated at 2022-06-23 08:11:46.113702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # test for init
    assert(action_module)

# Generated at 2022-06-23 08:11:57.572039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import os.path
    import ansible.plugins.action.include_vars

    action = ansible.plugins.action.include_vars.ActionModule(mock.Mock(), dict(), mock.Mock(), mock.Mock(), mock.Mock(), mock.Mock())

    # Test case 1
    # one arg
    # arg = file
    action._task.args = dict(file='./test/include_vars.json')
    if os.path.exists(action._task.args['file']):
        result = action.run()
        assert not result.get('failed')
    else:
        assert False

    # Test case 2
    # one arg
    # arg = dir
    action._task.args = dict(dir='./test')

# Generated at 2022-06-23 08:12:03.945327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This unit test uses Ansible 2.0.0.0 which includes
    # the plugin/modules for ActionModule.
    # This module has been tested on Ansible 2.0.0.0
    module = None
    for module in ACTION_MODULES:
        if module.__name__ == 'ActionModule':
            break

    assert(module.__name__ == 'ActionModule')

# Generated at 2022-06-23 08:12:08.531804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # ACTION['run'] is an instance method of class ActionModule

    # action = ACTION['run']

    # ACTION['run'] = ActionModule.run
    # if ACTION['run'] != ActionModule.run:
    #     print('%d values does not match' % ACTION['run'])
    # else:
    #     print('identical')
    # print('type of run is: %s' % str(type(ACTION['run'])))

    # ACTION['run'] = action
    pass # TODO

# Generated at 2022-06-23 08:12:19.745579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    return module


if __name__ == '__main__':
    task = {'args': {
                'name': 'testing_name',
                'dir': './var/',
                'depth': 1,
                'files_matching': '(.*).yml',
                'ignore_files': 'main.yml',
                'extensions': ['yml'],
                'ignore_unknown_extensions': False,
                'hash_behaviour': 'replace'
            },
            '_role_path': '/root/ansible/roles/common/tasks/'
            }
    module = test

# Generated at 2022-06-23 08:12:21.876595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._task.args == {}, "Test 1 - Constructor of ActionModule has error!"


# Generated at 2022-06-23 08:12:23.286344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:12:26.234831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_action = ActionModule()
    test_action._task.args = None
    try:
        test_action.run()
    except AnsibleError:
        pass


# Generated at 2022-06-23 08:12:26.923825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:12:33.810573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    class Host():
        def __init__(self, host_name):
            self.name = host_name

    inventory = {
        'test_host': Host('test_host')
    }

    class Playbook():
        pass
    pb = Playbook()

    class Connection():
        pass
    conn = Connection()


# Generated at 2022-06-23 08:12:34.913093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict())

# Generated at 2022-06-23 08:12:38.547510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:12:48.967343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for constructor for the class
    test_action_module = ActionModule()
    assert test_action_module._task.args.get('dir', None) is None
    assert test_action_module._task.args.get('file', None) is None
    assert test_action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert test_action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert test_action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert test_action_module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:12:50.591670
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance = ActionModule()
    assert instance

# Generated at 2022-06-23 08:13:01.260039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Trying to load a directory that does not exist
    test_vars = {'name': 'test_name',
                 'dir': 'test_dir',
                 'files_matching': 'test_files_matching',
                 'ignore_files': ['test_ignore_files'],
                 'hash_behaviour': None,
                 'ignore_unknown_extensions': False,
                 'extensions': ['yml', 'yaml']
                 }

    action_module = ActionModule()
    action_module._task.args = test_vars
    action_module._set_dir_defaults()
    failed, err_msg = action_module.run(task_vars=dict())['failed'], action_module.run(task_vars=dict())['message']

# Generated at 2022-06-23 08:13:10.613890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # type: () -> None
    def run_mock(*args, **kwargs):
      return {
        'failed': False,
        'ansible_facts': {
          'pkg_mgr': 'yum',
          'distribution': 'RedHat'
        }
      }
    file_loader = type('FileLoader', (object,), {'get_basedir': lambda x: '/path', '_get_file_contents': lambda x, y: ('', True)})
    my_loader = type('Loader', (object,), {'load': lambda x, y, z: {'pkg_mgr': 'yum', 'distribution': 'RedHat'}, '_get_file_contents': lambda x, y: ('', True)})()

# Generated at 2022-06-23 08:13:21.537294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    # create a fake task object
    class FakeTask:
        def __init__(self, args=dict()):
            self.action = 'include_vars'
            self.args = args
            self.task = None
            self.tags = set()
            self.register = None

        def set_loader(self, loader):
            self.loader = loader

        def set_task(self, task):
            self.task = task

        def set_role(self, role):
            self.role = role

        def set_ds(self, ds):
            self.ds = ds

    # create a fake play object

# Generated at 2022-06-23 08:13:23.816273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
    except Exception:
        raise AssertionError('Cannot initialize ActionModule')

# Method test for run method of class ActionModule

# Generated at 2022-06-23 08:13:30.896506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import shutil
    import sys
    import tempfile
    from ansible.module_utils._text import to_bytes

    # patching sys.argv so call to _find_needle works
    sys.argv = ['ansible-playbook', '-vvvvv', 'play.yml']
    # define temp directory to store test data in
    test_tmp_dir = tempfile.mkdtemp()

    # test data
    test_data = {
        'success_data': {'hello': 'world'},
        'fail_data': 'hello: world'
    }

    # test files
    test_success_file = os.path.join(test_tmp_dir, 'success.yml')

# Generated at 2022-06-23 08:13:42.675739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict()
    task['args'] = {'dir': './tests/unit/files/dir_files_vars', 'depth': 2, 'files_matching': '.*.yml'}
    task['name'] = 'include_vars'
    task['action'] = 'include_vars'
    task['_ansible_parsed'] = False
    task['_ansible_no_log'] = False
    task['_uses_shell'] = False
    task['when'] = []
    task['async'] = 0
    task['async_val'] = 0

    action_module = ActionModule(task, dict())
    assert action_module.source_dir == './tests/unit/files/dir_files_vars'
    assert action_module.depth == 2
    assert action_module.files

# Generated at 2022-06-23 08:13:50.943471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionModule)
    assert module.depth == 0
    assert isinstance(module.VALID_FILE_EXTENSIONS, list)
    assert isinstance(module.VALID_DIR_ARGUMENTS, list)
    assert isinstance(module.VALID_FILE_ARGUMENTS, list)

# Generated at 2022-06-23 08:13:59.686083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock of the class under test ActionModule
    class ActionModuleClassObj:
        def __init__(self):
            # Mock the _get_file_contents method of class Loader
            class LoaderClassObj:
                def __init__(self):
                    pass
                def _get_file_contents(self, filename):
                    return True
            # Mock the _loader instance variable
            self._loader = LoaderClassObj()
            # Mock the args instance variable
            self._task = object()
            self._task.args = dict()
            
    # Create an instance of the class under test
    action_module = ActionModuleClassObj()
    # run the code to be covered
    result = action_module.run()
    # Assert that the method run of class ActionModule returns a dict
    assert type(result) == dict

# Generated at 2022-06-23 08:14:10.685356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am._task is None
    assert am.depth is None
    assert am.ignore_files is None
    assert am.ignore_unknown_extensions is False
    assert am.included_files == []
    assert am.return_results_as_name is None
    assert am.show_content is True
    assert am.source_dir is None
    assert am.source_file is None
    assert am.VALID_ALL == ['name', 'hash_behaviour']
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert am.VALID_FILE_EXTENS

# Generated at 2022-06-23 08:14:12.950809
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import ansible.modules.system.include_vars as module
    assert True


# Generated at 2022-06-23 08:14:13.425375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-23 08:14:15.537618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule(None, None)) == ActionModule


# Generated at 2022-06-23 08:14:18.222169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    return action_module._task.args


# Generated at 2022-06-23 08:14:23.194586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert am.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:14:23.844572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 08:14:24.489969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:14:35.023483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict()
    task['vars'] = dict()
    task['vars']['dir'] = 'vars/'
    task['vars']['depth'] = 1
    task['vars']['ignore_files'] = 'main.yml'
    task['vars']['ignore_unknown_extensions'] = False
    # Instanstiating 'ActionModule' class
    am = ActionModule(task, dict())
    # Calling private method directly to test
    am._set_dir_defaults()
    am._set_root_dir()
    for _, filenames in am._traverse_dir_depth():
        am._load_files_in_dir(am.source_dir, filenames)
    return am

# Generated at 2022-06-23 08:14:37.500449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create mock object
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-23 08:14:48.426306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    from ansible.plugins.action.include_vars import ActionModule

    # setup mock action task
    mock_task_ds = mock.Mock()
    mock_task_ds._data_source = '/tmp/vars-include/tasks/main.yml'
    mock_task = mock.Mock()
    mock_task._role = None
    mock_task._ds = mock_task_ds
    mock_task.args = dict()
    mock_task.args['_raw_params'] = 'test_files/test_vars_files/first.yml'
    mock_task.args['depth'] = 0

    action_instance = ActionModule(mock_task, dict())

    # setup mock loader
    mock_loader = mock.Mock()
    mock_loader._get_file_contents

# Generated at 2022-06-23 08:14:57.625593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(None, None)

    # Test 1
    a._task.args = {'dir': 'vars', 'depth': 1, 'extensions': ['yml']}

    a._set_args()
    r = a.run(None, {'role_facts.yml': {'a': 'b'}})

    assert r['ansible_facts'] == {'a': 'b'}
    assert r['ansible_included_var_files'] == ['role_facts.yml']
    assert set(r['_ansible_no_log'].keys()) == {'changed'}
    assert not r['_ansible_no_log']['changed']

    # Test 2

# Generated at 2022-06-23 08:15:02.948234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock
    action = ActionModule()
    assert isinstance(action, ActionModule)
    assert isinstance(action._loader, mock.MagicMock)
    assert isinstance(action._play_context, mock.MagicMock)
    assert isinstance(action._task, mock.MagicMock)
    assert isinstance(action._connection, mock.MagicMock)
    assert isinstance(action._loader, mock.MagicMock)

# Generated at 2022-06-23 08:15:15.034268
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:15:27.035405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test is skipped on Python 2.6 and 3.4, because the yaml.load() does not support PyYaml's FullLoader
    # Test is skipped on Python 3.5, because it does not support the flag show_content
    # Test is skipped on Python 3.6, because it does not support the flag show_content
    # Test is skipped on Python 3.7, because it does not support the flag show_content
    # The flag show_content is required in tests because the pyyaml version
    # installed in the test environment does not support to load any python object
    # without it, so it raises an error like:
    # yaml.constructor.ConstructorError: could not determine a constructor for the tag 'tag:yaml.org,2002:python/unicode'
    import sys

# Generated at 2022-06-23 08:15:37.031613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.include_vars import ActionModule
    #  Fails if json file does not exist
    with pytest.raises(AnsibleError) as exception_info:
        ActionModule(dict(dir="../../../test/include_vars/vars_dir", depth=2, files_matching=".*\.json", ignore_files="test_include_vars.py"), None, None, None).run()

    #  Fails if dir does not exist
    with pytest.raises(AnsibleError) as exception_info:
        ActionModule(dict(dir="../../../test/include_vars", depth=2, files_matching=".*\.json", ignore_files="test_include_vars.py"), None, None, None).run()

    #  Fails if dir is

# Generated at 2022-06-23 08:15:37.739452
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:15:39.271923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.run()

test_ActionModule_run()

# Generated at 2022-06-23 08:15:51.469551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    from ansible.plugins.loader import action_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    import shutil

    class Options:
        DEFAULT_FORKS = 1
        _file_name = 'kevin.yml'
        connection = 'local'
        module_path = '/path/of/module/'
        forks = DEFAULT_FORKS
        become = False
        become_method = None
        become_user = None
        check = False
        diff = False
        verbosity = 3

# Generated at 2022-06-23 08:15:55.476408
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    """
    assert True, "Unit tests not implemented"
    """
    assert True

# Generated at 2022-06-23 08:15:56.340620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError

# Generated at 2022-06-23 08:15:58.319030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:16:08.420707
# Unit test for constructor of class ActionModule
def test_ActionModule():

    valid_file_extensions = ['yaml', 'yml', 'json']
    valid_dir_arguments = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    valid_file_arguments = ['file', '_raw_params']
    valid_all = ['name', 'hash_behaviour']

    plugin = ActionModule()

    assert plugin.VALID_FILE_EXTENSIONS == valid_file_extensions
    assert plugin.VALID_DIR_ARGUMENTS == valid_dir_arguments
    assert plugin.VALID_ALL == valid_all
    assert plugin.VALID_FILE_ARGUMENTS == valid_file_arguments

# Generated at 2022-06-23 08:16:13.974363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test to verify constructor of class ActionModule works as expected """
    # Init an instance of type:ActionModule named:am
    am = ActionModule()
    assert am is not None
    assert hasattr(am, 'show_content')
    assert hasattr(am, 'included_files')



# Generated at 2022-06-23 08:16:24.255004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext

    my_playbook_executor = PlaybookExecutor()
    my_playbook_executor._tqm = None
    my_playbook_executor._loader = None
    my_playbook_executor._variable_manager = None
    my_playbook_executor._basedir = '.'

    my_play_context = PlayContext()

    my_task = Task()
    my_task._role = None

    my_block = Block()
    my_block.block = []
    my_block.filter_terms = []

# Generated at 2022-06-23 08:16:35.531021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import ansible.playbook.task
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.block
    import ansible.playbook.helpers
    import ansible.parsing.dataloader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.connection import Connection
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader, connection_loader, lookup_loader, module_loader, callback_

# Generated at 2022-06-23 08:16:36.974238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call default constructor
    print(ActionModule())


# Generated at 2022-06-23 08:16:42.860504
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.module_utils.basic as basic
    import ansible.module_utils.facts as facts

    basic.AnsibleModule._load_params()
    facts.AnsibleModule_load_params()

    action = ActionModule()

    # tests mockup
    m_walk = Mock(walk)
    m_walk.walk.return_value = [('/root_dir', [], ['main.yml']), ('/root_dir', [], ['satellite.yml'])]

    m_load_file = Mock(ActionModule._load_files)
    m_load_file.ActionModule._load_files.return_value = (False, None, {'content': "is working"})

    m_ignore_file = Mock(ActionModule._ignore_file)
    m_ignore_file.ActionModule._ignore_

# Generated at 2022-06-23 08:16:43.721697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(__name__, {}, None)

# Generated at 2022-06-23 08:16:55.214456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class InputTaskVars(object):
        def __init__(self):
            self.args = {}

    class InputParent(object):
        def __init__(self):
            self._ds = InputDS()

    class InputDS(object):
        def __init__(self):
            self._data_source = 'test'

    class InputTask(object):
        def __init__(self):
            self._ds = InputDS()
            self._role = None
            self.args = dict()

    class InputRole(object):
        def __init__(self):
            self._role_path = 'test'

    INPUT_TASK = InputTask()
    INPUT_ROLE = None
    INPUT_LOADER = False
    INPUT_CACHE = False

# Generated at 2022-06-23 08:17:07.438062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # set the following global settings
    C.HOST_KEY_CHECKING = False
    C.DEFAULT_VAULT_PASSWORD_FILE = True
    C.DEFAULT_HASH_BEHAVIOUR = "replace"
    C.DEFAULT_KEEP_REMOTE_FILES = False
#    C.DEFAULT_CACHE_PLUGIN = "basic"
    #C.DEFAULT_TIMEOUT = 10
    #C.DEFAULT_SUDO_PASS = True
    #C.DEFAULT_SUDO_USER = True
    #C.DEFAULT_REMOTE_PASS = False
    #C.DEFAULT_REMOTE_USER = False

    #test_utf8_filename = 'café.yml'
    #test_utf8_filename = u'café.yml'.en

# Generated at 2022-06-23 08:17:09.939794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run')
    actionModule = ActionModule()

    # TODO: Test when the source_dir and source_file are not set

# Generated at 2022-06-23 08:17:10.928081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:17:12.785516
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

if __name__ == '__main__':
    # Run unit tests
    test_ActionModule()

# Generated at 2022-06-23 08:17:13.476356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:17:15.285511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    print("dummy test")

# Generated at 2022-06-23 08:17:15.995038
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert(actionModule)


# Generated at 2022-06-23 08:17:16.593483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return None

# Generated at 2022-06-23 08:17:17.095414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-23 08:17:20.394405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(0, 0, 0, 0)
    # TODO: implement
    assert False


# Generated at 2022-06-23 08:17:22.587906
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)


# Generated at 2022-06-23 08:17:36.594674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        pass
    test = TestActionModule()
    assert test.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert test.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert test.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert test.VALID_ALL == ['name', 'hash_behaviour']

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:17:37.271594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:17:38.017054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:17:45.483351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(), None, C.DEFAULT_LOADER, C.DEFAULT_TEMPLATE)
    assert action.VALID_ALL == ['name', 'hash_behaviour']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

# Generated at 2022-06-23 08:17:46.682920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule("dir/path")
    del action
    assert True

# Generated at 2022-06-23 08:17:52.836826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert hasattr(ActionModule, 'run')
    assert hasattr(ActionModule, '_set_args')
    assert hasattr(ActionModule, '_load_files')
    assert hasattr(ActionModule, '_load_files_in_dir')
    assert hasattr(ActionModule, '_ignore_file')
    assert hasattr(ActionModule, '_set_dir_defaults')
    assert hasattr(ActionModule, '_set_root_dir')
    assert hasattr(ActionModule, '_traverse_dir_depth')
    assert hasattr(ActionModule, '_is_valid_file_ext')

# Generated at 2022-06-23 08:17:56.688561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('tests/fixtures/test_include_vars/actions/action_plugins/', '', {}, '') is not None

# Generated at 2022-06-23 08:17:57.360302
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:18:10.749566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader

    def load_examples_from_file(tmpdir):
        data_dir = tmpdir.mkdir('data')
        data_dir.join('role_file.yml').write('role_file: name')

        task = Task()
        task.args = dict()

        # Test with only file argument
        task.args['_raw_params'] = 'role_file.yml - name=null'
        action = action_loader.get('include_vars', task, {},
                                   data_dir.join('role_file.yml').strpath)
        result = action.run()
        assert result['ansible_facts'] == dict(role_file=('name',))