

# Generated at 2022-06-23 08:08:19.670630
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:08:20.612636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:08:23.561696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = "ActionModule"
    module_path = "ansible.plugins.action.include_vars"
    module_klass = load_plugi

# Generated at 2022-06-23 08:08:24.558792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError

# Generated at 2022-06-23 08:08:28.017293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, {}, {}, None)
    assert am != None

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:08:37.011564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude, IncludeTask
    from ansible.inventory.manager import InventoryManager

    # Creating the objects needed to instantiate the class
    invent_manager = InventoryManager(loader=None, variables={})

# Generated at 2022-06-23 08:08:44.978428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ## set up
    module_mock = ActionModule()
    module_mock._set_args()
    module_mock.hash_behaviour = 'replace'
    module_mock.return_results_as_name = "vars_out"
    module_mock.source_dir = '/Users/allen/git/ansible/test/integration/targets/test-port-async-mux/vars'
    module_mock.depth = 0
    module_mock.files_matching = '.*'
    module_mock.ignore_unknown_extensions = False
    module_mock.ignore_files = ['main.yml']
    module_mock.valid_extensions = []
    module_mock.show_content = True

# Generated at 2022-06-23 08:08:52.054654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'actionPlugin'
    filename = 'actionPlugin.py'
    class_name = 'ActionModule'
    import sys
    import os
    import imp
    import ansible.plugins.action
    old_path = sys.path
    action_plugin_module = imp.find_module(module_name, [os.path.dirname(ansible.plugins.action.__file__)])
    action_plugin_module = imp.load_module(class_name, *action_plugin_module)
    action_plugin_class = getattr(action_plugin_module, class_name)

    # Create a mock object of class ActionModule
    action_module_class = action_plugin_class()
    return action_module_class


# Generated at 2022-06-23 08:08:53.381405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-23 08:08:59.943465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    protocol = [
        'dir',
        'depth',
        'files_matching',
        'ignore_files',
        'file',
        '_raw_params',
        'name',
        'extensions'
    ]
    # create a new ActionModule Object
    action_module = ActionModule()

    # Check if all the data is validating
    for item in protocol:
        assert item in action_module._task.args



# Generated at 2022-06-23 08:09:09.538682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case expected output
    expected_output = {
        u'ansible_included_var_files': [u'/test1.yml', u'/test2.yml'],
        u'ansible_facts': {
            u'var1': u'value1',
            u'var2': u'value2',
            u'var3': u'value3'
        },
        u'_ansible_no_log': True,
    }

    # test case input
    task_vars_input = dict()
    task_args_input = {
        'file': u'/test1.yml',
        'extensions': [u'yml', u'yaml']
    }

    ansible_module_mock = ActionModule('setup')
    ansible_module_mock._task = Task()

# Generated at 2022-06-23 08:09:11.099000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionModule)


# Generated at 2022-06-23 08:09:22.718780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def test(passed, target, true_value, fail=False):
        if fail:
            assert(passed != true_value)
        else:
            if target not in passed:
                raise Exception('{0} "{1}" not in answered value'.format(target, true_value))
            assert(passed[target] == true_value)

    def run_test(test_args, depth, files_matching, ignore_files, expected_results, is_file=True, return_as_name='', extensions=None):
        from .include_vars import ActionModule
        import imp, os

        #ansible/plugins/action/include_vars.py
        script_dir = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-23 08:09:24.719983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Create an instance of ActionModule, then run it.
    """
    action = ActionModule()
    action.run()

# Generated at 2022-06-23 08:09:33.677420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_task = lambda: None
    test_task.args = dict()
    test_task.args['_ansible_verbosity'] = 4
    test_task.args['_ansible_check_mode'] = True
    test_task.args['_ansible_selinux_special_fs'] = ['fuse', 'nfs', 'vboxsf', 'ramfs', '9p']
    test_task.args['_ansible_no_log'] = False
    test_task.args['_ansible_diff'] = False
    test_task.args['_raw_params'] = 'testfile'
    test_task.args['_ansible_syslog_facility'] = 'LOG_USER'
    test_task.args['_ansible_debug'] = True

# Generated at 2022-06-23 08:09:44.622754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    tmp = None
    source_dir_args = dict(
        dir='test_dir',
        depth=2,
        files_matching='.*',
        ignore_files='',
        extensions='yml'
    )
    file_args = dict(
        file='test_file'
    )
    args = source_dir_args
    args.update(file_args)

    action = ActionModule(task_vars=task_vars, tmp=tmp, args=args)
    assert action.TransfersFiles == False
    assert action.ValidFileExtensions == ['yaml', 'yml', 'json']
    assert action.ValidDirArguments == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']


# Generated at 2022-06-23 08:09:52.968930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from mock import Mock
    from ansible.utils.vars import combine_vars

    task_vars = dict()
    source_dir = "vars"
    source_file = "test.yml"
    _set_dir_defaults_source_dir = "test.yml"
    _set_dir_defaults_source_file = "test.yml"
    _set_dir_defaults_depth = 1
    _set_dir_defaults_files_matching = "*.yml"
    _set_dir_defaults_ignore_files = "*.ignore"
    _set_dir_defaults_extentions = ["yml"]
    _set_dir_defaults_ignore_unknown_extensions = False
    _set_dir_defaults_name = "test"
    _set_dir

# Generated at 2022-06-23 08:09:53.710868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:09:55.389447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action

# Generated at 2022-06-23 08:09:56.606528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert ActionModule.run()

# Generated at 2022-06-23 08:10:02.440225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t = ActionModule(None, None, None)
    t._set_root_dir()
    t._set_dir_defaults()
    t._traverse_dir_depth()
    t._ignore_file()
    t._load_files()
    t._load_files_in_dir()
    t._set_args()

# Generated at 2022-06-23 08:10:02.825797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:10:15.507962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeVars(object):
        _role = None
        _ds = None

    class FakeRole(object):
        def __init__(self):
            self._role_path = ''

    class FakeDataSource(object):
        def __init__(self):
            self._data_source = ''

    module_cls = ActionModule(task=FakeVars(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Failed test case: no file or dir prsent in args
    task_vars = {}
    result = module_cls.run(task_vars=task_vars)
    assert result['failed'] == True
    assert result['message'] == 'Neither file nor dir option passed to include_vars'

    # Failed test case: both

# Generated at 2022-06-23 08:10:21.107865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert  ActionModule(None, None, None, None).VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert  ActionModule(None, None, None, None).VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert  ActionModule(None, None, None, None).VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:10:29.530390
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # given
    depth = 0
    files_matching = None
    ignore_files = None
    source_dir = 'path/to/source_dir'
    source_file = 'path/to/source_file'
    task_vars = dict()
    valid_extensions = ['yaml', 'yml', 'json']
    target = dict()
    target['ansible_included_var_files'] = list()
    target['ansible_facts'] = dict()
    target['ansible_facts']['foo1'] = 'bar1'
    target['ansible_facts']['foo2'] = 'bar2'
    target['_ansible_no_log'] = True
    failed = False
    err_msg = ''

    # result in success

# Generated at 2022-06-23 08:10:31.804539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule constructor")
    print("ActionModule constructor is tested by Ansible")


# Generated at 2022-06-23 08:10:42.413178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import b
    from ansible.parsing.yaml.objects import AnsibleVaultSecret
    from ansible.plugins.action import ActionModule

    if not sys.version_info >= (2, 7):
        print('SKIPPING TestActionModule: requires python >= 2.7')
        return

    module_name = 'test_action_module'

# Generated at 2022-06-23 08:10:44.152706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:10:54.915003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    yaml_file = '../../examples/vars/example.yml'
    test_object = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_object._set_args()
    assert test_object.source_file == yaml_file, 'Initializing class with valid params failed'

    test_object = ActionModule(task=None, connection=None, play_context={}, loader=None, templar=None, shared_loader_obj=None)
    test_object._set_args()
    assert test_object.source_file is None, 'Initializing class with invalid params failed'

# Generated at 2022-06-23 08:10:56.535559
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# # Unit test for method _set_dir_defaults of class ActionModule

# Generated at 2022-06-23 08:11:02.727659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task={
        'action': {
            'name': 'include_vars',
            'args': {
                'dir': '/tmp/etc/yaml',
                'files_matching': '.*\.yaml',
                'ignore_files': '.*ignore.*'
            }
        }
    }, task_ds={}, play_context={}, shared_loader_obj=None, variable_manager=None, loader=None)
    assert action_module



# Generated at 2022-06-23 08:11:13.260910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module_obj.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module_obj.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module_obj.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module_obj.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-23 08:11:14.199887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-23 08:11:16.117509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(name='test')
    assert mod._task.action == 'test'


# Generated at 2022-06-23 08:11:17.335855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule()

# Generated at 2022-06-23 08:11:27.322830
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule """

    # tests for file parsing
    action = ActionModule(dict(), dict())
    source_file = 'source_file.yml'
    action.source_file = source_file
    files, show_content = action._loader._get_file_contents(source_file)
    assert len(files) == 0

    # tests for recursive directory parsing
    action = ActionModule(dict(), dict())
    action.ignore_unknown_extensions = True
    action.valid_extensions = ['yml']
    action.source_dir = 'source_dir'
    action.depth = 0
    action.ignore_files = ['source_file.yml']

# Generated at 2022-06-23 08:11:32.244143
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule().VALID_FILE_EXTENSIONS == ActionModule.VALID_FILE_EXTENSIONS
    assert ActionModule().VALID_DIR_ARGUMENTS == ActionModule.VALID_DIR_ARGUMENTS
    assert ActionModule().VALID_FILE_ARGUMENTS == ActionModule.VALID_FILE_ARGUMENTS
    assert ActionModule().VALID_ALL == ActionModule.VALID_ALL


# Generated at 2022-06-23 08:11:44.555399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Task:
        class _ds:
            _data_source = 'playbook/common.yml'
        _ds = _ds()
        args = {}
    class TaskVars:
        pass
    class Play:
        pass
    task_vars = TaskVars()
    task = Task()
    play = Play()
    play._role = None
    task._play = play
    am = ActionModule(task, {})
    am._task = task
    am._loader = None
    am._templar = None
    am._shared_loader_obj = None
    am._connection = None
    am._find_needle = None
    am._set_args()
    assert am.source_dir == 'playbook/common.yml'
    assert am.return_results_as_name == None

# Generated at 2022-06-23 08:11:55.742626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('\nTesting ActionModule.run')
    from ansible.playbook.task import Task
    from ansible.executor import task_result, active_results
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars

    # Create an UnsafeProxy object so that UnsafeProxy.is_safe_attribute returns True
    UnsafeProxy({})

    # Create a Task object so that Task._load_vars returns a VariableManager object
    fake_task = Task()
    fake_loader = fake_task._loader
    fake_variable_manager = VariableManager(loader=fake_loader, host_vars=HostVars(loader=fake_loader, groups=['all']))
    fake_task._variable_

# Generated at 2022-06-23 08:12:08.385652
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _loader = DictDataLoader({})
    _task = Task({'_role': None})
    _play_context = PlayContext()
    _shared_loader_obj = SharedPluginLoaderObj()
    _display = Display()

    action = ActionModule(loader=_loader, task=_task, play_context=_play_context,
                        shared_loader_obj=_shared_loader_obj, action_display=_display)

    # Args: dir
    # No match found for dir
    _task.args = {'dir': 'test'}
    assert action.run()['failed'] == True

    # Args: file
    # No match found for file
    _task.args = {'file': 'test'}
    assert action.run()['failed'] == True

    # Args: _raw_params
    #

# Generated at 2022-06-23 08:12:09.769200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.TRANSFERS_FILES == False


# Generated at 2022-06-23 08:12:12.098200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_ActionModule = ActionModule('test', 'test', 'test', 'test')
    assert test_ActionModule is not None

# Generated at 2022-06-23 08:12:24.051179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None, None, None)

    import re
    import base64
    import os

    play_context = object
    play_context.become = False
    play_context.become_user = None
    play_context.connection = 'smart'
    play_context.remote_addr = None
    play_context.remote_user = None
    play_context.port = 22
    play_context.password = None
    play_context.private_key_file = None
    play_context.timeout = 10
    play_context.shell = None
    play_context.sudo_user = None
    play_context.verbosity = 0
    play_context.only_tags = []
    play_context.skip_tags = []
    play_context.become_method = 'sudo'

# Generated at 2022-06-23 08:12:25.591515
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Dummy test
    try:
        ActionModule()
    except:
        print("Error")


# Generated at 2022-06-23 08:12:26.660705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None)

# Generated at 2022-06-23 08:12:34.398868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert mod.TRANSFERS_FILES == False

    # Test when both source_file and source_dir are none
    assert mod._task.args == {'_raw_params': 'roles/common/vars/main.yml'}
    assert mod.source_file == 'roles/common/vars/main.yml'
    assert mod.source_dir is None

    # Test when source_file is not none but source_dir is none
    assert mod._task.args == {'_raw_params': 'roles/common/vars/main.yml'}
    assert mod.source_file == 'roles/common/vars/main.yml'
    assert mod

# Generated at 2022-06-23 08:12:44.529308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.tests.unit.v2.test_utils.action_mocks import MockActionModule

    def test_ActionModule_run_ok():
        # Test OK case
        task = dict(
            action=dict(
                module='include_vars',
                args=dict(
                    file='/tmp/ansible/data/'
                )
            )
        )
        task_vars = dict()

        # Set mock
        mock_action = MockActionModule(task, task_vars)
        mock_action._find_needle = lambda self, directory, filename: '/tmp/ansible/data/var1.yml'
        mock_action._load_files = lambda self, filename: (False, '', dict(var1='val1'))


# Generated at 2022-06-23 08:12:57.817981
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_args = {'name': 'var_name', 'hash_behaviour': 'replace', 'dir': 'test_dir', 'depth': 0,
                 'files_matching': 'test_matching', 'ignore_files': 'file1', 'extensions': 'yaml'}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None,
                                 shared_loader_obj=None)
    action_module._task.args = task_args
    action_module._set_args()
    dirs = 0
    files = 0
    for arg in action_module._task.args:
        if arg in action_module.VALID_DIR_ARGUMENTS:
            dirs += 1

# Generated at 2022-06-23 08:12:59.209973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Not implemented yet")
    assert False

# Generated at 2022-06-23 08:13:09.203036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run
    '''
    args = {'file': 'test_include_vars.yml'}
    action = ActionModule(dict(ACTION=dict(args)), None)
    action._task.args = args
    action._task._role = dict()
    action._task._role._role_path = '.'
    action._task._ds = dict()
    action._task._ds._data_source = 'test_include_vars.yml'
    result = action.run()
    assert result['ansible_facts']['test_var'] == 'test_value'
    assert result['ansible_included_var_files'] == ['test_include_vars.yml']



# Generated at 2022-06-23 08:13:20.795908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case when 'name' is provided
    action_module_instance = ActionModule(
        task=dict(args=dict(name='test', file='/etc/hosts'))
    )
    result = action_module_instance.run()
    assert result['ansible_facts'] == dict(test=dict(hosts=['127.0.0.1'], hosts_ipv6=['::1']))
    assert result['ansible_included_var_files'] == []
    assert result['_ansible_no_log'] is True

    # Test case when 'name' is not provided
    action_module_instance = ActionModule(
        task=dict(args=dict(file='/etc/hosts'))
    )
    result = action_module_instance.run()
    assert result['ansible_facts']

# Generated at 2022-06-23 08:13:29.780795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Init mock variables
    vars = dict()
    task_vars = dict()
    tmp = None
    task_vars['role_path'] = '/Users/arpit/ansible-collection-community.general/roles/test'
    task_vars['data_source'] = '/Users/arpit/ansible-collection-community.general/roles/test/tasks/main.yml'
    tmp = None
    # Set object variables
    dirs = 0
    files = 0
    for arg in 'ansible_facts':
        if arg in ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']:
            dirs += 1
        elif arg in ['file', '_raw_params']:
            files += 1

# Generated at 2022-06-23 08:13:31.185864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """
    module = ActionModule()
    module.run()

# Generated at 2022-06-23 08:13:31.975693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:13:38.233251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-23 08:13:39.567108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_instance = ActionModule()
    assert test_instance is not None

# Generated at 2022-06-23 08:13:51.975207
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.utils import context_objects as co

    # set up test case

# Generated at 2022-06-23 08:14:00.448439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules.utility.include_vars as include_vars
    from ansible.playbook.play_context import PlayContext
    import yaml
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp(suffix='-ansible-tests')
    play_context = PlayContext()
    task = include_vars.ActionModule(None, None, tmp_dir, play_context, '', '', '', True)
    task_vars = dict()
    # Test empty args
    results = task.run(None, task_vars)
    assert results['failed'] == True
    assert results['message'] == 'You must specify at least one of the following options: dir, file, _raw_params'
    # Test args: name, dir
    tmp_dir = tempfile.mk

# Generated at 2022-06-23 08:14:11.408644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host_sequential_list = ['ansible-test-1.in.tls.example.com', 'ansible-test-2.in.tls.example.com', 'ansible-test-3.in.tls.example.com']

# Generated at 2022-06-23 08:14:17.139947
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create instance of ActionModule class
    obj = ActionModule()

    # test for bad dir
    obj.source_dir = 'thisisabaddirectory'
    assert obj.run()['failed']

    # test for bad file
    obj.source_dir = None
    obj.source_file = 'thisisabadfile.yml'
    assert obj.run()['failed']

    # test for good dir
    obj.source_dir = '../../lib/ansible/modules/system/'
    assert not obj.run()['failed']

    # test for good file
    obj.source_dir = None
    obj.source_file = '../../lib/ansible/modules/system/ping.py'
    assert not obj.run()['failed']



# Generated at 2022-06-23 08:14:19.612931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(dict(), dict(), dict())
    assert action_module is not None, "ActionModule is not initialized"


# Generated at 2022-06-23 08:14:20.837160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None)
    assert isinstance(action_module,ActionModule)

# Generated at 2022-06-23 08:14:26.405001
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # If no exception is raised, we are fine..
        test = ActionModule()
        # We only need to test the creation of the class, the __call__
        # method is tested elsewhere
        del test
    except Exception as e:
        error = e
        # There should be no Exceptions raised on creating the class
        # ActionModule
        raise Exception("We should not have gotten an error, but we got "
                        " {0}".format(error))


# Generated at 2022-06-23 08:14:29.889629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert set(am.VALID_FILE_ARGUMENTS) == set(['file', '_raw_params'])
    assert set(am.VALID_ALL) == set(['name', 'hash_behaviour'])

# Generated at 2022-06-23 08:14:34.529984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for class ActionModule."""
    action_module = ActionModule(
        task=dict(
            uuid='mock_uuid',
            args=dict(arg='mock_arg'),
            delegate_to='mock_delegate_to',
            register='mock_register',
            run_once='mock_run_once',
            action='mock_action'
        ),
        connection='mock_connection',
        play_context=dict(),
        loader='mock_loader',
        templar='mock_templar',
        shared_loader_obj='mock_shared_loader_obj'
    )
    assert action_module

# Generated at 2022-06-23 08:14:35.559267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:14:39.359531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    params = {
        'name': 'inventory_hostname',
        'file': 'localhost.yml',
    }
    action = ActionModule(None, params)
    assert action, "Failed to create ActionModule instance"

# Generated at 2022-06-23 08:14:44.066160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert type(action_module) == ActionModule

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:14:50.973573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(None, None)
    assert actionmodule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert actionmodule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert actionmodule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert actionmodule.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-23 08:14:51.785390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 08:14:58.425246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case
    test_data = {"file": "test/vars/test_data.yml"}
    # Test code
    import ansible.modules.utilities.include_vars
    test_ActionModule = ansible.modules.utilities.include_vars.ActionModule(task=test_data, connection=None, _shared_loader_obj=None, play_context=None)
    test_run = test_ActionModule.run()
    # Assertion
    assert test_run["failed"] == False
    assert test_run["ansible_facts"]["test_string"] == "Hello world"


# Generated at 2022-06-23 08:15:06.449805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.vars import VariableManager

    action_plugin = 'include_vars'
    name = 'test-name'
    variables = {
        'name': name,
        'dir': 'test-dir',
        'depth': 10,
        'files_matching': 'test-files-matching',
        'ignore_files': 'test-ignore-files',
        'ignore_unknown_extensions': False,
        'extensions': 'test-extensions',
    }
    path_to_action_plugin = action_loader.find_

# Generated at 2022-06-23 08:15:09.813166
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
  return action_module


# Generated at 2022-06-23 08:15:10.516704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:15:16.594232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    play_context = PlayContext()
    task = Task()
    task._role = None
    task._ds = None
    task.args = dict()
    action_module = ActionModule(task, play_context)

    assert action_module is not None

# Generated at 2022-06-23 08:15:24.109626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = {'hostvars': {'host1': {'ansible_host': 'host1'}, 'host2': {'ansible_host': 'host2'}},
                 'group_names': ['ungrouped']}


# Generated at 2022-06-23 08:15:35.261318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import yaml

    class TestTask(object):
        def __init__(self):
            self.args = {}
            self.default_vars = {}
            self.valid_attrs = ('args', 'default_vars')

        def __getattr__(self, name):
            if name not in self.valid_attrs:
                raise AttributeError("'{0}' object has no attribute '{1}'".format(self.__class__.__name__, name))
            else:
                return None

    class TestPlayContext(object):
        def __init__(self):
            self.network_os = None
            self.become = False
            self.become_method = None
            self.become_user = None
            self.remote_addr = None


# Generated at 2022-06-23 08:15:46.394069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import copy
    from ansible.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Empty specification
    args = dict()
    task = TaskInclude()
    task.args = args
    play_context = dict()

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    tqm = None

# Generated at 2022-06-23 08:15:56.914191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run')
    # set constants
    # default_hash_behaviour = 'replace'
    # default_name = None
    # default_ignore_unknown_extensions = False
    # default_extensions = ['yaml', 'yml', 'json']
    # default_depth = 0
    # default_files_matching = None
    # default_ignore_files = ['.gitignore']
    # default_return_results_as_name = None

    # set pkg variables
    source_dir = None
    source_file = 'test_example.yml'
    hash_behaviour = 'replace'
    return_results_as_name = 'test'
    depth = 0
    files_matching = None
    ignore_files = ['.gitignore']

# Generated at 2022-06-23 08:16:09.510839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set parameters
    tmp = None
    task_vars = {'ansible_pkg_mgr': 'yum'}
    # Create a class instance
    am = ActionModule(tmp)
    # Create an instance variable - this is necessary to call the run method
    # of class ActionModule.
    am._task = {'args': {'ignore_files': ['main'], 'ignore_unknown_extensions': False, 'extensions': ['yml', 'yaml'], 'hash_behaviour': 'replace', 'dir': 'test/unit/fixtures/', 'name': 'test_results'}}

    # Run run method
    result = am.run(tmp, task_vars)

# Generated at 2022-06-23 08:16:16.093130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes, to_text
    import os

    # Create the obj instance
    test_path = os.path.dirname(__file__)
    action_path = os.path.join(test_path, "./include_vars.py")
    action_class = action_loader.get('include_vars', class_only=True)
    action_instance = action_class()
    action_instance._setup_loader()

    # Create the mock task instance
    fixture_path = os.path.join(test_path, 'fixtures')
    data_source = 'include_vars.yml'
    data_source_path = os

# Generated at 2022-06-23 08:16:19.814149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionBase

    assert issubclass(ActionModule, ActionBase)
    assert hasattr(ActionModule, 'show_content')
    assert hasattr(ActionModule, 'included_files')



# Generated at 2022-06-23 08:16:27.224338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # construct a fake task object
    class FakeTask:
        def __init__(self):
            self._role = None
            self._ds = None
            self.args = {'file': 'string'}
    # construct a fake action module object
    class FakeActionModule:
        def __init__(self):
            pass
        def run(self, tmp=None, task_vars=None):
            return ('test_ActionModule_run', self._task)

    fakeactionmodule = FakeActionModule()
    fakeactionmodule._task = FakeTask()
    result, task_parameter_passed = fakeactionmodule.run()
    assert result == 'test_ActionModule_run'
    assert task_parameter_passed == fakeactionmodule._task


# Generated at 2022-06-23 08:16:27.963556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:16:31.284975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._task.args == {}
    assert module._loader.get_basedir() == '/nonexistent'
    assert module._templar.template('test') == 'test'

# Generated at 2022-06-23 08:16:41.568755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a mock task
    class MockTask():
        _ds = '.'
        _role = None
        def __init__(self):
            self._ds = '.'
            self._role = None
            self.args = None
            
    # create a mock play
    class MockPlay():
        def __init__(self):
            pass

    # create a mock options
    class MockOptions():
        def __init__(self):
            self.connection = False
            self.remote_user = "remote_user"

    # create a mock args
    class MockArgs():
        def __init__(self):
            self.connection = False
            self.remote_user = "remote_user"

    # create a mock data loader
    class MockLoader():
        def __init__(self):
            pass

    # create a mock

# Generated at 2022-06-23 08:16:53.519379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # functions not available in this module
    from ansible.playbook.play_context import PlayContext
    import sys

    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO
    # initialize objects
    play_context = PlayContext()
    action_module = ActionModule(load=None, play_context=play_context, task=None, connection=None, new_stdin=StringIO())
    action_module.connection = None
    action_module.loader = None
    action_module.task_vars = dict()
    action_module.tmp = dict()
    action_module.validate_files = False
    action_module._task = None
    action_module._loader = None
    # set task argument values
    action_module._task

# Generated at 2022-06-23 08:16:56.321988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('test_task_name', {'hash_behaviour': 'replace'}, 'test_included_files', 'test_show_content')

# Generated at 2022-06-23 08:16:57.140850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:17:02.802268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule

    :return: assert
    """
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-23 08:17:06.566406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=None, connection=None, _play_context=None, loader=None,
        templar=None, shared_loader_obj=None
    )
    assert action_module

# Generated at 2022-06-23 08:17:08.742387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test that the constructor of ActionModule accepts no arguments
    assert ActionModule() is not None



# Generated at 2022-06-23 08:17:09.445435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 08:17:19.604690
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:17:23.892107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    setattr(ActionModule, 'run', lambda self, tmp=None, task_vars=None: super(ActionModule,self).run(tmp=None, task_vars=None))
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-23 08:17:36.700539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    # call the Ansible module
    module = ActionModule(
        task=Task(
            ds=dict(
                _data_source='/Users/asanabria/Development/Toolbox/ansible/playbooks/playbook.yml',
            ),
            role=None
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # call the method we need to test
    module._traverse_dir_depth()

# Generated at 2022-06-23 08:17:46.915634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    include_vars = ActionModule(None, None, None, C.DEFAULT_HASH_BEHAVIOUR, None)
    assert include_vars.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert include_vars.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert include_vars.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert include_vars.VALID_ALL == ['name', 'hash_behaviour']



# Generated at 2022-06-23 08:17:47.624089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:17:48.307763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:17:48.848514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:17:55.142229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict())
    task_vars = dict()
    tmp = '/tmp'
    depth = dict()
    depth['depth'] = 0
    depth['dir'] = '../tests/unit/vars/complex/'
    depth['extensions'] = ['yml', 'yaml', 'json']
    depth['ignore_unknown_extensions'] = True
    depth['ignore_files'] = list()
    depth['ignore_files'].append('bar.j2')
    depth['ignore_files'].append('main.yml')
    depth['name'] = 'complex_dict'
    result = action.run(tmp, task_vars=task_vars, **depth)
    dict_test = dict()
    dict_test['list'] = ['foo', 'bar', 'baz']
    dict_test

# Generated at 2022-06-23 08:18:02.506993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ##############################################
    #
    #           Module: include_vars
    #           Action: run
    #           Case: Use file option
    #
    ##############################################

    # Initialize Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayBookPlay
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task as PlayBookTask
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils import context_objects as co

    # Initial

# Generated at 2022-06-23 08:18:06.584276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    res = ActionModule.run()
    assert(isinstance(res,dict))
    assert(res.get('ansible_included_var_files',None))
    assert(res.get('ansible_facts',None))

# Generated at 2022-06-23 08:18:08.432487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule("test"), ActionModule)


# Generated at 2022-06-23 08:18:09.095049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass