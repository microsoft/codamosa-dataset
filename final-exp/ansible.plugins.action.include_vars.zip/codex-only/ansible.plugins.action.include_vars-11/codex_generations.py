

# Generated at 2022-06-23 08:08:15.321913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    play = Play()

    # an action module is a subclass of object
    assert isinstance(ActionModule(loader=loader, play=play), object)

# Generated at 2022-06-23 08:08:23.195528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    """
    class FakeActionModule1(ActionModule):
        def __init__(self, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None):
            super(FakeActionModule1, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
    fake_action_module1 = FakeActionModule1()
    assert fake_action_module1


# Generated at 2022-06-23 08:08:24.846814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit tests
    pass


# Generated at 2022-06-23 08:08:26.216265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_ActionModule = ActionModule()

# Generated at 2022-06-23 08:08:33.365045
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils import basic
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task

    class FakeModule:
        def __init__(self, name=None, task=None):
            self.params = dict()
            self.name = name
            self.task = task

        def fail_json(self, msg):
            print(msg)

    class FakeTask:
        def __init__(self, args=None):
            self.args = args

    class FakeRole:
        def __init__(self, role_path=None):
            self.role_path = role_path
            self._role_path = role_path


# Generated at 2022-06-23 08:08:37.616391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    extra_vars = {'test_var': 'hello world'}
    action_module = ActionModule(task=extra_vars, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.test_var == 'hello world'

test_ActionModule()


# Generated at 2022-06-23 08:08:39.048101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(None, None), ActionBase)

# Generated at 2022-06-23 08:08:48.767735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    options = DummyOptions()
    options.connection = 'local'
    options.module_path = '.'
    options.forks = 1
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = {}
    play = Play().load

# Generated at 2022-06-23 08:09:01.044866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    # Create an instance of AnsibleTask
    task = Task()

    # Create an instance of AnsibleModule
    module = ActionModule(task, None)

    # Create task_vars
    task_vars = dict()
    task_vars["ansible_facts"] = {}

    # Create ansible_play_hosts
    ansible_play_hosts = None

    # Create a test case

# Generated at 2022-06-23 08:09:09.932874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    action_cls = action_loader.get('include_vars', class_only=True)
    action = action_cls(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._check_name('example.yml')
    assert action._check_name('subdir/example.yml')
    assert action._check_name('subdir/subsubdir/example.yml') == 'subsubdir/example.yml'
    assert action._check_name('subdir/subsubdir/subsubsubdir/example.yml') == 'subsubsubdir/example.yml'


# Generated at 2022-06-23 08:09:10.823441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 08:09:15.573484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Provide expected result to be returned by method run
    results = dict()
    results['ansible_included_var_files'] = []
    results['ansible_facts'] = dict()
    results['_ansible_no_log'] = True
    results['failed'] = False

# Generated at 2022-06-23 08:09:20.753979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(None, None)
    am._task.args = {'file': 'tests/fixtures/include_vars/main.yml'}
    out = am.run(task_vars={})
    assert out['_ansible_no_log'] is False
    assert out['ansible_facts']['lookups_data'] == {'test': 'data'}

# Generated at 2022-06-23 08:09:31.812035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from mock import patch, MagicMock
    # Set up mock object for loader
    loader_obj = MagicMock()
    loader_obj._get_file_contents.return_value = '''
    contents:
      load:
        result: {file: 'loaded'}
      ignore:
        result: {file: 'ignored'}
    '''
    loader_obj.load.return_value = [{'result':{'file': 'loaded'}}, {'result':{'file': 'ignored'}}]

    # Set up mock object for play
    play_obj = MagicMock()

    # Set up mock object for task
    task_obj = MagicMock()
    task_obj._ds = MagicMock()
    task_obj._ds._data_source = 'source/path'
    task_obj._

# Generated at 2022-06-23 08:09:33.438346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test for ActionModule class constructor """
    am = ActionModule(None, None)
    print('ActionModule Class instantiated')

# Generated at 2022-06-23 08:09:37.929705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(action=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:09:46.335199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    import os
    import sys
    import pytest
    import json

    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.constants import DEFAULT_VAULT_PASSWORD_FILE
    from ansible.constants import DEFAULT_TRANSPORT
    from ansible.constants import DEFAULT_PERSISTENT_COMMAND_TIMEOUT
    from ansible.module_utils.six import StringIO
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars

    test_file = os.path.join(os.environ.get('TEST_DATA_PATH'), 'vars_unit_test.txt')
    with open(test_file) as f:
        test_file_content = f.read()

# Generated at 2022-06-23 08:09:48.058193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None
# End of Unit test for constructor of class ActionModule


# Generated at 2022-06-23 08:09:50.534783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-23 08:10:01.988265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # arrange
    actionModule = ActionModule()
    actionModule.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
    actionModule.VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    actionModule.show_content = True
    actionModule._task = task = type('', (), {})()
    task.args = {'dir': 'dir', 'file': 'file', 'name': 'name'}

    def fun_format(string):
        return string

    actionModule._task.args = type('', (), {'get': fun_format})()

    def fun_get(string):
        return string

    def fun_set(string):
        return string

    actionModule._task

# Generated at 2022-06-23 08:10:11.936485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(None, None)
    assert mod.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert mod.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert mod.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert mod.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:10:22.185733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_args = {}
    dict_args['dir'] = './test/vars/dir1'
    dict_args['_raw_params'] = './test/vars/dir1'
    dict_args['file'] = './test/vars/dir1/vars.yml'

    task_vars = {}
    actinst = ActionModule(dict_args, task_vars)
    if not isinstance(actinst, ActionModule):
        pass
    else:
        raise Exception("Constructor of Action Module does not work")


if __name__ == '__main__':
    try:
        test_ActionModule()

        print('Unit test for ActionModule passed')

    except Exception as err:
        print('Unit test for ActionModule failed')
        print(err)

# Generated at 2022-06-23 08:10:24.734429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    ansible.plugins.action.ActionModule(None, None, None)

# Generated at 2022-06-23 08:10:26.589659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am

# Generated at 2022-06-23 08:10:35.221930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    # ansible.plugins.action.ActionBase._execute_module is stubbed to accomplish the required functionality
    act = ansible.plugins.action.ActionBase()
    act._execute_module = stub_ActionBase__execute_module
    # ansible.plugins.action.ActionBase.run is stubbed to facilitate the unit test
    act.run = stub_ActionBase_run

    obj = ActionModule(task=act, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    obj.run()

# This method stubs the ansible.plugins.action.ActionModule._execute_module
# and prints the status of the method

# Generated at 2022-06-23 08:10:36.183433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule()

# Generated at 2022-06-23 08:10:38.358474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(ActionModule(), dict())
    assert action_module is not None

# Generated at 2022-06-23 08:10:45.355815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Variables declaration
    ansible_facts = dict()
    ansible_included_var_files = list()
    failed = False
    message = None
    # Code
    pass
    # Tests
    assert ansible_facts is not None
    assert ansible_included_var_files is not None
    assert failed is not None
    assert message is not None
    # Debug:
    #print(ansible_facts)
    #print(ansible_included_var_files)
    #print(failed)
    #print(message)


# Generated at 2022-06-23 08:10:45.820596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:10:57.399313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(task_vars=task_vars)

    class TestTask:
        def __init__(self, args):
            self._ds = None
            self._role = None
            self.args = args

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

   

# Generated at 2022-06-23 08:10:59.612195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if not isinstance(ActionModule.run, MethodType):
        raise AssertionError("run is not a method of class ActionModule")

# Generated at 2022-06-23 08:11:00.326315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:11:01.292629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action.run()

# Generated at 2022-06-23 08:11:01.933433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:11:02.544414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:11:13.883075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
 
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C
    import json

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-23 08:11:17.961050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # arrange
    module = ActionModule()
    tmp = None
    task_vars = None

    # act
    result = module.run(tmp, task_vars)

    # assert
    assert 'ansible_facts' in result
    assert result['failed'] == True
    assert result['_ansible_no_log'] == True
    assert result['ansible_facts'] == {}
    assert result['ansible_included_var_files'] == []
    assert 'message' in result


# Generated at 2022-06-23 08:11:20.307685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    action_module._set_args()
    assert action_module.hash_behaviour == None

# Generated at 2022-06-23 08:11:21.237521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()


# Generated at 2022-06-23 08:11:30.808282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instance of class
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    task_vars = dict()
    result = action_module.run(task_vars=task_vars)

    assert result['ansible_included_var_files'] == []
    assert result['ansible_facts'] == {}

    # Test set_args method
    action_module._task.args = dict()
    action_module._task.args['dir'] = 'tests/vars'
    action_module._set_args()
    assert action_module.source_dir == 'tests/vars'
    assert action_module.depth == 0

    # Test called with dir
    action_module._task.args = dict

# Generated at 2022-06-23 08:11:41.177403
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None,
                                 templar=None,
                                 shared_loader_obj=None)
    assert action_module
    assert isinstance(action_module.VALID_FILE_EXTENSIONS, list)
    assert isinstance(action_module.VALID_DIR_ARGUMENTS, list)
    assert isinstance(action_module.VALID_FILE_ARGUMENTS, list)
    assert isinstance(action_module.VALID_ALL, list)


# Generated at 2022-06-23 08:11:51.715164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock
    from ansible.playbook.task import Task
    from ansible.playbook.block import TaskBlock
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    class TestModule(ActionModule):
        VALID_FILE_ARGUMENTS = ['file', '_raw_params']
        VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
        VALID_ALL = ['name', 'hash_behaviour']

        def __init__(self):
            self._set_dir_defaults = mock.Mock()
            self._set_args = mock.Mock()
            self._traverse_dir_depth = mock.Mock()
            self

# Generated at 2022-06-23 08:12:03.957577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Mock object for task
    def mock_task_func(task):
        task['args'] = {
            'dir': '/var/yml/',
            'name': 'test_var',
            'hash_behaviour': 'replace'
        }
        task['_role'] = {
            '_role_path': '/var/roles/'
        }

    action_module = ActionModule()
    action_module._get_action_args = mock_task_func
    action_module._set_root_dir()
    assert action_module.source_dir == '/var/yml/'

    action_module._set_root_dir()
    action_module._task.args['dir'] = 'vars'
    assert action_module.source_dir == '/var/roles/vars'


# Generated at 2022-06-23 08:12:05.745223
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    """
    action_module_obj = ActionModule(1, 2)
    assert isinstance(action_module_obj, ActionModule)

# Generated at 2022-06-23 08:12:06.390755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:12:07.367876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-23 08:12:10.466151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create task
    task = {
        'args': {
            'file': '../templates/sources/vars.yml'
        }
    }

    # Create module
    action = ActionModule(task, None)
    res = action.run()
    assert res['ansible_facts']['vars'] == 'ok'

# Generated at 2022-06-23 08:12:22.804576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    import collections
    import json

    task_vars = collections.namedtuple('TaskVars', ['name'])('test')

    module_args = collections.namedtuple('Module', ['file'])('test')

    module = AnsibleModule(argument_spec=dict(
        dir=dict(type='str', default=None),
        files_matching=dict(type='str', default=None),
        ignore_files=dict(type='str', default=None),
        extensions=dict(type='str', default=None),
        ignore_unknown_extensions=dict(type='bool', default=None),
        depth=dict(type='int', default=None),
    ))

    action = ActionModule(module, task_vars)
    results = action.run

# Generated at 2022-06-23 08:12:33.946307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This method is called inside of a context to set up the module and task
    # vars which cannot be done in a test.
    def run_module(task_vars=None):
        module = ActionModule()
        module._task = MockTask()
        module._connection = MockConnection()
        module._loader = MockLoader()
        if task_vars is None:
            module._task_vars = dict()
        else:
            module._task_vars = task_vars
        return module.run()

    # Helper function to verify the result of the module run
    def check_result(result, expected_res):
        assert 'failed' in result
        assert 'message' in result
        assert 'ansible_facts' in result
        assert 'ansible_included_var_files' in result


# Generated at 2022-06-23 08:12:36.508180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test case 1: get correct instance of ActionModule class
    return_value = ActionModule(dict(), dict())
    assert isinstance(return_value, ActionModule)

# Generated at 2022-06-23 08:12:47.643726
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:12:59.779499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    task_vars = dict()
    task_vars['ansible_distribution'] = Distribution().init().distribution_name

    action_mod = ActionModule()
    action_mod._task = object()
    action_mod._task.args = dict()
    action_mod._task.args['file'] = '/tmp/test.yml'
    action_mod._task.args['hash_behaviour'] = 'replace'
    action_mod._loader = AnsibleLoader()
    action_mod._connection = AnsibleConnection()
    action_mod._display = AnsibleDisplay()
    action_mod._set_args()

    # ActionModule._traverse_dir_depth
    action_mod.source_dir = '/tmp/test_dir'
    action_mod

# Generated at 2022-06-23 08:13:03.770548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ """
    # The test will pass if this function returns a value
    return True


if __name__ == '__main__':
    """ Main function """
    # Call the test function
    test_ActionModule_run()

# Generated at 2022-06-23 08:13:11.630023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader = DictDataLoader({})
    env_vars = {'ANSIBLE_FORCE_COLOR': 'false'}
    inventory = InventoryManager(loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    task = Task()
    task._role = MockRole()
    task._ds = MockDS()
    task._ds._data_source = 'fake/path/to/file'
    task._ds._task = task
    task._ds._task._role = None
    task._ds._task._ds = task._ds
    task._ds._task.args = {}

    action = ActionModule(task, variable_manager=variable_manager, all_vars=dict())
    assert action
    assert action._task == task
    assert action._play_context == None
    assert action

# Generated at 2022-06-23 08:13:17.644758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.args = dict()
    module._task.args['file'] = 'test/files/vars/user_name/user_name.yaml'
    module._task._role = 'test/files/vars'
    module._task._ds = 'test/files/vars'
    module.run()



# Generated at 2022-06-23 08:13:19.117462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:13:20.012248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-23 08:13:29.280878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_details = {
        'source_dir': 'test/unit/fixtures/include_vars',
        'return_results_as_name': 'test_variables',
        'hash_behaviour': 'replace',
        'ignore_files': 'main.yml',
        'files_matching': None,
        'depth': 1,
        'extensions': ['yml', 'yaml']
    }

    test_case_details['dir'] = 'dir_with_no_files'
    test_case = ActionModule(
        task=dict(
            _role=None,
            args=test_case_details
        )
    )

# Generated at 2022-06-23 08:13:30.679960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Write unit test
    pass


# Generated at 2022-06-23 08:13:42.599780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    source_dir = path.join(tmpdir, 'tests', 'vars')
    source_file = path.join(tmpdir, 'tests', 'vars', 'main.yml')

    assert not path.exists(tmpdir)
    os.makedirs(source_dir)
    with open(source_file, 'wt') as f:
        f.write('hello: 1\n')
        f.write('world: 2\n')

    task_vars = dict()
    task = dict(
        args = dict(
            dir = path.join(tmpdir, 'tests', 'vars'),
            hash_behaviour = 'merge',
            name = 'myvars'
        )
    )

# Generated at 2022-06-23 08:13:53.928949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from mock import Mock
    from mock import patch

    class FakeTask(object):
        def __init__(self):
            self._role = Mock()
            self._role._role_path = '/test/role_path'

        def __getattr__(self, name):
            if name == 'args':
                return self.args
            if name == '_ds':
                return self._ds

        def __setattr__(self, name, value):
            if name == 'args':
                self.args = value
            if name == '_ds':
                self._ds = value

    class FakeLoader(object):
        def __init__(self, data_source=None):
            self._data_source = data_source

        def __getattr__(self, name):
            if name == '_data_source':
                return

# Generated at 2022-06-23 08:14:01.710320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # init
    from ansible.plugins.loader import action_loader
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task

    # prepare
    plugin_list = [('include_vars', include_vars_action)]
    action_loader.add_directory(plugin_list)

    task = Task()
    task.name = 'include_vars'
    task.args = {
        'name': 'my_var',
        'file': '/home/user/my_var.yml',
        '_ansible_ignore_errors': True,
    }

    current_play = Playbook()
    current_play.vars = dict()
    current_play.extra_vars = dict()
    current_play.connection = 'local'
    current_play.hosts = dict

# Generated at 2022-06-23 08:14:12.354920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli import CLI
    from collections import namedtuple
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars
    from ansible.playbook.task import Task
    import os
    import pytest

    class DataLoaderMock:
        def __init__(self):
            self.files = {}
            self.files['./test/filetest.sh'] = u'{"test": "ok"}'

        def load(self, path, file_name='', show_content=True):
            return self.files[path] if path in self.files else '{}'


# Generated at 2022-06-23 08:14:15.400327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    action_module = ActionModule(task_vars)
    assert(action_module)


# Generated at 2022-06-23 08:14:26.020045
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import json

    filename = 'my_file.yml'
    filename_json = 'my_file.json'
    filename_txt = 'my_file.txt'

    fh = open(filename, 'w')
    fh.write("""
    foo: bar
    bar: baz
    """)
    fh.close()

    fh = open(filename_json, 'w')
    fh.write(json.dumps({'a': 'b'}))
    fh.close()

    fh = open(filename_txt, 'w')
    fh.write("invalid file contents")
    fh.close()

    # Unit test for file-names with invalid extensions

# Generated at 2022-06-23 08:14:27.196887
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance = ActionModule()
    assert isinstance(instance, ActionModule)

# Generated at 2022-06-23 08:14:27.775209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pass
    pass

# Generated at 2022-06-23 08:14:28.221277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:14:40.607523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am._task = object()
    am._task.args = {
        'name': 'test',
        'file': object()
    }
    am._task._ds = object()
    am._task._ds._data_source = '/tmp/test'
    am._set_args = Mock(return_value=None)
    am._load_files = Mock(return_value=(0, None, {'test': 'test'}))
    am._task.run = Mock(return_value={})
    result = am.run()
    assert result['ansible_facts'] == {'test': 'test'}
    am._set_args.side_effect = AnsibleError('test')

# Generated at 2022-06-23 08:14:42.103365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing ActionModule run()')
    # TODO implement unit test
    assert True

# Generated at 2022-06-23 08:14:43.741853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test_ActionModule_run
    pass

# Generated at 2022-06-23 08:14:44.394117
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass

# Generated at 2022-06-23 08:14:55.182683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.vars import combine_vars

    # create the object
    options = {}
    task = {}
    action = ActionModule(task, options)

    # create a test directory
    task['args'] = {'dir': '/tmp/testdir'}
    action._set_dir_defaults()
    assert action.files_matching == "*"
    assert action.matcher == re.compile("*")
    assert action.ignore_files == []
    assert action.depth == 0

    # create a test directory
    task['args'] = {'dir': '/tmp/testdir', 'files_matching': "*.yml"}
    action._set_dir_defaults()
    assert action.files_matching == "*.yml"

# Generated at 2022-06-23 08:15:04.710750
# Unit test for constructor of class ActionModule
def test_ActionModule():

    task_vars = dict()

    # Constructor test 1
    task_vars['ansible_included_var_files'] = []
    file_name = 'some_file.yml'
    task_vars['ansible_included_var_files'].append(file_name)
    my_action_module = ActionModule()
    my_action_module.run(task_vars=task_vars)
    assert 'ansible_included_var_files' in task_vars
    assert len(task_vars['ansible_included_var_files']) == 1
    assert task_vars['ansible_included_var_files'][0] == file_name

    # Constructor test 2 (no task_vars passed)
    my_action_module = ActionModule()
    my

# Generated at 2022-06-23 08:15:10.073455
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print ('''
    ########## Test cases ##########

    1. Valid case of usage.
    2. Invalid case of usage.
    ''')
    choice = int(input('\nEnter your choice: '))
    if choice == 1:
        print ('\nCreating valid instance of ActionModule')
        action_module = ActionModule()
        print ('\nPrinting the current task...')
        print (action_module._task)
    else:
        print ('\nCreating invalid instance of ActionModule')
        # Creating an invalid instance of ActionModule
        # action_module = ActionModule(None)
        action_module = ActionModule()

    print ('\n')

# Uncomment this section to run test cases for class ActionModule
# test_ActionModule()

# Generated at 2022-06-23 08:15:20.197793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source_dir = '/home/kask/Documents/ansible_examples/vars'
    root = '/home/kask/Documents/ansible_examples/'
    example_file = 'example_var.yml'
    depth = 2
    files_matching = '.*\.yml'
    ignore_files = ['.*\.txt']
    valid_extensions = ['yaml', 'yml', 'json', 'txt']
    ignore_unknown_extensions = False

    class _Task:
        class _DS:
            _data_source = '/home/kask/Documents/ansible_examples/vars/example_var.yml'

        def __init__(self):
            self._ds = self._DS()


# Generated at 2022-06-23 08:15:32.450792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup test
    import sys
    import os
    import tempfile

    source_dir = tempfile.mkdtemp()
    f1 = open(os.path.join(source_dir, 'file1.yml'), 'wb')
    f1.write(b"---\nname: file1")
    f1.close()

    f2 = open(os.path.join(source_dir, 'file2.yml'), 'wb')
    f2.write(b"---\nname: file2")
    f2.close()

    f3 = open(os.path.join(source_dir, 'file3.json'), 'wb')
    f3.write(b"{\nname: file3\n}")
    f3.close()

    my_task = MockTask()
    my_task._

# Generated at 2022-06-23 08:15:35.096217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-23 08:15:36.053167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:15:47.688975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    host_list = [
        {
            "hostname": "testserver.example.com",
            "groups": [
                "app_servers",
                "dev_env",
                "prod_env"
            ],
            "vars": {
                "foo": "bar"
            }
        }
    ]

    inventory = InventoryManager(loader=DataLoader(), sources=host_list)
    variable_

# Generated at 2022-06-23 08:15:48.868758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule == type(ActionModule())

# Generated at 2022-06-23 08:15:58.111583
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.errors import AnsibleError
    from ansible.plugins.action.include_vars import ActionModule
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    class FakeVariables:
        def get_vars(self, loader, play, host, task):
            return dict()

    class FakeLoader:

        def get_basedir(self, connection):
            return 'my_base_dir'

        def load(self, data, file_name=None, show_content=True):
            return dict(a='b')

    class FakeTask:
        def __init__(self):
            self._role = None
            self._ds = None

# Generated at 2022-06-23 08:16:09.834967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Playbook
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins import module_loader

    from ansible.utils.vars import combine_vars
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.play_context import PlayContext

    from ansible.inventory.host import Host

# Generated at 2022-06-23 08:16:12.558298
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:16:23.569187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test __init__
    assert ActionModule('', '', '', dict()).VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule('', '', '', dict()).VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule('', '', '', dict()).VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule('', '', '', dict()).VALID_ALL == ['name', 'hash_behaviour']

    # test _set_dir_defaults
    action_module = ActionModule('', '', '', dict())
    action_module.depth = None
    action_module._set_dir

# Generated at 2022-06-23 08:16:34.506215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit tests for class ActionModule"""
    action_module = ActionModule(None, None, None, None)

    # Case 1:
    # source_dir = /path/to/dir
    # depth = 1
    # files_matching = yml
    # ignore_files = test.yml
    # extensions = [yml, yaml]
    # ignore_unknown_extensions = False

    # Case 2:
    # source_dir = /path/to/dir
    # depth = 1
    # files_matching = yml
    # ignore_files = test.yml
    # extensions = [yml, yaml]
    # ignore_unknown_extensions = True


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-23 08:16:35.484639
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:16:44.901377
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test 1
    task = {
        "vars": {
            'hosts': ['host1', 'host2']
        },
        "args": {
            "file": "test_HostVars1",
            "name": "test1_result"
        }
    }

    am = ActionModule(task, {})

    result = am.run()
    assert result['ansible_facts']['test1_result']['vars'] == {'hosts': ['host1', 'host2']}

    # Test 2
    task = {
        "vars": {
            'hosts': ['host1', 'host2']
        },
        "args": {
            "file": "test_HostVars2",
            "name": "test2_result"
        }
    }


# Generated at 2022-06-23 08:16:45.910669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == "ActionModule"

# Generated at 2022-06-23 08:16:57.040920
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MockPluginLoader:
        pass

    class MockDS:
        pass

    class MockRole:
        pass

    class MockTask:
        pass

    class MockTaskDS:
        pass

    mock_plugin_loader = MockPluginLoader()
    mock_task_ds = MockTaskDS()
    mock_task_ds._data_source = './test/include_vars/vars/foo.yml'

    mock_ds = MockDS()
    mock_ds.my_var = 'test'
    mock_ds._data_source = './test/include_vars/vars/foo.yml'

    mock_role = MockRole()
    mock_role._role_path = '/tmp/roles/include_vars'

    mock_task = MockTask()
    mock_task._role = mock_role


# Generated at 2022-06-23 08:16:57.665313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:16:59.080616
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:17:11.689913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule"""
    # Testing with directory
    task_vars = dict()
    _setup_test(task_vars)
    action = create_action(dir='dir-valid', depth=0)
    result = action.run(task_vars=task_vars)
    assert result['ansible_facts']['files_found'] == 1 # The number of files found in the dir

    # Testing with file
    task_vars = dict()
    _setup_test(task_vars)
    action = create_action(file='file.yaml')
    result = action.run(task_vars=task_vars)
    assert result['ansible_facts']['files_found'] == 1 # The number of files found in the dir


# Generated at 2022-06-23 08:17:12.639334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError()


# Generated at 2022-06-23 08:17:21.567311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    unit_test_action_module = ActionModule(task=None, connection=None, play_context=None, loader=None,
                                           templar=None, shared_loader_obj=None)
    unit_test_module_result = {}
    unit_test_module_result['ansible_included_var_files'] = []
    unit_test_module_result['ansible_facts'] = []
    unit_test_module_result['_ansible_no_log'] = False
    unit_test_action_module._get_argument_spec = lambda: {'file': 'foo', 'name': 'bar', '_raw_params': 'baz'}
    unit_test_action_module._task.args = {'file': 'foo', 'name': 'bar', '_raw_params': 'baz'}


# Generated at 2022-06-23 08:17:25.431741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    print(action_module.__class__.__name__ + "()")
    return action_module


if __name__ == '__main__':
    action_module = test_ActionModule()
    print(action_module)

# Generated at 2022-06-23 08:17:38.438274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from unittest.mock import patch, Mock, MagicMock
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.include_vars import ActionModule
    from ansible.playbook.play_context import PlayContext
    
    mock_task = Mock()
    mock_task.args = {'dir': 'test_dir', 'depth': 1}
    mock_task._role = None
    mock_task._ds = None
    mock_task._ds._data_source = 'test_source'
    
    am = ActionModule(mock_task, Mock(), Mock())
    am.set_runner(Mock())
    am.set_loader(Mock())
    am._task.args = {}
    am._set_args = MagicMock()

# Generated at 2022-06-23 08:17:43.646257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    test = ActionModule(name=dict(), depth=1, file="test_hosts")
    assert(test.run(task_vars) == "test_hosts")

# Generated at 2022-06-23 08:17:44.806670
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:17:51.041370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor with no arguments
    op = ActionModule()

    # Constructor with no arguments
    assert not op.show_content
    assert isinstance(op.included_files, list)
    assert not op.source_dir
    assert not op.source_file
    assert not op.depth
    assert not op.files_matching
    assert not op.ignore_files
    assert isinstance(op.ignore_files, list)
    assert isinstance(op.valid_extensions, list)
    assert op.hash_behaviour == C.DEFAULT_HASH_BEHAVIOUR
    assert not op.return_results_as_name


# Generated at 2022-06-23 08:18:00.569752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tempfile
    from ansible.parsing.dataloader import DataLoader

    def get_temp_file(content):
        tmp_file, tmp_file_path = tempfile.mkstemp()
        with open(tmp_file_path, 'w+') as f:
            f.write(content)
        return tmp_file_path

    def get_temp_dir(files_dict):
        tmp_dir = tempfile.mkdtemp()
        for filename, content in files_dict.items():
            with open(path.join(tmp_dir, filename), 'w+') as f:
                f.write(content)
        return tmp_dir

    tmp_dir_path = get_temp_dir({'test1.yaml':'a: 2'})
    tmp_file_path = get_temp_

# Generated at 2022-06-23 08:18:12.438296
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    context = {}
    am = ActionModule(task=dict(), connection=None, play_context=context, loader=None, templar=None, shared_loader_obj=None)
    am.show_content = True
    am.VALID_FILE_EXTENSIONS = ['yaml', 'yml']
    am.included_files = []

    am._task.args = {'name': 'bar', 'ignore_files': ['ignore_me.yaml'], 'files_matching': '.*\.yaml$'}
    am._set_root_dir()
    if am._task._role:
        assert am.source_dir == '/tmp/test_ansible_include_vars/test_data/test_include/vars'

    assert am.return_results_as_name == 'bar'