

# Generated at 2022-06-23 08:08:12.875937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(None)
    assert actionModule.run() is None

# Generated at 2022-06-23 08:08:23.052972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import __builtin__
    import json
    import yaml
    __builtin__._ = 'test'
    __builtin__.__salt__ = dict()
    __builtin__.__salt__['helper.yaml'] = yaml
    __builtin__.__salt__['helper.json'] = json
    module = ActionModule(dict(), dict())

    source_dir = "./tests/fixtures/include_vars"
    module.source_dir = source_dir
    module.source_file = None
    module.valid_extensions = ['yml']
    module._set_dir_defaults()
    module._set_root_dir()

    for root_dir, file_names in module._traverse_dir_depth():
        failed, err_msg, results = module._load_files_

# Generated at 2022-06-23 08:08:24.296089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-23 08:08:32.205128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    """
    # Test 1: set_dir_defaults_depth_0
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module.depth = None
    action_module.files_matching = None
    action_module.ignore_files = None
    action_module._set_dir_defaults()
    assert(action_module.depth == 0)

    # Test 2: set_dir_defaults_files_matching
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module.depth = None
    action_module

# Generated at 2022-06-23 08:08:34.154878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    results = dict()
    pass

# Run all unit test

# Generated at 2022-06-23 08:08:41.965554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert a.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert a.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert a.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-23 08:08:43.821916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None)
    assert(isinstance(a, ActionModule))

# Generated at 2022-06-23 08:08:50.343829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule.
    """
    assert ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule.VALID_ALL == ['name', 'hash_behaviour']
    assert ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule.TRANSFERS_FILES == False

# Generated at 2022-06-23 08:08:51.743576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None, 'Test failed'

# unit test for function _set_dir_defaults of class ActionModule

# Generated at 2022-06-23 08:08:52.653007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:09:04.195335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Template for the test input data
    test_data = [
        {},
        {"name": "new_name"},
        {"name": "name", "option": "option_value"},
        {"name": "name", "option": "option_value", "sub-section": {"sub-section-name": "sub-section-name"}}
    ]

    # In this block, the variables defined in `test_data` is verified.
    # The variables are defined with the key 'name', which is an arbitrary value. The value of these variables
    # is also arbitrary.
    for test_item in test_data:
        expected = test_item

        # mock taks variables
        task = {
            'args': {
                'name': test_item.get('name')
            }
        }

        # the vairables, defined with

# Generated at 2022-06-23 08:09:06.228183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-23 08:09:08.295219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=protected-access
    assert isinstance(ActionModule('', '', '', '', '', ''), ActionModule)

# Generated at 2022-06-23 08:09:20.433889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=attribute-defined-outside-init
    class MockTask():
        def __init__(self, args):
            self.args = args
        def get_args(self):
            return self.args
    class MockDS():
        def __init__(self, data_source):
            self._data_source = data_source
    class MockRole():
        def __init__(self, role_path):
            self._role_path = role_path
    correct_task_args = {
        'hash_behaviour': 'replace',
        'name': '_fact_names',
        'dir': 'vars',
        'depth': 3,
        'files_matching': '.*',
        'ignore_files': ['^.*ignore.*'],
        'extensions': 'yml'
    }

# Generated at 2022-06-23 08:09:25.242167
# Unit test for constructor of class ActionModule
def test_ActionModule():
  print("Testing ActionModule constructor")
  action_module = ActionModule(None, None)
  if not isinstance(action_module, ActionModule):
    raise Exception("Unexpected type created by ActionModule constructor: %s" % action_module)
  print("Successfully tested ActionModule constructor")


# Generated at 2022-06-23 08:09:26.309999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:09:28.761998
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return ActionModule(dict(task=dict(args=dict())), dict(vars_files=[]))


# Generated at 2022-06-23 08:09:30.032527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass


# Generated at 2022-06-23 08:09:30.642400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 08:09:38.370944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        pass
    action_module = TestActionModule(
        dict(
            name="test_name",
            hash_behaviour="test_hash_behaviour"
        ),
        dict(
            dir="test_dir",
            depth="test_depth",
            files_matching="test_files_matching",
            ignore_files="test_ignore_files",
            extensions="test_extensions",
            ignore_unknown_extensions="test_ignore_unknown_extensions"
        ),
        dict(
            file="test_file",
            _raw_params="test__raw_params"
        )
    )
    assert action_module.hash_behaviour == "test_hash_behaviour"
    assert action_module.return_results_as_name == "test_name"


# Generated at 2022-06-23 08:09:49.403104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')
    assert hasattr(ActionModule, 'VALID_FILE_EXTENSIONS')
    assert hasattr(ActionModule, 'VALID_DIR_ARGUMENTS')
    assert hasattr(ActionModule, 'VALID_FILE_ARGUMENTS')
    assert hasattr(ActionModule, 'VALID_ALL')
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule

# Generated at 2022-06-23 08:09:58.694400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Testing constructor of ActionModule """
    obj = ActionModule()
    assert obj.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert obj.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert obj.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert obj.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:10:07.668588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    from ansible.plugins.action.include_vars import ActionModule as include_vars

    am = include_vars(None, {}, {}, None, '')
    am._task.args = {
        'depth': 1,
        '_raw_params': 'test_params',
    }
    am._task._role = None

    # seting this var to avoid running the method _set_args
    am.source_file = 'test_params'

    failed, err_msg, results = am._load_files(am.source_file)
    assert failed == False
    assert err_msg == ''
    assert results == {}

    failed, err_msg, updated_results = (am._load_files(am.source_file))
    assert failed == False
    assert err_msg == ''
    assert updated

# Generated at 2022-06-23 08:10:18.953031
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.include_vars import ActionModule
    from ansible.module_utils.common.removed import removed

# Generated at 2022-06-23 08:10:26.110693
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, None, None, None)
    action_module._task.args['dir'] = "test_dir"
    action_module._task.args['depth'] = 0
    action_module._task.args['files_matching'] = "file_matching"
    action_module._task.args['ignore_files'] = "file_ignore"
    action_module._task.args['extensions'] = "yml"
    action_module._task.args['ignore_unknown_extensions'] = False
    action_module._task._role = None
    action_module._task._ds = None
    action_module._task._ds._data_source = "test_ds"
    action_module._loader = None

    action_module._set_args()

# Generated at 2022-06-23 08:10:29.318185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._set_args()
    module._set_dir_defaults()
    module._set_root_dir()

# Generated at 2022-06-23 08:10:36.269431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test for ActionModule.run method.
        Args:
            tmp (str): The temporary directory to use.
            task_vars (dict): The task variables to use.

        Returns:
            Tuple (bool, str, dict)
    """
    # test case 1: var file exists and valid
    # test case 2: var file exists and invalid
    # test case 3: var file does not exists
    # test case 4: multiple var files
    # test case 5: vars directory exists
    # test case 6: vars directory does not exists
    # test case 7: vars directory with extensions

# Generated at 2022-06-23 08:10:42.525364
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_options = dict()
    module_options['_raw_params'] = './../../../test/fixtures/loader/include_vars/test_pass.yml'
    module_options['_uses_shell'] = False
    task_vars = dict()
    task_vars['ansible_os_family'] = 'RedHat'
    module = ActionModule(module_options, task_vars)
    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

# Generated at 2022-06-23 08:10:43.386362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test for method run of class ActionModule
    pass

# Generated at 2022-06-23 08:10:49.624927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_dir = dict(dir='some path', depth=0, extensions=['yml'], ignore_files=['main.yml'])
    args_file = dict(file='some_file.yml')

    actmod = ActionModule(None, dict(role=None,
                                     args=args_dir),
                         None,
                         loader=None,
                         templar=None,
                         shared_loader_obj=None)

    actmod._set_args()
    assert actmod.source_dir == 'some path'
    assert actmod.depth == 0
    assert actmod.valid_extensions == ['yml']
    assert actmod.ignore_files == ['main.yml']


# Generated at 2022-06-23 08:10:50.189796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:10:59.606198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, '').VALID_ALL == ['name', 'hash_behaviour']
    assert ActionModule(None, '').VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert ActionModule(None, '').VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert ActionModule(None, '').VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert ActionModule(None, '').TRANSFERS_FILES == False



# Generated at 2022-06-23 08:11:07.216396
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mock_loader = {
            "_get_file_contents" : None,
            "load" : None
    }

    mock_task = {
            "_role" : None,
            "_ds" : None,
            "args" : None
    }

    mock_task_vars = {
            "test1": "test1"
    }

    action_module = ActionModule(task=mock_task, connection=None, play_context=None, loader=mock_loader, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=mock_task_vars)

    assert result == {'failed': True, 'message': 'Must define a source'}

# Generated at 2022-06-23 08:11:15.287838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    """


# Generated at 2022-06-23 08:11:20.940632
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module

    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']

# Generated at 2022-06-23 08:11:30.617804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_self = dict()
    fake_self['_task'] = dict()
    fake_self['_task']['args'] = dict()
    fake_self['_task']['args']['file'] = 'foobar'
    fake_self['_task']['args']['ignore_files'] = 'foobar'
    fake_self['_task']['args']['files_matching'] = 'foobar'
    fake_self['_task']['args']['dir'] = 'foobar'
    fake_self['_task']['args']['name'] = 'foobar'
    fake_self['_task']['args']['ignore_unknown_extensions'] = 'foobar'

# Generated at 2022-06-23 08:11:31.883327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:11:43.960552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins
    import ansible.plugins.loader
    import ansible.plugins.action

    action_module = ansible.plugins.action.ActionModule(
        task=dict(action=dict(module_name="include_vars", _raw_params="", args=dict()), _ds=dict()),
        connection=dict(),
        play_context=dict(),
        loader=ansible.plugins.loader.ActionModuleLoader(),
        shared_loader_obj=ansible.plugins.loader.ActionModuleLoader(),
        path_lookup=True,
    )

    # result = action_module.run(task_vars=dict())
    # assert result.get("failed") == True
    # assert result.get("message") == "Please specify either a directory or a file"


# Generated at 2022-06-23 08:11:55.298680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    def AnsibleModule(*args, **kwargs):
        pass

    class FakeVarsModule(object):
        def __init__(self):
            self.vars = dict()

    class StubTask:
        def __init__(self):
            self._ds = FakeVarsModule()

    class StubPlayContext(PlayContext):
        def __init__(self):
            self.CLIARGS = dict()
            super(StubPlayContext, self).__init__()


# Generated at 2022-06-23 08:11:55.868893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:12:08.516318
# Unit test for constructor of class ActionModule
def test_ActionModule():
    file_loc = path.join(C.DEFAULT_LOCAL_TMP, 'role_under_test/vars/main.yml')
    test_obj = ActionModule('some_task', dict(file=file_loc))
    assert test_obj.VALID_FILE_ARGUMENTS == ['file', '_raw_params'], \
        "Expected 'file,_raw_params', but got %s" % test_obj.VALID_FILE_ARGUMENTS
    assert test_obj.VALID_ALL == ['name', 'hash_behaviour'], \
        "Expected 'name,hash_behaviour', but got %s" % test_obj.VALID_ALL

# Generated at 2022-06-23 08:12:19.243922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    import sys

    data_source = sys.argv[0]
    task_result_obj = TaskResult(
        host=None,
        task=None,
        task_fields=dict(
            action=dict(name='setup'),
            async_val=None,
            delegate_to=None,
            environment=dict(),
            first_available_file=None,
            local_action=None,
            loop=None,
            loop_args=dict(),
            name=None,
            notified_by=dict(),
            poll=0,
            retries=None,
            run_once=False,
            until=None,
            when=None
        ),
        task_internal_name='',
        _result=dict()
    )

    task_obj

# Generated at 2022-06-23 08:12:21.397592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   action = ActionModule(None)
   action._task = None
   a = 1


# Generated at 2022-06-23 08:12:22.021852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-23 08:12:24.135757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        a = ActionModule(10,20)
        print(a)
    except Exception as e:
        print(e)


# Generated at 2022-06-23 08:12:32.556166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    tmp = None
    task_vars = None
    test_action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Define test input data
    test_dir = None
    test_files_matching = None
    test_name = None
    test_return_results_as_name = None
    test_ignore_files = None
    test_extensions = None
    test_ignore_unknown_extensions = False
    test_hash_behaviour = None
    test_depth = None

    # Define expected output data
    expected_results = None
    expected_err_msg = 'Either dir or file option must be used by include_vars'

    # Create the test input data
   

# Generated at 2022-06-23 08:12:34.864149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, {})
    assert action_module is not None

# Generated at 2022-06-23 08:12:36.322620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Code for unit test
    pass

# Generated at 2022-06-23 08:12:37.391610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    assert result is None

# Generated at 2022-06-23 08:12:44.595996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Tests run method of class ActionModule
    """

    # pylint: disable=protected-access, unused-argument
    tmp_path = 'path/to/tmp'

    action_module = ActionModule()
    action_module.action._shared_loader_obj = None

    # Test with source_dir
    action_module.action.set_args({'dir': 'test_dir'})
    action_module.action._set_dir_defaults = MagicMock(return_value=None)
    action_module.action._set_root_dir = MagicMock(return_value=None)
    action_module.action._traverse_dir_depth = MagicMock(
        return_value=[('root_dir', [])]
    )

# Generated at 2022-06-23 08:12:52.134158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task():
        def __init__(self, args):
            self.args = args

    class DataSource():
        def __init__(self, source):
            self._data_source = source

    class Role():
        def __init__(self, path):
            self._role_path = path

    class Playbook():
        def __init__(self, name):
            self.name = name

    class Play():
        def __init__(self, name, ds):
            self.name = name
            self._ds = ds

    class Task():
        def __init__(self, play, role):
            self._play = play
            self._role = role

    class Loader():
        pass

    class Runner():
        pass

    class Inventory():
        pass

    class Variables():
        pass

   

# Generated at 2022-06-23 08:12:55.985346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor should create instance with instance variable '_task'
    task = dict({'args': dict({'file': 'somefile.yml'})})
    task_loader = dict({'_find_needle': lambda x: x})
    loader = dict({'_get_file_contents': lambda filename: (filename, True)})
    connection = dict({'_connection_plugin_load': lambda x: x})
    play_context = dict({'_play_context': dict()})
    action_module = ActionModule(task,
                                 connection,
                                 task_loader,
                                 play_context,
                                 loader=loader)
    assert action_module._task.args['file'] == 'somefile.yml'

# Generated at 2022-06-23 08:12:59.042413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert True
        print('test_ActionModule passed')
    except Exception as e:
        print('test_ActionModule failed: {0}'.format(e))


# Generated at 2022-06-23 08:13:09.614724
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test - simple run with dir
    task = dict(
        action=dict(
            module='include_vars',
            args=dict(
                dir='/tmp/vars',
            )
        )
    )
    tmp = None
    task_vars = dict()
    result = ActionModule(task, tmp).run(task_vars=task_vars)
    assert result[ 'ansible_included_var_files' ] == ['/tmp/vars/main.yaml']
    assert result['ansible_facts'] == {'a': 1}
    assert not result['failed']

    # Test - simple run with file

# Generated at 2022-06-23 08:13:21.024262
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test valid arguments
    def check_valid(args, expected_return):
        from ansible.parsing.dataloader import DataLoader
        from ansible.playbook.play import Play
        from ansible.playbook.task import Task

        loader = DataLoader()
        play_source =  dict(
                name = "Ansible Play",
                hosts = 'localhost',
                gather_facts = 'no',
                tasks = [
                    dict(action=dict(module='include_vars', args=args), register='shell_out'),
                   ]
                )
        play = Play().load(play_source, loader=loader, variable_manager=VariableManager(), loader=loader)
        tqm = None

# Generated at 2022-06-23 08:13:32.959671
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # load the test data from yml file
    test_data = yaml.load(open('./unit_tests/action_plugin/vars_files/test_data.yml', 'r'))

    for test in test_data['test_cases']:
        # create object for ActionModule
        obj = ActionModule()

        # set the object attributes for testing
        obj.action = test['action']
        obj.task_vars = test['task_vars']
        obj._task = test['_task']
        obj._task.args = test['_task']['args']
        obj._loader = test['_loader']

        # test the method _set_args()
        obj._set_args()

        # check the output is expected

# Generated at 2022-06-23 08:13:33.845199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:13:37.139341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:13:45.982917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from mock import MagicMock
    from ansible.module_utils.six import BytesIO
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    task_src = {
        'action': {
            '__ansible_module__': 'action_module',
            '__ansible_arguments__': {
                '_raw_params': 'test/path/to/file.txt'
            }
        },
        'name': 'test_action_module'
    }

    task_ds = dict()
    task_ds['action'] = 'action_module'
    task_ds['name'] = 'test_action_module'

   

# Generated at 2022-06-23 08:13:50.154408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict()
    task['args'] = {'file': '../../../tests/templates/file_c.j2',
                    'name': 'test'}
    actionmodule = ActionModule(task, dict())
    assert isinstance(actionmodule, ActionModule)


# Generated at 2022-06-23 08:13:50.814461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:13:52.130782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance = ActionModule()
    assert instance is not None

# Generated at 2022-06-23 08:13:55.344797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    self = MagicMock()
    self._task = MagicMock()
    self.run = run

    # Exercise
    self.run(self, tmp=None, task_vars=None)


# Generated at 2022-06-23 08:14:01.902446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = {'var1': '1'}
    action = ActionModule({'name': 'action'}, task_vars=task_vars)
    assert action.run() == {'ansible_facts': {}, 'changed': False, 'failed': False, '_ansible_no_log': False}

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 08:14:12.503392
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Change the following values to match your needs in order to test the
    # following method: ActionModule::run()

    # Filename that contains the expected output
    expected_filename = "./test_data/expected.json"

    # Values to be tested
    # -------------------
    # Arguments of the method run()
    test_run_args = {}

    # Expected function results

# Generated at 2022-06-23 08:14:21.097714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec={
            'dir': {'type': 'str', 'required': False},
            'extensions': {'type': 'str', 'required': False}
        },
        supports_check_mode=True
    )
    module_params = module.params
    setattr(module, '_task', AnsibleTask())
    setattr(module._task, '_role', AnsibleRole())
    setattr(module._task._role, '_role_path', 'some/path')
    setattr(module, '_find_needle', lambda x, y: y)
    setattr(module, '_loader', AnsibleFileLoader(None, None, None))

    am = ActionModule(module, module_params)

# Generated at 2022-06-23 08:14:22.110379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    actionModule.run()

# Generated at 2022-06-23 08:14:32.840311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common._collections_compat import Mapping
    import ansible.module_utils.basic
    import ansible.module_utils.facts
    import ansible.module_utils.hashivault
    import ansible.module_utils.network
    import ansible.module_utils.parsing.convert_bool
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.vmware
    import ansible.module_utils.helpers
    import ansible.module_utils.facts
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.alpine

# Generated at 2022-06-23 08:14:33.758975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:14:34.348615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule)

# Generated at 2022-06-23 08:14:35.670174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module


# Generated at 2022-06-23 08:14:42.320132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    play_source = dict(
        name='test.yml'
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    task_source = dict(
        name='test',
        param1=1,
        param2=2
    )
    task = Task.load(task_source, play=play, variable_manager=variable_manager, loader=loader)
    assert isinstance

# Generated at 2022-06-23 08:14:53.426727
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
    action_module._set_root_dir = lambda : None
    action_module._traverse_dir_depth = lambda: [('/tmp', ['foo.yml'])]
    action_module._set_dir_defaults = lambda : None
    action_module._set_args = lambda : None
    action_module.depth = 1
    action_module.ignore_unknown_extensions = True
    action_module.ignore_files = []
    action_module.matcher = None

    def mocked__load_files(self, filename, validate_extensions):
        return (False, '', {'foo': 'bar'})

# Generated at 2022-06-23 08:14:54.040063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()

# Generated at 2022-06-23 08:15:03.719971
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:15:15.923175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock these vars
    tmp = None
    # mock these vars
    task_vars = dict()
    # mock this class
    class MyClass():
        def __init__(self, tmp, task_vars):
            return
        def run(self, tmp, task_vars=None):
            return dict()
    # mock this class
    class MyClass():
        def __init__(self, dir, depth, files_matching, ignore_files, extensions, ignore_unknown_extensions):
            self.dir = dir
            self.depth = depth
            self.files_matching = files_matching
            self.ignore_files = ignore_files
            self.extensions = extensions
            self.ignore_unknown_extensions = ignore_unknown_extensions
            return


# Generated at 2022-06-23 08:15:23.011668
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext

    import mock
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play

    fake_loader = mock.MagicMock()
    fake_play_context = PlayContext()
    fake_task = mock.MagicMock()
    fake_task._role = None
    fake_task._role_path = None
    fake_task._ds = None
    fake_task.action = 'include_vars'
    fake_task.args = {
        'file': '/etc/ansible/host_vars/localhost'
    }


# Generated at 2022-06-23 08:15:34.191535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY3
    my_vars = {'a': 'b'}

    def mock_run(self, tmp=None, task_vars=None):
        return {'ansible_facts': my_vars, 'ansible_included_var_files': ['file1', 'file2']}

    ActionModule.run = mock_run

# Generated at 2022-06-23 08:15:39.621902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict()
    task['action'] = dict()
    task['action']['__ansible_module__'] = 'include_vars'
    task['action']['__ansible_arguments__'] = '-e "file=test/vars/main.yml"'
    task._role = None
    task._ds = dict()
    task._ds['_data_source'] = None
    task.args = dict()
    action = ActionModule(task, Connection(), '/usr/lib/python2.7/site-packages/ansible', loader=DataLoader())
    action.run(tmp=None, task_vars=None)


# Generated at 2022-06-23 08:15:51.661743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    module._set_dir_defaults()
    assert module.depth == 0
    assert module.matcher == None
    assert module.ignore_files == []
    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module.show_content == True
    assert module.included_files == []
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module.VALID_ALL == ['name', 'hash_behaviour']
    assert module.hash_behaviour == None
    assert module.return_results_as_

# Generated at 2022-06-23 08:16:02.414278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import sys
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-23 08:16:05.858731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import action_loader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    am = action_loader.get('include_vars', loader=loader)
    assert am is not None

# Generated at 2022-06-23 08:16:14.214503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert a.VALID_ALL == ['name', 'hash_behaviour']
    assert a.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert a.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']


# Generated at 2022-06-23 08:16:16.930701
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test action module constructor """
    action_module = ActionModule('some_task', {}, True, None)
    assert action_module


# Generated at 2022-06-23 08:16:17.763639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert_outcome_for_method_run()


# Generated at 2022-06-23 08:16:19.420437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    # TODO: Set up test
    pass

# Generated at 2022-06-23 08:16:25.545680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule({}, {}, {}, {}, {})
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:16:36.828573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    string_io_open_mock = Mock(return_value=MagicMock(read_data='test_content'))
    with patch('ansible.parsing.yaml.safe_load', return_value='parsed_content'), \
        patch('ansible.module_utils.six.moves.builtins.open', string_io_open_mock):
        action_module_obj = ActionModule(task=Mock())
        action_module_obj._set_args = Mock()
        action_module_obj._set_dir_defaults = Mock()
        action_module_obj._set_root_dir = Mock()
        action_module_obj._traverse_dir_depth = Mock(return_value=[('traverse_dir', ['traverse_file'])])
        action_module_obj._load_files_

# Generated at 2022-06-23 08:16:38.620234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    uut = ActionModule()
    assert uut != None


test_ActionModule()

# Generated at 2022-06-23 08:16:46.930562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  import ansible.plugins.action.include_vars
  # Test case1: The source file does not exist
  task_vars = dict()
  source_file = "/tmp/does_not_exist"
  task_run = ansible.plugins.action.include_vars.ActionModule()
  task_run._set_args()
  task_run.source_file = source_file
  result = task_run.run(task_vars=task_vars)
  assert(result['failed'])
  assert(result['message'] == '{0} file does not exist'.format(source_file))

  # Test case2: The source file exists, but is not a dictionary
  import tempfile
  td = tempfile.mkdtemp()
  source_file = path.join(td, "test")

# Generated at 2022-06-23 08:16:48.801478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    instance = ActionModule()

# Generated at 2022-06-23 08:16:58.200428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, "_set_args")
    assert callable(ActionModule._set_args)
    assert hasattr(ActionModule, "run")
    assert callable(ActionModule.run)
    assert hasattr(ActionModule, "_set_root_dir")
    assert callable(ActionModule._set_root_dir)
    assert hasattr(ActionModule, "_ignore_file")
    assert callable(ActionModule._ignore_file)
    assert hasattr(ActionModule, "_is_valid_file_ext")
    assert callable(ActionModule._is_valid_file_ext)
    assert hasattr(ActionModule, "_traverse_dir_depth")
    assert callable(ActionModule._traverse_dir_depth)
    assert hasattr(ActionModule, "_load_files")

# Generated at 2022-06-23 08:17:10.432921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

    # test no _task._ds
    am._task._ds = None
    am._task.args = {
        'hash_behaviour': None,
        'name': None,
        'dir': 'test_dir',
        'depth': None,
        'files_matching': None,
        'ignore_files': None,
        'extensions': None,
        'ignore_unknown_extensions': False,
        'file': None,
        '_raw_params': None
    }
    am._set_args()
    assert am.source_dir == 'test_dir'

    # test _task._ds
    am._task._ds = '/path/to/datasource'
    am._set_args()

# Generated at 2022-06-23 08:17:20.287823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, {
        'name': 'test_name',
        'file': '/test/file',
        'dir': '/test/dir',
        'extensions': 'yaml,yml,json',
        'ignore_unknown_extensions': False,
        'ignore_files': '.*\.py',
        'files_matching': '.*\.yml',
        'depth': 0,
        'hash_behaviour': '',
    })
    module._loader = False
    module._task = True
    assert module.run()['ansible_facts'] == {
        'test_name': {'var1': 'value1', 'var3': 'value3'}
    }
    module._loader = True
    module._task = False
    assert module.run()['ansible_facts'] == {}


# Generated at 2022-06-23 08:17:23.280071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        am = ActionModule()
    except Exception as e:
        print("Exception: " + str(e))
        assert False


# Generated at 2022-06-23 08:17:31.569360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-23 08:17:45.525002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.config.manager import ConfigManager
    # Arrange
    tmp = None
    task_vars = dict()
    # first mock the modules that are imported by the
    # run method of ActionModule
    import ansible.plugins.action.vars as vars
    from ansible.errors import AnsibleError

    # mock the class ActionBase
    action_base = vars.ActionBase
    action_base._loader = False
    action_base._templar = False

    # mock methods in ActionBase
    action_base.run = lambda self, tmp=None, task_vars=None: {"ansible_facts": {}, "_ansible_no_log": False}

    # mock method in ConfigManager
    ConfigManager.__init__ = lambda self: None

# Generated at 2022-06-23 08:17:46.893477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a.run(tmp=None, task_vars=None)
    pass

# Generated at 2022-06-23 08:17:47.450442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:17:58.887506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # set up mock objects
    #
    class ActionBaseMock(object):
        class _task(object):
            class _ds(object):
                _data_source = '/data/source'
            _role = None
            args = {
                'dir': './tests/data/',
                '_raw_params': './tests/data/test_file.yml',
                'extensions': 'yaml',
                'ignore_unknown_extensions': 'yes',
                'ignore_files': ['test_file.yml']
            }
        class _loader(object):
            class _basedir(object):
                pass

            @staticmethod
            def _get_file_contents(filename):
                return """---
my_test_var:
  key: value
""", False


# Generated at 2022-06-23 08:18:10.306505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    Path = 'ansible.plugins.action.vars_prompt'
    from sys import modules
    from ansible.plugins.action.vars_prompt import ActionModule
    from ansible.plugins.action.vars_prompt import ActionModule as vars_prompt
    import ansible.plugins.action.vars_prompt

    assert hasattr(ansible.plugins.action.vars_prompt, 'ActionModule')
    assert 'ansible.plugins.action.vars_prompt' == Path
    assert modules[Path] == ansible.plugins.action.vars_prompt
    assert ActionModule == vars_prompt.ActionModule


# Generated at 2022-06-23 08:18:21.797508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing and creating objects
    class FakeActionModule:
        def __init__(self):
            self._task = AnObject()
            self._loader = FakeLoader()
            self._ds = "fake/data/source"
            self._connection = "fake_connection"
        def run(self, task_vars=None):
            return super(ActionModule, self).run(task_vars=task_vars)

    class FakeLoader:
        def __init__(self):
            pass
        def _get_file_contents(self, filename):
            data = "name: my_name\n"
            return data.encode('utf-8'), False
        def load(self, data, file_name=None, show_content=False):
            return {'my_name': 'my_name'}
