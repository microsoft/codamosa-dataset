

# Generated at 2022-06-23 08:08:14.451954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert a.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert a.TRANSFERS_FILES == False


# Generated at 2022-06-23 08:08:20.452389
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def test_set_dir_defaults():
        pass

    def test_set_args():
        pass

    def test_traverse_dir_depth():
        pass

    def test_ignore_file():
        pass

    def test_is_valid_file_ext():
        pass

    def test_load_files():
        pass

    def test_load_files_in_dir():
        pass

# Generated at 2022-06-23 08:08:22.570109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert(action_module)
    

# Generated at 2022-06-23 08:08:26.914594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am.VALID_FILE_EXTENSIONS, list)
    assert isinstance(am.VALID_DIR_ARGUMENTS, list)
    assert isinstance(am.VALID_FILE_ARGUMENTS, list)
    assert isinstance(am.VALID_ALL, list)


# Test for _set_dir_defaults

# Generated at 2022-06-23 08:08:36.463298
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.template import Templar
    from ansible.vars import VariableManager
    fake_loader = None
    variable_manager = VariableManager()
    variable_manager._extra_vars = {}

    fake_task = Task.load(dict(action=dict(module='include_vars', args=dict(file='{{ item }}')), loop='{{ my_vars }}', name='include_vars test'), variable_manager=variable_manager, loader=fake_loader)
    fake_task._role = RoleDefinition.load(dict(name='test_role', file='test.yml'), variable_manager=variable_manager, loader=fake_loader)



# Generated at 2022-06-23 08:08:38.476022
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule(None, None, None, None) != None)


# Generated at 2022-06-23 08:08:45.586970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import io
    import sys
    import unittest
    import unittest.mock as mock

    class TestActionModule(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.return_results_as_name = "data"
            cls.source_file = "/home/local/data.yml"
            cls.task_vars = dict()
            cls.tmp = None
            cls.depth = 0
            cls.files_matching = None
            cls.ignore_files = list()
            cls.ignore_unknown_extensions = list()
            cls.valid_extensions = ['yml', 'yaml', 'json']
            cls.hash_behaviour = None
            cls.show_content = False

# Generated at 2022-06-23 08:08:52.927130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys, os
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action.include_vars import ActionModule
    from ansible import constants as C
    from ansible.module_utils import six

    # load the action plugin
    action = ActionModule(dict(ANSIBLE_MODULE_ARGS={}), basic.AnsibleModule(
        argument_spec=dict(),
    ))

    # set internal vars from args
    action._set_args()

    # load all files in the current directory
    # expected: the output of this command is a directory of files
    # those files are yml or json files

# Generated at 2022-06-23 08:08:56.583155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('task', 'loader', 'templar', 'shared_loader_obj')._task.action == 'include_vars'


# Generated at 2022-06-23 08:08:58.672811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule


# Generated at 2022-06-23 08:08:59.388846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:09:09.189523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook import Playbook
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    from test_loader import LoaderModule

    from ansible.module_utils.six import PY3

    # Can't use a constant here, due to import order issues.
    if PY3:
        source = b"""
---
- name: Include file with contents
  hosts: localhost
  tasks:
    - name: include file
      include_vars:
        file: '{0}'
""".format(path.join('test_include_vars', 'test_file.yml'))

# Generated at 2022-06-23 08:09:12.965519
# Unit test for constructor of class ActionModule
def test_ActionModule():  # lgtm [py/unused-function]
    setattr(ActionModule, "__doc__", "") # @NoSelf
    ActionModule.__module__.ModuleUtils.basic.AnsibleModule

# Generated at 2022-06-23 08:09:18.559366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Here is a sample of how to test method run in class ActionModule.
    # Assertions such as assert x == y and assert x is True or assert x is False
    # may be needed in your test method.
    # You can also use the pytest's raises if needed.
    # Example: raises(AnsibleError, some_function_to_test, arg1, arg2)
    pass

# Generated at 2022-06-23 08:09:26.126921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    import os
    import json

    playbook = PlaybookExecutor(
        playbooks=[],
        inventory=InventoryManager(loader=DataLoader(), sources='localhost,'),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        passwords={},
    )

    task = Task()
    task._role = IncludeRole()

    action = Action

# Generated at 2022-06-23 08:09:29.632351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' test the run method of class ActionModule'''
    print('[test_ActionModule_run] Test started')
    print('[test_ActionModule_run] Test reached')
    pass



# Generated at 2022-06-23 08:09:37.461723
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.plugins import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import os

    # Load test data for this unit test
    cwd = os.path.realpath(os.path.curdir)
    test_data_path = os.path.join(cwd, "test_data")
    test_hosts = os.path.join(test_data_path, "test_hosts")
    test_vars = os.path.join(test_data_path, "test_vars")
    test_playbook = os.path.join(test_data_path, "test_playbook")

    # Create the inventory and get the "test_host" host
    inventory = InventoryManager

# Generated at 2022-06-23 08:09:46.055138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.dict_transformations import dict_merge

    module_args = dict(
        depth=1,
        file='./templates/included_vars.yml',
        name='foo_bar'
    )

    mod = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    task_args = dict(
        action=dict(
            module_args=module_args,
        )
    )
    tm = ActionModule(task=task_args, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    tm._set_args()


# Generated at 2022-06-23 08:09:58.913740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 
                                          'ignore_files', 'extensions',
                                          'ignore_unknown_extensions']
    assert module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert module.VALID_ALL == ['name', 'hash_behaviour']
    assert ActionModule.TRANSFERS_FILES == False



# Generated at 2022-06-23 08:10:07.874185
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.errors import AnsibleError
    from ansible.parsing.vault import VaultLib

    def _get_loader_mock():
        # Create a mock loader
        loader = mock.Mock()
        loader.show_content = False
        loader.load.return_value = {
            'test': 'passed'
        }

        return loader

    def _get_action_mod():
        # Create a VaultLib mock
        vault_lib = mock.Mock(spec=VaultLib)

        # Create an action module

# Generated at 2022-06-23 08:10:09.820542
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:10:20.288784
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    results = dict()
    block = Block()
    task = Task()
    task._role = "test_role"
    task._ds = "test_ds"
    task_vars = dict()
    loader = DataLoader()
    play_context = PlayContext()
    actionModule = ActionModule(task, play_context, loader, templar=None, shared_loader_obj=None)
    results = actionModule.run(task_vars=task_vars)

    assert results['_ansible_no_log'] == True
    assert results['ansible_facts'] == {}

# Generated at 2022-06-23 08:10:31.686449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if verbose:
        print('ActionModule test:')

    am = ActionModule(loader=None, task=None, connection=None)

    if verbose:
        print('ActionModule -->', am)

    assert(am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'])
    assert(am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'])
    assert(am.VALID_FILE_ARGUMENTS == ['file', '_raw_params'])
    assert(am.VALID_ALL == ['name', 'hash_behaviour'])


# Generated at 2022-06-23 08:10:42.921941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test 1: empty constructor, this should return an instance of the class
    am = ActionModule()
    assert isinstance(am, ActionModule)

    # Test 2: Constructor that has a task
    # Also test for _task property exists
    am = ActionModule(task=dict())
    assert isinstance(am, ActionModule)
    assert hasattr(am, '_task')
    assert am._task is not None

    # Test 3: Constructor that has a task, connection
    # Also test for connection property exists
    am = ActionModule(task=dict(), connection=dict())
    assert isinstance(am, ActionModule)
    assert hasattr(am, '_connection')
    assert am._connection is not None

    # Test 4: Constructor that has a task, connection, play context
    # Also test for play_context property exists
   

# Generated at 2022-06-23 08:10:43.494847
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return None

# Generated at 2022-06-23 08:10:54.878264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.path import makedirs_safe

    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars

    from six import StringIO

    from io import open

    import shutil
    import tempfile
    import os

    # Cleanup
    current_dir = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-23 08:10:57.129168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionBase)
    assert isinstance(action.VALID_FILE_EXTENSIONS, list)
    assert isinstance(action.VALID_DIR_ARGUMENTS, list)
    assert isinstance(action.VALID_FILE_ARGUMENTS, list)
    assert isinstance(action.VALID_ALL, list)

# Generated at 2022-06-23 08:11:06.089015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test class attributes
    VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
    VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    VALID_FILE_ARGUMENTS = ['file', '_raw_params']
    VALID_ALL = ['name', 'hash_behaviour']

    # Test instance attributes
    hash_behaviour = 'replace'
    return_results_as_name = 'test_name'
    source_dir = '/tmp/ansible/test_dir'
    depth = 0
    files_matching = None
    ignore_unknown_extensions = False
    ignore_files = None
    valid_extensions = VALID_FILE_EXTENSIONS
   

# Generated at 2022-06-23 08:11:11.400625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        def test_action(self, tmp=None, task_vars=None):
            return dict()

        am = ActionModule()
        am.run = test_action
        assert am is not None
        assert am.run({}, {}) == dict()
    except Exception:
        assert False, "ActionModule creation is failed."

# Generated at 2022-06-23 08:11:22.118549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    from ansible.module_utils._text import to_bytes

    # Test for success when depth=0
    source_dir = to_bytes('./test/unit/plugins/modules/include_vars/depth_zero')
    depth = 0
    files_matching = 'main.yml'
    args = {
        'depth': depth, 'files_matching': files_matching,
        'extensions': ['yaml'], 'dir': source_dir
    }
    tmp = None
    task_vars = dict()
    am = ActionModule(task=MockTask(args), connection=None, play_context=MockPlayContext(), loader=MockLoader(), templar=MockTemplar(), shared_loader_obj=MockLoader())
    res = am.run

# Generated at 2022-06-23 08:11:22.756360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:11:24.174048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()
    assert actionmodule != None


# Generated at 2022-06-23 08:11:32.976297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import gather_facts
    from ansible.vars.hostvars import HostVars

    # Create a dict for the combine_vars method
    inventory = HostVars({
        "all": {
            "vars": {
                "my_var": "my_value"
            }
        }
    })

    inventory.set_variable(
        host="all",
        varname="my_var",
        value="my_value2",
    )

    # Create a dict for use in the combine_vars method
    host1_data = {
        "my_var": "my_value3",
        "my_var2": "my_value4"
    }

    # Create the class instance
    action = ActionModule()

    # Set variables for the _copy_module_

# Generated at 2022-06-23 08:11:44.401509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define class variable

    # Define instance variable
    task_vars = {
            'ansible_env': {
                'HOME': '/home/ansible'
            }
    }
    variable_manager = {'somekey':'somevalue'}

    # Define instance
    action_module = ActionModule(task=task_vars, variable_manager=variable_manager, loader=None)
    action_module._add_action_plugin_warnings = lambda _: None
    action_module._set_action_plugin_warnings = lambda _: None
    def _fake_get_file_contents(filename):
        return '{ "key": "value" }', True
    action_module._loader.get_file_contents = _fake_get_file_contents
    action_module._loader.is_file

# Generated at 2022-06-23 08:11:47.836653
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run('ignore_files', 'files_matching', 'depth', 'extensions', 'ignore_unknown_extensions', 'hash_behaviour', 'name')

# Generated at 2022-06-23 08:11:59.182546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_dict = {
        'dir': 'get_template',
        'name': 'var_results',
        'depth': 3
    }


# Generated at 2022-06-23 08:12:04.907541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class AnsibleTask(object):
        def __init__(self):
            self.args = ''
            self.task_vars = {}

    class AnsibleHost(object):
        def __init__(self):
            self.name = ''

    class AnsibleVars(object):
        def __init__(self):
            self.vars = {}

    task = AnsibleTask()
    host = AnsibleHost()
    vars = AnsibleVars()

    action = ActionModule(task, host, vars)

    assert(action is not None)


# Generated at 2022-06-23 08:12:14.771793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars

    class TestCallbackModule(CallbackBase):
        def __init__(self):
            self.task_result_map = {}


# Generated at 2022-06-23 08:12:17.978876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Valid experiment AM is constructed and returned.
    am = ActionModule()
    assert (isinstance(am, ActionModule))

# Generated at 2022-06-23 08:12:20.916207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of ActionModule class
    :return: none
    """
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-23 08:12:21.966619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ### TODO: write unit test
    return True

# Generated at 2022-06-23 08:12:30.339675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    import yaml
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.loader import AnsibleLoader

    # test class setup and parameter parsing
    test_args = {'dir': 'testdir', 'depth': 2, 'name': 'testdict', 'ignore_unknown_extensions': True}
    test = ActionModule(None, test_args, None)
    assert test.depth == 2
    assert test.return_results_as_name == 'testdict'
    assert test.ignore_unknown_extensions == True

    # test _set_dir_defaults without ignore_files
    test._task.args['ignore_files'] = None
    test._set_dir_defaults()
    assert test.ignore_files == []

    # test _set_dir_default

# Generated at 2022-06-23 08:12:41.184587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule.'''

    # Arrange
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    from ansible.errors import AnsibleParserError

    class DataSource:
        def __init__(self, data_source):
            self._data_source = data_source

    class Task:
        def __init__(self, args):
            self.args = args

    class Role:
        def __init__(self, role_path):
            self._role_path = role_path


# Generated at 2022-06-23 08:12:50.206666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext

    # Create a task which calls action module 'test_include_vars'
    class ModuleTestTask(object):
        def __init__(self):
            self.action = 'test_include_vars'

            self.args = dict(
                dir='tests/results/file_results/',
                files_matching='nested_vars[1-9].yml',
                ignore_files='ignore_me.yml',
                depth=1,
                name='my_test_facts',
                hash_behaviour='merge'
            )

            # The data source object used to get data
            self._ds = dict()

            # The role object
            self._role = dict()

            # Return custom loader
            self.get_loader = lambda: ModuleTestLoader

# Generated at 2022-06-23 08:13:01.010517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dirs = 0
    files = 0
    # Check error message when both dir and file options provided
    try:
        ActionModule.run(
            ActionModule(),
            args=dict(
                dir='ansible/test/vars',
                file='test.yml'
            )
        )
        assert False
    except AnsibleError as e:
        assert e.message == 'You are mixing file only and dir only arguments, these are incompatible'

    # Check error message when invalid option provided
    try:
        ActionModule.run(
            ActionModule(),
            args=dict(
                dir='ansible/test/vars',
                testing='test.yml'
            )
        )
        assert False
    except AnsibleError as e:
        assert e.message == 'testing is not a valid option in include_vars'

# Generated at 2022-06-23 08:13:02.398470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:13:03.670053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-23 08:13:05.189953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """
    pass

# Generated at 2022-06-23 08:13:13.104507
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    plugin = ActionModule(None, None, None)

    assert plugin._loader is not None
    assert plugin._templar is not None
    assert plugin._task is not None
    assert plugin._connection is not None
    assert plugin._play_context is not None

# Generated at 2022-06-23 08:13:14.059124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #TODO: write this
    return

# Generated at 2022-06-23 08:13:14.837932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 08:13:21.923278
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert issubclass(ActionModule, ActionBase)

    # Test for correct initialization
    am = ActionModule(dict(
        task=dict(args=dict(file='/path/to/file', name='test_name')),
    ))
    assert am._task.args['file'] == '/path/to/file'
    assert am._task.args['name'] == 'test_name'
    assert am.return_results_as_name == 'test_name'
    assert am.source_file == '/path/to/file'
    assert am.source_dir is None
    assert am.depth is None
    assert am.files_matching is None
    assert am.ignore_unknown_extensions is False
    assert am.ignore_files is None

# Generated at 2022-06-23 08:13:33.844972
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar

    my_play_context = PlayContext()
    my_play_context._play = None
    my_play_context._play_context = my_play_context
    my_play_context.vars = dict()
    my_play_context.prompt = dict()
    my_play_context.prompt.on_prompt = ()
    my_play_context.prompt.on_pre_validate = ()
    my_play_context.prompt.on_post_validate = ()

# Generated at 2022-06-23 08:13:34.423025
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:13:36.182039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-23 08:13:41.924077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """

    """
    # Initialize the action module run
    actual_result = ActionModule.run(task)

    # Create expected result for action module run
    expected_result = {'ansible_facts': {}, 'ansible_included_var_files': [], 'failed': False, 'message': ''}

    # Verify the results
    assert_equals(actual_result, expected_result)


# Generated at 2022-06-23 08:13:42.568446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:13:45.723836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:13:55.975940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for ActionModule.run. Checks for a return of a valid dict """

    test_dir = path.dirname(path.dirname(path.dirname(path.abspath(__file__))))
    test_file = 'var_tasks.yml'
    data_source = path.join(test_dir, 'lib', 'ansible', 'plugins', 'action', test_file)
    args = dict( dir = 'vars', depth = 0)
    test_action_module = ActionModule(load_name='test', load_args=args, runner_queue=None, task_uuid="uuid", task_vars=dict(), loader=None, templar=None, shared_loader_obj=None)
    result = test_action_module.run(task_vars=None)

# Generated at 2022-06-23 08:14:01.990143
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_args = {'dir': 'test_dir',
                 'depth': 2,
                 'files_matching': 'test_file',
                 'ignore_files': 'test_file',
                 'extensions': ['yaml'],
                 'ignore_unknown_extensions': False
                 }
    assert type(ActionModule(None, None, test_args)) is ActionModule


# Generated at 2022-06-23 08:14:05.859510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create Fake task object and Fake task datastore
    task = DummyTask()
    action_module = ActionModule(task, dict())

    # test whether instance variables are set correctly
    assert action_module._task is task


# Generated at 2022-06-23 08:14:10.085074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(dict())
    module._task = dict()
    module._task['args'] = dict()
    module._task.args['name'] = 'result'
    module._task.args['dir'] = './test/load_fixtures/'
    module.run()

# Generated at 2022-06-23 08:14:10.696988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:14:12.029201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:14:20.888972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup mock class ActionModule(ActionBase) to test the method run
    '''
    Mock class ActionModule(ActionBase) to test the method run.
    '''

    class ActionModule(ActionBase):

        def run(self, tmp=None, task_vars=None):
            return (super(ActionModule, self).run(task_vars=task_vars))

    # Setup the mock task object
    '''
    Mock the task object.
    '''

    mock_task = Mock()

    # Create the mock method run of the mock class ActionBase
    '''
    Create the mock method run for the mock class ActionBase.
    '''

    def mock_method_run(*args, **kwargs):
        return dict()

    '''
    Mock the method run of the mock class ActionBase.
    '''



# Generated at 2022-06-23 08:14:32.089487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def SubOptions(settings):
        return type('SubOptions', (object,), settings)

    SubActionBase = type('SubActionBase', (ActionBase,), {
        'run': lambda self, tmp=None, task_vars=None: dict(failed=False, _ansible_no_log=False)
    })
    SubActionModule = type('SubActionModule', (ActionModule,), {
        'run': lambda self, tmp=None, task_vars=None: dict(failed=False, _ansible_no_log=False)
    })

    # Test with no arguments
    action_module = SubActionModule(SubActionBase(SubOptions({}), None, None, None), None, {})
    action_module.run()

    # Test with invalid option

# Generated at 2022-06-23 08:14:36.418437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """  Unit test for constructor of class ActionModule """
    obj = ActionModule(
        task=None, connection=None, play_context=None, loader=None,
        templar=None, shared_loader_obj=None
    )
    obj._task = MagicMock()
    obj._task.args = dict()

    return obj

# Generated at 2022-06-23 08:14:39.176438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule('task').__class__.__name__ == "ActionModule")

# Generated at 2022-06-23 08:14:40.314804
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None

# Generated at 2022-06-23 08:14:44.111580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Unit test for constructor of class ActionModule
    '''
    task = {}
    args = {}
    load_options = {}
    x = ActionModule(task, args, load_options)
    assert x


# Generated at 2022-06-23 08:14:54.984250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import merge_hash
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.playbook.play
    import ansible.playbook.task_include
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.executor.task_queue_manager
    import ansible.executor.playbook_executor

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)

    fake_play = ansible.playbook.play.Play()
    fake_sub_play = ansible.playbook.play.Play()

# Generated at 2022-06-23 08:15:04.546682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.include_vars import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable

# Generated at 2022-06-23 08:15:13.565265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(load=True, task=True)
    assert actionModule.VALID_ALL == ['name', 'hash_behaviour']
    assert actionModule.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert actionModule.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert actionModule.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']


# Generated at 2022-06-23 08:15:20.515711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import module_utils
    from ansible.module_utils import basic
    module_args = dict()

    module = basic['AnsibleModule']
    task = {'args': module_args, 'action': 'include_vars'}
    task_ds = {'args': module_args}
    module_utils['AnsibleModule'] = module
    module_utils['_ds'] = task_ds
    ansible_task = {'name': 'include_vars', 'args': module_args}

    action_mod = ActionModule(ansible_task, module_utils, task)
    return action_mod

# Generated at 2022-06-23 08:15:27.481108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test default case
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module.show_content = True
    action_module.included_files = []
    action_module.hash_behaviour = None
    action_module.return_results_as_name = None

    # Test exception cases
    try:
        action_module._set_dir_defaults()
    except AnsibleError as err:
        actual_error = err
    displayed_error = "Abc is not a valid option in include_vars"
    assert(str(actual_error) == displayed_error)


# Generated at 2022-06-23 08:15:29.869289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a new ActionModule object
    amodule = ActionModule()
    assert isinstance(amodule, ActionModule)

# Generated at 2022-06-23 08:15:31.180712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()



# Generated at 2022-06-23 08:15:38.897132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config = {'name': 'test_name'}
    task = {'vars': {}, 'role': {'_role_path': None},
            '_ds': '_data_source', '_role': None, '_loader': '_mock_loader',
            'args': config}
    loader = '_mock_loader'
    play_context = '_play_context'
    shared_loader_obj = None
    variable_manager = '_variable_manager'
    ansible_included_var_files = ''
    ansible_facts = ''
    ansible_no_log = ''

# Generated at 2022-06-23 08:15:40.724238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert(a.VALID_ALL == ['name', 'hash_behaviour'])

# Generated at 2022-06-23 08:15:44.776399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''
    assert not ActionModule.VALID_FILE_ARGUMENTS is None
    assert not ActionModule.VALID_DIR_ARGUMENTS is None
    assert not ActionModule.TRANSFERS_FILES is None

# Generated at 2022-06-23 08:15:47.493338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up test fixture

    # act
    action = ActionModule()

    # assert
    assert action.run()

# Generated at 2022-06-23 08:15:57.405408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=no-self-use
    def play_context(self):
        pass
    # pylint: disable=no-member
    task_ds = ActionModule.TaskDS(dict_args=dict())
    # pylint: disable=attribute-defined-outside-init
    ActionModule.TaskDS.ds = play_context
    # pylint: disable=attribute-defined-outside-init
    ActionModule.TaskDS.ds._data_source = 'fake_data_source_file'

    task_vars = dict()
    current_path = './'
    current_file = path.join(current_path, 'test_ActionModule_run.py')

    args_dir = {'dir': 'test', 'name': 'test_dir', 'depth': 0}

# Generated at 2022-06-23 08:15:58.762101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:16:04.186661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS != None
    assert action_module.VALID_DIR_ARGUMENTS != None
    assert action_module.VALID_FILE_ARGUMENTS != None
    assert action_module.VALID_ALL != None


# Generated at 2022-06-23 08:16:16.563424
# Unit test for constructor of class ActionModule
def test_ActionModule():
    state_name = 'include_vars'
    state_file = '/home/user/Library/group_vars/all'
    state_dir = '/home/user/Library/group_vars/all'
    state_depth = '10'
    state_files_matching = '.yml'
    state_ignore_files = 'test.yml'
    state_extensions = ['yml', 'json']
    state_ignore_unknown_extensions = False
    state_name_check = 'test_name'
    state_hash_behaviour = 'merge'
    task = dict()
    task['name'] = state_name
    task['args'] = dict()
    task['args']['file'] = state_file
    task['args']['dir'] = state_dir

# Generated at 2022-06-23 08:16:17.250698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:16:26.061552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing constructor of ActionModule')
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)
    assert action_module.TRANSFERS_FILES == False
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-23 08:16:35.800951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class _ActionModule(ActionModule):
        def _set_args(self):
            self._task.args['name'] = 'test_name'
            self._task.args['dir'] = 'test_dir'
            self._task.args['file'] = 'test_file'
            self._task.args['_raw_params'] = 'test_raw_params'

        def _set_dir_defaults(self):
            pass

        def _find_needle(self, dirname, needle):
            pass

        def _loader_get_file_contents(self, filename):
            pass

    _action_module = _ActionModule()
    _action_module.run()

# Generated at 2022-06-23 08:16:45.147913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    test_task = Task()
    test_task._role = Role()
    test_task._role._role_path = '/data/ansible/roles/test_role'

    block = Block()
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    block._play_context = play_context

    host = Host()

# Generated at 2022-06-23 08:16:53.296335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    res = {
        '_ansible_no_log': True,
        '_ansible_parsed': True,
        'changed': False,
        'invocation': {
            'module_args': {
                'dir': 'test/test_dir/*',
                'files_matching': 'show'
            }
        },
        'ansible_facts': {},
        'ansible_included_var_files': []
    }
    assert res == ActionModule().run()

# Generated at 2022-06-23 08:17:05.167746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake task to be passed to the action class
    task = FakeTask()
    # Fake AnsibleModule class
    module = FakeModule()
    task._ds = module
    # Create the action class and call main execution
    action = ActionModule(task, module._connection, '/path/to/file', module._play_context, task._loader, module._templar, module._shared_loader_obj)
    result = action.run(task_vars=dict())
    assert result['ansible_facts']['vars_file4'] == 'bar'
    assert result['ansible_facts']['vars_file5'] == 'bar2'
    assert result['ansible_facts']['vars_file7'] == 'baz'

# Generated at 2022-06-23 08:17:11.991276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == (['yaml', 'yml', 'json'])
    assert isinstance(action_module.VALID_DIR_ARGUMENTS, list)
    assert isinstance(action_module.VALID_FILE_ARGUMENTS, list)
    assert isinstance(action_module.VALID_ALL, list)


# Generated at 2022-06-23 08:17:13.190637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module

# Generated at 2022-06-23 08:17:13.847031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return NotImplemented

# Generated at 2022-06-23 08:17:15.285589
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:17:23.311264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup
    def mock_run(self, tmp, task_vars):
        return {
            "failed": False,
            "ansible_included_var_files": [],
            "ansible_facts": {
                "include_vars": {
                    "name": "test_var",
                    "var_file": "test_var_file"
                }
            },
            "_ansible_no_log": False
        }

    # teardown
    def mock_walk(self, source_dir):
        return [
            (
                "/home/user1/Projects/ansible/playbooks/roles/test/vars/",
                [],
                ["main.yml"]
            )
        ]


# Generated at 2022-06-23 08:17:25.520108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:17:38.490101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Testing ActionModule run method
    """
    import unittest
    import yaml
    import os
    import shutil
    import tempfile
    import ansible.playbook
    import ansible.constants as C
    import ansible.utils.template as template
    #import ansible.plugins.action.include_vars as include_vars

    class FakeLoader:
        def load(self, data, file_name=None, show_content=False):
            """
            This method parses the data passed to it and returns
            """
            try:
                return yaml.safe_load(data)

            except Exception as err:
                raise AnsibleError('{0} failed to parse: {1}'.format(file_name, to_native(err)))


# Generated at 2022-06-23 08:17:45.412901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.include_vars
    assert issubclass(ansible.plugins.action.include_vars.ActionModule, ActionBase)
    action_instance = ansible.plugins.action.include_vars.ActionModule(dict(), dict(), False, dict())
    assert isinstance(action_instance, ansible.plugins.action.include_vars.ActionModule)

# Generated at 2022-06-23 08:17:52.867726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display

    class MockTask(Task):
        def __init__(self, vars):
            self.vars = vars
            self._ds = MockDataSource()

    class MockRole(Role):
        def __init__(self, path):
            self._role_path = path


# Generated at 2022-06-23 08:18:04.565970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    actionModule.VALID_FILE_EXTENSIONS = ['yml']
    actionModule.VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    actionModule.VALID_FILE_ARGUMENTS = ['file']
    actionModule.VALID_ALL = ['name', 'hash_behaviour']
    actionModule.source_file = 'test.yml'
    actionModule.source_dir = 'data'
    actionModule.depth = 0
    actionModule.files_matching = None
    actionModule.ignore_unknown_extensions = False
    actionModule.ignore_files = None
    actionModule.valid_extensions = ['yaml', 'yml', 'json']
    action

# Generated at 2022-06-23 08:18:05.013098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()

# Generated at 2022-06-23 08:18:13.944728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    templar = Templar(loader=loader, variables=variable_manager)

    # Create task
    params = {}
    params.update({'dir': '~/ansible/roles/common/vars/main.yml'})
    params.update({'name': 'config'})

    task = {
        'args': params,
        '_raw_params': params['dir']
    }
