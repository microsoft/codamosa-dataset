

# Generated at 2022-06-23 08:08:23.053155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for run method of class ActionModule
    """
    import sys, os
    import pytest
    sys.path.append(os.path.dirname(__file__))
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    import lib.module_utils.connection
    import lib.module_utils.network
    sys.modules['ansible.module_utils.basic'] = __import__('lib.module_utils.basic')
    sys.modules['ansible.module_utils.connection'] = __import__('lib.module_utils.connection')
    sys.modules['ansible.module_utils.network'] = __import__('lib.module_utils.network')


# Generated at 2022-06-23 08:08:33.388954
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #Should pass
    task_args = {'name': 'test_run_ok', 'file': './vars/vars_include.yml'}
    task_vars = {
        'hostvars': {
        }
    }
    from ansible.module_utils.facts import ansible_module
    import ansible.module_utils.facts
    from ansible.module_utils.facts import ansible_module
    from ansible.module_utils.facts import ansible_module
    ansible.module_utils.facts = MockFactsAnsible()
    facts_mock = mock.Mock()
    facts_mock.run.return_value = {'ansible_facts': {'test_run1': 'test_run1'}, 'failed': False, 'changed': False}
    facts_mock

# Generated at 2022-06-23 08:08:44.543631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake action module with all necessary parameters
    module = ActionModule('fake_task', 'fake_connection', 'fake_play_context', 'fake_loader', 'fake_templar', 'fake_shared_loader_obj')
    # Create a fake module_utils with all necessary attributes
    module._task = type('fake_task', (), {'args': {'return_results_as_name': None, 'hash_behaviour': None}})
    # Create a fake loader with all necessary attributes
    module._loader = type('fake_loader', (), {'_get_file_contents': lambda self, a: (b'fake_data', True)})
    # Create a fake task_vars with all necessary attributes

# Generated at 2022-06-23 08:08:52.208063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_list = ['test_key=test_value']
    params = ' '.join(arg_list)
    task_name = 'include_vars'
    task_ds = 'hdsdsjk'
    task_vars = {'test_key': 'test_value'}
    task_loader = 'loader'
    task_variable_manager = 'vman'

    common_kwargs = {
        'action': task_name,
        '_ansible_check_mode': False,
        '_ansible_debug': False,
        '_ansible_diff': False,
        '_ansible_no_log': False,
        '_ansible_verbosity': 0,
        '_raw_params': params,
    }
    kwargs = {'task_vars': task_vars}

# Generated at 2022-06-23 08:09:04.137981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit tests for method run of class ActionModule
    """
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import binary_type
    from ansible.plugins.action.vars import ActionModule

    action_module = ActionModule(Mapping(), ImmutableDict(), task_vars={})
    source_dir = action_module._task.args.get('dir')

    path_exists = 'path/to/path'
    path_not_exists = 'path/not/exists'

    def is_dir(path):
        return path == path_exists


# Generated at 2022-06-23 08:09:13.153389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    t = TaskInclude()
    variable_manager._fact_cache = dict()
    t.action = 'include_vars'
    t.args = dict()
    t.args['dir'] = '/etc/ansible/ansible/modules'
    t._role = None
    t._task = t
    am = ActionModule(loader=loader, task=t, connection=None, play_context=None, shared_loader_obj=None, variable_manager=variable_manager)

# Generated at 2022-06-23 08:09:23.879761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  tmp = None
  task_vars = {
    'test_var': 'test'
  }

  source_dir = '/src/tests/'
  source_file = '/src/tests/test'
  hash_behaviour = None
  return_results_as_name = 'test'

  # Mock object
  class MockActionModule(ActionModule):
    def __init__(self):
      pass
      # self.source_dir = source_dir
      # self.source_file = source_file
      # self.hash_behaviour = hash_behaviour
      # self.return_results_as_name = return_results_as_name
      # self._set_dir_defaults()
      # self._set_args()

    # Mocks
    def show_content():
      pass


# Generated at 2022-06-23 08:09:24.784610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-23 08:09:25.352565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:09:28.223787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

if __name__ == '__main__':
  import sys
  sys.exit(test_ActionModule_run())

# Generated at 2022-06-23 08:09:36.944686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task:
        def __init__(self,_args):
            self._args = _args

    class DataSource:
        def __init__(self, _data_source):
            self._data_source = _data_source

    class Role:
        def __init__(self, _role_path):
            self._role_path = _role_path

    class TaskDS:
        def __init__(self, _ds):
            self._ds = _ds

    class TaskRole:
        def __init__(self, _role):
            self._role = _role


# Generated at 2022-06-23 08:09:39.096024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:09:44.442063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        connection=None,
        _make_tmp=None,
        _task=None,
        _connection=None,
        _play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert True


# Generated at 2022-06-23 08:09:45.123619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule != None

# Generated at 2022-06-23 08:09:45.728721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:10:01.039149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    play_context = PlayContext()
    task = Task()
    task.__init__(play_context=play_context, action='include_vars')
    play_context.__init__()
    action_module = ActionModule()
    action_module.__init__(task=task, connection=None, play_context=play_context, loader=None, templar=None, shared_loader_obj=None)
    assert (action_module.task == task)
    assert (action_module._task == task)
    assert (action_module.connection == None)
    assert (action_module._connection == None)
    assert (action_module._play_context == play_context)

# Generated at 2022-06-23 08:10:14.296299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    play_source=dict(
            name="Ansible Play",
            hosts='localhost',
            gather_facts='no',
            tasks=[
                dict(action=dict(module='include_vars', file="/etc/ansible/hosts"), register='hosts')
            ]
        )
    # Create a play to instantiate the task
    play = Play().load(play_source, variable_manager=VariableManager(), loader=loader)

    # Create a task to test
    task = Task().load(play._entries[0], play=play)

    # Create a validator

# Generated at 2022-06-23 08:10:23.498189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.my_ansible_module import MyAnsibleModule

    mod = MyAnsibleModule(argument_spec={},supports_check_mode=True)
    mod._ansible_module = AnsibleModule(
        argument_spec={
            'file': {'required': True},
            'name': {'required': False},
            'depth': {'required': False},
            'files_matching': {'required': False},
            'ignore_files': {'required': False},
            'extensions': {'required': False},
            'ignore_unknown_extensions': {'required': False},
            'hash_behaviour': {'required': False},
        },
        supports_check_mode=True
    )
    mod

# Generated at 2022-06-23 08:10:24.267483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:10:34.369118
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action.VALID_ALL == ['name', 'hash_behaviour']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.TRANSFERS_FILES == False



# Generated at 2022-06-23 08:10:35.576735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    constructor = ActionModule()

# Generated at 2022-06-23 08:10:44.416404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Create an instance of ActionModule and run unit tests on it. """
    import unittest
    import shutil
    import tempfile
    import ansible.utils.yaml

    class TestActionModule(unittest.TestCase):
        """ Unit test class for testing ActionModule """
        # create a temporary directory to hold the test directory
        TEST_FILE_DIRECTORY = tempfile.mkdtemp(prefix='ansible-test-directory-')

        def setUp(self):
            """ Unit test setup method, executed before each unit test """
            # setup test folder(s) and test file(s)
            self.parent_dir = 'my-parent-dir'
            self.test_dir = 'my-test-dir'

# Generated at 2022-06-23 08:10:55.993668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('testing method run of class ActionModule')

    ##############
    # Setup test #
    ##############

# Generated at 2022-06-23 08:11:05.097793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Inject mocks for Ansible internal classes
    # Constructor of class Task
    mock_ds = ""
    mock_task = Task(
        None,
        mock_ds,
        0,
        False,
        None,
        None,
        None,
        None,
        None,
        None,
        0,
        False,
        False,
        False,
        False,
        False,
        None,
        None,
        None,
        None,
        None
    )

    # Constructor of class VariableManager
    mock_inventory = InventoryManager(loader=None, sources='')
    mock_variable

# Generated at 2022-06-23 08:11:14.761648
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    import ansible.plugins.action
    from ansible.errors import AnsibleError

    class TestActionModule(unittest.TestCase):
        def test_init(self):
            test_instance = ansible.plugins.action.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
            self.assertTrue(test_instance)

        def test_run(self):
            test_instance = ansible.plugins.action.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
            self.assertTrue(test_instance)
            with self.assertRaises(AnsibleError):
                test_instance.run()

   

# Generated at 2022-06-23 08:11:25.027472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    results = TaskResult(host=None, task=None, return_data=dict())
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    task_queue_manager = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=dict(connection='local'),
        passwords=dict(),
    )
    play_context = PlayContext(remote_user='root', log_path='play.log')


# Generated at 2022-06-23 08:11:33.616051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize with arguments
    # Called from a playbook
    task_vars = dict()
    loader = None
    templar = None

    action = ActionModule(
        dict(
            _task=dict(
                _role=None,
                args=dict(
                    file="../../tasks/files/vars_files/facts.yml"
                )
            ),
            _loader=loader,
            _task_vars=task_vars,
            _templar=templar
        )
    )

    # Run the action
    result = action.run(task_vars=task_vars)
    assert result
    assert result['ansible_facts']
    assert result['ansible_facts']['network_facts']

# Generated at 2022-06-23 08:11:39.355423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Unit test for constructor of class ActionModule '''
    task = 'include vars'
    args = {'name': 'test'}
    action = ActionModule(task, args)
    return 'Pass' 


# Generated at 2022-06-23 08:11:41.117816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test code for each of the methods
    actionModule = ActionModule()
    assert True

# Generated at 2022-06-23 08:11:51.711166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.vault import VaultLib
    from ansible.modules.system import ping
    from ansible.utils.vars import combine_vars
    module = AnsibleModule(
        argument_spec=ping.argspec,
        supports_check_mode=True
    )
    t = ActionModule(module,dict())

# Generated at 2022-06-23 08:11:54.928342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._set_dir_defaults()
    assert module.depth == 0 and module.files_matching == None and module.ignore_files == list()
    

# Generated at 2022-06-23 08:12:00.602517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    AM = ActionModule(
        task=dict(
            args=dict(
                file='vars_file_name'
            ),
            _ds=dict(
                _data_source='path/to/file'
            )
        ),
        play_context=dict(
            file_encoding='utf-8'
        )
    )

    AM._task.args = dict(
        file='path/to/file'
    )
    AM._task.args['_raw_params'] = 'path/to/file'
    AM._task._ds = dict(
        _data_source='/path/to/file'
    )
    AM._task._role = dict(
        _role_path='/path/to/file'
    )

# Generated at 2022-06-23 08:12:12.560419
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import unittest.mock as mock
    from ansible.plugins.action import ActionBase

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    mock_task_run = mock.MagicMock()
    mock_loader_get_file_contents = mock.MagicMock(return_value=('name: value', True))
    mock_loader_load = mock.MagicMock(return_value=dict(name='value'))

    mock_am = ActionModule(mock_task_run, {})
    mock_am._loader = mock.MagicMock()
    mock_am._loader.get_file_contents = mock_loader_get_file_contents
    mock_am._loader.load = mock_loader_load


# Generated at 2022-06-23 08:12:19.566363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of class ActionModule...")

    # arguments for testing ActionModule
    action_args = dict(
        dir='/tmp',
        depth=3,
        files_matching='*.yml',
        extensions='yml'
    )

    print("Testing constructor of class ActionModule...Done")

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-23 08:12:31.381776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context
    from ansible.template import Templar
    from ansible.vars import VariableManager, DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    context.CLIARGS = {}
    templar = Templar(loader=loader, variables=variable_manager)

    am = ActionModule('test', 'include_vars', dict(file='test'), loader=loader, templar=templar, shared_loader_obj=loader)
    assert am._task.name == 'test'
    assert am._task.action == 'include_vars'
    assert am._task.args['file'] == 'test'
    assert isinstance(am.VALID_FILE_EXTENSIONS, list)
    assert isinstance(am.VALID_DIR_ARGUMENTS, list)

# Generated at 2022-06-23 08:12:32.847327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()


# Unit tests for methods of class ActionModule

# Generated at 2022-06-23 08:12:42.778020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test the constructor of ActionModule
    :return: None
    """
    task = {'args': {}}
    task_vars = {}
    tmp = None
    AM = ActionModule(task, tmp, task_vars)
    AM.VALID_FILE_EXTENSIONS = ['yml', 'json']
    AM.VALID_DIR_ARGUMENTS = ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    AM.VALID_FILE_ARGUMENTS = ['file', '_raw_params']
    AM.VALID_ALL = ['name', 'hash_behaviour']

    AM.show_content = True
    AM.included_files = []

# Generated at 2022-06-23 08:12:56.208821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule
    """
    ActionModule.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
    fti = ActionModule()
    # fti._set_args()
    fti._task = FakeTask()
    fti._loader = FakeLoader()
    # fti.run(tmp=None, task_vars=None)
    fti._task._role = FakeRole()
    fti._task._ds = FakeDS()
    fti._set_root_dir()
    assert fti._task._ds._data_source == '/Users/ansible/example.yml'
    assert fti.source_dir == '/Users/ansible/test_module/vars'



# Generated at 2022-06-23 08:12:59.651551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(),
        connection=None,
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action

# Generated at 2022-06-23 08:13:09.902255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule
    """
    import ansible.playbook.play_context
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.utils.vars
    import ansible.template
    import ansible.parsing.dataloader

    # setup context
    loader = ansible.parsing.dataloader.DataLoader()
    variables = ansible.utils.vars.VariableManager()
    inventory = ansible.inventory.Inventory(loader=loader, variable_manager=variables, host_list=['localhost'])
    task_vars = variables.get_vars(play=ansible.playbook.play.Play().load(dict(inventory=inventory), loader=loader, variable_manager=variables))
    play_context = ans

# Generated at 2022-06-23 08:13:21.297204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    import json

    class MockTask(object):
        def __init__(self, args):
            self.args = args

    class MockPlay():
        def __init__(self):
            self._role = Role()

    class MockOptions(object):
        def __init__(self):
            self.connection = 'smart'
            self.module_path = '/path/to/mymodules'

# Generated at 2022-06-23 08:13:29.464816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def __init__(self):
        # pretend we are loading this as a plugin
        ActionBase.__init__(self, task=self, connection=self, play_context=self)

    def is_playbook():
        return False

    def _clean_task_data(self, data, is_handler=False):
        return super(ActionModule, self)._clean_task_data(data, is_handler=is_handler)
    # Inject our test methods in the class we want to test
    ActionModule.__init__ = __init__
    ActionModule.is_playbook = is_playbook
    ActionModule._clean_task_data = _clean_task_data

    # Init
    p = ActionModule()

    return p

# Generated at 2022-06-23 08:13:31.784756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert isinstance(ActionModule(), ActionBase)
    assert isinstance(ActionModule(), ActionModule)


# Generated at 2022-06-23 08:13:40.319937
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_object = ActionModule()
    assert test_object.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert test_object.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert test_object.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert test_object.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-23 08:13:52.656120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up the class and its attributes
    action_module = ActionModule()
    action_module._task = ""
    action_module._connection = ""
    action_module._play_context = ""
    action_module._loader = ""
    action_module._templar = ""
    action_module._shared_loader_obj = ""

    # Set the arguments to use for the method _load_files
    action_module.source_file = '../../library/data/vars.yaml'
    # Load the file
    error_flag, error_msg, loaded_data = action_module._load_files(action_module.source_file)

    # Assert that the file was loaded successfully
    assert error_flag == False, "Error loading file"

    # Assert that the contents of the file were loaded correctly
    # The file contains

# Generated at 2022-06-23 08:14:00.894597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(dict(), dict())
    assert mod._task.args.get('hash_behaviour', None) is None
    assert mod._task.args.get('name', None) is None
    assert mod._task.args.get('dir', None) is None
    assert mod._task.args.get('file', None) is None
    assert mod._task.args.get('_raw_params') is None
    assert mod._task.args.get('depth', None) is None
    assert mod._task.args.get('files_matching', None) is None
    assert mod._task.args.get('ignore_unknown_extensions', False)
    assert mod._task.args.get('ignore_files', None) is None
    assert mod.valid_extensions == ['yaml', 'yml', 'json']

    mod

# Generated at 2022-06-23 08:14:01.379686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:14:12.085348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.basic import AnsibleModule
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    import os

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["/etc/ansible/hosts"])
    variable_

# Generated at 2022-06-23 08:14:15.955414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-23 08:14:17.706765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO: write unit test for method run of class ActionModule
    pass

# Generated at 2022-06-23 08:14:18.554619
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #TODO: code this unit test

    assert True

# Generated at 2022-06-23 08:14:27.765360
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:14:29.709478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule({},{},{},{})
    assert action != None

# Generated at 2022-06-23 08:14:42.005065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_action_name = "include_vars"
    test_work_dir = "/tmp/ansible-test/work"
    test_vars_dir = "/tmp/ansible-test/vars"
    test_vars_file = "/tmp/ansible-test/vars/test.yml"
    test_root_path = "/tmp/ansible-test/roles/test"
    test_valid_extensions = ['yaml', 'yml', 'json']
    test_valid_all = ['name', 'hash_behaviour']

    fake_task = FakeTask()
    fake_task.action = test_action_name
    fake_task.work_dir = test_work_dir
    fake_task.vars_dir = test_vars_dir

# Generated at 2022-06-23 08:14:51.928664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_test_obj = action_loader.get('include_vars', class_only=True)(task={}, connection={}, play_context={}, loader={}, templar={}, shared_loader_obj={})
    dir_list = ['test/test_files']
    module_test_obj._task.args = {'dir': dir_list}
    module_test_obj._set_args()
    module_test_obj._set_root_dir()
    out = module_test_obj.run(task_vars={})
    assert out['ansible_facts']['test_out'] == 'test_out_value'
    assert out['ansible_facts']['test_out_2'] == 'test_out_2_value'


# Generated at 2022-06-23 08:14:52.575356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:14:53.449410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule()
    actionmodule.run()

# Generated at 2022-06-23 08:14:54.398080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _ = ActionModule()
    return _


# Generated at 2022-06-23 08:15:00.774073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.VALID_ALL == ['name', 'hash_behaviour']
    assert action.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']

# Generated at 2022-06-23 08:15:13.520264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.include_vars as include_vars
    class ActionModuleTask(object):
        def __init__(self):
            self.args = dict()
            self._role = None
            self._ds = None
    class ActionModuleLoader(object):
        pass
    class ActionModuleRole(object):
        def __init__(self):
            self._role_path = '/home/vagrant/ansible-test/test/unit/plugins/action/test_include_vars/'
    class ActionModuleDataSource(object):
        def __init__(self):
            self._data_source = '/home/vagrant/ansible-test/test/unit/plugins/action/test_include_vars/tasks/main.yml'


# Generated at 2022-06-23 08:15:20.451384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('/', {}, {}, True)

    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert am.VALID_DIR_ARGUMENTS == ['depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_FILE_ARGUMENTS == ['_raw_params']
    assert am.VALID_ALL == ['name', 'hash_behaviour']
    assert am._task.args == {}
    assert am.has_run == True


# Generated at 2022-06-23 08:15:24.831161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test constructor of class ActionModule
    """
    # Parameter 'task' required
    try:
        ActionModule()
        assert False
    except TypeError:
        assert True

    # test all parameters
 
    # TODO: Add test cases
    pass

# Generated at 2022-06-23 08:15:35.909883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = dict()

    # prepare mocks
    mock_task = Mock()
    mock_task._role = None
    mock_task._ds = None
    mock_task._role.return_value = None
    mock_task._ds.return_value = None
    mock_task.args = module_args

    test_action = ActionModule(mock_task, mock_task.args)
    assert test_action

    assert test_action.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert test_action.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']

# Generated at 2022-06-23 08:15:40.185517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # result of action should be a tuple of ( Boolean, String, Dict )
    assert isinstance(ActionModule.run, ActionBase.run)
    # result of action should be a tuple of ( Boolean, String, Dict )
    assert isinstance(ActionModule.run, ActionBase.run)

# Generated at 2022-06-23 08:15:52.251247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    global C
    C.PUSH_REMOTE_CONNECTION = None
    C.DEFAULT_HASH_BEHAVIOUR = 'replace'
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    module._set_args = MagicMock()
    module._set_dir_defaults = MagicMock()
    module._traverse_dir_depth = MagicMock()
    module._load_files_in_dir = MagicMock()
    module._set_root_dir = MagicMock()
    module._find_needle = MagicMock()
    module._load_files = MagicMock()
    module.run(task_vars=None)
    module.run(task_vars=dict())


# Generated at 2022-06-23 08:15:57.637765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = MockTask()
    mock_task.args = {"name":"test", "file":"sources/test_sample.yml"}
    action_module = ActionModule()
    action_module.included_files = []
    action_module.show_content = True
    action_module._task = mock_task
    action_module._set_args()
    action_module.source_file="sources/test_sample.yml"
    assert(action_module.run())


# Generated at 2022-06-23 08:16:09.712639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Mock_task:
        def __init__(self, args, role):
            self.args = args
            self._role = role
            self.args = dict()

    class Mock_Role:
        def __init__(self, path):
            self._role_path = path

    class Mock_Ansible_Module:
        def __init__(self, roles_path, data_source, name_to_be_passed):
            self._task = Mock_task(args={'name': name_to_be_passed}, role=Mock_Role(roles_path))
            self._ds = Mock_DS(data_source)
            self.show_content = None
            self.included_files = list()


# Generated at 2022-06-23 08:16:16.258398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_modules_path = '/usr/lib/python2.7/site-packages/ansible/modules/hashivault'
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    action_module.TRANSFERS_FILES = False
    assert(action_module.TRANSFERS_FILES == False)

    action_module.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']
    assert(action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'])


# Generated at 2022-06-23 08:16:20.377590
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {'action': 'include_vars', 'args': {'file': '../../../vars/foo.yml', 'name': 'foo'}}
    am = ActionModule(task, None)
    assert am._task.action == 'include_vars'

# Generated at 2022-06-23 08:16:29.669122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.utils.template as template
    from ansible.template import Templar

    jinja2 = template.Jinja2()
    templar = Templar(loader=None, variables={}, shared_loader_obj=jinja2)

    am = ActionModule(task=dict(), connection=dict(), play_context=dict(basedir="."), loader=None, templar=templar, shared_loader_obj=jinja2)
    am.run(task_vars={})

# Generated at 2022-06-23 08:16:39.819107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(dict(), None)
    action_module.missing_required_args = lambda : False
    action_module.show_content = True
    action_module.included_files = []
    action_module._set_dir_defaults()
    action_module._set_args()
    action_module._set_root_dir()
    action_module._traverse_dir_depth()
    action_module._ignore_file("mesos-master")
    action_module._is_valid_file_ext("mesos-master.yaml")
    action_module._load_files("mesos-master.yaml")
    action_module._load_files_in_dir("/opt/mesos/vars", "mesos-master.yaml")

# Generated at 2022-06-23 08:16:51.152832
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_data = {
        'variable': 'value'
    }

    class FakeLoader(object):
        def load(self, data, file_name=None, show_content=None):
            return test_data
    class FakeDataSource(object):
        def __init__(self):
            self._data_source = 'test_directory'

    class FakeRole(object):
        def __init__(self):
            self._role_path = 'test_role_dir'

    class FakeTask(object):
        def __init__(self):
            self._ds = FakeDataSource()
            self._role = None
            self.args = {}

        def _get_task_vars(self):
            return {}

    fake_loader = FakeLoader()

# Generated at 2022-06-23 08:16:59.351820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ unit test for ActionModule.run method """
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    # Setup the test environment
    module = None
    task_vars = {'test_var': '1'}
    play_context = PlayContext()
    task_args = {'name': 'test_var'}
    task_ds = {'role':{'path':'/tmp'},'_data_source':'/tmp/test_arg.txt'}
    task_include = TaskInclude(task_args, task_ds)
    task = Task()
    task._role = None
   

# Generated at 2022-06-23 08:17:09.736611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_loader = 'this is my loader'
    my_task = 'this is my task'
    my_connection = 'this is my connection'
    my_play_context = 'this is my play context'
    my_loader_args = dict()
    my_task_args = dict()
    my_connection_args = dict()
    my_play_context_args = dict()
    am = ActionModule(my_loader, my_task, my_connection, my_play_context, my_loader_args, my_task_args, my_connection_args, my_play_context_args)
    assert am.__class__.__name__ == "ActionModule"


# Generated at 2022-06-23 08:17:19.822925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.playbook.play, ansible.playbook.task, ansible.playbook.role, ansible.playbook.block
    import ansible.executor.task_queue_manager
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.utils.plugin_docs
    import ansible.utils.display
    import ansible.inventory.manager
    import ansible.playbook.role.definition


# Generated at 2022-06-23 08:17:28.400367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os
    import argparse
    import unittest
    #from ansible.cli import CLI
    #from ansible.module_utils import basic
    #from ansible.module_utils._text import to_bytes, to_text
    #from ansible.module_utils.six import PY2, PY3
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.strategy import ActionModule
    from ansible.executor import task_queue_manager
    from ansible.plugins.action import ActionBase

    test_parser = argparse.ArgumentParser()
    test_options = test_parser.parse_args()


# Generated at 2022-06-23 08:17:29.691171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor takes no argument
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-23 08:17:34.473854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None, 'Unable to instantiate ActionModule'

# Generated at 2022-06-23 08:17:38.898381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert module != None

# Generated at 2022-06-23 08:17:48.377678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test Paramaters
    source_dir = '../../../test/integration/targets/ansible-1.9.4/test/integration/roles/role_include_var/vars'
    depth = 0
    file_matching = None
    ignore_files = ['ignore_files']
    extensions = ['yml', 'yaml']
    ignore_unknown_extensions = True
    source_file = None
    hash_behaviour = 'merge'
    return_results_as_name = 'test_facts'
    # Create instance of class ActionModule to test run
    action_module = ActionModule()

# Generated at 2022-06-23 08:17:59.650195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.playbook.play_context

    from ansible.playbook.play_context import PlayContext

    from ansible.plugins.loader import action_loader

    from ansible.plugins.action.include_vars import ActionModule

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator

    from ansible.playbook.block import Block

    context = PlayContext()

    action = action_loader.get('include_vars', context)

    action._task.args['file'] = '/home/allen/ansible/ansible-include_vars-patch/tests/modules/action_plugins/include_vars/files/test_include_vars.json'
    action._task._role = None


# Generated at 2022-06-23 08:18:01.059521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module


# Generated at 2022-06-23 08:18:03.614577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-23 08:18:05.288131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()

    assert isinstance(action, ActionModule)


# Generated at 2022-06-23 08:18:13.565218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  """[ActionModule] test_ActionModule_run()
    Unit test for method run of class ActionModule
  """
  print(__name__, "Unit test for method run of class ActionModule")
  action = ActionModule(MonkeyPatch(
    _task=MonkeyPatch(
      _role=MonkeyPatch(
        _role_path=""
      ),
      _ds=MonkeyPatch(
        _data_source=""
      ),
      args=dict(
        name="test_name",
        hash_behaviour="merge",
        file="",
      ),
    ),
  ))
  print(action.run())
  assert True

if __name__ == "__main__":
  test_ActionModule_run()