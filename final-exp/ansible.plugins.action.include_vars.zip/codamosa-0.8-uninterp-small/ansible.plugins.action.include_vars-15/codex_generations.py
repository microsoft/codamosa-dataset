

# Generated at 2022-06-25 07:08:12.068980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 07:08:21.757682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b'e@\xac\xcf\x96\xf2\xb5"\xc5\x9a\x9d\xab\x0b\xe4\x03\xee\x0e\xb3'
    str_0 = '\x8c\x02f\x03\xe1\x99\xd8G\x85\xf5\x9f\x97\x14\xad\xb4\xad\xe4'
    set_0 = {False, str_0}
    action_module_0 = ActionModule(bool_0, bytes_0, str_0, bool_0, bool_0, set_0)
    action_module_0._set_dir_defaults()
    action_module_0._set_args()

# Generated at 2022-06-25 07:08:28.356944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bool_4 = False
    bytes_1 = b'\x80\x96\x8a\xb9\xdc\xe4\xfd\xf8\x19\x1e\x02e\xec\x93\x81'
    str_0 = 'both \'user\' and \'remote_user\' are set for this play. The use of \'user\' is deprecated, and should be removed'

    dict_0 = dict()
    dict_0['ansible_included_var_files'] = [bool_0, bool_0]
    dict_0['ansible_facts'] = dict()
    dict_0['_ansible_no_log'] = bool_0

    set_0 = {bool_0, bool_0}

# Generated at 2022-06-25 07:08:29.367314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:08:35.203260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(True, b"!.\xba\x81\xb5\xdb'\x9a\xec&", "both 'user' and 'remote_user' are set for this play. The use of 'user' is deprecated, and should be removed", True, True, {True, True})
    action_module_0.action = 'include_vars'
    action_module_0.task_vars = dict()
    # TODO: Add test case for boolean value True



# Generated at 2022-06-25 07:08:42.615460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    assert action_module_0.source_dir == None
    assert action_module_0.source_file == None
    assert action_module_0.ignore_files == None
    assert action_module_0.valid_extensions == ['yaml', 'yml', 'json']
    assert action_module_0.hash_behaviour == None
    assert action_module_0.return_results_as_name == None


# Generated at 2022-06-25 07:08:50.206776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b"!.\xba\x81\xb5\xdb'\x9a\xec&"
    str_0 = "both 'user' and 'remote_user' are set for this play. The use of 'user' is deprecated, and should be removed"
    set_0 = {bool_0, bool_0}
    action_module_0 = ActionModule(bool_0, bytes_0, str_0, bool_0, bool_0, set_0)
    return

# Generated at 2022-06-25 07:08:56.609243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b"!.\xba\x81\xb5\xdb'\x9a\xec&"
    str_0 = "both 'user' and 'remote_user' are set for this play. The use of 'user' is deprecated, and should be removed"
    set_0 = {bool_0, bool_0}
    action_module_0 = ActionModule(bool_0, bytes_0, str_0, bool_0, bool_0, set_0)
    assert action_module_0.hash_behaviour == None


# Generated at 2022-06-25 07:08:58.578043
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)
    assert isinstance(ActionModule, type)
    assert not hasattr(ActionModule, "__init__")
    assert not hasattr(ActionModule, "__call__")


# Generated at 2022-06-25 07:09:03.488610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\x17\xe2l\xb8\xcd\xee\x05\xcf\xbb\x1a\x12\xf6\x17\x1d'
    str_0 = "6U;&\xab\x8b\x1d\x1c"
    bool_1 = True
    bool_2 = True
    set_0 = {bool_1, bool_1}
    action_module_0 = ActionModule(bool_0, bytes_0, str_0, bool_1, bool_2, set_0)

    action_module_0.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 07:09:29.849180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Should succeed
    my_task = ActionModule([], 'file')
    print('Test 1 - Should succeed')
    print(my_task.run())

    # Should fail
    my_task = ActionModule([], None)
    print('Test 2 - Should fail')
    print(my_task.run())


# Generated at 2022-06-25 07:09:33.383019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_instance = ActionModule({'ansible_version': {'full': '1.2.3.4'}}, {})
    action_module_instance._set_dir_defaults()
    assert bool(action_module_instance._set_dir_defaults()) == False
    assert bool(action_module_instance._set_dir_defaults() == False)

# Generated at 2022-06-25 07:09:34.415240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '__init__'
    str_1 = '__call__'
    v0 = ActionModule(None)


# Generated at 2022-06-25 07:09:35.826615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print()
    print('Function test_ActionModule_run')
    instance_0 = ActionModule()
    print('  Function run')
    instance_0.run('task_vars')


# Generated at 2022-06-25 07:09:42.520857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_0 = str_0
    obj_1 = str_1
    obj_2 = str_2
    obj_3 = str_3
    obj_4 = str_4
    obj_5 = str_5
    obj_6 = str_6
    obj_7 = str_7
    obj_8 = str_8
    obj_9 = str_9
    obj_10 = str_10
    obj_11 = str_11
    obj_12 = str_12
    # Assert for instance variables
    assert obj_0 == '__init__'
    assert obj_1 == '__call__'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:09:49.007195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        print("Testing constructor of testing_module.ActionModule")
        obj = ActionModule()
        assert(True)
    except Exception as e:
        print("Error in testing_module.ActionModule constructor: " + str(e))
        assert(False)


# Generated at 2022-06-25 07:09:52.026644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()


# Generated at 2022-06-25 07:09:56.819014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 0
    test_case = 0
    l_action_plugin = ActionModule()
    # Test method run of class ActionModule
    method = ActionModule.run
    method(l_action_plugin)

# Generated at 2022-06-25 07:10:07.869332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("********* Unit Test for class ActionModule *********")
    print("************** Case 0: Testing constructor *************")
    instance_0 = ActionModule()
    str_0 = instance_0.__class__
    str_1 = 'ansible.plugins.action.ActionModule'
    print("Unit test case 0 of class ActionModule:")
    print("\tActual: %s" % str(str_0))
    print("\tExpected: %s" % str(str_1))
    print("\tOutput: %s" % str(str_0==str_1))
    assert str(str_0) == str(str_1)
    print("\tActual: %s" % str(instance_0.__doc__))
    print("\tExpected: None")

# Generated at 2022-06-25 07:10:09.895910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert(action_module_0 is not None)
    action_module_0.__init__()


# Generated at 2022-06-25 07:10:41.420246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    test_case_run = action_module_0.run()
    print(test_case_run)
    assert test_case_run == {'ansible_facts': {}, 'ansible_included_var_files': [], '_ansible_no_log': True}


# Generated at 2022-06-25 07:10:43.052603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:10:44.702261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if 1:
        # Unit test for constructor of class ActionModule
        action_module = ActionModule()



# Generated at 2022-06-25 07:10:45.570858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()


# Generated at 2022-06-25 07:10:46.836694
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()

    # Run test of method run of class ActionModule
    action_module_1.run()



# Generated at 2022-06-25 07:10:47.858261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run(tmp=None, task_vars=1)

# Generated at 2022-06-25 07:10:52.305757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    passed = True
    try:
        test_case_0()
    except Exception:
        passed = False
    assert passed == True

test_ActionModule()

# Generated at 2022-06-25 07:10:54.790776
# Unit test for constructor of class ActionModule
def test_ActionModule():

    #test case 1
    action_module_1 = ActionModule()
    assert action_module_1 is not None
    assert action_module_1.match is None
    assert action_module_1.run is not None


# Generated at 2022-06-25 07:11:05.214107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run = ActionModule()
    action_module_run._set_args()
    action_module_run._set_root_dir()
    action_module_run._set_dir_defaults()
    action_module_run._traverse_dir_depth()
    action_module_run._ignore_file("test_ignore_file")
    action_module_run._is_valid_file_ext("test_is_valid_file_ext.py")
    action_module_run._load_files("test_load_files.py")
    action_module_run._load_files_in_dir("test_load_files_in_dir.py")
    action_module_run.run()

# Generated at 2022-06-25 07:11:07.857456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._task = dict()
    action_module_0._task.args = dict()
    action_module_0.run()

# Generated at 2022-06-25 07:12:06.883828
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule()
    # tmp no longer has any effect
    tmp_1 = None
    task_vars_2 = dict()

    # Call method run of action_module_0
    return_value_3 = action_module_0.run(tmp=tmp_1, task_vars=task_vars_2)
    return return_value_3

# Generated at 2022-06-25 07:12:10.585055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1.run()

# Generated at 2022-06-25 07:12:12.795755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert not action_module



# Generated at 2022-06-25 07:12:13.900702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()


# Generated at 2022-06-25 07:12:20.366249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Executing method run of ActionModule...')
    action_module_1 = ActionModule()
    action_module_1._set_args()
    action_module_1._set_root_dir()
    print(action_module_1.source_dir)

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:12:24.714910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    try :
        assert isinstance(action_module, ActionModule)
    except AssertionError:
        print("ActionModule can not be instantiated")



# Generated at 2022-06-25 07:12:30.214036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print("Test ActionModule.run():")
    print("  length of results: " + str(len(action_module_0.run())))

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:12:37.941504
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_0 = ActionModule()
    assert action_module_0.show_content == True
    assert action_module_0.included_files == []

    action_module_1 = ActionModule()
    assert action_module_1.show_content == True
    assert action_module_1.included_files == []

    action_module_2 = ActionModule()
    assert action_module_2.show_content == True
    assert action_module_2.included_files == []

    assert id(action_module_0) != id(action_module_1)
    assert id(action_module_0) != id(action_module_2)
    assert id(action_module_1) != id(action_module_2)


# Generated at 2022-06-25 07:12:48.936264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run = ActionModule()

    # Test case 0
    tmp = None
    task_vars = dict()
    task_vars['ansible_included_var_files'] = ['_test_fixtures/ansible_test_included_var_files_mock_file']
    task_vars['ansible_facts'] = {'name': 'test_case_0'}
    task_vars['_ansible_no_log'] = False
    expected_result = {'ansible_included_var_files': ['_test_fixtures/ansible_test_included_var_files_mock_file'], 'ansible_facts': {'name': 'test_case_0'}, '_ansible_no_log': False}

# Generated at 2022-06-25 07:12:49.891684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-25 07:14:50.236060
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert isinstance(action_module_1, ActionModule)

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 07:14:56.927714
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_1 = ActionModule()
    action_module_1.show_content = True
    action_module_1._task.args = {'name':None, 'hash_behaviour':None, 'file':'main.yml'}
    action_module_1.source_file = 'main.yml'
    action_module_1._task.action = 'include_vars'
    action_module_1._task.ds = {'name':'include_vars', 'action':'include_vars', 'args':{'name':None, 'hash_behaviour':None, 'file':'main.yml'}}
    action_module_1.valid_extensions = ['yml', 'yaml', 'json']
    action_module_1._set_args()
    action_module_1._find_

# Generated at 2022-06-25 07:15:04.756292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module_0.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module_0.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module_0.VALID_ALL == ['name', 'hash_behaviour']

# Generated at 2022-06-25 07:15:05.564552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None

# Generated at 2022-06-25 07:15:10.120924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_list = {
        'hash_behaviour' : None,
        'name'           : None,
        'dir'            : None,
        'file'           : None,
        '_raw_params'    : './files/test_0.yml',
        'depth'          : 0,
        'files_matching' : None,
        'ignore_files'   : [],
        'extensions'     : [],
        'ignore_unknown_extensions' : False
    }

# Generated at 2022-06-25 07:15:17.646159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # For example:
    #     Check that the ActionModule.run() method exists
    #     Check that the ActionModule.run() method accepts the right number of parameters
    #     Check that the ActionModule.run() method returns a dict
    dict_0 = dict()
    dict_1 = dict()
    action_module_0 = ActionModule()
    task_0 = ActionModule.run(action_module_0, dict_0, dict_1)
    assert isinstance(task_0, dict)

# Generated at 2022-06-25 07:15:21.192841
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert compare(ActionModule()._task.args.get('file'), None)


# Generated at 2022-06-25 07:15:25.989523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule) is True


# Generated at 2022-06-25 07:15:28.925351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-25 07:15:33.078188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_loader = AnsibleLoader()
    action_module = ActionModule()
    action_module.run(tmp=None, task_vars=None)
