

# Generated at 2022-06-25 07:08:11.430170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:08:14.552536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize the class
    action_module_0 = ActionModule(value_0=bytes_0)
    # More unit test code here


test_case_0()
# We could add more test cases here

# Generated at 2022-06-25 07:08:16.012511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:08:24.439129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Prepare
    module = ansible.module_utils.basic.AnsibleModule(argument_spec = dict())
    module.params = dict(dir = 'dir')
    action_module = ActionModule(module, 'path', 'connection')
    action_module._task = ansible.parsing.dataloader.DataLoader()
    action_module._task._role = ansible.parsing.dataloader.DataLoader()
    action_module._task.args = dict(ignore_unknown_extensions = True, name = 'name', hash_behaviour = 'hash_behaviour', _raw_params = '_raw_params')
    action_module._traverse_dir_depth = mock.Mock(return_value = iter([('root_dir', 'filenames')]))
    action_module._load_files_

# Generated at 2022-06-25 07:08:34.869080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_0 = type('', (), {})() # fake AnsibleModule
    ansible_0.params = dict()
    ansible_0.check_mode = bool()
    ansible_0.no_log = bool()
    ansible_0._low_level_debug_enabled = bool()
    ansible_0._socket_path = str()
    ansible_0._json_mode = bool()
    ansible_0._diff = bool()
    ansible_task_0 = type('', (), {})() # fake AnsibleTask
    ansible_task_0.args = dict()
    ansible_self_0 = type('', (), {})() # fake self
    ansible_self_0._task = ansible_task_0
    ansible_self_0._task._role = type('', (), {})()

# Generated at 2022-06-25 07:08:41.675307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Tests for method run of class ActionModule."""
    action_module = ActionModule(task=object())
    str_0 = 'C\\68X.h;U*}oupFQ'
    bool_0 = True
    bytes_0 = b'\xf6#\xfe~\x94h\xaf\x10\xca'
    list_0 = [str_0]
    set_0 = {bool_0, list_0, list_0}
    action_module.run(tmp=set_0)


# Generated at 2022-06-25 07:08:52.847783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    test = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert test._set_args() is None
    assert test._set_dir_defaults() is None
    assert test._set_root_dir() is None
    assert test._traverse_dir_depth() is not None
    assert test._ignore_file(test.source_file) is True
    assert test._is_valid_file_ext(test.source_file) is True
    assert test._load_files(test.source_file) is not None
    assert test._load_files_in_dir(test.source_dir, test.source_file) is not None

# Generated at 2022-06-25 07:08:58.187310
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:09:06.304792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_var_1 = b'D\x8d\x1f\xa6\xa7\xd5\xf9\x01\xab\xa2\x1b\x94\xbd\xa1\x83\xc8\xb0\x9b\x05\xce\xa8\x98\x17\xd0j\xa6\x85\xf5\x9c\xed\x0eI\xfd\x03\xae\n\x81\xf8\x1c\x9d\x9c\x08'
    test_var_0 = ActionModule()
    test_var_0._task = test_var_1
    test_var_0._set_dir_defaults()
    assert test_var_0._task == test

# Generated at 2022-06-25 07:09:14.094162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'C\\68X.h;U*}oupFQ'
    str_1 = 'b\x1a\xa5\x96\x08\xb0\x89\x12\x8c\x100\xeb\xe3\x11\x90\xa2\x7f\x91'
    bool_0 = True
    list_0 = [str_0]
    tuple_0 = (bytes, list_0, list_0)
    dict_0 = {bool_0: tuple_0}
    int_0 = 9
    int_1 = 7

# Generated at 2022-06-25 07:09:45.258471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    assert type(action_module_0.run()) is dict, 'return value of method is not a dict type.'
    assert 'ansible_facts' in action_module_0.run(), 'return value does not contain ansible_facts.'
    assert '_ansible_no_log' in action_module_0.run(), 'return value does not contain _ansible_no_log.'
    assert 'ansible_included_var_files' in action_module_0.run(), 'return value does not contain ansible_included_var_files.'
    assert type(action_module_0.run()['ansible_facts']) is dict, 'type of ansible_facts is not a dict type.'
    assert type(action_module_0.run()['_ansible_no_log'])

# Generated at 2022-06-25 07:09:47.446865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

test_ActionModule()

# Generated at 2022-06-25 07:09:58.290745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    args = {'_raw_params': './ansible/test/units/modules/action_plugins/test_include_vars.yaml'}
    task_vars = {'ansible_include_vars': './ansible/test/units/modules/action_plugins/test_include_vars.yaml'}
    res = action_module_1.run(task_vars=task_vars, **args)
    print(res)
    print(action_module_1.included_files)
    print(action_module_1.show_content)
    print(res['ansible_facts'])

test_ActionModule_run()
#test_case_0()

# Generated at 2022-06-25 07:10:02.278339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
        print('%s Test case 0 passed' %(__name__))
    except Exception as ex:
        print('%s Test case 0 failed' %(__name__))
        print('%s Exception: %s' %(__name__, ex))

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:10:05.981073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:10:07.484937
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:10:08.243001
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:10:09.400680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:10:17.928261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    # 1.
    # tmp = None, task_vars = None
    result = action_module_1.run()
    print(result)
    print(type(result))
    print()
    
    # 2.
    # tmp = None, task_vars = {'a': 1}
    result = action_module_1.run(task_vars={'a': 1})
    print(result)
    print(type(result))
    print()

# Generated at 2022-06-25 07:10:19.879085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor
    action_module_0 = ActionModule()

    # Variables



# Generated at 2022-06-25 07:10:51.638728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize test variables
    task_tuple = ('tasks', 'tasks_file', '', 'tasks_no_colon', 'tasks_list', '', 'tasks_action', 'ActionModule')
    task_args = {'name': None, 'hash_behaviour': 'replace', 'file': '/tmp/test.yml'}

# Generated at 2022-06-25 07:10:53.058907
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:10:57.414819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    # assert callable(action_module_0)
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module_0.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module_0.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module_0.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-25 07:11:03.665350
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    if action_module is not None:
        print("Instantiation of ActionModule class was successful!")
    else:
        print("Instantiation of ActionModule class was NOT successful!")

test_ActionModule()

# Generated at 2022-06-25 07:11:04.531755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-25 07:11:06.535315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-25 07:11:12.970450
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._set_args()
    assert action_module_0.run(tmp="None", task_vars=None) is not None

# Generated at 2022-06-25 07:11:14.756672
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Constructor for ActionModule class"""
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:11:26.198631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run_0 = ActionModule()
    action_module_run_0.return_results_as_name = 'test_ActionModule_run'
    action_module_run_0.hash_behaviour = 'replace'
    action_module_run_0.included_files = ['include_vars']
    action_module_run_0.source_file = 'include_vars'
    action_module_run_0._set_args()
    action_module_run_0._loader = 'loader'
    action_module_run_0._task = 'task'
    action_module_run_0._traverse_dir_depth()
    action_module_run_0._set_root_dir()
    action_module_run_0._ignore_file('filename_0')
    action_module_run

# Generated at 2022-06-25 07:11:28.046528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()
    assert True


# Generated at 2022-06-25 07:12:00.808610
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:12:02.464799
# Unit test for constructor of class ActionModule
def test_ActionModule():
	# assert something
	action_module_0 = ActionModule()
	assert something


# Generated at 2022-06-25 07:12:03.162556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()



# Generated at 2022-06-25 07:12:05.655743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instance of class ActionModule
    action_module_instance_0 = ActionModule()
    # Call method run of class ActionModule instance action_module_instance_0
    action_module_instance_0.run()



# Generated at 2022-06-25 07:12:06.603922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module0 = ActionModule()

# Generated at 2022-06-25 07:12:15.231127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1.tmp = "/home/me/"
    action_module_1.task_vars = {u'cli_command': u'echo hello', u'command': u'/usr/bin/perl -T /var/lib/iRedAPD/tools/check_clamav_update.pl'}

    try:
        action_module_1.run()
    except Exception as ex:
        print("Error:", ex)


# Generated at 2022-06-25 07:12:22.000847
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run_0 = ActionModule()
    action_module_run_0._set_dir_defaults()
    action_module_run_0.depth = 1
    action_module_run_0.files_matching = '^.*'
    action_module_run_0.ignore_files = ['main.yml', 'test.yml']
    action_module_run_0.ignore_unknown_extensions = True
    action_module_run_0.matcher
    action_module_run_0.return_results_as_name = 'test_run'
    action_module_run_0.source_dir = './'
    action_module_run_0.valid_extensions = ['json']
    action_module_run_0.show_content = True
    action_module_run_0

# Generated at 2022-06-25 07:12:22.873411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module != None


# Generated at 2022-06-25 07:12:30.726899
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    action_module_1 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module_1.run(tmp=None, task_vars=task_vars)
    assert result['ansible_facts'] == {}
    assert result['ansible_included_var_files'] == []
    assert result['_ansible_no_log'] == True


# Generated at 2022-06-25 07:12:38.649522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1._task = AnsibleTask()
    action_module_1._task.args = {'dir':'/home/joe/ansible', 'files_matching':'SiteA-*', 'depth':3, 'ignore_files':['*.key'], 'hash_behaviour':'merge'}
    result = action_module_1.run()

# Generated at 2022-06-25 07:13:44.114546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._set_dir_defaults()
    # Test failed scenario
    try:
        assert False
    except AssertionError:
        print('AssertionError raised')


# Generated at 2022-06-25 07:13:45.646029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_arg = ActionModule()

    assert action_module_arg is not None

# Generated at 2022-06-25 07:13:46.872009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:13:48.337109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:13:53.662826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run_1 = ActionModule()
    action_module_run_2 = ActionModule()
    action_module_run_3 = ActionModule()
    action_module_run_4 = ActionModule()
    action_module_run_5 = ActionModule()
    action_module_run_6 = ActionModule()
    action_module_run_7 = ActionModule()
    action_module_run_8 = ActionModule()
    action_module_run_9 = ActionModule()
    action_module_run_10 = ActionModule()
    action_module_run_11 = ActionModule()
    action_module_run_12 = ActionModule()
    action_module_run_13 = ActionModule()
    action_module_run_14 = ActionModule()
    action_module_run_15 = ActionModule()
    action_module

# Generated at 2022-06-25 07:13:58.266262
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1.set_task(None)
    action_module_1.set_loader()
    action_module_1.run()

    action_module_2 = ActionModule()
    action_module_2.set_task(None)
    action_module_2.set_loader()
    action_module_2.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 07:13:59.551335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:14:00.789678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)



# Generated at 2022-06-25 07:14:03.482709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    # action_module.run()
    pass

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:14:10.037319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run = ActionModule()
    action_module_run._task = {}
    action_module_run._task.args = {}
    action_module_run._task.args["hash_behaviour"] = None
    action_module_run._task.args["name"] = None
    action_module_run._task.args["dir"] = "test_data/vars"
    action_module_run._task.args["file"] = "opt/file"
    action_module_run._task.args["depth"] = 0
    action_module_run._task.args["files_matching"] = None
    action_module_run._task.args["ignore_files"] = None
    action_module_run._task.args["extensions"] = ["yaml", "yml", "json"]
    action_module_run

# Generated at 2022-06-25 07:16:26.166017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:16:32.696115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing variable
    task_vars_1 = {
        'foo': {
            'bar': 'baz'
        },
        'target_host': '1.1.1.1',
        'target_port': '8080'
    }
    # Initializing variable
    runner_1 = {
        'module_name': 'ansible.module_utils.viper_test',
        'module_vars': {
            'target_host': '1.1.1.1',
            'target_port': '8080'
        },
        'no_log': False
    }

    # Initializing variable

# Generated at 2022-06-25 07:16:34.084192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    if action_module is None:
        raise Exception("Could not create an ActionModule Object!")


# Generated at 2022-06-25 07:16:34.973763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    assert True

# Generated at 2022-06-25 07:16:42.115517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._task = {
        'args': {
             'dir': 'dir',
             'depth': 'depth',
             'files_matching': 'files_matching',
             'ignore_files': 'ignore_files',
             'extensions': 'extensions',
             'ignore_unknown_extensions': 'ignore_unknown_extensions',
             'file': 'file',
             '_raw_params': '_raw_params',
             'name': 'name',
             'hash_behaviour': 'hash_behaviour',
        },
    }
    action_module_0.run()


# Generated at 2022-06-25 07:16:42.928800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:16:53.837260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #test case with value set for source_dir
    action_module_1 = ActionModule()
    action_module_1._task = object()
    action_module_1._task._ds = object()
    action_module_1._task._ds._data_source = 'HOME/data/basic.yml'
    action_module_1._task.args = {'dir':'data',
        'files_matching':'*.yml',
        'name':'ansible_collections.find_needle',
        'hash_behaviour':'replace'}
    action_module_1.run()
    assert action_module_1.source_dir == 'HOME/data'
    assert action_module_1.files_matching == '*.yml'

# Generated at 2022-06-25 07:17:00.199731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("")
    print("**************************")
    print("Unit test for method run")
    print("**************************")
    action_module = ActionModule()

    # normal case
    # test_case_1

    # dir is defined and corresponding dir exists
    action_module._task.action = 'include'
    action_module._task._role = None
    action_module._task._ds = None
    action_module._task.args = {
        'dir': 'ansible/test/test_include/test_include_root/test_include_vars/test_include_dir',
        'name': 'test_include_name'
    }
    action_module._set_args()
    action_module._set_root_dir()
    action_module._set_dir_defaults()

# Generated at 2022-06-25 07:17:02.832442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    action_module.run()


# Generated at 2022-06-25 07:17:04.205557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()