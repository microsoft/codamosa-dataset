

# Generated at 2022-06-25 07:08:10.150361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:08:13.524271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except AnsibleError as err:
        print("Ansible error: {0}".format(err))
    else:
        print("Constructor of class ActionModule works as expected")

# Generated at 2022-06-25 07:08:18.542429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2212
    list_0 = [int_0, int_0, int_0, int_0]
    bytes_0 = None
    bool_0 = True
    float_0 = None
    action_module_0 = ActionModule(list_0, bytes_0, bool_0, int_0, float_0, list_0)


# Generated at 2022-06-25 07:08:26.353102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1964091282
    list_0 = [int_0, int_0, int_0, int_0]
    bytes_0 = b'\x10\xeb\x84\xab\xb4\x11\xaa\x9e\xc4\x81\x18\x15\x79\xcf\xbd\x13\x1b0\x9e\xb1\xe1\xf7\x05\xa8\xab\x95\x0c\x81\x9fT\xc2\x86\xb2>|\x8a\x01:\x89\x82\x14\x8a\xc6\xb6\xb1\xeb\x8c\xfd'
    bool_0 = True
    int_1 = 0
   

# Generated at 2022-06-25 07:08:32.090194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_1 = [0, 0, 0, 0]
    bytes_1 = None
    bool_1 = True
    int_1 = -2212
    float_1 = None
    result_1 = ActionModule(list_1, bytes_1, bool_1, int_1, float_1, list_1)
    assert isinstance(result_1, ansible.plugins.action.ActionBase)


# Generated at 2022-06-25 07:08:39.801592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2212
    list_0 = [int_0, int_0, int_0, int_0]
    bytes_0 = None
    bool_0 = True
    float_0 = None
    action_module_0 = ActionModule(list_0, bytes_0, bool_0, int_0, float_0, list_0)

    # Call action_module_0.run
    # assert False # TODO: implement your test here
    raise Exception('Test Failed')


# Generated at 2022-06-25 07:08:48.034930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2212
    list_0 = [int_0, int_0, int_0, int_0]
    bytes_0 = None
    bool_0 = True
    float_0 = None
    action_module_0 = ActionModule(list_0, bytes_0, bool_0, int_0, float_0, list_0)

    task_vars = None
    tmp = None
    assert action_module_0.run(tmp, task_vars) is None


# Generated at 2022-06-25 07:08:50.779808
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test for case where dir is passed
    test_case_0()

    # Test for case where file is passed
    test_case_1()
    

# Generated at 2022-06-25 07:08:51.582044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:08:52.737187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO unit test for method run of class ActionModule
    assert False


# Generated at 2022-06-25 07:09:25.500618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3613
    bytes_0 = b'<\x12=\x08\xcbsp\xaa\x7f\xee\x19/\x1dX\xd0\x87\x11\xc2\x80\x8f'
    str_0 = 'A)pXn.>_7Mf{;SNd'
    str_1 = 'e\\G6k@qZ)p<4Cy0)/B='
    str_2 = ''
    bool_0 = True
    action_module_0 = ActionModule(int_0, bytes_0, str_0, str_1, str_2, bool_0)
    # var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8

# Generated at 2022-06-25 07:09:33.257629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit test variables
    int_0 = 25631
    bytes_0 = b'\x1e\xf6\xfaC\x96\xc3\x0f\xb3\x9c\x01\x0b\xbd\xbd\xf3\x82\xc0\xac\n'
    str_0 = '4z4MtRR8_%c[d}aMR\x81Y'
    str_1 = 'D{LG'
    bool_0 = False
    action_module_0 = ActionModule(int_0, bytes_0, str_0, str_1, bool_0)
    dict_0 = dict()
    dict_1 = dict(i9='W~', M4='{m4)A')

# Generated at 2022-06-25 07:09:42.360920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Goal:
    # set some data
    # run constructor with these data
    # check if constructor create instance as expected
    # and then compare with self.__dict__

    int_0 = 3613
    bytes_0 = b'<\x12=\x08\xcbsp\xaa\x7f\xee\x19/\x1dX\xd0\x87\x11\xc2\x80\x8f'
    str_0 = 'A)pXn.>_7Mf{;SNd'
    str_1 = 'e\\G6k@qZ)p<4Cy0)/B='
    str_2 = ''
    bool_0 = True

# Generated at 2022-06-25 07:09:46.802250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:09:52.897019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 8038
    bytes_0 = b'\x90\x12\x15\xd7d\xe6\xcf\x02\x00\x00'
    str_0 = '*3f:b54V<9]h'
    str_1 = 'd0@C6xL|6;h'
    str_2 = ''
    bool_0 = True
    action_module_0 = ActionModule(int_0, bytes_0, str_0, str_1, str_2, bool_0)
    var_0 = action_run()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:10:03.144657
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 30595
    bytes_0 = b'\xb9v\xbd\xeb\xd5\xd2\x8a\x8dw\x96\xee\x16\x9e\x05\xd0\xb5\xe3\xac'
    str_0 = '\x07\x9d\x83\xb4\xb7\xeb\xec\x99g\x0c\xdc\xf6U\x6f\x86\xf7\x1a\xab\x08\x82\x13\xbf\x97\x9a\x15\x7f\x04\x11\x15\xda\x7f'
    str_1 = 'A'
    str_2 = 's'
    bool_0 = True


# Generated at 2022-06-25 07:10:07.967324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    c0 = ActionModule()
    c1 = ActionModule(int, bytes, str, str, str, bool)
    # print(c0)
    # print(c1)
    c1.run()
    # print(c1.run())
    # print(c1.run(task_vars=None))

test_ActionModule()
test_case_0()

a = ActionModule()
print(a.run(task_vars={}))

# Generated at 2022-06-25 07:10:14.577216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 406

# Generated at 2022-06-25 07:10:16.655882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()


if __name__ == '__main__':
    # Test code here
    # test_ActionModule()
    pass

# Generated at 2022-06-25 07:10:23.317659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3613
    bytes_0 = b'<\x12=\x08\xcbsp\xaa\x7f\xee\x19/\x1dX\xd0\x87\x11\xc2\x80\x8f'
    str_0 = 'A)pXn.>_7Mf{;SNd'
    str_1 = 'e\\G6k@qZ)p<4Cy0)/B='
    str_2 = ''
    bool_0 = True
    action_module_0 = ActionModule(int_0, bytes_0, str_0, str_1, str_2, bool_0)
    var_0 = action_run()
    var_1 = action_run(var_0)

# Generated at 2022-06-25 07:11:16.725732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create default instance of a task
    task_0 = Task(0, b'\x1a', '', '', '', True)
    int_0 = 81
    bytes_0 = b'\x1a\n@\xf3\x0f\xa2\x0c\x08\xeed\x14\xeb\x12\xc6\xea\x83u\x06\xa7'
    str_0 = 'K'
    str_1 = '9\x13F>0\x18\\'
    str_2 = ''
    bool_0 = True
    action_module_0 = ActionModule(task_0, int_0, bytes_0, str_0, str_1, str_2, bool_0)
    task_vars = dict()
    var_0 = action_

# Generated at 2022-06-25 07:11:18.427431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:11:27.002072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 42510
    bytes_0 = b'\xd2\x93\xc4a\x13\x99\x9f\x91\xed\xfa\xbe\x89`\xe0\xc4k\x15\x9b\x0f\x8d\x08\xbc\xd3\xbc'
    str_0 = 'yC%\x1bl*R@\x04\x1c('
    str_1 = '/~8V2\x13\x7f@(+pv'
    str_2 = '\x14\x0b\x7f\x13'
    bool_0 = True
    action_module_1 = ActionModule(int_0, bytes_0, str_0, str_1, str_2, bool_0)

# Generated at 2022-06-25 07:11:35.868769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 6
    bytes_0 = b'\x13_\xfd\xa1[\xd3\x8f\t\xe9\xf0\xc7\x85\xeb\x1c\xef\xfe'
    str_0 = 'D|>F.PIL-pP]R-\x7f'
    str_1 = '64=g|\x7fXc\x1c7r!\x13\x7f'
    str_2 = '4)y%\x7fA.2\x1d{S\x1d'
    bool_0 = False
    action_module_0 = ActionModule(int_0, bytes_0, str_0, str_1, str_2, bool_0)
    task_vars = dict()
   

# Generated at 2022-06-25 07:11:47.210345
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 8486
    bytes_0 = b'\x88\x8f\xce<\x80\xae\x0c\xe8\xfa\xf0$\x0b4\xfb)\x9a\xbcZ\x0f'
    str_0 = '\x01\xe7\n\xab\x90\x92\x1dF\x89R\xa1\xa0\xedP\x9a\x87\x93\x1a'

# Generated at 2022-06-25 07:11:58.844785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -7744
    bool_0 = False
    bytes_0 = b'\xb8\x03\xdb\r\xd6\x1e\x00\x14\x96\x9b\xf8\xa8\xfd\xf6\xb1\x0c\xd8\x02'
    bytes_1 = b'\xf3\x93\xa3\x92\x15\x827\x0f5:\x04<\x16\xd8{\xec\xca'
    bool_1 = False
    action_module_0 = ActionModule(int_0, bool_0, bytes_0, bytes_1, bool_1)
    assert action_module_0._task.args == dict()


# Generated at 2022-06-25 07:12:07.789881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'<\x12=\x08\xcbsp\xaa\x7f\xee\x19/\x1dX\xd0\x87\x11\xc2\x80\x8f'
    str_0 = 'A)pXn.>_7Mf{;SNd'
    str_1 = 'e\\G6k@qZ)p<4Cy0)/B='
    str_2 = ''
    bool_0 = False
    action_module_0 = ActionModule(1073, bytes_0, str_0, str_1, str_2, bool_0)
    task_vars_0 = dict()
    dict_0 = action_module_0.run(task_vars_0=task_vars_0)
    bool_1 = bool()

# Generated at 2022-06-25 07:12:18.064314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 97317
    bytes_0 = b'0}4C\x0f\xe2\xa6\xd1\x9b\xab\xa9\xe4\x99\xc4\x8f\x91\x9f\x80\x84\xe4\x89'
    str_0 = '$<HT6w1PhFq3/\xd2e-?P~9/z\x05tg'
    str_1 = '\xa0\xef\x00\x16\x9b\xb1\xed\x99\xc1\x0b\xba\x14\x15\xbd\x1c\xc2\x92\xf4'

# Generated at 2022-06-25 07:12:20.532176
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # The assertion
    assert isinstance(action_module_0, ActionModule)



# Generated at 2022-06-25 07:12:29.304450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create instance of class ActionModule
    # Parameter 1: int
    int_0 = 3613
    # Parameter 2: bytes
    bytes_0 = b'<\x12=\x08\xcbsp\xaa\x7f\xee\x19/\x1dX\xd0\x87\x11\xc2\x80\x8f'
    # Parameter 3: str
    str_0 = 'A)pXn.>_7Mf{;SNd'
    # Parameter 4: str
    str_1 = 'e\\G6k@qZ)p<4Cy0)/B='
    # Parameter 5: str
    str_2 = ''
    # Parameter 6: bool
    bool_0 = True

# Generated at 2022-06-25 07:14:15.834020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Running test_ActionModule_run...')
    int_0 = 3613
    bytes_0 = b'<\x12=\x08\xcbsp\xaa\x7f\xee\x19/\x1dX\xd0\x87\x11\xc2\x80\x8f'
    str_0 = 'A)pXn.>_7Mf{;SNd'
    str_1 = 'e\\G6k@qZ)p<4Cy0)/B='
    str_2 = ''
    bool_0 = True
    action_module_0 = ActionModule(int_0, bytes_0, str_0, str_1, str_2, bool_0)
    action_module_0._set_args()
    action_module_0._set_root_dir

# Generated at 2022-06-25 07:14:26.193224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 5105
    bytes_0 = b'!\xfd(o5Q\x7fm\xc9\x82\x00\x1c\xd6\xbd\x04\xef\xa6\x8f\x9d'
    str_0 = 'T,8GrZr)F*j='
    str_1 = '8\'v_"m<$iFL{D(2< #'
    str_2 = '%^aO*j3'
    bool_0 = True
    action_module_0 = ActionModule(int_0, bytes_0, str_0, str_1, str_2, bool_0)
    int_1 = 16119

# Generated at 2022-06-25 07:14:31.614886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 843
    bytes_0 = b'\x02\x0c6\xff\x9a\x9e\xda\xb6\x8f\xe3\x87r\x1c\x95l\xb3\x9b\x0b\x8dP\x1d\x87S\xf1\xed\x8d\xe6\xe5\xae\x0f\xe5'

# Generated at 2022-06-25 07:14:41.165555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3613
    bytes_0 = b'<\x12=\x08\xcbsp\xaa\x7f\xee\x19/\x1dX\xd0\x87\x11\xc2\x80\x8f'
    str_0 = 'A)pXn.>_7Mf{;SNd'
    str_1 = 'e\\G6k@qZ)p<4Cy0)/B='
    str_2 = ''
    bool_0 = True
    action_module_0 = ActionModule(int_0, bytes_0, str_0, str_1, str_2, bool_0)
    action_module_1 = ActionModule(int_0, bytes_0, str_0, str_1, str_2, bool_0)

# Generated at 2022-06-25 07:14:41.712125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:14:50.688069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3613
    bytes_0 = b'<\x12=\x08\xcbsp\xaa\x7f\xee\x19/\x1dX\xd0\x87\x11\xc2\x80\x8f'
    str_0 = 'A)pXn.>_7Mf{;SNd'
    str_1 = 'e\\G6k@qZ)p<4Cy0)/B='
    str_2 = 'P3d5b5g&f]QR|L7h'
    bool_0 = True
    action_module_0 = ActionModule(int_0, bytes_0, str_0, str_1, str_2, bool_0)
    tmp_0 = None
    task_vars_0 = None
    action_

# Generated at 2022-06-25 07:15:01.688934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3224
    bytes_0 = b'p\x1do\x10\x0b\x8c\xb2\xbb\x0b\xe8\x1b\x10\x9a\xee\x8c\xa2\xaa\xd2\x1f\x1c'
    str_0 = '\x01O\x0c\x0c\x10V\x1a\x7f+\x0c\x11\x1e\x7f\x1eF\x1e\x16\x0e\x1d'

# Generated at 2022-06-25 07:15:04.538563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:15:10.890853
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Argument testing with default args
    try:
        int_0 = 3613
        bytes_0 = b'<\x12=\x08\xcbsp\xaa\x7f\xee\x19/\x1dX\xd0\x87\x11\xc2\x80\x8f'
        str_0 = 'A)pXn.>_7Mf{;SNd'
        str_1 = 'e\\G6k@qZ)p<4Cy0)/B='
        str_2 = ''
        bool_0 = True
        action_module_0 = ActionModule(int_0, bytes_0, str_0, str_1, str_2, bool_0)
    except Exception as exception_0:
        print(exception_0)
    
    
    
    

# Generated at 2022-06-25 07:15:20.761655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3160
    bytes_0 = b'}wU\x13'
    str_0 = 'y+O'
    str_1 = '\x06\x03\x00\x1d-\xf0T\x83F\x0e\x16\x90\xbf\xadw\xf4\x0e\x94\xaa*\x08\x8f\xe6\xd3\xa3\x14\x16\x90\xbf\xadw\xf4\x0e\x94\xaa*\x08\x8f\xe6\xd3\xa3\x14'
    str_2 = '\\'
    bool_0 = True