

# Generated at 2022-06-25 07:08:14.254781
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test ActionModule constructor
    test_case_0()


# Generated at 2022-06-25 07:08:23.489464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {}
    bytes_0 = b'\x14\x86\x17\xf8\xfe\x9a\x892\x88\xb3\x7f\x1a&\x9f\x8d\x00\xcd\x7f\xa8\xd0\x1d#\x9a\xa0\xdd\xd6\xee\xdcF&\x8cO\xad\x80\x0b\xe9x\x03\xeb\x14Y/\xd5\x8a\x0b\x80\x84\x9d\xb8\x93D\xa1\xdb\xb8'
    float_0 = -58.0987738

# Generated at 2022-06-25 07:08:29.623339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    bytes_0 = b't\x1c!\xab\xd0ND\xe7V\xac\xd6\x14\xa5\xefg'
    float_0 = -1983.7
    str_0 = "PW.Zbj\r'Ml:;!"
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)
    tmp = None
    task_vars = dict()

    # Act
    actual = action_module_0.run(tmp, task_vars)

    # Assert

# Generated at 2022-06-25 07:08:30.629356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False  # No implementation

# Generated at 2022-06-25 07:08:37.561379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    bytes_0 = b't\x1c!\xab\xd0ND\xe7V\xac\xd6\x14\xa5\xefg'
    float_0 = -1983.7
    str_0 = "PW.Zbj\r'Ml:;!"
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_1['ansible_included_var_files'] = []
    dict_2 = dict()
    dict_1['ansible_facts'] = dict_

# Generated at 2022-06-25 07:08:45.832478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    bytes_0 = b't\x1c!\xab\xd0ND\xe7V\xac\xd6\x14\xa5\xefg'
    float_0 = -1983.7
    str_0 = "PW.Zbj\r'Ml:;!"
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)
    action_module_0._set_dir_defaults()
    action_module_0._set_args()
    dir_0 = 'dir'
    int_0 = -2
    str_1 = 'dir'
    str

# Generated at 2022-06-25 07:08:46.970989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:08:54.543827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    bytes_0 = b't\x1c!\xab\xd0ND\xe7V\xac\xd6\x14\xa5\xefg'
    float_0 = -1983.7
    str_0 = "PW.Zbj\r'Ml:;!"
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 07:09:02.298966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    bytes_0 = b't\x1c!\xab\xd0ND\xe7V\xac\xd6\x14\xa5\xefg'
    float_0 = -1983.7
    str_0 = "PW.Zbj\r'Ml:;!"
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:09:13.698662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    bytes_0 = b't\x1c!\xab\xd0ND\xe7V\xac\xd6\x14\xa5\xefg'
    float_0 = -1983.7
    str_0 = "PW.Zbj\r'Ml:;!"
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)

    # Assume
    ansible_included_var_files_expected = [str_0]
    ansible_facts_expected = dict_0
    failed_expected = bool_0
    message_expected = str

# Generated at 2022-06-25 07:09:48.576784
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = True
    dict_1 = {bool_1: bool_1, bool_1: bool_1, bool_1: bool_1}
    bytes_1 = b'\x1a\xa3\xd57\xda\xef\x9f.\xdd~\xf7u\x1a\x87 A\n\x1a\xe6'
    float_1 = -1983.7
    str_1 = "PW.Zbj\r'Ml:;!"
    action_module_1 = ActionModule(bool_1, dict_1, bytes_1, float_1, str_1, bool_1)
    var_1 = action_run()

# SAGE Benchmark Metadata
# Benchmark Name: test_case_1
# Benchmark ID: 0
# Version: 0

# Generated at 2022-06-25 07:09:52.643428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_a = ActionModule()
    assert isinstance(obj_a, ActionModule)


# Generated at 2022-06-25 07:10:02.500392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    bytes_0 = b'\x1a\xa3\xd57\xda\xef\x9f.\xdd~\xf7u\x1a\x87 A\n\x1a\xe6'
    float_0 = -1983.7
    str_0 = "PW.Zbj\r'Ml:;!"
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)
    assert result == '<None>', var_0


# Generated at 2022-06-25 07:10:09.772200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()
    dict_18 = dict()
    dict_19 = dict()
    dict_20 = dict()
    dict_21 = dict()
    dict_22 = dict()
    dict_23 = dict()
    dict_24 = dict()

# Generated at 2022-06-25 07:10:20.626627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    bytes_0 = b'\x1a\xa3\xd57\xda\xef\x9f.\xdd~\xf7u\x1a\x87 A\n\x1a\xe6'
    float_0 = -1983.7
    str_0 = "PW.Zbj\r'Ml:;!"
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)
    var_0 = action_run()

    # Teardown
    del var_0

    return None

# This is the format of a unit test

# Generated at 2022-06-25 07:10:32.393368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    location = 'constants.py'
    value = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data/file.txt')
    try:
        os.unlink(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data/file.txt'))
    except:
        pass

    module_mock = mock.MagicMock(return_value=value)

# Generated at 2022-06-25 07:10:35.942599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    print("Debug: ActionModule: ", action_module)
    assert(action_module.__class__.__name__ == 'ActionModule')


# Generated at 2022-06-25 07:10:46.730225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor for class ActionModule
    """
    
    # TODO: it seems we are not able to generate the following three statements:
    # assert isinstance(self, ActionBase)
    # assert isinstance(self, ActionModule)
    # assert isinstance(self, DynamicLoader)
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # assert isinstance(facts, dict)
    
    
    
    
    
    
    # assert isinstance(included_files, list)
    
    
    
    
    
    # assert isinstance(filename, str)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-25 07:10:51.471913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = False
    dict_1 = {bool_1: bool_1, bool_1: bool_1, bool_1: bool_1}
    bytes_1 = b'\x1a\xa3\xd57\xda\xef\x9f.\xdd~\xf7u\x1a\x87 A\n\x1a\xe6'
    float_1 = -1983.7
    str_1 = "PW.Zbj\r'Ml:;!"
    action_module_1 = ActionModule(bool_1, dict_1, bytes_1, float_1, str_1, bool_1)
    return action_module_1

action_module_1 = test_ActionModule()
action_module_0 = test_ActionModule()
action_module_0._set_

# Generated at 2022-06-25 07:10:55.865250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    bytes_0 = b'\x1a\xa3\xd57\xda\xef\x9f.\xdd~\xf7u\x1a\x87 A\n\x1a\xe6'
    float_0 = -1983.7
    str_0 = "PW.Zbj\r'Ml:;!"
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:11:51.173661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Case 1
    bool_0 = bool()
    dict_0 = dict()
    bytes_0 = bytes(1)
    float_0 = float()
    str_0 = str()
    bool_1 = bool()
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_1)
    var_0 = action_module_0.run()
    assert var_0 == {'ansible_included_var_files': [], '_ansible_no_log': True, 'changed': False, 'ansible_facts': {}}
    # Case 2
    bool_2 = bool()
    dict_1 = dict()
    bytes_1 = bytes(1)
    float_1 = float()
    str_1 = str()
    bool_

# Generated at 2022-06-25 07:12:00.391251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = b'\x18\xa9\x9a\xe6\x1c\xaa\xf3\xef\xd6\x87\xe3\xcd\xfd\x07W\xe0\xfd\xd3\x08\x0f\r\xcd\xab\xde\xf9\xbe\x98\x1e\xf0\x8f\x84\x92\xf6\xac\x9c\x04\xee\x96\xfe\x03\x83\x98\xd1\xe4\x9f\x0b\xdd\x04g\xc7\n\xaaS\xa5\xca\xac\x9a\xdb\xf5\xb0\x04'
    var_1 = 7

# Generated at 2022-06-25 07:12:10.573700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    dict_0 = {}
    bytes_0 = b'\x00\x00'
    float_0 = '1.0'
    str_0 = "cl\x1dwqj\x12\x93"
    bool_1 = True
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_1)
    bool_0 = False
    dict_0 = {}
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00'
    float_0 = '1.0'
    str_0 = "l\x06\x87\x0c\x1f\x02\xf1\x0f\xef"
    bool_1

# Generated at 2022-06-25 07:12:18.795687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    bytes_0 = b'\x1a\xa3\xd57\xda\xef\x9f.\xdd~\xf7u\x1a\x87 A\n\x1a\xe6'
    float_0 = -1983.7
    str_0 = "PW.Zbj\r'Ml:;!"
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)
    action_module_0.run()
    action_module_0.run()
    var_0 = action_run()


# Generated at 2022-06-25 07:12:19.414687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:12:25.851033
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        tmp = None
        task_vars = None

        # Calling run method
        # Actual result is a dict object
        actual_result = ActionModule.run(self, tmp, task_vars)

        # Expected result is a dict object
        expected_result = {}

        assert actual_result == expected_result
    except Exception as e:
        print(e)
        raise AssertionError()

# Generated at 2022-06-25 07:12:35.291203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    bytes_0 = b'\x1a\xa3\xd57\xda\xef\x9f.\xdd~\xf7u\x1a\x87 A\n\x1a\xe6'
    float_0 = -1983.7
    str_0 = "\x1c\x8e\x18\xe1\x1f\xaa\x03\x94"
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)
    tmp = None
    task_vars = {}
    var_0 = action_module_run(action_module_0, tmp, task_vars)


# Generated at 2022-06-25 07:12:41.331060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    bytes_0 = b'\x1a\xa3\xd57\xda\xef\x9f.\xdd~\xf7u\x1a\x87 A\n\x1a\xe6'
    float_0 = -1983.7
    str_0 = "PW.Zbj\r'Ml:;!"
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:12:47.149898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing run...")

    # Setup
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    bytes_0 = b'\x1a\xa3\xd57\xda\xef\x9f.\xdd~\xf7u\x1a\x87 A\n\x1a\xe6'
    float_0 = -1983.7
    str_0 = "PW.Zbj\r'Ml:;!"
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)

    action_run()
    # Verification
    assert len(action_module_0.result) == 8
    assert action

# Generated at 2022-06-25 07:12:49.920536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock object
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)
    # Call method run on mock object
    action_module_0.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 07:14:38.142257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        tmp = None
        task_vars = None
        action_module_0 = ActionModule(None, None, None, None, None, None, None)
        var_0 = action_module_0.run(tmp, task_vars)
    except Exception as exception_0:
        print('Traceback (most recent call last): ')
        raise exception_0



# Generated at 2022-06-25 07:14:46.012347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = list()
    list_0.append(bool_0)
    list_0.append(bool_0)
    task_vars_0 = dict()
    task_vars_0['sorted_walk'] = list_0
    task_vars_0['data'] = list_0
    int_0 = 0
    task_vars_0['file_ext'] = int_0
    task_vars_0['current_root'] = list_0
    task_vars_0['current_files'] = list_0
    task_vars_0['list_0'] = list_0
    task_vars_0['current_dir'] = list_0
    task_vars_0['loaded_data'] = list_0
    task_vars_0

# Generated at 2022-06-25 07:14:54.607843
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module_0 = ActionModule()
  assert action_module_0._task is None
  assert action_module_0._connection is None
  assert action_module_0._play_context is None
  assert action_module_0._loader is None
  assert action_module_0._templar is None
  assert action_module_0._shared_loader_obj is None
  assert action_module_0._task_vars is None
  assert action_module_0._task_vars_injected is None
  assert action_module_0._loaded_frm_file is None
  assert action_module_0._filter_nones is False
  assert action_module_0._supports_check_mode is False
  assert action_module_0._supports_async is False

# Generated at 2022-06-25 07:14:59.901687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_ActionModule()
    ActionModule()
    ActionModule(None, None, None, None, None, None)
    test_case_0()


# Generated at 2022-06-25 07:15:07.986420
# Unit test for constructor of class ActionModule
def test_ActionModule():
  bool_0 = False
  dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
  bytes_0 = b'\x1a\xa3\xd57\xda\xef\x9f.\xdd~\xf7u\x1a\x87 A\n\x1a\xe6'
  float_0 = -1983.7
  str_0 = "PW.Zbj\r'Ml:;!"
  action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)

# Generated at 2022-06-25 07:15:08.694222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:15:12.826528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)
    arg_tmp = {action_module_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    arg_task_vars = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    ret_value = action_module_0.run(arg_tmp, arg_task_vars)
    assert ret_value


# Generated at 2022-06-25 07:15:18.027301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.vars import ActionModule
    #
    # Test for: action_take_action
    #

    # Test for: _set_args
    #

    # Test for: _set_dir_defaults
    #

    # Test for: _set_root_dir
    #

    # Test for: _traverse_dir_depth
    #

    # Test for: _ignore_file
    #

    # Test for: _is_valid_file_ext
    #

    # Test for: _load_files
    #

    # Test for: _load_files_in_dir
    #

    # Test for: run
    #

    params = dict()
    _task = None
    _connection = None
    _play_context = None
    loader = None
    templar = None

# Generated at 2022-06-25 07:15:23.279462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    bytes_0 = b'\x1a\xa3\xd57\xda\xef\x9f.\xdd~\xf7u\x1a\x87 A\n\x1a\xe6'
    float_0 = -1983.7
    str_0 = "PW.Zbj\r'Ml:;!"
    action_module_0 = ActionModule(bool_0, dict_0, bytes_0, float_0, str_0, bool_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:15:26.471716
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0 = ActionModule()
