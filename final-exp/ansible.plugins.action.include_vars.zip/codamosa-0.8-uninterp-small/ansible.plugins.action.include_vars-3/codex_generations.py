

# Generated at 2022-06-25 07:08:18.220353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'h'
    int_0 = 40
    float_0 = 0.2
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    assert action_module_0.data_source == 'h'
    assert action_module_0.playbook_dir == 'h'
    assert action_module_0.play_context == 'h'
    assert action_module_0.new_stdin == 40
    assert action_module_0.passed_args == 40
    assert action_module_0.debug_str == 'h'
    assert action_module_0.task_vars == 'h'
    assert action_module_0.task_include == 'h'
    assert action_module_0.default_v

# Generated at 2022-06-25 07:08:20.918802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('/etc/hosts', 'Path to hosts', '/etc/hosts', 0, 0, 0.5)
    assert type(action_module_0.run()) == dict


# Generated at 2022-06-25 07:08:24.856633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True # implement the test to verify that run works as expected

# Generated at 2022-06-25 07:08:27.016440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    value = 'Hello World'
    action_module_0 = ActionModule(value, value, value, value, value, value)
    assert action_module_0.run() is not None

# Generated at 2022-06-25 07:08:28.859368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_run() == False

# Generated at 2022-06-25 07:08:35.723690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '1)Qb0h.\x0bBl>gw(<DWYh'
    str_1 = 'Ma\x7fW:$S6G\x20\x17#3'
    str_2 = '\x0bLc].,&0aZ_\x16\x01\x0e'
    int_0 = 301
    int_1 = 6
    float_0 = 1.5
    action_module_0 = ActionModule(str_0, str_1, str_2, int_0, int_1, float_0)


# Generated at 2022-06-25 07:08:39.804309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test constructor")
    assert str_0 == str_0
    assert int_0 != int_0
    assert float_0 > float_0
    assert action_module_0 == action_module_0

    print("test method run()")
    assert var_0 == var_0

# Generated at 2022-06-25 07:08:49.634654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'V7hY\x0bz(JkcxZ`HX|\x0b0'
    str_1 = 'l+Y\n0\x0bq"4\x0bX|\x0bJ'
    float_0 = 9.0
    int_0 = 717
    action_module_0 = ActionModule(str_0, str_0, str_1, int_0, int_0, float_0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 07:08:54.078514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'B)pO\x06bH\r'
    int_0 = 0
    float_0 = 0.4
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    action_module_0.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 07:09:00.698439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0.included_files[0] == 'foo'
    assert action_module_0.included_files[1] == 'bar'
    assert action_module_0.included_files[2] == 'yaml'
    assert action_module_0.included_files[3] == 'json'
    assert action_module_0.included_files[4] == 'a'
    assert action_module_0.included_files[5] == 'b'
    assert action_module_0.included_files[6] == 'c'
    assert action_module_0.included_files[7] == '1'
    assert action_module_0.return_results_as_name == 'foo'
    assert action_module_0.hash_behaviour == 'replace'
   

# Generated at 2022-06-25 07:09:25.277164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()



# Generated at 2022-06-25 07:09:26.940453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert(action_module_0 is not None)


# Generated at 2022-06-25 07:09:34.263490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'R#8Om:p+=h\x0b.3<r]t\x7f'
    str_1 = '#{d\x7f:.\x0cV\x7fp.\x7f'
    int_0 = 301
    float_0 = 1.5
    str_2 = 'd]t\x7f'
    str_3 = '3<r]t\x7f'
    str_4 = '<^O\x7f(i\x7f'
    int_1 = 301
    float_0 = 1.5
    str_5 = '6?f.\x0b'
    str_6 = 'Qb0'
    str_7 = '6?f.\x0bBl>gw(<DWYh'


# Generated at 2022-06-25 07:09:38.460643
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'v5Nl,i;|X0f:\x0e\x0bL?W)0'
    int_0 = 12
    float_0 = 36.0
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    assert not hasattr(action_module_0, 'hash_behaviour')
    assert not hasattr(action_module_0, 'return_results_as_name')
    assert not hasattr(action_module_0, 'source_dir')
    assert not hasattr(action_module_0, 'source_file')
    assert not hasattr(action_module_0, 'depth')
    assert not hasattr(action_module_0, 'files_matching')
    assert not has

# Generated at 2022-06-25 07:09:39.412797
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # TODO: Fix the test case to pass
    test_case_0()


# Generated at 2022-06-25 07:09:46.981247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '1)Qb0h.\x0bBl>gw(<DWYh'
    int_0 = 301
    float_0 = 1.5
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    var_0 = action_module_0.run(None, None)
    assert var_0 == None

# Generated at 2022-06-25 07:09:51.427878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('\ntest_ActionModule_run()')
    str_0 = '1)Qb0h.\x0bBl>gw(<DWYh'
    int_0 = 301
    float_0 = 1.5
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    action_module_0.run()

# Generated at 2022-06-25 07:09:58.218465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'G\x1c(!\x16f\x0b\x04'
    int_0 = 677
    float_0 = 3.5
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:10:06.365316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '1)Qb0h.\x0bBl>gw(<DWYh'
    int_0 = 301
    float_0 = 1.5
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    assert action_module_0._role_name == '1)Qb0h.\x0bBl>gw(<DWYh'
    assert action_module_0._task_name == '1)Qb0h.\x0bBl>gw(<DWYh'
    assert action_module_0._play_name == '1)Qb0h.\x0bBl>gw(<DWYh'
    assert action_module_0._play_identifier == 301


# Generated at 2022-06-25 07:10:13.142209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '`k8dzW\x19y[\t'
    int_0 = 9
    dict_0 = dict()
    str_1 = 'x\x0b\x10\n{\\\x1dA\x18\x1e'
    bool_0 = bool()
    str_2 = 'rp}q\x0c'
    bool_1 = bool()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_2['s'] = dict_3
    dict_2['s']['s'] = dict_3
    dict_2['s']['s']['s'] = dict_3
    dict_1['s'] = dict_2['s']

# Generated at 2022-06-25 07:11:07.962589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '1)Qb0h.\x0bBl>gw(<DWYh'
    int_0 = 301
    float_0 = 1.5
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    assert 0 < len(action_module_0.VALID_FILE_EXTENSIONS)
    assert 0 < len(action_module_0.VALID_DIR_ARGUMENTS)
    assert 0 < len(action_module_0.VALID_FILE_ARGUMENTS)
    assert 0 < len(action_module_0.VALID_ALL)
    action_module_0._run()


# Generated at 2022-06-25 07:11:16.783521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Hello, World!'
    int_0 = 42
    float_0 = 3.14159265359
    str_1 = '1)Qb0h.\x0bBl>gw(<DWYh'
    int_1 = 301
    float_1 = 1.5

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()

# Generated at 2022-06-25 07:11:25.647772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '1)Qb0h.\x0bBl>gw(<DWYh'
    str_1 = '1)Qb0h.\x0bBl>gw(<DWYh'
    str_2 = '1)Qb0h.\x0bBl>gw(<DWYh'
    int_0 = 301
    int_1 = 301
    float_0 = 1.5
    __action_module_1 = ActionModule(str_0, str_1, str_2, int_0, int_1, float_0)



# Generated at 2022-06-25 07:11:33.698897
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ')0D6X-\x0b?Fc\\U!_aU8F.\x0b5'
    str_1 = '8X`W-;v/eI?Rp'
    str_2 = '!5vE%QP^qrpe\x0b>&;v/eI?Rp'
    int_0 = 748
    int_1 = 748
    float_0 = 1.5
    action_module_0 = ActionModule(str_0, str_1, str_2, int_0, int_1, float_0)
    var_0 = action_module_0.action_plugin_loader_path
    var_1 = action_module_0._task
    var_2 = action_module_0._connection

# Generated at 2022-06-25 07:11:34.332446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:11:37.026963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    var_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)


# Generated at 2022-06-25 07:11:44.588076
# Unit test for constructor of class ActionModule
def test_ActionModule():
    root_dir = 'vars'
    current_dir = 'main.yml'
    depth = 0
    hostname = 'localhost'
    port = 8383
    timeout = 60.0
    action_module_0 = ActionModule(root_dir, current_dir, depth, hostname, port, timeout)
    var_0 = action_run()
    assert(var_0 == dict())

# Generated at 2022-06-25 07:11:49.116533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    str_0 = '1)Qb0h.\x0bBl>gw(<DWYh'
    int_0 = 301
    float_0 = 1.5
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:11:59.048681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'f3qc%\x1aH\t\\'
    # Setup mock AnsibleTaskVars object
    mock_AnsibleTaskVars = MagicMock(spec=AnsibleTaskVars)

    mock_AnsibleTaskVars.vars.return_value.to_dict.return_value = {}
    mock_AnsibleTaskVars.get.return_value = None

    # Setup mock AnsibleActionBase object
    mock_AnsibleActionBase = MagicMock(spec=AnsibleActionBase)
    mock_AnsibleActionBase.run.return_value = str_0
    mock_AnsibleActionBase.vars.return_value = mock_AnsibleTaskVars

    # Setup test data for args

# Generated at 2022-06-25 07:12:08.258370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'G'
    int_0 = 300
    float_0 = 2.0
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    # Test trigger of assert
    try:
        action_module_0._task.args = dict()
        action_module_0._set_args()
        action_module_0._task.args['dir'] = 'vars'
        action_module_0._set_dir_defaults()
    except AssertionError:
        pass
    # Test trigger of AnsibleError

# Generated at 2022-06-25 07:13:46.223945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:13:48.842429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Constructor test
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    assert_equal(action_module_0.run(), var_0)

# Generated at 2022-06-25 07:13:49.936397
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:13:53.944080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 07:14:01.841803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '#:pV\x0e'
    str_1 = 'ZQx'
    int_0 = 22
    int_1 = 301
    int_2 = 31
    float_0 = 3.14
    float_1 = 1.5
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    action_module_0._task = str_1
    action_module_0._task._ds = str_1
    action_module_0._task._ds._data_source = str_1
    action_module_0._task._role = str_1
    action_module_0._task._role._role_path = str_1
    action_module_0._task._ds = str_1
    action

# Generated at 2022-06-25 07:14:12.904707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    os_sep = (os.sep)
    os_sep_str = "%s" % os_sep
    os_alt_sep = (os.altsep)
    os_alt_sep_str = "%s" % os_alt_sep
    if os_alt_sep == None:
        os_alt_sep_str = ''
    if os_sep == '\\':
        chr_0 = '\x00'
        chr_1 = '\x0f'
        int_0 = (((ord(chr_0) + ord(chr_1)) % (0x14 + 2)) + 0x10)

# Generated at 2022-06-25 07:14:17.628030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '1)Qb0h.\x0bBl>gw(<DWYh'
    int_0 = 301
    float_0 = 1.5
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    assert(not action_module_0)


# Generated at 2022-06-25 07:14:27.078994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    path_0 = action_module_0.source_dir
    setattr(action_module_0, '_task', path_0)
    int_0 = action_module_0.depth
    setattr(action_module_0, 'depth', int_0)
    path_0 = action_module_0.source_dir
    setattr(action_module_0, 'source_dir', path_0)
    action_module_0.show_content = True
    action_module_0.included_files = []
    action_module_0.source_file = ''
    action_module_0.return_results_as_name = ''
    action_module_0._set_args()
    action_module_0._set_root_dir()
    action_module_

# Generated at 2022-06-25 07:14:27.922430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule constructor')


# Generated at 2022-06-25 07:14:33.837428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '1)Qb0h.\x0bBl>gw(<DWYh'
    int_0 = 301
    float_0 = 1.5
    action_module_0 = ActionModule(str_0, str_0, str_0, int_0, int_0, float_0)
    var_0 = action_module_0.run(None)
