

# Generated at 2022-06-25 07:08:12.111305
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader

    test_ActionModule_0 = ActionModule(task=None, connection=None, play_context=None, loader=DataLoader(), templar=None, shared_loader_obj=None)

# Generated at 2022-06-25 07:08:13.971986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not(test_case_0())
    print("Test case 0 for constructor of class ActionModule passed.")



# Generated at 2022-06-25 07:08:17.603829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an object of the ActionModule class as am
    am = ActionModule()
    test_case_0()
    print ('test_case_0 executed')

# Main function call
if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:08:25.024253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ac_mod = ActionModule()
    ac_mod._task = MockTask()
    ac_mod._task._ds = MockDatasource()
    ac_mod._task._ds._data_source = MockDataSource()
    ac_mod._task._ds._data_source.split = lambda s: ['.']
    ac_mod._task._role = MockRole()
    ac_mod._task._role._role_path = '.'
    ac_mod._task._role._role_path.split = lambda s: ['.']
    ac_mod.run()


# Generated at 2022-06-25 07:08:33.675817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    # Declare mock objects
    action_module_instance = ActionModule()
    action_module_instance._task = mock.Mock()
    action_module_instance._connection = mock.Mock()
    action_module_instance._play_context = mock.Mock()
    action_module_instance._play_context.update = mock.Mock(return_value=None)
    action_module_instance._loader = mock.Mock()
    action_module_instance._loader._get_file_contents = mock.Mock(return_value=())
    action_module_instance._loader.load = mock.Mock(return_value={})
    action_module_instance._task.args = {}

    # Call method under test
    action_module_instance.run()

    #

# Generated at 2022-06-25 07:08:43.325963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'T'
    str_1 = '0'
    str_2 = 'X'
    str_3 = '['
    str_4 = '_'
    str_5 = '5'
    str_6 = '('
    str_7 = '/'
    str_8 = 'k'
    str_9 = 'g'
    str_10 = 'Z'
    str_11 = '4'
    str_12 = 'I'
    str_13 = 'D'
    str_14 = 'U'
    str_15 = '='
    str_16 = 's'
    str_17 = 'm'
    str_18 = '^'
    str_19 = 'C'
    str_20 = 'v'
    str_21 = 'O'

# Generated at 2022-06-25 07:08:53.503794
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Declarations
    ansible_facts = {'ansible_included_var_files': '', 'ansible_facts': {}}
    task_vars = {}
    tmp = None
    source_dir = None
    action_module = ActionModule()
    source_dir = 'dir'
    source_file = None
    source_file = 'file'
    if source_dir:
        action_module._set_dir_defaults()
    else:
        if source_file:
            action_module._find_needle()
        action_module.return_results_as_name = ''
        action_module.source_dir = ''
        action_module.source_file = ''
        action_module.depth = ''
        action_module.files_matching = ''
        action_module.ignore_files = ''


# Generated at 2022-06-25 07:08:54.402294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:08:58.227134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task={'args': {'foo': 'bar'}}, connection={'con_foo': 'bar'},
                                 play_context={'ctx_foo': 'bar'}, loader={'loader_foo':'bar'}, templar={'templar_foo': 'bar'},
                                 shared_loader_obj={'shared_loader_obj_foo': 'bar'})


# Generated at 2022-06-25 07:08:59.141562
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Running test_ActionModule...')
    test = ActionModule()

# Unit Test for test_case_0

# Generated at 2022-06-25 07:09:26.650601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None



if __name__ == '__main__':
    # Unit test for method run of class ActionModule
    test_ActionModule_run()


    print("All tests passed")

# Generated at 2022-06-25 07:09:36.499007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    root_dir = '/etc/ansible'
    file_name = 'test.yml'
    task_vars = {'task_vars': 'task_vars'}
    source_dir = '/tmp'
    depth = 0
    files_matching = None
    ignore_files = None
    extensions = ['yaml', 'yml']
    return_results_as_name = None
    source_file = 'test.yml'
    hash_behaviour = None
    ignore_unknown_extensions = False

    # Initializing mock object(s)
    _loader = mock.Mock()
    _task = mock.Mock()
    _task._role = mock.Mock()
    _task._ds = mock.Mock()
    _task._ds._data_source = mock.Mock()

    #

# Generated at 2022-06-25 07:09:39.102130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global var_0

    print("*** Test 1: case_0")
    test_case_0()
    if var_0 == None:
        print("Test 1 Passed")
    else:
        print("Test 1 Failed")

test_ActionModule()

# Generated at 2022-06-25 07:09:40.075005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m_action_0 = ActionModule()


# Generated at 2022-06-25 07:09:42.152796
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global var_0
    var_0 = ActionModule('data_0', 'data_1')
    var_0.test_case_0()
    return var_0.run()


# Generated at 2022-06-25 07:09:46.905977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    res = ActionModule(task = None, connection = None, play_context = None, loader = None, templar = None, shared_loader_obj = None)
    print("Object of constructor is: ", res)
    assert_equal(res.task, None)
    assert_equal(res.connection, None)
    assert_equal(res.play_context, None)
    assert_equal(res.loader, None)
    assert_equal(res.templar, None)
    assert_equal(res.shared_loader_obj, None)


# Generated at 2022-06-25 07:09:51.122014
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Initialize an instance of class ActionModule
    am = ActionModule()

    # The following is a minimal set of argument values to invoke method run
    task_vars = dict()

    # Invoke method run on instance of class ActionModule to run a unit test
    # The arguments for this method are optional and the default values are shown
    am.run(task_vars)



# Generated at 2022-06-25 07:10:02.015987
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:10:09.440853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    action = ansible.plugins.action.ActionModule(
        {'name': 'test', 'hash_behaviour': None, 'dir': None, 'file': None, '_raw_params': None, 'depth': None, 'files_matching': None, 'ignore_files': None, 'extensions': None, 'ignore_unknown_extensions': False},
        {'vars': dict(), 'path': '/home/user', 'role_names': [], '_role': test_case_0, 'task_vars': dict()},
        'localhost',
        )
    # TODO: Implement
    action.run()

    ret = action.run()
    # TODO: Implement
    if "ansible_included_var_files" in ret:
        raise NotImplementedError
   

# Generated at 2022-06-25 07:10:11.004038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None


# Generated at 2022-06-25 07:10:37.293575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 07:10:39.265462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\nUnit Test: Constructor of class ActionModule")
    action = ActionModule()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 07:10:41.526125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    var_0 = test_case_0()

#  Main function
if __name__ == "__main__":
    test_ActionModule()
    print('Tests Passed')

# Generated at 2022-06-25 07:10:46.863206
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass
    # obj = ActionModule()
    # assert obj._set_dir_defaults()
    # assert obj._set_args()
    # assert obj.run(tmp=None, task_vars=None)
    # assert obj._set_root_dir()
    # assert obj._traverse_dir_depth()
    # assert obj._ignore_file(filename)
    # assert obj._is_valid_file_ext(source_file)
    # assert obj._load_files(filename, validate_extensions=False)
    # assert obj._load_files_in_dir(root_dir, var_files)


# Generated at 2022-06-25 07:10:50.674186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ds = None
        name = None
        task_include = "/manifests/init.pp"
        task_vars = None
        templar = None
        action = "include_vars"
        args = {'name': name}
        action_loader = None
        task_loader = None
        variable_manager = None
        loader = None
        # ActionModule(ds, task_include, task_vars, templar, action, args, action_loader, task_loader, variable_manager, loader)
    except Exception as error:
        raise AssertionError(error)


# Generated at 2022-06-25 07:10:51.351204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:10:56.182186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = None

    # Invoke method
    var_2 = test_case_0()

# Generated at 2022-06-25 07:10:59.436060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_1 = ActionModule()
    test_1._task = None
    test_case_0()


# Generated at 2022-06-25 07:11:00.309116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 07:11:06.286145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_vars = dict()
    vars_file = None
    tmp_path = None
    task_vars = dict()
    action_module = ActionModule(None, task_vars, host_vars, vars_file, tmp_path)
    action_module._set_args()
    action_module._set_root_dir()
    action_module.run()


# Generated at 2022-06-25 07:11:37.396416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'C'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    bytes_0 = b'D'
    int_0 = 442
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_1.update(dict_0)
    dict_2 = dict()
    dict_2['ansible_included_var_files'] = []
    dict_2['ansible_facts'] = dict()
    dict_2['_ansible_no_log'] = True
    dict_1.update(dict_2)
    dict_1.update(dict_2)
    dict_3 = dict()

# Generated at 2022-06-25 07:11:45.040079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\\:0.'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    bytes_0 = b'=Mw+'
    int_0 = 699
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    action_module_0.run()


# Generated at 2022-06-25 07:11:53.414938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup
    act_mod = ActionModule(
        'hoge', False, set(), False, b'=Mw+', 699)

    # Test case
    assert act_mod.included_files == list()
    assert act_mod.matcher is None
    assert act_mod.return_results_as_name == None
    assert act_mod.source_dir == None
    assert act_mod.source_file == None
    assert act_mod.depth == None
    assert act_mod.files_matching == None
    assert act_mod.ignore_files == None
    assert act_mod.valid_extensions == [
        'yaml', 'yml', 'json'
    ]
    assert act_mod.ignore_unknown_extensions == False

# Generated at 2022-06-25 07:11:58.758492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\\:0.'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    bytes_0 = b'=Mw+'
    int_0 = 699
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    assert(action_module_0)


# Generated at 2022-06-25 07:12:04.894992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    in_path = './tests/example_vars'

    obj = ActionModule(in_path, None, None, None, None, None)

    assert obj.depth == 0
    assert obj.files_matching.pattern == '.*'
    assert obj.ignore_files == []
    assert obj.ignore_unknown_extensions == False
    assert obj.hash_behaviour == None


# Generated at 2022-06-25 07:12:05.948670
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:12:17.817099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = [
        '\\:0.',
        '#\\/',
        '*L-\'',
        'J.5I',
        '5&Q{',
        '/*.'
    ]

# Generated at 2022-06-25 07:12:27.836398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '*D7V'
    bool_0 = True
    set_0 = set({})
    bool_1 = False
    bytes_0 = b'^'
    int_0 = 405
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    assert isinstance(action_module_0, ActionModule) == True
    assert action_module_0.TRANSFERS_FILES == False
    str_0 = '.1f`'
    str_1 = 'y6jM'
    assert action_module_0.VALID_FILE_EXTENSIONS[0] == str_0
    assert action_module_0.VALID_FILE_EXTENSIONS[1] == str_1

# Generated at 2022-06-25 07:12:36.406415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    setup_playbook_yml = '{{playbook_dir}}/tasks/main.yml'
    constructor_name = '{{playbook_dir}}/tasks/setup.yml'
    expect = {'ansible_included_var_files': ['{{playbook_dir}}/tasks/main.yml'], 'ansible_facts': {}, '_ansible_no_log': True}
    real_result = action_run(setup_playbook_yml, constructor_name)
    if real_result == expect:
        print(ACTION_MODULE_TEST_SUCCESS_MESSAGE.format(constructor_name, ACTION_MODULE_SUCCESS))

# Generated at 2022-06-25 07:12:37.225306
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 07:13:43.055356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\\!<4-h'
    bool_0 = True
    set_0 = {'#': True}
    bool_1 = False
    bytes_0 = b'\x95\xb6\xfa\x9a\xf7\xf2'
    int_0 = 614
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    int_1 = action_module_0.run()
    assert int_1 == 614



# Generated at 2022-06-25 07:13:48.648476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up parameters
    ansible_included_var_files = ''
    ansible_facts = dict()
    _ansible_no_log = True
    task_vars = dict()
    set_0 = set()
    bool_0 = False
    bool_1 = False
    bytes_0 = b'j'
    int_0 = -12
    action_module_0 = ActionModule('', bool_0, set_0, bool_1, bytes_0, int_0)
    # invoke and check
    var_0 = action_module_0.run(task_vars=task_vars)

# Generated at 2022-06-25 07:13:51.777439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\\:0.'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    bytes_0 = b'=Mw+'
    int_0 = 699
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)

    assert not hasattr(action_module_0, '_action_plugins')



# Generated at 2022-06-25 07:14:00.281630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test 0
    #
    # Test case
    str_0 = '\\:0.'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    bytes_0 = b'=Mw+'
    int_0 = 699
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    var_0 = action_run()
    #
    # Test 1
    #
    # Test case
    str_0 = '*&o#'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    bytes_0 = b'h++l'
    int_0 = 110

# Generated at 2022-06-25 07:14:08.323886
# Unit test for constructor of class ActionModule
def test_ActionModule():
    error_msg_0 = 'Failed to construct object of class ActionModule'
    raise_exception(error_msg_0)
    action_module_0 = ActionModule("q")
    str_0 = 'c'
    bool_0 = True
    set_0 = set()
    bool_1 = False
    bytes_0 = b'Y'
    int_0 = 776
    action_module_1 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    str_1 = '?'
    bool_2 = True
    set_1 = set()
    bool_3 = False
    bytes_1 = b'+'
    int_1 = 645

# Generated at 2022-06-25 07:14:16.533820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '?/f\\$'
    bool_0 = False
    set_0 = set()
    bool_1 = True
    bytes_0 = b'=Mw+'
    int_0 = 699
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    var_0 = action_module_0.run()
    var_1 = action_module_0.run(task_vars_0)
    var_2 = action_module_0.run(task_vars_1)
    var_3 = action_module_0.run(task_vars_0, )
    var_4 = action_module_0.run(task_vars_1, )

# Generated at 2022-06-25 07:14:26.281027
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\\:0.'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    bytes_0 = b'=Mw+'
    int_0 = 699
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    str_1 = '\\:0.'
    bool_2 = False
    set_1 = set()
    bool_3 = False
    bytes_1 = b'=Mw+'
    int_1 = 699
    action_module_1 = ActionModule(str_1, bool_2, set_1, bool_3, bytes_1, int_1)
    assert action_module_0 is not None
    assert action_module_1 is not None

# Generated at 2022-06-25 07:14:27.404582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('', False, {}, False, b'', 0)


# Generated at 2022-06-25 07:14:37.720346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Define arguments
    str_0 = '\\:0.'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    bytes_0 = b'=Mw+'
    int_0 = 699
    # Instantiate class
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    # Assert type of object
    assert isinstance(action_module_0, ActionModule)
    # Evaluate true branch

# Generated at 2022-06-25 07:14:42.103506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '>|!'
    bool_0 = True
    set_0 = set()
    bool_1 = False
    bytes_0 = b'=Mw+'
    int_0 = 699
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:17:19.583020
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Args:
    #     self ():
    #     task ():
    #     connection ():
    #     play_context ():
    #     loader ():
    #     templar ():
    #     shared_loader_obj ():
    
    task = AnsibleTask()
    connection = AnsibleConnection()
    play_context = AnsiblePlayContext()
    loader = DataLoader()
    templar = AnsibleTemplar()
    shared_loader_obj = AnsibleLoader()
    
    action_module_0 = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 07:17:28.402898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\\:0.'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    bytes_0 = b'=Mw+'
    int_0 = 699
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    str_1 = 'p>*F'
    dict_0 = dict()
    tuple_0 = action_module_0.run(str_1, dict_0)
    assert len(tuple_0) == 3
    assert isinstance(tuple_0, tuple)
    assert tuple_0[0] is False
    assert isinstance(tuple_0[0], bool)
    assert tuple_0[1] == ''

# Generated at 2022-06-25 07:17:33.614685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '|/2W8'
    bool_0 = False
    set_0 = set()
    bool_1 = True
    bytes_0 = b'{8%c'
    int_0 = 888
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    var_0 = action_module_0.run('tmp', dict())
    var_1 = action_module_0.run('tmp', None)
    var_2 = action_module_0.run(None, dict())
    var_3 = action_module_0.run(None, None)


# Generated at 2022-06-25 07:17:37.580197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\\KQ*'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    bytes_0 = b'\x01'
    int_0 = -90
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    var_0 = action_run()
    return var_0


# Generated at 2022-06-25 07:17:45.509828
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'arbitrary test string'
    bool_0 = True
    set_0 = set(['9f', 'dk', 'eR7'])
    bool_1 = False
    bytes_0 = b'35E6'
    int_0 = 26
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    int_1 = 1
    int_2 = 0
    dict_0 = dict()
    dict_1 = dict()
    dict_0['8sbv'] = dict_1
    dict_2 = dict()
    dict_1['i'] = dict_2
    dict_2['3q'] = dict_1
    list_0 = list()
    dict_3 = dict()
    dict_4

# Generated at 2022-06-25 07:17:53.476589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'm=M\x15*;\x0b\x0c\x1e\x1d'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    bytes_0 = b'vG,\x1c'
    int_0 = 1
    action_module_0 = ActionModule(str_0, bool_0, set_0, bool_1, bytes_0, int_0)
    var_0 = action_module_0.run()
    print(var_0)