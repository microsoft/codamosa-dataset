

# Generated at 2022-06-25 07:08:16.683230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = float()
    dict_0 = dict()
    int_0 = 0
    bool_0 = bool()
    action_module_0 = ActionModule(float_0, dict_0, dict_0, int_0, float_0, bool_0)
    str_0 = str()
    dict_1 = dict()
    result = action_module_0.run(str_0, dict_1)
    assert result != None

# Generated at 2022-06-25 07:08:17.392591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True == True


# Generated at 2022-06-25 07:08:18.307510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:08:21.943574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_1 = {}
    dict_2 = {}
    int_1 = 0
    float_1 = None
    bool_1 = False
    action_module_1 = ActionModule(dict_1, dict_2, dict_2, int_1, float_1, bool_1)


# Generated at 2022-06-25 07:08:23.115141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  print("Testing run of class ActionModule")
  test_case_0()

# Generated at 2022-06-25 07:08:26.325470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {}
    dict_1 = {}
    int_0 = -880
    float_1 = None
    bool_0 = True
    action_module_0 = ActionModule(float_0, dict_0, dict_1, int_0, float_1, bool_0)


# Generated at 2022-06-25 07:08:36.239950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    dict_1 = {'dir': '/tmp/dir/', 'depth': 0}
    dict_2 = {'dir': '/tmp/dir/', 'depth': 0}
    dict_3 = {'dir': '/tmp/dir/', 'depth': 0}
    dict_4 = {'dir': '/tmp/dir/', 'depth': 0}
    dict_5 = {'dir': '/tmp/dir/', 'depth': 0}
    dict_6 = {'dir': '/tmp/dir/', 'depth': 0}
    dict_7 = {'dir': '/tmp/dir/', 'depth': 0}
    dict_8 = {'dir': '/tmp/dir/', 'depth': 0}
    dict_9 = {'dir': '/tmp/dir/', 'depth': 0}
    dict_

# Generated at 2022-06-25 07:08:37.567261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:08:41.220801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {}
    int_0 = -880
    bool_0 = True
    action_module_0 = ActionModule(float_0, dict_0, dict_0, int_0, float_0, bool_0)


# Generated at 2022-06-25 07:08:52.724849
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Set up test values
    tmp = None
    task_vars = None
    float_0 = None
    dict_0 = {}
    int_0 = -880
    bool_0 = True
    action_module_0 = ActionModule(float_0, dict_0, dict_0, int_0, float_0, bool_0)
    action_module_0._set_dir_defaults()
    action_module_0._set_args()
    action_module_0._set_root_dir()
    for root_dir, filenames in action_module_0._traverse_dir_depth():
        failed, err_msg, updated_results = (action_module_0._load_files_in_dir(root_dir, filenames))
        if failed:
            break

# Generated at 2022-06-25 07:09:24.344002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Boolean to test whether the ActionModule class is defined
    is_class_defined = False
    try:
        # Try to use or define ActionModule
        try:
            ActionModule
        except NameError:
            class ActionModule:
                pass
        is_class_defined = True
        # Check the class type (constructor)
        assert(type(ActionModule) == type(type))
    except AssertionError:
        # Print traceback if the class cannot be used or defined
        traceback.print_exc()
    # Print whether the class is defined or not
    print('Is ActionModule class defined? : {}'.format(is_class_defined))


# Generated at 2022-06-25 07:09:25.743899
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False, 'Need unit test for constructor of class ActionModule'


# Generated at 2022-06-25 07:09:30.597198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Creating objects
    set_0 = {'pG'}
    list_0 = [set_0, set_0, set_0]
    str_0 = 'r5"iC}'
    int_0 = 1876
    str_1 = 'x|f=_p'
    int_1 = 2124
    set_1 = {str_0, (('= vX' + str_0) + 'u!iwa'), int_1}
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, str_1, int_1, set_1, bool_0)
    # Calling methods
    var_0 = action_module_0.run(list_0)

# Generated at 2022-06-25 07:09:41.116887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    str_0 = 'RQ]N1vwRFRaG\x0cCG'
    int_0 = 3701
    str_1 = '~^cx?%ep'
    set_1 = {str_0, str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, str_1, int_0, set_1, bool_0)
    dict_0 = {}

# Generated at 2022-06-25 07:09:52.237889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(">> Testing constructor:")
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    str_0 = 'RQ]N1vwRFRaG\x0cCG'
    int_0 = 3701
    str_1 = '~^cx?%ep'
    set_1 = {str_0, str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, str_1, int_0, set_1, bool_0)
    # Call _set_args()
    action_module_0._set_args()
    # Check if method could run successfully
    print("## Unit test result: %s" % action_module_0)

test_ActionModule()

# Generated at 2022-06-25 07:09:56.699091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule(str_2, int_1, str_3, int_2, set_2, bool_1)


# Generated at 2022-06-25 07:10:06.657360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    str_0 = 'RQ]N1vwRFRaG\x0cCG'
    int_0 = 3701
    str_1 = '~^cx?%ep'
    set_1 = {str_0, str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, str_1, int_0, set_1, bool_0)
    var_0 = action_run(list_0)


# Generated at 2022-06-25 07:10:11.149767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '-_W\x7fZ4KRM'
    int_0 = 9535
    str_1 = 'pK`N3b)W\x7f|2'
    int_1 = 5226
    set_0 = {str_1}
    bool_0 = True
    action_module_0 = ActionModule(str_0, int_0, str_1, int_1, set_0, bool_0)


# Generated at 2022-06-25 07:10:16.669571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Simple assignment
    x = ActionModule(dict, int, str, int, set, bool)
    # Simple call
    y = x.run()


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:10:20.827588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = set()
    var_1 = [var_0, var_0, var_0]
    var_2 = 'RQ]N1vwRFRaG\x0cCG'
    var_3 = 3701
    var_4 = '~^cx?%ep'
    var_5 = {var_2, var_2, var_2}
    var_6 = False
    var_7 = ActionModule(var_2, var_3, var_4, var_3, var_5, var_6)
    var_8 = var_7.run(var_1)
    var_9 = dict(var_8)
    var_10 = var_9.get('ansible_included_var_files')
    var_11 = var_9.get('ansible_facts')

# Generated at 2022-06-25 07:11:13.228350
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    str_0 = 'RQ]N1vwRFRaG\x0cCG'
    int_0 = 3701
    str_1 = '~^cx?%ep'
    set_1 = {str_0, str_0, str_0}
    bool_0 = False
    int_1 = 67880
    str_2 = 'x\x0c\x0b<dum\ni'
    dict_0 = dict()
    dict_0['task_vars']=dict()
    dict_0['task_vars']['ansible_facts']=dict()

# Generated at 2022-06-25 07:11:19.726532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    str_0 = 'RQ]N1vwRFRaG\x0cCG'
    int_0 = 3701
    str_1 = '~^cx?%ep'
    set_1 = {str_0, str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, str_1, int_0, set_1, bool_0)


# Generated at 2022-06-25 07:11:20.920863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _set_dir_defaults()
    _set_args()
    run()


# Generated at 2022-06-25 07:11:22.593743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(str_0, int_0, str_1, int_0, set_1, bool_0)


# Generated at 2022-06-25 07:11:24.826059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    set_1 = set()
    str_0 = 'KG'
    bool_0 = False
    action_module_0 = ActionModule(set_0, set_1, str_0, bool_0)


# Generated at 2022-06-25 07:11:33.077067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor without arguments
    # TODO: fix constructor to accept variable number of arguments
    # action_module_0 = ActionModule()
    # Verify that instance variables were set correctly
    assert action_module_0.matcher == None, 'Expected None, got {0}'.format(action_module_0.matcher)
    assert action_module_0.hash_behaviour == None, 'Expected None, got {0}'.format(action_module_0.hash_behaviour)
    assert action_module_0.return_results_as_name == None, 'Expected None, got {0}'.format(action_module_0.return_results_as_name)

# Generated at 2022-06-25 07:11:36.686457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    str_0 = 'RQ]N1vwRFRaG\x0cCG'
    int_0 = 3701
    str_1 = '~^cx?%ep'
    set_1 = {str_0, str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, str_1, int_0, set_1, bool_0)
    assert action_module_0 != None

# Generated at 2022-06-25 07:11:47.020906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = list()
    list_0.append('a')
    list_0.append('b')
    list_0.append('c')
    set_0 = set()
    list_0_0 = [list_0, list_0, list_0, set_0, list_0]
    str_0 = 'v'
    str_1 = 'i5Uaxg,X\x0c#'
    set_1 = {str_0, str_1, str_0}
    action_module_0 = ActionModule(str_0, str_1, set_1, str_0, list_0_0)
    var_0 = action_run(list_0)


# Generated at 2022-06-25 07:11:59.129592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case 0
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    str_0 = 'RQ]N1vwRFRaG\x0cCG'
    int_0 = 3701
    str_1 = '~^cx?%ep'
    set_1 = {str_0, str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, str_1, int_0, set_1, bool_0)

    assert action_module_0 is not None

    # Test case 1
    str_0 = '~0a@,V'
    int_0 = 8
    str_1 = 'KjN.s9'
    int_1 = 1

# Generated at 2022-06-25 07:12:06.901049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    str_0 = 'RQ]N1vwRFRaG\x0cCG'
    int_0 = 3701
    str_1 = '~^cx?%ep'
    set_1 = {str_0, str_0, str_0}
    bool_0 = False
    del set_0
    del set_1
    del list_0
    del str_0
    del str_1
    del int_0
    del bool_0


# Generated at 2022-06-25 07:13:47.941728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    str_0 = 'RQ]N1vwRFRaG\x0cCG'
    int_0 = 3701
    str_1 = '~^cx?%ep'
    set_1 = {str_0, str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, str_1, int_0, set_1, bool_0)
    action_module_1 = ActionModule(str_0, int_0, str_1, int_0, set_1, bool_0)

# Generated at 2022-06-25 07:13:53.321236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\'4./F@dTtQnT'
    int_0 = -2746
    str_1 = '~^cx?%ep'
    int_1 = 3701
    set_0 = {'-9J\x03\x17\x1c', '-9J\x03\x17\x1c', '-9J\x03\x17\x1c'}
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, str_1, int_1, set_0, bool_0)
    str_2 = 'U6#^$8XdD*M'

# Generated at 2022-06-25 07:14:00.576276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    str_0 = 'RQ]N1vwRFRaG\x0cCG'
    int_0 = 3701
    str_1 = '~^cx?%ep'
    set_1 = {str_0, str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, str_1, int_0, set_1, bool_0)
    var_0 = action_run(list_0)


# Generated at 2022-06-25 07:14:07.237655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    str_0 = 'RQ]N1vwRFRaG\x0cCG'
    int_0 = 3701
    str_1 = '~^cx?%ep'
    set_1 = {str_0, str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, str_1, int_0, set_1, bool_0)
    var_0 = action_module_0.run(list_0)


# Generated at 2022-06-25 07:14:14.897175
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test_case_0
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    str_0 = 'RQ]N1vwRFRaG\x0cCG'
    int_0 = 3701
    str_1 = '~^cx?%ep'
    set_1 = {str_0, str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, str_1, int_0, set_1, bool_0)
    var_0 = action_module_0.run(list_0)



# Generated at 2022-06-25 07:14:20.362195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    str_0 = 'RQ]N1vwRFRaG\x0cCG'
    int_0 = 3701
    str_1 = '~^cx?%ep'
    set_1 = {str_0, str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, str_1, int_0, set_1, bool_0)
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_4['name'] = '^cx?%ep'
    dict_4[str_0] = dict_

# Generated at 2022-06-25 07:14:27.497319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    str_0 = 'RQ]N1vwRFRaG\x0cCG'
    int_0 = 3701
    str_1 = '~^cx?%ep'
    set_1 = {str_0, str_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, int_0, str_1, int_0, set_1, bool_0)
    var_0 = action_module_0.run(list_0)



# Generated at 2022-06-25 07:14:37.797001
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ''.join(sys.argv[1:])
    var_0 = var_0.split(':')
    var_1 = ''.join(sys.argv[1:])
    var_1 = var_1.split(':')
    var_1 = var_1[-1]
    var_1 = var_1.split('=')
    var_1 = var_1[-1]
    var_1 = int(var_1)
    var_2 = ''.join(sys.argv[1:])
    var_2 = var_2.split(':')
    var_2 = var_2[-2]
    var_2 = var_2.split('=')
    var_2 = var_2[-1]

# Generated at 2022-06-25 07:14:42.740903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  t1 = ("RQ]N1vwRFRaG\x0cCG", 3701, "~^cx?%ep", 3701, {"RQ]N1vwRFRaG\x0cCG", "RQ]N1vwRFRaG\x0cCG", "RQ]N1vwRFRaG\x0cCG"}, False)
  t2 = ()
  assert(equals(test_case_0(), None))

test_ActionModule_run()

# Generated at 2022-06-25 07:14:51.220325
# Unit test for constructor of class ActionModule
def test_ActionModule():
	# Create the task and the task_vars
    task_0 = dict()
    task_vars_0 = dict()

	# Create a TaskExecutor
    task_executor_0 = TaskExecutor(task_0, task_vars_0, False)

	# Create an instance of ActionModule
    action_module_0 = ActionModule(task_executor_0, 'tmp', task_vars_0)

    # Compare the classes of action_module_0 and TaskExecutor
    if not isinstance(action_module_0, TaskExecutor):
        print('Expected %s, but got %s' % (TaskExecutor, type(action_module_0)))
        return False
    else:
        return True

# Greedy search