

# Generated at 2022-06-25 07:08:19.490475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    int_0 = None
    dict_1 = {int_0: int_0}
    bytes_0 = b'\xcd\xd6\x0b\xcd\x11\xb4\xcd\x9b\x16\x80\xcd\x16n\xcd'
    dict_2 = {bytes_0: dict_0}
    list_0 = [int_0, int_0, bytes_0]
    dict_3 = {bytes_0: list_0}
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    int_1 = 0

# Generated at 2022-06-25 07:08:26.944483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 15417401166719763650
    str_0 = '{0}'.format(int_0)
    str_1 = 'c\xfe\x98\x18\x1f\x01\xe2\x9a\x08'
    bytes_0 = b'\xe5\xe1\xe6p\xd6\xfc\x90\xa9\x8f\x84\xc5\x82\x0f\x93\xfc\xa0\xdf\x9a\xdf\x1c=\xac'
    list_0 = [bytes_0, str_0, str_1, str_1]
    dict_0 = {str_0: list_0}

# Generated at 2022-06-25 07:08:29.811718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    return True

if __name__ == '__main__':
    print (test_ActionModule())

# Generated at 2022-06-25 07:08:38.700420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    desc_0 = '\x03\xd0\x07s'
    dict_0 = {desc_0: desc_0}
    bytes_0 = b'\x1b\xda\xb3\xafQ\xbb\xaf\x1f\x91\x0e\x86'
    dict_1 = {desc_0: desc_0}
    list_0 = [desc_0, desc_0, bytes_0, desc_0]
    action_module_0 = ActionModule(dict_0, bytes_0, dict_1, list_0, list_0, dict_0)
    dict_2 = {desc_0: bytes_0}
    action_module_0.run(dict_2)

# Generated at 2022-06-25 07:08:44.476366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    dict_0 = {int_0: int_0}
    bytes_0 = b'N\x1f\xa5\x11\xcd\xa1_\xa8A\x14'
    list_0 = [int_0, int_0, bytes_0]
    action_module_0 = ActionModule(dict_0, bytes_0, dict_0, list_0, list_0, dict_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:08:46.107735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:08:50.065996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    dict_0 = dict()
    dict_0['key_0'] = 'val_0'
    dict_0['key_1'] = 'val_1'
    action_module_0.run(task_vars=dict_0)

# Generated at 2022-06-25 07:08:53.531580
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    tmp_0 = None
    task_vars_0 = None
    str_0 = action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:09:02.397237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = random.randint(-100, 100)
    int_1 = random.randint(-100, 100)
    str_0 = str(random.randint(-100, 100))
    str_1 = str(random.random())
    str_2 = str(random.randint(-100, 100))
    str_3 = str(random.random())
    bytearray_0 = bytearray(100)
    str_4 = str(random.random())
    str_5 = str(random.randint(-100, 100))
    str_6 = str(random.random())
    str_7 = str(random.randint(-100, 100))
    str_8 = str(random.random())
    str_9 = str(random.randint(-100, 100))

# Generated at 2022-06-25 07:09:13.699312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_1 = {'role_path': '', '_ds': {'_data_source': './roles/role1/vars/main.yml'}, '_role': {'_role_path': './roles/role1'}, 'args': {'dir': 'vars3', '_raw_params': 'vars3', 'hash_behaviour': 'replace', 'name': None}}

# Generated at 2022-06-25 07:09:50.961154
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:09:57.604003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("ActionModule test case 1")
    test_obj = ActionModule(
        "/Users/harryzhang/raw/AppiumTest/Git/appium-test/appium-test/appium/ansible_play/tasks/include_vars.yml",
        "/Users/harryzhang/raw/AppiumTest/Git/appium-test/appium-test/appium/ansible_play/tasks",
        "ansible_play",
        "include_vars"
    )
    print(test_obj)



# Generated at 2022-06-25 07:10:01.437518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    test_case_0()


# Generated at 2022-06-25 07:10:08.989585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test presence of class ActionModule
    try:
        test_case_0()
        print('test_case_0: pass')
    except:
        print('test_case_0: fail')

    # Test presence of method _set_dir_defaults
    try:
        test_case_1()
        print('test_case_1: pass')
    except:
        print('test_case_1: fail')

    # Test presence of method _set_args
    try:
        test_case_2()
        print('test_case_2: pass')
    except:
        print('test_case_2: fail')

    # Test presence of method run

# Generated at 2022-06-25 07:10:14.666697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 07:10:19.534326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(m, ActionModule)


# Generated at 2022-06-25 07:10:24.673324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act_module = ActionModule()
    assert (act_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'])
    assert (act_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'])
    assert (act_module.TRANSFERS_FILES == False)
    assert (act_module.VALID_FILE_ARGUMENTS == ['file', '_raw_params'])
    assert (act_module.VALID_ALL == ['name', 'hash_behaviour'])
    test_case_0()
    act_module._set_dir_defaults()
    act_module._set_args()
    tmp = None
    task_vars = None


# Generated at 2022-06-25 07:10:34.591302
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No args
    task_vars = dict()
    tmp = [None]
    task_vars['result'] = False
    task_vars['result_message'] = ''
    tmp.append(task_vars)
    task_vars['ansible_included_var_files'] = ['test_case_0']
    task_vars['ansible_facts'] = dict()
    task_vars['_ansible_no_log'] = [True]
    tmp.append(task_vars)
    ac = ActionModule()
    ac._task = 'task_0'
    ac._task._role = True
    ac._task._role._role_path = 'test_case_0'
    ac._task._ds = True
    ac._task._ds._data_source = 'test_case_0'

# Generated at 2022-06-25 07:10:46.633515
# Unit test for constructor of class ActionModule
def test_ActionModule():
    string_0 = 'xr9X@uV7'
    string_1 = ')0F!P{(}'
    string_2 = '8T+T_p7V'
    string_3 = '8T+T_p7V'
    string_4 = '8T+T_p7V'
    string_5 = '8T+T_p7V'
    string_6 = '8T+T_p7V'
    string_7 = '8T+T_p7V'
    string_8 = '8T+T_p7V'
    string_9 = '8T+T_p7V'
    string_10 = '8T+T_p7V'
    string_11 = '8T+T_p7V'

# Generated at 2022-06-25 07:10:51.427729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('testing ActionModule constructor')
    return_value = True
    return return_value


# Generated at 2022-06-25 07:11:45.289745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    path_0 = ActionModule()
    path_1 = path_0.run(tmp=None, task_vars={'test_succeeded': True})
    if (path_1['ansible_facts'] != {}):
        test_case_0()


# Generated at 2022-06-25 07:11:55.895115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize the class, then verify that its instance variables are correct
    action_module = ActionModule()
    assert action_module.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'], "action_module.VALID_FILE_EXTENSIONS is not equal to ['yaml', 'yml', 'json']"
    assert action_module.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'], 'action_module.VALID_DIR_ARGUMENTS is not equal to [\'dir\', \'depth\', \'files_matching\', \'ignore_files\', \'extensions\', \'ignore_unknown_extensions\']'
    assert action_module.VALID_FILE_ARGUMENTS

# Generated at 2022-06-25 07:12:02.104429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=None,
        connection=None,
        _play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    bool_0 = True



# Generated at 2022-06-25 07:12:09.586579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    vars_0 = dict()
    inst_0 = ActionModule(vars_0)
    vars_1 = dict()
    vars_1['hash_behaviour'] = C.DEFAULT_HASH_BEHAVIOUR
    vars_1['name'] = 'run_0'
    vars_1['_raw_params'] = '"/Users/allen/Source/ansible/lib/ansible/plugins/modules/vars/next_var.yml"'
    vars_1['_ansible_module_name'] = 'TestModule'
    vars_1['_ansible_module_name'] = 'TestModule'
    vars_1['_ansible_module_name'] = 'TestModule'
    vars_1['_ansible_module_name'] = 'TestModule'
    v

# Generated at 2022-06-25 07:12:14.915629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule...', end='')
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    print('Done!')


# Generated at 2022-06-25 07:12:16.774820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-25 07:12:18.435419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule('', '') != None)


# Generated at 2022-06-25 07:12:25.384288
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars


# Generated at 2022-06-25 07:12:34.726587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_task = {'args': {'file': 'tests/units/module_utils/fixtures/use_include/main.yml', 'name': 'a', 'hash_behaviour': 'replace'}, '_role': None, 'action': 'include_vars', 'delegate_to': 'localhost', 'delegate_facts': False, 'register': 'r', 'tags': ['tests', 'include_vars'], 'when': True}
    test_connection = None
    test_play_context = None
    test_loader = None
    test_templar = None
    test_shared_loader_obj = None

    test_case_0()
    test_obj = ActionModule(test_task, test_connection, test_play_context, test_loader, test_templar, test_shared_loader_obj)



# Generated at 2022-06-25 07:12:41.770446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test environment
    task_vars = dict()
    tmp = None
    source_file = "test/test.yml"
    source_file = source_file.rstrip('\n')
    source_dir = "test/test/"
    depth = 1
    files_matching = ".yml"
    ignore_files = list()
    ignore_unknown_extensions =  False
    valid_extensions = ['yaml', 'yml', 'json']

    filename = source_file
    stop_iter =  False
    # Never include main.yml from a role, as that is the default included by the role
    if path.join(source_file) == path.join(source_dir, filename):
        stop_iter = True
        continue

    filepath = path.join(source_dir, filename)


# Generated at 2022-06-25 07:13:51.943685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xea\xf1'
    str_0 = '\n        Sets attributes from the task if they are set, which will override\n        those from the play.\n\n        :arg task: the task object with the parameters that were set on it\n        :arg variables: variables from inventory\n        :arg templar: templar instance if templating variables is needed\n        '
    str_1 = '4E*0w&<4C)6TcJ'
    set_0 = set()
    tuple_0 = None
    int_0 = -407
    tuple_1 = (tuple_0, int_0)
    bool_0 = True

# Generated at 2022-06-25 07:13:52.437081
# Unit test for constructor of class ActionModule
def test_ActionModule():
	pass

# Generated at 2022-06-25 07:14:01.514023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xea\xf1'
    str_0 = '\n        Sets attributes from the task if they are set, which will override\n        those from the play.\n\n        :arg task: the task object with the parameters that were set on it\n        :arg variables: variables from inventory\n        :arg templar: templar instance if templating variables is needed\n        '
    str_1 = '4E*0w&<4C)6TcJ'
    set_0 = set()
    tuple_0 = None
    int_0 = -407
    tuple_1 = (tuple_0, int_0)
    bool_0 = True
    # Test function call

# Generated at 2022-06-25 07:14:06.160509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xea\xf1'
    str_0 = '\n\n        return the file list in a directory specified by the user.\n        '
    str_1 = '4E*0w&<4C)6TcJ'
    set_0 = set()
    tuple_0 = None
    int_0 = -407
    tuple_1 = (tuple_0, int_0)
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, str_0, str_1, set_0, tuple_1, bool_0)
    tmp_0 = None
    task_vars_0 = None
    var_0 = action_module_0.run(tmp_0, task_vars_0)
    return var_0


# Generated at 2022-06-25 07:14:15.897546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xea\xf1'
    str_0 = '\n        Sets attributes from the task if they are set, which will override\n        those from the play.\n\n        :arg task: the task object with the parameters that were set on it\n        :arg variables: variables from inventory\n        :arg templar: templar instance if templating variables is needed\n        '
    str_1 = '4E*0w&<4C)6TcJ'
    set_0 = set()
    tuple_0 = None
    int_0 = -407
    tuple_1 = (tuple_0, int_0)
    bool_0 = True

# Generated at 2022-06-25 07:14:26.232071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xea\xf1'
    str_0 = '\n        Sets attributes from the task if they are set, which will override\n        those from the play.\n\n        :arg task: the task object with the parameters that were set on it\n        :arg variables: variables from inventory\n        :arg templar: templar instance if templating variables is needed\n        '
    str_1 = '4E*0w&<4C)6TcJ'
    set_0 = set()
    tuple_0 = None
    int_0 = -407
    tuple_1 = (tuple_0, int_0)
    bool_0 = True

# Generated at 2022-06-25 07:14:31.685038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with argument self = action_module_0 and tmp = bytes_0
    bytes_0 = b'\xfb\xaa\xed'
    str_0 = '\n        Sets attributes from the task if they are set, which will override\n        those from the play.\n\n        :arg task: the task object with the parameters that were set on it\n        :arg variables: variables from inventory\n        :arg templar: templar instance if templating variables is needed\n        '
    str_1 = 'c!v0x'
    set_0 = set()
    tuple_0 = None
    int_0 = 368
    tuple_1 = (tuple_0, int_0)
    bool_0 = True

# Generated at 2022-06-25 07:14:34.233263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True  # TODO: implement your test here


# Generated at 2022-06-25 07:14:40.573021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xea\xf1'
    str_0 = '\n        Sets attributes from the task if they are set, which will override\n        those from the play.\n\n        :arg task: the task object with the parameters that were set on it\n        :arg variables: variables from inventory\n        :arg templar: templar instance if templating variables is needed\n        '
    str_1 = '4E*0w&<4C)6TcJ'
    set_0 = set()
    tuple_0 = None
    int_0 = -407
    tuple_1 = (tuple_0, int_0)
    bool_0 = True

# Generated at 2022-06-25 07:14:49.502265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xef\xb0'
    str_0 = '\n        Run this task, using the previously specified params.\n\n        This method is implemented by subclasses and should not be called\n        directly.\n        '
    str_1 = '|'
    set_0 = set()
    tuple_0 = None
    int_0 = 0
    tuple_1 = (tuple_0, int_0)
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, str_0, str_1, set_0, tuple_1, bool_0)
    tmp = None
    task_vars = None
    var_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:17:32.787907
# Unit test for constructor of class ActionModule
def test_ActionModule():
  bytes_0 = b'\xea\xf1'
  str_0 = '\n        Sets attributes from the task if they are set, which will override\n        those from the play.\n\n        :arg task: the task object with the parameters that were set on it\n        :arg variables: variables from inventory\n        :arg templar: templar instance if templating variables is needed\n        '
  str_1 = '4E*0w&<4C)6TcJ'
  set_0 = set()
  tuple_0 = None
  int_0 = -407
  tuple_1 = (tuple_0, int_0)
  bool_0 = True

# Generated at 2022-06-25 07:17:39.244624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'$\x80\xfa'
    str_0 = '\n        Runs a task that does not return a result\n        '
    str_1 = '\x8dD\x05\t'
    set_0 = set()
    tuple_0 = None
    int_0 = -407
    tuple_1 = (tuple_0, int_0)
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, str_0, str_1, set_0, tuple_1, bool_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['ansible_included_var_files'] = dict_0
    dict_2['message'] = dict_1

# Generated at 2022-06-25 07:17:44.786997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def test_case_0():
        bytes_0 = b'\x86\xca'
        str_0 = 'j\x9c\x1a\xa5N\xac'
        str_1 = 'C/G\x89\xe3\x9a\xd5\x16\x7f\xbc'
        set_0 = set()
        tuple_0 = None
        int_0 = 784
        tuple_1 = (tuple_0, int_0)
        bool_0 = True
        action_module_0 = ActionModule(bytes_0, str_0, str_1, set_0, tuple_1, bool_0)