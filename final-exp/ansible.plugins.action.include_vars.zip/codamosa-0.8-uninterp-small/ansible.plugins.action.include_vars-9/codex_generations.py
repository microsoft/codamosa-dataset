

# Generated at 2022-06-25 07:08:18.242843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    bytes_0 = b'?\xec\xfep\xab'
    str_0 = '^(-?\\d+)(s|m|h|d|w)?$'
    tuple_0 = (bytes_0, str_0)
    set_0 = {tuple_0, str_0}
    action_module_0 = ActionModule(float_0, bytes_0, tuple_0, float_0, tuple_0, set_0)
    assert isinstance(action_module_0, ActionModule) == True
    assert action_module_0.TRANSFERS_FILES == False
    assert isinstance(action_module_0.VALID_FILE_EXTENSIONS, list) == True
    assert len(action_module_0.VALID_FILE_EXTENSIONS) == 3


# Generated at 2022-06-25 07:08:18.862070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:08:25.628387
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    bytes_0 = b'?\xec\xfep\xab'
    str_0 = '^(-?\\d+)(s|m|h|d|w)?$'
    tuple_0 = (bytes_0, str_0)
    set_0 = {tuple_0, str_0}
    action_module_0 = ActionModule(float_0, bytes_0, tuple_0, float_0, tuple_0, set_0)
    action_module_0.run()

try:
    test_case_0()
    test_ActionModule_run()
except AnsibleError as e:
    print(e)

# Generated at 2022-06-25 07:08:26.472227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance = ActionModule()


# Generated at 2022-06-25 07:08:29.167764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:08:30.172350
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 07:08:39.409014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing with the values
    float_0 = None
    bytes_0 = b'?\xec\xfep\xab'
    str_0 = '^(-?\\d+)(s|m|h|d|w)?$'
    tuple_0 = (bytes_0, str_0)
    set_0 = {tuple_0, str_0}
    action_module_0 = ActionModule(float_0, bytes_0, tuple_0, float_0, tuple_0, set_0)
    # Calling the method run of the class ActionModule with the appropriate arguments
    action_module_0.run()
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:08:47.404597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    bytes_0 = b'?\xec\xfep\xab'
    str_0 = '^(-?\\d+)(s|m|h|d|w)?$'
    tuple_0 = (bytes_0, str_0)
    set_0 = {tuple_0, str_0}
    action_module_0 = ActionModule(float_0, bytes_0, tuple_0, float_0, tuple_0, set_0)


# Generated at 2022-06-25 07:08:50.491597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception:
        print('Exception caught in main loop')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:08:56.132156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None

# Generated at 2022-06-25 07:09:23.453146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    unit_test_ActionModule = ActionModule()
    return unit_test_ActionModule



# Generated at 2022-06-25 07:09:24.662184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Executing action module')


# Generated at 2022-06-25 07:09:31.573074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule([])
    assert(var_1.TRANSFERS_FILES == False)
    assert(var_1.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'])
    assert(var_1.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'])
    assert(var_1.VALID_FILE_ARGUMENTS == ['file', '_raw_params'])
    assert(var_1.VALID_ALL == ['name', 'hash_behaviour'])


# Generated at 2022-06-25 07:09:36.746635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert isinstance(obj, ActionModule) == True


# Generated at 2022-06-25 07:09:38.134500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule()
    assert action_module_obj


# Generated at 2022-06-25 07:09:45.317954
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:09:47.652863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = ActionModule(var_0)
    var_2 = None
    var_3 = dict()
    var_4 = var_1.run(var_2, var_3)
    return var_4


# Generated at 2022-06-25 07:09:59.264056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run")

    class DummyActionModule(ActionModule):
        class DummyResult():
            def __init__(self):
                self.ansible_facts = {"test": "passed"}
                self.ansible_included_var_files = []
                self.failed = False
                self.message = ''
                self._ansible_no_log = True

        def __init__(self):
            pass

        def run(self, tmp=None, task_vars=None):
            return self.DummyResult()

    test_case = DummyActionModule()
    test_result = test_case.run(tmp=None, task_vars=None)

    assert test_result.failed is False
    assert test_result.message == ''
    assert test_result._ansible_no_log

# Generated at 2022-06-25 07:10:00.127490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_0 = ActionModule()


# Generated at 2022-06-25 07:10:03.397939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # ensure that the task has no errors
    print('Testing ActionModule...')

    print('\tChecking parameters')
    test_case_0()
    print('\tTests completed')

# run main() for unit test
if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:10:55.679191
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 07:11:02.193981
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:11:09.943998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._task = None
    return_value = action.run()
    assert (return_value == NotImplementedError)
    return_value = action.run(tmp=None)
    assert (return_value == NotImplementedError)
    return_value = action.run(tmp=None, task_vars=var_0)
    assert (return_value == NotImplementedError)


# Generated at 2022-06-25 07:11:19.956585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # Check if parameters are correct
    params = dict()
    params["dir"] = "../ansible/module_utils"
    params["hash_behaviour"] = "merge"
    params["name"] = "foo"
    params["files_matching"] = "regex"

    # Execute action
    ret = module.run(params)
    assert ret["_ansible_no_log"] == True
    assert ret["failed"] == False
    assert ret["ansible_included_var_files"] == ["../ansible/module_utils/foo.yaml"]
    assert ret["ansible_facts"]["foo"]["bar"] == "baz"
    assert ret["message"] == ""
    #assert ret["ansible_facts"]["foo"]["bar"]["baz

# Generated at 2022-06-25 07:11:25.341009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data_for_arg_1 = [
        {
            'failed': True,
            'message': 'test_1'
        },
        {
            'ansible_included_var_files': ['test_2'],
            'ansible_facts': {
                'test_3': 'test_4'
            },
            '_ansible_no_log': False
        }
    ]
    ActionModule_instance = ActionModule(data_for_arg_1)
    try:
        assert ActionModule_instance
    except AssertionError as e:
        print('AssertionError:', e)
        raise
    else:
        print('Unit test of constructor of class ActionModule passed.')


# Generated at 2022-06-25 07:11:26.280529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule()


# Generated at 2022-06-25 07:11:34.176707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = None
    var_0['a'] = var_1
    var_0['a'] = None
    var_0['1'] = var_0
    var_0['3'] = dict()
    var_2 = dict()
    var_0['3']['b'] = var_2
    var_0['3']['b']['c'] = None
    var_0['3']['b']['d'] = dict()
    var_0['3']['b']['d']['e'] = None
    var_0['3']['b']['d']['f'] = dict()
    var_0['3']['b']['d']['f']['g'] = None

# Generated at 2022-06-25 07:11:45.077929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    runner = Runner()
    runner.load_plugins()
    unit = runner._tasks[0]
    ancestor = unit._block
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-25 07:11:45.675036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:11:49.857549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize an object of ActionModule
    test_obj_0 = ActionModule()

    # Initialize a variable that would be assigned to the variable task_vars
    var_0 = dict()

    # Invoke method run of test_obj_0 with appropriate arguments
    r = test_obj_0.run(tmp=None, task_vars=var_0)

    # Check if the returned value of method run is None
    assert r is None

# Generated at 2022-06-25 07:12:46.584806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    task_vars = dict()  # type: Dict
    tmp = None

    action_module.run(tmp, task_vars)


# Generated at 2022-06-25 07:12:50.510284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    import ansible.plugins.action.include_vars as iv
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native, to_text
    from ansible.utils.vars import combine_vars
    from os import path, walk
    import re
    test_IV = iv.ActionModule(0, 0)
    assert test_IV.run()


# Generated at 2022-06-25 07:12:51.763178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == "__main__":
    action = ActionModule()
    action.run()

# Generated at 2022-06-25 07:12:52.459048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 07:12:53.307200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    test_case_0()


# Generated at 2022-06-25 07:12:56.284219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_myinstance = ActionModule()
    assert type(action_module_myinstance) == ActionModule


# Generated at 2022-06-25 07:13:07.185326
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:13:11.956621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = dict()
    var_1['ansible_included_var_files'] = [0]
    var_1['ansible_facts'] = dict()
    var_1['_ansible_no_log'] = True

    assert ActionModule.run(action_module_0, None, var_0) == var_1


# Generated at 2022-06-25 07:13:16.927766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('-----------------------------------------------------------------\n')
    print('#### Unit Testing for ActionModule ####\n')
    try:
        test_case_0()
    except Exception as e:
        print(e)
    print('\n#### Unit Testing for ActionModule ####\n')
    print('-----------------------------------------------------------------\n')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:13:18.212850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable (ActionModule.run)
    assert isinstance(ActionModule.run(), dict)
    

# Generated at 2022-06-25 07:14:26.499746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'mG=qs'
    list_0 = None
    bool_0 = True
    int_0 = -6742
    bytes_0 = b'\x85\xae\xe3\xe5\x7f\x15\xc0\x12\x87'
    float_0 = 1323.792409
    bool_1 = False
    int_1 = -2443
    action_module_0 = ActionModule(bool_0, int_0, bytes_0, float_0, bool_1, int_1)
    var_0 = action_run(list_0)
    bytes_1 = b'\x12\x8e\xa1\xd0z\xeb\x19'
    set_0 = {bytes_1}
    dict_0 = {}
    action_

# Generated at 2022-06-25 07:14:31.884741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '$\x84\xa5\x99\xbe\x8f\x9f'
    list_0 = None
    bool_0 = False
    int_0 = 843
    bytes_0 = b'\x7f\xc4\xd1\xc5\xde\x11'
    float_0 = 2254.304345
    bool_1 = False
    int_1 = -3650
    action_module_0 = ActionModule(bool_0, int_0, bytes_0, float_0, bool_1, int_1)
    action_module_0 = ActionModule(action_module_0, bool_0, int_0, bytes_0, float_0, bool_1, int_1)

# Generated at 2022-06-25 07:14:41.378436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = '*'
    str_0 = ''
    float_0 = 556.351207
    float_1 = 59.373094
    list_0 = ['Q' for i in range(0, 6)]
    str_1 = '`m'
    list_1 = [30, 30, 30, 30]
    action_module_0 = ActionModule(var_0)
    list_2 = [action_module_0, action_module_0]
    action_module_0.run(list_1, list_2)
    action_module_0.run(list_0, list_2)
    action_module_0.run([list_1, list_0], list_2)
    action_module_0.run(list_1, [list_2, list_0])



# Generated at 2022-06-25 07:14:50.340739
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = None
    str_0 = '~4\x14\x0f\x1e\xc2\xf2'
    bytes_0 = b'\xa9\xbc\x06\x1d\xf0\xc4\x0f\x8a\x87\x9a\x13\x1f\x1c\xc6\x96\xe0\x8f\xd9\xe6\x9d\x1e\xbe'
    str_1 = '\x18\xb8\x08\x9c\x1e\x17\xa5\x87\xa5\xaf'
    long_0 = 1550783834026721135

# Generated at 2022-06-25 07:14:52.674783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
        print("Test case 0 passed")

    except Exception as e:
        print("Test case 0 failed - {0}".format(e))



# Generated at 2022-06-25 07:14:58.514342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '!\x1a\x93\x0b\x1c'
    list_0 = None
    bool_0 = True
    int_0 = -6218
    bytes_0 = b'7\x9bq\x7f\xeb\x17'
    float_0 = 487.2555
    bool_1 = False
    int_1 = -8668
    action_module_0 = ActionModule(bool_0, int_0, bytes_0, float_0, bool_1, int_1)
    var_0 = action_run(list_0)
    set_0 = set()
    dict_0 = {}
    action_module_1 = ActionModule(str_0, set_0, set_0, set_0, set_0, dict_0)
   

# Generated at 2022-06-25 07:15:01.756215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\n*** BEGIN TEST***")
    test_case_0()
    test_case_1()
    test_case_2()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:15:06.419250
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:15:07.145694
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO Implement unit test for method run of class ActionModule
    pass


# Generated at 2022-06-25 07:15:08.142139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert False
    except AssertionError:
        print('test_ActionModule_run')
        raise
