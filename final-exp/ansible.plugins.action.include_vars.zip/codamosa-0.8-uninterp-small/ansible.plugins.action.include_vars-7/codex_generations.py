

# Generated at 2022-06-25 07:08:14.343176
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('x', 'x', {})


# Generated at 2022-06-25 07:08:21.405219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars_0 = {}
    str_0 = "Zl<nI{8W"
    int_0 = -5568
    dict_0 = {}
    bytes_0 = b'\x1d'
    result_0 = ActionModule.run(task_vars_0, str_0, int_0, dict_0, bytes_0, dict_0, int_0)
    print("Return value: " + str(result_0))

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:08:31.529140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    # These parameters should be set according to the values in self._task.args
    # For example, self._task.args['name'] = "new_name"
    # WARNING : All parameters might not be used in the action_module, this is just an example
    task_vars = None
    tmp = None
    try:
        action_module_0 = ActionModule(None, None, {}, None, None, None)
    except:
        action_module_0 = None
    try:
        action_module_0.run(tmp, task_vars)
    except:
        assert False

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:08:41.208865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x82\xd3\xa1'
    str_0 = "l'~b\x10\\9\xce\xfb"
    int_0 = 2992
    dict_0 = {int_0: int_0}
    bytes_1 = b'\xb3'
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_1, dict_0, int_0)
    action_module_1 = ActionModule(str_0, int_0, dict_0, bytes_1, dict_0, int_0)
    action_module_2 = ActionModule(str_0, int_0, dict_0, bytes_1, dict_0, int_0)

# Generated at 2022-06-25 07:08:52.714403
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    str_0 = "c'OagA6Ni@MHVT"
    int_0 = -3971
    dict_0 = {int_0: int_0}
    bytes_1 = b'\xa4\xf3'
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_1, dict_0, int_0)

    assert action_module_0._task._role._role_path == 'c\'OagA6Ni@MHVT'
    assert action_module_0._task._role._role_name == 'c\'OagA6Ni@MHVT'
    assert action_module_0._task._role._task_blocks == {-3971: -3971}
    assert action_module_0._task._role._default_v

# Generated at 2022-06-25 07:09:01.656984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'@\x9c'
    str_0 = "c'OagA6Ni@MHVT"
    int_0 = -3971
    dict_0 = {int_0: int_0}
    bytes_1 = b'\xa4\xf3'
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_1, dict_0, int_0)
    dict_1 = {}
    dict_1[str_0] = dict_0
    dict_2 = {}
    dict_2['ansible_included_var_files'] = []
    dict_2['ansible_facts'] = {}
    dict_2['_ansible_no_log'] = True
    dict_1['task_vars'] = dict_2
    dict_

# Generated at 2022-06-25 07:09:13.284465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    str_0 = "c'OagA6Ni@MHVT"
    int_0 = -3971
    dict_0 = {int_0: int_0}
    bytes_1 = b'\xa4\xf3'
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_1, dict_0, int_0)

# Generated at 2022-06-25 07:09:23.649496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''

# Generated at 2022-06-25 07:09:28.862045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    str_0 = "c'OagA6Ni@MHVT"
    int_0 = -3971
    dict_0 = {int_0: int_0}
    bytes_1 = b'\xa4\xf3'
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_1, dict_0, int_0)


# Generated at 2022-06-25 07:09:36.340325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xae'
    str_0 = ">ut*aP|"
    int_0 = 9
    dict_0 = {
        0: -46,
        1: -51,
        2: 5,
        3: -42,
        4: -6
    }
    bytes_1 = b'\xdc\xd2'
    dict_1 = {
        0: 18,
        1: -48,
        2: -18,
        3: 48,
        4: -16
    }
    int_1 = -63
    dict_2 = {
        0: -16,
        1: -37,
        2: -61,
        3: -43,
        4: 25
    }

# Generated at 2022-06-25 07:10:02.538020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule({})
    action_module.run()

# Generated at 2022-06-25 07:10:08.181646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {
        'name': 'test_task_action'
    }
    play_context = {
        'name': 'test_play_context'
    }
    loader = None
    templar = None
    shared_loader_obj = None
    variable_manager = None
    action_base_obj = ActionBase(task, play_context, loader, templar, shared_loader_obj, variable_manager)
    action_module_obj = ActionModule(task, play_context, loader, templar, shared_loader_obj, variable_manager)

# Generated at 2022-06-25 07:10:13.737141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    command_0 = '/opt/py/bin/python'
    command_options_0 = '{"file": "/opt/ansible/testdir/vars_test.yml"}'
    name_0 = 'vars_test'

# Generated at 2022-06-25 07:10:19.417452
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing if the constructor raises an exception on an incorrect value of _task parameter
    caught = False
    try:
        # _task is not a dict
        test_case_0()
        ActionModule(_task=bytes_0)
    except TypeError:
        caught = True
    assert caught


# Generated at 2022-06-25 07:10:20.165131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_result = bytes_0



# Generated at 2022-06-25 07:10:20.897801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''



# Generated at 2022-06-25 07:10:25.060104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-25 07:10:27.463800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-25 07:10:37.548345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    str_0 = '{dummy_var}'
    str_1 = 'a\n'
    str_2 = 't\n'
    str_3 = str_2
    str_4 = 'r\n'
    str_5 = 't\n'
    str_6 = str_5
    str_7 = 'r'
    str_8 = 'r'
    str_9 = 'r'
    str_10 = 'r'
    str_11 = 'r'
    str_12 = 'r'
    str_13 = 'r'
    str_14 = 'r'
    str_15 = 'r'
    str_16 = 'r'
    str_17 = 'r'
    str_18 = 'r'

# Generated at 2022-06-25 07:10:42.867030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.TRANSFERS_FILES == False
    assert am.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert am.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert am.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert am.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-25 07:11:11.795398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()



# Generated at 2022-06-25 07:11:19.730289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0.is_setup = False
    test_case_0.exception = None
    test_case_0.action_module = None
    test_case_0.result = None
    test_case_0.exception_info = (None, None, None)
    test_case_0.fail_if_no_setup()

    # Create an ActionModule object
    test_case_0.action_module = ActionModule()
    test_case_0.action_module._set_dir_defaults()
    test_case_0.action_module._set_root_dir()
    test_case_0.action_module._set_args()
    test_case_0.action_module.source_dir = '/asanabria/testbed/doc/examples/vars'
    test_case_

# Generated at 2022-06-25 07:11:21.093396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()
    action_module_obj.run()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:11:25.719476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Module initialization
    # Create an object of the class ActionModule
    action_module_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-25 07:11:33.742221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiates a connection mocked object
    connection = Connection('ssh', 'user', 'hos7.local', '22', '22', 'local')

    # Instantiates an Ansible task
    task = Task('include variables', connection, '/etc/ansible/roles/role_under_test/tasks/main.yml', False, None, True, False)

    # Instantiates an Ansible Play
    play = Play(playbook='/etc/ansible/roles/role_under_test/tasks/main.yml', connection=connection, play_hosts=None, play=None)
    play.name = 'include variables'
    play.hosts = 'hos7.local'

    module_params = dict()

# Generated at 2022-06-25 07:11:40.348283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_task_vars = dict()
    my_tmp = None
    my_action_base_class = ActionBase(my_task_vars, my_tmp)
    my_data = dict()
    my_data['x'] = 1
    my_data['y'] = 2
    my_data['z'] = 3
    my_data['w'] = 4
    my_data['_ansible_no_log'] = False
    my_data['file_name'] = 'test.yml'
    my_data['ansible_facts'] = dict()
    my_data['ansible_facts']['_python_version'] = 3
    my_data['ansible_facts']['_python_version_str'] = '3.5.2'

# Generated at 2022-06-25 07:11:43.237456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case #0
    tmp = None
    task_vars = dict()
    a = ActionModule(tmp, task_vars)
    assert a.run(tmp, task_vars)



# Generated at 2022-06-25 07:11:44.662248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t_action = ActionModule()
    assert isinstance(t_action, ActionModule)


# Generated at 2022-06-25 07:11:52.198353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data_source = '/path/to/data_source'
    depth = 0
    directories = '/path/to/directories'
    dirname = 'dirname'
    ds = ''
    extensions = ['yml', 'yaml', 'json']
    file = '/path/to/file'
    files_matching = ''
    ignore_files = []
    ignore_unknown_extensions = True
    name = 'name'
    source_dir = '/path/to/source/dir'
    source_file = '/path/to/source/file'
    task_vars = dict()
    args = dict()
    loader_mock = LoaderMock()
    task_mock = TaskMock(data_source, args, loader_mock)

# Generated at 2022-06-25 07:12:01.187504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing the objects
    #action_base_obj = ActionBase(task, connection, play_context, loader, templar, shared_loader_obj)
    #action_module_obj = ActionModule(action_base_obj._task, action_base_obj._connection, action_base_obj._play_context, action_base_obj._loader, action_base_obj._templar, action_base_obj._shared_loader_obj)

    # Code starts here
    tmp, task_vars = None, None
    result = action_module_obj.run(tmp, task_vars)
    assert result['ansible_included_var_files'] == action_module_obj.included_files
    assert result['ansible_facts'] == result['ansible_facts']

# Generated at 2022-06-25 07:12:29.327022
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-25 07:12:30.302593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_module = ActionModule()


# Generated at 2022-06-25 07:12:34.260664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # initialize variables used in this test case
    bool_0 = bool()
    test_case_0()
    test_case_0()
    test_case_0()

    obj = ActionModule()
    if isinstance(obj, ActionModule):
        assert True
    else:
        assert False

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:12:35.252144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()


# Generated at 2022-06-25 07:12:38.024538
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Try to invoke method run of ActionModule with args (None, None)
    try:
        ActionModule.run(None, None)
    except Exception as e:
        print(str.format("Failed to invoke method run of class ActionModule with args (None, None)"))
        print(str.format("Exception: {0}", str(e)))
    else:
        print(str.format("Successfully invoked method run of class ActionModule with args (None, None)"))



# Generated at 2022-06-25 07:12:48.997612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_run = {
        'loop': [],
        '_ansible_version': '2.3.3.0',
        '_ansible_module_name': 'include_vars',
        'invocation': {
            'module_name': 'include_vars',
            'module_args': {
            }
        }
    }
    for test_case_run_name in test_case_run:
        test_case_run[test_case_run_name] = test_case_run[test_case_run_name]

    test_case_run_task_vars = {}

# Generated at 2022-06-25 07:12:50.790254
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-25 07:12:51.643327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:12:56.919625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionBase
    # Mock methods
    action_base_0 = ActionBase()
    action_base_0.run = MagicMock()
    action_base_0.run.return_value = (1,)
    # Create an instance of AnsibleTask
    ansible_task_0 = AnsibleTask(task_vars=dict())
    # Create an instance of ActionModule
    action_module_0 = ActionModule(ansible_task_0)
    # Set instance variables
    action_module_0.TRANSFERS_FILES = 0
    action_module_0.VALID_FILE_EXTENSIONS = ['yaml', 'yml', 'json']

# Generated at 2022-06-25 07:13:07.255911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ref_0 = AnsibleError('Invalid type for "extensions" option, it must be a list')
    ref_1 = AnsibleError('foo is not a valid option in include_vars')
    ref_2 = AnsibleError('Invalid regular expression: foo')
    ref_3 = AnsibleError('Invalid regular expression: foo')
    ref_4 = AnsibleError('/does/not/exist/file does not have a valid extension: yaml, yml, json')
    ref_5 = AnsibleError('/does/not/exist/file is not a dictionary/hash')
    ref_6 = AnsibleError('/does/not/exist/file does not have a valid extension: yaml, yml, json')


# Generated at 2022-06-25 07:14:16.326825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''

# Generated at 2022-06-25 07:14:26.280935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n" + "Class: " + ActionModule.__name__ + "\nFunction: " + "run")

    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    result = action_module.run(tmp=None, task_vars=None)

    print("type(result):", type(result))
    print("result:", result)

    assert isinstance(result, dict) 
    assert result['failed'] is not None 
    assert result['message'] is not None 
    assert result['ansible_included_var_files'] is not None 
    assert result['ansible_facts'] is not None 
    assert result['_ansible_no_log'] is not None 


# Unit

# Generated at 2022-06-25 07:14:31.728215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Define a fake task
    class FakeTask:
        # Fake _role
        class FakeRole:
            # Fake _role_path
            _role_path = 'C:\\Users\\Allen\\Ansible'

            def __init__(self):
                pass

        # Fake _ds
        class FakeDs:
            # Fake _data_source
            _data_source = 'C:\\Users\\Allen\\Ansible\\playbooks\\vars_merge'

            def __init__(self):
                pass

        # Fake args
        class FakeArgs:
            # Fake dir
            dir = 'dir_0'
            # Fake name
            name = 'name_0'
            # Fake hash_behaviour
            hash_behaviour = 'hash_behaviour_0'


# Generated at 2022-06-25 07:14:34.820305
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:14:35.718296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:14:38.220162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = object()
    connection = object()
    play_context = object()
    loader = object()

    am = ActionModule(task, connection, play_context, loader)
    assert isinstance(am, ActionModule)

# Generated at 2022-06-25 07:14:46.129029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = dict()
    params['action'] = dict()
    params['action']['args'] = dict()
    params['action']['args']['file'] = 'file_0'
    params['action']['args']['_raw_params'] = '_raw_params_0'
    params['action']['module_name'] = 'module_name_0'
    params['action']['_uses_shell'] = False
    params['action']['_raw_params'] = '_raw_params_1'
    params['action']['_task'] = dict()
    params['action']['_task']['args'] = dict()
    params['action']['_task']['args']['file'] = 'file_1'

# Generated at 2022-06-25 07:14:49.733284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()

    assert mod.run() == 'ANSIBLE_INCLUDED_VAR_FILES', 'Check whether method run of class ActionModule return value is `ANSIBLE_INCLUDED_VAR_FILES`'


# Generated at 2022-06-25 07:14:50.612692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 07:14:51.290764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-25 07:15:44.589264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule("f}2n?Z", -9, var_0 = "Fm{wT}[")
    action_module_obj.run()


test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:15:53.140078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x8a\xa7\xed\x9f\xb1\x8a\xaf\x98\x98\xc7\x8d\x8a'
    str_0 = 'eJ1KQ0xxAQAEX4I4='
    int_0 = -30
    dict_0 = {int_0: int_0}
    bytes_1 = b'\xae\xf3'
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_1, dict_0, int_0)


# Generated at 2022-06-25 07:15:56.744318
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    str_0 = "c'OagA6Ni@MHVT"
    int_0 = -3971
    dict_0 = {int_0: int_0}
    bytes_1 = b'\xa4\xf3'
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_1, dict_0, int_0, int_0)
    assert type(action_module_0) == ActionModule
    del action_module_0


# Generated at 2022-06-25 07:16:05.399608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    str_0 = "c'OagA6Ni@MHVT"
    int_0 = -3971
    dict_0 = {int_0: int_0}
    bytes_1 = b'\xa4\xf3'
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_1, dict_0, int_0)
    print(action_module_0.VALID_FILE_EXTENSIONS)
    print(action_module_0.VALID_DIR_ARGUMENTS)
    print(action_module_0.VALID_FILE_ARGUMENTS)
    print(action_module_0.VALID_FILE_EXTENSIONS)
    print(action_module_0.VALID_ALL)


# Generated at 2022-06-25 07:16:16.709758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xb0\xf6'
    str_0 = "L-{K'%Y"
    int_0 = 9087
    dict_0 = {int_0: int_0}
    bytes_1 = b'\x94'
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_1, dict_0, int_0)
    var_0 = action_module_0.run(dict_0, dict_0)
    # assert var_0['ansible_included_var_files'] == dict_0
    assert var_0['ansible_facts'] == dict_0
    assert var_0['_ansible_no_log'] == True
    # assert var_0['failed'] == dict_0
    # assert var_0['

# Generated at 2022-06-25 07:16:18.421339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tester = TestActionModule()
    tester.test()


# Generated at 2022-06-25 07:16:27.926429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x18\x81\x92\xd3\x8d\xcd\x9c\xf7\x96\xe0\x80\xfe\xc4\xe1\xf8\x19\x6b\x1d'
    str_0 = 'application/octet-stream'
    dict_0 = dict()

# Generated at 2022-06-25 07:16:31.477301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    str_0 = "c'OagA6Ni@MHVT"
    int_0 = -3971
    dict_0 = {int_0: int_0}
    bytes_1 = b'\xa4\xf3'
    action_module_0 = ActionModule(str_0, int_0, dict_0, bytes_1, dict_0, int_0)

# Generated at 2022-06-25 07:16:37.948132
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # When ansible_playbook_python is called with additional command line args
    # (--extra-vars for example), the cmdline_args.ansible_cmdline may not be
    # the same object as the global C.ANSIBLE_CMDLINE. So, if constructor of
    # ActionModule is changed in any way, we need to update these tests to
    # ensure that the global C.ANSIBLE_CMDLINE is not modified.

    # initialization
    str_0 = "c'OagA6Ni@MHVT"
    int_0 = -3971
    dict_0 = {int_0: int_0}
    bytes_0 = b'\xa4\xf3'
    dict_1 = {int_0: int_0}
    int_1 = -3971

# Generated at 2022-06-25 07:16:43.689154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    str_0 = 'b'
    int_0 = -6236
    list_0 = [12, 92, 46, '6U|>sUz', '%+8Z', str_0]
    list_1 = [str_0, -9927, int_0]
    list_2 = [int_0, '@!N<Y\\', 'N', -8552]
    list_3 = [str_0, str_0, int_0]
    list_4 = [list_3, str_0, str_0]
    int_1 = -8
    int_2 = 0
    list_5 = [91, -1, 'n']
    list_6 = [29, '?', '\\%g<h']