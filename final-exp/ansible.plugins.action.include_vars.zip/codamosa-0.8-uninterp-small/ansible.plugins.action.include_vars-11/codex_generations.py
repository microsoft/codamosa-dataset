

# Generated at 2022-06-25 07:08:16.681457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:08:25.948461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 572.07149
    set_0 = {float_0}
    str_0 = 'solaris'
    bytes_0 = None
    action_module_0 = ActionModule(float_0, float_0, set_0, str_0, bytes_0, set_0)
    str_1 = '@nu'
    str_2 = 'u@admin'
    str_3 = '@'
    str_4 = 'nu'
    dict_0 = {str_1: str_2, str_3: str_4}
    str_5 = '@nu'
    str_6 = 'u@admin'
    str_7 = '@'
    str_8 = 'nu'
    dict_1 = {str_5: str_6, str_7: str_8}


# Generated at 2022-06-25 07:08:34.337860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 62.5
    str_0 = 'ansible_play_hosts'
    float_1 = 0.1716666586803995
    set_0 = {float_0, str_0}
    bool_0 = False
    str_1 = 'linux'
    set_1 = {float_1, set_0}
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_1, set_1, set_1)
    assert action_module_0 is not None
    assert action_module_0._task.args.get('files_matching') == '*.yml'
    assert action_module_0.hash_behaviour == 'replace'
    assert action_module_0.source_dir == 'vars'


# Generated at 2022-06-25 07:08:36.022506
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:08:45.053284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 572.07149
    set_0 = {float_0}
    str_0 = 'solaris'
    bytes_0 = None
    action_module_0 = ActionModule(float_0, float_0, set_0, str_0, bytes_0, set_0)
    str_1 = 'hoist'
    str_2 = 'pluck'
    str_3 = 'fatal'
    str_4 = 'daoist'
    float_1 = -84.18179
    set_1 = {str_2, str_3, str_4}
    float_2 = 37.82928
    str_5 = 'mind'
    str_6 = 'break'
    str_7 = 'hanger'
    str_8 = 'fantasia'
    set_

# Generated at 2022-06-25 07:08:54.729174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 572.07149
    set_0 = {float_0}
    str_0 = 'solaris'
    bytes_0 = None
    action_module_0 = ActionModule(float_0, float_0, set_0, str_0, bytes_0, set_0)
    action_module_0._set_args()
    action_module_0._set_root_dir()
    action_module_0._traverse_dir_depth()
    action_module_0._traverse_dir_depth()
    action_module_0._traverse_dir_depth()
    action_module_0._traverse_dir_depth()
    action_module_0._traverse_dir_depth()
    action_module_0._traverse_dir_depth()
    action_module_0._tra

# Generated at 2022-06-25 07:08:55.987189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    # Unit test for constructor of class ActionModule
    test_ActionModule()

# Generated at 2022-06-25 07:08:57.731594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as e:
        assert(False)


# Generated at 2022-06-25 07:09:01.878711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 447.9229
    action_module_0 = ActionModule({'_raw_params': '$HOME/blah', 'file': '$HOME/blah', '_ansible_no_log': False, '_ansible_verbosity': 0, '_ansible_selinux_special_fs': False, '_ansible_version': '2.0.2.0', 'failed': False, '_ansible_system_version': '7', '_ansible_diff': False, 'gid': 1000, '_ansible_parsed': True, '_ansible_debug': False, '_ansible_check_mode': False, '_ansible_keep_remote_files': False, '_ansible_no_log_args': False, 'cmd': 'ls'}, None, None)
    action

# Generated at 2022-06-25 07:09:09.639258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 572.07149
    set_0 = {float_0}
    str_0 = 'solaris'
    bytes_0 = None
    action_module_0 = ActionModule(float_0, float_0, set_0, str_0, bytes_0, set_0)
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:09:40.683563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(float(), float(), float(), str(), str(), float())
    assert action_module_0.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions']
    assert action_module_0.VALID_FILE_ARGUMENTS == ['file', '_raw_params']
    assert action_module_0.VALID_ALL == ['name', 'hash_behaviour']


# Generated at 2022-06-25 07:09:47.887758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 775.9456819503381
    str_0 = 'solaris'
    action_module_0 = ActionModule(float_0, float_0, float_0, str_0, str_0, float_0)
    task_vars = dict()
    results = action_module_0.run(None, task_vars)

# Generated at 2022-06-25 07:09:59.266153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 898.0
    float_1 = 753.9954
    float_2 = -435.98864
    str_0 = 'linux'
    str_1 = 'bsd'
    float_3 = -100.78846
    float_4 = 174.0
    float_5 = -795.0524
    float_6 = -866.1089
    float_7 = -766.245
    float_8 = -843.08344
    float_9 = -971.33725
    float_10 = -70.77766

    action_module_0 = ActionModule(float_0, float_1, float_2, str_0, str_1, float_3)

# Generated at 2022-06-25 07:10:00.775837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:10:01.976658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:10:05.685798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()


# Generated at 2022-06-25 07:10:12.678355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 55.33
    str_0 = 'linux'
    float_1 = 1.1
    str_1 = 'bsd'
    float_2 = 7.9
    str_2 = 'openbsd'
    action_module_0 = ActionModule(float_0, float_1, float_2, str_0, str_1, str_2)
    assert (float_0 == action_module_0.loader), "Expected %s, but got %s" % (float_0, action_module_0.loader)
    assert (str_1 == action_module_0.templar), "Expected %s, but got %s" % (str_1, action_module_0.templar)

# Generated at 2022-06-25 07:10:21.713807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 839.3
    float_1 = 2.55069e+11
    float_2 = 0.0
    str_0 = 'centos'
    str_1 = 'rhce'
    float_3 = 5.8
    action_module_0 = ActionModule(float_0, float_1, float_2, str_0, str_1, float_3)
    assert action_module_0.VALID_ALL == ['name', 'hash_behaviour']
    assert action_module_0._task.args.get('dir', None) == str_0
    assert action_module_0._task.args.get('file', None) == str_1
    assert action_module_0.source_file is None
    assert action_module_0.matcher is None
    assert action_module_0

# Generated at 2022-06-25 07:10:26.575429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule(572.07149, 572.07149, 572.07149, 'solaris', 'solaris', 572.07149)
    except Exception as exception_0:
        print(str(exception_0))
        exit(1)


# Generated at 2022-06-25 07:10:30.804645
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with floats and strs as input.
    float_0 = 765.04612
    str_0 = 'hpux'
    ActionModule(float_0, float_0, float_0, str_0, str_0, float_0)


# Generated at 2022-06-25 07:11:10.242363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xd1\xfa\x01\xcc\x16\x03M\xcd\xd4c\x15\xc1r\xc3GR\t\t\xdd'
    set_0 = set()
    bool_0 = False
    str_0 = '^0zjJd'
    str_1 = 'enablerepo'
    list_0 = [set_0, str_0, bool_0, str_0]
    action_module_0 = ActionModule(set_0, bool_0, set_0, str_0, str_1, list_0)
    assert action_module_0._task is set_0
    assert action_module_0.connection is bool_0
    assert action_module_0._play_context is set_0
    assert action_

# Generated at 2022-06-25 07:11:11.761271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert not action_module_0.run()



# Generated at 2022-06-25 07:11:19.704495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bool_0 = False
    str_0 = 'h'
    str_1 = 'h'
    list_0 = [set_0, bool_0, bool_0, str_1, str_0, bool_0]
    action_module_0 = ActionModule(set_0, bool_0, set_0, str_0, str_1, list_0)
    assert action_module_0._task == set_0
    assert action_module_0._connection == bool_0
    assert action_module_0._play_context == set_0
    assert action_module_0._shared_loader_obj == str_0
    assert action_module_0._loader == str_1
    assert action_module_0._templar == list_0


# Generated at 2022-06-25 07:11:24.963001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xd1\xfa\x01\xcc\x16\x03M\xcd\xd4c\x15\xc1r\xc3GR\t\t\xdd'
    set_0 = set()
    bool_0 = False
    str_0 = '^0zjJd'
    str_1 = 'enablerepo'
    list_0 = [set_0, str_0, bool_0, str_0]
    action_module_0 = ActionModule(set_0, bool_0, set_0, str_0, str_1, list_0)
    var_0 = action_module_0.run(bytes_0, set_0)

# Generated at 2022-06-25 07:11:32.426118
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xd1\xfa\x01\xcc\x16\x03M\xcd\xd4c\x15\xc1r\xc3GR\t\t\xdd'
    set_0 = set()
    bool_0 = False
    str_0 = '^0zjJd'
    str_1 = 'enablerepo'
    list_0 = [set_0, str_0, bool_0, str_0]
    action_module_0 = ActionModule(set_0, bool_0, set_0, str_0, str_1, list_0)
    result = action_module_0.run(bytes_0)
    assert result == {}



# Generated at 2022-06-25 07:11:39.294936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xd1\xfa\x01\xcc\x16\x03M\xcd\xd4c\x15\xc1r\xc3GR\t\t\xdd'
    set_0 = set()
    bool_0 = False
    str_0 = '^0zjJd'
    str_1 = 'enablerepo'
    list_0 = [set_0, str_0, bool_0, str_0]
    action_module_0 = ActionModule(set_0, bool_0, set_0, str_0, str_1, list_0)
    assert not action_module_0.action_loader
    assert action_module_0.action_loader_shared_dynamic_libs
    assert not action_module_0.action_loader_templates

# Generated at 2022-06-25 07:11:48.459723
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:11:59.271634
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'x)V\x87\xd9\x06\xc2\x01\xbb\x03\x98\x01\x8c\x1d\x0bz'
    str_1 = 'IO.\x13\x08\x16\x17\x19\r\r\r\r\r\r\r\r\r\r\r\r\r'

# Generated at 2022-06-25 07:12:01.416841
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule(None, None, None, None, None, None)
    except Exception as e:
        print("Exception raised in constructor of ActionModule: " + str(e))


# Generated at 2022-06-25 07:12:05.139673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print(action_module_0.TRANSFERS_FILES)
    print(action_module_0.VALID_FILE_EXTENSIONS)
    print(action_module_0.VALID_DIR_ARGUMENTS)
    print(action_module_0.VALID_FILE_ARGUMENTS)
    print(action_module_0.VALID_ALL)


# Generated at 2022-06-25 07:13:10.320405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:13:18.764613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xd1\xfa\x01\xcc\x16\x03M\xcd\xd4c\x15\xc1r\xc3GR\t\t\xdd'
    set_0 = set()
    bool_0 = False
    str_0 = '^0zjJd'
    str_1 = 'enablerepo'
    list_0 = [set_0, str_0, bool_0, str_0]
    action_module_0 = ActionModule(set_0, bool_0, set_0, str_0, str_1, list_0)
    var_0 = action_run(bytes_0)

# Generated at 2022-06-25 07:13:25.763525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = False
    str_0 = 'mTzTf'
    str_1 = 'p\xaf\x17\xdb\x00\x88\x8e\xab\xb4\xdd\xa1\x8a\xcc\x97\x12\x8c\x1b\x9a\xbf\xc7'
    list_0 = [str_0, str_0, str_0, str_1]
    action_module_0 = ActionModule(set_0, bool_0, set_0, str_0, str_1, list_0)
    int_0 = len(list_0)
    var_0 = action_module_0.run(int_0)
    print(var_0)


# Generated at 2022-06-25 07:13:35.420325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xd1\xfa\x01\xcc\x16\x03M\xcd\xd4c\x15\xc1r\xc3GR\t\t\xdd'
    set_0 = set()
    bool_0 = False
    str_0 = '^0zjJd'
    str_1 = 'enablerepo'
    list_0 = [set_0, str_0, bool_0, str_0]
    action_module_0 = ActionModule(set_0, bool_0, set_0, str_0, str_1, list_0)
    var_0 = action_module_0.run(bytes_0, str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:13:40.882076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x88'
    result_0 = set()
    str_0 = '}*R'
    dict_0 = dict()
    dict_0[str_0] = result_0
    list_0 = [dict_0, dict_0, dict_0, dict_0]
    action_module_0 = ActionModule(list_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    action_module_0.run(bytes_0)


# Generated at 2022-06-25 07:13:45.080427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(test_case_0())

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:13:52.519651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = False
    str_0 = 'vars'
    str_1 = 'enablerepo'
    list_0 = [set_0, str_0, bool_0, str_0]
    action_module_0 = ActionModule(set_0, bool_0, set_0, str_0, str_1, list_0)
    dict_0 = dict()
    dict_1 = action_module_0.run(dict_0)
    str_2 = 'ansible_included_var_files'
    assert str_2 in dict_1
    str_3 = 'ansible_facts'
    assert str_3 in dict_1
    str_4 = '_ansible_no_log'
    assert str_4 in dict_1



# Generated at 2022-06-25 07:13:54.153802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #TestConstructor
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:14:01.980193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xd1\xfa\x01\xcc\x16\x03M\xcd\xd4c\x15\xc1r\xc3GR\t\t\xdd'
    set_0 = set()
    bool_0 = False
    str_0 = '^0zjJd'
    str_1 = 'enablerepo'
    list_0 = [set_0, str_0, bool_0, str_0]
    action_module_0 = ActionModule(set_0, bool_0, set_0, str_0, str_1, list_0)
    var_0 = action_module_0.run(bytes_0)

    action_module_0._set_dir_defaults()
    action_module_0._set_args()
    action_

# Generated at 2022-06-25 07:14:13.129421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    os_path_0 = path.join('b', 'c', 'd')
    str_0 = './BksC"=N)'
    str_1 = "'N\x13\x11\x0e\x1fh\x18s\x0fz\x0f\x10\x0f\x1bv\x08\x0c\x10u\x18\x1a\x05\x0c'"
    str_2 = 'Z\nB\x12\n\x1e\x0cS\x1c\x18\n'
    ansible_errors_AnsibleError_0 = AnsibleError('R\x1b\\.\\"\x13')

# Generated at 2022-06-25 07:14:56.456955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:15:05.396702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_error_0 = module_0.AnsibleError()
    str_0 = '\x7fE\x1a\x1cg_\x12A\x0e3\x7f\x1f\n\x08\r\n\x0b\n\x00'
    dict_0 = {str_0: ansible_error_0, str_0: ansible_error_0}
    float_0 = -1491.6674621006453
    action_module_0 = ActionModule(ansible_error_0, str_0, dict_0, float_0, float_0, str_0)
    #assert_equal(action_module_0.run(), 0)

# Generated at 2022-06-25 07:15:10.307471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_error_0 = module_0.AnsibleError()
    str_0 = ':sCbd\x0c1{Xc4%'
    dict_0 = {str_0: ansible_error_0, str_0: ansible_error_0}
    float_0 = -1491.6674621006453
    action_module_0 = ActionModule(ansible_error_0, str_0, dict_0, float_0, float_0, str_0)
    assert_equals(action_module_0 != None, True)


# Generated at 2022-06-25 07:15:18.506474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_error_0 = module_0.AnsibleError()
    str_0 = ':sCbd\x0c1{Xc4%'
    dict_0 = {str_0: ansible_error_0, str_0: ansible_error_0}
    float_0 = -1491.6674621006453
    action_module_0 = ActionModule(ansible_error_0, str_0, dict_0, float_0, float_0, str_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:15:19.496105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module.run(tmp, task_vars) == result


# Generated at 2022-06-25 07:15:23.608374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_error_0 = module_0.AnsibleError()
    str_0 = '\x7f~\x7f'
    dict_0 = {str_0: ansible_error_0, str_0: ansible_error_0}
    float_0 = -1491.6674621006453
    action_module_0 = ActionModule(ansible_error_0, str_0, dict_0, float_0, float_0, str_0)
    assert isinstance(action_module_0, ActionModule) == True


# Generated at 2022-06-25 07:15:33.682644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TempClass:
        def __init__(self):
            self.args = {'ignore_files': '', 'extensions': ['yaml'], 'no_log': False, '_raw_params': './ansible/test/sanity/code/inventory', '_uses_shell': False, '_raw_params_files': [], '_ansible_check_mode': False, '_ansible_no_log': False, '_ansible_debug': False, 'name': 'discovered_packages'}
            self.action = 'include_vars'
            self.deprecations = []
            self.warnings = []
            self.set_type_success = True
            self.aliases = []
            self.no_log = False
            self.notify = []
            self.async_val = 0


# Generated at 2022-06-25 07:15:40.052524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test to check the return type of run method is dict
    ansible_error_0 = module_0.AnsibleError()

# Generated at 2022-06-25 07:15:44.669263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:15:54.475132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_error_0 = module_0.AnsibleError()
    str_0 = '-Lc%i#j'
    dict_0 = {str_0: ansible_error_0, str_0: ansible_error_0}
    float_0 = -1491.6674621006453
    action_module_0 = ActionModule(ansible_error_0, str_0, dict_0, float_0, float_0, str_0)
    var_0 = action_module_0.run()

    # Test if callable
    assert callable(action_module_0.run)

    # Test if callable
    assert callable(ActionModule.run)

    # Test if callable
    assert callable(ActionModule)

    # Test if callable

# Generated at 2022-06-25 07:17:02.198653
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_error_0 = module_0.AnsibleError()
    str_0 = 'i\x1a`w\x1b\x02\x07\x13\x14'
    float_0 = -3804.008923676683
    action_module_0 = ActionModule(ansible_error_0, str_0, ansible_error_0, float_0, float_0, str_0)
    action_module_0.run()

# Generated at 2022-06-25 07:17:10.795497
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_error_0 = module_0.AnsibleError()
    str_0 = 'n=g2Q\x7f'
    str_1 = '}Z{*\x7f]\x0b\x7f'
    float_0 = -3719.956465611084
    float_1 = -5934.146826021971
    str_2 = ':sCbd\x0c1{Xc4%'
    action_module_0 = ActionModule(ansible_error_0, str_0, ansible_error_0, float_0, float_0, str_0)
    ansible_error_1 = module_0.AnsibleError()
    setattr(action_module_0, '_task', ansible_error_1)
    ansible_error

# Generated at 2022-06-25 07:17:18.339767
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'c%\t]jC\x1ab\x7f'
    ansible_error_0 = module_0.AnsibleError()
    float_0 = 1247.8268730593435
    ansible_error_1 = module_0.AnsibleError()
    str_1 = 'd^\x1e\x1c\x1fJg\x15'
    float_1 = 1450.6736147293375
    float_2 = 0.7409455049341892
    str_2 = 'z\x11\x12\x7f\x1cR\x1bi\x0f0\x18'

# Generated at 2022-06-25 07:17:25.358692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_error_0 = module_0.AnsibleError()
    str_0 = ':sCbd\x0c1{Xc4%'
    float_0 = -1491.6674621006453
    action_module_0 = ActionModule(ansible_error_0, str_0, ansible_error_0, float_0, float_0, str_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:17:32.710239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_error_0 = module_0.AnsibleError()
    str_0 = ':sCbd\x0c1{Xc4%'
    float_0 = -1491.6674621006453
    action_module_0 = ActionModule(ansible_error_0, str_0, ansible_error_0, float_0, float_0, str_0)
    assert isinstance(action_module_0, ActionModule)
    assert isinstance(action_module_0, object)
    assert issubclass(ActionModule, object) 


# Generated at 2022-06-25 07:17:34.443164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
    test_case_0()

if __name__ == '__main__':
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 07:17:39.761043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_error_0 = module_0.AnsibleError()
    str_0 = '9~f'
    ansible_error_1 = module_0.AnsibleError()
    float_0 = -1491.6674621006453
    float_1 = -1491.6674621006453
    str_1 = ':sCbd\x0c1{Xc4%'
    action_module_0 = ActionModule(ansible_error_0, str_0, ansible_error_1, float_0, float_1, str_1)
    var_0 = action_module_0.run()
    test_case_0()


# Generated at 2022-06-25 07:17:40.683178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	ansible.errors.AnsibleError
	test_case_0()

# Generated at 2022-06-25 07:17:51.191325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_error_0 = module_0.AnsibleError()
    str_0 = ':sCbd\x0c1{Xc4%'
    float_0 = -1491.6674621006453
    action_module_0 = ActionModule(ansible_error_0, str_0, ansible_error_0, float_0, float_0, str_0)
    var_0 = action_module_0.run()
    str_1 = 'X]H2\\,`U6*'
    float_1 = 1.25
    str_2 = 'Pm(.d{9#'
    action_module_1 = ActionModule(ansible_error_0, str_2, ansible_error_0, float_0, float_0, str_0)