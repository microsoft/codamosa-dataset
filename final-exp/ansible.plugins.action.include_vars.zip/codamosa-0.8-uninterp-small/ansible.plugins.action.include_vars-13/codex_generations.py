

# Generated at 2022-06-25 07:08:10.788401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test ActionModule constructor")
    test_case_0()
    print("Test ActionModule done")

test_ActionModule()

# Generated at 2022-06-25 07:08:17.482982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_var_0 = False
    float_var_0 = -7.19739
    dict_var_0 = {float_var_0: float_var_0}
    float_var_1 = -1202.694
    action_module_obj = ActionModule(bool_var_0, float_var_0, dict_var_0, float_var_1, bool_var_0, float_var_1)
    assert action_module_obj.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:08:23.390709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit test for method run of class ActionModule
    bool_0 = True
    float_0 = 1142.244444444444
    dict_0 = {float_0: float_0}
    float_1 = 3.37E24
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    tmp = None
    task_vars = dict()
    action_module_0.run(tmp, task_vars)



# Generated at 2022-06-25 07:08:29.576743
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Try with param tmp
    params = {'tmp': None}

    # Try with param task_vars
    task_vars = None
    action_module_0 = ActionModule(params, task_vars)

    # Try with params tmp and task_vars
    action_module_1 = ActionModule(params, task_vars)

    # Try with param tmp
    params = {'tmp': ''}

    # Try with param task_vars
    task_vars = {}
    action_module_2 = ActionModule(params, task_vars)

    # Try with params tmp and task_vars
    action_module_3 = ActionModule(params, task_vars)

    # Try with param tmp
    params = {'tmp': 'tmp'}

    # Try with param task_vars
    task_v

# Generated at 2022-06-25 07:08:30.587907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 07:08:32.182170
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:08:41.876893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 0.23267724829784818
    str_0 = 'LhQzWUYO9'
    action_module_0 = ActionModule(bool_0, float_0, str_0, str_0, bool_0, str_0)
    action_module_0.warning = 'U^Gj#'
    action_module_0.region = 'fIN'
    action_module_0.included_files = 's2'
    action_module_0.ansible_loop = 'QH'
    action_module_0.ansible_apparmor = 'RfOG'
    action_module_0.ansible_play_hosts = 'a!O'
    action_module_0.ansible_version = 'I#p'
   

# Generated at 2022-06-25 07:08:48.660680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = -1.0
    dict_0 = {str_0: float_0}
    float_1 = -81.03515
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:08:57.201107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY3
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes, to_native, to_text
    import ansible.constants as C
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars
    import os
    import re
    import os.path
    from ansible.utils._text import to_bytes, to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleError
    import os
    import re
    import os.path

# Generated at 2022-06-25 07:09:04.468572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test case 1 is running')
    bool_0 = False
    float_0 = -127.8084414511299
    dict_0 = {float_0: float_0}
    float_1 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    # Test case 1
    task_vars = dict()
    dict_1 = dict()
    dict_1['roles'] = dict()
    dict_1['roles']['role'] = 'role'
    dict_2 = dict()
    dict_2['_role_path'] = '_role_path'
    dict_1['roles']['role'] = dict_2
    dict_1['_ds'] = dict()

# Generated at 2022-06-25 07:09:36.460831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = -137.7
    dict_0 = {float_0: float_0}
    float_1 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    assert action_module_0.action_executor._connection._play_context.connection == "local"
    assert action_module_0.action_executor._connection._play_context.network_os == "default"
    assert action_module_0.action_executor._connection._play_context.remote_addr == "127.0.0.1"
    assert action_module_0.action_executor._connection._play_context.remote_user == "root"
    assert 0

# Generated at 2022-06-25 07:09:37.289691
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True and False == False

# Generated at 2022-06-25 07:09:44.617043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Unit test for method run of class ActionModule")
    bool_0 = False
    float_0 = 2087.184
    set_0 = {'not_an_integer': bool_0}
    float_1 = -1136.55
    float_2 = 0.8016
    float_3 = 0.7392
    float_4 = 3137.3
    float_5 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, set_0, float_1, bool_0, float_2, float_3, float_4, float_5)
    action_module_0.run(set_0)
    action_module_0.run()

test_ActionModule_run()
test_case_0()

# Generated at 2022-06-25 07:09:50.343297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Parameterized test case

    # Testing parameter 'tmp'
    tmp = None
    ansible_call_result = dict(ansible_facts=dict(a='b'), failed=False, changed=False)
    module_args = dict(gather_subset='all')
    module_ret = dict(ansible_facts=dict(a='b'), failed=False, changed=False)
    action_module_0 = ActionModule(module_ret, tmp, module_args, tmp, tmp, tmp)
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool

# Generated at 2022-06-25 07:09:54.797528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(True, -9759.857, {-0.2: -2845.856}, 17.0, True, 1908.259)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:09:56.232955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        #TODO: Need to implement
        assert False
    except:
        assert False

# Generated at 2022-06-25 07:10:00.989916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = -137.7
    dict_0 = {float_0: float_0}
    float_1 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:10:08.637640
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Boolean value
    bool_val = "T"

    # Float value
    float_val = 12.4

    # Dictionary
    dict_val = {12.4: 12.4}

    # String value
    str_val = "Hello"

    # ActionModule object with params as Boolean, Float and Dictionary
    action_module = ActionModule(bool_val, float_val, dict_val)

    # Boolean value
    bool_val = "F"

    # Float value
    float_val = -12.4

    # ActionModule object with params as Boolean and Float
    action_module = ActionModule(bool_val, float_val)

    # Boolean value
    bool_val = "T"

    # String value
    str_val = "Hello World!"

    # ActionModule object with params as Boolean and String
    action_module

# Generated at 2022-06-25 07:10:15.209090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    method_0 = ActionModule(False, -137.7, {-137.7: -137.7}, -2946.709, False, -2946.709)
    method_0.run()
    method_1 = ActionModule(False, -139.6, {-139.6: -139.6}, -2496.68, False, -2496.68)
    method_1.run()
    method_2 = ActionModule(False, -106.3, {-106.3: -106.3}, -2080.35, False, -2080.35)
    method_2.run()
    method_3 = ActionModule(False, -56.2, {-56.2: -56.2}, -2496.68, False, -2496.68)
    method_3.run()
    method_

# Generated at 2022-06-25 07:10:19.085567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    run test stub
    '''
    action_run()


if __name__ == '__main__':
    import sys
    import __main__ as main

    print('Python %s on %s' % (sys.version, sys.platform))
    print('action module: %s' % main.__file__)

    test_case_0()

# Generated at 2022-06-25 07:11:09.887736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = -137.7
    dict_0 = {float_0: float_0}
    float_1 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    #assert action_module_0.__dict__.keys() == ['VALID_ALL', 'VALID_FILE_ARGUMENTS', 'VALID_DIR_ARGUMENTS', 'VALID_FILE_EXTENSIONS', 'show_content', 'included_files']
    #assert_equals (action_module_0.VALID_ALL, ['name', 'hash_behaviour'])
    #assert_equals (action_module_0.VALID_FILE_ARGUMENTS, ['file',

# Generated at 2022-06-25 07:11:14.941542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = -137.7
    dict_0 = {float_0: float_0}
    float_1 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    test_case_0()


# Generated at 2022-06-25 07:11:21.756513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = -137.7
    dict_0 = {float_0: float_0}
    float_1 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    action_module_0._set_dir_defaults()
    action_module_0._set_args()
    action_module_0._set_root_dir()
    for root_dir, filenames in action_module_0._traverse_dir_depth():
        action_module_0._load_files_in_dir(root_dir, filenames)
    action_module_0._load_files(action_module_0.source_file)
    action_module_0.run()


# Generated at 2022-06-25 07:11:25.371488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:11:32.465637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = 25.0
    dict_0 = {float_0: float_0}
    float_1 = -39.45
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:11:33.921618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:11:37.546379
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = -137.7
    dict_0 = {float_0: float_0}
    float_1 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:11:41.179807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = -137.7
    dict_0 = {float_0: float_0}
    float_1 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    result_0 = action_module_run()
    assert isinstance(result_0, dict)


# Generated at 2022-06-25 07:11:45.075462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = -14.48
    dict_0 = {}
    float_1 = -3732.9
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    action_module_0.run()


# Generated at 2022-06-25 07:11:50.027449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(('Running test for method run of class ActionModule... '))
    bool_0 = False
    float_0 = -137.7
    dict_0 = {float_0: float_0}
    float_1 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    var_0 = action_module_0.run()
    assert var_0

# Generated at 2022-06-25 07:13:22.692868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(False, 12.0, {12.0: 12.0}, 12.0, False, 12.0)
    assert True == isinstance(action_module, ActionModule)


# Generated at 2022-06-25 07:13:28.287190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test if action_run is a function of ActionModule
    bool_0 = False
    float_0 = -137.7
    dict_0 = {float_0: float_0}
    float_1 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)

    # Test if it is callable with tmp, task_vars
    assert callable(action_module_0.run(float_1, dict_0))

    del tmp, task_vars


# Generated at 2022-06-25 07:13:30.585532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = -137.7
    dict_0 = {float_0: float_0}
    float_1 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    action_run()

test_case_0()

# Generated at 2022-06-25 07:13:32.076930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True == True


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 07:13:34.543963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_run()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:13:38.366616
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = -137.7
    dict_0 = {float_0: float_0}
    float_1 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)


# Generated at 2022-06-25 07:13:43.000101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = -137.7
    dict_0 = {float_0: float_0}
    float_1 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    str_0 = '`Z0]8Z_'
    var_0 = action_module_0.run(str_0, dict_0)
    var_0 = action_module_0.run(str_0, dict_0)

# Generated at 2022-06-25 07:13:48.406397
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = -137.7
    dict_0 = {float_0: float_0}
    float_1 = -2946.709
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1, bool_0, float_1)
    assert action_module_0.run(None, None)


# Generated at 2022-06-25 07:13:50.924325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Case 0
    #
    # obj = ActionModule(
    #     task, connection, play_context, loader, templar, shared_loader_obj
    # )
    action_module_0 = ActionModule()
    assert(action_module_0 is not None)



# Generated at 2022-06-25 07:13:56.604232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = -438.43
    dict_0 = {'c': 'S'}
    float_1 = -1908.876
    action_module_0 = ActionModule(bool_0, float_0, dict_0, float_1)
    test_case_0()


test_ActionModule()