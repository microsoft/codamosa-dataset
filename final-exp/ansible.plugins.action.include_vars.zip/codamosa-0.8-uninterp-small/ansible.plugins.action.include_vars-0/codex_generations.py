

# Generated at 2022-06-25 07:08:17.366943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b'F\x15a\xa3\x0c!@\xf1\xacd\x08\xe4\xfcd9'
    float_0 = 107.0
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, dict_0, float_0)
    tmp_0 = None
    task_vars_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)

    assert result
    assert not result['failed']

# Generated at 2022-06-25 07:08:26.944092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b'\x1f\x84\x89\x91\xd8\x8f\x83\xd0\x08\xa8\x90\xcdc\x94\xf2\xaa\x7f\x16\x9b\x88\x8f\xc1\x11'
    float_0 = 10.0
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, dict_0, float_0)
    str_0 = '|'
    str_1 = 'a'
    dict_1 = {str_1: action_module_0}

# Generated at 2022-06-25 07:08:33.712751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b'F\x15a\xa3\x0c!@\xf1\xacd\x08\xe4\xfcd9'
    float_0 = 107.0
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, dict_0, float_0)
    action_module_0.run()


# Generated at 2022-06-25 07:08:40.151547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b'F\x15a\xa3\x0c!@\xf1\xacd\x08\xe4\xfcd9'
    float_0 = 107.0
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, dict_0, float_0)

# Generated at 2022-06-25 07:08:49.166376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b'F\x15a\xa3\x0c!@\xf1\xacd\x08\xe4\xfcd9'
    float_0 = 107.0
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, dict_0, float_0)
    action_module_0.run()


# Generated at 2022-06-25 07:08:57.489674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_0['role'] = None
    dict_0['roles_path'] = []
    dict_0['include_tasks'] = []
    dict_0['include_role'] = None
    dict_0['include_vars'] = None
    dict_0['static'] = None
    dict_0['pre_tasks'] = []
    dict_0['post_tasks'] = []
    dict_0['tags'] = []
    dict_0['name'] = 'include_vars'
    dict_0['block'] = []
    dict_0['task'] = []
    dict_0['tasks'] = []
    dict_0['when'] = "True"
    dict_0['args'] = {}
    dict_0['always'] = None

# Generated at 2022-06-25 07:09:04.617573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_0['action'] = 'include_vars'
    dict_0['delegate_to'] = 'localhost'
    dict_0['ignore_files'] = '*.py'
    dict_0['register'] = 'result'
    dict_0['vars'] = dict()
    dict_0['vars']['dir'] = '/etc/ansible/roles/common/vars/'
    dict_0['vars']['depth'] = 1
    dict_0['vars']['files_matching'] = 'regex'
    dict_0['vars']['ignore_files'] = '*.py'
    dict_0['vars']['name'] = 'result'
    dict_0['vars']['extensions'] = 'yaml'
   

# Generated at 2022-06-25 07:09:12.118132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b'F\x15a\xa3\x0c!@\xf1\xacd\x08\xe4\xfcd9'
    float_0 = 107.0
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, dict_0, float_0)
    # Calling run method of class ActionModule
    action_module_0.run()


# Generated at 2022-06-25 07:09:19.672330
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b'F\x15a\xa3\x0c!@\xf1\xacd\x08\xe4\xfcd9'
    float_0 = 107.0
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, dict_0, float_0)
    result = action_module_0.run()
    assert isinstance(result, dict)

# Generated at 2022-06-25 07:09:20.299251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:09:47.161609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule(task_0, connection_0, play_context_0, loader_0, templar_0, shared_loader_obj_0)
    assert var_0.action.strip() == 'meta'


# Generated at 2022-06-25 07:09:55.906667
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:09:57.925427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    var_1 = dict()
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 07:10:02.935136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = test_case_0()
    test_obj = ActionModule()
    test_obj.run(var_0)


# Generated at 2022-06-25 07:10:08.173408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    task = dict()
    task['args'] = dict()

    # Test #0
    try:
        ActionModule(task, dict()).run()
        assert False
    except:
        pass # Expected
    assert var_0 == dict()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:10:13.715877
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task_vars_0 = dict()
    task_vars_0['ansible_play_batch'] = task_vars_0['__ansible_play_hosts'] = [u'localhost']
    task_vars_0['ansible_play_hosts_all'] = [u'localhost']
    task_vars_0['group_names'] = [u'ungrouped']
    task_vars_0['inventory_dir'] = u'~/ansible_dir'
    task_vars_0['inventory_file'] = u'~/ansible_dir/hosts'
    task_vars_0['playbook_dir'] = u'~/ansible_dir'
    task_vars_0['play_hosts'] = [u'localhost']

# Generated at 2022-06-25 07:10:18.596402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize test values
    tmp = "tmp"
    task_vars = dict()
    task_vars["test_task_vars"] = "test_task_vars_var"
    task_vars["result"] = "result_var"
    task_vars["ansible_facts"] = "ansible_facts_var"

    # Call method(s) under test
    actionModuleObj = ActionModule()
    result = actionModuleObj.run(tmp, task_vars)

    # Verify results
    assert isinstance(result, dict)
    assert result["ansible_facts"] == var_0
    assert result["ansible_included_var_files"] == []
    assert result["_ansible_no_log"] == True
    assert result["failed"] == False

# Generated at 2022-06-25 07:10:19.679829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Specifying variable:
    var_0 = ActionModule()


# Generated at 2022-06-25 07:10:21.788234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule(task=test_case_0())
    return obj.run(tmp='tmp', task_vars=test_case_0())

if __name__ == "__main__":
    print(test_ActionModule_run())

# Generated at 2022-06-25 07:10:23.136712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-25 07:10:52.193840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test Method run")
    assert not False


# Generated at 2022-06-25 07:11:03.246409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for ActionModule.run
    # 
    # In addition to "regular" results, the action plugin returns
    # the list of included variables files, and a boolean controlling
    # whether to include the contents of the files in the logs (when 
    # show_content is True, the contents of the files are included in
    # the logs).
    # 
    # The list of included variables files is available in 
    # result['ansible_included_var_files'], and the boolean controlling
    # whether to include the file contents in the logs is available
    # in result['_ansible_no_log'].
    global var_0
    var_0 = dict()
    var_0['file'] = 'value of file'
    var_0['_raw_params'] = 'value of _raw_params'
    var

# Generated at 2022-06-25 07:11:07.542720
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    test_cases = [
        (var_0, ),
    ]

    for test_case in test_cases:
        assert test_case == do_test(*test_case)


# Generated at 2022-06-25 07:11:18.543128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # test case: source_file = None
    with pytest.raises(AnsibleError):
        action_module.run()

    action_module._task.args = dict({'file': 'tests/fixtures/host_vars/host_vars.yml'})
    action_module._set_args()
    action_module._set_root_dir()
    assert action_module.source_file == 'tests/fixtures/host_vars/host_vars.yml'

    action_module._task._ds._data_source = 'tests/fixtures/roles/role_1/tasks/main.yml'

# Generated at 2022-06-25 07:11:19.812514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert var_0 == [], 'Unit test for constructor of class ActionModule is failing !!!'


# Generated at 2022-06-25 07:11:20.531276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()


# Generated at 2022-06-25 07:11:23.182329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule()
    assert var_1 != None


# Generated at 2022-06-25 07:11:31.773430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0['super'] = var_0
    var_0['AnsibleAction'] = var_0
    var_0 = dict()
    var_0['super'] = var_0
    var_0['AnsibleAction'] = var_0
    var_0 = dict()
    var_0['super'] = var_0
    var_0['AnsibleAction'] = var_0
    var_0 = dict()
    var_0['super'] = var_0
    var_0['AnsibleAction'] = var_0
    var_0 = dict()
    var_0['hash_behaviour'] = 0
    var_0['name'] = var_0
    var_0['dir'] = var_0
    var_0['file'] = var_0
    var

# Generated at 2022-06-25 07:11:32.664809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 07:11:34.149334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    obj_0 = ActionModule(var_0)
    obj_0.run()
    assert obj_0.run.__func__


# Generated at 2022-06-25 07:12:09.424278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b"F\x15a'1!@\xf1\xacd\x08\xe4\xfcd9"
    float_0 = 107.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, tuple_0, float_0)

    var_0 = action_run(action_module_0)
    assert var_0.items() == dict_0.items()


# Generated at 2022-06-25 07:12:15.226450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    str_0 = str(complex_0)
    int_0 = int(complex_0)
    complex_0 = complex(complex_0, complex_0)
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    tuple_0 = (TEST_CASE, dict_0)
    dict_0 = {float_0: complex_0, complex_0: complex_0}
    float_0 = float(complex_0)
    bytes_0 = b"F\x15a'1!@\xf1\xacd\x08\xe4\xfcd9"
    float_0 = 107.0
    tuple_0 = ()

# Generated at 2022-06-25 07:12:22.790625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b"F\x15a'1!@\xf1\xacd\x08\xe4\xfcd9"
    float_0 = 107.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, tuple_0, float_0)
    str_0 = action_module_0.run()
    assert str_0 == "ansible_facts"


# Generated at 2022-06-25 07:12:30.916681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b"F\x15a'1!@\xf1\xacd\x08\xe4\xfcd9"
    float_0 = 107.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, tuple_0, float_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:12:31.725945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:12:32.576387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 07:12:37.681560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b"F\x15a'1!@\xf1\xacd\x08\xe4\xfcd9"
    float_0 = 107.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, tuple_0, float_0)


# Generated at 2022-06-25 07:12:40.766623
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create instance of class ActionModule with parameter (dict)
    action_module_instance = ActionModule(dict)
    # Create instance of class ActionModule with parameter (bytes)
    action_module_instance_1 = ActionModule(bytes)
    # Create instance of class ActionModule with parameter (float)
    action_module_instance_2 = ActionModule(float)


# Generated at 2022-06-25 07:12:42.967510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    #line:75
    action_module_0.run()
    #line:76
    action_module_0.run(None, None)



# Generated at 2022-06-25 07:12:50.300269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_1 = None
    dict_1 = {complex_1: complex_1, complex_1: complex_1}
    bytes_1 = b'\xb6\xcc\x0b^\xf8\xdc\xec\x83\xfd_\x8c\x05\x17\x03'
    float_1 = 6.0
    tuple_1 = ()
    action_module_1 = ActionModule(dict_1, bytes_1, float_1, dict_1, tuple_1, float_1)
    assert action_module_1._task.args.get('name') == complex_1
    assert action_module_1._task._role.name == 'asanabria'
    assert action_module_1.name == complex_1

# Generated at 2022-06-25 07:14:03.481161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_0['depth'] = 0
    dict_0['_ansible_verbosity'] = 1
    dict_0['_ansible_syslog_facility'] = 30
    dict_0['_ansible_keep_remote_files'] = 0
    dict_0['extensions'] = ["json", "yml", "yaml"]
    dict_0['_ansible_socket'] = "/tmp/ansible-20170301-988852-187716103388650.sock"
    dict_0['_ansible_check_mode'] = 0
    dict_0['_ansible_selinux_special_fs'] = ["fuse", "nfs", "vboxsf", "ramfs", "9p", "vfat", "iso9660"]

# Generated at 2022-06-25 07:14:15.115695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b"F\x15a'1!@\xf1\xacd\x08\xe4\xfcd9"
    float_0 = 107.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, tuple_0, float_0)
    # Call the run method and check the results

# Generated at 2022-06-25 07:14:18.714119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = test_case_0()
    var_0 = action_run()
    try:
        assert var_0["ansible_included_var_files"][0] == "ansible/test/playbooks/../../vars/example.yml"
        assert var_0["ansible_included_var_files"][1] == "ansible/test/playbooks/../../vars/example2.yml"
    except:
        raise

# Generated at 2022-06-25 07:14:19.381098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-25 07:14:25.991688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b"F\x15a'1!@\xf1\xacd\x08\xe4\xfcd9"
    float_0 = 107.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, tuple_0, float_0)
    assert action_module_0


# Generated at 2022-06-25 07:14:31.988385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b"F\x15a'1!@\xf1\xacd\x08\xe4\xfcd9"
    float_0 = 107.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, tuple_0, float_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:14:38.560185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b"F\x15a'1!@\xf1\xacd\x08\xe4\xfcd9"
    float_0 = 107.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, tuple_0, float_0)


# Generated at 2022-06-25 07:14:48.482803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b"F\x15a'1!@\xf1\xacd\x08\xe4\xfcd9"
    float_0 = 107.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, tuple_0, float_0)
    assert action_module_0._set_dir_defaults() is None
    assert action_module_0._set_args() is None
    assert action_module_0.run() is None
    assert action_module_0._set_root_dir() is None
    assert action_module_0._traverse_dir_depth() is not None
   

# Generated at 2022-06-25 07:14:53.793850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    bytes_0 = b"F\x15a'1!@\xf1\xacd\x08\xe4\xfcd9"
    float_0 = 107.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, bytes_0, float_0, dict_0, tuple_0, float_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:15:03.645318
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_1 = None
    dict_0 = {complex_1: complex_1, complex_1: complex_1}
    bytes_1 = b"A\x12\x11\x04\x0e\xabA\x0f\x8c\xe1\xee\x9c\x1e"
    float_0 = 107.0
    dict_1 = {complex_1: complex_1, complex_1: complex_1}
    tuple_0 = ()
    float_1 = 107.0
    action_module_1 = ActionModule(dict_0, bytes_1, float_0, dict_1, tuple_0, float_1)
    var_0 = action_module_1.run()
