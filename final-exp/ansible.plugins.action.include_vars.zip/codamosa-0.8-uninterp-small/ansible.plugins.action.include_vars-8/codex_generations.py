

# Generated at 2022-06-25 07:08:14.313523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    err_msg = ''
    action_module_0 = ActionModule(err_msg, err_msg, err_msg)

# Generated at 2022-06-25 07:08:17.603332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # str -> dict -> bytes -> set
        ActionModule(str_0, dict_0, bytes_0, set_0)
    except Exception:
        raise Exception


# Generated at 2022-06-25 07:08:24.329857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    params = {
    }
    my_obj = ActionModule(params)
    assert(my_obj.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json'])
    assert(my_obj.VALID_DIR_ARGUMENTS == ['dir', 'depth', 'files_matching', 'ignore_files', 'extensions', 'ignore_unknown_extensions'])
    assert(my_obj.VALID_FILE_ARGUMENTS == ['file', '_raw_params'])
    assert(my_obj.VALID_ALL == ['name', 'hash_behaviour'])


# Generated at 2022-06-25 07:08:26.483428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Run the code
    test_case_0()

# Run the code
test_ActionModule()

# Generated at 2022-06-25 07:08:36.425460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._task = Mock()
    action_module_0._task.args = {
        '_raw_params': '',
        'extensions': ['json', 'yml', 'yaml'],
        'file': './tests/yml/valid.yml',
        'hash_behaviour': 'merge',
        'name': ''
    }
    action_module_0._task._ds = Mock()
    action_module_0._task._ds._data_source = "../ansible_collections/ansible/netcommon/plugins/action/include_vars.py"
    action_module_0._task._role = Mock()
    action_module_0._task._role._role_path = ""


# Generated at 2022-06-25 07:08:45.329862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '4\x95\x8e\xa2\xef\xd2\xbf\xc3(\x06\x86'
    float_0 = 6.81729510873e+222
    float_1 = 4.72151394699e-9
    float_2 = 1.07214068982e+11
    list_0 = ['o', '*', 's', 'b', 'q']
    str_1 = '\xea\x91\x00\x85\xc6\x1c\x9d\xce\xdaB$\xd7H\xa3\xde\x89\x99\xe1\x9f\x1c\xf2\xfd\x0c\x0c'
    bool_0 = True

# Generated at 2022-06-25 07:08:55.694569
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # class ActionModule(ActionBase):
    module = ActionModule()
    tmp = None
    task_vars = None
    str_0 = 'g'
    dict_0 = {str_0: str_0, str_0: str_0}
    str_1 = '.\\;Bg[\rQ'
    dict_1 = {str_1: str_1}
    bytes_0 = b'\xfd!\xd7|\x18\xfa#\xf9'
    set_0 = {dict_1, dict_1, dict_1, dict_1}
    assert module.run(tmp, task_vars) == {
        '_ansible_no_log': False,
        'ansible_facts': {},
        'ansible_included_var_files': []
        }


# Generated at 2022-06-25 07:09:01.899972
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '.\\ACTzI5\x92Q\x04\xc3'
    float_0 = 3.2
    str_1 = '.\\8\x1c\x94\xc7\xec\x8b'
    str_2 = 'l\xe1\x82\x12\xa4\x85\xcc\xd2\xab\xa4'
    int_0 = 106438
    float_1 = 1.8

    test_case_0()
    test_case_1 = ActionModule()

test_ActionModule()

# Generated at 2022-06-25 07:09:13.585793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    param_0 = '$'
    param_1 = {param_0: param_0, param_0: param_0, param_0: param_0, param_0: param_0}
    param_2 = {'&': '&', '&': '&', '&': '&', '&': '&', '&': '&'}
    str_0 = 'lD?\x98'
    str_1 = 'B'
    str_2 = '\x09'
    str_3 = 'G=\xfa\x01\xa2\xd9Y\xaa\x05\xa6\x17\x94'
    str_4 = '\xcd'
    str_5 = '\x88'

# Generated at 2022-06-25 07:09:17.744399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source_file = 'file1.yml'
    action_module_0 = ActionModule()
    source_dir = 'source_dir'
    action_module_0.source_dir = source_dir
    depth = 0
    action_module_0.depth = depth
    files_matching = 'files_matching'
    action_module_0.files_matching = files_matching
    ignore_files = 'ignore_files'
    action_module_0.ignore_files = ignore_files
    valid_extensions = ('valid_extensions',)
    action_module_0.valid_extensions = valid_extensions
    action_module_0.source_file = source_file
    tmp = None
    task_vars = {'task_vars': 'task_vars'}
    action_module_

# Generated at 2022-06-25 07:09:43.021583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var = {}

    # Initialize an instance of class ActionModule
    action_module = ActionModule(var)
    tmp = None
    task_vars = None

    # Call method run on instance of class ActionModule
    return_value = action_module.run(tmp, task_vars)
    assert return_value


# Generated at 2022-06-25 07:09:51.398111
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_2 = {}
    task_vars_2 = {}
    action_module_1 = ActionModule(var_2)
    print('type(action_module_1): ' + str(type(action_module_1)))
    print('action_module_1.run(task_vars = task_vars_2): ' + str(action_module_1.run(task_vars = task_vars_2)))

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:09:53.305867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(ActionModule.run)


# Generated at 2022-06-25 07:09:59.703006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing when argument task_vars is None
    var_1 = {}
    action_module_1 = ActionModule(var_1)
    task_vars_1 = None
    try:
        action_module_1.run(task_vars=task_vars_1)
    except:
        pass
    else:
        assert False, "Expected Exception"


# Generated at 2022-06-25 07:10:10.167630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role


# Generated at 2022-06-25 07:10:20.690017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup a test task where the 'name', 'hash_behaviour' and 'dir' arguments are set.
    task_0 = {}
    task_0['args'] = {}
    task_0['name'] = 'test'
    task_0['hash_behaviour'] = 'merge'
    task_0['args']['name'] = task_0['name']
    task_0['args']['hash_behaviour'] = task_0['hash_behaviour']
    task_0['args']['dir'] = path.join(path.dirname(path.abspath(__file__)), 'vars')
    task_0['args']['ignore_unknown_extensions'] = False
    action_module_0 = ActionModule(task_0)

    # First test: Assign the result of run to a variable

# Generated at 2022-06-25 07:10:25.422500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    action_module_0 = ActionModule(var_0)
    action_module_0.run()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 07:10:27.031469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test 0 - Is constructor of class ActionModule generating")
    test_case_0()


test_ActionModule()

# Generated at 2022-06-25 07:10:29.987298
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except Exception as e:
        assert 0, "Unable to instantiate ActionModule: " + str(e)

# Generated at 2022-06-25 07:10:32.501777
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = {}
    action_module_1 = ActionModule(var_1)
    assert action_module_1 is not '', 'Test Failed'


# Generated at 2022-06-25 07:11:06.070134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert not (ActionModule().run())
    assert not (ActionModule().run(None, None))
    assert not (ActionModule().run(None, test_case_0()))
    assert not (ActionModule().run(test_case_0(), None))
    assert not (ActionModule().run(test_case_0(), test_case_0()))

# Generated at 2022-06-25 07:11:12.543708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        bool_0 = True
        str_0 = "\r4AJg;l#WAyAYT'qt"
        str_1 = ')Odc#@%\nGFXb5\r\n'
        tuple_0 = (str_0, str_1)
        list_0 = [bool_0]
        float_0 = 2238.6052
        set_0 = set()
        int_0 = 50
        action_module_0 = ActionModule(bool_0, tuple_0, list_0, float_0, set_0, int_0)
    except Exception:
        pass


# Generated at 2022-06-25 07:11:20.102230
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:11:22.208177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Creating an instance of class ActionModule
    action_module_2 = ActionModule(bool_0, tuple_0, list_0, float_0, set_0, int_0)
    assert not action_module_2


# Generated at 2022-06-25 07:11:26.550758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'b^YHNyT1wgHy\n'
    str_1 = '#u9&!U\n'
    tuple_0 = (str_0, str_1)
    list_0 = ['', '', '']
    float_0 = 0.4
    set_0 = set()
    int_0 = 82
    action_module_0 = ActionModule(bool_0, tuple_0, list_0, float_0, set_0, int_0)
    # assert action_module_0.run(None, None) == None


# Generated at 2022-06-25 07:11:35.850794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = "Kfz-kK\r\rZl\n1C!<\r"
    str_1 = "\nSNy]Bnv0#NYEauhD"
    dict_0 = dict()
    dict_0['int'] = 26
    dict_0['int'] = 56
    dict_0['list'] = list(())
    dict_0['list'] = list((8, 56))
    dict_0['str'] = str("nZ6U.\nX%\r,2!\nWyR")
    dict_0['str'] = str("\r\rB2r|>#<H\rF\rff,y")
    dict_0['dict'] = dict()
    dict_0['dict'] = dict()
    dict_

# Generated at 2022-06-25 07:11:40.165007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = "S#0?B"
    str_1 = ">tA0L3qhA"
    tuple_0 = (str_0, str_1)
    list_0 = [bool_0]
    float_0 = 3.0
    set_0 = set()
    int_0 = 90
    action_module_0 = ActionModule(bool_0, tuple_0, list_0, float_0, set_0, int_0)


# Generated at 2022-06-25 07:11:41.358950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)


# Generated at 2022-06-25 07:11:49.210171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = "\r4AJg;l#WAyAYT'qt"
    str_1 = ')Odc#@%\nGFXb5\r\n'
    tuple_0 = (str_0, str_1)
    list_0 = [bool_0]
    float_0 = 2238.6052
    set_0 = set()
    int_0 = 50

# Generated at 2022-06-25 07:11:59.346326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = 'DV\rO\x00k\x1f\x07S'
    str_1 = 't'
    tuple_0 = (str_0, str_1)
    list_0 = [0, 0]
    float_0 = 7124.4022
    set_0 = set()
    int_0 = -832657344
    dict_0 = dict()
    dict_0[False] = 0.896
    dict_0['Gq\rT\x1f\x1eU'] = -0.0724
    dict_0[-0.0724] = int_0
    dict_0[0.896] = float_0
    dict_0[0] = set_0
    dict_0[tuple_0] = dict_

# Generated at 2022-06-25 07:12:59.491612
# Unit test for constructor of class ActionModule
def test_ActionModule():

    act = ActionModule()

    assert(act.TRANSFERS_FILES == False)



# Generated at 2022-06-25 07:13:08.395815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = "+b7V\n\n"
    str_1 = "'yQ>([\n\n"
    tuple_0 = (str_0, str_1)
    list_0 = [bool_0]
    float_0 = 2238.6052
    set_0 = set()
    int_0 = 50
    action_module_0 = ActionModule(bool_0, tuple_0, list_0, float_0, set_0, int_0)
    int_0 = 50
    str_0 = "vars"
    str_1 = "tcNg\n"
    dict_0 = dict()
    dict_1 = dict()
    dict_1['name'] = str_0
    dict_1['hash_behaviour'] = str_1
   

# Generated at 2022-06-25 07:13:13.352044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # constructor of class ActionModule
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:13:23.872363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = "\r4AJg;l#WAyAYT'qt"
    str_1 = ')Odc#@%\nGFXb5\r\n'
    tuple_0 = (str_0, str_1)
    list_0 = [bool_0]
    float_0 = 2238.6052
    set_0 = set()
    int_0 = 50
    action_module_0 = ActionModule(bool_0, tuple_0, list_0, float_0, set_0, int_0)
    str_2 = "U%cw]6P(^!+\tY@'R^#"
    bool_1 = False
    action_module_0.action_run(str_2, bool_1)

# Generated at 2022-06-25 07:13:29.451639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = "\r4AJg;l#WAyAYT'qt"
    str_1 = ')Odc#@%\nGFXb5\r\n'
    tuple_0 = (str_0, str_1)
    list_0 = [bool_0]
    float_0 = 2238.6052
    set_0 = set()
    int_0 = 50
    action_module_0 = ActionModule(bool_0, tuple_0, list_0, float_0, set_0, int_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:13:38.810619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = "\r4AJg;l#WAyAYT'qt"
    str_1 = ')Odc#@%\nGFXb5\r\n'
    tuple_0 = (str_0, str_1)
    list_0 = [bool_0]
    float_0 = 2238.6052
    int_0 = 50
    dict_0 = dict()
    action_module_0 = ActionModule(bool_0, tuple_0, list_0, float_0)
    action_module_0.set_loader(dict_0)
    var_0 = action_module_0.run(dict_0, dict_0)



if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:13:40.325506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:13:44.370652
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:13:49.143147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for call of constructor in class ActionModule, with parameters
    bool_0 = True
    str_0 = "\r4AJg;l#WAyAYT'qt"
    str_1 = ')Odc#@%\nGFXb5\r\n'
    tuple_0 = (str_0, str_1)
    list_0 = [bool_0]
    float_0 = 2238.6052
    set_0 = set()
    int_0 = 50
    action_module_0 = ActionModule(bool_0, tuple_0, list_0, float_0, set_0, int_0)



# Generated at 2022-06-25 07:13:57.167157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = '4AJg;l#WAyAYT\'qt)'
    result = action_module_0.run(str_0)

    if not result.get('ansible_included_var_files') is None:
        print(result.get('ansible_included_var_files'))
    if not result.get('ansible_facts') is None:
        print(result.get('ansible_facts'))
    if not result.get('_ansible_no_log') is None:
        print(result.get('_ansible_no_log'))
    if not result.get('message') is None:
        print(result.get('message'))


# Generated at 2022-06-25 07:16:20.735046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the constructor of class ActionModule
    # Simple cases
    bool_0 = True
    str_0 = '+L0Y\\\n3\nA\r'
    tuple_0 = ('cjh;J4U6?\n', 'YT6TJ<\rC9')
    list_1 = [bool_0, bool_0, bool_0]
    str_2 = ':DdXr+LZ#Ng'
    str_3 = 'd5>l)o+qi=?/'
    tuple_1 = (str_2, str_3)
    set_0 = set()
    set_0.add(str_0)
    set_0.add(str_2)
    set_0.add(str_3)

# Generated at 2022-06-25 07:16:23.693622
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up
    try:
        ActionModule()
        assert True
    except TypeError:
        assert False
    except ValueError:
        assert False
    except AssertionError:
        assert False
    except RuntimeError:
        assert False


# Generated at 2022-06-25 07:16:27.719780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 07:16:32.929890
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = '>`3(4<"pkc4[BNR'
    str_1 = '?D2jH8|Yw5g5q>'
    tuple_0 = (str_0, str_1)
    list_0 = [str_0]
    float_0 = -2784.834
    set_0 = set()
    int_0 = 42
    action_module_0 = ActionModule(bool_0, tuple_0, list_0, float_0, set_0, int_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:16:39.616116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'i)'
    str_1 = "|<D"
    tuple_0 = (str_0, str_1)
    list_0 = [bool_0]
    float_0 = 5930.6873
    set_0 = set()
    int_0 = 50
    action_module_0 = ActionModule(bool_0, tuple_0, list_0, float_0, set_0, int_0)
    assert action_module_0._loader._get_file_contents() == (None, None)
    assert action_module_0._task._role._role_path == str_0
    assert isinstance(action_module_0.VALID_FILE_EXTENSIONS, list)

# Generated at 2022-06-25 07:16:43.381318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Running test case 0...')
    test_case_0()
    print('Test case 0 passed.')

test_ActionModule_run()

# Generated at 2022-06-25 07:16:48.198962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:16:53.433265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

test_case_0()

# Generated at 2022-06-25 07:16:54.237453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:17:00.499930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n:: test_ActionModule_run")
    tuple_0 = (bool_0, str_0, str_1)
    list_0 = [bool_0]
    float_0 = 2238.6052
    set_0 = set()
    int_0 = 50
    action_module_0 = ActionModule(bool_0, tuple_0, list_0, float_0, set_0, int_0)
    str_2 = "h\t\n6U5>6\n\nM$Y\n\t\t"
    str_3 = "q0H*\tQ8FkWz\tj"
    str_4 = "8*hdcZ\n"
    str_5 = "O\nU5y\t\tEa"