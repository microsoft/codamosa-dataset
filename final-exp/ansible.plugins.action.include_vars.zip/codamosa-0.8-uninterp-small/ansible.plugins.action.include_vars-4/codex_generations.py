

# Generated at 2022-06-25 07:08:11.630761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing arguments
    tmp = None
    task_vars = None

    # Calling run
    result = ActionModule.run(tmp, task_vars)
    assert result == None


# Generated at 2022-06-25 07:08:13.095209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 07:08:14.433394
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Implement your test here
    raise NotImplementedError()


# Generated at 2022-06-25 07:08:16.681545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated source for class YAML_ActionBase

# Generated at 2022-06-25 07:08:24.966503
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    list_0 = [bool_0, bool_0, bool_0]
    bool_1 = False
    set_0 = set()
    int_0 = 2526
    action_module_0 = ActionModule(bool_0, list_0, bool_1, set_0, int_0, set_0)
    action_module_0._set_args()
    action_module_0._set_dir_defaults()
    action_module_0._set_root_dir()
    bool_2 = True
    action_module_0.show_content = bool_2
    action_module_0.included_files = list()
    action_module_0._task._ds._data_source = 'a/b/c'
    action_module_0._set_root_dir()


# Generated at 2022-06-25 07:08:33.642239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_0 = None
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(task_0, None, None, None, None, None)
    # Call method run of class ActionModule with arguments (task=None, tmp=None, task_vars=None)
    assert action_module_0.run(task_0, tmp_0, task_vars_0)
    # Call method run of class ActionModule with arguments (task=None, tmp=None, task_vars=None)
    assert action_module_0.run(task_0, tmp_0, task_vars_0)
    # Call method run of class ActionModule with arguments (task=None, tmp=None, task_vars=None)

# Generated at 2022-06-25 07:08:34.866309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:08:35.805142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


test_ActionModule()

# Generated at 2022-06-25 07:08:38.846405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule), "constructor of class ActionModule"
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:08:39.928047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == None, "Constructor Test Failed!"



# Generated at 2022-06-25 07:09:07.837631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_correct = dict()
    var = NotImplementedError()


# Generated at 2022-06-25 07:09:12.200354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule(
        task=NotImplementedError,
        connection=None,
        play_context=NotImplementedError,
        loader=NotImplementedError,
        templar=NotImplementedError,
        shared_loader_obj=NotImplementedError
    )


# Generated at 2022-06-25 07:09:22.644471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize the test variables
    action_module_var = ActionModule(action='run')
    test_case_0_tmp = None
    test_case_0_task_vars = None
    test_case_0_results = {'ansible_facts': {'ansible_included_var_files': [], '_ansible_no_log': True, 'failed': True, 'message': 'dir is required'}}
    # Call the method
    try:
        test_case_0_return = action_module_var.run(test_case_0_tmp, test_case_0_task_vars)
    except Exception as err:
        # verify if the exception has the expected type
        assert type(err).__name__ == type(test_case_0_results).__name__


# Generated at 2022-06-25 07:09:31.189972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_N = NotImplementedError()
    # xfail: TypeError: run() missing 1 required positional argument: 'tmp'
    # xfail: TypeError: run() missing 1 required positional argument: 'task_vars'
    """
    test_case_0
    """
    # var_0 - required class attribute
    var_0 = var_N
    """
    test_case_1
    """
    # var_1 - required class attribute
    var_1 = var_N
    """
    test_case_2
    """
    # var_2 - required class attribute
    var_2 = var_N
    """
    test_case_3
    """
    # var_3 - required class attribute
    var_3 = var_N
    """
    test_case_4
    """
    # var

# Generated at 2022-06-25 07:09:36.535107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = None
    var_2 = None
    var_0.run(var_1, var_2)

# Generated at 2022-06-25 07:09:43.947514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    parse_vars = dict()
    tmp = dict()
    dir_arg = dict()
    dir_arg['dir'] = NotImplementedError()
    dir_arg['_raw_params'] = NotImplementedError()
    var_Playbook_data = dict()
    var_Playbook_data['_task'] = dict()
    var_Playbook_data['_task']['args'] = dir_arg
    var_Playbook_data['_task']['_role'] = None
    var_Playbook_data['_task']['_ds'] = NotImplementedError()
    var_Playbook_data['_task']['_ds']['_data_source'] = NotImplementedError()
    var_Playbook_data['show_custom_stats'] = NotImplementedError()
   

# Generated at 2022-06-25 07:09:53.194875
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:09:57.757434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # init obj
    obj = ActionModule(action=test_case_0)
    # run method
    obj.run(
        tmp='tmp',
        task_vars='task_vars'
    )

# Generated at 2022-06-25 07:10:05.897090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_obj = ActionModule()
    path_0 = module_obj._task.args.get('dir', None)
    if not path_0:
        path_0 = module_obj._task.args.get('file', None)
        if path_0:
            path_0 = path_0.rstrip('\n')
    module_obj._set_args()
    module_obj.source_dir = path_0
    module_obj._set_root_dir()
    module_obj._set_dir_defaults()
    module_obj._traverse_dir_depth()
    module_obj._is_valid_file_ext('test')
    module_obj._is_valid_file_ext('test.json')
    module_obj._ignore_file('test')

# Generated at 2022-06-25 07:10:08.323208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(test_case_0.__doc__)
    try:
        x = ActionModule()
        x.run()
    except Exception as e:
        print(e)

test_ActionModule_run()

# Generated at 2022-06-25 07:10:47.038371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_argument_spec = {"file": {"required": False, "choices": ["yaml", "yml", "json"]}, "dir": {"required": False, "choices": ["yaml", "yml", "json"]}}

    var_module = ActionModule(var_argument_spec=var_argument_spec)
    var_result = var_module.run()

    if var_result["ansible_facts"] != "var_result['ansible_facts']":
        test_case_0()
    if var_result["ansible_included_var_files"] != "var_result['ansible_included_var_files']":
        test_case_0()
    if var_result["_ansible_no_log"] != "var_result['_ansible_no_log']":
        test_case_0

# Generated at 2022-06-25 07:10:50.608597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:10:52.157563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = NotImplementedError()


# Generated at 2022-06-25 07:10:53.263342
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = NotImplementedError()


# Generated at 2022-06-25 07:10:56.053318
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule('test_input_as_str')
    assert test.name == 'test_input_as_str'
    test = ActionModule('test_input_as_str', 'test_input_as_str', 15)
    assert test.name == 'test_input_as_str'
    assert test._task == 'test_input_as_str'
    assert test._connection == 15


# Generated at 2022-06-25 07:11:00.571978
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 1. No files loaded in role, no file exists in directory
    # 2. File exists but it is not in the list of valid extensions
    # 3. File exists and is matched, loaded, and valid
    pass


# Generated at 2022-06-25 07:11:03.588967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = NotImplementedError()


# Generated at 2022-06-25 07:11:07.573704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert action.run() == {
        'ansible_facts': {},
        '_ansible_no_log': True,
        'failed': True,
        'message': 'Please provide a `file` or `dir` path'
    }

# Generated at 2022-06-25 07:11:09.757896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        with test_case_0():
            assert False
    except NotImplementedError:
        assert True
    else:
        assert False

# Generated at 2022-06-25 07:11:18.547026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fixture = [
        (False, dict(), dict(), dict()),
        (True, dict(), dict(), dict()),
        (False, dict(), dict(), dict()),
        (False, dict(), dict(), dict()),
        (False, dict(), dict(), dict()),
    ]
    for index, (tmp, task_vars, expected_result, expected_result_1) in enumerate(fixture):
        # Setup test case
        test_case = ActionModule()
        # Exercise test case
        actual_result = test_case.run(tmp, task_vars)
        # Verify results
        assert expected_result == actual_result


# Generated at 2022-06-25 07:11:50.765894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:12:00.176435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'$F\xbe\x7f\xef\x9c xj\xdd\xbe\xb3\xfa\x95%\xe0c\xa4\xe1'
    list_0 = []
    str_0 = '&'
    bool_0 = True
    int_0 = -2412
    str_1 = 'KA '
    action_module_0 = ActionModule(list_0, str_0, bool_0, int_0, list_0, str_1)
    str_2 = "L@S^5"
    str_3 = "mXX\x01^"
    dict_0 = {}
    dict_0 = action_module_0.run(str_2, dict_0)

# Generated at 2022-06-25 07:12:09.185150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'n\xee\x9d\xe3\x8d\xae\xdc\x81\x1a\xb8'
    str_0 = '9g\x181P\xfc\xf1\x1f\xb1\x8a\xda\x97\x9f\x01\x8d\x03\x1e'
    int_0 = -0x0c6758eb
    set_0 = {'\x04\x0c\x1f\x16`\x8d\x0b\x9f\x1c\x0f\x08\x18\x06\x0b'}

# Generated at 2022-06-25 07:12:18.148644
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:12:25.353768
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    str_0 = '\x17'
    bool_0 = False
    int_0 = -79
    str_1 = '_\x00'
    action_module_0 = ActionModule(list_0, str_0, bool_0, int_0, list_0, str_1)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:12:34.222534
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xb9\x8c\x0b\x94\x8f\x7f\x86\xb0\xfd\xd4\x9f\x85\x1f\x93H\xd0\xcf'
    list_0 = []
    str_0 = ')'
    bool_0 = True
    int_0 = -7894
    str_1 = '`.'
    action_module_0 = ActionModule(list_0, str_0, bool_0, int_0, list_0, str_1)
    var_0 = test_case_0()
    return action_module_0;


# Generated at 2022-06-25 07:12:39.861716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'$F\xbe\x7f\xef\x9c xj\xdd\xbe\xb3\xfa\x95%\xe0c\xa4\xe1'
    list_0 = []
    str_0 = '&'
    bool_0 = True
    int_0 = -2412
    str_1 = 'KA '
    action_module_0 = ActionModule(list_0, str_0, bool_0, int_0, list_0, str_1)
    var_0 = action_run(bytes_0)


# Generated at 2022-06-25 07:12:45.852695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'$F\xbe\x7f\xef\x9c xj\xdd\xbe\xb3\xfa\x95%\xe0c\xa4\xe1'
    list_0 = []
    str_0 = '&'
    bool_0 = True
    int_0 = -2412
    str_1 = 'KA '
    action_module_0 = ActionModule(list_0, str_0, bool_0, int_0, list_0, str_1)
    assert action_module_0.C is C
    assert action_module_0.TRANSFERS_FILES is False
    assert action_module_0.VALID_FILE_EXTENSIONS == ['yaml', 'yml', 'json']
    assert action_module_0.VALID_

# Generated at 2022-06-25 07:12:52.050444
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:12:57.290483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_instance = ActionModule()

# Generated at 2022-06-25 07:14:14.208140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xeb\x0b-\x99\x17\xdf\x1e\x9f'
    list_0 = []
    str_0 = '>3'
    bool_0 = True
    int_0 = -2412
    str_1 = 'KA '
    action_module_0 = ActionModule(list_0, str_0, bool_0, int_0, list_0, str_1)
    var_0 = action_run(bytes_0)

# Generated at 2022-06-25 07:14:18.881507
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'$F\xbe\x7f\xef\x9c xj\xdd\xbe\xb3\xfa\x95%\xe0c\xa4\xe1'
    list_0 = []
    str_0 = '&'
    bool_0 = True
    int_0 = -2412
    str_1 = 'KA '
    action_module_0 = ActionModule(list_0, str_0, bool_0, int_0, list_0, str_1)
    var_0 = action_run(bytes_0)



# Generated at 2022-06-25 07:14:27.923419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xdd\x88\x84\xd7\x9b\xd4/\xfa\x81b\x00\x8d\xd9\x9a\x9f\x9c\x8e\x11\xbd\x8f\x8a\x9c\xda'
    list_0 = []
    str_0 = '()'
    bool_0 = True
    int_0 = -6003
    str_1 = '\x1c\x12\x0e\x11\x16\x00'
    action_module_0 = ActionModule(list_0, str_0, bool_0, int_0, list_0, str_1)
    action_module_0.run()


# Generated at 2022-06-25 07:14:38.258201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfe!\xe8\xde\x94\xde\xb1\x1b\xee\x8b'
    list_0 = []
    str_0 = '\xfc\x81'
    bool_0 = True
    int_0 = 203
    dict_0 = {}
    str_1 = '6H'
    list_1 = []
    dict_1 = {}
    list_2 = [bytes_0, list_0, str_0, bool_0, int_0, dict_0, str_1, list_1, dict_1, dict_0]
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}

# Generated at 2022-06-25 07:14:40.007322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    aa = ActionModule()

# Example of how to run unit tests
if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 07:14:46.129605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'$F\xbe\x7f\xef\x9c xj\xdd\xbe\xb3\xfa\x95%\xe0c\xa4\xe1'
    list_0 = []
    str_0 = '&'
    bool_0 = True
    int_0 = -2412
    str_1 = 'KA '
    action_module_0 = ActionModule(list_0, str_0, bool_0, int_0, list_0, str_1)
    action_module_0.run(bytes_0)


# Generated at 2022-06-25 07:14:54.661275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    str_0 = '2`0'
    bool_0 = True
    int_0 = -8654
    list_1 = []
    str_1 = 'D'
    action_module_0 = ActionModule(list_0, str_0, bool_0, int_0, list_1, str_1)
    list_2 = []
    str_2 = 'P%c'
    bool_1 = True
    int_1 = -7469
    str_3 = 'Q\x8a'
    action_module_1 = ActionModule(list_2, str_2, bool_1, int_1, list_0, str_3)
    dict_0 = {}
    dict_1 = {}
    dict_1['ansible_facts'] = dict_0
    dict_

# Generated at 2022-06-25 07:15:01.181013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    str_0 = '&'
    bool_0 = True
    int_0 = -2412
    str_1 = 'KA '
    action_module_0 = ActionModule(list_0, str_0, bool_0, int_0, list_0, str_1)


# Generated at 2022-06-25 07:15:09.219818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def test_case_0():
        bytes_0 = b'$F\xbe\x7f\xef\x9c xj\xdd\xbe\xb3\xfa\x95%\xe0c\xa4\xe1'
        list_0 = []
        str_0 = '&'
        bool_0 = True
        int_0 = -2412
        str_1 = 'KA '
        list_1 = []
        action_module_0 = ActionModule(list_1, str_0, bool_0, int_0, list_0, str_1)
        var_0 = action_run(bytes_0)

    test_case_0()

# Generated at 2022-06-25 07:15:11.048626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.template import ActionModule
    from ansible.module_utils.six import string_types
    from os import path, walk

    test_case_1()
