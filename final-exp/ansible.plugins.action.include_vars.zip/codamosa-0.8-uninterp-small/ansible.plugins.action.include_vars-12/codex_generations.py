

# Generated at 2022-06-25 07:08:18.753324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_0.set_loader(None)
    action_module_0.set_loader(None)
    action_module_0.set_loader(None)
    action_module_0.set_loader(None)
    action_module_0.set_loader(None)
    action_module_0.set_loader(None)
    action_module_0.set_loader(None)
    action_module_0.set_loader(None)
    action_module_0.set_loader(None)
    action_module_0.set_loader(None)
    action_module_0.set_loader(None)
    action_module_0.set_loader(None)
    action_module_0.set_loader(None)
    action_module_0

# Generated at 2022-06-25 07:08:26.036707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    str_0 = 'subelements'
    tuple_0 = None
    bytes_0 = b'\xd4\xce~A\xba\x1fk\xf3\xf7W\xba\x93\x8f(+q'
    list_0 = [bytes_0, set_0, set_0]
    bytes_1 = b'/\xe62p\xa0G\xa8\xd3\xd29.p\xe4\x81'
    action_module_0 = ActionModule(set_0, str_0, tuple_0, list_0, str_0, bytes_1)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:08:28.986841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:08:38.608654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    str_0 = 'Cannot include_vars from a folder when recursion depth specified'
    bytes_0 = b'\xf8\x9b\xa3\xa1\x96\xc8\x1b\xff\xbf#\x89\x8b\xdc\x02\x7f?'
    int_0 = 100
    set_0 = None
    str_1 = 'vars'
    dict_0 = {}
    dict_1 = {"include_vars": "localhost"}
    dict_2 = {str_1: dict_0}
    action_module_0._task.args = dict_1
    action_module_0._task.args['_raw_params'] = dict_2
    action

# Generated at 2022-06-25 07:08:49.939842
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test with valid parameters

    # Test with invalid parameters
    try:
        set_0 = None
        str_0 = 'subelements'
        tuple_0 = None
        bytes_0 = b'\xd4\xce~A\xba\x1fk\xf3\xf7W\xba\x93\x8f(+q'
        list_0 = [bytes_0, set_0, set_0]
        bytes_1 = b'/\xe62p\xa0G\xa8\xd3\xd29.p\xe4\x81'
        action_module_0 = ActionModule(set_0, str_0, tuple_0, list_0, str_0, bytes_1)
    except AssertionError:
        # Do nothing
        pass

    # Test with invalid parameters


# Generated at 2022-06-25 07:08:51.688489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:08:52.844125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('dir')
    action_module_0.run()

# Generated at 2022-06-25 07:09:01.187071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    str_0 = 'subelements'
    tuple_0 = None
    bytes_0 = b'\xd4\xce~A\xba\x1fk\xf3\xf7W\xba\x93\x8f(+q'
    list_0 = [bytes_0, set_0, set_0]
    bytes_1 = b'/\xe62p\xa0G\xa8\xd3\xd29.p\xe4\x81'
    action_module_0 = ActionModule(set_0, str_0, tuple_0, list_0, str_0, bytes_1)

    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:09:01.933249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 07:09:12.919449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    str_0 = 'subelements'
    tuple_0 = None
    bytes_0 = b'\xd4\xce~A\xba\x1fk\xf3\xf7W\xba\x93\x8f(+q'
    list_0 = [bytes_0, set_0, set_0]
    bytes_1 = b'/\xe62p\xa0G\xa8\xd3\xd29.p\xe4\x81'
    action_module_0 = ActionModule(set_0, str_0, tuple_0, list_0, str_0, bytes_1)

    test_case_0()


# Generated at 2022-06-25 07:09:48.044210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('0.0.0.0')
    action_module_0.run('0.0.0.0', task_vars=['0.0.0.0', '0.0.0.0', '0.0.0.0'])
    for _ in range(4):
        action_module_0.run()
    action_module_0.run('0.0.0.0')



# Generated at 2022-06-25 07:09:53.531133
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing constructor of class ActionModule')
    str_0 = 'd'
    action_module_0 = ActionModule(str_0)
    print('Test case 0 is successful')


# Generated at 2022-06-25 07:09:55.222821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case
    test_case_0()


# Generated at 2022-06-25 07:10:05.580396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test'
    int_0 = 0
    dict_0 = dict()
    dict_1 = dict()
    dict_1['ansible_included_var_files'] = list()
    dict_1['ansible_facts'] = dict()
    dict_1['_ansible_no_log'] = False
    dict_0['failed'] = False
    dict_0['message'] = 'test'
    dict_1['failed'] = False
    dict_1['message'] = 'test'
    dict_0['ansible_included_var_files'] = list()
    dict_0['ansible_facts'] = dict()
    dict_0['_ansible_no_log'] = False
    dict_0['failed'] = True
    dict_0['message'] = 'test'
    dict_

# Generated at 2022-06-25 07:10:06.965157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '$fr'
    action_module_0 = ActionModule(str_0)



# Generated at 2022-06-25 07:10:12.787996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params_0 = 'nad'
    task_vars_0 = 'bco'
    str_0 = '*v&+'
    action_module_0 = ActionModule(str_0)
    action_module_0.show_content = True
    action_module_0.included_files = list()
    action_module_0.return_results_as_name = 'ex'
    action_module_0.source_file = 'Yo@'
    action_module_0.depth = 1
    action_module_0.files_matching = 1
    action_module_0.ignore_unknown_extensions = False
    action_module_0.ignore_files = '>z^'
    action_module_0.valid_extensions = list()

# Generated at 2022-06-25 07:10:20.046350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run method')
    str_0 = '$fr'
    # Test for case of None type
    if type(str_0) == str:
        action_module_0 = ActionModule(str_0)
        action_module_0.run()
    else:
        try:
            action_module_0 = ActionModule(str_0)
            action_module_0.run()
        except TypeError:
            print('TypeError was raised as expected')
        else:
            raise Exception('Invalid test case')


# Generated at 2022-06-25 07:10:27.816228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '*\x1cA\x04\x04\xff\x03\x10\xe5\xff^\x14\xff\x1b\xbf\xff\x7f\x08'
    str_1 = 'lo\xff\x7f\x83o\xff\x7f\xbf\\\xff\x7f\x01\x00\x00'
    str_2 = '\x14@\x00\x01\x00\x00\x00'
    int_0 = 80
    int_1 = 168
    int_2 = 120
    int_3 = 15
    int_4 = 128
    int_5 = 16
    int_6 = 0
    bool_0 = True
    bool_1 = False
    int_7 = 152
    int_

# Generated at 2022-06-25 07:10:30.420951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None)
    assert action_module_0

test_ActionModule()
test_case_0()

# Generated at 2022-06-25 07:10:38.698609
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = 'S*h#'
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()
    dict_18 = dict()
    dict_19 = dict()
    dict_20 = dict()
    dict_21 = dict()


# Generated at 2022-06-25 07:11:29.571308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test whether the function throws an expected exception/error
    with pytest.raises(AnsibleError, match=r'^Invalid type for "extensions" option, it must be a list$'):
        str_0 = '$fr'
        action_module_0 = ActionModule(str_0)
        action_module_0._set_args()
        str_1 = '$fr'
        action_module_0.source_file = str_1
        dict_0 = dict({'$fr':'$fr'})
        action_module_0.run(task_vars=dict_0)


# Generated at 2022-06-25 07:11:38.051248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_str_0 = 'w?r'
    task_vars_str_0 = 'N'
    results_str_0 = action_module_0.run(tmp_str_0, task_vars_str_0)
    assert isinstance(results_str_0, dict)
    assert 'ansible_facts' in results_str_0
    assert '_ansible_no_log' in results_str_0
    assert 'ansible_included_var_files' in results_str_0

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:11:42.682311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None
    action_module_0 = ActionModule()
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:11:44.430587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == None

if __name__ == "__main__":
    test_ActionModule()
    print('Tests Passed')

# Generated at 2022-06-25 07:11:45.252251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert True


# Generated at 2022-06-25 07:11:48.459848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '$fr'
    action_module_0 = ActionModule(str_0)
    # test getter
    assert action_module_0.name == str_0, "expected ActionModule.name == '$fr', got %s" % action_module_0.name


# Generated at 2022-06-25 07:11:51.591476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

if __name__ == '__main__' :
    test_ActionModule()

# Generated at 2022-06-25 07:11:56.342564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '$fr'
    action_module_0 = ActionModule(str_0)


# Generated at 2022-06-25 07:12:02.068169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = '$fr'
    result = action_module_0.run(str_0, str_0)
    assert result is None


# Generated at 2022-06-25 07:12:03.353666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '$fr'
    action_module_0 = ActionModule(str_0)

# Generated at 2022-06-25 07:12:57.267306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0x72c
    bytes_0 = b'9\x1a\x0e\x0f!\x1d\xba\x92\x87\n\xe6\xdb\xc8\x92\x87\x81\xea\x1c'
    int_1 = 0x9e2
    bytes_1 = b'\x85\x01\xa5\x80\xb1\x1b\x020\x0b\x8b\x07\xbe{\x01\x00 \x80\x98\xf0'
    bytes_2 = b'\xc6\xac\x00\xbb\x1a\x0f\xa2\x9c\x1b'
    list_0 = list()

# Generated at 2022-06-25 07:13:05.242311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = 1575
    str_0 = 'X\'8\t\n'
    bytes_0 = b'\xfc\x8e1\xb5\xe8\x1f\x1c\xc9\x96\x1djce\x9av'
    tuple_0 = (int_0, set_0)
    action_module_0 = ActionModule(set_0, str_0, tuple_0, bytes_0, set_0, bytes_0)
    action_module_0.run()


# Generated at 2022-06-25 07:13:16.480267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2656
    bytes_0 = b'/c\xfcC\x8e1\xb5\xe8\x1f\x1c\xc9\x96\x1djce\x9av'
    bytes_1 = b'\xcc\xb2\xf0\xd9\xd0u\x90\x8d-'
    set_0 = set()
    dict_0 = {bytes_1: bytes_1, bytes_1: set_0, bytes_1: set_0, bytes_1: set_0}
    int_1 = 401
    float_0 = 0.0
    tuple_0 = (int_1, float_0)
    bool_0 = False
    float_1 = -581.0

# Generated at 2022-06-25 07:13:23.481753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    tuple_0 = ()
    bool_0 = False
    set_0 = set()
    float_0 = -581.0
    str_0 = '4/OBF4,dQ\t\n'
    action_module_0 = ActionModule(dict_0, tuple_0, bool_0, set_0, float_0, str_0)
    action_module_0.included_files = apply(test_case_0, tuple_0)
    assert action_module_0.included_files == 23014



# Generated at 2022-06-25 07:13:24.075092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-25 07:13:30.588400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 2656
    bytes_0 = b'/c\xfcC\x8e1\xb5\xe8\x1f\x1c\xc9\x96\x1djce\x9av'
    bytes_1 = b'\xcc\xb2\xf0\xd9\xd0u\x90\x8d-'
    set_0 = set()
    dict_0 = {bytes_1: bytes_1, bytes_1: set_0, bytes_1: set_0, bytes_1: set_0}
    int_1 = 401
    float_0 = 0.0
    tuple_0 = (int_1, float_0)
    bool_0 = False
    float_1 = -581.0

# Generated at 2022-06-25 07:13:40.132021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2656
    bytes_0 = b'/c\xfcC\x8e1\xb5\xe8\x1f\x1c\xc9\x96\x1djce\x9av'
    bytes_1 = b'\xcc\xb2\xf0\xd9\xd0u\x90\x8d-'
    set_0 = set()
    dict_0 = {bytes_1: bytes_1, bytes_1: set_0, bytes_1: set_0, bytes_1: set_0}
    int_1 = 401
    float_0 = 0.0
    tuple_0 = (int_1, float_0)
    bool_0 = False
    float_1 = -581.0

# Generated at 2022-06-25 07:13:51.240661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run')
    int_0 = 2656
    bytes_0 = b'/c\xfcC\x8e1\xb5\xe8\x1f\x1c\xc9\x96\x1djce\x9av'
    bytes_1 = b'\xcc\xb2\xf0\xd9\xd0u\x90\x8d-'
    set_0 = set()
    dict_0 = {bytes_1: bytes_1, bytes_1: set_0, bytes_1: set_0, bytes_1: set_0}
    int_1 = 401
    float_0 = 0.0
    tuple_0 = (int_1, float_0)
    bool_0 = False
    float_1 = -581.0

# Generated at 2022-06-25 07:14:00.258606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    __tracebackhide__ = True
    int_0 = 2656
    bytes_0 = b'/c\xfcC\x8e1\xb5\xe8\x1f\x1c\xc9\x96\x1djce\x9av'
    bytes_1 = b'\xcc\xb2\xf0\xd9\xd0u\x90\x8d-'
    set_0 = set()
    dict_0 = {bytes_1: bytes_1, bytes_1: set_0, bytes_1: set_0, bytes_1: set_0}
    int_1 = 401
    float_0 = 0.0
    tuple_0 = (int_1, float_0)
    bool_0 = False
    float_1 = -581.0

# Generated at 2022-06-25 07:14:08.323901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 2656
    bytes_0 = b'/c\xfcC\x8e1\xb5\xe8\x1f\x1c\xc9\x96\x1djce\x9av'
    bytes_1 = b'\xcc\xb2\xf0\xd9\xd0u\x90\x8d-'
    set_0 = set()
    dict_0 = {bytes_1: bytes_1, bytes_1: set_0, bytes_1: set_0, bytes_1: set_0}
    int_1 = 401
    float_0 = 0.0
    tuple_0 = (int_1, float_0)
    bool_0 = False
    float_1 = -581.0

# Generated at 2022-06-25 07:16:05.556115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2656
    bytes_0 = b'/c\xfcC\x8e1\xb5\xe8\x1f\x1c\xc9\x96\x1djce\x9av'
    bytes_1 = b'\xcc\xb2\xf0\xd9\xd0u\x90\x8d-'
    set_0 = set()
    dict_0 = {bytes_1: bytes_1, bytes_1: set_0, bytes_1: set_0, bytes_1: set_0}
    int_1 = 401
    float_0 = 0.0
    tuple_0 = (int_1, float_0)
    bool_0 = False
    float_1 = -581.0

# Generated at 2022-06-25 07:16:16.710453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 2656
    bytes_0 = b'/c\xfcC\x8e1\xb5\xe8\x1f\x1c\xc9\x96\x1djce\x9av'
    bytes_1 = b'\xcc\xb2\xf0\xd9\xd0u\x90\x8d-'
    set_0 = set()
    dict_0 = {bytes_1: bytes_1, bytes_1: set_0, bytes_1: set_0, bytes_1: set_0}
    int_1 = 401
    float_0 = 0.0
    tuple_0 = (int_1, float_0)
    bool_0 = False
    float_1 = -581.0

# Generated at 2022-06-25 07:16:27.027409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 8287
    bytes_0 = b'\x98\x91\x16\x8fC\x8a\xfa\x94mm\x08\x9a\xb3\x92\xd7\x0b\xab\xc1'
    bytes_1 = b'\x8a\x17]\x83\x0f\x0e\xfc\x92\x0c\xb4\x8c\xee\x12\xb7$'
    set_0 = {bytes_0, bytes_1, bytes_1, bytes_0, bytes_0, bytes_1}
    dict_0 = {bytes_0: set_0, bytes_0: bytes_1, bytes_1: set_0}
    int_1 = 615
    float_0 = 59

# Generated at 2022-06-25 07:16:33.498510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2
    bytes_0 = b'G'
    bytes_1 = b'\xf8\x1a\x96\xec\xc4EA)4\xa4\xdd\xd5\x0e\xfcx'
    set_0 = set()
    dict_0 = {bytes_0: int_0, bytes_1: bytes_0}
    int_1 = 4752
    float_0 = 0.0
    tuple_0 = (int_1, float_0)
    dict_1 = dict()
    float_1 = -4.7
    str_0 = '}'
    action_module_0 = ActionModule(dict_0, tuple_0, dict_1, set_0, float_1, str_0)
    action_module_0.runner = MagicM

# Generated at 2022-06-25 07:16:42.170707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2656
    bytes_0 = b'/c\xfcC\x8e1\xb5\xe8\x1f\x1c\xc9\x96\x1djce\x9av'
    bytes_1 = b'\xcc\xb2\xf0\xd9\xd0u\x90\x8d-'
    set_0 = set()
    dict_0 = {bytes_1: bytes_1, bytes_1: set_0, bytes_1: set_0, bytes_1: set_0}
    int_1 = 401
    float_0 = 0.0
    tuple_0 = (int_1, float_0)
    bool_0 = False
    float_1 = -581.0

# Generated at 2022-06-25 07:16:43.190768
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test ActionModule")
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:16:54.076022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1459
    bytes_0 = b'>\xcf\xbd\x8c\xb9&\x06\x1f\xce\x8cz\xc1\xad\x94\xed\x93\x9b\xb3\xdd\xf6\x0b\x1c\xbc\x0b\xdd\x9e'
    int_1 = 1498
    tuple_0 = (int_0, bytes_0)
    bool_0 = True
    set_0 = set()
    float_0 = -4.0
    str_0 = '\x16\x18\x1a\x1c\x1e\x17\x192'

# Generated at 2022-06-25 07:17:00.408420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2656
    bytes_0 = b'/c\xfcC\x8e1\xb5\xe8\x1f\x1c\xc9\x96\x1djce\x9av'
    bytes_1 = b'\xcc\xb2\xf0\xd9\xd0u\x90\x8d-'
    set_0 = set()
    dict_0 = {bytes_1: bytes_1, bytes_1: set_0, bytes_1: set_0, bytes_1: set_0}
    int_1 = 401
    float_0 = 0.0
    tuple_0 = (int_1, float_0)
    bool_0 = False
    float_1 = -581.0

# Generated at 2022-06-25 07:17:10.262542
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 164
    bytes_0 = b'\xe6\xe9\x9a\x9d\xbdP\x92$\xff3\x8c%\xa2\x81x'
    bytes_1 = b'\xf7\xdf\xeb\x80\xcb\xa6\xcb\x1a\x9b'
    set_0 = set()
    dict_0 = {bytes_1: bytes_1, bytes_1: bytes_1, bytes_1: set_0, bytes_1: bytes_1}
    int_1 = 2126
    float_0 = 0.0
    tuple_0 = (int_1, float_0)
    bool_0 = False
    float_1 = 23.0

# Generated at 2022-06-25 07:17:11.301719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()