

# Generated at 2022-06-10 21:45:20.257897
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(
        'a',
        [('a', str)],
    )== str
    assert get_repr_function(
        'a',
        [(str, str)],
    )== str
    assert get_repr_function(
        'a',
        [(str, id)],
    )== id
    assert get_repr_function(
        'a',
        [(str, str), (str, id)],
    )== id
    assert get_repr_function(
        u'a',
        [(str, str), (unicode, id)],
    )== str
    assert get_repr_function(
        u'a',
        [(unicode, id), (str, str)],
    )== id

# Generated at 2022-06-10 21:45:32.662688
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A(object):
        def __init__(self, name):
            self.name = name
        def __repr__(self):
            return 'A({})'.format(self.name)
    class B(object):
        def __str__(self):
            return 'b'
    assert get_shortish_repr(A('x'), max_length=5) == 'A(x)'
    assert get_shortish_repr(A('x'), max_length=6) == 'A(x)'
    assert get_shortish_repr(A('x'), max_length=7) == 'A(x)'
    assert get_shortish_repr(A('x'), max_length=8) == 'A(x)'
    assert get_shortish_repr(A('x'), max_length=9)

# Generated at 2022-06-10 21:45:40.796709
# Unit test for function get_repr_function
def test_get_repr_function():
    import numbers
    assert get_repr_function(3) == repr
    assert get_repr_function(3, custom_repr=[(numbers.Integral, None)]) is None
    assert get_repr_function(3, custom_repr=[(int, None)]) is None
    assert get_repr_function(
        3, custom_repr=[((lambda x: x > 2), None)]
    ) is None
    assert get_repr_function(3, custom_repr=[(str, None)]) == repr



# Generated at 2022-06-10 21:45:44.788302
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .str import StringIO, StringStream
    from .file import FileStream

    assert WritableStream.__subclasshook__(StringIO) is True
    assert WritableStream.__subclasshook__(StringStream) is True
    assert WritableStream.__subclasshook__(FileStream) is True

# Generated at 2022-06-10 21:45:55.549308
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr(['hello']) == "('hello',)"
    assert get_shortish_repr(['hello', 'hello']) == "('hello', 'hello')"
    assert get_shortish_repr('hello', custom_repr=[(str, lambda x: 'str')]) == 'str'
    assert get_shortish_repr(
        'hello', custom_repr=[(str, lambda x: 'str')], max_length=3
    ) == 'str'
    assert get_shortish_repr(
        'hello', custom_repr=[(str, lambda x: 'str')], max_length=5
    ) == 'str'

# Generated at 2022-06-10 21:46:02.352114
# Unit test for function get_repr_function
def test_get_repr_function():
    from .python_toolbox import cute_iter_tools
    assert get_repr_function(1, ((int, str,), lambda i: 'Yay')) == str
    assert get_repr_function(3.14, ((int, str,), lambda i: 'Yay')) == repr
    assert get_repr_function([1, 2], ((int, str,), lambda i: 'Yay')) == repr

# Generated at 2022-06-10 21:46:08.539887
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamTester(WritableStream):
        def __init__(self):
            self.written_chunks = []

        def write(self, chunk):
            self.written_chunks.append(chunk)
    s = WritableStreamTester()
    s.write('hello')
    s.write(' you')
    assert s.written_chunks == ['hello', ' you']

# Generated at 2022-06-10 21:46:12.296418
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class SubWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(SubWritableStream, WritableStream)



# Generated at 2022-06-10 21:46:24.859875
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('abc') == 'abc'

# Generated at 2022-06-10 21:46:30.926685
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamThatPrintsToSysStdout(WritableStream):
        def write(self, s):
            sys.stdout.write(s)
    WritableStream.register(WritableStreamThatPrintsToSysStdout)
    assert issubclass(WritableStreamThatPrintsToSysStdout, WritableStream)
    assert isinstance(WritableStreamThatPrintsToSysStdout(), WritableStream)

# Generated at 2022-06-10 21:46:40.207085
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class MyClass(object):
        def __repr__(self):
            return 'this is a repr'
        def __str__(self):
            return 'this is a str'

    assert get_shortish_repr(MyClass()) == 'this is a repr'
    assert get_shortish_repr(MyClass(), normalize=True) == 'this is a repr'

    assert get_shortish_repr(MyClass(), max_length=5) == 'this...'
    assert get_shortish_repr(MyClass(), max_length=5, normalize=True) == 'this...'

    assert get_shortish_repr(MyClass(), custom_repr=((MyClass, str),), max_length=5) == 'this...'

# Generated at 2022-06-10 21:46:48.970494
# Unit test for function get_repr_function
def test_get_repr_function():
    def assert_get_repr_function(item, repr_function, custom_repr=()):
        assert repr_function == get_repr_function(item, custom_repr)
    assert_get_repr_function(None, repr, custom_repr=[])
    assert_get_repr_function(None, str, custom_repr=[(lambda x: x is None, str)])
    assert_get_repr_function('', str, custom_repr=[])
    assert_get_repr_function('', repr, custom_repr=[(str, repr)])



# Generated at 2022-06-10 21:46:59.526089
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('abc', (
        (str, str.upper),
        (lambda x: isinstance(x, int), hex),
    )) == str.upper
    assert get_repr_function(123, (
        (str, str.upper),
        (lambda x: isinstance(x, int), hex),
    )) == hex
    assert get_repr_function(None, (
        (str, str.upper),
        (lambda x: isinstance(x, int), hex),
    )) == repr
    assert get_repr_function(123, (
        (str, str.upper),
        (int, hex),
    )) == hex

# Generated at 2022-06-10 21:47:02.432866
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Stream(object):
        def write(self, s):
            pass
    assert isinstance(Stream(), WritableStream)



# Generated at 2022-06-10 21:47:06.781155
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert hasattr(WritableStream, 'write')
    assert isinstance(WritableStream.write, classmethod)
    assert sys.stdout is not None
    assert isinstance(sys.stdout, WritableStream)
    assert sys.stdout.write('Hello') is None


# Generated at 2022-06-10 21:47:15.977939
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr(b'hello') == "b'hello'"
    assert get_shortish_repr(b'hello', max_length=8) == "b'hell..."
    assert get_shortish_repr(b'hello', max_length=9) == "b'hello'"
    assert get_shortish_repr(b'hello', max_length=10) == "b'hello'"
    assert get_shortish_repr(b'hello', max_length=11) == "b'hello'"
    assert get_shortish_repr(b'hello', max_length=None) == "b'hello'"
    assert get_shortish_repr(b'hello', max_length=5) == "b'..."


# Generated at 2022-06-10 21:47:27.951063
# Unit test for function shitcode
def test_shitcode():
    for x in ['a', '1', '€', 'é', 'ø', 'Æ', 'Ç', 'Y', '\t', '\n', '\r', ' ',
              '\x00', '\x01', '\x07', '\x08', '\x0e', '\x0f', '\x10',
              '\x7e', '\x7f']:
        assert shitcode(x) == x

    assert shitcode('\x01\x02\x03\x04\x05\x06\x07\x09\x0b\x0c\x0d\x0e\x0f') \
        == '??????\t\x0b\x0c\r\x0e?'



# Generated at 2022-06-10 21:47:36.515953
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(4, max_length=5) == '4'
    assert get_shortish_repr((1, 2, 3), max_length=10) == '(1, 2, 3)'
    assert get_shortish_repr((1, 2, 3), max_length=4) == '(...'
    assert get_shortish_repr((1, 2, 3), max_length=3) == '(1, ...'
    assert get_shortish_repr((1, 2, 3), max_length=2) == '(1, ...'
    assert get_shortish_repr((1, 2, 3), max_length=1) == '(1, ...'
    assert get_shortish_repr((1, 2, 3), max_length=0) == '(1, ...'



# Generated at 2022-06-10 21:47:41.035944
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    
    class A(WritableStream):
        def __init__(self):
            self.output = ''
        def write(self, s):
            self.output += s
    
    a = A()
    a.write('hello')
    
    assert a.output == 'hello'

# Generated at 2022-06-10 21:47:52.869068
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    for write in [
        lambda x: print(x, end=''),
        lambda x: None,
        lambda x: sys.stdout.write(x),
    ]:
        class A(WritableStream):
            def write(self, x):
                return write(x)

        a = A()
        a.write('hello world')



# Unit tests for function write_to_stream
# def test_write_to_stream():
#     write_to_stream(sys.stdout, 'hi')
#     write_to_stream(sys.stdout, 'there')
#     assert not sys.stdout.closed
#     write_to_stream(sys.stdout, 'there', flush=True)
#     assert not sys.stdout.closed
#     stream = io.StringIO()
#     write_

# Generated at 2022-06-10 21:47:58.414731
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.output = ''
        def write(self, s):
            self.output += s
    x = MyWritableStream()
    x.write('hello')
    assert x.output == 'hello'

# Generated at 2022-06-10 21:48:06.998842
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('a\u00ff') == 'a?'

    # CPython > 2
    if sys.version_info[:2] > (2, 6):
        try:
            assert shitcode('') == ''
        except UnicodeDecodeError:
            pass
        else:
            raise Exception(
                'Expecting `shitcode(...)` to give a `UnicodeDecodeError` '
                'error on an empty string in CPython > 2.'
            )

# Generated at 2022-06-10 21:48:18.461839
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello world') == repr('hello world')
    assert get_shortish_repr(12) == repr(12)
    assert get_shortish_repr(12, max_length=100) == repr(12)
    assert get_shortish_repr(12, max_length=10) == repr(12)

    assert get_shortish_repr('hello world', max_length=10) == '\'hel...d\''

    class A:
        def __init__(self):
            self.foo = 123

        def __repr__(self):
            return 'A'

    assert get_shortish_repr(A()) == 'A'

    class B:
        pass
    assert get_shortish_repr(B()) == 'B()'


# Generated at 2022-06-10 21:48:25.104830
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('') == "''"
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', 5) == "'hel...'"
    assert get_shortish_repr(range(1), 5) == 'range(0,...'
    assert get_shortish_repr(range(1), 5, True) == 'range(0,'



# Generated at 2022-06-10 21:48:34.280788
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr('hi', max_length=2) == 'hi'
    assert get_shortish_repr('hi', max_length=1) == 'h...'
    assert get_shortish_repr('hi', max_length=3) == 'hi'
    assert get_shortish_repr([1, 2, 3], max_length=2) == '[1, ...]'
    assert get_shortish_repr([1, 2, 3], max_length=3) == '[1, ...]'
    assert get_shortish_re

# Generated at 2022-06-10 21:48:41.423498
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            return s

    class B: pass

    class C(WritableStream):
        def write(self, s):
            return s

    assert issubclass(A, WritableStream)
    assert issubclass(C, WritableStream)
    assert not issubclass(B, WritableStream)


if __name__ == '__main__':
    test_WritableStream_write()

# Generated at 2022-06-10 21:48:43.800247
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, x):
            pass
    assert issubclass(A, WritableStream)
    a = A()
    a.write('hello')


# Generated at 2022-06-10 21:48:51.526649
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.data = ''
            super(MyWritableStream, self).__init__()

        def write(self, s):
            self.data += s

    my_stream = MyWritableStream()
    my_stream.write('spam\n')
    my_stream.write('eggs\n')
    assert my_stream.data == 'spam\neggs\n'

# Generated at 2022-06-10 21:48:58.495447
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    c = 'hello there'
    assert get_shortish_repr(c, max_length=100) == c
    assert get_shortish_repr(c, max_length=50) == c
    assert get_shortish_repr(c, max_length=5) == c
    assert get_shortish_repr(c, max_length=4) == 'h...'
    assert get_shortish_repr(c, max_length=3) == 'he...'
    assert get_shortish_repr(c, max_length=2) == 'he...'
    assert get_shortish_repr(c, max_length=1) == '...'
    assert get_shortish_repr(c, max_length=0) == '...'

# Generated at 2022-06-10 21:49:06.484540
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([1, 2, 3], max_length=10) == \
                                                      '(1, 2, 3)'
    assert get_shortish_repr([1, 2, 3, 4, 5], max_length=10) == \
                                                '(1, 2, 3)...(4, 5)'
    assert get_shortish_repr(b'hi', max_length=10) == 'b\'hi\''
    assert get_shortish_repr(b'hi', max_length=3) == 'b\'...\''

# Generated at 2022-06-10 21:49:11.660900
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    assert issubclass(io.StringIO, WritableStream)
    assert not issubclass(io.StringIO, WritableStream)

# Generated at 2022-06-10 21:49:20.000110
# Unit test for function get_repr_function
def test_get_repr_function():
    class Dummy1:
        pass

    class Dummy2:
        pass

    dummy1 = Dummy1()
    dummy2 = Dummy2()

    assert get_repr_function(dummy1, ()) is repr
    assert get_repr_function(dummy1, ((Dummy1, str),)) is str
    assert get_repr_function(dummy2, ((Dummy1, str),)) is repr
    assert get_repr_function(5, ((int, str),)) is str
    assert get_repr_function(5, ((float, str),)) is repr
    assert get_repr_function(5, ((float, str), (int, str))) is str

    assert get_repr_function(5, (('5', str),)) is str

# Generated at 2022-06-10 21:49:22.734550
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class BogusWritableStream(WritableStream):
        def write(self, s):
            pass

    BogusWritableStream.write('bla')





# Generated at 2022-06-10 21:49:27.864057
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class Foo(object):
        def write(self, s):
            pass

    assert isinstance(Foo(), WritableStream)

    class Bar(Foo, object):
        pass

    assert isinstance(Bar(), WritableStream)

    class Foo2(object):
        pass

    assert not isinstance(Foo2(), WritableStream)



# Generated at 2022-06-10 21:49:32.653152
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class StreamSpy(object):
        def __init__(self):
            self.written_items = []

        def write(self, item):
            self.written_items.append(item)
    stream_spy = StreamSpy()
    assert isinstance(stream_spy, WritableStream)
    stream_spy.write('foo')
    assert stream_spy.written_items == ['foo']

# Generated at 2022-06-10 21:49:35.138050
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'abc\n') == u'abc\n'
    asser

# Generated at 2022-06-10 21:49:37.280092
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C(WritableStream):
        def write(self, s):
            return

    assert issubclass(C, WritableStream)



# Generated at 2022-06-10 21:49:39.490361
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            print(s)
    assert isinstance(MyWritableStream(), WritableStream)



# Generated at 2022-06-10 21:49:40.960462
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert _check_methods(file, 'write')



# Generated at 2022-06-10 21:49:46.217450
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStream:
        def write(self, s):
            return s
    assert issubclass(WritableStream, WritableStream)
    assert not issubclass(int, WritableStream)
    assert not issubclass(int, ABC)
    assert issubclass(WritableStream, ABC)



# Generated at 2022-06-10 21:49:58.367735
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert (get_shortish_repr(1, max_length=None) ==
            repr(1))
    assert (get_shortish_repr(1, max_length=5) ==
            repr(1))
    assert (get_shortish_repr(1, max_length=2) ==
            '1')
    assert (get_shortish_repr((1, 2, 3), max_length=10) ==
            repr((1, 2, 3)))
    assert (get_shortish_repr((1, 2, 3), max_length=8) ==
            '(1, ...)')
    assert (get_shortish_repr((1, 2, 3), max_length=7) ==
            '(1, ...)')

# Generated at 2022-06-10 21:50:08.540340
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr(False) == 'False'
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(b'abc') == "b'abc'"
    assert get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert get_shortish_repr({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(b'abc', max_length=5) == "b'abc'"

# Generated at 2022-06-10 21:50:14.062790
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.content = ''
        def write(self, s):
            self.content += s
    obj = MyWritableStream()
    obj.write('hi')
    assert obj.content == 'hi', repr(obj.content)


# Generated at 2022-06-10 21:50:21.913368
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr('abc' * 1000) == 'abcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabc...'

# Generated at 2022-06-10 21:50:26.575615
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestClass(WritableStream):
        def write(self, s):
            return

    c = TestClass()
    c.write('hello, world!')
    try:
        assert issubclass(TestClass, WritableStream)
    except NameError:  # pragma: no cover
        pass


if __name__ == '__main__':
    test_WritableStream_write()

# Generated at 2022-06-10 21:50:31.726358
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Subclass(WritableStream):
        def __init__(self):
            self.write_called = False

        def write(self, *args, **kwargs):
            self.write_called = True

    sub = Subclass()

    assert issubclass(Subclass, WritableStream)
    assert isinstance(sub, WritableStream)



# Generated at 2022-06-10 21:50:37.825197
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Sample(WritableStream):
        def __init__(self):
            self.data = ''
        def write(self, data):
            self.data += data
    assert isinstance(Sample(), WritableStream)
    s = Sample()
    s.write('a')
    assert s.data == 'a'
    s.write('b')
    assert s.data == 'ab'



# Generated at 2022-06-10 21:50:47.086888
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    x = [lambda: 17, u'hello', 2.5, {'a': 2}, 'a', (1, 2, 3),
         b'unicode', b'\xc3\xa9\xc3\xb5\xc3\xbb\xc3\xb0\xc2\xab',
         DEFAULT_REPR_RE]
    prefix = 'VVVVV'
    prefix_length = len(prefix)
    max_length = prefix_length + 10
    for item in x:
        r = get_shortish_repr(item, max_length=max_length)
        assert len(r) <= max_length
        assert r.startswith(prefix)
        assert r.endswith(prefix)



# Generated at 2022-06-10 21:50:54.722949
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr((1, 2, 3), max_length=4) == '(1, ...)'
    assert get_shortish_repr([1, 2, 3], max_length=4) == '[1, ...]'
    assert get_shortish_repr([1, 2, 3], max_length=5) == '[1, ...]'

# Generated at 2022-06-10 21:51:06.871881
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    print('Testing function', get_shortish_repr.__name__)
    assert get_shortish_repr(object) == "<type 'object'>"
    assert get_shortish_repr(set) == "<type 'set'>"
    assert get_shortish_repr(set([1, 2, 3])) in ["set([1, 2, 3])",
                                                 "set([1, 3, 2])"]
    def custom(x):
        return 'custom'
    assert get_shortish_repr(object, custom_repr=[(object, custom)]) == "custom"
    assert get_shortish_repr(set([1, 2, 3]), max_length=15) in ["set([1, 2, 3])",
                                                         "set([1, 3, 2])"]
    assert get_

# Generated at 2022-06-10 21:51:14.894072
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyWritableStream(WritableStream):
        def write(self, s):
            return len(s)

    class NotWritableStream:
        def write(self, s):
            return len(s)

    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(NotWritableStream, WritableStream)




# Generated at 2022-06-10 21:51:25.438061
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from python_toolbox import identity
    from python_toolbox import boggling
    from . import dot_notation

    assert get_shortish_repr(3) == '3'
    assert get_shortish_repr([1, 2, 3, 4]) == '[1, 2, 3, 4]'
    assert get_shortish_repr([1, 2, 3, 4], max_length=20) == '[1, 2, 3, 4]'
    assert get_shortish_repr([1, 2, 3, 4], max_length=20, normalize=True) == \
                                                                       '[1, 2, 3, 4]'
    assert get_shortish_repr([1, 2, 3, 4], max_length=10) == '[1, 2, 3, 4]'
    assert get_shortish_repr

# Generated at 2022-06-10 21:51:38.872652
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((lambda x: True, str),)) == str
    assert get_repr_function(1, ((lambda x: False, str),)) == repr
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((float, str),)) == repr
    assert get_repr_function(1, ((int, str), (float, str))) == str
    assert get_repr_function(1.0, ((1, str), (float, str))) == str
    assert get_repr_function(1.0, ((1.5, str), (float, str))) == str
    assert get_repr_function(1.0, ((1.5, str), (int, str))) == repr



# Generated at 2022-06-10 21:51:42.758501
# Unit test for function get_repr_function
def test_get_repr_function():

    class Foo(object):
        def __repr__(self):
            return 'Foo object'

    class Bar(object):
        def __repr__(self):
            return 'Bar object'

    def boring_function(item):
        return item.__class__.__name__


    custom_repr = [
        (lambda item: (isinstance(item, Foo) or isinstance(item, Bar)),
         boring_function),
    ]

    foo = Foo()
    assert get_repr_function(foo, custom_repr) is boring_function

    bar = Bar()
    assert get_repr_function(bar, custom_repr) is boring_function

    assert get_repr_function(12345, custom_repr) is repr



# Generated at 2022-06-10 21:51:52.795418
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'אבגדהוזחטיכלמנסעפצקרשת') == u'???????????'
    assert shitcode(u'abcdefghijklmnopqrstuvwxyz') == u'abcdefghijklmnopqrstuvwxyz'
    assert shitcode(u'ABCDEFGHIJKLMNOPQRSTUVWXYZ') == u'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

# Generated at 2022-06-10 21:51:54.362787
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class C(WritableStream):
        def write(self, s): pass

    assert issubclass(C, WritableStream)

# Generated at 2022-06-10 21:52:04.569607
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStream(ABC):
        @abc.abstractmethod
        def write(self, s):
            pass

        @classmethod
        def __subclasshook__(cls, C):
            if cls is WritableStream:
                return _check_methods(C, 'write')
            return NotImplemented

    class BytesIO(WritableStream):
        def write(self, s):
            pass

    class File(WritableStream):
        def write(self, s):
            pass

    assert issubclass(BytesIO, WritableStream)
    assert issubclass(File, WritableStream)

    class NoWrite(object):
        def write(self):
            pass

    assert not issubclass(NoWrite, WritableStream)

    class NoWrite(object):
        pass

    assert not issub

# Generated at 2022-06-10 21:52:12.802398
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(A): pass
    b = B()
    c = C()

    assert get_repr_function(b, ()) is repr
    assert get_repr_function(b, [(A, str)]) is repr
    assert get_repr_function(b, [(B, str)]) is str
    assert get_repr_function(c, [(A, str)]) is str
    assert get_repr_function(c, [(A, str), (C, object)]) is object
    assert get_repr_function(c, [(A, str)]) is str

    class A: pass
    class B(A):
        def __repr__(self):
            return 'B'
    class C(A): pass
    b = B()
    c

# Generated at 2022-06-10 21:52:18.431207
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1.5) == '1.5'
    assert get_shortish_repr('hi') == "'hi'"
    assert (get_shortish_repr('honey mustard') == "'honey mustard'")



# Generated at 2022-06-10 21:52:29.632687
# Unit test for function get_repr_function
def test_get_repr_function():

    def get_string_repr(x):
        return x.__class__.__name__ + ' ' + repr(x)[1:-1]

    custom_repr = [
        (lambda x: isinstance(x, str), repr),
        (int, repr),
        (lambda x: isinstance(x, (list, tuple)), get_string_repr),
    ]

    assert get_repr_function(1, custom_repr) is repr
    assert get_repr_function(1.0, custom_repr) is repr
    assert get_repr_function('1', custom_repr) is repr
    assert get_repr_function([1, 2, 3], custom_repr)([1, 2, 3]) == \
                                                                    'list 1'

# Generated at 2022-06-10 21:52:34.469470
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    assert issubclass(io.StringIO, WritableStream)

# Generated at 2022-06-10 21:52:40.288375
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    for max_length in (None, 3, 6, 40):
        for normalize in False, True:
            assert get_shortish_repr('hello', max_length=max_length,
                                     normalize=normalize) == \
                                     truncate('hello', max_length)
            assert get_shortish_repr(u'חשבון', max_length=max_length,
                                                             normalize=normalize) == \
                                     truncate(u'חשבון', max_length)
            assert get_shortish_repr(1, max_length=max_length,
                                     normalize=normalize) == '1'
            assert get_shortish_repr((1, 2, 3), max_length=max_length,
                                     normalize=normalize)

# Generated at 2022-06-10 21:52:50.150707
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr(0) == '0'
    assert get_shortish_repr(0, max_length=None) == '0'
    assert get_shortish_repr(0, max_length=2) == '0'
    assert get_shortish_repr(0, max_length=1) == '0'
    assert get_shortish_repr(0, max_length=0) == ''

    assert get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=None) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=10) == '[1, 2, 3]'
    assert get_short

# Generated at 2022-06-10 21:52:52.421576
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s): pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-10 21:52:59.193148
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(b'\xff') == b'?'
    assert shitcode(b'\x00') == b'?'
    assert shitcode(b'\x01') == b'\x01'
    assert shitcode(b'\x7f') == b'\x7f'
    assert shitcode(b'\x80') == b'?'
    assert shitcode(b'abc') == b'abc'
    assert shitcode(b'a\x80') == b'a?'

    assert shitcode('\xff') == '?'
    assert shitcode('\x00') == '?'
    assert shitcode('\x01') == '\x01'
    assert shitcode('\x7f') == '\x7f'
    assert shitcode('\x80') == '?'
    assert shitcode('abc')

# Generated at 2022-06-10 21:53:10.670234
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class ClassForTesting(object):
        def __repr__(self):
            return 'really long string'

    assert get_shortish_repr(ClassForTesting(), max_length=20) == 'really l...(13)'
    assert get_shortish_repr(ClassForTesting(), max_length=10) == 'really l...'
    assert get_shortish_repr(ClassForTesting(), max_length=None) == 'really long string'
    assert get_shortish_repr(ClassForTesting(), max_length=11) == 'really long string'
    assert get_shortish_repr(ClassForTesting(), max_length=250) == 'really long string'

    assert get_shortish_repr(u'abcd efgh', max_length=8) == 'abcd ef...'

# Generated at 2022-06-10 21:53:18.102650
# Unit test for function get_repr_function
def test_get_repr_function():
    class Adder(object):
        def __init__(self, addend):
            self.addend = addend

        def __add__(self, other):
            return other + self.addend

        def __repr__(self):
            return 'Adder({!r})'.format(self.addend)

    assert get_repr_function(Adder(0), []) is repr
    assert get_repr_function(Adder(0), [(lambda x: isinstance(x, Adder),
                                         lambda x: x.addend)]) == \
                                                        (lambda x: x.addend)
    assert get_repr_function(Adder(0), [(Adder, lambda x: x.addend)]) == \
                                                        (lambda x: x.addend)
    assert get_repr

# Generated at 2022-06-10 21:53:30.716078
# Unit test for function get_repr_function
def test_get_repr_function():
    import operator
    from collections import namedtuple, OrderedDict
    from .curried import to_curry

    assert get_repr_function(17, []) is repr
    assert get_repr_function(17, [(to_curry(operator.is_(17)), str)]) is str
    assert get_repr_function(
        namedtuple('Point', ('x', 'y'))(1, 2),
        [(namedtuple, lambda t: '{}(x=1, y=2)'.format(t.__name__))]
    ) == 'Point(x=1, y=2)'

# Generated at 2022-06-10 21:53:37.545141
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):

        def __init__(self):
            self.bytes_written = bytearray()

        def write(self, b):
            assert isinstance(b, bytes)
            self.bytes_written.extend(b)

    stream = MyWritableStream()
    stream.write(b'f')
    stream.write(b'o')
    stream.write(b'o')
    assert stream.bytes_written == b'foo'



# Generated at 2022-06-10 21:53:46.518294
# Unit test for function get_repr_function
def test_get_repr_function():

    def get_repr(x):
        return get_repr_function(x,
                                 ((lambda y: isinstance(y, int),
                                   lambda x: hex(id(x))),
                                  (lambda y: isinstance(y, str),
                                   lambda x: '"' + x + '"'),
                                  )
                                 )

    assert get_repr(5) is hex
    assert get_repr('a') == '"' + 'a' + '"'
    assert get_repr(5.5) is repr




# Generated at 2022-06-10 21:54:00.639117
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyClass: pass
    assert WritableStream.__subclasshook__(DummyClass) is NotImplemented

    class DummyClass2:
        def write(self, some_string):
            pass
    assert WritableStream.__subclasshook__(DummyClass2) is True

    class DummyClass3:
        def write(self, some_string):
            pass

        def write2(self, some_string):
            pass
    assert WritableStream.__subclasshook__(DummyClass3) is NotImplemented

    class DummyClass4(DummyClass2): pass
    assert WritableStream.__subclasshook__(DummyClass4) is True

# Generated at 2022-06-10 21:54:04.617110
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyWritableStream(WritableStream):
        pass

    MyWritableStream.register(sys.stdout.__class__)

    assert isinstance(sys.stdout, WritableStream)

# Generated at 2022-06-10 21:54:08.046706
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(object):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(object, WritableStream)

# Generated at 2022-06-10 21:54:16.396291
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('', [(lambda *args: True, lambda *args: 'Hi')])() == 'Hi'
    assert get_repr_function('', [(type(None), lambda *args: 'Hi')])() == 'Hi'
    assert get_repr_function('', [(lambda *args: False, lambda *args: 'Hi')])() != 'Hi'
    assert get_repr_function('', [(type(None), lambda *args: 'Hi')],
                             default=lambda *args: 'Hi' + 'there')() == 'Hithere'



# Generated at 2022-06-10 21:54:23.369156
# Unit test for function get_repr_function
def test_get_repr_function():
    def custom_repr(x):
        return 'custom repr for ' + repr(x)
    assert get_repr_function([], custom_repr=[(list, custom_repr)])([]) == \
      'custom repr for []'
    class A: pass
    assert get_repr_function(A(), custom_repr=[(list, custom_repr)]) == \
           get_repr_function(A(), custom_repr=[(object, custom_repr)]) == \
           repr
    assert get_repr_function(A(), custom_repr=[(list, custom_repr),
                                               (object, custom_repr)]) == \
           custom_repr



# Generated at 2022-06-10 21:54:25.821492
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(object):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

# Generated at 2022-06-10 21:54:32.328469
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyClass(WritableStream):
        def __init__(self):
            self.written_lines = []

        def write(self, s):
            self.written_lines.append(s)

    my_class = MyClass()
    my_class.write('hi')
    assert my_class.written_lines == ['hi'], my_class.written_lines




# Generated at 2022-06-10 21:54:46.895663
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import contextlib

    class ClassThatWritesFour(WritableStream):
        def write(self, s):
            assert len(s) == 4

    class ClassThatWritesSeven(WritableStream):
        def write(self, s):
            assert len(s) == 7

    class ClassThatDoesntWrite(WritableStream):
        pass

    def check_WritableStream(cls):
        with contextlib.closing(cls()) as instance:
            assert isinstance(instance, WritableStream)
            instance.write('1234')

    check_WritableStream(ClassThatWritesFour)
    check_WritableStream(ClassThatWritesSeven)

# Generated at 2022-06-10 21:54:54.349702
# Unit test for function get_repr_function
def test_get_repr_function():
    def foo(x):
        return 'foo'
    def bar(x):
        return 'bar'
    class Point(object): pass
    class Circle(object): pass
    point = Point()
    circle = Circle()

    custom_repr = (
        (Point, foo),
        (lambda x: True, bar),
    )
    assert get_repr_function(point, custom_repr) is foo
    assert get_repr_function(circle, custom_repr) is bar
    assert get_repr_function('', custom_repr) is bar

    assert get_repr_function(point, ()) is repr
    assert get_repr_function(circle, ()) is repr
    assert get_repr_function('', ()) is repr

# Generated at 2022-06-10 21:54:58.263095
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class WritableStreamTest(WritableStream):

        def write(self, s):
            return


    for item in [WritableStreamTest(), WritableStreamTest(), "hi", 1337,
                 WritableStreamTest()]:
        assert isinstance(item, WritableStream)