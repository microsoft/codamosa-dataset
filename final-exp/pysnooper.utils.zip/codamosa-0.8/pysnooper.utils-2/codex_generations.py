

# Generated at 2022-06-10 21:45:20.124410
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr((1,), max_length=None) == '(1,)'
    assert get_shortish_repr((1,), max_length=5) == '(1,)'
    assert get_shortish_repr((1,), max_length=4) == '(1)'
    assert get_shortish_repr((1, 2), max_length=4) == '(1, 2)'
    assert get_shortish

# Generated at 2022-06-10 21:45:23.884683
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class XYZ:
        def write(self, s):
            pass

    assert isinstance(XYZ(), WritableStream)

    class XYZ:
        pass

    assert not isinstance(XYZ(), WritableStream)



# Generated at 2022-06-10 21:45:35.876679
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=50) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr('123', max_length=2) == '1...'


# Generated at 2022-06-10 21:45:43.015501
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode(u'abc') == 'abc'
    assert shitcode('\xff') == '?'
    assert shitcode(u'\xff') == '?'
    assert shitcode('\x00') == '\x00'
    assert shitcode(u'\x00') == '\x00'
    assert shitcode('') == ''
    assert shitcode(u'') == ''




# Generated at 2022-06-10 21:45:44.147585
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    ws = WritableStream()
    ws.write('hi')



# Generated at 2022-06-10 21:45:54.712871
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class A(object):
        def __repr__(self):
            return '<A at 0x%x>' % id(self)

    class B(object):
        def __repr__(self):
            return '<B at 0x%x>' % id(self)

    assert get_shortish_repr(A()) == '<A at 0x...>'
    assert get_shortish_repr(A(), max_length=5) == '<A a...>'
    assert get_shortish_repr(A(), max_length=40) == '<A at 0x...>'
    assert get_shortish_repr(A(), max_length=7) == '<A at ...>'

# Generated at 2022-06-10 21:46:02.949363
# Unit test for function get_repr_function
def test_get_repr_function():
    class ThingA(object): pass
    class ThingAB(ThingA): pass
    class ThingB(object): pass
    class ThingC(object): pass

    def repr_thinga(thinga):
        assert isinstance(thinga, ThingA)
        return 'THINGA'

    def repr_thingb(thingb):
        assert isinstance(thingb, ThingB)
        return 'THINGB'

    assert get_repr_function(ThingA(),
                             custom_repr=((ThingA, repr_thinga),))() == 'THINGA'

    assert get_repr_function(ThingAB(),
                             custom_repr=((ThingA, repr_thinga),))() == 'THINGA'


# Generated at 2022-06-10 21:46:11.966852
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def write(self, s):
            pass
    assert isinstance(Foo(), WritableStream)

    class Bar(Foo):
        pass

    assert isinstance(Bar(), WritableStream)

    class NonWritable(WritableStream):
        def write(self):
            pass
    assert not isinstance(NonWritable(), WritableStream)

    class NotWritable(object):
        pass

    assert not isinstance(NotWritable(), WritableStream)

    class NotImplementingWrite(WritableStream):
        pass

    assert not isinstance(NotImplementingWrite(), WritableStream)



# Generated at 2022-06-10 21:46:16.188990
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Writer(WritableStream):
        def write(self, s):
            return s + s
    assert Writer().write('hi') == 'hihi'
    assert issubclass(Writer, WritableStream)

# Generated at 2022-06-10 21:46:18.640193
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Y:
        def write(self, s):
            pass
    assert issubclass(Y, WritableStream)

# Generated at 2022-06-10 21:46:29.510629
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    from .pycompat import class_types
    assert isinstance(A(), WritableStream)
    assert issubclass(A, WritableStream)
    assert issubclass(class_types.ClassType, WritableStream)
    assert isinstance(file('foo', 'wb', buffering=0), WritableStream)
    assert issubclass(file('foo', 'wb', buffering=0).__class__, WritableStream)
    assert issubclass(type(sys.stdout), WritableStream)
    assert not isinstance(2, WritableStream)
    assert not issubclass(type(2), WritableStream)

# Generated at 2022-06-10 21:46:38.370922
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(
        (1, 2, 3),
        custom_repr=((lambda x: True, str),)
    )(1, 2, 3) == '(1, 2, 3)'
    assert get_repr_function(
        [1, 2, 3],
        custom_repr=((lambda x: True, str),)
    )([1, 2, 3]) == '[1, 2, 3]'
    assert get_repr_function(
        (1, 2, 3),
        custom_repr=(
            (lambda x: True, str),
            (tuple, lambda x: 'TUPLE')
        )
    )(1, 2, 3) == 'TUPLE'

# Generated at 2022-06-10 21:46:49.954696
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object):
        pass

    class B(object):
        def __repr__(self):
            return 'repr of B instance'

    class C(object):
        def __str__(self):
            return 'str of C instance'

    a1 = A()
    b1 = B()
    c1 = C()

    assert get_repr_function(a1, ((A, lambda x: 'A')))() == 'A'
    assert get_repr_function(b1, ((A, lambda x: 'A')))() == 'repr of B instance'
    assert get_repr_function(a1, ())() == repr(a1)
    assert get_repr_function(b1, ())() == repr(b1)
    assert get_repr_function(c1, ())()

# Generated at 2022-06-10 21:47:00.319784
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('', max_length=1) == '...'
    assert get_shortish_repr('hi', max_length=1) == '...'
    assert get_shortish_repr('hi', max_length=2) == 'hi'
    assert get_shortish_repr('hi', max_length=3) == 'hi'
    assert get_shortish_repr('hi', max_length=4) == 'hi'
    assert get_shortish_repr('hi', max_length=5) == 'hi'
    assert get_shortish_repr('hi', max_length=6) == 'hi'
    assert get_shortish_repr('hi', max_length=7) == 'hi'

# Generated at 2022-06-10 21:47:04.877053
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import unittest
    class TestWritableStream(WritableStream):
        
        def __init__(self):
            pass
        
        def write(self):
            return 1
        
    TestWritableStream()



# Generated at 2022-06-10 21:47:10.349159
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def __init__(self):
            self.string = ''

        def write(self, string):
            self.string += string

        def flush(self):
            pass

        def close(self):
            pass

    foo = Foo()
    assert foo.write('hi') is None
    assert foo.string == 'hi'

# Generated at 2022-06-10 21:47:17.563373
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import unittest


    class PositiveIntegerWriter(WritableStream):
        def write(self, s):
            try:
                s = int(s)
            except ValueError:
                raise
            if not (s >= 0 and s == s // 1):
                raise ValueError(
                    "`s` must be an integer greater than or equal to 0."
                )
            return True


    class WritableStreamTest(unittest.TestCase):
        def test_general(self):
            positive_integer_writer = PositiveIntegerWriter()
            self.assertTrue(positive_integer_writer.write(1))
            self.assertTrue(positive_integer_writer.write('2'))
            with self.assertRaises(ValueError):
                positive_integer_writer.write('r')

# Generated at 2022-06-10 21:47:28.693970
# Unit test for function get_shortish_repr

# Generated at 2022-06-10 21:47:31.681755
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import logging
    import sys

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(MyWritableStream(), WritableStream)
    assert type(io.StringIO()) is not WritableStream
    assert type(io.BytesIO()) is not WritableStream
    assert type(sys.stdout) is not WritableStream
    assert type(logging.Logger()) is not WritableStream



# Generated at 2022-06-10 21:47:43.569397
# Unit test for function get_repr_function
def test_get_repr_function():
    class CustomRepr(str):
        def __repr__(self):
            return str(self) + ' [CUSTOM]'

    class SubCustomRepr(CustomRepr):
        pass

    foo = 1,
    bar = 'hello'
    baz = 12345678901234567890
    qux = CustomRepr('what')
    quux = SubCustomRepr('are')
    corge = 1.2345678901234567890
    grault = [1, 2, 3]


# Generated at 2022-06-10 21:47:54.254718
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStream1(WritableStream):
        def write(self, s):
            self._s = s
    assert issubclass(WritableStream1, WritableStream)
    class WritableStream2(WritableStream):
        def write(self, s):
            self._s = s
        def write2(self, s):
            self._s = s
    assert not issubclass(WritableStream2, WritableStream)
    class WritableStream3(WritableStream):
        pass
    assert not issubclass(WritableStream3, WritableStream)

# Generated at 2022-06-10 21:47:57.714734
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    '''
    class TestWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = ''
        def write(self, s):
            self.written_stuff += s
    t = TestWritableStream()
    t.write('asdf')
    assert t.written_stuff == 'asdf'
    '''

# Generated at 2022-06-10 21:48:08.939382
# Unit test for function get_repr_function
def test_get_repr_function():
    from .cute_testing import (assert_equal, assert_true, assert_false,
                               assert_is, assert_raises, assert_call)

    assert_is(get_repr_function(1, []), repr)

    assert_is(get_repr_function(1, [(int, lambda x: x)]),
              lambda x: x)
    assert_is(get_repr_function(1, [(float, lambda x: x)]),
              repr)

    assert_is(get_repr_function(1.0, [
        (float, lambda x: x),
        (int, lambda x: x),
    ]), repr)


# Generated at 2022-06-10 21:48:18.327340
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    custom_repr = [
        (A, lambda a: 'A-repr!'),
        (C, lambda a: 'C-repr!'),
    ]

    assert get_shortish_repr(A(), custom_repr) == 'A-repr!'
    assert get_shortish_repr(B(), custom_repr) == repr(B())
    assert get_shortish_repr(C(), custom_repr) == 'C-repr!'


if __name__ == '__main__':
    test_get_repr_function()

# Generated at 2022-06-10 21:48:27.572734
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [
        (lambda x: True, lambda x: x + 1),
        (lambda x: False, lambda x: x + 2)
    ]) == (lambda x: x + 1)
    assert get_repr_function(1, [(int, lambda x: x + 1)]) == (lambda x: x + 1)
    assert get_repr_function(1, [(int, lambda x: x + 1),
                                 (float, lambda x: x + 2)]) == (lambda x: x + 1)


# Generated at 2022-06-10 21:48:32.787409
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class ThingToString(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s
    thing_to_string = ThingToString()
    thing_to_string.write('hello')
    assert thing_to_string.s == 'hello'
    thing_to_string.write('world')
    assert thing_to_string.s == 'helloworld'
    
    



# Generated at 2022-06-10 21:48:37.783825
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    my_writable_stream = MyWritableStream()
    WritableStream.register(MyWritableStream)
    my_writable_stream.write('hello')
    assert isinstance(my_writable_stream, WritableStream)

# Generated at 2022-06-10 21:48:45.912955
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (
        (int, lambda i: 'two'),
        (float, lambda x: 'three')
    )) == repr

# Generated at 2022-06-10 21:48:53.299639
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """Unit test for method `write` of class `WritableStream`."""
    from .stream import Stream
    assert isinstance(Stream(bytearray(b'abc')), WritableStream)
    assert isinstance(Stream(b'abc'), WritableStream)
    assert isinstance(Stream(open(__file__, 'rb')), WritableStream)
    assert isinstance(Stream(open(__file__, 'r')), WritableStream)

# Generated at 2022-06-10 21:48:55.618725
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    assert issubclass(sys.stdout.__class__, WritableStream)
    assert isinstance(sys.stdout, WritableStream)



# Generated at 2022-06-10 21:49:10.587554
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A(object):
        def __repr__(self):
            return 'AAAAA' * 10000

    assert get_shortish_repr('hello', max_length=5) == 'hello'
    assert get_shortish_repr(None, max_length=5) == 'None'
    assert get_shortish_repr(A(), max_length=5) == 'AAAAA'
    assert get_shortish_repr(A(), max_length=20) == 'AAAAA...AAAAA'
    assert get_shortish_repr(A(), max_length=None) == 'AAAAA' * 10000
    assert get_shortish_repr('AAAAA', custom_repr=[(lambda s: s == 'AAAAA',
                                                    lambda s: 'B')],
                                                                max_length=5)

# Generated at 2022-06-10 21:49:19.407542
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1.1, []) is repr
    assert get_repr_function('abc', []) is repr

# Generated at 2022-06-10 21:49:24.132745
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self._written = ''

        def write(self, s):
            self._written += s

    w = MyWritableStream()

    w.write('hello')
    w.write('world')

    assert w._written == 'helloworld'

# Generated at 2022-06-10 21:49:33.558911
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(17, ()) == repr
    assert get_repr_function(17.3, ()) == repr
    assert get_repr_function(17, [(lambda x: True, lambda x: 'foo')]) == (
                                                                        lambda x: 'foo'
                                                                        )
    assert get_repr_function(17, [(lambda x: False, lambda x: 'foo')]) == (
                                                                        repr
                                                                        )
    assert get_repr_function(17, [(lambda x: False, lambda x: 'foo'),
                                  (lambda x: True, lambda x: 'bar')]) == (
                                                                        lambda x: 'bar'
                                                                        )

# Generated at 2022-06-10 21:49:38.285004
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(metaclass=WritableStream):
        def write(self, s):
            pass
    class B:
        def write(self, s):
            pass
    assert isinstance(A(), WritableStream)
    assert not isinstance(B(), WritableStream)

# Generated at 2022-06-10 21:49:48.754185
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\0\1\2') == '?!?'
    assert shitcode('\0\1\2\0') == '?!?\0'
    assert shitcode('\0\1\2\0\1\2') == '?!?\0?!?'
    assert shitcode('\0\1\2\3\4\5\6\7\8\9') == '?!?!?!?!?!?!?!??'
    assert shitcode('\0\1\2\3\4\5\6\7\8\9\0\1\2\3\4\5\6\7\8\9') == ''.join('!?' for _ in range(20))
    assert shitcode('\u097b\u097c\u097d\u097e') == '???'
    assert shit

# Generated at 2022-06-10 21:49:58.190815
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr('') == "''"
    assert get_shortish_repr('foo') == "'foo'"
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(10) == '10'
    assert get_shortish_repr(100) == '100'
    assert get_shortish_repr(1000) == '1000'

    assert get_shortish_repr([1, 2], max_length=5) == '[1, 2]'
    assert get_shortish_repr([1, 2], max_length=7) == '[1, 2]'

# Generated at 2022-06-10 21:50:08.269332
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1) == repr
    custom_repr = [
        (lambda x: x in (1, 3),
         lambda x: 'one' if x == 1 else 'three'),
        (lambda x: x % 2 == 0,
         lambda x: 'even number')
    ]
    assert get_repr_function(1, custom_repr) == \
                                               (lambda x: 'one' if x == 1 else 'three')
    assert get_repr_function(2, custom_repr) == \
                                               (lambda x: 'even number')
    assert get_repr_function(3, custom_repr) == \
                                               (lambda x: 'one' if x == 1 else 'three')

# Generated at 2022-06-10 21:50:11.175798
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        pass
    assert A.__subclasshook__(A) is True



# Generated at 2022-06-10 21:50:19.885889
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(4) == '4'
    assert get_shortish_repr('hi') == "'hi'"
    assert get_shortish_repr('hi', max_length=2) == "'h'"
    assert get_shortish_repr(('hi',)) == "('hi',)"
    assert get_shortish_repr(('h', 'i')) == "('h', 'i')"
    assert get_shortish_repr(('h\ni', )) == "('h i',)"
    assert get_shortish_repr(('h\ri', )) == "('h i',)"
    assert get_shortish_repr(('h\n\ri', )) == "('h i',)"
    assert get_shortish_repr(('h\n\ri', ), 5)

# Generated at 2022-06-10 21:50:35.105167
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('spam') == 'spam'
    assert get_shortish_repr(u'\N{EURO SIGN}') == u'\N{EURO SIGN}'
    assert get_shortish_repr(u'\N{EURO SIGN}', max_length=3) == u'\N{EURO SIGN}'
    assert get_shortish_repr(u'\N{EURO SIGN}', max_length=4) == u'\N{EURO SIGN}'
    assert get_shortish_repr(u'\N{EURO SIGN}', max_length=5) == u'\N{EURO SIGN}'

# Generated at 2022-06-10 21:50:46.009778
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hello', []) is repr
    assert get_repr_function('hello', [
        (lambda x: True, lambda x: 'goodbye')
    ]) == 'goodbye'

    assert get_repr_function('hello', [
        (lambda x: False, lambda x: 'goodbye')
    ]) is repr

    assert get_repr_function('hello', [
        (lambda x: False, lambda x: 'goodbye'),
        (lambda x: True, lambda x: 'weird')
    ]) == 'weird'

    assert get_repr_function(0, [
        (lambda x: isinstance(x, int), lambda x: '0')
    ]) == '0'


# Generated at 2022-06-10 21:50:50.779214
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class A(WritableStream):
        pass

    class B(A):
        def write(self, s):
            return 'write(%s)' % repr(s)

    b = B()
    assert issubclass(B, WritableStream)
    assert isinstance(b, WritableStream)



# Generated at 2022-06-10 21:50:57.668971
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class SomeFile(object):
        def write(self, s):
            return s
    class SomeStringIO(object):
        def write(self, s):
            return s
    class SomeBadStringIO(object):
        pass

    assert issubclass(SomeFile, WritableStream)
    assert issubclass(SomeStringIO, WritableStream)
    assert not issubclass(SomeBadStringIO, WritableStream)

# Generated at 2022-06-10 21:51:09.075466
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('', []) is repr
    assert get_repr_function('', [
        (lambda x: False, lambda x: '*' + x + '*')
    ]) is repr
    assert get_repr_function('', [
        (lambda x: True, lambda x: '*' + x + '*')
    ]) is not repr
    assert get_repr_function('', [
        (lambda x: True, lambda x: '*' + x + '*')
    ])('hello') == '*hello*'

    assert get_repr_function(0, [(lambda x: True, lambda x: '!' + str(x) + '!')])(1) == '!1!'

# Generated at 2022-06-10 21:51:13.821033
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    def my_repr(x):
        return str(x) + '!!!'
    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr(5, custom_repr=[(int, my_repr)]) == '5!!!'






# Generated at 2022-06-10 21:51:24.818285
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, id),)) == id
    assert get_repr_function(1, ((float, id),)) == repr
    assert get_repr_function(1.5, ((int, id),)) == repr
    assert get_repr_function(1.5, ((float, id),)) == id
    assert get_repr_function(1.5, ((lambda x: isinstance(x, int), id),)) == \
                                                                       repr
    assert get_repr_function(1, ((lambda x: True, id),)) == id
    assert get_repr_function(1, ((lambda x: isinstance(x, int), id),
                                 (lambda x: isinstance(x, float), id),))

# Generated at 2022-06-10 21:51:37.458337
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.string = ''

        def write(self, s):
            self.string += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('spam')
    assert my_writable_stream.string == 'spam'

    # Should raise an exception, because of abstract method:
    try:
        class MyWritableStream2(WritableStream):
            def write(self):
                pass
    except TypeError:
        pass
    else:
        raise Exception

from python_toolbox.context_management import assert_raises
from python_toolbox.temp_value_setting import TempValueSetter



# Generated at 2022-06-10 21:51:42.051062
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    tws = TestWritableStream()
    tws.write('abc')
    assert tws.written == 'abc'

# Generated at 2022-06-10 21:51:55.083221
# Unit test for function get_repr_function
def test_get_repr_function():

    def test_repr(x):
        return 'test_repr(' + repr(x) + ')'

    class TestClass(object):
        pass

    test_instance = TestClass()

    assert get_repr_function(
        'hello',
        (
            (lambda x: isinstance(x, int), str),
            (lambda x: len(x) > 3, lambda s: s[:3] + '...'),
            (TestClass, test_repr),
            (int, test_repr),
        ),
    ) == repr


# Generated at 2022-06-10 21:52:03.824131
# Unit test for function get_repr_function
def test_get_repr_function():
    u = u'unicode me!'
    b = 'bytes me!'
    assert get_repr_function(b, custom_repr=((unicode, str),)) == str

# Generated at 2022-06-10 21:52:11.643944
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io

    class MyIOBase(io.IOBase):
        def write(self, s):
            pass

    class MyStringIO(io.StringIO):
        def write(self, s):
            super().write(s)

    my_io_base = MyIOBase()
    my_string_io = MyStringIO()

    assert isinstance(my_io_base, WritableStream)
    assert isinstance(my_string_io, WritableStream)

# Generated at 2022-06-10 21:52:19.042585
# Unit test for function get_repr_function
def test_get_repr_function():
    from .refreshing_tuple import RefreshingTuple
    assert get_repr_function(7, custom_repr=(
        (lambda x: x % 2 == 0, str.upper),
        (RefreshingTuple, lambda x: "RefreshingTuple(%s)" % (', '.join(
            "'%s'" % y for y in x
        )))
    )) == str
    assert get_repr_function(8, custom_repr=(
        (lambda x: x % 2 == 0, str.upper),
        (RefreshingTuple, lambda x: "RefreshingTuple(%s)" % (', '.join(
            "'%s'" % y for y in x
        )))
    )) == str.upper

# Generated at 2022-06-10 21:52:30.133977
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C: pass
    assert get_repr_function(A(), []) is repr
    assert get_repr_function(B(), [(lambda x: True, 'hi')]) == 'hi'
    assert get_repr_function(C(), [(A, lambda x: 'A'), (B, lambda x: 'B')]) =='B'
    assert get_repr_function(int(), [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(int(), [((int,), lambda x: 'int')]) == 'int'
    assert get_repr_function(int(), [((int,), 'int')]) == 'int'
    assert get_repr_function(int(), [(int, 'int')]) == 'int'

# Generated at 2022-06-10 21:52:36.896985
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (int, lambda x: 'int {}'.format(x))) == \
           'int 1'

    assert get_repr_function('1', (int, lambda x: 'int {}'.format(x))) == \
           repr

    assert get_repr_function(1, (int, lambda x: 'int {}'.format(x)),
                                   (lambda x: isinstance(x, str),
                                    lambda x: 'str {}'.format(x))) == \
           'int 1'

    assert get_repr_function('1', (int, lambda x: 'int {}'.format(x)),
                                   (lambda x: isinstance(x, str),
                                    lambda x: 'str {}'.format(x))) == \
           'str 1'



# Generated at 2022-06-10 21:52:42.177902
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        '''
        A simple writable stream that writes to `sys.stdout`.
        '''
        def write(self, s):
            '''
            Write the string `s` to `sys.stdout`.
            '''
            print(s)

    MyWritableStream().write('hello')

# Generated at 2022-06-10 21:52:51.764907
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    def check(WritableStreamClass):
        assert issubclass(WritableStreamClass, WritableStream)
        stream = WritableStreamClass()
        try:
            stream.write(b'abc')
            stream.write(u'abc')
        except Exception as e:
            if not isinstance(e, TypeError):
                raise
            else:
                try:
                    stream.write(u'abc')
                    stream.write(b'abc')
                except Exception as e:
                    if not isinstance(e, TypeError):
                        raise
                    else:
                        pass


    class MyWritableStream(WritableStream):

        def write(self, s):
            pass

    check(MyWritableStream)


# Generated at 2022-06-10 21:52:57.248859
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Field error of class WritableStream
    class WritableStreamError(BaseException):
        pass

    # Method write of class WritableStream is not implemented
    class NotImplementedWrite(WritableStream):
        pass

    # Method write of class WritableStream is implemented
    class ImplementedWrite(WritableStream):
        def write(self, s):
            pass

    assert WritableStream.__subclasshook__(NotImplementedWrite) is NotImplemented
    assert WritableStream.__subclasshook__(ImplementedWrite) is True

# Generated at 2022-06-10 21:53:04.445146
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    '''Test unit for method `write` of class `WritableStream`.'''
    class MyWritableStream(WritableStream):
        '''
        A writable stream as a class for testing `test_WritableStream_write`.
        '''
        def write(self, s):
            pass
    my_writable_stream = MyWritableStream()
    assert isinstance(my_writable_stream, WritableStream)



# Generated at 2022-06-10 21:53:14.195755
# Unit test for function get_repr_function
def test_get_repr_function():
    s = 'hello'
    assert get_repr_function(s, []) == repr
    assert get_repr_function(s, [(lambda s: False, 'bad')]) == repr
    assert get_repr_function(s, [(lambda s: True, 'good')]) == 'good'
    assert get_repr_function(s, [(lambda s: False, 'bad'),
                                 (lambda s: True, 'good')]) == 'good'
    assert get_repr_function(s, [(lambda s: True, 'bad'),
                                 (lambda s: True, 'good')]) == 'bad'
    assert get_repr_function(s, [(lambda s: True, 'bad'),
                                 (lambda s: False, 'good')]) == 'bad'

# Generated at 2022-06-10 21:53:20.830762
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStream__subclass(WritableStream):
        def write(self, s):
            print(s)

    assert issubclass(WritableStream__subclass, WritableStream)



# Generated at 2022-06-10 21:53:30.348765
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C: pass
    class D(B): pass
    assert get_repr_function(A(), ()) == repr

# Generated at 2022-06-10 21:53:37.545344
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import io
    from .pycompat import BytesIO

    # Verifying that io.StringIO is WritableStream

    assert isinstance(io.StringIO(), WritableStream)
    assert isinstance(BytesIO(), WritableStream)

    # Verifying that sys.stdout is WritableStream
    assert isinstance(sys.stdout, WritableStream)

    # Verifying that stream.write() works

    s = io.StringIO()
    s.write('hello')
    assert s.getvalue() == 'hello'

# Generated at 2022-06-10 21:53:44.272925
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(object):
        def write(self, s):
            pass
    assert isinstance(X(), WritableStream)

    class Y(object):
        pass
    assert not isinstance(Y(), WritableStream)

    class Z(object):
        def write(self, s):
            pass
        write = None
    assert not isinstance(Z(), WritableStream)



# Generated at 2022-06-10 21:53:48.665589
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hello world!', ()) == repr
    assert get_repr_function('hello world!', ((str, bool),)) == bool
    assert get_repr_function('hello world!', ((str, bool), (int, basestring))) == bool
    assert get_repr_function('hello world!', ((str, bool), (str, basestring))) == basestring
    assert get_repr_function([1, 2, 3], ((str, bool), (str, basestring))) == repr



# Generated at 2022-06-10 21:53:53.055580
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s
    x = X()
    x.write('spam')
    assert x.written == 'spam'

# Generated at 2022-06-10 21:54:01.242762
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr('abcdefg') == 'abcdefg'
    assert get_shortish_repr('abcdefg', max_length=3) == 'abc...'
    assert get_shortish_repr(5, max_length=3) == '5'
    assert get_shortish_repr(2 ** 3, max_length=1) == '8'
    assert get_shortish_repr("a\n\nb", max_length=10) == 'a ... b'
    assert get_shortish_repr("\n\n\n", max_length=10) == '   ... '



# Generated at 2022-06-10 21:54:09.574233
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .pycompat import Integer
    from . import pycompat
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=8) == '1'
    assert get_shortish_repr(2 ** 32 + 1, max_length=8) == '4294967297'
    assert get_shortish_repr(2 ** 32 + 1, max_length=9) == '4294967297'
    assert get_shortish_repr(2 ** 32 + 1, max_length=10) == '4294967297'
    assert get_shortish_repr(2 ** 32 + 1, max_length=11) == '4294967297'

# Generated at 2022-06-10 21:54:20.096697
# Unit test for function get_repr_function
def test_get_repr_function():

    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass

    a1 = A()
    b = B()
    c = C()
    d = D()
    e = int()

    def repr_A(x): return 'A(%s)' % id(x)
    def repr_B(x): return 'B(%s)' % id(x)
    def repr_C(x): return 'C(%s)' % id(x)
    def repr_int(x): return 'int(%s)' % id(x)

    custom_repr = ((A, repr_A),
                   (B, repr_B),
                   (int, repr_int))

    assert get_repr_function(a1, custom_repr) is repr_

# Generated at 2022-06-10 21:54:23.566461
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(object):
        def write(self, s):
            pass

    x = X()
    assert isinstance(x, WritableStream)

    class Y(WritableStream):
        pass

    y = Y()
    try:
        WritableStream.register(Y)
        assert isinstance(y, WritableStream)
    finally:
        del WritableStream.__subclasscheck__



# Generated at 2022-06-10 21:54:33.315947
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.buffer = []

        def write(self, s):
            self.buffer.append(s)

    stream = MyWritableStream()
    stream.write('hey')
    assert stream.buffer == ['hey']
    stream.write('there')
    assert stream.buffer == ['hey', 'there']



# Generated at 2022-06-10 21:54:47.729289
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(12345, max_length=2) == '1...5'
    assert get_shortish_repr(123456, max_length=2) == '1...6'
    assert get_shortish_repr(1234567, max_length=2) == '12...7'
    assert get_shortish_repr(1234567, max_length=3) == '123...7'
    assert get_shortish_repr((1, 2, 3), max_length=5) == '(1, 2, 3)'

# Generated at 2022-06-10 21:54:50.300129
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .streams import OutputStream, OutputStringIOStream
    OutputStream.write(OutputStringIOStream(), 'Hi')



# Generated at 2022-06-10 21:55:03.434614
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X:
        pass
    
    assert _check_methods(type('X', (object,), {'write': 1}), 'write') is NotImplemented
    assert _check_methods(type('X', (object,), {'write': None}), 'write')
    assert _check_methods(type('X', (object,), {'write': lambda _: 1}), 'write')
    
    class X:
        def write(self, s):
            pass
    assert _check_methods(X, 'write')
    
    class X(WritableStream):
        def write(self, s):
            pass
    assert isinstance(X(), WritableStream)
    
    class X(WritableStream):
        pass
    assert isinstance(X(), WritableStream) is False
    

# Generated at 2022-06-10 21:55:15.538422
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr('foo') == 'foo'
    assert get_shortish_repr('a' * 1 + 'b' * 2 + 'c' * 3) == 'a' * 1 + 'b' * 2 + 'c' * 3
    assert get_shortish_repr('a' * 1 + 'b' * 2 + 'c' * 3,
                             max_length=2) == 'a' * 1 + '...'
    assert get_shortish_repr('a' * 1 + 'b' * 2 + 'c' * 3,
                             max_length=4) == 'abc...'