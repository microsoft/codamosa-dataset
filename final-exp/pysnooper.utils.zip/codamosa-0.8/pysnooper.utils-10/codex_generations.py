

# Generated at 2022-06-10 21:45:15.403857
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert isinstance(A(), WritableStream)

# Generated at 2022-06-10 21:45:19.807456
# Unit test for function get_repr_function
def test_get_repr_function():
    for dtype in ('int32', 'float64', 'float128'):
        assert get_repr_function(numpy.dtype(dtype), custom_repr) == str
        assert get_repr_function(
            numpy.array(
                [0],
                dtype=dtype
            ).item(),
            custom_repr
        ) == str

# Generated at 2022-06-10 21:45:32.103116
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import sys


    class IStream(WritableStream): # IStream is an alias of WritableStream
        pass


    class IStream0(IStream):
        def write(self, s):
            return s

    class IStream1(IStream):
        def write(self, s, a=1):
            return s, a

    class IStream2(IStream):
        def write(self, s, a, b=2):
            return s, a, b

    class IStream3(IStream):
        def write(self, s, a, b, c=3):
            return s, a, b, c

    class IStream4(IStream):
        def write(self, s, a, b, c, d=4):
            return s, a, b, c, d


# Generated at 2022-06-10 21:45:43.986892
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(str, custom_repr=[]) is str
    assert get_repr_function(str, custom_repr=[(lambda x: True, str)]) is str
    assert get_repr_function(str, custom_repr=[(lambda x: False, str)]) is str
    assert get_repr_function(str, custom_repr=[(str, str)]) is str
    assert get_repr_function(str, custom_repr=[(lambda x: False, str),
                                               (str, str)]) is str
    assert get_repr_function(str, custom_repr=[(lambda x: True, str),
                                               (str, str)]) is str

# Generated at 2022-06-10 21:45:54.486970
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('\x00') == '?'
    assert shitcode('\x00\x01\x02\x03') == '????'
    assert shitcode('\x00\x01\x02\x03\x04\x05\x06\x07') == '????????'
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'abc\x00') == u'abc?'
    assert shitcode(u'\x00') == u'?'
    assert shitcode(u'\x00\x01\x02\x03') == u'????'

# Generated at 2022-06-10 21:45:56.685287
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            return

    # The `isinstance` check here is to make sure we have the `write`
    # attribute.
    assert isinstance(MyWritableStream(), WritableStream)



# Generated at 2022-06-10 21:45:59.655497
# Unit test for function get_repr_function
def test_get_repr_function():
    x = [('abcd', lambda x: 'X'+x)]
    y = get_repr_function('abcd', x)
    yy = y('abcde')
    assert yy == 'Xabcde'



# Generated at 2022-06-10 21:46:10.698630
# Unit test for function get_repr_function
def test_get_repr_function():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass

    a = A()
    b = B()
    c = C()

    assert get_repr_function(a, [(type(a), None), (A, lambda a: 'A')]) is None
    assert get_repr_function(a, [(type(a), None), (B, lambda a: 'B')]) == repr
    assert get_repr_function(a, [(B, lambda a: 'B')]) == repr
    assert get_repr_function(b, [(type(a), None), (A, lambda a: 'A')]) == repr
    assert get_repr_function(b, [(type(a), None), (B, lambda a: 'B')]) is None
    assert get_re

# Generated at 2022-06-10 21:46:24.310739
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5) == repr
    assert get_repr_function('abc') == repr
    assert get_repr_function([1, 2, 3]) == repr
    assert get_repr_function((1, 2)) == repr
    assert get_repr_function(None) == repr

    def square(x): return x ** 2
    assert get_repr_function(square, (
        (lambda x: True, str),
    )) == str
    assert get_repr_function(square, (
        (lambda x: True, lambda x: x ** 3),
    )) == square

    assert get_repr_function(5, (
        (int, square),
    )) == square

# Generated at 2022-06-10 21:46:34.959542
# Unit test for function get_repr_function
def test_get_repr_function():
    """
    get_repr_function(object, custom_repr=((condition, repr_action), ...)[, normalize])
    """
    custom_repr_default = \
        get_repr_function(object(), []) == repr

    custom_repr_list_default = \
        get_repr_function([], []) == repr

    custom_repr_list_custom = \
        get_repr_function([], [(lambda x: True, str)]) == str

    custom_repr_type_default = \
        get_repr_function(object(), [(list, object)]) == repr

    custom_repr_type_custom = \
        get_repr_function(object(), [(list, str)]) == str

    assert custom_repr_default
    assert custom_repr_list_

# Generated at 2022-06-10 21:46:50.000747
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-10 21:46:52.826643
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io

    assert isinstance(io.BytesIO(), WritableStream)
    assert isinstance(io.StringIO(), WritableStream)



# Generated at 2022-06-10 21:46:57.017958
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(object):
        def write(self, s):
            raise NotImplementedError

    assert issubclass(A, WritableStream)

    class B(object):
        pass

    assert not issubclass(B, WritableStream)


# Generated at 2022-06-10 21:47:07.367396
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(10) == '10'
    assert get_shortish_repr(10, normalize=True) == '10'
    assert get_shortish_repr(10, max_length=2) == '10'
    assert get_shortish_repr(10, max_length=1) == '1'
    assert get_shortish_repr(10, max_length=0) == ''
    assert get_shortish_repr(10, max_length=-1) == ''


if __name__ == '__main__':
    test_get_shortish_repr()

# Generated at 2022-06-10 21:47:12.063438
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello', max_length=3) == 'hel...'
    assert get_shortish_repr('hello', max_length=12) == 'hello'
    assert get_shortish_repr('hello', max_length=None) == 'hello'



# Generated at 2022-06-10 21:47:25.158802
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    tests = (
        (1, "1"),
        ("hi", "hi"),
        (u"hi", "hi"),
        (1.0, "1.0"),
        (# If a default repr has too many characters, it gets truncated:
         object(),
         normalize_repr('<object object at 0x{:08x}>'.format(id(object())))),
        ("this is a long string that should be truncated", "this is a long..."),
        (Exception("Exception with a long message"), "Exception('Exception..."),
        ([1, 2, 3], "[1, 2, ..."),
        (set([1, 2, 3]), "{1, 2, ..."),
        (set(), "{}"),
        (Exception, "<class 'Exception'>"))


# Generated at 2022-06-10 21:47:31.143433
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import six
    class Writer(six.with_metaclass(WritableStream)):
        def write(self, s):
            pass

    class AltWriter(six.with_metaclass(WritableStream)):
        def write(self, s):
            pass

    class UnWriter(object):
        def write(self, s):
            pass

    class UnWriter2(Writer):
        def no_write(self, s):
            pass

    assert issubclass(Writer, WritableStream)
    assert issubclass(AltWriter, WritableStream)
    assert not issubclass(UnWriter, WritableStream)
    assert not issubclass(UnWriter2, WritableStream)



# Generated at 2022-06-10 21:47:38.194891
# Unit test for function get_repr_function
def test_get_repr_function():
    from . import Object

    class A(object): pass
    class B(A): pass
    class C(A): pass

    assert get_repr_function(A(), ((A, lambda _: 'A'),))() == 'A'
    assert get_repr_function(A(), ((B, lambda _: 'B'),))() == repr(A)
    assert get_repr_function(B(), ((B, lambda _: 'B'),
                                   (A, lambda _: 'A')))() == 'B'
    assert get_repr_function(B(), ((A, lambda _: 'A'),
                                   (B, lambda _: 'B')))() == 'B'

    lst = [1, 2, 3]

# Generated at 2022-06-10 21:47:47.149199
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object):
        num = 13
    a = A()
    assert get_repr_function(a, ((int, str),)) is str

# Generated at 2022-06-10 21:47:54.254050
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        def write(self, s): pass

    class Bar(Foo):
        pass

    class Baz(Foo):
        def write(self, s): pass

    assert issubclass(Baz, WritableStream)
    assert not issubclass(Bar, WritableStream)
    assert isinstance(Baz(), WritableStream)
    assert not isinstance(Bar(), WritableStream)


if __name__ == '__main__':
    test_WritableStream_write()

# Generated at 2022-06-10 21:48:10.920650
# Unit test for function get_repr_function
def test_get_repr_function():
    from .test_tools import assert_equal

    class A(object): pass
    class B(A): pass
    class C(object): pass

    assert_equal(get_repr_function(A(), [(A, int)]), int)
    assert_equal(get_repr_function(A(), [(B, int)]), repr)
    assert_equal(get_repr_function(A(), [(int, int)]), repr)
    assert_equal(get_repr_function(A(), [(object, int)]), int)
    assert_equal(get_repr_function(A(), [(C, int)]), repr)
    assert_equal(get_repr_function(A(), [(lambda x: True, int)]), int)

# Generated at 2022-06-10 21:48:22.059034
# Unit test for function get_repr_function
def test_get_repr_function():
    """Unit test for function get_repr_function"""
    from .type_checking import get_type_name

    def identity(x):
        return x

    def is_float(x):
        return isinstance(x, float)

    def is_int(x):
        return isinstance(x, int)

    def is_int_or_string(x):
        return isinstance(x, (int, string_types))


# Generated at 2022-06-10 21:48:27.047343
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr(7, max_length=5) == '7'
    assert get_shortish_repr('hello', max_length=5) == 'hello'

    assert get_shortish_repr('hello world', max_length=5) == 'hello...ld'



# Generated at 2022-06-10 21:48:35.122680
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, normalize=True) == '1'
    assert get_shortish_repr(1, max_length=11) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=1, normalize=True) == '1'
    assert get_shortish_repr(1234, max_length=2) == '1...4'
    assert get_shortish_repr(
        1234,
        max_length=2,
        normalize=True
    ) == '1...4'
    assert get_shortish_repr(123456789, max_length=6)

# Generated at 2022-06-10 21:48:44.483224
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        pass

    class MyConformingWritableStream(object):
        def write(self, s):
            pass

    class MyNonConformingWritableStream(object):
        pass

    assert issubclass(MyConformingWritableStream, WritableStream)
    assert not issubclass(MyNonConformingWritableStream, WritableStream)

    assert isinstance(MyConformingWritableStream(), WritableStream)
    assert not isinstance(MyNonConformingWritableStream(), WritableStream)

    assert MyWritableStream.write.__isabstractmethod__

    class MyConcreteWritableStream(MyWritableStream):
        def write(self, s):
            pass

    assert isinstance(MyConcreteWritableStream(), WritableStream)

# Generated at 2022-06-10 21:48:54.264373
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Nonsense:
        pass
    assert not isinstance(Nonsense(), WritableStream)
    if sys.implementation.name != 'ironpython':
        # IronPython bug?
        assert issubclass(Nonsense, WritableStream)
        assert Nonsense.__subclasscheck__(Nonsense)
    n = Nonsense()
    assert not isinstance(n, WritableStream)

    class Nonsense:
        def write(self, s):
            raise NotImplementedError

    assert isinstance(Nonsense(), WritableStream)
    assert issubclass(Nonsense, WritableStream)
    assert Nonsense.__subclasscheck__(Nonsense)

# Generated at 2022-06-10 21:49:01.596974
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('1') == '1'
    assert shitcode('亞') == '?'
    assert shitcode('א') == '?'
    assert shitcode('Æ') == '?'
    assert shitcode('Aba') == 'Aba'
    assert shitcode('Abaה') == 'Aba?'
    assert shitcode('Abaהא') == 'Aba??'
    assert shitcode('האAba') == '?Aba'
    assert shitcode('האהא') == '??'

# Generated at 2022-06-10 21:49:11.254320
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def write(self, s):
            return s

    assert issubclass(MyStream, WritableStream)
    assert isinstance(MyStream(), WritableStream)

    assert MyStream().write('meow') == 'meow'

    class MyBrokenStream(WritableStream):
        pass
    assert not issubclass(MyBrokenStream, WritableStream)
    assert not isinstance(MyBrokenStream(), WritableStream)

    class MyPartiallyWorkingStream(WritableStream):
        def write(self, s):
            pass

    assert not isinstance(MyPartiallyWorkingStream, WritableStream)
    assert not isinstance(MyPartiallyWorkingStream(), WritableStream)



# Generated at 2022-06-10 21:49:17.024232
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def __init__(self):
            self.phat = ''

        def write(self, s):
            self.phat += s

    class B(WritableStream):
        def __init__(self):
            self.phat = ''

    a = A()
    a.write('hey')
    assert a.phat == 'hey'

    try:
        b = B()
        raise Exception
    except TypeError:
        pass

# Generated at 2022-06-10 21:49:27.912514
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    def assert_shortish_repr(input, expected_output):
        actual_output = get_shortish_repr(input)
        assert actual_output == expected_output

    class TestClass(object):
        def __repr__(self):
            return 'test_class'

    assert_shortish_repr(TestClass(), 'test_class')
    assert_shortish_repr(TestClass(), 'test_class', normalize=True)
    assert_shortish_repr(TestClass(), 'test_class', max_length=None)
    assert_shortish_repr(TestClass(), 'test_class', max_length=1000)
    assert_shortish_repr(TestClass(), 'test_class', max_length=5)

# Generated at 2022-06-10 21:49:35.829743
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'...'"



# Generated at 2022-06-10 21:49:39.123223
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from io import StringIO
    class DummyStream(WritableStream):
        def write(self, s):
            self.s = s

    stream = DummyStream()
    stream.write('spam')
    assert stream.s == 'spam'



# Generated at 2022-06-10 21:49:49.769620
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    def _test_WritableStream_write_sub(C, s):
        assert issubclass(C, WritableStream)
        class Saver(C):
            def __init__(self):
                self.written = []
            def write(self, s):
                self.written.append(s)
        saver = Saver()
        saver.write(s)
        assert saver.written == [s]
    _test_WritableStream_write_sub(sys.stdout.__class__, u'This is a test.')
    _test_WritableStream_write_sub(StringIO(), u'This is a test.')
    _test_WritableStream_write_sub(BytesIO(), b'This is a test.')



# Generated at 2022-06-10 21:49:58.865224
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'

    assert get_shortish_repr('a', max_length=2) == 'a'
    assert get_shortish_repr('a', max_length=3) == 'a'
    assert get_shortish_repr('a', max_length=4) == 'a'

    assert get_shortish_repr('abc', max_length=4) == 'abc'
    assert get_shortish_repr('abc', max_length=5) == 'abc'

# Generated at 2022-06-10 21:50:09.220595
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import pytest
    from .bytestringio import BytestringIO

    for stream_class in (io.BytesIO, BytestringIO):
        stream = stream_class()
        stream.write(b'abc')
        assert stream.getvalue() == b'abc'

    for stream_class in (io.BytesIO, BytestringIO):
        stream = stream_class(b'abc')
        stream.write(b'def')
        assert stream.getvalue() == b'def'


    stream = BytestringIO(u'abc')
    with pytest.raises(TypeError):
        stream.write(b'def')

    stream = BytestringIO(u'abc')
    with pytest.raises(TypeError):
        stream.write(u'def')




# Generated at 2022-06-10 21:50:17.633912
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr({1, 2, 3}) == '(1, 2, 3)'
    assert len(get_shortish_repr({1, 2, 3}, max_length=15)) <= 15
    assert get_shortish_repr({1, 2, 3}, max_length=5) == '(1, 2, 3)'
    assert get_shortish_repr({1, 2, 3}, max_length=1) == '...'
    assert get_shortish_repr({1, 2, 3}, max_length=0) == ''
    assert get_shortish_repr({1, 2, 3}, max_length=-1) == ''


# Generated at 2022-06-10 21:50:27.927800
# Unit test for function get_repr_function
def test_get_repr_function():
    import numpy
    assert get_repr_function(1) == repr
    assert get_repr_function(True) == repr
    assert get_repr_function(1.1) == repr
    assert get_repr_function(1 + 3j) == repr
    assert get_repr_function(1j) == repr

# Generated at 2022-06-10 21:50:31.283590
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamTester(WritableStream):
        def __init__(self):
            self.lines = []
        def write(self, s):
            self.lines.append(s)

    f = WritableStreamTester()
    f.write('hello')
    f.write('world')
    assert f.lines == ['hello', 'world']



# Generated at 2022-06-10 21:50:43.238926
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello\nworld') == "'hello\\nworld'"
    assert get_shortish_repr('') == "''"
    assert get_shortish_repr(10) == '10'
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr([1, 2]) == '[1, 2]'
    assert get_shortish_repr([1, 2], max_length=15) == '[1, 2]'
    assert get_shortish_repr([1, 2], max_length=14) == '[1, 2]'
    assert get_shortish_repr([1, 2], max_length=13) == '[1, 2]'
    assert get_shortish

# Generated at 2022-06-10 21:50:49.736524
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcdef') == 'abcdef'
    assert get_shortish_repr('abcdef', (lambda x: (isinstance(x, str),
                                                   lambda x: 'bla'),),
                             max_length=4) == 'bla'
    assert get_shortish_repr('abcdef', (lambda x: (isinstance(x, str),
                                                   lambda x: 'bla'),),
                             max_length=4) == 'bla'
    assert get_shortish_repr('abcdef', (lambda x: (isinstance(x, str),
                                                   lambda x: 'bla'),),
                             max_length=3) == '...'
    assert get_shortish_repr('abcdef', max_length=3) == '...'
   

# Generated at 2022-06-10 21:51:02.001277
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class F(object):
        def write(self, s):
            pass
    assert isinstance(F(), WritableStream)




# Generated at 2022-06-10 21:51:08.760049
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        def write(self, s):
            pass

    assert (issubclass(Foo, WritableStream))

    class Bar(Foo):
        def write(self, s):
            pass

    assert (issubclass(Bar, WritableStream))

    class Wrong:
        pass

    assert (not issubclass(Wrong, WritableStream))


if __name__ == '__main__':
    test_WritableStream_write()

# Generated at 2022-06-10 21:51:18.868515
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """Unit test for method write of class WritableStream."""
    from .test_bases.exception_test_case import ExceptionTestCase
    from .test_bases.test_case import TestCase
    from .test_bases.exception_test_context_manager import \
                                                          ExceptionTestContextManager

    class TestStream(WritableStream):
        def __init__(self):
            self.string = ''

        def write(self, s):
            self.string += s

    class TestStream2(object):
        def write(self, s):
            pass

    class TestCase_(ExceptionTestCase):
        def test(self):
            self.assertIs(issubclass(TestStream, WritableStream), True)
            self.assertIs(issubclass(TestStream2, WritableStream), False)
   

# Generated at 2022-06-10 21:51:21.246491
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, x):
            return x

    assert issubclass(A, WritableStream)



# Generated at 2022-06-10 21:51:31.350966
# Unit test for function get_repr_function
def test_get_repr_function():
    def f1(x):
        return x.upper()
    def f2(x):
        return x.lower()
    def normalize_repr(x):
        return x.replace(' at 0x', ' at ?')

    assert get_repr_function(1, custom_repr=((int, f1),)) == f1
    assert get_repr_function(1, custom_repr=((float, f1),)) == repr
    assert get_repr_function(repr, custom_repr=()) == repr

    assert get_repr_function('', custom_repr=()) == repr
    assert get_repr_function('', custom_repr=((str, f1),)) == f1
    assert get_repr_function('', custom_repr=((str, f2),)) == f

# Generated at 2022-06-10 21:51:35.831459
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import StringIO
    s = StringIO()
    assert isinstance(s, WritableStream)
    s.write('bla')
    assert s.getvalue() == 'bla'




# Generated at 2022-06-10 21:51:48.170364
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
        pass
    b = B()
    c = C()
    d = D()


    custom_repr_list = [
        (lambda x, y=B: isinstance(x, y), lambda x: 'B'),
        (lambda x, y=A: isinstance(x, y), lambda x: 'A'),
        (lambda x, y=D: isinstance(x, y), lambda x: 'D'),
    ]

    assert get_repr_function(b, custom_repr_list) == custom_repr_list[0][1]

# Generated at 2022-06-10 21:51:52.032606
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MockFile(object):
        def __init__(self, *args, **kwargs):
            self.write_calls = []
        def write(self, *args, **kwargs):
            self.write_calls.append((args, kwargs))

    mf = MockFile()
    assert isinstance(mf, WritableStream)



# Generated at 2022-06-10 21:51:53.949834
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .my_collections import FrozenOrderedDict
    assert get_shortish_repr(None) == 'None'


# Generated at 2022-06-10 21:52:05.949785
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(123) == '123'
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr('goodbye', max_length=4) == 'goo...'
    assert get_shortish_repr(b'bye', max_length=4) == 'bye'
    assert get_shortish_repr(b'\x00\x01\x02\x03\x04', max_length=4) == '\x00\x01...'
    assert get_shortish_repr({'hello': 123}) == "{'hello': 123}"
    assert get_shortish_repr({'hello': 123, 'goodbye': 456}, max_length=12) == "{'hello': 123..."

# Generated at 2022-06-10 21:52:28.356658
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class F(object):
        def write(self, s):
            pass

    assert WritableStream.__subclasshook__(F)

    class F2(object):
        def write(self, s):
            return s

    assert WritableStream.__subclasshook__(F2)

    class F3(object):
        pass

    assert WritableStream.__subclasshook__(F3) is NotImplemented



# Generated at 2022-06-10 21:52:34.135300
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('a', ()) == repr
    assert get_repr_function(1, ((str, str),)) == str
    assert get_repr_function('a', ((str, str),)) == str
    assert get_repr_function(lambda: 3, ((str, str),)) == repr
    assert get_repr_function(1, ((str, str), (int, int))) == repr
    assert get_repr_function(1, ((str, str), (int, int), (int, float))) == float





# Generated at 2022-06-10 21:52:45.309384
# Unit test for function get_repr_function
def test_get_repr_function():
    lol = [1, 2, 3]
    print(get_repr_function(lol, [(lambda x: True, str)]))
    assert get_repr_function(lol, [(lambda x: True, str)]) == str

    print(get_repr_function(lol, [(lambda x: False, str)]))
    assert get_repr_function(lol, [(lambda x: False, str)]) != str

    a = 'a'
    print(get_repr_function(a, [(lambda x: True, str)]))
    assert get_repr_function(a, [(lambda x: True, str)]) != str

    print(get_repr_function(a, [(lambda x: False, str)]))
    assert get_repr_function(a, [(lambda x: False, str)]) == str

   

# Generated at 2022-06-10 21:52:47.858574
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Faketty(object):
        def __init__(self):
            self.content = ''
        def write(self, s):
            assert isinstance(s, str)
            self.content += s

    faketty = Faketty()

    assert isinstance(faketty, WritableStream)



# Generated at 2022-06-10 21:52:53.438519
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [
        (str, lambda s: s.upper()),
        (int, lambda i: 'I:' + str(i)),
    ]

    assert get_repr_function('a', custom_repr) == 'a'.upper
    assert get_repr_function(1, custom_repr) == 'I:1'
    assert get_repr_function(1.1, custom_repr) == repr




# Generated at 2022-06-10 21:52:58.259500
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class B: pass
    class C(B):
        def write(self, s):
            pass
    assert isinstance(C(), WritableStream)
    class D(B):
        def writ(self, s):
            pass
    assert not isinstance(D(), WritableStream)
    class E(B):
        def write(self, s):
            pass
        write = None
    assert not isinstance(E(), WritableStream)


if __name__ == '__main__':
    test_WritableStream_write()

# Generated at 2022-06-10 21:53:06.130196
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(
        1,
        (
            (lambda x: isinstance(x, int), str),
            (lambda x: isinstance(x, string_types), id)
        )
    ) is str
    assert get_repr_function(
        'yoyo',
        (
            (lambda x: isinstance(x, int), str),
            (lambda x: isinstance(x, string_types), id)
        )
    ) is id



# Generated at 2022-06-10 21:53:15.414232
# Unit test for function get_repr_function
def test_get_repr_function():
    
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B): pass
    class E(D): pass
    
    assert get_repr_function(A(), []) is repr
    assert get_repr_function(B(), []) is repr
    assert get_repr_function(C(), []) is repr
    assert get_repr_function(D(), []) is repr
    assert get_repr_function(E(), []) is repr
    
    assert get_repr_function(
        A(),
        custom_repr=((A, object),)
    ) is object
    
    assert get_repr_function(
        B(),
        custom_repr=((A, object),)
    ) is object
    
    assert get_re

# Generated at 2022-06-10 21:53:18.742875
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream): pass
    assert not issubclass(A, WritableStream)
    class B(WritableStream):
        def write(self, s):
            pass
    assert issubclass(B, WritableStream)

# Generated at 2022-06-10 21:53:31.071897
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=5) == '[...]'
    assert get_shortish_repr([1, 2, 3], max_length=11) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3, 4, 5], max_length=11) == '[1, 2, ...]'
    assert get_shortish_repr([1, 2, 3, 4, 5], max_length=9) == '[1, ...]'
    assert get_shortish_repr([1, 2, 3, 4, 5], max_length=8) == '[...]'

# Generated at 2022-06-10 21:53:55.950590
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import sys
    assert isinstance(sys.stdout, WritableStream)
    # On IronPython, `isinstance(sys.stdout, WritableStream)` is False,
    # because sys.stdout doesn't have a `write` method, but a `Write` method
    # instead.
    assert sys.stdout.write('hi')



# Generated at 2022-06-10 21:54:02.234467
# Unit test for function get_repr_function
def test_get_repr_function():
    items = (1, 1.0, 'hi', get_repr_function, {})
    custom_repr = [
        (lambda x: isinstance(x, collections_abc.Mapping),
                                                lambda x: x.__class__.__name__),
        (1, lambda x: 'one')
    ]
    for item in items:
        print('item', item)
        print('custom_repr', get_repr_function(item, custom_repr))
        print('standard', get_repr_function(item, []))
        print()


if __name__ == '__main__':
    test_get_repr_function()

# Generated at 2022-06-10 21:54:06.733079
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Good(WritableStream):
        def write(self, s): pass

    class Bad1(WritableStream):
        pass

    class Bad2(WritableStream):
        def write(self, s): pass

    assert issubclass(Good, WritableStream)
    assert not issubclass(Bad1, WritableStream)
    assert not issubclass(Bad2, WritableStream)



# Generated at 2022-06-10 21:54:18.051392
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('meow', ((str, lambda x: '"meow"'),)) == '"meow"'
    assert get_repr_function(object(), ((str, lambda x: '"meow"'),)) == repr
    assert get_repr_function('meow', ((int, lambda x: '"meow"'),)) == repr
    assert get_repr_function(2, ((int, lambda x: '"meow"'),)) == '"meow"'
    assert get_repr_function(object(), ((object, lambda x: '"meow"'),)) == \
                                                                   '"meow"'
    assert get_repr_function(2, ((str, lambda x: '"meow"'),)) == repr

# Generated at 2022-06-10 21:54:24.060691
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr('12345', max_length=3) == '123...'
    assert get_shortish_repr('12345', max_length=4) == '123...'
    assert get_shortish_repr('123456789', max_length=4) == '1...'

# Generated at 2022-06-10 21:54:27.087753
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)
    assert not issubclass(WritableStream, A)



# Generated at 2022-06-10 21:54:29.688155
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestClass(object):
        def write(self, s):
            pass

    assert issubclass(TestClass, WritableStream)



# Generated at 2022-06-10 21:54:39.873613
# Unit test for function get_repr_function
def test_get_repr_function():

    def f(x):
        return id(x)

    def g(x):
        return -id(x)

    assert get_repr_function(1, (lambda x: False, f)) == f
    assert get_repr_function(2, (lambda x: False, g)) == g
    assert get_repr_function(3, ((int, long), g)) == g

    assert get_repr_function(3, ((int, long), f)) == repr
    assert get_repr_function(3, (long, f)) == repr
    assert get_repr_function(3.0, (int, f)) == repr
    assert get_repr_function(3.0, ((float, long), g)) == g


# Generated at 2022-06-10 21:54:44.624183
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.wrote = ''
        def write(self, s):
            self.wrote += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('ram')
    assert my_writable_stream.wrote == 'ram'

# Generated at 2022-06-10 21:54:56.718326
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo(object):
        pass
    class Bar(object):
        pass
    foo = Foo()
    bar = Bar()
    assert get_repr_function(foo, ((IS_FOO, lambda x: x.foorepr))) == \
                                                                 Foo.foorepr
    assert get_repr_function(bar, ((IS_FOO, lambda x: x.foorepr))) is repr
    assert get_repr_function(bar, ((Foo, lambda x: x.foorepr))) is repr
    assert get_repr_function(foo, ((IS_FOO, lambda x: x.foorepr), (Foo, id))) == \
                                                                                id