

# Generated at 2022-06-10 21:45:14.323817
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FileLike:
        def write(self, s):
            pass

    f = FileLike()
    assert issubclass(FileLike, WritableStream)
    assert issubclass(WritableStream, FileLike)
    assert isinstance(f, WritableStream)


PY3 = sys.version_info[0] == 3

# Generated at 2022-06-10 21:45:22.697281
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C: pass

    assert get_repr_function(A(), ()) == repr
    assert get_repr_function(B(), ()) == repr
    assert get_repr_function(C(), ()) == repr
    assert get_repr_function(A(), ((A, lambda x: 'a'),)) == 'a'
    assert get_repr_function(B(), ((A, lambda x: 'a'), (B, lambda x: 'b'))) == 'b'
    assert get_repr_function(C(), ((A, lambda x: 'a'), (B, lambda x: 'b'))) == repr

    assert get_repr_function(['a'], ((list, lambda x: 'a'),)) == 'a'

# Generated at 2022-06-10 21:45:33.997658
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(int, [(int, lambda: 'int')])() == 'int'
    assert get_repr_function(float, [(int, lambda: 'int')])() != 'int'
    assert get_repr_function(
        float,
        [(int, lambda: 'int'), (float, lambda: 'float')]
    )() == 'float'
    assert get_repr_function(
        'hello',
        [(int, lambda: 'int'), (float, lambda: 'float')]
    )() != 'int'
    assert get_repr_function(
        'hello',
        [(int, lambda: 'int'), (float, lambda: 'float')]
    )() != 'float'



# Generated at 2022-06-10 21:45:45.692322
# Unit test for function get_repr_function
def test_get_repr_function():
    from .custom_repr import CustomRepr
    from .custom_repr import custom_repr
    from .custom_repr import copy_custom_repr
    from .decorators import decorate

    @decorate(custom_repr(lambda x: x.number))
    class Foo(object):
        def __init__(self, number):
            self.number = number

    @decorate(custom_repr(lambda x: 'Custom repr'))
    class Bar(object):
        def __init__(self, number):
            self.number = number

    @decorate(custom_repr(CustomRepr('custom repr')))
    class Zoo(object):
        def __init__(self, number):
            self.number = number

    assert get_repr_function(Foo(5), []) == Foo

# Generated at 2022-06-10 21:45:56.304900
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(3) == '3'
    assert get_shortish_repr(3.14159) == '3.14159'
    assert get_shortish_repr('Hi mom.') == "'Hi mom.'"
    assert get_shortish_repr(3) == '3'
    assert get_shortish_repr(None) == 'None'

    assert get_shortish_repr(
        [1, 2, 3, 4, 5],
        custom_repr=((list, lambda x: 'listland'),),
    ) == "listland"


# Generated at 2022-06-10 21:46:01.162428
# Unit test for function get_repr_function
def test_get_repr_function():
    def f(x):
        if isinstance(x, int):
            return 'int'
        if isinstance(x, str):
            return 'str'
        return repr(x)

    custom_repr = ((int, f), (str, f), (object, repr))

    assert get_repr_function(1, custom_repr) is f
    assert get_repr_function(1.0, custom_repr) is repr
    assert get_repr_function(sys.stdout, custom_repr) is repr



# Generated at 2022-06-10 21:46:12.221055
# Unit test for function get_repr_function
def test_get_repr_function():
    class MyClass: pass
    class MySubclass(MyClass): pass
    class OtherClass: pass
    class MyOtherSubclass(OtherClass): pass


    def return_happy(x):
        if isinstance(x, MyOtherSubclass):
            return 'happy'
        else:
            return 'sad'


    def return_shitty(x):
        if isinstance(x, MySubclass):
            return 'shitty'
        else:
            return 'nice'


    custom_repr = (
        (return_happy, 'happy_repr'),
        (return_shitty, 'shitty_repr'),
    )
    m = MyClass()
    ms = MySubclass()
    mo = MyOtherSubclass()
    assert get_repr_function(m, custom_repr) is repr

# Generated at 2022-06-10 21:46:20.693740
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc', max_length=5) == 'abc'
    assert get_shortish_repr('abc', max_length=4) == 'a...'
    assert get_shortish_repr(('abc', 'def'), max_length=4) == ('abc', '...')
    assert get_shortish_repr(('abc', 'def'), max_length=3) == ('a...', '...')



# Generated at 2022-06-10 21:46:25.120158
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self, target=None):
            self.target = target

        def write(self, s):
            if self.target is not None:
                self.target.write(s)

    stream = MyWritableStream()
    assert isinstance(stream, WritableStream)



# Generated at 2022-06-10 21:46:35.661747
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class A(object):
        def __repr__(self):
            return 'A'

    assert get_shortish_repr(A(), max_length=10) == 'A'

    assert get_shortish_repr(A(), max_length=0) == ''

    assert get_shortish_repr(A(), max_length=2) == 'A'

    assert get_shortish_repr(A(), max_length=1) == '...'

    assert get_shortish_repr(A(), max_length=3) == 'A'

    assert get_shortish_repr(A(), max_length=4) == 'A'

    assert get_shortish_repr(A(), max_length=5) == 'A'


# Generated at 2022-06-10 21:46:45.935951
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('ação') == 'a?o'
    assert shitcode('ação'.encode('utf-8')) == 'ação'
    assert shitcode('ação'.encode('utf-32')) == 'a?'
    assert shitcode('ação'.encode('Latin1')) == 'ação'
    assert shitcode('ação'.encode('big5')) == 'a?'




# Generated at 2022-06-10 21:46:57.796993
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    x = 'spam' * 100
    assert get_shortish_repr(x,
                             max_length=20) == 'spamspamsp...spamspamsp'
    assert get_shortish_repr(x, max_length=20, normalize=True) == \
                                                         'spamspamsp...spamspamsp'

# Generated at 2022-06-10 21:47:05.885536
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('I like ramen.') == 'I like ramen.'
    assert shitcode('\u263a') == '?'
    assert shitcode('\u263a') == '?'
    assert shitcode('\u263a' + '\u263b') == '??'
    assert shitcode('I like ramen.\u263a') == 'I like ramen.?'
    assert shitcode('\u263aI like ramen.\u263a') == '?I like ramen.?'
    assert shitcode('I like ramen.\u263aI like ramen.\u263a') == \
                                                  'I like ramen.??I like ramen.?'

# Generated at 2022-06-10 21:47:13.029394
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Testable(metaclass=ABC):
        @abc.abstractmethod
        def write(self, s): pass

    # Make sure `write` method is detected correctly:
    assert issubclass(Testable, WritableStream)

    # Make sure `write` method is NOT detected correctly:
    class Testable(metaclass=ABC):
        @abc.abstractmethod
        def write2(self, s): pass

    assert not issubclass(Testable, WritableStream)



# Generated at 2022-06-10 21:47:23.917108
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(A): pass

    def repr_function_1(x): return 'Gotcha repr_function_1'
    def repr_function_2(x): return 'Gotcha repr_function_2'

    custom_repr = ((A, repr_function_1), (B, repr_function_2))

    assert get_repr_function(A(), custom_repr) is repr_function_1
    assert get_repr_function(B(), custom_repr) is repr_function_2
    assert get_repr_function(C(), custom_repr) is repr_function_1



# Generated at 2022-06-10 21:47:33.621922
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('', []) == repr
    assert get_repr_function('', [(lambda x: x, lambda x: 'y')]) == 'y'
    assert get_repr_function('',
                             [(lambda x: x, lambda x: 'y'),
                              (lambda x: x, lambda x: 'z')]) == 'y'
    assert get_repr_function(42,
                             [(lambda x: x, lambda x: 'y'),
                              (lambda x: x, lambda x: 'z')]) == 'z'
    assert get_repr_function('',
                             [(lambda x: x, lambda x: 'y'),
                              (lambda x: x, lambda x: 'z'),
                              (lambda x: x, lambda x: 'w')]) == 'y'

# Generated at 2022-06-10 21:47:37.763753
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TextIOWrapper(WritableStream):
        def __init__(self, *args, **kwargs):
            pass
        def write(self, s):
            pass
    assert issubclass(TextIOWrapper, WritableStream)



# Generated at 2022-06-10 21:47:47.043156
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function("abc", (("abc", 42),)) == 42
    assert get_repr_function("abc", ((lambda x: x == "abc", 42),)) == 42
    assert get_repr_function("abc", ((str, 42),)) == 42
    assert get_repr_function("abc", ((bytes, 42),)) != 42
    assert get_repr_function("abc", ((list, 42),)) != 42
    assert get_repr_function("abc", ((list, 42), (str, 24))) == 24
    assert get_repr_function("abc", ()) == repr



# Generated at 2022-06-10 21:47:56.900129
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .test_tools import TestCase, assert_equal


    class Cat(object):
        def __repr__(self):
            return 'Cat'
        def __unicode__(self):
            return 'Cat'

    class Dog(object):
        def __repr__(self):
            return 'Dog'
        def __unicode__(self):
            return 'Dog'

    class MyException(Exception):
        pass

    class TestCase(TestCase):
        def test_repr(self):
            assert_equal(get_shortish_repr(1), '1')
            assert_equal(get_shortish_repr(1, max_length=1), '1')
            assert_equal(get_shortish_repr(1, max_length=0), '')

# Generated at 2022-06-10 21:48:08.217083
# Unit test for function get_repr_function
def test_get_repr_function():
    a = 'a'
    b = (1, 2)
    c = 3
    special_repr = lambda x: 'special repr for %s' % (x,)
    assert get_repr_function(a, custom_repr=(
        (lambda x: isinstance(x, basestring), special_repr),
        ((float, int), special_repr)
    )) == special_repr
    assert get_repr_function(b, custom_repr=(
        (lambda x: isinstance(x, basestring), special_repr),
        ((float, int), special_repr)
    )) is repr

# Generated at 2022-06-10 21:48:17.952633
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(1, lambda x: 'foo')]) == 'foo'
    assert get_repr_function(1, [(int, lambda x: 'foo')]) == 'foo'
    assert get_repr_function(1, [(str, lambda x: 'foo')]) != 'foo'
    assert get_repr_function('', [(str, lambda x: 'foo')]) == 'foo'
    assert get_repr_function(1, []) == repr



# Generated at 2022-06-10 21:48:29.396270
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None, normalize=False) == 'None'
    assert get_shortish_repr(None, normalize=True) == 'None'
    assert get_shortish_repr(123, normalize=False) == '123'
    assert get_shortish_repr(123, normalize=True) == '123'
    assert get_shortish_repr([1,2,[3,4]], normalize=False) == '[1, 2, [...]]'
    assert get_shortish_repr([1,2,[3,4]], normalize=True) == '[1, ...]'
    assert get_shortish_repr([1,2,[3,4]], max_length=5, normalize=False) \
                                                                   == '[...]'
    assert get_

# Generated at 2022-06-10 21:48:31.588588
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class SomeClass(object):
        def write(self, s):
            pass

    assert isinstance(SomeClass(), WritableStream)





# Generated at 2022-06-10 21:48:33.532131
# Unit test for function get_repr_function
def test_get_repr_function():
    repr_function = get_repr_function('abc', ((str, 'foobar'),))
    assert repr_function('abc') == 'foobar'



# Generated at 2022-06-10 21:48:38.302681
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s): pass
        def doh(self): pass

    assert MyWritableStream.__subclasshook__(MyWritableStream) is True
    assert MyWritableStream.__subclasshook__(type) is NotImplemented

# Generated at 2022-06-10 21:48:42.873190
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello world') == 'hello world'
    assert shitcode('\u2655\u2656\u2657\u2658\u2659') == '?????'
    assert shitcode('\u2655\u2656\u2657\u2658\u2659' * 100) == '?????' * 100

# Generated at 2022-06-10 21:48:47.804890
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(WritableStream):
        def write(self, s):
            pass
    assert issubclass(X, WritableStream)
    class Y(X):
        pass
    assert issubclass(Y, WritableStream)
    class Z(Y):
        def write(self, s):
            pass
    assert issubclass(Z, WritableStream)

# Generated at 2022-06-10 21:48:56.657203
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    def r(item):
        return get_shortish_repr(item, max_length=12, custom_repr=())

    assert r('') == ''
    assert r(1) == '1'
    assert r(1.0) == '1.0'
    assert r([1, 2, 3]) == '(1, 2, 3)'
    assert r((1, 2, 3)) == '(1, 2, 3)'
    assert r(set([1, 2, 3])) == '{1, 2, 3}'
    assert r('bla bla bla') == 'bla bla bla'
    assert r(None) == 'None'



# Generated at 2022-06-10 21:49:07.813143
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .exceptions import NoComma

    class A:

        def __repr__(self):
            return '12345'

        def __unicode__(self):
            raise NoComma

        def __str__(self):
            raise NoComma

    class B:

        def __repr__(self):
            return '\r\n'

        def __unicode__(self):
            raise NoComma

        def __str__(self):
            raise NoComma

    class C(A):

        def __repr__(self):
            raise NoComma

    assert get_shortish_repr(A()) == '12345'


# Generated at 2022-06-10 21:49:12.189550
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class GoodWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(GoodWritableStream, WritableStream)

    class BadWritableStream:
        pass

    assert not issubclass(BadWritableStream, WritableStream)


# Generated at 2022-06-10 21:49:24.225786
# Unit test for function get_repr_function
def test_get_repr_function():
    a = object()
    b = object()
    assert get_repr_function(a, ((object, lambda o: 'yeah'), (b, 'nope'))) is repr
    assert get_repr_function(b, ((object, lambda o: 'yeah'), (b, 'nope'))) == 'nope'



# Generated at 2022-06-10 21:49:28.962649
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestFile:
        def __init__(self):
            self.text = ''
        def write(self, stuff):
            self.text += stuff
    assert issubclass(TestFile, WritableStream)
    test_file = TestFile()
    test_file.write('hi')
    assert test_file.text == 'hi'

# Generated at 2022-06-10 21:49:32.266544
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def write(self, s):
            assert isinstance(s, string_types)
            self.__s = s

    my_stream = MyStream()
    my_stream.write('meow')



# Generated at 2022-06-10 21:49:45.026178
# Unit test for function get_repr_function
def test_get_repr_function():

    class A: pass

    def f(x): return 'f'

    def g(x): return 'g'

    def h(x): return 'h'

    assert get_repr_function(
        a,
        [
            (A, f),
            (lambda x: True, g),
        ]
    ) is f

    assert get_repr_function(
        a,
        [
            (A, g),
            (lambda x: True, f),
        ]
    ) is g

    assert get_repr_function(
        a,
        [
            (A, f),
            (lambda x: True, h),
        ]
    ) is f


# Generated at 2022-06-10 21:49:54.308138
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    def repr_func1(item): return 'repr_func1({!r})'.format(item)
    def repr_func2(item): return 'repr_func2({!r})'.format(item)
    custom_repr = [
        (A, repr_func1),
        (B, repr_func2)
    ]
    assert get_repr_function(A(), custom_repr) is repr_func1
    assert get_repr_function(B(), custom_repr) is repr_func2
    assert get_repr_function(C(), custom_repr) is repr_func1



# Generated at 2022-06-10 21:49:58.263215
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import re
    import textwrap
    from .pycompat import StringIO

    class ExampleWritableStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(StringIO(), WritableStream)
    assert isinstance(ExampleWritableStream(), WritableStream)
    assert not isinstance(1, WritableStream)

# Generated at 2022-06-10 21:50:08.389283
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('1234', normalize=True) == "'1234'"
    assert get_shortish_repr([1, 2, 3, 4], normalize=True) == "[1, 2, 3, 4]"
    assert get_shortish_repr([1, 2, 3, 4], normalize=True, max_length=15) == \
                                                             "[1, 2, 3, 4]"
    assert get_shortish_repr('foobar', normalize=True, max_length=4) == "'f...'"
    assert get_shortish_repr(['1', '22', '333'], normalize=True, max_length=9) == \
                                                                   "['1', '2...']"

# Generated at 2022-06-10 21:50:11.308264
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Test(WritableStream):
        def write(self, s):
            pass
    assert isinstance(Test(), WritableStream)

# Generated at 2022-06-10 21:50:19.962871
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .cute_iter_tools import ilen

    class A(object):
        def __init__(self, x):
            self.x = x
        def __repr__(self):
            return str(self.x)

    repr_1 = get_shortish_repr(A(1), max_length=4, normalize=True)
    assert repr_1 == '1'
    repr_11111111111111111111111111111111111111111111111111111111111111 = \
                             get_shortish_repr(
                                 A(11111111111111111111111111111111111111111111111111111111111111),
                                 max_length=4,
                                 normalize=True
                             )

# Generated at 2022-06-10 21:50:26.380056
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_data = []
        def write(self, s):
            assert isinstance(s, str)
            self.written_data.append(s)
    mws = MyWritableStream()
    mws.write('lala')
    assert mws.written_data == ['lala']

# Generated at 2022-06-10 21:50:34.805210
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeStream(WritableStream):
        def write(self, s):
            return 'test ' + s

    assert FakeStream().write('success') == 'test success'



# Generated at 2022-06-10 21:50:40.310804
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(WritableStream):
        def write(self, s):
            pass

    assert issubclass(X, WritableStream)

    class Y(WritableStream):
        pass

    assert not issubclass(Y, WritableStream)

    class Y(object):
        def write(self, s):
            pass

    assert issubclass(Y, WritableStream)

# Generated at 2022-06-10 21:50:50.626631
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A(object):
        def __repr__(self):
            return 'A()' * 100

    custom_repr = (
        (lambda x: isinstance(x, A), lambda x: 'A' * 50),
        (lambda x: 'a' in x, lambda x: 'foo'),
    )

    assert get_shortish_repr('1234567890',
                             max_length=None) == '1234567890'
    assert get_shortish_repr('1234567890',
                             max_length=10) == '1234567890'
    assert get_shortish_repr('1234567890',
                             max_length=9) == '12345...90'

# Generated at 2022-06-10 21:51:00.221528
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, [(int, lambda x: 'int!')]) == str
    assert get_repr_function(0, [(int, lambda x: 'int!'),
                                 (object, lambda x: 'object!')]) == str
    assert get_repr_function(
        0, [(object, lambda x: 'object!'), (int, lambda x: 'int!')]
    ) == str
    assert get_repr_function(0, [(int,)]) != str
    assert get_repr_function(0, [(int,)]) == int.__repr__



# Generated at 2022-06-10 21:51:10.612882
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyFile(object):
        def write(self, s):
            assert isinstance(s, str)
    assert issubclass(MyFile, WritableStream)

    class MyFileWithNone(object):
        def write(self, s):
            assert isinstance(s, str)
            return None
    assert issubclass(MyFileWithNone, WritableStream)

    class MyNotFileWithNone(object):
        def another_method(self):
            pass
        def write(self):
            return None
    assert not issubclass(MyNotFileWithNone, WritableStream)

    class MyNotFileWithWrite(object):
        def write(self, s):
            assert isinstance(s, str)

    class MyNotFile(MyNotFileWithWrite):
        pass

# Generated at 2022-06-10 21:51:22.851984
# Unit test for function get_repr_function
def test_get_repr_function():

    class A(object): pass
    class B(object): pass
    class C(object): pass

    for a in (1, 1.1, '1', A(), B()):
        assert get_repr_function(
            a, custom_repr=(
                (A, lambda a: 'A'),
            )
        ) is repr
        assert get_repr_function(
            a, custom_repr=(
                (A, lambda a: 'A'),
                (1, lambda a: '1'),
            )
        ) is repr


# Generated at 2022-06-10 21:51:36.588146
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    t = ((1, 2), {3, 4}, '1234567890')
    assert get_shortish_repr(t, max_length=None) == repr(t)
    assert get_shortish_repr(t, max_length=16) == '(1, 2)...'
    assert get_shortish_repr(t, max_length=17) == '(1, 2), ...'
    assert get_shortish_repr(t, max_length=18) == '(1, 2), {...'
    assert get_shortish_repr(t, max_length=19) == '(1, 2), {3...'
    assert get_shortish_repr(t, max_length=20) == '(1, 2), {3, ...'

# Generated at 2022-06-10 21:51:39.307941
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestClass(WritableStream):
        def write(self, s):
            pass

    TestClass()



# Generated at 2022-06-10 21:51:44.530993
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        pass

    assert not issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-10 21:51:53.292522
# Unit test for function get_repr_function
def test_get_repr_function():
    passes = 0
    fails = 0

    class A:
        pass
    a = A()

    class B:
        pass
    b = B()

    def repr_one(x):
        assert x == 1
        return 'ONE'

    def repr_two(x):
        assert x == 2
        return 'TWO'

    def repr_a(x):
        assert x is a
        return 'A'

    repr_function = get_repr_function(
        1,
        custom_repr=[(lambda x: x == 1, repr_one),
                     (lambda x: x == 2, repr_two),
                     (lambda x: x is a, repr_a)]
    )

    assert repr_function(1) == 'ONE'
    passes += 1


# Generated at 2022-06-10 21:52:06.564310
# Unit test for function get_repr_function
def test_get_repr_function():
    for item, result in [
        (1, repr),
        (1.5, repr),
        ('a', repr),
        ((), repr),
        (dict(), repr),
        ([], repr),
        (set(), repr),
        (1, str),
        (5, float),
    ]:
        assert get_repr_function(item, [(int, str), (float, float)]) == result



# Generated at 2022-06-10 21:52:12.118792
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamTest(WritableStream):
        def write(self, s):
            pass

    assert isinstance(WritableStreamTest(), WritableStream)
    class A:
        pass
    assert not isinstance(A(), WritableStream)


if sys.version_info[0] == 2:
    from .py2 import *

# Generated at 2022-06-10 21:52:24.104799
# Unit test for function get_repr_function

# Generated at 2022-06-10 21:52:33.589330
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object):
        pass

    class B(A):
        pass

    a = A()
    b1 = B()
    b2 = B()

    def f(x):
        return int(x)

    def g(x):
        return float(x)

    assert get_repr_function(a) == repr
    assert get_repr_function(b1) == repr
    assert get_repr_function(b2) == repr
    assert get_repr_function(a, custom_repr=[(A, f)]) == f
    assert get_repr_function(b1, custom_repr=[(A, f)]) == f
    assert get_repr_function(b1, custom_repr=[(B, g)]) == g

# Generated at 2022-06-10 21:52:37.190784
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class XStream(WritableStream):
        def write(self, s):
            assert isinstance(s, str)

    xstream = XStream()
    xstream.write('')




# Generated at 2022-06-10 21:52:47.550117
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'

    assert get_shortish_repr(1, max_length=4, normalize=True) == '1'

    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'

# Generated at 2022-06-10 21:52:56.461495
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .testing import assert_equal
    assert_equal(get_shortish_repr([1, 2, 3]), '[1, 2, 3]')


# Generated at 2022-06-10 21:53:02.651309
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            import sys
            sys.stdout.write(s)
    class MyNonWritableStream(object):
        pass
    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(MyNonWritableStream, WritableStream)




# Generated at 2022-06-10 21:53:13.048489
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .context_management import OutputRedirector
    from .sys_tools import IteratedDataStream, TeeDataStream

    class SimpleObject(object):
        def __init__(self, a, b):
            self.a, self.b = a, b

        def __repr__(self):
            return 'SimpleObject({}, {})'.format(self.a, self.b)

    object_ = SimpleObject(5, 12)

    # Test truncating with a regular repr
    with OutputRedirector() as output_redirector:
        print(get_shortish_repr(object_, max_length=15))
    assert output_redirector.get_output() == 'SimpleObject(5, ...\n'

    # Test truncating with a custom repr

# Generated at 2022-06-10 21:53:16.496530
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s): pass
    class B:
        pass
    class C(WritableStream):
        def write(self, s): pass
    assert issubclass(A, WritableStream)
    assert issubclass(C, WritableStream)
    assert not issubclass(B, WritableStream)




# Generated at 2022-06-10 21:53:34.653792
# Unit test for function get_repr_function

# Generated at 2022-06-10 21:53:42.036253
# Unit test for function get_repr_function
def test_get_repr_function():
    import numpy as np
    class A: pass
    class B(A): pass
    class C(B): pass
    class D: pass
    assert get_repr_function(A, ((None, 'repr A'))) == 'repr A'
    assert get_repr_function(B, ((None, 'repr A'))) == 'repr A'
    assert get_repr_function(C, ((None, 'repr A'))) == 'repr A'
    assert get_repr_function(D, ((None, 'repr A'))) == 'repr A'
    assert get_repr_function(D, ((D, 'repr D'),(None, 'repr A'))) == 'repr D'

# Generated at 2022-06-10 21:53:43.264368
# Unit test for function get_repr_function
def test_get_repr_function():
    s = get_repr_function('str', [(str, str)])
    assert s == str
    assert get_repr_function('str', [(int, lambda: 'int')]) == repr



# Generated at 2022-06-10 21:53:44.135748
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    MyWritableStream()

# Generated at 2022-06-10 21:53:52.644333
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C: pass
    class D: pass
    assert get_repr_function(A(), custom_repr=[(A, lambda x: 'hi')])() == 'hi'
    assert get_repr_function(
        B(), custom_repr=[(A, lambda x: 'hi')])() == 'hi'
    assert normalize_repr(get_repr_function(
        C(), custom_repr=[(A, lambda x: 'hi')])(C())) == "C()"

# Generated at 2022-06-10 21:54:01.691965
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class NonWritableStream:
        write = None
        flush = None

    class WritableStream2:
        write = None

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

        def flush(self):
            pass

    assert isinstance(MyWritableStream(), WritableStream) is True
    assert isinstance(NonWritableStream(), WritableStream) is False
    assert isinstance(WritableStream2(), WritableStream) is False

    class AutoWritableStream(WritableStream):
        def __init__(self, name):
            self.name = name

        def write(self, s):
            print(s.replace('\n', '\\n'), file=sys.stderr)

        def flush(self):
            pass

    auto_writable_stream = AutoWritable

# Generated at 2022-06-10 21:54:07.414591
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hi', custom_repr=((int, lambda _: 'int'),)) == repr
    assert get_repr_function(5, custom_repr=((int, lambda _: 'int'),)) == (lambda _: 'int')


if __name__ == '__main__':
    test_get_repr_function()

# Generated at 2022-06-10 21:54:11.371409
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass
    assert isinstance(A(), WritableStream)

    class B:
        pass
    assert not isinstance(B(), WritableStream)




# Generated at 2022-06-10 21:54:16.914501
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    x = WritableStream()

    try:
        x.write('hi')
    except NotImplementedError:
        pass
    else:
        raise Exception("Write method of WritableStream has no not "
                        "implemented error!")

    class X(WritableStream):
        def write(self, s):
            pass

    X().write('hi')

# Generated at 2022-06-10 21:54:21.954231
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, custom_repr=((lambda x: x == 1, lambda x: 'one'),)) == 'one'
    assert get_repr_function((1,), custom_repr=((list, lambda x: 'list'),)) == repr
    assert get_repr_function([1], custom_repr=((list, lambda x: 'list'),)) == 'list'





# Generated at 2022-06-10 21:54:38.741723
# Unit test for function get_repr_function
def test_get_repr_function():

    def custom_repr_for_ints(i):
        return '"{}"'.format(i)

    string_repr_function = get_repr_function('abc', [
        (lambda s: isinstance(s, str), str)
    ])
    assert string_repr_function('abc') == "'abc'"

    custom_repr_function = get_repr_function(2, [
        (int, custom_repr_for_ints)
    ])
    assert custom_repr_function(2) == '"2"'

    default_repr_function = get_repr_function('abc', [
        (int, custom_repr_for_ints)
    ])
    assert default_repr_function('abc') == "'abc'"



# Generated at 2022-06-10 21:54:45.025078
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class CorrectClass(WritableStream):
        def write(self, s):
            pass

    assert isinstance(CorrectClass(), WritableStream)
    assert not isinstance(object(), WritableStream)

    class MissingMethod(WritableStream):
        pass

    assert not isinstance(MissingMethod(), WritableStream)

    class IncorrectMethodSignature(WritableStream):
        def write(self):
            pass

    assert not isinstance(IncorrectMethodSignature(), WritableStream)



# Generated at 2022-06-10 21:54:57.026687
# Unit test for function get_repr_function
def test_get_repr_function():
    from .pycompat import PY3
    if PY3:
        assert get_repr_function(1, []) is repr
        assert get_repr_function(1.0, []) is repr
        assert get_repr_function(True, []) is repr
        assert get_repr_function(False, []) is repr
        assert get_repr_function(None, []) is repr
        assert get_repr_function(b'', []) is repr
        assert get_repr_function('', []) is repr
        assert get_repr_function([], []) is repr
        assert get_repr_function({}, []) is repr
        assert get_repr_function((), []) is repr

        assert get_repr_function(1, [(int, str)]) is str

# Generated at 2022-06-10 21:55:02.895524
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(b'x', max_length=6) == "b'x'"
    assert get_shortish_repr('x', max_length=0) == 'x'[:0]
    assert get_shortish_repr(2 + 3j) == '(2+3j)'
    assert get_shortish_repr(2 + 3j, max_length=5) == '(2+3j)'[:5]


