

# Generated at 2022-06-10 21:45:27.612377
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .python_toolbox import nice_repr

    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(None, max_length=4) == 'None'
    assert get_shortish_repr(None, max_length=3) == 'Non'
    assert get_shortish_repr(None, max_length=2) == 'No'
    assert get_shortish_repr(None, normalize=True) == 'None'
    assert get_shortish_repr(None, normalize=True, max_length=2) == 'No'
    assert get_shortish_repr('') == "''"
    assert get_shortish_repr('', max_length=0) == '""'

# Generated at 2022-06-10 21:45:35.997452
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, ((int, int.__repr__),)) == int.__repr__
    assert get_repr_function(3, ((int, str.__repr__),)) == str.__repr__
    assert get_repr_function(3, ((int, str.__repr__), (int, int.__repr__))) == str.__repr__
    assert get_repr_function(3, ((int, int.__repr__), (int, str.__repr__))) == int.__repr__



# Generated at 2022-06-10 21:45:46.213667
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(3.3, max_length=2) == '3.3'
    assert get_shortish_repr(3.3, max_length=3) == '3.3'
    assert get_shortish_repr(3.3, max_length=4) == '3.3'

    assert get_shortish_repr(3.3, max_length=5) == '3.3'

    assert get_shortish_repr(3.3, max_length=6) == '3.3'

    assert get_shortish_repr(3.3, max_length=7) == '3.3'
    assert get_shortish_repr(3.3, max_length=8) == '3.3'

# Generated at 2022-06-10 21:45:56.629412
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .testing.asserting import assert_repr

    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'

    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'

    assert get_shortish_repr(1, max_length=4) == '1'

# Generated at 2022-06-10 21:46:06.532588
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=-1) == ''

    assert get_shortish_repr(1, normalize=True) == '1'
    assert get_shortish_repr(1, max_length=2, normalize=True) == '1'
    assert get_shortish_repr(1, max_length=1, normalize=True) == '1'

# Generated at 2022-06-10 21:46:10.157275
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('abc', []) is repr
    assert get_repr_function('abc', [
        (int, str),
    ]) is not str
    assert get_repr_function('abc', [
        (lambda x: x == 'cba', str),
    ]) is repr
    assert get_repr_function('cba', [
        (lambda x: x == 'cba', str),
    ]) is str



# Generated at 2022-06-10 21:46:24.040608
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(object): pass
    assert get_repr_function(None, [])  == repr
    assert get_repr_function(A(), [])  == repr
    assert get_repr_function(B(), [])  == repr
    assert get_repr_function(None, [(lambda x: True, lambda x: 'y')]) == 'y'
    assert get_repr_function(None, [(lambda x: True, lambda x: x)]) == None
    assert get_repr_function(A(), [(lambda x: True, lambda x: x)]) == A
    assert get_repr_function(A(), [(lambda x: True, lambda x: x), (lambda x: True, lambda x: x)]) == A

# Generated at 2022-06-10 21:46:33.156128
# Unit test for method write of class WritableStream
def test_WritableStream_write():


    class WritableStringIO(WritableStream):
        __slots__ = ('value',)

        def __init__(self):
            self.value = ''

        def write(self, s):
            self.value += s

    wsio = WritableStringIO()
    wsio.write('hello')
    assert wsio.value == 'hello'

    class BadWritableStringIO(WritableStream):
        __slots__ = ('value',)

        def __init__(self):
            self.value = ''

    with pytest.raises(TypeError):
        issubclass(BadWritableStringIO, WritableStream)



# Generated at 2022-06-10 21:46:39.461598
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('a', []) is repr
    assert get_repr_function(1, []) is repr

    def special_repr(x):
        return 'a'
    assert get_repr_function('a', [(lambda x: True, special_repr)]) is \
           special_repr
    assert get_repr_function('a', [(lambda x: False, special_repr)]) is not \
           special_repr

    assert get_repr_function('a', [(str, special_repr)]) is special_repr
    assert get_repr_function(1, [(str, special_repr)]) is not special_repr



# Generated at 2022-06-10 21:46:44.572542
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """Method write of class WritableStream is tested."""
    class MyWritableStream(WritableStream):
        def write(self, s):
            return 42
    stream = MyWritableStream()
    assert stream.write('meow') == 42


# This should happen in the unit test as well
if __name__ == '__main__':
    test_WritableStream_write()

# Generated at 2022-06-10 21:46:53.387615
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Good:
        def write(self, s):
            pass

    class Bad:
        def write(self, s):
            return 'a'

    class Ugly:
        write = 1

    assert issubclass(Good, WritableStream)
    assert not issubclass(Bad, WritableStream)
    assert not issubclass(Ugly, WritableStream)

# Generated at 2022-06-10 21:47:01.624083
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass

    def my_repr(x):
        return 'my repr of ' + repr(x)

    custom_repr = (
        (lambda x: isinstance(x, B), my_repr),
        (D, lambda x: 'D'),
    )

    assert get_repr_function(A(), custom_repr) is repr
    assert get_repr_function(B(), custom_repr) is my_repr
    assert get_repr_function(C(), custom_repr) is repr
    assert get_repr_function(D(), custom_repr) is (lambda x: 'D')

# Generated at 2022-06-10 21:47:10.161119
# Unit test for function get_repr_function
def test_get_repr_function():
    if sys.version_info <= (3, 5):
        return
    assert get_repr_function(1, custom_repr=(
        (int, lambda x: str(x)),
    ))(1) == '1'
    assert get_repr_function(1, custom_repr=(
        (type, lambda x: str(x)),
    ))(1) == '1'
    assert get_repr_function(1, custom_repr=(
        (lambda x: isinstance(x, int), lambda x: str(x)),
    ))(1) == '1'

# Generated at 2022-06-10 21:47:15.046018
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert 'spam' == get_shortish_repr('spam', max_length=10)
    assert 'spam' == get_shortish_repr('spam', max_length=4)
    assert 'spa...ham' == get_shortish_repr('spam', max_length=5)
    assert '<spa...am>' == get_shortish_repr('<spam>', max_length=8)

# Generated at 2022-06-10 21:47:19.037620
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C:
        def write(self, s): pass
    assert issubclass(C, WritableStream)


# Unit tests for method __subclasshook__ of class WritableStream


# Generated at 2022-06-10 21:47:25.560266
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WriteMe(object):
        def __init__(self):
            self.text = ''

        def write(self, text):
            self.text += text

    assert issubclass(WriteMe, WritableStream)
    assert WriteMe().text == ''
    WriteMe().write('hi')
    assert WriteMe().text == 'hi'



# Generated at 2022-06-10 21:47:26.744261
# Unit test for function shitcode
def test_shitcode():
    shitcode('שלום')

# Generated at 2022-06-10 21:47:35.502569
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[]) == repr
    assert get_repr_function(1, custom_repr=[(1, str)]) == str
    assert get_repr_function(1, custom_repr=[(1, str), (1, str)]) == str
    assert get_repr_function(1, custom_repr=[(1, str), (1, str), (1, str)]) \
                                                                          == str

    assert get_repr_function(1, custom_repr=[(1, str), (2, str)]) == repr
    assert get_repr_function(1, custom_repr=[(2, str), (1, str)]) == str

# Generated at 2022-06-10 21:47:47.432258
# Unit test for function get_repr_function
def test_get_repr_function():
    def f(x):
        return x**2

    custom_repr = (
        (lambda x: x == 5, lambda x: '5'),
        ((int, float, long), lambda x: 'number'),
        (lambda x: x > 10, lambda x: '>10'),
        (lambda x: x < 10, lambda x: '<10')
    )

    assert get_repr_function(5, custom_repr) is custom_repr[0][1]

    assert get_repr_function(10, custom_repr) is custom_repr[2][1]

    assert get_repr_function(3, custom_repr) is custom_repr[3][1]

    assert get_repr_function(3.5, custom_repr) is custom_repr[1][1]



# Generated at 2022-06-10 21:47:52.444702
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass
    assert issubclass(WritableStreamSubclass, WritableStream)

    class WritableStreamSubclass2(WritableStream):
        pass
    assert not issubclass(WritableStreamSubclass2, WritableStream)

# Generated at 2022-06-10 21:48:02.004550
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestWritableStream(WritableStream):
        def __init__(self):
            self.written = []
        def write(self, s):
            self.written.append(s)
    t = TestWritableStream()
    t.write('abc')
    assert t.written == ['abc']



# Generated at 2022-06-10 21:48:13.836317
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\0x01') == '?x01'
    assert shitcode(u'\u00FE') == u'\uFFFD'
    assert shitcode(u'\U00010302') == u'\U00010302'
    if sys.version_info >= (3, 0):
        assert shitcode(bytes([])) == ''
        assert shitcode(bytes([0])) == '\x00'
        assert shitcode(bytes([1])) == '\x01'
        assert shitcode(bytes([255])) == '\xff'
        assert shitcode(bytes([0, 1])) == '\x00\x01'
        assert shitcode(bytes([0xff, 0xff])) == '\xff\xff'

# Generated at 2022-06-10 21:48:20.513721
# Unit test for function get_repr_function
def test_get_repr_function():
    x = (1, 2, 3)

    assert get_repr_function(x, []) == repr
    assert get_repr_function(x, [(lambda y: True, None)]) == None
    assert get_repr_function(x, [(lambda y: True, lambda y: 'X')])() == 'X'

    assert get_repr_function(x, [(lambda y: False, None)]) == repr
    assert get_repr_function(x, [(lambda y: False, lambda y: 'X')]) == repr
    assert get_repr_function(x, [(lambda y: False, lambda y: 'X')])() == repr()

    assert get_repr_function(x, [(list, lambda y: 'list')])() == 'list'

# Generated at 2022-06-10 21:48:23.822686
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a ב ג') == 'a ? ?'
    assert shitcode('a ב ג') == 'a ? ?'



# Generated at 2022-06-10 21:48:30.848126
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class _WritableStreamTest(WritableStream):
        pass
    _WritableStreamTest.register(_WritableStreamTest)
    assert issubclass(_WritableStreamTest, WritableStream)
    class _TestSubclass(_WritableStreamTest):
        pass
    assert issubclass(_TestSubclass, WritableStream)
    writable_stream = _WritableStreamTest()
    class _NotWritableStreamTest(object):
        pass
    assert not issubclass(_NotWritableStreamTest, WritableStream)

# Generated at 2022-06-10 21:48:32.273568
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class FakeFile(WritableStream):
        def write(self, s):
            pass

    FakeFile().write('Hello')

# Generated at 2022-06-10 21:48:42.796828
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr('hello', max_length=3) == 'hel'
    assert get_shortish_repr('hello', max_length=6) == 'hello'
    assert get_shortish_repr('hello', max_length=7) == 'hello'
    assert get_shortish_repr('hello', max_length=8) == 'hello'
    assert get_shortish_repr('hello', max_length=4) == 'hell'
    assert get_shortish_repr('hello', max_length=5) == 'hello'
    assert get_shortish_repr(b'hello') == "b'hello'"

# Generated at 2022-06-10 21:48:54.291989
# Unit test for function get_repr_function
def test_get_repr_function():
    a = [1]
    b = {2: 3}
    c = (4,)
    d = set([5])
    e = 6
    f = (1, 2, 3, 4)
    g = []

    def repr_function_a(item, repr_function=repr):
        if isinstance(item, int):
            return repr(item + 1)
        else:
            return repr_function(item)

    def repr_function_b(item):
        return str(item)

    assert get_repr_function(a, [(lambda x: isinstance(x, list),
                                  repr_function_a)]) == repr_function_a
    assert get_repr_function(b, [(lambda x: isinstance(x, list),
                                  repr_function_a)]) is repr
    assert get

# Generated at 2022-06-10 21:49:05.111132
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, ()) == repr
    assert get_repr_function(3.14, ()) == repr
    assert get_repr_function(2**15, ()) == repr

    assert get_repr_function(3, custom_repr=((int, str),)) == str
    assert get_repr_function(3.14, custom_repr=((int, str),)) == repr
    assert get_repr_function(2**15, custom_repr=((int, str),)) == str

    assert get_repr_function(3, custom_repr=((lambda x: x == 3, str),)) == str
    assert get_repr_function(3.14, custom_repr=((lambda x: x == 3, str),)) == repr

# Generated at 2022-06-10 21:49:15.533246
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    shortish_repr = get_shortish_repr

    assert shortish_repr('hello') == "'hello'"
    assert shortish_repr(5) == '5'
    assert shortish_repr(5.5) == '5.5'

    assert shortish_repr(True) == 'True'
    assert shortish_repr(False) == 'False'

    assert shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert shortish_repr({1, 2, 3}) == '{1, 2, 3}'
    assert shortish_repr({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"


# Generated at 2022-06-10 21:49:28.580705
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(str, []) is repr     # default repr
    assert get_repr_function(str, [(str, str)]) is str
    assert get_repr_function('a', [(str, str)]) is str
    assert get_repr_function(str, [(str, str), (frozenset, frozenset.__repr__)]) is str
    assert get_repr_function(frozenset(), [(str, str), (frozenset, frozenset.__repr__)]) is frozenset.__repr__
    assert get_repr_function(frozenset(), [(frozenset, frozenset.__repr__), (str, str)]) is frozenset.__repr__

# Generated at 2022-06-10 21:49:36.524563
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    __metaclass__ = ABC
    class FileLike(WritableStream):
        def __init__(self, file_like_object, write_function=None):
            if write_function is None:
                def write_function(s):
                    file_like_object.write(s)
            self.write_function = write_function

        def write(self, s):
            return self.write_function(s)

    class FileLikeThing(FileLike):
        pass

    class OtherFileLikeThing(FileLikeThing):
        def write(self, s):
            return self.write_function(s)

    assert issubclass(FileLike, WritableStream)
    assert issubclass(FileLikeThing, WritableStream)
    assert issubclass(OtherFileLikeThing, WritableStream)



# Generated at 2022-06-10 21:49:47.237860
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    max_length = 30
    assert get_shortish_repr(1, max_length=max_length) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr([1, 2, 3], max_length=max_length) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=9) == '[1, 2, 3]'

# Generated at 2022-06-10 21:49:51.553308
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass

    assert issubclass(
        WritableStreamSubclass,
        WritableStream
    )

    class WritableStreamSubclass2(WritableStream):
        pass

    assert not issubclass(
        WritableStreamSubclass2,
        WritableStream
    )

    class WritableStreamSubclass3(WritableStream):
        def write(self):
            pass

    assert not issubclass(
        WritableStreamSubclass3,
        WritableStream
    )

# Generated at 2022-06-10 21:49:59.821861
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    def check(max_length,
              item,
              custom_repr=(),
              expected_result=None,
              normalize=False):
        if expected_result is None:
            expected_result = get_repr_function(item, custom_repr)(item)
        r = get_shortish_repr(item, custom_repr, max_length, normalize)
        assert r == expected_result
        
    from .mock import Mock, MagicMock
    class A:
        def __repr__(self):
            return 'repr_a'
    class B:
        def __repr__(self):
            return 'repr_b'
    class C:
        def __repr__(self):
            return 'repr_c'

# Generated at 2022-06-10 21:50:03.357276
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    a = 'a'
    class Foo(object):
        def write(self, s):
            a = s
    assert isinstance(Foo(), WritableStream)
    Foo().write('b')
    assert a == 'b'



# Generated at 2022-06-10 21:50:14.476500
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr('a', max_length=5) == 'a'
    assert get_shortish_repr('a' * 5, max_length=5) == 'aaaaa'
    assert get_shortish_repr('a' * 6, max_length=5) == '...a'
    assert get_shortish_repr('a' * 7, max_length=5) == '...a'



# Generated at 2022-06-10 21:50:26.407547
# Unit test for function get_shortish_repr

# Generated at 2022-06-10 21:50:28.713820
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestWritableStream(WritableStream):
        def write(self, s):
            pass
    TestWritableStream()

# Generated at 2022-06-10 21:50:33.348950
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr([1, 2, 3, 4], max_length=10) == '[1, 2, 3...'

# Generated at 2022-06-10 21:50:46.625133
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    def assert_get_shortish_repr(item, expected=None, **kwargs):
        result = get_shortish_repr(item, **kwargs)
        assert result == expected

    class Thing:
        pass


    thing = Thing()
    assert_get_shortish_repr(thing, expected=thing.__repr__())

    thing.__repr__ = lambda: 'YAY!'
    assert_get_shortish_repr(thing, expected='YAY!')

    assert_get_shortish_repr(thing, expected=thing.__repr__(),
                             max_length=3)
    assert_get_shortish_repr(thing, expected=thing.__repr__(),
                             max_length=4)

# Generated at 2022-06-10 21:50:52.645394
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(
        1, [(lambda x: isinstance(x, int), str)]
    ) is str
    assert get_repr_function(123, [(lambda x: x > 100, str)]) is str
    assert get_repr_function('meep', [(lambda x: isinstance(x, int), str)]) \
                  is repr



# Generated at 2022-06-10 21:51:04.724754
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, []) == repr
    assert get_repr_function(None, custom_repr=((1, 1),)) == repr
    assert get_repr_function(None, custom_repr=((None, 1),)) == 1
    assert get_repr_function(None, custom_repr=((lambda x: False, 1),)) == repr
    assert get_repr_function(None, custom_repr=((lambda x: True, 1),)) == 1
    assert get_repr_function('', custom_repr=((None, 1),)) == repr
    assert get_repr_function('', custom_repr=((str, 1), (int, 2))) == 1

# Generated at 2022-06-10 21:51:09.929165
# Unit test for function get_repr_function
def test_get_repr_function():
    # assert get_repr_function(1, (int, list)) == list
    assert get_repr_function(1, ((int, list),)) == list
    assert get_repr_function(1.0, (float,)) == float
    assert get_repr_function('abc', (str, repr)) == repr
    assert get_repr_function('abc', (str, str)) == str



# Generated at 2022-06-10 21:51:13.125757
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Spam(object):
        def write(self, x):
            print(x)
    assert isinstance(Spam(), WritableStream)




# Generated at 2022-06-10 21:51:24.850652
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int!'))) == 'int!'
    assert get_repr_function(3.14, ((int, 'int!'))) == repr
    assert get_repr_function(1, ((lambda x: isinstance(x, int), 'int!'))) == 'int!'
    assert get_repr_function(3.14, ((lambda x: isinstance(x, int), 'int!'))) == repr
    assert get_repr_function(3.14, ((lambda x: isinstance(x, int), 'int!'), (float, 'float!'))) == 'float!'
    assert get_repr_function(1, ((lambda x: isinstance(x, int), 'int!'), (float, 'float!'))) == 'int!'

# Generated at 2022-06-10 21:51:31.166980
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeFile(object):
        def write(self, s):
            self.written = s

    fake_file = FakeFile()
    WritableStream.register(FakeFile)
    assert issubclass(FakeFile, WritableStream)
    fake_file.write(1)
    assert fake_file.written == 1



# Generated at 2022-06-10 21:51:35.602875
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Making a dummy class
    class Dummy(WritableStream):
        def write(self, s):
            pass

    # Making a dummy object
    dummy = Dummy()

    # Calling the method
    dummy.write('spam')



# Generated at 2022-06-10 21:51:45.179770
# Unit test for function get_repr_function
def test_get_repr_function():
    assert callable(get_repr_function('a string', custom_repr=(())))
    assert get_repr_function('a string', custom_repr=((int, str),)) == str
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function([1], custom_repr=((int, str),)) == repr
    def halve(x):
        return x // 2
    assert get_repr_function(2, custom_repr=((lambda x: x == 2, halve),)) == halve



# Generated at 2022-06-10 21:51:53.568149
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(C): pass

# Generated at 2022-06-10 21:52:06.625217
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello world') == "'hello world'"
    assert get_shortish_repr(['hello world']) == "['hello world']"
    assert get_shortish_repr(['hello', 'world']) == "['hello', 'world']"
    assert (get_shortish_repr(['hello world'] * 100000,
                              max_length=100) ==
            "['hello world', 'hello world', ..., 'hello world']")

# Generated at 2022-06-10 21:52:14.603071
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    try:
        class MyWritableStream2(WritableStream):
            pass
    except TypeError:
        pass
    else:
        raise Exception("This should have raised a TypeError.")

    try:
        class MyWritableStream3(WritableStream):
            def write(self, s, t):
                pass
    except TypeError:
        pass
    else:
        raise Exception("This should have raised a TypeError.")



# Generated at 2022-06-10 21:52:17.215097
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Stub:
        def write(self, s):
            pass
    assert WritableStream.__subclasshook__(Stub)



# Generated at 2022-06-10 21:52:25.707952
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        pass
    assert not isinstance(A, WritableStream)
    class B(WritableStream):
        def write(self, s):
            pass
    assert isinstance(B, WritableStream)
    class C(WritableStream):
        def write(self, s):
            pass
        def write_whatever(self, s):
            pass
    assert not isinstance(C, WritableStream)
    class D(B):
        def write_whatever(self, s):
            pass
    assert isinstance(D, WritableStream)




# Generated at 2022-06-10 21:52:34.487684
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(object(), max_length=7) == 'object()'
    assert get_shortish_repr(object(), max_length=6) == 'objec...'
    assert get_shortish_repr(object(), max_length=1) == '...'
    assert get_shortish_repr(object(), max_length=None) == 'object()'
    assert get_shortish_repr(object(), max_length=6,
                             normalize=True) == 'object()'
    assert get_shortish_repr(object(), max_length=6,
                             normalize=True) == 'object()'
    assert get_shortish_repr(object(), max_length=1,
                             normalize=True) == '...'
    assert get_shortish_re

# Generated at 2022-06-10 21:52:40.288774
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(()) == '()'
    assert get_shortish_repr([]) == '[]'
    assert get_shortish_repr({}) == '{}'
    assert get_shortish_repr('') == "''"
    assert get_shortish_repr(u'') == "u''"

    assert get_shortish_repr('a') == "'a'"
    assert get_shortish_repr(u'a') == "u'a'"
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr(u'abc') == "u'abc'"
    assert get_shortish_repr('abcde') == "'abcde'"

# Generated at 2022-06-10 21:52:46.406350
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, custom_repr=((int, str),)) == str
    assert get_repr_function(None, custom_repr=((int, str),)) == repr
    assert get_repr_function(4.5) == repr
    assert get_repr_function(4.5, custom_repr=((int, str),)) == repr


if __name__ == '__main__':
    test_get_repr_function()

# Generated at 2022-06-10 21:52:55.494457
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import pytest
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abc', max_length=3) == "'abc'"
    assert get_shortish_repr('abc', max_length=4) == "'abc'"
    assert get_shortish_repr('abc', max_length=5) == "'abc'"
    assert get_shortish_repr('abc', max_length=2) == "'a..'"
    assert get_shortish_repr('abc', max_length=1) == "'.'"
    assert get_shortish_repr('abc', max_length=0) == ''
    assert get_shortish_

# Generated at 2022-06-10 21:53:01.636685
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStream1(object):
        def write(self, s):
            assert isinstance(s, str)
    assert isinstance(WritableStream1(), WritableStream)
    class WritableStream2(object):
        def NOTwrite(self, s):
            assert isinstance(s, str)
    assert not isinstance(WritableStream2(), WritableStream)



# Generated at 2022-06-10 21:53:04.444274
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    t = get_shortish_repr
    assert t(3.14159265, normalize=True) == '3.14159265'



# Generated at 2022-06-10 21:53:17.767855
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamTest(WritableStream):
        def write(self, s):
            assert type(s) is str
    assert issubclass(WritableStreamTest, WritableStream)



# Generated at 2022-06-10 21:53:30.400377
# Unit test for function get_repr_function
def test_get_repr_function():
    # Simple usage
    assert get_repr_function(1, ((int, str), str)) == str
    assert get_repr_function(1, ((float, str), str)) == str
    assert get_repr_function(object(), ((int, str), str)) == str
    assert get_repr_function(object(), ((str, str), str)) == str
    assert get_repr_function(1, ((object, str), str)) == str

    # Complex usage
    assert get_repr_function(1,
                             ((object, str),
                              (int, lambda x: '%s_' % x))) == '1_'
    assert get_repr_function(1,
                             ((object, str),
                              (float, lambda x: '%s_' % x))) == str

    # Test

# Generated at 2022-06-10 21:53:35.638073
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    def write(s):
        print(s)

    class TestClass:
        pass

    assert issubclass(TestClass, WritableStream)
    TestClass.write = write
    test_instance = TestClass()
    assert isinstance(test_instance, WritableStream)
    test_instance.write('hello!')



# Generated at 2022-06-10 21:53:41.935291
# Unit test for function get_repr_function
def test_get_repr_function():
    class CustomClass(object):
        pass
    custom_instance = CustomClass()
    generic_instance = object()
    repr_functions = [
        (lambda x: isinstance(x, type(custom_instance)), lambda x: 'custom'),
        (lambda x: isinstance(x, type(generic_instance)), lambda x: 'generic'),
        (lambda x: True, lambda x: 'fail')
    ]
    assert get_repr_function(custom_instance, repr_functions)() == 'custom'
    assert get_repr_function(generic_instance, repr_functions)() == 'generic'
    assert get_repr_function(None, repr_functions)() == 'fail'

# Generated at 2022-06-10 21:53:48.276148
# Unit test for function get_repr_function
def test_get_repr_function():
    # Test that get_repr_function returns the relevant repr
    # Test that when a custom repr is defined for the item, it returns
    # the custom repr
    assert get_repr_function(4, [(int, str)])('4') == '4'
    assert get_repr_function(4.5, [(int, str)])('4.5') == '4.5'
    assert get_repr_function((2, 3), [(int, str)])('(2, 3)') == '(2, 3)'
    assert get_repr_function('abc', [(int, str)])('abc') == 'abc'
    assert get_repr_function(int, [(int, str)])('int') == 'int'

# Generated at 2022-06-10 21:53:58.058664
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class FakeFile(WritableStream):
        def write(self, s):
            if s == 'b':
                raise IOError('')
            elif s == 'c':
                raise ValueError('')
            else:
                self._written = s

    FakeFile().write('a')

    try:
        FakeFile().write('b')
    except IOError:
        pass # Good
    else:
        raise AssertionError("IOError wasn't raised.")

    try:
        FakeFile().write('c')
    except ValueError:
        pass # Good
    else:
        raise AssertionError("ValueError wasn't raised.")


# Unit tests for shitcode

# Generated at 2022-06-10 21:54:10.841555
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io

    class FakeWritableStream(WritableStream):
        def write(self, s):
            if not isinstance(s, (str, bytes)):
                raise ValueError('You must pass a `str` or `bytes`: ' +
                                 str(s))

    FakeWritableStream().write(b'foo')
    FakeWritableStream().write('foo')

    class FakeUnicodeWritableStream(WritableStream):
        def write(self, s):
            if not isinstance(s, str):
                raise ValueError('You must pass a `str`: ' + str(s))

    FakeUnicodeWritableStream().write('foo')


# Generated at 2022-06-10 21:54:19.873335
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr(5, max_length=4) == '5'
    assert get_shortish_repr(5, max_length=3) == '5'
    assert get_shortish_repr(5, max_length=2) == '5'
    assert get_shortish_repr(5, max_length=1) == '5'
    assert get_shortish_repr(5, max_length=0) == '...'
    assert get_shortish_repr('5'*500, max_length=10) == '5'*5 + '...' + '5'*4



# Generated at 2022-06-10 21:54:24.644677
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=5) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'he...'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=2) == "'h...'"
    assert get_shortish_repr('hello', max_length=1) == '"h..."'

# Generated at 2022-06-10 21:54:35.948156
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import sys
    import types

    def test_function(x):
        return get_shortish_repr(x, custom_repr=((int, hex),
                                                  (types.CodeType,
                                               lambda x: '<code object foo>')))

    assert test_function(5) == '5'
    assert test_function(None) == 'None'
    assert test_function(object()) == 'object()'
    assert test_function(object) == 'object'
    assert test_function(type) == 'type'
    assert test_function([1, 2, 3]) == '[1, 2, 3]'
    assert test_function((1, 2, 3)) == '(1, 2, 3)'
    assert test_function({}) == '{}'

# Generated at 2022-06-10 21:55:09.480734
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (lambda x: str(x).startswith('2'),
                                 lambda x: 'the number two')) == repr
    assert get_repr_function(2, (lambda x: str(x).startswith('2'),
                                 lambda x: 'the number two')) == (
        lambda x: 'the number two')
