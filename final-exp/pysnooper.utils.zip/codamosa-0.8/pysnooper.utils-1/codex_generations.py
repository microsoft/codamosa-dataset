

# Generated at 2022-06-10 21:45:27.698132
# Unit test for function get_repr_function
def test_get_repr_function():
    import pandas as pd
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(object): pass
    a = A()
    b = B()
    c = C()
    d = D()
    df = pd.DataFrame()
    selectors = [
        lambda x: isinstance(x, A),
        pd.DataFrame,
        A
    ]
    repr_functions = [
        repr,
        id,
        repr
    ]
    for selector, repr_function in zip(selectors, repr_functions):
        assert \
            get_repr_function(a, custom_repr=((selector, repr_function),)) \
            is repr_function

# Generated at 2022-06-10 21:45:31.881624
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """
    Trying to create a subclass of `WritableStream` that doesn't implement
    `write` raises `TypeError`.
    """
    class A(WritableStream): pass

    with pytest.raises(TypeError):
        A()

# Generated at 2022-06-10 21:45:35.434459
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(TestWritableStream, WritableStream)

# Generated at 2022-06-10 21:45:45.911256
# Unit test for function get_repr_function
def test_get_repr_function():

    ###########################################################################
    #### Test using types #####################################################
    ###########################################################################

    import collections

    assert get_repr_function(None) == repr
    assert get_repr_function(True) == repr
    assert get_repr_function(1) == repr
    assert get_repr_function('a') == repr
    assert get_repr_function(['x', 'y', 'z']) == repr
    assert get_repr_function((1, 2, 3)) == repr


# Generated at 2022-06-10 21:45:56.345839
# Unit test for function get_repr_function
def test_get_repr_function():
    def default_repr(x):
        return 'default_repr({})'.format(x)

    def custom_repr(x):
        return 'custom_repr({})'.format(x)

    def custom_repr_1(x):
        return 'custom_repr_1({})'.format(x)

    assert get_repr_function('gum', custom_repr=((str, custom_repr),))(
        'gum') == 'custom_repr(gum)'

    assert get_repr_function(2, custom_repr=((str, custom_repr),))(
        'gum') == 'custom_repr(gum)'

    assert get_repr_function(2, custom_repr=((str, custom_repr),))(2) == '2'



# Generated at 2022-06-10 21:46:01.046193
# Unit test for function get_repr_function
def test_get_repr_function():
    assert callable(get_repr_function(4, []))
    assert callable(get_repr_function(4, [(int, str)]))
    assert callable(get_repr_lambda(4, [(lambda x: False, str)]))
    assert (
        get_repr_lambda(4, [(int, str), (lambda x: False, str)]) is str
    )

# Generated at 2022-06-10 21:46:12.096058
# Unit test for function get_repr_function
def test_get_repr_function():

    class Foo(object):
        pass

    class Foo2(Foo):
        pass

    class Bar(object):
        pass

    from pprint import pprint   # `pprint` is more readable than `repr`.

    print(get_repr_function(0, []))
    print(get_repr_function(0, [int, lambda x: pprint(x)]))
    print(get_repr_function(0, [int, lambda x: pprint(x)],
                            [Foo, 'not executed']))
    print(get_repr_function(0, [int, lambda x: pprint(x)],
                            [Foo, 'not executed'],
                            [Foo, 'the function executed']))

# Generated at 2022-06-10 21:46:16.323991
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('חוקר') == '?????'
    assert shitcode('helloחוקר') == 'hello?????'



# Generated at 2022-06-10 21:46:26.034173
# Unit test for function shitcode
def test_shitcode():

    def test(s, expected_shitty_code):
        if shitcode(s) != expected_shitty_code:
            raise AssertionError(
                'Expected {!r} to be shitcoded to {!r}, but it was shitcoded '
                'to {!r}.'.format(s, expected_shitty_code, shitcode(s))
            )

    test('hello there', 'hello there')
    test('hello\nthere', 'hello?there')
    test('יוד הא יוד הא', '? ? ? ? ? ?')
    test(u'\x01\x02\x03\x04\x05\x06', '??????')
    test(chr(1) + chr(2) + chr(3), '???')



# Generated at 2022-06-10 21:46:35.558068
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo(object):
        pass

    class Bar(Foo):
        pass

    class Baz(object):
        pass

    assert get_repr_function(Foo(), [(int, 'int_repr')]) is repr
    assert get_repr_function(Foo(), [(Foo, 'foo_repr')]) is 'foo_repr'
    assert get_repr_function(Bar(), [(Foo, 'foo_repr')]) is 'foo_repr'
    assert get_repr_function(Foo(), [(Bar, 'bar_repr')]) is repr
    assert get_repr_function(Baz(), [(Foo, 'foo_repr')]) is repr



# Generated at 2022-06-10 21:46:50.094020
# Unit test for function get_repr_function
def test_get_repr_function():
    from .function_tools import forward_to
    def test_type(value):
        return 'type'

    def test_type2(value):
        return 'type2'

    def test_value_type(value):
        return 'type {0}'.format(type(value).__name__)

    def test_value(value):
        return 'value'

    assert get_repr_function(1, ((int, test_type),)) == test_type
    assert get_repr_function(1, ((int, test_type), (int, test_type2))) == test_type
    assert get_repr_function(int, ((int, test_type), (int, test_type2))) == test_type


# Generated at 2022-06-10 21:47:00.434022
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    from .python_repr import PR


    assert get_shortish_repr(123, normalize=True) == \
                                                normalize_repr(PR(123)) == '123'

    assert get_shortish_repr(123, custom_repr=(
        (lambda x: True, lambda x: u'hi'),
    ), normalize=True) == 'hi'

    assert get_shortish_repr([123], custom_repr=(
        (lambda x: True, lambda x: u'hi'),
    )) == 'hi'

    assert get_shortish_repr([123], custom_repr=(
        (lambda x: False, lambda x: u'hi'),
        (lambda x: True, lambda x: u'ok'),
    )) == 'ok'


    assert get_shortish_repr

# Generated at 2022-06-10 21:47:05.760259
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class GoodClass(WritableStream):
        def write(self, s):
            pass

    class BadClass(WritableStream):
        pass

    assert issubclass(GoodClass, WritableStream)
    assert not issubclass(BadClass, WritableStream)

test_WritableStream_write()

# Generated at 2022-06-10 21:47:13.512627
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream): pass
    assert not issubclass(MyStream, WritableStream)
    class MyStream(WritableStream):
        def write(self, s): pass
    assert issubclass(MyStream, WritableStream)
    class MyStream(MyStream): pass
    assert issubclass(MyStream, WritableStream)
    class MyStream(MyStream):
        def write(self, s): return s
    assert issubclass(MyStream, WritableStream)
    ms = MyStream()
    assert ms.write('meow') == 'meow'

# Generated at 2022-06-10 21:47:22.069198
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, x):
            pass
    assert WritableStream.register(A)

    class B(WritableStream):
        def write(self, x):
            pass
        def write_twice(self, x):
            pass
    assert WritableStream.register(B)

    class C(WritableStream):
        def write_twice(self, x):
            pass
    assert not WritableStream.register(C)



# Generated at 2022-06-10 21:47:32.433202
# Unit test for function get_repr_function
def test_get_repr_function():
    class A:
        pass

    assert get_repr_function(A(), []) is repr
    assert get_repr_function(A(), [(A, id)]) is id
    assert get_repr_function(A(), [(A, id)]) is id
    assert get_repr_function(A(), [(A, id), (int, 123)]) is id
    assert get_repr_function(A(), [(int, 123), (A, id)]) is id
    assert get_repr_function(A(), [
        (int, 123),
        (A, id),
        (lambda x: isinstance(x, A), lambda x: 'is a A')
    ]) == 'is a A'

# Generated at 2022-06-10 21:47:40.469511
# Unit test for function get_repr_function
def test_get_repr_function():
    my_repr = lambda x: f'Hello {x}!'
    assert get_repr_function(7, []) is repr
    assert get_repr_function(7, [(lambda x: x == 7, my_repr)]) is my_repr
    assert get_repr_function(7.0, [(float, my_repr)]) is my_repr
    assert get_repr_function(7.0, [(int, my_repr)]) is repr



# Generated at 2022-06-10 21:47:47.572163
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, ()) == repr
    assert get_repr_function(5, ((int, lambda i: 'int'),)) == (lambda i: 'int')
    assert get_repr_function(5.2, ((int, lambda i: 'int'),)) == repr
    assert get_repr_function(5.2,
                             ((lambda x: isinstance(x, int),
                               lambda i: 'int'),)) == repr



# Generated at 2022-06-10 21:47:57.291187
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class X:
        def __repr__(self):
            return 'yo'
    assert get_shortish_repr(X(), ()) == 'yo'
    assert get_shortish_repr(X(), (), max_length=2) == 'yo'
    assert get_shortish_repr(X(), (), 1) == 'y'
    assert get_shortish_repr(X(), (), 2) == 'yo'
    assert get_shortish_repr(X(), (), 3) == 'yo'
    assert get_shortish_repr(X(), (), 4) == 'yo'
    assert get_shortish_repr(X(), (
        (lambda x: True, lambda x: 'zoo'),
    )) == 'zoo'

# Generated at 2022-06-10 21:48:02.004611
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritable(WritableStream):
        def write(self, s):
            pass
    if not issubclass(MyWritable, WritableStream):
        assert False, '`issubclass(MyWritable, WritableStream)` returned '\
                      '`False`.'



# Generated at 2022-06-10 21:48:16.499394
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A:
        def __repr__(self):
            return 'A'
    a = A()

    assert get_shortish_repr(a, max_length=2) == 'A'
    assert get_shortish_repr(a, max_length=3) == 'A'
    assert get_shortish_repr(a, max_length=4) == 'A'
    assert get_shortish_repr(a, max_length=5) == 'A'

    assert get_shortish_repr(a, max_length=None) == 'A'

    # Test that it truncates the repr
    assert get_shortish_repr(a, max_length=1) == '...'

    # Test that it doesn't truncate if the repr is already short enough
    assert get_shortish_

# Generated at 2022-06-10 21:48:29.365111
# Unit test for function get_repr_function
def test_get_repr_function():

    import types
    assert get_repr_function(None, ()) is repr
    assert get_repr_function(object(), ()) is repr
    assert get_repr_function(type, ()) is repr
    assert get_repr_function(Exception, ()) is repr

    assert get_repr_function(None, [(lambda x: isinstance(x, type),
                                     lambda x: 'CUSTOM')]) is repr
    assert get_repr_function(Exception(), [(lambda x: isinstance(x, type),
                                            lambda x: 'CUSTOM')]) is repr
    assert get_repr_function(Exception, [(lambda x: isinstance(x, type),
                                          lambda x: 'CUSTOM')]) == 'CUSTOM'


# Generated at 2022-06-10 21:48:36.614597
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    class MyWritableStream(WritableStream):
        def write(self, s):
            self.s = s

    a = io.StringIO()
    b = MyWritableStream()
    assert issubclass(a.__class__, WritableStream)
    assert issubclass(b.__class__, WritableStream)
    a.write('abc')
    b.write('abc')
    assert a.getvalue() == 'abc'
    assert b.s == 'abc'



# Generated at 2022-06-10 21:48:45.478858
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test regular cases
    class MyWritable(WritableStream):
        def write(self, text):
            if not isinstance(text, str):
                raise TypeError("The `text` must be a string.")
            self.text = text

    my_writable = MyWritable()
    my_writable.write('meow')

    # Test an error case
    class MyWritable(WritableStream):
        def write(self, text):
            raise ValueError('Blah')

    my_writable = MyWritable()
    with pytest.raises(ValueError):
        my_writable.write('meow')

    # Test the wrong type
    class MyWritable:
        def write(self, text):
            pass

    my_writable = MyWritable()

# Generated at 2022-06-10 21:48:56.250663
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert get_shortish_repr((1, 2, 3)) == '(1, 2, 3)'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(12345, max_length=4) == '...'
    assert get_shortish_repr(12345, max_length=5) == '...5'

# Generated at 2022-06-10 21:49:02.555596
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def __init__(self):
            self.written = []

        def write(self, s):
            self.written.append(s)

    my_stream = MyStream()
    my_stream.write(b'a')
    my_stream.write(b'b')
    assert my_stream.written == [b'a', b'b']



# Generated at 2022-06-10 21:49:06.441093
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .test_tools import assert_equal
    from .pycompat import sys_exc_info

    class X(WritableStream):
        def write(self, s):
            return s

    x = X()
    assert_equal(x.write('abc'), 'abc')



# Generated at 2022-06-10 21:49:07.965930
# Unit test for function shitcode
def test_shitcode():
    string = shitcode('אאאא')
    assert string == '????'

# Generated at 2022-06-10 21:49:17.698042
# Unit test for function get_repr_function
def test_get_repr_function():
    def repr_string(x):
        return repr(x) + '_string'

    def repr_int(x):
        return repr(x) + '_int'

    assert get_repr_function('a', [(str, repr_string), (int, repr_int)]) \
                                                                  == repr_string
    assert get_repr_function(1, [(str, repr_string), (int, repr_int)]) \
                                                                   == repr_int
    assert get_repr_function(None, []) == repr
    assert get_repr_function(None, [(type(None), lambda x: 'is_none')]) \
                                                                   == 'is_none'
    assert get_repr_function('a', [(str, None)]) == repr

# Generated at 2022-06-10 21:49:28.438323
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(6, ()) is repr
    assert get_repr_function(6, ((lambda x: True, str),)) is str
    assert get_repr_function(6, ((lambda x: False, str),)) is repr
    assert get_repr_function('meow', ((lambda x: True, str),)) is str
    assert get_repr_function('meow', ((lambda x: False, str),)) is repr
    assert get_repr_function('meow', ((str, str),)) is str
    assert get_repr_function('meow', ((int, str),)) is repr
    assert get_repr_function(6, ((int, str),)) is str

# Generated at 2022-06-10 21:49:46.518082
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(u'\u2603') == u'\\u2603'
    assert get_shortish_repr(u'\u2603', max_length=8) == u'\\u2603'
    assert get_shortish_repr(u'\u2603', max_length=7) == u'\\u2603'
    assert get_shortish_repr(u'\u2603', max_length=6) == u'\\u2603'
    assert get_shortish_repr(u'\u2603', max_length=5) == u'\\u2603'
    assert get_shortish_repr(u'\u2603', max_length=4) == u'\\u2603'

# Generated at 2022-06-10 21:49:52.660482
# Unit test for function get_repr_function

# Generated at 2022-06-10 21:50:00.443147
# Unit test for function get_repr_function
def test_get_repr_function():
    
    def repr_function1(item):
        if isinstance(item, int):
            return 'int!'
        if isinstance(item, str):
            return 'str!'
        return repr(item)
    
    def repr_function2(item):
        if isinstance(item, str):
            return 'str!'
        raise RuntimeError

    assert get_repr_function(1, ()) is repr
    assert get_repr_function('1', ()) is repr

    assert get_repr_function(1, ((int, repr_function1),)) is repr_function1
    assert get_repr_function('1', ((int, repr_function1),)) is repr_function1

    assert get_repr_function(1, ((str, repr_function2),)) is repr

# Generated at 2022-06-10 21:50:12.075098
# Unit test for function get_repr_function
def test_get_repr_function():
    # this is the function we are going to test

    oo = object()
    assert get_repr_function(1, [(int, str)]) == str

    assert get_repr_function(1, [(int, str),
                                 (int, lambda x: 'aaaaa')]) == str

    assert get_repr_function(1, [(int, str),
                                 (int, lambda x: 'a' * 1000)]) == str

    assert get_repr_function(1, [(int, str),
                                 (float, lambda x: 'aaaaa')]) == str

    assert get_repr_function(1.0, [(int, str),
                                   (float, lambda x: 'aaaaa')]) == 'aaaaa'


# Generated at 2022-06-10 21:50:14.837069
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('A') == 'A'
    assert shitcode('ß') == '?'
    assert shitcode('A\u1234B') == 'A?B'

# Generated at 2022-06-10 21:50:19.223821
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyWritableStream(object):
        def write(self, *args, **kwargs):
            pass
    assert issubclass(DummyWritableStream, WritableStream)



# Generated at 2022-06-10 21:50:26.070228
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    sys.stdout = io.BytesIO()
    with open(__file__, 'r') as f:
        import proofread.prettyprint
        proofread.prettyprint.get_shortish_repr(f)
        sys.stdout.write('method write of class WritableStream works')


if __name__ == '__main__':
    test_WritableStream_write()

# Generated at 2022-06-10 21:50:28.800466
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X:
        def write(self, s):
            pass
    assert issubclass(X, WritableStream)



# Generated at 2022-06-10 21:50:38.294180
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'

    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'


# Generated at 2022-06-10 21:50:46.832209
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo: pass
    class Bar: pass
    class Baz: pass
    foo = Foo()
    bar = Bar()
    baz = Baz()
    custom_reprs = [
        (lambda x: isinstance(x, Foo), lambda x: 'foo'),
        (Bar, lambda x: 'bar'),
    ]
    assert get_repr_function(foo, custom_reprs) is foo.__repr__
    assert get_repr_function(bar, custom_reprs) is bar.__repr__
    assert get_repr_function(baz, custom_reprs) is baz.__repr__



# Generated at 2022-06-10 21:51:04.643241
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyWritableStream(WritableStream):
        def __init__(self):
            self.write_calls = []

        def write(self, s):
            self.write_calls.append(s)

    dummy_writable_stream = DummyWritableStream()
    dummy_writable_stream.write('foo')
    assert dummy_writable_stream.write_calls == ['foo']
    dummy_writable_stream.write('bar')
    assert dummy_writable_stream.write_calls == ['foo', 'bar']

    # Making sure that the `write` method is required for the class to be a
    # subclass of WritableStream:
    class Dummy(object): pass
    dummy = Dummy()
    assert issubclass(DummyWritableStream, WritableStream)
    assert not iss

# Generated at 2022-06-10 21:51:12.556096
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .data_structures import FrozenDict

    d = {'a': 1, 'b': 2}
    data_structures_repr = (
        (Dict, lambda x: 'Dict with {} elements.'.format(len(x))),
        (
            FrozenDict,
            lambda x: 'FrozenDict with {} elements.'.format(len(x))
        ),
    )
    assert get_shortish_repr(d, custom_repr=data_structures_repr) == 'Dict with 2 elements.'
    assert get_shortish_repr(FrozenDict(d),
                             custom_repr=data_structures_repr) == 'FrozenDict with 2 elements.'


# Generated at 2022-06-10 21:51:24.597287
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=10) == '1'
    assert get_shortish_repr(6, max_length=10) == '6'
    assert get_shortish_repr('qwerasdf', max_length=10) == 'qwerasdf'
    assert get_shortish_repr('qwerasdf', max_length=9) == 'qwerasdf'
    assert get_shortish_repr('qwerasdf', max_length=8) == 'qwer...'
    assert get_shortish_repr('qwerasdf', max_length=7) == 'qwe...'
    assert get_shortish_repr('qwerasdf', max_length=6) == 'qw...'

# Generated at 2022-06-10 21:51:31.877122
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyFakeFile(WritableStream):
        def write(self, s):
            assert isinstance(s, string_types)
    my_fake_file = MyFakeFile()
    my_fake_file.write('hi')
    my_fake_file.write(u'hi')
    my_fake_file.write(b'hi')
    sys.stdout.write(b'hi')



# Generated at 2022-06-10 21:51:37.786854
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X:
        pass

    assert WritableStream.__subclasshook__(X) is NotImplemented
    X.write = None
    assert WritableStream.__subclasshook__(X) is NotImplemented
    X.write = object()
    assert WritableStream.__subclasshook__(X) is True



# Generated at 2022-06-10 21:51:49.602433
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(list, max_length=30) == 'list'
    assert get_shortish_repr(list, max_length=4) == 'list'
    assert get_shortish_repr(list, max_length=3) == 'lis'
    assert get_shortish_repr(list, max_length=2) == 'li'
    assert get_shortish_repr(list, max_length=1) == 'l'
    assert get_shortish_repr(list, max_length=0) == ''
    assert get_shortish_repr('abc', max_length=3) == "'ab'"
    assert get_shortish_repr('abc', max_length=5) == "'abc'"

# Generated at 2022-06-10 21:52:01.245026
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, custom_repr=((lambda x: x is None, id),)) == \
                                                                               id
    assert get_repr_function(None, custom_repr=((lambda x: x is not None,
                                                 str),)) == repr
    assert get_repr_function(None, custom_repr=((None, id),)) == id
    assert get_repr_function(None, custom_repr=((1, id),)) == repr
    assert get_repr_function(None, custom_repr=(('foo', id),)) == repr
    assert get_repr_function(None, custom_repr=((1.5, id),)) == repr
    assert get_repr_function(None, custom_repr=(((1,), id),)) == repr

# Generated at 2022-06-10 21:52:03.823616
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, _):
            pass

    MyWritableStream()




# Generated at 2022-06-10 21:52:14.766566
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(3, max_length=5) == '3'
    assert get_shortish_repr('hello', max_length=5) == 'hello'
    assert get_shortish_repr([1,2,3], max_length=5) == '[1, 2]'
    assert get_shortish_repr([1,2,3], max_length=6) == '[1, 2]'
    assert get_shortish_repr([1,2,3], max_length=7) == '[1, 2, 3]'
    assert get_shortish_repr([1,2,3], max_length=8) == '[1, 2, 3]'
    assert get_shortish_repr([1,2,3], max_length=9) == '[1, 2, 3]'

# Generated at 2022-06-10 21:52:21.627180
# Unit test for function get_repr_function
def test_get_repr_function():
    from pytest import raises
    custom_repr = (
        (lambda x: isinstance(x, int), lambda x: 'i%d' % x),
        (lambda x: x > 3, lambda x: '>3'),
        (lambda x: x < -3, lambda x: '<-3'),
        (lambda x: isinstance(x, float), lambda x: 'f%.3f' % x),
        (lambda x: isinstance(x, str), lambda x: '"%s"' % x),
    )

# Generated at 2022-06-10 21:52:44.194334
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr

    assert get_repr_function(1, []) == repr

    assert get_repr_function(1, [((), str)]) == str

    assert get_repr_function(1, [(lambda x: x == 1, str)]) == str

    assert get_repr_function(1, [(1, str)]) == str

    assert get_repr_function(1, [((1,), str)]) == str

    assert get_repr_function(1, [((1), str)]) == str

    assert get_repr_function(1, [([1], str)]) == repr

    assert get_repr_function(1, [(lambda x: False, str)]) == repr


# Generated at 2022-06-10 21:52:53.317413
# Unit test for function get_repr_function
def test_get_repr_function():
    from .python_toolbox import misc_tools

    assert u"<function str_repr_function at" in get_repr_function(
        1,
        (
            (lambda x: True, misc_tools.str_repr_function),
        )
    ).__repr__()
    assert u"<function repr_function at" in get_repr_function(
        1,
        (
            (lambda x: True, misc_tools.repr_function),
        )
    ).__repr__()
    assert get_repr_function(
        1,
        (
            (lambda x: False, misc_tools.str_repr_function),
        )
    ) is repr


# Generated at 2022-06-10 21:52:58.927876
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        assert issubclass(WritableStream, ABC)
        def write(self, s):
            pass
    assert issubclass(Foo, WritableStream)

    class Bar:
        assert issubclass(WritableStream, ABC)
        def write(self, s):
            pass
        def __init__(self):
            self.write = None
    assert not issubclass(Bar, WritableStream)

    class Baz:
        assert issubclass(WritableStream, ABC)
        def write(self, s):
            pass
        def __init__(self):
            del self.write
    assert not issubclass(Baz, WritableStream)

# Generated at 2022-06-10 21:53:03.265530
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'hello') == 'hello'
    assert shitcode('\x14\xFF') == '??'
    assert shitcode(u'\u201Cwell\u201D') == '?"well?"'



# Generated at 2022-06-10 21:53:09.583184
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(A): pass


# Generated at 2022-06-10 21:53:17.645374
# Unit test for function get_repr_function
def test_get_repr_function():

    class MyException(Exception):
        pass

    assert get_repr_function(ValueError, custom_repr=()) is repr

    assert get_repr_function(
        ValueError,
        custom_repr=((ValueError, str),)
    ) is str

    def my_repr(s):
        return '<{}>'.format(s)

    assert get_repr_function(
        ValueError,
        custom_repr=((ValueError, my_repr),)
    ) is my_repr

    assert get_repr_function(
        ValueError(),
        custom_repr=((ValueError, my_repr),)
    ) is my_repr


# Generated at 2022-06-10 21:53:30.308778
# Unit test for function get_repr_function
def test_get_repr_function():
    from .python_toolbox import caching
    class A(object): pass
    a = A()
    def __repr_A(a):
        return 'A'
    def __repr_B(a):
        return 'B'
    def __repr_C(a):
        return 'C'
    custom_repr = [
        (lambda a: isinstance(a, A), __repr_A),
        (B,                     __repr_B),
    ]
    assert get_repr_function(a, custom_repr) == __repr_A
    class B(object): pass
    b = B()
    assert get_repr_function(b, custom_repr) == __repr_B
    class C(A): pass
    c = C()
    assert get_repr_function

# Generated at 2022-06-10 21:53:33.640736
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('\x0Fuck you') == '?Fuck you'
    assert shitcode('\u1234\u4321') == '????'





# Generated at 2022-06-10 21:53:34.892588
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    s = io.StringIO()
    assert isinstance(s, WritableStream)
    s.write('hmmm')
    assert s.getvalue() == 'hmmm'



# Generated at 2022-06-10 21:53:37.507692
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        def __init__(self):
            self.string = ''

        def write(self, s):
            self.string += s

    assert isinstance(Foo(), WritableStream)



# Generated at 2022-06-10 21:54:06.577299
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyFile(WritableStream):
        def __init__(self):
            self.written_data = ''
        def write(self, s):
            self.written_data += s
            return len(s)
    d = MyFile()
    d.write(b'abc def')
    assert d.written_data == 'abc def'
    d.write('abcd')
    assert d.written_data == 'abc defabcd'



# Generated at 2022-06-10 21:54:13.615824
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, ()) == repr
    assert get_repr_function(5, ((lambda x: x, 'yo'),)) == repr
    assert get_repr_function(6, ((lambda x: x, 'yo'),)) == 'yo'
    assert get_repr_function(5, ((int, 'yo'),)) == 'yo'
    assert get_repr_function(5.0, ((int, 'yo'),)) == repr



# Generated at 2022-06-10 21:54:16.155891
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Test(object):
        def write(self, s): pass
    assert WritableStream.__subclasshook__(Test) == True

# Generated at 2022-06-10 21:54:23.901771
# Unit test for function get_repr_function
def test_get_repr_function():
    class Thingy: pass
    class AnotherThingy(Thingy): pass
    assert get_repr_function(1, {}) is repr
    assert get_repr_function(Thingy(), {}) is repr
    assert get_repr_function(Thingy(), {get_repr_function: 'foobar'}) == 'foobar'
    assert get_repr_function(AnotherThingy(), {Thingy: 'foobar'}) == 'foobar'
    assert get_repr_function(AnotherThingy(), {int: 'foobar'}) is repr
    assert get_repr_function([1, 2, 3],
                             [
                                 (lambda x: isinstance(x, list), str),
                                 (lambda x: isinstance(x, dict), str),
                             ]) == str


# Generated at 2022-06-10 21:54:34.083368
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, repr),)) is repr
    def f(x):
        return 'f(%s)' % x
    assert get_repr_function(1, ((int, f),)) is f
    assert get_repr_function(1, ((lambda x: x == 1, f),)) is f
    def g(x):
        return 'g(%s)' % x
    def h(x):
        return 'h(%s)' % x
    assert get_repr_function(1, ((int, g), (lambda x: x == 1, h))) is h

# Generated at 2022-06-10 21:54:48.352281
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    """`get_shortish_repr` must work the way we want it to."""
    class TestClass(object): pass
    test_class_instance = TestClass()
    custom_repr_classes = (bytes, bytearray, memoryview, TestClass)

# Generated at 2022-06-10 21:55:01.407757
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    custom_repr = []

    class MyInt(int):
        pass

    class MyList(list):
        pass

    class MyDict(dict):
        pass

    custom_repr = [
        (MyInt, lambda x: 'MyInt({})'.format(int(x))),
        (MyList, lambda x: 'MyList({})'.format(
            ','.join(get_shortish_repr(item) for item in x)
        )),
        (MyDict, lambda x: 'MyDict({})'.format(
            ','.join(get_shortish_repr(key) + ':' +
                     get_shortish_repr(value)
                     for key, value in x.items())
        )),
    ]

    # Basic

# Generated at 2022-06-10 21:55:07.909205
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class DummyWritableStream(WritableStream):
        def write(self, s):
            pass

    ws = DummyWritableStream()
    class FakeType:
        def write(self, s):
            pass
    assert issubclass(DummyWritableStream, WritableStream)
    assert issubclass(FakeType, WritableStream)

    assert isinstance(ws, WritableStream)
    assert not isinstance(5, WritableStream)
    assert not isinstance('afsd', WritableStream)

    # Make sure that abstractmethod doesn't interfere with this
    # machinery:
    class AbstractMysteryWritableStream(WritableStream):
        @abc.abstractmethod
        def write(self, s):
            pass

    assert issubclass(AbstractMysteryWritableStream, WritableStream)
    assert not isinstance