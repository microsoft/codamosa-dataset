

# Generated at 2022-06-10 21:45:19.819897
# Unit test for function get_repr_function
def test_get_repr_function():

    r = get_repr_function(123, [])
    assert r == repr

    r = get_repr_function(123, [(int, lambda x: x * 2)])
    assert r(123) == '246'

    class Foo: pass
    r = get_repr_function(Foo(), [(type(Foo()), lambda x: 'foo')])
    assert r(Foo()) == 'foo'

    r = get_repr_function(123, [(Foo, lambda x: x * 2)])
    assert r(123) == 123

    bad_custom_repr = [(Foo, lambda x: x * 2, lambda x: x * 3)]
    try:
        r = get_repr_function(123, bad_custom_repr)
    except TypeError:
        pass

# Generated at 2022-06-10 21:45:22.447991
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamForTest(WritableStream):
        pass
    assert issubclass(WritableStreamForTest, WritableStream)



# Generated at 2022-06-10 21:45:32.290307
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert (get_shortish_repr('') == "''")
    assert (get_shortish_repr('hello\nworld') == r"'hello\\nworld'")
    assert (get_shortish_repr(u'hello', max_length=5) == u"u'hell\u2026'")
    assert (get_shortish_repr(u'hello' * 100, max_length=5) == u"u'hell\u2026'")
    assert (get_shortish_repr([0, 1, 2, 3], max_length=7) == r'[0, 1, \u2026]')



# Generated at 2022-06-10 21:45:36.612058
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X: pass
    x = X()
    assert not isinstance(x, WritableStream)
    x.write = lambda x: x
    assert isinstance(x, WritableStream)

    y = X()
    assert not isinstance(y, WritableStream)
    y.write = None
    assert not isinstance(y, WritableStream)

# Generated at 2022-06-10 21:45:43.997553
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import StringIO
    class MyWritableStream(WritableStream):
        def __init__(self):
            self._s = ''
        def write(self, s):
            self._s += s

    mws = MyWritableStream()
    mws.write('abc')
    mws.write('def')
    assert mws._s == 'abcdef'

    sio = StringIO()
    assert isinstance(sio, WritableStream)

# Generated at 2022-06-10 21:45:54.487516
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: x > 0, lambda x: 'positive')]) == \
                                                               repr
    assert get_repr_function(2, [(lambda x: x > 0, lambda x: 'positive')]) == \
                                                  (lambda x: 'positive')
    assert get_repr_function(2, []) == repr
    assert get_repr_function(2, [(lambda x: x > 0, None)]) == repr
    assert get_repr_function(2, [(lambda x: x > 0, lambda x: 'positive'),
                                 (lambda x: x < 0, lambda x: 'negative')]) == \
                                                  (lambda x: 'positive')

# Generated at 2022-06-10 21:46:01.758863
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            assert isinstance(s, str)
    class B(WritableStream):
        def write(self, s):
            assert isinstance(s, bytes)
    class C(WritableStream):
        def write(self, s):
            assert False
    class D(WritableStream):
        pass
    class E(WritableStream):
        def write(self, s): # This method is declared but doesn't exist
            raise NotImplementedError
    assert WritableStream.__subclasshook__(A) is True
    assert WritableStream.__subclasshook__(B) is True
    assert WritableStream.__subclasshook__(C) is NotImplemented
    assert WritableStream.__subclasshook__(D) is NotImplemented


# Generated at 2022-06-10 21:46:08.988795
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import pytest

    class WritableStream1(WritableStream):
        def write(self, s):
            pass

    class WritableStream2(WritableStream):
        def write(self, s):
            pass

    class NotWritableStream:
        pass


    assert issubclass(WritableStream1, WritableStream)
    assert issubclass(WritableStream2, WritableStream)
    assert not issubclass(NotWritableStream, WritableStream)



# Generated at 2022-06-10 21:46:23.005820
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .colorama_tools import Colorizer
    from .testing import assert_equal

    c = Colorizer()

    assert_equal(
        get_shortish_repr('abc', custom_repr=(),
                          max_length=6, normalize=False),
        'abc'
    )
    assert_equal(
        get_shortish_repr('abc', custom_repr=(),
                          max_length=5, normalize=False),
        'abc'
    )
    assert_equal(
        get_shortish_repr('abc', custom_repr=(),
                          max_length=4, normalize=False),
        '...'
    )

# Generated at 2022-06-10 21:46:33.765229
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr

    assert get_repr_function(1, [(int, str)]) == str

    assert get_repr_function(1, [(2, 3)]) == repr

    def sum(a, b):
        return a + b
    assert get_repr_function(sum, [(int, str), (lambda x: x is sum, str)]) == str

    assert get_repr_function(1, []) == repr

    class objectWithCustomRepr(object):
        def __repr__(self):
            return "custom __repr__ !"
    assert get_repr_function(objectWithCustomRepr(), [(int, str)]) == str

# Generated at 2022-06-10 21:46:47.535864
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    s = 'x' * 1000
    assert get_shortish_repr(s) == truncate(s, 200)
    assert get_shortish_repr(s, max_length=10) == truncate(s, 10)
    assert get_shortish_repr(s, max_length=1000) == truncate(s, 1000)
    assert get_shortish_repr(5, max_length=5) == '5'
    assert get_shortish_repr(5, max_length=500) == '5'
    assert get_shortish_repr(5, max_length=0) == '...'

# Generated at 2022-06-10 21:46:50.774714
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, ((int, lambda x: 'i'),)) == 'i'
    assert get_repr_function(None, ((int, lambda x: 'i'),)) == repr



# Generated at 2022-06-10 21:47:00.106276
# Unit test for function get_repr_function
def test_get_repr_function():
    repr_function = get_repr_function(5, [
        (lambda n: n > 4, lambda n: 'big'),
        (lambda n: n % 2, lambda n: 'odd'),
        (int, lambda n: 'int'),
        (lambda n: n % 2 == 0, lambda n: 'even'),
        (object, lambda n: 'object'),
    ])
    assert repr_function(5) == 'big'
    assert repr_function(4) == 'even'
    assert repr_function(3) == 'odd'
    assert repr_function(2) == 'even'
    assert repr_function(1) == 'odd'
    assert repr_function(0) == 'int'




# Generated at 2022-06-10 21:47:04.677914
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'ABC') == u'ABC'
    assert shitcode(u'ABC\u2122') == u'ABC?'
    assert shitcode(u'ABC\u2122DEF\u9999') == u'ABC?DEF?'




# Generated at 2022-06-10 21:47:11.145953
# Unit test for function get_repr_function
def test_get_repr_function():

    def my_repr(x):
        return 'my_repr'

    assert get_repr_function(0, [(int, my_repr)]) is my_repr
    assert get_repr_function(0.1, [(int, my_repr)]) is repr
    assert get_repr_function(0, [(lambda x:True, my_repr)]) is my_repr



# Generated at 2022-06-10 21:47:14.467679
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('פדאאאאאאאאאאאאאאאאאאאאאאאאאאא') == \
           '??????'
    assert shitcode(u'\ud800\udc00\ud800') == u'??\ud800'



# Generated at 2022-06-10 21:47:25.391350
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo:
        pass
    foo = Foo()
    assert get_repr_function(foo, [(Foo, str)]) == str
    assert get_repr_function(foo, [(Foo, lambda x: 'bar')]) == 'bar'
    assert normalize_repr('hello at 0x1eed') == 'hello'
    assert normalize_repr('hello at 0x10efa') == 'hello'
    assert normalize_repr('hello') == 'hello'
    assert truncate('hello', 2) == 'he...'
    assert truncate('hello', 4) == 'he...'
    assert truncate('hello', 10) == 'hello'




# Generated at 2022-06-10 21:47:28.070899
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def write(self, string):
            return string * 2
    assert Foo().write('hello') == 'hellohello'
    
    

# Generated at 2022-06-10 21:47:30.358017
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class A(WritableStream):
        def write(self, s): pass

    assert issubclass(A, WritableStream)

# Generated at 2022-06-10 21:47:37.848264
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, (lambda x: isinstance(x, str),
                                 lambda x: ''.join(reversed(x)),
                                 (int, lambda x: x**2))) == repr


# Generated at 2022-06-10 21:47:52.346146
# Unit test for function get_repr_function
def test_get_repr_function():
    c = get_repr_function(False, [(lambda x: x, str), (True, lambda x: 1)])
    assert c('a') == 'a'
    assert c(True) == 1
    assert c(False) == 'False'
    assert c(None) == 'None'
    assert c(u"\u05d0") == u"\u05d0"

    assert get_repr_function(False, [(int, lambda _: 'int')])(False) \
                                                                == 'False'
    assert get_repr_function(False, [(int, lambda _: 'int')])(5) == '5'

    assert get_repr_function(False) == repr
    assert get_repr_function(False, [(int, lambda _: 'int')]) != repr


# Unit

# Generated at 2022-06-10 21:47:57.517391
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('a') == 'a'
    assert shitcode('a'*1000) == 'a'*1000
    assert shitcode('אאאאאאאאאאאאאאאאאאאאאאאאאאאאאאא'
                    'אאאאאאאאאאאאאאאאאאאאאאאאאאאאאאאא') == (
        '?' * 1000
    )

# Generated at 2022-06-10 21:48:08.762000
# Unit test for function get_repr_function
def test_get_repr_function():
    class AClass(object):
        pass
    def custom_repr(x):
        return 'custom repr'
    a_dict = {'a': 1, 'b': 2}
    assert get_repr_function(object(), []) == repr
    assert get_repr_function(AClass(), []) == repr
    assert get_repr_function(AClass(), [(AClass, custom_repr)]) == custom_repr
    assert get_repr_function(AClass(), [(AClass, custom_repr)]) == custom_repr
    assert get_repr_function(AClass(), [((AClass, object), custom_repr)]) == \
                                                             custom_repr
    assert get_repr_function(a_dict, [(AClass, custom_repr)]) == repr

# Generated at 2022-06-10 21:48:11.166663
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class A(WritableStream):
        def write(self, s):
            pass
    assert A()

# Generated at 2022-06-10 21:48:22.257545
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestSubclass(WritableStream):
        def __init__(self):
            self.output = ''
        def write(self, s):
            self.output += s
    TestSubclass()


    class TestSubSubclass(TestSubclass):
        def __init__(self, f):
            self.f = f
        def write(self, s):
            self.f.write(s)

    TestSubSubclass(open(__file__, 'rb'))

    class BrokenTestSubclass(TestSubclass):
        pass
    assert not issubclass(BrokenTestSubclass, WritableStream)

    class BrokenTestSubSubclass(TestSubSubclass):
        pass
    assert not issubclass(BrokenTestSubSubclass, WritableStream)


# Generated at 2022-06-10 21:48:32.386357
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('1234567890') == '1234567890'
    assert get_shortish_repr('1234567890', max_length=10) == '1234567890'
    assert get_shortish_repr('1234567890', max_length=9) == '1234567...'
    assert get_shortish_repr('1234567890', max_length=8) == '12345...'
    assert get_shortish_repr('1234567890', max_length=7) == '1234...'
    assert get_shortish_repr('1234567890', max_length=6) == '123...'
    assert get_shortish_repr('1234567890', max_length=5) == '12...'
    assert get_shortish_re

# Generated at 2022-06-10 21:48:42.602131
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class A:
        def __repr__(self):
            return 'Hi there'

    def first_repr_function(x):
        return 'first function says: %s' % x

    def second_repr_function(x):
        return 'second function says: %s' % x

    a = A()

    assert 'Hi there' == get_shortish_repr(a)


    assert 'first function says: ...' == \
           get_shortish_repr(a,
                             custom_repr=((type(a), first_repr_function),))

    assert 'second function says: ...' == \
           get_shortish_repr(a,
                             custom_repr=((type(a), second_repr_function),))



# Generated at 2022-06-10 21:48:45.222959
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\x00hello\x01\x0f') == '??hello???'


# Unit tests for function get_shortish_repr

# Generated at 2022-06-10 21:48:53.504045
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) is repr
    assert get_repr_function(None, ((lambda x: False, None))) is repr
    assert get_repr_function(None, ((lambda x: True, None))) is None
    assert get_repr_function(None, ((lambda x: True, str))) is str

    assert get_repr_function(None, ((int, None))) is repr
    assert get_repr_function(None, ((int, str))) is str



# Generated at 2022-06-10 21:48:55.113980
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    with open('test.txt', 'w') as f:
        assert isinstance(f, WritableStream)



# Generated at 2022-06-10 21:49:08.786460
# Unit test for function get_repr_function
def test_get_repr_function():
    import itertools, textwrap, io
    from . import my_repr, safe_repr
    from . import io_tools


# Generated at 2022-06-10 21:49:18.323444
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(object): pass
    get_repr_function(A(), (
        (B, lambda x: 'B'),
        (lambda x: isinstance(x, C), lambda x: 'C')
    ))
    assert get_repr_function(A(), (
        (B, lambda x: 'B'),
        (lambda x: isinstance(x, C), lambda x: 'C')
    )) is repr

# Generated at 2022-06-10 21:49:20.691000
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(MyWritableStream(), WritableStream)



# Generated at 2022-06-10 21:49:23.479840
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

# Generated at 2022-06-10 21:49:25.782160
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('', [(str, str)]) == str
    assert get_repr_function('', []) == repr



# Generated at 2022-06-10 21:49:34.688880
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from random import choice
    from string import ascii_letters, digits
    for _ in range(20):
        length = choice(range(0, 1000))
        string = ''.join(choice(ascii_letters + digits)
                                                          for _ in range(length))
        assert (truncate(string, length) == string)
        if length:
            assert (truncate(string, length-1) == string[:-1] + '...')
            assert (truncate(string, 3) == '...')
            assert (truncate(string, 2) == '..')
            assert (truncate(string, 1) == '.')
            assert (truncate(string, 0) == '')


if __name__ == '__main__':
    test_get_shortish_repr()

# Generated at 2022-06-10 21:49:45.577627
# Unit test for function get_repr_function
def test_get_repr_function():
    item = "a"
    assert get_repr_function(item, [(str, lambda x: "hi")]) == "hi"
    assert get_repr_function(item, [(str, lambda x: "hi"),
                                    (int, lambda x: "ho")]) == "hi"
    assert get_repr_function(item, [(int, lambda x: "ho"),
                                    (str, lambda x: "hi")]) == "hi"
    assert get_repr_function(item, [(tuple, lambda x: "ar")]) == repr
    assert get_repr_function(item, [(int, lambda x: "ar")]) == repr
    assert get_repr_function(item, [(int, lambda x: "ar")]) == repr

# Generated at 2022-06-10 21:49:47.980317
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(DummyWritableStream, WritableStream)

# Generated at 2022-06-10 21:49:51.144601
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import _py_abc
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert _py_abc.abstractmethod(MyWritableStream.write) == False

# Generated at 2022-06-10 21:49:59.613190
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('a', None) == repr
    assert get_repr_function(b'a', None) == repr
    assert get_repr_function(1, None) == repr

    def condition(x): return isinstance(x, int)
    def action(x): return str(x + 1)
    assert get_repr_function('a', ((condition, action),)) == repr
    assert get_repr_function(b'a', ((condition, action),)) == repr
    assert get_repr_function(1, ((condition, action),)) == action
    assert get_repr_function(2, ((condition, action),)) == action

    assert get_repr_function('a', ((str, action),)) == repr

# Generated at 2022-06-10 21:50:12.553869
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo(object): pass
    class Bar(Foo): pass

    assert get_repr_function(None, ()) is repr
    assert get_repr_function(Foo(), ((type(Foo), id),)) is id

    assert get_repr_function(Foo(), ((type(Foo), id),
                                     (type(Bar), id))) is id

    assert get_repr_function(Bar(), ((type(Foo), id),
                                     (type(Bar), id))) is id

    assert get_repr_function(Bar(), ((type(Foo), id),)) is repr
    assert get_repr_function(Bar(), ((Foo, id),)) is repr

# Generated at 2022-06-10 21:50:16.708939
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MissingInit(WritableStream):
        def write(self, s):
            pass

    def write(self, s):
        pass
    class MissingWrite(WritableStream): pass
    class MissingWrite: pass
    assert issubclass(MissingInit, WritableStream)
    assert issubclass(MissingWrite, WritableStream) is False

# Generated at 2022-06-10 21:50:25.666200
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object):
        pass
    class B(A):
        pass
 
    assert get_repr_function(None, custom_repr=((object, lambda x: 'Ha!'),)) == repr
    assert get_repr_function(A(), custom_repr=((object, lambda x: 'Ha!'),)) == repr
    assert get_repr_function(A(), custom_repr=((A, lambda x: 'Ha!'),)) == repr
    assert get_repr_function(B(), custom_repr=((A, lambda x: 'Ha!'),)) == 'Ha!'



# Generated at 2022-06-10 21:50:28.863214
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import io3
    assert issubclass(io.StringIO, io3.WritableStream)
    assert issubclass(io.BytesIO, io3.WritableStream)

# Generated at 2022-06-10 21:50:38.322666
# Unit test for function get_repr_function
def test_get_repr_function():
    assert repr(1) == get_repr_function(1, [])()
    assert repr(1) == get_repr_function(1, [])()
    assert '1' == get_repr_function(1, [])()
    assert '1' == get_repr_function(1, [((lambda x: True), (lambda x: '1'))])()
    assert '1' == get_repr_function(1, [((lambda x: True), (lambda x: '1'))])()
    assert '2' == get_repr_function(2, [((lambda x: True), (lambda x: '1'))])()
    assert '1' == get_repr_function(1, [((lambda x: False), (lambda x: '1'))])()
    assert '2' == get_

# Generated at 2022-06-10 21:50:47.811841
# Unit test for function get_repr_function
def test_get_repr_function():
    def is_one_or_two(x):
        return x in (1, 2)
    def is_one(x):
        return x == 1
    def is_square(x):
        return x ** 0.5 ** 2 == x
    def is_even(x):
        return x % 2 == 0
    custom_repr = [
        (is_one, lambda x: 'one'),
        (is_one_or_two, lambda x: 'one or two'),
        (lambda x: x in (3, 4), lambda x: 'three or four'),
        (is_square, lambda x: 'square'),
        (is_even, lambda x: 'even'),
    ]
    def test(x, *expected_results):
        result = get_repr_function(x, custom_repr)
        assert result

# Generated at 2022-06-10 21:50:50.905641
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Example(WritableStream):
        def write(self, s):
            assert isinstance(s, str)
            sys.stdout.write(s)
    Example().write('hi')
    
    
    
    

# Generated at 2022-06-10 21:51:03.411861
# Unit test for function get_repr_function
def test_get_repr_function():

    def my_repr(x):
        return repr(x.__class__.__name__)

    x = 5

    assert get_repr_function(x, ()) is repr

    assert get_repr_function(x,
                             [(lambda x: True, lambda x: 'zoo ' + repr(x))]) == \
                             'zoo 5'

    assert get_repr_function(x, [(int, my_repr)]) == my_repr(x)

    assert get_repr_function(x, ((int,), my_repr)) == my_repr(x)

    assert get_repr_function(x, [(lambda x: False, my_repr)]) == repr(x)


# Generated at 2022-06-10 21:51:12.058064
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(u'א', max_length=5) == u'א'
    assert get_shortish_repr(u'א' * 30, max_length=5) == u'...'
    assert (get_shortish_repr(u'א' * 30, max_length=8) ==
                                                u'...\u05d0\u05d0\u05d0\u05d0')
    assert (get_shortish_repr(u'א' * 30, max_length=9) ==
                                                u'...\u05d0\u05d0\u05d0\u05d0')

# Generated at 2022-06-10 21:51:23.653260
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('abc', ()) is repr
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1.0, ()) is repr

    assert get_repr_function('abc', (
        (str, lambda x: 'lala'),
    )) == 'lala'

    assert get_repr_function(1, (
        (int, lambda x: 'lala'),
    )) == 'lala'

    assert get_repr_function(1.0, (
        (int, lambda x: 'lala'),
    )) is repr

    assert get_repr_function(1, (
        (float, lambda x: 'lala'),
    )) is repr


# Generated at 2022-06-10 21:51:39.813368
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, ()) is repr

    def my_repr(x):
        return 'my represention'

    assert get_repr_function(0, ((lambda x: True, my_repr),)) is my_repr

    assert get_repr_function(0, ((int, my_repr),)) is my_repr

    assert get_repr_function(1.0, ((int, my_repr),)) is repr

    assert get_repr_function(
        1.0, ((int, my_repr),
              (float, my_repr))
    ) is my_repr

# Generated at 2022-06-10 21:51:50.856648
# Unit test for function get_repr_function
def test_get_repr_function():
    class Object(object):
        pass

    class OtherObject(object):
        pass

    def repr_function_1(x):
        return '{} * {}'.format(x, x)

    def repr_function_2(x):
        return '{} ^ {}'.format(x, x)

    x = Object()
    assert get_repr_function(x, ((Object(), repr_function_1),)) is \
                          repr_function_1
    assert get_repr_function(x, ((OtherObject(), repr_function_2),)) is \
                           repr
    assert \
        get_repr_function(x, ((lambda y: isinstance(y, Object),
                               repr_function_2),)) is repr_function_2

    y = OtherObject()

# Generated at 2022-06-10 21:51:56.805381
# Unit test for method write of class WritableStream
def test_WritableStream_write(): # todo: test
    class Testee(WritableStream):
        def write(self, s):
            return s

    assert Testee().write('hi') == 'hi'

    class NotWritable(object):
        pass

    assert not issubclass(NotWritable, WritableStream)

    class Testee(WritableStream):
        pass

    assert issubclass(Testee, WritableStream)

    class Testee(WritableStream):
        def write(self, s):
            pass

    assert issubclass(Testee, WritableStream)



# Generated at 2022-06-10 21:52:03.793836
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        pass
    assert not issubclass(A, WritableStream)

    class B:
        def write(self, s):
            pass
    assert not issubclass(B, WritableStream)

    class C:
        def write(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(B, C):
        pass
    assert not issubclass(D, WritableStream)



# Generated at 2022-06-10 21:52:08.243055
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(WritableStream):
        write_called = False
        def write(self, s):
            self.write_called = True
    x = X()
    x.write('nadav')
    assert x.write_called




# Generated at 2022-06-10 21:52:14.288428
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert (
        get_shortish_repr(
            [1, 2, 3],
            max_length=10,
            custom_repr=[(list, lambda l: 'list')],
            normalize=True
        ) == 'list'
    )

    assert (
        get_shortish_repr(
            [1, 2, 3],
            max_length=1,
            custom_repr=[(list, lambda l: 'list')],
            normalize=True
        ) == 'l...'
    )

    assert (
        get_shortish_repr(
            [1, 2, 3],
            max_length=30,
            custom_repr=[(list, lambda l: 'list')],
            normalize=True
        ) == 'list'
    )



# Generated at 2022-06-10 21:52:17.824004
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (lambda x: isinstance(x, str), str)) == repr
    assert get_repr_function('1', (lambda x: isinstance(x, str), str)) == str

# Generated at 2022-06-10 21:52:29.076379
# Unit test for function get_repr_function
def test_get_repr_function():
    def repr_of_bad_car(bad_car):
        return 'Looks like a bad car but actually it is a good one.'

    custom_repr = (
        ((lambda x: isinstance(x, str) and x.startswith('bad')), repr_of_bad_car),
        (lambda x: x == 17, lambda x: 'seventeen'),
        ((int, float), str),
        ((list, tuple), lambda x: 'list: ' + repr(x))
    )

    class BadCar(object):
        def __repr__(self):
            return 'bad car'

    assert get_repr_function('bad', custom_repr) is repr_of_bad_car
    assert get_repr_function('bad as hell', custom_repr) is repr_of_bad_car

# Generated at 2022-06-10 21:52:35.479179
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    assert isinstance(io.StringIO(), WritableStream)
    assert isinstance(io.BytesIO(), WritableStream)
    assert not isinstance([], WritableStream)

    class MyWritableStream(WritableStream):
        pass
    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream2(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream2, WritableStream)

    class MyWritableStream3(WritableStream):
        def foo(self, s):
            pass
    assert not issubclass(MyWritableStream3, WritableStream)

# Generated at 2022-06-10 21:52:44.439281
# Unit test for function get_repr_function
def test_get_repr_function():

    def f(x):
        return x + 1

    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [])(1) == '1'
    assert get_repr_function(2, [(lambda x: x == 1, f)]) == repr
    assert get_repr_function(2, [(lambda x: x == 1, f)])(1) == '1'
    assert get_repr_function(3, [(int, f)]) == f
    assert get_repr_function(3, [(int, f)])(1) == 2




# Unit tests for truncate

# Generated at 2022-06-10 21:52:57.617826
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestClass(object):
        def write(self, s):
            pass
        pass
    assert issubclass(TestClass, WritableStream)

# Generated at 2022-06-10 21:53:03.372839
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io

    class WritableStreamTest(WritableStream):
        def write(self, s):
            pass

    assert isinstance(io.StringIO(), WritableStream)
    assert isinstance(io.TextIOWrapper(io.BytesIO()), WritableStream)
    assert isinstance(WritableStreamTest(), WritableStream)


# Generated at 2022-06-10 21:53:11.133119
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr("a" * 100) == 'a' * 100
    assert get_shortish_repr("a" * 100, max_length=None) == 'a' * 100
    assert get_shortish_repr("a" * 100, max_length=5) == 'aaaaa...aaaaa'
    assert get_shortish_repr("a" * 101, max_length=101) == 'a' * 101
    assert get_shortish_repr("a" * 101, max_length=100) == 'aaaaa...aaaaa'



# Generated at 2022-06-10 21:53:12.530165
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # We can write to `sys.stderr`:
    assert isinstance(sys.stderr, WritableStream)

# Generated at 2022-06-10 21:53:15.527710
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .implementation import StreamImplementation
    assert issubclass(StreamImplementation, WritableStream)
    my_stream = StreamImplementation()
    my_stream.write('This is a test')
    assert my_stream.output == 'This is a test'



# Generated at 2022-06-10 21:53:19.954276
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyFile(WritableStream):
        def write(self, s):
            return '{}-written'.format(s)

    dummy_file = DummyFile()
    assert dummy_file.write('foo') == 'foo-written'



# Generated at 2022-06-10 21:53:30.818861
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class StringWriter(WritableStream):
        def __init__(self, target_string):
            self.target_string = target_string
        def write(self, s):
            assert isinstance(s, str)
            self.target_string += s

    target_string = 'xxx'

    writer = StringWriter(target_string)

    original_string = 'hey there'
    expected_string = 'xxxhey there'
    writer.write(original_string)
    assert target_string == expected_string

    original_string = 'I am the very model'
    expected_string = 'xxxhey thereI am the very model'
    writer.write(original_string)
    assert target_string == expected_string



# Generated at 2022-06-10 21:53:39.991792
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr('abc') == 'abc'
    assert len(get_shortish_repr('abcde'*1000, max_length=10)) == 10
    assert get_shortish_repr('abc', max_length=2) == 'ab'
    assert get_shortish_repr(None, max_length=2) == 'No'

    class C(object):
        def __repr__(self):
            return 'abc[def'
    assert get_shortish_repr(C(), max_length=7) == 'abc'

    class C2(object):
        def __repr__(self):
            return 'abc\ndef'
    C2_repr = get_shortish_repr(C2(), max_length=7)

# Generated at 2022-06-10 21:53:51.720445
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass

    def f(x): return x

    assert get_repr_function(42, []) == repr
    assert get_repr_function(42, [(lambda x: False, f)]) == repr
    assert get_repr_function(42, [(lambda x: True, f)]) == f

    assert get_repr_function(A(), [(lambda x: False, f)]) == repr
    assert get_repr_function(A(), [(lambda x: True, f)]) == f

    assert get_repr_function(B(), [(lambda x: False, f)]) == repr
    assert get_repr_function(B(), [(lambda x: True, f)]) == f

    assert get_repr_function(B(), [(A, f)]) == f

# Generated at 2022-06-10 21:53:59.045351
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    try:
        import queue
    except ImportError:
        import Queue as queue

    class WriteEater(WritableStream):

        def __init__(self):
            self.queue = queue.Queue()

        def write(self, s):
            self.queue.put(s)

    write_eater = WriteEater()
    assert WriteEater.__subclasshook__(WriteEater)
    write_eater.write('yo')
    assert write_eater.queue.get() == 'yo'



# Generated at 2022-06-10 21:54:25.822938
# Unit test for function get_repr_function
def test_get_repr_function():

    class A:
        pass

    class B:
        pass

    class C:
        pass

    def dummy_repr(x):
        return u'Dummy repr'

    assert get_repr_function(A(), custom_repr=[(A, dummy_repr)]) == dummy_repr
    assert get_repr_function(B(), custom_repr=[(A, dummy_repr)]) != dummy_repr
    assert repr(str(C())) == get_repr_function(C(), custom_repr=[(A, dummy_repr)])
    assert repr(str(C())) == get_repr_function(C(), custom_repr=[(B, dummy_repr)])

# Generated at 2022-06-10 21:54:33.124941
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FileLike:
        def write(self, s):
            pass

    class StringIOLike:
        def write(self, s):
            if not isinstance(s, str):
                return NotImplemented

    assert isinstance(sys.stdout, WritableStream)
    assert isinstance(sys.stderr, WritableStream)
    assert isinstance(FileLike, WritableStream)
    assert not isinstance(StringIOLike, WritableStream)

# Generated at 2022-06-10 21:54:37.446504
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestStream(WritableStream):
        def write(self, s):
            pass
    assert isinstance(TestStream(), WritableStream)
    assert issubclass(TestStream, WritableStream)

# Generated at 2022-06-10 21:54:50.182106
# Unit test for function get_repr_function
def test_get_repr_function():

    class Foo: pass
    class Bar: pass

    def foo_repr(foo):
        return 'Foo, wah-ha-ha'

    def bar_repr(bar):
        return 'Bar, ooo-oo-oo'

    assert get_repr_function(Foo(), [(Foo, foo_repr)]) is foo_repr
    assert get_repr_function(Bar(), [(Foo, foo_repr)]) is repr
    assert get_repr_function(Foo(), [(object, foo_repr)]) is foo_repr
    assert get_repr_function(Bar(), [(object, bar_repr)]) is bar_repr

    assert get_repr_function(Foo(), [(Foo, None)]) is repr

# Generated at 2022-06-10 21:55:01.772738
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s): pass

    assert issubclass(A, WritableStream)
    assert not issubclass(int, WritableStream)
    assert not issubclass(list, WritableStream)
    assert not issubclass(str, WritableStream)

    class B(WritableStream):
        def write(self, *s): pass

    assert not issubclass(B, WritableStream)
    class C(WritableStream):
        pass

    assert issubclass(C, WritableStream)
    class D(WritableStream):
        def write(self, s):
            return s

    assert issubclass(D, WritableStream)



# Generated at 2022-06-10 21:55:07.987781
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello', max_length=None) == 'hello'
    assert get_shortish_repr('hello', max_length=5) == 'hello'
    assert get_shortish_repr('hello', max_length=4) == 'he...'
    assert get_shortish_repr('hello', max_length=3) == '...'
    assert get_shortish_repr('hello', max_length=3) == '...'
    assert get_shortish_repr('hello', max_length=2) == '..'
    assert get_shortish_repr('hello', max_length=1) == '.'
    assert get_shortish_repr('hello', max_length=0) == ''
