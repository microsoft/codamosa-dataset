

# Generated at 2022-06-10 21:45:20.871376
# Unit test for function get_repr_function
def test_get_repr_function():
    x = lambda x: None

    assert get_repr_function(None, custom_repr=(
        (lambda x, y=x: x is y, x),
        (lambda x, y=x: x is y, x),
        (lambda x, y=x: x is y, x)
    )) is x
    assert get_repr_function(None, custom_repr=(
        (lambda x, y=x: x is y, x),
        (lambda x, y=x: x is y, x),
        (lambda x, y=x: x is y, x)
    )) is x

# Generated at 2022-06-10 21:45:32.764566
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello there') == "'hello there'"
    assert get_shortish_repr('hello there  ') == "'hello there  '"
    assert get_shortish_repr('hello', max_length=3) == "'hel'"
    assert get_shortish_repr('hello there', max_length=14) == "'hello there'"
    assert get_shortish_repr('hello', max_length=5) == "'hello'"
    assert get_shortish_repr('hello there', max_length=10) == "'hello...'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_

# Generated at 2022-06-10 21:45:44.033063
# Unit test for function get_repr_function
def test_get_repr_function():
    def banana_repr(b):
        return 'banana'
    def peach_repr(p):
        return 'peach'

    assert get_repr_function(42, (
        (int, lambda x: str(x) + ' not int'),
    ))(42) == '42'

    assert get_repr_function(42, (
        (int, 'banana'),
    )) == 'banana'

    assert get_repr_function(42, (
        ((lambda n: n < 3), 'banana'),
    )) == 'banana'

    assert get_repr_function(42, (
        ((lambda n: n < 3), 'banana'),
        ((lambda n: n > 10), 'peach'),
    )) == 'banana'


# Generated at 2022-06-10 21:45:54.532538
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(20, ((int, str), (int, lambda _: 'twenty'))) == \
                                                                      str
    assert get_repr_function(20.0, ((int, str), (int, lambda _: 'twenty'))) == \
                                                                      repr
    assert get_repr_function(20, ((int, str), (int, lambda _: 'twenty'),
                                  (float, lambda x: '{:.2f}'.format(x)))) == \
                                                                      str

# Generated at 2022-06-10 21:45:58.581054
# Unit test for function get_repr_function
def test_get_repr_function():
    class Object(object):
        pass
    class MyClass:
        pass
    assert get_repr_function(Object(), ()).__name__ == '__repr__'
    assert get_repr_function(1, ()).__name__ == 'repr'
    assert get_repr_function(MyClass(), ((type,), str)).__name__ == 'str'



# Generated at 2022-06-10 21:46:00.381116
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyStream, WritableStream)

# Generated at 2022-06-10 21:46:03.422037
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc😸') == 'abc?😸'
    assert shitcode(u'abc😸') == 'abc?😸'



# Generated at 2022-06-10 21:46:14.043325
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    repr_failing_instance = type('ReprFailing', (), {'__repr__': lambda self: 1/0})()
    assert get_shortish_repr(repr_failing_instance) == 'REPR FAILED'
    assert get_shortish_repr('hi', max_length=2) == 'hi'
    assert get_shortish_repr('hi', max_length=3) == 'hi'
    assert get_shortish_repr('hi', max_length=4) == 'hi'
    assert get_shortish_repr('hi', max_length=5) == 'hi'
    assert get_shortish_repr('hi', max_length=6) == 'hi'
    assert get_shortish_repr('hi', max_length=7) == 'hi'

# Generated at 2022-06-10 21:46:17.409232
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Stream(WritableStream):
        def write(self, s):
            pass

    s = Stream()
    assert isinstance(s, WritableStream)
    # Just testing that `s` is, in fact, a WritableStream instance




# Generated at 2022-06-10 21:46:20.465238
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .testing import assert_equals
    
    class Foo(WritableStream):
        def __init__(self):
            self.s = ''

        def write(self, s):
            self.s += s

    foo = Foo()
    foo.write('abc')
    assert_equals(foo.s, 'abc')




# Generated at 2022-06-10 21:46:33.691389
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C(metaclass=ABCMeta):
        @abc.abstractmethod
        def write(self, s): pass
    c = C()
    assert not issubclass(c.__class__, WritableStream)
    assert not isinstance(c, WritableStream)
    class C(metaclass=ABCMeta):
        @abc.abstractmethod
        def write(self, s): pass
        @abc.abstractmethod
        def read(self, s): pass
    c = C()
    assert not issubclass(c.__class__, WritableStream)
    assert not isinstance(c, WritableStream)
    class C(metaclass=ABCMeta):
        @abc.abstractmethod
        def write(self, s): pass
        def read(self, s): pass
    c = C()
   

# Generated at 2022-06-10 21:46:40.044407
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo(object):
        pass
    foo = Foo()
    assert get_repr_function(foo, ()) is repr
    assert get_repr_function(foo, ((Foo, lambda x: 'bar'),)) == 'bar'
    assert get_repr_function(foo, ((Foo, None),)) is repr
    assert get_repr_function(foo, ((int, lambda x: 'bar'),)) is repr
    assert get_repr_function(foo, (lambda x: True, lambda x: 'bar')) == 'bar'
    assert get_repr_function(foo, (lambda x: False, lambda x: 'bar')) is repr
    assert get_repr_function(foo, (lambda x: False, None)) is repr


# Generated at 2022-06-10 21:46:51.051412
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class Foo:
        def __init__(self, x):
            self.x = x
        def __repr__(self):
            return self.x

    custom = (
        (str, lambda x: 'str'),
        (lambda x: isinstance(x, Foo) and x.x.startswith('*'),
         lambda x: 'good'),
        (lambda x: isinstance(x, Foo) and x.x.startswith('**'),
         lambda x: 'evil'),
    )

    assert get_shortish_repr('hello') == repr('hello')
    assert get_shortish_repr(Foo('hi')) == repr('hi')
    assert get_shortish_repr(Foo('*hi'), custom) == 'good'

# Generated at 2022-06-10 21:47:01.107831
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    def assert_get_shortish_repr(item, expected, extra_args=(),
                                 extra_kwargs=None):
        actual = get_shortish_repr(item, *extra_args, **(extra_kwargs or {}))
        assert actual == expected

    def assert_get_shortish_repr_raises(item, exception_type, extra_args=(),
                                        extra_kwargs=None):
        try:
            get_shortish_repr(item, *extra_args, **(extra_kwargs or {}))
        except exception_type:
            pass
        else:
            assert False, 'Did not raise'

    assert_get_shortish_repr('abc', "'abc'")

# Generated at 2022-06-10 21:47:12.715668
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Test default repr is untouched
    assert get_shortish_repr(42) == '42'
    # Test custom reprs do not truncate
    assert get_shortish_repr(42, custom_repr=[
        (type(42), lambda x: 'a' * 100),
    ]) == 'a' * 100
    # Test that defaults are truncated
    assert get_shortish_repr(42, max_length=10) == '42'
    assert get_shortish_repr('a' * 100, max_length=10) == 'a' * 10 + '...'
    assert get_shortish_repr(42, max_length=10, normalize=True) == '42'

# Generated at 2022-06-10 21:47:20.384006
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('normal string') == 'normal string'
    assert shitcode('\u05d4\u05d5\u05d6\u05d7') == '????'
    assert shitcode('B\xc4\x85cz\xc4\x85z') == 'B??z??z'
    assert shitcode('B\xc4\u05d4z\xc4\u05d5z') == 'B??z??z'

# Generated at 2022-06-10 21:47:24.215704
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            print('writing!')

    assert isinstance(WritableStreamSubclass(), WritableStream)



# Generated at 2022-06-10 21:47:26.759842
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WriteableObject(WritableStream):
        def write(self, s):
            pass

    assert issubclass(WriteableObject, WritableStream)

# Generated at 2022-06-10 21:47:29.141852
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io

    class MyFile(io.TextIOBase, WritableStream):
        def write(self, s):
            super(MyFile, self).write(s)

    f = MyFile()
    f.write('hi')

# Generated at 2022-06-10 21:47:40.284494
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    from .python_snippets import revert_decorator

    def ensure_repr(item, repr_str, repr_function=repr):
        r = get_shortish_repr(item, custom_repr=((None, repr_function),))
        assert r == repr_str

    class C:
        pass
    c = C()
    c.__repr__ = lambda: 'custom repr'
    ensure_repr(c, 'custom repr')

    class C(object):
        def __repr__(self):
            return 'custom repr'
    c = C()
    ensure_repr(c, 'custom repr')

    ensure_repr(int, 'int')
    ensure_repr(int, 'int', lambda x: str(x))


# Generated at 2022-06-10 21:47:54.380149
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is repr
    assert get_repr_function(1, ((int, str),
                                 (1, lambda: 'one'))) is repr
    assert get_repr_function(1, ((int, str),
                                 (1, lambda: 'one'),
                                 ('?', lambda: '?'))) is repr
    assert get_repr_function(1, ((int, str),
                                 (1, lambda: 'one'),
                                 ('?', lambda: '?'),
                                 (lambda x: x == 1, lambda: '1'))) is repr

# Generated at 2022-06-10 21:48:04.465134
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    s = '1234567890'
    assert get_shortish_repr(s) == s
    assert get_shortish_repr(s, max_length=4) == '1234'
    assert get_shortish_repr(s, max_length=5) == '12...'
    assert get_shortish_repr(s, max_length=6) == '123...'
    assert get_shortish_repr(s, max_length=7) == '1234...'
    assert get_shortish_repr(s, max_length=8) == '12345...'
    assert get_shortish_repr(s, max_length=9) == '1234567...'
    assert get_shortish_repr(s, max_length=10) == s



# Generated at 2022-06-10 21:48:09.400887
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStream2:
        write = None

    class WritableStream3(WritableStream):
        write = None
    assert not isinstance(WritableStream2(), WritableStream)
    assert not isinstance(WritableStream3(), WritableStream)



# Generated at 2022-06-10 21:48:18.608373
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    def f(x):
        return get_shortish_repr(x, max_length=10,
                                 custom_repr=(
                                     (lambda y: isinstance(y, list), lambda y: y),
                                     (lambda y: isinstance(y, str), shitcode),
                                 ))
    assert f('') == ''
    assert f('a' * 8) == 'a' * 8
    assert f('a' * 9) == 'a' * 9
    assert f('a' * 10) == 'a' * 10
    assert f('a' * 11) == 'a' * 8 + '...a' * 3
    assert f('a' * 100) == 'a' * 8 + '...a' * 3

# Generated at 2022-06-10 21:48:29.647525
# Unit test for function get_repr_function
def test_get_repr_function():
    def my_repr(x):
        assert type(x) is int
        return 'It\'s an int!'

    custom_repr = (
        (lambda x: isinstance(x, float), repr),
        (int, my_repr)
    )
    assert (get_repr_function(1, custom_repr)(1) ==
            get_shortish_repr(1, custom_repr))
    assert (get_repr_function(3.14, custom_repr)(3.14) ==
            get_shortish_repr(3.14, custom_repr))
    assert (get_repr_function(object(), custom_repr)(object()) ==
            get_shortish_repr(object(), custom_repr))



# Generated at 2022-06-10 21:48:36.672653
# Unit test for function get_repr_function
def test_get_repr_function():
    assert normalize_repr('fuu at 0x00012345678') == 'fuu'
    assert normalize_repr('fuu at 0xABCD') == 'fuu'
    assert normalize_repr('fuu') == 'fuu'
    assert normalize_repr('fuu at 0x234') == 'fuu'
    assert normalize_repr('fuu at 0x45678') == 'fuu'
    assert normalize_repr('fuu at 0xABCDEF') == 'fuu'
    assert normalize_repr('fuu at 0xABABABABAB') == 'fuu'
    assert normalize_repr('fuu at 0x012345678') == 'fuu'


# Generated at 2022-06-10 21:48:45.496121
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, tuple()) == repr
    assert get_repr_function(None, ((None, str),)) == str
    assert get_repr_function(1, ((None, str),)) == repr
    assert get_repr_function(1, ((lambda x: x % 2, str),)) == str
    assert get_repr_function(2, ((lambda x: x % 2, str),)) == repr
    assert get_repr_function((1, 2), ((tuple, str),)) == str
    assert get_repr_function([1, 2], ((list, str),)) == str
    assert get_repr_function((1, 2), ((tuple, str), (list, repr))) == repr

# Generated at 2022-06-10 21:48:56.250800
# Unit test for function get_repr_function
def test_get_repr_function():

    def repr_int(x):
        return str(x)

    def repr_float(x):
        return str(x + 0.4)

    repr_zero = repr_int

    custom_repr = ((int, repr_int), (float, repr_float), (0, repr_zero))

    for i in (1, 2, 0.0, 4.0, 7.9, 'a'):
        assert get_repr_function(i, custom_repr) == repr_int
    for i in (1.5, 1.0/0, 1.7e300, -87.6):
        assert get_repr_function(i, custom_repr) == repr_float
    assert get_repr_function(0, custom_repr) == repr_zero


# Generated at 2022-06-10 21:49:07.386094
# Unit test for function get_repr_function
def test_get_repr_function():
    class DummyClass: pass
    assert get_repr_function(DummyClass, (
        (lambda x: isinstance(x, DummyClass), lambda x: 'dummy'),
    ))(DummyClass()) == 'dummy'

    assert get_repr_function(None, (
        (lambda x: isinstance(x, DummyClass), lambda x: 'dummy'),
    ))(None) == 'None'

    assert get_repr_function(None, (
        (lambda x: isinstance(x, DummyClass), lambda x: 'dummy'),
        (lambda x: isinstance(x, int), lambda x: 'integer'),
    ))(None) == 'None'


# Generated at 2022-06-10 21:49:17.347398
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\x00\x01\x02♥') == '\x00\x01\x02?'
    assert shitcode(u'\x00\x01\x02♥') == '\x00\x01\x02?'

    assert shitcode('') == ''
    assert shitcode('abc') == 'abc'
    assert shitcode('abc♥') == 'abc?'
    assert shitcode('abc\x00') == 'abc\x00'
    assert shitcode('abc\x00♥') == 'abc\x00?'

    assert shitcode(u'') == ''
    assert shitcode(u'abc') == 'abc'
    assert shitcode(u'abc♥') == 'abc?'
    assert shitcode(u'abc\x00') == 'abc\x00'

# Generated at 2022-06-10 21:49:26.163760
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, ((lambda x: isinstance(x, (list, dict)), int))) == int
    assert get_repr_function(0, ((lambda x: isinstance(x, (list, dict)), lambda x: 'HELLO'))) == repr
    assert get_repr_function(0, ((None, lambda x: 'HELLO'))) == 'HELLO'



# Generated at 2022-06-10 21:49:34.996877
# Unit test for function get_repr_function
def test_get_repr_function():
    class Point:
        def __init__(self, x, y):
            self.x = x
            self.y = y

        def __repr__(self):
            return '<Point x={} y={}>'.format(self.x, self.y)

    x = 42
    p = Point(1, 2)
    m = {'x': Point(3, 4), 'y': [5, 6]}
    l = [7, p, m]
    print(get_shortish_repr(x, max_length=10))
    print(get_shortish_repr(p, max_length=10))
    print(get_shortish_repr(m, max_length=10, normalize=True))

# Generated at 2022-06-10 21:49:40.089404
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr((1, 2)) == '(1, 2)'
    assert get_shortish_repr([1, 2]) == '[1, 2]'
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr(b'hello') == "b'hello'"



# Generated at 2022-06-10 21:49:49.091838
# Unit test for function get_repr_function
def test_get_repr_function():
    assert repr(get_repr_function(1, [])) == '<function repr>'
    assert repr(get_repr_function(1, [(float, lambda x: 'a')])) == \
                                                              '<function <lambda>>'
    assert repr(get_repr_function(1.0, [(float, lambda x: 'a')])) == "u'a'"
    assert repr(get_repr_function(1.0, [1, (2, 3)])) == "u'a'"
    assert repr(get_repr_function(1.0, [(1, 2, 3)])) == "<function <lambda>>"

# Generated at 2022-06-10 21:49:52.131951
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ""
        def write(self, s):
            self.written_string += s

    writable_stream = MyWritableStream()
    writable_stream.write("hello")
    writable_stream.write(" there")
    assert writable_stream.written_string == "hello there"



# Generated at 2022-06-10 21:49:59.092122
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    # The first use-case is testing exceptions.
    class NondefaultException(Exception):
        pass

    class MyStream(WritableStream):
        def write(self, s):
            raise NondefaultException('yay')

    try:
        MyStream().write('hoo')
        assert False
    except NondefaultException:
        pass

    # The second use-case is testing that it's called.
    class MyStream(WritableStream):
        def write(self, s):
            self.called = True

    my_stream = MyStream()
    my_stream.write('hoo')
    assert my_stream.called

# Generated at 2022-06-10 21:50:01.608281
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert isinstance(MyWritableStream(), WritableStream)



# Generated at 2022-06-10 21:50:11.759000
# Unit test for function get_repr_function
def test_get_repr_function():
    def f1(x):
        return x

    def f2(x):
        return x

    class C: pass

    class D(C): pass

    class E: pass

    c = C()
    d = D()
    e = E()

    assert get_repr_function(c, ((C, f1), (E, f2))) is f1
    assert get_repr_function(d, ((C, f1), (E, f2))) is f1
    assert get_repr_function(e, ((C, f1), (E, f2))) is f2
    assert get_repr_function(e, ((D, f1), (E, f2))) is f2



# Generated at 2022-06-10 21:50:18.081897
# Unit test for function get_repr_function
def test_get_repr_function():

    class A(object):
        pass

    class B(A):
        pass

    assert get_repr_function(A, ((A, lambda x: 1),)) == 1
    assert get_repr_function(A(), ((A, lambda x: 2),)) == 2
    assert get_repr_function(B(), ((A, lambda x: 3),)) == 3

    assert get_repr_function(A(), ((B, lambda x: 4),)) == repr
    assert get_repr_function(A(), ((type, lambda x: 5),)) == 5



# Generated at 2022-06-10 21:50:24.311721
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    class Foo(WritableStream):
        def write(self, s):
            pass
    assert isinstance(Foo(), WritableStream)
    assert not isinstance(io.StringIO(), WritableStream)
    class Bar(Foo):
        pass
    assert isinstance(Bar(), WritableStream)



# Generated at 2022-06-10 21:50:30.681918
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(object):
        def write(self, s):
            pass
    assert isinstance(A(), WritableStream)


if __name__ == '__main__':
    test_WritableStream_write()

# Generated at 2022-06-10 21:50:32.219109
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Test(object):
        def write(self, s):
            pass
    assert issubclass(Test, WritableStream)

# Generated at 2022-06-10 21:50:43.288497
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, []) == repr

    def f(x):
        return len(x)

    assert get_repr_function('meow', []) == repr
    assert get_repr_function('meow', [(f, f)]) == f
    assert get_repr_function(1, [(f, f)]) == repr
    assert get_repr_function('meow', [(1, f)]) == repr
    assert get_repr_function('meow', [(f, f), (int, f)]) == f
    assert get_repr_function(1, [(f, f), (int, f)]) == f



# Generated at 2022-06-10 21:50:49.755157
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert normalize_repr('igloo at 0x100') == 'igloo'
    assert normalize_repr('meow') == 'meow'

    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=5) == "'h...'"
    assert get_shortish_repr('hello', max_length=5, normalize=True) == "'h...'"
    assert get_shortish_repr('hello', max_length=3, normalize=True) == "'h...'"

    assert get_shortish_repr(u'hello') == u"'hello'"

# Generated at 2022-06-10 21:51:02.206524
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) == repr
    assert get_repr_function('', ()) == repr
    assert get_repr_function(
        '',
        (lambda s: s == 'a', lambda s: 'aa')
    ) == 'aa'
    assert get_repr_function('a', (lambda s: s == 'a', lambda s: 'aa')) == 'aa'
    assert get_repr_function(
        'aa',
        (lambda s: s == 'a', lambda s: 'bb')
    ) == repr
    assert get_repr_function(1, (lambda s: s == 'a', lambda s: 'bb')) == repr

# Generated at 2022-06-10 21:51:05.260006
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s): pass

    assert issubclass(A, WritableStream)
    assert issubclass(sys.stdout, WritableStream)



# Generated at 2022-06-10 21:51:08.485751
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from io import StringIO, BytesIO

    assert isinstance(StringIO(), WritableStream)
    assert not isinstance(sys.stdout, WritableStream)
    assert isinstance(BytesIO(), WritableStream)

# Generated at 2022-06-10 21:51:11.257672
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Stream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(Stream, WritableStream)

# Generated at 2022-06-10 21:51:15.448719
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    class FakeWriteableStream(WritableStream):
        def write(self, s):
            return s

    assert isinstance(FakeWriteableStream(), WritableStream)
    assert isinstance(io.StringIO(), WritableStream)

# Generated at 2022-06-10 21:51:26.182162
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import tempfile
    import os
    with tempfile.NamedTemporaryFile() as f:
        x = f.name
        assert get_shortish_repr(x, max_length=40, normalize=True) == x
        assert get_shortish_repr(x, max_length=40, normalize=False) == x
        assert get_shortish_repr(x, max_length=23, normalize=True) ==  \
                                                                repr(x)[:23]
        assert get_shortish_repr(x, max_length=23, normalize=False) == \
                                                                truncate(x, 23)
    assert len(get_shortish_repr(os, max_length=30)) <= 30

# Generated at 2022-06-10 21:51:45.840074
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([0, 1, 2, 3], max_length=30) == '[0, 1, 2, 3]'
    assert get_shortish_repr([0, 1, 2, 3], max_length=13) == '[0, 1, 2...]'
    assert get_shortish_repr([0, 1, 2, 3], max_length=15) == '[0, 1, 2, 3]'
    assert get_shortish_repr([], max_length=13) == '[]'
    assert get_shortish_repr('hi', max_length=3) == "'hi'"
    assert get_shortish_repr('hi', max_length=5) == "'hi'"
    assert get_shortish_repr('hi', max_length=4) == "'h...'"
    assert get

# Generated at 2022-06-10 21:51:52.673780
# Unit test for function get_repr_function
def test_get_repr_function():
    def f(x):
        return x

    g = lambda x: x

    h = lambda x: x+1

    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, f))) is f
    assert get_repr_function(1, ((int, f), (str, g))) is f
    assert get_repr_function('1', ((int, f), (str, g))) is g
    assert get_repr_function(1, ((str, g))) is repr
    assert get_repr_function(1, ((int, h), (str, f))) is repr



# Generated at 2022-06-10 21:51:54.042769
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass


# Generated at 2022-06-10 21:52:01.435479
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    a = A()
    b = 'hi'
    c = 5
    assert get_repr_function(a, [(int, str), (A, id)]) is id
    assert get_repr_function(b, [(int, str), (A, id)]) is id
    assert get_repr_function(c, [(int, str), (A, id)]) is str




# Generated at 2022-06-10 21:52:04.459458
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abc', max_length=2) == "'a...'"

# Generated at 2022-06-10 21:52:12.697329
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(4, ()) == repr
    assert get_repr_function(4, [(lambda x: False, str)]) == repr
    assert get_repr_function(4, [(lambda x: True, str)]) == str
    assert get_repr_function(4, [(int, str)]) == str
    assert get_repr_function(
        (3, 4),
        [(lambda x: len(x) == 2, list)]
    ) == list



# Generated at 2022-06-10 21:52:24.593366
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr((1, 2, 3, 4)) == '(1, 2, 3, 4)'
    assert get_shortish_repr((1, 2, 3, 4), max_length=10) == '(1, 2, ...)'
    assert get_shortish_repr(range(1000), max_length=10) == 'range(0, 1...'
    assert get_shortish_repr((1, 2, 3, 4), max_length=3) == '(1, ...)'
    assert get_shortish_repr((1, 2, 3, 4), max_length=0) == '(...)'
    assert get_shortish_repr((1, 2, 3, 4), max_length=-1) == '...'

# Generated at 2022-06-10 21:52:33.967087
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(123) == '123'
    assert get_shortish_repr('abc') == repr('abc')
    assert get_shortish_repr([1, 2, 3], max_length=20) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=20, normalize=True) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=6) == '[1, ...]'
    assert get_shortish_repr([1, 2, 3], max_length=7) == '[1, ...]'
    assert get_shortish_repr([1, 2, 3], max_length=8) == '[1, 2, ...]'
    assert get_shortish_re

# Generated at 2022-06-10 21:52:45.227520
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) == repr
    assert get_repr_function('', ()) == repr
    
    assert get_repr_function(None, ((None, lambda x: 'A'))) == 'A'
    assert get_repr_function(None, ((None, lambda x: 'A'), (None, lambda x: 'B'))) == 'A'
    
    assert get_repr_function('', ((None, lambda x: 'A'))) == 'A'
    assert get_repr_function('', ((None, lambda x: 'A'), (None, lambda x: 'B'))) == 'A'
    
    assert get_repr_function(None, ((type(None), lambda x: 'A'))) == 'A'

# Generated at 2022-06-10 21:52:47.811901
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s
    assert issubclass(A, WritableStream)
    a = A()
    a.write('hello world')
    a.write('\n')
    assert a.s == 'hello world\n'

# Generated at 2022-06-10 21:53:06.507596
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([1, 2, 3, 4], max_length=5) == '[1, 2...]'
    assert get_shortish_repr([1, 2, 3, 4], max_length=6) == '[1, 2...]'
    assert get_shortish_repr([1, 2, 3, 4], max_length=7) == '[1, 2, ...]'
    assert get_shortish_repr([1, 2, 3, 4], max_length=8) == '[1, 2, ...]'
    assert get_shortish_repr([1, 2, 3, 4], max_length=9) == '[1, 2, 3...]'
    assert get_shortish_repr([1, 2, 3, 4], max_length=10) == '[1, 2, 3...]'
   

# Generated at 2022-06-10 21:53:09.068033
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class ClassWithWrite:
        def write(self):
            pass
    assert isinstance(ClassWithWrite(), WritableStream)
    assert not isinstance(1, WritableStream)

# Generated at 2022-06-10 21:53:14.121054
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = None

        def write(self, s):
            self.written = s

    mws = MyWritableStream()
    mws.write('bla')
    assert mws.written == 'bla'

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-10 21:53:26.269975
# Unit test for function get_repr_function
def test_get_repr_function():
    class _A(object): pass
    a = _A()
    b = object()
    # default
    assert get_repr_function(a) is repr
    assert get_repr_function(b) is repr

    # custom repr
    def repr_a(x):
        assert isinstance(x, _A)
        return 'A'
    repr_b = repr

    # repr per item
    assert get_repr_function(a, custom_repr=((a, repr_a),)) is repr_a
    assert get_repr_function(b, custom_repr=((a, repr_a),)) is repr_b

    # repr per type
    assert get_repr_function(a, custom_repr=((_A, repr_a),)) is repr_a
    assert get_repr_function

# Generated at 2022-06-10 21:53:37.279294
# Unit test for function get_repr_function
def test_get_repr_function():
    def f(x):
        return get_repr_function(x, [(lambda x: True, lambda x: 'a')])
    assert f(None) == 'a'
    assert f(5) == 'a'
    assert f({}) == 'a'

    def f(x):
        return get_repr_function(
            x,
            [
                (lambda x: isinstance(x, dict), lambda x: 'dict'),
                (lambda x: isinstance(x, (None, int, float)),
                 lambda x: 'number')
            ]
        )
    assert f(None) == 'number'
    assert f(5) == 'number'
    assert f(5.5) == 'number'
    assert f({}) == 'dict'



# Generated at 2022-06-10 21:53:49.466264
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '...'
    assert get_shortish_repr(1, max_length=-1) == ''

    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=None) == "'hello'"
    assert get_shortish_repr('hello', max_length=5) == "'hello'"
    assert get_shortish

# Generated at 2022-06-10 21:53:57.175729
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MockWritableStream(WritableStream):
        def __init__(self):
            self.written_strings = []

        def write(self, s):
            self.written_strings.append(s)

    ws = MockWritableStream()

    ws.write('abc')
    ws.write('12')
    ws.write('~!@')
    ws.write('a')

    assert ws.written_strings == ['abc', '12', '~!@', 'a']

# Generated at 2022-06-10 21:54:05.797439
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) is repr
    assert get_repr_function(1, ()) is repr
    assert get_repr_function('a', ()) is repr
    assert get_repr_function(1, ((int, lambda x: str(x + 5)),)) == '6'
    assert get_repr_function('a', ((int, lambda x: str(x + 5)),)) is repr


if __name__ == '__main__':
    test_get_repr_function()

# Generated at 2022-06-10 21:54:17.199104
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .data_structures import FrozenDict
    from .decorators import decorate_class_with_custom_repr
    from .collections_abc import Sequence

    @decorate_class_with_custom_repr(to_repr=lambda self: self.name)
    class Foo(object):
        def __init__(self, name):
            self.name = name
    assert get_shortish_repr(Foo('a'), custom_repr=()) == 'Foo object'
    assert get_shortish_repr(Foo('a'), custom_repr=((Foo, lambda item: item.name),)) == \
                                                                                   'a'

    class FooDict(FrozenDict):
        pass


# Generated at 2022-06-10 21:54:23.933205
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(12345, normalize=False) == '12345'
    assert get_shortish_repr('0123456789', normalize=False) == '0123456789'
    assert get_shortish_repr(
        '0123456789',
        normalize=False,
        max_length=10
    ) == '0123456789'
    assert get_shortish_repr(
        '0123456789',
        normalize=False,
        max_length=9
    ) == '01234567...89'
    assert get_shortish_repr(
        '0123456789',
        normalize=False,
        max_length=8
    ) == '01234...789'

# Generated at 2022-06-10 21:54:45.838694
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .smart_writable_file_like_object import SmartWritableFileLikeObject
    writable_file_like_object = SmartWritableFileLikeObject()
    assert isinstance(
        writable_file_like_object, WritableStream
    )

    from .smart_writable_file_like_object import SmartWritableFileLikeObject
    dummy_writable_file_like_object = SmartWritableFileLikeObject(
        writes_to_string=True
    )
    assert isinstance(
        dummy_writable_file_like_object, WritableStream
    )
    dummy_writable_file_like_object.write('hello world')
    assert dummy_writable_file_like_object.string == 'hello world'

# Generated at 2022-06-10 21:54:51.100465
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('long string that should be truncated') == (
        'long string that shoul...truncated'
    )
    assert get_shortish_repr(
        'long string that should be truncated',
        max_length=4
    ) == 'l...'



# Generated at 2022-06-10 21:55:04.258195
# Unit test for function get_shortish_repr