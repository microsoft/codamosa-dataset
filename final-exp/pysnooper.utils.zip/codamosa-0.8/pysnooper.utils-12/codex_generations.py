

# Generated at 2022-06-10 21:45:20.639093
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A(object):
        def __repr__(self):
            return 'Hahaha!'

    assert get_shortish_repr('hello world', max_length=3) == 'hel...'
    assert get_shortish_repr('hello world', max_length=100) == 'hello world'
    assert get_shortish_repr('hello world', max_length=None) == 'hello world'
    assert get_shortish_repr(A(), max_length=3) == repr(A()) == 'Hahaha!'
    assert get_shortish_repr(A(), max_length=6) == repr(A())

# Generated at 2022-06-10 21:45:27.922855
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableMock(object):
        def __init__(self):
            self.s = ''

        def write(self, s):
            self.s += s

    writable_mock = WritableMock()

    assert issubclass(WritableMock, WritableStream)
    assert isinstance(writable_mock, WritableStream)

    writable_mock.write('test')
    assert writable_mock.s == 'test'

# Generated at 2022-06-10 21:45:39.880788
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    a = A()

    assert get_repr_function(a, ()) == repr
    assert get_repr_function(a, ((object, str), )) == str

    assert get_repr_function(a, ((lambda x: True, str), )) == str
    assert get_repr_function(a, ((lambda x: False, str), )) == repr

    assert get_repr_function(a, ((A, str), )) == str
    assert get_repr_function(a, ((A, str), (object, str))) == str

    assert get_repr_function(A, ((A, str), )) == str
    assert get_repr_function(A, ((A, str), (type, str))) == str





if __name__ == '__main__':
    test

# Generated at 2022-06-10 21:45:47.930922
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(8.2, ())(8.2) == '8.2'
    assert get_repr_function('abc', ())('abc') == "'abc'"
    assert get_repr_function(8.2, (str, lambda x: 'str!'))(8.2) == '8.2'
    assert get_repr_function('abc', (str, lambda x: 'str!'))('abc') == 'str!'
    assert get_repr_function('abc', ((lambda s: len(s) == 2,
                                      lambda x: 'yes'),
                                     ))('abc') == "'abc'"
    assert get_repr_function('abc', ((lambda s: len(s) == 2,
                                      lambda x: 'yes'),
                                     ))('ab') == 'yes'

# Generated at 2022-06-10 21:45:53.690195
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('t') == 't'
    assert shitcode('i') == 'i'
    assert shitcode('\u20ac') == '?'
    assert shitcode('\u20ac\u20ac') == '??'
    assert shitcode('€') == '?'
    assert shitcode('??') == '??'



# Generated at 2022-06-10 21:46:01.329367
# Unit test for function get_repr_function
def test_get_repr_function():
    from .fake import ClassA, ClassB
    classA = ClassA()
    classB = ClassB()
    assert get_repr_function(classA, custom_repr=[]) is repr
    assert get_repr_function(classB, custom_repr=[]) is repr
    assert get_repr_function(classA, custom_repr=[
        (lambda x: True, str),
    ]) is str
    assert get_repr_function(classB, custom_repr=[
        (lambda x: True, str),
    ]) is str
    assert get_repr_function(classA, custom_repr=[
        (lambda x: True, str),
        (lambda x: False, repr),
    ]) is str

# Generated at 2022-06-10 21:46:05.656131
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('Hello', max_length=3) == 'He...'
    assert get_shortish_repr('Hello', max_length=5) == 'Hello'
    assert get_shortish_repr('Hello', max_length=10) == 'Hello'




# Generated at 2022-06-10 21:46:10.314944
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            self.s = s
    writable_stream = MyWritableStream()
    writable_stream.write('hey')
    assert writable_stream.s == 'hey'




# Generated at 2022-06-10 21:46:24.126803
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWeirdWritableStream(WritableStream):
        def bar(self):
            pass

    assert issubclass(MyWeirdWritableStream, WritableStream)

    class NoWritableStream(object):
        pass

    assert not issubclass(NoWritableStream, WritableStream)

    class MyOtherWritableStream(object):
        def write(self, s):
            pass

    class MyOtherWeirdWritableStream(MyOtherWritableStream, WritableStream):
        pass

    assert issubclass(MyOtherWeirdWritableStream, WritableStream)


# Generated at 2022-06-10 21:46:31.942210
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('foo') == u'foo'
    assert shitcode(u'foo') == u'foo'
    assert shitcode(1) == u'?'
    assert shitcode(u'\ud840') == u'?'
    assert shitcode(u'\ud840'.encode('utf8')) == u'?'
    assert shitcode(u'\ud841') == u'?'
    assert shitcode(u'\ud841'.encode('utf8')) == u'?'
    assert shitcode(u'\ud840\udc01') == u'?'

# Generated at 2022-06-10 21:46:50.315319
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(1, 'abc')]) is repr
    assert get_repr_function(1, [(2, 'abc')]) is repr

    assert get_repr_function(1, [(1, 'abc')]) == 'abc'
    assert get_repr_function(2, [(2, 'abc')]) == 'abc'
    assert get_repr_function(4, [(lambda x: x % 4 == 0, 'divisible by 4')]) == \
           'divisible by 4'

# Generated at 2022-06-10 21:46:57.838195
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('', ()) == repr
    assert get_repr_function(u'', ()) == repr

    assert get_repr_function(u'', ((str, str),)) == str
    assert get_repr_function(u'', ((str, str), (unicode, str))) == str

    assert get_repr_function(u'', ((bytes, str),)) == str
    assert get_repr_function(u'', ((bytes, str), (unicode, str))) == str

# Generated at 2022-06-10 21:47:02.776251
# Unit test for function get_repr_function
def test_get_repr_function():
    def repr_function(x):
        return 'repr_function({})'.format(x)
    assert repr(1.0) == get_repr_function(1.0, ())(1.0)
    assert 'repr_function' == get_repr_function(1.0, ((lambda x: True,
                                                        repr_function)))(1.0)



# Generated at 2022-06-10 21:47:12.356899
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        pass

    assert WritableStream in Foo.__mro__
    assert WritableStream.__subclasshook__(Foo) is NotImplemented
    class Foo(WritableStream):
        def __init__(self):
            self.string = ''

        def write(self, s):
            assert isinstance(s, str)
            self.string += s

    assert WritableStream in Foo.__mro__
    assert WritableStream.__subclasshook__(Foo)

    foo = Foo()
    foo.write('hello')
    assert foo.string == 'hello'
    with pytest.raises(TypeError):
        foo.write(123)



# Generated at 2022-06-10 21:47:16.698603
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)
    
    
    



# Generated at 2022-06-10 21:47:28.320068
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    ### Test standard write ###
    import tempfile
    with tempfile.NamedTemporaryFile('r+', encoding='utf-8') as temp_file:
        class MyWritableStream(WritableStream):
            def write(self, s):
                temp_file.write(s)
        instance = MyWritableStream()
        assert isinstance(instance, WritableStream)
        instance.write(u'עולם של חיים ונפשות')
        temp_file.seek(0)
        assert temp_file.read() == u'עולם של חיים ונפשות'


    ### Test alternate write ###
    import tempfile

# Generated at 2022-06-10 21:47:36.815404
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(1, '_')]) == '_'
    assert get_repr_function(1, [
        (lambda x: x == 1, '_'),
    ]) == '_'
    assert get_repr_function(1, [
        (lambda x: x != 1, '_'),
    ]) == repr
    assert get_repr_function([1], [
        (lambda x: x == 1, '_'),
    ]) == repr
    assert get_repr_function(1, [
        (lambda x: True, '_'),
    ]) == '_'

# Generated at 2022-06-10 21:47:40.954037
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def write(self, s):
            self.string = s

    foo = Foo()
    foo.write('meow')
    assert foo.string == 'meow'



# Generated at 2022-06-10 21:47:52.819051
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    x = 123456789012345
    y = 'a' * 100
    z = b'b' * 100
    c = lambda: None
    assert get_shortish_repr(x) == '123456789012345'
    assert get_shortish_repr(x, max_length=15) == '123456789012345'
    assert get_shortish_repr(x, max_length=100) == '123456789012345'
    assert get_shortish_repr(x, max_length=8) == '1234...7890'
    assert get_shortish_repr(x, max_length=7) == '1234...'

    assert get_shortish_repr(y) == y

# Generated at 2022-06-10 21:48:02.053786
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('', []) is repr
    assert get_repr_function(2, []) is repr
    assert get_repr_function(2, [(str, str)]) is repr

    import re
    assert get_repr_function(re.compile(''), []) is repr
    assert get_repr_function(re.compile(''), [(re.Pattern, repr)]) is repr
    assert get_repr_function(re.compile(''), [(re.Pattern, str)]) is str

    assert get_repr_function(re.compile(''), [(str, str)]) is repr
    assert get_repr_function(re.compile(''), [(str, str), (re.Pattern, str)]) \
                                                                       is str



# Generated at 2022-06-10 21:48:09.757630
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    get_shortish_repr(5)
    get_shortish_repr(5, max_length=None)
    get_shortish_repr(5, max_length=1) # noinspection PyTypeChecker
    get_shortish_repr('abc', max_length=3) # noinspection PyTypeChecker
    get_shortish_repr('abc', max_length=2) # noinspection PyTypeChecker
    get_shortish_repr('abc', max_length=None) # noinspection PyTypeChecker
    get_shortish_repr('abc', max_length=4) # noinspection PyTypeChecker
    get_shortish_repr('abc', max_length=6) # noinspection PyTypeChecker

# Generated at 2022-06-10 21:48:16.628730
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStream(ABC):
        @abc.abstractmethod
        def write(self, s):
            pass
        @classmethod
        def __subclasshook__(cls, C):
            if cls is WritableStream:
                return _check_methods(C, 'write')
            return NotImplemented


    class Albatross(WritableStream):
        def write(self, s):
            pass


    assert issubclass(Albatross, WritableStream)



# Generated at 2022-06-10 21:48:23.920145
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X:
        def write(self, s):
            pass
        def non_write(self, s):
            pass
    class Y(X):
        def write(self, s):
            pass
        def non_write(self, s):
            pass
    
    assert issubclass(X, WritableStream)

    assert issubclass(Y, WritableStream)

    assert not issubclass(object, WritableStream)

    

# Generated at 2022-06-10 21:48:33.564621
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [(int, str),
                   (float, lambda x: '#%s' % x)]
    assert get_repr_function(1, custom_repr) is str
    assert get_repr_function(1.0, custom_repr) is not str
    assert get_repr_function(1.0, custom_repr) is not float
    assert get_repr_function(1.0, custom_repr) is not int
    assert get_repr_function(1.0, custom_repr) is get_repr_function(
        1.0, custom_repr
    )
    assert get_repr_function(1, custom_repr) is not get_repr_function(
        1.0, custom_repr
    )
    assert get_repr_

# Generated at 2022-06-10 21:48:39.857404
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, []) == repr
    assert get_repr_function('a', [(str, repr)]) == repr
    assert get_repr_function(0, [(str, repr)]) == repr
    assert get_repr_function(0, [(int, str)]) == str
    assert get_repr_function(0, [(int, str), (str, repr)]) == str

# Generated at 2022-06-10 21:48:46.804180
# Unit test for function shitcode
def test_shitcode():
    from .test_tools import assert_equal
    assert_equal(shitcode('זה יואל קליין'), 'זה יואל קליין')
    assert_equal(shitcode('זה יואל קליין\x90'), 'זה יואל קליין?')
    assert_equal(shitcode('זה יואל קליין\x90\x90'), 'זה יואל קליין??')
    assert_equal(shitcode('זה יואל קליין\x90\x90\x90'), 'זה יואל קליין???')

# Generated at 2022-06-10 21:48:56.930115
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcdefg') == "'abcdefg'"
    assert get_shortish_repr('abcdefg', max_length=5) == "'ab...'"
    assert get_shortish_repr(6, (
        (lambda x: isinstance(x, float), float.__repr__),
    )) == '6'
    assert get_shortish_repr(6.3, (
        (lambda x: isinstance(x, float), float.__repr__),
    )) == '6.3'
    assert get_shortish_repr('abcdefg', (
        (lambda x: x.startswith('a'), lambda x: 'yes'),
    )) == "'yes'"
    # Unit test for `ensure_tuple`:
    assert ensure_tuple(1)

# Generated at 2022-06-10 21:49:08.010735
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr((1, 2, 3), max_length=25) == '(1, 2, 3)'
    assert (get_shortish_repr((1, 2, 3), max_length=10) ==
            '(1, 2,...)')

    assert (get_shortish_repr((1, 2, 3), max_length=25,
                              custom_repr=[(lambda x, y=(1, 2, 3): x == y,
                                            lambda x, y='HALA': repr(y))]) ==
            'HALA')


# Generated at 2022-06-10 21:49:17.697226
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from . import (spec, this, maybe)
    from .every import Every
    from .Functional import (map, filter)

    from .cute_testing import (expect, run_tests_if_main, assert_not_raised,
                               get_fake_document)

    bool_repr = lambda x: 'bool: ' + str(x)
    str_repr = lambda x: 'str: ' + x

    with assert_not_raised():
        expect(get_shortish_repr(True,
                                 custom_repr=((bool, bool_repr),),
                                 max_length=5)).to_equal('bool: True')
        expect(get_shortish_repr(True,
                                 custom_repr=((bool, bool_repr),),
                                 max_length=7)).to

# Generated at 2022-06-10 21:49:28.438966
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import sys
    import math
    import numpy as np

    def assert_short_repr_of(item, max_length, desired_short_repr):
        assert desired_short_repr == get_shortish_repr(
            item,
            max_length=max_length,
            custom_repr=((np.ndarray, lambda x: 'ndarray({})'.format(
                x.__str__(max_length-len('ndarray(')))),
                                          (math.pi, lambda: 'π')),
            normalize=True
        )

    assert_short_repr_of(math.pi, None, 'π')
    assert_short_repr_of(math.pi, 10, 'π')

# Generated at 2022-06-10 21:49:42.250935
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [1]) == repr
    assert get_repr_function(1, [(1, None)]) == repr
    assert get_repr_function(1, ((1, None),)) == repr
    assert get_repr_function(1, [(1, False)]) == False
    assert get_repr_function(1, ((1, False),)) == False
    assert get_repr_function(1, [(1, True)]) == True
    assert get_repr_function(1, ((1, True),)) == True
    assert get_repr_function(1, [(1, lambda s: 'a')]) == 'a'
    assert get_re

# Generated at 2022-06-10 21:49:52.992017
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1,()) == repr
    assert get_repr_function(None,()) == repr
    assert get_repr_function(1,((lambda x: True, lambda x: 'x'))) == repr
    assert get_repr_function(1,((type(1), lambda x: 'x'))) == 'x'
    assert get_repr_function(1,((lambda x: False, lambda x: 'x'))) == repr
    assert get_repr_function(1,((type(1), lambda x: 'x'),(lambda x: False, lambda x: 'y'))) == 'x'
    assert get_repr_function(1,((type(None), lambda x: 'x'),(lambda x: False, lambda x: 'y'))) == 'x'


# Generated at 2022-06-10 21:49:56.903038
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    def test_write(f):
        f.write(b'bye')

    assert issubclass(WritableStream, type)

    assert isinstance(sys.stdout, WritableStream)

    #assert isinstance(test_write, WritableStream) # Doesn't work yet



# Generated at 2022-06-10 21:49:58.148428
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert hasattr(sys.stdout, 'write')



# Generated at 2022-06-10 21:50:04.646252
# Unit test for function get_repr_function
def test_get_repr_function():

    custom_repr = (lambda x: isinstance(x, str), shitcode),
    def my_repr(x):
        return 'my repr of ' + repr(x)

    class A(object):
        pass
    assert get_repr_function('foo', custom_repr) is shitcode
    assert get_repr_function(A(), custom_repr) is repr
    assert get_repr_function(
        A(), custom_repr + ((A, my_repr),)
    ) is my_repr



# Generated at 2022-06-10 21:50:11.572904
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    '''
    Tests `write` method of class `WritableStream`.
    '''
    from .test_python_toolbox import AssertRaisesContext
    class BadStream(WritableStream):
        __metaclass__ = ABC
    with AssertRaisesContext(TypeError):
        BadStream.register(int)
    class BadStream(WritableStream):
        def write(self, s):
            pass
    BadStream.register(int)

# Generated at 2022-06-10 21:50:15.621259
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):

        def __init__(self):
            self.items = []

        def write(self, s):
            self.items.append(s)

    stream = MyWritableStream()
    stream.write('HELLO')
    assert stream.items == ['HELLO']

# Generated at 2022-06-10 21:50:20.399308
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    MyWritableStream().write('hi')


if __name__ == '__main__':
    test_WritableStream_write()

# Generated at 2022-06-10 21:50:33.406641
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(B): pass
    class D: pass

    repr_function = get_repr_function(A(), [(A, repr)])
    assert repr_function is repr

    repr_function = get_repr_function(B(), [(A, repr)])
    assert repr_function is repr

    repr_function = get_repr_function(A(), [(B, repr)])
    assert repr_function is not repr

    repr_function = get_repr_function(A(), [(B, repr), (A, str)])
    assert repr_function is str

    repr_function = get_repr_function(B(), [(A, repr), (B, str)])
    assert repr_function is str


# Generated at 2022-06-10 21:50:44.873030
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(123) == '123'
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=2) == "'h...'"
    assert get_shortish_repr('hello', normalize=True) == "'hello'"
    assert get_shortish_repr('hello', max_length=2, normalize=True) == "'h...'"

    class MyClass(object):
        def __repr__(self):
            return 'hello'

    assert get_shortish_repr(MyClass()) == 'hello'
    assert get_shortish_repr(MyClass(), max_length=2) == 'he...'

    class MyClass(object):
        def __repr__(self):

            return 'hello'

# Generated at 2022-06-10 21:50:50.906090
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function([1, 2, 3], ((list, lambda x: 'list'),)) == 'list'
    assert get_repr_function(1, ((list, lambda x: 'list'),)) == '1'



# Generated at 2022-06-10 21:51:03.411794
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class TestClass(object):
        def __repr__(self):
            return 'a' * 100

    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(TestClass()) == 'a' * 100
    assert get_shortish_repr(TestClass(), max_length=20) == 'a' * 17 + '...'
    assert get_shortish_repr(TestClass(), max_length=20, normalize=True) == 'a' * 17 + '...'

    def custom_repr(x):
        return 'meow'

    assert get_shortish_repr(TestClass(), ((int, repr), (TestClass, custom_repr))) == '1'

# Generated at 2022-06-10 21:51:09.439320
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class StringStream(WritableStream):
        def __init__(self):
            self.string = ''
        def write(self, s):
            self.string += s
    stream = StringStream()
    stream.write('hello')
    assert stream.string == 'hello'
    stream.write(' my')
    assert stream.string == 'hello my'
    stream.write(' name')
    assert stream.string == 'hello my name'



# Generated at 2022-06-10 21:51:13.113565
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            self.s = s

    a = A()
    a.write('test')
    assert a.s == 'test'



# Generated at 2022-06-10 21:51:24.369887
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, [(int, lambda x: '{} is an int'.format(x))]) ==\
                                                               (lambda x: '{} is an int'.format(x))
    assert get_repr_function(5.5, [(float, lambda x: '{} is a float'.format(x))]) ==\
                                                               (lambda x: '{} is a float'.format(x))
    assert get_repr_function(5.5, [(int, lambda x: '{} is an int'.format(x))]) == repr
    assert get_repr_function(5.5, [(None, lambda x: '{} is None'.format(x))]) == repr
    assert get_repr_function(5.5, [(None,)]) == repr
    assert get_re

# Generated at 2022-06-10 21:51:31.224171
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyWritableStream(WritableStream):
        def write(self, s):
            pass

    DummyWritableStream()

    class BadWritableStream(WritableStream):
        pass

    try:
        BadWritableStream()
    except TypeError:
        pass
    else:
        raise Exception("Shouldn't be able to instantiate a BadWritableStream")

# Generated at 2022-06-10 21:51:37.046849
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(b'abc') == u'abc'
    assert shitcode(u'a\u07b5c') == u'a?c'
    assert shitcode(b'a\u07b5c') == u'a?c'



# Generated at 2022-06-10 21:51:41.708421
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Stream(WritableStream):
        def __init__(self): self.data = []
        def write(self, s): self.data.append(s)

    stream = Stream()
    stream.write('Hello world!')
    assert stream.data == ['Hello world!']



# Generated at 2022-06-10 21:51:45.558778
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('שלום עולם') == '??? ?????', \
                                                'shitcode is not shitcoding'



# Generated at 2022-06-10 21:51:53.721672
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    def assert_get_shortish_repr(input_, output):
        assert get_shortish_repr(input_) == output
    assert_get_shortish_repr(2, '2')
    assert_get_shortish_repr((2, 3), '(2, 3)')
    assert_get_shortish_repr('abc', "'abc'")
    assert_get_shortish_repr('abcdefg', "'abcdefg'")
    assert_get_shortish_repr('abcdefghij', "'abcdef...ij'")
    assert_get_shortish_repr('abcdefghijklmnopq', "'abcdef...nopq'")
    assert_get_shortish_repr((2, 3, 'a'), '(2, 3, ' + "'a')")

# Generated at 2022-06-10 21:52:08.001851
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None) == repr
    assert get_repr_function(1) == repr
    assert get_repr_function((1, 2)) == repr
    assert get_repr_function(b'1') == repr
    assert get_repr_function(b'1') == repr
    assert get_repr_function(set()) == repr
    assert get_repr_function(dict()) == repr
    assert get_repr_function(1, [(int, 'int')]) == 'int'
    assert get_repr_function(1.2, [(int, 'int')]) == repr
    assert get_repr_function(1, [(lambda x: isinstance(x, int), 'int')]) == 'int'

# Generated at 2022-06-10 21:52:10.209290
# Unit test for function shitcode
def test_shitcode():
    test_string = 'עברית'
    assert shitcode(test_string).count('?') == 3



# Generated at 2022-06-10 21:52:13.198571
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class APrinter:
        def write(self, s):
            print('A:' + s)

    class BPrinter:
        def write(self, s):
            print('B:' + s)
        def close(self):
            print('close')

    assert isinstance(APrinter(), WritableStream)
    assert isinstance(BPrinter(), WritableStream)



# Generated at 2022-06-10 21:52:24.961801
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C: pass
    a = A()
    b = B()
    c = C()

    custom_repr1 = [(lambda item: item == a, lambda item: 'This is A.')]
    custom_repr2 = [(lambda item: item == a, lambda item: 'This is A.'),
                    (lambda item: item == b, lambda item: 'This is B.'),
                    (lambda item: item == c, lambda item: 'This is C.')]


# Generated at 2022-06-10 21:52:28.123100
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class GoodWritableStream(WritableStream):
        def write(self, s):
            pass

    class BadWritableStream(WritableStream):
        def do_not_write(self, s):
            pass

# Generated at 2022-06-10 21:52:31.308754
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyFile(WritableStream):
        def __init__(self):
            self.data = []
        def write(self, s):
            self.data.append(s)

    f = MyFile()
    assert f.write('ok') is None

# Generated at 2022-06-10 21:52:43.137651
# Unit test for function get_repr_function
def test_get_repr_function():
    def f(x):
        return 'f(%s)' % x
    def g(x):
        return 'g(%s)' % x
    assert get_repr_function(1, ()) == repr
    assert get_repr_function('', ()) == repr
    assert get_repr_function(1, ((str, f),)) == repr
    assert get_repr_function('', ((str, f),)) == f
    assert get_repr_function(1, ((str, f), (int, g))) == g
    assert get_repr_function('', ((str, f), (int, g))) == f
    assert get_repr_function('', ((int, g), (str, f))) == f
    assert get_repr_function('', ((str, f), (str, g))) == f






# Generated at 2022-06-10 21:52:49.804459
# Unit test for function get_repr_function
def test_get_repr_function():
    from .registry import register_repr
    class Dog(object):
        pass
    for x in [None, 0, '', '1', (1,), [1], {1: 2}, Dog(), Dog]:
        assert get_repr_function(x) is repr
    register_repr(Dog, str)
    assert get_repr_function(Dog()) is str
    register_repr(lambda x: x is None, str)
    assert get_repr_function(None) is str
    
    
    
    

# Generated at 2022-06-10 21:52:57.710271
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('s', [('s', lambda x: x)]) == 's'
    assert get_repr_function('s', [
        (lambda x: True, lambda x: x),
    ]) == 's'
    assert get_repr_function('s', [
        (lambda x: False, lambda x: x),
        (lambda x: True, lambda x: x),
    ]) == 's'
    assert get_repr_function('s', [
        (lambda x: False, lambda x: x),
        (lambda x: True, lambda x: 'hi'),
        (lambda x: True, lambda x: 'bye'),
    ]) == 'hi'

# Generated at 2022-06-10 21:53:03.923691
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Whatever(WritableStream):
        def write(self, s):
            pass
    class WhateverElse(WritableStream):
        # This is an abstract class, but I'm testing that it doesn't pass the
        # test.
        pass
    assert issubclass(Whatever, WritableStream)
    assert not issubclass(WhateverElse, WritableStream)



# Generated at 2022-06-10 21:53:13.583856
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('') == "''"
    assert get_shortish_repr('') == "''"
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abcdefghij') == "'abcdefghij'"
    assert get_shortish_repr('abcdefghijk') == "'abcdefghi...k'"
    assert get_shortish_repr('abcdefghijklmnopqr') == "'abcdefghi...r'"




# Generated at 2022-06-10 21:53:24.800510
# Unit test for function get_repr_function
def test_get_repr_function():
    from string import Template
    assert get_repr_function(1, ())(1) == '1'
    assert get_repr_function([1], ())([1]) == '[1]'
    assert get_repr_function(1, [])(1) == '1'
    assert get_repr_function([1], [])([1]) == '[1]'
    assert (get_repr_function(1, [(int, lambda x: 'int')])
                                (1) == 'int')
    assert (get_repr_function([1], [(int, lambda x: 'int')])
                                 ([1]) == '[1]')
    assert (get_repr_function(1, [(str, lambda x: 'str'),
                                  (int, lambda x: 'int')])
                                (1) == 'int')

# Generated at 2022-06-10 21:53:30.237996
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FileLike(WritableStream):
        def write(self, s):
            pass

    assert issubclass(FileLike, WritableStream)
    assert isinstance(FileLike(), WritableStream)
    assert not issubclass(list, WritableStream)
    assert not isinstance([], WritableStream)




# Generated at 2022-06-10 21:53:39.670175
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo: pass

    class Bar(Foo): pass

    bar = Bar()

    assert get_repr_function(bar, (
        (lambda x: isinstance(x, Bar), lambda x: '<bar>'),
    )) is repr
    assert get_repr_function(bar, (
        (lambda x: isinstance(x, Foo), lambda x: '<foo>'),
    )) is repr

    assert get_repr_function(bar, (
        (Bar, lambda x: '<bar>'),
    )) is repr
    assert get_repr_function(bar, (
        (Foo, lambda x: '<foo>'),
    )) is repr


# Generated at 2022-06-10 21:53:42.569936
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def write(self, s):
            pass

    f = Foo()
    isinstance(f, WritableStream)


# Generated at 2022-06-10 21:53:47.790002
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('Hello world') == 'Hello world'
    assert shitcode('\x7f') == '\x7f'
    assert shitcode('a\u1234\u4321b') == 'a?\ufffd?b'
    assert shitcode('\x00\x7f') == '\x7f'



# Generated at 2022-06-10 21:53:54.970974
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, [(int, '5')]) == '5'
    assert get_repr_function(5, [(int, '5'), (str, '5')]) == '5'
    assert get_repr_function(5, [(str, '5')]) != '5'
    assert get_repr_function(5, [(lambda x: False, '???')]) != '???'



# Generated at 2022-06-10 21:54:01.936709
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda x: isinstance(x, int), lambda x: 'int!'),
        (int, lambda x: 'int2!')
    )
    assert get_repr_function(0, custom_repr) is int.__repr__
    assert get_repr_function(1, custom_repr) is int.__repr__
    assert get_repr_function('a', custom_repr) is str.__repr__
    assert get_repr_function(0.3, custom_repr) is float.__repr__
    assert get_repr_function([], custom_repr) is list.__repr__



# Generated at 2022-06-10 21:54:10.031198
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'hello world') == u'hello world'
    assert shitcode(u'π') == u'?'
    assert shitcode(u'\u22d7') == u'?'
    assert shitcode(u'\n') == u'\n'


if sys.version_info[0] >= 3:
    def bytes_to_unicode(bs):
        return bs.decode('utf-8')
else:
    def bytes_to_unicode(bs):
        return bs

# Generated at 2022-06-10 21:54:19.322278
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class A(WritableStream):
        def write(self, s):
            super(A, self).write(s)

    class B: pass

    assert issubclass(A, WritableStream)
    assert not issubclass(B, WritableStream)

    assert normalize_repr('a at 0xbeef') == 'a'
    assert normalize_repr('a at 0xbeefL') == 'a'
    assert normalize_repr('a at 0xbeefLL') == 'a'
    assert normalize_repr('a at 0xbeefL') == 'a'
    assert normalize_repr('a at 0xbeef1') == 'a at 0xbeef1'

# Generated at 2022-06-10 21:54:34.481602
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hi') == "'hi'"
    assert get_shortish_repr([1, 2]) == '[1, 2]'
    assert get_shortish_repr(['hello', 'there']) == "['hello', 'there']"
    assert get_shortish_repr(('hello', 'there')) == "('hello', 'there')"
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(type) == '<class \'type\'>'
    assert get_shortish_repr(Exception) == 'Exception'
    assert get_shortish_repr(Exception()) == 'Exception()'
    assert get_shortish_repr({'hi': 'there'}) == '{\'hi\': \'there\'}'
    assert get

# Generated at 2022-06-10 21:54:38.218629
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    assert WritableStream.__subclasshook__(sys.stdout) is True
    assert WritableStream.__subclasshook__(object) is NotImplemented

# Generated at 2022-06-10 21:54:50.585692
# Unit test for function get_repr_function
def test_get_repr_function():
    repr1 = lambda x: 'repr1: %s' % x
    repr2 = lambda x: 'repr2: %s' % x
    repr3 = lambda x: 'repr3: %s' % x

    class A: pass
    class B: pass

    assert get_repr_function(A(), custom_repr=(
        (lambda x: isinstance(x, A), repr1),
        (lambda x: isinstance(x, B), repr2),
        (lambda x: True, repr3)
    ))  == repr1

    assert get_repr_function(B(), custom_repr=(
        (lambda x: isinstance(x, A), repr1),
        (lambda x: isinstance(x, B), repr2),
        (lambda x: True, repr3)
    ))  == repr2

# Generated at 2022-06-10 21:54:58.253829
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def __init__(self):
            self.text = ''
        def write(self, s):
            self.text += s
    writable_stream_subclass = WritableStreamSubclass()
    assert isinstance(writable_stream_subclass, WritableStream)
    writable_stream_subclass.write('hi!')
    assert writable_stream_subclass.text == 'hi!'

# Generated at 2022-06-10 21:55:02.378066
# Unit test for function get_repr_function
def test_get_repr_function():

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    repr_function = get_repr_function(A(), ((A, str),))
    assert repr_function('A') == "'A'"

    repr_function = get_repr_function(C(), ((A, str),))
    assert repr_function('C') == "'C'"

    repr_function = get_repr_function(C(), ((B, str),))
    assert repr_function('C') == 'C'

    repr_function = get_repr_function(B(), ((B, str),))
    assert repr_function('B') == "'B'"

    repr_function = get_repr_function(C(), ((B, str),))
    assert repr_function('C') == 'C'