

# Generated at 2022-06-10 21:45:20.967496
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyObject(object):
        def write(self, s):
            pass

    assert issubclass(MyObject, WritableStream)

    class MyOtherObject(object):
        def write(self, s):
            pass

        def my_method(self, x):
            pass

    assert issubclass(MyOtherObject, WritableStream)

    class MyThirdObject(object):
        def write(self, s):
            pass

        def my_method(self, x):
            pass

        def write(self, s):
            pass

    assert issubclass(MyThirdObject, WritableStream)

    class MyFourthObject(object):
        def write(self, s):
            pass

        def my_method(self, x):
            pass

        def write(self, s):
            pass


# Generated at 2022-06-10 21:45:32.853480
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert (get_shortish_repr(123) == '123')
    assert (get_shortish_repr(123, normalize=True) == '123')
    assert (get_shortish_repr(123, max_length=4) == '123')
    assert (get_shortish_repr('abcdef', max_length=4) == 'abc...ef')
    assert (get_shortish_repr('abcdef', max_length=4, normalize=True)
            == 'abc...ef')
    assert (get_shortish_repr(123, custom_repr=[(int, str)]) == '123')
    class MyInt(int): pass

# Generated at 2022-06-10 21:45:40.558489
# Unit test for function get_repr_function
def test_get_repr_function():
    class Item: pass
    custom_repr = ((str, lambda x: 'a string'),
                   (Item, lambda x: 'an Item'))

# Generated at 2022-06-10 21:45:48.279450
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .toolbox import assert_equal
    assert_equal(
        get_shortish_repr('a' * 100), '{}...{}'.format('a' * (98 / 2), 'a' * (98 / 2))
    )
    assert_equal(
        get_shortish_repr(b'a' * 100), '{}...{}'.format('a' * (98 / 2), 'a' * (98 / 2))
    )
    assert_equal(
        get_shortish_repr('a' * 100, max_length=10),
        '{}...{}'.format('a' * 4, 'a' * 3),
    )

# Generated at 2022-06-10 21:45:55.037459
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, ((int, str), (float, str))) \
                                                            == str
    assert get_repr_function(3.5, ((int, str), (float, str))) \
                                                              == str
    assert get_repr_function('hi', ((int, str), (float, str))) \
                                                               == repr



if __name__ == '__main__':
    test_get_repr_function()

# Generated at 2022-06-10 21:46:00.756189
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1j, ((int, str), (complex, repr))) == str
    assert get_repr_function(
        1j, ((int, str), (complex, repr)),
    ) == repr
    assert get_repr_function(
        'a', ((int, str), (complex, repr)),
    ) == str
    assert get_repr_function(
        'a', ((int, str), (complex, repr)),
    ) == str
    assert get_repr_function(
        dict(), ((int, str), (complex, repr)),
    ) == repr



# Generated at 2022-06-10 21:46:07.514833
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestClass:
        def write(self, s):
            return s * 2
    assert isinstance(TestClass(), WritableStream)

    class TestClass:
        pass
    assert not isinstance(TestClass(), WritableStream)

    class TestClass:
        def write(self, s):
            pass
    assert isinstance(TestClass(), WritableStream)

    def TestClass():
        pass
    assert isinstance(TestClass(), WritableStream)



# Generated at 2022-06-10 21:46:17.449481
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    custom_repr = ((type(None), lambda item: 'None'),
                   (type(Ellipsis), lambda item: 'Ellipsis')
                   )

    assert get_shortish_repr(None, custom_repr=custom_repr,
                             max_length=None) == 'None'
    assert get_shortish_repr(None, custom_repr=custom_repr,
                             max_length=10) == 'None'
    assert get_shortish_repr(Ellipsis, custom_repr=custom_repr,
                             max_length=None) == 'Ellipsis'
    assert get_shortish_repr(Ellipsis, custom_repr=custom_repr,
                             max_length=5) == 'Ellipsis'
    assert get_shortish_repr

# Generated at 2022-06-10 21:46:24.608446
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('hello\r\nworld') == 'hello\r\nworld'
    assert shitcode('こんにちは') == '??????'
    assert shitcode('こんにちは\r\n世界') == '??????\r\n????'
    assert shitcode('こんにちは\r\n世界\r\n') == '??????\r\n????\r\n'
    assert shitcode('אבא') == '?????'
    assert shitcode('אבא\r\nבבב') == '?????\r\n????'
    assert shitcode('אבא\r\nבבב\r\n') == '?????\r\n????\r\n'
    assert shit

# Generated at 2022-06-10 21:46:35.236711
# Unit test for function get_repr_function
def test_get_repr_function():
    class C(object): pass
    c = C()
    assert get_repr_function(c, [(type(C), lambda x: 'C')]) is repr
    assert get_repr_function(c, [(type(c), lambda x: 'c')]) is repr
    assert get_repr_function(c, [
        (lambda x: isinstance(x, type(C)), lambda x: 'C'),
        (lambda x: isinstance(x, type(c)), lambda x: 'c'),
    ]) is repr
    assert get_repr_function(c, [(lambda x: True, lambda x: 'c')]) == 'c'
    assert get_repr_function(c, [(lambda x: False, lambda x: 'b')]) == repr

# Generated at 2022-06-10 21:46:43.488003
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C: pass
    repr_function = get_repr_function(A(), ((type(A()), repr),))
    assert repr_function(A()) == repr(A())
    assert repr_function(B()) == repr(B())
    assert repr_function(C()) != repr(C())



# Generated at 2022-06-10 21:46:46.658350
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(WritableStream):
        def write(self, s):
            pass
    x = X()
    try:
        x.write('yo')
    except NotImplementedError:
        assert False

# Generated at 2022-06-10 21:46:52.632596
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestableClass(WritableStream):
        def write(self, s):
            pass

    assert issubclass(TestableClass, WritableStream)
    assert TestableClass.__subclasshook__(TestableClass) == True
    assert TestableClass.__subclasshook__(Exception) == NotImplemented



# Generated at 2022-06-10 21:47:01.687437
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    # This is the method we're going to test
    def write(s):
        print(s, end='')

    # This is our class:
    class Bad(object):
        pass

    # This is how we test it
    from . import testing_tools

    testing_tools.assert_is_subclass(Bad, WritableStream)

    # This is how we test it for real.
    import six
    if six.PY2:
        from io import BytesIO
        b = BytesIO()
        b.write = write
        testing_tools.assert_is_subclass(b.__class__, WritableStream)
    else:
        from io import StringIO
        s = StringIO()
        s.write = write

# Generated at 2022-06-10 21:47:05.492936
# Unit test for function get_repr_function
def test_get_repr_function():
    def my_repr(x):
        return 'my_repr({})'.format(x)
    my_repr.__name__ = 'my_repr'
    assert get_repr_function(1, (
        (lambda x: True, my_repr),
        (lambda x: False, str),
    )) is my_repr
    assert get_repr_function(2, (
        (lambda x: False, my_repr),
        (lambda x: True, str),
    )) is str



# Generated at 2022-06-10 21:47:09.013738
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Subclass(WritableStream):
        def write(self, s):
            sys.stdout.write(s)

    assert issubclass(Subclass, WritableStream)
    assert issubclass(Subclass, WritableStream)



# Generated at 2022-06-10 21:47:17.105905
# Unit test for function get_repr_function
def test_get_repr_function():

    assert get_repr_function(1, []) == repr
    assert get_repr_function('hello', []) == repr
    assert get_repr_function((1, 2, 3), []) == repr


# Generated at 2022-06-10 21:47:22.901416
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamTest(WritableStream):
        def write(self, s):
            raise NotImplementedError
    writable_stream = WritableStreamTest()
    assert issubclass(WritableStreamTest, WritableStream)
    writable_stream.write('foo')



# Generated at 2022-06-10 21:47:28.156880
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, [('something', 'else')]) == repr
    assert get_repr_function('', [('something', 'else')]) == repr
    assert get_repr_function('', [(str, 'else')]) == 'else'
    assert get_repr_function(1, [(str, 'else')]) == repr



# Generated at 2022-06-10 21:47:36.683668
# Unit test for function get_repr_function
def test_get_repr_function():
    # Testing a single repr function
    item = []
    assert get_repr_function(item, [(list, lambda x: 'list')])() == 'list'
    item = ()
    assert get_repr_function(item, [(list, lambda x: 'list')])() == "()"

    # Testing two repr functions
    item = []
    assert (get_repr_function(item, [(list, lambda x: 'list'),
                                     (set, lambda x: 'set')]))() == 'list'
    item = set()
    assert (get_repr_function(item, [(list, lambda x: 'list'),
                                     (set, lambda x: 'set')]))() == 'set'
    item = ()

# Generated at 2022-06-10 21:47:45.868330
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(object):
        def write(self, s):
            pass

    class Y(object):
        def write(self):
            pass

    class Z(object):
        def foo(self, s):
            pass

    x = X()
    y = Y()
    z = Z()

    assert isinstance(x, WritableStream)
    assert not isinstance(y, WritableStream)
    assert not isinstance(z, WritableStream)


# Generated at 2022-06-10 21:47:53.376246
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, ((int, lambda x: 'int!'))) == 'int!'
    assert get_repr_function(5, ((int, lambda x: 'int!'), (str, 'string!'))) \
                                                                         == 'int!'
    assert get_repr_function('hello', ((str, 'string!'), (int, 'int!'))) == 'string!'
    assert get_repr_function('hello', ((int, 'int!'), (float, 'float!'))) == repr

# Generated at 2022-06-10 21:47:56.681221
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('foo') == 'foo'
    assert shitcode(u'foo') == 'foo'
    assert shitcode('föo') == 'f??o'
    assert shitcode(u'föo') == 'f??o'
    assert shitcode(u'א') == '?'

# Generated at 2022-06-10 21:47:59.394904
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MockStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(MockStream(), WritableStream)

# Generated at 2022-06-10 21:48:05.637752
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, str.upper), (str, str.lower))) == str
    assert get_repr_function('1', ((int, str.upper), (str, str.lower))) == str.lower
    assert get_repr_function(1.0, ((int, str.upper), (str, str.lower))) == repr



# Generated at 2022-06-10 21:48:10.819353
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .stdout_capturing import StdoutCapturing

    class Stdout(WritableStream):
        def write(self, s):
            sys.stdout.write(s)

    with StdoutCapturing():
        Stdout().write('hello')



# Generated at 2022-06-10 21:48:21.964578
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .testing import TestCase, assert_equal
    from .testing import assert_same_items as assert_same
    from .testing import assert_startswith
    from .testing import assert_endswith

    class MyClass(object):
        def __init__(self, x):
            self.x = x

    assert_startswith(get_shortish_repr('foo'), 'foo')
    assert_startswith(get_shortish_repr('f' * 2000), 'ffffffff')
    assert_endswith(get_shortish_repr('foo'), 'foo')
    assert_endswith(get_shortish_repr('f' * 2000), 'fffff')

    assert_equal(
        get_shortish_repr('foo', max_length=None),
        'foo'
    )



# Generated at 2022-06-10 21:48:27.753515
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello', max_length=4) == 'hel...'
    assert get_shortish_repr('hello', max_length=4, normalize=True) == 'hel...'
    assert get_shortish_repr([1, (2, 3)], max_length=9) == '[1, (2, 3)]'



# Generated at 2022-06-10 21:48:35.653858
# Unit test for function get_repr_function
def test_get_repr_function():
    assert(get_repr_function('foo', (('', lambda x: x.upper()),))
                                                               == 'FOO')

    assert(get_repr_function('foo', ((lambda x: len(x) == 3,
                                      lambda x: x.upper()),))
                                                               == 'FOO')

    assert(get_repr_function('foo', ((lambda x: len(x) == 2,
                                      lambda x: x.upper()),))
                                                               == repr)

    assert(get_repr_function(1, ((int, lambda x: x.upper()),))
                                                               == 'FOO')

    assert(get_repr_function('foo', ((int, lambda x: x.upper()),))
                                                               == repr)



# Generated at 2022-06-10 21:48:44.901575
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # my_repr is used to test the `custom_repr` arg
    def my_repr(x):
        return 'myrepr({})'.format(x)

    assert get_shortish_repr(42) == '42'
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr(object()) == '???'
    assert get_shortish_repr(42, max_length=2) == '42'
    assert get_shortish_repr(42, max_length=3) == '42'
    assert get_shortish_repr(42, max_length=4) == '42'
    assert get_shortish_repr(42, max_length=5) == '42'

# Generated at 2022-06-10 21:48:52.857087
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    class B(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)



# Generated at 2022-06-10 21:48:56.024611
# Unit test for function get_repr_function
def test_get_repr_function():
    def f(x):
        return x
    assert get_repr_function(None, ((str, f),)) is f
    assert get_repr_function(None, ((str, f), (type(None), int))) is int



# Generated at 2022-06-10 21:49:02.163624
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, str),)) == repr
    assert get_repr_function(1.4, ((int, str),)) == str
    def my_repr(x):
        return u"My repr of {}".format(x)
    assert get_repr_function(1.4, ((float, my_repr),)) == my_repr

# Generated at 2022-06-10 21:49:12.653465
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class One(WritableStream):
        def write(self, s):
            pass

    assert isinstance(One(), WritableStream)

    class Two(WritableStream):
        def write(self, s):
            pass

        def __subclasshook__(cls, C):
            return True

    assert isinstance(Two(), WritableStream)

    class Three(WritableStream):
        def write(self, s):
            pass

        def __subclasshook__(cls, C):
            if cls is WritableStream:
                return _check_methods(C, 'write')
            return NotImplemented

    assert isinstance(Three(), WritableStream)

    class Four(WritableStream):
        def __subclasshook__(cls, C):
            if cls is WritableStream:
                return _check

# Generated at 2022-06-10 21:49:20.576015
# Unit test for function get_repr_function
def test_get_repr_function():
    assert normalize_repr('<string at 0x7fbb14e17128>') == '<string>'

    class A(object): pass
    a = A()
    class B(A): pass
    b = B()
    assert get_repr_function(a, ((A, lambda a: 'A'))) == repr
    assert get_repr_function(b, ((A, lambda a: 'A'))) == repr
    assert get_repr_function(a, ((A, lambda a: 'A'), (B, lambda b: 'B'))) == \
                                                                      repr
    assert get_repr_function(b, ((A, lambda a: 'A'), (B, lambda b: 'B'))) == \
                                                                       repr

# Generated at 2022-06-10 21:49:30.936504
# Unit test for function get_repr_function
def test_get_repr_function():

    def repr_none(x):
        assert x is None
        return 'NONE'

    def repr_int(x):
        assert isinstance(x, int)
        return 'INT'

    def repr_int_repr(x):
        assert isinstance(x, int)
        return '{}'.format(repr(x))

    def repr_str(x):
        assert isinstance(x, str)
        return 'STR'

    def repr_float(x):
        assert isinstance(x, float)
        return 'FLOAT'

    def repr_list(x):
        assert isinstance(x, list)
        return 'LIST'

    def repr_set(x):
        assert isinstance(x, set)
        return 'SET'


# Generated at 2022-06-10 21:49:39.352369
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert (get_shortish_repr(set([1, 2, 3])) ==
            "set([1, 2, 3])")

    class A(object):
        def __repr__(self):
            return 'hi'
    assert (get_shortish_repr(A()) == "hi")
    assert (get_shortish_repr(A(), custom_repr=[(A, lambda x: 'bye')]) == "bye")
    assert (get_shortish_repr(A(), custom_repr=[(A, lambda x: 1 / 0)]) ==
            "REPR FAILED")

# Generated at 2022-06-10 21:49:50.381216
# Unit test for function get_repr_function
def test_get_repr_function():
    class X: pass
    x = X()
    class Y: pass
    y = Y()
    custom_repr = (
        (X, lambda item: 'X'),
        (Y, lambda item: 'Y'),
        (lambda item: isinstance(item, str), lambda item: '|' + item + '|'),
    )
    assert get_repr_function(x, custom_repr=custom_repr)(x) == 'X'
    assert get_repr_function(y, custom_repr=custom_repr)(y) == 'Y'
    assert get_repr_function('abc', custom_repr=custom_repr)('abc') == '|abc|'
    assert get_repr_function('abc', custom_repr=None)('abc') == repr('abc')


# Unit

# Generated at 2022-06-10 21:49:59.060158
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcdefg', max_length=3) == 'abc'
    assert get_shortish_repr('abcdefg', max_length=None) == 'abcdefg'
    assert get_shortish_repr('abcdefg', max_length=10) == 'abcdefg'
    assert get_shortish_repr('abcdefg', max_length=6) == 'abc...'
    assert get_shortish_repr('abcdefg', max_length=7) == 'abc...'
    assert get_shortish_repr('abcdefg', max_length=8) == 'abc...g'
    assert get_shortish_repr('abcd efg', max_length=8) == 'abcd...'

# Generated at 2022-06-10 21:50:04.417408
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(Exception) == 'exceptions.Exception'
    assert get_shortish_repr(Exception(), max_length=28) == (
                                             'Exception() at 0x0...0x0')
    assert get_shortish_repr(Exception(), max_length=28, normalize=True) == (
                                                                   'Exception()')



# Generated at 2022-06-10 21:50:16.940558
# Unit test for function get_repr_function
def test_get_repr_function():
    def _test(item, custom_repr, expected_result):
        assert get_repr_function(item, custom_repr) == expected_result

    _test('abc', [], repr)
    _test('abc', [
        (lambda x: True, bool),
        (lambda x: False, float),
    ], bool)

    _test(1, [], repr)
    _test(1, [
        (lambda x: True, bool),
        (lambda x: False, float),
    ], bool)

    _test('abc', [
        (1, bool),
        (lambda x: False, float),
    ], bool)

    _test(1, [
        (1, bool),
        (False, float),
    ], bool)


# Generated at 2022-06-10 21:50:23.361939
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_data = b''
        def write(self, s):
            self.written_data += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write(b'hello')
    assert my_writable_stream.written_data == b'hello'

# Generated at 2022-06-10 21:50:29.725791
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, (lambda x: True, lambda x: 'Yes!')) == 'Yes!'
    assert get_repr_function(5, ((lambda x: x == 3, lambda x: 'Yes!'),)) == repr
    assert get_repr_function('yo', ((str, lambda x: 'Yes!'),)) == 'Yes!'
    assert get_repr_function(None, ((type(None), lambda x: 'Yes!'),)) == 'Yes!'
    assert get_repr_function([1,3,3], (list, lambda x: 'Yes!')) == 'Yes!'



# Generated at 2022-06-10 21:50:35.209527
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1.0, ()) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hai')]) == 'hai'
    assert get_repr_function(1, [(1, lambda x: 'hai')]) == 'hai'
    assert get_repr_function(1.3, [(1, lambda x: 'hai')]) is repr
    assert get_repr_function(1.0, [(lambda x: True, lambda x: 'hai')]) == 'hai'
    assert get_repr_function(1, [(1, lambda x: 'hai')]) == 'hai'
    assert get_repr_function(1, [(1, lambda x: 'hai')]) == 'hai'
    assert get

# Generated at 2022-06-10 21:50:46.079497
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import random, string
    import pytest


    def test_repr(item, expected_repr):
        assert get_shortish_repr(item) == expected_repr

    test_repr(1, '1')
    test_repr('abc', "'abc'")
    test_repr('a' * 99, "'a" * 99 + "'")
    test_repr('a' * 100, "'" + "a" * 97 + "...'")
    test_repr('a' * 101, "'" + "a" * 97 + "...'")
    test_repr(string.ascii_letters, repr(string.ascii_letters))

    test_repr(_my_object(), 'my object!')


# Generated at 2022-06-10 21:50:51.075754
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MockWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MockWritableStream, WritableStream)

    class NonMockWritableStream(WritableStream):
        pass

    assert not issubclass(NonMockWritableStream, WritableStream)



# Generated at 2022-06-10 21:51:03.596777
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('') == r"''"
    assert get_shortish_repr('1') == r"'1'"
    assert get_shortish_repr('12') == r"'12'"
    assert get_shortish_repr('123') == r"'123'"
    assert get_shortish_repr('1234') == r"'1234'"
    assert get_shortish_repr('1234', max_length=3) == r"'123'"
    assert get_shortish_repr('12345678', max_length=5) == r"'1...8'"
    assert get_shortish_repr('12345678', max_length=6) == r"'12...8'"

# Generated at 2022-06-10 21:51:09.869138
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestWritableStream(WritableStream):
        def __init__(self):
            self.write_calls = []
        def write(self, s):
            self.write_calls.append(s)

    test_writable_stream = TestWritableStream()
    test_writable_stream.write('foo')
    test_writable_stream.write('bar')
    assert test_writable_stream.write_calls == ['foo', 'bar']



# Generated at 2022-06-10 21:51:19.452809
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(b'hello') == "b'hello'"
    assert get_shortish_repr(['hello', 'world']) == "['hello', 'world']"
    assert get_shortish_repr(['hello', 'world'], max_length=12) == \
                                                              "['hello',..."
    assert get_shortish_repr(['hello', 'world'], max_length=11) == "['h..."
    assert get_shortish_repr(['hello', 'world'], max_length=10) == "['..."
    assert get_shortish_repr(['hello', 'world'], max_length=9) == "[..."
    assert get_shortish_repr(['hello', 'world'], max_length=8) == "[..."
    assert get_

# Generated at 2022-06-10 21:51:24.447042
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from io import StringIO
    io = StringIO()
    writable_stream = WritableStream()
    writable_stream.write = lambda s: io.write(s)

    def ws_write(s):
        writable_stream.write(s)

    ws_write('foo')
    ws_write('bar')
    assert io.getvalue() == 'foobar'

# Generated at 2022-06-10 21:51:34.352947
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_data = b''
        def write(self, s):
            self.written_data += s

    o = MyWritableStream()

    assert o.writable() is True



# Generated at 2022-06-10 21:51:41.011960
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyWritableStream(WritableStream):

        def __init__(self):
            self.written = []

        def write(self, s):
            self.written.append(s)

        def __bool__(self):
            return True

        def __nonzero__(self): # Python 2
            return True

    stream = MyWritableStream()
    stream.write('Hi')
    assert stream.written == ['Hi']



# Generated at 2022-06-10 21:51:45.505460
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1) is repr
    assert get_repr_function('a') is repr
    assert get_repr_function(1, ((int, str), lambda x: 'hi')) == 'hi'



# Generated at 2022-06-10 21:51:53.696489
# Unit test for function get_shortish_repr

# Generated at 2022-06-10 21:52:01.595035
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert 'test' == \
           get_shortish_repr('test', max_length=None)
    assert 'test' == \
           get_shortish_repr('test', max_length=4)
    assert 'te...st' == \
           get_shortish_repr('test', max_length=7)
    assert 'tes...est' == \
           get_shortish_repr('test', max_length=8)


# Generated at 2022-06-10 21:52:10.235071
# Unit test for function get_repr_function
def test_get_repr_function():
    def square_repr(x):
        return 'squared: {!r}'.format(x**2)
    custom_repr = (
        (int, square_repr),
    )

    assert get_repr_function(4, custom_repr) is square_repr
    assert get_repr_function('hello', custom_repr) is repr
    assert get_repr_function(None, custom_repr) is repr
    assert get_repr_function(lambda: None, custom_repr) is repr



# Generated at 2022-06-10 21:52:11.649958
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'hello \u2713') == 'hello \xfffd'



# Generated at 2022-06-10 21:52:14.063063
# Unit test for function shitcode
def test_shitcode():
    test = "123ÎŚć"
    result = "123\xef\x9f\x8a"
    assert shitcode(test) == result

# Generated at 2022-06-10 21:52:23.946409
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    def write(s):
        raise NotImplementedError()

    class A(WritableStream):
        pass

    class B(A):
        pass

    assert not issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)
    b = B()
    b.write = write
    b.write('spam')

    class C(WritableStream):
        def write(self, s):
            raise NotImplementedError()

    class D(C):
        def write(self, s):
            pass

    assert issubclass(C, WritableStream)
    assert issubclass(D, WritableStream)



# Generated at 2022-06-10 21:52:33.492992
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import numbers

    class MyInt(int): pass
    class MyIntSubclass(MyInt): pass
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(MyInt(1)) == 'MyInt(1)'
    assert get_shortish_repr(MyIntSubclass(1)) == 'MyIntSubclass(1)'
    assert get_shortish_repr('asd') == "'asd'"
    assert get_shortish_repr('a' * 100) == "'" + 'a' * 97 + "...'"
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=2, normalize=True) == '1'
    assert get_shortish_repr

# Generated at 2022-06-10 21:52:57.307270
# Unit test for function get_repr_function
def test_get_repr_function():
    assert (get_repr_function(1, [(lambda x: x == 2, lambda x: 'two'),
                                  (lambda x: x == 3, lambda x: 'three'),
                                  (lambda x: x == 4, 2)]) ==
            get_repr_function(1, [(re.compile(x), y) for x, y in [
                (r'2', lambda x: 'two'),
                (r'3', lambda x: 'three'),
                (r'4', 2)
            ]]))
    assert get_repr_function(1, [(1, 2)]) == repr
    assert get_repr_function(2, [(1, 2), (2, 3)]) == 3
    assert get_repr_function(3, [(1, 2), (4, 3)]) == repr
    assert get

# Generated at 2022-06-10 21:53:00.496578
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr(int) == '<class \'int\'>'
    assert get_shortish_repr('my string') == "'my string'"



# Generated at 2022-06-10 21:53:10.917689
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int: ' + str(x))]) == 'int: 1'
    assert get_repr_function(3.4, [(int, lambda x: 'int: ' + str(x))]) != 'int: 3.4'
    assert get_repr_function(3.4, [(int, lambda x: 'int: ' + str(x))]) == repr(3.4)
    assert get_repr_function(
        3.4,
        [(int, lambda x: 'int: ' + str(x)),
         lambda x: isinstance(x, float),
         lambda x: 'float: ' + str(x)]
    ) == 'float: 3.4'



# Generated at 2022-06-10 21:53:19.811766
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(C): pass

    custom_repr = [
        (lambda x: isinstance(x, B), lambda x: 'B'),
        (lambda x: isinstance(x, C), lambda x: 'C'),
        (lambda x: True, lambda x: 'all others')
    ]

    t = lambda x: get_repr_function(x, custom_repr)

    assert t(A()) == 'all others'
    assert t(B()) == 'B'
    assert t(D()) == 'C'
    assert t(C()) == 'C'
    assert t(123) == 'all others'



# Generated at 2022-06-10 21:53:31.946719
# Unit test for function get_repr_function
def test_get_repr_function():

    class X(object):
        pass

    class Y(X):
        pass

    def is_y(x):
        return isinstance(x, Y)

    def is_x(x):
        return isinstance(x, X)

    def is_int(x):
        return isinstance(x, int)

    x = X()
    y = Y()
    z = X()

    assert get_repr_function(x, ((is_y, id), (is_x, ord))) == ord
    assert get_repr_function(y, ((is_y, id), (is_x, ord))) == id
    assert get_repr_function(z, ((is_y, id), (is_x, ord))) == ord

# Generated at 2022-06-10 21:53:35.859472
# Unit test for function shitcode
def test_shitcode():
    assert shitcode("שלום") == "??"
    assert shitcode("שלום") != "שלום"
    assert shitcode("zxcvbnm") == "zxcvbnm"



# Generated at 2022-06-10 21:53:42.777607
# Unit test for function get_repr_function
def test_get_repr_function():
    import pickle
    class C(object):
        def __init__(self, x):
            self.x = x
        def __repr__(self):
            return 'C! x={!r}'.format(self.x)
    class D(C):
        pass
    assert get_repr_function(D(1), ()) == repr
    assert get_repr_function(C(1), ()) == repr
    assert get_repr_function(D(1), ((D, str),)) == str
    assert get_repr_function(C(1), ((D, str),)) == repr
    assert get_repr_function(D(1), ((C, str),)) == str
    assert get_repr_function(C(1), ((C, str),)) == str
    c = C(1)
   

# Generated at 2022-06-10 21:53:54.924150
# Unit test for function get_repr_function
def test_get_repr_function():
    def custom_repr(x):
        return 'custom repr for {}'.format(x)
    assert get_repr_function('spam', ()) is repr
    assert get_repr_function('spam', [(str, custom_repr)]) is custom_repr
    assert get_repr_function(5, [(str, custom_repr)]) is repr
    assert get_repr_function('spam', [
        (lambda x: isinstance(x, str), custom_repr),
    ]) is custom_repr
    assert get_repr_function('spam', [
        (lambda x: isinstance(x, str), custom_repr),
        (lambda x: True, repr)
    ]) is custom_repr

# Generated at 2022-06-10 21:54:00.868966
# Unit test for function get_repr_function
def test_get_repr_function():
    
    class class_a(object): pass
    
    class class_b(object): pass
    
    a = class_a()
    b = class_b()
    
    assert get_repr_function(a, custom_repr=((class_a, 'bla'),)) == 'bla'
    assert get_repr_function(b, custom_repr=((class_a, 'bla'),)) == repr

    
    
if __name__ == '__main__':
    test_get_repr_function()

# Generated at 2022-06-10 21:54:09.396376
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(23, []) is repr
    assert get_repr_function(23, [(int, 'int')]) == 'int'
    assert get_repr_function(23, [((str, list), 'str')]) == 'str'
    assert get_repr_function(23, [((str, list), 'str'), (int, 'int')]) == 'int'
    assert get_repr_function(23, [(lambda x: True, 'yes')]) == 'yes'
    assert get_repr_function(23, [(lambda x: False, 'yes')]) is repr

if sys.version_info[0] == 2:
    def open_stream(stream, mode='r'):
        if isinstance(stream, file):
            return stream

# Generated at 2022-06-10 21:54:44.653501
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(object):
        def write(self, s): pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(object):
        pass
    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(object):
        def write(self, s): pass
        def method(self): pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(object):
        def write(self, s): pass
        def write(self, s): raise NotImplementedError
    assert not issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-10 21:54:50.957613
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Child:
        def write(self, s):
            pass

    class BadChild1:
        pass

    class BadChild2:
        def __init__(self, x):
            pass

    assert issubclass(Child, WritableStream)
    assert not issubclass(BadChild1, WritableStream)
    assert not issubclass(BadChild2, WritableStream)

# Generated at 2022-06-10 21:54:58.630716
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class WritableStreamDummy(WritableStream):
        def write(self, s):
            return s

    WritableStreamDummy().write('')

    try:
        class WritableStreamSubclass(WritableStreamDummy):
            pass

        WritableStreamSubclass()
    except TypeError as e:
        if str(e) != 'Can\'t instantiate abstract class ' \
                     'WritableStreamSubclass with abstract methods write':
            raise

# Generated at 2022-06-10 21:55:03.371845
# Unit test for function get_repr_function
def test_get_repr_function():

    assert get_repr_function('foo', ()) == repr
    assert get_repr_function(22, ()) == repr
    assert get_repr_function('foo', ((str, 1),)) == 1
    assert get_repr_function(22, ((str, 1),)) == repr

# Generated at 2022-06-10 21:55:13.772507
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class D(object):
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)
    class E(object):
        pass
    assert not issubclass(E, WritableStream)
    class F:
        def write(self, s):
            pass
    assert issubclass(F, WritableStream)
    class G:
        pass
    assert not issubclass(G, WritableStream)
    class H(D, F):
        pass
    assert issubclass(H, WritableStream)



if __name__ == '__main__':
    test_WritableStream_write()