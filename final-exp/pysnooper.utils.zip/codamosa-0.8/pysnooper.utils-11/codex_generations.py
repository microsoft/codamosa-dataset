

# Generated at 2022-06-10 21:45:19.848502
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(4, ()) == repr
    assert get_repr_function((1, 2), ((lambda x: True, lambda x: x))) == (1, 2)
    assert get_repr_function(
        (1, 2),
        ((lambda x: x == (1, 2), lambda x: x),)
    ) == (1, 2)
    assert get_repr_function(
        (1, 2),
        (((1, 2), lambda x: x),)
    ) == (1, 2)



# Generated at 2022-06-10 21:45:22.448088
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        def write(self, junk):
            pass
    assert issubclass(Foo, WritableStream)



# Generated at 2022-06-10 21:45:28.320518
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hi there', ((str, str.upper),)) == str.upper
    assert get_repr_function('hi there', ((int, str.upper),)) == repr
    assert get_repr_function('hi there', ((int, str.upper),
                                          (str, str.lower))) == str.lower



# Generated at 2022-06-10 21:45:40.302492
# Unit test for function get_repr_function
def test_get_repr_function():
    # We'll test with a number of different types, each with a different
    # representation.
    class A:
        pass
    class B(A):
        pass
    class C:
        pass

    for item in [
        A(),
        B(),
        C(),
        [],
        (),
        {},
        1,
        1.0,
        u'',
        b'',
        sys.maxsize,
        sys.maxint,
        sys.maxsize + 1,
        NotImplemented,
    ]:
        normal_repr = repr(item)
        assert get_repr_function(item)() == normal_repr
        assert get_repr_function(item, custom_repr=[])() == normal_repr


# Generated at 2022-06-10 21:45:42.066980
# Unit test for function shitcode
def test_shitcode():
    s = 'hello שלום'
    assert shitcode(s) == 'hello ?'

# Generated at 2022-06-10 21:45:45.500749
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .file_system_tools import write_to_temp_file

    class NewClass(WritableStream):
        def write(self, s):
            pass
    try:
        assert issubclass(NewClass, WritableStream)
    finally:
        del NewClass

# Generated at 2022-06-10 21:45:50.478265
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        written_lines = []
        def write(self, s):
            self.written_lines.append(s)

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hey')
    assert my_writable_stream.written_lines == ['hey']

# Generated at 2022-06-10 21:45:54.587535
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Stream(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, string):
            self.s += string
    stream = Stream()
    stream.write('spam')
    assert stream.s == 'spam'

# Generated at 2022-06-10 21:45:56.810650
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'unicode string') == u'unicode string'
    assert shitcode(u'unicode string with \u20ac') == \
                                              u'unicode string with ?'
    assert shitcode(b'\xff') == '?'

# Generated at 2022-06-10 21:45:58.789371
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C(WritableStream):
        def write(self, s):
            return s

    c = C()
    assert c.write('abc') == 'abc'





# Generated at 2022-06-10 21:46:12.699393
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass
    b = B()

    custom_repr = (
        ((lambda x: x==b), repr),
        ((lambda x: x=='c'), repr),
    )
    assert get_repr_function(b, custom_repr) == repr
    assert get_repr_function('a', custom_repr) != repr
    custom_repr = (
        ((lambda x: x==('a', 'b')), repr),
        ((lambda x: x=='c'), repr),
    )
    assert get_repr_function(('a', 'b'), custom_repr) == repr
    assert get_repr_function('a', custom_repr) != repr

# Generated at 2022-06-10 21:46:25.004490
# Unit test for function get_repr_function
def test_get_repr_function():
    class X: pass
    class Y: pass
    class Z(X, Y): pass
    z = Z()
    custom_repr = (
        (lambda x: isinstance(x, int), lambda x: str(x) + '.'),
        ((X, Y), lambda x: 'longer than default repr'),
        (Z, lambda x: 'this will not be used'),
    )
    assert get_repr_function('', custom_repr) == repr

# Generated at 2022-06-10 21:46:33.452371
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (('hi', lambda x: x))) == repr

# Generated at 2022-06-10 21:46:40.110524
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(get_shortish_repr, max_length=None) == \
                                          "get_shortish_repr(get_shortish_repr)"
    assert get_shortish_repr(get_shortish_repr, max_length=None, normalize=True) == \
                                                   "get_shortish_repr"
    assert get_shortish_repr(get_shortish_repr, max_length=4) == \
                                                   "get_..."
    assert get_shortish_repr(get_shortish_repr, max_length=4, normalize=True) == \
                                                        "ge..."

# Generated at 2022-06-10 21:46:51.130485
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from itertools import count
    class ReprFailer(object):
        def __init__(self):
            self.counter = count()
        def __repr__(self):
            self.counter.next()
            if self.counter.next() == 3:
                raise Exception
            return 'success' * 1000
    assert get_shortish_repr(ReprFailer(), normalize=True) == 'REPR FAILED'
    assert get_shortish_repr(ReprFailer(), normalize=True) == 'REPR FAILED'
    assert get_shortish_repr(ReprFailer(), normalize=True) == 'REPR FAILED'

# Generated at 2022-06-10 21:47:01.134910
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C: pass
    class D: pass
    obj1 = A()
    obj2 = B()
    obj3 = C()
    obj4 = D()
    custom_repr = (
        (lambda x: isinstance(x, A), shitcode),
        (B, lambda x: 'B{}'.format(len(str(x)))),
        (type(obj3), lambda x: 'C*' + str(x)),
        (type, lambda x: type(x).__name__)
    )
    assert get_repr_function(obj1, custom_repr) == shitcode

# Generated at 2022-06-10 21:47:11.712434
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\nb') == 'a\nb'
    assert shitcode(u'a\u200bb') == u'a\u200bb'
    assert shitcode('a\u200bb') == 'a\u200bb'
    assert shitcode(u'a\nb') == u'a\nb'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode(u'a\x00b') == u'a?b'
    assert shitcode('a\x81b') == 'a?b'
    assert shitcode(u'a\x81b') == u'a?b'



# Generated at 2022-06-10 21:47:21.321681
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MockFile(WritableStream):
        def __init__(self):
            self.data = ''
        def write(self, s):
            self.data += s
        def __repr__(self):
            return '<MockFile: %r>' % (self.data)

    mock_file = MockFile()
    mock_file.write('foo\n')
    mock_file.write('bar\n')
    assert repr(mock_file) == "<MockFile: 'foo\\nbar\\n'>".encode('utf-8')



# Generated at 2022-06-10 21:47:31.895459
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcabcabcabcabcabcabc123123123123') == (
        'abcabcabcabcabcabcabc123123123123'
    )
    assert get_shortish_repr('abcabcabcabcabcabcabc123123123123', max_length=30) == (
        'abcabcabcabcabcabcabc12312312...'
    )
    assert get_shortish_repr('abcabcabcabcabcabcabc123123123123', max_length=1) == (
        'a...'
    )
    assert get_shortish_repr('abcabcabcabcabcabcabc123123123123', max_length=0) == (
        '...'
    )

# Generated at 2022-06-10 21:47:38.872189
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            assert isinstance(s, basestring)
            self.written += s
    stream = MyWritableStream()
    stream.write('spam')
    stream.write('eggs')
    assert stream.written == 'spameggs'




# Generated at 2022-06-10 21:47:53.160301
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('meow') == 'meow'
    assert get_shortish_repr('meow', max_length=0) == ''
    assert get_shortish_repr('meow', max_length=1) == 'm...'
    assert get_shortish_repr('meow', max_length=2) == 'm...'
    assert get_shortish_repr('meow', max_length=3) == 'm...'
    assert get_shortish_repr('meow', max_length=4) == 'meow'
    assert get_shortish_repr('meow', max_length=5) == 'meow'
    assert get_shortish_repr('meow', max_length=6) == 'meow'
    assert get_shortish_re

# Generated at 2022-06-10 21:48:02.700116
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from . import case_tagged
    from . smart_repr import smart_repr

    assert get_shortish_repr(
        'abc',
        max_length=None
    ) == 'abc'
    assert get_shortish_repr(
        'abc',
        max_length=3
    ) == 'abc'
    assert get_shortish_repr(
        'abc',
        max_length=2
    ) == 'ab'
    assert get_shortish_repr(
        'abc',
        max_length=1
    ) == 'a'
    assert get_shortish_repr(
        'abc',
        max_length=0
    ) == ''
    assert get_shortish_repr(
        'abc',
        max_length=4
    ) == 'abc'

# Generated at 2022-06-10 21:48:15.345152
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, ()) is repr
    assert get_repr_function([], (lambda x: x == [], lambda x: 'hi')) is \
                                                                     (lambda x: 'hi')
    assert get_repr_function(1.2, (int, lambda x: 'hi')) is repr
    assert get_repr_function(3, ((lambda x: x == 3, ('nice',)), (list,
                                                                lambda x: 'hi'))) is repr
    assert get_repr_function(1.2, (list, lambda x: 'hi')) is repr
    assert get_repr_function(1.2, (list, lambda x: 'hi')) is repr
    assert get_repr_function(1.2, (dict, lambda x: 'hi')) is repr

# Generated at 2022-06-10 21:48:20.058836
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [(lambda x: hasattr(x, 'kitties'), str)]
    assert get_repr_function('foo', custom_repr) == str
    assert get_repr_function(12, custom_repr) == repr



# Generated at 2022-06-10 21:48:26.343792
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(io.StringIO, WritableStream)

    assert issubclass(MyWritableStream, WritableStream)

    class BadWritableStream(WritableStream): pass
    assert not issubclass(BadWritableStream, WritableStream)

# Generated at 2022-06-10 21:48:29.533262
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import unittest
    class Test(WritableStream):
        def __init__(self):
            self.io = io.StringIO()

        def write(self, s):
            self.io.write(s)

    test = Test()
    test.write('hello')
    assert test.io.getvalue() == 'hello'
    assert isinstance(test, WritableStream)
    assert not issubclass(int, WritableStream)
    assert issubclass(Test, WritableStream)



# Generated at 2022-06-10 21:48:36.438430
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo(object):
        pass
    class Bar(object):
        pass

    def bar_repr(x):
        return 'bar repr of ' + repr(x)
    foo = Foo()
    bar = Bar()
    assert get_repr_function(foo, custom_repr=[
        (Foo, bar_repr),
    ]) == bar_repr
    assert get_repr_function(bar, custom_repr=[
        (Foo, bar_repr),
    ]) == repr
    assert get_repr_function(
        bar, custom_repr=[
            (lambda x: True, bar_repr),
        ]
    ) == bar_repr
    assert get_repr_function(foo, custom_repr=[]) == repr



# Generated at 2022-06-10 21:48:45.359107
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object):
        pass

    class B(object):
        pass

    class C(object):
        pass

    assert get_repr_function(A(), (
        (lambda x: x is A, lambda x: 'spam')))

    assert get_repr_function(B(), (
        (lambda x: x is A, lambda x: 'spam')))

    assert get_repr_function(C(), (
        (lambda x: x is A, lambda x: 'spam')))

    assert isinstance(
        get_repr_function(A(), (
            (lambda x: x is A, lambda x: 'spam'))),
        type(lambda x: x)
    )


# Generated at 2022-06-10 21:48:56.184734
# Unit test for function get_repr_function
def test_get_repr_function():
    d = 'ram'
    assert get_repr_function(d, custom_repr=[]) == repr
    assert get_repr_function(d, custom_repr=[(str, str)]) == str
    assert get_repr_function(d, custom_repr=[(str, str), (str, str)]) == str
    assert get_repr_function(d, custom_repr=[(int, int)]) == repr
    assert get_repr_function(d, custom_repr=[(lambda s: s, 1)]) == repr
    assert get_repr_function(d, custom_repr=[(lambda s: True, 1)]) == 1
    assert get_repr_function(d, custom_repr=[(str, int), (int, int)]) == int

# Generated at 2022-06-10 21:49:04.855223
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(metaclass=ABCMeta):
        @abc.abstractmethod
        def write(self, x):
            pass

    class B(A):
        def write(self, x):
            pass

    class C(B):
        pass

    b = B()
    assert isinstance(b, WritableStream)
    c = C()
    assert isinstance(c, WritableStream)

    class D(A):
        def write(self, x):
            pass

        def flush(self, x):
            pass

    d = D()
    assert not isinstance(d, WritableStream)



# Generated at 2022-06-10 21:49:16.649418
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, []) is repr
    assert get_repr_function(3, [(int, str)]) is str
    assert get_repr_function(3.3, [(int, str)]) is repr
    assert get_repr_function(int, [(int, str)]) is str
    assert get_repr_function(int, [(int, str), (float, unicode)]) is str
    assert get_repr_function(13, [(lambda x: isinstance(x, int) and x == 13,
                                   str)]) is str
    assert get_repr_function(13, [(lambda x: isinstance(x, int) and x == 14,
                                   str)]) is repr



# Generated at 2022-06-10 21:49:20.239499
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        pass
    f = Foo()
    f.write = lambda s: sys.stdout.write(s)
    assert isinstance(f, WritableStream)

# Generated at 2022-06-10 21:49:30.621304
# Unit test for function get_repr_function
def test_get_repr_function():

    class A(object): pass
    class B(object):
        def __repr__(self):
            return '<B>'
    class C(A, B): pass
    class D(A, B):
        def __repr__(self):
            return 'hello'

    assert get_repr_function(A(), ((A, '<A>'), (B, '<B>')))() == '<A>'
    assert get_repr_function(B(), ((A, '<A>'), (B, '<B>')))() == '<B>'
    assert get_repr_function(C(), ((A, '<A>'), (B, '<B>')))() == '<A>'

# Generated at 2022-06-10 21:49:41.808618
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('123') == '123'
    assert get_shortish_repr('12345') == '12345'
    assert get_shortish_repr('123456') == '123456'
    assert get_shortish_repr('1234567') == '1234567'
    assert get_shortish_repr('12345678', normalize=True) == '12345678'

    assert get_shortish_repr('123456789', max_length=10) == '123456789'
    assert get_shortish_repr('1234567890', max_length=10) == '1234567...0'
    assert get_shortish_repr('1234567890', max_length=10, normalize=True) == '1234567...0'
    assert get

# Generated at 2022-06-10 21:49:52.643547
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(object):
        def write(self, s):
            pass
    class B(object):
        def write(self, s):
            pass
    class C(A, B):
        pass
    class D(A):
        def write(self, s):
            pass
    class E(A):
        pass
    E.write = None
    class F(C, D, E):
        pass
    class G(B):
        pass
    class H(A):
        pass
    class I(F, G, H):
        pass
    assert issubclass(WritableStream, A)
    assert issubclass(WritableStream, B)
    assert issubclass(WritableStream, C)
    assert issubclass(WritableStream, D)
    assert issubclass(WritableStream, E)


# Generated at 2022-06-10 21:50:00.442845
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[]) == repr
    assert get_repr_function('string', custom_repr=[]) == repr
    assert get_repr_function(
        1, custom_repr=[(lambda x: x < 0, lambda x: 'negative')]
    ) == repr

# Generated at 2022-06-10 21:50:03.726381
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyWritableStream(WritableStream):
        def write(self, stuff):
            wrote.append(stuff)
    wrote = []
    DummyWritableStream().write('hey')
    assert wrote == ['hey']

# Generated at 2022-06-10 21:50:15.141371
# Unit test for function get_repr_function
def test_get_repr_function():
    class C(object): pass
    class D(C): pass
    c = C()
    d = D()

    custom_repr = (
        (C, lambda c: 'A C object'),
        (lambda x: isinstance(x, C), lambda c: 'A C instance'),
        (lambda x: x == c, lambda c: 'The C instance'),
        (C(), lambda c: 'A C instance'),
        (D, lambda d: 'A D object'),
        (lambda x: isinstance(x, D), lambda d: 'A D instance'),
        (lambda x: x == d, lambda d: 'The D instance'),
        (D(), lambda d: 'A D instance'),
    )

    assert get_repr_function(c, custom_repr) == (lambda c: 'A C object')
    assert get

# Generated at 2022-06-10 21:50:26.790265
# Unit test for function get_repr_function
def test_get_repr_function():
    l = [(1,), (1,), (1,), (1,), (1,), (1,), (1,), (1,), (1,), (1,),
         (1,), (1,), (1,), (1,), (1,), (1,), (1,), (1,), (1,), (1,),
         (1,), (1,), (1,), (1,), (1,), (1,), (1,), (1,), (1,), (1,)]
    assert len(l) == 30
    assert get_repr_function(l, [(lambda x: isinstance(x, list), id)]) is id
    assert get_repr_function(l, [(list, id)]) is id

# Generated at 2022-06-10 21:50:33.533824
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr('hi') == 'hi'
    assert get_shortish_repr(lambda: None) == '<function <lambda> at 0x'
    assert get_shortish_repr((3, 2, 1)) == '(3, 2, 1)'
    assert get_shortish_repr([3, 2, 1]) == '[3, 2, 1]'
    assert get_shortish_repr({'a': 3, 'b': 2}) == "{'a': 3, 'b': 2}"

    assert get_shortish_repr(None, max_length=2) == 'No'

# Generated at 2022-06-10 21:50:47.924598
# Unit test for function get_repr_function
def test_get_repr_function():
    get_repr_function(5, [(int, lambda x: 'is an int')])(5)
    get_repr_function(5, [(int, lambda x: 'is an int')])(5.5)


#temp
if sys.version_info.major == 3 and sys.version_info.minor < 4:
    def write_ansi(stream, s, ampersand_ok=False, code_to_symbol=None,
                   bold=False, fg=None, bg=None):
        s = escape_ansi(s, ampersand_ok, code_to_symbol, bold, fg, bg)
        stream.write(s)


# Generated at 2022-06-10 21:50:55.057019
# Unit test for function get_repr_function
def test_get_repr_function():

    def custom_repr1(n):
        return 'Not really {!r}'.format(n)

    def custom_repr2(m):
        return 'Not really {!r}'.format(m)


# Generated at 2022-06-10 21:51:06.786995
# Unit test for function get_repr_function
def test_get_repr_function():
    x = [1, 2, 3, object()]
    assert (get_repr_function(x[0], (int, lambda x: 'int %s' % x)) ==
            get_repr_function(x[1], (int, lambda x: 'int %s' % x)))
    assert (get_repr_function(x[0], (int, lambda x: 'int %s' % x)) !=
            get_repr_function(x[2], (int, lambda x: 'int %s' % x)))
    assert (get_repr_function(x[3], (int, lambda x: 'int %s' % x)) !=
            get_repr_function(x[2], (int, lambda x: 'int %s' % x)))



# Generated at 2022-06-10 21:51:20.759944
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str), (str, lambda _: 'hi'))) \
                                                                           == str
    assert get_repr_function(1.2, custom_repr=((int, str), (str, lambda _: 'hi'))) \
                               == repr

# Generated at 2022-06-10 21:51:22.932875
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X:
        def write(self, s):
            pass
    assert issubclass(X, WritableStream)



# Generated at 2022-06-10 21:51:36.645925
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class Reprable(object):
        def __repr__(self):
            return '<Reprable!>'
    reprable = Reprable()
    assert get_shortish_repr(2, max_length=None) == '2'
    assert get_shortish_repr([], max_length=None) == '[]'
    assert get_shortish_repr(reprable, max_length=None) == '<Reprable!>'
    assert get_shortish_repr('bla', max_length=None) == 'bla'
    assert get_shortish_repr(2, [], max_length=None) == '(2, [])'
    assert get_shortish_repr([reprable], max_length=None) == '[<Reprable!>]'

# Generated at 2022-06-10 21:51:45.267662
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcde', max_length=9) == 'abcde'
    assert get_shortish_repr('1234567890', max_length=9) == '123...890'
    assert get_shortish_repr('1234567890', max_length=None) == '1234567890'
    assert get_shortish_repr(12345, max_length=9) == '12345'
    assert get_shortish_repr(1234567890, max_length=9) == '123...890'
    assert get_shortish_repr(1234567890, max_length=None) == '1234567890'



# Generated at 2022-06-10 21:51:49.798126
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MockClass:

        def __init__(self):
            self.data = ''
            self.written = []

        def write(self, s):
            self.data += s
            self.written.append(s)

    assert issubclass(MockClass, WritableStream)



# Generated at 2022-06-10 21:52:01.375616
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    custom_repr = ((lambda x: x=='aaa', lambda x: 'Aaaa'), ) # we don't want the repr to be 'aaa' but 'Aaaa'
    assert get_shortish_repr('aaa', custom_repr) == 'Aaaa'
    assert get_shortish_repr('aaa', custom_repr, 1) == 'A'
    assert get_shortish_repr('aaa', custom_repr, 5) == 'Aaaa'
    assert get_shortish_repr('aaa', custom_repr, 6) == 'Aaaa'
    assert get_shortish_repr('aaa', custom_repr, 7) == 'Aaaa'
    assert get_shortish_repr('a' * 100, custom_repr, 5) == 'Aaa...a'



# Generated at 2022-06-10 21:52:13.677935
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr

# Generated at 2022-06-10 21:52:30.048937
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert 'x'[:None] == 'x'
    assert 'x'[:None] == 'x'
    for i in range(10):
        assert get_shortish_repr(i, max_length=None) == repr(i)
        assert get_shortish_repr(i, max_length=10) == repr(i)
        assert get_shortish_repr(i, max_length=2) == repr(i)

    assert get_shortish_repr(re.compile('a'), max_length=10) == "re.compile('a')"
    assert get_shortish_repr(re.compile('a'), max_length=None) == "re.compile('a')"

# Generated at 2022-06-10 21:52:33.094098
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, ((int, str),)) == str
    assert get_repr_function(3.0, ((int, str),)) == repr


if __name__ == '__main__':
    test_get_repr_function()

# Generated at 2022-06-10 21:52:38.219907
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            self.string = s

    my_writable_stream1 = MyWritableStream()
    my_writable_stream1.write('hi')
    assert my_writable_stream1.string == 'hi'



# Generated at 2022-06-10 21:52:48.652501
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'hello'"
    assert get_shortish_repr('hello', max_length=2) == "'he'"
    assert get_shortish_repr('hello', max_length=1) == "'h'"
    assert get_shortish_repr('hello', max_length=0) == '...'
    assert get_shortish_repr('hello', max_length=None) == "'hello'"
    assert get_shortish_repr('hello', max_length=-1) == "'hello'"

    assert get_shortish_repr(u'hello') == "u'hello'"

# Generated at 2022-06-10 21:52:56.526261
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, (
        (int, lambda x: 'int!'), 
    )) == 'int!'
    assert get_repr_function('hello world', (
        (str, lambda x: 'str!'), 
    )) == 'str!'
    assert get_repr_function('hello world', (
        (int, lambda x: 'int!'), 
    )) == repr
    assert get_repr_function(5, (
        ((int, str), lambda x: 'int or str!'), 
    )) == 'int or str!'
    assert get_repr_function('hello world', (
        ((int, str), lambda x: 'int or str!'), 
    )) == 'int or str!'

# Generated at 2022-06-10 21:53:08.254388
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=10) == "'hello'"
    assert get_shortish_repr('hello', max_length=5) == "'he...'"
    assert get_shortish_repr([1, 2, 3], max_length=20) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=20,
                             custom_repr=((list, 'LISTY'),)) == 'LISTY'
    assert get_shortish_repr([1, 2, 3], max_length=20,
                             custom_repr=((list, 'LISTY'), (str, 'STRINGY'))) \
                                                                 == 'LISTY'

# Generated at 2022-06-10 21:53:10.338639
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    s = StringIO()
    assert isinstance(s, WritableStream)



# Generated at 2022-06-10 21:53:17.932196
# Unit test for function get_repr_function
def test_get_repr_function():

    custom_repr = (
        (lambda item: isinstance(item, int), lambda item: '%d' % item),
        (lambda item: isinstance(item, float), lambda item: '%.1f' % item),
        (lambda item: isinstance(item, complex),
         lambda item: '%.1f+%.1fi' % (item.real, item.imag)),
        (lambda item: isinstance(item, str),
         lambda item: '"%s"' % item.replace('"', '\\"')),
    )

    def test_single_item(item):
        repr_function = get_repr_function(item, custom_repr)
        r = repr_function(item)
        assert isinstance(r, str)
        assert eval(r) == item


# Generated at 2022-06-10 21:53:30.561691
# Unit test for function get_repr_function
def test_get_repr_function():
    """The function should return the repr function if the type doesn't match
    """
    def repr_a(x):
        return 'A'

    def repr_b(x):
        return 'B'

    def repr_c(x):
        return 'C'

    assert get_repr_function(1, [(int, repr_a), (str, repr_b)]) == repr
    assert get_repr_function(1, [(int, repr_a), (str, repr_b)]) == repr

    assert get_repr_function(1, [(int, repr_a), (str, repr_b)]) == repr
    assert get_repr_function(1, [(int, repr_a), (str, repr_b)]) == repr

    assert get_repr_function(1, [(int, repr_a)])

# Generated at 2022-06-10 21:53:35.412698
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Checking that it's not possible to subclass `WritableStream` without
    # overriding `write`:
    class T(WritableStream):
        pass
    assert not issubclass(T, WritableStream)


if __name__ == '__main__':
    test_WritableStream_write()

# Generated at 2022-06-10 21:53:57.713051
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None,    [(lambda _: True, lambda _: 'hi')])() == 'hi'
    assert get_repr_function(27,      [(lambda _: True, lambda x: x*2)])() == 54
    assert get_repr_function(object(), [(lambda _: True, lambda x: id(x))])() == id(object())

    assert get_repr_function(27,      [])() == 27
    assert get_repr_function(object(), [])() == "<object object at 0x...>"

    assert get_repr_function(27,      [(lambda _: True, lambda x: x*2),
                                       (lambda x: x == 'hi', lambda _: 'bye')])() == 54



# Generated at 2022-06-10 21:54:10.651335
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr(5, custom_repr=((int, lambda x: 'int' + repr(x)),)) == 'int5'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(123, max_length=2) == '1...3'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1234, max_length=6) == '12...34'
    assert get_shortish_repr(12345, max_length=6) == '1...45'

# Generated at 2022-06-10 21:54:13.433401
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass

    assert issubclass(WritableStreamSubclass, WritableStream)



# Generated at 2022-06-10 21:54:22.443789
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class SillyStream(WritableStream):

        def __init__(self):
            self.s = ''

        def write(self, s):
            self.s += s

    silly_stream = SillyStream()

    silly_stream.write('abc')
    assert silly_stream.s == 'abc'

    silly_stream.write('def')
    assert silly_stream.s == 'abcdef'

    silly_stream.write('')
    assert silly_stream.s == 'abcdef'

    silly_stream.write(5)
    assert silly_stream.s == 'abcdef5'

    # A real-life case, since we support writing bytes to a stream:
    silly_stream.write(b'bytes')
    assert silly_stream.s == 'abcdef5bytes'


# Generated at 2022-06-10 21:54:28.714689
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        def write(self, s):
            return None

    assert issubclass(Foo, WritableStream)

    class Foo2:
        def write(self, s):
            return True

    assert issubclass(Foo2, WritableStream)

    class Foo3:
        pass

    assert not issubclass(Foo3, WritableStream)



# Generated at 2022-06-10 21:54:39.458722
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [
        ('hello', 'pig'),
        (1, 'dog'),
        (lambda x: x == 6, 'chicken'),
        (lambda x: isinstance(x, bool), 'turkey'),
        (lambda x: isinstance(x, tuple) and x[0] == 'frog', 'duck')
    ]

    assert get_repr_function('hello', custom_repr) == 'dog'
    assert get_repr_function('HELlo', custom_repr) == 'dog'
    assert get_repr_function(1, custom_repr) == 'pig'
    assert get_repr_function(6, custom_repr) == 'chicken'
    assert get_repr_function(True, custom_repr) == 'turkey'
    assert get_

# Generated at 2022-06-10 21:54:46.889169
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('a') == "'a'"
    assert get_shortish_repr(u'a') == "'a'"
    assert get_shortish_repr(b'a') == "b'a'"
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1.0) == '1.0'
    assert get_shortish_repr(object) == 'object'
    assert get_shortish_repr(object(), normalize=True) == 'object'
    assert get_shortish_repr(object(), max_length=8, normalize=True) == 'object'
    assert (get_shortish_repr(object(), max_length=5, normalize=True) ==
                                                                     'objec' * 2)

# Generated at 2022-06-10 21:54:51.530489
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def __init__(self):
            self.written_stuff = ''
        def write(self, s):
            self.written_stuff += s

    foo = Foo()
    foo.write('bar')
    assert foo.written_stuff == 'bar'
    foo.write(' bar')
    assert foo.written_stuff == 'bar bar'



# Generated at 2022-06-10 21:55:02.172957
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass

    assert get_repr_function(A(), ()) is repr
    assert get_repr_function(B(), ()) is repr
    assert get_repr_function(A(), [(A, lambda x: 'x')]) is repr
    assert get_repr_function(B(), [(A, lambda x: 'x')]) == (lambda x: 'x')
    assert get_repr_function(
        B(), [(A, lambda x: 'x'), (B, lambda x: 'y')]
    ) == (lambda x: 'y')


test_get_repr_function()



# Generated at 2022-06-10 21:55:05.989804
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyWritableStream(WritableStream):
        def write(self, s):
            pass

    dummy_writable_stream = DummyWritableStream()
    assert isinstance(dummy_writable_stream, WritableStream)

