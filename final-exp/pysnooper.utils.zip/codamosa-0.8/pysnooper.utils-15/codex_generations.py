

# Generated at 2022-06-10 21:45:07.869442
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(WritableStream):
        def write(self, s):
            pass

    assert issubclass(X, WritableStream)

# Generated at 2022-06-10 21:45:11.716244
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C: pass

    a = A()
    b = B()
    c = C()


# Generated at 2022-06-10 21:45:16.273956
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            return s

    class B:
        pass

    assert issubclass(A, WritableStream)
    assert not issubclass(B, WritableStream)


# Generated at 2022-06-10 21:45:23.473561
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C:
        def write(self, s): pass
    assert issubclass(C, WritableStream)
    class C(object):
        def write(self, s): pass
    assert issubclass(C, WritableStream)
    class C:
        pass
    assert not issubclass(C, WritableStream)
    class C:
        def write(self, s): pass
        def flush(self): pass
    assert not issubclass(C, WritableStream)




# Generated at 2022-06-10 21:45:32.189668
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('hello') == 'hello'
    assert shitcode('hello\nworld') == 'hello\nworld'
    assert shitcode('h\xe9llo') == 'h?llo'
    assert shitcode('h\x9d9llo') == 'h??llo'
    assert shitcode('h\xe9llo\nworld') == 'h?llo\nworld'
    assert shitcode('h\x9d9llo\nworld') == 'h??llo\nworld'



# Generated at 2022-06-10 21:45:38.320745
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        pass
    assert WritableStream.__subclasshook__(A) == NotImplemented
    class B(WritableStream):
        def write(self, s):
            pass
    assert WritableStream.__subclasshook__(B) == True
    class C(WritableStream):
        def write(self, s):
            pass
        def write_new(self, s):
            pass
    assert WritableStream.__subclasshook__(C) == True
    class D(C):
        pass

    assert WritableStream.__subclasshook__(D) == True
    class E(D):
        pass

    assert WritableStream.__subclasshook__(E) == True
    class F(WritableStream):
        def write(self, s):
            return 0

   

# Generated at 2022-06-10 21:45:47.299537
# Unit test for function shitcode
def test_shitcode():
    assert ''.join(shitcode(u'abc')) == u'abc'
    assert ''.join(shitcode(u'abc\u2665')) == u'abc?'
    assert ''.join(shitcode(u'a\U0001f226')) == 'a?'
    assert ''.join(shitcode(u'a\U0001f226d\u2665')) == 'a?d?'
    assert ''.join(shitcode(u'a\U0001f226d\u2665')) == 'a?d?'
    assert ''.join(shitcode(u'abc\u2665\u2665\u2665')) == u'abc???'

# Generated at 2022-06-10 21:45:57.515153
# Unit test for function shitcode
def test_shitcode():
    cases = [
        (u'hello', u'hello'),
        (u'אאאא', u'????'),
        (u'abc😊def', u'abc?def'),
        (u'abc\ud801\udc37def', u'abc?def'),
    ]

    for string, expected in cases:
        assert shitcode(string) == expected

    # Should work on bytes or bytearray too
    for type_ in (bytes, bytearray):
        for string, expected in cases:
            assert shitcode(type_(string.encode('utf-8'))) == expected


_PY2 = sys.version_info.major == 2

if not _PY2:
    def to_unicode(s):
        if isinstance(s, str):
            return s

# Generated at 2022-06-10 21:45:59.402409
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .logging_system import StringIOWithEncoding

    test_stream = StringIOWithEncoding()
    assert isinstance(test_stream, WritableStream)



# Generated at 2022-06-10 21:46:03.988023
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass
    assert isinstance(A(), WritableStream)
    class B:
        def write(self):
            pass
    assert not isinstance(B(), WritableStream)
    class C:
        pass
    assert not isinstance(C(), WritableStream)



# Generated at 2022-06-10 21:46:10.590723
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, ()) == repr
    assert get_repr_function('hello', ()) == repr
    assert get_repr_function(3, ((str, lambda x: 'str'),)) == repr
    assert get_repr_function('hello', ((str, lambda x: 'str'),)) == str
    assert get_repr_function(3, ((int, lambda x: 'int'),)) == 'int'
    assert get_repr_function('hello', ((int, lambda x: 'int'),)) == repr



# Generated at 2022-06-10 21:46:22.479570
# Unit test for function get_repr_function
def test_get_repr_function():

    assert get_repr_function(5, custom_repr=((5, 'five'),)) == 'five'
    assert get_repr_function('hey', custom_repr=((5, 'five'),)) != 'five'
    assert get_repr_function(5, custom_repr=((str, 'str'),)) != 'str'
    assert get_repr_function(5, custom_repr=((str, 'str'),)) == repr
    assert get_repr_function(5, custom_repr=()) == repr

    assert get_repr_function('hey', custom_repr=((lambda x: True, 'all'),)) == \
                                                                         'all'

# Generated at 2022-06-10 21:46:33.105599
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr([1, 2, 3],
                             (lambda x: isinstance(x, list), lambda x: str(x)),
                             ) == '[1, 2, 3]'
    assert get_shortish_repr('123456789', max_length=5) == "'123...'"
    assert get_shortish_repr(b'123456789', max_length=5) == "b'123...'"
    assert get_shortish_repr(b'123456789', max_length=10) == "b'1234567...'"

# Generated at 2022-06-10 21:46:36.669099
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeFile(object):
        def __init__(self):
            self.written = ''

        def write(self, s):
            self.written += s
    f = FakeFile()
    assert isinstance(f, WritableStream)
    f.write('hi')
    assert f.written == 'hi'

# Generated at 2022-06-10 21:46:42.608161
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('Hello world') == 'Hello world'
    assert shitcode(u'hello \x2030') == 'hello ?'
    assert shitcode(u'hello \x0030') == 'hello ?'
    assert shitcode(b'hello \xe7') == 'hello ?'
    assert shitcode(b'hello \x00') == 'hello ?'

# Generated at 2022-06-10 21:46:54.314825
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    def _test(value, expected_result, max_length=None):
        result = get_shortish_repr(value, max_length=max_length)
        assert result == expected_result, \
                  '%s did not give %s as result' % (repr(value),
                                                    repr(expected_result))
    _test([1, 2, 3],
          "[1, 2, 3]")
    _test([1, 2, 3],
          "[1, 2, 3]",
          max_length=7)
    _test([1, 2, 3],
          "[1, 2, 3]",
          max_length=8)
    _test([1, 2, 3],
          "[1, 2, ...]",
          max_length=9)

# Generated at 2022-06-10 21:46:56.726422
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeStream(WritableStream):
        def write(self, s): pass
    assert issubclass(FakeStream, WritableStream)


# Generated at 2022-06-10 21:47:05.885555
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([], max_length=0) == '[]'
    assert get_shortish_repr([], max_length=1) == '[]'
    assert get_shortish_repr([], max_length=2) == '[]'
    assert get_shortish_repr([], max_length=3) == '[]'
    assert get_shortish_repr([], max_length=4) == '[]'

    assert get_shortish_repr([1], max_length=0) == '[...]'
    assert get_shortish_repr([1], max_length=1) == '[...]'
    assert get_shortish_repr([1], max_length=2) == '[...]'

# Generated at 2022-06-10 21:47:14.739069
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MockIO:
        def write(self, s):
            return True
    io = MockIO()
    assert isinstance(io, WritableStream)
    assert WritableStream.__subclasshook__(MockIO) is True
    assert WritableStream.__subclasshook__(io) is True
    assert isinstance(io, WritableStream)

    class MockIO2:
        pass
    io2 = MockIO2()
    assert WritableStream.__subclasshook__(MockIO2) is NotImplemented
    assert WritableStream.__subclasshook__(io2) is NotImplemented
    assert not isinstance(io2, WritableStream)




# Generated at 2022-06-10 21:47:24.582534
# Unit test for function get_repr_function
def test_get_repr_function():
    class X(object):
        pass
    class Y(X):
        pass
    class Z(Y):
        pass
    custom_repr = (
        (lambda i: isinstance(i, X), lambda x: 'X'),
        (lambda i: isinstance(i, Z), lambda x: 'Z'),
    )
    assert get_repr_function(Y(), custom_repr) is repr
    assert get_repr_function(Z(), custom_repr) is not repr
    assert get_repr_function(Z(), custom_repr)() == 'Z'



# Generated at 2022-06-10 21:47:33.074592
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass
    class C(object): pass
    a = A()
    b = B()
    c = C()
    assert get_repr_function(a, ((type(a), lambda x: 'ahhh'),))() == 'ahhh'
    assert get_repr_function(b, ((A, lambda x: 'oh no'),))() == 'oh no'
    assert get_repr_function(c, ((A, lambda x: 'oh no'),))() == repr(c)

# Generated at 2022-06-10 21:47:39.799595
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStream1(WritableStream):
        def write(self, s):
            pass

    class WritableStream2(WritableStream1):
        pass

    class NotWritableStream:
        pass

    assert isinstance(WritableStream1(), WritableStream)
    assert isinstance(WritableStream2(), WritableStream)
    assert not isinstance(NotWritableStream(), WritableStream)

# Generated at 2022-06-10 21:47:44.764613
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def write(self, s):
            pass

    class Bar:
        pass

    isinstance(Foo(), WritableStream)
    assert not isinstance(Bar(), WritableStream)


if __name__ == '__main__':
    test_WritableStream_write()
    print('pass')

# Generated at 2022-06-10 21:47:50.901623
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeWritableStream(object):
        def write(self, s):
            pass

    assert issubclass(FakeWritableStream, WritableStream)
    assert issubclass(sys.stdout.__class__, WritableStream)

    class FakeNotWritableStream(object):
        pass

    assert not issubclass(FakeNotWritableStream, WritableStream)


# Generated at 2022-06-10 21:47:58.869989
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object):
        pass
    class B(object):
        pass
    class C(A):
        pass
    class D(A):
        pass
    class E(C, D):
        pass

    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(int, unicode)]) == unicode
    assert get_repr_function(1, [(float, unicode)]) == repr
    assert get_repr_function(1, [(float, unicode), (int, unicode)]) == unicode
    assert get_repr_function(1, [(C, unicode), (int, unicode)]) == repr
    assert get_repr_function(1, [(A, unicode), (int, unicode)]) == repr
    assert get_repr

# Generated at 2022-06-10 21:48:03.294549
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    a = A()
    custom_repr = [(A, A.__repr__)]
    assert get_repr_function(a, custom_repr) == A.__repr__



# Generated at 2022-06-10 21:48:07.048937
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritable(object):

        def __init__(self):
            self.text = ''

        def write(self, s):
            self.text += s

    assert isinstance(MyWritable(), WritableStream)

# Generated at 2022-06-10 21:48:15.788242
# Unit test for function get_repr_function
def test_get_repr_function():
    import numbers
    assert get_repr_function('abc', custom_repr=((str, int),)) == int

    class MyObject(object): pass
    my_object = MyObject()
    assert get_repr_function(my_object, custom_repr=()) == repr

    assert get_repr_function(my_object, custom_repr=((MyObject, int),)) == int

    assert get_repr_function(my_object, custom_repr=((numbers.Real, int),)) \
                                                                      == repr




# Generated at 2022-06-10 21:48:17.795493
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class NewWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(NewWritableStream, WritableStream)

# Generated at 2022-06-10 21:48:26.950884
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Buffer(WritableStream):
        def __init__(self):
            self.buffer = []

        def write(self, s):
            self.buffer.append(s)

    buffer = Buffer()

    assert not isinstance(buffer, WritableStream)
    assert isinstance(buffer, WritableStream)
    assert not isinstance(float, WritableStream)
    assert not WritableStream.__subclasshook__(float)
    assert WritableStream.__subclasshook__(buffer)

    buffer.write('meow')

    assert buffer.buffer == ['meow']





# Generated at 2022-06-10 21:48:35.166870
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class GoodWritableStream(WritableStream):
        def write(self, s):
            pass
    class BadWritableStream:
        def write(self, s):
            pass
    assert issubclass(GoodWritableStream, WritableStream)
    assert not issubclass(BadWritableStream, WritableStream)
    assert GoodWritableStream.write('e')
    assert not BadWritableStream.write('f')

# Generated at 2022-06-10 21:48:44.771814
# Unit test for function get_repr_function
def test_get_repr_function():
    def custom_repr(x):
        return '*' * x
    
    assert get_repr_function(5, ())(5) == '5'
    assert get_repr_function(5.5, ())(5.5) == '5.5'
    assert get_repr_function(5j, ())(5j) == '5j'
    assert get_repr_function('x', ())('x') == "'x'"
    assert get_repr_function([1, 2, 3], ())([1, 2, 3]) == '[1, 2, 3]'
    assert get_repr_function((1, 2, 3), ())((1, 2, 3)) == '(1, 2, 3)'

# Generated at 2022-06-10 21:48:55.851852
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .test_tools import assert_equal, assert_regex
    
    # Check default behavior:
    for input in (4, 4.4, 'foo', [4, 5], {4: 6}):
        assert_equal(get_shortish_repr(input), repr(input))
    
    # Check max_length:
    assert_equal(get_shortish_repr(range(100), max_length=8), '[0, 1, 2, 3, '
                                                               '..., 97, 98, '
                                                               '99]')
    assert_equal(get_shortish_repr(range(100), max_length=9), '[0, 1, 2, 3, '
                                                               '..., 98, 99]')

# Generated at 2022-06-10 21:49:01.597104
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test `write` is called, and called with a string:
    class TestStream(WritableStream):
        calls = []
        def write(self, s):
            TestStream.calls.append(s)
    test_stream = TestStream()
    test_stream.write('abc')
    assert TestStream.calls.pop() == 'abc'

# Generated at 2022-06-10 21:49:12.041326
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(2, [(lambda x: x == 2, lambda x: x * 2)]) == \
                                                                      (lambda x: x * 2)
    assert get_repr_function(3, [(lambda x: x == 2, lambda x: x * 2)]) == \
                                                                     repr
    assert get_repr_function(2, [(2, lambda x: x * 2)]) == (lambda x: x * 2)
    assert get_repr_function(2, [(2,)]) == repr
    assert get_repr_function(2, [(True, lambda x: x * 2)]) == (lambda x: x * 2)
    assert get_repr_function(2, [int]) == repr

# Generated at 2022-06-10 21:49:14.196300
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def write(self, s):
            pass

    MyStream().write('foo')



# Generated at 2022-06-10 21:49:18.729278
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    a = list(range(1000))
    repr_string = repr(a)
    repr_string_truncated = repr_string[:100] + '...' + repr_string[-100:]
    assert repr_string == get_shortish_repr(a)
    assert repr_string_truncated == get_shortish_repr(a, max_length=200)



# Generated at 2022-06-10 21:49:29.058264
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A(object):
        pass
    class B(object):
        def __repr__(self):
            return 'shorter_than_default_repr'

# Generated at 2022-06-10 21:49:38.556982
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Testing that basic strings are written OK.
    class MyFileWrapper(WritableStream):
        def __init__(self, real_file):
            self.real_file = real_file
        def write(self, s):
            self.real_file.write(s.encode('utf-8'))

    s = b''
    with open(__file__, 'rb') as real_file:
        my_file_wrapper = MyFileWrapper(real_file)
        my_file_wrapper.write('hello')
        my_file_wrapper.write(123)
        my_file_wrapper.write(b'hi')
        my_file_wrapper.write(u'bye')
        s += real_file.read()

    assert b''.join(b'hello123hibye'.split()) in s

    # Test

# Generated at 2022-06-10 21:49:49.567940
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=100) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'

# Generated at 2022-06-10 21:49:54.165254
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert isinstance(MyWritableStream(), WritableStream)

# Generated at 2022-06-10 21:49:57.573644
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def __init__(self):
            self.string = ''

        def write(self, s):
            self.string += s

    foo = Foo()
    foo.write('hi')
    assert foo.string == 'hi'

# Generated at 2022-06-10 21:50:07.515773
# Unit test for function get_repr_function
def test_get_repr_function():
    def monkey(x):
        return x.__dict__
    
    monkey_int = lambda x: monkey(x) if isinstance(x, int) else repr(x)
    monkey_float = lambda x: monkey(x) if isinstance(x, float) else repr(x)
    monkey_complex = lambda x: monkey(x) if isinstance(x, complex) else repr(x)
    
    def assert_reprs(custom_repr, list_of_items, list_of_reprs):
        for item, repr_ in zip(list_of_items, list_of_reprs):
            assert get_repr_function(item, custom_repr)(item) == repr_
    

# Generated at 2022-06-10 21:50:17.495382
# Unit test for function get_repr_function
def test_get_repr_function():
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass
    assert get_repr_function(C(), ((A, 'A'), )) == 'A'
    assert get_repr_function(C(), ((C, 'C'), (A, 'A'), )) == 'C'
    assert get_repr_function(C(), ((B, 'B'), (A, 'A'), )) == 'B'
    assert get_repr_function(C(), ((B, 'B'), (object, 'object'), )) == 'B'
    assert get_repr_function(C(), ((object, 'object'), (B, 'B'), )) == 'B'
    assert get_repr_function(C(), ((object, 'object'), (B, 'B'), )) == 'B'
    assert get

# Generated at 2022-06-10 21:50:27.858913
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == \
                                        '\'hello\''
    assert get_shortish_repr(range(10)) == \
                            'range(0, 10)'
    assert get_shortish_repr('f' * 100) == \
                            '\'f' + 'f' * (100 - 3) + '...\''
    assert get_shortish_repr('f' * 100, max_length=2) == \
                            '\'f...\''
    assert get_shortish_repr('f' * 100, max_length=2, normalize=True) == \
                            '\'f...\''
    assert get_shortish_repr(range(100), max_length=30) == \
                            'range(0, 100)'
    assert get_short

# Generated at 2022-06-10 21:50:35.630708
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (('x', lambda x: 'x'))) == repr
    assert get_repr_function('x', (('x', lambda x: 'x'))) == 'x'
    assert get_repr_function(1, ((1, lambda x: 'x'))) == 'x'
    assert get_repr_function([1], ((1, lambda x: 'x'))) == repr
    assert get_repr_function([1], ((list, lambda x: 'x'))) == 'x'



# Generated at 2022-06-10 21:50:38.098436
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritable(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritable, WritableStream)

# Generated at 2022-06-10 21:50:42.083711
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert hasattr(sys.stdout, 'write')
    assert isinstance(sys.stdout, WritableStream)
    assert not hasattr(1, 'write')
    assert not isinstance(1, WritableStream)
    assert hasattr(int, 'write')



# Generated at 2022-06-10 21:50:49.539853
# Unit test for function get_repr_function
def test_get_repr_function():
    # We'll define several types of different representations, with their
    # conditions. Then we'll use `get_repr_function` with the conditions,
    # and make sure it correctly finds the right representation.

    def doesnt_happen(*items):
        raise Exception('This function should never be called.')

    def custom_a(x):
        return 'a'

    def custom_b(x):
        return 'b'

    for cls in (Exception, ValueError):
        assert get_repr_function(cls(), [
            (cls, custom_a),
            (Exception, custom_b),
        ]) == custom_a

    assert get_repr_function('abc', [
        (Exception, custom_a),
    ]) == doesnt_happen


# Generated at 2022-06-10 21:50:58.139005
# Unit test for function get_repr_function
def test_get_repr_function():
    class Object1(object): pass
    class Object2(object): pass
    class Object3(object): pass
    custom_repr = (
        (lambda x: isinstance(x, Object1), str),
        (Object2, str),
    )
    assert get_repr_function(Object1(), custom_repr) == str
    assert get_repr_function(Object2(), custom_repr) == str
    assert get_repr_function(Object3(), custom_repr) == repr




# Generated at 2022-06-10 21:51:09.366640
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def __init__(self, str_list):
            self.str_list = str_list
        def write(self, s):
            self.str_list.append(s)
    str_list = []
    writable_stream = WritableStreamSubclass(str_list)
    writable_stream.write('hey')
    assert str_list == ['hey']



# Generated at 2022-06-10 21:51:19.165927
# Unit test for function get_repr_function
def test_get_repr_function():
    from .test_python_toolbox import TestCase

    class Cat:
        pass

    class Orange(object):
        pass

    class SubSubOrange(Orange):
        pass

    class World(object):
        pass

    def cat_repr(cat):
        assert isinstance(cat, Cat)
        return 'cat'

    def orange_repr(orange):
        assert isinstance(orange, Orange)
        return 'orange'

    def dummy_repr(x):
        return '{}'.format(x)


# Generated at 2022-06-10 21:51:25.679877
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    class B(A):
        pass

    assert issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)

    assert not issubclass(int, WritableStream)
    assert not issubclass(Exception, WritableStream)
    assert not issubclass(A, int)
    assert not issubclass(list, WritableStream)
    assert not issubclass(list, A)





# Generated at 2022-06-10 21:51:31.224603
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function('1', ()) is repr

    assert get_repr_function(1, ((1, None),)) is None
    assert get_repr_function('1', ((1, None),)) is repr





# Generated at 2022-06-10 21:51:43.174534
# Unit test for function get_repr_function

# Generated at 2022-06-10 21:51:52.265527
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, ()) is repr
    assert get_repr_function(5, ((int, str),)) is str
    assert get_repr_function(5, ((int, str), (lambda x: x == 5, int))) is int
    assert get_repr_function(5, ((int, str), (lambda x: x == 6, int))) is str
    assert get_repr_function(5, ((int, str), (lambda x: x == 5, int),
                                 (int, float))) is int
    assert get_repr_function(5, ((int, str), (lambda x: x == 5, int),
                                 (float, lambda x: int(x)))) is int

# Generated at 2022-06-10 21:51:54.276891
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamMock(WritableStream):
        def write(self, s):
            pass

    assert issubclass(WritableStreamMock, WritableStream)



# Generated at 2022-06-10 21:52:00.713047
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class DummyWritableStream(WritableStream):

        def __init__(self):
            self.s = ''

        def write(self, s):
            self.s += s

    dummy_writable_stream = DummyWritableStream()
    dummy_writable_stream.write('abc')
    assert dummy_writable_stream.s == 'abc'



# Generated at 2022-06-10 21:52:09.748679
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    a = A()
    #test callable condition
    assert get_repr_function(a, [(lambda x:True, "")]) == ""
    #test type condition
    assert get_repr_function(a, [(A, "")]) == ""
    #test multiple conditions
    assert get_repr_function(a, [(lambda x:True, ""), (A, "")]) == ""
    #test empty custom_repr
    assert get_repr_function(a, []) == repr
    #test default if no matching condition
    a = None
    assert get_repr_function(a, [(lambda x:"", "")]) == repr

# Generated at 2022-06-10 21:52:12.162952
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TheStream(object):
        def write(self, s):
            print(s)

    assert isinstance(TheStream(), WritableStream)
    assert not isinstance(12, WritableStream)

# Generated at 2022-06-10 21:52:32.391960
# Unit test for function get_repr_function
def test_get_repr_function():

    class Thing(object): pass
    class Thing1(Thing): pass
    class Thing2(Thing): pass

    custom_reprs = (
        (lambda thing: isinstance(thing, Thing1), lambda thing: 'Thingy1'),
        (lambda thing: thing == 9, lambda thing: 'It is 9'),
        (Thing2, lambda thing: 'Thingy2'),
        (Thing, lambda thing: 'Thingy'),
    )

    assert get_repr_function(Thing1(), custom_reprs)() == 'Thingy1'
    assert get_repr_function(Thing2(), custom_reprs)() == 'Thingy2'
    assert get_repr_function(Thing(), custom_reprs)() == 'Thingy'
    assert get_repr

# Generated at 2022-06-10 21:52:38.430280
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [
        (lambda x: True, lambda x: [x, x][0]),
        (str, str),
        (str, lambda x: [x, x][0])
    ]
    assert get_repr_function('a', custom_repr) == str
    assert get_repr_function(1, custom_repr)('a') == 'a'

# Generated at 2022-06-10 21:52:46.850427
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import sys
    import os

    class MyWritableStream(WritableStream):
        def __init__(self):
            self.data = []

        def write(self, s):
            self.data.append(s)

    stream = MyWritableStream()
    old_stdout = sys.stdout
    sys.stdout = stream
    for x in range(100):
        print(x, 'hello', 42j)
    sys.stdout = old_stdout
    assert stream.data == [os.linesep.join((str(x), 'hello', '42j'))
                           for x in range(100)]



# Generated at 2022-06-10 21:52:50.977126
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            assert isinstance(s, string_types), type(s)
            assert len(s) > 1
            return

    MyWritableStream().write('a')
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-10 21:52:58.332812
# Unit test for function get_repr_function

# Generated at 2022-06-10 21:53:03.092908
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    global x
    class TestWritableStream:
        def write(self, s):
            global x
            x += s
    x = ''
    ws = TestWritableStream()
    ws.write('hey')
    assert x == 'hey'



# Generated at 2022-06-10 21:53:05.134121
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert issubclass(sys.stdout.__class__, WritableStream)



# Generated at 2022-06-10 21:53:13.501715
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X:
        def write(self, s):
            pass
    assert isinstance(X(), WritableStream)

    class Y:
        def write(self, s):
            pass
    class Z(X, Y):
        pass
    assert isinstance(Z(), WritableStream)

    class A(X):
        pass

    class B(Y):
        pass

    del X.write
    del Y.write
    assert not isinstance(X(), WritableStream)
    assert not isinstance(Y(), WritableStream)
    assert isinstance(A(), WritableStream)
    assert isinstance(B(), WritableStream)
    assert isinstance(Z(), WritableStream)

# Generated at 2022-06-10 21:53:24.401383
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('yo') == "'yo'"
    assert get_shortish_repr(b'yo') == "b'yo'"
    assert get_shortish_repr(123) == '123'
    assert get_shortish_repr((1, 2, 3)) == '(1, 2, 3)'
    assert get_shortish_repr(u'\u2665') == 'u\'\u2665\''
    if sys.version_info[0] == 2:
        assert get_shortish_repr(u'\u2665'.encode('utf-8')) == "u'\\xe2\\x99\\xa5'"

# Generated at 2022-06-10 21:53:29.736966
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TxtFile(object):
        def __init__(self):
            self.content = []
        def write(self, s):
            self.content.append(s)

    txt_file = TxtFile()
    assert isinstance(txt_file, WritableStream)



# Generated at 2022-06-10 21:54:02.211096
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(5) == '5'

    assert get_shortish_repr(5, max_length=4) == '5'

    assert get_shortish_repr(5, max_length=3) == '5'

    assert get_shortish_repr(5, max_length=2) == '5'

    assert get_shortish_repr(5, max_length=1) == '5'

    assert get_shortish_repr(5, max_length=0) == '5'

    assert get_shortish_repr(5, max_length=None) == '5'

    assert get_shortish_repr('abcde', max_length=3) == 'abc...'


# Generated at 2022-06-10 21:54:14.115581
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) == repr

    assert get_repr_function(None, ((type(None), str), (int, str))) == str
    assert get_repr_function(42, ((type(None), str), (int, str))) == str
    assert get_repr_function('', ((type(None), str), (int, str))) == repr

    assert get_repr_function(
        42, ((lambda x: x > 40, str), (int, str))
    ) == str
    assert get_repr_function(
        42, ((lambda x: x > 50, str), (int, str))
    ) == repr

    class Base(object):
        pass
    class A(Base):
        pass
    class B(Base):
        pass


# Generated at 2022-06-10 21:54:16.722952
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            self.s = s

    assert issubclass(A, WritableStream)



# Generated at 2022-06-10 21:54:24.202223
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '...'
    assert get_shortish_repr(1, max_length=1, normalize=True) == '...'

    assert get_shortish_repr(1, max_length=2, normalize=True) == '1'
    assert get_shortish_repr(1, max_length=1, normalize=True) == '...'

    assert get_shortish_repr(1, custom_repr=((int, str),)) == '1'

# Generated at 2022-06-10 21:54:26.300730
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def write(self, s):
            pass
    Foo()



# Generated at 2022-06-10 21:54:37.861674
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    # not defined at all

    class X(WritableStream): pass
    x = X()
    with pytest.raises(TypeError):
        x.write()


    # defined as a method

    class X(WritableStream):
        def write(self, s):
            assert 'write' == s

    x = X()
    x.write('write')



    # defined as a staticmethod

    class X(WritableStream):
        @staticmethod
        def write(s):
            assert 'write' == s

    x = X()
    x.write('write')


    # defined as a classmethod

    class X(WritableStream):

        @classmethod
        def write(cls, s):
            assert cls is X
            assert 'write' == s

    x = X()
    x.write

# Generated at 2022-06-10 21:54:43.819715
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyOtherWritableStream:
        pass
    assert not issubclass(MyOtherWritableStream, WritableStream)



# Generated at 2022-06-10 21:54:52.325172
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class SimpleWritableStream(WritableStream):
        def write(self, s):
            pass
        pass

    assert issubclass(SimpleWritableStream, WritableStream)

    x = SimpleWritableStream()
    assert isinstance(x, WritableStream)

    class SimpleAnotherWritableStream(WritableStream):
        pass

    assert not issubclass(SimpleAnotherWritableStream, WritableStream)

    class SimpleAnotherBWritableStream(SimpleWritableStream):
        pass

    assert issubclass(SimpleAnotherBWritableStream, WritableStream)

# Generated at 2022-06-10 21:54:57.066189
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class GoodWritableStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(GoodWritableStream(), WritableStream)

    class BadWritableStream(WritableStream):
        def hi(self):
            pass

    assert not isinstance(BadWritableStream(), WritableStream)

# Generated at 2022-06-10 21:55:02.129984
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s
    a = A()
    a.write('shalom')
    assert a.s == 'shalom'
    assert isinstance(a, WritableStream)
    def foo(s):
        pass
    assert isinstance(foo, WritableStream)

