

# Generated at 2022-06-10 21:45:22.194542
# Unit test for function get_repr_function
def test_get_repr_function():
    print('test_get_repr_function')
    assert get_repr_function(1, custom_repr=(lambda x: x == 2, int)) == int
    assert get_repr_function(1, custom_repr=((lambda x: x == 2, int),)) == repr
    assert get_repr_function(2, custom_repr=((lambda x: x == 2, int),)) == int
    assert get_repr_function(
        2, custom_repr=((lambda x: x == 2, int), (lambda x: x == 1, str))) == int
    assert get_repr_function(
        3, custom_repr=((lambda x: x == 2, int), (lambda x: x == 1, str))) == repr

# Generated at 2022-06-10 21:45:34.255079
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from StringIO import StringIO
    from .exceptions import NothingWritten
    s = StringIO()
    ws = WritableStream()
    try:
        ws.write(s)
    except NotImplementedError:
        pass
    else:
        raise Exception('should not be implemented')
    
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        
    ws = MyWritableStream()
    ws.write(s)
    
    class MyWritableStreamWithNoneWrite(WritableStream):
        def write(self, s):
            None
        
    ws2 = MyWritableStreamWithNoneWrite()
    try:
        ws2.write(s)
    except NotImplementedError:
        pass

# Generated at 2022-06-10 21:45:45.678156
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(WritableStream):
        pass

    class Y(WritableStream):
        def write(self, s):
            pass

    class Z(WritableStream):
        def writeline(self, s):
            pass

    assert isinstance(X, WritableStream) is False
    assert isinstance(Y, WritableStream) is True
    assert isinstance(Z, WritableStream) is False

    assert WritableStream.__subclasshook__(str) is NotImplemented
    assert WritableStream.__subclasshook__(int) is NotImplemented
    assert WritableStream.__subclasshook__(X) is NotImplemented
    assert WritableStream.__subclasshook__(Y) is True
    assert WritableStream.__subclasshook__(Z) is NotImplemented


# Generated at 2022-06-10 21:45:56.265171
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    hello = 'hello'
    hello_repr = "'hello'"
    assert get_shortish_repr(hello) == hello_repr
    assert get_shortish_repr(hello, max_length=len(hello_repr)-1) == \
                                                                  hello_repr[:-2]
    assert get_shortish_repr(hello, max_length=len(hello_repr)+1) == \
                                                                  hello_repr
    assert get_shortish_repr(hello, max_length=len(hello_repr)) == hello_repr

    assert get_shortish_repr([hello] * 2) == "['hello', 'hello']"

# Generated at 2022-06-10 21:46:02.375138
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'abc\xAA') == u'abc?'
    assert shitcode(u'abc\u0D10') == u'abc?'
    assert shitcode(u'\xC6') == u'?'
    assert shitcode(u'\xC6\u0D10') == u'??'
    assert shitcode(u'\u0D0E\u0D0E\xAA') == u'???'
    assert shitcode(bytearray(b'\x00\xFF')) == u'??'
    assert shitcode(memoryview(b'\x00\xFF')) == u'??'



# Generated at 2022-06-10 21:46:13.111581
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class P(object):
        def __repr__(self):
            return u'a{0}c' + 'b' * 1000
    p = P()
    print(get_shortish_repr(p))
    print(get_shortish_repr(p, max_length=None))
    print(get_shortish_repr(p, max_length=20))
    print(get_shortish_repr(p, max_length=10))
    print(get_shortish_repr(p, max_length=5))
    print(get_shortish_repr(p, max_length=2))
    print(get_shortish_repr(p, max_length=1))
    print(get_shortish_repr(p, normalize=True))

# Generated at 2022-06-10 21:46:18.644585
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .compatibility import mock

    class WritableStreamMock(WritableStream):
        def write(self, s):
            pass

    writable_stream_mock = WritableStreamMock()

    writable_stream_mock.write('hi')

    with mock.patch.object(writable_stream_mock, 'write') as patched_write:
        writable_stream_mock.write('hi')

    patched_write.assert_called_once_with('hi')

# Generated at 2022-06-10 21:46:25.997175
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('asdf') == "'asdf'"
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(1.0) == '1.0'
    assert get_shortish_repr(1.0, max_length=2) == '1.'
    assert get_shortish_repr(1.0, max_length=3) == '1.0'
    assert get_shortish_repr(1.0, max_length=4) == '1.0'
    assert get_shortish_repr(1.0, max_length=5) == '1.0'

# Generated at 2022-06-10 21:46:31.244766
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from io import StringIO
    from .writable_stream import WritableStream
    # Making a stream
    stream = StringIO()
    assert isinstance(stream, WritableStream)
    # Writing to it
    stream.write('hi')
    # Reading from it
    assert stream.getvalue() == 'hi'




# Generated at 2022-06-10 21:46:34.345482
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('אאאאאאאאאאאאאאאאאאאאאאאאאאאאאאאאא') == '?????????????????????????????????????'



# Generated at 2022-06-10 21:46:46.308435
# Unit test for function get_repr_function
def test_get_repr_function():

    def foo(x):
        pass

    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(int, foo)]) == foo

    class C(object):
        pass

    c = C()

    assert get_repr_function(c, [(C, foo)]) == foo
    assert get_repr_function(c, [(object, foo)]) == foo
    assert get_repr_function(c, [(int, foo)]) == repr

    assert get_repr_function(c, [(lambda x: isinstance(x, int), foo)]) == repr



# Generated at 2022-06-10 21:46:58.038317
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (
        (int, str),
        (str, int),
        (float, lambda x: '{0:f}'.format(x)),
    )) == str
    assert get_repr_function('1', (
        (int, str),
        (str, int),
        (float, lambda x: '{0:f}'.format(x)),
    )) == int
    assert (get_repr_function(1, (
        (int, str),
        (lambda x: isinstance(x, str), int),
    ))) == str

# Generated at 2022-06-10 21:47:00.433256
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyTestClass(WritableStream): pass
    my_test_object = MyTestClass()
    try:
        my_test_object.write('some string')
    except NotImplementedError:
        pass
    else:
        raise Exception




# Generated at 2022-06-10 21:47:10.677413
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode(u'abc') == u'abc'
    assert shitcode('\xFF') == '?'
    assert shitcode(u'\xFF') == u'?'
    assert shitcode('\x00') == '?'
    assert shitcode(u'\x00') == u'?'
    assert shitcode('\x01') == '\x01'
    assert shitcode(u'\x01') == u'\x01'
    assert shitcode('\xFE') == '\xFE'
    assert shitcode(u'\xFE') == u'\xFE'



# Generated at 2022-06-10 21:47:13.769642
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MockedStdout(WritableStream):
        def write(self, s):
            sys.stdout.write(s)

    mocked_stdout = MockedStdout()

    mocked_stdout.write('hi')

# Generated at 2022-06-10 21:47:21.833679
# Unit test for function shitcode
def test_shitcode():
    the_string = '\n\r\t'
    the_string += chr(0) * 2
    the_string += chr(1)
    the_string += 'abc'
    the_string += chr(254)
    the_string += chr(255) * 2

    assert shitcode(the_string) == (
        '\n\r\t'
        '??'
        '?'
        'abc'
        '?'
        '??'
    )

# Generated at 2022-06-10 21:47:26.432911
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import StringIO
    class X(WritableStream):
        def write(self, s):
            pass
    assert issubclass(X, WritableStream)
    x = X()
    x.write('hey')
    assert issubclass(StringIO.StringIO, WritableStream)

# Generated at 2022-06-10 21:47:35.211085
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C: pass
    class D: pass
    a = A()
    b = B()
    c = C()
    d = D()

    custom_repr = [
        (A, lambda x: '<A>'),
        (lambda x: isinstance(x, B), lambda x: '<B>'),
        (C, lambda x: '<C>'),
        (D, lambda x: '<D>'),
    ]

    assert get_repr_function(a, custom_repr)() == '<A>'
    assert get_repr_function(b, custom_repr)() == '<B>'
    assert get_repr_function(c, custom_repr)() == '<C>'
    assert get_repr_function

# Generated at 2022-06-10 21:47:47.150558
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('bla', [(str, lambda x: x + '!')]) == 'bla!'
    assert get_repr_function(3, [(str, lambda x: x + '!')]) == repr
    assert get_repr_function('bla', [(int, lambda x: x + '!')]) == repr
    assert get_repr_function(3, [(int, lambda x: 'hello')]) == 'hello'
    assert get_repr_function(3, [(int, lambda x: x + '!')]) == '3!'
    assert get_repr_function(3, [(int, lambda x: x + '!'), (str, lambda x: 'str')]) == '3!'

# Generated at 2022-06-10 21:47:54.297136
# Unit test for function get_repr_function
def test_get_repr_function():
    repr_function = get_repr_function(10j, ((int, lambda x: 'i')))
    assert repr_function(10j) == 'i'

    repr_function = get_repr_function(10j, ((float, int)))
    assert repr_function(10j) == 'int'

    repr_function = get_repr_function(10, ((lambda x: x > 5, lambda x: 'Big')))
    assert repr_function(10) == 'Big'



# Generated at 2022-06-10 21:48:01.355171
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(Exception(), [(Exception, str)]) is str
    assert get_repr_function(Exception(), [(BaseException, str)]) is str
    assert get_repr_function(Exception(), [(OSError, str)]) is repr



# Generated at 2022-06-10 21:48:12.710335
# Unit test for function get_repr_function
def test_get_repr_function():
    class A:
        pass
    class B:
        def __repr__(self):
            return '>repr-B<'

    a = A()
    b = B()

    assert get_repr_function(a, ()) is repr
    assert get_repr_function(a, ((str, None),)) is repr
    assert get_repr_function(a, ((A, None),)) is A.__repr__

    assert get_repr_function(b, ()) is B.__repr__
    assert get_repr_function(b, ((str, None),)) is B.__repr__
    assert get_repr_function(b, ((A, None),)) is B.__repr__



# Generated at 2022-06-10 21:48:15.554612
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C:
        def write(self, s):
            return 'hello'
    c = C()
    assert issubclass(C, WritableStream)
    assert c.write('not_used') == 'hello'



# Generated at 2022-06-10 21:48:28.326200
# Unit test for function get_repr_function
def test_get_repr_function():
    class A:
        pass
    class B:
        pass
    class C(A):
        pass
    class D(C):
        pass

    def b_repr(b):
        return 'b_repr(%r)' % b

    reprs = (
        (lambda b: b.__class__ is B, b_repr),
        (lambda b: b.__class__ is A, lambda a: 'a_repr(%r)' % a),
        (lambda b: b.__class__ is D, lambda d: 'd_repr(%r)' % d),
    )


# Generated at 2022-06-10 21:48:39.717605
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    """Testing function get_shortish_repr."""
    import pytest
    # regular strings
    assert get_shortish_repr('hello') == "hello"
    assert get_shortish_repr('hello', max_length=10) == "hello"
    assert get_shortish_repr('hello', max_length=4) == "hel..."

    # unicode strings
    assert get_shortish_repr(u'hello') == u"hello"
    assert get_shortish_repr(u'hello', max_length=10) == u"hello"
    assert get_shortish_repr(u'hello', max_length=4) == u"hel..."

    # custom repr
    class Example(object):
        def __repr__(self):
            return 'custom'

    assert get_shortish

# Generated at 2022-06-10 21:48:46.766574
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .python_toolbox import cute_testing
    assert get_shortish_repr(13) == '13'
    assert get_shortish_repr(13, max_length=2) == '13'
    assert get_shortish_repr(13, max_length=1) == '1...'
    assert get_shortish_repr(13, max_length=0) == '...'
    assert get_shortish_repr(13, max_length=None) == '13'
    assert get_shortish_repr(13, max_length=-1) == '13'
    assert get_shortish_repr(13, normalize=True) == '13'

# Generated at 2022-06-10 21:48:49.048322
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class ExampleClass(WritableStream):

        def write(self, s):
            pass

    assert issubclass(ExampleClass, WritableStream)



# Generated at 2022-06-10 21:48:54.098137
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Child(WritableStream):
        def write(self, s):
            pass

    assert issubclass(Child, WritableStream)
    assert not issubclass(object, WritableStream)
    assert not issubclass(Child, WritableStream)



# Generated at 2022-06-10 21:48:55.760756
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(object):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)



# Generated at 2022-06-10 21:49:01.836426
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import sys
    n = get_shortish_repr(sys, normalize=True)
    assert n == "module 'sys'"
    assert len(n) > 20
    n = get_shortish_repr(sys, normalize=True, max_length=20)
    assert n == "module 'sys'"
    assert len(n) == 20



# Generated at 2022-06-10 21:49:07.754577
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    def write(s):
        assert isinstance(s, string_types)


    class MyWritableStream(WritableStream):
        write = write

    print('hooray!')




# Generated at 2022-06-10 21:49:12.874072
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def __init__(self):
            self.write_log = []
        def write(self, s):
            self.write_log.append(s)

    ws = WritableStreamSubclass()
    ws.write('hello')
    assert ws.write_log == ['hello']



# Generated at 2022-06-10 21:49:17.108255
# Unit test for function get_repr_function
def test_get_repr_function():
    def f(x):
        return 'f({})'.format(x)
    assert get_repr_function(0, custom_repr=(
        (lambda x: x < 3, f),
    )) is f
    assert get_repr_function(4, custom_repr=(
        (lambda x: x < 3, f),
    )) is repr

# Generated at 2022-06-10 21:49:21.720396
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def __init__(self):
            self.buffer = []

        def write(self, s):
            self.buffer.append(s)

    foo = Foo()
    foo.write('hello world')
    assert foo.buffer == ['hello world']

# Generated at 2022-06-10 21:49:31.754552
# Unit test for function get_repr_function
def test_get_repr_function():
    assert (get_repr_function([1, 2, 3], [(list, lambda x: 'This is a list.')]) ==
                                                   'This is a list.')
    assert (get_repr_function('foo', [(list, lambda x: 'This is a list.')]) ==
                                                                    repr('foo'))
    assert (get_repr_function(
        [1, 2, 3], [(list, lambda x: 'This is a list.'), (str, lambda x: 'x')]
    ) == 'This is a list.')
    assert (get_repr_function('foo', [(list, lambda x: 'This is a list.'),
                                                     (str, lambda x: 'x')]) ==
                                                                        'x')

# Generated at 2022-06-10 21:49:37.440620
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import types
    class MyStream(io.StringIO):
        def write(self, s):
            super(MyStream, self).write(s)
    assert issubclass(MyStream, WritableStream)
    assert type(sys.stdout) is not types.FileType
    assert issubclass(type(sys.stdout), WritableStream)

# Generated at 2022-06-10 21:49:40.518968
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = ''

        def write(self, s):
            self.written_stuff += s

    test_WritableStream().write('spam')

# Generated at 2022-06-10 21:49:47.980252
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.items = []
        def write(self, s):
            self.items.append(s)

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('a')
    my_writable_stream.write('b')
    my_writable_stream.write('c')
    assert my_writable_stream.items == ['a', 'b', 'c']



# Generated at 2022-06-10 21:49:57.611182
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(B): pass
    assert get_repr_function(A(), []) is repr
    assert get_repr_function(A(), []) is repr
    assert get_repr_function(B(), []) is repr
    assert get_repr_function(C(), []) is repr
    assert get_repr_function(A(), [(A, lambda x: 'A')]) is repr
    assert get_repr_function(B(), [(A, lambda x: 'A')]) is repr
    assert get_repr_function(C(), [(A, lambda x: 'A')]) is repr
    assert get_repr_function(A(), [(A, lambda x: 'A'), (B, lambda x: 'B')]) is repr
    assert get_repr_function

# Generated at 2022-06-10 21:50:07.163044
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('1', []) is repr
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function('1', [(int, str)]) is repr
    assert get_repr_function(1, [
        (lambda x: isinstance(x, int), str)
    ]) == str
    assert get_repr_function('1', [(lambda x: isinstance(x, int), str)]) is repr
    assert get_repr_function(1, [(int, str), (str, len)]) == str
    assert get_repr_function('1', [(int, str), (str, len)]) == len



# Generated at 2022-06-10 21:50:19.061040
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) is repr
    assert get_repr_function(1, (('', lambda x: x+1))) == 1 + 1
    assert get_repr_function(1, ((lambda x: True, lambda x: x+1))) == 1 + 1
    assert get_repr_function(None, ((None, lambda x: x+1))) == None + 1
    assert (get_repr_function(1, ((Exception, lambda x: x+1))) is None)
    assert get_repr_function(None, ((None, lambda x: x+1),)) == None + 1
    assert (get_repr_function(None, ((None, lambda x: x+1), (None,
                                                             lambda x: x+2)))) == None + 2





# Generated at 2022-06-10 21:50:31.931241
# Unit test for function get_repr_function
def test_get_repr_function():
    class Person(object):
        def __init__(self, name, age):
            self.name = name
            self.age = age
        def __repr__(self):
            return 'Person(name={}, age={})'.format(self.name, self.age)
    alice = Person('Alice', 20)
    bob = Person('Bob', 22)

    x = get_repr_function(alice, [(Person, lambda x: x.name)])
    assert x is alice.name
    y = get_repr_function(bob, [(Person, lambda x: x.name)])
    assert y is bob.name
    z = get_repr_function(alice, [(Person, lambda x: x.age)])
    assert z is alice.age


# Generated at 2022-06-10 21:50:43.833003
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, custom_repr=((int, str),)) == str
    assert get_repr_function(4.5, custom_repr=((int, str),)) == repr
    assert get_repr_function(4.5, custom_repr=((int, str), (float, float.hex))) == float.hex

# Generated at 2022-06-10 21:50:48.248603
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('foo', ()) is repr
    assert get_repr_function('foo', [(str, 'bar')]) is repr
    assert get_repr_function('foo', [(str, lambda x: 'bar')]) == 'bar'

# Generated at 2022-06-10 21:50:52.570270
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class PseudoWritableStream:
        def __init__(self):
            self._calls = []
        def write(self, s):
            self._calls.append(s)
    assert isinstance(PseudoWritableStream(), WritableStream)
    pseudo_writable_stream = PseudoWritableStream()
    pseudo_writable_stream.write('a')
    assert pseudo_writable_stream._calls == ['a']



# Generated at 2022-06-10 21:50:54.944270
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            self.s = s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.s == 'hello'

# Generated at 2022-06-10 21:50:58.195173
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritable(WritableStream):
        def write(self, s):
            return super().write(s)
    MyWritable().write('foo')




# Generated at 2022-06-10 21:51:03.988259
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def __init__(self):
            self.writes = []
        def write(self, s):
            self.writes.append(s)

    foo = Foo()
    foo.write('bar')
    assert foo.writes == ['bar']
    foo.write('baz')
    assert foo.writes == ['bar', 'baz']

# Generated at 2022-06-10 21:51:12.288811
# Unit test for function get_repr_function
def test_get_repr_function():
    class MyClass(object):
        def __init__(self, x):
            self.x = x
        def __repr__(self):
            return repr(self.x)
    def myrepr(x):
        return 'a'
    expected_result = {
        1: repr,
        3.4: repr,
        MyClass(4): repr,
        MyClass(6): myrepr,
        MyClass(2): myrepr,
    }
    for item in expected_result:
        result = get_repr_function(
            item,
            custom_repr=((lambda x: x.x == 2, myrepr), (MyClass, myrepr)),
        )
        expected = expected_result[item]
        assert result == expected



# Generated at 2022-06-10 21:51:23.816074
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1.0, ()) == repr
    assert get_repr_function('', ()) == repr
    assert get_repr_function(u'', ()) == repr
    assert get_repr_function(None, ()) == repr
    assert get_repr_function(object(), ()) == repr
    assert get_repr_function(object, ()) == repr
    assert get_repr_function(Exception, ()) == repr
    assert get_repr_function(1, ((int, str), lambda x: 'x')) == repr
    assert get_repr_function(1.0, ((int,), lambda x: 'x')) == repr

# Generated at 2022-06-10 21:51:39.696309
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(B): pass
    class E(B): pass
    class F(C, D): pass
    assert get_repr_function(A(), []) is repr
    assert get_repr_function(B(), []) is repr
    assert get_repr_function(C(), []) is repr
    assert get_repr_function(D(), []) is repr
    assert get_repr_function(E(), []) is repr
    assert get_repr_function(F(), []) is repr
    assert get_repr_function(A(), [(A, id)]) is id
    assert get_repr_function(B(), [(A, id)]) is repr

# Generated at 2022-06-10 21:51:41.954077
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class F:
        def write(self, s): pass

    x = F()
    assert isinstance(x, WritableStream)

# Generated at 2022-06-10 21:51:54.432946
# Unit test for function get_repr_function

# Generated at 2022-06-10 21:51:58.822464
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(TestWritableStream, WritableStream)
    assert isinstance(TestWritableStream(), WritableStream)



# Generated at 2022-06-10 21:52:09.790158
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(42, ((lambda a: True, int))) == int
    assert get_repr_function('meow', ((lambda a: True, int))) == int
    assert get_repr_function(None, ((lambda a: True, int))) == int
    assert get_repr_function(42, ((lambda a: False, int))) == repr
    assert get_repr_function('meow', ((lambda a: False, int))) == repr
    assert get_repr_function(None, ((lambda a: False, int))) == repr
    assert get_repr_function(
        42,
        ((lambda a: False, int), (lambda a: True, str), (lambda a: False, float))
    ) == str

# Generated at 2022-06-10 21:52:14.699433
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('s', []) is repr
    assert get_repr_function('s', [(str, str)]) is str
    assert get_repr_function('s', [(str, str), (int, int)]) is str
    assert get_repr_function(2, [(str, str), (int, int)]) is int
    assert get_repr_function('s', [(lambda x: x == 's', str), (int, int)]) is str
    assert get_repr_function(2, [(lambda x: x == 's', str), (int, int)]) is int
    assert get_repr_function(2, [('s', str), (int, int)]) is int

# Generated at 2022-06-10 21:52:21.543555
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hello', (
        (lambda x: isinstance(x, int), lambda x: 'int: ' + str(x)),
        (lambda x: x == 42, lambda x: '42'),
    )) == repr


# Generated at 2022-06-10 21:52:32.130036
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    g = lambda: 1
    assert get_shortish_repr(g) == '<function test_get_shortish_repr.<locals>.<lambda>>'
    assert get_shortish_repr(g, max_length=22) == '<function test_get_shortish_repr.<locals>.<lambda>>'
    assert get_shortish_repr(g, max_length=21) == '<function test_get_shortish_repr.<locals>.<lambda>'
    assert get_shortish_repr(g, max_length=20) == '<function test_get_sh...<lambda>'

    class C:
        pass
    c = C()

# Generated at 2022-06-10 21:52:43.862068
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(object): pass
    class C(A): pass
    class D(object): pass
    class E(D): pass
    a = A()
    b = B()
    c = C()
    d = D()
    e = E()
    assert get_repr_function(a, custom_repr=[]) == repr
    assert get_repr_function(a, custom_repr=[(A, '{}')]) == '{}'
    assert get_repr_function(a, custom_repr=[(A, '{}'), (A, repr)]) == repr
    assert get_repr_function(a, custom_repr=[(B, '{}'), (A, repr)]) == repr

# Generated at 2022-06-10 21:52:48.658477
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert isinstance(MyWritableStream(), WritableStream) is True
    try:
        class BadWritableStream:
            def write(self, s):
                pass
    except TypeError:
        pass
    else:
        assert False, 'TypeError should be raised by bad class'

# Generated at 2022-06-10 21:52:59.764013
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .abc import FrozenThing

    ft = FrozenThing('abcdefg')
    assert get_shortish_repr(ft) == repr(ft)
    assert get_shortish_repr(ft, max_length=None) == repr(ft)
    assert get_shortish_repr(ft, max_length=8) == repr(ft)
    assert get_shortish_repr(ft, max_length=9) == repr(ft)
    assert get_shortish_repr(ft, max_length=10) == repr(ft)
    assert get_shortish_repr(ft, max_length=11) == repr(ft)
    assert get_shortish_repr(ft, max_length=12) == repr(ft)

# Generated at 2022-06-10 21:53:03.979404
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C(WritableStream):
        def write(self, s):
            pass
    assert issubclass(C, WritableStream)
    assert issubclass(sys.__stdout__.__class__, WritableStream)

# Generated at 2022-06-10 21:53:13.931366
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert (get_shortish_repr('hello', max_length=3) == 'hel')
    assert (get_shortish_repr(42, max_length=3) == '42')
    assert (get_shortish_repr('hello', max_length=15) == 'hello')
    assert (get_shortish_repr({1, 2, 3}, max_length=15) == '{1, 2, 3}')
    assert (get_shortish_repr(
        {1, 2, 3, 4, 5, 6, 7}, max_length=11) == '{1, 2, 3...}'
    )

# Generated at 2022-06-10 21:53:26.156551
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function((1, 2), []) is repr
    assert get_repr_function((1, 2), [(lambda x: True, list)]) is list
    assert get_repr_function((1, 2), [(lambda x: True, lambda x: list(x))]) \
                                                        is list
    assert get_repr_function((1, 2, 3), [(lambda x: len(x) == 2, list)]) \
                                                                is repr
    assert get_repr_function((1, 2), [(lambda x: len(x) == 2, list)]) \
                                                                is list

    assert get_repr_function((1, 2), [(tuple, list)]) is list

# Generated at 2022-06-10 21:53:31.450577
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Mock:
        def write(self, s):
            self.s = s
    instance = Mock()
    WritableStream.register(Mock)
    assert issubclass(Mock, WritableStream)
    instance.write('hi')
    assert instance.s == 'hi'



# Generated at 2022-06-10 21:53:34.986195
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (int, lambda x: str(x))) == str
    assert get_repr_function(None, (int, lambda x: str(x))) == repr



# Generated at 2022-06-10 21:53:37.240273
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import sys
    assert issubclass(io.StringIO, WritableStream)
    assert issubclass(sys.stdout, WritableStream)

# Generated at 2022-06-10 21:53:47.990501
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda item: isinstance(item, int), lambda item: '%s (integer)' % item),
        (int, lambda item: '%s (int)' % item),
        (list, lambda item: '%s (list)' % item),
    )
    assert get_repr_function(1, custom_repr) is repr
    assert get_repr_function(1.0, custom_repr) is repr
    assert get_repr_function([1], custom_repr)([1]) == '[1] (list)'
    assert get_repr_function([1.0], custom_repr)([1.0]) == '[1.0]'



# Generated at 2022-06-10 21:53:59.119452
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=0) == '...'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'


# Generated at 2022-06-10 21:54:02.204476
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .write import StringIOWrapper
    stream = StringIOWrapper()
    assert isinstance(stream, WritableStream)

# Generated at 2022-06-10 21:54:18.866244
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from pytest import raises
    import string

    assert get_shortish_repr('') == "''"
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abcdef') == "'abcdef'"
    assert get_shortish_repr('abcdef', normalize=True) == "'abcdef'"
    assert get_shortish_repr('abcdef', max_length=5) == "'…def'"
    assert get_shortish_repr('abcdef', max_length=5, normalize=True) == "'…def'"
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr((1, 2, 3), max_length=4) == '(1, 2…)'
    assert get_shortish_repr

# Generated at 2022-06-10 21:54:25.214221
# Unit test for function get_repr_function
def test_get_repr_function():
    class X(object): pass
    class Y(object): pass
    assert get_repr_function(X(), ()) is repr
    assert get_repr_function(Y(), (
        (lambda o: o.__class__ is X, lambda o: 'X'),
        (Y, lambda o: 'Y'),
    )) is repr
    assert get_repr_function(X(), (
        (lambda o: o.__class__ is X, lambda o: 'X'),
        (Y, lambda o: 'Y'),
    )) == 'X'
    assert get_repr_function(Y(), (
        (lambda o: o.__class__ is X, lambda o: 'X'),
        (Y, lambda o: 'Y'),
    )) == 'Y'



# Generated at 2022-06-10 21:54:36.801687
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1.5) == '1.5'
    assert get_shortish_repr(1.5000006) == '1.5000006'
    assert get_shortish_repr(1.5000006, max_length=20) == '1.5000006'
    assert get_shortish_repr(1.5000006, max_length=20, normalize=True) == \
                                                                    '1.5000006'
    assert get_shortish_repr(1.5000006, max_length=4) == '...6'
    assert get_shortish_repr(1.5000006, max_length=4, normalize=True) == '...6'

# Generated at 2022-06-10 21:54:40.089023
# Unit test for function get_repr_function
def test_get_repr_function():
    assert(get_repr_function(1, []) == repr)
    assert(get_repr_function('a', [(int, lambda x: 'int')]) == repr)

# Generated at 2022-06-10 21:54:44.891837
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass

    class WritableStreamSubSubclass(WritableStreamSubclass):
        pass

    assert (
        issubclass(WritableStreamSubclass, WritableStream) and
        issubclass(WritableStreamSubSubclass, WritableStream)
    )





# Generated at 2022-06-10 21:54:56.918415
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(object):
        pass

    assert type(get_repr_function(C(), (
        (B, lambda x: 'B'+':'+repr(x)),
        (A, lambda x: 'A'+':'+repr(x)),
    ))) == type(repr)
    assert get_repr_function(C(), (
        (B, lambda x: 'B'+':'+repr(x)),
        (A, lambda x: 'A'+':'+repr(x)),
    ))(C()) == 'B:<__main__.C object at 0x'


# Generated at 2022-06-10 21:55:01.363458
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (float, str))) is str
    assert get_repr_function(1.0, ((int, str), (float, str))) is str



# Generated at 2022-06-10 21:55:06.390730
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr

    assert get_repr_function(1, ((int, lambda x: x * 2),)) == (lambda x: x * 2)
    assert get_repr_function(1, ((lambda x: x == 1, lambda x: x * 2),)) == (
        lambda x: x * 2)
    assert get_repr_function(1, ((2, lambda x: x * 2),)) == repr

