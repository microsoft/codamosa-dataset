

# Generated at 2022-06-10 21:45:21.422350
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr('abc', max_length=3) == 'abc'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr('abc', max_length=2) == 'ab...'
    assert get_shortish_repr([1, 2, 3, 4], max_length=10) == '[1, 2, 3, 4]'
    assert get_shortish_repr([1, 2, 3, 4], max_length=9) == '[1, 2...'
    assert get_shortish_repr([1, 2, 3, 4], max_length=8) == '[1...'



# Generated at 2022-06-10 21:45:25.965505
# Unit test for function get_repr_function
def test_get_repr_function():
    def my_repr(item):
        return 'In my_repr'
    my_dict = {'a': 'b'}
    assert get_repr_function(my_dict, ((dict, my_repr),)) is my_repr



# Generated at 2022-06-10 21:45:37.119977
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import collections
    import io
    from .cache import WeakKeyCache
    from .context_manager import ContextManager

    # First we need to inject an actual WritableStream into
    # abc.ABCMeta._abc_registry, so that the subclasses will be registered.
    ws = WeakKeyCache(WritableStream)
    ws[io.BytesIO] = None

    for i in range(10):
        for class_ in sorted(ws, key=str):
            assert issubclass(class_, WritableStream)
        io.BytesIO.write = None
        assert not issubclass(io.BytesIO, WritableStream)

    del io.BytesIO.write
    io.BytesIO.write = lambda self, string: sys.stdout.write(
        '{} got {}'.format(self, string)
    )

# Generated at 2022-06-10 21:45:46.878725
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1.23456789012345) == '1.23456789012345'
    assert get_shortish_repr(1.23456789012345, max_length=14) == '1.23456789012345'
    assert get_shortish_repr(1.23456789012345, max_length=13) == '1.234567890123...'
    assert get_shortish_repr(1.23456789012345, max_length=12) == '1.2345678901...'
    assert get_shortish_repr(1.23456789012345, max_length=11) == '1.234567890...'

# Generated at 2022-06-10 21:45:56.345156
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hello')])\
           == 'hello'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hello')])\
           == repr
    assert get_repr_function(1, [(int, lambda x: 'hello')])\
           == 'hello'
    assert get_repr_function(3, [(int, lambda x: 'hello')])\
           == 'hello'
    assert get_repr_function(3.5, [(int, lambda x: 'hello')])\
           == repr



# Generated at 2022-06-10 21:46:02.784165
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None) is repr
    assert get_repr_function(1) is repr
    assert get_repr_function('') is repr
    assert get_repr_function([]) is repr
    assert get_repr_function(()) is repr
    assert get_repr_function(set()) is repr
    assert get_repr_function({}) is repr

    # this class is not defined above, so we can use it as a temporary class
    class TempClass(object): pass
    class TempSubClass(TempClass): pass

    assert get_repr_function(TempClass()) is repr
    assert get_repr_function(TempSubClass()) is repr

    def custom_repr(x):
        return 'custom repr of ' + repr(x)


# Generated at 2022-06-10 21:46:06.381620
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """
    pytest.skip()
    class MyWritableStream(WritableStream):
        __slots__ = ()
        def write(self, s):
            pass

    assert isinstance(MyWritableStream(), WritableStream)
    """

# Generated at 2022-06-10 21:46:11.582888
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) is repr
    assert get_repr_function(1, ()) is repr
    assert get_repr_function('abc', ()) is repr
    assert get_repr_function(1.0, ()) is repr
    assert get_repr_function({}, ()) is repr
    assert get_repr_function(set(), ()) is repr
    assert get_repr_function(frozenset(), ()) is repr
    assert get_repr_function(list(), ()) is repr
    assert get_repr_function(tuple(), ()) is repr
    assert get_repr_function(123, ((lambda x: True, lambda x: 'a'),)) == 'a'
    assert get_repr_function(123, ((lambda x: False, lambda x: 'a'),)) is repr
    assert get

# Generated at 2022-06-10 21:46:24.676048
# Unit test for function shitcode

# Generated at 2022-06-10 21:46:35.276666
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=5) == "'he...'"
    assert get_shortish_repr('hello', max_length=5, normalize=True) == "'he...'"
    assert get_shortish_repr('hellooooooooo') == "'hellooooooooo'"
    assert get_shortish_repr(u'“𝄞”', max_length=6, normalize=True) \
                                                               == u"'“𝄞...'"
    assert get_shortish_repr(u'“𝄞”', max_length=7, normalize=True) \
                                                              == u"'“𝄞”'"

# Generated at 2022-06-10 21:46:39.823596
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def write(self, s):
            pass
    Foo()



# Generated at 2022-06-10 21:46:44.859497
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class FakeWritableStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(FakeWritableStream(), WritableStream)

    class FakeWritableStream2(WritableStream):
        def not_write(self, s):
            pass

    assert not isinstance(FakeWritableStream2(), WritableStream)


# Unit tests for method truncate

# Generated at 2022-06-10 21:46:48.510208
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestWritableStream(WritableStream):
        def write(self, s):
            pass
    TestWritableStream().write('asdf')



# Generated at 2022-06-10 21:46:55.790546
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: True, str)]) == str
    assert get_repr_function(1, [(lambda x: False, str)]) == repr
    assert get_repr_function(1, [(int, str)]) == str


if sys.version_info[0] == 2:
    def is_function(x):
        return type(x) in (type(int), type(test_get_repr_function))
else:
    is_function = callable



# Generated at 2022-06-10 21:46:59.048513
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(object):

        def write(self, s):
            pass

    assert issubclass(X, WritableStream)

    class X(object):
        pass

    assert not issubclass(X, WritableStream)



# Generated at 2022-06-10 21:47:04.026414
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, '<int>'),)) == '<int>'
    assert get_repr_function(1.0, custom_repr=((int, '<int>'),)) == repr
    assert get_repr_function(2, custom_repr=((lambda x: isinstance(x, int),
                                              '<int>'),)) == '<int>'
    assert get_repr_function(2.0, custom_repr=((lambda x: isinstance(x, int),
                                                '<int>'),)) == repr



# Generated at 2022-06-10 21:47:12.555831
# Unit test for function get_repr_function
def test_get_repr_function():
    class Alpha(object): pass
    class Beta(object): pass
    x = Alpha()
    y = Beta()
    custom_repr = [
        (Alpha, lambda s: 'alpha'),
        (Beta, lambda s: 'beta')
    ]
    assert get_repr_function(x, custom_repr=custom_repr)() == 'alpha'
    assert get_repr_function(y, custom_repr=custom_repr)() == 'beta'


# Unit tests for `shitcode`


# Generated at 2022-06-10 21:47:25.560657
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=10) == '1'
    assert get_shortish_repr(1, max_length=11) == '1'
    assert get_shortish_repr(1, max_length=12) == '1'

# Generated at 2022-06-10 21:47:30.402639
# Unit test for function get_repr_function
def test_get_repr_function():
    my_repr = lambda x: 'oh'
    assert get_repr_function(1, (('', my_repr),)) is my_repr
    for custom_repr in (
            (('', my_repr),),
            ((int, my_repr),),
            ((type(1), my_repr),),
            (((lambda x: x > 0), my_repr),),
            (((lambda x: x == 1), my_repr),),
            (((lambda x, y=1: x == y), my_repr),),
            (((lambda x, y=1: x is y), my_repr),),
    ):
        assert get_repr_function(1, custom_repr) is my_repr

# Generated at 2022-06-10 21:47:37.881823
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(['bla']) == "['bla']"
    assert get_shortish_repr(['bla'], max_length=4) == "['b..."
    assert get_shortish_repr('bla') == "'bla'"
    assert get_shortish_repr('bla', max_length=2) == "'..."

    assert get_shortish_repr('bla', normalize=True) == "'bla'"
    assert get_shortish_repr('bla', max_length=9, normalize=True) == "'bla'"
    assert get_shortish_repr('bla', max_length=8, normalize=True) == "'b..."


# Generated at 2022-06-10 21:47:47.481487
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, []) == repr
    assert get_repr_function(0, [(lambda x: x == 0, lambda x: 'hi')]) == \
                                                                     (lambda x: 'hi')
    assert get_repr_function(0, [(int, lambda x: 'hi')]) == (lambda x: 'hi')
    assert get_repr_function(1, [(int, lambda x: 'hi')]) == repr



# Generated at 2022-06-10 21:47:51.623820
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'normal') == 'normal'
    assert shitcode(u'\u2661') == '?'
    assert shitcode(u'\u2661\u2661\u2661') == '???'



# Generated at 2022-06-10 21:48:00.394837
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .testing import (
        assert_equal, assert_true, assert_false, assert_is_none, assert_raises
    )

    long_repr = 'a' * 1000
    long_repr_truncated = 'a' * 497 + '...' + 'a' * 3

    class A(object):
        def __repr__(self):
            return long_repr

    a = A()

    assert_equal(
        get_shortish_repr(
            a,
            max_length=None
        ),
        long_repr
    )

    assert_equal(
        get_shortish_repr(
            a,
            max_length=500
        ),
        long_repr_truncated
    )


# Generated at 2022-06-10 21:48:13.569865
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, []) == repr
    assert get_repr_function('', []) == repr
    assert get_repr_function(0, [(lambda x: x == 0, (lambda x: 'zero'))]) == \
                                                                   (lambda x: 'zero')
    assert get_repr_function('', [(lambda x: x == '', (lambda x: 'empty'))]) == \
                                                                   (lambda x: 'empty')
    assert get_repr_function('', [(lambda x: False, (lambda x: 'empty'))]) == repr

# Generated at 2022-06-10 21:48:16.587358
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import builtins

    class MyFile(builtins.file):
        def write(self, x):
            pass
        def writelines(self, x):
            pass

    assert isinstance(MyFile('some_path.txt', 'w'), WritableStream)



# Generated at 2022-06-10 21:48:20.303431
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('привет') == '??????'
    assert shitcode('\xfe\xff') == '??'




# Generated at 2022-06-10 21:48:26.101031
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            print(s)
    MyWritableStream().write('hi')


if __name__ == '__main__':
    test_WritableStream_write()
    for _ in range(100):
        _ == truncate('123456789', 7)

# Generated at 2022-06-10 21:48:28.912833
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class writable(WritableStream):
        def write(self, s):
            pass

    assert isinstance(writable(), WritableStream)

# Generated at 2022-06-10 21:48:40.165417
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('foo', max_length=None) == 'foo'
    assert get_shortish_repr('foo', max_length=2) == 'foo'
    assert get_shortish_repr('foobar', max_length=3) == 'fo...'
    assert get_shortish_repr('foobar', max_length=5) == 'foo...'
    assert get_shortish_repr('foo', max_length=5) == 'foo'
    assert get_shortish_repr('foobar', max_length=6) == 'foobar'
    assert get_shortish_repr(set([1, 2, 3]), max_length=7) == '{1, 2, ...'

# Generated at 2022-06-10 21:48:44.323444
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import types
    import doctest
    write_test_stream = types.SimpleNamespace(write=lambda x: None)
    assert issubclass(type(write_test_stream), WritableStream)
    class NotWritableStream:
        def whatever(self, x):
            pass
    assert not issubclass(type(NotWritableStream()), WritableStream)



# Generated at 2022-06-10 21:48:54.661356
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hello', custom_repr=()) == repr
    assert get_repr_function('hello', custom_repr=((str, str),)) == str
    assert get_repr_function(5, custom_repr=((str, str),)
                             ) == normalize_repr
    assert get_repr_function(5, custom_repr=((lambda x: x.real > 0, str),)
                             ) == str



# Generated at 2022-06-10 21:49:03.095176
# Unit test for function get_repr_function

# Generated at 2022-06-10 21:49:13.639034
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(A):
        pass

    assert issubclass(B, WritableStream)

    class C(A):
        def write(self, s):
            pass

    assert issubclass(C, WritableStream)

    class D(C):
        def write(self, s):
            pass

    assert issubclass(D, WritableStream)

    class E(D):
        pass

    assert issubclass(E, WritableStream)

    class F(WritableStream):
        pass

    assert issubclass(F, WritableStream) is NotImplemented

    class G(F):
        def write(self, s):
            pass


# Generated at 2022-06-10 21:49:18.322799
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeWritableStream:
        def write(self, s):
            pass

    class AnotherFakeWritableStream:
        def write(self, s):
            pass

        def make_coffee(self, number_of_cups):
            pass

    assert isinstance(FakeWritableStream(), WritableStream)
    assert isinstance(AnotherFakeWritableStream(), WritableStream)




# Generated at 2022-06-10 21:49:28.625142
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    r = get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=17)
    assert r == 'abcdefghijklmnopq'
    r = get_shortish_repr(object(), max_length=30)
    assert r == '<object object at '
    r = get_shortish_repr(object(), max_length=30, normalize=True)
    assert r == '<object object>'
    r = get_shortish_repr([object(), object(), object()], max_length=20)
    assert r == '[<object object at '
    r = get_shortish_repr([object(), object(), object()],
                          max_length=20, normalize=True)
    assert len(r) < 21

# Generated at 2022-06-10 21:49:36.564661
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    def repr_A(x): return 'repr_A'

    def repr_B(x): return 'repr_B'

    global_repr_call_counter = 0

    def global_repr(x):
        global global_repr_call_counter
        global_repr_call_counter += 1
        return global_repr_call_counter

    custom_repr = (
        (lambda x: isinstance(x, A), repr_A),
        (repr_B, lambda x: isinstance(x, str)),
        (lambda x: True, global_repr),
    )
    assert get_repr_function(A(), custom_repr) is repr_A
   

# Generated at 2022-06-10 21:49:47.278227
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr('a') == "'a'"
    assert get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert get_shortish_repr(object()) == '<object object at 0x...>'
    assert get_shortish_repr(lambda a: a) == \
           '<function <lambda> at 0x...>'
    assert get_shortish_repr((1, 2, 3)) == '(1, 2, 3)'
    assert get_shortish_repr(xrange(0, 100)) == \
           'xrange(100)'

# Generated at 2022-06-10 21:49:49.103500
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class _MyTestStream(WritableStream):
        def write(self, s):
            sys.stdout.write(shitcode(s))

    stream = _MyTestStream()
    stream.write('foo')

# Generated at 2022-06-10 21:49:53.638283
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        text = b''
        def write(self, data):
            if isinstance(data, str):
                data = data.encode('utf-8')
            self.text += data

    stream = MyWritableStream()
    assert isinstance(stream, WritableStream)



# Generated at 2022-06-10 21:50:00.922501
# Unit test for function get_repr_function
def test_get_repr_function():
    attributes = ['a', 'b', 'c']
    class Class:
        __repr__ = lambda self: "Class"
    class Class_1:
        __repr__ = lambda self: "Class_1"
        def __init__(self, *args):
            for arg, attribute in zip(args, attributes):
                setattr(self, attribute, arg)
    class Class_2(Class_1):
        __repr__ = lambda self: "Class_2"
    class Class_3(Class_2):
        __repr__ = lambda self: "Class_3"
    class Class_4(Class_1):
        __repr__ = lambda self: "Class_4"

# Generated at 2022-06-10 21:50:08.718723
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.text = ''
        def write(self, s):
            self.text += s
    s = MyWritableStream()
    s.write('hello ')
    s.write('world')
    assert s.text == 'hello world'



# Generated at 2022-06-10 21:50:15.251503
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = []
        def write(self, s):
            self.written.append(s)

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    my_writable_stream.write('world')
    assert my_writable_stream.written == ['hello', 'world']


# Generated at 2022-06-10 21:50:26.789788
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert normalize_repr('A at 0xca') == 'A'
    assert normalize_repr('A') == 'A'
    assert normalize_repr('B ') == 'B '

    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr('A') == "'A'"

    assert get_shortish_repr(5, max_length=3) == '5'
    assert get_shortish_repr(5, max_length=2) == '5'
    assert get_shortish_repr(5, max_length=1) == '5'
    assert get_shortish_repr(5, max_length=0) == '...'
    assert get_shortish_repr(5, max_length=-1) == '...'



# Generated at 2022-06-10 21:50:34.491772
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[]) is repr
    assert get_repr_function(1, custom_repr=[(int, str)]) is str
    assert get_repr_function(1, custom_repr=[(lambda i: i == 2, lambda x: x)]) \
                                                                          is repr

# Generated at 2022-06-10 21:50:45.583788
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(A): pass

    a = A()
    b = B()
    c = C()
    d = 1  # noqa
    e = 'abc'  # noqa

    assert get_repr_function(b, custom_repr=[(B, 'b_repr')]) == 'b_repr'
    assert get_repr_function(c, custom_repr=[(B, 'b_repr')]) == repr
    assert get_repr_function(a, custom_repr=[(B, 'b_repr')]) == repr

    assert get_repr_function(b, custom_repr=[(A, 'a_repr')]) == 'a_repr'

# Generated at 2022-06-10 21:50:51.008187
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('', ()) == repr
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ([(lambda x: x is 1, lambda x: x)])) == repr
    assert get_repr_function(1, ([(lambda x: x is 2, lambda x: x)])) != repr



# Generated at 2022-06-10 21:51:03.549272
# Unit test for function get_repr_function
def test_get_repr_function():
    from .pattern_matching import Pattern
    from .python_toolbox import Missing
    from .cute_iter_tools import ilen

    A = type('a', (object,), {})
    a = A()

    def test(custom_repr, item, expected):
        result = get_repr_function(item, custom_repr)
        assert result is expected, (custom_repr, item, expected, result)

    test(((lambda x: x is A, lambda x: 'A'), ), a, repr)
    test(((A, lambda x: 'A'), ), a, lambda x: 'A')
    test(((A, str), ), a, str)
    test(((A, str), (A, repr)), a, repr)
    test(((Missing, str), ), a, str)



# Generated at 2022-06-10 21:51:12.105266
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, [(lambda _: True, None)]) is None
    assert get_repr_function(None, [(lambda _: True, str)]) is str
    assert get_repr_function(None, [(lambda _: True, lambda _: 'hi')])() == \
                                                                           'hi'
    assert get_repr_function(None, [(lambda _: True, lambda _: 'hi')])() == \
                                                                           'hi'
    assert get_repr_function(None,
                             [(lambda _: True, lambda _: 'hi'),
                              (lambda _: True, lambda _: 'bye')])() == 'hi'

# Generated at 2022-06-10 21:51:14.728265
# Unit test for function shitcode
def test_shitcode():
    the_string = '\u0420\u0430\u043c Рам'
    assert shitcode(the_string) == '??? Ram'

# Generated at 2022-06-10 21:51:17.385461
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(MyStream(), WritableStream)



# Generated at 2022-06-10 21:51:29.022111
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Writer(WritableStream):
        def __init__(self):
            self.string_written = ''

        def write(self, s):
            self.string_written += s

    to_write = 'foo'
    writer = Writer()
    writer.write(to_write)
    assert writer.string_written == to_write



# Generated at 2022-06-10 21:51:33.996330
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def __init__(self):
            self.data = ''

        def write(self, s):
            self.data += s

    a = A()
    a.write('hi')
    assert a.data == 'hi'



# Generated at 2022-06-10 21:51:46.810855
# Unit test for function get_repr_function
def test_get_repr_function():
    from .meow_format import MeowFormat

    from .format import Format

    class CatFormat(MeowFormat):
        pass

    class DogFormat(MeowFormat):
        pass

    mf = MeowFormat()
    cf = CatFormat()
    df = DogFormat()

    assert get_repr_function(mf, ()) == mf.__repr__
    assert get_repr_function(mf, ((MeowFormat, str),)) == str

    assert get_repr_function(cf, ((CatFormat, str),)) == str
    assert get_repr_function(cf, ((DogFormat, str),)) == cf.__repr__

    assert get_repr_function(cf, ((MeowFormat, str),)) == str

# Generated at 2022-06-10 21:51:54.128864
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, lambda i: 'int'))) == (lambda i: 'int')

    assert get_repr_function('a', ((int, lambda i: 'int'))) == repr

    from .tools import my_function
    assert get_repr_function(my_function, ((int, lambda i: 'int'))) == repr

    assert get_repr_function(1, ((int, int))) == int
    assert get_repr_function(1, ((int, str))) == str

    assert get_repr_function(1, ((str, lambda s: 'str'))) == repr
    assert get_repr_function('1', ((str, lambda s: 'str'))) == (lambda s: 'str')

# Generated at 2022-06-10 21:52:00.046333
# Unit test for function get_repr_function
def test_get_repr_function():
    assert (get_repr_function(3, ((lambda x: x < 5, str),)) == str)
    assert (get_repr_function(9, ((lambda x: x < 5, str),)) == repr)
    assert (get_repr_function(1.2, ((float, str),)) == str)



# Generated at 2022-06-10 21:52:02.901986
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(WritableStream):
        def write(self, s):
            pass

    x = X()
    x.write('123')
    assert True




# Generated at 2022-06-10 21:52:14.411583
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(2, 3)]) == repr
    assert get_repr_function(1, [(lambda x: x == 2, 3)]) == repr
    assert get_repr_function(1, [(lambda x: x == 1, 3)]) == 3
    assert get_repr_function(1, [(lambda x: x == 1, 3), (lambda x: x == 2, 4)]) \
                                                                        == 3
    assert get_repr_function(2, [(lambda x: x == 1, 3), (lambda x: x == 2, 4)]) \
                                                                        == 4

# Generated at 2022-06-10 21:52:26.139998
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('s', ((str, str),)) == str
    assert get_repr_function('s', (int, repr), (str, str)) == str
    assert get_repr_function(1.0, (int, repr), (str, str)) == repr
    assert get_repr_function(1.0, (float, str), (int, repr), (str, str)) == str
    assert get_repr_function(1.0, (float, str)) == str
    assert get_repr_function(1.0, (float, str), (int, str)) == str
    assert get_repr_function(1, (float, str), (int, str)) == str

# Generated at 2022-06-10 21:52:31.662684
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object):
        pass
    class B(A):
        pass
    class C(object):
        pass
    assert get_repr_function(A(), ((A, str), (str, int))) == str
    assert get_repr_function(B(), ((A, str), (str, int))) == str
    assert get_repr_function(C(), ((str, int), (A, str))) == int



# Generated at 2022-06-10 21:52:41.540906
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class WritableStream(WritableStream):

        def __init__(self):
            self.string_buffer = []

        def write(self, s):
            self.string_buffer.append(s)

    writable_stream = WritableStream()
    writable_stream.write('Hello')
    assert writable_stream.string_buffer == ['Hello']
    writable_stream.write(' ')
    assert writable_stream.string_buffer == ['Hello', ' ']
    writable_stream.write('world!')
    assert writable_stream.string_buffer == ['Hello', ' ', 'world!']



# Generated at 2022-06-10 21:52:53.280934
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class StringIO(WritableStream):
        def write(self, s):
            self.s = s
            return len(s)

    string_io = StringIO()

    string_io.write('spam')
    assert string_io.s == 'spam'

# Generated at 2022-06-10 21:52:56.428795
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .test_tools import assert_false

    class Test(object):
        pass

    test = Test()

    assert_false(isinstance(test, WritableStream))
    test.write = lambda s: None
    assert_false(issubclass(Test, WritableStream))

# Generated at 2022-06-10 21:53:08.149473
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('abc') == 'abc'
    assert shitcode('\x7f') == '?'
    assert shitcode('\x00') == '?'
    assert shitcode('\x01') == '\x01'
    assert shitcode('\x01\x02\x03') == '\x01\x02\x03'
    assert shitcode('\x01\x02\x03\x7f') == '\x01\x02\x03?'
    assert shitcode('\x01\x02\x03\x7f\x80\x81\x82') == '\x01\x02\x03???'

# Generated at 2022-06-10 21:53:16.827043
# Unit test for function get_shortish_repr

# Generated at 2022-06-10 21:53:19.577535
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)



# Generated at 2022-06-10 21:53:31.851453
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('ab') == 'ab'
    assert shitcode('\xaa') == '\xaa'
    assert shitcode('\xff') == '\xff'
    assert shitcode(u'\u044a') == '?'
    assert shitcode(u'\u0000') == '?'
    assert shitcode('\x00') == '?'
    assert shitcode('\x01') == '\x01'
    assert shitcode('\x02') == '\x02'
    assert shitcode('\x03') == '\x03'
    assert shitcode('\x04') == '\x04'
    assert shitcode('\x05') == '\x05'
    assert shitcode('\x06') == '\x06'
    assert shitcode('\x07') == '\x07'
   

# Generated at 2022-06-10 21:53:36.449476
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    a = A()
    assert a.written == ''
    a.write(u'Hi!')
    assert a.written == 'Hi!'

# Generated at 2022-06-10 21:53:48.562095
# Unit test for function shitcode
def test_shitcode():
    s = '\0\x7f\x80\xff'
    assert shitcode(s) == '\x00?\x7f?'
    s = '\xb1\xa3\xa8\xaf\xc9\xc7\xce\xa3\xbf\xbf'
    assert shitcode(s) == '???????\xbf\xbf'
    s = '\xe1\xe9\xed\xf3\xfa\xd1\xd3\xda\xba\xb9\xbf\xbf\xbf\xbf'
    assert shitcode(s) == '????????????????\xbf\xbf'
    s = '\xf1\xf3\xb3\xbf'
    assert shitcode(s) == '????\xbf'
    s = ''
    assert shit

# Generated at 2022-06-10 21:53:59.459310
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda x: isinstance(x, int), lambda x: str(x ** 2)),
        (lambda x: isinstance(x, str), lambda x: '<STRING>'),
        (lambda x: isinstance(x, float), lambda x: '<FLOAT>'),
    )
    assert get_repr_function(3, custom_repr) is str
    assert get_repr_function(4, custom_repr) == '16'
    assert get_repr_function('hi', custom_repr) == '<STRING>'
    assert get_repr_function(3.14, custom_repr) == '<FLOAT>'
    assert get_repr_function(None, custom_repr) is repr

# Generated at 2022-06-10 21:54:04.465352
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_to = False
        def write(self, s):
            self.written_to = True
    assert not MyWritableStream().written_to



# Generated at 2022-06-10 21:54:15.721683
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    def normalize_repr(repr_str):
        return re.sub(r' at 0x[0-9a-fA-F]+', '', repr_str)

    class VeryLong(object):
        def __repr__(self):
            return 'Very ' * 1000 + 'long.'


# Generated at 2022-06-10 21:54:23.688863
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, [(lambda x: x < 1, lambda x: 'small')]) == repr
    assert get_repr_function(5, [(lambda x: x < 10, lambda x: 'small')]) == \
                                                                        'small'
    assert get_repr_function(5, [(lambda x: x < 1, lambda x: 'small'),
                                 (lambda x: x < 10, lambda x: 'medium')]) == \
                                                                        'medium'
    assert get_repr_function(5, [(lambda x: x < 1, lambda x: 'small'),
                                 (lambda x: x < 10, lambda x: 'medium'),
                                 (lambda x: x < 100, lambda x: 'big')]) == 'medium'

# Generated at 2022-06-10 21:54:35.203327
# Unit test for function get_repr_function
def test_get_repr_function():
    import pytest
    customs = (
        (lambda x: isinstance(x, float), str),
        (lambda x: isinstance(x, type(None)), type),
        (int, [].append),
        (str, dict)

    )
    for item, result in [
        ('foo', str),
        ('', str),
        (1, str),
        (1.0, str),
        (None, type),
        ('foo', str),
        (['foo'], list.__repr__),
        ([], list.__repr__),
        ({}, dict.__repr__),
        (set(), set.__repr__),
        (set(), dict.__repr__),
    ]:
        assert get_repr_function(item, customs) is result
    assert get_repr_

# Generated at 2022-06-10 21:54:42.893282
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(object, max_length=4) == 'obj'
    assert get_shortish_repr((1, 2, 3, 4),
                             custom_repr=((list, lambda x: '[1, 2]'))
                             ) == '[1, 2]'



# Generated at 2022-06-10 21:54:46.016639
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyStream, WritableStream)



# Generated at 2022-06-10 21:54:50.408789
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    assert MyStream().write('hey') is None




# Generated at 2022-06-10 21:55:03.557457
# Unit test for function get_repr_function
def test_get_repr_function():
    import unittest
    class A: pass
    class B(A): pass

    class Test(unittest.TestCase):
        def test(self):
            def repr1(x):
                return x

            def repr2(x):
                return str(x + 10)

            custom_repr = (
                (B, repr1),
                (A, repr2),
                (lambda x, y=3: x == y, repr1)
            )

            a = A()
            b = B()

            assert get_repr_function(a, custom_repr)(a) == str(a)
            assert get_repr_function(a, custom_repr)(b) == repr1(b)
            assert get_repr_function(a, custom_repr)(3) == repr1(3)

           