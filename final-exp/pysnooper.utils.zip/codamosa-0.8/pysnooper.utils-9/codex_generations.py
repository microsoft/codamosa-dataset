

# Generated at 2022-06-10 21:45:15.142218
# Unit test for function get_repr_function
def test_get_repr_function():
    assert repr(get_repr_function(1, [])) == repr
    assert repr(get_repr_function(1, [(int, lambda x: 'a')])) == repr(
        lambda x: 'a'
    )



# Generated at 2022-06-10 21:45:22.932077
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcde') == 'abcde'
    assert get_shortish_repr('abcde', max_length=4) == 'ab'
    assert get_shortish_repr('abcde', max_length=None) == 'abcde'
    assert get_shortish_repr('abcde', max_length=5) == 'abcde'
    assert get_shortish_repr('abcde', max_length=6) == 'abcde'
    assert get_shortish_repr([1, 2, 3],
                             custom_repr=[(list, lambda x: 'a list')]) == 'a list'

# Generated at 2022-06-10 21:45:34.907098
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.0, [(int, str)]) == repr
    assert get_repr_function(1, [(lambda x: x == 1, str)]) == str
    assert get_repr_function((1,), [(lambda x: x == 1, str)]) == repr
    assert get_repr_function(1, [(lambda x: x == 1, str), (float, str)]) == str
    assert get_repr_function(1.0, [(lambda x: x == 1, str), (float, str)]) == str

# Generated at 2022-06-10 21:45:45.678223
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A(object):
        def __repr__(self):
            return 'A'
    class B(object):
        def __repr__(self):
            return 'B'
    custom_repr = [(A, lambda a: 'CUSTOM'), (lambda x: x == 3, lambda x: 'CUSTOM')]
    assert get_shortish_repr(A()) == 'A'
    assert get_shortish_repr(B()) == 'B'
    assert get_shortish_repr(A(), custom_repr) == 'CUSTOM'
    assert get_shortish_repr(B(), custom_repr) == 'B'
    assert get_shortish_repr(3, custom_repr) == 'CUSTOM'

# Generated at 2022-06-10 21:45:56.305939
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, []) is repr
    assert get_repr_function(None, [(None, repr)]) is repr
    assert get_repr_function(None, [(None, None)]) is repr
    assert get_repr_function(None, [(None, lambda x: '')]) is repr
    assert get_repr_function(None, [('', lambda x: '')]) is repr
    assert get_repr_function(None, [(int, lambda x: '')]) is repr
    assert get_repr_function(None, [(None, None), (int, lambda x: '')]) is repr

# Generated at 2022-06-10 21:46:05.926672
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'hello') == u'hello'
    assert shitcode(u'אהללה עם ישראל') == u'???? ???? ??????'
    assert shitcode(u'מגן דוד המלך') == u'??? ???? ???'
    assert shitcode(u'מגן דוד המלך') == u'??? ???? ???'
    assert shitcode(u'こんにちは,世界') == u'??????,???'
    assert shitcode(u'ребя́та,приве́т') == u'???????,??????'

# Generated at 2022-06-10 21:46:10.893220
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo: pass
    class Bar: pass
    assert get_repr_function(Foo(), [(Foo, lambda x: 'foo')])() == 'foo'
    assert get_repr_function(Bar(), [(Foo, lambda x: 'foo')])() == '<Bar>'




# Generated at 2022-06-10 21:46:15.313115
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('123') == "'123'"
    assert get_shortish_repr('123456789', max_length=8) == "'1234...789'"



# Generated at 2022-06-10 21:46:25.781149
# Unit test for function get_repr_function
def test_get_repr_function():
    import datetime

    custom_repr = [
        (datetime.datetime, lambda x: 'datetime: {}'.format(x)),
        (datetime.timedelta, lambda x: 'timedelta: {}'.format(x)),
        (lambda x: isinstance(x, str) and len(x) > 2, lambda x: 'str: "{}"'.format(x)),
    ]


# Generated at 2022-06-10 21:46:31.903731
# Unit test for function get_repr_function
def test_get_repr_function():
    from .short_repr import  ShortRepr, short_repr
    assert get_repr_function(1, (int, ShortRepr)) == repr
    assert get_repr_function(1, ((lambda x: True, ShortRepr))) == short_repr
    assert get_repr_function(False, ((lambda x: True, ShortRepr))) == short_repr



# Generated at 2022-06-10 21:46:37.892392
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import sys
    assert isinstance(sys.stdout, WritableStream)
    assert not isinstance(sys.stdin, WritableStream)



# Generated at 2022-06-10 21:46:44.292985
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamTest(WritableStream):
        def __init__(self):
            self.called = False
            self.s = None
        def write(self, s):
            self.called = True
            self.s = s

    writable_stream = WritableStreamTest()
    writable_stream.write('xyz')
    assert writable_stream.called
    assert writable_stream.s == 'xyz'



# Generated at 2022-06-10 21:46:56.212940
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''

    assert get_shortish_repr(22, max_length=1) == '2...'
    assert get_shortish_repr(33, max_length=2) == '3...'
    assert get_shortish_repr(44, max_length=3) == '4...'


# Generated at 2022-06-10 21:46:58.963715
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        def write(self, s):
            pass

    assert issubclass(Foo, WritableStream)



# Generated at 2022-06-10 21:47:03.917319
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, [(lambda x: x > 3, len), (int, str)]) == str
    assert get_repr_function(
        'test', [(lambda x: x > 3, len), (int, str)]
    ) is repr

# Generated at 2022-06-10 21:47:15.593761
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, []) == repr
    assert get_repr_function(None, [(lambda x, y=None: x is None,
                                     lambda x: 'lol')]) == (lambda x: 'lol')
    assert get_repr_function(None, [(None, lambda x: 'lol')]) == (lambda x:
                                                                   'lol')
    assert get_repr_function(None, [((lambda x, y=None: x is None),
                                     lambda x: 'lol')]) == (lambda x: 'lol')
    assert get_repr_function(None, [(type(None), lambda x: 'lol')]) == (lambda
                                                                        x:
                                                                        'lol')
    assert get_repr_function('', []) == repr
    assert get_repr

# Generated at 2022-06-10 21:47:18.805540
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert issubclass(sys.stdout.__class__, WritableStream)
    assert issubclass(sys.stderr.__class__, WritableStream)

# Generated at 2022-06-10 21:47:22.565915
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'עברית') == u'???'
    assert shitcode(u'אנגלית') == u'????'

# Generated at 2022-06-10 21:47:27.145911
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Stream(object):
        def __init__(self):
            self.got = []
        def write(self, s):
            self.got.append(s)
        def flush(self):
            pass
    assert issubclass(Stream, WritableStream)

# Generated at 2022-06-10 21:47:35.829181
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [
        (re.compile('hello'), 'world'),
        (lambda x: x == 'yo', 'wassup')
    ]
    assert get_repr_function('hello', custom_repr) == 'world'
    assert get_repr_function('yo', custom_repr) == 'wassup'
    assert get_repr_function('yeah', custom_repr) == repr

    custom_repr = [
        (re.compile('hello'), 'world'),
        (lambda x: x == 'yo', 'wassup'),
        (lambda x: x == 'yeah', 'nah'),
    ]
    assert get_repr_function('hello', custom_repr) == 'world'

# Generated at 2022-06-10 21:47:44.273987
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .fake_file import FakeFile

    string = 'hello, world!\n'

    fake_file = FakeFile()
    assert isinstance(fake_file, WritableStream)
    fake_file.write(string)

    fake_file.close()
    assert fake_file.read() == string

    fake_file.write('')
    fake_file.close()
    assert fake_file.read() == string

# Generated at 2022-06-10 21:47:49.725591
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1.0) == '1.0'
    assert get_shortish_repr(1 + 2j) == '(1+2j)'
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr(False) == 'False'
    assert get_shortish_repr(u'hello') == "u'hello'"
    assert get_shortish_repr(None) == 'None'
    class A(object):
        def __repr__(self):
            return 'A repr'
        def some_method(self):
            pass
    assert get_shortish_repr(A()) == 'A repr'

# Generated at 2022-06-10 21:47:58.445905
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def write(self, s):
            print('hi')

    my = MyStream()

    assert issubclass(MyStream, WritableStream)
    assert isinstance(my, WritableStream)


from .cute_test_generator import generate_tests
from python_toolbox.nifty_collections import OrderedDict
from python_toolbox import cute_testing


# Generated at 2022-06-10 21:48:08.579637
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, ()) == repr

# Generated at 2022-06-10 21:48:13.195143
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('hello\x00') == 'hello?'
    assert shitcode('\xd7\x94\xd7\x90\xd7\xa8\xd7\x94') == '??????'

# Generated at 2022-06-10 21:48:18.064988
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class SomeClass(object):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    some_object = SomeClass()
    assert isinstance(some_object, WritableStream)
    assert isinstance(some_object, WritableStream)
    assert isinstance(sys.stdout, WritableStream)

    some_object.write('a')
    assert some_object.written == 'a'



# Generated at 2022-06-10 21:48:29.164268
# Unit test for function get_repr_function
def test_get_repr_function():
    class MyClass(object):
        pass
    assert get_repr_function(MyClass(), custom_repr=()) is repr
    assert get_repr_function(MyClass(), custom_repr=((type, lambda: 'foo'),)) \
        == 'foo'
    assert get_repr_function(MyClass(), custom_repr=((True, lambda: 'foo'),)) \
                                                                        == 'foo'
    assert get_repr_function(MyClass(), custom_repr=((False, lambda: 'foo'),)) \
        is repr
    assert get_repr_function(MyClass(), custom_repr=((False, lambda: 'foo'),
                                                     (type, lambda: 'bar'),
                                                     ())
                            ) == 'bar'



# Generated at 2022-06-10 21:48:40.372723
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C: pass
    class D(C): pass
    a = A()
    b = B()
    c = C()
    d = D()
    assert get_repr_function(a, [(A, lambda x: 'a')])() == 'a'
    assert get_repr_function(a, [(B, lambda x: 'b')])() == 'a'
    assert get_repr_function(a, [(C, lambda x: 'c')])() == 'a'
    assert get_repr_function(a, [(D, lambda x: 'd')])() == 'a'
    assert get_repr_function(b, [(A, lambda x: 'a')])() == 'b'

# Generated at 2022-06-10 21:48:42.718820
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Tester:
        def write(self, s):
            pass

    tester = Tester()
    assert isinstance(tester, WritableStream)



# Generated at 2022-06-10 21:48:47.746106
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self, write_buffer):
            self.write_buffer = write_buffer
        def write(self, s):
            self.write_buffer += s

    mws = MyWritableStream('')
    mws.write('bla')
    assert mws.write_buffer == 'bla'



# Generated at 2022-06-10 21:48:58.288748
# Unit test for function get_repr_function
def test_get_repr_function():
    def my_repr(x):
        return '<%s>' % x
    custom_repr = (
        ((2, 3), my_repr),
        (lambda x: x == 4, lambda x: 'four'),
        ((5,), lambda x: 'five')
    )
    assert get_repr_function(1, custom_repr) == repr
    assert get_repr_function(2, custom_repr) == my_repr
    assert get_repr_function(3, custom_repr) == my_repr
    assert get_repr_function(4, custom_repr) == custom_repr[1][1]
    assert get_repr_function(5, custom_repr) == custom_repr[2][1]



# Generated at 2022-06-10 21:49:03.731985
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            self.s = s
    mws = MyWritableStream()
    mws.write('Hello!')
    assert mws.s == 'Hello!'
test_WritableStream_write()




if sys.version_info[0] == 2:
    from .py2_compatibility import *

# Generated at 2022-06-10 21:49:06.121637
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Test:
        pass
    Test.write = lambda self, x: None
    assert isinstance(Test(), WritableStream)


# Generated at 2022-06-10 21:49:16.319026
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .prepare_for_tests import sys_modules_backup
    from .prepare_for_tests import sys_modules_snapshot
    from .prepare_for_tests import sys_modules_state
    from .prepare_for_tests import sys_modules_restore
    from .prepare_for_tests import restore_sys_modules
    from .prepare_for_tests import remove_sys_modules_caches
    from .prepare_for_tests import remove_caches
    from .prepare_for_tests import remove_garbage_collectors
    from .prepare_for_tests import install_fake_subprocess
    from .prepare_for_tests import uninstall_fake_subprocess
    import sys
    import tempfile
    import os
    import random


# Generated at 2022-06-10 21:49:24.729351
# Unit test for function get_repr_function
def test_get_repr_function():
    class Cat(object): pass
    class Dog(object): pass
    cat = Cat()
    dog = Dog()
    assert get_repr_function(cat, ()) == repr
    assert get_repr_function(dog, ()) == repr
    assert get_repr_function(cat, ((lambda x: isinstance(x, Cat),
                                    lambda x: 'CAT'))) == (lambda x: 'CAT')
    assert get_repr_function(dog, ((lambda x: isinstance(x, Cat),
                                    lambda x: 'CAT'))) == repr





# Generated at 2022-06-10 21:49:29.056883
# Unit test for function get_repr_function
def test_get_repr_function():
    def f(x):
        print(get_repr_function(x, [(str, str.upper)]))
    f('a string')
    f(b'a string as bytes')
    f(lambda x: None)
    from types import MethodType
    f(MethodType(lambda: None, box(1)))

# Generated at 2022-06-10 21:49:38.585358
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(object()) == repr(object())
    assert get_shortish_repr(object(), normalize=True) == 'object()'
    assert get_shortish_repr(object, normalize=True) == 'type(object)'
    assert get_shortish_repr(1.0, normalize=True) == '1.0'
    assert get_shortish_repr(1/2, normalize=True) == '0.5'
    assert get_shortish_repr((1, 2, 3), normalize=True) == '(1, 2, 3)'
    assert get_shortish_repr([1, 2, 3], normalize=True) == '[1, 2, 3]'
    assert get_short

# Generated at 2022-06-10 21:49:49.615721
# Unit test for function get_repr_function
def test_get_repr_function():
    from .numbers import Pi
    from .text import pluralize
    assert get_repr_function('a', ()) == repr
    assert get_repr_function(True, ()) == repr
    assert get_repr_function(b'a', ()) == repr
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1.1, ()) == repr
    assert get_repr_function(1, ((basestring, shitcode),)) == shitcode
    assert get_repr_function('a', ((basestring, shitcode),)) == shitcode
    assert get_repr_function('a', ((basestring, shitcode), (int, str))) == repr
    assert get_repr_function(1, ((int, str),)) == str

# Generated at 2022-06-10 21:49:58.236618
# Unit test for function get_repr_function
def test_get_repr_function():
    from .python_toolbox import cute_testing

    class Foo: pass
    foo = Foo()

    def repr_foo(foo):
        return 'I am the repr of foo'

    def repr_foo_2(foo):
        return 'I am the repr of foo 2'


    assert get_repr_function(foo, []) == repr

    assert get_repr_function(foo, [(lambda _: True, repr_foo)]) == repr_foo

    assert get_repr_function(foo, [(Foo, repr_foo)]) == repr_foo

    assert get_repr_function(foo, [(Foo, repr_foo), (Foo, repr_foo_2)]) == \
                                                                    repr_foo



# Generated at 2022-06-10 21:50:03.496389
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        pass
    assert WritableStream.__subclasshook__(Foo) is NotImplemented
    class Foo:
        def write(self, s):
            pass
    assert WritableStream.__subclasshook__(Foo) is True
    class Foo(object):
        def write(self, s):
            pass
    assert WritableStream.__subclasshook__(Foo) is True



# Generated at 2022-06-10 21:50:08.096006
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C:
        def write(self, s):
            pass

    assert issubclass(C, WritableStream)


# Generated at 2022-06-10 21:50:17.940138
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr(100) == '100'
    assert get_shortish_repr(1.2) == '1.2'
    assert get_shortish_repr(None) == 'None'

    assert (get_shortish_repr(
        'a' * 12,
        normalize=True,
        max_length=12
    ) == 'aaaaaaaaaaaa')
    assert (get_shortish_repr(
        'a' * 12,
        normalize=True,
        max_length=11
    ) == 'aaaaaaaaaa...')

# Generated at 2022-06-10 21:50:28.065888
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(2.3) == '2.3'
    assert get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=11) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=12) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=13) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=14) == '[1, 2, 3]'

# Generated at 2022-06-10 21:50:39.289882
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import nose_parameterized
    import six

    def _test(item, repr_function, expected_r, expected_type,
              max_length=None, normalize=False):
        r = get_shortish_repr(
            item,
            custom_repr=((isinstance, repr_function),),
            max_length=max_length,
            normalize=normalize
        )
        assert type(r) is expected_type, (
            'Expected type `{}` for repr of `{}`, but got a `{}`.'.format(
                expected_type, item, type(r)
            )
        )

# Generated at 2022-06-10 21:50:48.325288
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, ()) == repr

    assert get_repr_function(0, ((int, custom_repr),)) == custom_repr
    assert get_repr_function(None, ((int, custom_repr),)) == repr

    assert get_repr_function(object(), ((int, custom_repr),)) == repr

    assert get_repr_function(0, ((lambda x: x % 2 == 0, custom_repr),)) == \
                                                                    custom_repr
    assert get_repr_function(1, ((lambda x: x % 2 == 0, custom_repr),)) == repr

    assert get_repr_function(object(int), ((lambda x: isinstance(x, int),
                                            custom_repr),)) == custom_repr




# Generated at 2022-06-10 21:50:55.215309
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) is repr
    assert get_repr_function(None, ((None, str),)) is str
    assert get_repr_function(1, ((None, str),)) is str
    assert get_repr_function(None, ((lambda x: x is None, str),)) is str
    assert get_repr_function(1, ((lambda x: x is None, str),)) is repr
    assert get_repr_function(None, ((None, str), (int, str))) is str
    assert get_repr_function(1, ((None, str), (int, str))) is str
    assert get_repr_function(None, ((None, str), (int, repr))) is str

# Generated at 2022-06-10 21:51:07.242016
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(object):
        def write(self, x):
            pass

    class B(object):
        def write(self, x):
            pass

    assert issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)

    class C(object):
        pass

    assert not issubclass(C, WritableStream)

    class D(object):
        def write(self, x):
            pass

        def write2(self, x):
            pass

    assert issubclass(D, WritableStream)

    class E(D):
        def write3(self, x):
            pass

    assert issubclass(E, WritableStream)

    class F(D):
        pass

    assert issubclass(F, WritableStream)


# Generated at 2022-06-10 21:51:12.838191
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class NonWritableStream: pass

    class WritableStream1(WritableStream):
        def write(self, s):
            pass

    class WritableStream2(WritableStream):
        def write(self, s):
            pass

    NonWritableStream.__bases__ = ()
    WritableStream1.__bases__ = (WritableStream,)
    WritableStream2.__bases__ = (WritableStream1,)

    assert issubclass(NonWritableStream, WritableStream) is False
    assert issubclass(WritableStream1, WritableStream) is True
    assert issubclass(WritableStream2, WritableStream) is True




# Generated at 2022-06-10 21:51:17.385861
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('a', ()) == repr

# Generated at 2022-06-10 21:51:21.197863
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert isinstance(A(), WritableStream)

    class B(WritableStream):
        pass
    assert not isinstance(B(), WritableStream)



# Generated at 2022-06-10 21:51:40.856417
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(int, []) is repr
    assert get_repr_function(int, [(int, str), (float, str)]) is str
    assert get_repr_function(float, [(int, str), (float, str)]) is str
    assert get_repr_function(4.2, [(int, str), (float, str)]) is str
    assert get_repr_function(int, [(lambda x: isinstance(x, int), str), (float, str)]) is str
    assert get_repr_function(float, [(lambda x: isinstance(x, int), str), (float, str)]) is str
    assert get_repr_function(4.2, [(lambda x: isinstance(x, int), str), (float, str)]) is str
    assert get_re

# Generated at 2022-06-10 21:51:43.594053
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    MyWritableStream()

# Generated at 2022-06-10 21:51:52.634748
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, x):
            pass

    class B(A):
        pass

    assert issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)

    class C:
        pass

    assert not issubclass(C, WritableStream)

    class D(C):
        def write(self, x):
            pass

    assert issubclass(D, WritableStream)

    class E(D):
        pass

    assert issubclass(E, WritableStream)



# Generated at 2022-06-10 21:51:55.872855
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io

    class MyWritableStream(WritableStream):
        def write(self, s):
            return len(s)

    assert isinstance(MyWritableStream(), WritableStream)
    assert isinstance(io.BytesIO(), WritableStream)
    assert isinstance(io.StringIO(), WritableStream)

# Generated at 2022-06-10 21:52:03.474777
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass

    class B:
        def write(self, s):
            pass
        def other(self, x):
            pass

    class C:
        def write(self, s):
            pass
        def other(self, x):
            pass

    assert issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)
    assert not issubclass(C, WritableStream)




# Generated at 2022-06-10 21:52:13.562977
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class NonFileStream:
        def write(self, x):
            return x

    class FileStream:
        def write(self, x):
            return x

    class FileStreamWithClose:
        def write(self, x):
            return x

        def close(self):
            pass

    assert isinstance(NonFileStream(), WritableStream)
    assert isinstance(FileStream(), WritableStream)
    assert isinstance(FileStream(), writable)
    assert isinstance(FileStreamWithClose(), WritableStream)
    assert isinstance(FileStreamWithClose(), writable)


_writable_streams = [
    sys.stdout
]



# Generated at 2022-06-10 21:52:25.424922
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('asdf', max_length=5) == 'asdf'
    assert get_shortish_repr('asdf', max_length=4) == 'asd'
    assert get_shortish_repr('asdf', max_length=3) == 'a...'
    assert get_shortish_repr('asdf', max_length=2) == '...'
    assert get_shortish_repr('asdf', max_length=1) == '...'
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(b'asdf', max_length=5) == "b'asdf'"
    assert get_shortish_repr(b'asdf', max_length=4) == "b'as'"

# Generated at 2022-06-10 21:52:34.304894
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import FileIO
    from .testing.test_utils import assert_equal
    from .testing.test_utils import assert_isinstance
    from .testing.test_utils import assert_raises_regex
    from .testing.test_utils import assert_regex
    from .testing.test_utils import assert_true
    from .testing import raise_exception

    class B: pass
    class C(B): pass



    class Foo(object):
        def __init__(self, mode='w'):
            self.f = FileIO(mode=mode)
        def write(self, s):
            return self.f.write(s)

    class Bar(object):
        def write(self, s):
            return 1


    def foo_write(s):
        return 2


# Generated at 2022-06-10 21:52:39.139417
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import os
    class Writer(WritableStream):
        def write(self, s):
            pass
    assert issubclass(Writer, WritableStream)
    assert not issubclass(io.BytesIO, WritableStream)
    assert not issubclass(os.PathLike, WritableStream)

# Generated at 2022-06-10 21:52:49.260211
# Unit test for function get_repr_function
def test_get_repr_function():
    my_object = object()
    assert get_repr_function(my_object) is repr
    assert get_repr_function(my_object, (lambda x: x, lambda x: 'hi')) is \
                                                                    repr
    assert get_repr_function(my_object, (lambda x: False, lambda x: 'hi')) is \
                                                                    repr
    assert get_repr_function(my_object, (lambda x: object, lambda x: 'hi'))(
                                                                        my_object
                                                                         ) == 'hi'
    assert get_repr_function(my_object, (object, lambda x: 'hi'))(
                                                                        my_object
                                                                         ) == 'hi'



# Generated at 2022-06-10 21:53:08.254068
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr((1, 2, 3), max_length=7) == '(1, 2, ...)'

    class X(object):
        def __repr__(self):
            return ''.join('X' for i in range(500))

    assert len(get_shortish_repr(X(), max_length=100)) == 100
    assert get_shortish_repr(X(), max_length=1000) == (
        ''.join('X' for i in range(500))
    )

    class Y(object):
        def __repr__(self):
            raise ValueError
    assert get_shortish_repr(Y()) == 'REPR FAILED'



# Generated at 2022-06-10 21:53:15.837354
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    for item, length, expected in (
        (1, 10, '1'),
        ((1,), 10, '(1,)'),
        ((1,), None, '(1,)'),
        (1, 3, '1'),
        ((1,), 3, '(1,)'),
        ((1, 2), 3, '(1, 2)'),
        ('a' * 100, None, 'a' * 100),
        ('a' * 100, 10, 'a' * 10 + '...'),
        ('a' * 100, 9, 'a' * 9 + '...'),
    ):
        assert get_shortish_repr(item, max_length=length) == expected




# Generated at 2022-06-10 21:53:22.590929
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.buffer = []
        def write(self, s):
            self.buffer.append(s)
    writable_stream = MyWritableStream()
    writable_stream.write('hello')
    writable_stream.write('there')
    assert writable_stream.buffer == ['hello', 'there']

# Generated at 2022-06-10 21:53:32.387382
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('foo', ()) == repr
    assert get_repr_function(10, (lambda x: x % 2, lambda x: "Odd")) == repr
    assert get_repr_function(11, (lambda x: x % 2, lambda x: "Odd")) == \
                                                               (lambda x: "Odd")
    assert get_repr_function('foo', ((str, lambda _: "It's a string."))) == \
                                                               (lambda _: "It's a string.")
    assert get_repr_function(42, ((str, lambda _: "It's a string."))) == repr



# Generated at 2022-06-10 21:53:38.622292
# Unit test for function get_repr_function
def test_get_repr_function():
    class X(object):
        pass
    x = X()
    def custom_repr(x):
        return '*' * 10
    custom_repr_list = [(X, custom_repr), (int, hex)]
    assert get_repr_function(int(1), custom_repr_list) == hex
    assert get_repr_function(x, custom_repr_list) == custom_repr
    assert get_repr_function(object(), custom_repr_list) == repr



# Generated at 2022-06-10 21:53:41.232855
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass

    assert isinstance(A(), WritableStream)

# Generated at 2022-06-10 21:53:52.857958
# Unit test for function get_repr_function
def test_get_repr_function():
    a = []
    repr(a) # cache repr
    repr_a = get_repr_function(a, ((),))
    assert repr_a(a) == repr(a) # repr should not change
    repr_a = get_repr_function(a, ((int,),))
    assert repr_a(a) == repr(a) # custom_repr should not be relevant
    repr_a = get_repr_function(a, ((list,), lambda x: 'list'))
    assert repr_a(a) == 'list' # custom_repr should be relevant
    repr_a = get_repr_function(a, ((list,), lambda x: 'list', (int,),
                                   lambda x: 'int'))
    assert repr_a(a) == 'list' # The first applicable should be chosen

# Generated at 2022-06-10 21:54:01.790817
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(tuple(), tuple()) is repr
    assert get_repr_function(1, tuple()) is repr

    custom_repr = (
        (int, lambda x: 'INT!'),
        (type, lambda x: 'TYPE!'),
    )

    assert get_repr_function(tuple(), custom_repr) is repr
    assert get_repr_function(1, custom_repr) == 'INT!'
    assert get_repr_function(int, custom_repr) == 'TYPE!'
    assert get_repr_function(type, custom_repr) == 'TYPE!'

    custom_repr = (
        (int, lambda x: 'INT!'),
        (type, lambda x: 'TYPE!'),
        (str, lambda x: 'STR!'),
    )

   

# Generated at 2022-06-10 21:54:06.055262
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.result = ''
        def write(self, message):
            self.result += message
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('spam')
    assert my_writable_stream.result == 'spam'



# Generated at 2022-06-10 21:54:09.040637
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream:
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-10 21:54:38.012453
# Unit test for function get_repr_function
def test_get_repr_function():

    # Check that repr is used when custom repr is empty
    assert get_repr_function(1, []) is repr


    # Check that repr is used when item does not match any condition
    assert get_repr_function(1, [(lambda x: False, object)]) is repr


    # Check that repr is used when item does not match any condition
    f = object()
    assert get_repr_function(1, [(lambda x: False, f)]) is repr


    # Check that function is used when item matches condition
    def g():
        pass
    assert get_repr_function(1, [(lambda x: True, g)]) is g


    # Check that function is used when item matches condition
    f = object()
    assert get_repr_function(f, [(lambda x: True, g)]) is g



# Generated at 2022-06-10 21:54:40.495063
# Unit test for function get_repr_function
def test_get_repr_function():
    example = lambda x, y=1: (x, y)

    assert get_repr_function(example, ((str, lambda x: id(x)),)) == id



# Generated at 2022-06-10 21:54:47.284851
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr((1, 2, 3), max_length=10, custom_repr=((list, lambda l: list(l)),)) == '[1, 2, 3]'

    assert get_shortish_repr([1, 2, 3], max_length=10, custom_repr=((list, lambda l: list(l)),)) == '[1, 2, 3]'

    assert get_shortish_repr([1, 2, 3], max_length=10) == '[1, 2, 3]'

    assert get_shortish_repr((1, 2, 3), max_length=10) == '(1, 2, 3)'

    assert get_shortish_repr((1, 2, 3), max_length=3) == '(1, 2, 3)'


# Generated at 2022-06-10 21:54:55.050889
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, custom_repr=((type(None), lambda: 'foo'))) \
                                                                       == 'foo'
    assert get_repr_function(1, custom_repr=((type(None), lambda: 'foo'))) \
                                                                       == repr
    assert get_repr_function(2, custom_repr=((2, lambda: 'foo'))) == 'foo'
    assert get_repr_function(2.0, custom_repr=((2, lambda: 'foo'))) == repr
    assert get_repr_function(2, custom_repr=((2, lambda: 'foo'),
                                             (3, lambda: 'bar'))) == 'foo'

# Generated at 2022-06-10 21:55:00.454816
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Broken(WritableStream):
        pass
    class Good(WritableStream):
        def write(self, s):
            pass
    Broken.__subclasshook__(Broken)
    Broken.__subclasshook__(Good)
    Good.__subclasshook__(Broken)
    Good.__subclasshook__(Good)

test_WritableStream_write()

