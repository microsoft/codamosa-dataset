

# Generated at 2022-06-10 21:45:22.275815
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, []) == repr
    assert get_repr_function(5, [(lambda x: True, lambda x: str(x*2))]) == \
                                                                   (lambda x: str(x*2))
    assert get_repr_function(4.6, [(lambda x: True, lambda x: str(x*2))]) == \
                                                                   (lambda x: str(x*2))
    assert get_repr_function(4.6, [(lambda x: x >= 5, lambda x: str(x*2))]) == \
                                                                            repr
    assert get_repr_function(4.6, [(lambda x: x < 5, lambda x: str(x*2))]) == \
                                                                   (lambda x: str(x*2))
   

# Generated at 2022-06-10 21:45:31.150763
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def __init__(self):
            self.written_bytes = b''

        def write(self, s):
            self.written_bytes = self.written_bytes + s

    WritableStream.register(WritableStreamSubclass)
    assert issubclass(WritableStreamSubclass, WritableStream)

    writable_stream_subclass = WritableStreamSubclass()
    writable_stream_subclass.write(b'abc')
    assert writable_stream_subclass.written_bytes == b'abc'

# Generated at 2022-06-10 21:45:42.584440
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(-1, max_length=1) == '-1'
    assert get_shortish_repr(-123456, max_length=1) == '-1'
    assert get_shortish_repr(-123456, max_length=2) == '-1'

# Generated at 2022-06-10 21:45:49.100652
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, []) is repr
    assert get_repr_function(None, [(None, str)]) is str
    assert get_repr_function(None, [(lambda x: False, str)]) is repr
    assert get_repr_function(None, [(lambda x: True, str)]) is str
    assert get_repr_function(42, []) is repr
    assert get_repr_function(42, [(None, str)]) is str
    assert get_repr_function(42, [((lambda x: False), str)]) is repr
    assert get_repr_function(42, [(type(42), str)]) is str
    assert get_repr_function(42, [((lambda x: True), str)]) is str

# Generated at 2022-06-10 21:45:58.581451
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('mystring') == 'mystring'
    assert get_shortish_repr(b'mystring') == b'mystring'
    assert get_shortish_repr('mystring', (str, lambda x: '!' + x + '!')) == '!mystring!'
    assert get_shortish_repr('mystring', (str, lambda x: '!' + x + '!'), max_length=2) == '!m...ng'
    assert get_shortish_repr('mystring', max_length=2) == 'my...ng'
    assert get_shortish_repr('mystring', max_length=2, normalize=True) == 'my...ng'

# Generated at 2022-06-10 21:46:03.537268
# Unit test for function shitcode
def test_shitcode():
    # This test should pass in python 2 and python 3
    # Let's make sure it does
    assert shitcode('אבגד') == '????'
    assert shitcode(u'אבגד') == u'????'
    assert shitcode(b'abcd') == b'abcd'
    assert shitcode('פרטים לכתובת המייל מטה') == '?????? ??? ??? ??? ??'

    # (This is not a bug.)
    assert shitcode('אבגד'.encode('utf-8')) == '????'
    assert shitcode(b'abc'.decode('ascii')) == 'abc'

# Generated at 2022-06-10 21:46:11.040196
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr('1') == "'1'"
    assert get_shortish_repr('123456') == "'123456'"
    assert get_shortish_repr('123456', max_length=5) == "'12...'"
    assert get_shortish_repr(object()) == '???'
    assert get_shortish_repr(object(), max_length=5) == '???'



# Generated at 2022-06-10 21:46:24.453786
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(set([1, 2, 3, 4])) == '{1, 2, 3, 4}'
    assert get_shortish_repr(set([1, 2, 3, 4]), max_length=10) == '{1, 2...}'
    assert get_shortish_repr(
        set([1, 2, 3, 4]), custom_repr=[(lambda x: isinstance(x, set),
                                         lambda x: 'asd')]
    ) == 'asd'
    my_list = ['asd', 1]
    assert get_shortish_repr(
        my_list, [
            (lambda x: x is my_list, lambda x: 'my_list')
        ]
    ) == 'my_list'



# Generated at 2022-06-10 21:46:28.892317
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamTest(WritableStream):
        string = ''
        def write(self, s):
            self.string += s
    wst = WritableStreamTest()
    assert wst.write('xyz') is None
    assert wst.string == 'xyz'



# Generated at 2022-06-10 21:46:35.238027
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('AbCdEfGh') == 'AbCdEfGh'
    assert shitcode('AbCdEfGh\x01') == 'AbCdEfGh?'
    assert shitcode('AbCdEfGh\x01\x02') == 'AbCdEfGh??'
    assert shitcode('AbCdEfGh\x01\x02\x03') == 'AbCdEfGh???'


# Generated at 2022-06-10 21:46:45.030500
# Unit test for function get_repr_function
def test_get_repr_function():
    def repr_function(x):
        return 'x is {}'.format(x)
    assert repr_function(42) == 'x is 42'
    assert get_repr_function(42, [(str, repr_function)]) == repr_function
    assert normalize_repr('not at 0x1234') == 'not '
    assert normalize_repr('no at') == 'no at'
    assert normalize_repr('') == ''




# Generated at 2022-06-10 21:46:57.158132
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .testing.log_assertions import assert_logs
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr(u'abc') == "u'abc'"
    assert get_shortish_repr(dict(x=5)) == "{'x': 5}"
    assert get_shortish_repr((5, 6, 7)) == "(5, 6, 7)"
    assert get_shortish_repr([5, 6, 7]) == "[5, 6, 7]"
    assert get_shortish_repr(set([5, 6, 7])) == '{5, 6, 7}'

# Generated at 2022-06-10 21:47:01.056937
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyClass(WritableStream):
        def __init__(self):
            self.written_strings = []
        def write(self, s):
            self.written_strings.append(s)

    my_class = MyClass()
    my_class.write('a')
    my_class.write('b')
    assert my_class.written_strings == ['a', 'b']

# Generated at 2022-06-10 21:47:06.546876
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class Writer(WritableStream):

        def __init__(self):
            super().__init__()
            self.lines = []

        def write(self, string):
            self.lines.append(string)

    w = Writer()
    w.write('A')
    w.write('B')
    assert w.lines == ['A', 'B']

# Generated at 2022-06-10 21:47:13.732381
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hey this is a string', max_length=18) == \
                                                          'hey this is a...'

    class X(object):
        def __repr__(self):
            return 'this is a repr'
    assert get_shortish_repr(X(), max_length=18) == 'this is a repr'

    assert get_shortish_repr(X(), max_length=18, custom_repr=((X, lambda y: 'x'),)) == 'x'



# Generated at 2022-06-10 21:47:20.854783
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyWritableStream(WritableStream):
        def __init__(self):
            self.written_text = ''

        def write(self, s):
            self.written_text += s

    dummy_writable_stream = DummyWritableStream()
    dummy_writable_stream.write('xyz')
    assert dummy_writable_stream.written_text == 'xyz'



# Generated at 2022-06-10 21:47:26.771378
# Unit test for method write of class WritableStream
def test_WritableStream_write(): # todo: make unittests
    class BogusStream(WritableStream):
        def __init__(self):
            self.written_stuff = ''
        def write(self, s):
            self.written_stuff += s

    bs = BogusStream()
    bs.write('hi')
    assert bs.written_stuff == 'hi'



# Generated at 2022-06-10 21:47:31.735442
# Unit test for function get_repr_function
def test_get_repr_function():

    def get_repr(item):
        custom_repr = (
            (lambda x: isinstance(x, int), lambda x: 'this is an int'),
            (lambda x: isinstance(x, str), lambda x: 'this is a str'),
            (lambda x: isinstance(x, dict), lambda x: 'this is a dict'),
        )
        return get_repr_function(item, custom_repr)(item)

    assert get_repr(2) == 'this is an int'
    assert get_repr('hello') == 'this is a str'
    assert get_repr({5, 6}) == 'this is a dict'
    assert get_repr(object()) == repr(object())

# Generated at 2022-06-10 21:47:43.614618
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1.2) == '1.2'
    assert get_shortish_repr('Hello') == "'Hello'"
    assert get_shortish_repr('Hello! %d %f') == "'Hello! %d %f'"
    assert get_shortish_repr(b'Hello') == "b'Hello'"
    assert get_shortish_repr(u'Hello') == "u'Hello'"
    assert get_shortish_repr((1, 2)) == '(1, 2)'
    assert get_shortish_repr([1, 2]) == '[1, 2]'
    assert get_shortish_repr({1, 2}) == '{1, 2}'

# Generated at 2022-06-10 21:47:54.925087
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, [(int, lambda x: 'number!')]) == 'number!'
    assert get_repr_function(3.0, [(int, lambda x: 'number!')]) != 'number!'
    assert (get_repr_function(3.0, [(int, lambda x: 'number!'),
                                    (float, lambda x: 'float!')]) ==
                                                                'float!')
    assert (get_repr_function(3, [(lambda x: isinstance(x, (int, float)),
                                   lambda x: 'number!')]) ==
                                                                'number!')

# Generated at 2022-06-10 21:47:59.967748
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyFileLike(WritableStream):

        def __init__(self):
            self.contents = []

        def write(self, s):
            self.contents.append(s)

    d = DummyFileLike()
    s = 'some string'
    d.write(s)
    assert d.contents == [s]

# Generated at 2022-06-10 21:48:13.130181
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1234) == '1234'
    assert get_shortish_repr(12345) == '12345'
    assert get_shortish_repr(123456) == '123456'
    assert get_shortish_repr(1234567, max_length=3) == '123...'
    assert get_shortish_repr(1234567, max_length=4) == '123...'
    assert get_shortish_repr(1234567, max_length=5) == '123...'
    assert get_shortish_repr(1234567, max_length=6) == '123...'

# Generated at 2022-06-10 21:48:20.101591
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .pycompat import StringIO
    sio = StringIO()
    class Foo(object): pass
    foo_object = Foo()
    assert get_shortish_repr(foo_object, (
        (lambda x: x.__class__ is Foo, lambda x: 'foo'),
        (lambda x: 'repr' in x.__class__.__name__, lambda x: x),
    )) == 'foo'
    assert get_shortish_repr(foo_object, (
        (lambda x: x.__class__ is Foo, lambda x: 'foo'),
    ), max_length=6) == 'foo'

# Generated at 2022-06-10 21:48:28.263372
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (lambda x: True, None)) is None
    assert get_repr_function(1, (lambda x: False, None)) is repr
    assert get_repr_function(1, ((1,), None)) is None
    assert get_repr_function(2, ((1,), None)) is repr
    assert get_repr_function(1, ((int,), None)) is None
    assert get_repr_function(1.0, ((int,), None)) is repr

# Generated at 2022-06-10 21:48:39.674168
# Unit test for function get_repr_function
def test_get_repr_function():
    class X(object):
        pass
    class Y(object):
        pass
    assert get_repr_function(
        X(),
        custom_repr=(
            (X, lambda x: 'X'),
            (Y, lambda x: 'Y'),
            (str, lambda x: 'str'),
        )
    ) == 'X'
    assert get_repr_function(
        Y(),
        custom_repr=(
            (X, lambda x: 'X'),
            (Y, lambda x: 'Y'),
            (str, lambda x: 'str'),
        )
    ) == 'Y'

# Generated at 2022-06-10 21:48:43.141948
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('æøå') == '???'
    assert shitcode(u'æøå') == '???'
    assert shitcode('Aøå') == 'A??'
    assert shitcode(u'Aøå') == 'A??'




# Generated at 2022-06-10 21:48:54.530283
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(3) == '3'
    assert get_shortish_repr(3.1) == '3.1'
    assert get_shortish_repr(3.14, custom_repr=(
        (int, lambda x: 'int'),
    )) == 'int'
    assert get_shortish_repr(3.14, custom_repr=(
        (float, lambda x: 'float'),
    )) == 'float'
    assert get_shortish_repr(3.14, custom_repr=(
        lambda x: hasattr(x, 'lower'), lambda x: 'has lower',
    )) == 'has lower'

# Generated at 2022-06-10 21:49:02.961564
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc\N{LATIN SMALL LETTER N WITH TILDE}') == 'abc?'
    assert shitcode('\u2028abc\u2029') == '?abc?'


if sys.version_info[0] == 2:
    def safe_unicode(s, errors='replace'):
        return unicode(s, errors=errors)
else:
    def safe_unicode(s, errors='replace'):
        if isinstance(s, bytes):
            return str(s, errors=errors)
        else:
            return str(s)



# Generated at 2022-06-10 21:49:06.121655
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class SampleStream(WritableStream):
        def write(self, s):
            pass
    sample_stream = SampleStream()
    assert isinstance(sample_stream, WritableStream)



# Generated at 2022-06-10 21:49:12.607363
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C(object): pass
    assert isinstance(WritableStream.__subclasshook__(C), NotImplemented)
    class D(object):
        def write(self, s): pass
    assert isinstance(WritableStream.__subclasshook__(D), bool)
    class E(object):
        def write(self, s): pass
        write = None
    assert WritableStream.__subclasshook__(E) is NotImplemented



# Generated at 2022-06-10 21:49:20.785217
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(2, ((int, str),)) == str
    assert get_repr_function(2.0, ((int, str),)) == repr
    assert get_repr_function(2, ((lambda x: x > 1, str), (int, lambda x: 'int'))) == str
    assert get_repr_function(1.0, ((lambda x: x > 1, str), (int, lambda x: 'int'))) == repr
    assert get_repr_function(2, ((lambda x: False, str), (int, lambda x: 'int'))) == repr



# Generated at 2022-06-10 21:49:25.586599
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    a = [3, 'hihi', [{3, 4, 7}, 8, 'hihi']]
    expected = (
        '(3, '
        "'hihi', "
        "([{3, 4, 7}, 8, 'hihi'],))"
    )
    assert get_shortish_repr(a) == expected

# Generated at 2022-06-10 21:49:34.547402
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C: pass
    def repr_A(x): return 'A!'
    def repr_BC(x): return 'BC!'
    def repr_C(x): return 'C!'
    custom_repr = (
        (lambda x: isinstance(x, A), repr_A),
        (lambda x: isinstance(x, B) or isinstance(x, C), repr_BC),
        (lambda x: isinstance(x, C), repr_C)
    )
    assert get_repr_function(A(), custom_repr) == repr_A
    assert get_repr_function(B(), custom_repr) == repr_BC
    assert get_repr_function(C(), custom_repr) == repr_C

# Generated at 2022-06-10 21:49:45.152273
# Unit test for function get_repr_function
def test_get_repr_function():

    def foo_repr(x):
        return 'foo' + repr(x)

    integer_repr = get_repr_function(1, custom_repr=())
    assert integer_repr(1) == repr(1)

    custom_repr = get_repr_function(1, custom_repr=[(int, foo_repr)])
    assert custom_repr(1) == 'foo1'

    custom_repr = get_repr_function(1, custom_repr=[(lambda x: x == 1,
                                                     foo_repr)])
    assert custom_repr(1) == 'foo1'

    custom_repr = get_repr_function(1, custom_repr=[(lambda x: x != 1,
                                                     foo_repr)])
    assert custom

# Generated at 2022-06-10 21:49:51.032352
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(lambda x: isinstance(x, int), str)]) == str
    assert get_repr_function(1, [(2, str)]) == repr
    assert get_repr_function(1, []) == repr
    assert get_repr_function(2, [(int, str)]) == repr


# Generated at 2022-06-10 21:49:53.364265
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-10 21:50:00.784067
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr([1, 2, 3],
                             custom_repr=((lambda x: True, lambda x: '.' * 1000),)) == '...'
    assert get_shortish_repr(['a', 'b', 'c'], custom_repr=(
        (lambda x: isinstance(x, list), lambda x: 'a' * 1000),
    )) == 'aaaaaa...'
    assert get_shortish_repr(['a', 'b', 'c'], custom_repr=(
        (lambda x: isinstance(x, list), lambda x: 'a' * 1000),
    ), normalize=True) == 'a...a'

# Generated at 2022-06-10 21:50:12.236740
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import datetime
    assert get_shortish_repr(55) == '55'
    assert get_shortish_repr(55, custom_repr=((int, str),)) == '55'
    assert get_shortish_repr(55, custom_repr=((int, lambda x: 'fifty-five'),)) \
           == 'fifty-five'
    assert get_shortish_repr(
        datetime.datetime(2001, 1, 1), max_length=20
    ) == 'datetime.datetime(2001, 1, 1, 0, 0)'

# Generated at 2022-06-10 21:50:20.761871
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, []) is repr
    assert get_repr_function(1, []) is repr
    assert get_repr_function(None, [(lambda x: True, lambda x: 'a')])() == 'a'
    assert get_repr_function(1, [(lambda x: True, lambda x: 'a')])() == 'a'
    assert get_repr_function(None, [(None, lambda x: 'a')])() == 'a'
    assert get_repr_function(1, [(None, lambda x: 'a')])() == 'a'
    assert get_repr_function(None, [(None, 'a')])() == 'a'
    assert get_repr_function(1, [(None, 'a')])() == 'a'
    assert get_re

# Generated at 2022-06-10 21:50:33.782773
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(
        tuple([]),
        (
            (lambda x: x == 1, lambda x: x),
            (lambda x: x == 2, lambda x: x),
            (lambda x: x == 3, lambda x: x),
            (lambda x: x == 4, lambda x: x),
        )
    )(1) == 1
    assert get_repr_function(
        tuple([]),
        (
            (lambda x: x == 1, lambda x: x),
            (lambda x: x == 2, lambda x: x),
            (lambda x: x == 3, lambda x: x),
            (lambda x: x == 4, lambda x: x),
        )
    )(4) == 4

# Generated at 2022-06-10 21:50:46.867767
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass
    class C(A): pass

    assert get_repr_function(A(), ()) is repr
    assert get_repr_function(A(), [(object, str)]) is str
    assert get_repr_function(A(), [(object, str), (A, str.upper)]) is str.upper
    assert get_repr_function(A(), [(object, str), (A, str.upper), (B, str.lower)]) is str.upper
    assert get_repr_function(B(), [(object, str), (A, str.upper), (B, str.lower)]) is str.lower
    assert get_repr_function(C(), [(object, str), (A, str.upper), (B, str.lower)]) is str.upper
    assert get

# Generated at 2022-06-10 21:50:49.907436
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Mock(WritableStream):
        def write(self, s):
            pass

    mock = Mock()
    mock.write('hi')


# Generated at 2022-06-10 21:50:55.057689
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.data = ''
        def write(self, s):
            self.data += s
    stream = MyWritableStream()
    stream.write('hi')
    assert stream.data == 'hi'



# Generated at 2022-06-10 21:51:07.119613
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # long_string makes sure we can shorten long strings, both at right and
    # left.
    long_string = '1234567890' * 20 + '12345'
    assert get_shortish_repr(long_string, max_length=30) == '1234...012345'
    assert get_shortish_repr(long_string, max_length=31) == '123...012345'
    assert get_shortish_repr(long_string, max_length=32) == '12...012345'
    assert get_shortish_repr(long_string, max_length=33) == '1...012345'
    assert get_shortish_repr(long_string, max_length=34) == '...012345'

# Generated at 2022-06-10 21:51:11.502367
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    fail_count = 0

    def fail():
        nonlocal fail_count
        fail_count += 1

    class C(WritableStream):
        def write(self, s):
            pass

    assert isinstance(C(), WritableStream)

    class C(WritableStream):
        pass

    assert not isinstance(C(), WritableStream)
    fail()

    print(f'{fail_count} tests failed.')




# Generated at 2022-06-10 21:51:18.410083
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class ClassWithWrite:
        def write(self, s):
            return s * 2

    class ClassWithoutWrite: pass

    assert issubclass(ClassWithWrite, WritableStream)
    assert not issubclass(ClassWithoutWrite, WritableStream)

    assert ClassWithWrite().write('xyz') == 'xyzxyz'

    from .pycompat import StringIO

    assert issubclass(StringIO, WritableStream)

# Generated at 2022-06-10 21:51:26.292313
# Unit test for function get_repr_function
def test_get_repr_function():
    def custom_repr_for_float(x):
        return 'float {!r}'.format(x)

    assert get_repr_function(5, (
        (int, str),
        (float, custom_repr_for_float),
    )) is str
    assert get_repr_function(5.0, (
        (int, str),
        (float, custom_repr_for_float),
    )) is custom_repr_for_float
    assert get_repr_function(5.1, (
        (int, str),
        (float, custom_repr_for_float),
    )) is repr



# Generated at 2022-06-10 21:51:32.928365
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import cStringIO
    from .testing_tools import assert_equals
    from .testing_tools import assert_raises
    from .testing_tools import sleep_while_garbage_collected
    from .testing_tools import GarbageCollectorChecker
    class Stream(WritableStream):
        def __init__(self):
            self.string = ''
        def write(self, s):
            self.string += s
    stream = Stream()
    assert issubclass(Stream, WritableStream)
    assert_equals(stream.string, '')
    stream.write('hello')
    assert_equals(stream.string, 'hello')
    stream.write(' world')
    assert_equals(stream.string, 'hello world')

# Generated at 2022-06-10 21:51:37.270709
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestWriteWritableStream(WritableStream):
        def write(self, s):
            pass

    TestWriteWritableStream().write('x')
    assert subclasses_of_type(TestWriteWritableStream, WritableStream)



# Generated at 2022-06-10 21:51:42.208920
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def __init__(self):
            self.written_text = ''
        def write(self, s):
            assert isinstance(s, str)
            self.written_text += s

    f = Foo()
    f.write('foo')
    f.write(' ')
    f.write('bar')
    assert f.written_text == 'foo bar'

# Generated at 2022-06-10 21:51:48.245036
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        def write(self, s):
            pass
    assert issubclass(Foo, WritableStream)
    f = Foo()
    assert isinstance(f, WritableStream)



# Generated at 2022-06-10 21:51:53.850895
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'אאאאאאאאא') == u'????????????????'
    assert shitcode(u'abc בגד') == u'abc ??'
    assert shitcode('abc בגד') == u'abc ??'
    assert shitcode('abc בגד'.decode('utf-8')) == u'abc ??'



# Generated at 2022-06-10 21:51:57.331146
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pythonde import patch

    class Subclass(WritableStream):
        def write(self, s):
            pass

    patch(Subclass.write)

# Generated at 2022-06-10 21:52:10.290212
# Unit test for function get_repr_function
def test_get_repr_function():
    class C: pass
    class D: pass
    cd = C()
    d = D()
    assert get_repr_function(cd, custom_repr=((C, 'yes'),)) == 'yes'
    assert get_repr_function(cd, custom_repr=((C, 'yes'),
                                              (D, 'no'))) == 'yes'
    assert get_repr_function(cd, custom_repr=((D, 'no'),
                                              (C, 'yes'))) == 'yes'
    assert get_repr_function(d, custom_repr=((C, 'yes'),
                                             (D, 'no'))) == 'no'
    assert get_repr_function(d, custom_repr=((D, 'no'),
                                             (C, 'yes')))

# Generated at 2022-06-10 21:52:13.893835
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def __init__(self):
            self.written_text = ''
        def write(self, s):
            self.written_text += s

    stream = MyStream()
    stream.write('hello')
    assert stream.written_text == 'hello'

    try:
        class MyWrongStream(WritableStream):
            pass
    except TypeError:
        pass
    else:
        assert False, "Shouldn't be able to create `MyWrongStream`"

# Generated at 2022-06-10 21:52:25.709332
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(
        5,
        custom_repr=[
            (lambda x: isinstance(x, (int, bool)), lambda x: 'c' * x)
        ]
    )(5) == 'ccccc'
    assert get_repr_function(5.5) == repr




SPACE_HORIZONTAL = u'\u2002'
SPACE_VERTICAL = u'\u2003'
SPACE_EM = u'\u2004'
SPACE_THIN = u'\u2005'
SPACE_HAIR = u'\u2006'
SPACE_SIXTH = u'\u2006'
SPACE_FIFTH = u'\u2006'
SPACE_FOURTH = u'\u2006'

# Generated at 2022-06-10 21:52:34.459147
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import string
    import random
    import itertools
    import math

    # Create definition of `crazy_class`:

    class crazy_class(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

        def __repr__(self):
            return '<{} at 0x{:x}>'.format(self.__class__.__name__, id(self))

    # Create definition of `crazy_container_class`:

    class crazy_container_class(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y


# Generated at 2022-06-10 21:52:36.822021
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def write(self, s):
            return 'written %s' % s
    stream = MyStream()
    assert stream.write('here') == 'written here'
    assert isinstance(stream, WritableStream)
    assert issubclass(MyStream, WritableStream)



# Generated at 2022-06-10 21:52:47.276770
# Unit test for function get_repr_function
def test_get_repr_function():
    x = 5

    # Test that without custom_repr, we get the default `repr`:
    assert get_repr_function(x) is repr

    # Test that with `custom_repr` that matches the type, we get the
    # replacement:
    assert get_repr_function(x, custom_repr=((int, str),)) == str

    # Test that with `custom_repr` that doesn't match the type, we get the
    # default `repr`:
    assert get_repr_function(x, custom_repr=((str, str),)) is repr

    # Test that with `custom_repr` that matches the item, we get the
    # replacement:
    assert get_repr_function(x, custom_repr=((5, str),)) == str

    # Test that

# Generated at 2022-06-10 21:52:54.846963
# Unit test for function get_repr_function
def test_get_repr_function():

    assert get_repr_function(1, custom_repr=[]) is repr
    assert get_repr_function(1, custom_repr=[(int, type)]) is type

    assert get_repr_function(1, custom_repr=[(int, issubclass)]) is issubclass

    assert get_repr_function(1, custom_repr=[(int, id)]) is id
    assert get_repr_function(1, custom_repr=[((int, type), id)]) is id

    assert get_repr_function(2, custom_repr=[((int, type), id)]) is repr



# Generated at 2022-06-10 21:53:02.251807
# Unit test for function get_repr_function
def test_get_repr_function():
    class A:
        pass
    class B(A):
        pass

    assert get_repr_function(B(), custom_repr=((A, lambda x: 'A'))) == 'A'
    assert get_repr_function(B()) == repr



# Generated at 2022-06-10 21:53:08.017679
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(42, ()) == repr
    assert get_repr_function('abc', (lambda x: False, lambda x: 'xyz')) == \
                                                                          repr
    assert get_repr_function('abc', (lambda x: True, lambda x: 'xyz'))(
        'abc'
    ) == 'xyz'


# unit test for function truncate

# Generated at 2022-06-10 21:53:16.766237
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(object()) == '<object object at 0x'
    assert get_shortish_repr('hello world') == "'hello world'"
    assert get_shortish_repr(max_length=4) == 'REPR'
    assert get_shortish_repr(
            (1, 2, 3),
            custom_repr=((lambda x: isinstance(x, tuple) and len(x) == 3,
                          lambda x: '(1,2,3)'),),
            max_length=7,
            normalize=True
        ) == '(1,2,3)'
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(1, max_length=0) == '...'

# Generated at 2022-06-10 21:53:29.781110
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == '1'
    assert get_shortish_repr(12345, max_length=4) == '12...'
    assert get_shortish_repr('abcde', max_length=4) == 'abc...'
    assert get_shortish_repr('abcde', max_length=5)

# Generated at 2022-06-10 21:53:36.258138
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.data = b''
        def write(self, s):
            self.data += s
    stream = MyWritableStream()
    stream.write(b'3')
    stream.write(b'\n')
    stream.write(b'HELLO')
    assert stream.data == b'3\nHELLO'



# Generated at 2022-06-10 21:53:40.559161
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('a¢b') == 'a?b'
    assert shitcode('מה') == '??'
    assert shitcode('שלום') == '????'



# Generated at 2022-06-10 21:53:47.576992
# Unit test for function get_repr_function
def test_get_repr_function():

    import types

    from . import link_hashes


    assert get_repr_function(
        1,
        custom_repr=[
            (lambda x: isinstance(x, types.BuiltinFunctionType), shitcode),
            (lambda x: isinstance(x, types.FunctionType), shitcode),
            (lambda x: isinstance(x, link_hashes.LinkHashes),
             lambda x: x.sha1),
        ]
    ) == repr

# Generated at 2022-06-10 21:53:58.785453
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .python_toolbox import NiceRepr
    custom_repr = (
        (lambda x: isinstance(x, NiceRepr), lambda x: x.nice_repr()),
    )

# Generated at 2022-06-10 21:54:10.696352
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Thing:
        def write(self, s):
            return s * 2
    class Thing2(Thing):
        pass
    assert issubclass(Thing, WritableStream)
    assert issubclass(Thing2, WritableStream)
    assert not issubclass(object, WritableStream)
    assert not issubclass(int, WritableStream)
    class Thing3:
        pass
    assert not issubclass(Thing3, WritableStream)
    class Thing4(Thing3):
        def write(self, s):
            return s * 2
    assert issubclass(Thing4, WritableStream)


if __name__ == '__main__':
    test_WritableStream_write()

# Generated at 2022-06-10 21:54:15.753046
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, ((int, lambda x: 'int:' + str(x)),)) == 'int:3'
    assert get_repr_function(4, ((lambda x: x == 4, lambda x: '4'),)) == '4'
    assert get_repr_function(5, ()) == str



# Generated at 2022-06-10 21:54:32.636930
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcdef', max_length=4) == 'abc...'
    assert get_shortish_repr('abcdef', max_length=10) == 'abcdef'
    assert get_shortish_repr('abcdef', max_length=None) == 'abcdef'
    expected_repr_type = '<class \'string\', \'repr-failer\'>'
    r = get_shortish_repr('repr-failer', custom_repr=(
        (repr_failer, type),
        (expected_repr_type, lambda x: '<class \'string\', \'repr-failer\'>')
    ))
    assert r == expected_repr_type



# Generated at 2022-06-10 21:54:38.775131
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s
    stream = MyWritableStream()
    stream.write('hello')
    assert stream.s == 'hello'



# Generated at 2022-06-10 21:54:41.099557
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)



# Generated at 2022-06-10 21:54:47.434511
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(object): pass
    a = A()
    b = B()

# Generated at 2022-06-10 21:54:58.657983
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class Thing(object):
        def __repr__(self):
            return "I'm thing's repr"

    assert get_shortish_repr("abc") == "abc"
    assert get_shortish_repr("a"*100) == "a"*100
    assert get_shortish_repr("a"*100, max_length=None) == "a"*100
    assert get_shortish_repr("a"*100, max_length=150) == "a"*100
    assert get_shortish_repr("a"*100, max_length=10) == 'a...a'
    assert get_shortish_repr("a"*100, max_length=5) == 'a...'

# Generated at 2022-06-10 21:55:02.751543
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            self.s = s

    my_writable_stream = MyWritableStream()
    assert isinstance(my_writable_stream, WritableStream)
    my_writable_stream.write('abc')
    assert my_writable_stream.s == 'abc'




# Generated at 2022-06-10 21:55:05.227495
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        def write(self, s):
            pass

    assert issubclass(Foo, WritableStream)

