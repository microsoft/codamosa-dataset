

# Generated at 2022-06-24 17:21:27.917173
# Unit test for function get_repr_function
def test_get_repr_function():
    float_0 = 13.18
    var_0 = get_repr_function(float_0, ())
    assert callable(var_0), (
        "The variable `var_0` should be callable. It was: " +
        repr(var_0)
    )
    assert var_0(float_0) == "13.18", (
        "The variable `var_0` should be a callable that returns the float "
        "13.18 when you call it with the float 13.18. It was: " +
        repr(var_0)
    )


# Generated at 2022-06-24 17:21:38.023878
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\t') == '?\t'
    assert shitcode('\x56') == '\x56'
    assert shitcode('\xff') == '?'
    assert shitcode('\n') == '\n'
    assert shitcode('\xe3') == '?'
    assert shitcode('\r') == '\r'
    assert shitcode('\x05') == '\x05'
    assert shitcode('\xed') == '?'
    assert shitcode('') == ''
    assert shitcode('\xdd') == '?'
    assert shitcode('\x00') == '\x00'
    assert shitcode('\x85') == '\x85'
    assert shitcode('\x92') == '\x92'
    assert shitcode('\xa4') == '?'

# Generated at 2022-06-24 17:21:47.071672
# Unit test for function shitcode
def test_shitcode():
    var_333 = "hello"
    var_334 = shitcode(var_333)
    assert var_334 == "hello"
    var_335 = "LOL\u20ac"
    var_336 = shitcode(var_335)
    assert var_336 == "LOL?"
    var_337 = "LOL\x81"
    var_338 = shitcode(var_337)
    assert var_338 == "LOL?"
    var_339 = "LOL\ufffe"
    var_340 = shitcode(var_339)
    assert var_340 == "LOL?"
    var_341 = "LOL\uffff"
    var_342 = shitcode(var_341)
    assert var_342 == "LOL?"




# Generated at 2022-06-24 17:21:58.736999
# Unit test for function get_shortish_repr

# Generated at 2022-06-24 17:22:00.959033
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_0 = WritableStream()
    string_0 = ''
    var_0.write(string_0)


# Generated at 2022-06-24 17:22:07.531451
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('', []) is repr
    assert get_repr_function(7, [(lambda x: True, str)]) is str
    assert get_repr_function(7, [(lambda x: False, str)]) is repr
    assert get_repr_function(7, [(int, str)]) is str
    assert get_repr_function('hello', [(int, str)]) is repr


# Generated at 2022-06-24 17:22:19.796465
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda x: isinstance(x, int),
         lambda x: '{:g}'.format(x)),
    )
    assert get_repr_function(0, custom_repr) is int.__repr__
    assert get_repr_function(1, custom_repr) is int.__repr__
    assert get_repr_function('', custom_repr) is str.__repr__
    assert get_repr_function([], custom_repr) is list.__repr__
    assert get_repr_function(int, custom_repr) is type.__repr__
    assert get_repr_function(float, custom_repr) is type.__repr__

# Generated at 2022-06-24 17:22:23.409303
# Unit test for function get_repr_function
def test_get_repr_function():
    repr_function = get_repr_function(float_0, custom_repr=[])
    assert repr_function == repr

    repr_function = get_repr_function(str(float_0), custom_repr=[])
    assert repr_function == repr



# Generated at 2022-06-24 17:22:31.958080
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from random import random as float_0
    float_0 = float_0()

    var_0 = get_shortish_repr(float_0)
    assert var_0 == str(float_0)

    var_0 = get_shortish_repr(float_0, normalize=True)
    assert var_0 == str(float_0)

    var_0 = get_shortish_repr(float_0, max_length=1)
    assert var_0 == '{r...}'.format(r=repr(float_0))

    var_0 = get_shortish_repr(float_0, max_length=1, normalize=True)
    assert var_0 == '{r...}'.format(r=repr(float_0))

    var_0 = get_shortish_re

# Generated at 2022-06-24 17:22:33.907584
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    float_0 = -980.0
    var_0 = normalize_repr(float_0)


# Generated at 2022-06-24 17:22:39.327389
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    assert (writable_stream_0.write('O')) is None, 'Processed'


# Generated at 2022-06-24 17:22:45.357946
# Unit test for function get_repr_function
def test_get_repr_function():
    class X: pass
    class Y: pass

    custom_repr = (
        (lambda x: isinstance(x, X), lambda x: 'X'),
        (lambda x: isinstance(x, Y), lambda x: 'Y')
    )


# Generated at 2022-06-24 17:22:56.155948
# Unit test for function get_repr_function
def test_get_repr_function():
    def fruit_repr(fruit):
        juices = {
            'banana': 'yellow',
            'orange': 'orange',
            'lemon': 'yellow',
            'pomegranate': 'red'
        }
        return '{} is {}'.format(
            fruit,
            juices.get(fruit, 'unknown')
        )

    assert get_repr_function(5, []) == repr
    assert get_repr_function(
        5,
        [
            (lambda x: x == 5, lambda x: '5'),
            (lambda x: x == 6, lambda x: '6'),
        ]
    ) == (lambda x: '5')

    assert get_repr_function(None, []) == repr
    assert get_repr_function('banana', []) == repr

    assert get

# Generated at 2022-06-24 17:23:02.155811
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, custom_repr=[(int, lambda i: '5')]) == '5'
    assert get_repr_function(5, custom_repr=[(lambda i: i == 5, lambda i: '5')]) == '5'
    assert get_repr_function(5, custom_repr=[(lambda i: i == 7, lambda i: '5')]) == repr
    assert get_repr_function(5, custom_repr=[(lambda i: i == 7, '5')]) == repr

    class A: pass
    class B(A): pass
    assert get_repr_function(A(), custom_repr=[(A, lambda i: 'A')]) == 'A'

# Generated at 2022-06-24 17:23:07.084245
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.2, custom_repr=((int, str),)) == repr
    assert get_repr_function(1) == repr



# Generated at 2022-06-24 17:23:13.658120
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    try:
        writable_stream_0.write(len('Write output to a stream'))
        print('Test case 0: Pass')
    except Exception as e:
        print('Test case 0: Fail')
        print(e)
    try:
        writable_stream_0.write(len(''))
        print('Test case 1: Pass')
    except Exception as e:
        print('Test case 1: Fail')
        print(e)
test_WritableStream_write()


# Generated at 2022-06-24 17:23:23.926006
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(123, max_length=7) == '123'
    assert get_shortish_repr(-123, max_length=7) == '-123'
    assert get_shortish_repr(long(123), max_length=7) == '123L'
    assert get_shortish_repr(u'abde', max_length=7) == u'abde'
    assert get_shortish_repr(u'0123456789', max_length=7) == u'0123...'
    assert get_shortish_repr(u'0123456789', max_length=None) == u'0123456789'

# Generated at 2022-06-24 17:23:27.862186
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    # simple write
    writable_stream_0.write('Test')  # Expected a write



# Generated at 2022-06-24 17:23:39.032408
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    x = [1, 2, 3]
    assert get_shortish_repr(x, max_length=5) == '[...]'
    assert get_shortish_repr(x, max_length=4) == '[...]'
    assert get_shortish_repr(x, max_length=3) == '[...]'
    assert get_shortish_repr(x, max_length=2) == '[...]'
    assert get_shortish_repr(x, max_length=1) == '[...]'
    assert get_shortish_repr(x, max_length=0) == '[...]'
    assert get_shortish_repr(x, max_length=None) == '[1, 2, 3]'

    assert get_shortish_repr(['a', 'b'], max_length=8)

# Generated at 2022-06-24 17:23:51.697548
# Unit test for function get_repr_function
def test_get_repr_function():
    """
    Test for get_repr_function function
    """
    custom_repr_0 = ((type, lambda x: '{}'.format(type(x))),)
    max_length_0 = 0
    item_0 = object
    item_1 = float
    assert get_shortish_repr(item_0, custom_repr_0, max_length_0) == '<type object>'
    assert get_shortish_repr(item_1, custom_repr_0, max_length_0) == '<type float>'
    max_length_1 = 1
    assert get_shortish_repr(item_0, custom_repr_0, max_length_1) == '<t>'

# Generated at 2022-06-24 17:24:09.063842
# Unit test for function get_repr_function
def test_get_repr_function():
    # Test 0:
    custom_repr = ()
    get_repr_function_0 = get_repr_function('item', custom_repr)
    assert repr == get_repr_function_0

    # Test 1:
    def repr_0(x):
        pass
    custom_repr = ((lambda x, y=TypeError: isinstance(x, y), repr_0),)
    get_repr_function_1 = get_repr_function('item', custom_repr)
    assert repr != get_repr_function_1 and repr_0 == get_repr_function_1
    
    # Test 2:
    def repr_1(x):
        pass
    def repr_2(x):
        pass

# Generated at 2022-06-24 17:24:20.091425
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('', custom_repr=[], max_length=None, normalize=False) == ''
    assert get_shortish_repr('', custom_repr=[], max_length=None, normalize=True) == ''
    assert get_shortish_repr('', custom_repr=[], max_length=6, normalize=False) == ''
    assert get_shortish_repr('', custom_repr=[], max_length=6, normalize=True) == ''
    assert get_shortish_repr('abcdefghi', custom_repr=[], max_length=None, normalize=False) == 'abcdefghi'

# Generated at 2022-06-24 17:24:27.532255
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(object(), ()) is repr
    assert get_repr_function(object(), custom_repr=[(object, str)]) is str
    assert get_repr_function(object()) is repr
    assert get_repr_function(object(), custom_repr=[(object, str)]) is str
    assert get_repr_function(object(), custom_repr=[(type(None), str)]) is repr
    assert get_repr_function(object(), custom_repr=[(object, str), (type(None), str)]) is str
    assert get_repr_function(object(), custom_repr=[(object, str), (type(None), str)]) is str
    assert get_repr_function(object(), custom_repr=[(type, str), (type(None), str)])

# Generated at 2022-06-24 17:24:28.808144
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_case_0()


# Generated at 2022-06-24 17:24:35.976449
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(12345) == '12345'
    assert get_shortish_repr('12345') == "'12345'"
    assert get_shortish_repr([1, {'a': 'b'}]) == "[1, {'a': 'b'}]"

    assert get_shortish_repr(12345, max_length=2) == '12...'
    assert get_shortish_repr('12345', max_length=2) == "'12...'..."
    assert get_shortish_repr([1, {'a': 'b'}], max_length=2) == "[1, {...}]"

    class X(object):
        pass
    x = X()
    x.a = 1
    x.b = 2
    assert get_shortish_repr

# Generated at 2022-06-24 17:24:44.121537
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    normalize_repr('<__main__.MyClass object at 0x7fc988f725c0>')
    get_shortish_repr('abc', max_length=3)
    get_shortish_repr(1234567890, max_length=3)
    get_shortish_repr(object(), max_length=9)
    get_shortish_repr(
        ('abc', 'def', 'ghi', 'jkl'), max_length=9, custom_repr=[
            (lambda x: isinstance(x, tuple), lambda x: 'tuple')
        ]
    )

# Generated at 2022-06-24 17:24:48.550083
# Unit test for function get_repr_function
def test_get_repr_function():
    class x(int): pass
    class y(int): pass
    assert get_repr_function(x(10), ((x, lambda x: 'ha!'),)) == 'ha!'
    assert get_repr_function(y(10), ((x, lambda x: 'ha!'),)) != 'ha!'

# Generated at 2022-06-24 17:24:52.259026
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    def test_case_1():
        writable_stream_0 = WritableStream()
        try:
            writable_stream_0.write(1)
        except Exception as e:
            print('Exception: ' + str(e))
    pass

# Generated at 2022-06-24 17:24:55.500569
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    # writable_stream_0.write(1, 2) # Raises `TypeError` as expected.
    writable_stream_0.write(1)



# Generated at 2022-06-24 17:25:01.422286
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()

# Generated at 2022-06-24 17:25:06.816357
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    with pytest.raises(TypeError, match="Can't instantiate abstract class WritableStream with abstract methods write"):
        writable_stream_0 = WritableStream()


# Generated at 2022-06-24 17:25:08.934318
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    assert writable_stream_0.write('w')
    assert 1 == 1


# Generated at 2022-06-24 17:25:13.043334
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    r = writable_stream_0.write("b'{ write() }'")
    # assert write() returns None
    assert r is None


# Generated at 2022-06-24 17:25:24.471747
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'

    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'

# Generated at 2022-06-24 17:25:35.399480
# Unit test for function get_repr_function
def test_get_repr_function():
    import collections

    def some_repr(x):
        return 'some_repr: ' + x

    assert get_repr_function(5, ((int, some_repr),))(5) == 'some_repr: 5'
    assert get_repr_function((5,), ((collections.Iterable, some_repr),))((5,)) == 'some_repr: (5,)'



# Generated at 2022-06-24 17:25:36.976042
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_1 = WritableStream()
    assert NotImplemented == writable_stream_1.write("")


# Generated at 2022-06-24 17:25:39.123295
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('')


# Generated at 2022-06-24 17:25:50.477998
# Unit test for function get_repr_function
def test_get_repr_function():
    # Testing normal
    class A(object): pass
    class B(A): pass

    assert get_repr_function(A(), [(B, lambda x: 'b')]) is repr
    assert get_repr_function(B(), [(B, lambda x: 'b')]) == 'b'
    assert get_repr_function(B(), [(B, lambda x: 'b'), (A, repr)]) == 'b'
    assert get_repr_function(A(), [(B, lambda x: 'b')]) is repr
    assert get_repr_function(0, [(B, lambda x: 'b')]) is repr
    assert get_repr_function(0, [(int, lambda x: 'i')]) == 'i'


if __name__ == '__main__':
    test_case_0()
    test_

# Generated at 2022-06-24 17:26:01.174249
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    try:
        WritableStream.write
    except Exception as e:
        print('line 75')
        print(type(e))
        print(e)
    writable_stream_0 = WritableStream()
    s = 'Raise NotImplementedError'
    try:
        writable_stream_0.write(s)
    except Exception as e:
        print('line 84')
        print(type(e))
        print(e)
    writable_stream_0 = WritableStream()
    s = 'Raise NotImplementedError'
    try:
        writable_stream_0.write(s)
    except Exception as e:
        print('line 94')
        print(type(e))
        print(e)
    writable_stream_0 = WritableStream()

# Generated at 2022-06-24 17:26:06.690952
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    def repr_a(a):
        return 'A'
    class B(object): pass
    def repr_b(b):
        return 'B'


    assert get_repr_function(A(), (
        (A, repr_a),
        (B, repr_b),
    )) is repr_a
    assert get_repr_function(B(), (
        (A, repr_a),
        (B, repr_b),
    )) is repr_b
    assert get_repr_function(object(), (
        (A, repr_a),
        (B, repr_b),
    )) is repr



# Generated at 2022-06-24 17:26:11.220822
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    WRITABLE_STREAM_0 = WritableStream()
    WRITABLE_STREAM_0.write('')


# Generated at 2022-06-24 17:26:12.896248
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('s')

# Generated at 2022-06-24 17:26:20.066054
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Arrange
    writable_stream_0 = WritableStream()

    # Act
    def write0(s):
        writable_stream_0.write(s)
        return len(s)
    # Assert
    try:
        writable_stream_0.write("")
    except NotImplementedError:
        pass
    except:
        assert False, 'unexpected exception'


# Generated at 2022-06-24 17:26:25.044259
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream = WritableStream()
    assert writable_stream.write('') is None
    assert writable_stream.write('abc') is None
    assert writable_stream.write('\n') is None
    # assert writable_stream.write(None) is None  # Fails
    # assert writable_stream.write(2) is None  # Fails




# Generated at 2022-06-24 17:26:30.930010
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    isinstance(writable_stream_0, WritableStream)
    writable_stream_0.write('a')
    writable_stream_0.write('b')
    writable_stream_0.write('c')
    assert writable_stream_0.write('a') is None
    with raises(TypeError):
        writable_stream_0.write(2.2)
    assert hash(writable_stream_0) == hash(WritableStream)



# Generated at 2022-06-24 17:26:39.423754
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(int, []) == repr


# Generated at 2022-06-24 17:26:44.184617
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    for writable_stream in (WritableStream(),
                            writable_stream_0,
                            ):

        writable_stream.write('abc')
        writable_stream.write(100)

# Generated at 2022-06-24 17:26:53.453845
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    try:
        assert WritableStream.__subclasscheck__(WritableStream)
    except Exception:
        print("Exception: assert WritableStream.__subclasscheck__(WritableStream)")
    try:
        writable_stream_0 = WritableStream()
        try:
            writable_stream_0.write("")
            if not(len(writable_stream_0.write("")) == 0):
                raise AssertionError("len(writable_stream_0.write('')) == 0")
        except Exception:
            print("Exception: writable_stream_0.write('')")
    except Exception:
        print("Exception: writable_stream_0 = WritableStream()")

# Generated at 2022-06-24 17:26:55.843885
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream = WritableStream()
    with pytest.raises(TypeError):
        writable_stream.write(object())


# Generated at 2022-06-24 17:27:07.026129
# Unit test for function get_repr_function
def test_get_repr_function():
    from itertools import count
    from collections import namedtuple
    Thing = namedtuple('Thing', 'number')
    assert get_repr_function(Thing(1), ()) == repr
    assert get_repr_function(Thing(1), ((Thing, lambda a: 'eggs'),)) == (
        lambda a: 'eggs'
    )
    assert get_repr_function(Thing(1), ((int, lambda a: 'eggs'),)) == repr
    assert get_repr_function(Thing(1), ((str, lambda a: 'eggs'),)) == repr

# Generated at 2022-06-24 17:27:18.657498
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('1')
    writable_stream_0.write('')
    writable_stream_0.write('2')
    writable_stream_0.write('')
    try:
        writable_stream_0.write('3')
    except AttributeError:
        pass
    else:
        raise AssertionError
        pass



# Generated at 2022-06-24 17:27:21.017299
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('hello')


    writable_stream_1 = WritableStream()
    writable_stream_1.write('hello')

# Generated at 2022-06-24 17:27:30.653963
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, []) == repr

    assert get_repr_function([], []) == repr

    assert get_repr_function([], [(lambda x: True, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )

    assert get_repr_function(object(), [(object, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )

    assert get_repr_function(object(), [(lambda x: False, lambda x: 'hi')]) == (
        repr
    )



# Generated at 2022-06-24 17:27:34.287429
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    with pytest.raises(TypeError):
        writable_stream_0.write()


# Generated at 2022-06-24 17:27:36.672163
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    global writable_stream_0
    writable_stream_0.write('x')


# Generated at 2022-06-24 17:27:44.747997
# Unit test for function get_repr_function
def test_get_repr_function():
    from .custom_repr import CustomRepr
    cr = CustomRepr((lambda x: isinstance(x, int), lambda x: 'int! %s' % x))
    assert get_repr_function(3, cr) is not repr
    assert get_repr_function(3, cr)(3) == 'int! 3'
    assert get_repr_function('abc', cr) is repr
    assert get_repr_function('abc', cr) == repr
    assert get_repr_function((3, 'abc'), cr) is repr
    assert get_repr_function((3, 'abc'), cr) == repr


# Generated at 2022-06-24 17:27:46.786668
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('abcde')


# Generated at 2022-06-24 17:27:48.552205
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    assert writable_stream_0


# Generated at 2022-06-24 17:27:50.617319
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('w')

# Generated at 2022-06-24 17:27:56.461872
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: x)]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: x)]) is repr
    assert get_repr_function(1, [(isinstance, lambda x: x)])(1) == 1
    assert get_repr_function(1, [(int, lambda x: x)])(1) == 1
    assert get_repr_function(1, [(int, lambda x: x), (float, lambda x: x)])(
        1) == 1



# Generated at 2022-06-24 17:28:11.489011
# Unit test for function get_repr_function
def test_get_repr_function():

    def ref_equal(a, b):
        """Quick and dirty"""
        return str(a) == str(b)

    def custom_repr(x):
        return "I'm a {}.".format(type(x).__name__)
    cr = [
        (lambda x: isinstance(x, bool),
         custom_repr),
    ]
    assert get_repr_function(True, cr) is custom_repr
    assert get_repr_function(False, cr) is custom_repr
    assert get_repr_function(None, cr) is repr

    assert get_shortish_repr(True, cr, max_length=None) == "I'm a bool."
    assert get_shortish_repr(True, cr, max_length=0) == '...'

    # Test if

# Generated at 2022-06-24 17:28:17.135265
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_1 = WritableStream()
    try: writable_stream_1.write('text')
    except: pass
    writable_stream_2 = WritableStream()
    try: writable_stream_2.write(1)
    except: pass
    writable_stream_3 = WritableStream()
    try: writable_stream_3.write('text')
    except: pass
    writable_stream_4 = WritableStream()
    try: writable_stream_4.write(1)
    except: pass

# Generated at 2022-06-24 17:28:27.720029
# Unit test for function get_repr_function
def test_get_repr_function():
    def roundtrip(d, custom_repr=None):
        repr_func = get_repr_function(d, custom_repr)
        return repr_func(d)
    def custom(x):
        return 'this is something i want'
    a = roundtrip(12345)
    assert a == '12345'
    b = roundtrip(12345, custom_repr=((int, custom),))
    assert b == 'this is something i want'
    c = roundtrip(123.45)
    assert c == '123.45'
    d = roundtrip(123.45, custom_repr=((float, custom),))
    assert d == 'this is something i want'
    e = roundtrip('hi')
    assert e == "'hi'"

# Generated at 2022-06-24 17:28:36.462871
# Unit test for function get_repr_function
def test_get_repr_function():
    original_repr = repr
    class MyClass: pass
    my_instance = MyClass()
    assert get_repr_function(my_instance, []) is original_repr
    assert get_repr_function(my_instance, [
        (lambda item: False, lambda item: 'special repr')
    ]) is original_repr
    assert get_repr_function(my_instance, [
        ((type, MyClass), lambda item: 'special repr')
    ]) is not original_repr
    assert get_repr_function(my_instance, [
        ((type, MyClass), lambda item: 'special repr')
    ])(my_instance) == 'special repr'

# Generated at 2022-06-24 17:28:39.340568
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('string'+'string')
    assert(True)

# Generated at 2022-06-24 17:28:49.390520
# Unit test for function get_repr_function
def test_get_repr_function():
    from .contextmanagers import ignored
    from .filesystem_tools import make_temp_file

    from .filesystem_tools import make_temp_file


# Generated at 2022-06-24 17:28:56.728431
# Unit test for function get_repr_function
def test_get_repr_function():

    def custom_repr(x):
        return 'hi!'

    custom_repr_1 = custom_repr

    assert get_repr_function(1, ()) == repr
    assert get_repr_function(int, ()) == repr
    assert get_repr_function(2, ((lambda x: x > 1, str), )) == str
    assert get_repr_function(2, ((lambda x: x > 1, custom_repr_1), )) == \
                                                                   custom_repr



# Generated at 2022-06-24 17:29:08.803161
# Unit test for function get_repr_function
def test_get_repr_function():
    # Assert that a function is returned for lists
    assert get_repr_function([1,2,3]) == repr

    # Assert that a custom function is returned
    assert get_repr_function([1,2,3],[(list,int)]) == int

    # Assert that a custom function is returned when condition is a type
    assert get_repr_function([1,2,3],[(list, lambda x: int(x))]) == int

    # Assert that a custom function is returned when condition is a function
    assert get_repr_function([1,2,3],[(lambda x: True, lambda x: int(x))]) == int

    # Assert that a defualt function will be returned if the custom function doesn't match

# Generated at 2022-06-24 17:29:11.205948
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_1 = WritableStream()
    # This test case tests the body of method write for class WritableStream.
    # It is not testing the method's contract.



# Generated at 2022-06-24 17:29:16.614543
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(2, (int, str, repr)) == repr

    class A(object): pass
    a = A()

# Generated at 2022-06-24 17:29:26.330563
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass

if sys.version_info.major == 2:
    from .pycompat import PY3
    py3 = False
elif sys.version_info.major == 3:
    from .pycompat import PY2
    py3 = True
else:
    raise Exception('Unsupported Python version. Please contact the author.')



# Generated at 2022-06-24 17:29:27.414856
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    x = WritableStream()
    assert x.write("string") == None


# Generated at 2022-06-24 17:29:28.059685
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    print('hello')

# Generated at 2022-06-24 17:29:30.905286
# Unit test for function get_repr_function
def test_get_repr_function():
    # Create a dictionary with key:value
    d = {1:2, 3:4, 5:6}

    for key in d:
        # Check if the key exists in 'd'
        assert get_repr_function(key, d) == 2
    print('All the tests have passed')




# Generated at 2022-06-24 17:29:33.510122
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    write_stream = WritableStream(sys.stdout)
    write_stream.write('hello world')
    write_stream.write('\r\n')

# Generated at 2022-06-24 17:29:36.843064
# Unit test for function get_repr_function
def test_get_repr_function():
    try:
        test_case_0()
        print(
            'TRACE: Passed test case 0 (get_repr_function)'
        )
    except AssertionError as err:
        print(
            'ERROR: Failed test case 0 (get_repr_function)'
        )
        print(err.args)

test_get_repr_function()

# Generated at 2022-06-24 17:29:41.896621
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    W = WritableStream
    if W.write is None:
        return
    W.write()
    W.write()



# Generated at 2022-06-24 17:29:42.767468
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert True



# Generated at 2022-06-24 17:29:53.408326
# Unit test for function get_repr_function
def test_get_repr_function():
    if(ensure_tuple(sys.platform) == ('darwin',)):
        str_0 = '8W2g`'
        var_0 = get_repr_function(str_0, str_0)
    if(ensure_tuple(sys.platform) == ('win32',)):
        str_0 = 'lLqa)'
        var_0 = get_repr_function(str_0, str_0)
    if(ensure_tuple(sys.platform) == ('darwin',)):
        str_0 = ':{U]^'
        var_1 = get_repr_function(str_0, str_0)
    if(ensure_tuple(sys.platform) == ('win32',)):
        str_0 = '{yvkR'
        var

# Generated at 2022-06-24 17:29:54.573901
# Unit test for function get_repr_function
def test_get_repr_function():
    test_case_0()




# Generated at 2022-06-24 17:30:06.132113
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    xs = str()
    ws = WritableStream()
    ws.write(xs)

# Generated at 2022-06-24 17:30:09.647337
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_0 = WritableStream()
    str_0 = 'Y0|>j'
    var_1 = var_0.write(str_0)
    assert str_0 == var_1


# Generated at 2022-06-24 17:30:14.655262
# Unit test for function get_repr_function
def test_get_repr_function():
    var_1 = 'F9M}'

# Generated at 2022-06-24 17:30:16.472336
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    file_0 = sys.stdout
    # <TODO>


# Generated at 2022-06-24 17:30:17.251515
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass

# Generated at 2022-06-24 17:30:27.524574
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    Stream = WritableStream
    assert isinstance(Stream, type)
    assert issubclass(Stream, ABC)
    assert Stream.__mro__ == (Stream, ABC, object)
    assert isinstance(Stream.write, types.MethodType)
    assert Stream.__abstractmethods__ == frozenset({'write'})
    assert Stream.__base__ is abc.ABC
    assert Stream.__bases__ == (abc.ABC,)
    class SubClass(Stream):
        assert issubclass(SubClass, Stream)
        assert SubClass.__mro__ == (SubClass, Stream, abc.ABC, object)
        assert SubClass.__bases__ == (Stream,)
    assert issubclass(SubClass, Stream)
    assert isinstance(SubClass().write, types.MethodType)

# Generated at 2022-06-24 17:30:31.378772
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_0 = WritableStream.write(
        WritableStream,
        WritableStream.__subclasshook__(WritableStream)
    )
    var_1 = isinstance(
        WritableStream,
        WritableStream
    )
    assert var_1 is True
    assert var_0 is True


# Generated at 2022-06-24 17:30:34.163600
# Unit test for function get_repr_function
def test_get_repr_function():
    get_repr_function = get_repr_function()
    assert get_repr_function


# Generated at 2022-06-24 17:30:37.065714
# Unit test for function get_repr_function
def test_get_repr_function():
    str_0 = '6;?){6'
    str_1 = get_repr_function(str_0, str_0)
    assert repr(str_1) == repr(get_repr_function(str_0, str_0))



# Generated at 2022-06-24 17:30:39.250866
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, ((int, lambda x: x),)) == 5



# Generated at 2022-06-24 17:31:10.210784
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = 'W6B>Pr'
    str_1 = get_shortish_repr(str_0)
    assert str_1 == 'W6B>Pr'

    lst_0 = ['Y', '<:G']
    str_2 = get_shortish_repr(lst_0)
    assert str_2 == "['Y', '<:G']"

    str_3 = get_shortish_repr(str_3)
    assert str_3 == 'REPR FAILED'

    lst_1 = ['_dHo', ';egI', 'y>|Q']
    str_4 = get_shortish_repr(lst_1)
    assert str_4 == "['_dHo', ';egI', 'y>|Q']"

    str_5

# Generated at 2022-06-24 17:31:13.146119
# Unit test for function get_repr_function
def test_get_repr_function():
    def _test_get_repr_function(str_0):
        var_0 = get_repr_function(str_0, str_0)
        assert var_0 == str_0
    test_case_0()


# Generated at 2022-06-24 17:31:18.195829
# Unit test for function get_repr_function
def test_get_repr_function():
    str_0 = 'Ix'
    var_0 = get_repr_function(str_0, str_0)
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 17:31:21.410342
# Unit test for function get_repr_function
def test_get_repr_function():
    # Test normal operation
    str_0 = 'W6B>Pr'
    var_0 = get_repr_function(str_0, str_0)
    assert var_0 == str_0

