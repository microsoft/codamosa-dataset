

# Generated at 2022-06-24 17:21:35.263356
# Unit test for function get_repr_function
def test_get_repr_function():
    tuple_0 = None
    tuple_1 = (None,)
    tuple_2 = (-75)
    tuple_3 = ((tuple_2,),)
    tuple_4 = float(0)
    tuple_5 = float(-0)
    tuple_6 = float(1)
    tuple_7 = float(-1)
    tuple_8 = (False, (tuple_2,),)
    tuple_9 = (-75,)
    tuple_10 = (-75, None,)
    tuple_11 = (None,)
    tuple_12 = (False, None,)
    tuple_13 = (tuple_0,)
    tuple_14 = tuple_8
    tuple_15 = tuple_12
    tuple_16 = (tuple_0,)
    tuple_17 = (-75,)
    tuple_18 = tuple_9
    tuple_

# Generated at 2022-06-24 17:21:37.545392
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C:
        def write(self, s):
            pass
    assert(C, WritableStream)


# Generated at 2022-06-24 17:21:39.300782
# Unit test for function shitcode
def test_shitcode():
    assert shitcode("¢¢¥¥««\u2605") == "???????"



# Generated at 2022-06-24 17:21:40.728459
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert _check_methods(WritableStream, 'write') == True


# Generated at 2022-06-24 17:21:48.016349
# Unit test for function get_repr_function
def test_get_repr_function():
    for item in (1, None, '', [], {}):
        if get_repr_function(item, []) is not repr:
            raise AssertionError
    for item in (1, None, '', [], {}):
        if get_repr_function(item, [(True, int)]) is not int:
            raise AssertionError
    for item in (1, None, '', [], {}):
        if get_repr_function(item, [(True, int), (False, str)]) is not str:
            raise AssertionError



# Generated at 2022-06-24 17:21:59.889002
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('áÁ¡ãẃŵ') == '??¡???'
    assert shitcode('ħħħħħħħħħħħħ') == '???????????'
    assert shitcode('') == ''
    assert shitcode(chr(65535)) == chr(255)
    assert shitcode(chr(0)) == ''
    assert shitcode('\x00') == ''
    assert shitcode('\x01') == '\x01'
    assert shitcode('\x99') == '\x99'
    assert shitcode('\xFF') == '\xFF'

# Generated at 2022-06-24 17:22:01.748186
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert hasattr(WritableStream.write, '__call__')


# Generated at 2022-06-24 17:22:06.138722
# Unit test for function get_repr_function
def test_get_repr_function():
    for i in range(0,1):
        for j in range(0,1):
            assert get_repr_function(i, j) is j;
    assert get_repr_function(None, None) is j;

# Generated at 2022-06-24 17:22:13.826686
# Unit test for function get_repr_function
def test_get_repr_function():
    from python_toolbox.python_toolbox import get_repr_function
    test_fails = False
    def my_repr(x): return 1
    assert(get_repr_function(1, ((int, my_repr),)) == my_repr)
    assert(get_repr_function(1, ((2, my_repr),)) == repr)
    assert(get_repr_function(1, ((lambda x, y=1: x == y, my_repr),)) == my_repr)
    assert(get_repr_function(1, ((lambda x, y=2: x == y, my_repr),)) == repr)
    try: assert(get_repr_function(1, ((2, my_repr),)) == my_repr)
    except: test_f

# Generated at 2022-06-24 17:22:15.929002
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = WritableStream()
    stream.write(1)


# Generated at 2022-06-24 17:22:23.153398
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_file = open(__file__, 'rb+')
    file_output = WritableStream()
    file_output.write(test_file.___write)



# Generated at 2022-06-24 17:22:24.058333
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_case_0()

# Generated at 2022-06-24 17:22:32.556774
# Unit test for function get_repr_function
def test_get_repr_function():
    def func_0(x):
        return x
    def func_1(x):
        return x
    assert get_repr_function(0, [
        (int, func_1),
        (str, func_0)
    ]) == func_1
    assert get_repr_function(1, [
        (int, func_1),
        (str, func_0)
    ]) == func_1
    assert get_repr_function('', [
        (int, func_1),
        (str, func_0)
    ]) == func_0
    assert get_repr_function('¥', [
        (int, func_1),
        (str, func_0)
    ]) == func_0

# Generated at 2022-06-24 17:22:39.373880
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    repr_function = lambda x: 'A string'
    assert get_shortish_repr('A string', ((lambda x: True, repr_function),)) == 'A string'
    assert get_shortish_repr('A string', ((False, repr_function),),
                             max_length=10) == 'A string'
    assert get_shortish_repr('A string', ((False, repr_function),),
                             max_length=5) == 'A st...'


# Generated at 2022-06-24 17:22:42.356099
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    result = get_shortish_repr([1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4], max_length=10)
    assert result == '[1, 2, 3,...'


# Generated at 2022-06-24 17:22:46.299889
# Unit test for function get_repr_function
def test_get_repr_function():
    from .tests.lib import my_repr
    from .tests.lib import MyDict

    m = MyDict((('a', '1'), ('b', '2')))

    assert get_repr_function(m, ((type, lambda x: '<type>'),
                                 (MyDict, my_repr),
                                 )) == my_repr



# Generated at 2022-06-24 17:22:48.436732
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream = WritableStream()
    with pytest.raises(NotImplementedError):
        writable_stream.write('test')



# Generated at 2022-06-24 17:22:53.647948
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Make sure write() does what it's supposed to do.
    sys.stdout.write("Test: WritableStream.write()\n")

    # Test with a file
    open("tmp_file", "wb").close()
    f = open("tmp_file", "rb+")
    ws = WritableStream()
    ws.write = f.write
    ws.write(b"Test test")
    ws.write(b"\n")
    f.seek(0)
    if f.read() != b'Test test\n':
        raise ValueError("Wrong write()")
    f.close()
    sys.stdout.write("Test passed\n")

    # Test with a StringIO
    f = StringIO()
    ws = WritableStream()
    ws.write = f.write

# Generated at 2022-06-24 17:23:03.602195
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    a = []
    a.append(1)
    print(get_shortish_repr(a, max_length = None))
    b = [[1, 2, 3]]
    b.append(b)
    print(get_shortish_repr(b, max_length = None))
    c = [1, 2, 3]
    print(get_shortish_repr(c, max_length = 9))



test_case_0()
test_get_shortish_repr()

# Generated at 2022-06-24 17:23:13.172870
# Unit test for function get_repr_function
def test_get_repr_function():
    class Number(object):
        def __init__(self, num):
            self.num = num
        def __repr__(self):
            return str(self.num)
    custom_repr = (
        (type(''), lambda s: '"' + s + '"'),
        (Number, lambda number: 'NUMBER: ' + str(number.num)),
    )
    assert get_repr_function('a', custom_repr) == '"' + 'a' + '"'
    assert get_repr_function(2, custom_repr) == repr(2)
    assert get_repr_function(Number(3), custom_repr) == 'NUMBER: 3'



# Generated at 2022-06-24 17:23:24.157555
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stderr
    # Test for case where `s` is a string
    test_string = 'This is a test string.'
    stream.write(test_string)
    # Test for case where `s` is not a string
    test_tuple = ('This is a test', 'tuple.')
    stream.write(test_tuple)
    # Test for case where `s` is not a string
    test_list = ['This is a test', 'list.']
    stream.write(test_list)



# Generated at 2022-06-24 17:23:27.861371
# Unit test for function get_repr_function
def test_get_repr_function():
    repr_function = get_repr_function(None, custom_repr=[str, str.lower])
    repr_function('Joe') == 'joe'


# Generated at 2022-06-24 17:23:35.754926
# Unit test for function get_repr_function
def test_get_repr_function():
    try:
        assert get_repr_function(1, ((2, 'b'), (1, 'a'))) == 'a'
        assert get_repr_function(2.0, ((2, 'b'), (1, 'a'))) == 'b'
    except AssertionError:
        print('Failed at basic get_repr_function test.')
        raise
    else:
        print('Passed basic get_repr_function test.')


# Generated at 2022-06-24 17:23:39.896200
# Unit test for function get_repr_function
def test_get_repr_function():
    int_0 = 3
    custom_repr_0 = ((int_0, 'int'),)
    repr_function_0 = get_repr_function(int_0, custom_repr_0)
    repr_function_1 = get_repr_function(str_0, custom_repr_0)
    assert repr_function_0 == 'int'
    assert repr_function_1 != 'int'

# Generated at 2022-06-24 17:23:43.265772
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class ClassOne(WritableStream):
        def write(self, s):
            pass

    one = ClassOne()
    assert one.write('hey') is None




# Generated at 2022-06-24 17:23:51.240488
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Create a new instance of WritableStream
    name_0 = WritableStream()
    # Test method write of class WritableStream
    # Test with argument s of type tuple
    str_0 = '¢¢¥¥««★'
    var_0 = shitcode(str_0)
    # Check that method write of class WritableStream returns the correct value
    assert var_0 == (name_0.write(var_0))



# Generated at 2022-06-24 17:23:54.164959
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    w = WritableStream()
    w.write('test')



# Generated at 2022-06-24 17:23:57.934461
# Unit test for function get_repr_function
def test_get_repr_function():
    global str_0
    global var_0
    set_up_test_case_0()
    test_case_0()
    assert var_0 == shitcode(str_0)



# Generated at 2022-06-24 17:24:07.039850
# Unit test for function get_repr_function
def test_get_repr_function():

    # When custom_repr is empty, default representation
    # should be returned
    assert get_repr_function(1, []) == repr

    # When custom_repr is empty, custom representation
    # should be returned
    assert get_repr_function(1, [(lambda x: True, lambda x: x)]) == 1

    # When custom_repr is empty, custom representation
    # should be returned
    assert get_repr_function(1, [(type, lambda x: x)]) == 1

    # When a complicated custom_repr is specified,
    # the correct condition should be returned
    assert get_repr_function(
        '1', [(lambda x: x == '1', lambda x: x),(lambda x: x == '2', lambda x: x)]) == '1'

    # When a complicated custom_

# Generated at 2022-06-24 17:24:07.632964
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert True



# Generated at 2022-06-24 17:24:20.856863
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = '¢¢¥¥««★'
    assert get_shortish_repr(str_0, max_length=3) == '¢¢¥¥…'
    assert get_shortish_repr(str_0, max_length=2) == '¢¢¥›'
    assert get_shortish_repr(str_0, max_length=1) == '¢»'
    assert get_shortish_repr(str_0, max_length=0) == '※'
    assert get_shortish_repr(str_0, max_length=4, normalize=True) == '¢¢¥¥…'

# Generated at 2022-06-24 17:24:22.738943
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def write(self, s):
            pass
    MyStream().write('hi')


# Generated at 2022-06-24 17:24:33.683500
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, {}) == repr
    assert get_repr_function(1, ((lambda x: True, lambda x: 2))) == 2
    assert get_repr_function(1, ((lambda x: False, lambda x: 2))) == repr
    assert get_repr_function(1, ((type(None), lambda x: 2))) == 2
    assert get_repr_function(None, ((type(None), lambda x: 2))) == 2
    assert get_repr_function(None, ((type(None), lambda x: 2))) == 2
    assert get_repr_function(None, ((lambda x: False, lambda x: 2))) == repr

# Generated at 2022-06-24 17:24:39.169560
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    try:
        str_0 = '¢¢¥¥««★'
        var_0 = shitcode(str_0)
        sys.stdout.write(var_0)
    except:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        exc_type = exc_type.__name__
        format_tb = traceback.format_exc()
        short_tb = ''.join(format_tb.splitlines()[-1:]) if format_tb \
            else 'Traceback (most recent call last) not available'
        print('TEST FAILED: {exception}: {short_tb}'.format(
            exception=exc_type,
            short_tb=short_tb
        ))

# Generated at 2022-06-24 17:24:43.250370
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    temp_1 = sys.stdout
    #sys.stdout = WritableStream()
    try:
        WritableStream().write('')
    finally:
        sys.stdout = temp_1
        

# Generated at 2022-06-24 17:24:55.326292
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(
        'a', [
            (str, lambda x: 'str-override'),
            (int, lambda x: 'int-override'),
        ]
    )('a') == 'str-override'
    assert get_repr_function(
        3, [
            (str, lambda x: 'str-override'),
            (int, lambda x: 'int-override'),
        ]
    )(3) == 'int-override'
    assert get_repr_function(
        2.3, [
            (str, lambda x: 'str-override'),
            (int, lambda x: 'int-override'),
            (float, lambda x: 'float-override'),
        ]
    )(2.3) == 'float-override'



# Generated at 2022-06-24 17:25:01.262407
# Unit test for function get_repr_function
def test_get_repr_function():
    # If an isinstance() check was done on a type that was not a type, but was
    #  a list, then the program would throw a TypeError, saying that
    #  isinstance() expected two arguments.
    bad_custom_repr = [(list, lambda x: 'buggy lambda function')]
    assert all(get_repr_function(i, bad_custom_repr) == repr for i in range(10))

    # For the list [1.2], get_repr_function() should return str().
    good_custom_repr = [
        (float, str),
    ]
    assert get_repr_function(1.2, good_custom_repr) == str
    assert get_repr_function([1.2], good_custom_repr) == repr


# Generated at 2022-06-24 17:25:08.221964
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Update global symbols
    global max_length
    global repr_function
    global repr_function
    repr_function = None
    repr_function = (
        (
            lambda item: True,
            lambda item: ''.join(
                (
                    c if (0 < ord(c) < 256) else '?'
                ) for c in str_0
            )
        ),
    )
    repr_function = get_repr_function(frozenset(), get_shortish_repr)
    assert repr_function(frozenset()) == repr(frozenset())
    # Update global symbols
    global max_length
    global max_length
    max_length = None
    max_length = 42
    assert get_shortish_repr(str_0, max_length=max_length) == var_0

# Generated at 2022-06-24 17:25:15.260928
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(str_0, custom_repr=(('ç', str_0))).__name__ == 'str_0'
    assert get_repr_function((1, 2, 3), custom_repr=(('ç', str_0))).__name__ == 'repr'
    assert get_repr_function((1, 2, 3), custom_repr=(('ç', str_0))).__self__ is None




# Generated at 2022-06-24 17:25:21.282658
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(test_get_shortish_repr) == 'function test_get_shortish_repr at 0x%x' % id(test_get_shortish_repr)


if __name__ == '__main__':
    test_get_shortish_repr()

# Generated at 2022-06-24 17:25:31.513880
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import tempfile
    temp_file = None
    try:
        temp_file = tempfile.TemporaryFile(mode='w+')
        temp_file.write('')
        temp_file.seek(0)
        temp_file.read()
    finally:
        if temp_file:
            temp_file.close()

# Generated at 2022-06-24 17:25:37.491961
# Unit test for function get_repr_function
def test_get_repr_function():
    def func_0(x):
        return x.__repr__
    func_1 = get_repr_function(5, ((int, func_0),))
    func_2 = get_repr_function('', ((int, func_0),))

# Generated at 2022-06-24 17:25:38.636421
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass # TODO: implement test.


# Generated at 2022-06-24 17:25:43.046039
# Unit test for function get_repr_function
def test_get_repr_function():
    from startup_namer import main
    assert get_repr_function(
        main,
        custom_repr=(
            (lambda x: True, lambda x: '<Main>'),
        )
    ) == '<Main>'


# Generated at 2022-06-24 17:25:46.082963
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass

    WritableStreamSubclass()


# Generated at 2022-06-24 17:25:48.638506
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(
        object(), # `item`
        [(int, '')] # `custom_repr`
    ) == ''


# Generated at 2022-06-24 17:26:00.974907
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: '1')]) == '1'
    assert get_repr_function(1.0, [(int, lambda x: '1')]) == repr
    assert get_repr_function(
        1, [lambda x: True, lambda x: '1']) == '1'
    assert get_repr_function(1, [(lambda x: False, str), (int, str)]) == str
    assert get_repr_function(
        1, [(lambda x: True, str), (int, str)]) == str
    assert get_repr_function(1, [(1, str)]) == str
    assert get_repr_function(2, [(1, str)]) == repr

# Generated at 2022-06-24 17:26:06.753416
# Unit test for function get_repr_function
def test_get_repr_function():
    class C:
        def __init__(self, value):
            self.value = value

        def _repr(self):
            return '<C %s>' % self.value

    c = C(5)

    assert get_repr_function(5, ()) is repr
    assert get_repr_function(5, custom_repr=((5, 5),)) == 5
    assert get_repr_function(c, ()) is repr
    assert get_repr_function(c, custom_repr=((lambda x: hasattr(x, '_repr'),
                                              lambda x: x._repr()),))(c) == \
                                                                      '<C 5>'



# Generated at 2022-06-24 17:26:08.922287
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    msg = 'test_WritableStream_write'
    stream.write(msg)

# Generated at 2022-06-24 17:26:14.764855
# Unit test for function get_repr_function
def test_get_repr_function():
    """
    Check if a repr function was chosen correctly
    """
    class MyClass0:
        pass
    my_class0_instance = MyClass0()
    assert get_repr_function(my_class0_instance, ()) is repr
    assert get_repr_function(my_class0_instance,
                             ((lambda x: False, lambda x:'badlambda'),)) is repr
    assert get_repr_function(my_class0_instance,
                             ((MyClass0, lambda x:'badlambda'),)) == 'badlambda'
    assert get_repr_function(my_class0_instance,
                             ((lambda x: False, lambda x:'badlambda'),
                              (MyClass0, lambda x: 'goodlambda'))) == 'goodlambda'

# Generated at 2022-06-24 17:26:32.973974
# Unit test for function get_repr_function
def test_get_repr_function():
    def c(item):
        if isinstance(item, dict):
            return 'DICT'
        if isinstance(item, set):
            return 'SET'
        if isinstance(item, list):
            return 'LIST'
        if isinstance(item, tuple):
            return 'TUPLE'
        return repr(item)
    def test(item):
        assert (get_repr_function(item, ((dict, 'DICT'), (set, 'SET'),
                                         (list, 'LIST'), (tuple, 'TUPLE')))
                == c(item))
    for item in (1, '2', 3.4, {}, {1, 2, 3}, [], '', b'', None, True, False,
                 (1, 2), []):
        test(item)



# Generated at 2022-06-24 17:26:40.033965
# Unit test for function get_repr_function
def test_get_repr_function():
    # Tests the function get_repr_function
    var_0 = False
    var_1 = []
    var_2 = get_repr_function(var_1, [])
    var_3 = repr
    var_0 = var_3 == var_2
    var_1 = True
    var_2 = get_repr_function(var_1, [])
    var_3 = repr
    var_0 = var_3 == var_2
    var_1 = None
    var_2 = get_repr_function(var_1, [])
    var_3 = repr
    var_0 = var_3 == var_2
    var_1 = 'var_1'
    var_2 = get_repr_function(var_1, [])
    var_3 = repr

# Generated at 2022-06-24 17:26:49.130319
# Unit test for function get_repr_function
def test_get_repr_function():
    var_1 = (
        (lambda _: False, lambda _: "BINGO"),
        (int, lambda _: "BINGO"),
        (lambda _: False, lambda _: "BANGO"),
        (str, repr)
    )
    var_2 = 7
    var_3 = get_repr_function(var_2, var_1)
    if var_3 is repr:
        return None
    else:
        return var_3(var_2)


# Generated at 2022-06-24 17:26:55.613235
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyWritableStream(object):
        def write(self, s):
            self.s_that_was_written = s

    my_writable_stream = MyWritableStream()

    class MyWritableStreamSubclass(MyWritableStream):
        pass

    assert issubclass(MyWritableStreamSubclass, WritableStream)

    assert isinstance(my_writable_stream, WritableStream)

    my_writable_stream.write('asdf')

    assert my_writable_stream.s_that_was_written == 'asdf'



# Generated at 2022-06-24 17:26:57.359327
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert isinstance('', WritableStream)
    assert isinstance(sys.stdout, WritableStream)




# Generated at 2022-06-24 17:27:00.867748
# Unit test for function get_repr_function
def test_get_repr_function():
    from . import ipython
    custom_repr = (
        (ipython.IPythonObject, lambda x: "ipython object"),
    )
    str_0 = '¢¢¥¥««★'
    var_0 = get_repr_function(str_0, custom_repr)


# Generated at 2022-06-24 17:27:03.562929
# Unit test for function get_repr_function
def test_get_repr_function():
    str_0 = 'Y¤¿Å¥®½'
    var_0 = get_repr_function(str_0, ())
    assert(var_0 == repr)



# Generated at 2022-06-24 17:27:04.794629
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert ensure_tuple('str') == ensure_tuple('str')

# Generated at 2022-06-24 17:27:05.705823
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert var_0 == '?????'




# Generated at 2022-06-24 17:27:10.244736
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    def test(x):
        return 'test'
    assert get_repr_function(1, ((int, test),)) == test
    assert get_repr_function(1.0, ((int, test),)) == repr
    assert get_repr_function(1.0, ((float, test),)) == test


# Generated at 2022-06-24 17:27:34.221960
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import doctest
    failed, total = doctest.testmod(sys.modules[__name__])
    assert failed == 0, '{} of {} tests failed'.format(failed, total)

# Generated at 2022-06-24 17:27:39.714168
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, [(int, str)]) is str
    assert get_repr_function(0., [(int, str)]) is repr
    assert get_repr_function(0, [(int, str), (float, str)]) is str
    assert get_repr_function(0., [(int, str), (float, str)]) is str



# Generated at 2022-06-24 17:27:49.421728
# Unit test for function get_repr_function
def test_get_repr_function():

    # print('running test_get_repr_function')

    item_0, item_1, item_2, item_3 = '', 1, [], []
    custom_repr_0 = [
        (lambda x: isinstance(x, str),
         lambda x: 'a string!'),
        (lambda x: x is item_2,
         lambda x: 'item 2'),
    ]

    function_0 = get_repr_function(item_0, custom_repr_0)
    assert (function_0(item_0) == 'a string!')

    function_0 = get_repr_function(item_1, custom_repr_0)
    assert (function_0(item_1) == '1')


# Generated at 2022-06-24 17:27:59.827605
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class MyClass(object):
        pass

    custom_repr = (
        (type(MyClass), lambda x: 'POUET'),
    )
    assert get_shortish_repr(MyClass, custom_repr=custom_repr) == 'POUET'
    assert get_shortish_repr(1, max_length=10) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr((1, 2, 3), max_length=5) == '(1, 2, ...'
    assert get_shortish_repr(set([1, 2, 3]), max_length=5) == '{1, 2, ...'
    assert get_shortish_repr(u'aaa', max_length=3)

# Generated at 2022-06-24 17:28:10.307001
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) == repr
    assert get_repr_function(None, ((lambda x: True, lambda x: 'x'))) == repr
    assert get_repr_function(None, ((lambda x: False, lambda x: 'x'))) == repr
    assert get_repr_function('x', ((lambda x: True, lambda x: 'x'))) == 'x'
    assert get_repr_function('x', ((lambda x: False, lambda x: 'x'))) == repr
    assert get_repr_function('x', ((lambda x: True, lambda x: 'y'))) == 'y'
    assert get_repr_function('x', ((lambda x: False, lambda x: 'y'))) == repr

# Generated at 2022-06-24 17:28:12.407310
# Unit test for function get_repr_function
def test_get_repr_function():
    """Unit test for function get_repr_function"""
    # Testing for string/Error
    get_repr_function('', [])



# Generated at 2022-06-24 17:28:14.214437
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    stream.write('Hello')
    assert stream.write(None) is None

# Generated at 2022-06-24 17:28:16.936530
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    item = 'hello'
    custom_repr = ()
    max_length = 20
    
    r = get_shortish_repr(item, custom_repr, max_length)
    assert r == 'hello'


# Generated at 2022-06-24 17:28:23.108337
# Unit test for function get_repr_function
def test_get_repr_function():
    def test_repr(item):
        return '< %s >' % (item,)

    my_object = object()
    reprs = [(type(str), repr),
             (lambda item: item is my_object, test_repr)]

    assert get_repr_function('', reprs) is repr
    assert get_repr_function(my_object, reprs) is test_repr



# Generated at 2022-06-24 17:28:34.815010
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    # Implicitly try writing to stdout.
    WritableStream.write(sys.stdout, 'The magic words are squeamish ossifrage.')

    # If we get here, we succeeded. Now let's try something fancy:

    class MyWritableStream(WritableStream):
        def write(self, s):
            # Also write to stdout and then to stderr.
            sys.stdout.write(s + '\n')
            sys.stderr.write(s + '\n')

    # Let's try it:
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('There is no spoon.')

    # If we got here, we succeeded.



# Generated at 2022-06-24 17:29:26.064016
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    
    # Constructor for class WritableStream
    class WritableStream_1(WritableStream):
    
        def __init__(self, arg_0):
            """Called when the object is initialized."""
            pass
        
        def write(self, arg_0):
            """Called when the `write` method is invoked."""
            pass
    
    
    assert(isinstance(WritableStream_1, ABC))
    instance_0 = WritableStream_1()
    try:
        instance_0.write('abc')
        assert(True)
    except TypeError:
        assert(False)
    try:
        WritableStream_1.write(instance_0, 123)
        assert(False)
    except:
        assert(True)



# Generated at 2022-06-24 17:29:28.201135
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    str_0 = '◒◒◖◗'
    writable_stream_0.write(str_0)


# Generated at 2022-06-24 17:29:30.020093
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    str_1 = '¢¢¥¥««★'
    var_0 = shitcode(str_1)


# Generated at 2022-06-24 17:29:39.863902
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(0) == "0"
    assert get_shortish_repr(0, max_length=1) == "0"
    assert get_shortish_repr(0, max_length=2) == "0"
    assert get_shortish_repr(0, max_length=0) == ""

    assert get_shortish_repr(0, max_length=1, normalize=True) == "0"
    assert get_shortish_repr(0, max_length=2, normalize=True) == "0"
    assert get_shortish_repr(0, max_length=0, normalize=True) == ""


    assert get_shortish_repr(0.8, max_length=1) == "0..."
    assert get_shortish_

# Generated at 2022-06-24 17:29:42.291533
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(WritableStream, ()) is WritableStream.__repr__

# Generated at 2022-06-24 17:29:51.109956
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, []) is repr
    assert get_repr_function(5, [(lambda x: True, str)]) is str
    assert get_repr_function(5, [(lambda x: False, str)]) is repr
    assert get_repr_function(5, [(lambda x: True, str), (lambda x: False, str)]) is str
    assert get_repr_function(5, [(lambda x: False, str), (lambda x: True, str)]) is str

# Generated at 2022-06-24 17:29:54.144235
# Unit test for function get_repr_function
def test_get_repr_function():
    try:
        assert get_repr_function(['a',1], [(str, str)]) == str
    except AssertionError:
        print(get_repr_function(['a',1], [(str, str)]))


# Generated at 2022-06-24 17:30:04.022121
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(A, max_length=6) == 'A'
    code = compile('1+1', '', 'exec')
    assert get_shortish_repr([1, 2, 3], max_length=None) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=5) == '[1, ...]'
    assert get_shortish_repr('abcdefg', max_length=5) == 'abcde...'


# Generated at 2022-06-24 17:30:14.396974
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    var_0 = get_shortish_repr(['[]', '{}', '()'], (
        (float, lambda f: '{:.10f}'.format(f)),),
        max_length=10, normalize=True
    )
    assert var_0 == "['[]', '{}', '()']"

    var_0 = get_shortish_repr(['[]', '{}', '()'], (
        (float, lambda f: '{:.10f}'.format(f)),),
        max_length=10, normalize=False
    )
    assert var_0 == "['[]', '{}', '()']"


# Generated at 2022-06-24 17:30:26.291290
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, str), str)) == str
    assert get_repr_function('', ((int, str), str)) == str
    assert get_repr_function(2.2, ((int, str), str)) == repr
    assert get_repr_function((), ((int, str), str)) == repr

    assert get_repr_function('', custom_repr=((int, str), str)) == str
    assert get_repr_function('', custom_repr=((float, str), str)) == repr

    assert get_repr_function('', custom_repr=((int, str), str)) == str
    assert get_repr_function('', custom_repr=((float, str), str)) == repr
