

# Generated at 2022-06-24 17:21:28.062992
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    WritableStream.__subclasshook__()
    file_writing_errors = (
        IOError,
        OSError,
        ValueError # IronPython weirdness.
    )
    @abc.abstractmethod
    def write(self, s):
        pass
    @classmethod
    def __subclasshook__(cls, C):
        if cls is WritableStream:
            return _check_methods(C, 'write')
        return NotImplemented
    @classmethod
    def __instancecheck__(cls, instance):
        return _check_methods(instance.__class__, 'write')


# Generated at 2022-06-24 17:21:32.834900
# Unit test for function shitcode
def test_shitcode():
    with open(__file__) as f:
        t = f.read()
    t = shitcode(t)
    assert t.count('?') < len(t) // 2
    assert t.count('\r') + t.count('\n') == 0


# Generated at 2022-06-24 17:21:37.114158
# Unit test for function get_repr_function
def test_get_repr_function():
    assert '<' in get_repr_function('', ())
    assert '<' in get_repr_function('', ((lambda x: True, lambda x: ''),))
    assert get_repr_function('', ((lambda x: False, lambda x: ''),)) != ''


# Generated at 2022-06-24 17:21:46.607707
# Unit test for function get_repr_function
def test_get_repr_function():
    # test function get_repr_function
    custom_repr = [
        (int, 'bigint'),
        (float, 'dub'),
        (type, 'not a real object')
    ]
    assert get_repr_function(10, custom_repr) != repr
    assert get_repr_function(10, custom_repr) == 'bigint'
    custom_repr.append(lambda x: isinstance(x, str)
                       and x.lower() in {'yo', 'hello', 'sup'})
    assert get_repr_function('yo', custom_repr) != repr
    assert get_repr_function('yo', custom_repr) == 'yo'
    assert get_repr_function('Yo', custom_repr) == repr

# Generated at 2022-06-24 17:21:51.115763
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('\u1234') == '????'
    assert shitcode('foo\u1234bar\u1234') == 'foo????bar????'

# Generated at 2022-06-24 17:21:59.547350
# Unit test for function get_repr_function
def test_get_repr_function():
    arg_0 = [('A',[('B',[('C',[('D',1)]),2])],'abc','100')]
    arg_1 = [(lambda x: isinstance(x,int) ,len),(lambda x: isinstance(x,str) ,shitcode),(lambda x: isinstance(x,tuple) ,lambda x: ','.join((shitcode(i) for i in x)))]
    var_2 = get_repr_function(arg_0,arg_1)
    assert var_2 != 0.0 and var_2 != ''


# Generated at 2022-06-24 17:22:00.960409
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    write = WritableStream()
    write.write(list())


# Generated at 2022-06-24 17:22:09.656981
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello', max_length=7) == 'hello'
    assert get_shortish_repr('hello', max_length=15) == 'hello'
    assert get_shortish_repr('hello', max_length=3) == 'hel'
    assert get_shortish_repr('hello', max_length=None) == 'hello'
    assert get_shortish_repr('hello', max_length=0) == ''

    assert get_shortish_repr(1, max_length=7) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'

# Generated at 2022-06-24 17:22:12.351357
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_0 = WritableStream()
    var_1 = ''

    var_0.write(var_1)


# Generated at 2022-06-24 17:22:20.154190
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Testing Empty
    list_0 = []
    var_0 = get_shortish_repr(list_0)
    print(var_0)
    # Testing Empty
    print(get_shortish_repr())
    # Testing Normal
    var_1 = get_shortish_repr([1, 2])
    print(var_1)
    # Testing Normal
    var_2 = get_shortish_repr('hello')
    print(var_2)


# Generated at 2022-06-24 17:22:26.046260
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    list_0 = []
    var_0 = truncate(list_0, max_length=None)


# Generated at 2022-06-24 17:22:28.350599
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass
    # method write of class WritableStream
    # has no test as it is abstract

# Generated at 2022-06-24 17:22:39.047765
# Unit test for function get_repr_function
def test_get_repr_function():
    from pytest_cute import assert_no_exception, assert_no_warnings, assert_equal
    custom_repr = [('a', lambda x: 'custom repr for a'), (1, lambda x: 'custom repr for 1')]
    assert_no_exception(lambda: get_repr_function('a', custom_repr))
    repr_function = get_repr_function('a', custom_repr)
    assert_equal(repr_function('a'), 'custom repr for a')
    custom_repr = [((lambda x: isinstance(x, str) and len(x) > 5), lambda x: 'long string')]
    assert_no_exception(lambda: get_repr_function('123456789', custom_repr))

# Generated at 2022-06-24 17:22:46.953610
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(0) == '0'
    assert get_shortish_repr('') == '""'
    assert get_shortish_repr([1,2,3]) == '[1, 2, 3]'
    assert get_shortish_repr([1,2,3],max_length=12) == '[1, 2, 3]'
    assert get_shortish_repr([1,2,3],max_length=11) == '[1, 2, 3]'
    assert get_shortish_repr([1,2,3],max_length=10) == '[1, 2, 3]'
    assert get_shortish_repr([1,2,3],max_length=9) == '[1, 2, 3]'

# Generated at 2022-06-24 17:22:49.236465
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    str_0 = ''
    stream_0 = sys.stderr
    stream_0.write(str_0)


# Generated at 2022-06-24 17:22:53.432297
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    list_0 = []
    custom_repr = (())
    max_length = 6
    var_0 = get_shortish_repr(list_0,custom_repr,max_length)


# Generated at 2022-06-24 17:23:08.214797
# Unit test for function get_repr_function
def test_get_repr_function():
    class TestClass(object):
        pass
    assert get_repr_function(TestClass, ()) is repr
    class TestClass_1(TestClass):
        pass
    assert get_repr_function(TestClass_1(), ()) is repr
    assert get_repr_function('', ()) is repr
    #assert get_repr_function(None, ()) is repr
    assert get_repr_function(str, ()) is repr
    assert get_repr_function(TestClass, ((type, str),)) is str
    assert get_repr_function(TestClass, ((lambda x: x == 1, str),)) is str
    assert get_repr_function(TestClass, ((lambda x: x == 2, str),)) is repr
    assert get_repr_function(None, ((lambda x: x == 2, str),))

# Generated at 2022-06-24 17:23:19.234042
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([]) == '[]'
    assert get_shortish_repr([1, 2, 3, 4, 5, 6, 7]) == '[1, 2, 3, 4, 5, 6, 7]'
    assert get_shortish_repr([1, 2, 3, 4, 5, 6, 7], max_length=11) == \
                                                         '[1, 2, 3, 4]'
    assert get_shortish_repr([1, 2, 3, 4, 5, 6, 7], max_length=12) == \
                                                      '[1, 2, 3, 4, 5]'
    assert get_shortish_repr([1, 2, 3, 4, 5, 6, 7], max_length=13) == \
                                                     '[1, 2, 3, 4, 5,...'

# Generated at 2022-06-24 17:23:20.879305
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    print("Testing method write of class WritableStream")
    WritableStream.write("hi")
    print("Returning from method write of class WritableStream")


# Generated at 2022-06-24 17:23:30.262874
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(123, max_length=2) == '12'
    assert get_shortish_repr(123, max_length=3) == '123'
    assert get_shortish_repr(123, max_length=4) == '123'
    assert get_shortish_repr('hello', max_length=2) == 'he'
    assert get_shortish_repr('hello', max_length=3) == 'hel'

# Generated at 2022-06-24 17:23:39.512342
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import bytes_literal
    import sys
    import collections
    import types

    # Mock needed objects
    class Mock_io(collections.MutableMapping):

        def __init__(self):
            self.store = dict()

        def __getitem__(self, key):
            return self.store[key]

        def __setitem__(self, key, value):
            self.store[key] = value

        def __delitem__(self, key):
            del self.store[key]

        def __iter__(self):
            return iter(self.store)

        def __len__(self):
            return len(self.store)

    class Mock_sys(object):
        stdout = Mock_io()
        stderr = Mock_io()

    # Setup
    sys_

# Generated at 2022-06-24 17:23:51.725750
# Unit test for function get_repr_function
def test_get_repr_function():
    def function(x):
        if x == 0:
            return 1
        elif x == 1:
            return 2
        else:
            return 3

    def function_0(x):
        if x == 3:
            return 1
        elif x == 1:
            return 2
        else:
            return 3

    def function_1(x):
        if x == 0:
            return 1
        elif x == 5:
            return 2
        else:
            return 3

    def function_2(x):
        if x == 0:
            return 1
        elif x == 1:
            return 2
        else:
            return 4

    def function_3(x):
        if x == 1:
            return 1
        elif x == 0:
            return 2
        else:
            return 3

   

# Generated at 2022-06-24 17:23:58.185616
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Test with a string:
    assert get_shortish_repr("hello") == "hello"
    assert get_shortish_repr("hello", max_length=1) == "h..."
    assert get_shortish_repr("hello", max_length=5) == "hello"


# Generated at 2022-06-24 17:24:05.401829
# Unit test for function get_repr_function
def test_get_repr_function():
    for x in range(0, 10):
        custom_repr = [('', '0')]
        repr_result = get_repr_function(x, custom_repr)
        assert repr_result == '0'
    print('All tests succeeded.')

test_get_repr_function()
test_case_0()

# Generated at 2022-06-24 17:24:07.390525
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    list_0 = "Text"
    var_0 = stream.write(list_0)


# Generated at 2022-06-24 17:24:18.177300
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Test that we can use a custom repr function
    print('Test that we can use a custom repr function')
    class TestClass:
        def __init__(self, x):
            self.x = x
        def __repr__(self):
            return 'TestClass(x={})'.format(self.x)
    test_class = TestClass('a')
    assert get_shortish_repr(test_class) == 'TestClass(x=a)'
    assert get_shortish_repr(test_class,
                             custom_repr=((type(test_class), str),)) == 'a'
    test_class_b = TestClass('a\nb')
    assert get_shortish_repr(test_class_b) == 'TestClass(x=a\\nb)'

# Generated at 2022-06-24 17:24:19.926468
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert 1==1 # TODO: implement your test here


# Generated at 2022-06-24 17:24:23.002208
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    x = WritableStream.__subclasshook__(type(stream))
    assert x is True
    x = WritableStream.__subclasshook__(list)
    assert x is NotImplemented


# Generated at 2022-06-24 17:24:26.220099
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([1, 2, 3], max_length=14) == '[1, 2, 3]'


# Generated at 2022-06-24 17:24:35.130300
# Unit test for function get_repr_function
def test_get_repr_function():
    # Python 3.5+ is required to run tests with static analysis.
    # I wrote this test because PyCharm was reporting false positive
    # warnings, saying that get_repr_function will always return the
    # repr function even though the condition is False.
    import sys
    PY35_OR_ABOVE = (sys.version_info >= (3, 5))

    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    a = A()
    b = B()
    c = C()

    assert get_repr_function(a, custom_repr=[(A, 4)]) == 4
    assert get_repr_function(b, custom_repr=[(A, 4)]) == 4

# Generated at 2022-06-24 17:24:44.120577
# Unit test for function get_repr_function
def test_get_repr_function():
    list_0 = []
    var_0 = get_repr_function(list_0)
    var_1 = type(var_0) == type(get_repr_function)
    assert var_1



# Generated at 2022-06-24 17:24:52.708377
# Unit test for function get_repr_function
def test_get_repr_function():
    print('Test 1:')
    assert get_repr_function('0', [])() == '\'0\''
    print('ok')
    print('Test 2')
    assert get_repr_function(0, [])() == '0'
    print('ok')
    print('Test 3')
    assert get_repr_function('0', [(lambda x: True, lambda: 'non-zero')])() == 'non-zero'
    print('ok')

# Generated at 2022-06-24 17:24:55.179548
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """ Unit test for method write of class WritableStream """
    WritableStream(file_0, list_0, int_0).write(var_0, file_1, file_2)




# Generated at 2022-06-24 17:24:58.365786
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    list_0 = []
    var_0 = WritableStream()
    var_1 = var_0.write(list_0)


# Generated at 2022-06-24 17:25:07.444747
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from . import testdata
    def example(x):
        return get_shortish_repr(x, max_length=100)

# Generated at 2022-06-24 17:25:11.035906
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('foobar') == 'foobar'
    assert get_shortish_repr(42) == '42'


# Generated at 2022-06-24 17:25:15.669778
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    list_0 = []
    def func_0(val_0, max_length_0=None):
        out_0 = truncate(val_0, max_length_0)
        return out_0
    func_0(list_0, max_length_0=6)
    return func_0(list_0, max_length_0=1)






# Generated at 2022-06-24 17:25:22.978974
# Unit test for function get_repr_function
def test_get_repr_function():
    # Test:
    # 1. list_0 is a list
    # 2. a generator function is defined to be used as get_repr_function's
    #    argument
    # 3. get_repr_function is called with list_0 and the generator function
    #    should return a generator object
    list_0 = []
    var_0 = lambda x: x
    var_1 = get_repr_function(list_0, var_0)


# Generated at 2022-06-24 17:25:34.450020
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from . import get_shortish_repr

    assert get_shortish_repr('hello, world!') == "u'hello, world!'"
    assert get_shortish_repr(u'hello, world!') == "u'hello, world!'"
    obj = object()
    assert get_shortish_repr(obj) == '<object object at 0x{:x}>'.format(id(obj))
    assert get_shortish_repr(obj, max_length=10) == \
                                              '<object...0x{:x}>'.format(id(obj))
    assert get_shortish_repr(obj, max_length=9) == '<obje...x{:x}>'.format(id(obj))

# Generated at 2022-06-24 17:25:35.820971
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    list_0 = []
    var_0 = get_shortish_repr(list_0)


# Generated at 2022-06-24 17:25:50.672586
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert True

# Generated at 2022-06-24 17:25:56.155942
# Unit test for function get_repr_function
def test_get_repr_function():
    def func_0(var_0_0):
        return get_repr_function(item=var_0_0, custom_repr=((int, lambda x: 'int'),))
    var_0 = func_0(1)
    assert var_0 == repr
    var_1 = func_0('1')
    assert var_1 == repr
    var_2 = func_0(b'1')
    assert var_2 == repr


# Generated at 2022-06-24 17:26:04.007150
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('123456789') == '123456789'
    assert get_shortish_repr('123456789', max_length=1) == '1'
    assert get_shortish_repr('123456789', max_length=6) == '123...9'
    assert get_shortish_repr('123456789', max_length=7) == '123...89'
    assert get_shortish_repr('123456789', max_length=8) == '123456789'
    assert get_shortish_repr('123456789', max_length=9) == '123456789'
    assert get_shortish_repr('123456789', max_length=10) == '123456789'

# Generated at 2022-06-24 17:26:06.085948
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(list_0, custom_repr) == repr(list_0)



# Generated at 2022-06-24 17:26:10.976121
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    if not isinstance(sys.stdout, WritableStream):
        print('Wrong types: %s' % ((type(sys.stdout), WritableStream),))
    else:
        sys.stdout.write('%s: %d\n' % (sys.stdout.__class__.__name__, sys.stdout.__hash__(),))
    pass



# Generated at 2022-06-24 17:26:20.327629
# Unit test for function get_repr_function
def test_get_repr_function():
    str1 = r'hello'
    list1 = []
    dict1 = {}
    set1 = set()
    tuple1 = ()
    class test:
        pass
    obj1 = test()
    t = (get_repr_function(str1, []), get_repr_function(list1, []), get_repr_function(dict1, []), get_repr_function(set1, []), get_repr_function(tuple1, []), get_repr_function(obj1, []))
    assert t == (repr, repr, repr, repr, repr, repr)


# Generated at 2022-06-24 17:26:24.313030
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    from . import my_writable_stream
    # Some object of a class that inherits from `WritableStream`.
    writable_stream_0 = my_writable_stream.MyWritableStream()
    # Method `write` is called on it.
    writable_stream_0.write("")



# Generated at 2022-06-24 17:26:32.516891
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # long repr with newlines
    assert get_shortish_repr([2, 3, 5, 7, 11, 13, 17, 19]) == '[2, 3, 5, 7, 11, 13, 17, 19]'
    assert get_shortish_repr([2, 3, 5,
                              7, 11, 13, 17, 19]) == '[2, 3, 5, 7, 11, 13, 17, 19]'
    assert get_shortish_repr([2, 3, 5,
                              7, 11,
                              13, 17,
                              19]) == '[2, 3, 5, 7, 11, 13, 17, 19]'

    # repr is a class, which is special
    class D(object):
        pass
    assert get_shortish_repr(D, normalize=True) == 'D'

   

# Generated at 2022-06-24 17:26:34.291704
# Unit test for function shitcode
def test_shitcode():
    list_0 = []
    var_0 = shitcode(list_0)
    assert var_0 == ''

# Generated at 2022-06-24 17:26:40.496882
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    try:
        var_0 = WritableStream()
        var_0.write(var_0)
    except TypeError as exception_0:
        pass


# Generated at 2022-06-24 17:27:12.134521
# Unit test for function get_repr_function
def test_get_repr_function():
    def _test_get_repr_function():
        assert get_repr_function(1, []) is repr
        assert get_repr_function(1, [(lambda _: True, id)]) is id
        assert get_repr_function(1, [(lambda _: False, id)]) is repr
        assert get_repr_function(1, [(int, id)]) is id
        assert get_repr_function(1.2, [(int, id)]) is repr
        assert get_repr_function(1, [(int, 'invalid')]) == 'invalid'
        assert get_repr_function(1, [(1, id)]) is id
        assert get_repr_function(2, [(1, id)]) is repr
    _test_get_repr_function()



# Generated at 2022-06-24 17:27:22.144078
# Unit test for function shitcode
def test_shitcode():
    # Testing for Eq
    list_0 = []
    var_0 = shitcode(list_0)
    assert var_0 == ''

    list_1 = ['\U000fffff', 'c', '\U0001efffe', '\U000ffffe']
    var_1 = shitcode(list_1)
    assert var_1 == '????????c???'

    list_2 = ['\U000fffe6']
    var_2 = shitcode(list_2)
    assert var_2 == '?'

    list_3 = ['\U000fffe6', '\U000fffff', '\U0001efffe']
    var_3 = shitcode(list_3)
    assert var_3 == '????'


# Generated at 2022-06-24 17:27:32.734186
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    #from pytest import raises
    assert True
    #from six import BytesIO
    #from six.moves import StringIO
    #from garlicsim.general_misc.third_party.six.moves import cStringIO
    #from garlicsim.general_misc.third_party.six.moves import StringIO

    # Test with `six.BytesIO`.
    #f = BytesIO()
    #assert f is not None
    #assert WritableStream.__subclasshook__(type(f)) is True
    #isinstance(f, WritableStream)

    # Test with `six.moves.cStringIO`.
    #f = cStringIO()
    #assert f is not None
    #assert WritableStream.__subclasshook__(type(f)) is True
    #isinstance(f, WritableStream

# Generated at 2022-06-24 17:27:35.585047
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    list_0 = []
    var_0 = WritableStream()
    var_0.write(list_0)


# Generated at 2022-06-24 17:27:40.733478
# Unit test for function get_repr_function
def test_get_repr_function():
    # Assert that get_repr_function returns the correct output for a string
    custom_repr = [(lambda x,y=5: 1, lambda x: x*x)]
    assert get_repr_function('abcd', custom_repr) == repr

# Generated at 2022-06-24 17:27:50.144296
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    list_0 = []
    var_0 = get_shortish_repr(list_0)
    assert var_0 == "[]"

    dict_0 = {}
    var_1 = get_shortish_repr(dict_0)
    assert var_1 == "{}"

    int_0 = 2
    var_2 = get_shortish_repr(int_0)
    assert var_2 == "2"

    str_0 = ""
    var_3 = get_shortish_repr(str_0)
    assert var_3 == '""'

    list_1 = [""]
    var_4 = get_shortish_repr(list_1)
    assert var_4 == "['']"

    list_2 = ["", ""]

# Generated at 2022-06-24 17:27:57.079764
# Unit test for function shitcode
def test_shitcode():
    list_0 = [55, 67, 12, 26, 27, 23, 12]
    list_1 = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    string_0 = 'KV\x15\x84'
    string_1 = 'QV\x15\x84'
    string_2 = '\x7f\x15\x84'
    string_3 = '\x7f\x15\x85'
    string_4 = '\x7f\x15\x84\x84'
    assert shitcode(list_0) == 'KV\x15\x84', '##'
    assert shitcode(list_1) == 'QV\x15\x84', '##'

# Generated at 2022-06-24 17:28:05.356523
# Unit test for function get_repr_function
def test_get_repr_function():
    from .test_helpers import (iterable_to_string,
                               get_shortish_repr)
    custom_repr = [
        (lambda x: x==42, lambda x: 'the answer'),
        ((int, float, bool), str),
        (list, iterable_to_string),
        (dict, lambda d: '{{{}}}'.format(
            ' '.join('{!s}:{!s}'.format(get_shortish_repr(k),
                                        get_shortish_repr(v))
                     for k, v in d.items()))),
    ]
    assert get_repr_function(42,
                             custom_repr) == custom_repr[0][1]
    assert get_repr_function(True,
                             custom_repr) == custom_

# Generated at 2022-06-24 17:28:08.854234
# Unit test for function get_repr_function
def test_get_repr_function():
    try:
        assert list_0 == 1
    except:
        etype, value, tb = sys.exc_info()
        item = value
        custom_repr = []
        assert get_repr_function(item, custom_repr) == repr


# Generated at 2022-06-24 17:28:15.094167
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import StringIO
    r = re.compile('a')
    w = StringIO()
    w.write(r)
    assert r == w.getvalue()
    w.close()

    s = WritableStream()
    assert s.write(r) is NotImplemented

    class A:  # noqa: N801
        pass
    a = A()
    a.write = lambda _: None
    assert a.write(r) is None
    assert isinstance(a, WritableStream)


# Generated at 2022-06-24 17:28:42.270728
# Unit test for function shitcode
def test_shitcode():
    list_0 = []
    var_0 = shitcode(list_0)
    assert var_0 == ''


# Generated at 2022-06-24 17:28:46.439867
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from . import sys
    from . import StringIO
    from .pycompat import StringIO as StringIO_2
    expected_0 = 'unicode'
    var_0 = sys.stdout.write(expected_0)
    actual_0 = type(var_0).__name__
    expected_1 = 'NoneType'
    assert actual_0 == expected_1


# Generated at 2022-06-24 17:28:57.908500
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(-1) == '-1'
    assert get_shortish_repr(0) == '0'
    if sys.version_info.major != 2:
        assert get_shortish_repr(2 ** 200)
    else:
        assert get_shortish_repr(2 ** 200) == repr(2 ** 200)[:25] + '...'
    assert get_shortish_repr((1, 2, 3)) == '(1, 2, 3)'
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr(1.2) == '1.2'
    assert get_shortish

# Generated at 2022-06-24 17:29:09.652398
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, custom_repr=((int, lambda x: 'a'),)) == 'a'
    assert get_shortish_repr(1, max_length=10) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'

# Generated at 2022-06-24 17:29:11.397568
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(1, lambda: 2)])() == 2


# Generated at 2022-06-24 17:29:23.474203
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = []
    assert get_repr_function(0, custom_repr) == repr

    custom_repr = [(int, str)]
    assert get_repr_function(0, custom_repr) == str

    custom_repr = [(int, None)]
    assert get_repr_function(0, custom_repr) is None

    custom_repr = [((lambda x: False, None))]
    assert get_repr_function(0, custom_repr) is None

    custom_repr = [(0, None)]
    assert get_repr_function(0, custom_repr) is None

    custom_repr = [(1, None)]
    assert get_repr_function(0, custom_repr) == repr



# Generated at 2022-06-24 17:29:27.852846
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(None) == ''
    assert shitcode([]) == ''
    assert shitcode([u'\xe2\x9c\x8c']) == '??'
    assert shitcode(u'\U0010ffff') == '?'
    assert shitcode([u'\U0010ffff']) == '?'



# Generated at 2022-06-24 17:29:29.644970
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """
    Make sure that testing will succeed.
    """
    assert 'easy' == 'easy'

# Generated at 2022-06-24 17:29:32.306154
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # There are no tests yet, but don't you worry: they are coming!
    pass # TODO: write tests here!



# Generated at 2022-06-24 17:29:41.246417
# Unit test for function get_repr_function
def test_get_repr_function():
    __tracebackhide__ = True
    assert get_repr_function(None) is repr
    assert get_repr_function(1) is repr
    assert get_repr_function(1, ((int, lambda x: str(x)*2),)) == '11'
    assert get_repr_function(1, ((int, lambda x: str(x)*2),), ) == '11'
    assert get_repr_function(1, ((str, lambda x: str(x)*2),)) is repr
    assert get_repr_function(1, ((str, lambda x: str(x)*2),), ) is repr
    assert get_repr_function(1, ((int, lambda x: str(x)*2),), (), ) == '11'

# Generated at 2022-06-24 17:30:34.479075
# Unit test for function shitcode
def test_shitcode():
    list_0 = []
    assert shitcode(list_0) == ''


# Generated at 2022-06-24 17:30:39.832747
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import sys
    import tempfile
    expected_0 = 'Windows'.encode()
    assert sys.platform.startswith('win'), 'only supported on windows'
    assert sys.getdefaultencoding() == 'utf-8', 'only supported on utf-8'
    with tempfile.TemporaryFile(mode='wb', buffering=0) as temp_file_0:
        temp_file_0_write = temp_file_0.write
        temp_file_0_write('Windows')
        temp_file_0.seek(0)
        actual_0 = temp_file_0.read()
    assert actual_0 == expected_0

# Generated at 2022-06-24 17:30:46.555844
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    list_0 = []
    #repr(object): Return the canonical string representation of the object.
    var_0 = repr(list_0)
    assert var_0 == "[]"
    # Unit test for truncate(max_length=None)
    var_0 = truncate("Test default, no max_length", None)
    assert var_0 == "Test default, no max_length"
    # Unit test for truncate(max_length=4)
    var_0 = truncate("0123456789", 4)
    assert var_0 == "0123..."
    # Unit test for truncate(max_length=5)
    var_0 = truncate("0123456789", 5)
    assert var_0 == "01234..."
    # Unit test for truncate(max_length=6)
    var_

# Generated at 2022-06-24 17:30:48.232738
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    WritableStream.write('TEST')
    return None


# Generated at 2022-06-24 17:30:49.881957
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # WritableStream.write(b'abc')
    pass


# Generated at 2022-06-24 17:30:52.448175
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    list_0 = []
    var_1 = WritableStream()
    var_1.write(list_0)


# Generated at 2022-06-24 17:30:55.241056
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    list_0 = []
    var_0 = WritableStream()
    var_1 = var_0.write(list_0)


# Generated at 2022-06-24 17:31:05.998487
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from decimal import Decimal
    from fractions import Fraction
    from datetime import timedelta, date, datetime
    from collections import OrderedDict, Counter
    from itertools import cycle, islice


    def test(item, result):
        assert get_shortish_repr(item) == result
        assert get_shortish_repr(item, normalize=True) == normalize_repr(
            result
        )


    # False:
    test(False, 'False')
    # True:
    test(True, 'True')
    # None:
    test(None, 'None')
    # Numbers:
    test(0, '0')
    test(1, '1')
    test(1.0, '1.0')
    test(1000, '1000')

# Generated at 2022-06-24 17:31:11.784642
# Unit test for function shitcode
def test_shitcode():
    list_0 = [1, 2, 3]
    var_0 = shitcode(list_0)
    assert var_0 == u'???'

    list_0 = [u'', u'', u'']
    var_0 = shitcode(list_0)
    assert var_0 == u'???'

    list_0 = [u'hello', u'', u'']
    var_0 = shitcode(list_0)
    assert var_0 == u'hello???'

    list_0 = [u'hello', u'world', u'!']
    var_0 = shitcode(list_0)
    assert var_0 == u'helloworld!'

    list_0 = [u'hello', u'world!', u'!']
    var_0 = shitcode(list_0)

# Generated at 2022-06-24 17:31:16.510701
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """
    from .pycompat import string_types
    from .py3compat import StringIO, BytesIO

    s = u'unicode object'
    b = b'bytes object'
    r = repr(b)

    for stream, x in zip((StringIO(), BytesIO()), (s, b)):
        stream.write(x)
        assert type(stream.getvalue()) is string_types
        assert stream.getvalue() == r

    del StringIO
    del BytesIO
    del string_types
    """
    pass
