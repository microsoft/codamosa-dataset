

# Generated at 2022-06-24 17:21:21.326207
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    assert hasattr(writable_stream_0, 'write')



# Generated at 2022-06-24 17:21:25.522042
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = ((lambda x: x == 4, lambda x: "4!"),
                   (lambda x: x == 6, lambda x: "6!"))

    assert get_repr_function(5, custom_repr) == repr
    assert get_repr_function(4, custom_repr)() == "4!"



# Generated at 2022-06-24 17:21:36.124321
# Unit test for function get_repr_function
def test_get_repr_function():
    class X(object):
        def __repr__(self):
            return 'hey'
        def __str__(self):
            return 'you'
    assert get_repr_function(X(), [(X, str)]) is str
    assert get_repr_function(X(), [(X, lambda x: x.__doc__)]) is None
    assert get_repr_function(X(), [(lambda x: True, lambda x: x.__doc__)]) is None
    assert get_repr_function(X(), [(lambda x: False, lambda x: x.__doc__)]) is None
    assert get_repr_function(X(), [(lambda x: True, lambda x: x.__doc__),
                                   (X, str)]) == str

# Generated at 2022-06-24 17:21:37.908765
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # type: () -> None
    test_case_0()


# Unit tests for module reprlib2

# Generated at 2022-06-24 17:21:46.364633
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(b'abc') == u'abc'
    assert shitcode(u'') == u''
    assert shitcode(b'') == u''
    assert shitcode(u'\x00') == u'?'  # NUL
    assert shitcode(b'\x00') == u'?'  # NUL
    assert shitcode(u'\x01') == u'?'  # SOH
    assert shitcode(b'\x01') == u'?'  # SOH
    assert shitcode(u'\xff') == u'?'  # �
    assert shitcode(b'\xff') == u'?'  # �

# Generated at 2022-06-24 17:21:58.491541
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('') == "''"
    assert get_shortish_repr(max_length=None) == "None"
    assert get_shortish_repr(max_length=20) == "None"
    assert get_shortish_repr('hello', max_length=None) == "'hello'"
    assert get_shortish_repr('hello', max_length=20) == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'hel...'"
    assert get_shortish_repr(1234567890, max_length=9) == "1234567...'"
    assert get_shortish_repr(1234567890, max_length=10) == "1234567890"

# Generated at 2022-06-24 17:22:05.710994
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'áã') == u'??'
    assert shitcode(u'\u2713') == u'?'
    assert shitcode(b'\x00xx') == u'\x00xx'
    assert shitcode(b'\xffxx') == u'\xffxx'
    assert shitcode(b'\x00\xff') == u'\x00\xff'
    assert shitcode(b'\x00') == u'\x00'
    assert shitcode(b'\xff') == u'\xff'


# Generated at 2022-06-24 17:22:08.375945
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Check that it doesn't crash
    test_case_0()


# Generated at 2022-06-24 17:22:09.933403
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=(('hello', str),)) == str

# Generated at 2022-06-24 17:22:13.226878
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass # ABCs do not have tests.


if __name__ == '__main__':

    test_case_0()

    test_WritableStream_write()

# Generated at 2022-06-24 17:22:16.732822
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert True


# Generated at 2022-06-24 17:22:20.333427
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = 'w$>4@'
    var_0 = get_shortish_repr(str_0)


# Generated at 2022-06-24 17:22:22.574320
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Init
    obj_0 = WritableStream()
    str_0 = 'b'

    # Call method
    obj_0.write(str_0)


# Generated at 2022-06-24 17:22:31.838705
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test with valid arguments
    # Unit test for method write of class WritableStream
    def test_WritableStream_write():
        # Test with valid arguments
        life_0 = WritableStream()
        death_0 = WritableStream()
        try:
            death_0.write('\x01\xab\xCC\xCD\xFF')
        except TypeError:
            raise AssertionError('Unable to write to writable stream.')
        death_0.close()
        try:
            life_0.write(str_0)
        except TypeError:
            raise AssertionError('Unable to write to writable stream.')
        life_0.flush()
    # Test with invalid arguments

# Generated at 2022-06-24 17:22:38.223539
# Unit test for function get_repr_function

# Generated at 2022-06-24 17:22:42.265835
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_1 = WritableStream()
    str_1 = 'XfNlz}0'
    var_0 = var_1.write(str_1)
    str_0 = '9-*Tc>|'
    var_1 = var_1.write(str_0)


# Generated at 2022-06-24 17:22:49.179190
# Unit test for function get_repr_function
def test_get_repr_function():
    for var_3 in range(0, 50):
        str_0 = 's{}'.format(var_3)
        assert get_repr_function(str_0, ((int, lambda s: s))) == repr

# Generated at 2022-06-24 17:22:51.358904
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    stream.write('')

# Generated at 2022-06-24 17:22:53.120752
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writer = WritableStream()
    writer.write('hello')



# Generated at 2022-06-24 17:23:00.260149
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Check that basic string writing works
    str_1 = '\t\x80P\x0f\x809\x1f\x81'
    bytes_0 = b'\x86\x91\x92\x93\x94\x95\x96\x97'
    var_0 = WritableStream()
    var_1 = get_shortish_repr(var_0, max_length=9)
    var_0.write(var_1)
    class_1 = sys.modules['__main__'].WritableStream
    class_2 = sys.modules['__main__'].WritableStream
    var_2 = class_2()
    var_3 = get_shortish_repr(var_2, max_length=6)

# Generated at 2022-06-24 17:23:07.972615
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test arguments and expected results

    # Call method with arguments
    str_0 = WritableStream.write("string")
    var_0 = get_shortish_repr(str_0)

# Generated at 2022-06-24 17:23:18.916789
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = '5=B:5#5'
    assert (get_shortish_repr(str_0) == '5=B:5#5')
    str_1 = 'w6U,b6U*b6U-b6U.b6U/b6U0b6U1b6U2b6U3b6U4b6U5b6U6b6U7b6U8b6U9b6U:b6U;b6U<b6U=b6U>b6U?b6U@b6UA'

# Generated at 2022-06-24 17:23:20.395908
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    str_0 = ')'
    stream = sys.stdout
    stream.write(str_0)
    return None

# Generated at 2022-06-24 17:23:29.955758
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, [(lambda: False, lambda: 'abc')]) == repr
    assert get_repr_function(5, [(lambda: True, lambda: 'abc')]) == (
        lambda: 'abc')
    assert get_repr_function(5, [(lambda x: x == 5, lambda: 'abc')]) == (
        lambda: 'abc')
    assert get_repr_function(5, [(lambda x: x == 6, lambda: 'abc')]) == repr
    assert get_repr_function(5, [(6, lambda: 'abc')]) == (lambda: 'abc')
    assert get_repr_function(5, [(5, lambda: 'abc')]) == (lambda: 'abc')

# Generated at 2022-06-24 17:23:39.034845
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class SimpleWritableStream(WritableStream):
        def write(self, s):
            print("Hello world!")

    class ClassWithWrong_write(WritableStream):

        def write(self):
            pass

    assert issubclass(SimpleWritableStream, WritableStream)
    assert not issubclass(ClassWithWrong_write, WritableStream)


if __name__ == "__main__":
    tests = [
        test_case_0,
        test_WritableStream_write
        ]
    for test in tests:
        print("=" * 60)
        print(test.__name__)
        print("-" * 60)
        test()
        print()

# Generated at 2022-06-24 17:23:45.888990
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    string_0 = '(F%wO='
    str_0 = "f3gk}"
    string_0 = "f3gk}"
    string_0 += 'U6^A;I'
    UnicodeString_0 = string_0
    var_0 = WritableStream()
    var_1 = WritableStream()
    var_1.write(string_0)


# Generated at 2022-06-24 17:23:52.660741
# Unit test for function shitcode
def test_shitcode():
    # Test that shitcode returns '?' for non ascii character
    assert shitcode('a\xe3') == 'a?'
    assert shitcode('aaa\xbb') == 'aaa?'

    # Test that shitcode returns the whole string for ascii string
    assert shitcode('bbbb') == 'bbbb'
    assert shitcode('ccccccccccccccc') == 'ccccccccccccccc'

    # Test that shitcode returns the whole string for empty string
    assert shitcode('') == ''

    # Test that shitcode returns '?' for a unicode character
    assert shitcode('efgh\u1234') == 'efgh?'



# Generated at 2022-06-24 17:23:54.909164
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = WritableStream()
    b = stream.write('abc')



# Generated at 2022-06-24 17:23:59.727695
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = 'Output stream'
    var_0 = get_shortish_repr(str_0)
    assert var_0 == 'Output stream', 'Lhs: %s Rhs: %s' % (var_0, 'Output stream')


# Generated at 2022-06-24 17:24:05.710624
# Unit test for function get_repr_function
def test_get_repr_function():
    assert (get_repr_function('f', [(lambda x, y=(): isinstance(x, y),
                                    lambda y: y)]) == 'f')



# Generated at 2022-06-24 17:24:21.130595
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    str_0 = 's'
    str_1 = 'h'
    str_2 = 'i'
    str_3 = 't'
    str_4 = 'c'
    str_5 = 'o'
    str_6 = 'd'
    str_7 = 'e'
    str_8 = '.'
    str_9 = 'r'
    str_10 = 'a'
    str_11 = 'c'
    str_12 = 'h'
    str_13 = 'u'
    str_14 = 'm'
    str_15 = '.'
    str_16 = 'c'
    str_17 = 'o'
    str_18 = 'm'
    str_19 = '/'
    str_20 = 's'
    str_21 = 'h'
    str_22

# Generated at 2022-06-24 17:24:26.748576
# Unit test for function get_repr_function
def test_get_repr_function():
    str_0 = 'I\x83\t\xa7t\x99\x1dr\xbb\x07\xcf'
    custom_repr_0 = ((str_0, lambda x: 'shit'))
    var_0 = get_repr_function(str_0, custom_repr_0)
    var_1 = get_repr_function(str_0, custom_repr_0)
    var_2 = get_repr_function(str_0, custom_repr_0)
    assert var_0 == var_1 == var_2 == 'shit'


# Generated at 2022-06-24 17:24:34.458362
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = 'X9o6=='
    dict_0 = {}
    dict_1 = {}
    list_0 = [(dict_0, dict_0, dict_0), ({}, dict_1, dict_0, dict_1)]
    var_0 = get_shortish_repr(list_0, max_length=10, normalize=True)
    assert var_0 == '(({}, {}, {}), ({}, {}, {}, {}))'
    var_0 = get_shortish_repr(str_0, max_length=10, normalize=True)
    assert var_0 == 'X9o6=='


# Generated at 2022-06-24 17:24:44.836020
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    print('Testing get_shortish_repr...')
    str_0 = '(F%wO='
    len_0 = 9
    assert len(get_shortish_repr(str_0)) == len_0
    str_1 = '(F%wO='
    len_1 = 9
    assert len(get_shortish_repr(str_1, max_length=5)) == len_1
    str_2 = '(F%wO='
    len_2 = 5
    assert len(get_shortish_repr(str_2, max_length=5, normalize=True)) == len_2
    str_3 = '(F%wO='
    len_3 = 6
    assert len(get_shortish_repr(str_3, max_length=6, normalize=True)) == len

# Generated at 2022-06-24 17:24:49.211215
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda x: hasattr(x, '__iter__'), lambda x: '{0} ...'.format(
            type(x).__name__
        )),
    )
    assert 'str ...' == get_repr_function('a string', custom_repr)


# Generated at 2022-06-24 17:24:53.352843
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream_0 = sys.stdout
    assert isinstance(stream_0, WritableStream)
    assert WritableStream.__subclasshook__(stream_0)


if __name__ == '__main__':
    test_case_0()
    test_WritableStream_write()

# Generated at 2022-06-24 17:24:56.533310
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from tigerhost.api.console import WritableStream

    class MyWritableStream(WritableStream):
        def write(self, s):
            WritableStream.write(self, s)

    my_writable_stream = MyWritableStream()

    my_writable_stream.write('str')




# Generated at 2022-06-24 17:25:00.961192
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = writable_stream()
    success = True

    try:
        assert same_strings(stream.write(str_0), None)
    except AssertionError as e:
        sys.stderr.write(
            """Test case write of class WritableStream failed. The call stream.write(str_0) was not equal to None.""")
        success = False

    return success


# Generated at 2022-06-24 17:25:04.146196
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_0 = """test string"""
    var_1 = WritableStream
    var_2 = WritableStream().write(var_0)
    return [var_0, var_1, var_2]


# Generated at 2022-06-24 17:25:05.884260
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # we can't test it, because this function is abstract
    pass


# Generated at 2022-06-24 17:25:24.952315
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = '(F%wO='
    var_0 = get_shortish_repr(str_0)
    assert var_0 == '(F%wO='
    str_0 = '$8WyFH\tbf\x1d'
    var_0 = get_shortish_repr(str_0)
    assert var_0 == '$8WyFH\tbf\x1d'
    str_0 = '\x03\x14\x00\x17\x04'
    var_0 = get_shortish_repr(str_0)
    assert var_0 == '\x03\x14\x00\x17\x04'
    str_0 = '%'
    var_0 = get_shortish_repr(str_0)
    assert var_0

# Generated at 2022-06-24 17:25:35.651401
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('(F%wO=') == "'(F%wO='"
    assert get_shortish_repr(u'(F%wO=') == "u'(F%wO='"
    assert get_shortish_repr('(F%wO=', max_length=2) == "'(Fa'"
    assert get_shortish_repr('(F%wO=', max_length=7) == "'(F%wO='"
    assert get_shortish_repr('(F%wO=', max_length=8) == "'(F%wO='"
    assert get_shortish_repr('(F%wO=', max_length=9) == "'(F%wO='"

# Generated at 2022-06-24 17:25:48.312641
# Unit test for function get_shortish_repr

# Generated at 2022-06-24 17:25:54.593528
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(test_case_0, None) \
        is get_repr_function(test_case_0, None)

    assert get_repr_function(None, None) \
        is get_repr_function(None, None)



# Generated at 2022-06-24 17:26:02.387934
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test code generated by Python fuzzer.
    stream = WTOU(ZG0YZZ1(FZH22OZ(0), FZH22OZ('')), '')
    stream.write(ZG0YZZ1(FZH22OZ(7), FZH22OZ('_[6S')))
    stream.write(ZG0YZZ1(FZH22OZ(6), FZH22OZ('J}z R')))
    stream.write(ZG0YZZ1(FZH22OZ(0), FZH22OZ('')))
    stream.write(ZG0YZZ1(FZH22OZ(1), FZH22OZ('.%?97')))

# Generated at 2022-06-24 17:26:12.261473
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert repr(get_shortish_repr(str)) == repr(str)

# Generated at 2022-06-24 17:26:13.938712
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = ... # type: WritableStream
    s = ... # type: str
    stream.write(s)


# Generated at 2022-06-24 17:26:19.205340
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = '(F%wO='
    assert get_shortish_repr(str_0) == repr(str_0[-7:-1]), 'assert#1'




# Generated at 2022-06-24 17:26:21.184609
# Unit test for function shitcode
def test_shitcode():
    str_0 = '\xe0\xfe\xd2\xdd\xfe'
    var_0 = shitcode(str_0)



# Generated at 2022-06-24 17:26:28.845980
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from StringIO import StringIO
    from .pycompat import StringIO as Py2StringIO

    if isinstance(StringIO(), StringIO):
        [sio] = ensure_tuple(StringIO())
    else:
        [sio] = ensure_tuple(Py2StringIO())
    if isinstance(StringIO(), Py2StringIO):
        [psio] = ensure_tuple(Py2StringIO())
    else:
        [psio] = ensure_tuple(StringIO())
    if (isinstance(StringIO(), StringIO) and isinstance(StringIO(), Py2StringIO)):
        [psio] = ensure_tuple(Py2StringIO())
    else:
        [psio] = ensure_tuple(StringIO())

# Generated at 2022-06-24 17:26:59.225865
# Unit test for function get_repr_function

# Generated at 2022-06-24 17:27:00.349203
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    ws = StreamIO()
    ws.write('hello world')


# Generated at 2022-06-24 17:27:05.467289
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Instantiate superclass of class WritableStream
    class Super(object):
        def write(self, s):
            print('write: ', s)
    # Instantiate subclass of class WritableStream
    class Sub(Super, WritableStream):
        pass
    # Instantiate object of class WritableStream
    x = Sub()

if __name__ == '__main__':
    test_case_0()
    test_WritableStream_write()

# Generated at 2022-06-24 17:27:13.467932
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert hasattr(WritableStream, 'write')
    assert hasattr(WritableStream, 'write')
    assert isinstance(WritableStream, object)
    assert isinstance(WritableStream, object)
    assert isinstance(WritableStream, object)
    assert isinstance(WritableStream, object)
    assert isinstance(WritableStream, object)
    assert isinstance(WritableStream, object)
    assert isinstance(WritableStream, object)
    assert isinstance(WritableStream, object)
    assert isinstance(WritableStream, object)
    assert isinstance(WritableStream, object)
    assert isinstance(WritableStream, object)
    assert isinstance(WritableStream, object)
    assert isinstance(WritableStream, object)
    assert isinstance(WritableStream, object)

# Generated at 2022-06-24 17:27:17.994303
# Unit test for function get_repr_function
def test_get_repr_function():
    var_0 = get_repr_function([0], [(list, list.__repr__)])
    str_0 = var_0([1, 2, 3, 4])
    str_1 = '[1, 2, 3, 4]'
    assert str_0 == str_1


# Generated at 2022-06-24 17:27:21.175978
# Unit test for function shitcode
def test_shitcode():
    res = None
    test_str = '-j\tWU 2G}Qe'
    res = shitcode(test_str)
    assert res == '-j\tWU 2G}Qe'



# Generated at 2022-06-24 17:27:28.961425
# Unit test for function get_repr_function
def test_get_repr_function():
    from .timing import timer

    t = timer((lambda: test_case_0()), globals(), number=100000)
    print(t) # should be about 0.3 sec
    assert len(var_0) == len(str_0)
    for i, char in enumerate(str_0):
        assert char in ascii_letters or not char.isalnum()
        assert var_0[i] == char or char == '\n'

# Generated at 2022-06-24 17:27:33.869141
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .diagnostic_tools import OutputCatcher
    try:
        import sys
        import tempfile
        fsock = sys.stdout
        stream = WritableStream()

        output = OutputCatcher()
        with output:
            stream.write('Hello')
        assert not output.output

        # Now test that the stream is actually writing something
        sys.stdout = tempfile.TemporaryFile()
        stream.write('Hello')
        sys.stdout = fsock
    finally:
        sys.stdout = fsock



# Generated at 2022-06-24 17:27:37.808819
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    with MockWritableStream as var_1:
        var_1.write('>')
    with MockWritableStream as var_2:
        var_2.write('>')


# Generated at 2022-06-24 17:27:39.338673
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_2 = '-j\tWU 2G}Qe'
    var_2 = get_shortish_repr(str_2)


# Generated at 2022-06-24 17:27:57.313411
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    
    
    pass

# Generated at 2022-06-24 17:28:03.728365
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hello', []) is repr
    assert get_repr_function('hello', [(lambda x: True, str)]) is str
    assert get_repr_function('hello', [(lambda x: False, str)]) is repr
    assert get_repr_function('hello', [(lambda x: False, str),
                                       (lambda x: True, id)]) is id
    assert get_repr_function('hello', [(lambda x: False, str),
                                       (lambda x: False, id)]) is repr



# Generated at 2022-06-24 17:28:04.373186
# Unit test for function get_repr_function
def test_get_repr_function():
    test_case_0()

# Generated at 2022-06-24 17:28:05.269929
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert True



# Generated at 2022-06-24 17:28:13.133471
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import six
    import io
    import io
    import io
    sys.stderr = io.open(sys.stderr.fileno(), mode='w', encoding='utf-8',
             closefd=False)
    sys.stdin = io.open(sys.stdin.fileno(), mode='r', encoding='utf-8',
            closefd=False)
    sys.stdout = io.open(sys.stdout.fileno(), mode='w', encoding='utf-8',
             closefd=False)
    str_0 = '-j\tWU 2G}Qe'
    var_0 = shitcode(str_0)

# Generated at 2022-06-24 17:28:16.086243
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    my_stream = writables.WritableStream(stream)
    assert repr(stream) == repr(my_stream)


# Generated at 2022-06-24 17:28:25.701540
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    max_length = 100
    assert get_shortish_repr(test_get_shortish_repr, max_length=max_length) == repr(test_get_shortish_repr)
    assert get_shortish_repr(test_get_shortish_repr, max_length=max_length).endswith(')'), repr(test_get_shortish_repr)
    assert get_shortish_repr(test_get_shortish_repr, max_length=max_length, normalize=True) == normalize_repr(
        repr(test_get_shortish_repr))

# Generated at 2022-06-24 17:28:31.410355
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(2, ((int, str), (2, 3))) == str
    assert get_repr_function(3, ((int, str), (2, 3))) == repr



# Generated at 2022-06-24 17:28:34.840340
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hi', [(str, 'hi')]) == 'hi'
    assert get_repr_function('hi', [(int, 'hi')]) == repr
    assert get_repr_function(5, [(str, 5)]) == repr
    assert get_repr_function(5, [(int, 5)]) == 5


# Generated at 2022-06-24 17:28:40.313499
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = 'y\xe3\x83\xa9'
    item = str_0
    max_length = 18
    res_0 = get_shortish_repr(item, (), max_length)
    assert res_0 == 'y\xe3\x83\xa9'


# Generated at 2022-06-24 17:29:17.713242
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    
    
    
    
    
    
    
    
    
    
    
    pass



# Generated at 2022-06-24 17:29:22.088190
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    str_0 = 'g\x9e\x14\xec\x1cI\x1f\x1a\x1b'
    var_0 = WritableStream()
    var_0.write(str_0)


# Generated at 2022-06-24 17:29:24.475994
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()



# Generated at 2022-06-24 17:29:30.910062
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\u0123', ret='\u0123') == '\u0123' # 0 - minimum valid
    assert shitcode('\u0A5E', ret='\u0A5E') == '\u0A5E' # 4126 - valid
    assert shitcode('\u0A5F', ret='\u0A5F') == '?' # 4127 - minimum invalid
    assert shitcode('\u10FFFF', ret='\u10FFFF') == '?' # 1073741823 - maximum invalid
    assert shitcode('\u10FFFE', ret='\u10FFFE') == '\u10FFFE' # 1073741822 - maximum valid


# Generated at 2022-06-24 17:29:34.620312
# Unit test for function shitcode
def test_shitcode():
    try:
        str_0 = '-j\tWU 2G}Qe'
        var_0 = shitcode(str_0)
        assert var_0 == '-j\tWU 2G}Qe'
        str_1 = '\x03'
        var_1 = shitcode(str_1)
        assert var_1 == '?'
    except AssertionError:
        raise AssertionError('The function failed to execute properly')


# Generated at 2022-06-24 17:29:43.818253
# Unit test for function get_repr_function
def test_get_repr_function():
    x = get_repr_function(0, ((int, repr), ('hello', len)))
    assert x(0) == '0'
    x = get_repr_function(0, (int, len))
    assert x(0) == '0'
    x = get_repr_function(0, (float, len))
    assert x('hello') == '5'

# Generated at 2022-06-24 17:29:53.776129
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\x67') == '?'
    assert shitcode('\x01\x23\x45\x67\x89\xab\xcd\xef\x01\x23\x45\x67\x89\xab\xcd\xef') == '????????????????'
    assert shitcode('\x01\x23\x45\x67\x89\xab\xcd\xef') == '????????'
    assert shitcode('\x01\x23\x45\x67\x89\xab\xcd') == '??????'
    assert shitcode('\x01\x23\x45\x67\x89\xab') == '????'
    assert shitcode('\x01\x23\x45\x67\x89') == '???'
    assert shit

# Generated at 2022-06-24 17:29:59.001363
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Prepare
    str_0 = 'F\t{p9*[\x0c,'
    max_length_0 = 15
    var_0 = get_shortish_repr(str_0, max_length=max_length_0)
    # Evaluate
    assert var_0 == 'F\\t{p9*[\\x0c,'
    # End



# Generated at 2022-06-24 17:30:00.133175
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    stream.write("test text")



# Generated at 2022-06-24 17:30:07.339680
# Unit test for function get_repr_function
def test_get_repr_function():
    # Test with a type
    assert get_repr_function(1, [(type(1), list)]) == list

    # Test with a lambda condition
    assert get_repr_function(1, [(lambda x: (x >= 4), list)]) == repr

    # Test with a lambda action
    assert get_repr_function(
        1, [(type(1), lambda x: (x == 1) * 'a')]
    ) == 'a'

    # Test with a lambda condition and action
    assert get_repr_function(
        1, [(lambda x: (x < 5), lambda x: x * 2)]
    ) == 2

    # Test with no matches
    assert get_repr_function(1) == repr

    # Test with multiple matches

# Generated at 2022-06-24 17:31:12.514040
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo():
        pass
    foo = Foo()

    assert not isinstance(foo, WritableStream)
    assert not issubclass(Foo, WritableStream)

    # Check that the class breaks
    try:
        WritableStream.register(Foo)
    except TypeError:
        pass
    else:
        assert False, '''\
The class CustomStream shouldn't be accepted as a subclass of WritableStream.'''

    class CustomStream(WritableStream):
        def __init__(self):
            self.history = []

        def write(self, s):
            self.history.append(s)
            return len(s)

    # Check that the class passes