

# Generated at 2022-06-24 17:21:30.677101
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write("")


# Generated at 2022-06-24 17:21:39.740201
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('123456789', max_length=None) == '123456789'
    assert get_shortish_repr('123456789', max_length=5) == '12345...89'
    assert get_shortish_repr('12345', max_length=5) == '12345'
    assert get_shortish_repr('1', max_length=5) == '1'
    assert get_shortish_repr([123456789], max_length=5) == '[123456789]'
    assert get_shortish_repr([123456789], max_length=6) == '[12345...89]'
    assert get_shortish_repr([123456789], max_length=15) == '[123456789]'
    assert get_shortish

# Generated at 2022-06-24 17:21:42.331684
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    try:
        writable_stream_0.write('hello')
    except NotImplementedError:
        pass


# Generated at 2022-06-24 17:21:47.863789
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test that writing to the stream works.
    writable_stream = WritableStream()
    #
    buffered_string = ''
    def hook(s):
        nonlocal buffered_string
        buffered_string += s
    writable_stream.write = hook
    #
    writable_stream.write('abc')
    writable_stream.write('Ͱ')
    writable_stream.write('def')
    #
    assert buffered_string == 'abcͰdef'

# Generated at 2022-06-24 17:21:59.824236
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([1, 2], max_length=10) == '[1, 2]'
    assert get_shortish_repr([1, 2], max_length=100) == '[1, 2]'
    assert get_shortish_repr([1, 2], max_length=3) == '[1...]'
    assert get_shortish_repr([1, 2], max_length=4) == '[...]'
    assert get_shortish_repr([1, 2], max_length=5) == '[...]'
    assert get_shortish_repr([1, 2], max_length=6) == '[...]'
    assert get_shortish_repr([1, 2], max_length=7) == '[...]'

# Generated at 2022-06-24 17:22:07.196021
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test that we don't get NotImplemented error for the write method
    writable_stream_1 = WritableStream()
    try:
        writable_stream_1.write('test string')
    except:
        assert False



if __name__ == '__main__':
    import sys
    import pytest
    errno = pytest.main(['-x', __file__])
    if errno:
        sys.exit(errno)

# Generated at 2022-06-24 17:22:11.844333
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\000') == '?'
    assert shitcode('\001') == '?'
    assert shitcode('\255') == '?'
    assert shitcode('\256') == '?'

    assert shitcode('a') == 'a'
    assert shitcode('b') == 'b'
    assert shitcode('z') == 'z'
    assert shitcode('A') == 'A'
    assert shitcode('B') == 'B'
    assert shitcode('Z') == 'Z'

    assert shitcode('\000C') == '?C'
    assert shitcode('\001C') == '?C'
    assert shitcode('\255C') == '?C'
    assert shitcode('\256C') == '?C'

    assert shitcode('a\000') == 'a?'

# Generated at 2022-06-24 17:22:21.814685
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(u'a', max_length=10) == u'a'
    assert get_shortish_repr(u'abc', max_length=10) == u'abc'
    assert get_shortish_repr(u'abcdefghijklmnop', max_length=10) == u'abcdef...op'
    assert normalize_repr(get_shortish_repr('a', max_length=10)) == u'a'
    assert normalize_repr(get_shortish_repr([1, 2], max_length=10)) == u'[1, 2]'

# Generated at 2022-06-24 17:22:26.276069
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()

    try:
        writable_stream_0.write('abcd')
    except AttributeError:
        print('Expected an exception due to missing implementation')


if __name__ == "__main__":
    test_case_0()
    test_WritableStream_write()

# Generated at 2022-06-24 17:22:31.135878
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('123') == '123'
    assert shitcode(chr(27)) == '?'
    assert shitcode('123' + chr(27) + '789') == '123???789'
    assert shitcode(chr(31) + '123' + chr(127)) == '?123?'
    assert shitcode('אבגד') == '?????', "This will fail on platforms like " \
                                                                 "Windows"


# Generated at 2022-06-24 17:22:43.833811
# Unit test for function get_repr_function
def test_get_repr_function():
    """test_get_repr_function"""
    assert (get_repr_function(
        None,
        [],
    ) is repr)

    class X(object):
        def __init__(self, repr_function):
            self.repr_function = repr_function
        def __repr__(self):
            return "X({})".format(self.repr_function)

    t = (1, 2, "three", X("__repr__"))
    assert get_repr_function(t, [(tuple, lambda *whatever: "tuple!")])() == "tuple!"
    assert get_repr_function(t, [(list, lambda *whatever: "list!")]) is repr

# Generated at 2022-06-24 17:22:52.056913
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, custom_repr=((int, lambda x: 'got integer'))) == \
                                                                     'got integer'
    assert get_repr_function(0.1, custom_repr=((int, lambda x: 'got integer'))) \
                                                                   == repr


# Generated at 2022-06-24 17:23:00.056799
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    def setUp():
        writable_stream_0 = WritableStream()
    def tearDown():
        del(writable_stream_0)
    def test_basics():
        writable_stream_0.write(1)
        writable_stream_0.write('a' * 16)
        writable_stream_0.write(bytearray(0))
        writable_stream_0.write(writable_stream_0)
        writable_stream_0.write(None)
        writable_stream_0.write(writable_stream_0.__class__)
    def test_empty_string():
        writable_stream_0.write('')

# Generated at 2022-06-24 17:23:02.593161
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream = WritableStream()
    writable_stream.write('a')


# Generated at 2022-06-24 17:23:03.852298
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass


# Generated at 2022-06-24 17:23:07.735322
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    assert isinstance(writable_stream_0, WritableStream)
    assert hasattr(writable_stream_0, 'write')

# Generated at 2022-06-24 17:23:13.978490
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    try:
        writable_stream_0.write('')
    except NotImplementedError:
        pass
    else:
        raise AssertionError('Didnt raise NotImplementedError')

if __name__ == '__main__':
    for case in (test_case_0, ):
        case()
    print('success')

# Generated at 2022-06-24 17:23:23.336278
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, []) is repr
    assert get_repr_function('hello', []) is repr
    assert get_repr_function((1, 2, 3), []) is repr
    assert get_repr_function([1, 2, 3], []) is repr

    assert get_repr_function(5, [(int, lambda x: 'num')]) == 'num'
    assert get_repr_function(5, [(int, lambda x: 'num'), (float, lambda x: 'float')]) == 'num'

    assert get_repr_function(5, [(lambda x: True, lambda x: 'num')]) == 'num'

# Generated at 2022-06-24 17:23:26.180927
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    with pytest.raises(TypeError):
        writable_stream_0.write()



# Generated at 2022-06-24 17:23:34.396960
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    res = get_shortish_repr({"a": 1})

# Generated at 2022-06-24 17:23:38.483689
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # @todo: write unit test for method WritableStream.write()
    assert False, "test not implemented"


# Generated at 2022-06-24 17:23:42.027055
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout

    try:
        stream.write('test_WritableStream_write')
        assert True
    except AssertionError:
        raise AssertionError



# Generated at 2022-06-24 17:23:50.106556
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    try:
        assert get_shortish_repr(dict_0) == repr(dict_0)
        assert get_shortish_repr(dict_0, max_length=100) == repr(dict_0)
        assert get_shortish_repr(dict_0, max_length=1) == '{...}'
    except AssertionError:
        return False
    return True

# Generated at 2022-06-24 17:23:52.495958
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Subclass(WritableStream):
        def write(self, s):
            pass
    assert issubclass(Subclass, WritableStream)


# Generated at 2022-06-24 17:23:56.924332
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    print("test_WritableStream_write")
    writable_stream = WritableStream()
    writable_stream.write("test string")
    assert hasattr(writable_stream, 'write')



# Generated at 2022-06-24 17:24:00.214519
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import sys
    assert isinstance(sys.stdout, WritableStream)
    assert isinstance(sys.stderr, WritableStream)



# Generated at 2022-06-24 17:24:06.806610
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    assert hasattr(stream, "write")
    stream.write("Hello")
    assert stream.write
    assert stream.write == sys.stderr.write
    assert stream.write == sys.stdout.write



# Generated at 2022-06-24 17:24:17.665187
# Unit test for function get_repr_function
def test_get_repr_function():
    dict_0 = {}
    dict_1 = {}
    dict_0 ["a"] = {}
    dict_0 ["b"] = "aoeuaoeu"
    dict_0 ["c"] = {}
    dict_0 ["d"] = {}
    dict_0 ["c"] ["d"] = {}
    dict_0 ["e"] = {}
    dict_0 ["e"] ["f"] = "aoeuaoeu"
    dict_0 ["e"] ["f"] = {}
    dict_0 ["e"] ["f"] ["g"] = "sdafasd"
    dict_0 ["e"] ["f"] ["h"] = "sdafasd"
    dict_0 ["a"] ["i"] = "sdafasd"
    dict_0 ["a"] ["j"] = "sdafasd"

# Generated at 2022-06-24 17:24:26.178681
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import abc
    import doctest
    import sys
    import unittest
    if sys.version_info >= (3, 0):
        from unittest.mock import patch
    else:
        from mock import patch
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    import StringIO
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_

# Generated at 2022-06-24 17:24:28.484488
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(dict_0) == 'None'
    assert var_0 == 'None'

# Generated at 2022-06-24 17:24:43.292846
# Unit test for function get_repr_function
def test_get_repr_function():
    dict_0 = None
    dict_1 = {}
    dict_2 = {'a': 1}

    custom_repr = (
        (str, lambda x: 'Hi'),
        (lambda x: isinstance(x, dict) and 'a' in x, lambda x: x.__repr__()),
        (dict, lambda x: 'dict'),
    )

    assert get_repr_function(dict_0, custom_repr) == str
    assert get_repr_function(dict_1, custom_repr) == dict.__repr__
    assert get_repr_function(dict_2, custom_repr) == dict.__repr__

# Generated at 2022-06-24 17:24:47.771127
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    global var_1
    for thing_0 in range(10):
        var_2 = str(thing_0)
        
        def function_0():
            var_3 = get_shortish_repr(thing_0)
            var_1.write(var_2)
        function_0()


# Generated at 2022-06-24 17:24:57.485631
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    dict_1 = dict()
    var_1 = get_shortish_repr(dict_1)
    assert var_1 == '{}'


    dict_2 = dict()
    dict_2['0'] = '0'
    var_2 = get_shortish_repr(dict_2)
    assert var_2 == "{'0': '0'}"


    dict_3 = dict()
    dict_3['0'] = '0'
    dict_3['1'] = '1'
    dict_3['2'] = '2'
    dict_3['3'] = '3'
    dict_3['4'] = '4'
    dict_3['5'] = '5'
    dict_3['6'] = '6'
    dict_3['7'] = '7'
    dict_

# Generated at 2022-06-24 17:24:59.568075
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    output = sys.stdout
    var_0 = WritableStream.__subclasshook__(output.__class__)
    output.write('test\n')

# Generated at 2022-06-24 17:25:07.510111
# Unit test for function get_repr_function
def test_get_repr_function():
    dict_0 = None
    var_0 = get_repr_function(dict_0, custom_repr=())
    var_1 = get_repr_function(dict_0, custom_repr=((lambda x: True, repr),))
    var_2 = get_repr_function(dict_0)

    dict_1 = {}
    var_3 = get_repr_function(dict_1, custom_repr=((dict, repr), (type, repr)))
    var_4 = get_repr_function(dict_1, custom_repr=((dict, repr), (type, repr), (1, repr)))
    var_5 = get_repr_function(dict_1, custom_repr=((dict, 1), (type, repr), (1, repr)))


# Generated at 2022-06-24 17:25:08.483708
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    test_case_0()

# Generated at 2022-06-24 17:25:18.345995
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    dict_0 = None
    var_0 = get_shortish_repr(dict_0)
    assert var_0 == "None"
    dict_0 = {}
    var_0 = get_shortish_repr(dict_0)
    assert var_0 == "{}"
    dict_0 = {"key_0": "valu"}
    var_0 = get_shortish_repr(dict_0)
    assert var_0 == "{'key_0': 'valu'}"
    dict_0 = {"key_1": "value_2", "key_3": "value_4"}
    var_0 = get_shortish_repr(dict_0)
    assert var_0 == "{'key_1': 'value_2', 'key_3': 'value_4'}"

# Generated at 2022-06-24 17:25:21.485063
# Unit test for function get_repr_function
def test_get_repr_function():
    dict_0 = None
    var_1 = get_repr_function(dict_0, (None, None))


# Generated at 2022-06-24 17:25:22.795744
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    dict_0 = sys.stdout.write
    dict_0("test")

# Generated at 2022-06-24 17:25:34.450459
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    output_0 = sys.stdout
    output_1 = sys.stderr
    file_object_0 = open('./python-lib-sugar/tests/outputs/tests_output/test_pysugar/test_output_stream.txt', 'a+')
    output_2 = file_object_0
    output_3 = open('./python-lib-sugar/tests/outputs/tests_output/test_pysugar/test_output_stream.txt', 'w')
    def test1(output):
        cond_0 = isinstance(output, WritableStream)
        if cond_0:
            output.write('success!')
        else:
            raise ValueError
    test1(output_0)
    test1(output_1)
    test1(output_2)
    test1

# Generated at 2022-06-24 17:25:44.262273
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # TODO: Add tests!
    #       One test should be to use a FakeFile to make sure the write method
    #       is actually written to it.
    #       Another test should be to test functionality of other methods that
    #       use this method.
    assert False



# Generated at 2022-06-24 17:25:48.638168
# Unit test for method write of class WritableStream
def test_WritableStream_write():

   # Create an instance of the WritableStream class
    writable_stream_instance = WritableStream()

   # Call the write method of the WritableStream class with a string
   # argument
    var_0 = writable_stream_instance.write('hello')


# Generated at 2022-06-24 17:25:59.204993
# Unit test for function get_repr_function
def test_get_repr_function():
    dict_0 = type
    dict_0_str = "type"
    dict_1 = object
    dict_1_str = "object"

    # Test normal input.
    test_repr = get_repr_function(dict_0, dict_0, dict_0_str)
    assert test_repr == dict_0_str

    # Test when there is no match in the tuple.
    test_repr = get_repr_function(dict_1, dict_0, dict_0_str)
    assert test_repr == dict_0_str


# Generated at 2022-06-24 17:26:01.254787
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    s = WritableStream()
    s.write('test')
    # Unit test for method write of class WritableStream

# Generated at 2022-06-24 17:26:04.888778
# Unit test for function get_repr_function
def test_get_repr_function():
    try:
        import nose
    except ImportError:
        raise Exception("This module's tests require the `nose` package.")
    nose.tools.with_setup(test_case_0, setup=None, teardown=None)

# Generated at 2022-06-24 17:26:11.362632
# Unit test for function get_repr_function
def test_get_repr_function():
    dict_0 = None
    dict_1 = None

    def v_0(x): return x is None
    def v_1(x, y=2): return x is None

    assert get_repr_function(dict_0, ((v_0, '_0'), (v_1, '_1'))) == '_0'
    assert get_repr_function(dict_1, ((v_0, '_0'), (v_1, '_1'))) == '_0'



# Generated at 2022-06-24 17:26:22.933226
# Unit test for function get_repr_function
def test_get_repr_function():
    examples = (
        # Test common cases
        (1, lambda x: 'one ' + str(x)),
        (2, lambda x: 'two ' + str(x)),
        (3, lambda x: 'three ' + str(x)),

        # Test default case
        (42, lambda x: 'forty-two ' + str(x)),
    )
    custom_repr = ( (1, lambda x: 'one ' + str(x)),
                    (2, lambda x: 'two ' + str(x)),
                    (3, lambda x: 'three ' + str(x))
                                                    )

# Generated at 2022-06-24 17:26:27.747743
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .bitbucket import write

    # Test when input is a string.
    string_0 = 'Hello world!'
    var_0 = sys.stdout.write(string_0)
    var_1 = WritableStream.__subclasshook__(sys.stdout)



# Generated at 2022-06-24 17:26:37.982751
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(0) == '0'
    assert get_shortish_repr(0.0) == '0.0'
    assert get_shortish_repr(1.1) == '1.1'
    assert get_shortish_repr('') == "''"
    assert get_shortish_repr('a') == "'a'"
    assert get_shortish_repr('abcde') == "'abcde'"
    assert get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert get_shortish_repr({1, 2, 3}) == '{1, 2, 3}'

# Generated at 2022-06-24 17:26:40.019071
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream = None
    s = None
    writable_stream.write(s)


# Generated at 2022-06-24 17:26:53.596948
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    inpt = WritableStream()
    out = sys.stdout

    writable_stream = WritableStream()
    writable_stream.write("")
    writable_stream.write("\n")

    writable_stream.write("")
    writable_stream.write("text")
    writable_stream.write("text")
    writable_stream.write("text")

    writable_stream.write("\n")

    writable_stream.write("")
    writable_stream.write("text")






# Generated at 2022-06-24 17:26:58.420797
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()

# Generated at 2022-06-24 17:27:01.011275
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(x=5, custom_repr=((int, lambda x: x),)) == 5


# Generated at 2022-06-24 17:27:05.115631
# Unit test for function get_repr_function
def test_get_repr_function():

    # units_included test
    assert get_repr_function(3, custom_repr=((lambda x: x > 2, lambda x: 'bigger'))) == 'bigger'
    assert get_repr_function(2, custom_repr=((lambda x: x > 2, lambda x: 'bigger'))) == repr



# Generated at 2022-06-24 17:27:13.200476
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from pickle import dumps, loads
    # test 0:
    dict_0 = None
    var_0 = get_shortish_repr(dict_0)
    assert var_0 == 'None'
    # test 1:
    dict_1 = dumps
    var_0 = get_shortish_repr(dict_1)
    assert var_0 == '<built-in function dumps>'
    # test 2:
    dict_2 = loads
    var_0 = get_shortish_repr(dict_2)
    assert var_0 == '<built-in function loads>'
    # test 3:
    dict_3 = [1, 2, 3]
    var_0 = get_shortish_repr(dict_3)
    assert var_0 == '[1, 2, 3]'
    # test 4

# Generated at 2022-06-24 17:27:22.208738
# Unit test for function get_repr_function
def test_get_repr_function():
    
    def func_0(var_1) :
        l_0 = (var_1,)
        assert l_0 == (0,)
        return get_repr_function(l_0, [(tuple, id)])

    def func_1(l_1, var_2) :
        assert l_1 == (0.0,)
        assert var_2 == 0.0
        return get_repr_function(var_2, [(tuple, id)])
    
    with pytest.raises(ValueError):
        func_0(0)
    with pytest.raises(AssertionError):
        func_1((0.0,), 0.0)
        
    
    
    
    

# Generated at 2022-06-24 17:27:23.575012
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    test_case_0()

# Generated at 2022-06-24 17:27:33.293298
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import builtins
    from .pycompat import StringIO
    from .pycompat import io
    from .pycompat import StringIO_
    from .pycompat import io_
    from .pycompat import open_
    from .pycompat import open_kwargs
    var_0 = sys.stdout
    var_1 = sys.stdout.buffer
    var_2 = builtins.open('unit_test_WritableStream_write_file.txt', 'w')
    var_3 = io.BytesIO()
    var_4 = StringIO()
    var_5 = StringIO_.StringIO()
    var_6 = io_.StringIO()
    var_7 = open_('unit_test_WritableStream_write_file.txt', 'w', **open_kwargs)
    var

# Generated at 2022-06-24 17:27:36.731014
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Set up local variables
    ws = WritableStream()
    s = ''

    # Call method write of ws
    ws.write(s)



# Generated at 2022-06-24 17:27:41.361032
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None, (int, 'NO!')) == 'NO!'
    assert get_shortish_repr(5, (int, '{0} is an int.')) == '5 is an int.'
    assert get_shortish_repr(5, (float, '{0} is a float.')) == '5'


# Generated at 2022-06-24 17:28:01.968758
# Unit test for function get_repr_function
def test_get_repr_function():
    from . import identities
    from . import args
    from . import tuples

    assert get_repr_function(None, ()) is None.__repr__
    assert get_repr_function(
        None, (
            (lambda x: True, lambda x: 'Lambda function.'),
        )
    )() == 'Lambda function.'

    assert get_repr_function(None, (
        (identities.ObjectIdentity, lambda x: 'Object identity'),
        (args.Kwargs, lambda x: 'Kwargs'),
        (tuples.Subtuple, lambda x: 'Subtuple'),
        (tuples.ReverseTuple, lambda x: 'ReverseTuple'),
        (tuples.SetTuple, lambda x: 'SetTuple'),
    ))() == 'None'



# Generated at 2022-06-24 17:28:11.971547
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    dict_0 = None
    var_0 = get_shortish_repr(dict_0)
    assert var_0 == 'None'
    dict_1 = False
    var_1 = get_shortish_repr(dict_1)
    assert var_1 == 'False'
    dict_2 = True
    var_2 = get_shortish_repr(dict_2)
    assert var_2 == 'True'
    dict_3 = 0
    var_3 = get_shortish_repr(dict_3)
    assert var_3 == '0'
    dict_4 = b''
    var_4 = get_shortish_repr(dict_4)
    assert var_4 == "b''"
    dict_5 = 'xyzzy'
    var_5 = get_shortish_repr

# Generated at 2022-06-24 17:28:14.159980
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    def test_parameters_0():
        pass

        s_0 = None
        test_parameters_0.write(s_0)


# Generated at 2022-06-24 17:28:21.226613
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    l = list()
    WritableStream.register(list)
    assert WritableStream.__subclasshook__(list)
    isinstance(l, WritableStream)
    l.write('abc')
    assert l == ['abc']

if __name__ == '__main__':
    test_case_0()
    test_WritableStream_write()

# Generated at 2022-06-24 17:28:29.289648
# Unit test for function get_repr_function
def test_get_repr_function():
    class O1: pass
    class O2: pass
    class O3: pass
    class O4: pass
    class O5: pass
    custom_repr = ((O1, lambda x: 1), (O2, lambda x: 2))
    assert get_repr_function(O1(), custom_repr)() == '1'
    assert get_repr_function(O2(), custom_repr)() == '2'
    assert get_repr_function(O3(), custom_repr)() == 'REPR FAILED'
    custom_repr = (
        (O2, lambda x: 2),
        (lambda x: isinstance(x, O3), lambda x: 3),
    )

# Generated at 2022-06-24 17:28:30.987505
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # TODO: Implement test.
    pass



# Generated at 2022-06-24 17:28:37.689702
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import subprocess
    from pathlib import Path
    
    def test_1():
        dict_0 = None
        var_0 = get_shortish_repr(dict_0)
        assert var_0 == "None"
        return var_0
        
    def test_2():
        dict_0 = 12
        var_0 = get_shortish_repr(dict_0)
        assert var_0 == "12"
        return var_0
        
    def test_3():
        dict_0 = "12"
        var_0 = get_shortish_repr(dict_0)
        assert var_0 == "12"
        return var_0
        
    def test_4():
        dict_0 = "long string"

# Generated at 2022-06-24 17:28:42.078366
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    print('test_get_shortish_repr... ', end='')
    try:
        test_case_0()
        print('Pass\n')
    except:
        print('Fail\n')

# Generated at 2022-06-24 17:28:50.475007
# Unit test for function get_repr_function
def test_get_repr_function():
    dict_0 = None
    var_0 = get_repr_function(dict_0, None)
    var_1 = get_repr_function(dict_0, ((1, 2), (3, 4)))
    var_2 = get_repr_function(dict_0, ((lambda: True, 2), (3, 4)))
    var_3 = get_repr_function(dict_0, ((dict, 2), (3, 4)))
    dict_1 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    var_4 = get_repr_function(dict_1, None)
    var_5 = get_repr_function(dict_1, ((1, 2), (3, 4)))

# Generated at 2022-06-24 17:28:52.513576
# Unit test for function get_repr_function
def test_get_repr_function():
    #Assert: function get_repr_function()
    assert 1 == 1

# Generated at 2022-06-24 17:29:08.333289
# Unit test for function get_repr_function
def test_get_repr_function():
    dict_0 = None
    var_0 = get_repr_function(dict_0, ())
    dict_1 = {}
    var_1 = get_repr_function(dict_1, ((dict, str),))
    dict_2 = {}
    var_2 = get_repr_function(dict_2, ((set, str),))



# Generated at 2022-06-24 17:29:09.062433
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    pass

    # Tests for public methods

    # Test for private methods



# Generated at 2022-06-24 17:29:10.257851
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    w = WritableStream()
    w.write('text')


# Generated at 2022-06-24 17:29:14.117253
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    dict_0 = None
    var_0 = get_shortish_repr(dict_0)
    input = sys.stdin
    var_1 = WritableStream
    o = var_1.__subclasshook__(input)
    return o

# Generated at 2022-06-24 17:29:23.980550
# Unit test for function get_repr_function
def test_get_repr_function():
    class TestClass(object): pass
    class TestSubClass(TestClass): pass
    test_object = TestSubClass()
    assert get_repr_function(test_object,
                             ((TestClass, lambda x: 'Test'),)) == 'Test'
    assert get_repr_function(test_object,
                             ((TestSubClass, lambda x: 'Test'),)) == 'Test'
    assert get_repr_function(test_object,
                             ((tuple, lambda x: 'Test'),)) == 'Test'
    assert get_repr_function(1, ((tuple, lambda x: 'Test'),)) != 'Test'



# Generated at 2022-06-24 17:29:32.637609
# Unit test for function get_repr_function
def test_get_repr_function():

    var_0 = get_repr_function(1, custom_repr=((bool, str),))
    var_1 = get_repr_function(2, custom_repr=((bool, str),))
    var_2 = get_repr_function(0.1, custom_repr=((bool, str),))
    var_3 = get_repr_function(2.2, custom_repr=((bool, str),))
    var_4 = get_repr_function(True, custom_repr=((bool, str),))
    var_5 = get_repr_function(False, custom_repr=((bool, str),))
    var_6 = get_repr_function('string', custom_repr=((bool, str),))

# Generated at 2022-06-24 17:29:36.405508
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Stream_0(WritableStream):
        def write(self, s):
            return s + ' ' + str(self)
    
    stream = Stream_0()
    assert stream.write('hello') == 'hello ' + str(stream)


if __name__ == '__main__':
    test_case_0()
    assert test_case_0() is None

# Generated at 2022-06-24 17:29:39.777407
# Unit test for function get_repr_function
def test_get_repr_function():
    assert 1 == 1


# Generated at 2022-06-24 17:29:52.237398
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # if we get here, the test has failed
    assert False, 'test not implemented'

if __name__ == '__main__':
    import sys
    import nose
    import nose.tools
    from nose.plugins.skip import SkipTest

    if sys.argv[0].endswith('__main__.py'):
        raise RuntimeError("This code must be run as a module.")

    module_name = sys.modules[__name__].__file__
    if module_name[-4:] in ('.pyc', '.pyo'):
        module_name = module_name[:-1]


# Generated at 2022-06-24 17:29:57.328982
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    dict_0 = None
    var_0 = get_shortish_repr(dict_0)
    assert var_0 == 'None'
    dict_1 = 10
    dict_2 = 'afefeaaf'
    dict_3 = [1, 'd', 'd', 1]
    dict_4 = tuple()
    dict_5 = tuple(dict_3)
    dict_6 = dict()
    dict_7 = dict(a=dict_2, b=dict_3)
    dict_8 = {1: 's', 'e': 2}
    dict_9 = {1: 's', 2: 'e', 3: 'w'}

# Generated at 2022-06-24 17:30:25.490675
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    dict_0 = {'a':1 ,'b':2}
    stream_0=sys.stdout
    var_0 = WritableStream.__subclasshook__(stream_0)
    var_1 = WritableStream.write(stream_0, dict_0)


# Generated at 2022-06-24 17:30:30.344407
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_1 = WritableStream()
    var_1.write('lol')

# Generated at 2022-06-24 17:30:37.748106
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hello', []) == repr
    assert get_repr_function('hello', [(lambda x: True, lambda x: x)]) == 'hello'
    assert get_repr_function('hi', [(lambda x: x == 'hello', lambda x: x)]) == repr
    assert get_repr_function('hello', [(str, lambda x: x)]) == 'hello'
    assert get_repr_function('hello', [(str, lambda x: x), (int, lambda x: x)]) == 'hello'



# Generated at 2022-06-24 17:30:45.793323
# Unit test for function get_repr_function
def test_get_repr_function():
    assert 'normalize_repr' in get_repr_function.__code__.co_varnames
    assert 'custom_repr' in get_repr_function.__code__.co_varnames
    assert 'item' in get_repr_function.__code__.co_varnames
    assert 'r' in get_repr_function.__code__.co_varnames
    assert 'test_case_0' in get_repr_function.__code__.co_varnames
    assert 'dict_0' in get_repr_function.__code__.co_varnames
    assert 'var_0' in get_repr_function.__code__.co_varnames
    assert 'test_get_repr_function' in get_repr_function.__code__

# Generated at 2022-06-24 17:30:49.419585
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    
    #Declare variables
    
    # Initialize variable
    var_0 = isinstance(int, WritableStream)
    var_1 = assertEqual(var_0, False)


# Generated at 2022-06-24 17:30:52.447958
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None) == "None"
    assert get_shortish_repr(object()) == "<object object at 0x...>"


# Generated at 2022-06-24 17:30:56.110798
# Unit test for method write of class WritableStream
def test_WritableStream_write():


    class MyStream(WritableStream):
        def write(self, s):
            pass

    try:
        stream = MyStream()
        assert True
    except Exception as e:
        print(e.args)



# Generated at 2022-06-24 17:31:00.874477
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Arguments initialization
    # Return type initialization
    # Call to write
    write()
    # Check that the return type of the function is None
    assert isinstance(type(write()), NoneType)

    dict_0 = None
    var_0 = get_shortish_repr(dict_0)


# Generated at 2022-06-24 17:31:01.808233
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert False, 'Not implemented.'


# Generated at 2022-06-24 17:31:12.589072
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    dict_0 = None
    var_0 = get_shortish_repr(dict_0)
    assert var_0 == None
    dict_0 = []
    var_0 = get_shortish_repr(dict_0, (), 1)
    assert var_0 == '[]'
    dict_0 = []
    var_0 = get_shortish_repr(dict_0, (), 1, True)
    assert var_0 == '[]'
    dict_0 = {}
    var_0 = get_shortish_repr(dict_0, (), 1)
    assert var_0 == '{}'
    dict_0 = {}
    var_0 = get_shortish_repr(dict_0, (), 1, True)
    assert var_0 == '{}'
