

# Generated at 2022-06-24 17:21:27.272293
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # The following code is taken from `pydoc.HTMLDoc.write`
    s = 'hello'
    open('filename.txt', 'w').write(s)


# Generated at 2022-06-24 17:21:31.137671
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = 'HQla:%y'
    var_0 = get_shortish_repr(str_0)
    assert var_0 == str_0



# Generated at 2022-06-24 17:21:40.028902
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('กขฃคฅฆงจฉช') == '??????'
    assert shitcode('\x00\x01\x02\x03\x04\x05\x06\x07') == '\x00\x01\x02\x03\x04\x05\x06\x07'
    assert shitcode('\x08\t\n\x0b\x0c\r\x0e\x0f') == '\x08\t\n\x0b\x0c\r\x0e\x0f'

# Generated at 2022-06-24 17:21:45.904371
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = 'nU6#<'
    str_1 = 'U2A'
    str_2 = 'w'
    str_3 = '<!aaz'
    str_4 = 'pT'
    str_5 = '![I'
    str_6 = 'W4$8I'
    str_7 = 'L'
    str_8 = 'e%]'
    str_9 = 'Z'
    str_10 = 'P'
    str_11 = 'E'
    str_12 = '5]2'
    str_13 = 'l:07'
    str_14 = '_p'
    str_15 = 'Ic%J'
    str_16 = '`'
    str_17 = 'S>'
    str_18 = 's_<'


# Generated at 2022-06-24 17:21:52.475219
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('á') == '?'
    assert shitcode('aáb') == 'a?b'
    assert shitcode(u'\u001f\u00a0') == '??'


# Generated at 2022-06-24 17:22:04.094482
# Unit test for function get_repr_function
def test_get_repr_function():
    var_0 = get_repr_function(['a', 'b'], custom_repr=((list, str),))
    var_1 = var_0 == repr
    var_0 = get_repr_function(['a', 'b'], custom_repr=((list, str), (tuple, str)))
    var_2 = var_0 == str
    var_0 = get_repr_function('hi', custom_repr=())
    var_3 = var_0 == repr
    var_0 = get_repr_function('hi', custom_repr=((list, str),))
    var_4 = var_0 == repr
    var_0 = get_repr_function('hi', custom_repr=((str, str),))
    var_5 = var_0 == str
    var_0

# Generated at 2022-06-24 17:22:10.329734
# Unit test for function get_repr_function
def test_get_repr_function():
    assert callable(get_repr_function), "Expected a callable!"
    assert get_repr_function(0) == repr, "Expected %s, got %s!" % (repr, get_repr_function(0))


# Generated at 2022-06-24 17:22:14.212298
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    print("Unit test for method write of class WritableStream")
    var_0 = sys.stdout
    print("Testing if it succeeds in the case of a Stream.")
    test_case_0()


# Generated at 2022-06-24 17:22:16.265091
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream_0 = sys.stdout
    stream_0.write('Example wrote this')

# Generated at 2022-06-24 17:22:21.903235
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((lambda x: x > 0, lambda x: 'too big'))) == repr

# Generated at 2022-06-24 17:22:26.711009
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    assert(WritableStream.__subclasshook__(stream) is True)
    stream.write(str_0)
    #assert (str == str_0)


test_WritableStream_write()
#test()

# Generated at 2022-06-24 17:22:28.245309
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    w = WritableStream()
    w.write(str_0)  # should not crash


# Generated at 2022-06-24 17:22:32.858800
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert hasattr(test_case_0, '__wrapped__')
    assert isinstance(test_case_0.__wrapped__, WritableStream)
    assert hasattr(test_case_0.__wrapped__, 'write')
    assert callable(test_case_0.__wrapped__.write)




# Generated at 2022-06-24 17:22:39.646487
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [
        (lambda x: isinstance(x, int), lambda x: '<int {}>'.format(x)),
        (lambda x: isinstance(x, str), lambda x: '<str {}>'.format(x)),
        (lambda x: isinstance(x, list), lambda x: '<list {}>'.format(x)),
    ]
    assert get_repr_function(1, custom_repr) == str
    assert get_repr_function(3, custom_repr) == str
    assert get_repr_function('c', custom_repr) == str
    assert get_repr_function([], custom_repr) == str
    assert get_repr_function(set(), custom_repr) == repr
    assert get_repr_function(object(), custom_repr)

# Generated at 2022-06-24 17:22:47.333406
# Unit test for method write of class WritableStream

# Generated at 2022-06-24 17:22:52.056892
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    print('Method write of class WritableStream')
    class MockWritableStream(WritableStream):
        def write(self, s): pass
    writable_stream_0 = MockWritableStream()
    assert (isinstance(writable_stream_0,
                       WritableStream))


# Generated at 2022-06-24 17:22:55.208801
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    # Test 1:
    #  make sure writes are appended to the output buffer
    #
    sys.stdout.write(str_0)



# Generated at 2022-06-24 17:23:01.271827
# Unit test for function get_repr_function
def test_get_repr_function():

    def func_0():
        return get_repr_function(str_0, ((str, repr),))

    def func_1():
        return get_repr_function(str_0, ((int, repr),))

    def func_2():
        return get_repr_function(str_0, ((str, type),))

    def func_3():
        return get_repr_function(str_0, ((int, type),))


    func_0() # OSError: [Errno 2] No such file or directory: 'Example wrote this'
    func_1() # OSError: [Errno 2] No such file or directory: 'Example wrote this'
    func_2() # TypeError: type() takes 1 or 3 arguments
    func_3() # TypeError: type() takes 1 or 3

# Generated at 2022-06-24 17:23:08.533039
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(test_case_0) == (
        '<function test_case_0 at 0x{:x}>'.format(id(test_case_0))
    )
    assert get_shortish_repr(test_case_0, max_length=30) == (
        '<function test_case_0 at ...>'
    )
    assert get_shortish_repr(test_case_0, max_length=30, normalize=True) == (
        '<function test_case_0 ...>'
    )
    assert get_shortish_repr(test_case_0, custom_repr=((str_0, str),)) == (
        'Example wrote this'
    )
    assert get_shortish_repr('Hello') == "'Hello'"
   

# Generated at 2022-06-24 17:23:19.502405
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # str_0 is a str
    str_0 = 'Example wrote this'
    # test_case_1 is True
    test_case_1 = (get_shortish_repr(str_0, [], 41) == 'Example wrote this')
    # test_case_2 is True
    test_case_2 = (get_shortish_repr(str_0, [], 40) == 'Example wrote thi...')
    # test_case_3 is True
    test_case_3 = (get_shortish_repr(str_0, [], 1) == 'E...')
    # test_case_4 is True
    test_case_4 = (get_shortish_repr(str_0, [], 0) == '')
    # test_case_5 is True

# Generated at 2022-06-24 17:23:27.952258
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """Unit test for method write of class WritableStream"""

    str_0 = 'ABCDEF'
    str_1 = ''
    str_2 = 'B'
    str_3 = 'A'
    str_4 = 'D'
    int_0 = 10
    int_1 = 0
    int_2 = -1
    obj_0 = object()
    obj_1 = obj_0
    int_3 = 0
    int_4 = None
    int_5 = len(str_0)
    for i in range(0, int_5):
        str_1 = str(str_1) + str(str_0[i])
    str_2 = str(str_1)
    int_6 = 0
    int_7 = len(str_2)

# Generated at 2022-06-24 17:23:30.299001
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    Stream = WritableStream
    x = Stream()
    x.write(str_0)


# Generated at 2022-06-24 17:23:40.454175
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(test_case_0) == '<function test_case_0 at 0x%x>' % id(test_case_0)
    assert get_shortish_repr(test_case_0, max_length=15) == '<function test_case_0 at 0x%x>' % id(test_case_0)
    assert get_shortish_repr(test_case_0, max_length=10) == '<functio...0x%x>' % id(test_case_0)
    assert get_shortish_repr(test_case_0, max_length=9) == '<funct...0x%x>' % id(test_case_0)

# Generated at 2022-06-24 17:23:44.926788
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # tests.utils.test_io.test_io_base.test_case_0
    stream = StringIO() # type: WritableStream
    assert stream.write(str_0).__class__ is int
    assert stream.getvalue() == str_0

# Generated at 2022-06-24 17:23:53.979871
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(bool, lambda _: 'Boolean')]) == repr
    assert get_repr_function(False, [(bool, lambda _: 'Boolean')]) == 'Boolean'
    assert get_repr_function('str', [(str, lambda _: 'String')]) == 'String'
    assert get_repr_function('str', [(str, lambda _: 'String'),
                                     (list, lambda _: 'List')]) == 'String'
    assert get_repr_function([], [(str, lambda _: 'String'),
                                  (list, lambda _: 'List')]) == 'List'

# Generated at 2022-06-24 17:24:04.001958
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr('hello', max_length=5) == 'hello'
    assert get_shortish_repr('hello', max_length=4) == 'h...'
    assert get_shortish_repr((1,2,3), max_length=5) == '(1, 2, 3)'
    assert get_shortish_repr((1,2,3,4), max_length=5) == '(1, ..., 4)'
    assert get_shortish_repr((1,2,3,4), max_length=5, normalize=True) == \
                                                          '(1, ..., 4)'


# Generated at 2022-06-24 17:24:14.683244
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(5) == '5'

# Generated at 2022-06-24 17:24:22.673419
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Case 0
    item = str_0
    r = get_shortish_repr(item)
    assert r == "'Example wrote this'"

    # Case 1
    item = str_0
    custom_repr = ((str, lambda x: x.swapcase()),)
    r = get_shortish_repr(item, custom_repr=custom_repr)
    assert r == 'EXAMPLE WROTE THIS'

    # Case 2
    item = str_0
    max_length = 20
    r = get_shortish_repr(item, max_length=max_length)
    assert r == "'Example wrote..."

    # Case 3
    item = str_0
    normalize = True
    r = get_shortish_repr(item, normalize=normalize)

# Generated at 2022-06-24 17:24:33.650743
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(test_case_0,
                             custom_repr=((lambda x: True,
                                           lambda x: "Example wrote this"),),
                             max_length=None) == 'Example wrote this'
    assert get_shortish_repr(test_case_0,
                             custom_repr=((lambda x: False,
                                           lambda x: "Example wrote this"),),
                             max_length=None) == \
                                                   '<function test_case_0 at 0x7f3fbf6b8ea0>'

# Generated at 2022-06-24 17:24:35.920388
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    s = test_case_0()
    out = WritableStream()
    out.write(s)



# Generated at 2022-06-24 17:24:41.518039
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Test for equality
    r = get_shortish_repr(str_0, max_length=13)
    assert r == 'Example wrote...'


# Generated at 2022-06-24 17:24:55.171306
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .mirror import Mirror as Obj

    # Make sure the repr is short
    r = get_shortish_repr(Obj(test_case_0), max_length=100)
    assert r == "Example wrote this"

    # Make sure the repr is truncated if it's too long
    r = get_shortish_repr(Obj(test_case_0), max_length=20)
    assert r == "Example wrot..."

    # Make sure the repr is truncated if it's too long
    r = get_shortish_repr(Obj(test_case_0), max_length=10)
    assert r == "Ex..."

    # Make sure the repr is not truncated if it's not too long
    r = get_shortish_repr(Obj(test_case_0), max_length=50)
   

# Generated at 2022-06-24 17:25:01.242468
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stringIO = None
    with open("tests/test_temp_file", "w") as file:
        writableStream = file
        writableStream.write(str_0)
        assert file.read() == str_0, "Failed test_WritableStream_write"
        stringIO = file.getvalue()
    assert stringIO == str_0, "Failed test_WritableStream_write"

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 17:25:03.394176
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    # Test for simple classes
    assert get_shortish_repr(str_0) == "'Example wrote this'"



# Generated at 2022-06-24 17:25:11.656199
# Unit test for function get_repr_function
def test_get_repr_function():
    """
    get_repr_function
    ~~~~~~~~~~~~~~~~~

    Verify that get_repr_function returns a function when passed
    a function that returns True
    """
    custom_repr = ((lambda x: True, lambda x: ''),)
    func = get_repr_function('', custom_repr)
    assert callable(func)
    assert isinstance(func, collections_abc.Callable)



# Generated at 2022-06-24 17:25:19.357164
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class CustomClass(object):
        pass
    custom_instance = CustomClass()
    custom_instance.toto = "toto"
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=50) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr('hello', max_length=None) == "'hello'"
    assert get_shortish_repr('hello', max_length=1) == "'h'"
    assert get_shortish_

# Generated at 2022-06-24 17:25:23.113556
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(test_case_0,
                             (lambda x: (lambda y: y.__name__ == 'test_case_0')(x),
                              lambda y: 'function repr')) == 'function repr'



# Generated at 2022-06-24 17:25:27.523296
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    example_stream = WritableStream()
    for i in range(1, 10):
        print(i, end='')
    example_stream.write(str_0)
    assert example_stream.write(str_0) == 39



# Generated at 2022-06-24 17:25:34.911555
# Unit test for function get_repr_function
def test_get_repr_function():
    expected_result = test_case_0()
    actual_result = get_repr_function(test_case_0)
    try:
        assert actual_result == expected_result
    except AssertionError:
        print('test get_repr_function() failed\n'
              'expected_result: {}\n'
              'actual_result  : {} (type:{})\n'.format(
                 expected_result, actual_result, type(actual_result)
              )
        )


# Generated at 2022-06-24 17:25:41.262075
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = 'Example wrote this'
    str_1 = 'Example wrote that'
    assert get_shortish_repr(str_0) == 'Example wrote this'
    assert get_shortish_repr(str_0, max_length=8) == 'Example'
    assert get_shortish_repr(str_1, max_length=8) == 'Example'
    assert get_shortish_repr(str_0, max_length=16) == 'Example wrote this'
    assert get_shortish_repr(str_0, max_length=17) == 'Example wrote this'
    assert get_shortish_repr(str_0, max_length=18) == 'Example wrote this'

# Generated at 2022-06-24 17:25:51.585430
# Unit test for function get_repr_function
def test_get_repr_function():
    type_list = [int, str, bool, list, tuple]
    custom_repr = [(lambda x: x, lambda x: 'IT WORKS!')]
    for item in [10, 'word', True, [1, 2, 3], (1, 2, 3)]:
        assert get_repr_function(item, custom_repr) == repr
        if type(item) in type_list:
            assert get_repr_function(item, []) == repr

# Generated at 2022-06-24 17:25:59.539888
# Unit test for function get_repr_function
def test_get_repr_function():
    print('get_repr_function')
    custom_repr = []
    item = 'e2784'
    assert get_repr_function(item, custom_repr) == repr
    custom_repr.append((lambda x: x == item, str))
    assert get_repr_function(item, custom_repr) == str
    custom_repr.append((lambda x: x != item, lambda x: 'feb7'))
    assert get_repr_function(item, custom_repr) == str
    custom_repr.append(('', lambda x: 'd2f1'))
    assert get_repr_function(item, custom_repr) == str
    custom_repr.append((lambda x: x != item, str_0))

# Generated at 2022-06-24 17:26:04.006987
# Unit test for function get_repr_function
def test_get_repr_function():
    str_0 = 'Example wrote this'

    def func_0(str_0):
        return str_0

    custom_repr_0 = ((str, func_0),)
    item_0 = str_0
    assert get_repr_function(item_0, custom_repr_0) == func_0


# Generated at 2022-06-24 17:26:09.002436
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function((1, 2), ((lambda x: True, str),)) is str
    assert get_repr_function((1, 2), ((lambda x: isinstance(x, tuple), repr),)) \
                                                                        is repr



# Generated at 2022-06-24 17:26:13.887400
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test for method write of class WritableStream
    buf = the_buffer = []
    class Writeable:
        def write(self, s):
            buf.append(s)
    w = Writeable()

    w.write(b"hello ")
    w.write(b"world")
    assert buf == [b"hello ", b"world"]

    buf = []
    w.write(u"hello world")
    assert buf == [b"hello ", b"world"]
    buf = []
    w.write(str_0)
    assert buf == [b"hello ", b"world"]

# Generated at 2022-06-24 17:26:19.160860
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(str_0, 'str') == repr(str_0)
    assert get_shortish_repr(str_0, 'str') == repr(str_0)


# Generated at 2022-06-24 17:26:20.821131
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Testing for write()
    w = WritableStream()
    w.write(str_0)

# Generated at 2022-06-24 17:26:27.625041
# Unit test for function get_repr_function
def test_get_repr_function():

    class Example(type):
        def __repr__(self):
            return 'Example wrote this'

    class ReallyExample(Example):
        pass

    assert issubclass(ReallyExample, Example) is True

    class FakeExample:
        pass

    assert issubclass(FakeExample, Example) is False

    custom_repr = ((Example, str_0), )

    assert get_repr_function(ReallyExample, custom_repr) == str_0
    assert get_repr_function(Example, custom_repr) == str_0
    assert get_repr_function(FakeExample, custom_repr) != str_0

# Generated at 2022-06-24 17:26:37.875123
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(test_case_0, max_length=None, normalize=False) == "function test_case_0 at 0x7ff715bce048"
    assert get_shortish_repr(test_case_0, max_length=0, normalize=False) == ""
    assert get_shortish_repr(test_case_0, max_length=16, normalize=False) == "function tes..."
    assert get_shortish_repr(test_case_0, max_length=17, normalize=False) == "function test..."
    assert get_shortish_repr(test_case_0, max_length=18, normalize=False) == "function test_..."

# Generated at 2022-06-24 17:26:44.268882
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test that `WritableStream.write` is rejecting invalid inputs
    _args = (((True,), False),)
    for item in _args:
        try:
            WritableStream.write(str_0, *item[0])
        except Exception as e:
            assert item[1]
        else:
            assert not item[1]
    # Test that `WritableStream.write` is rejecting invalid inputs
    _args = (((int,), False),)
    for item in _args:
        try:
            instance_0 = WritableStream()
            instance_0.write(*item[0])
        except Exception as e:
            assert item[1]
        else:
            assert not item[1]
    # Test that `WritableStream.write` is rejecting invalid inputs

# Generated at 2022-06-24 17:26:52.467025
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    if isinstance(sys.stdout, WritableStream):
        sys.stdout.write(str_0)
# Test successful



# Generated at 2022-06-24 17:27:01.015116
# Unit test for function get_repr_function
def test_get_repr_function():
    # Test the line that writes to a string
    #from .abc import Attribute, Class, Function
    try:
        shitcode(str_0)
    except:
        assert False
    finally:
        assert True
    # Test the line
    assert get_repr_function('', (
        (lambda x: isinstance(x, str), lambda s: s),
        (lambda x: isinstance(x, int), lambda i: 'int({})'.format(i)),
        (lambda x: isinstance(x, float), lambda f: 'float({})'.format(f)),
    )) == shitcode

# Generated at 2022-06-24 17:27:04.077617
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test whether a WritableStream subclass can be casted as a WritableStream
    # without failing
    repr_function = get_repr_function(str_0, ())
    repr_function(str_0)
    assert True


# Generated at 2022-06-24 17:27:07.668813
# Unit test for function get_repr_function
def test_get_repr_function():
    # These lines are used to test the function.
    custom_repr = [(lambda item: str(type(item)) == "<class 'str'>", str)]
    assert get_repr_function('string', custom_repr) == str
    assert get_repr_function(123, custom_repr) == repr


# Generated at 2022-06-24 17:27:19.727602
# Unit test for function get_repr_function

# Generated at 2022-06-24 17:27:25.841518
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test that calling `write` on a class that doesn't implement it raises an
    # exception.
    class C:
        'A class that doesn\'t implement `write`'
        pass
    c = C()
    with pytest.raises(TypeError):
        c.write(str_0)


# Generated at 2022-06-24 17:27:33.115171
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (
        (lambda x: x == 1, lambda x: 'one'),
        (lambda x: x == 2, lambda x: 'two'),
    )) == 'one'
    assert get_repr_function(2, (
        (lambda x: x == 1, lambda x: 'one'),
        (lambda x: x == 2, lambda x: 'two'),
    )) == 'two'
    assert get_repr_function(3, (
        (lambda x: x == 1, lambda x: 'one'),
        (lambda x: x == 2, lambda x: 'two'),
    )) == repr



# Generated at 2022-06-24 17:27:40.824072
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """
    Ensure that the write method of the WritableStream class is working as
    expected.

    The write method of the WritableStream class should write the string
    passed to it to the screen.
    """
    class Test():
        def __init__(self):
            pass
        def write(self, s):
            str_0 = s
            return str_0
    test_object = Test()
    str_0 = test_object.write('Example wrote this')
    assert str_0 == 'Example wrote this'


# Generated at 2022-06-24 17:27:43.747022
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Initializing variables
    ws = sys.stdout
    s = str_0
    r = None

    # Testing method write of class WritableStream
    r = ws.write(s)
    assert r is None

# Generated at 2022-06-24 17:27:48.018902
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    # WritableStream.write is abstract
    test_inputs = (
        (sys.stdout, str_0),
    )
    test_method = 'write'

    for target, args in test_inputs:
        result = target.write(*args)
        assert result is None # TODO: actually test something

# Generated at 2022-06-24 17:27:57.226183
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(test_case_0, max_length=30) == "builtins.function test_case_0"

# Generated at 2022-06-24 17:27:58.635689
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(str_0, []) == repr


# Generated at 2022-06-24 17:28:01.265112
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    str_0 = sys.stdout
    str_0.write('Example wrote this')



# Generated at 2022-06-24 17:28:02.403759
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # See comment before the method definition
    pass

# Generated at 2022-06-24 17:28:06.141125
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    W = WritableStream()
    try:
        W.write(str_0)
    except Exception as e:
        e_type = type(e)
        raise AssertionError(
            'Failed to write to WritableStream. '
            'The exception type was {}. The exception was {!r}.'.format(
                e_type.__name__,
                e,
            )
        )
    else:
        assert True



# Generated at 2022-06-24 17:28:08.411209
# Unit test for function get_repr_function
def test_get_repr_function():
    r = get_repr_function('str_0', (('str_0', 'str_1'),))
    expected = 'str_1'
    assert r == expected


# Generated at 2022-06-24 17:28:12.407308
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class StringIO(WritableStream):
        def write(self, s):
            return str_0.join(s)

if __name__ == "__main__":
    import python_toolbox
    python_toolbox.nice_2_to_3.nice_2_to_3(__file__)

# Generated at 2022-06-24 17:28:16.209094
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    input_str_0 = str_0
    max_length = 11
    output_str_0 = 'Example...te this'
    assert get_shortish_repr(input_str_0, max_length=max_length) == \
                                                              output_str_0

test_get_shortish_repr()






# Generated at 2022-06-24 17:28:25.701890
# Unit test for function get_repr_function
def test_get_repr_function():
    """Note that this unittest is very fragile and may fail in different
    environments. For example, when being run in a certain version of IronPython,
    it fails."""
    repr_func = get_repr_function('string',
                                  custom_repr=((str, str),))
    assert repr_func('string') == 'string'

    custom_repr = ((str, str),)
    assert get_repr_function('string', custom_repr) == str
    assert get_repr_function(u'unicode', custom_repr) == repr
    assert get_repr_function(b'bytes', custom_repr) == repr
    assert get_repr_function(bytearray(b'bytearray'), custom_repr) == repr

# Generated at 2022-06-24 17:28:36.303493
# Unit test for function get_repr_function
def test_get_repr_function():
    original_repr_0 = repr(
        get_repr_function(set(), (
            (1, lambda: 'Test')
        ))
    )
    repr_0 = repr(
        get_repr_function(set(), (
            (1, lambda: 'Test')
        ))
    )
    expected_repr_0 = normalize_repr("<function <lambda> at 0x%x>" % id(
        get_repr_function(set(), (
            (1, lambda: 'Test')
        )).__code__
    ))
    # Check if got expected result.
    if expected_repr_0 == original_repr_0:
        assert repr_0 == expected_repr_0
    else:
        print("Got: " + repr_0)

# Generated at 2022-06-24 17:28:42.271909
# Unit test for function get_repr_function
def test_get_repr_function():
    from .test_tools import assert_equal
    test_get_repr_function_0()
    test_case_0()


# Generated at 2022-06-24 17:28:42.964242
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass



# Generated at 2022-06-24 17:28:55.988793
# Unit test for function get_repr_function

# Generated at 2022-06-24 17:28:57.102180
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr



# Generated at 2022-06-24 17:29:00.924497
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    try:
        stream_0 = sys.stdout
        str_0 = 'a'
        stream_0.write(str_0)
    except Exception as e:
        raise e


# Generated at 2022-06-24 17:29:03.306395
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    int_0 = None
    var_0 = WritableStream.write(int_0)


# Generated at 2022-06-24 17:29:08.802440
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import PY3
    from .pycompat import StringIO
    sio = StringIO()
    ws = WritableStream()
    ws.write = sio.write
    ws.write('hello')
    ws.write(' ')
    ws.write('world!')
    assert sio.getvalue() == 'hello world!'

# Generated at 2022-06-24 17:29:15.285895
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(()) == '()'
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr(False) == 'False'
    assert get_shortish_repr(sys.maxint) == str(sys.maxint)
    assert get_shortish_repr('bla') == 'bla'
    assert get_shortish_repr(type(None)) == "<type 'NoneType'>"
    assert get_shortish_repr(object()) == '<object object at 0x%s>' % (
        id(object()) % 0x10000
    )


# Generated at 2022-06-24 17:29:23.050701
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    for (a, b) in ((0, 100), (100, 100), (100, 20), (20, 100), (100, 0),
                   (0, 0)):
        assert len(get_shortish_repr(range(a), max_length=b)) < b + 3
    assert get_shortish_repr(range(100), max_length=0) == '...'
    assert get_shortish_repr(range(100), max_length=None) == repr(range(100))


# Generated at 2022-06-24 17:29:33.951916
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello world') == "'hello world'"
    assert get_shortish_repr(12, normalize=True) == '12'
    assert get_shortish_repr(12, normalize=True,
                             max_length=30) == '12'
    assert get_shortish_repr(12, max_length=3) == '12'
    assert get_shortish_repr(12, max_length=1) == '1'
    assert get_shortish_repr((1, 2), max_length=7) == '(1, 2)'
    assert get_shortish_repr((1, 2), max_length=6) == '(1, ...'
    assert get_shortish_repr({1, 2}, max_length=6) == '{1, ...'

# Generated at 2022-06-24 17:29:51.997580
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('abc', ()).__name__ == 'repr'

    class A(object):
        pass

    assert get_repr_function(A(), ()).__name__ == 'repr'
    assert get_repr_function(A(),
                             [(lambda x: True,
                               lambda x: x.__class__.__name__)]).__name__ == \
                                                                 'function'
    assert get_repr_function(A(),
                             [(lambda x: False,
                               lambda x: x.__class__.__name__)]).__name__ == \
                                                                   'repr'

# Generated at 2022-06-24 17:29:53.352757
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert 1 == get_shortish_repr



# Generated at 2022-06-24 17:29:56.123411
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(object(), ()) is repr
    assert get_repr_function('hello', [(str, str)]) is str


# Generated at 2022-06-24 17:29:58.062041
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    var_0 = get_shortish_repr(type('a', (), {'__repr__': lambda x: 1 / 0}))
    var_1 = get_shortish_repr(int)
    assert var_1 == 'int'

# Generated at 2022-06-24 17:30:03.960242
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [(lambda x: x == 0,
                    lambda x: 'hello'),
                   (lambda x: x == 1,
                    lambda x: 'world')]

# Generated at 2022-06-24 17:30:14.327910
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    t.assertEqual(get_shortish_repr(int_0), 'None')
    t.assertEqual(get_shortish_repr(var_0), 'None')
    t.assertEqual(get_shortish_repr(int_0, max_length=1), 'None')
    t.assertEqual(get_shortish_repr(var_0, max_length=1), 'None')
    t.assertEqual(get_shortish_repr(int_0, max_length=2), 'None')
    t.assertEqual(get_shortish_repr(var_0, max_length=2), 'None')
    t.assertEqual(get_shortish_repr(int_0, max_length=3), 'None')

# Generated at 2022-06-24 17:30:15.698421
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass # Nothing to test


# Generated at 2022-06-24 17:30:17.980121
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    int_0 = None
    var_0 = WritableStream.write(int_0)


# Generated at 2022-06-24 17:30:27.841114
# Unit test for function get_repr_function
def test_get_repr_function():
    # Test that the function get_repr_function returns the right value when
    # given the right type of arguments.
    assert get_repr_function(0, None) == repr
    assert get_repr_function([], None) == repr
    assert get_repr_function({}, None) == repr
    assert get_repr_function(0, [(lambda x: True, str)]) == str
    assert get_repr_function([], [(lambda x: True, str)]) == str
    assert get_repr_function({}, [(lambda x: True, str)]) == str
    assert get_repr_function(0, [(list, str)]) == repr
    assert get_repr_function([], [(list, str)]) == str
    assert get_repr_function({}, [(list, str)]) == repr


# Generated at 2022-06-24 17:30:37.686555
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Test_WritableStream_write(WritableStream):
        def __init__(self):
            self.integer_0 = None
        def write(self, string_0):
            var_0 = shitcode(string_0)
            int_0 = self.integer_0
            self.integer_0 = (int_0 + len(var_0))

    test_WritableStream_write = Test_WritableStream_write()
    string_0 = ''
    test_WritableStream_write.write(string_0)


# Generated at 2022-06-24 17:30:46.680618
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import doctest
    doctest.testfile('README.md')

# Generated at 2022-06-24 17:30:49.824713
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    file = open("test.txt", "w")
    file.write("First line.")
    file.write("Second line.")
    file.close()



# Generated at 2022-06-24 17:30:58.469204
# Unit test for function get_repr_function
def test_get_repr_function():
    from inspect import getargspec
    from types import FunctionType
    from .test_tools.test_runner import test_callers
    from .test_tools.test_runner import assert_
    from .test_tools.test_runner import assert_equal

    def f_1(item, custom_repr):
        return len(getargspec(get_repr_function(item, custom_repr)).args)

    def f_2(item, custom_repr):
        return get_repr_function(item, custom_repr)

    def f_3(item, custom_repr):
        return get_repr_function(item, custom_repr)()


# Generated at 2022-06-24 17:31:02.729532
# Unit test for function get_repr_function
def test_get_repr_function():
    from .example_code import shitcode
    repr_function = get_repr_function(None, [
        (lambda item: item is None, lambda item: 'None'),
        (lambda item: isinstance(item, string_types), shitcode)
    ])
    expected = shitcode
    assert repr_function == expected




# Generated at 2022-06-24 17:31:13.389833
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert normalize_repr('(NoneType) None') == '(NoneType) None'
    assert normalize_repr('(NoneType) None at 0xFEEBFEEB') == \
                                                       '(NoneType) None'
    assert normalize_repr('(NoneType) None at 0xFEEBFEEB') == \
                                                       '(NoneType) None'
    assert truncate(u'1234567890', 8) == u'12345...'
    assert truncate(u'1234567890', 10) == u'1234567890'
    assert truncate(u'1234567890', 18) == u'1234567890'
    assert get_shortish_repr(None) == 'None'

    assert get_shortish_repr(None, max_length=8) == 'None'