

# Generated at 2022-06-24 17:21:32.284849
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write(u':)')
    assert True  #pragma: no cover ; may be changed to a failure test case

if __name__ == '__main__':
    from . import pyperclip # pragma: no cover
    pyperclip.copy('')
    test_case_0()
    test_WritableStream_write()

# Generated at 2022-06-24 17:21:42.656143
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr_0 = (
        (lambda x: True, 
         lambda x: 'haha'),
    )
    item_0 = 'foo'

    assert get_repr_function(item_0, custom_repr_0) == (lambda x: 'haha')

    custom_repr_1 = (
        (lambda x: False, 
         lambda x: 'haha'),
    )
    item_1 = 'foo'

    assert get_repr_function(item_1, custom_repr_1) == repr

    custom_repr_2 = ((int, lambda x: 'haha'),)
    item_2 = 1

    assert get_repr_function(item_2, custom_repr_2) == (lambda x: 'haha')




# Generated at 2022-06-24 17:21:46.727138
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'asd') == u'asd'
    assert shitcode(u'\u2713') == u'?'
    assert shitcode(u'\uD834\uDD1E') == u'??'
    assert shitcode(u'\U0001f4a9') == u'?'


# Generated at 2022-06-24 17:21:53.798499
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .explanations import default_explanation_registry \
                                                      as explanation_registry
    item = explanation_registry._ExplainerRegistry.__call__
    repr_function = get_repr_function(item, ())
    assert repr_function is repr
    assert repr_function(item) == repr(item)

# Generated at 2022-06-24 17:21:56.858932
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    with pytest.raises(AttributeError):
        writable_stream_0.write()


# Generated at 2022-06-24 17:22:04.497378
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('foo', []) == repr

# Generated at 2022-06-24 17:22:10.579224
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(4, ((lambda x: x % 2 == 0,
                                  lambda x: 'Even'),)) == str
    assert get_repr_function(5, ((lambda x: x % 2 == 0,
                                  lambda x: 'Even'),)) == repr


# Generated at 2022-06-24 17:22:18.761337
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    try:
        writable_stream_0.write()
        assert False
    except TypeError:
        pass
    try:
        writable_stream_0.write(1, 2)
        assert False
    except TypeError:
        pass
    try:
        writable_stream_0.write(1)
        assert False
    except NotImplementedError:
        pass

# Generated at 2022-06-24 17:22:28.407496
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Use custom repr for some types
    assert get_shortish_repr([1, 2, 3], custom_repr=((type([]), lambda x: None),)) is None
    # Check fallback to default repr
    assert get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    # Check truncation
    assert get_shortish_repr([1, 2, 3, 4, 5], max_length=6) == '[1, 2, ...]'
    # Check that truncation doesn't go over the edge
    assert get_shortish_repr([1, 2, 3], max_length=6) == '[1, 2, ...]'
    assert get_shortish_repr([1, 2, 3], max_length=10) == '[1, 2, 3]'



# Generated at 2022-06-24 17:22:30.963683
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, ((lambda x: True, lambda x: None),))() == \
                                                                       'None'



# Generated at 2022-06-24 17:22:43.995060
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([1, 2, 3, 4, 5], max_length=15) == '[1, 2, ...]'
    assert get_shortish_repr([1, 2, 3, 4, 5], max_length=15, normalize=True) == '[1, 2, ...]'
    assert get_shortish_repr([1, 2, 3, 4, 5], max_length=16) == '[1, 2, 3, ...]'
    assert get_shortish_repr([1, 2, 3, 4, 5], max_length=16, normalize=True) == '[1, 2, 3, ...]'
    assert get_shortish_repr([1, 2, 3, 4, 5], max_length=17) == '[1, 2, 3, ...]'
    assert get_shortish_re

# Generated at 2022-06-24 17:22:55.625736
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr(u'abc') == "u'abc'"
    assert get_shortish_repr(b'abc') == "b'abc'"
    assert get_shortish_repr(123) == '123'
    assert get_shortish_repr(3.14) == '3.14'
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr('abc', max_length=3) == "'ab'"
    assert get_shortish_repr('abc', max_length=2) == "'a'"
    assert get_shortish_repr('abc', max_length=1) == "'a'"

# Generated at 2022-06-24 17:23:01.428040
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # First round
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(0) == '0'
    assert get_shortish_repr(0.0) == '0.0'
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr(False) == 'False'
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr(u'hello') == "u'hello'"
    assert get_shortish_repr(b'hello') == "b'hello'"
    assert get_shortish_repr(shitcode(b'hello')) == "'hello'"

# Generated at 2022-06-24 17:23:12.054192
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    str_0 = str()
    try:
        writable_stream_0.write(str_0)
        assert False, 'This should have raised a TypeError'
    except TypeError:
        assert True
    class DerivedWritableStream(WritableStream): pass
    derived_writable_stream_0 = DerivedWritableStream()
    derived_writable_stream_1 = DerivedWritableStream()
    str_0 = str()
    assert derived_writable_stream_0.write(str_0) is None
    assert derived_writable_stream_1.write(str_0) is None



# Generated at 2022-06-24 17:23:15.822806
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    global writable_stream_0
    writable_stream_0 = WritableStream()
    assert isinstance(writable_stream_0.write, collections_abc.Callable)


test_case_0()
test_WritableStream_write()

# Generated at 2022-06-24 17:23:20.290144
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # This is a basic example of how to use the class
    writable_stream_0 = WritableStream()
    writable_stream_0.write('0.0')

    # Try to print the object
    writable_stream_0.__str__()



# Generated at 2022-06-24 17:23:24.459620
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('')

    # Attempts to call the abstract method.
    try:
        WritableStream.write('')
    except TypeError:
        pass


# Generated at 2022-06-24 17:23:32.766392
# Unit test for function shitcode
def test_shitcode():
    # from .pycompat import IS_PY2
    # if IS_PY2:
    #     assert shitcode(u'abc') == u'abc'
    #     assert shitcode(u'בית') == u'???'
    assert shitcode(b'abc') == 'abc'
    assert shitcode(b'\xe1\x84\x8b') == '???'



# Generated at 2022-06-24 17:23:37.505010
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    s = ""
    try:
        writable_stream_0.write(s)
        assert False
    except NotImplementedError:
        pass
    writable_stream_1 = sys.__stdout__
    writable_stream_1.write(s)


# Generated at 2022-06-24 17:23:43.520604
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    def bad_repr(x):
        raise ValueError

    assert (get_shortish_repr('abc', max_length=5) == 'abc')
    assert (get_shortish_repr('abcdef', max_length=5) == 'a...f')
    assert (get_shortish_repr('abcdef', max_length=6) == 'abcdef')
    assert (get_shortish_repr('abcdef', max_length=7) == 'abcdef')
    assert (get_shortish_repr('abcdef', max_length=None) == 'abcdef')


# Generated at 2022-06-24 17:23:59.207270
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'') == u''
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'abc\0\1\2\3\4') == u'abc?????'


# Generated at 2022-06-24 17:24:09.355582
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello', max_length=3) == '...'
    assert get_shortish_repr('hello', max_length=5) == 'hel...'
    assert get_shortish_repr('hello', max_length=None) == 'hello'
    assert get_shortish_repr('hello', max_length=6) == 'hello'
    assert get_shortish_repr('hello', max_length=7) == 'hello'
    assert get_shortish_repr('hello', max_length=8) == 'hello'
    assert get_shortish_repr('hello', max_length=0) == '...'
    assert get_shortish_repr('', max_length=0) == ''
    assert get_shortish_repr('', max_length=1)

# Generated at 2022-06-24 17:24:19.309766
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    if writable_stream_0 is None:
        writable_stream_0 = WritableStream()
    assert isinstance(writable_stream_0.write, collections_abc.Callable)
    writable_stream_0.write = 'axe'
    assert isinstance(writable_stream_0.write, collections_abc.Callable)

test_case_0()
test_WritableStream_write()


if __name__ == '__main__':
    if sys.argv[1:] == [
        '--shapely-test-WritableStream-write', 'with_bool'
    ]:
        test_WritableStream_write()

# Generated at 2022-06-24 17:24:23.402162
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    #assert writable_stream_0.write() == NotImplemented
    #assert writable_stream_0.write() == NotImplemented
    assert writable_stream_0.write('') == None
    assert writable_stream_0.write('Hello') == None





# Generated at 2022-06-24 17:24:25.431477
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    x = WritableStream()
    x.write('abc')


# Generated at 2022-06-24 17:24:27.940941
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('foo')



# Generated at 2022-06-24 17:24:32.001500
# Unit test for function shitcode
def test_shitcode():
    msg = u'hello ÍÉÄ£ØÅÆÞÐÞþðþþþþþþþ'
    assert shitcode(msg) == 'hello IEALOASOoDDoooottttttttt'



# Generated at 2022-06-24 17:24:34.314580
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    assert issubclass(WritableStream, ABC)



# Generated at 2022-06-24 17:24:37.147315
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    print('test WritableStream.write')
    writable_stream_0 = WritableStream()
    output = writable_stream_0.write('abc')
    assert output is None

# Generated at 2022-06-24 17:24:38.830172
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    def test_case_0():
        assert get_shortish_repr('hello world', max_length=10) == 'hello worl'

    test_case_0()


# Generated at 2022-06-24 17:24:52.343426
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('')
    writable_stream_1 = WritableStream()
    writable_stream_1.write(b'')


# Generated at 2022-06-24 17:24:59.853455
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    print('try to get repr of a not so long string')
    assert get_shortish_repr('foobar') == 'foobar'
    print('pass')

    print('try to get repr of a long string')
    assert get_shortish_repr('foobar'*100, max_length=10) == 'foobar...obar'
    print('pass')

    print('try to get repr of a int')
    assert get_shortish_repr(10) == '10'
    print('pass')

    print('try to get repr of a float')
    assert get_shortish_repr(10.12345) == '10.12345'
    print('pass')

    print('try to get first repr of a list with two custom reprs')

# Generated at 2022-06-24 17:25:12.114739
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('some string', max_length=10) == 'some stri...'
    assert get_shortish_repr('some string', max_length=1000) == 'some string'
    assert get_shortish_repr('some string', max_length=None) == 'some string'
    assert get_shortish_repr([1, 2, 3], max_length=None) == '[1, 2, 3]'
    assert (
        get_shortish_repr([1, 2, 3], max_length=10, normalize=True)
        == '[1, 2, 3]'
    )
    assert (
        get_shortish_repr([1, 2, 3], max_length=4, normalize=True)
        == '[1, 2, 3]'
    )

# Generated at 2022-06-24 17:25:13.918590
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('')



# Generated at 2022-06-24 17:25:18.814445
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    # Test case where there is no write method
    writable_stream_1 = WritableStream()
    try:
        writable_stream_1.write()
    except NoMethodFound:
        pass
    else:
        raise Exception

# Generated at 2022-06-24 17:25:26.260102
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(object, max_length=3) == 'ob...'
    assert get_shortish_repr(object, max_length=4) == 'obje...'
    assert get_shortish_repr(object, max_length=5) == 'objec...'
    assert get_shortish_repr(object, max_length=6) == 'object...'
    assert get_shortish_repr(object, max_length=7) == 'object...'
    assert get_shortish_repr(object, max_length=8) == 'object...'
    assert get_shortish_repr(object, max_length=9) == 'object...'
    assert get_shortish_repr(object, max_length=100) == 'object...'
    assert get_short

# Generated at 2022-06-24 17:25:36.340428
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr(writable_stream_0) == 'REPR FAILED'
    assert get_shortish_repr(5, max_length=3) == '5'
    assert get_shortish_repr(5, max_length=2) == '5'
    assert get_shortish_repr(5, max_length=1) == '5'
    assert get_shortish_repr(5, max_length=0) == '...'

    class Dummy(object):
        def __init__(self, name_):
            self.name = name_
        def __repr__(self):
            return self.name

# Generated at 2022-06-24 17:25:40.572306
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()

    # TODO: should also assert that an exception has been raised.
    # writable_stream_0.write('abc')

test_case_0()






# Generated at 2022-06-24 17:25:51.102617
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import re
    from . import get_shortish_repr
    # Test for get_shortish_repr with simple parameters
    res = get_shortish_repr((1, 2), max_length=3)
    assert re.match(r"\(1, 2\)", res) # Test that the string was ltrimmed properly

    # Test for get_shortish_repr with a string
    res = get_shortish_repr("a simple super long string", max_length=5,
                                                            normalize=True)
    assert re.match(r"a sim", res) # Test that the string was ltrimmed properly

    def method_returning_something(x):
        return something
    res = get_shortish_repr(method_returning_something(3))

# Generated at 2022-06-24 17:25:52.463079
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert isinstance(WritableStream.write, collections_abc.Callable)
    test_case_0()



# Generated at 2022-06-24 17:26:04.538071
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from . import WritableStream, NotImplemented
    class writable_stream_0(WritableStream):
        def write(self, s):
            # raise NotImplementedError()
            pass
    writable_stream_0 = writable_stream_0()

    assert issubclass(writable_stream_0.__class__, WritableStream)
    assert writable_stream_0.write(u'abc') == None
    assert writable_stream_0.write(u'abc') == None



# Generated at 2022-06-24 17:26:13.207034
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert truncate('hello world', None) == 'hello world'
    assert truncate('hello world', 10) == 'hello wor...'
    assert truncate('hello world', 20) == 'hello world'
    assert truncate('hello world', 11) == 'hello wo...'
    assert truncate('hello world', 9) == 'hello w...'
    assert truncate('hello world', 8) == 'hello ...'
    assert truncate('hello world', 7) == 'hello ...'
    assert truncate('hello world', 6) == 'hello ...'
    assert truncate('hello world', 5) == 'he...'
    assert truncate('hello world', 4) == '...'
    assert truncate('hello world', 3) == '...'
    assert truncate('hello world', 2) == '...'

# Generated at 2022-06-24 17:26:17.969536
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_1 = WritableStream()
    try:
        writable_stream_1.write('jkl')
    except NotImplementedError:
        pass
    else:
        assert False



# Generated at 2022-06-24 17:26:22.842571
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # First we need to create a WritableStream object to call its write
    # method. (You can't call a method on an abstract class.)
    writable_stream_1 = WritableStream()

    # Now we're ready. Let's call the method.
    writable_stream_1.write('abcd')



# Generated at 2022-06-24 17:26:26.136724
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    assert hasattr(writable_stream_0, 'write')
    assert callable(writable_stream_0.write)
    writable_stream_0_0 = writable_stream_0.write('q')


# Generated at 2022-06-24 17:26:34.504683
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr(False) == 'False'
    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr(5.0) == '5.0'
    assert get_shortish_repr('abc') == "u'abc'"
    assert get_shortish_repr([3, 4]) == '[3, 4]'
    assert get_shortish_repr((3, 4)) == '(3, 4)'
    assert get_shortish_repr({5, 4}) == '{4, 5}'
    assert get_shortish_repr({3: 4}) == '{3: 4}'
    assert get

# Generated at 2022-06-24 17:26:36.286884
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('')


# Generated at 2022-06-24 17:26:43.515423
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('a', max_length=3) == 'a'
    assert get_shortish_repr('ab', max_length=3) == 'ab'
    assert get_shortish_repr('abc', max_length=3) == 'abc'
    assert get_shortish_repr('abcd', max_length=3) == 'abc...'
    assert get_shortish_repr('abcde', max_length=3) == 'abc...'
    assert get_shortish_repr('abcdef', max_length=3) == 'abc...'
    assert get_shortish_repr('abcdefg', max_length=3) == 'abc...'



# Generated at 2022-06-24 17:26:48.579881
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.close()
    try:
        writable_stream_0.write()
    except Exception:
        pass
    writable_stream_0.write('<code>')


# Generated at 2022-06-24 17:26:51.609955
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    def test_case_s0():
        writable_stream_0 = WritableStream()
        writable_stream_0.write("")
        writable_stream_0.write("a")


# Generated at 2022-06-24 17:27:07.776746
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0_0 = WritableStream()
    writable_stream_0_0.write('G')
    writable_stream_0_0.write('R')
    writable_stream_0_0.write('E')
    writable_stream_0_0.write('C')
    writable_stream_0_0.write('E')
    writable_stream_0_0.write('D')
    writable_stream_0_0.write(' ')
    writable_stream_0_0.write('I')
    writable_stream_0_0.write('T')
    writable_stream_0_0.write(' ')
    writable_stream_0_0.write('P')
    writable_stream_0_0.write('A')
    writable_

# Generated at 2022-06-24 17:27:19.853674
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()

    def test_func(string):
        writable_stream_0 = WritableStream()
        writable_stream_0.write(string)

# Generated at 2022-06-24 17:27:27.238211
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write("r")
    writable_stream_0.write("a")
    writable_stream_0.write("r")
    writable_stream_0.write("r")
    writable_stream_0.write("a")
    writable_stream_0.write("\n")



# Generated at 2022-06-24 17:27:30.676986
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    if writable_stream_0.write('a'*1000000):
        return False
    return True

test_ = 4 + 5


# Generated at 2022-06-24 17:27:33.716190
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    assert writable_stream_0.write("") == None


# Generated at 2022-06-24 17:27:36.334616
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    assert callable(writable_stream_0.write)



# Generated at 2022-06-24 17:27:38.393829
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write(str)



# Generated at 2022-06-24 17:27:45.184546
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    try:
        writable_stream_0.write('')
    except TypeError as e:
        assert str(e) == 'write() missing 1 required positional argument: \'s\''
    else:
        assert False, 'This should have raised a TypeError'
    try:
        writable_stream_0.write()
    except TypeError as e:
        assert str(e) == 'write() missing 1 required positional argument: \'s\''
    else:
        assert False, 'This should have raised a TypeError'






# Generated at 2022-06-24 17:27:46.078733
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_case_0()

# Generated at 2022-06-24 17:27:53.492955
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Arrange
    writable_stream = WritableStream()

    # Act
    writable_stream.write('# Unit test for method write of class WritableStream')
    writable_stream.write('def test_WritableStream_write():')
    writable_stream.write('    # Arrange')
    writable_stream.write('    writable_stream = WritableStream()')
    writable_stream.write('')
    writable_stream.write('    # Act')
    writable_stream.write('    writable_stream.write(\'# Unit test for method write of class WritableStream\')')
    writable_stream.write('    writable_stream.write(\'def test_WritableStream_write():\')')

# Generated at 2022-06-24 17:27:59.761518
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    try:
        writable_stream_0.write('anything')
    except NotImplementedError:
        pass

# Generated at 2022-06-24 17:28:10.306428
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    try:
        writable_stream_0.write('Lorem')
    except NotImplementedError:
        
        pass
    else:
        raise AssertionError()
    try:
        WritableStream.write(writable_stream_0, 'Lorem')
    except NotImplementedError:
        
        pass
    else:
        raise AssertionError()
    try:
        WritableStream.__dict__['write'].__get__(writable_stream_0)('Lorem')
    except NotImplementedError:
        
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-24 17:28:11.355732
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_case_1()


# Generated at 2022-06-24 17:28:17.776121
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    if hasattr(writable_stream_0, "write"):
        name = "write"
        arg_names = ("s",)
        arg_values = (sys.stdout, )
        try:
            getattr(writable_stream_0, name)(*arg_values)
            print("Method", name, "of class WritableStream worked as expected.")
        except Exception as e:
            print("Method", name, "of class WritableStream didn't work as expected.")
            print("   ", e)
    else:
        print("Method 'write' was not defined for class WritableStream.")

# Generated at 2022-06-24 17:28:21.695953
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('abc')
    assert True


# Generated at 2022-06-24 17:28:23.274979
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    assert writable_stream_0.write('n') is NotImplemented


# Generated at 2022-06-24 17:28:32.388514
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """Test method write of class WritableStream"""
    def check_WritableStream_write(object):
        return isinstance(object, WritableStream)
    assert WritableStream.write("") == True, "writable_stream_0.write()" + \
                                                                  " failed!"


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 17:28:35.294424
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    __dispatch__ = {'WritableStream': test_case_0}
    __dispatch__[WritableStream.__name__]()


# Generated at 2022-06-24 17:28:42.223359
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    # Populate writable_stream_0.__dict__
    writable_stream_0.__dict__['name'] = 'writable_stream_0'
    writable_stream_0.__dict__['write'] = lambda s: None
    writable_stream_0.write('foo')



# Generated at 2022-06-24 17:28:50.560359
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    assert repr(writable_stream_0) == 'None'
    writable_stream_0.write(None)
    assert repr(writable_stream_0) == 'None'
    assert repr(writable_stream_0) == 'None'
    assert repr(writable_stream_0) == 'None'
    assert repr(writable_stream_0) == 'None'
    assert repr(writable_stream_0) == 'None'
    assert repr(writable_stream_0) == 'None'
    assert repr(writable_stream_0) == 'None'
    assert repr(writable_stream_0) == 'None'
    assert repr(writable_stream_0) == 'None'

# Generated at 2022-06-24 17:28:55.944465
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    assert callable(writable_stream_0.write)

# Generated at 2022-06-24 17:28:59.362969
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr((1,2), max_length=1, normalize=True) == '...'
    assert get_shortish_repr((1,2), max_length=10, normalize=True) == '(1, 2)'
    assert get_shortish_repr((1,2), max_length=5, normalize=True) == '...'

# Generated at 2022-06-24 17:29:10.058625
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # test if declared
    writable_stream_0 = WritableStream()
    assert hasattr(writable_stream_0, "write")
    # test if it's callable
    assert callable(getattr(writable_stream_0, "write"))
    try:
        x = type(getattr(writable_stream_0, "write")())
    except Exception:
        x = False
        if str(sys.exc_info()[1]) == "write() takes 1 positional argument but 0 were given":
            print("Test pass")
        else:
            print("err", sys.exc_info()[1])
        assert str(sys.exc_info()[1]) == "write() takes 1 positional argument but 0 were given"
        

# Generated at 2022-06-24 17:29:21.819264
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    try:
        writable_stream_0.write()
    except Exception as exc:
        assert str(exc) == 'write() takes at least 1 argument (0 given)', \
                   'write fails to raise TypeError exception when invoked ' \
                   'with no arguments'
    else:
        assert False, 'write fails to raise exception when invoked with no ' \
                      'arguments'
    try:
        writable_stream_0.write((1, 2))
    except Exception as exc:
        assert str(exc) == 'write() takes exactly 1 argument (2 given)', \
                   'write fails to raise TypeError exception when invoked ' \
                   'with multiple arguments'
    else:
        assert False, 'write fails to raise exception when invoked with ' \
                      'multiple arguments'


# Generated at 2022-06-24 17:29:24.981026
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """Unit test for method write of class WritableStream"""
    writable_stream_write_0 = WritableStream()

    
    
    def function_0():
        return writable_stream_write_0.write(1)

    assert function_0() == NotImplemented
    
    
    
    
    
    
    

# Generated at 2022-06-24 17:29:27.328999
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream = WritableStream()
    assert hasattr(writable_stream, 'write')
    assert isinstance(writable_stream.write, collections_abc.Callable)


# Generated at 2022-06-24 17:29:29.379039
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write()


# Generated at 2022-06-24 17:29:32.967379
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    with raises(TypeError, match='write() missing 1 required positional argument: "s"'):
        writable_stream_0.write()


# Generated at 2022-06-24 17:29:41.578007
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(int, max_length=2) == 'int'
    assert get_shortish_repr(int, max_length=5) == 'int'
    assert get_shortish_repr(int, max_length=6) == 'int'
    assert get_shortish_repr(int, max_length=10) == 'int'
    assert get_shortish_repr(3, max_length=10) == '3'
    assert get_shortish_repr(3.14, max_length=10) == '3.14'
    assert get_shortish_repr(3.14, max_length=4) == '3.1'
    assert get_shortish_repr(3.14, max_length=5) == '3.14'
    assert get

# Generated at 2022-06-24 17:29:50.737218
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    if True:  # TODO: Find some better conditions for this branch
        try:
            writable_stream_0.write("")
        except TypeError:
            pass
        except NotImplementedError:
            pass
        else:
            assert False
    else:
        pass

if __name__ == "__main__":
    test_case_0()
    test_WritableStream_write()
  
#c = WritableStream()

# Generated at 2022-06-24 17:30:01.202411
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    try:
        writable_stream_0.write(None)
    except NotImplementedError:
        pass
    else:
        assert False, 'err'
    return True

# Generated at 2022-06-24 17:30:02.835739
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    x = WritableStream()
    x.write('hello')


# Generated at 2022-06-24 17:30:04.268058
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    _writable_stream_0 = WritableStream()
    _writable_stream_0.write('abc')

# Generated at 2022-06-24 17:30:06.991824
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    assert writable_stream_0.write('') == None


# Generated at 2022-06-24 17:30:10.414299
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('abc')
    assert writable_stream_0.write('abc') is None
    
    
    


# Generated at 2022-06-24 17:30:12.494629
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    with pytest.raises(TypeError):
        writable_stream_0.write()

# Generated at 2022-06-24 17:30:17.119715
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    with (writable_stream_0.write) as method:
        assert isinstance(method, types.FunctionType)
        assert isinstance(method(writable_stream_0), collections_abc.Iterable)


# Generated at 2022-06-24 17:30:19.590336
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('s')


# Generated at 2022-06-24 17:30:24.692446
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    try:
        writable_stream_0.write('we5i5ph')
        success = True
    except Exception:
        success = False
    assert success, '''Method write of class WritableStream caused an error.'''


# Generated at 2022-06-24 17:30:33.939872
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('ABC', max_length=3) == 'ABC'
    assert get_shortish_repr('ABC', max_length=2) == 'AB'
    assert get_shortish_repr('ABC', max_length=1) == 'A'
    assert get_shortish_repr('ABC', max_length=0) == ''
    assert get_shortish_repr('ABC', max_length=None) == 'ABC'

    assert get_shortish_repr('ABCDEF', max_length=3) == 'ABC'
    assert get_shortish_repr('ABCDEF', max_length=4) == 'ABCD'
    assert get_shortish_repr('ABCDEF', max_length=5) == 'ABCDE'

# Generated at 2022-06-24 17:30:56.235144
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    assert writable_stream_0.write() is NotImplemented


# Generated at 2022-06-24 17:30:59.197606
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write(2.5)


# Generated at 2022-06-24 17:31:01.213319
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    with raises(TypeError):
        writable_stream_0 = WritableStream()
        writable_stream_0.write()



# Generated at 2022-06-24 17:31:05.022219
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    try:
        writable_stream_0.write('5')
    except NotImplementedError:
        pass
    except Exception as e:
        print('Caught: ', e)


# Generated at 2022-06-24 17:31:08.138746
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    result = writable_stream_0.write('a')
    assert result is None
    assert sys.stdout.getvalue() == 'a'

test_cases = [test_case_0, test_WritableStream_write]


# Generated at 2022-06-24 17:31:16.198738
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    shortish_repr = get_shortish_repr(range(20), max_length=50)
    assert shortish_repr == u'range(0, 20)'
    shortish_repr = get_shortish_repr(range(20), max_length=20)
    assert shortish_repr == u'range(0, 20)'
    shortish_repr = get_shortish_repr(range(20), max_length=19)
    assert shortish_repr == u'range(0, 20)...'
    shortish_repr = get_shortish_repr(range(20), max_length=18)
    assert shortish_repr == u'range(0, 20)...'
    shortish_repr = get_shortish_repr(range(20), max_length=17)

# Generated at 2022-06-24 17:31:18.894705
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Can't instantiate an abstract class.
    with AssertRaises(TypeError):
        WritableStream()
