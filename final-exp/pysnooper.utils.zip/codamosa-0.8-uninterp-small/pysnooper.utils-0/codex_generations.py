

# Generated at 2022-06-24 17:21:35.261658
# Unit test for function get_repr_function
def test_get_repr_function():
    file_0 = open(__file__)
    try:
        null = None
        var_1 = get_repr_function(file_0, ( (bool, str),))
        var_2 = get_repr_function(null, ( (bool, str),))
        var_3 = get_repr_function(file_0, ( (str, str),))
        var_4 = get_repr_function(null, ( (str, str),))
    finally:
        file_0.close()
    assert var_1 == repr
    assert var_2 == repr
    assert var_3 == str
    assert var_4 == str

# Generated at 2022-06-24 17:21:37.500472
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'one')]) == 'one'
    


# Generated at 2022-06-24 17:21:42.028160
# Unit test for function get_repr_function
def test_get_repr_function():
    import re
    var_0 = get_repr_function(float_0, (
        (lambda x: True, shitcode),
        (re.compile('^A.*$'), lambda x: 'B' * len(x))
    ))
    assert var_0(float_0) == '?.?.?'


# Generated at 2022-06-24 17:21:49.687542
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # List of locations to check method write of class WritableStream
    locations = [
        [0], # float_0
        [0], # var_0
        [0], # float_0
        [0], # var_0
        [0], # float_0
        [0], # var_0
        [0], # float_0
        [0], # var_0
        [1, 0], # float_0
        [1, 0], # var_0
        [1, 0], # float_0
        [1, 0], # var_0
        [1, 0], # float_0
        [1, 0], # var_0
    ]
    # The conditions that must be true for each call to method write of
    # class WritableStream

# Generated at 2022-06-24 17:22:00.549362
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(['a', 'b', 'c'], max_length=2) == 'a...'
    assert get_shortish_repr(['a', 'b', 'c'], max_length=3) == "'a',..."
    assert get_shortish_repr(['a', 'b', 'c'], max_length=4) == "'a',..."
    assert get_shortish_repr(['a', 'b', 'c'], max_length=5) == "'a',..."
    assert get_shortish_repr(['a', 'b', 'c'], max_length=6) == "'a',..."
    assert get_shortish_repr(['a', 'b', 'c'], max_length=7) == "'a',..."
    assert get_shortish_

# Generated at 2022-06-24 17:22:04.180011
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('A') == 'A'
    assert shitcode(u'\u0184') == '?'
    assert shitcode('A\u0104') == 'A?'

# Generated at 2022-06-24 17:22:08.832582
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_0 = WritableStream()
    var_0.write('i am a banana')


# Generated at 2022-06-24 17:22:18.477616
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """
    Unit test for method :meth:`WritableStream.write`.

    Make sure it works well with all kinds of `iterable_type`.
    """
    import io
    import types

    for iterable_type in (string_types, types.GeneratorType, collections_abc.Generator, tuple, list, dict, set, frozenset, object, object()):
        print(iterable_type)
        var_0 = ensure_tuple(iterable_type)
        ensure_tuple(iterable_type)

# Generated at 2022-06-24 17:22:28.205932
# Unit test for function get_repr_function
def test_get_repr_function():
    def repr_function(item, repr_function=None, repr_function_0=None):
        if repr_function is None:
            repr_function = repr
        if repr_function_0 is None:
            repr_function_0 = repr
        return repr_function if item else repr_function_0
    i = 0
    test_list = []
    for var_0 in range(100):
        if i == 0:
            test_list.append((i, 0))
        elif i == 1:
            test_list.append((i, 0))
        elif i == 2:
            test_list.append((i, 0))
        elif i == 3:
            test_list.append((i, 0))
        elif i == 4:
            test_list.append((i, 0))

# Generated at 2022-06-24 17:22:33.288601
# Unit test for function get_repr_function
def test_get_repr_function():
    assert (get_repr_function(1, [(lambda x: True, lambda x: 'x')]) == 'x')


# Generated at 2022-06-24 17:22:38.785796
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """
    Unit test for method :meth:`WritableStream.write`.

    Make sure it works well with all kinds of `iterable_type`.
    """
    pass


# Generated at 2022-06-24 17:22:45.944513
# Unit test for function get_repr_function
def test_get_repr_function():
    from pickle import Pickler
    assert get_repr_function('abc', ()) == repr
    assert get_repr_function('abc', ((str, str),)) == str
    assert get_repr_function(u'abc', ((str, str),)) == repr
    assert get_repr_function(u'abc', ((str, str), (lambda x: False, None))) == repr
    assert get_repr_function(u'abc', ((lambda x: True, None), (str, str))) == str
    p = Pickler()
    assert get_repr_function(
        p, ((lambda x: True, None), (str, str))
    ) == str
    assert get_repr_function(p, ((str, str),)) == str


# Generated at 2022-06-24 17:22:47.666724
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    get_shortish_repr(str_0, max_length=32)
    return None

# Generated at 2022-06-24 17:22:57.684282
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(str_0) == repr
    assert get_repr_function(str_0, ((str, 'blah'))) == 'blah'
    assert get_repr_function(str_0, ((str, 'blah'),)) == 'blah'
    assert get_repr_function(str_0, ((str, 'blah'),)) == 'blah'
    assert get_repr_function(str_0, ((str, 'blah'), (str, 'blah'))) == 'blah'
    class A(object):
        pass
    class B(A):
        pass
    assert get_repr_function(A(), ((B, 'blah'))) != 'blah'

# Generated at 2022-06-24 17:22:58.741711
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Make sure it works well with all kinds of iterable_type
    pass


# Generated at 2022-06-24 17:23:10.727220
# Unit test for function get_repr_function
def test_get_repr_function():
    def to_list(x):
        return list(x)
    assert get_repr_function([], [(int, to_list)]) is list
    assert get_repr_function(1, [(float, to_list)]) is repr
    assert get_repr_function(1, [(int, to_list)]) is to_list
    assert get_repr_function(1, [lambda x: not isinstance(x, list), to_list]) \
                                                                      is to_list
    assert get_repr_function([], [lambda x: not isinstance(x, list), to_list])\
                                                                      is repr
    assert get_repr_function([], [lambda x: False, to_list]) is to_list



# Generated at 2022-06-24 17:23:16.309432
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    for iterable_type in (list, tuple, set, frozenset, dict.keys, dict.values,
                          range(0, 4)):
        for item in iterable_type:
            assert WritableStream.write(item) is None
    assert WritableStream.write(str_0) == None
    assert WritableStream.write(str_0) == None



# Generated at 2022-06-24 17:23:17.065292
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass

# Generated at 2022-06-24 17:23:19.765986
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    if str_0 == get_shortish_repr(str_0):
        return 0
    else:
        return 1


# Generated at 2022-06-24 17:23:28.498262
# Unit test for function get_repr_function
def test_get_repr_function():
    test_cases = [('a', 0),
                  ('a', 1),
                  ('a', 2),
                  ('a', (1, 2)),
                  ('a', 'a'),
                  ('a', (1, 'b')),
                  ('a', {0: 1}),
                  ('a', {}),
                  ('a', None),
                  ('a', [1, 2]),
                  ('a', [])]
    for item, custom in test_cases:
        assert get_repr_function(item, custom) == repr
    assert get_repr_function(str, 'a') == repr
    assert get_repr_function(str, str) == str



# Generated at 2022-06-24 17:23:33.312727
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Make sure it works well with all kinds of string.
    test_case_0()



# Generated at 2022-06-24 17:23:34.228144
# Unit test for function get_repr_function
def test_get_repr_function():
    get_repr_function(str_0, var_0)


# Generated at 2022-06-24 17:23:42.215422
# Unit test for function get_repr_function
def test_get_repr_function():
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    list_0 = []
    class_0 = WritableStream
    tuple_0 = (str_0,)
    dict_0 = {}
    assert get_repr_function(str_0, []) == repr
    assert get_repr_function(list_0, []) == repr
    assert get_repr_function(class_0, []) == repr
    assert get_repr_function(tuple_0, []) == repr
    assert get_repr_function(dict_0, []) == repr
    assert get_repr_function(str_0, [(lambda x: True, str)]) == str


# Generated at 2022-06-24 17:23:49.920210
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Make sure it works well with all kinds of iterable_type: str
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_0 = get_shortish_repr(str_0)
    print(var_0)

# Generated at 2022-06-24 17:23:56.000929
# Unit test for function get_repr_function
def test_get_repr_function():
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    func_0 = get_repr_function(str_0)


# Generated at 2022-06-24 17:24:06.080050
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from random import randint
    from string import ascii_letters, digits
    ascii_letters_and_digits = ascii_letters + digits

    assert get_shortish_repr('hi') == 'hi'
    assert get_shortish_repr('') == ''
    assert get_shortish_repr('ab' * 200) == \
                               'ab' * 200
    assert get_shortish_repr('ab' * 200, max_length=20) == \
                               'abababababababababa...abab'
    assert get_shortish_repr('ab' * 200, max_length=19) == \
                               'abababababababababa...bab'

# Generated at 2022-06-24 17:24:09.698378
# Unit test for function get_repr_function
def test_get_repr_function():
    str_0 = get_repr_function({}, ((dict, lambda x: 'hello world'),))

    def func_0(x):
        return 'ok'
    str_1 = get_repr_function(['x', 'y'], (func_0, ))



# Generated at 2022-06-24 17:24:20.520630
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    def test_case_0():
        str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
        var_0 = get_shortish_repr(str_0)

    def test_case_1():
        str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
        var_0 = get_shortish_repr(str_0, max_length=70)


# Generated at 2022-06-24 17:24:24.471466
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_0 = get_shortish_repr(str_0)


if (__name__ is '__main__'):
    test_case_0()

# Generated at 2022-06-24 17:24:34.550938
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from . import WritableStream
    assert _check_methods(WritableStream, 'write')
    def w(x):
        return WritableStream().write(x)
    # Make sure it works well with all kinds of iterable_type.
    assert w('a') == None
    assert w(b'a') == None
    assert w(['a']) == None
    assert w(('a',)) == None
    assert w(('a', 'b')) == None
    assert w({'a'}) == None
    assert w({'a': 'b'}) == None
    assert w('a'.split()) == None
    assert w(5 * 'a'.split()) == None
    assert w('a' + 'b') == None
    assert w('a' * 5) == None

# Generated at 2022-06-24 17:24:46.133392
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, custom_repr=(
        (type(1), lambda item: 'n == one'),
    )) == repr
    assert get_repr_function(1, custom_repr=(
        (type(1), lambda item: 'n == one'),
    )) == (lambda item: 'n == one')
    assert get_repr_function(1.5, custom_repr=(
        (type(1), lambda item: 'n == one'),
    )) == repr
    assert get_repr_function(1, custom_repr=(
        (lambda i: i==1, lambda item: 'n == one'),
    )) == (lambda item: 'n == one')

# Generated at 2022-06-24 17:24:57.646790
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    test_case_0()
    var_1 = get_shortish_repr(17)
    assert var_1 == '17', var_1
    var_2 = get_shortish_repr([1, 2, 3])
    assert var_2 == '[1, 2, 3]', var_2
    var_3 = get_shortish_repr(True)
    assert var_3 == 'True', var_3
    var_4 = get_shortish_repr(3.14)
    assert var_4 == '3.14', var_4
    var_5 = get_shortish_repr(0.14)
    assert var_5 == '0.14', var_5
    var_6 = get_shortish_repr(0)
    assert var_6 == '0', var_6


# Generated at 2022-06-24 17:25:02.276467
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Make sure it works well with all kinds of iterable_type.
    str_0 = "Python is a widely used high-level, general-purpose, interpreted,\n    dynamic programming language. Its design philosophy emphasizes code\n    readability, and its syntax allows programmers to express concepts in\n    fewer lines of code than possible in languages such as C++ or Java.[25][26]\n    "
    var_0 = WritableStream()
    var_1 = var_0.write(str_0)

# Generated at 2022-06-24 17:25:12.674183
# Unit test for function get_repr_function
def test_get_repr_function():
    repr_str = get_repr_function("foo")("foo")
    repr_int = get_repr_function(42)(42)
    repr_list = get_repr_function([42])([42])
    repr_custom_repr = get_repr_function("foo", custom_repr=((str, lambda x: "FOO"),))("foo")
    assert repr_str == "'foo'"
    assert repr_int == '42'
    assert repr_list == '[42]'
    assert repr_custom_repr == "FOO"


# Generated at 2022-06-24 17:25:16.116374
# Unit test for function get_repr_function
def test_get_repr_function():
    ensure_repr_function(test_case_0, get_repr_function, test_case_0.var_0)


# Generated at 2022-06-24 17:25:25.274452
# Unit test for function get_repr_function
def test_get_repr_function():
    global str_0
    global var_0

    assert get_repr_function(1, [(lambda x: x == 1, lambda x: str(x) + 'a')])('1') == '1a'
    assert get_repr_function(1, [(lambda x: x == 2, lambda x: str(x) + 'a')])('1') == '1'
    assert get_repr_function(1, [(lambda x: x.__len__ == 2, lambda x: str(x) + 'a')])('1') == '1'
    assert get_repr_function(1, [(lambda x, y=2: x.__len__ == y, lambda x: str(x) + 'a')])('1') == '1'



# Generated at 2022-06-24 17:25:35.828121
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('abcd', ()) == repr


# Generated at 2022-06-24 17:25:48.296529
# Unit test for function get_repr_function
def test_get_repr_function():
    # given:
    class A(object):
        pass
    a = A()
    assert get_repr_function(a, ()) == repr
    assert get_repr_function(a, ((A, str),)) == str
    assert get_repr_function(a, ((A, str), (type(a), lambda a: 'b'))) == str
    assert get_repr_function(a, ((A, str), (type(a), lambda a: 'b'))) == str
    assert get_repr_function(a, ((A, str), (type(a), lambda a: 'b'),
                                 (float, float))) == str
    assert get_repr_function(1, ((A, str), (type(a), lambda a: 'b'),
                                 (float, float))) == float



# Generated at 2022-06-24 17:25:54.593579
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_0 = get_shortish_repr(str_0)

# Generated at 2022-06-24 17:25:59.090137
# Unit test for function shitcode
def test_shitcode():
    str_0 = 'abc\u2014def'
    assert shitcode(str_0) == 'abc?def'
    str_1 = 'abc\u2014def\u2014'
    assert shitcode(str_1) == 'abc?def?'


# Generated at 2022-06-24 17:26:07.398519
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    fun = get_shortish_repr
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_

# Generated at 2022-06-24 17:26:12.147812
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(len) == '<built-in function len>'
    assert get_shortish_repr(Ellipsis, normalize=True) == "'...'"
    assert '0x' not in get_shortish_repr([1, 2, 3])

# Generated at 2022-06-24 17:26:18.510303
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Make sure it works well with all kinds of `iterable_type`.
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_0 = get_shortish_repr(str_0)


# Generated at 2022-06-24 17:26:27.475784
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from . import WritableStream
    from .pycompat import with_metaclass


    class DummySystemOut(with_metaclass(WritableStream)):
        def __init__(self) -> None:
            self.buffer = []
        def write(self, s):
            self.buffer.append(s)

        def clear_buffer(self):
            self.buffer[:] = []



    dummy_system_out = DummySystemOut()

    def test_case_0():
        str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
        var_0 = get_shortish_repr(str_0)

    def test_case_1():
        str_

# Generated at 2022-06-24 17:26:37.726598
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(ascii('abcdef')) == 'abcdef'
    assert shitcode(ascii('abc\xf1\xd7def')) == 'abc??def'

# Generated at 2022-06-24 17:26:41.503469
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_0 = get_shortish_repr(str_0)



# Generated at 2022-06-24 17:26:52.980735
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None, max_length=100) == 'None'
    assert get_shortish_repr('', max_length=100) == "''"
    assert get_shortish_repr('x'*1000, max_length=100) == "'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'"
    assert get_shortish_repr([1, 2, 3], max_length=100) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=8) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=7) == '[1,...]'
    assert get_shortish_repr([1, 2, 3], max_length=6)

# Generated at 2022-06-24 17:27:01.624407
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    """
    Unit test for method :meth:`WritableStream.write`.

    Make sure it works well with all kinds of `iterable_type`.
    """
    from . import string_types
    from . import collections_abc
    from . import get_shortish_repr
    get_shortish_repr('abc')
    get_shortish_repr(b'abc')
    get_shortish_repr(None)
    get_shortish_repr([])
    get_shortish_repr({})
    try:
        get_shortish_repr(set())
    except TypeError:
        pass
    else:
        raise RuntimeError
    get_shortish_repr(object())
    get_shortish_repr(u'abc')
    get_shortish_repr('abc')

# Generated at 2022-06-24 17:27:04.584125
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from . import assert_that
    from sweet_python import get_shortish_repr
    from . import is_, not_, is_instance_of, is_equal_to

    test_case_0()
    pass




# Generated at 2022-06-24 17:27:12.573076
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    str_1 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_0 = get_shortish_repr(str_0)
    string_2 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_1 = get_shortish_repr(string_2)


# Generated at 2022-06-24 17:27:23.752535
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_0 = get_shortish_repr(str_0)
    var_1 = get_shortish_repr(str_0, max_length=None)
    var_2 = get_shortish_repr(str_0, max_length=1)

# Generated at 2022-06-24 17:27:25.200601
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_case_0()

# Generated at 2022-06-24 17:27:33.822671
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    def write(self, s):
        if isinstance(s, bytes):
            s = s.decode(self.encoding, self.errors)
        elif not isinstance(s, str):
            raise TypeError("can't write %s to text stream" % s.__class__.__name__)
        try:
            self.stream.write(s)
            self.stream.flush()
        except OSError as e:
            print("OSError")
            if not self.errors:
                raise
            elif self.errors == 'strict':
                raise
            elif self.errors == 'replace':
                pass
            elif self.errors == 'ignore':
                return
            elif self.errors == 'backslashreplace':
                pass
            else:
                print("Unknown mode")

# Generated at 2022-06-24 17:27:44.711213
# Unit test for function shitcode
def test_shitcode():
    str_0 = '\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
    var_0 = shitcode(str_0)
    str_1 = '\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f'
    var_1 = shitcode(str_1)
    str_2 = ' !"#$%&\'()*+,-./0123456789:;<=>?'
    var_2 = shitcode(str_2)

# Generated at 2022-06-24 17:27:45.956638
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    get_shortish_repr(str_0)
    test_case_0()

# Generated at 2022-06-24 17:27:53.029336
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    var_0 = get_shortish_repr(b'\xfc\xfc\xfc')
    var_1 = get_shortish_repr(b'\xfc')
    var_2 = get_shortish_repr(b'\xfc\xfc\xfc', max_length=3)
    var_3 = get_shortish_repr(b'\xfc\xfc\xfc', max_length=4)
    var_4 = get_shortish_repr(b'\xfc\xfc\xfc', max_length=5)
    var_5 = get_shortish_repr(b'\xfc\xfc\xfc', max_length=6)
    
    

# Generated at 2022-06-24 17:27:53.652238
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    test_case_0()

# Generated at 2022-06-24 17:27:59.186728
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_0 = get_shortish_repr(str_0)
    var_1 = var_0
    var_2 = set()
    var_3 = get_shortish_repr(var_2)
    var_4 = var_1
    var_5 = var_3
    var_6 = (1, 2, 3)
    var_7 = get_shortish_repr(var_6)
    var_8 = var_4
    var_9 = var_7
    var_10 = {'a': 1, 'b': 2}

# Generated at 2022-06-24 17:28:08.324102
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    # Make sure it works well with all kinds of iterable_type.
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.output = []
        def write(self, s):
            self.output.append(s)
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('')
    assert my_writable_stream.output == ['']
    my_writable_stream.write('a')
    assert my_writable_stream.output == ['']
    my_writable_stream.write('ab')
    assert my_writable_stream.output == ['']



# Generated at 2022-06-24 17:28:10.525500
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert isinstance(WritableStream.write, collections_abc.Callable)


EXTRANEOUS = ' \ufeff\u200b'

# Generated at 2022-06-24 17:28:19.677056
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_0 = get_shortish_repr(str_0)
    assert var_0 == '\'\\n    Unit test for method :meth:`WritableStream.write`.\\n\\n    Make sure it works well with all kinds of `iterable_type`.\\n    \''



# Generated at 2022-06-24 17:28:28.859755
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Make sure it works well with all kinds of `iterable_type`.
    var_0 = getattr(sys.stdout, 'write')
    var_0(str_0)
    var_1 = str_0.split()
    var_2 = get_shortish_repr(var_1)
    var_0.write(var_1)
    var_3 = (word for word in str_0.split())
    var_4 = get_shortish_repr(var_3)
    var_0.write(var_3)
    var_5 = get_shortish_repr(var_3, normalize=True)
    var_0.write(var_3)
    var_6 = get_shortish_repr(''.join(var_3))



# Generated at 2022-06-24 17:28:34.263972
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    def func_0(s):
        sys.stdout.write(s)

    def test_case_0(s):
        assert isinstance(s, str)
        func_0(s)

    test_case_0('\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    ')


# Generated at 2022-06-24 17:28:43.103356
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_0 = get_shortish_repr(str_0)
    assert var_0 == '\'\\n    Unit test for method :meth:`WritableStream.write`.\\n\\n    Make sure it works well with all kinds of `iterable_type`.\\n    \''


# Generated at 2022-06-24 17:28:44.363407
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_case_0()
# END tested code

# Generated at 2022-06-24 17:28:46.475291
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert test_case_0() == '    Unit test for...pe`.\n    '

# Generated at 2022-06-24 17:28:48.844890
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(123) == '123'




# Generated at 2022-06-24 17:28:55.363256
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class StubWritableStream(WritableStream):
        def write(self, s):
            pass

    stub_writable_stream_0 = StubWritableStream()
    stub_writable_stream_0.write('\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    ')


# Generated at 2022-06-24 17:28:58.951687
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    print('Method: get_shortish_repr')
    var_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_1 = get_shortish_repr(var_0)
    print(var_1)



# Generated at 2022-06-24 17:29:00.363753
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_case_0()



# Generated at 2022-06-24 17:29:14.172381
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    list_0 = [1, 4, 2, 0, 2, 5, 2, 0, 2, 5, 2, 0, 2, 5, 2, 0, 2, 5, 2, 0, 2, 5, 2, 0, 2, 5, 2, 0, 2, 5, 2]
    var_0 = get_shortish_repr(list_0)

# Generated at 2022-06-24 17:29:25.996174
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Make sure it works well with all kinds of str
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_0 = get_shortish_repr(str_0)
    assert var_0 == '\'\\n    Unit test for method :meth:`WritableStream.write`.\\n\\n    Make sure it works well with all kinds of `iterable_type`.\\n    \''

    str_1 = """

    Unit test for method :meth:`WritableStream.write`.

    Make sure it works well with all kinds of `iterable_type`
    """
    var_1 = get_shortish_repr(str_1)
    assert var_1

# Generated at 2022-06-24 17:29:29.894753
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import pytest
    # Test for method get_shortish_repr
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_0 = get_shortish_repr(str_0)
    test_case_0()

# Generated at 2022-06-24 17:29:34.001646
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    sys.stdout.write('Testing write with different iterable types...')
    for iterable_type in (list, tuple, dict, set, frozenset):
        sys.stdout.write('\n{!r}: '.format(iterable_type))
        iterable = iterable_type(['a', 'b', 'c'])
        stream = WritableStream()
        stream.write(iterable)
        sys.stdout.write('PASSED')
    sys.stdout.write('\nDone.')

# Generated at 2022-06-24 17:29:40.054199
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    var_0 = get_shortish_repr('\n    ')
    var_1 = get_shortish_repr('\n    ', max_length=None)
    var_2 = get_shortish_repr('\n    ', max_length=0)
    var_3 = get_shortish_repr('\n    ', max_length=1)
    var_4 = get_shortish_repr('\n    ', max_length=2)
    var_5 = get_shortish_repr('\n    ', max_length=3)
    var_6 = get_shortish_repr(None)
    var_7 = get_shortish_repr(None, custom_repr=(('NOOOOO', 'HEY'),))

# Generated at 2022-06-24 17:29:52.350511
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert normalize_repr(get_shortish_repr(None)) == repr(None)
    assert normalize_repr(get_shortish_repr('')) == repr('')
    assert normalize_repr(get_shortish_repr(Ellipsis)) == repr(Ellipsis)
    assert normalize_repr(get_shortish_repr(NotImplemented)) == \
        repr(NotImplemented)
    assert normalize_repr(get_shortish_repr(5)) == repr(5)

    assert normalize_repr(get_shortish_repr(5j)) == repr(5j)

    assert normalize_repr(get_shortish_repr(5 + 5j)) == repr(5 + 5j)

# Generated at 2022-06-24 17:30:03.302015
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import re
    # unit test for repr(None)
    try:
        var_0 = get_shortish_repr(None)
    except:
        print('test_get_shortish_repr(); expected <NoneType>; got <None>')
        raise AssertionError
    if not isinstance(var_0, type(None)):
        print('test_get_shortish_repr(); expected <NoneType>; got <NoneType>')
        raise AssertionError
    # unit test for repr(1)
    try:
        var_1 = get_shortish_repr(1)
    except:
        print('test_get_shortish_repr(); expected <str>; got <None>')
        raise AssertionError
    if not isinstance(var_1, str):
        print

# Generated at 2022-06-24 17:30:09.155552
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    with open('/home/mongo/Documents/bookmarks.json', 'w') as var_1:
        for var_2 in test_case_0():
            write = getattr(var_1, 'write', None)
            var_2 = '{}\n'.format(var_2)
            write(var_2)

test_WritableStream_write()

# Generated at 2022-06-24 17:30:16.960372
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    var_1 = get_shortish_repr('\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    ')

    var_2 = get_shortish_repr(('\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    ',))

    var_3 = get_shortish_repr(('\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    ',), max_length=35)


# Generated at 2022-06-24 17:30:25.342560
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    var_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_1 = get_shortish_repr(var_0)
    var_2 = 'Unit test for method :meth:`WritableStream.write`. Make sure it works well with all kinds of `iterable_type`.'
    assert var_1 == var_2

test_case_0()
test_get_shortish_repr()

# Generated at 2022-06-24 17:30:45.274038
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_0 = get_shortish_repr(str_0)
    assert var_0 == "'\\n    Unit test for method :meth:`WritableStream.write`.\\n\\n    Make sure it works well with all kinds of `iterable_type`.\\n    '"

# Generated at 2022-06-24 17:30:56.580141
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    def get_result(*args, **kwargs):
        return WritableStream.write(self=None, *args, **kwargs)

    self = None
    s = 'hoo'
    get_result(self, s)
    s = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    get_result(self, s)
    s = 'hoo\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    get_result(self, s)

# Generated at 2022-06-24 17:31:01.812051
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Make sure it works well with all kinds of iterable_type
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    var_0 = get_shortish_repr(str_0, max_length=200)

# Generated at 2022-06-24 17:31:12.589629
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    print('Testing unit test for method :meth:`WritableStream.write`.\n')
    print('Make sure it works well with all kinds of `iterable_type`.')
    assert len(get_shortish_repr('\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    ')) == 111
    assert len(get_shortish_repr('\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    ')) == 111

# Generated at 2022-06-24 17:31:17.331927
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    for iterable_type in (list, set, tuple, dict, range):
        for _ in range(2):
            _test_WritableStream_write(iterable_type)


# Generated at 2022-06-24 17:31:24.309532
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = '\n    Unit test for method :meth:`WritableStream.write`.\n\n    Make sure it works well with all kinds of `iterable_type`.\n    '
    assert isinstance(str_0, str)
    var_0 = get_shortish_repr(str_0)
    assert isinstance(var_0, str)
    assert var_0 == '\'\\n    Unit test for method :meth:`WritableStream.write`.\\n\\n    Make sure it works well with all kinds of `iterable_type`.\\n    \''
