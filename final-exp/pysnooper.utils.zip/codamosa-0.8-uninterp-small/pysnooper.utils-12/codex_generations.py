

# Generated at 2022-06-24 17:21:31.137013
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test that a write to sys.stdout can be done without errors.
    sys.stdout.write("hello world")
    sys.stdout.write("\n")

# Generated at 2022-06-24 17:21:33.137319
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    with open('test_writable_stream.txt', 'w') as f:
        f.write('')


# Generated at 2022-06-24 17:21:35.274624
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream_0 = sys.stdout
    var_0 = stream_0.write('')

# Generated at 2022-06-24 17:21:45.122414
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    print('  Testing: get_shortish_repr')
    custom_repr = tuple()
    item = None
    test_get_shortish_repr_var_0 = get_shortish_repr(item, custom_repr)
    assert test_get_shortish_repr_var_0 == 'None'
    item, max_length = None, 4
    test_get_shortish_repr_var_1 = get_shortish_repr(item, custom_repr, max_length)
    assert test_get_shortish_repr_var_1 == 'Non...'
    item, max_length = None, 2
    test_get_shortish_repr_var_2 = get_shortish_repr(item, custom_repr, max_length)
    assert test_get_

# Generated at 2022-06-24 17:21:59.256765
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # This is a simple test of the output of `get_shortish_repr`
    if get_shortish_repr('abc') != 'abc':
        return False

    # This is a simple test of the output of `get_shortish_repr`
    if get_shortish_repr((1, 2, 3)) != '(1, 2, 3)':
        return False

    # This is a simple test of the output of `get_shortish_repr`
    if get_shortish_repr(['a', 'b', 'c']) != "['a', 'b', 'c']":
        return False

    # This is a simple test of the output of `get_shortish_repr`

# Generated at 2022-06-24 17:22:00.703616
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    stream.write('foo')

# Generated at 2022-06-24 17:22:03.821569
# Unit test for function get_repr_function
def test_get_repr_function():
    bool_0 = True
    var_0 = get_repr_function('str_0', 'list_0')


# Generated at 2022-06-24 17:22:08.320713
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()


# Generated at 2022-06-24 17:22:14.393333
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((lambda x: False, None))) == repr
    assert get_repr_function(1, ((lambda x: False, lambda x: x))) == repr
    assert callable(get_repr_function(1, ((lambda x: True, lambda x: x))))
    assert get_repr_function(1, ((1, lambda x: x)))() == 1
    assert get_repr_function(1, ((int, lambda x: x)))() == 1
    assert get_repr_function(1, ((1, lambda x: x), (int, lambda x: x)))() == 1
    assert callable(get_repr_function(1, ((1, lambda x: x), (int, None))))
    assert get_repr_function(1, ((int, None))) == repr

# Generated at 2022-06-24 17:22:18.365473
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .test.fake_stream import FakeStream
    var_0 = FakeStream()
    var_1 = 'test'
    var_0.write(var_1)


# Generated at 2022-06-24 17:22:32.417224
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [
        (lambda x: isinstance(x, float), float.hex),
        (lambda x: isinstance(x, int), hex),
        (lambda x: isinstance(x, str), lambda x: '*' + x)
    ]
    assert get_repr_function(2.2, custom_repr) is float.hex
    assert get_repr_function(2.2, custom_repr) != repr
    assert get_repr_function(22, custom_repr) is hex
    assert get_repr_function(22, custom_repr) != repr
    assert get_repr_function('str', custom_repr) != repr
    assert get_repr_function('str', custom_repr)('str') == '*str'
    assert get_repr_function

# Generated at 2022-06-24 17:22:35.364233
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(test_case_0(), ()) == str

# Generated at 2022-06-24 17:22:44.416308
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr(str_0) == '\'\''
    assert get_shortish_repr(str_0, max_length=8) == '\'\''
    assert get_shortish_repr(str_0, max_length=7) == '\'\''
    assert get_shortish_repr(str_0, max_length=6) == '\'\''
    assert get_shortish_repr(str_0, max_length=5) == '\'\''

    assert get_shortish_repr(str_0, normalize=True) == '\'\''
    assert get_shortish_repr(str_0, max_length=8, normalize=True) == '\'\''

# Generated at 2022-06-24 17:22:55.782567
# Unit test for function get_repr_function
def test_get_repr_function():
    import sys
    import pytest


# Generated at 2022-06-24 17:23:00.211966
# Unit test for function get_repr_function
def test_get_repr_function():
    print('Test #1')
    custom_repr = [int, str, float]
    assert get_repr_function(1, custom_repr) == int

    print('Test #2')
    assert get_repr_function(1.1, custom_repr) == float

    print('Test #3')
    assert get_repr_function('a', custom_repr) == str

    print('Test #4')
    assert get_repr_function([1, 2, 3], custom_repr) == repr

    print('Test #5')



# Generated at 2022-06-24 17:23:05.861854
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import StringIO
    WritableStream.register(StringIO.StringIO)
    assert issubclass(StringIO.StringIO, WritableStream)
    ws = StringIO.StringIO()
    ws.write('abcde')
    assert(ws.getvalue() == 'abcde')



# Generated at 2022-06-24 17:23:08.154513
# Unit test for function get_repr_function
def test_get_repr_function():
    r = get_repr_function (test_case_0, ())
    assert r is repr


# Generated at 2022-06-24 17:23:16.478365
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .shortern_repr import get_shortish_repr
    print(get_shortish_repr(str_0, custom_repr=(), max_length=None, normalize=False))
    print(get_shortish_repr(str_0, custom_repr=(), max_length=3, normalize=False))
    print(get_shortish_repr(str_0, custom_repr=(), max_length=3, normalize=True))
    return 0

test_case_0()
test_get_shortish_repr()

# Generated at 2022-06-24 17:23:19.033722
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    ws = WritableStream()
    ws.write('5')
    ws.write(str_0)
    ws.write('a')



# Generated at 2022-06-24 17:23:22.990259
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    result = WritableStream.write(str_0)
    assert isinstance(result, string_types)
    result = WritableStream.write(str_0)
    assert isinstance(result, string_types)
    result = WritableStream.write(str_0)
    assert isinstance(result, string_types)



# Generated at 2022-06-24 17:23:28.109734
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .compat import assert_equal
    # Check that the function works on a simple example:
    assert_equal(get_shortish_repr('abcde', max_length=3), 'abc...')



# Generated at 2022-06-24 17:23:32.566057
# Unit test for function get_repr_function
def test_get_repr_function():
    pass

    # Call function get_repr_function
#    get_repr_function(arg_0, arg_1)



# Generated at 2022-06-24 17:23:33.935916
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass



# Generated at 2022-06-24 17:23:42.107830
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\x00\x00\x00') == '\x00\x00\x00', shitcode('\x00\x00\x00')
    assert shitcode(u'\x00\x00\x00') == '\x00\x00\x00', shitcode(u'\x00\x00\x00')
    assert shitcode('\x00\x01\x02') == '\x00\x01\x02'
    assert shitcode(u'\x00\x01\x02') == '\x00\x01\x02'
    assert shitcode('\xFF\xFF\xFF') == '\xFF\xFF\xFF', shitcode('\xFF\xFF\xFF')

# Generated at 2022-06-24 17:23:52.686333
# Unit test for function get_repr_function
def test_get_repr_function():
    my_int = 5
    assert get_repr_function(my_int, ((int, str),)) == str
    assert get_repr_function(my_int, ((int, str),),) == str
    assert get_repr_function(my_int, ((int, str))) == str
    assert get_repr_function(5, (lambda y: y >= 5, str)) == str
    assert get_repr_function(5, ((lambda y: y >= 5, str))) == str
    assert get_repr_function(5, ((lambda y: y >= 5, str))) == str
    assert get_repr_function(5, ((lambda y: y >= 5, str)),) == str
    assert get_repr_function(5, (lambda y: y >= 5, str),) == str

import re


# Generated at 2022-06-24 17:23:55.879871
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    r0 = WritableStream.write(sys.stdout, 'hello world!')
    assert r0 is None


# Generated at 2022-06-24 17:24:06.013984
# Unit test for function get_repr_function
def test_get_repr_function():
    def mock_repr(item):
        return item
    def mock_repr_2(item):
        return item + 1
    mock_custom_repr = (
        (lambda x: True, mock_repr),
        (2, mock_repr_2)
    )

    bool_0 = True
    int_0 = 0
    str_0 = '0'
    tuple_0 = ()

    # general
    assert get_repr_function(bool_0, custom_repr=()) == repr
    assert get_repr_function(int_0, custom_repr=()) == repr
    assert get_repr_function(str_0, custom_repr=()) == repr
    assert get_repr_function(tuple_0, custom_repr=()) == repr

    # custom_repr

# Generated at 2022-06-24 17:24:13.732250
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .Assert import Assert
    var_1 = get_shortish_repr(test_get_shortish_repr, max_length=None, normalize=True)
    Assert(var_1, 'function get_shortish_repr')
    var_1 = get_shortish_repr('test string', max_length=None, normalize=True)
    Assert(var_1, 'test string')
    var_1 = get_shortish_repr('test string', max_length=3, normalize=True)
    Assert(var_1, 'tes...ing')

# Generated at 2022-06-24 17:24:17.194446
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Necessary objects
    # No arguments
    # Expected value
    expected_value = None
    # Call function
    stream = print
    assert stream.write(expected_value) == expected_value



# Generated at 2022-06-24 17:24:23.883010
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(42, max_length=6) == '42'
    assert get_shortish_repr(42, max_length=6) == '42'
    assert get_shortish_repr(42) == u'42'
    assert get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert get_shortish_repr(set([1, 2, 3])) == '{1, 2, 3}'
    assert get_shortish_repr([1, 2, 3], max_length=6) == '[1, 2...'
    assert get_shortish_repr(set([1, 2, 3]), max_length=6) == '{1, 2...'

# Generated at 2022-06-24 17:24:35.218117
# Unit test for function get_repr_function
def test_get_repr_function():
    r = get_repr_function(sys.stdout, custom_repr=[])
    assert callable(r)
    r = get_repr_function(sys.stdout, custom_repr=[(lambda x: True, lambda x: 'yo')])
    assert r(1) == 'yo'
    r = get_repr_function(sys.stdout, custom_repr=[(lambda x: False, lambda x: 'yo')])
    assert r(1) == '1'
    r = get_repr_function(sys.stdout, custom_repr=[(lambda x: False, lambda x: 'yo'), (lambda x: True, lambda x: 'yoyo')])
    assert r(1) == 'yoyo'

# Generated at 2022-06-24 17:24:43.082230
# Unit test for function get_repr_function
def test_get_repr_function():
    # create a simple custom repr function
    def repr_func(x):
        return str(x) + '_appended'

    # create an object to test
    test_obj = 'test_obj'

    # create a simple custom repr list
    custom_repr = [(lambda x: isinstance(x, str), repr_func)]

    # call the function
    repr_func = get_repr_function(test_obj, custom_repr)

    # make sure its the correct function
    assert repr_func == repr_func



# Generated at 2022-06-24 17:24:45.538928
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(bool_0, ) == repr
    assert get_repr_function(var_0, ) == repr


# Generated at 2022-06-24 17:24:48.059497
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self):
            pass

    assert isinstance(A(), WritableStream)


# Generated at 2022-06-24 17:24:57.703314
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from copy import copy
    from pickle import dumps
    from io import BytesIO
    from garlicsim.general_misc.queues import Queue
    from garlicsim.general_misc.context_manager import ContextManager
    from garlicsim.general_misc.cache_dict import CacheDict
    from garlicsim.general_misc.nifty_collections import OrderedSet
    from garlicsim.general_misc.third_party import limitedtuple
    from garlicsim.general_misc import address_tools
    import garlicsim.general_misc.infinity
    import threading
    import tempfile
    import datetime
    import random
    import time
    import os
    import logging

    def test_case_0():
        var_0 = [1]
        var_1 = get_shortish_repr(var_0)

# Generated at 2022-06-24 17:24:59.424825
# Unit test for function get_repr_function
def test_get_repr_function():
    repr_function = get_repr_function("Hello world", [])
    repr_function("Hello world")


# Generated at 2022-06-24 17:25:01.075142
# Unit test for function shitcode
def test_shitcode():
    assert test_case_0() == True


# Generated at 2022-06-24 17:25:05.260349
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(NotImplemented, []) == repr
    assert get_repr_function(1, [(lambda x: True, int)]) == int
    assert get_repr_function(1, [(lambda x: False, int), (lambda x: True, str)]) == str
    assert get_repr_function(1, []) == repr


# Generated at 2022-06-24 17:25:07.484634
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert isinstance(WritableStream.__subclasshook__, classmethod)



# Generated at 2022-06-24 17:25:16.666612
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(test_case_0, []) is repr

# Generated at 2022-06-24 17:25:22.081227
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(test_get_repr_function, ()) == repr


# Generated at 2022-06-24 17:25:23.604537
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    a = WritableStream
    a.write(1)
    
    
    
    

# Generated at 2022-06-24 17:25:28.740263
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MockWritableStream(WritableStream):
        def write(self, s):
            pass

    mock_writable_stream = MockWritableStream()

    # Unit test for method write of class WritableStream
    mock_writable_stream.write('test string')

# Generated at 2022-06-24 17:25:33.094164
# Unit test for function shitcode
def test_shitcode():
    bool_0 = True
    var_0 = shitcode(bool_0)
    assert var_0 == 'True'
    str_0 = 'Some random text with \x00 and \x01'
    var_1 = shitcode(str_0)
    assert var_1 == 'Some random text with ? and ?'
    str_1 = 'זה סימון מקום של ברית'
    var_2 = shitcode(str_1)
    assert var_2 == '????? ???? ???? ????? ????'


# Generated at 2022-06-24 17:25:35.791423
# Unit test for function shitcode
def test_shitcode():
    var_2 = '剑指offer'
    var_1 = shitcode(var_2)
    var_3 = '\u5251\u653boffer'
    assert var_1 == var_3


# Generated at 2022-06-24 17:25:48.296771
# Unit test for function get_repr_function
def test_get_repr_function():
    # type: () -> None
    from .test_tools import asserted_repr, list_with_index_repr, tuple_with_index_repr, set_with_index_repr
    assert get_repr_function('abc', []) is repr
    assert get_repr_function('abc', [(str, lambda s: '"{}"'.format(s))]) == '"abc"'
    assert get_repr_function('abc', [(str, lambda s: '"{}"'.format(s)),
                                     (int, lambda s: 'int({})'.format(s))]) == '"abc"'
    assert get_repr_function('abc', [(str, lambda s: '"{}"'.format(s)),
                                     (list, lambda s: 'list({})'.format(s))]) == '"abc"'
   

# Generated at 2022-06-24 17:26:00.813350
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    #assert get_shortish_repr(None, None) is None
    assert get_shortish_repr(1, (int, lambda x: 'int %d' % x), 8) == 'int 1'
    assert get_shortish_repr(1, (str, lambda x: 'str %s' % x), 8) == '1'
    assert get_shortish_repr(1, (str, lambda x: 'str %s' % x), 1) == '1'
    assert get_shortish_repr(1, (int, lambda x: 'int %d' % x), None) == 'int 1'
    assert get_shortish_repr(1, (int, lambda x: 'int %d' % x), 0) == 'i'

# Generated at 2022-06-24 17:26:03.573073
# Unit test for function get_repr_function
def test_get_repr_function():
    test_get_repr_function_0 = (lambda item: item)
    var_0 = get_repr_function(None, test_get_repr_function_0)


# Generated at 2022-06-24 17:26:06.084824
# Unit test for function shitcode
def test_shitcode():
    bool_0 = bool(1)
    var_0 = shitcode(bool_0)
    assert var_0 == bool_0



# Generated at 2022-06-24 17:26:10.977411
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    var_3 = "something"
    if (var_3):
        try:
            return var_3
        except Exception:
            print("Exception in user code:")
            print('-'*60)
            traceback.print_exc(file=sys.stdout)
            print('-'*60)
            raise
    else:
        return False



# Generated at 2022-06-24 17:26:25.520556
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('a', (('b', 'c'), )) == repr
    assert get_repr_function('a', (('b', 'c'), (str, 'd'))) == 'd'
    assert get_repr_function('a', (('b', 'c'), (str, 'd'),)) == 'd'
    assert get_repr_function('a', (('b', 'c'), (str, 'd'))) == 'd'
    assert get_repr_function('a', (('b', 'c'), (str, 'd'))) == 'd'
    assert get_repr_function('a', (('b', 'c'), (str, 'd'))) == 'd'

# Generated at 2022-06-24 17:26:27.225105
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = StringIO()
    stream.write("Testing")


# Generated at 2022-06-24 17:26:37.068282
# Unit test for function get_repr_function
def test_get_repr_function():
    assert (get_repr_function('123') == repr)
    assert (get_repr_function(u'123') == repr)
    assert (get_repr_function(1) == repr)
    assert (get_repr_function(1.0) == repr)
    assert (get_repr_function(1j) == repr)
    assert (get_repr_function((1, 2)) == repr)
    assert (get_repr_function({1, 2}) == repr)
    assert (get_repr_function({}) == repr)
    assert (get_repr_function([]) == repr)
    assert (get_repr_function(['']) == repr)
    assert (get_repr_function(None) == repr)


# Generated at 2022-06-24 17:26:44.108309
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # AssertionError: None != u''
    assert get_shortish_repr(None, max_length=5) == None
    # AssertionError: u'abcdef' != u'abcde'
    assert get_shortish_repr('abcdef', max_length=5) == u'abcde'
    # AssertionError: u'ABCDEFGHIJKLMN...KLM' != u'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert get_shortish_repr('ABCDEFGHIJKLMNOPQRSTUVWXYZ', max_length=20) == u'ABCDEFGHIJKLMN...KLM'
    # AssertionError: u'' != u''
    assert get_shortish_repr('') == u''
    # Assertion

# Generated at 2022-06-24 17:26:54.602642
# Unit test for function get_repr_function
def test_get_repr_function():
    # Create a local scope so we can play with the vars that were created
    # during the run
    def get_vars_from_local_scope():
        return dict(locals())
    # We create a local scope on purpose, so that we'll run the code of the
    # function
    local_vars = get_vars_from_local_scope()

# Generated at 2022-06-24 17:27:06.217829
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    s = "I am a very long string"
    assert get_shortish_repr(s, max_length=30) == s
    assert get_shortish_repr(s, max_length=20) == "I am a ver..."
    assert get_shortish_repr(s, max_length=10) == "I am..."
    assert get_shortish_repr(s, max_length=0) == ""
    assert get_shortish_repr((1, 2, 3, 4), max_length=3,
                             custom_repr=((tuple, str),)) == "[1, 2, 3]"
    assert get_shortish_repr(1, max_length=3, custom_repr=((tuple, str),)) == \
                                                                          "1"


# Generated at 2022-06-24 17:27:16.650780
# Unit test for function get_repr_function
def test_get_repr_function():
    match = False

    def repr_function(arg_1):
        return '{}'.format(arg_1)

    def repr_function_1(arg_1):
        return '{}'.format(arg_1)

    match = repr_function is repr_function_1
    assert match == True

    def repr_function_2(arg_1):
        return '{}'.format(arg_1)

    match = repr_function_1 is repr_function_2
    assert match == True

    match = repr_function_2 is repr_function_2
    assert match == True


# Generated at 2022-06-24 17:27:18.981224
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    item_repr_0 = 'hello world'
    assert get_shortish_repr(item_repr_0, custom_repr=(), normalize=True) == 'hello world'


# Generated at 2022-06-24 17:27:22.700814
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.5, [(int, str)]) == repr
    assert get_repr_function('hello', [(int, str)]) == repr



# Generated at 2022-06-24 17:27:29.087921
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .testing import assert_equal
    from .WritableStream import WritableStream

    class A(WritableStream):
        #def write(self, s):
        #    pass
        pass

    a = A()

    assert_equal(WritableStream.__subclasshook__(A), True)
    assert a.write('Hello') == None



# Generated at 2022-06-24 17:27:41.602304
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (int, lambda x: '!'),
        (str, lambda x: '#'),
    )
    assert get_repr_function(0, custom_repr)() == '!'
    assert get_repr_function('abc', custom_repr)() == '#'
    assert get_repr_function(3.5, custom_repr)() == '3.5'
    assert get_repr_function(set([0]), custom_repr)() == '{0}'



# Generated at 2022-06-24 17:27:50.808711
# Unit test for function get_shortish_repr

# Generated at 2022-06-24 17:27:57.362915
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(5, (), None) == '5'
    assert get_shortish_repr(5, (), 6) == '5'
    assert get_shortish_repr(5, (), 7) == '5'
    assert get_shortish_repr(5, (), 8) == '5'
    assert get_shortish_repr(5, (), 9) == '5'
    assert get_shortish_repr(5, (), 10) == '5'
    assert get_shortish_repr(5, (), 11) == '5'
    assert get_shortish_repr(5, (), 12) == '5'
    assert get_shortish_repr(5, (), 13) == '5'
    assert get_shortish_repr(5, (), 14) == '5'

# Generated at 2022-06-24 17:28:03.728926
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[(lambda x: True, lambda x: 'a')]) == 'a'
    assert get_repr_function(1, custom_repr=[(lambda x: False, lambda x: 'a')]) == repr
    assert get_repr_function(1, custom_repr=[(1, lambda x: 'a')]) == 'a'
    assert get_repr_function(0, custom_repr=[(1, lambda x: 'a')]) == repr


# Generated at 2022-06-24 17:28:05.837073
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert hasattr(WritableStream, 'write')
    assert callable(getattr(WritableStream, 'write'))


# Generated at 2022-06-24 17:28:06.740728
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_0 = WritableStream()

# Generated at 2022-06-24 17:28:09.234376
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStream_0(WritableStream):
        def write(self, _s):
            var_0 = _s # var_0 is _s


# Generated at 2022-06-24 17:28:17.632384
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """Test for method WritableStream.write"""
    bool_0 = bool()
    bool_1 = bool(bool_0)
    bool_2 = bool(bool_1)
    bool_3 = bool()
    bool_4 = bool(bool_3)
    bool_5 = bool()
    bool_6 = bool(bool_5)
    bool_7 = bool()
    bool_8 = bool(bool_7)
    bool_9 = bool(bool_8)
    bool_10 = bool(bool_9)
    bool_11 = bool(bool_10)
    bool_12 = bool(bool_11)
    bool_13 = bool(bool_12)
    bool_14 = bool(bool_13)
    bool_15 = bool(bool_14)
    bool_16 = bool()
    bool_

# Generated at 2022-06-24 17:28:22.371593
# Unit test for function get_repr_function
def test_get_repr_function():
    try:
        from .test_get_repr_function import TestCase
        assert (get_repr_function('hello world', TestCase.custom_repr) == TestCase.str_repr_function)
    except ImportError:
        pass



# Generated at 2022-06-24 17:28:24.178720
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import tempfile
    file_0 = tempfile.TemporaryFile()

# Generated at 2022-06-24 17:28:46.815773
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(0) == '0'
    assert get_shortish_repr(0,max_length=5) == '0'
    assert get_shortish_repr(0,max_length=3) == '0'
    assert get_shortish_repr(0,max_length=2) == '0'
    assert get_shortish_repr(0,max_length=1) == '...'
    assert get_shortish_repr(1, custom_repr=[(int, lambda i: 'int'),
                                             (str, lambda s: 'str')]) == 'int'

# Generated at 2022-06-24 17:28:49.750307
# Unit test for function get_repr_function
def test_get_repr_function():
    repr_function = get_repr_function(var_0, ((type(var_0), str),))

# Generated at 2022-06-24 17:28:55.704803
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, lambda x: str(x)),)) == str
    assert get_repr_function(1.0, ((int, lambda x: str(x)),)) == repr
    assert get_repr_function(1, ((type, lambda x: 'a_str'),)) == repr



# Generated at 2022-06-24 17:29:01.735286
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    custom_repr = ((bool, lambda x:'boolean'),)
    item = True
    max_length = 50
    normalize = True
    expected_type = "<class 'str'>"
    expected_return = 'boolean'
    actual_return = get_shortish_repr(item, custom_repr, max_length, normalize)
    assert_type = type(actual_return) == expected_type
    assert_return = actual_return == expected_return
    if not (assert_type and assert_return):
        raise AssertionError("get_shortish_repr(item, custom_repr, max_length, normalize) returned \"%s\", not \"%s\"" % (actual_return, expected_return))



# Generated at 2022-06-24 17:29:05.323722
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    def write(s):
        return stream.write(s)
    assert_compare_strict(stream.write, write)



# Generated at 2022-06-24 17:29:13.434385
# Unit test for function get_repr_function
def test_get_repr_function():
# Test Case #0
    test_case_0()

# Test Case #1
    custom_repr = (
    ('hello', lambda x: 'world'),
    ('world', lambda x: 'hello'),
    (int, lambda x: 'number'),
    )
    var_0 = get_repr_function(
    'hello',
    custom_repr,
    )
    var_1 = getattr(var_0, '__name__', '')
    var_2 = 'world'
    assert var_1 == var_2

# Test Case #2
    var_0 = get_repr_function(
    'world',
    custom_repr,
    )
    var_1 = getattr(var_0, '__name__', '')
    var_2 = 'hello'
    assert var

# Generated at 2022-06-24 17:29:18.345075
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    sys.stdout.write(u'test_WritableStream_write')
    test_case = WritableStream()
    var_0 = test_case.write
    sys.stdout.write(u'[{}]'.format(var_0))
    sys.stdout.write(u'\n')


# Generated at 2022-06-24 17:29:29.889426
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import sys
    import random
    for i in range(100):
        str_0 = str(random.randint(-1000, 1000))
        var_0 = shitcode(str_0)
        assert normalize_repr(repr(var_0)) == normalize_repr("'{}'".format(str_0))

    int_0 = sys.maxsize
    var_1 = shitcode(int_0)
    assert normalize_repr(repr(var_1)) == normalize_repr("{}".format(int_0))

    list_0 = [1, 2, 3]
    var_2 = shitcode(list_0)
    assert normalize_repr(repr(var_2)) == normalize_repr("[1, 2, 3]")

# Generated at 2022-06-24 17:29:32.071049
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    bool_0 = True
    var_0 = get_shortish_repr(bool_0)


# Generated at 2022-06-24 17:29:41.112550
# Unit test for function get_repr_function
def test_get_repr_function():
    import string
    import datetime
    import copy
    custom_repr = (
        (lambda x: isinstance(x, int), str),
        (lambda x: isinstance(x, string.ascii_letters), str),
        (lambda x: isinstance(x, datetime.datetime),
            lambda x: str(x.isocalendar())),
        (lambda x: isinstance(x, datetime.date),
            lambda x: str(x.isocalendar())),
        (lambda x: isinstance(x, datetime.time),
            lambda x: str(x.isocalendar())),
        (lambda x: isinstance(x, copy.deepcopy),
            lambda x: str(x.isocalendar())),
    )
    int_0 = 0
    string_0 = 'hello'
    dat

# Generated at 2022-06-24 17:30:08.122338
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, ((int, 'abc'))) == 'abc'
    assert get_repr_function(0.0, ((int, 1))) == 1
    assert get_repr_function(0.0, ((int, 1), (float, 2.0))) == 2.0


# Generated at 2022-06-24 17:30:10.068269
# Unit test for function get_repr_function
def test_get_repr_function():
    bool_0 = True
    var_0 = get_repr_function(bool_0)


# Generated at 2022-06-24 17:30:12.155887
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Define arguments
    # Declare object of the class WritableStream and call its method write
    # assert the result
    pass


# Generated at 2022-06-24 17:30:17.313229
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    bool_1 = False
    var_1 = WritableStream()
    assert isinstance(var_1, WritableStream)
    try:
        var_1.write(bool_1)
    except NotImplementedError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-24 17:30:19.308777
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    with pytest.raises(TypeError):
        pass



# Generated at 2022-06-24 17:30:21.729740
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    print(bool_0)
    print(var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:30:27.365926
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_1 = sys.stdout
    try:
        var_1.write("This is a test")
    except IOError as var_2:
        print("IOError: {}".format(var_2))
    except OSError as var_3:
        print("OSError: {}".format(var_3))
    except ValueError as var_4: # IronPython weirdness
        print("ValueError: {}".format(var_4))



# Generated at 2022-06-24 17:30:33.191743
# Unit test for function get_repr_function
def test_get_repr_function():
    from random import random
    from math import isnan
    from queue import Queue
    from .strstrings import MultiLineString
    from .collections import OrderedDict
    from .iteration import Progress
    from .sequence_tools import OrderedSet
    from .numbers import Number
    from .iter_tools import one
    from .builtins import get_all_subclasses

    all_subclasses = get_all_subclasses(object)
    classes = tuple(sorted(all_subclasses, key=lambda x: str(x)))


# Generated at 2022-06-24 17:30:36.588748
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda item: isinstance(item, str), shitcode),
    )
    assert get_repr_function('x', custom_repr) is shitcode
    assert get_repr_function(False, custom_repr) is repr



# Generated at 2022-06-24 17:30:38.230365
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert hasattr(WritableStream.write, "__call__")
