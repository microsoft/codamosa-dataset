

# Generated at 2022-06-24 17:21:32.242511
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .stubs.WritableStream import WritableStream
    WritableStream_write = WritableStream.write
    my_writable_stream = WritableStream()
    s = 'abc'
    WritableStream_write.im_func(my_writable_stream, s)


# Generated at 2022-06-24 17:21:36.778270
# Unit test for function shitcode
def test_shitcode():
    shitcode("Hello world")
    shitcode("Привет мир")
    shitcode("👩🏻‍🦱😬")
    shitcode("🧨")
    shitcode("🤪")
    #
    #
    #
    #
    #
    #

# Generated at 2022-06-24 17:21:46.323173
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    print("TESTING get_shortish_repr")
    var_0 = 30
    var_1 = get_shortish_repr(var_0)
    var_2 = '30'
    var_3 = (var_1 == var_2)
    assert var_3
    var_4 = normalize_repr(var_1)
    var_5 = (var_4 == var_2)
    assert var_5
    var_6 = 'a'
    var_7 = get_shortish_repr(var_6)
    var_8 = 'a'
    var_9 = (var_7 == var_8)
    assert var_9
    var_10 = normalize_repr(var_7)
    var_11 = (var_10 == var_8)
    assert var_

# Generated at 2022-06-24 17:21:49.183320
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    test_case_0()



# Generated at 2022-06-24 17:21:54.976172
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    int_0 = 1
    str_0 = 'This is a test string'
    str_1 = get_shortish_repr(str_0, (), 100)
    str_2 = get_shortish_repr(int_0, (), 10)
    int_1 = get_shortish_repr(int_0, (), None)


# Generated at 2022-06-24 17:22:05.949625
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # We shall mimic a `TextWrapper` class as a `WritableStream`:

    class TextWrapper:
        def __init__(self, max_length=80, indent=0, initial_indent='',
                     subsequent_indent='', break_long_words=True, break_on_hyphens=True):
            for attr_name in (
                'max_length', 'indent', 'initial_indent', 'subsequent_indent',
                'break_long_words', 'break_on_hyphens'
            ):
                setattr(self, attr_name, locals()[attr_name])
            self.current_indent = initial_indent
            self.current_length = 0

        def write(self, s):
            assert isinstance(s, string_types)
            # Do not include spaces

# Generated at 2022-06-24 17:22:07.159103
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert callable(WritableStream.write)


# Generated at 2022-06-24 17:22:11.350958
# Unit test for function get_repr_function
def test_get_repr_function():
    from .test_toolbox import assert_equal
    assert_equal(get_repr_function(None, {}), shite)
    assert_equal(get_repr_function(None, ((type(None), lambda: 'None'),)),
                 lambda x: 'None')


# Generated at 2022-06-24 17:22:21.719776
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .pycompat import HAS_PYTHON2
    if HAS_PYTHON2:
        from string import printable
    else:
        from string import printable as printable_string
        import unicodedata
        printable = [
            unicodedata.normalize('NFKD', c)[0] for c in printable_string
        ]

    assert get_shortish_repr(b'\x01', max_length=3) == 'b\'\\x01\''
    assert get_shortish_repr(b'\x01') == "b'\\x01'"
    assert get_shortish_repr(b'\x01', max_length=2) == 'b\''
    assert get_shortish_repr('hellow') == "'hellow'"
    assert get_shortish_

# Generated at 2022-06-24 17:22:30.963950
# Unit test for function get_repr_function
def test_get_repr_function():
    """
    Test get_repr_function with basic scenario
    """
    int_0 = 3335
    tuple_0 = (4, 0, 0)
    list_0 = []
    dict_0 = {}
    str_0 = 'Seventy'
    str_1 = 'a'

# Generated at 2022-06-24 17:22:35.648071
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    print("test_WritableStream_write not implemented")


# Generated at 2022-06-24 17:22:44.416205
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    x = list(range(0, 6))
    x[0] = None
    x[1] = 12
    x[2] = [True, ('a', 2)]
    x[3] = {'b': 2, 'a': 1}
    x[4] = b'a'
    x[5] = lambda x: x
    expected = [
        'None',
        '12',
        "[True, ('a', 2)]",
        "{'a': 1, 'b': 2}",
        "b'a'",
        '<function <lambda> at 0x...>'
    ]
    for i in range(0, len(x)):
        assert get_shortish_repr(x[i]) == expected[i]

# Generated at 2022-06-24 17:22:46.729057
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    # write is not implemented
    assert hasattr(WritableStream,'write')
    assert callable(getattr(WritableStream, "write", None))
    assert getattr(WritableStream, "write", None).__doc__



# Generated at 2022-06-24 17:22:47.829904
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_0 = WritableStream()
    test_case_0(var_0)


# Generated at 2022-06-24 17:22:58.248885
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    print('Testing function get_shortish_repr...')
    assert get_shortish_repr(
        {'foo': 1, 'bar': 2}, max_length=12, normalize=True
    ) == "{'bar': 2, 'foo': 1}"
    assert get_shortish_repr(
        {'foo': 1, 'bar': 2}, max_length=11, normalize=True
    ) == "{'bar': 2, 'fo..."
    assert get_shortish_repr(
        {'foo': 1, 'bar': 2}, max_length=5, normalize=True
    ) == "{..."
    assert get_shortish_repr(
        {'foo': 1, 'bar': 2}, max_length=0, normalize=True
    ) == "..."
    assert get_shortish_re

# Generated at 2022-06-24 17:23:10.349214
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    complex_0 = None
    var_0 = get_shortish_repr(complex_0)
    assert var_0 == 'None'
    complex_1 = ''
    var_1 = get_shortish_repr(complex_1)
    assert var_1 == "''"
    complex_2 = 'abc'
    var_2 = get_shortish_repr(complex_2)
    assert var_2 == "'abc'"
    complex_3 = 'a'
    var_3 = get_shortish_repr(complex_3)
    assert var_3 == "'a'"
    complex_4 = 1
    var_4 = get_shortish_repr(complex_4)
    assert var_4 == '1'
    complex_5 = (1,)
    var_5 = get_shortish_re

# Generated at 2022-06-24 17:23:20.611399
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr("'Hello world!'", max_length=12) == "'Hello..."
    assert get_shortish_repr(None, max_length=12) == 'None'
    assert get_shortish_repr({}, max_length=12) == '{}'
    assert get_shortish_repr([], max_length=12) == '[]'
    assert get_shortish_repr((), max_length=12) == '()'
    assert get_shortish_repr(b'a', max_length=12) == "b'a'"
    assert get_shortish_repr(1, max_length=12) == '1'
    assert get_shortish_repr(1.0, max_length=12) == '1.0'
    assert get_shortish

# Generated at 2022-06-24 17:23:23.372428
# Unit test for function shitcode
def test_shitcode():
    # Place your code here to test shitcode
    pass # remove or comment out this line if you wish to test the code



# Generated at 2022-06-24 17:23:28.976248
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    _test_coverage = 1

    try:
        custom_repr = None

        max_length = None

        normalize = False

        get_shortish_repr(custom_repr, max_length, normalize)

        normalize = True

        get_shortish_repr(custom_repr, max_length, normalize)
    except:
        _test_coverage = 0
        print("Unhandled exception was raised")



# Generated at 2022-06-24 17:23:36.673568
# Unit test for function shitcode
def test_shitcode():
    # Source: http://stackoverflow.com/questions/983354/how-do-i-make-python-to-print-out-the-dict-with-non-ascii-characters-in-it/1273239#1273239
    d = {'a':u"é", 'b':u"\u2646" } # It's ♂
    l = [u"é", u"\u2646" ]

    try:
        print(d)
        print(l)
    except UnicodeEncodeError:
        pass
    print(shitcode(d))
    print(shitcode(l))
    # Expected result:
    # {'a': u'\xe9', 'b': u'\u2646'}
    # [u'\xe9', u'\u2646']

# Generated at 2022-06-24 17:23:50.413869
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import mock
    repr_function = mock.MagicMock()
    repr_function.return_value = 'SNAKE'
    with mock.patch('python_toolbox.misc_tools.repr_tools.get_repr_function') \
           as get_repr_function:
        get_repr_function.return_value = repr_function
        assert get_shortish_repr('blabla') == 'SNAKE'



# Generated at 2022-06-24 17:23:52.967430
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    file_0 = sys.stdout
    string_0 = 'This is a test.\n'
    file_0.write(string_0)

# Generated at 2022-06-24 17:23:57.266767
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_0 = WritableStream()
    complex_0 = None
    var_0.write(complex_0)


# Generated at 2022-06-24 17:24:01.715743
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    item_repr = 'Eleven'
    truncate_len = 5
    truncate_elm = 'Eleve...'
    assert get_shortish_repr(item_repr, max_length=truncate_len) == truncate_elm



# Generated at 2022-06-24 17:24:03.720868
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class Foo:
        pass
    foo_0 = Foo()
    var_0 = get_shortish_repr(foo_0)



# Generated at 2022-06-24 17:24:05.645328
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    file_0 = None
    var_0 = file_0.write(complex_0)


# Generated at 2022-06-24 17:24:07.630387
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    try:
        test_case_0()
    except AssertionError:
        print('AssertionError raised in test case 0')

# Generated at 2022-06-24 17:24:10.365496
# Unit test for function shitcode
def test_shitcode():
    test_case_0()
    complex_0 = 'a'
    var_1 = shitcode(complex_0)
    print(var_1)


# Generated at 2022-06-24 17:24:13.108001
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    try:
        WritableStream.write(int)
    except TypeError:
        pass
    else:
        assert False, "Unexpected success of method write"



# Generated at 2022-06-24 17:24:14.349493
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    w = sys.stdout  # Note: we're using sys.stdout here, to ensure this test doesn't do anything to stdout.
    w.write('test')
    assert w.write

# Generated at 2022-06-24 17:24:27.092650
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('asğduasgdasgdasghasgdhjasgdasgdkfajsdlfmaklsdfj') == 'asğduasgdasgdasghasgdhjasgdasgdkfajsdlfmaklsdfj'
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(object()) == 'REPR FAILED'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(range(4), max_length=10) == 'range(0, 4)'
    assert get_shortish_repr(range(4), max_length=4) == 'ran...4)'

# Generated at 2022-06-24 17:24:35.402629
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None, max_length=None) == 'None', 'function get_shortish_repr did not work as expected'
    assert get_shortish_repr('str', max_length=None) == "'str'", "function get_shortish_repr did not work as expected"
    assert get_shortish_repr(['a', 1], max_length=None) == "['a', 1]", "function get_shortish_repr did not work as expected"
    assert get_shortish_repr(set([]), max_length=None) == 'set()', 'function get_shortish_repr did not work as expected'

# Generated at 2022-06-24 17:24:37.668628
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import __main__

    __main__.complex_0 = None
    assert get_shortish_repr(complex_0) == 'None'



# Generated at 2022-06-24 17:24:46.008221
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    file_0 = tempfile.TemporaryFile()
    file_0.write('hello')
    file_0.seek(0)
    file_0.write('hellp')
    file_0.seek(0)
    file_0.write('hepll')
    file_0.seek(0)
    file_0.write('heppl')
    file_0.seek(0)
    file_0.write('hllep')
    file_0.seek(0)
    file_0.write('hpple')
    file_0.seek(0)
    file_0.write('pehll')
    file_0.seek(0)
    file_0.write('plehl')


# Generated at 2022-06-24 17:24:51.218987
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    StringIO = getattr(__import__(name='io', fromlist=('StringIO',)), 'StringIO')
    i1 = StringIO()
    w1 = WritableStream.__subclasshook__(StringIO)
    b1 = get_shortish_repr(i1)
    sys.stdout.write(b1)

# Generated at 2022-06-24 17:24:54.605529
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert hasattr(WritableStream, "write")
    assert callable(WritableStream.write)
    assert isinstance(WritableStream.write, classmethod)
    
    

# Generated at 2022-06-24 17:24:57.266665
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass # TODO: implement your test here





# Generated at 2022-06-24 17:24:58.803762
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    complex_0 = None
    var_0 = get_shortish_repr(complex_0)


# Generated at 2022-06-24 17:24:59.950163
# Unit test for function shitcode
def test_shitcode():
    assert test_case_0()



# Generated at 2022-06-24 17:25:07.040773
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr("hi") == "hi"
    assert get_shortish_repr("hi", max_length=20) == "hi"
    assert get_shortish_repr("hello" * 50, max_length=20) == "helloh..."
    assert get_shortish_repr("hello" * 50, max_length=20, normalize=True) == "helloh..."
    assert get_shortish_repr(" " * 10, custom_repr=((lambda x: x == " " * 10,
                                                    lambda x: "<SPACE>"),)) == "<SPACE>"


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:25:15.965414
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    complex_0 = None
    var_0 = WritableStream.write(complex_0)



# Generated at 2022-06-24 17:25:17.874706
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # TODO: Implement test.
    assert False


# Generated at 2022-06-24 17:25:23.506015
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Stub function
    pass


# Generated at 2022-06-24 17:25:28.699537
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_1 = None
    var_1 = type(WritableStream)((WritableStream,))
    var_1.register(str)
    var_1.write
    setattr(var_1, 'write', None)
    var_1.write


# Generated at 2022-06-24 17:25:30.905769
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    complex_0 = WritableStream()
    complex_1 = unicode()
    assert complex_0.write(complex_1) == None


# Generated at 2022-06-24 17:25:33.639038
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # get_shortish_repr(self, item, custom_repr=(), max_length=None, normalize=False)
    assert False


# Generated at 2022-06-24 17:25:37.622127
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import random
    # String for us to test
    test_str = 'This is a random string, with a random number of characters'
    # Lets randomise the length of the string
    test_str = test_str[0:random.randrange(20, len(test_str))]
    # Run the function, the expected output is the string itself
    assert get_shortish_repr(test_str) == test_str



# Generated at 2022-06-24 17:25:46.775888
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc') == repr('abc')
    assert get_shortish_repr('abc', max_length=1000) == 'abc'
    assert get_shortish_repr('abc', max_length=2) == 'ab'
    assert get_shortish_repr('abc', max_length=1) == 'a'
    assert get_shortish_repr('abc', max_length=0) == ''
    assert get_shortish_repr('abc', max_length=-1) == ''

# Generated at 2022-06-24 17:25:50.089914
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = open(r'C:\Users\Rachum\Documents\Github\python-toolbox\test_stream.txt','w')
    stream.write(r'C:\Users\Rachum\Documents\Github\python-toolbox\test_stream.txt')
    stream.close()


# Generated at 2022-06-24 17:25:53.109307
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Place below your test code for method write of class WritableStream
    print(test_WritableStream_write.__doc__)

    # test_0
    complex_0 = None
    WritableStream_0 = WritableStream()
    var_0 = WritableStream.write(WritableStream_0, complex_0)


# Generated at 2022-06-24 17:26:09.466389
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Create an instance of the class "WritableStream" with no parameters
    writable_stream = WritableStream()
    # Create a string s = "abc"
    s = "abc"
    # Call method write of writable_stream with parameter s
    x = writable_stream.write(s)
    # Verify that x does not equal None
    assert (x != None)

# Generated at 2022-06-24 17:26:10.275099
# Unit test for function shitcode
def test_shitcode():
    pass # nothing to test



# Generated at 2022-06-24 17:26:12.421566
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    try:
        test = get_shortish_repr(complex_0)
    except:
        assert False
    return


# Generated at 2022-06-24 17:26:13.795993
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert hasattr(sys.stdout, "write")
    # unit test for write method of class WritableStream



# Generated at 2022-06-24 17:26:19.390753
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Tests that the method returns a bool
    assert(isinstance(WritableStream().write(truncate(normalize_repr(get_shortish_repr('', (), None, True)), None)), bool))


# Generated at 2022-06-24 17:26:27.854448
# Unit test for function shitcode
def test_shitcode():
    assert(shitcode('Hello') == 'Hello')
    assert(shitcode('') == '')
    assert(shitcode('Hello\r\nworld!') == 'Hello\r\nworld!')
    assert(shitcode('a') == 'a')
    assert(shitcode('a' * 3) == 'a' * 3)
    assert(shitcode(u'\U0001f600') == '?')
    assert(shitcode(u'\U0001f600' * 3) == '?' * 3)
    assert(shitcode('\x55\x55\x55\x55') == '\x55\x55\x55\x55')
    assert(shitcode('\xaa\xaa\xaa\xaa') == '\xaa\xaa\xaa\xaa')

# Generated at 2022-06-24 17:26:29.914850
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test with callable argument
    # Test with callable argument
    pass



# Generated at 2022-06-24 17:26:32.539229
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    my_stream = file_dummy()
    my_stream.write('e')
    my_stream.write('b')
    assert my_stream.data == 'eb'

# Generated at 2022-06-24 17:26:37.965716
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abcd') == 'abcd'
    assert shitcode('\0\0') == '??'
    assert shitcode('\0abc') == '?abc'
    assert shitcode('abc\0') == 'abc?'
    assert shitcode('a\0b\0c') == 'a?b?c'
    assert shitcode(u'a\0') == u'a?'



# Generated at 2022-06-24 17:26:40.008009
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    obj = WritableStream()
    complex_0 = None
    obj.write(complex_0)


# Generated at 2022-06-24 17:26:59.917464
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass


# Generated at 2022-06-24 17:27:03.172676
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_case_0()
    test_case_1()

test_case_1_kwargs = {
    'max_length': None,
    'repr_function': repr,
    'custom_repr': (),
    'normalize': False,
}


# Generated at 2022-06-24 17:27:11.735322
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Test0
    print("Unit test for get_shortish_repr")
    complex_0 = '#Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer eu scelerisque eros. '
    result = get_shortish_repr(complex_0)
    print(result)
    # Test1
    complex_0 = 'Phasellus ut urna risus. Nunc egestas, mauris id venenatis sollicitudin, enim magna iaculis mi, a iaculis libero massa ac arcu. In euismod, lectus vitae commodo volutpat, mauris mauris iaculis lacus, id mollis ligula sapien in turpis. '
    result = get_shortish_repr

# Generated at 2022-06-24 17:27:21.436501
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    # stream: WritableStream
    stream.write('Hello, world')
    stream.write('Hello, world!')
    stream.write('Hello, world')
    stream.write('Hello, world!')
    stream.write('Hello, world')
    stream.write('Hello, world!')
    stream.write('Hello, world')
    stream.write('Hello, world!')
    stream.write('Hello, world')
    stream.write('Hello, world!')
    stream.write('Hello, world')
    stream.write('Hello, world!')
    stream.write('Hello, world')
    stream.write('Hello, world!')
    stream.write('Hello, world')
    stream.write('Hello, world!')
    stream.write('Hello, world')

# Generated at 2022-06-24 17:27:28.218157
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_1 = WritableStream
    var_2 = lambda x: var_1(x)
    var_3 = var_2(file)
    var_4 = sys.stdout
    var_5 = var_3.write(var_4)
    var_6 = sys.stderr
    var_7 = var_3.write(var_6)


# Generated at 2022-06-24 17:27:30.746077
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    ws = MyWritableStream()
    ws.write("Hello")
    assert ws.s == "Hello"


# Generated at 2022-06-24 17:27:37.569561
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Arguments
    custom_repr_0 = None
    max_length_0 = None
    normalize_0 = None
    # Return type
    r = get_shortish_repr(item=custom_repr_0, custom_repr=max_length_0,
                          max_length=normalize_0, normalize=normalize_0)
    pass



# Generated at 2022-06-24 17:27:41.279565
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import pytest
    from . import MockIOBase
    from .mock_iobase import MockIOBase
    from .mock_iobase import mock_open

    def test_case_0():
        complex_0 = MockIOBase(mode=None)
        var_0 = complex_0.write(2)

# Generated at 2022-06-24 17:27:42.832256
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    complex_0 = None
    var_0 = WritableStream().write(complex_0)



# Generated at 2022-06-24 17:27:45.443298
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_1 = WritableStream()
    complex_0 = None
    var_0 = var_1.write(complex_0)

# Generated at 2022-06-24 17:28:24.264457
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    expected_result = 'None[:11]'
    actual_result = get_shortish_repr(None, max_length=11)
    assert actual_result == expected_result



# Generated at 2022-06-24 17:28:28.694714
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    complex_0 = None
    var_0 = WritableStream.write(complex_0)


# Generated at 2022-06-24 17:28:30.470460
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None) == 'None'


# Generated at 2022-06-24 17:28:32.425517
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # WritableStream.write
    assert 0==0 # TODO: implement your test here


# Generated at 2022-06-24 17:28:36.351191
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert isinstance(test_WritableStream_write.__doc__, str)
    assert isinstance(test_case_0.__doc__, str)
    assert isinstance(test_case_0.__doc__, str)



# Generated at 2022-06-24 17:28:38.173779
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # There is no code to unit-test
    pass


# Generated at 2022-06-24 17:28:48.609101
# Unit test for function get_shortish_repr

# Generated at 2022-06-24 17:28:49.801534
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    obj = WritableStream()
    obj.write('')

# Generated at 2022-06-24 17:28:55.947776
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    stream_0 = sys.stdout
    var_0 = writable_stream_0.write("Motto: %s" % (shitcode("No one expects the spanish inquisition!")))
    var_1 = writable_stream_0.write("Motto: %s" % (shitcode("No one expects the spanish inquisition!")))


# Generated at 2022-06-24 17:28:58.458534
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test if the method write is a function
    assert callable(WritableStream.write)
    # Test if the method is setting the correct attribute
    complex_0 = None
    var_0 = WritableStream.write(complex_0)


# Generated at 2022-06-24 17:30:21.587056
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Check that a NOT MATCHING instance can't pass the test
    class C: pass
    try:
        isinstance(C(), WritableStream)
    except:
        pass
    else:
        assert False, "Shouldn't pass isinstance test"

    # Check that a MATCHING instance can pass the test
    class C:
        def write(self, s): pass
    assert isinstance(C(), WritableStream)
    assert issubclass(C, WritableStream)


# Generated at 2022-06-24 17:30:23.175444
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    stream.write('Hello!\n')



# Generated at 2022-06-24 17:30:26.446963
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # target_0 = WritableStream()
    # target_0.write('hi')
    # assert target_0.write(6) == NotImplemented
    pass


#Unit test for function normalize_repr

# Generated at 2022-06-24 17:30:29.957133
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert issubclass(WritableStream, ABC)
    var_0 = WritableStream()
    assert isinstance(var_0, ABC)

# Generated at 2022-06-24 17:30:34.288482
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    complex_0 = None
    var_0 = WritableStream()
    var_0.write(
        shitcode(complex_0))



# Generated at 2022-06-24 17:30:40.739797
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert shitcode(get_shortish_repr('None')) == 'None'
    assert shitcode(get_shortish_repr(4.20)) == '4.2'
    assert shitcode(get_shortish_repr('None', max_length=5)) == 'None'
    assert shitcode(get_shortish_repr(4.20, max_length=5)) == '4.2'
    assert shitcode(get_shortish_repr('None', max_length=3)) == 'Non'
    assert shitcode(get_shortish_repr(4.20, max_length=3)) == '4.'
    assert shitcode(get_shortish_repr('None', max_length=1)) == 'N'

# Generated at 2022-06-24 17:30:44.898987
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Instantiation of a Class
    complex_0 = get_shortish_repr(None)
    complex_1 = get_shortish_repr(None, normalize=True)

    # Invocation of function 'get_shortish_repr'
    get_shortish_repr(var_0, truncate(complex_0, complex_1))
    # Invocation of function 'truncate'
    truncate(complex_0, complex_1)


# Generated at 2022-06-24 17:30:56.383413
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None, custom_repr=(), max_length=None, normalize=False) == 'None', "Function get_shortish_repr failed"
    assert get_shortish_repr(None, custom_repr=(), max_length=None, normalize=True) == 'None', "Function get_shortish_repr failed"
    assert get_shortish_repr(None, custom_repr=(), max_length=1, normalize=False) == 'None', "Function get_shortish_repr failed"
    assert get_shortish_repr(None, custom_repr=(), max_length=1, normalize=True) == 'None', "Function get_shortish_repr failed"

# Generated at 2022-06-24 17:30:58.665110
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_1 = WritableStream()
    var_1.write("fucking hell")


# Generated at 2022-06-24 17:31:04.203172
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    try:
        instance = WritableStream()
        arg = 'some string'
        instance.write(arg)
    except Exception as e:
        raise Exception(
            'Failed to call method `write` of class `WritableStream`.'
            '\nDescription: This method must receive a string argument'
            ' and write it to the stream.'
            '\nError: {}'.format(e)
        )

