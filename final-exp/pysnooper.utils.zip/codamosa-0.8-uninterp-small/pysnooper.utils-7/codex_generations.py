

# Generated at 2022-06-24 17:21:38.333319
# Unit test for function get_repr_function
def test_get_repr_function():
    r = get_repr_function(True, ((bool, lambda b: '<bool>'),))
    assert r(True) == '<bool>'
    r = get_repr_function(False, ((bool, lambda b: '<bool>'),))
    assert r(False) == '<bool>'
    r = get_repr_function(
        False,
        ((bool, lambda b: '<bool>'), (str, lambda s: '<str>'))
    )
    assert r(False) == '<bool>'
    r = get_repr_function(
        'Hello',
        ((bool, lambda b: '<bool>'), (str, lambda s: '<str>'))
    )
    assert r('Hello') == '<str>'


# Generated at 2022-06-24 17:21:41.378695
# Unit test for function get_repr_function
def test_get_repr_function():
    assert isinstance(get_repr_function(dict(), ()), type(repr)), 'assert type(get_repr_function(dict(), ())) is type(repr)'



# Generated at 2022-06-24 17:21:43.889586
# Unit test for function get_repr_function
def test_get_repr_function():
    dict_0 = function_0(0)
    var_0 = get_repr_function(dict_0, function_2())



# Generated at 2022-06-24 17:21:52.105649
# Unit test for function get_shortish_repr

# Generated at 2022-06-24 17:22:01.895055
# Unit test for function get_repr_function
def test_get_repr_function():
    import os, types

    # Check non-default
    var_0 = get_repr_function(1, ((lambda x: True, str),))
    assert var_0 == str

    # Check default
    var_1 = get_repr_function(1)
    assert var_1 == repr

    # Check list
    var_2 = get_repr_function(1, ((list, str),))
    assert var_2 == repr

    # Check list subclass
    class mylist(list): pass
    var_3 = get_repr_function(mylist((1,)), ((list, str),))
    assert var_3 == str


# Generated at 2022-06-24 17:22:06.609426
# Unit test for function get_repr_function
def test_get_repr_function():
    item = float
    custom_repr = (
    (lambda x:x==float, lambda x: 'float'),
    )
    func = get_repr_function(item,custom_repr)
    assert func(item) == 'float'



# Generated at 2022-06-24 17:22:10.412915
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((lambda x: x > 0, str),)) == str
    assert get_repr_function(
        -1, custom_repr=((lambda x: x > 0, str),)) == repr


# Generated at 2022-06-24 17:22:12.701318
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    print(sys._getframe().f_code.co_name)
    pass


# Generated at 2022-06-24 17:22:20.098791
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None) is repr
    assert get_repr_function(None, custom_repr=((object, id),)) is id
    assert get_repr_function(None, custom_repr=((int, id),)) is repr
    def func(*args, **kwargs):
        return 'spam'
    assert get_repr_function(func, custom_repr=((type(func.__call__), id),)) is id


# Generated at 2022-06-24 17:22:26.714776
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr

# Generated at 2022-06-24 17:22:39.990183
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert issubclass(sys.stdout.__class__, WritableStream)
    sys.stdout.write('{}' + ''.join(chr(i) for i in range(256)))
    sys.stdout.write(unicode('{}' + ''.join(chr(i) for i in range(256))))
    sys.stdout.write('\n\r')
    assert isinstance(sys.stdout.write('\n\r'), int)
    assert sys.stdout.write('\n\r') >= 0


import pytest


# Generated at 2022-06-24 17:22:42.399172
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = WritableStream()

    assert stream.write == None
    assert callable(stream.write)

    with pytest.raises(AttributeError):
        stream.write(1)



# Generated at 2022-06-24 17:22:43.927566
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    file_object = sys.stdout
    assert isinstance(file_object, WritableStream)


# Generated at 2022-06-24 17:22:55.599377
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    '''
    Tests the usage of the method write.
    '''
    
    # Assigning to <mod>.WritableStream
    sys.modulename.WritableStream = WritableStream

    # Building StreamWriter from sys.stdout
    sw = StreamWriter(sys.stdout)

    # Writing to <mod>.StreamWriter
    sw.write('hello world')

    # Building StringIO from StringIO()
    sio = StringIO()

    # Writing to StringIO
    sio.write('hello world')

    # Building StreamWriter from StringIO()
    ssw = StreamWriter(sio)

    # Writing to <mod>.StreamWriter
    ssw.write('foo bar')

    # Building StreamWriter from StringIO()
    ssw2 = StreamWriter(sio)

    # Writing to <mod>.StreamWriter
    s

# Generated at 2022-06-24 17:23:01.428101
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(int_0) == '0'
    assert get_shortish_repr(str(int_0), max_length=2) == '0'
    assert get_shortish_repr(str(int_0), max_length=2) == '0'
    assert get_shortish_repr(str(int_0), max_length=3) == '0'
    assert get_shortish_repr(str(int_0), max_length=4) == '0'
    assert get_shortish_repr(str(int_0), max_length=5) == '0'
    assert get_shortish_repr(str(int_0), max_length=6) == '0'

# Generated at 2022-06-24 17:23:04.459311
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('test') == 'test'
    assert shitcode(u'test') == 'test'
    assert shitcode(u'a\u2200d') == 'ad'
    assert shitcode('a\u2200d') == 'a\u2200d'
    assert shitcode('a\u2200\u2200d') == 'a?d'
    assert shitcode('a\u2200d\u2200') == 'a?d?'



# Generated at 2022-06-24 17:23:09.676110
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'אני אוהב אותך') == '???? ???? ????'
    assert shitcode('abc') == 'abc'
    assert shitcode(u'abc') == 'abc'
    assert shitcode(u'\u201c') == '?'



# Generated at 2022-06-24 17:23:20.251223
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Testing for default repr.
    assert get_shortish_repr(int_0) == '0'
    assert get_shortish_repr(int_0, (str, int)) == '0'
    assert get_shortish_repr(int_0, (str, int), normalize=True) == '0'
    assert get_shortish_repr(int_0, (str, int), normalize=True, max_length=3) == '0'

    def custom_repr(x):
        return 'dozint'
    assert get_shortish_repr(int_0, custom_repr=((int, custom_repr),)) == 'dozint'

# Generated at 2022-06-24 17:23:27.007669
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([1, 2, 3, 4, 5]) == '[1, 2, 3, 4, 5]'
    assert get_shortish_repr([1, 2, 3, 4, 5], max_length=8) == '[1, 2, ...]'
    assert get_shortish_repr([1, 2, 3, 4, 5], max_length=None) ==\
                                                             '[1, 2, 3, 4, 5]'



# Generated at 2022-06-24 17:23:29.934949
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x01def') == 'abc?def'


# Generated at 2022-06-24 17:23:40.979142
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda x: isinstance(x, int), lambda x: hex(x)),
        (lambda x: isinstance(x, float), lambda x: '%.2f' % x),
        (lambda x: isinstance(x, set), lambda x: str(x))
    )

    assert get_repr_function(1, custom_repr) == hex

# Generated at 2022-06-24 17:23:52.324055
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass
    
    w = WritableStream.__new__(WritableStream)
    assert issubclass(type(w),WritableStream)
    
    import io
    class MyStdOut(io.TextIOWrapper, WritableStream):
        pass
    
    assert issubclass(MyStdOut,WritableStream)
    
    # WritableStream.write is now implemented in io.TextIOWrapper.write
    #
    # This passes:
    # assert hasattr(w,'write')
    # assert hasattr(w.write,'__call__')
    # w.write('hello world')
    
    w = MyStdOut(open('.pydoc', 'w'))
    assert hasattr(w,'write')
    assert hasattr(w.write,'__call__')
    w

# Generated at 2022-06-24 17:24:04.336798
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(123, max_length=10) == '123'
    assert get_shortish_repr(123456789, max_length=10) == '123456789'
    assert get_shortish_repr(123456789, max_length=5) == '12...89'
    assert get_shortish_repr(123456789, max_length=4) == '12...'
    assert get_shortish_repr(123456789, max_length=3) == '...'
    assert get_shortish_repr(123456789, max_length=2) == '..'
    assert get_shortish_repr(123456789, max_length=1) == '.'


# Generated at 2022-06-24 17:24:05.589401
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) is repr



# Generated at 2022-06-24 17:24:16.458608
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(test_case_0) == '<function test_case_0 at 0x%x>' % id(test_case_0)
    for length in range(len(test_case_0.__name__) + 1):
        assert get_shortish_repr(test_case_0, max_length=length) == (test_case_0.__name__)[:length]
    assert get_shortish_repr(test_case_0, normalize=True) == '<function test_case_0>'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr('a', max_length=5) == 'a'

# Generated at 2022-06-24 17:24:25.583658
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('a' * 19) == 'a' * 19
    assert get_shortish_repr('a' * 20) == 'a' * 20
    assert get_shortish_repr('a' * 300) == 'a' * 300
    assert get_shortish_repr('a' * 18, max_length=20) == 'a' * 18
    assert get_shortish_repr('a' * 19, max_length=20) == 'a' * 19
    assert get_shortish_repr('a' * 20, max_length=20) == 'a' * 20
    assert get_shortish_repr('a' * 21, max_length=20) == 'a' * 18 + '...'

# Generated at 2022-06-24 17:24:33.682618
# Unit test for function get_repr_function
def test_get_repr_function():
    def custom_repr(x):
        if isinstance(x, int):
            return ('int', lambda x: 'int: {}'.format(x))
        elif isinstance(x, str):
            return ('string', lambda x: 'string: {}'.format(x))
        else:
            raise ValueError

    assert get_repr_function(123, custom_repr) == repr
    assert get_repr_function('123', custom_repr) == repr
    assert get_repr_function(int_0, custom_repr) == repr
    assert get_repr_function('str', custom_repr) == repr



# Generated at 2022-06-24 17:24:35.420583
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [(lambda x: True, lambda x: 'my_repr')]
    assert get_repr_function(int_0, custom_repr) is 'my_repr'


# Generated at 2022-06-24 17:24:45.274636
# Unit test for function get_repr_function
def test_get_repr_function():

    assert get_repr_function(5, []) == repr
    assert get_repr_function(5, [(type(5), int)]) == int
    assert get_repr_function(5, [(type(5), int), (lambda x, y=sys.__class__:
                                                  isinstance(x, y))]) == int
    assert get_repr_function(int_0, []) == repr
    assert get_repr_function(int_0, [(type(5), int)]) == int
    assert get_repr_function(int_0, [(type(5), int),
                                     (lambda x, y=sys.__class__:
                                      isinstance(x, y))]) == int

    # Unit tests for function get_shortish_repr

# Generated at 2022-06-24 17:24:55.978007
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, (lambda x: isinstance(x, str), str)) == str
    assert get_repr_function(5, (lambda x: isinstance(x, (str, int)), str)) == str
    assert get_repr_function(5, (lambda x: isinstance(x, (str, int)), repr)) == repr
    assert get_repr_function('5', (lambda x: isinstance(x, (str, int)), str)) == str
    assert get_repr_function('5', (lambda x: isinstance(x, (str, int)), repr)) == repr
    assert get_repr_function(5, (lambda x: isinstance(x, object), str)) == repr

# Generated at 2022-06-24 17:25:06.700069
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    def write(s):
        sys.stdout.write(s)
    stream.write = write
    s = 'hello world!'
    stream.write(s)


# Generated at 2022-06-24 17:25:17.088614
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(0) == '0'
    assert get_shortish_repr(0, max_length=2) == '0'
    assert get_shortish_repr(0, max_length=3) == '0'
    assert get_shortish_repr(0, max_length=4) == '0'

    assert get_shortish_repr(0, custom_repr=((int, lambda x: 'NUMBER'),)) \
                                                                 == 'NUMBER'
    assert get_shortish_repr(0, custom_repr=((int, lambda x: 'NUMBER'),),
                                          max_length=2) == 'NUMBER'

# Generated at 2022-06-24 17:25:22.293230
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, shitcode)]) == shitcode
    assert get_repr_function(1, [(bool, shitcode)]) == repr
    assert (get_repr_function([1], [(list, shitcode)]) ==
            get_repr_function((1,), [(tuple, shitcode)]) ==
            get_repr_function(set([1]), [(set, shitcode)])) == shitcode
    assert get_repr_function(1, [(lambda x: x == 1, shitcode)]) == shitcode
    assert get_repr_function(2, [(lambda x: x == 1, shitcode)]) == repr
    assert get_repr_function(int, [(int, shitcode)]) == repr

# Generated at 2022-06-24 17:25:24.573875
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    WritableStream.register(sys.stdout.__class__)
    assert isinstance(sys.stdout, WritableStream)
    assert isinstance(sys.stdout, file)


# Generated at 2022-06-24 17:25:27.523440
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert not issubclass(object, WritableStream)
    assert issubclass(sys.stdout, WritableStream)


# Generated at 2022-06-24 17:25:36.854572
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    with open('my_file.txt', 'wb') as file:
        writableStream = WritableStream()
        writableStream.write(file, 'Hello World!')
        assert writableStream.write(file, 'Hello World!') == 'Hello World!'
        assert writableStream.write(file, "a") == "a"
        assert writableStream.write(file, "b\nc") == "b\nc"
        assert writableStream.write(file, '\r') == '\r'
        assert writableStream.write(file, '\n') == '\n'
        assert writableStream.write(file, '\t') == '\t'
        assert writableStream.write(file, '\v') == '\v'

# Generated at 2022-06-24 17:25:39.414685
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(test_case_0, [(int, str)])(test_case_0) == "0"


# Generated at 2022-06-24 17:25:50.644185
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    """
    Check the get_shortish_repr function

    :return: nothing
    """

    # Check a simple example
    assert get_shortish_repr(1) == "1"

    # Check that repr is used with a simple example
    assert get_shortish_repr(test_case_0) == repr(test_case_0)

    # Check that repr is used with a simple example
    assert get_shortish_repr(test_case_0()).split(' ')[0] == 'test_case_0'

    # Check that truncating works
    assert get_shortish_repr(test_case_0(), max_length=1) == 't...0'

    # Check that custom repr is used

# Generated at 2022-06-24 17:25:53.987155
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_case_0()


_methods_by_class_name = {
    'WritableStream': [
        test_WritableStream_write,
    ],
}


# Generated at 2022-06-24 17:26:00.696778
# Unit test for function get_repr_function
def test_get_repr_function():
    def custom_repr_func(item):
        return str(item)

    input_list = [(0, custom_repr_func), (1, lambda i: list(i))]
    expected_list = [repr, list]
    for ind, item in enumerate(input_list):
        assert (get_repr_function(input_list[ind][0], (item,))
                == expected_list[ind])
    assert get_repr_function(0, tuple()) == repr



# Generated at 2022-06-24 17:26:12.060236
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (int, lambda x: 'custom repr for {!r}'.format(x)),
    )

# Generated at 2022-06-24 17:26:14.407548
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda _: True, lambda _: ''),
    )
    assert get_repr_function(None, custom_repr) == (lambda _: '')


# Generated at 2022-06-24 17:26:24.399967
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (int, lambda item: 'int'),
        (float, lambda item: 'float'),
        (type(None), lambda item: 'None'),
    )
    assert get_repr_function(None, custom_repr) == custom_repr[-1][1]
    assert get_repr_function(0, custom_repr) == custom_repr[0][1]
    assert get_repr_function(3.5, custom_repr) == custom_repr[1][1]
    assert get_repr_function('bla', custom_repr) == repr



# Generated at 2022-06-24 17:26:29.772553
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\x00\x01\x02\x03\x04\x05') == '??????'
    assert shitcode(u'\x00\x01\x02\x03\x04\x05') == '??????'
    assert shitcode(b'\x00\x01\x02\x03\x04\x05') == '??????'



# Generated at 2022-06-24 17:26:32.738323
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Tries to write to a file, and sees if it succeeds.
    with open(__file__, 'r') as f:
        f.write('hello world')
        #print('write succeeded')



# Generated at 2022-06-24 17:26:40.864710
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(test_case_0) == '<function test_case_0 at 0x{:x}>'.format(id(test_case_0))
    assert get_shortish_repr(test_case_0, max_length=20) == '<function test_case_0...>'

    assert get_shortish_repr(0) == '0'
    assert get_shortish_repr(0, max_length=20) == '0'

    assert '<function ensure_tuple at 0x' in get_shortish_repr(ensure_tuple)
    assert get_shortish_repr(ensure_tuple, max_length=20) == '<function ensure_tuple...>'


# Generated at 2022-06-24 17:26:43.016456
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    w = sys.stdout
    w.write('0')

# Generated at 2022-06-24 17:26:46.911577
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(
        test_case_0,
        custom_repr=(
            (lambda x: False, lambda x: 'wrong'),
        )
    ) is repr



# Generated at 2022-06-24 17:26:52.082442
# Unit test for function get_repr_function
def test_get_repr_function():
    assert (get_repr_function(1, ((int, int_0),)) == int_0)



# Generated at 2022-06-24 17:26:58.311890
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo:
        def __repr__(self):
            return 'Foo()'
    custom_repr = ((lambda x: x == 'foo', lambda x: "I'm %s!" % x),)
    assert get_repr_function('foo', custom_repr)("I'm %s!" % 'foo')
    assert get_repr_function('bar', custom_repr)('bar') == 'bar'
    assert get_repr_function(Foo(), custom_repr)(Foo()) == 'Foo()'



# Generated at 2022-06-24 17:27:12.637489
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(int_0) == '0'
    assert get_shortish_repr(int_0, normalize=True) == '0'
    assert get_shortish_repr(int_0, max_length=2) == '0'
    assert get_shortish_repr(int_0, max_length=1) == '0'
    assert get_shortish_repr(int_0, max_length=0) == ''
    assert get_shortish_repr(int_0, max_length=2, normalize=True) == '0'
    assert get_shortish_repr(int_0, max_length=1, normalize=True) == '0'

# Generated at 2022-06-24 17:27:15.129488
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()

# Generated at 2022-06-24 17:27:23.402330
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = ((lambda x: isinstance(x, int), repr))
    repr_function = get_repr_function(test_case_0(), custom_repr)
    r = repr_function(test_case_0())
    assert r == '0'

    custom_repr = ((lambda x: isinstance(x, (int, str)), repr))
    repr_function = get_repr_function(test_case_0(), custom_repr)
    r = repr_function(test_case_0())
    assert r == '0'

    custom_repr = ((lambda x: isinstance(x, str), repr))
    repr_function = get_repr_function(object(), custom_repr)
    r = repr_function(test_case_0())

# Generated at 2022-06-24 17:27:28.502034
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    for file_like_object in [
        open('some_file', 'w'),
        sys.stdout,
        sys.stderr,
        sys.__stdout__,
        sys.__stderr__
    ]:
        assert issubclass(type(file_like_object), WritableStream)

# Generated at 2022-06-24 17:27:35.065023
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import sys

    # Write to sys.stdout
    print('test write')
    sys.stdout.write('test write\n')

    # Write to sys.stderr
    print('test write', file=sys.stderr)
    sys.stderr.write('test write\n')

    # Write to io.StringIO()
    test_output = io.StringIO()
    print('test write', file=test_output)
    test_output.write('test write\n')

    # Write to io.BytesIO()
    test_output = io.BytesIO()
    print('test write', file=test_output)
    test_output.write(b'test write\n')

    # non-string type
    f = io.StringIO()

# Generated at 2022-06-24 17:27:45.485525
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(3) == '3'
    assert get_shortish_repr(5, max_length=100) == '5'
    assert get_shortish_repr(5, (int, str), max_length=100) == '5'
    assert get_shortish_repr(3, (int, str), max_length=100) == '3'
    assert get_shortish_repr(3, (int, str), max_length=2) == '3'
    assert get_shortish_repr(3, normalize=True) == '3'
    assert get_shortish_repr(3, normalize=False) == '3'
    assert get_shortish_repr(str(3), normalize=True) == "3"
    assert get_shortish_

# Generated at 2022-06-24 17:27:47.321240
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyClass(WritableStream):
        def write(self, s):
            pass
    MyClass()



# Generated at 2022-06-24 17:27:55.226311
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .python_toolbox.nifty_collections import OrderedDict
    from .python_toolbox.misc_tools import make_sorted_tuple
    from .python_toolbox import sexy_repr

    WritableStream = cls_WritableStream
    class A(WritableStream):
        def write(self, s):
            self.s = s

    a = A()
    a.write('test_test')
    assert a.s == 'test_test'
    assert isinstance(a, WritableStream)



# Generated at 2022-06-24 17:28:04.175684
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    print(get_shortish_repr(int_0))
    print(get_shortish_repr(int_0, normalize=True))
    print(base=int_0,normalize=False)
    print(base=int_0,normalize=True)
    print(base=int_0,repr_function=repr,normalize=False)
    print(base=int_0,repr_function=repr,normalize=True)
    print(base=int_0,repr_function=lambda x: hex(id(x)),normalize=False)
    print(base=int_0,repr_function=lambda x: hex(id(x)),normalize=True)

# Generated at 2022-06-24 17:28:13.379786
# Unit test for function get_repr_function
def test_get_repr_function():
    CR = ((int, 'int_0'), (float, 'float_0'), (object, 'object_0'))
    assert get_shortish_repr(0, custom_repr=CR) == 'int_0'
    assert get_shortish_repr(0.0, custom_repr=CR) == 'float_0'
    assert get_shortish_repr(object(), custom_repr=CR) == 'object_0'
    assert get_shortish_repr(0j, custom_repr=CR) == '0j'
    assert get_shortish_repr(None, custom_repr=CR) == 'None'

# Generated at 2022-06-24 17:28:23.900524
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """Unit test for method write of class WritableStream"""
    import StringIO
    stream = StringIO.StringIO()
    assert ln.WritableStream.__subclasshook__(
        StringIO.StringIO.__class__
    )
    stream = StringIO.StringIO()
    stream.write('Hello')
    assert stream.getvalue() == 'Hello'



# Generated at 2022-06-24 17:28:33.787969
# Unit test for function get_repr_function
def test_get_repr_function():
    import numpy as np
    assert get_repr_function(0, ()) == repr
    assert get_repr_function(0, ((int, lambda x: -x),))(0) == '0'
    assert get_repr_function(0.1, ((int, lambda x: -x),))(0.1) == '0.1'
    assert get_repr_function(np.array([1, 2]), ((np.array, lambda x: x.sum()),))(np.array([1, 2])) == 3


# Generated at 2022-06-24 17:28:45.426899
# Unit test for function get_repr_function
def test_get_repr_function():
    int_repr = get_repr_function(0, ((int, lambda x: 'an int'),))
    assert int_repr(0) == 'an int'
    assert int_repr(2) == 'an int'
    assert int_repr('0') == 'an int'
    assert int_repr('0') == 'an int'

    int_repr = get_repr_function(0, ((int, lambda x: 'an int'),
                                     (str, lambda x: 'a str')))
    assert int_repr(0) == 'an int'
    assert int_repr(2) == 'an int'
    assert int_repr('0') == 'a str'
    assert int_repr('0') == 'a str'



# Generated at 2022-06-24 17:28:47.076939
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    w = sys.stdout
    assert w.write('abc') == 3

# Generated at 2022-06-24 17:28:58.274718
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(0) == '0'
    assert get_shortish_repr(0, max_length=2) == '0'
    assert get_shortish_repr(
        0,
        max_length=2,
        normalize=True,
    ) == '0'

    assert get_shortish_repr(1234567) == '1234567'
    assert get_shortish_repr(1234567, max_length=5) == '12...67'
    assert get_shortish_repr(
        1234567,
        max_length=5,
        normalize=True,
    ) == '12...67'

    assert get_shortish_repr(set([1, 2, 3])) == '{1, 2, 3}'
    assert get

# Generated at 2022-06-24 17:29:09.937298
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(int_0, (), None) == '0'
    assert get_shortish_repr(int_0, (), 3) == '0'
    assert get_shortish_repr(int_0, (), 1) == '0'
    assert get_shortish_repr(int_0, (), 0) == '0'
    assert get_shortish_repr(int_0, (), 0) == '0'
    assert get_shortish_repr(int_0, (), 0) == '0'
    assert get_shortish_repr(int_0, (), -1) == '0'
    assert get_shortish_repr(int_0, (), -2) == '0'

# Generated at 2022-06-24 17:29:21.540947
# Unit test for function get_repr_function
def test_get_repr_function():
    get_repr_function(test_case_0.int_0, [(isinstance, repr),
                                          (lambda x: True, repr),
                                          (lambda x: True, repr),]) == repr



if sys.version_info.major == 2:
    # In Python 2, `tempfile` didn't have `NamedTemporaryFile`
    def NamedTemporaryFile(*args, **kwargs):
        import threading
        import tempfile
        temp_file_name = tempfile.mktemp()
        kwargs['delete'] = False
        with tempfile.NamedTemporaryFile(name=temp_file_name, *args, **kwargs) \
                                                                     as file:
            file.name = temp_file_name
            yield file
        tempfile.unlink(temp_file_name)

# Generated at 2022-06-24 17:29:24.463253
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    s = sys.stdout
    assert isinstance(s, WritableStream)
    s.write('something')


# Generated at 2022-06-24 17:29:28.509753
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [(lambda obj: type(obj) == int,
                    lambda obj: 'no_int_repr')]
    assert get_repr_function(1, custom_repr) is custom_repr[0][1]
    assert get_repr_function("1", custom_repr) is repr
    assert get_repr_function("1", custom_repr) is repr


# Generated at 2022-06-24 17:29:34.435879
# Unit test for function get_repr_function
def test_get_repr_function():
    string_1 = '0'
    assert get_repr_function(string_0, ()) == repr
    assert get_repr_function(string_1, ()) == repr
    assert get_repr_function(string_0, ((str, str.upper),)) == str.upper
    assert get_repr_function(string_1, ((str, str.upper),)) == repr


# Generated at 2022-06-24 17:29:43.675820
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(int_0, ((int, lambda x: 'lambda is this'))) == \
                                                            'lambda is this'



# Generated at 2022-06-24 17:29:53.705093
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from . import assert_equal

    assert_equal(get_shortish_repr(1), '1')
    assert_equal(get_shortish_repr('hi'), '\'hi\'')
    assert_equal(get_shortish_repr('hi', max_length=10), '\'hi\'')
    assert_equal(get_shortish_repr('hi', max_length=3), '\'...\'')
    assert_equal(get_shortish_repr('hi', max_length=2), '\'...\'')
    assert_equal(get_shortish_repr('hi', max_length=1), '\'...\'')

    assert_equal(get_shortish_repr(1, normalize=True), '1')

# Generated at 2022-06-24 17:29:56.305910
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Arrange
    obj = sys.stdout

    # Act
    obj.write('abc')

    # Assertion
    assert True



# Generated at 2022-06-24 17:29:58.889491
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    new_repr = get_shortish_repr(test_case_0, normalize=True)
    assert new_repr == '<function test_case_0 at 0x'

# Generated at 2022-06-24 17:30:03.533404
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream_0 = sys.stdout
    stream_0.write('abcde')

test_case_0.test_name = 'test_case_0'
test_WritableStream_write.test_name = 'test_WritableStream_write'
test_cases = (test_case_0, test_WritableStream_write)

# Generated at 2022-06-24 17:30:05.292587
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, 'hello'))) == 'hello'


# Generated at 2022-06-24 17:30:06.749305
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    x = WritableStream()

# Generated at 2022-06-24 17:30:11.283920
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from pytest import raises
    item = 5
    custom_repr = (
        (isinstance, lambda i: 'a'),
        (lambda i: i > 0,  lambda i: 'b')
    )
    with raises(Exception):
        get_shortish_repr(item, custom_repr)

# Generated at 2022-06-24 17:30:18.307570
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object):
        pass
    class B(A):
        pass

    assert get_repr_function(0, ()) == repr

# Generated at 2022-06-24 17:30:27.956468
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    print(get_shortish_repr(int_0, max_length=None))
    print(get_shortish_repr(int_0, max_length=1))
    print(get_shortish_repr(int_0, max_length=2))
    print(get_shortish_repr(int_0, max_length=3))
    print(get_shortish_repr(int_0, max_length=10))
    print(get_shortish_repr(int_0, max_length=11))
    print(get_shortish_repr(int_0, max_length=12))
    print(get_shortish_repr(int_0, max_length=13))
    print(get_shortish_repr(int_0, max_length=14))
   

# Generated at 2022-06-24 17:30:44.928750
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # This is a test for the method write() of class WritableStream.
    # pylint: disable=bad-whitespace, line-too-long, missing-docstring, invalid-name
    # pylint: disable=too-many-locals, too-many-branches, too-many-statements
    # pylint: disable=expression-not-assigned, pointless-statement
    # pylint: disable=unused-variable, unused-argument, redefined-variable-type
    # pylint: disable=unused-expression
    # pylint: disable=misplaced-comparison-constant, unused-comparison

    import datetime
    import functools
    import socket
    import sys
    import tempfile
    import io
    import os
    import gc
    from collections import namedt

# Generated at 2022-06-24 17:30:56.411850
# Unit test for function get_repr_function
def test_get_repr_function():

    # BUG #1: This was failing
    assert get_repr_function(int_0, [(lambda x: True, lambda x: 'hello')]) == 'hello'

    from .python_toolbox.temp_value_setters import temp_value

    custom_repr = [(lambda x: True, lambda x: 'hello')]
    assert get_repr_function(int_0, custom_repr) == 'hello'
    with temp_value(custom_repr, custom_repr + [('hello', 'no')]):
        assert get_repr_function(int_0, custom_repr) == 'no'

    custom_repr = [(lambda x: True, lambda x: 'hello')]
    assert get_repr_function(int_0, custom_repr) == 'hello'

# Generated at 2022-06-24 17:31:00.305481
# Unit test for function get_repr_function
def test_get_repr_function():
    my_repr = get_repr_function(int_0, custom_repr=[(lambda x: x == 0, lambda x: 'zero')])
    assert my_repr(int_0) == 'zero'


# Generated at 2022-06-24 17:31:11.003516
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=20) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=14) == '[1, 2,...]'
    assert get_shortish_repr([1, 2, 3], max_length=8) == '[1,...'
    assert get_shortish_repr([1, 2, 3], max_length=7) == '[1,...]'
    assert get_shortish_repr([1, 2, 3], max_length=6) == '[1...]'
    assert get_shortish_repr([1, 2, 3], max_length=5) == '[...]'


# Generated at 2022-06-24 17:31:15.493425
# Unit test for function get_repr_function
def test_get_repr_function():
    # Custom repr for `int`.
    custom_repr = (
        (int, lambda x: '{} (int)'.format(x)),
    )

# Generated at 2022-06-24 17:31:24.842137
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(test_case_0, ()) is repr
    assert get_repr_function(
        test_case_0,
        (
            (lambda x: True, lambda x: 'success'),
        )
    )(test_case_0) == 'success'
    assert get_repr_function(
        test_case_0,
        (
            (lambda x: False, lambda x: 'failure'),
            (lambda x: True, lambda x: 'success'),
        )
    )(test_case_0) == 'success'