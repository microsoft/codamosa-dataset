

# Generated at 2022-06-24 17:21:31.393553
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(int_0, (int, 'no')) == 'no'
    assert get_repr_function(writable_stream_0, (str, 'yes')) == repr


# Generated at 2022-06-24 17:21:40.133098
# Unit test for function get_repr_function
def test_get_repr_function():
    import sys
    item = object()
    repr_function = get_repr_function(item, [])
    assert repr_function(item) == repr(item)
    repr_function = get_repr_function(item, [(type, lambda x: 'meow')])
    assert repr_function(item) == 'meow'
    repr_function = get_repr_function(item, [
        (lambda i: True, lambda x: 'meow'),
        (lambda i: False, lambda x: 'woof')
    ])
    assert repr_function(item) == 'meow'
    repr_function = get_repr_function(item, [
        (lambda i: False, lambda x: 'meow'),
        (lambda i: True, lambda x: 'woof')
    ])

# Generated at 2022-06-24 17:21:48.636002
# Unit test for function get_repr_function
def test_get_repr_function():
    def assert_equal(x, y):
        if x != y:
            raise Exception('{} != {}'.format(x, y))

    # Examples from documentation
    assert_equal(
        get_repr_function(
            int_0,
            custom_repr=(
                (int, lambda x: '{}i'.format(x)),
            )
        )(int_0),
        '-57i'
    )
    assert_equal(
        get_repr_function(
            writable_stream_0,
            custom_repr=(
                (WritableStream, lambda x: 'stream'),
            )
        )(writable_stream_0),
        'stream'
    )

# Generated at 2022-06-24 17:22:00.432551
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(int_0, (), 3, True) == '-5'

    assert get_shortish_repr(int_0, (), None, True) == '-57'

    assert get_shortish_repr(int_0, (), 3) == '-5'

    assert get_shortish_repr(int_0, (), None) == '-57'

    assert get_shortish_repr(int_0, ((int, lambda x: str(x) + '!'),), None) == '-57!'

    assert get_shortish_repr(int_0, ((int, lambda x: str(x) + '!'),), 3) == '-5!'


# Generated at 2022-06-24 17:22:03.103292
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_case_0()
    writable_stream_0.write(int_0)
    return True




# Generated at 2022-06-24 17:22:09.724750
# Unit test for function get_repr_function
def test_get_repr_function():
    assert (get_repr_function('string') == repr)
    assert (get_repr_function('string', [(lambda x: True, lambda x: 'foo')]) == 'foo')


# Generated at 2022-06-24 17:22:20.931857
# Unit test for function shitcode
def test_shitcode():
    print("Testing shitcode")

# Generated at 2022-06-24 17:22:29.940349
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(-57, normalize=True) == '-57'
    assert get_shortish_repr(-57, max_length=3, normalize=True) == '-5...'
    assert get_shortish_repr(-57, max_length=4, normalize=True) == '-57'
    assert get_shortish_repr(57, (int, lambda i: 'int({})'.format(i)), normalize=True) == 'int(57)'
    assert get_shortish_repr(int_0, (int, lambda i: 'int({})'.format(i)), normalize=True) == 'int(-57)'

# Generated at 2022-06-24 17:22:40.200739
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Check that get_shortish_repr accepts an integer.
    int_0 = -11
    assert get_shortish_repr(int_0) == '-11'
    assert get_shortish_repr(int_0, max_length=10) == '-11'
    # Check that get_shortish_repr accepts a float.
    float_0 = -0.0002533
    assert get_shortish_repr(float_0) == '-0.0002533'
    assert get_shortish_repr(float_0, max_length=10) == '-0.0002533'
    # Check that get_shortish_repr accepts a long integer.
    long_0 = -57
    assert get_shortish_repr(long_0) == '-57L'
   

# Generated at 2022-06-24 17:22:47.307262
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert WritableStream.__subclasshook__(WritableStream) == True
    int_0 = -57
    writable_stream_0 = WritableStream()
    assert writable_stream_0.write(int_0) == None
    assert writable_stream_0.write(int_0) == None
    assert WritableStream.__subclasshook__(WritableStream) == True

    int_0 = -57
    writable_stream_0 = WritableStream()
    assert writable_stream_0.write(int_0) == None
    assert writable_stream_0.write(int_0) == None
    assert WritableStream.__subclasshook__(WritableStream) == True


# Generated at 2022-06-24 17:22:59.799699
# Unit test for function shitcode
def test_shitcode():
    # Testing this function is not easy, since it is used to
    # print unreadable characters that are not printable.
    # e.g. shitcode(b'\x80') == '?'
    assert shitcode(b'\x80\x81') == '??'


# Generated at 2022-06-24 17:23:06.547768
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(bool_0) == 'True'
    assert (get_shortish_repr(bool_0) == 'True') == True
    assert (get_shortish_repr(bool_0) == 'True') == True
    assert (get_shortish_repr(bool_0) == 'True') == True



# Generated at 2022-06-24 17:23:08.745973
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    os = sys.__stdout__
    os.write('one')
    os.write('two')





# Generated at 2022-06-24 17:23:18.062764
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import pytest
    class MyStream(WritableStream):
        def __init__(self):
            self.s = ''

        def write(self, s):
            self.s += s

        def close(self):
            self.s = None

    f = io.StringIO()
    MyStream.register(f)
    assert isinstance(f, MyStream)

    s = MyStream()
    assert isinstance(s, MyStream)
    f.write('stuff')
    assert f.getvalue() == 'stuff'
    f.close()
    with pytest.raises(ValueError):
        f.write('stuff')



# Generated at 2022-06-24 17:23:20.555794
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    assert isinstance(stream, WritableStream)
    stream.write('foo')
    assert True

# Generated at 2022-06-24 17:23:30.053349
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([]) == '[]'
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(2) == '2'
    assert get_shortish_repr(3) == '3'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(2, max_length=1) == '2'
    assert get_shortish_repr(3, max_length=1) == '3'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(2, max_length=2) == '2'

# Generated at 2022-06-24 17:23:40.318737
# Unit test for function get_repr_function
def test_get_repr_function():
    x = [1, 2, 3]
    assert get_repr_function(x, (('hello', 'goodbye'),)) == repr
    assert get_repr_function(x, ((type(''), 'goodbye'),)) == repr
    assert get_repr_function(x, ((type(None), 'goodbye'),)) == repr
    assert get_repr_function(x, ((lambda x: True, 'goodbye'),)) == 'goodbye'
    assert get_repr_function(x, ((lambda x: False, 'goodbye'),)) == repr
    assert get_repr_function(x, ((lambda x: False, 'goodbye'),
                                 (int, 'bye'))) == repr

# Generated at 2022-06-24 17:23:52.069854
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .settings import Settings
    from .state import State
    from .recording import Recording
    from . import recording
    from . import misc

    settings = Settings(
        use_colors=True,
        use_unicode=True,
        use_align=True,
        use_multiple_lines=True,
        truncate_length=5,
        custom_repr=((re.compile('^my_regex$'), lambda x: 'my_repr'),),
        repr_function_factory=None  # Deprecated
    )
    state = State(
        settings=settings,
        last_recorded_value=None,
        parent=None
    )

    assert get_shortish_repr('foo') == "'foo'"
    assert get_shortish_repr(1) == '1'
    assert get

# Generated at 2022-06-24 17:23:59.779251
# Unit test for function shitcode
def test_shitcode():
    test_data = (
        (u'\u05d0\u05d1\u05d2', 'abg'),
    )
    for input, expected in test_data:
        actual = shitcode(input)
        assert actual == expected, (
            'shitcode({!r}) = {!r}, should be {!r}'.format(
                input, actual, expected))


# Generated at 2022-06-24 17:24:07.917252
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    bool_1 = True

    def test_inner_nested_function_0():
        bool_2 = True
        bool_1 = False
        if bool_1:
            bool_2 = False
        else:
            bool_3 = True
        bool_4 = bool_3 if bool_3 else bool_1 if bool_1 or bool_2 else bool_2
        bool_5 = False
        bool_6 = True
        return bool_5 if bool_5 or bool_6 else bool_6
    bool_7 = True
    bool_8 = False
    bool_9 = True

# Generated at 2022-06-24 17:24:15.977441
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(True, []) == repr
    assert get_repr_function(True, []) == repr

# Generated at 2022-06-24 17:24:22.036045
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyWritableStream(WritableStream):

        def __init__(self):
            self.written_string = ''

        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'


# Generated at 2022-06-24 17:24:25.915216
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda x: x == True, lambda y: 'yep'),
    )
    assert get_repr_function(True, custom_repr) is custom_repr[0][1]
    assert get_repr_function(False, custom_repr) is repr
    assert get_repr_function(1, custom_repr) is repr



# Generated at 2022-06-24 17:24:29.756522
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert WritableStream.write.__doc__ == '''Write a string to the stream.

    Note that the end of the string may not be immediately visible
    to external readers of the stream.
    '''


# Generated at 2022-06-24 17:24:39.252863
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc def ghi') == 'abc def ghi'
    assert get_shortish_repr(b'abc def ghi') == "b'abc def ghi'"
    assert get_shortish_repr(b'abc def ghi', max_length=5) == "b'a..."
    assert get_shortish_repr(b'abc def ghi', max_length=10) == "b'abc..."
    assert get_shortish_repr(b'abc def ghi', max_length=999999999) ==\
                                                              "b'abc def ghi'"




# Generated at 2022-06-24 17:24:43.640993
# Unit test for function get_repr_function
def test_get_repr_function():
    # Checking if the conditions and action are dict and return in right format

    assert isinstance(get_repr_function(1, (bool, str))[0], bool)
    assert isinstance(get_repr_function(1, (bool, str))[1], str)



# Generated at 2022-06-24 17:24:55.514552
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, []) == __builtins__['repr']
    assert get_repr_function(0, [(0, lambda x: '0')]) == __builtins__['repr']
    assert get_repr_function(0, [(1, lambda x: '0')]) == __builtins__['repr']
    assert get_repr_function(0, [(lambda x: False, lambda x: '0')]) == __builtins__['repr']
    assert get_repr_function(0, [(lambda x: True, lambda x: '0')]) == (lambda x: '0')
    assert get_repr_function(0, [(lambda x: True, lambda x: '0'),
                                 (lambda x: True, lambda x: '1')]) == (lambda x: '0')

# Generated at 2022-06-24 17:24:56.857517
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(test_case_0, ()) == repr




# Generated at 2022-06-24 17:24:59.713967
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    stream = sys.stdout

    stream.write('hello world')

    stream.write('This is line no 1\n')

    stream.write('This is line no 2\n')

    stream.write("I'm here")



# Generated at 2022-06-24 17:25:04.526684
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import pytest
    import tempfile
    import os

    # Test: Calling WritableStream.write with a string argument should write
    # that string to the file.
    with tempfile.TemporaryFile() as file_:
        file_.write(b'aaa')
        file_.flush()
        file_.seek(0)
        assert file_.read() == b'aaa'



# Generated at 2022-06-24 17:25:18.654326
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hello', [(bool, lambda x: 'yes!')]) == repr
    assert get_repr_function(True, [(bool, lambda x: 'yes!')]) == (lambda x:
                                                                   'yes!')
    assert get_repr_function(0, [(bool, lambda x: 'yes!')]) == repr
    assert get_repr_function(None, [(bool, lambda x: 'yes!')]) == repr
    assert get_repr_function(NotImplemented, [(bool, lambda x: 'yes!')]) == \
        repr
    assert get_repr_function(Ellipsis, [(bool, lambda x: 'yes!')]) == repr



# Generated at 2022-06-24 17:25:21.673361
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream = WritableStream()
    writable_stream.write('test')
    print('test_WritableStream_write')


# Generated at 2022-06-24 17:25:24.225547
# Unit test for function shitcode
def test_shitcode():
    '''
    # TODO: Implement the function and remove this.
    '''
    raise NotImplementedError('shitcode() needs to be implemented before \
                              this test can be run.')



# Generated at 2022-06-24 17:25:28.255473
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    temp_var_0 = sys.stdout
    sys.stdout = WritableStream()
    sys.stdout.write('foo')
    sys.stdout = temp_var_0


# Generated at 2022-06-24 17:25:37.480056
# Unit test for function get_repr_function
def test_get_repr_function():
    from . import dots_repr
    from . import list_repr
    from . import set_repr
    from . import tuple_repr
    from . import dict_repr
    from . import ordered_dict_repr
    from . import object_repr_modules
    from . import object_repr

# Generated at 2022-06-24 17:25:49.388835
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test whether it accepts all kinds of arguments
    from .pycompat import io
    from .pycompat import str
    from .pycompat import bytes
    from .pycompat import unicode
    from .pycompat import bytearray
    from .pycompat import file
    from .pycompat import buffer
    from .pycompat import memoryview
    from .pycompat import xrange
    from .pycompat import StringIO
    from .pycompat import cStringIO
    from .pycompat import StringIO
    from .pycompat import unicode_type
    from .pycompat import string_types
    from .pycompat import IS_PY2
    from .pycompat import BytesIO
    from .pycompat import cStringIO
    from .pycompat import StringIO

# Generated at 2022-06-24 17:26:01.053230
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('a') == 'a'
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\ndef') == 'abc?def'
    assert shitcode(u'abc\ndef') == 'abc?def'
    assert shitcode('abc\r\ndef') == 'abc??def'
    assert shitcode('abc\r\n\rdef') == 'abc???def'
    assert shitcode('abc\ndef\nefg\nhij') == 'abc?def?efg?hij'
    assert shitcode(u'abc\ndef\nefg\nhij') == 'abc?def?efg?hij'

# Generated at 2022-06-24 17:26:07.221247
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_1 = WritableStream()
    try:
        var_1.write('foo')
    except Exception as e:
        print('e:')
        print(e)
        print('e.__class__:')
        print(e.__class__)
        print('e.__class__.__name__:')
        print(e.__class__.__name__)
        print('e.args:')
        print(e.args)
        print('e.args[0]:')
        print(e.args[0])
        print('e.args[1]:')
        print(e.args[1])
        print('e.args[2]:')
        print(e.args[2])
        print('e.message:')
        print(e.message)
        print('dir(e):')

# Generated at 2022-06-24 17:26:10.721935
# Unit test for function get_repr_function
def test_get_repr_function():
    try:
        # test for Default case
        assert get_repr_function(list(), [])

    except AssertionError as e:
        print('Auto-generated exception: AssertionError')
        raise

    else:
        pass


# Generated at 2022-06-24 17:26:17.973542
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    try:
        test_case_0()
    except AssertionError as e:
        print('AssertionError:', e)
        raise
    except Exception as e:
        print('Exception:', e)
        raise

if __name__ == '__main__':
    if sys.flags.optimize >= 2:
        print('The test module must be run with -O0 or debug mode.')
        sys.exit(2)
    test_get_shortish_repr()

# Generated at 2022-06-24 17:26:27.746771
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    list_0 = []
    var_0 = get_shortish_repr(list_0)



# Generated at 2022-06-24 17:26:29.777798
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(7, ((str, shitcode), (list, repr))) == repr


# Generated at 2022-06-24 17:26:35.120761
# Unit test for function shitcode
def test_shitcode():
    s = 'asdfasdf'
    assert shitcode(s) == s

    s = 'שדג'
    assert shitcode(s) == '????????'

    s = 'שדג123'
    assert shitcode(s) == '?????123'

    s = 'שדג123\x00'
    assert shitcode(s) == '?????123?'

# Generated at 2022-06-24 17:26:37.461644
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    f = lambda: 42
    stream = WritableStream()
    assert stream.write('hello') is None
    assert stream.write(f) is None

# Generated at 2022-06-24 17:26:41.089985
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    stream.write('')
    stream.write('hello world')
    stream.write('hello\nworld')
    stream.write('hello\rworld')
    stream.write('hello world! '*10)



# Generated at 2022-06-24 17:26:42.010556
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass



# Generated at 2022-06-24 17:26:53.151764
# Unit test for function get_repr_function
def test_get_repr_function():
    class TestClass:
        def test(self, val):
            return val * 3

        def __repr__(self):
            return 'TestClass()'
    testObj = TestClass()
    assert get_repr_function(testObj, [(lambda x: isinstance(x, TestClass),
                                        testObj.test)])(5) == 15
    assert get_repr_function(testObj, [(lambda x: isinstance(x, int),
                                        testObj.test)])(5) == 5
    assert get_repr_function(testObj, [])(testObj) == 'TestClass()'
    assert get_repr_function('hello', []) == repr
    assert get_repr_function('hello', [(str, 'hello')]) == 'hello'

# Generated at 2022-06-24 17:26:54.568319
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    test_case_0()




# Generated at 2022-06-24 17:26:56.674635
# Unit test for function get_repr_function
def test_get_repr_function():
    # Test function get_repr_function for int
    int_0 = get_repr_function(1, (lambda x: True, 'A'))


# Generated at 2022-06-24 17:26:59.004219
# Unit test for function shitcode
def test_shitcode():
    list_0 = ['a', 'b', 'c']
    var_0 = shitcode('a\x00b\x00c')
    assert(var_0 == 'a?b?c')


# Generated at 2022-06-24 17:27:08.387983
# Unit test for method write of class WritableStream

# Generated at 2022-06-24 17:27:10.245340
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('abc', custom_repr=[(bool, bool), (None, str)]) == str



# Generated at 2022-06-24 17:27:12.934034
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # list_0 = []
    test_case_0()

# Generated at 2022-06-24 17:27:22.567319
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    list_0 = []
    var_0 = get_shortish_repr(list_0)
    assert var_0 == "[]"

    list_1 = [1, 2, 3]
    var_1 = get_shortish_repr(list_1)
    assert var_1 == "[1, 2, 3]"

    list_2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    var_2 = get_shortish_repr(list_2)
    assert var_2 == ("[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]")

    list_3 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]

# Generated at 2022-06-24 17:27:26.586161
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [(lambda x: True, lambda x: 'A')]

# Generated at 2022-06-24 17:27:34.353766
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert issubclass(WritableStream, ABC)
    assert issubclass(WritableStream, collections_abc.Awaitable)
    assert issubclass(WritableStream, collections_abc.AsyncIterable)
    assert issubclass(WritableStream, collections_abc.AsyncContextManager)
    assert issubclass(WritableStream, collections_abc.Coroutine)
    assert issubclass(WritableStream, collections_abc.Generator)
    assert issubclass(WritableStream, collections_abc.Iterator)
    assert issubclass(WritableStream, collections_abc.Reversible)
    assert issubclass(WritableStream, collections_abc.Sized)
    assert issubclass(WritableStream, collections_abc.Callable)
    assert issubclass(WritableStream, collections_abc.Container)
    assert issubclass

# Generated at 2022-06-24 17:27:44.989816
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    #TODO: more tests
    from .python_toolbox import sequence_tools
    from .python_toolbox import misc_tools
    from .python_toolbox import string_tools
    from .python_toolbox import math_tools
    from .python_toolbox import caching

    assert shortish_repr('hello world') == "'hello world'"
    assert shortish_repr((0, 1, 2, 3)) == "(0, 1, 2, 3)"
    assert shortish_repr({'a': 1}) == "{'a': 1}"
    assert shortish_repr(1 + 2j) == "(1+2j)"
    assert shortish_repr(misc_tools.Sentinel) == 'misc_tools.Sentinel'

# Generated at 2022-06-24 17:27:52.847839
# Unit test for function get_repr_function
def test_get_repr_function():
    list_1 = [1, 2, 3]
    tuple_1 = (1, 2, 3)
    dict_1 = {1: 2, 3: '4'}
    set_1 = {1, 2, 3}
    frozenset_1 = frozenset((1, 2, 3))
    custom_repr = ((list, str), (dict, lambda x: x))

    assert get_repr_function(list_1, custom_repr=custom_repr) == str
    assert get_repr_function(tuple_1, custom_repr=custom_repr) == repr
    assert get_repr_function(dict_1, custom_repr=custom_repr) == dict_1

# Generated at 2022-06-24 17:27:55.230535
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # ???
    stream_0 = WritableStream()
    assert getattr(stream_0, 'write') is None
    # ???
    stream_1 = WritableStream()
    assert getattr(stream_1, 'write') is None



# Generated at 2022-06-24 17:27:57.560507
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = WritableStream()
    stream.write('')
    stream.write('')
    stream.write('abc')
    stream.write('xxx')



# Generated at 2022-06-24 17:28:18.251045
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    a = list_0  # class list

    a.append(5)  # method list.<locals>.append
    a[1] = 100  # method list.<locals>.<setitem>
    a.extend([2, 3, 4])  # method list.<locals>.extend



# Generated at 2022-06-24 17:28:20.650447
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    x = WritableStream()
    x.write('')

# Generated at 2022-06-24 17:28:23.313591
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # def test_case_0():
    #     list_0 = []
    #     var_0 = get_shortish_repr(list_0)
    var_0 = sys.stdout.write(0)



# Generated at 2022-06-24 17:28:32.095691
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda x: isinstance(x, list),
         lambda x: '{}(len={})'.format(type(x).__name__, len(x))),
    )
    assert get_repr_function(0, custom_repr) is repr
    assert get_repr_function([], custom_repr) is not repr



# Generated at 2022-06-24 17:28:32.733254
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass


# Generated at 2022-06-24 17:28:44.940691
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    instance_0 = WritableStream()

# Generated at 2022-06-24 17:28:48.330297
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    list_0 = []
    var_0 = WritableStream()
    var_0.write(list_0)


# Generated at 2022-06-24 17:28:51.670650
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    list_0 = []
    var_0 = get_shortish_repr(list_0)
    assert var_0 == '[]'



# Generated at 2022-06-24 17:28:56.766751
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('foo', ()) == repr

    assert get_repr_function('foo', (
        (type('bar'), lambda x: 'BAZ')
    )) == repr


# Generated at 2022-06-24 17:28:59.930060
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    w = WritableStream()
    try:
        w.write('')
    except NotImplementedError:
        pass
    else:
        raise RuntimeError


# Generated at 2022-06-24 17:29:25.277276
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_class = WritableStream
    function_name = 'write'
    def test_function():
        # Empty call from `test_case_0`.
        list_0 = []
        var_0 = test_class.write(list_0)



# Generated at 2022-06-24 17:29:29.768519
# Unit test for function get_repr_function
def test_get_repr_function():
    assert type(get_repr_function('', ())) is type(repr)
    assert get_repr_function('', ((_, _),))(0) == '0'
    assert type(get_repr_function('', ((_, 'a'),))) is type(repr)
    assert get_repr_function('', ((_, 'a'),))(0) == '0'
    
    
    

# Generated at 2022-06-24 17:29:32.906635
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Thingy(WritableStream):
        def write(self, s):
            pass

    thing = Thingy()
    thing.write('')



# Generated at 2022-06-24 17:29:35.039624
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    list_0 = []
    var_0 = WritableStream()
    var_1 = WritableStream()
    var_0.write(var_1)

# Generated at 2022-06-24 17:29:36.717902
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream_0 = sys.stdout
    stream_0.write('C')



# Generated at 2022-06-24 17:29:51.767483
# Unit test for function get_repr_function
def test_get_repr_function():
    class MyClass0: pass
    class MyClass1(MyClass0): pass
    class MyClass2(MyClass0): pass
    class MyClass3(MyClass0): pass

    my_instance0 = MyClass0()
    my_instance1 = MyClass1()
    my_instance2 = MyClass2()
    my_instance3 = MyClass3()

    custom_repr = (
        (lambda x: isinstance(x, MyClass0), lambda x: 'myclass0 repr'),
        (MyClass1, lambda x: 'myclass1 repr'),
        (MyClass1, lambda x: 'myclass1 repr again')
    )

    assert get_repr_function(my_instance0, custom_repr)() == 'myclass0 repr'

# Generated at 2022-06-24 17:29:53.443514
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Test:
        def write(self, s):
            return None

    assert issubclass(Test, WritableStream)

# Generated at 2022-06-24 17:29:54.224710
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass

# Generated at 2022-06-24 17:30:04.057625
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # line 4 "test_writable_stream.py"
    f = open('out.txt', 'wb')
    stream_0 = WritableStream()
    stream_0.write(f'{shitcode("hello")}')
    f.write(f'{var_0}\n'.encode())
    f.close()
    codeobj_0 = sys._getframe().f_code
    codeobj_1 = lambda: None # Singleton
    codeobj_1.co_filename = test_WritableStream_write.__code__.co_filename
    codeobj_1.co_name = test_WritableStream_write.__code__.co_name
    codeobj_1.co_firstlineno = 4
    codeobj_1.co_argcount = 0

# Generated at 2022-06-24 17:30:11.733272
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, (('', lambda x: 'bla'),)) == 'bla'
    assert get_repr_function(1, (('', lambda x: None),)) is None
    assert get_repr_function(1, ((lambda x: True, lambda y: 'bla'),)) == 'bla'
    assert get_repr_function(1, ((lambda x: False, lambda y: 'bla'),)) == repr



# Generated at 2022-06-24 17:31:13.184955
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    writable_stream_0.write('Hello')

# Generated at 2022-06-24 17:31:23.180346
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # We will test that writing to a file-like object with a encoding specified
    # writes the correct string.

    class CustomWritableStream(WritableStream):
        def __init__(self):
            self.calls = []
        def write(self, s):
            self.calls.append(s)

    writable_stream_0 = CustomWritableStream()
    writable_stream_0.write('Hello, world!')
    assert writable_stream_0.calls == ['Hello, world!']
    writable_stream_0.write(' Goodbye')
    assert writable_stream_0.calls == ['Hello, world!', ' Goodbye']

