

# Generated at 2022-06-24 17:21:24.483829
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    ws = sys.stdout
    ws.write('a')



# Generated at 2022-06-24 17:21:34.906605
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'a'),)) == 'a'
    assert get_repr_function(1.0, ((int, lambda x: 'a'),)) != 'a'
    assert get_repr_function(1, ((int, 'a'),)) == 'a'
    assert get_repr_function(1, (((int, float), 'a'),)) != 'a'
    try:
        assert get_repr_function(1, (((int, float), 1),)) == '1'
    except Exception:
        sys.stderr.write(
            '\n\n!!!!!FAILED!!!!!!\n\n'
        )



# Generated at 2022-06-24 17:21:43.345989
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr(False) == 'False'
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1.0) == '1.0'
    assert get_shortish_repr('pįp') == "u'p\\u012dp'"
    assert get_shortish_repr('עברית') == "u'\\u05e2\\u05d1\\u05e8\\u05d9\\u05ea'"



# Generated at 2022-06-24 17:21:46.157171
# Unit test for function get_repr_function
def test_get_repr_function():
    bytes_0 = None
    get_repr_function(bytes_0, [['', '']])


# Generated at 2022-06-24 17:21:49.987281
# Unit test for function shitcode
def test_shitcode():
    assert test_case_0() == None, \
        'Failure in line 10, test case 0 of test_shitcode'




# Generated at 2022-06-24 17:22:00.585477
# Unit test for function get_repr_function
def test_get_repr_function():
    def func_0(x):
        return

    @staticmethod
    def func_1(x):
        return

    class Class_0:
        def func_2(self, x):
            return

        @classmethod
        def func_3(cls, x):
            return

        @staticmethod
        def func_4(x):
            return

    try:
        yield func_0, Class_0.func_2
        yield func_0, Class_0.func_3
        yield func_0, Class_0.func_4
    except AttributeError as e:
        pass

# Generated at 2022-06-24 17:22:04.180423
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    try:
        var_1 = sys.stdout
    except IOError:
        pass
    else:
        var_1.write(var_0)



# Generated at 2022-06-24 17:22:13.802566
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    buffer_size = 4096
    buffer = bytearray(buffer_size)
    stream = sys.stdout.buffer  # type: WritableStream

    def write_ASCII(s, start, end):
        stream.write(s.encode('ascii', errors='replace'))

    def write_UTF8(s, start, end):
        stream.write(s.encode('utf8', errors='replace'))

    def write_binary(s, start, end):
        stream.write(s[start:end].encode('raw_unicode_escape'))

    async def write(s, start=0, end=sys.maxsize, flush=False):
        if end <= start:
            return
        if start:
            s = s[start:]


# Generated at 2022-06-24 17:22:22.366610
# Unit test for function get_repr_function
def test_get_repr_function():
    assert repr(get_repr_function('foo', ())) == "repr"
    assert repr(get_repr_function('foo', ((str, lambda x: 'bar'),))) == \
                                                               "str(<lambda>)"
    assert repr(get_repr_function('foo', ((str, lambda x: 'bar'),
                                          (int, lambda x: 5)))) == \
                                                               "str(<lambda>)"
    assert repr(get_repr_function(5, ((str, lambda x: 'bar'),
                                      (int, lambda x: 5)))) == "5"
    assert repr(get_repr_function(5, ((str, lambda x: 'bar'),
                                      (int, lambda x: 'five')))) == \
                                                              "str(<lambda>)"
    assert repr

# Generated at 2022-06-24 17:22:23.973744
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from . import WritableStream
    w = WritableStream()
    w.write('\n')


# Generated at 2022-06-24 17:22:40.323988
# Unit test for function shitcode
def test_shitcode():
    # since the function expects different inputs, we will use a loop to test
    # all inputs
    for i in range(3):
        if i == 0:
            bytes_0 = None
        elif i == 1:
            bytes_0 = b'\x00\x01\x00\x01'
        else:
            bytes_0 = b'\x01\x00\x02\x00'
        var_0 = shitcode(bytes_0)
        if (var_0 != '?' if (i in (0, 2)) else '\x00\x01\x00\x01'):
            return 'shitcode test failed'
    return 'shitcode test done'


# Generated at 2022-06-24 17:22:47.855580
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from . import get_shortish_repr
    from . import get_repr_function

    def assert_repr(obj, expected_repr):
        actual_repr1 = get_shortish_repr(obj)
        assert actual_repr1 == expected_repr, \
               'actual_repr1={!r}'.format(actual_repr1)
        actual_repr2 = get_shortish_repr(obj, max_length=len(expected_repr))
        assert actual_repr2 == expected_repr, \
               'actual_repr2={!r}'.format(actual_repr2)
        actual_repr3 = get_repr_function(obj)(obj)

# Generated at 2022-06-24 17:22:48.762411
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass


# Generated at 2022-06-24 17:22:52.480407
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    ws = sys.stdout
    ws.write('hello world!\n')
    ws.flush()
################################################################################
# Region: custom reprs



# Generated at 2022-06-24 17:23:00.214224
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class C: pass
    class D(C): pass
    assert get_shortish_repr(C) == '__main__.C'
    assert get_shortish_repr(D) == '__main__.D'
    def f(x):
        return '<%s>' % x
    assert get_shortish_repr(C, custom_repr=((f, f),)) == '<__main__.C>'
    assert get_shortish_repr(D, custom_repr=((C, f),)) == '<__main__.D>'
    assert get_shortish_repr(D, custom_repr=((C, f),)) == '<__main__.D>'
    assert get_shortish_repr(D(), custom_repr=((C, f),))

# Generated at 2022-06-24 17:23:04.325985
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(value=sys, custom_repr=None) is repr
    assert get_repr_function(value=None, custom_repr=None) is repr


# Generated at 2022-06-24 17:23:08.628242
# Unit test for function get_repr_function
def test_get_repr_function():
    if isinstance(UnitTest_get_repr_function, type): # If a class
        UnitTest_get_repr_function()
    else: # If a function
        UnitTest_get_repr_function()


# Generated at 2022-06-24 17:23:15.482621
# Unit test for function get_repr_function
def test_get_repr_function():
    eval_0 = get_repr_function(str, str)
    eval_1 = False
    eval_2 = get_repr_function(str, str)
    eval_3 = eval_2 == eval_0
    eval_4 = 'function' in eval_1
    if eval_4 and eval_3:
        var_0 = True
    else:
        var_0 = False
    assert var_0



# Generated at 2022-06-24 17:23:17.628239
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_WritableStream_write_0()
    test_WritableStream_write_1()


# Generated at 2022-06-24 17:23:21.000583
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    print("Testing method write of class WritableStream...")
    bytes_0 = None
    writable_stream_0 = WritableStream()
    writable_stream_0.write(bytes_0)


# Generated at 2022-06-24 17:23:30.834910
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class Dummy1(object):
        def __repr__(self):
            return '{}(repr)'.format(self.__class__.__name__)

    class Dummy2(Dummy1):
        pass

    class Dummy3(Dummy2):
        def __init__(self, id):
            self.id = id

        def __repr__(self):
            return '{}({!r})'.format(self.__class__.__name__, self.id)

    class Dummy4(Dummy3):
        def __repr__(self):
            return '{}(repr, but failing)'.format(self.__class__.__name__)
    assert get_shortish_repr(1) == '1'

# Generated at 2022-06-24 17:23:40.488317
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # As bytes_0 is None, both branches are executed. This branch is
    # executed first. Also, this branch sets var_0 to "None".
    var_0 = None
    if not var_0:
        var_0 = 'None'
    else:
        var_0 = 'not None'

    # This branch is executed second, because above branch causes
    # var_0 to be "None". Therefore, this branch is executed.
    # This branch does not set var_0 to a new value.
    if var_0:
        var_0 = 'no new var_0'
    else:
        var_0 = 'new var_0'

    # var_0 is in fact "new var_0"
    assert var_0 == 'new var_0', var_0



# Generated at 2022-06-24 17:23:52.117859
# Unit test for function get_repr_function
def test_get_repr_function():
    """Test if get_repr_function function works as expected"""
    def first():
        yield 0
    def second():
        pass
    assert get_repr_function(first(), [
            (lambda fn: True, repr),
            (lambda fn: False, second)
        ]) == repr
    assert get_repr_function(first(), []) == repr
    assert get_repr_function(first(), [
            (lambda fn: False, second)
        ]) == repr
    assert get_repr_function(first(), [
            (lambda fn: True, second)
        ]) == second
    assert get_repr_function(first(), [
            (lambda fn: True, second),
            (lambda fn: False, second)
        ]) == second

# Generated at 2022-06-24 17:23:55.699051
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stdout
    try:
        stream.write(b'hello')
    except AttributeError:
        pass


# Generated at 2022-06-24 17:24:03.355731
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = sys.stdout.write

# Generated at 2022-06-24 17:24:09.990674
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import pathlib
    import os
    from .pycompat import zip

    from .compat import StringIO
    from .compat import BytesIO

    class ShitFile(StringIO):
        name = 'shitfile.txt'

    class ShitFile2(StringIO):
        name = 'shitfile.txt'

    def test_cases():
        yield ('עברית', (), {}, 'עברית')
        yield ('a' * 100, (), {}, 'a' * 100)
        yield ('a' * 100, (), {'max_length': 30}, 'a' * 30 + '...' + 'a' * 30)

# Generated at 2022-06-24 17:24:17.548945
# Unit test for function get_repr_function
def test_get_repr_function():
    class Test:
        def __repr__(self):
            return 'test'
    custom_repr = (
        (str, lambda x: 'abc'),
        (Test, lambda x: 'test'),
    )

# Generated at 2022-06-24 17:24:24.042030
# Unit test for function get_repr_function
def test_get_repr_function():
    a = 1
    b = 'lol'
    c = {'strange'}
    d = (1, 2)
    assert get_repr_function(a) == repr
    assert get_repr_function(b) == repr
    assert get_repr_function(c) == repr
    assert get_repr_function(a, ((type(a), repr),)) == repr
    assert get_repr_function(b, ((type(a), repr),)) == repr
    assert get_repr_function(c, ((type(a), repr),)) == repr
    assert get_repr_function(d, ((type(a), repr),)) == repr
    assert get_repr_function(a, ((int, repr),)) == repr

# Generated at 2022-06-24 17:24:26.774702
# Unit test for function shitcode
def test_shitcode():
    test_bytes_0 = None
    assert shitcode(test_bytes_0) is None


# Generated at 2022-06-24 17:24:27.992159
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    bytes_0 = None
    var_0 = WritableStream()
    var_0.write(bytes_0)



# Generated at 2022-06-24 17:24:38.777778
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (lambda x: x > 2, str)) == repr
    assert get_repr_function(3, (lambda x: x > 2, str)) == str
    assert get_repr_function([1, 2, 3], ((list, tuple), str)) == str
    assert get_repr_function(1, ((list, tuple), str)) == repr


# Generated at 2022-06-24 17:24:44.479347
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestClass:
        def write(self, text):
            return text
    class TestClass2:
        def write(self, text):
            pass
    writable_stream = TestClass()
    assert is_writable_stream(writable_stream)

    new_writable_stream = TestClass2()
    assert is_writable_stream(new_writable_stream)



# Generated at 2022-06-24 17:24:48.216769
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, []) == repr
    assert get_repr_function(0, [(int, str)]) == str
    assert get_repr_function(0, [(TypeError, str)]) == repr


# Generated at 2022-06-24 17:24:50.301196
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    f = open('out.txt', 'w')

    f.write('This is a test\n')
    f.close()



# Generated at 2022-06-24 17:24:55.297262
# Unit test for function shitcode
def test_shitcode():
    from pickle import loads, dumps
    assert loads(dumps(shitcode))(b'abc') == b'abc'
    assert loads(dumps(shitcode))(b'ab\xc2\xca') == b'ab??'




# Generated at 2022-06-24 17:25:06.620387
# Unit test for function get_repr_function
def test_get_repr_function():
    class X():
        def __repr__(self): return 'X'
    class Y(X): pass

    assert get_repr_function(1, [(Y, lambda x: 'Y')]) == repr
    assert get_repr_function(1, [(int, lambda x: 'int')]) == repr
    assert get_repr_function('1', [(int, lambda x: 'int')]) == repr
    assert get_repr_function('1', [(str, lambda x: 'str')]) == repr
    assert get_repr_function(1, [(str, lambda x: 'str')]) == repr
    assert get_repr_function(X(), [(type(X()), lambda x: 'X')]) == repr
    assert get_repr_function(X(), [(X, lambda x: 'X')]) == repr
   

# Generated at 2022-06-24 17:25:10.822658
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = sys.stderr
    test_string = 'Test string'
    stream.write(test_string)
    try:
        stream.write(test_string)
    except IOError:
        pass

# Generated at 2022-06-24 17:25:13.099134
# Unit test for function shitcode
def test_shitcode():
    # Default test
    bytes_0 = None
    var_0 = shitcode(bytes_0)
    assert var_0 == ""

# Generated at 2022-06-24 17:25:16.524871
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    a = "abcd"
    assert get_shortish_repr(a, max_length=3) == "abc"



# Generated at 2022-06-24 17:25:25.591108
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import pytest
    from .pycompat import is_python_2
    if is_python_2:
        import sys
        import StringIO
        class Stream(WritableStream):
            def __init__(self):
                self.stream = StringIO.StringIO()
            def write(self, s):
                self.stream.write(s)
            def __repr__(self):
                return repr(self.stream.getvalue())
    else:
        import io
        class Stream(WritableStream):
            def __init__(self):
                self.stream = io.StringIO()
            def write(self, s):
                self.stream.write(s)
            def __repr__(self):
                return repr(self.stream.getvalue())

    stream = Stream()

# Generated at 2022-06-24 17:25:50.377537
# Unit test for function shitcode
def test_shitcode():
    assert issubclass(WritableStream, collections_abc.Sized)
    assert shitcode('') == ''
    assert shitcode(b'zzz') == 'zzz'
    assert shitcode(b'\xFF') == '?'
    assert shitcode(b'\x01\x02\x03') == '\x01\x02\x03'
    assert shitcode('\xFF') == '?'
    assert shitcode('\x01\x02\x03') == '\x01\x02\x03'
    assert shitcode('\r\n') == '\r\n'
    assert shitcode(chr(0x7E)) == '?'
    assert shitcode(u'\u2713') == '?'
    assert issubclass(WritableStream, collections_abc.Iterable)


# Generated at 2022-06-24 17:25:53.259673
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    bytes_0 = None
    var_0 = WritableStream()
    var_0.write(bytes_0)


# Generated at 2022-06-24 17:25:55.150044
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1) == repr


# Generated at 2022-06-24 17:25:59.510451
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = ((int, lambda x: str(x)),)
    assert get_repr_function(b'123', custom_repr) == bytes.__repr__
    assert get_repr_function(123, custom_repr) == custom_repr[0][1]


# Generated at 2022-06-24 17:26:04.816154
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    kls = get_shortish_repr(3)
    assert isinstance(kls, str)
    assert kls == '3'
    kls = get_shortish_repr('hello')
    assert isinstance(kls, str)
    assert kls == "'hello'"
    kls = get_shortish_repr('hello', max_length=1)
    assert isinstance(kls, str)
    assert kls == "'h...'"



# Generated at 2022-06-24 17:26:08.572453
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    bytes_0 = None
    var_0 = WritableStream()
    var_0.write(bytes_0)

# This method tests the is_py3k property of the sys module

# Generated at 2022-06-24 17:26:10.943877
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hello', ((str, lambda x: x+'!!!'),)) == ('hello!!!')
    assert get_repr_function('hello', ()) == ('hello')


# Generated at 2022-06-24 17:26:22.525126
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # get_shortish_repr(item, custom_repr=(), max_length=None)
    # test if input / output is equal
    assert get_shortish_repr("input") == "input"

    # test if max length is less or equal to input string length
    assert get_shortish_repr("input", max_length=2) == "input"

    # test if max length is greater than input string length and
    # input string length is less than or equal to max length - 3
    assert get_shortish_repr("input", max_length=4) == "inpu"

    # test if max length is greater than input string length and
    # input string length is less than or equal to max length + 8
    assert get_shortish_repr("input", max_length=10) == "input"

    #

# Generated at 2022-06-24 17:26:29.625842
# Unit test for function get_repr_function
def test_get_repr_function():

    custom_repr = (
        (lambda x: x.__class__.__name__ == 'C',
         lambda x, **kwargs: '{0.__class__.__name__}({0.x})'.format(x)
        ),
    )
    class C:
        def __init__(self, x):
            self.x = x
    assert get_repr_function(C(1), custom_repr) == repr
    assert get_repr_function(C(1), custom_repr) == repr
    assert get_repr_function(C(1), custom_repr) == repr
    assert get_repr_function(C(1), custom_repr) == repr
    assert get_repr_function(C(1), custom_repr) == repr
    assert get_repr_

# Generated at 2022-06-24 17:26:34.149619
# Unit test for function shitcode
def test_shitcode():
    print(shitcode('\x00'))
    print(shitcode(u'abc'))
    print(shitcode('\xf1'))
    #assert shitcode('\x00') == '?'
    #assert shitcode(u'abc') == u'abc'
    #assert shitcode('\xf1') == '?'



# Generated at 2022-06-24 17:26:49.222805
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1234) == '1234'
    assert get_shortish_repr(1234, max_length=3) == '123'
    assert get_shortish_repr(1234, max_length=2) == '12...'
    assert get_shortish_repr(1234, max_length=2, normalize=True) == '12...'
    assert get_shortish_repr(1234567, max_length=8, normalize=True) == '123...67'
    assert get_shortish_repr('12345678', max_length=8) == '12345678'
    assert get_shortish_repr('12345678', max_length=7) == '123456...'

# Generated at 2022-06-24 17:26:53.007778
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    file_0 = open('output.log', 'w+')
    class_0 = WritableStream
    bytes_0 = 'test'
    method_0 = class_0.write
    var_0 = method_0(file_0, bytes_0)
    file_0.close()
    return var_0


# Generated at 2022-06-24 17:27:01.624386
# Unit test for function get_shortish_repr

# Generated at 2022-06-24 17:27:10.324255
# Unit test for function get_repr_function
def test_get_repr_function():
    # Test for default repr
    item = ['str']
    repr_function = get_repr_function(item)
    repr_result = repr_function(item)
    assert repr_result == "['str']"
    # Test for function with order
    custom_repr = ((lambda x: True, lambda x: 'repr_me'),
                   (lambda x: x == 1, lambda x: 'repr_me_too'))
    repr_function = get_repr_function(1, custom_repr)
    repr_result = repr_function(1)
    assert repr_result == 'repr_me_too'
    # Test for type with order
    custom_repr = ((list, lambda x: 'repr_me'),
                   (dict, lambda x: 'repr_me_too'))
    repr_

# Generated at 2022-06-24 17:27:17.301540
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    from pickle import _compat_pickle

    # Testing of function `get_shortish_repr` with no parameters
    # Return type: <class 'str'>
    assert isinstance(get_shortish_repr(42), str)
    # Testing of function `get_shortish_repr` with parameters:
    #   (max_length=None)
    # Return type: <class 'str'>
    assert isinstance(get_shortish_repr(42, max_length=None), str)
    # Testing of function `get_shortish_repr` with parameters:
    #   (max_length=int)
    # Return type: <class 'str'>

# Generated at 2022-06-24 17:27:19.261025
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    # Init instance
    stream = None
    s = None
    stream.write(s)

# Generated at 2022-06-24 17:27:20.724988
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeTest_0(WritableStream):
        def write(self, s):
            return



# Generated at 2022-06-24 17:27:21.393694
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass

# Generated at 2022-06-24 17:27:24.241133
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream_0 = None
    s_0 = None
    stream_0.write(s_0)


# Generated at 2022-06-24 17:27:32.027483
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(2, (
        (lambda x: x == 2, 'two'),
        (lambda x: x == 4, 'four'),
    )) == 'two'
    assert get_repr_function(3, (
        (lambda x: x == 2, 'two'),
        (lambda x: x == 4, 'four'),
    )) == repr
    assert get_repr_function(
        'a',
        ((str, lambda x: 'got a unicode string'),)
    ) == 'got a unicode string'


# Generated at 2022-06-24 17:27:55.022087
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, []) == repr



# Generated at 2022-06-24 17:27:56.394835
# Unit test for function shitcode
def test_shitcode():
    assert test_case_0() is None


# Generated at 2022-06-24 17:28:04.892312
# Unit test for function get_repr_function
def test_get_repr_function():

    assert normalize_repr('"poom" at 0xDEADBEEF') == '"poom"'

    assert get_repr_function(5, custom_repr=(
        (lambda x: x < 10, lambda x: 'small'),
    ))(5) == 'small'

    assert get_repr_function('', custom_repr=(
        (lambda x: x == '', lambda x: 'empty'),
    ))('') == 'empty'

    assert get_repr_function('', custom_repr=(
        (lambda x: x == '', lambda x: 'empty'),
        (lambda x: not x, lambda x: 'false'),
    ))('') == 'empty'


# Generated at 2022-06-24 17:28:06.478311
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import StringIO
    stream = StringIO()
    stream.write('abc def')

# Generated at 2022-06-24 17:28:14.232437
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[(lambda x: True, str)]) == str
    assert get_repr_function(1, custom_repr=[(lambda x: False, str)]) == repr
    assert get_repr_function(1, custom_repr=[(1, str)]) == str
    assert get_repr_function(2, custom_repr=[(1, str)]) == repr
    assert get_repr_function(1, custom_repr=[(int, str)]) == str
    assert get_repr_function(1.5, custom_repr=[(int, str)]) == repr


# Generated at 2022-06-24 17:28:15.170885
# Unit test for function shitcode
def test_shitcode():
    test_case_0()


# Generated at 2022-06-24 17:28:16.601488
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    bytes_0 = None
    var_0 = get_shortish_repr(bytes_0)


# Generated at 2022-06-24 17:28:17.977158
# Unit test for function get_repr_function
def test_get_repr_function():
    pass


# Generated at 2022-06-24 17:28:23.628214
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class Class_0(WritableStream):
        def write(self, var_0):
            if False:
                var_0 = ''.join(
                    (c if (0 < ord(c) < 256) else '?') for c in var_0
                )


    Class_0_object_0 = Class_0()

    test_case_0()
    test_case_1()


# Generated at 2022-06-24 17:28:29.938032
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .test_case_0 import var_0, bytes_0
    var_1 = sys.stdout
    assert var_0 == var_1.write(bytes_0)


# Generated at 2022-06-24 17:29:18.099761
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from . import get_shortish_repr
    from . import get_repr_function

    item = (1, 2, 3)
    repr_function = get_repr_function(item)
    repr_function(item)



# Generated at 2022-06-24 17:29:22.152212
# Unit test for function get_repr_function
def test_get_repr_function():
    x = 2
    r = get_repr_function(x, [(lambda x: x < 0, lambda x: 'x < 0')])
    print(r)
    assert r == repr



# Generated at 2022-06-24 17:29:22.901875
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass


# Generated at 2022-06-24 17:29:30.380279
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, normalize=True, max_length=999) == '1'
    assert get_shortish_repr('a', max_length=None) == "'a'"

# Generated at 2022-06-24 17:29:40.090197
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .python_toolbox import dyn_import
    from .python_toolbox import cute_testing
    python_toolbox = dyn_import.install('sys.modules', globals(), '..')
    TestingWritableStream = python_toolbox.ensure_object(WritableStream)
    writable_stream_1 = TestingWritableStream()
    writable_stream_1.write(None)
    writable_stream_1.write(None)
    writable_stream_1.write(None)
    writable_stream_1.write(None)
    writable_stream_1.write(None)
    writable_stream_1.write(None)
    writable_stream_1.write(None)
    writable_stream_1.write(None)
    writable_stream_1.write(None)


# Generated at 2022-06-24 17:29:42.587624
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test whether type of first argument is the WritableStream.write() method's first argument.
    assert type(None) is type(WritableStream.write(None))
    # Test whether the first argument is the WritableStream.write() method's first argument.
    assert None is WritableStream.write(None, None)


# Generated at 2022-06-24 17:29:53.327636
# Unit test for function get_repr_function
def test_get_repr_function():
    a = {'a': 'b'}
    b = (1, 2, a)

    assert get_repr_function(a, {})(a) == repr(a)
    assert get_repr_function(b, {})(b) == repr(b)

    assert get_repr_function(a, [(dict, lambda x: list(sorted(x.items())))
                                 ])(a) == "[('a', 'b')]"
    assert get_repr_function(
        b, [(dict, lambda x: list(sorted(x.items())))
            ])(b) == "(1, 2, [('a', 'b')])"


# Generated at 2022-06-24 17:29:58.479658
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, [(lambda x: True, repr)]) == repr
    assert get_repr_function(0, [(int, repr)]) == repr
    assert get_repr_function(
        '',
        [(int, lambda x: 'int'), (str, lambda x: 'str')]
    ) == 'str'


# Generated at 2022-06-24 17:30:06.458131
# Unit test for function get_repr_function
def test_get_repr_function():
    # Some examples
    assert get_repr_function(3, []) == repr
    assert get_repr_function(3, [(lambda x: True, lambda x: x + 1)]) == (
        lambda x: x + 1
    )
    assert get_repr_function(3, [(lambda x: False, lambda x: x + 1)]) == repr
    assert get_repr_function(3, [
        (lambda x: False, lambda x: x + 1),
        (lambda x: True, lambda x: x * 3)
    ]) == (lambda x: x * 3)
    assert get_repr_function(3, [
        (lambda x: True, lambda x: x * 3),
        (lambda x: True, lambda x: x + 3)
    ]) == (lambda x: x * 3)
   

# Generated at 2022-06-24 17:30:14.116457
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    repr_function = get_repr_function(1, [(1,2)])
    assert repr_function(1) == 2
    assert repr_function(2) == '2'
    assert get_shortish_repr(1, max_length=2, custom_repr=[(1,2)]) == 2
    assert get_shortish_repr(4, max_length=2, custom_repr=[(1,2)]) == '4'
    assert get_shortish_repr(4, max_length=1, custom_repr=[(1,2)]) == '...'
