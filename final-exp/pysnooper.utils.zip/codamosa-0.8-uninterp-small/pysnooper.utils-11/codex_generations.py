

# Generated at 2022-06-24 17:21:23.799564
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    repr_0 = get_shortish_repr(dict_0)
    assert repr_0 == "{}".format(dict_0)


# Generated at 2022-06-24 17:21:35.270585
# Unit test for function get_repr_function
def test_get_repr_function():
    dict_0 = {}
    dict_1 = dict_0.copy()
    dict_setdefault_0 = dict_0.setdefault
    dict_update_0 = dict_0.update
    dict_get_0 = dict_0.get
    dict_clear_0 = dict_0.clear
    dict_pop_0 = dict_0.pop
    dict_popitem_0 = dict_0.popitem
    dict_viewkeys_0 = dict_0.viewkeys
    dict_viewvalues_0 = dict_0.viewvalues
    dict_viewitems_0 = dict_0.viewitems
    dict_keys_0 = dict_0.keys
    dict_values_0 = dict_0.values
    dict_items_0 = dict_0.items
    dict_iterkeys_0 = dict_0.iterkeys

# Generated at 2022-06-24 17:21:37.860362
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(test_case_0, (
        (lambda _: True, lambda _: 'hi'),
    ))() == 'hi'



# Generated at 2022-06-24 17:21:47.256675
# Unit test for function shitcode
def test_shitcode():
    
    # Call function shitcode and check its result against expected result.
    dict_0 = {}
    assert shitcode(dict_0) == '' # test 1
    
    dict_0 = {0: 1, 2: 3}
    assert shitcode(dict_0) == '{0: 1, 2: 3}' # test 2
    
    dict_0 = {0j: 1, 2.0: 3}
    assert shitcode(dict_0) == '{0j: 1, 2.0: 3}' # test 3
    
    dict_0 = {0+0j: 1, 2: 3}
    assert shitcode(dict_0) == '{0j: 1, 2: 3}' # test 4
    
    dict_0 = {}
    var_0 = shitcode(dict_0)

#

# Generated at 2022-06-24 17:21:49.599014
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    dict_0 = {}
    var_0 = WritableStream.write(dict_0)


# Generated at 2022-06-24 17:21:52.462181
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(dict_0, [(lambda item: True, lambda x: '1')]) == '1'



# Generated at 2022-06-24 17:21:59.136653
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    file_object = open("file_0.txt", "wb")
    WritableStream.write(file_object, str(0))
    file_object.close()
    file_object = open("file_0.txt", "rb")
    str_0 = file_object.read()
    file_object.close()
    assert(str(0) == str_0)
    return True


# Generated at 2022-06-24 17:22:09.135537
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    str_0 = """\
        tünes
        """
    dict_0['hello'] = dict_1['world'] = dict_2['fübar'] = str_0
    dict_1[str_0] = dict_2['hello'] = dict_1
    dict_0[dict_0] = dict_1
    dict_1[dict_0] = dict_1
    dict_0['hello'] = dict_1
    dict_0[dict_1] = dict_1
    dict_1[dict_0] = dict_0
    dict_2[dict_0] = dict_1
    dict_1['world'] = dict_1
    dict_2[dict_2] = dict_0

# Generated at 2022-06-24 17:22:12.154498
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert 'foo'

    out = sys.stdout
    writable_stream = WritableStream
    my_stream = writable_stream()
    my_stream.write('foo')

# Generated at 2022-06-24 17:22:21.882357
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .pycompat import zip
    from .pycompat import PY2
    from .tuple_tools import get_shortish_repr

# Generated at 2022-06-24 17:22:30.399276
# Unit test for method write of class WritableStream

# Generated at 2022-06-24 17:22:34.232153
# Unit test for function shitcode
def test_shitcode():
    dict_0 = {}
    var_0 = shitcode(dict_0)
    if var_0 != '':
        print('test_shitcode failed: var_0:', repr(var_0), 'expected:', repr(''))

# Generated at 2022-06-24 17:22:43.888123
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr('span') == "'span'"
    assert get_shortish_repr((1, 2), max_length=9) == '(1, 2)'
    assert get_shortish_repr((1, 2), max_length=6) == '(1...2)'
    assert get_shortish_repr(range(1000), max_length=6) == 'range(...1000)'
    assert get_shortish_repr(range(10), max_length=6) == 'range(...)'
    assert get_shortish_repr(range(10), max_length=5) == 'rang(...)'
    assert get_shortish_repr(range(10), max_length=4) == 'ran(...)'

# Generated at 2022-06-24 17:22:47.177346
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Arrange
    stream_0 = sys.stdout
    # Act
    stream_0.write('test')
    # Assert
    print ("Asssert")
    assert True



# Generated at 2022-06-24 17:22:49.480016
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_0 = WritableStream()
    var_1 = 'test'
    var_0.write(var_1)


# Generated at 2022-06-24 17:22:51.682667
# Unit test for function shitcode
def test_shitcode():
    assert test_case_0() is None, "shitcode failing"



# Generated at 2022-06-24 17:22:54.393228
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Method should return NotImplemented
    assertNotImplemented(WritableStream, 'write', ['hello'])


# Generated at 2022-06-24 17:22:58.065056
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 17:23:03.811249
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # input arguments for the test
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    

    # calling the method
    # var_0 = WritableStream.write(dict_0)
    
    class DummyStream:
        def write(self, string):
            pass
    
    DummyStream.write('foo')
    
    var_0 = DummyStream.write(dict_0)

    # output checking
    # assert var_0 == 
    # assert dict_0 == dict_1
    # assert dict_1 == dict_2
    # assert dict_2 == dict_3
    # assert dict_3 == dict_4
    # assert dict_4 == dict

# Generated at 2022-06-24 17:23:10.458985
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test for write
    writable_stream = StringIO()
    writable_stream.write("Hello, world!")
    assert writable_stream.getvalue() == "Hello, world!"
    # Test for write
    writable_stream = StringIO()
    writable_stream.write("Hello, world!")
    assert writable_stream.getvalue() == "Hello, world!"

# Generated at 2022-06-24 17:23:23.032007
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from copy import copy, deepcopy
    assert get_shortish_repr(test_get_shortish_repr) == '<function test_get_shortish_repr at 0x000001D6F2E2B488>'
    assert len(get_shortish_repr(test_get_shortish_repr, 10)) == 10
    assert get_shortish_repr(test_get_shortish_repr, 10) == '<functio...2B488>'
    assert get_shortish_repr(test_get_shortish_repr, 100, normalize=True) == '<function test_get_shortish_repr>'

# Generated at 2022-06-24 17:23:29.558686
# Unit test for function get_repr_function

# Generated at 2022-06-24 17:23:35.480929
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    obj_0 = {'a': 1}
    var_0 = get_shortish_repr(obj_0)
    assert (var_0 == "{'a': 1}")
    obj_0 = [{'a': 1}, {'b': 2}]
    var_0 = get_shortish_repr(obj_0, max_length=8)
    assert (var_0 == "[{'a': 1...'b': 2}]")
    obj_0 = [{'a': 1}, {'b': 2}]
    var_0 = get_shortish_repr(obj_0, max_length=5)
    assert (var_0 == "[{...}]")
    obj_0 = [{'a': 1}, {'b': 2}]
    var_0 = get_shortish_

# Generated at 2022-06-24 17:23:35.930297
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    dict_0 = {}

# Generated at 2022-06-24 17:23:38.603699
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Initializing variables
    var_0 = WritableStream()
    var_1 = sys.stdout
    # Call method write
    var_1.write('Hello, world!')
    return var_0


test_WritableStream_write()

# Generated at 2022-06-24 17:23:51.307296
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO
    from .pycompat import StringIO

# Generated at 2022-06-24 17:23:55.398528
# Unit test for function shitcode
def test_shitcode():
    dict_0 = {}
    var_0 = shitcode(dict_0)
    assert var_0 == '{}'


# Generated at 2022-06-24 17:23:56.127907
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    pass

# Generated at 2022-06-24 17:24:03.005376
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test whether bytecode optimization affects it
    try:
        file = sys.stdout
        class MyWritableStream(WritableStream):
            def write(self, s):
                file.write(s)

        WritableStream.__subclasscheck__(MyWritableStream)
        assert(MyWritableStream.__subclasscheck__(WritableStream))
    except NotImplemented:
        print("Method write of class WritableStream not defined correctly")
# Test for method truncate

# Generated at 2022-06-24 17:24:09.773455
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    dict_0 = {}
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0
    dict_0['a'] = dict_0


# Generated at 2022-06-24 17:24:20.255058
# Unit test for function get_repr_function
def test_get_repr_function():
    def lambda_0(item):
        return item == 1
    custom_repr = [(lambda_0, lambda item: 'item = {}'.format(item))]
    var_3 = get_repr_function(1, custom_repr)
    var_4 = get_repr_function(2, custom_repr)
    var_1 = 'item = 1'
    var_2 = var_3()
    assert var_1 == var_2
    assert var_4 is repr


# Generated at 2022-06-24 17:24:22.278022
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    dict_0 = {}
    var_1 = get_shortish_repr(dict_0)
    assert var_1 == "{}"


# Generated at 2022-06-24 17:24:24.618396
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    file_1 = sys.stdout
    WritableStream.write(file_1)


# Generated at 2022-06-24 17:24:34.611127
# Unit test for function get_repr_function
def test_get_repr_function():
    from .testtools import eq_
    from .testtools import assert_raises

    custom_repr = [
        (lambda x: x > 0, 'wow'),
        (lambda x: x < 0, 'baz'),
    ]

    repr_function = get_repr_function(1, custom_repr)
    eq_(repr_function(1), 'wow')
    repr_function = get_repr_function(-1, custom_repr)
    eq_(repr_function(-1), 'baz')

    repr_function = get_repr_function(1.5, custom_repr)
    eq_(repr_function(1.5), repr(1.5))


# Generated at 2022-06-24 17:24:37.341261
# Unit test for function shitcode
def test_shitcode():
    dict_0 = {}
    assert shitcode('abc') == 'abc'
    assert shitcode(dict_0) == '{}'



# Generated at 2022-06-24 17:24:39.631586
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    dict_0 = {}
    actual = WritableStream.write(dict_0)
    expected = None
    assert(expected == actual)


# Generated at 2022-06-24 17:24:41.238155
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    WritableStream.write(sys.stdout, 'Hello world')


# Generated at 2022-06-24 17:24:47.294972
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_case_0()


# Packages
# -*- test-cases-order: sorted; -*-

# Local variables:
# mode: Python
# tab-width: 8
# indent-tabs-mode: nil
# End:
# vim: ai et ts=8 sw=4 sts=4

# Generated at 2022-06-24 17:24:57.130956
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from garlicsim.general_misc import cute_testing
    from garlicsim.general_misc.temp_value import TempValue

    assert get_shortish_repr(dict()) == '{}'
    assert get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert get_shortish_repr(set([1, 2, 3])) == 'set([1, 2, 3])'

    assert get_shortish_repr(dict(), max_length=4) == '{}'
    assert get_shortish_repr([1, 2, 3], max_length=4) == '[1...'
    assert get_shortish_repr(set([1, 2, 3]), max_length=4) == 'set...'

# Generated at 2022-06-24 17:25:07.687875
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    test_item = "The quick brown fox jumps over the lazy dog"
    assert get_shortish_repr(test_item) == "The quick brown fox jumps over the lazy dog"
    assert get_shortish_repr(test_item, max_length=50) == "The quick brown fox jumps over the lazy dog"
    assert get_shortish_repr(test_item, max_length=45) == "The quick brown fox jumps over the lazy dog"
    assert get_shortish_repr(test_item, max_length=40) == "The quick brown fox jumps over the lazy ..."
    assert get_shortish_repr(test_item, max_length=35) == "The quick brown fox jumps ove..."

# Generated at 2022-06-24 17:25:13.148593
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Execute
    test_case_0()

    # Assert
    assert dict_0.keys() == {'a': 1, 'b': 2}



# Generated at 2022-06-24 17:25:22.740929
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    dict_0 = {}
    dict_0 = get_shortish_repr(dict_0)
    dict_0 = get_shortish_repr(dict_0, (lambda x: True, lambda _: 'a'))
    dict_0 = get_shortish_repr(dict_0, () or ((lambda x: False, lambda _: 'a')))
    dict_0 = get_shortish_repr(dict_0 or {})
    dict_0 = get_shortish_repr(dict_0, (), 100, True)


# Generated at 2022-06-24 17:25:25.721895
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    import re
    get_shortish_repr(re, max_length=100, normalize=True)


# Generated at 2022-06-24 17:25:36.062982
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    var_0 = WritableStream()
    var_1 = WritableStream()
    var_2 = WritableStream()
    var_3 = WritableStream()
    var_4 = WritableStream()
    def func_0(arg_0):
        var_0.write(arg_0)
    def func_1(arg_0):
        var_1.write(arg_0)
    def func_2(arg_0):
        var_2.write(arg_0)
    def func_3(arg_0):
        var_3.write(arg_0)
    func_4 = lambda arg_0: var_4.write(arg_0)
    import sys
    func_0 = sys.stdout.write
    func_1 = sys.stdout.write
    func_2 = sys.std

# Generated at 2022-06-24 17:25:38.580410
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    str_0 = get_shortish_repr(dict_0)
    assert repr(str_0) == repr("{}")


# Generated at 2022-06-24 17:25:50.000832
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import re
    import sys
    import sys
    import unittest
    # Use io for io.BytesIO when Python 2.7 is no longer supported
    import io
    import StringIO
    import StringIO
    class TestWritableStream(WritableStream):
        def __init__(self, stream=None):
            self.closed = False
            if stream is None:
                stream = sys.__stdout__
            self.stream = stream
            self.encoding = stream.encoding
            self.writable = True
        def write(self, s):
            if not self.writable:
                raise ValueError('write to closed file')
            if isinstance(s, unicode):
                s = s.encode(self.encoding)
            self.stream.write(s)
            self.stream.flush()
       

# Generated at 2022-06-24 17:25:50.907387
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_case_0()

# Generated at 2022-06-24 17:25:53.260108
# Unit test for function get_repr_function
def test_get_repr_function():
    """
    >>> from .utils import get_repr_function
    """


# Generated at 2022-06-24 17:26:02.043426
# Unit test for function get_shortish_repr

# Generated at 2022-06-24 17:26:12.060249
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(2, max_length=2) == '2'
    assert get_shortish_repr(3, max_length=1) == '3'
    assert get_shortish_repr(4, max_length=0) == '4'
    assert get_shortish_repr(5, max_length=None) == '5'
    assert get_shortish_repr(slice(None, None), max_length=8) == 'slice(...'
    assert get_shortish_repr(slice(None, None), max_length=7) == 'slice...'
    assert get_shortish_repr(slice(None, None), max_length=6) == 'slice..'
    assert get_short

# Generated at 2022-06-24 17:26:26.891881
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert normalize_repr('whatever') == 'whatever'
    assert normalize_repr('something at 0x5655b2c2b8f8') == 'something'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 3) == 'abc...yz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 20) == 'abcdefghijklmnopqrstuvwxyz'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', (
        (lambda x: True, lambda x: '...'),
    ), max_length=3) == '...'

# Generated at 2022-06-24 17:26:28.136074
# Unit test for function shitcode
def test_shitcode():
    assert test_case_0() == None, 'function call failed in test case'




# Generated at 2022-06-24 17:26:33.419749
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class var_0_(object):
        def write(self, var_0):
            pass
    var_1 = WritableStream()
    try:
        var_1.write(var_0_())
    except TypeError:
        assert isinstance(var_1, WritableStream)
    else:
        assert False, 'Expected TypeError'


# Generated at 2022-06-24 17:26:41.865462
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_0 = WritableStream
    var_0 = test_0.__subclasshook__(WritableStream)
    test_1 = WritableStream
    var_1 = test_1.__subclasshook__(WritableStream)
    test_2 = WritableStream
    var_2 = test_2.__subclasshook__(WritableStream)


# Generated at 2022-06-24 17:26:43.872835
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    WritableStream.write(sys.stdout, 'test')

# Generated at 2022-06-24 17:26:54.402577
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    dict_0 = dict()
    dict_0['key1'] = 'val1'
    dict_0['key2'] = 'val2'
    dict_0['key3'] = 'val3'
    dict_0['key4'] = 'val4'
    dict_0['key5'] = 'val5'
    dict_0['key6'] = 'val6'
    dict_0['key7'] = 'val7'
    dict_0['key8'] = 'val8'
    dict_0['key9'] = 'val9'
    dict_0['key10'] = 'val10'
    dict_0['key11'] = 'val11'
    dict_0['key12'] = 'val12'
    dict_0['key13'] = 'val13'

# Generated at 2022-06-24 17:26:55.868974
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # TODO: Implement test.
    raise NotImplementedError()


# Generated at 2022-06-24 17:27:07.024881
# Unit test for function shitcode
def test_shitcode():
    dict_0 = {}
    try:
        dict_0[1] = '￿￿￿￿￿￿'
        dict_0[2] = '￿￿￿￿￿'
        dict_0[3] = '￿￿￿￿'
        dict_0[4] = '￿￿￿'
        dict_0[5] = '￿￿'
        dict_0[6] = '￿'
    except ValueError as var_1:
        print(var_1)
    dict_1 = dict_0.copy()
    dict_2 = dict_1.copy()
    dict_3 = dict_2.copy()

# Generated at 2022-06-24 17:27:13.138720
# Unit test for function shitcode
def test_shitcode():
    dict_0 = {}
    var_0 = shitcode(dict_0)
    assert var_0 == '{}'
    dict_1 = {str(var_1): str(len(str(var_1))) for var_1 in range(0, 5)}
    var_1 = shitcode(dict_1)
    assert var_1 == "{'0': '1', '1': '1', '2': '1', '3': '1', '4': '1'}"
    var_2 = shitcode({'': 1})
    assert var_2 == '{'': 1}'


# Generated at 2022-06-24 17:27:22.688734
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    dict_0 = {}
    dict_0 = {}
    dict_0[1] = 1
    dict_0[2] = 2
    dict_0[3] = 3
    dict_1 = {}
    dict_1[1] = 1
    dict_1[2] = 2
    dict_1[3] = 3
    output_1 = get_shortish_repr(dict_0, ())
    output_2 = get_shortish_repr(dict_0, (), 10)
    output_3 = get_shortish_repr(dict_1, ())
    output_4 = get_shortish_repr(dict_1, (), 10)
    assert output_1 == "{1: 1, 2: 2, 3: 3}"
    assert output_2 == "{1: 1, ...}"
    assert output_

# Generated at 2022-06-24 17:27:33.263288
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    test_case_0()

# Generated at 2022-06-24 17:27:35.641468
# Unit test for function get_repr_function
def test_get_repr_function():
    dict_1 = {}
    var_1 = get_repr_function(dict_1)


# Generated at 2022-06-24 17:27:44.519948
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr({'a': 1, 'b': '2', 'c': {'d': 3}}) \
                                                              == "{'a': 1, 'b': '2', 'c': {'d': 3}}"
    assert get_shortish_repr({'a': 1, 'b': '2', 'c': {'d': 3}}, max_length=10) \
                                                              == "{'a': 1..."
    assert get_shortish_repr({'a': 1, 'b': '2', 'c': {'d': 3}}, max_length=2) \
                                                              == "..."


# Generated at 2022-06-24 17:27:52.464303
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    thing = [
        ('hi', 'hello'),
        ('bye', 'world'),
        ('no', 'python'),
        ('yes', '&'),
    ]
    def func():
        pass

# Generated at 2022-06-24 17:27:54.724455
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('aaa', ((str, str),)) is str


# Generated at 2022-06-24 17:27:56.162711
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert 1 == 1, '''TODO: Implement test'''



# Generated at 2022-06-24 17:28:03.798025
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test case with inputs that don't raise exceptions.
    try:
        sys.stdout.write(test_case_0())
    # Test case with inputs that raise exceptions.
    except Exception as exc:
        assert False, 'Expected pass, got %s' % (str(exc))

## EXAMPLE OF A TEST CASE
#def test_example():
#    
#    # Test case with inputs that don't raise exceptions.
#    try:
#        result0 = example([[0,0,0]])
#    # Test case with inputs that raise exceptions.
#    except Exception as exc:
#        assert False, 'Expected pass, got %s' % (str(exc))

# Generated at 2022-06-24 17:28:05.099593
# Unit test for function shitcode
def test_shitcode():
    def compare(x, y):
        return x == y

    compare(dict_0, var_0)

test_shitcode()




# Generated at 2022-06-24 17:28:14.233903
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr('a' * 99, max_length=100) == 'a' * 99
    assert get_shortish_repr(['a' * 99], max_length=100) == ["'aaaaa...aaaa'"]
    assert get_shortish_repr(['a' * 99], max_length=100) == ["'aaaaa...aaaa'"]
    assert get_shortish_repr(['a' * 100], max_length=100) == ["'aaaaa...aaaa'"]

# Generated at 2022-06-24 17:28:20.497768
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    print('running test_WritableStream_write...')
    # test case: 'test_case_0'
    try:
        test_case_0()
    except:
        print('test_case_0 failure')
        raise
    else:
        print('test_case_0 success')




# Generated at 2022-06-24 17:28:46.246838
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    dict_0 = {}
    var_0 = WritableStream(dict_0)
    var_0.write(dict_0)

# Generated at 2022-06-24 17:28:47.483700
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(test_case_0()) == ''

# Generated at 2022-06-24 17:28:50.757748
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Stream(WritableStream):
        def write(self, s):
            pass
    s = Stream()
    s.write('t')
    assert True

# Generated at 2022-06-24 17:28:59.605973
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A():
        def __repr__(self):
            return 'i is five'
    assert get_shortish_repr(A()) == 'i is five'
    assert get_shortish_repr(A(), ()), 'i is five'
    assert get_shortish_repr(A(), (), 25) == 'i is five'
    assert get_shortish_repr(A(), (), 5) == 'i is...five'
    assert get_shortish_repr(A(), (), 5, True) == 'i is...ve'
    assert get_shortish_repr(A(), ((lambda x: True,
                                     lambda x: 'i is six')), 5) == 'i is six'

# Generated at 2022-06-24 17:29:01.900303
# Unit test for function get_repr_function
def test_get_repr_function():
    assert repr('abc') == get_repr_function('abc', ())()



# Generated at 2022-06-24 17:29:11.977578
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class MyClass(object):
        def __repr__(self):
            return 'Hai'
    my_object = MyClass()
    assert get_shortish_repr(my_object) == 'Hai'

    # Test that nested objects are being recursively `get_shortish_repr`ed
    class NestedClass(object):
        def __repr__(self):
            return 'Nested'
    class ContainerClass(object):
        def __repr__(self):
            return '{0} {1}'.format(NestedClass(), my_object)
    container_object = ContainerClass()
    assert get_shortish_repr(container_object) == 'Nested Hai'

    # Test that the `custom_repr` argument works

# Generated at 2022-06-24 17:29:16.065333
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream_0 = WritableStream()
    var_0 = writable_stream_0.write('C:/Users/Eliran/Desktop/Programming/Python/pysnooper/pysnooper.py')


# Generated at 2022-06-24 17:29:27.231245
# Unit test for function get_repr_function
def test_get_repr_function():
    # Test normal repr
    assert get_repr_function(1, custom_repr=((int, str), )) == repr
    assert get_repr_function(1.1, custom_repr=((int, str), )) == repr
    assert get_repr_function(1, custom_repr=((float, str), )) == repr
    assert get_repr_function(1.1, custom_repr=((float, str), )) == repr
    assert get_repr_function('1', custom_repr=((float, str), )) == repr
    assert get_repr_function('1', custom_repr=((int, str), )) == repr

    # Test custom repr
    assert get_repr_function(1, custom_repr=((int, str), )) == str
    assert get_repr_function

# Generated at 2022-06-24 17:29:29.268466
# Unit test for function get_repr_function
def test_get_repr_function():
    assert(get_repr_function(test_case_0, []) == repr)



# Generated at 2022-06-24 17:29:31.475114
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    dict_0 = {}
    var_0 = get_shortish_repr(dict_0)

# Generated at 2022-06-24 17:29:56.554889
# Unit test for method write of class WritableStream
def test_WritableStream_write():
  if WritableStream.write is ABC.write:
    raise AssertionError


# Generated at 2022-06-24 17:30:05.387088
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    print("start")
    dict_0 = {}
    dict_1 = {"a":1}
    dict_2 = {"a":1, "b": 2}
    try:
        test_0 = get_shortish_repr(dict_0,)
        assert test_0 == '{}'
        test_1 = get_shortish_repr(dict_1,max_length=100)
        assert test_1 == "{'a': 1}"
        test_2 = get_shortish_repr(dict_2,normalize=True)
        assert test_2 == "{'a': 1, 'b': 2}"
    except AssertionError:
        print("Unit test failed")
    else:
        print("Unit test passed")


# Generated at 2022-06-24 17:30:07.831102
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    dict_0 = {}
    var_0 = get_shortish_repr(dict_0)


# Generated at 2022-06-24 17:30:10.673200
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    dict_0 = {}
    test_var_0 = get_shortish_repr(dict_0)
    assert test_var_0 == "{}"


# Generated at 2022-06-24 17:30:17.963223
# Unit test for function get_repr_function
def test_get_repr_function():
    dict_0 = {}
    dict_0['key_0'] = dict_0
    dict_0['key_1'] = str()
    dict_0['key_2'] = str()
    dict_0['key_3'] = str()
    dict_0['key_4'] = str()
    dict_0['key_5'] = str()
    dict_0['key_6'] = str()
    dict_0['key_7'] = str()
    dict_0['key_8'] = str()
    dict_0['key_9'] = str()
    dict_0['key_a'] = str()
    dict_0['key_b'] = dict_0
    dict_0['key_c'] = str()
    dict_0['key_d'] = str()

# Generated at 2022-06-24 17:30:21.730719
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Define the arguments
    dict_0 = {'a':'a', 'b':'b', 'c':'c'}
    # Call the method
    shitcode(dict_0)





# Generated at 2022-06-24 17:30:26.158124
# Unit test for function get_repr_function
def test_get_repr_function():
    from .testing_tools import assert_equal
    from .settings import Settings
    from . import Context

    settings = Settings()
    settings.colorize_output = False

    context = Context(settings=settings)

    assert_equal(get_repr_function(context, ()), repr)



# Generated at 2022-06-24 17:30:30.368229
# Unit test for function get_repr_function
def test_get_repr_function():
    var_0 = get_repr_function((1,), [(lambda o: o.__class__ in (dict,), lambda o: o.__class__.__name__)])


# Generated at 2022-06-24 17:30:39.604241
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(test_case_0, [(lambda x: True, lambda x: 'a')])(test_case_0) == 'a'
    # assert get_repr_function(test_case_0, [(lambda x: False, lambda x: 'a')])(test_case_0) == 'REPR FAILED'
    assert get_repr_function(test_case_0, [(lambda x: True, lambda x: x is not None)]) is not None
    assert get_repr_function(test_case_0, [(lambda x: False, lambda x: x is None)]) is None
    assert get_repr_function(test_case_0, [(lambda x: True, lambda x: len(x) > 0)]) is not None



# Generated at 2022-06-24 17:30:46.513215
# Unit test for function get_repr_function
def test_get_repr_function():
    class_0 = A()
    var_0 = get_repr_function(class_0, (('', ''), ))
    assert var_0 == repr, 'Should return repr'
    class_0 = B()
    var_0 = get_repr_function(class_0, (('', ''), ))
    assert var_0 == repr, 'Should return repr'
    class_0 = B()
    var_0 = get_repr_function(class_0, ((B, ''), ))
    assert var_0 == '', 'Should return '''
    class_0 = B()
    var_0 = get_repr_function(class_0, ((A, ''), ))
    assert var_0 == repr, 'Should return repr'
    class_0 = B()
    var_0 = get_repr_function

# Generated at 2022-06-24 17:31:24.253677
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    line_0 = u'def get_shortish_repr(item, custom_repr=(), max_length=None, normalize=False):'
    line_1 = u"    repr_function = get_repr_function(item, custom_repr)"
    line_2 = u"    try:"
    line_3 = u"        r = repr_function(item)"
    line_4 = u"    except Exception:"
    line_5 = u"        r = 'REPR FAILED'"
    line_6 = u"    r = r.replace('\\r', '').replace('\\n', '')"
    line_7 = u"    if normalize:"
    line_8 = u"        r = normalize_repr(r)"
    line_9 = u"    if max_length:"
    line_10