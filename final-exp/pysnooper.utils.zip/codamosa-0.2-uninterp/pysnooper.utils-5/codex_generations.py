

# Generated at 2022-06-16 19:28:29.671993
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((lambda x: True, lambda x: 'a'))) == (
        lambda x: 'a'
    )
    assert get_repr_function(1, ((lambda x: False, lambda x: 'a'))) == repr
    assert get_repr_function(1, ((lambda x: False, lambda x: 'a'),
                                 (lambda x: True, lambda x: 'b'))) == (
        lambda x: 'b'
    )
    assert get_repr_function(1, ((lambda x: False, lambda x: 'a'),
                                 (lambda x: False, lambda x: 'b'))) == repr

# Generated at 2022-06-16 19:28:41.952851
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1, [(lambda x: isinstance(x, int),
                                  lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(lambda x: isinstance(x, int),
                                    lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(lambda x: isinstance(x, int),
                                    lambda x: 'int')]) == repr
    assert get_repr

# Generated at 2022-06-16 19:28:53.494577
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00\x01') == 'abc??'
    assert shitcode('abc\x00\x01\x02') == 'abc???'
    assert shitcode('abc\x00\x01\x02\x03') == 'abc????'
    assert shitcode('abc\x00\x01\x02\x03\x04') == 'abc?????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05') == 'abc??????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06') == 'abc???????'

# Generated at 2022-06-16 19:28:56.293997
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:29:08.312184
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((str, str),)) == repr
    assert get_repr_function(1, ((lambda x: x == 1, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) == repr
    assert get_repr_function(1, ((lambda x: x == 1, str), (int, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (str, str))) == repr

# Generated at 2022-06-16 19:29:10.659370
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)



# Generated at 2022-06-16 19:29:18.500815
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == (
        lambda x: 'bye'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')]) == repr

# Generated at 2022-06-16 19:29:20.611700
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'



# Generated at 2022-06-16 19:29:28.692603
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10)

# Generated at 2022-06-16 19:29:39.074616
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 1, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 1, str), (int, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 3, str)))

# Generated at 2022-06-16 19:29:53.745056
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, [(float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'),
                                   (int, lambda x: 'int')]) == 'float'
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int')]) == 'int'

# Generated at 2022-06-16 19:30:05.632234
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00\x01') == 'abc??'
    assert shitcode('abc\x00\x01\x02') == 'abc???'
    assert shitcode('abc\x00\x01\x02\x03') == 'abc????'
    assert shitcode('abc\x00\x01\x02\x03\x04') == 'abc?????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05') == 'abc??????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06') == 'abc???????'

# Generated at 2022-06-16 19:30:08.323544
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:30:14.385579
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = ''
        def write(self, s):
            self.written_stuff += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_stuff == 'hello'

# Generated at 2022-06-16 19:30:17.334500
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:30:24.746880
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, [(int, lambda x: 'int'), (float, lambda x: 'float')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int'), (float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, [(float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'), (int, lambda x: 'int')]) == 'float'

# Generated at 2022-06-16 19:30:34.392194
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(int, str), (str, int)]) is str
    assert get_repr_function(1, [(str, int)]) is repr
    assert get_repr_function(1, [(lambda x: x == 1, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) is repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (lambda x: x == 1,
                                                           str)]) is str



# Generated at 2022-06-16 19:30:42.918433
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass
        def write3(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass

# Generated at 2022-06-16 19:30:54.614690
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:30:58.243868
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:14.549565
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[(int, str)]) == str
    assert get_repr_function(1.0, custom_repr=[(int, str)]) == repr
    assert get_repr_function(1, custom_repr=[(lambda x: x == 1, str)]) == str
    assert get_repr_function(2, custom_repr=[(lambda x: x == 1, str)]) == repr
    assert get_repr_function(1, custom_repr=[(lambda x: x == 1, str),
                                             (lambda x: x == 2, str)]) == str
    assert get_repr_function(2, custom_repr=[(lambda x: x == 1, str),
                                             (lambda x: x == 2, str)]) == str

# Generated at 2022-06-16 19:31:26.204232
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00\x01') == 'abc??'
    assert shitcode('abc\x00\x01\x02') == 'abc???'
    assert shitcode('abc\x00\x01\x02\x03') == 'abc????'
    assert shitcode('abc\x00\x01\x02\x03\x04') == 'abc?????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05') == 'abc??????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06') == 'abc???????'

# Generated at 2022-06-16 19:31:29.936803
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)
    assert isinstance(A(), WritableStream)
    assert isinstance(A(), A)



# Generated at 2022-06-16 19:31:41.188141
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'foo')]) == \
                                                                    (lambda x: 'foo')
    assert get_repr_function(1, [(lambda x: False, lambda x: 'foo')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'foo'),
                                 (lambda x: True, lambda x: 'bar')]) == \
                                                                    (lambda x: 'bar')
    assert get_repr_function(1, [(lambda x: False, lambda x: 'foo'),
                                 (lambda x: False, lambda x: 'bar')]) == repr
    assert get_repr_function(1, [(int, lambda x: 'foo')])

# Generated at 2022-06-16 19:31:43.631221
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:48.970762
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1.0, ((int, lambda x: 'int'))) == repr
    assert get_repr_function(1, ((lambda x: x == 1, lambda x: '1'))) == '1'
    assert get_repr_function(2, ((lambda x: x == 1, lambda x: '1'))) == repr



# Generated at 2022-06-16 19:31:54.465414
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.0, custom_repr=((int, str),)) == repr
    assert get_repr_function(1, custom_repr=((int, str), (float, str))) == str
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str))) == str
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str),
                                               (str, str))) == str
    assert get_repr_function('1', custom_repr=((int, str), (float, str),
                                               (str, str))) == str

# Generated at 2022-06-16 19:32:00.380182
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.0, custom_repr=((int, str),)) == repr
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str))) == str
    assert get_repr_function(1.0, custom_repr=((float, str), (int, str))) == str



# Generated at 2022-06-16 19:32:11.540294
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:32:21.174458
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.0, [(int, str)]) == repr
    assert get_repr_function(1.0, [(int, str), (float, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (float, int)]) == int
    assert get_repr_function(1.0, [(int, str), (float, str), (float, int),
                                   (float, lambda x: 'float')]) == 'float'

# Generated at 2022-06-16 19:32:36.988163
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''

    assert get_shortish_repr(1, normalize=True) == '1'
    assert get_shortish_

# Generated at 2022-06-16 19:32:40.344938
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_strings = []
        def write(self, s):
            self.written_strings.append(s)

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    my_writable_stream.write('world')
    assert my_writable_stream.written_strings == ['hello', 'world']

# Generated at 2022-06-16 19:32:49.248667
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:32:58.273248
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.0, custom_repr=((int, str),)) == repr
    assert get_repr_function(1.0, custom_repr=((float, str),)) == str
    assert get_repr_function(1.0, custom_repr=((float, str), (int, str))) == str
    assert get_repr_function(1, custom_repr=((float, str), (int, str))) == str
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str))) == str
    assert get_repr_function(1, custom_repr=((int, str), (float, str))) == str


# Generated at 2022-06-16 19:33:09.674814
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:33:20.868424
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00def') == 'abc?def'
    assert shitcode('abc\x00\x01\x02def') == 'abc???def'

# Generated at 2022-06-16 19:33:30.308151
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is repr
    assert get_repr_function(1, ((int, str), (str, str))) is str
    assert get_repr_function(1, ((str, str), (int, str))) is str
    assert get_repr_function(1, ((str, str), (int, str), (int, int))) is int
    assert get_repr_function(1, ((str, str), (int, str), (int, int),
                                 (str, str))) is str
    assert get_repr_function(1, ((str, str), (int, str), (int, int),
                                 (str, str), (int, int))) is int
    assert get_repr_function

# Generated at 2022-06-16 19:33:32.430155
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def write(self, s):
            pass

    assert issubclass(Foo, WritableStream)



# Generated at 2022-06-16 19:33:42.825552
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('hello\n') == 'hello\n'
    assert shitcode('hello\r\n') == 'hello\r\n'
    assert shitcode('hello\r\n\r\n') == 'hello\r\n\r\n'
    assert shitcode('hello\r\n\r\n\r\n') == 'hello\r\n\r\n\r\n'
    assert shitcode('hello\r\n\r\n\r\n\r\n') == 'hello\r\n\r\n\r\n\r\n'

# Generated at 2022-06-16 19:33:53.114174
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:03.993774
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'



# Generated at 2022-06-16 19:34:14.664336
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr('hello', max_length=3) == 'hel'
    assert get_shortish_repr('hello', max_length=3, normalize=True) == 'hel'
    assert get_shortish_repr('hello', max_length=4, normalize=True) == 'hell'
    assert get_shortish_repr('hello', max_length=5, normalize=True) == 'hello'
    assert get_shortish_repr('hello', max_length=6, normalize=True) == 'hello'
    assert get_shortish_repr('hello', max_length=7, normalize=True) == 'hello'

# Generated at 2022-06-16 19:34:20.355393
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'



# Generated at 2022-06-16 19:34:25.580178
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = []
        def write(self, s):
            self.written_stuff.append(s)

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('spam')
    assert my_writable_stream.written_stuff == ['spam']



# Generated at 2022-06-16 19:34:36.747363
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:48.564778
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:56.981051
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'

# Generated at 2022-06-16 19:35:00.019004
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:03.319894
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:14.338377
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00def') == 'abc?def'
    assert shitcode('abc\x00def\x00') == 'abc?def?'
    assert shitcode('abc\x00def\x00\x00') == 'abc?def??'
    assert shitcode('abc\x00def\x00\x00\x00') == 'abc?def???'
    assert shitcode('abc\x00def\x00\x00\x00\x00') == 'abc?def????'
    assert shitcode('abc\x00def\x00\x00\x00\x00\x00') == 'abc?def?????'

# Generated at 2022-06-16 19:35:30.716155
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''

    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish

# Generated at 2022-06-16 19:35:38.757527
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.0, [(int, str)]) == repr
    assert get_repr_function(1.0, [(float, str)]) == str
    assert get_repr_function(1.0, [(lambda x: isinstance(x, float), str)]) == str
    assert get_repr_function(1.0, [(lambda x: isinstance(x, float), str),
                                   (int, str)]) == str
    assert get_repr_function(1.0, [(lambda x: isinstance(x, float), str),
                                   (lambda x: isinstance(x, int), str)]) == str

# Generated at 2022-06-16 19:35:50.488914
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((str, int), (int, str))) is str
    assert get_repr_function(1, ((str, int), (int, int))) is int
    assert get_repr_function(1, ((str, int), (int, int), (int, str))) is str
    assert get_repr_function(1, ((str, int), (int, int), (int, int))) is int
    assert get_repr_function(1, ((str, int), (int, int), (int, int),
                                 (int, str)))

# Generated at 2022-06-16 19:36:00.906030
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int!'),)) == 'int!'
    assert get_repr_function(1.0, ((int, lambda x: 'int!'),)) == repr
    assert get_repr_function(1.0, ((float, lambda x: 'float!'),)) == 'float!'
    assert get_repr_function(1.0, ((float, lambda x: 'float!'),
                                   (int, lambda x: 'int!'))) == 'float!'
    assert get_repr_function(1, ((float, lambda x: 'float!'),
                                 (int, lambda x: 'int!'))) == 'int!'



# Generated at 2022-06-16 19:36:10.063315
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:36:19.531061
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def foo(self):
            pass

    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)


# Generated at 2022-06-16 19:36:31.723105
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:36:41.434008
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''

# Generated at 2022-06-16 19:36:52.283976
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int!'),)) == \
                                                                     'int!'
    assert get_repr_function(1.0, custom_repr=((int, lambda x: 'int!'),)) == \
                                                                      repr
    assert get_repr_function(1.0, custom_repr=((float, lambda x: 'float!'),)) \
                                                                     == 'float!'
    assert get_repr_function(1.0, custom_repr=((int, lambda x: 'int!'),
                                               (float, lambda x: 'float!'),)) \
                                                                     == 'float!'

# Generated at 2022-06-16 19:36:54.473510
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:37:06.886403
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:37:15.435741
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\xFF') == 'abc?'
    assert shitcode('abc\x00\xFF') == 'abc??'
    assert shitcode('abc\xFF\x00') == 'abc??'
    assert shitcode('\x00\xFF') == '??'
    assert shitcode('\xFF\x00') == '??'
    assert shitcode('\x00') == '?'
    assert shitcode('\xFF') == '?'
    assert shitcode('') == ''



# Generated at 2022-06-16 19:37:23.612717
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1, [(lambda x: isinstance(x, int),
                                  lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(lambda x: isinstance(x, int),
                                    lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(lambda x: isinstance(x, int),
                                    lambda x: 'int')]) == repr



# Generated at 2022-06-16 19:37:31.870623
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: '1')]) == '1'
    assert get_repr_function(1, [(lambda x: False, lambda x: '1')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'),
                                 (lambda x: True, lambda x: '2')]) == '2'
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'),
                                 (lambda x: False, lambda x: '2')]) is repr

# Generated at 2022-06-16 19:37:38.837460
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass

    assert issubclass(WritableStreamSubclass, WritableStream)
    assert not issubclass(WritableStream, WritableStreamSubclass)

    class WritableStreamSubclass2(WritableStream):
        pass

    assert not issubclass(WritableStreamSubclass2, WritableStream)

    class WritableStreamSubclass3(WritableStream):
        def write(self, s):
            pass

        def write2(self, s):
            pass

    assert issubclass(WritableStreamSubclass3, WritableStream)

    class WritableStreamSubclass4(WritableStream):
        def write(self, s):
            pass

        def write2(self, s):
            pass


# Generated at 2022-06-16 19:37:50.603430
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 1, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) == repr
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 3, str))) == str
   

# Generated at 2022-06-16 19:38:01.665488
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:38:05.127472
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:38:14.757868
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, [(float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'),
                                   (int, lambda x: 'int')]) == 'float'
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int')]) == 'int'