

# Generated at 2022-06-16 19:28:27.068337
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int'),)) == 'int'
    assert get_repr_function(1.0, ((int, lambda x: 'int'),)) == repr
    assert get_repr_function(1.0, ((float, lambda x: 'float'),)) == 'float'
    assert get_repr_function(1.0, ((float, lambda x: 'float'),
                                   (int, lambda x: 'int'))) == 'float'
    assert get_repr_function(1.0, ((int, lambda x: 'int'),
                                   (float, lambda x: 'float'))) == 'float'
    assert get_repr_function(1, ((int, lambda x: 'int'),
                                 (float, lambda x: 'float'))) == 'int'
   

# Generated at 2022-06-16 19:28:34.084790
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(int, str), (str, int)]) is str
    assert get_repr_function(1, [(str, int), (int, str)]) is str
    assert get_repr_function(1, [(str, int)]) is repr
    assert get_repr_function(1, [(lambda x: x == 1, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) is repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) is str

# Generated at 2022-06-16 19:28:45.849771
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(int, str), (int, repr)]) == str
    assert get_repr_function(1, [(int, str), (float, repr)]) == str
    assert get_repr_function(1.0, [(int, str), (float, repr)]) == repr
    assert get_repr_function(1.0, [(int, str), (float, repr), (int, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, repr), (float, str)]) == str

# Generated at 2022-06-16 19:28:52.664759
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('hello\x00') == 'hello?'
    assert shitcode('hello\x00\x00') == 'hello??'
    assert shitcode('hello\x00\x00\x00') == 'hello???'
    assert shitcode('hello\x00\x00\x00\x00') == 'hello????'
    assert shitcode('hello\x00\x00\x00\x00\x00') == 'hello?????'
    assert shitcode('hello\x00\x00\x00\x00\x00\x00') == 'hello??????'
    assert shitcode('hello\x00\x00\x00\x00\x00\x00\x00') == 'hello???????'

# Generated at 2022-06-16 19:28:58.525468
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: True, lambda x: '1')]) == '1'
    assert get_repr_function(1, [(lambda x: False, lambda x: '1')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'),
                                 (lambda x: True, lambda x: '1')]) == '1'
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'),
                                 (lambda x: False, lambda x: '1')]) == repr

# Generated at 2022-06-16 19:29:10.316200
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:29:18.336621
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, [(int, lambda x: 'int'), (str, lambda x: 'str')]) == 'int'
    assert get_repr_function('1', [(int, lambda x: 'int'), (str, lambda x: 'str')]) == 'str'
    assert get_repr_function('1', [(int, lambda x: 'int'), (str, lambda x: 'str'), (1, lambda x: '1')]) == 'str'
    assert get_repr_function(1, [(int, lambda x: 'int'), (str, lambda x: 'str'), (1, lambda x: '1')]) == '1'

# Generated at 2022-06-16 19:29:27.790993
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00def') == 'abc?def'
    assert shitcode('abc\x00def\x00') == 'abc?def?'
    assert shitcode('abc\x00def\x00\x00') == 'abc?def??'
    assert shitcode('abc\x00def\x00\x00\x00') == 'abc?def???'
    assert shitcode('abc\x00def\x00\x00\x00\x00') == 'abc?def????'
    assert shitcode('abc\x00def\x00\x00\x00\x00\x00') == 'abc?def?????'

# Generated at 2022-06-16 19:29:38.357431
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:29:44.059891
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream)
    assert not issubclass(MyWritableStream, MyWritableStream)



# Generated at 2022-06-16 19:29:56.935727
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == 'bye'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')]) is repr

# Generated at 2022-06-16 19:30:09.192013
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((lambda x: x == 1, str),)) is str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) is repr
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) is str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str))) is str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 3, str))) is str




# Generated at 2022-06-16 19:30:13.718954
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:30:23.006481
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:30:30.854498
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 1, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) is repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) is str



# Generated at 2022-06-16 19:30:37.527740
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 1, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) == repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 3, str)])

# Generated at 2022-06-16 19:30:44.644662
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcde') == 'abcde'
    assert get_shortish_repr('abcde', max_length=3) == 'abc...'
    assert get_shortish_repr('abcde', max_length=4) == 'abcd...'
    assert get_shortish_repr('abcde', max_length=5) == 'abcde'
    assert get_shortish_repr('abcde', max_length=6) == 'abcde'
    assert get_shortish_repr('abcde', max_length=7) == 'abcde'
    assert get_shortish_repr('abcde', max_length=8) == 'abcde'
    assert get_shortish_repr('abcde', max_length=9) == 'abcde'
    assert get_

# Generated at 2022-06-16 19:30:56.048596
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=5) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5, normalize=True) == "'hel...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=6, normalize=True) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=7, normalize=True) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_

# Generated at 2022-06-16 19:31:01.808638
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_strings = []
        def write(self, s):
            self.written_strings.append(s)
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_strings == ['hello']

# Generated at 2022-06-16 19:31:13.441160
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def foo(self):
            pass

    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

    assert issubclass(MyWritableStream, WritableStream)


# Generated at 2022-06-16 19:31:27.950264
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == 'bye'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')]) is repr

# Generated at 2022-06-16 19:31:39.025533
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == 'bye'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')])

# Generated at 2022-06-16 19:31:49.113624
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.0, [(int, str)]) == repr
    assert get_repr_function(1.0, [(int, str), (float, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (str, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (str, str),
                                   (object, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (str, str),
                                   (object, str), (lambda x: True, str)]) == str

# Generated at 2022-06-16 19:31:54.584593
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1.0, ((int, lambda x: 'int'))) == repr
    assert get_repr_function(1.0, ((float, lambda x: 'float'))) == 'float'
    assert get_repr_function(1.0, ((float, lambda x: 'float'),
                                   (int, lambda x: 'int'))) == 'float'
    assert get_repr_function(1, ((float, lambda x: 'float'),
                                 (int, lambda x: 'int'))) == 'int'

# Generated at 2022-06-16 19:32:02.884062
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == 'bye'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')]) is repr

# Generated at 2022-06-16 19:32:13.566639
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, str)]) == str
    assert get_repr_function(1, [(lambda x: False, str)]) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(int, str), (float, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (str, str)]) == str
    assert get_repr_function('1', [(int, str), (float, str), (str, str)]) == str
    assert get

# Generated at 2022-06-16 19:32:22.734835
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) == repr
    assert get_repr_function(1, [(int, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )
    assert get_repr_function(1, [(int, lambda x: 'hi'), (int, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )

# Generated at 2022-06-16 19:32:34.014517
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((str, int), (int, str))) is str
    assert get_repr_function(1, ((str, int), (int, str), (int, int))) is int
    assert get_repr_function(1, ((str, int), (int, str), (int, int),
                                 (int, lambda x: x + 1))) is int

# Generated at 2022-06-16 19:32:45.807980
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1, custom_repr=((lambda x: x == 1,
                                              lambda x: 'one'))) == 'one'
    assert get_repr_function(1, custom_repr=((lambda x: x == 2,
                                              lambda x: 'two'))) == repr
    assert get_repr_function(1, custom_repr=((lambda x: x == 2,
                                              lambda x: 'two'),
                                             (lambda x: x == 1,
                                              lambda x: 'one'))) == 'one'

# Generated at 2022-06-16 19:32:55.347387
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:33:10.877097
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:33:21.627416
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:33:24.859630
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:34.321065
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, [(float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'),
                                   (int, lambda x: 'int')]) == 'float'
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int')]) == 'int'

# Generated at 2022-06-16 19:33:45.368460
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.0, [(int, str)]) == repr
    assert get_repr_function(1.0, [(int, str), (float, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (object, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (object, str),
                                   (lambda x: False, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (object, str),
                                   (lambda x: True, str)]) == str

# Generated at 2022-06-16 19:33:49.041554
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass

    assert issubclass(WritableStreamSubclass, WritableStream)



# Generated at 2022-06-16 19:34:00.339772
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream)

    class MyWritableStream2(WritableStream):
        pass
    assert not issubclass(MyWritableStream2, WritableStream)

    class MyWritableStream3(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(MyWritableStream3, WritableStream)

    class MyWritableStream4(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass

# Generated at 2022-06-16 19:34:07.545865
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass

    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write_again(self, s):
            pass

    assert not issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

        def write(self, s):
            pass


# Generated at 2022-06-16 19:34:16.799908
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''

    assert get_shortish_repr(1, normalize=True) == '1'
    assert get_shortish_repr(1, normalize=True, max_length=2) == '1'

# Generated at 2022-06-16 19:34:27.010977
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10)

# Generated at 2022-06-16 19:34:43.367903
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, str)]) == str
    assert get_repr_function(1, [(lambda x: False, str)]) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.0, [(int, str)]) == repr
    assert get_repr_function(1, [(int, str), (float, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str)]) == str
    assert get_repr_function(1, [(int, str), (float, str), (str, str)]) == str

# Generated at 2022-06-16 19:34:53.315413
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:35:05.339755
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def foo(self):
            pass
    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(MyWritableStream, WritableStream)


# Generated at 2022-06-16 19:35:16.041944
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: '1')]) == '1'
    assert get_repr_function(1, [(lambda x: False, lambda x: '1')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'),
                                 (lambda x: True, lambda x: '2')]) == '2'
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'),
                                 (lambda x: False, lambda x: '2')]) == repr

# Generated at 2022-06-16 19:35:23.030710
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10)

# Generated at 2022-06-16 19:35:25.785295
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:34.099692
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == (
        lambda x: 'hi')
    assert get_repr_function(1, [(int, lambda x: 'hi')]) == (
        lambda x: 'hi')
    assert get_repr_function(1, [(int, lambda x: 'hi'), (int, lambda x: 'bye')]) == (
        lambda x: 'hi')
    assert get_repr_function(1, [(int, lambda x: 'hi'), (str, lambda x: 'bye')]) == (
        lambda x: 'hi')

# Generated at 2022-06-16 19:35:40.732930
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:35:51.429940
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode('a\x00b\x00c\x00') == 'a?b?c?'
    assert shitcode('a\x00b\x00c\x00d') == 'a?b?c?d'
    assert shitcode('a\x00b\x00c\x00d\x00') == 'a?b?c?d?'
    assert shitcode('a\x00b\x00c\x00d\x00e') == 'a?b?c?d?e'

# Generated at 2022-06-16 19:35:54.034447
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert isinstance(A(), WritableStream)



# Generated at 2022-06-16 19:36:11.713632
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:20.031777
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str),
                                 (lambda x: True, str)]) is str

# Generated at 2022-06-16 19:36:31.815274
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass

    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

        def write(self, s):
            pass

    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass


# Generated at 2022-06-16 19:36:41.504534
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:36:52.363912
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:37:03.956972
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz') == \
                                                          'abcdefghijklmnopqrstuvwxyz'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=10) == \
                                                          'abcdefghij...xyz'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=11) == \
                                                          'abcdefghijk...xyz'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=12) == \
                                                          'abcdefghijkl...xyz'
    assert get_short

# Generated at 2022-06-16 19:37:15.294925
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:37:23.528036
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:37:31.766913
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == 'bye'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')])

# Generated at 2022-06-16 19:37:37.394410
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = ''
        def write(self, s):
            self.written_stuff += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_stuff == 'hello'



# Generated at 2022-06-16 19:38:08.303201
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

