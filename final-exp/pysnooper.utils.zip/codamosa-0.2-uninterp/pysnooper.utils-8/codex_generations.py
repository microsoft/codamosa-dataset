

# Generated at 2022-06-16 19:28:29.471216
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:28:41.522169
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'


# Generated at 2022-06-16 19:28:50.396105
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00\x01\x02') == 'abc???'
    assert shitcode('abc\x00\x01\x02\x03') == 'abc????'
    assert shitcode('abc\x00\x01\x02\x03\x04') == 'abc?????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05') == 'abc??????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06') == 'abc???????'

# Generated at 2022-06-16 19:29:02.482603
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.0, [(int, str)]) == repr
    assert get_repr_function(1.0, [(lambda x: x > 0, str)]) == str
    assert get_repr_function(1.0, [(lambda x: x < 0, str)]) == repr
    assert get_repr_function(1.0, [(lambda x: x < 0, str), (int, str)]) == str
    assert get_repr_function(1.0, [(lambda x: x < 0, str), (float, str)]) == str
    assert get_repr_function(1.0, [(lambda x: x < 0, str), (float, str),
                                   (int, str)]) == str

# Generated at 2022-06-16 19:29:14.029988
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: '2')]) == '2'
    assert get_repr_function(1, [(lambda x: False, lambda x: '2')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: '2'),
                                 (lambda x: True, lambda x: '3')]) == '3'
    assert get_repr_function(1, [(lambda x: False, lambda x: '2'),
                                 (lambda x: False, lambda x: '3')]) is repr

# Generated at 2022-06-16 19:29:20.219421
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream)

    class MyWritableStream2(WritableStream):
        pass

    assert not issubclass(MyWritableStream2, WritableStream)



# Generated at 2022-06-16 19:29:28.538587
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(D): pass
    class F(E): pass

    assert get_repr_function(A(), []) == repr
    assert get_repr_function(B(), []) == repr
    assert get_repr_function(C(), []) == repr
    assert get_repr_function(D(), []) == repr
    assert get_repr_function(E(), []) == repr
    assert get_repr_function(F(), []) == repr


# Generated at 2022-06-16 19:29:38.972017
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00\x01\x02') == 'abc???'
    assert shitcode('abc\x00\x01\x02\x03') == 'abc????'
    assert shitcode('abc\x00\x01\x02\x03\x04') == 'abc?????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05') == 'abc??????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06') == 'abc???????'

# Generated at 2022-06-16 19:29:50.362915
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr(u'hello') == "u'hello'"
    assert get_shortish_repr(u'hello', max_length=3) == "u'h..."
    assert get_shortish_repr(u'hello', max_length=4) == "u'he.."
    assert get_shortish_repr(u'hello', max_length=5) == "u'hel.."
    assert get_shortish_repr(u'hello', max_length=6) == "u'hell.."
    assert get_shortish_repr(u'hello', max_length=7) == "u'hello'"

# Generated at 2022-06-16 19:29:58.248315
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'),)) == \
                                                                      'int'
    assert get_repr_function(1, custom_repr=((str, lambda x: 'str'),)) == \
                                                                      repr
    assert get_repr_function(1, custom_repr=((str, lambda x: 'str'),
                                             (int, lambda x: 'int'))) == \
                                                                      'int'
    assert get_repr_function(1, custom_repr=((str, lambda x: 'str'),
                                             (int, lambda x: 'int'),
                                             (float, lambda x: 'float'))) == \
                                                                      'int'

# Generated at 2022-06-16 19:30:14.480814
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == '1'
    assert get_shortish_repr(1, max_length=-2) == '1'
    assert get_shortish_repr(1, max_length=-3) == '1'

# Generated at 2022-06-16 19:30:23.415220
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:30:28.629638
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'

# Generated at 2022-06-16 19:30:31.796990
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:30:41.805641
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 1, str)]) is str
    assert get_repr_function(2, [(lambda x: x == 1, str)]) is repr
    assert get_repr_function(1, [(lambda x: x == 1, str), (int, str)]) is str
    assert get_repr_function(2, [(lambda x: x == 1, str), (int, str)]) is str
    assert get_repr_function(1.0, [(lambda x: x == 1, str), (int, str)]) is repr

# Generated at 2022-06-16 19:30:50.654912
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream2(WritableStream):
        pass

    assert not issubclass(MyWritableStream2, WritableStream)

    class MyWritableStream3(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

    assert issubclass(MyWritableStream3, WritableStream)



# Generated at 2022-06-16 19:31:02.263579
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def foo(self):
            pass

    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

    assert issubclass(MyWritableStream, WritableStream)


# Generated at 2022-06-16 19:31:14.388189
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz') == \
                                                 'abcdefghijklmnopqrstuvwxyz'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=10) == \
                                                 'abcdefghij...xyz'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=11) == \
                                                 'abcdefghijk...xyz'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=12) == \
                                                 'abcdefghijkl...xyz'
    assert get_shortish_repr

# Generated at 2022-06-16 19:31:26.075090
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=5) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5, normalize=True) == "'hel...'"
    assert get_shortish_repr('hello', max_length=4) == "'he...'"
    assert get_shortish_repr('hello', max_length=4, normalize=True) == "'he...'"
    assert get_shortish_repr('hello', max_length=3) == "'h...'"
    assert get_shortish_repr('hello', max_length=3, normalize=True) == "'h...'"
    assert get_shortish_repr('hello', max_length=2) == "'...'"


# Generated at 2022-06-16 19:31:37.307097
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abc', max_length=2) == "'ab'"
    assert get_shortish_repr('abc', max_length=3) == "'abc'"
    assert get_shortish_repr('abc', max_length=4) == "'abc'"
    assert get_shortish_repr('abc', max_length=5) == "'abc'"
    assert get_shortish_repr('abc', max_length=6) == "'abc'"
    assert get_shortish_repr('abc', max_length=7) == "'abc'"
    assert get_shortish_repr('abc', max_length=8) == "'abc'"

# Generated at 2022-06-16 19:31:49.882572
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is repr
    assert get_repr_function(1, ((int, str), (str, str))) is str
    assert get_repr_function(1, ((int, str), (str, str), (int, int))) is int
    assert get_repr_function(1, ((int, str), (str, str), (int, int), (1, 1))) is 1
    assert get_repr_function(1, ((int, str), (str, str), (int, int), (1, 1),
                                 (2, 2))) is 2

# Generated at 2022-06-16 19:31:52.486277
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:55.513643
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:03.336604
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream2(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

    assert issubclass(MyWritableStream2, WritableStream)

    class MyWritableStream3(WritableStream):
        def foo(self):
            pass

    assert not issubclass(MyWritableStream3, WritableStream)

    class MyWritableStream4(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

        def write(self, s):
            pass

    assert issubclass(MyWritableStream4, WritableStream)


# Generated at 2022-06-16 19:32:14.008449
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz') == 'abcdefghijklmnopqrstuvwxyz'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=10) == 'abcdefghij...xyz'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=10, normalize=True) == 'abcdefghij...xyz'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=10, normalize=True) == 'abcdefghij...xyz'

# Generated at 2022-06-16 19:32:20.815749
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, [(float, lambda x: 'float')]) == repr
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int'),
                                 (lambda x: True, lambda x: 'true')]) == 'int'
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int'),
                                 (lambda x: False, lambda x: 'false')]) == 'int'
    assert get_re

# Generated at 2022-06-16 19:32:31.438334
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.0, custom_repr=((int, str),)) == repr
    assert get_repr_function(1, custom_repr=((float, str),)) == repr
    assert get_repr_function(1.0, custom_repr=((float, str),)) == str
    assert get_repr_function(1, custom_repr=((lambda x: x > 0, str),)) == str
    assert get_repr_function(1, custom_repr=((lambda x: x < 0, str),)) == repr

# Generated at 2022-06-16 19:32:34.057626
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:45.846191
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=5) == "'hel...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10) == "'hello'"
    assert get_shortish_repr('hello', max_length=11) == "'hello'"

# Generated at 2022-06-16 19:32:55.386854
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'\u05d0\u05d1\u05d2\u05d3') == '????'
    assert shitcode(u'\u05d0\u05d1\u05d2\u05d3'.encode('utf-8')) == '????'
    assert shitcode(u'\u05d0\u05d1\u05d2\u05d3'.encode('utf-16')) == '????'
    assert shitcode(u'\u05d0\u05d1\u05d2\u05d3'.encode('utf-32')) == '????'
    assert shitcode(u'\u05d0\u05d1\u05d2\u05d3'.encode('utf-7')) == '????'

# Generated at 2022-06-16 19:33:09.678142
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1, [(int, lambda x: 'int'), (float, lambda x: 'float')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int'), (float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(int, lambda x: 'int'), (float, lambda x: 'float')]) != 'int'

# Generated at 2022-06-16 19:33:20.869442
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    class B(A):
        pass
    class C(A):
        def write(self, s):
            pass
    class D(C):
        pass
    class E(C):
        def write(self, s):
            pass
    class F(E):
        pass
    class G(E):
        def write(self, s):
            pass
    class H(G):
        pass
    class I(G):
        def write(self, s):
            pass
    class J(I):
        pass
    class K(I):
        def write(self, s):
            pass
    class L(K):
        pass
    class M(K):
        def write(self, s):
            pass

# Generated at 2022-06-16 19:33:27.148384
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((lambda x: x == 1, str),)) is str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) is repr
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) is str



# Generated at 2022-06-16 19:33:29.368076
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:39.334986
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.0, custom_repr=((int, str),)) == repr
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str))) == str
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str),
                                               (str, str))) == str
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str),
                                               (str, str), (object, str))) == str

# Generated at 2022-06-16 19:33:50.605956
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, custom_repr=[(int, lambda x: 'int')]) == repr
    assert get_repr_function(1, custom_repr=[(lambda x: True, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, custom_repr=[(lambda x: True, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, custom_repr=[(lambda x: False, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, custom_repr=[(lambda x: False, lambda x: 'int')]) == repr




# Generated at 2022-06-16 19:33:54.464248
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:57.843607
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:06.421592
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass

    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

        def write(self, s):
            pass

    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass


# Generated at 2022-06-16 19:34:16.147870
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream2(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass

    assert issubclass(MyWritableStream2, WritableStream)

    class MyWritableStream3(WritableStream):
        def foo(self):
            pass

    assert not issubclass(MyWritableStream3, WritableStream)

    class MyWritableStream4(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass

    assert issubclass(MyWritableStream4, WritableStream)


# Generated at 2022-06-16 19:34:21.434892
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:29.191921
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, str), (str, lambda x: 'str'))) == repr
    assert get_repr_function('1', ((int, str), (str, lambda x: 'str'))) == \
                                                                       'str'
    assert get_repr_function(1, ((str, str), (str, lambda x: 'str'))) == repr
    assert get_repr_function('1', ((str, str), (str, lambda x: 'str'))) == \
                                                                       'str'
    assert get_repr_function(1, ((lambda x: x == 1, str), (str, lambda x: 'str'))) == \
                                                                       'str'

# Generated at 2022-06-16 19:34:38.872774
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:50.300167
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:58.246662
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:35:09.803480
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abc', max_length=2) == "'a'"
    assert get_shortish_repr('abc', max_length=3) == "'ab'"
    assert get_shortish_repr('abc', max_length=4) == "'abc'"
    assert get_shortish_repr('abc', max_length=5) == "'abc'"
    assert get_shortish_repr('abc', max_length=6) == "'abc'"
    assert get_shortish_repr('abc', max_length=7) == "'abc'"
    assert get_shortish_repr('abc', max_length=8) == "'abc'"

# Generated at 2022-06-16 19:35:12.356052
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:17.631365
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'



# Generated at 2022-06-16 19:35:29.764146
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((str, str),)) == repr
    assert get_repr_function(1, ((lambda x: x == 1, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) == repr
    assert get_repr_function(1, ((lambda x: x == 1, str), (int, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (str, str))) == repr
    assert get_repr_

# Generated at 2022-06-16 19:35:38.076753
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'a')]) == (
        lambda x: 'a'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'a')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'a'),
                                 (lambda x: True, lambda x: 'b')]) == (
                                     lambda x: 'b'
                                 )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'a'),
                                 (lambda x: False, lambda x: 'b')]) == repr

# Generated at 2022-06-16 19:35:49.686312
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_to = False
        def write(self, s):
            self.written_to = True
    my_writable_stream = MyWritableStream()
    assert issubclass(MyWritableStream, WritableStream)
    assert isinstance(my_writable_stream, WritableStream)
    my_writable_stream.write('hello')
    assert my_writable_stream.written_to



# Generated at 2022-06-16 19:36:01.876093
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream)
    assert not issubclass(object, MyWritableStream)
    assert not issubclass(MyWritableStream, object)
    assert not issubclass(MyWritableStream, int)
    assert not issubclass(MyWritableStream, str)
    assert not issubclass(MyWritableStream, list)
    assert not issubclass(MyWritableStream, dict)
    assert not issubclass(MyWritableStream, set)
    assert not issubclass(MyWritableStream, tuple)
    assert not issubclass(MyWritableStream, frozenset)
    assert not issub

# Generated at 2022-06-16 19:36:04.447961
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:13.940872
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[]) == repr

# Generated at 2022-06-16 19:36:18.223439
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(A): pass

    assert get_repr_function(A(), ()) == repr
    assert get_repr_function(B(), ()) == repr
    assert get_repr_function(C(), ()) == repr

    assert get_repr_function(A(), ((A, str),)) == str
    assert get_repr_function(B(), ((A, str),)) == str
    assert get_repr_function(C(), ((A, str),)) == str

    assert get_repr_function(A(), ((B, str),)) == repr
    assert get_repr_function(B(), ((B, str),)) == str
    assert get_repr_function(C(), ((B, str),)) == repr


# Generated at 2022-06-16 19:36:30.469218
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((str, int), (int, str))) is str
    assert get_repr_function(1, ((str, int), (int, str), (int, int))) is int
    assert get_repr_function(1, ((str, int), (int, str), (int, int), (int, str))) is str
    assert get_repr_function(1, ((str, int), (int, str), (int, int), (int, str), (int, int))) is int

# Generated at 2022-06-16 19:36:33.171672
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:42.230325
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:36:53.272010
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 1, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) == repr
    assert get_repr_function(1, ((lambda x: x == 2, str),
                                 (lambda x: x == 1, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str),
                                 (lambda x: x == 3, str))) == repr

# Generated at 2022-06-16 19:37:04.700396
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass

    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass

    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
        def write(self, s):
            pass

    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
        write = None


# Generated at 2022-06-16 19:37:12.054605
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:37:17.370529
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'



# Generated at 2022-06-16 19:37:19.699144
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:37:22.907004
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:37:31.294279
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:37:34.974488
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(int, str), (lambda x: True, str)]) is str
    assert get_repr_function(1, [(int, str), (lambda x: False, str)]) is str
    assert get_repr_function(1, [(int, str), (lambda x: False, str),
                                 (lambda x: True, str)]) is str

# Generated at 2022-06-16 19:37:42.026121
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
        def write(self, s):
            pass


# Generated at 2022-06-16 19:37:53.040413
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=2) == "'h...'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"

# Generated at 2022-06-16 19:38:02.845606
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == \
                                                                    (lambda x: 'hi')
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == \
                                                                    (lambda x: 'bye')
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == \
                                                                    (lambda x: 'hi')

# Generated at 2022-06-16 19:38:13.435169
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.0, custom_repr=((int, str),)) == repr
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str))) == str
    assert get_repr_function(1.0, custom_repr=((float, str), (int, str))) == str
    assert get_repr_function(1.0, custom_repr=((float, str), (int, str))) == str
    assert get_repr_function(1.0, custom_repr=((float, str), (int, str))) == str