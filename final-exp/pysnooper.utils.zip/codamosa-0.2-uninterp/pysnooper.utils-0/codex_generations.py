

# Generated at 2022-06-16 19:28:29.902877
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((str, int), (int, str))) is str
    assert get_repr_function(1, ((str, int), (int, lambda x: '1'))) is str
    assert get_repr_function(1, ((str, int), (int, lambda x: '1'),
                                 (int, lambda x: '2'))) is str

# Generated at 2022-06-16 19:28:42.333038
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(B): pass
    class D(C): pass
    class E(D): pass
    class F(E): pass
    class G(F): pass
    class H(G): pass
    class I(H): pass
    class J(I): pass
    class K(J): pass
    class L(K): pass
    class M(L): pass
    class N(M): pass
    class O(N): pass
    class P(O): pass
    class Q(P): pass
    class R(Q): pass
    class S(R): pass
    class T(S): pass
    class U(T): pass
    class V(U): pass
    class W(V): pass
    class X(W): pass
    class Y(X): pass
   

# Generated at 2022-06-16 19:28:53.495070
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:29:04.582875
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\x00') == '?'
    assert shitcode('\x01') == '?'
    assert shitcode('\x02') == '?'
    assert shitcode('\x03') == '?'
    assert shitcode('\x04') == '?'
    assert shitcode('\x05') == '?'
    assert shitcode('\x06') == '?'
    assert shitcode('\x07') == '?'
    assert shitcode('\x08') == '?'
    assert shitcode('\t') == '?'
    assert shitcode('\n') == '?'
    assert shitcode('\x0b') == '?'
    assert shitcode('\x0c') == '?'
    assert shitcode('\r') == '?'

# Generated at 2022-06-16 19:29:15.516424
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:29:24.722663
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_text = ''
        def write(self, s):
            self.written_text += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written_text == 'abc'
    my_writable_stream.write('def')
    assert my_writable_stream.written_text == 'abcdef'
    my_writable_stream.write('ghi')
    assert my_writable_stream.written_text == 'abcdefghi'



# Generated at 2022-06-16 19:29:27.327497
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            return s

    assert isinstance(MyWritableStream(), WritableStream)



# Generated at 2022-06-16 19:29:29.968844
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyStream, WritableStream)



# Generated at 2022-06-16 19:29:39.703834
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:29:51.238529
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:30:05.853754
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abc', max_length=2) == "'a'"
    assert get_shortish_repr('abc', max_length=3) == "'ab'"
    assert get_shortish_repr('abc', max_length=4) == "'abc'"
    assert get_shortish_repr('abc', max_length=5) == "'abc'"
    assert get_shortish_repr('abc', max_length=6) == "'abc'"
    assert get_shortish_repr('abc', max_length=7) == "'abc'"
    assert get_shortish_repr('abc', max_length=8) == "'abc'"

# Generated at 2022-06-16 19:30:11.955567
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_data = ''
        def write(self, s):
            self.written_data += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written_data == 'abc'



# Generated at 2022-06-16 19:30:22.061662
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00c') == 'a?c'
    assert shitcode('a\x00\x00c') == 'a??c'
    assert shitcode('a\x00\x00\x00c') == 'a???c'
    assert shitcode('a\x00\x00\x00\x00c') == 'a????c'
    assert shitcode('a\x00\x00\x00\x00\x00c') == 'a?????c'
    assert shitcode('a\x00\x00\x00\x00\x00\x00c') == 'a??????c'

# Generated at 2022-06-16 19:30:33.432215
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:30:35.246400
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:30:43.365593
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1.0, ((int, str),)) is repr
    assert get_repr_function(1, ((lambda x: x == 1, str),)) is str
    assert get_repr_function(2, ((lambda x: x == 1, str),)) is repr
    assert get_repr_function(1, ((lambda x: x == 1, str),
                                 (lambda x: x == 2, str))) is str
    assert get_repr_function(2, ((lambda x: x == 1, str),
                                 (lambda x: x == 2, str))) is str

# Generated at 2022-06-16 19:30:48.007440
# Unit test for function get_repr_function

# Generated at 2022-06-16 19:30:50.604592
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:02.218604
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:31:07.910546
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
        def write(self, s):
            pass


# Generated at 2022-06-16 19:31:20.334363
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is repr
    assert get_repr_function(1, ((int, str), (int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1, ((int, str), (int, lambda x: 'int'),
                                 (str, lambda x: 'str'))) == 'int'
    assert get_repr_function('', ((int, str), (int, lambda x: 'int'),
                                  (str, lambda x: 'str'))) == 'str'



# Generated at 2022-06-16 19:31:25.848890
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'



# Generated at 2022-06-16 19:31:36.962799
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (int, int))) is int
    assert get_repr_function(1, ((int, str), (int, int), (int, str))) is str
    assert get_repr_function(1, ((int, str), (int, int), (int, str),
                                 (int, int))) is int
    assert get_repr_function(1, ((int, str), (int, int), (int, str),
                                 (int, int), (int, str))) is str

# Generated at 2022-06-16 19:31:47.196835
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10)

# Generated at 2022-06-16 19:31:53.341163
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:32:00.719841
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1.0, custom_repr=((int, lambda x: 'int'))) == repr
    assert get_repr_function(1, custom_repr=((lambda x: x == 1, lambda x: '1'))) == '1'
    assert get_repr_function(2, custom_repr=((lambda x: x == 1, lambda x: '1'))) == repr



# Generated at 2022-06-16 19:32:07.057825
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_strings = []
        def write(self, s):
            self.written_strings.append(s)

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_strings == ['hello']



# Generated at 2022-06-16 19:32:17.277723
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(3) == '3'
    assert get_shortish_repr(3, max_length=2) == '3'
    assert get_shortish_repr(3, max_length=1) == '3'
    assert get_shortish_repr(3, max_length=0) == '3'
    assert get_shortish_repr(3, max_length=None) == '3'
    assert get_shortish_repr(3, max_length=3) == '3'
    assert get_shortish_repr(3, max_length=4) == '3'
    assert get_shortish_repr(3, max_length=5) == '3'

# Generated at 2022-06-16 19:32:25.153244
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'h...'"
    assert get_shortish_repr('hello', max_length=4) == "'he...'"
    assert get_shortish_repr('hello', max_length=5) == "'hel...'"
    assert get_shortish_repr('hello', max_length=6) == "'hell...'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"

# Generated at 2022-06-16 19:32:37.236447
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str),
                                 (lambda x: True, str)]) is str

# Generated at 2022-06-16 19:32:44.747804
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:51.631080
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:32:56.410883
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'



# Generated at 2022-06-16 19:33:03.004871
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'



# Generated at 2022-06-16 19:33:08.362966
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written_string == 'abc'



# Generated at 2022-06-16 19:33:11.711526
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'



# Generated at 2022-06-16 19:33:14.700597
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:23.013668
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00\x01') == 'abc??'
    assert shitcode('abc\x00\x01\x02') == 'abc???'
    assert shitcode('abc\x00\x01\x02\x03') == 'abc????'
    assert shitcode('abc\x00\x01\x02\x03\x04') == 'abc?????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05') == 'abc??????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06') == 'abc???????'

# Generated at 2022-06-16 19:33:31.856063
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str), (lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str), (lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str), (lambda x: False, str), (lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str), (lambda x: False, str), (lambda x: False, str)])

# Generated at 2022-06-16 19:33:42.078076
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == 'bye'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')]) is repr
    assert get_repr_function(1, [(int, lambda x: 'hi')]) == 'hi'

# Generated at 2022-06-16 19:34:04.253848
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int'),)) == 'int'
    assert get_repr_function(1.0, ((int, lambda x: 'int'),)) == repr
    assert get_repr_function(1.0, ((float, lambda x: 'float'),)) == 'float'
    assert get_repr_function(1.0, ((float, lambda x: 'float'),
                                   (int, lambda x: 'int'))) == 'float'
    assert get_repr_function(1.0, ((float, lambda x: 'float'),
                                   (int, lambda x: 'int'),
                                   (lambda x: True, lambda x: 'default'))) == 'float'

# Generated at 2022-06-16 19:34:13.685313
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        def write(self, s):
            pass

    class E(D):
        pass

    class F(E):
        pass

    assert issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)
    assert issubclass(C, WritableStream)
    assert issubclass(D, WritableStream)
    assert issubclass(E, WritableStream)
    assert issubclass(F, WritableStream)



# Generated at 2022-06-16 19:34:24.580456
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00b\x00') == 'a?b?'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode('a\x00b\x00c\x00') == 'a?b?c?'
    assert shitcode('a\x00b\x00c\x00d') == 'a?b?c?d'
    assert shitcode('a\x00b\x00c\x00d\x00') == 'a?b?c?d?'

# Generated at 2022-06-16 19:34:35.876061
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E: pass
    class F(E): pass
    class G(E): pass
    class H(F, G): pass

    assert get_repr_function(D(), ()) == repr
    assert get_repr_function(D(), ((A, lambda x: 'A'))) == repr
    assert get_repr_function(D(), ((A, lambda x: 'A'), (B, lambda x: 'B'))) == \
                                                                            'B'
    assert get_repr_function(D(), ((A, lambda x: 'A'), (B, lambda x: 'B'),
                                   (C, lambda x: 'C'))) == 'B'
    assert get_repr_

# Generated at 2022-06-16 19:34:40.369268
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:46.475764
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1.0, ((int, lambda x: 'int'))) == repr
    assert get_repr_function(1, ((lambda x: isinstance(x, int),
                                  lambda x: 'int'))) == 'int'
    assert get_repr_function(1.0, ((lambda x: isinstance(x, int),
                                    lambda x: 'int'))) == repr



# Generated at 2022-06-16 19:34:50.893700
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'hi')]) is repr

# Generated at 2022-06-16 19:35:00.530944
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode('a\x00b\x00c\x00d') == 'a?b?c?d'
    assert shitcode('a\x00b\x00c\x00d\x00e') == 'a?b?c?d?e'
    assert shitcode('a\x00b\x00c\x00d\x00e\x00f') == 'a?b?c?d?e?f'

# Generated at 2022-06-16 19:35:11.585274
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert isinstance(A(), WritableStream)
    class B(WritableStream):
        pass
    assert not isinstance(B(), WritableStream)
    class C(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert isinstance(C(), WritableStream)
    class D(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert isinstance(D(), WritableStream)
    class E(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert isinstance

# Generated at 2022-06-16 19:35:16.907328
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((str, str),)) == repr
    assert get_repr_function(1, ((lambda x: x == 1, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) == repr



# Generated at 2022-06-16 19:35:44.085032
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:35:52.729994
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def foo(self):
            pass
    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        write = None
    assert not issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:03.700702
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:36:08.054752
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'



# Generated at 2022-06-16 19:36:13.883210
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) == repr
    assert get_repr_function(1, [(int, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )
    assert get_repr_function(1, [(int, lambda x: 'hi'), (int, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )

# Generated at 2022-06-16 19:36:18.176463
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'hi')]) is repr

# Generated at 2022-06-16 19:36:30.419724
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=5) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5, normalize=True) == "'hel...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=6, normalize=True) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=7, normalize=True) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_

# Generated at 2022-06-16 19:36:39.545426
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(lambda x: True, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(lambda x: False, lambda x: 'int')]) == repr



# Generated at 2022-06-16 19:36:42.205163
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:53.224240
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, str)]) == str
    assert get_repr_function(1, [(lambda x: False, str)]) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(int, str), (float, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (str, str)]) == str
    assert get_repr_function('1', [(int, str), (float, str), (str, str)]) == str
    assert get

# Generated at 2022-06-16 19:37:50.638054
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass

    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

        def write(self, s):
            pass

    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass


# Generated at 2022-06-16 19:38:01.705722
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, [(float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'),
                                   (int, lambda x: 'int')]) == 'float'
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int')]) == 'int'

# Generated at 2022-06-16 19:38:12.680758
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'