

# Generated at 2022-06-16 19:28:22.484975
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:28:27.608201
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_lines = []
        def write(self, s):
            self.written_lines.append(s)
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_lines == ['hello']

# Generated at 2022-06-16 19:28:34.339849
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.0, custom_repr=((int, str),)) == repr
    assert get_repr_function(1.0, custom_repr=((float, str),)) == str
    assert get_repr_function(1.0, custom_repr=((float, str), (int, str))) == str
    assert get_repr_function(1, custom_repr=((float, str), (int, str))) == str
    assert get_repr_function(1, custom_repr=((float, str), (int, str))) == str
    assert get_repr_function(1, custom_repr=((float, str), (int, str))) == str

# Generated at 2022-06-16 19:28:46.884453
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
        def write(self, s):
            pass


# Generated at 2022-06-16 19:28:49.039596
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:29:01.216937
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, str), (str, lambda x: 'str'))) == repr
    assert get_repr_function('1', ((int, str), (str, lambda x: 'str'))) == str
    assert get_repr_function(1, ((str, str), (str, lambda x: 'str'))) == repr
    assert get_repr_function('1', ((str, str), (str, lambda x: 'str'))) == str
    assert get_repr_function(1, ((lambda x: True, str), (str, lambda x: 'str'))) == str
    assert get_repr_function('1', ((lambda x: True, str), (str, lambda x: 'str'))) == str

# Generated at 2022-06-16 19:29:03.666254
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = ''
        def write(self, s):
            self.written_stuff += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_stuff == 'hello'

# Generated at 2022-06-16 19:29:14.868507
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
        def write(self, s):
            pass


# Generated at 2022-06-16 19:29:25.352155
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(D): pass
    class F(E): pass
    class G(F): pass
    class H(G): pass
    class I(H): pass
    class J(I): pass
    class K(J): pass
    class L(K): pass
    class M(L): pass
    class N(M): pass
    class O(N): pass
    class P(O): pass
    class Q(P): pass
    class R(Q): pass
    class S(R): pass
    class T(S): pass
    class U(T): pass
    class V(U): pass
    class W(V): pass
    class X(W): pass
    class Y(X): pass

# Generated at 2022-06-16 19:29:36.311035
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''

    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(12345, max_length=3) == '123...'

# Generated at 2022-06-16 19:29:50.447990
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B:
        pass

    assert not issubclass(B, WritableStream)

    class C:
        def write(self, s):
            pass
        def foo(self):
            pass

    assert issubclass(C, WritableStream)

    class D:
        def write(self, s):
            pass
        def foo(self):
            pass
        write = None

    assert not issubclass(D, WritableStream)

    class E:
        def write(self, s):
            pass
        def foo(self):
            pass
        write = None
        def write(self, s):
            pass

    assert issubclass(E, WritableStream)


# Generated at 2022-06-16 19:29:54.981910
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) is repr
    assert get_repr_function(None, ((lambda x: True, lambda x: 'hi'))) == 'hi'
    assert get_repr_function(None, ((lambda x: False, lambda x: 'hi'))) is repr
    assert get_repr_function(None, ((lambda x: True, lambda x: 'hi'),
                                    (lambda x: True, lambda x: 'bye'))) == 'hi'
    assert get_repr_function(None, ((lambda x: False, lambda x: 'hi'),
                                    (lambda x: True, lambda x: 'bye'))) == 'bye'

# Generated at 2022-06-16 19:29:58.997477
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:30:09.593103
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00\x01\x02') == 'abc???'
    assert shitcode('abc\x00\x01\x02\x03') == 'abc????'
    assert shitcode('abc\x00\x01\x02\x03\x04') == 'abc?????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05') == 'abc??????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06') == 'abc???????'

# Generated at 2022-06-16 19:30:16.242716
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_strings = []
        def write(self, s):
            self.written_strings.append(s)
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written_strings == ['abc']



# Generated at 2022-06-16 19:30:24.305096
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, [(float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'),
                                   (int, lambda x: 'int')]) == 'float'
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int')]) == 'int'

# Generated at 2022-06-16 19:30:32.650375
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, [(lambda x: x == 1, lambda x: '1')]) == '1'
    assert get_repr_function(1, [(lambda x: x == 2, lambda x: '2')]) == repr
    assert get_repr_function(1, [(lambda x: x == 2, lambda x: '2'),
                                 (lambda x: x == 1, lambda x: '1')]) == '1'



# Generated at 2022-06-16 19:30:36.016792
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:30:40.458642
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = []
        def write(self, s):
            self.written_stuff.append(s)

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_stuff == ['hello']



# Generated at 2022-06-16 19:30:46.805653
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 1, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) == repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 3, str)])

# Generated at 2022-06-16 19:31:01.187745
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'

# Generated at 2022-06-16 19:31:03.577475
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:14.966786
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(int, str), (lambda x: True, str)]) is str
    assert get_repr_function(1, [(int, str), (lambda x: False, str)]) is str
    assert get_repr_function(1, [(int, str), (lambda x: False, str),
                                 (lambda x: True, str)]) is str

# Generated at 2022-06-16 19:31:26.583112
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00bc') == 'a?bc'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode('a\x00b\x00c\x00') == 'a?b?c?'
    assert shitcode('\x00') == '?'
    assert shitcode('\x00\x00') == '??'
    assert shitcode('\x00\x00\x00') == '???'
    assert shitcode('\x00\x00\x00\x00') == '????'
    assert shitcode('\x00\x00\x00\x00\x00') == '?????'

# Generated at 2022-06-16 19:31:37.951917
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 1, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) is repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str)]) is str



# Generated at 2022-06-16 19:31:42.161580
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, custom_repr=[(int, lambda x: 'int')]) == repr



# Generated at 2022-06-16 19:31:50.771358
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((lambda x: True, lambda x: 'hi'))) == \
                                                                    (lambda x: 'hi')
    assert get_repr_function(1, ((lambda x: False, lambda x: 'hi'))) == repr
    assert get_repr_function(1, ((lambda x: True, lambda x: 'hi'),)) == \
                                                                    (lambda x: 'hi')
    assert get_repr_function(1, ((lambda x: False, lambda x: 'hi'),)) == repr

# Generated at 2022-06-16 19:32:00.931628
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass
        def write3(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass

# Generated at 2022-06-16 19:32:07.391777
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_text = ''
        def write(self, s):
            self.written_text += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_text == 'hello'



# Generated at 2022-06-16 19:32:10.029522
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:17.992172
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:20.305525
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:23.955982
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = []
        def write(self, s):
            self.written.append(s)
    mws = MyWritableStream()
    mws.write('hi')
    assert mws.written == ['hi']



# Generated at 2022-06-16 19:32:36.018948
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(lambda x: True, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, [(lambda x: False, lambda x: 'int')]) == repr
    assert get

# Generated at 2022-06-16 19:32:46.700951
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'h...'"
    assert get_shortish_repr('hello', max_length=4) == "'he...'"
    assert get_shortish_repr('hello', max_length=5) == "'hel...'"
    assert get_shortish_repr('hello', max_length=6) == "'hell...'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"

# Generated at 2022-06-16 19:32:56.223089
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:32:59.131704
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:05.892978
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'



# Generated at 2022-06-16 19:33:08.453347
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:19.665992
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:33:41.934525
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream2(WritableStream):
        pass

    assert not issubclass(MyWritableStream2, WritableStream)

    class MyWritableStream3(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass

    assert issubclass(MyWritableStream3, WritableStream)

    class MyWritableStream4(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass
        def write3(self, s):
            pass

    assert issubclass(MyWritableStream4, WritableStream)


# Generated at 2022-06-16 19:33:44.999792
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:54.188263
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, str)]) == str
    assert get_repr_function(1, [(lambda x: False, str)]) == repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: True, str)]) == str
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str)]) == repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str),
                                 (lambda x: True, str)]) == str

# Generated at 2022-06-16 19:34:04.725739
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:15.136338
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: '1')]) == \
                                                                   (lambda x: '1')
    assert get_repr_function(1, [(lambda x: False, lambda x: '1')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'),
                                 (lambda x: True, lambda x: '2')]) == \
                                                                   (lambda x: '2')
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'),
                                 (lambda x: False, lambda x: '2')]) == repr

# Generated at 2022-06-16 19:34:25.867627
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, [(float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'),
                                   (int, lambda x: 'int')]) == 'float'
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int')]) == 'int'

# Generated at 2022-06-16 19:34:36.739520
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:39.643467
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:46.175596
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1, [(lambda x: isinstance(x, int),
                                  lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(lambda x: isinstance(x, int),
                                    lambda x: 'int')]) == repr



# Generated at 2022-06-16 19:34:48.738399
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:17.394431
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1.0, custom_repr=((int, lambda x: 'int'))) == repr
    assert get_repr_function(1, custom_repr=((float, lambda x: 'float'))) == repr
    assert get_repr_function(1.0, custom_repr=((float, lambda x: 'float'))) == 'float'
    assert get_repr_function(1, custom_repr=((float, lambda x: 'float'),
                                             (int, lambda x: 'int'))) == 'int'

# Generated at 2022-06-16 19:35:24.086321
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'




# Generated at 2022-06-16 19:35:31.625700
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream)
    assert issubclass(MyWritableStream, object)
    assert not issubclass(object, MyWritableStream)
    assert issubclass(MyWritableStream, MyWritableStream)
    assert issubclass(object, object)
    assert not issubclass(object, WritableStream)
    assert not issubclass(WritableStream, object)



# Generated at 2022-06-16 19:35:39.355377
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:35:50.976241
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'hi')]) is repr

# Generated at 2022-06-16 19:36:02.378144
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'


# Generated at 2022-06-16 19:36:10.755584
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:36:19.719777
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x01') == 'abc?'
    assert shitcode('abc\x02') == 'abc?'
    assert shitcode('abc\x03') == 'abc?'
    assert shitcode('abc\x04') == 'abc?'
    assert shitcode('abc\x05') == 'abc?'
    assert shitcode('abc\x06') == 'abc?'
    assert shitcode('abc\x07') == 'abc?'
    assert shitcode('abc\x08') == 'abc?'
    assert shitcode('abc\x09') == 'abc?'
    assert shitcode('abc\x0a') == 'abc?'
    assert shitcode('abc\x0b') == 'abc?'

# Generated at 2022-06-16 19:36:31.815386
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str),
                                 (lambda x: True, str)]) is str

# Generated at 2022-06-16 19:36:37.763069
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = ''
        def write(self, s):
            self.written_stuff += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_stuff == 'hello'



# Generated at 2022-06-16 19:37:37.586383
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(123456789, max_length=4) == '...789'
    assert get_shortish_repr(123456789, max_length=5) == '...789'
    assert get_shortish_repr(123456789, max_length=6) == '...789'
    assert get_shortish_repr

# Generated at 2022-06-16 19:37:39.588836
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:37:51.505453
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass

    assert get_repr_function(A(), ()) is repr
    assert get_repr_function(B(), ()) is repr
    assert get_repr_function(C(), ()) is repr
    assert get_repr_function(D(), ()) is repr

    assert get_repr_function(A(), ((A, lambda x: 'A'))) == 'A'
    assert get_repr_function(B(), ((A, lambda x: 'A'))) == 'A'
    assert get_repr_function(C(), ((A, lambda x: 'A'))) == 'A'
    assert get_repr_function(D(), ((A, lambda x: 'A'))) == 'A'

    assert get

# Generated at 2022-06-16 19:38:02.022955
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:38:12.761497
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((lambda x: True, lambda x: '1'))) == (
        lambda x: '1'
    )
    assert get_repr_function(1, ((lambda x: False, lambda x: '1'))) == repr
    assert get_repr_function(1, ((lambda x: False, lambda x: '1'),
                                 (lambda x: True, lambda x: '2'))) == (
        lambda x: '2'
    )
    assert get_repr_function(1, ((lambda x: False, lambda x: '1'),
                                 (lambda x: False, lambda x: '2'))) == repr