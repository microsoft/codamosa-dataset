

# Generated at 2022-06-16 19:28:27.509753
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00b\x00') == 'a?b?'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode('a\x00b\x00c\x00') == 'a?b?c?'
    assert shitcode('a\x00b\x00c\x00d') == 'a?b?c?d'
    assert shitcode('a\x00b\x00c\x00d\x00') == 'a?b?c?d?'

# Generated at 2022-06-16 19:28:34.294038
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: True, str),
                                 (lambda x: False, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str)]) is repr

# Generated at 2022-06-16 19:28:46.889443
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == 'bye'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')]) is repr

# Generated at 2022-06-16 19:28:51.682063
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1, [(lambda x: isinstance(x, int),
                                  lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(lambda x: isinstance(x, int),
                                    lambda x: 'int')]) == repr



# Generated at 2022-06-16 19:29:03.622638
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == (
        lambda x: 'bye'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')]) == repr

# Generated at 2022-06-16 19:29:14.828937
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((int, str), (str, int))) == str
    assert get_repr_function(1, ((str, int), (int, str))) == str
    assert get_repr_function(1, ((str, int), (int, int))) == int
    assert get_repr_function(1, ((str, int), (int, int), (int, str))) == str
    assert get_repr_function(1, ((str, int), (int, int), (int, str),
                                 (str, str))) == str

# Generated at 2022-06-16 19:29:25.310323
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:29:30.466958
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'



# Generated at 2022-06-16 19:29:35.933411
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'



# Generated at 2022-06-16 19:29:42.444738
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1, custom_repr=((lambda x: True, lambda x: 'int'))) == 'int'
    assert get_repr_function(1, custom_repr=((lambda x: False, lambda x: 'int'))) != 'int'
    assert get_repr_function(1, custom_repr=((lambda x: False, lambda x: 'int'),
                                             (lambda x: True, lambda x: 'int'))) == 'int'
    assert get_repr_function(1, custom_repr=((lambda x: False, lambda x: 'int'),
                                             (lambda x: False, lambda x: 'int'))) != 'int'


# Generated at 2022-06-16 19:29:56.673133
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B:
        pass

    assert not issubclass(B, WritableStream)

    class C:
        def write(self, s):
            pass

        def write_more(self, s):
            pass

    assert issubclass(C, WritableStream)

    class D:
        def write(self, s):
            pass

        def write_more(self, s):
            pass

        def write(self, s):
            pass

    assert issubclass(D, WritableStream)

    class E:
        def write(self, s):
            pass

        def write_more(self, s):
            pass

        def write(self, s):
            pass


# Generated at 2022-06-16 19:30:08.903779
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == '1'
    assert get_shortish_repr(1, max_length=-2) == '1'
    assert get_shortish_repr(1, max_length=-3) == '1'
    assert get_shortish_repr(1, max_length=-4) == '1'


# Generated at 2022-06-16 19:30:20.314478
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass

    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

        def write(self, s):
            pass

    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass


# Generated at 2022-06-16 19:30:32.738744
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr('hello', max_length=5) == 'hello'
    assert get_shortish_repr('hello', max_length=4) == 'he...'
    assert get_shortish_repr('hello', max_length=3) == 'he...'
    assert get_shortish_repr('hello', max_length=2) == 'he...'
    assert get_shortish_repr('hello', max_length=1) == '...'
    assert get_shortish_repr('hello', max_length=0) == '...'
    assert get_shortish_repr('hello', max_length=None) == 'hello'

# Generated at 2022-06-16 19:30:36.120809
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:30:43.812204
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'

# Generated at 2022-06-16 19:30:46.321984
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written_string == 'abc'



# Generated at 2022-06-16 19:30:58.355165
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass

    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

        def write(self, s):
            pass

    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass


# Generated at 2022-06-16 19:31:01.049119
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:07.470476
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == (
        lambda x: 'hi'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == (
        lambda x: 'bye'
    )

# Generated at 2022-06-16 19:31:13.826916
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:17.901977
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:31:28.124063
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 1, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) == repr
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 3, str))) == str




# Generated at 2022-06-16 19:31:39.111799
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((int, str), (str, int), (int, int))) is int
    assert get_repr_function(1, ((int, str), (str, int), (int, int), (int, str))) is str
    assert get_repr_function(1, ((int, str), (str, int), (int, int), (int, str), (int, int))) is int

# Generated at 2022-06-16 19:31:42.258465
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:50.850846
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str),
                                 (lambda x: True, str)]) is str

# Generated at 2022-06-16 19:32:00.959778
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abc', max_length=2) == "'a...'"
    assert get_shortish_repr('abc', max_length=3) == "'ab...'"
    assert get_shortish_repr('abc', max_length=4) == "'abc'"
    assert get_shortish_repr('abc', max_length=5) == "'abc'"
    assert get_shortish_repr('abc', max_length=6) == "'abc'"
    assert get_shortish_repr('abc', max_length=7) == "'abc'"
    assert get_shortish_repr('abc', max_length=8) == "'abc'"

# Generated at 2022-06-16 19:32:12.247616
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode('a\x00b\x00c\x00d') == 'a?b?c?d'
    assert shitcode('a\x00b\x00c\x00d\x00e') == 'a?b?c?d?e'
    assert shitcode('a\x00b\x00c\x00d\x00e\x00f') == 'a?b?c?d?e?f'

# Generated at 2022-06-16 19:32:18.908942
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:32:26.128057
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00def') == 'abc?def'
    assert shitcode('abc\x00def\x00') == 'abc?def?'
    assert shitcode('\x00') == '?'
    assert shitcode('\x00\x00') == '??'
    assert shitcode('\x00\x00\x00') == '???'
    assert shitcode('\x00\x00\x00\x00') == '????'
    assert shitcode('\x00\x00\x00\x00\x00') == '?????'
    assert shitcode('\x00\x00\x00\x00\x00\x00') == '??????'

# Generated at 2022-06-16 19:32:35.615759
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'



# Generated at 2022-06-16 19:32:46.371024
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass

    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass

        def write2(self, s):
            pass

    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass

        def write2(self, s):
            pass

        def write3(self, s):
            pass

    assert not issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass


# Generated at 2022-06-16 19:32:55.864708
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:33:02.732720
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written == 'abc'



# Generated at 2022-06-16 19:33:11.489788
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\x00\x01\x02') == '???'

# Generated at 2022-06-16 19:33:21.654382
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: True, lambda x: 'one')]) == 'one'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'one')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'one'),
                                 (lambda x: True, lambda x: 'two')]) == 'two'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'one'),
                                 (lambda x: False, lambda x: 'two')]) == repr

# Generated at 2022-06-16 19:33:24.858958
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:27.108438
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:29.823906
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:39.921969
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00def') == 'abc?def'
    assert shitcode('abc\x00def\xFF') == 'abc?def?'
    assert shitcode('abc\x00def\xFF\x01') == 'abc?def??'
    assert shitcode('abc\x00def\xFF\x01\x00') == 'abc?def???'
    assert shitcode('abc\x00def\xFF\x01\x00\xFF') == 'abc?def????'
    assert shitcode('abc\x00def\xFF\x01\x00\xFF\x00') == 'abc?def?????'

# Generated at 2022-06-16 19:33:45.557669
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:54.517014
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(123456789, max_length=4)

# Generated at 2022-06-16 19:34:00.389532
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'



# Generated at 2022-06-16 19:34:11.547332
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
        def write(self, s):
            pass


# Generated at 2022-06-16 19:34:18.342346
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 1, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) == repr
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) == str



# Generated at 2022-06-16 19:34:21.205297
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:29.090405
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\x00\x01\x02') == '???'
    assert shitcode('\x00\x01\x02') == '???'
    assert shitcode('\x00\x01\x02') == '???'
    assert shitcode('\x00\x01\x02') == '???'
    assert shitcode('\x00\x01\x02') == '???'
    assert shitcode('\x00\x01\x02') == '???'
    assert shitcode('\x00\x01\x02') == '???'
    assert shitcode('\x00\x01\x02') == '???'
    assert shitcode('\x00\x01\x02') == '???'

# Generated at 2022-06-16 19:34:36.841611
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:39.724731
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:48.109578
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:52.681387
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:59.381188
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:35:02.851686
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:13.297690
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream2(WritableStream):
        pass

    assert not issubclass(MyWritableStream2, WritableStream)

    class MyWritableStream3(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass

    assert issubclass(MyWritableStream3, WritableStream)

    class MyWritableStream4(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
        def bar(self):
            pass

    assert issubclass(MyWritableStream4, WritableStream)


# Generated at 2022-06-16 19:35:16.228793
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass
    assert issubclass(WritableStreamSubclass, WritableStream)



# Generated at 2022-06-16 19:35:23.123787
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:35:28.484383
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.s = ''

        def write(self, s):
            self.s += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.s == 'hello'



# Generated at 2022-06-16 19:35:30.792334
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:33.195983
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:40.193252
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass
        write = None
    assert not issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass
        write = None


# Generated at 2022-06-16 19:35:53.665775
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is repr
    assert get_repr_function(1, ((int, str), (int, lambda x: 'int'))) is str
    assert get_repr_function(1, ((int, str), (int, lambda x: 'int')),
                             (int, lambda x: 'int')) is str
    assert get_repr_function(1, ((int, str), (int, lambda x: 'int')),
                             (int, lambda x: 'int'), (int, lambda x: 'int')) \
                                                                          is str

# Generated at 2022-06-16 19:36:03.960968
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(A):
        pass

    assert issubclass(B, WritableStream)

    class C(B):
        pass

    assert issubclass(C, WritableStream)

    class D(C):
        pass

    assert issubclass(D, WritableStream)

    class E(D):
        pass

    assert issubclass(E, WritableStream)

    class F(E):
        pass

    assert issubclass(F, WritableStream)

    class G(F):
        pass

    assert issubclass(G, WritableStream)

    class H(G):
        pass

    assert issubclass(H, WritableStream)


# Generated at 2022-06-16 19:36:11.584390
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00\x00b') == 'a??b'
    assert shitcode('a\x00\x00\x00b') == 'a???b'
    assert shitcode('a\x00\x00\x00\x00b') == 'a????b'
    assert shitcode('a\x00\x00\x00\x00\x00b') == 'a?????b'
    assert shitcode('a\x00\x00\x00\x00\x00\x00b') == 'a??????b'

# Generated at 2022-06-16 19:36:16.596213
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_strings = []
        def write(self, s):
            self.written_strings.append(s)
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_strings == ['hello']



# Generated at 2022-06-16 19:36:18.849090
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:31.097411
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: True, str), (lambda x: True, str)]) \
                                                                          is str
    assert get_repr_function(1, [(lambda x: False, str), (lambda x: True, str)]) \
                                                                          is str
    assert get_repr_function(1, [(lambda x: True, str), (lambda x: False, str)]) \
                                                                          is str

# Generated at 2022-06-16 19:36:39.782655
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 1, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) == repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str)]) == str



# Generated at 2022-06-16 19:36:50.779179
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((str, int), (int, str))) is str
    assert get_repr_function(1, ((str, int), (int, str), (int, int))) is int
    assert get_repr_function(1, ((str, int), (int, str), (int, int),
                                 (int, str))) is str
    assert get_repr_function(1, ((str, int), (int, str), (int, int),
                                 (int, str), (str, str))) is str
    assert get_repr_function

# Generated at 2022-06-16 19:36:57.867676
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=None, normalize=True) == '1'

# Generated at 2022-06-16 19:37:10.097889
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: True, str), (lambda x: True, str)]) \
                                                                          is str
    assert get_repr_function(1, [(lambda x: False, str), (lambda x: True, str)]) \
                                                                          is str
    assert get_repr_function(1, [(lambda x: False, str), (lambda x: False, str)]) \
                                                                          is repr

# Generated at 2022-06-16 19:37:18.526250
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:37:25.194018
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str),
                                 (lambda x: True, str)]) is str

# Generated at 2022-06-16 19:37:37.546991
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:37:39.552333
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:37:51.511396
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr

# Generated at 2022-06-16 19:38:01.990413
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(int, str), (str, int)]) is str
    assert get_repr_function(1, [(int, str), (str, int), (int, int)]) is int
    assert get_repr_function(1, [(int, str), (str, int), (int, int), (int, str)]) is str
    assert get_repr_function(1, [(int, str), (str, int), (int, int), (int, str), (str, str)]) is str

# Generated at 2022-06-16 19:38:12.761337
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'