

# Generated at 2022-06-16 19:28:22.367381
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written == 'abc'

# Generated at 2022-06-16 19:28:31.632584
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'abc\x00') == u'abc?'
    assert shitcode(u'abc\x00\x01') == u'abc??'
    assert shitcode(u'abc\x00\x01\x02') == u'abc???'
    assert shitcode(u'abc\x00\x01\x02\x03') == u'abc????'
    assert shitcode(u'abc\x00\x01\x02\x03\x04') == u'abc?????'
    assert shitcode(u'abc\x00\x01\x02\x03\x04\x05') == u'abc??????'

# Generated at 2022-06-16 19:28:44.376826
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:28:46.643522
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:28:48.859564
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:29:01.016013
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode('a\x00b\x00c\x00') == 'a?b?c?'
    assert shitcode('\x00') == '?'
    assert shitcode('\x00\x00') == '??'
    assert shitcode('\x00\x00\x00') == '???'
    assert shitcode('') == ''
    assert shitcode('\x00\x00\x00\x00') == '????'
    assert shitcode('\x00\x00\x00\x00\x00') == '?????'

# Generated at 2022-06-16 19:29:03.805624
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:29:13.293697
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is repr
    assert get_repr_function(1, ((int, str), (int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1, ((int, str), (int, lambda x: 'int'),
                                 (str, lambda x: 'str'))) == 'int'
    assert get_repr_function('1', ((int, str), (int, lambda x: 'int'),
                                   (str, lambda x: 'str'))) == 'str'



# Generated at 2022-06-16 19:29:19.050752
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 1, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) is repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str)]) is str



# Generated at 2022-06-16 19:29:28.064092
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, [(float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'),
                                   (int, lambda x: 'int')]) == 'float'
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int')]) == 'int'

# Generated at 2022-06-16 19:29:40.600330
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 1, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) is repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 3, str)])

# Generated at 2022-06-16 19:29:44.108164
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:29:54.274035
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)
    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)
    class C(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass
    assert issubclass(C, WritableStream)
    class D(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass
        write = None
    assert not issubclass(D, WritableStream)
    class E(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass
        write = None


# Generated at 2022-06-16 19:30:00.450235
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00\x00b') == 'a??b'
    assert shitcode('a\x00\x00\x00b') == 'a???b'
    assert shitcode('a\x00\x00\x00\x00b') == 'a????b'
    assert shitcode('a\x00\x00\x00\x00\x00b') == 'a?????b'
    assert shitcode('a\x00\x00\x00\x00\x00\x00b') == 'a??????b'

# Generated at 2022-06-16 19:30:04.377545
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((int, str), (str, int))) == str
    assert get_repr_function(1, ((str, int), (int, str))) == str
    assert get_repr_function(1, ((str, int), (int, str), (int, int))) == int
    assert get_repr_function(1, ((str, int), (int, str), (int, int),
                                 (int, str))) == str
    assert get_repr_function(1, ((str, int), (int, str), (int, int),
                                 (int, str), (str, str))) == str
    assert get_repr_function

# Generated at 2022-06-16 19:30:15.892835
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00b\x00') == 'a?b?'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode('a\x00b\x00c\x00') == 'a?b?c?'
    assert shitcode('a\x00b\x00c\x00d') == 'a?b?c?d'
    assert shitcode('a\x00b\x00c\x00d\x00') == 'a?b?c?d?'

# Generated at 2022-06-16 19:30:24.110571
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream)
    assert not issubclass(MyWritableStream, MyWritableStream)

    class MyWritableStream2(WritableStream):
        pass
    assert not issubclass(MyWritableStream2, WritableStream)

    class MyWritableStream3(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(MyWritableStream3, WritableStream)

    class MyWritableStream4(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass

# Generated at 2022-06-16 19:30:27.999560
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)



# Generated at 2022-06-16 19:30:33.430384
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_text = ''
        def write(self, s):
            self.written_text += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_text == 'hello'

# Generated at 2022-06-16 19:30:38.514655
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_text = ''
        def write(self, s):
            self.written_text += s
    writable_stream = MyWritableStream()
    writable_stream.write('abc')
    assert writable_stream.written_text == 'abc'



# Generated at 2022-06-16 19:30:52.972714
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('a' * 100) == 'a' * 100
    assert get_shortish_repr('a' * 100, max_length=10) == 'a' * 10 + '...'
    assert get_shortish_repr('a' * 100, max_length=10, normalize=True) == \
                                                                      'a' * 10
    assert get_shortish_repr('a' * 100, max_length=10, normalize=True) == \
                                                                      'a' * 10
    assert get_shortish_repr('a' * 100, max_length=10, normalize=True) == \
                                                                      'a' * 10

# Generated at 2022-06-16 19:31:04.171289
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1.0, [(int, str)]) is repr
    assert get_repr_function(1.0, [(float, str)]) is str
    assert get_repr_function(1.0, [(int, str), (float, str)]) is str
    assert get_repr_function(1.0, [(int, str), (float, str), (str, str)]) is str

# Generated at 2022-06-16 19:31:10.627936
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = ''
        def write(self, s):
            self.written_stuff += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written_stuff == 'abc'



# Generated at 2022-06-16 19:31:22.383461
# Unit test for function get_repr_function
def test_get_repr_function():
    def f(x):
        return x + 1
    assert get_repr_function(1, ((int, f),)) == f
    assert get_repr_function(1.0, ((int, f),)) != f
    assert get_repr_function(1.0, ((int, f),)) == repr
    assert get_repr_function(1, ((lambda x: x == 1, f),)) == f
    assert get_repr_function(2, ((lambda x: x == 1, f),)) != f
    assert get_repr_function(2, ((lambda x: x == 1, f),)) == repr
    assert get_repr_function(1, ((lambda x: x == 1, f), (int, f))) == f

# Generated at 2022-06-16 19:31:30.632388
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

    assert not issubclass(MyWritableStream, WritableStream)


# Generated at 2022-06-16 19:31:42.022128
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.0, [(int, str)]) == repr
    assert get_repr_function(1, [(lambda x: x == 1, str)]) == str
    assert get_repr_function(2, [(lambda x: x == 1, str)]) == repr
    assert get_repr_function(1, [(lambda x: x == 1, str), (int, str)]) == str
    assert get_repr_function(2, [(lambda x: x == 1, str), (int, str)]) == str
    assert get_repr_function(1.0, [(lambda x: x == 1, str), (int, str)]) == str

# Generated at 2022-06-16 19:31:50.716400
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
        def write(self, s):
            pass


# Generated at 2022-06-16 19:32:00.894142
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1.0, custom_repr=((int, lambda x: 'int'))) == repr
    assert get_repr_function(1.0, custom_repr=((float, lambda x: 'float'))) == 'float'
    assert get_repr_function(1.0, custom_repr=((float, lambda x: 'float'),
                                               (int, lambda x: 'int'))) == 'float'
    assert get_repr_function(1, custom_repr=((float, lambda x: 'float'),
                                             (int, lambda x: 'int'))) == 'int'

# Generated at 2022-06-16 19:32:12.197048
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abc', max_length=2) == "'ab'"
    assert get_shortish_repr('abc', max_length=2, normalize=True) == "'ab'"
    assert get_shortish_repr('abc', max_length=3) == "'abc'"
    assert get_shortish_repr('abc', max_length=3, normalize=True) == "'abc'"
    assert get_shortish_repr('abc', max_length=4) == "'abc'"
    assert get_shortish_repr('abc', max_length=4, normalize=True) == "'abc'"
    assert get_shortish_repr('abc', max_length=5) == "'abc'"
    assert get_shortish

# Generated at 2022-06-16 19:32:19.067702
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def foo(self):
            pass

    assert not issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:27.878361
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.0, custom_repr=((int, str),)) == repr
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str))) == str
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str),
                                               (str, str))) == str
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str),
                                               (str, str), (object, str))) == str

# Generated at 2022-06-16 19:32:31.332670
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:43.396603
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str),
                                 (lambda x: True, str)]) is str

# Generated at 2022-06-16 19:32:50.937430
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10)

# Generated at 2022-06-16 19:32:59.169941
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, []) is repr
    assert get_repr_function(None, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(None, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(None, [(lambda x: False, lambda x: 'hi'),
                                    (lambda x: True, lambda x: 'bye')]) == 'bye'
    assert get_repr_function(None, [(lambda x: False, lambda x: 'hi'),
                                    (lambda x: False, lambda x: 'bye')]) is repr

# Generated at 2022-06-16 19:33:10.265553
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'x')]) == (
        lambda x: 'x'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'x')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'x'),
                                 (lambda x: True, lambda x: 'y')]) == (
        lambda x: 'y'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'x'),
                                 (lambda x: False, lambda x: 'y')]) == repr

# Generated at 2022-06-16 19:33:17.300698
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'



# Generated at 2022-06-16 19:33:26.981610
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:33:37.030371
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:33:45.416253
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 1, str),)) == str
    assert get_repr_function(2, ((lambda x: x == 1, str),)) == repr
    assert get_repr_function(1, ((lambda x: x == 1, str), (int, str))) == str
    assert get_repr_function(2, ((lambda x: x == 1, str), (int, str))) == str



# Generated at 2022-06-16 19:33:55.223468
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def foo(self):
            pass
    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(MyWritableStream, WritableStream)


# Generated at 2022-06-16 19:34:05.408817
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00b\x00') == 'a?b?'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode('a\x00b\x00c\x00') == 'a?b?c?'
    assert shitcode('a\x00b\x00c\x00d') == 'a?b?c?d'
    assert shitcode('a\x00b\x00c\x00d\x00') == 'a?b?c?d?'

# Generated at 2022-06-16 19:34:15.618639
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.0, custom_repr=((int, str),)) == repr
    assert get_repr_function(1.0, custom_repr=((float, str),)) == str
    assert get_repr_function(1.0, custom_repr=((float, str), (int, str))) == str
    assert get_repr_function(1, custom_repr=((float, str), (int, str))) == str
    assert get_repr_function(1, custom_repr=((float, str), (int, str))) == str
    assert get_repr_function(1, custom_repr=((float, str), (int, str))) == str

# Generated at 2022-06-16 19:34:26.255631
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00def') == 'abc?def'
    assert shitcode('abc\x00def\x00') == 'abc?def?'
    assert shitcode('\x00') == '?'
    assert shitcode('\x00\x00') == '??'
    assert shitcode('\x00\x00\x00') == '???'
    assert shitcode('\x00\x00\x00\x00') == '????'
    assert shitcode('\x00\x00\x00\x00\x00') == '?????'
    assert shitcode('\x00\x00\x00\x00\x00\x00') == '??????'
    assert shitcode

# Generated at 2022-06-16 19:34:36.783089
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int'),)) == 'int'
    assert get_repr_function(1.0, ((int, lambda x: 'int'),)) == repr
    assert get_repr_function(1.0, ((float, lambda x: 'float'),)) == 'float'
    assert get_repr_function(1.0, ((float, lambda x: 'float'),
                                   (int, lambda x: 'int'),)) == 'float'
    assert get_repr_function(1.0, ((int, lambda x: 'int'),
                                   (float, lambda x: 'float'),)) == 'float'

# Generated at 2022-06-16 19:34:43.405724
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_text = ''
        def write(self, s):
            self.written_text += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_text == 'hello'



# Generated at 2022-06-16 19:34:48.896111
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass
        write = None
    assert not issubclass(D, WritableStream)



# Generated at 2022-06-16 19:34:51.166418
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:58.697930
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:35:02.305783
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:11.318950
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int'),)) == 'int'
    assert get_repr_function(1.0, ((int, lambda x: 'int'),)) == repr
    assert get_repr_function(1.0, ((float, lambda x: 'float'),)) == 'float'
    assert get_repr_function(1.0, ((float, lambda x: 'float'),
                                   (int, lambda x: 'int'))) == 'float'



# Generated at 2022-06-16 19:35:17.087324
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'



# Generated at 2022-06-16 19:35:29.391273
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass

# Generated at 2022-06-16 19:35:38.038780
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass

    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass

        def write(self, s):
            pass

    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass

        def write(self, s):
            pass

        def foo(self):
            pass


# Generated at 2022-06-16 19:35:49.992876
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00\x00b') == 'a??b'
    assert shitcode('a\x00\x00\x00b') == 'a???b'
    assert shitcode('a\x00\x00\x00\x00b') == 'a????b'
    assert shitcode('a\x00\x00\x00\x00\x00b') == 'a?????b'
    assert shitcode('a\x00\x00\x00\x00\x00\x00b') == 'a??????b'

# Generated at 2022-06-16 19:35:56.258768
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'



# Generated at 2022-06-16 19:35:59.256334
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:07.555461
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:36:09.568613
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:12.959063
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:28.107141
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1.0, [(int, str)]) is repr
    assert get_repr_function(1.0, [(int, str), (float, str)]) is str
    assert get_repr_function(1.0, [(float, str), (int, str)]) is str
    assert get_repr_function(1.0, [(float, str), (int, str), (str, str)]) is str

# Generated at 2022-06-16 19:36:38.909362
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.0, [(int, str)]) == repr
    assert get_repr_function(1.0, [(int, str), (float, str)]) == str
    assert get_repr_function(1.0, [(lambda x: isinstance(x, float), str)]) == str
    assert get_repr_function(1.0, [(lambda x: isinstance(x, int), str)]) == repr
    assert get_repr_function(1.0, [(lambda x: isinstance(x, int), str),
                                   (lambda x: isinstance(x, float), str)]) == str

# Generated at 2022-06-16 19:36:50.406973
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=None, normalize=True) == '1'
    assert get_shortish_repr(1, max_length=None, normalize=False) == '1'
    assert get_shortish_repr(1, max_length=0, normalize=True) == ''

# Generated at 2022-06-16 19:36:58.918913
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:37:11.020557
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10)

# Generated at 2022-06-16 19:37:16.699372
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written_string == 'abc'



# Generated at 2022-06-16 19:37:27.033026
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\xFF') == 'abc?'
    assert shitcode('abc\x01') == 'abc?'
    assert shitcode('abc\x7F') == 'abc?'
    assert shitcode('abc\x80') == 'abc?'
    assert shitcode('abc\x81') == 'abc?'
    assert shitcode('abc\xFE') == 'abc?'
    assert shitcode('abc\xFF') == 'abc?'
    assert shitcode('abc\x00def') == 'abc?def'
    assert shitcode('abc\xFFdef') == 'abc?def'
    assert shitcode('abc\x00\xFF') == 'abc??'

# Generated at 2022-06-16 19:37:32.944327
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = []
        def write(self, s):
            self.written_stuff.append(s)
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hi')
    assert my_writable_stream.written_stuff == ['hi']




# Generated at 2022-06-16 19:37:41.258341
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1, custom_repr=((int, str), (float, int))) == str
    assert get_repr_function(1.0, custom_repr=((int, str), (float, int))) == int
    assert get_repr_function(1.0, custom_repr=((int, str), (float, int))) == int
    assert get_repr_function(1.0, custom_repr=((int, str), (float, int))) == int
    assert get_repr_function(1.0, custom_repr=((int, str), (float, int))) == int

# Generated at 2022-06-16 19:37:52.781681
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == (
        lambda x: 'bye'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')]) == repr

# Generated at 2022-06-16 19:38:01.918258
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'



# Generated at 2022-06-16 19:38:09.390147
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream)

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written == 'abc'

