

# Generated at 2022-06-16 19:28:16.563362
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:28:28.144103
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, [(float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'),
                                   (int, lambda x: 'int')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'),
                                   (int, lambda x: 'int'),
                                   (lambda x: True, lambda x: 'always')]) == \
                                                                          'float'

# Generated at 2022-06-16 19:28:33.063278
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = ''
        def write(self, s):
            self.written_stuff += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_stuff == 'hello'

# Generated at 2022-06-16 19:28:45.402558
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((lambda x: x == 1, str),)) is str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) is repr
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) is str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str))) is str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 3, str))) is str
   

# Generated at 2022-06-16 19:28:52.462691
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, [(float, lambda x: 'float')]) == repr
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int'),
                                 (lambda x: True, lambda x: 'lambda')]) == 'int'
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int'),
                                 (lambda x: False, lambda x: 'lambda')]) == 'int'
    assert get_re

# Generated at 2022-06-16 19:29:04.263074
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode('a\x00b\x00c\x00d') == 'a?b?c?d'
    assert shitcode('a\x00b\x00c\x00d\x00e') == 'a?b?c?d?e'
    assert shitcode('a\x00b\x00c\x00d\x00e\x00f') == 'a?b?c?d?e?f'

# Generated at 2022-06-16 19:29:15.245728
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00def') == 'abc?def'
    assert shitcode('abc\x00\x01\x02def') == 'abc???def'

# Generated at 2022-06-16 19:29:25.743591
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == 'bye'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')])

# Generated at 2022-06-16 19:29:36.842804
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00\x01\x02') == 'abc???'
    assert shitcode('abc\x00\x01\x02\x03') == 'abc???'
    assert shitcode('abc\x00\x01\x02\x03\x04') == 'abc????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05') == 'abc?????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06') == 'abc??????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06\x07') == 'abc???????'

# Generated at 2022-06-16 19:29:48.455251
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is repr
    assert get_repr_function(1, ((int, str), (int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1, ((int, str), (int, lambda x: 'int'),
                                 (int, lambda x: 'int2'))) == 'int'
    assert get_repr_function(1, ((int, lambda x: 'int'), (int, lambda x: 'int2'))) == 'int'
    assert get_repr_function(1, ((int, lambda x: 'int'), (int, lambda x: 'int2'),
                                 (int, lambda x: 'int3'))) == 'int'
    assert get_

# Generated at 2022-06-16 19:29:55.472489
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'

# Generated at 2022-06-16 19:30:07.520416
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:30:14.039882
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_data = ''
        def write(self, s):
            self.written_data += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_data == 'hello'



# Generated at 2022-06-16 19:30:16.798444
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:30:24.539509
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is repr
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((int, str), (str, int), (int, int))) is int
    assert get_repr_function(1, ((int, str), (str, int), (int, int), (int,
                                                                      str))) is str
    assert get_repr_function(1, ((int, str), (str, int), (int, int), (int,
                                                                      str),
                                 (str, str))) is str

# Generated at 2022-06-16 19:30:34.826565
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, ((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(3.5, ((int, lambda x: 'int'))) == repr
    assert get_repr_function(3.5, ((float, lambda x: 'float'))) == 'float'
    assert get_repr_function(3.5, ((float, lambda x: 'float'), (int, lambda x: 'int'))) == 'float'
    assert get_repr_function(3.5, ((int, lambda x: 'int'), (float, lambda x: 'float'))) == 'float'
    assert get_repr_function(3.5, ((lambda x: isinstance(x, int), lambda x: 'int'), (float, lambda x: 'float'))) == 'float'


# Generated at 2022-06-16 19:30:39.615280
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_strings = []
        def write(self, s):
            self.written_strings.append(s)
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_strings == ['hello']



# Generated at 2022-06-16 19:30:41.691968
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:30:54.063484
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, [(float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'),
                                   (int, lambda x: 'int')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'),
                                   (int, lambda x: 'int'),
                                   (lambda x: True, lambda x: 'default')]) == \
                                                                          'float'

# Generated at 2022-06-16 19:31:04.724785
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: True, lambda x: 'one')]) == 'one'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'one')]) == repr
    assert get_repr_function(1, [(int, lambda x: 'one')]) == 'one'
    assert get_repr_function(1, [(str, lambda x: 'one')]) == repr
    assert get_repr_function(1, [(int, lambda x: 'one'),
                                 (str, lambda x: 'two')]) == 'one'
    assert get_repr_function(1, [(str, lambda x: 'one'),
                                 (int, lambda x: 'two')]) == 'two'

# Generated at 2022-06-16 19:31:19.893803
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1, ((lambda x: isinstance(x, int),
                                  lambda x: 'int'))) == 'int'
    assert get_repr_function(1, ((lambda x: False, lambda x: 'int'))) == repr
    assert get_repr_function(1, ((lambda x: False, lambda x: 'int'),
                                 (lambda x: True, lambda x: 'int'))) == 'int'
    assert get_repr_function(1, ((lambda x: False, lambda x: 'int'),
                                 (lambda x: False, lambda x: 'int'))) == repr

# Generated at 2022-06-16 19:31:22.631375
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:30.742846
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == 'bye'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')]) is repr

# Generated at 2022-06-16 19:31:33.964433
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:44.982431
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:31:56.376600
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:31:58.147232
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:04.564004
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:32:08.953800
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'hi')])

# Generated at 2022-06-16 19:32:19.025826
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00\x01') == 'abc??'
    assert shitcode('abc\x00\x01\x02') == 'abc???'
    assert shitcode('abc\x00\x01\x02\x03') == 'abc????'
    assert shitcode('abc\x00\x01\x02\x03\x04') == 'abc?????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05') == 'abc??????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06') == 'abc???????'

# Generated at 2022-06-16 19:32:27.030761
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:39.049805
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(int, str), (str, int)]) is str
    assert get_repr_function(1, [(str, int), (int, str)]) is str
    assert get_repr_function(1, [(str, int)]) is repr
    assert get_repr_function(1, [(lambda x: x == 1, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) is repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) is str

# Generated at 2022-06-16 19:32:44.768382
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:32:54.770098
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10)

# Generated at 2022-06-16 19:33:00.935450
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((str, int), (int, str))) is int
    assert get_repr_function(1, ((lambda x: x == 1, str),)) is str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) is repr
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) is str
    assert get_repr_function(1, ((lambda x: x == 2, str), (str, int))) is int



# Generated at 2022-06-16 19:33:05.016723
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[]) == repr
    assert get_repr_function(1, custom_repr=[(int, str)]) == str
    assert get_repr_function(1, custom_repr=[(lambda x: x == 1, str)]) == str
    assert get_repr_function(1, custom_repr=[(lambda x: x == 2, str)]) == repr
    assert get_repr_function(1, custom_repr=[(lambda x: x == 2, str),
                                             (int, str)]) == str
    assert get_repr_function(1, custom_repr=[(lambda x: x == 2, str),
                                             (int, str),
                                             (lambda x: x == 1, str)]) == str

# Generated at 2022-06-16 19:33:12.486611
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write_again(self, s):
            pass
    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        write_again = None
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        write_

# Generated at 2022-06-16 19:33:22.149579
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=5) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5, normalize=True) == "'hel...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=6, normalize=True) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=7, normalize=True) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_

# Generated at 2022-06-16 19:33:27.935766
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int!'),)) == 'int!'
    assert get_repr_function(1.0, ((int, lambda x: 'int!'),)) == repr
    assert get_repr_function(1, ((lambda x: True, lambda x: 'int!'),)) == 'int!'
    assert get_repr_function(1, ((lambda x: False, lambda x: 'int!'),)) == repr



# Generated at 2022-06-16 19:33:29.750065
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)



# Generated at 2022-06-16 19:33:50.121155
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: True, str), (lambda x: True, int)]) is str
    assert get_repr_function(1, [(lambda x: False, str), (lambda x: True, int)]) is int
    assert get_repr_function(1, [(lambda x: False, str), (lambda x: False, int)]) is repr
    assert get_repr_function(1, [(lambda x: False, str), (lambda x: False, int), (lambda x: True, float)]) is float
    assert get_re

# Generated at 2022-06-16 19:34:02.119911
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((str, int), (int, str))) is str
    assert get_repr_function(1, ((str, int), (int, str), (int, int))) is int
    assert get_repr_function(1, ((str, int), (int, str), (int, int),
                                 (int, lambda x: x))) is int
    assert get_repr_function(1, ((str, int), (int, str), (int, int),
                                 (int, lambda x: x), (int, lambda x: x))) is int

# Generated at 2022-06-16 19:34:14.194327
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E(D): pass
    class F(E): pass
    class G(F): pass
    class H(G): pass
    class I(H): pass
    class J(I): pass
    class K(J): pass
    class L(K): pass
    class M(L): pass
    class N(M): pass
    class O(N): pass
    class P(O): pass
    class Q(P): pass
    class R(Q): pass
    class S(R): pass
    class T(S): pass
    class U(T): pass
    class V(U): pass
    class W(V): pass
    class X(W): pass
    class Y(X): pass

# Generated at 2022-06-16 19:34:23.069989
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 1, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) == repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, lambda x: '1')]) == '1'



# Generated at 2022-06-16 19:34:25.507135
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:33.224673
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
        def bar(self):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
        def bar(self):
            pass


# Generated at 2022-06-16 19:34:38.199325
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'



# Generated at 2022-06-16 19:34:43.344992
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'



# Generated at 2022-06-16 19:34:49.747591
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz') == 'abcdefghijklmnopqrstuvwxyz'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=10) == 'abcdefghij...xyz'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=10, normalize=True) == 'abcdefghij...xyz'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=None, normalize=True) == 'abcdefghijklmnopqrstuvwxyz'

# Generated at 2022-06-16 19:34:57.855682
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'),)) == \
                                                                     'int'
    assert get_repr_function(1.0, custom_repr=((int, lambda x: 'int'),)) == \
                                                                     repr
    assert get_repr_function(1, custom_repr=((float, lambda x: 'float'),)) == \
                                                                     repr
    assert get_repr_function(1.0, custom_repr=((float, lambda x: 'float'),)) == \
                                                                     'float'
    assert get_repr_function(1, custom_repr=((lambda x: x > 0,
                                              lambda x: 'positive'),)) == \
                                                                     'positive'
    assert get_re

# Generated at 2022-06-16 19:35:13.935865
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:35:17.648861
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'

# Generated at 2022-06-16 19:35:29.390075
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream2(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

    assert issubclass(MyWritableStream2, WritableStream)

    class MyWritableStream3(WritableStream):
        def foo(self):
            pass

    assert not issubclass(MyWritableStream3, WritableStream)

    class MyWritableStream4(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

        write = None

    assert not issubclass(MyWritableStream4, WritableStream)

# Generated at 2022-06-16 19:35:35.797819
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream2(WritableStream):
        pass

    assert not issubclass(MyWritableStream2, WritableStream)

    class MyWritableStream3(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

    assert issubclass(MyWritableStream3, WritableStream)



# Generated at 2022-06-16 19:35:48.512781
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.0, [(int, str)]) == repr
    assert get_repr_function(1.0, [(int, str), (float, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (str, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (str, str),
                                   (object, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (str, str),
                                   (object, str), (1, str)]) == str

# Generated at 2022-06-16 19:35:54.992959
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, [(float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'),
                                   (int, lambda x: 'int')]) == 'float'
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int')]) == 'int'

# Generated at 2022-06-16 19:36:04.869881
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00\x01\x02') == 'abc???'
    assert shitcode('abc\x00\x01\x02\x03') == 'abc????'
    assert shitcode('abc\x00\x01\x02\x03\x04') == 'abc?????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05') == 'abc??????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06') == 'abc???????'

# Generated at 2022-06-16 19:36:15.012556
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, [(str, lambda x: 'str')]) != 'str'
    assert get_repr_function(1, [(str, lambda x: 'str')]) == repr
    assert get_repr_function(1, [(int, lambda x: 'int'),
                                 (str, lambda x: 'str')]) == 'int'
    assert get_repr_function(1, [(str, lambda x: 'str'),
                                 (int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, [(str, lambda x: 'str'),
                                 (int, lambda x: 'int')]) == 'int'

# Generated at 2022-06-16 19:36:19.279806
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written_string == 'abc'

# Generated at 2022-06-16 19:36:31.626638
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:36:52.930820
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((str, int), (int, str))) is str
    assert get_repr_function(1, ((str, int), (int, str), (str, int))) is str
    assert get_repr_function(1, ((str, int), (int, str), (str, int),
                                 (int, str))) is str
    assert get_repr_function(1, ((str, int), (int, str), (str, int),
                                 (int, str), (str, int))) is str
    assert get_repr_function

# Generated at 2022-06-16 19:37:01.715210
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1, [(lambda x: x == 1, lambda x: '1')]) == '1'
    assert get_repr_function(2, [(lambda x: x == 1, lambda x: '1')]) == repr



# Generated at 2022-06-16 19:37:04.474098
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:37:10.757792
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'



# Generated at 2022-06-16 19:37:20.675200
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((str, int), (int, str))) is str
    assert get_repr_function(1, ((str, int), (int, str), (int, int))) is int
    assert get_repr_function(1, ((str, int), (int, str), (int, int),
                                 (int, lambda x: str(x)))) is str

# Generated at 2022-06-16 19:37:29.837942
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1.0, [(int, str)]) is repr
    assert get_repr_function(1, [(int, str), (float, str)]) is str
    assert get_repr_function(1.0, [(int, str), (float, str)]) is str
    assert get_repr_function(1.0, [(int, str), (float, str), (str, str)]) is str

# Generated at 2022-06-16 19:37:39.676963
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def foo(self):
            pass
    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)


# Generated at 2022-06-16 19:37:45.859193
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written == 'abc'



# Generated at 2022-06-16 19:37:56.034402
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((str, str),)) == repr
    assert get_repr_function(1, ((lambda x: x == 1, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) == repr
    assert get_repr_function(1, ((lambda x: x == 1, str), (int, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (str, str))) == repr

# Generated at 2022-06-16 19:38:01.953974
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'