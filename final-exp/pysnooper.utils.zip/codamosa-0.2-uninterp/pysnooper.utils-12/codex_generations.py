

# Generated at 2022-06-16 19:28:22.582781
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:28:31.765238
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'x')]) == 'x'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'x')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'x'),
                                 (lambda x: True, lambda x: 'y')]) == 'y'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'x'),
                                 (lambda x: False, lambda x: 'y')]) is repr
    assert get_repr_function(1, [(int, lambda x: 'x')]) == 'x'

# Generated at 2022-06-16 19:28:38.587166
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written_string == 'abc'



# Generated at 2022-06-16 19:28:42.133673
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:28:53.496192
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:28:59.418397
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:29:11.381018
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((int, str), (str, int))) == str
    assert get_repr_function(1, ((str, int), (int, str))) == str
    assert get_repr_function(1, ((str, int), (int, int))) == int
    assert get_repr_function(1, ((str, int), (int, int), (int, str))) == str
    assert get_repr_function(1, ((str, int), (int, int), (int, int))) == int
    assert get_repr_function(1, ((str, int), (int, int), (int, int),
                                 (int, str)))

# Generated at 2022-06-16 19:29:18.824778
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(int, str), (str, int)]) is str
    assert get_repr_function(1, [(str, int), (int, str)]) is str
    assert get_repr_function(1, [(str, int)]) is repr
    assert get_repr_function(1, [(lambda x: x == 1, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) is repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) is str

# Generated at 2022-06-16 19:29:27.929729
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.0, [(int, str)]) == repr
    assert get_repr_function(1.0, [(int, str), (float, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (str, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (str, str),
                                   (object, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str), (str, str),
                                   (object, str), (lambda x: True, str)]) == str

# Generated at 2022-06-16 19:29:38.471284
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:29:52.637667
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\x00\x01\x02') == '???'
    assert shitcode('\x00\x01\x02\x03') == '????'
    assert shitcode('\x00\x01\x02\x03\x04') == '?????'
    assert shitcode('\x00\x01\x02\x03\x04\x05') == '??????'
    assert shitcode('\x00\x01\x02\x03\x04\x05\x06') == '???????'
    assert shitcode('\x00\x01\x02\x03\x04\x05\x06\x07') == '???????'

# Generated at 2022-06-16 19:29:59.562323
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('hello\x00') == 'hello?'
    assert shitcode('hello\x00\x01') == 'hello??'
    assert shitcode('hello\x00\x01\x02') == 'hello???'
    assert shitcode('hello\x00\x01\x02\x03') == 'hello????'
    assert shitcode('hello\x00\x01\x02\x03\x04') == 'hello?????'
    assert shitcode('hello\x00\x01\x02\x03\x04\x05') == 'hello??????'
    assert shitcode('hello\x00\x01\x02\x03\x04\x05\x06') == 'hello???????'

# Generated at 2022-06-16 19:30:08.513965
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.0, [(int, str)]) == repr
    assert get_repr_function(1, [(lambda x: x == 1, str)]) == str
    assert get_repr_function(1.0, [(lambda x: x == 1, str)]) == repr
    assert get_repr_function(1, [(lambda x: x == 1, str), (int, str)]) == str
    assert get_repr_function(1.0, [(lambda x: x == 1, str), (int, str)]) == str



# Generated at 2022-06-16 19:30:19.957772
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('hello\x00') == 'hello?'
    assert shitcode('hello\x00\x01\x02\x03') == 'hello????'
    assert shitcode('hello\x00\x01\x02\x03\x04') == 'hello?????'
    assert shitcode('hello\x00\x01\x02\x03\x04\x05') == 'hello??????'
    assert shitcode('hello\x00\x01\x02\x03\x04\x05\x06') == 'hello???????'
    assert shitcode('hello\x00\x01\x02\x03\x04\x05\x06\x07') == 'hello???????'

# Generated at 2022-06-16 19:30:32.385483
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (int, lambda x: 'int'))) is str
    assert get_repr_function(1, ((int, str), (int, lambda x: 'int'),
                                 (str, lambda x: 'str'))) is str
    assert get_repr_function(1, ((int, str), (int, lambda x: 'int'),
                                 (str, lambda x: 'str'), (str, lambda x: 'str'))) is str

# Generated at 2022-06-16 19:30:41.996353
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:30:50.088363
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_strings = []
        def write(self, s):
            self.written_strings.append(s)

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    my_writable_stream.write('world')
    assert my_writable_stream.written_strings == ['hello', 'world']



# Generated at 2022-06-16 19:31:01.764175
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:31:07.794068
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written_string == 'abc'



# Generated at 2022-06-16 19:31:11.177553
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:27.625202
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(D): pass
    assert get_repr_function(A(), ((A, lambda x: 'A'),))() == 'A'
    assert get_repr_function(B(), ((A, lambda x: 'A'),))() == 'A'
    assert get_repr_function(C(), ((A, lambda x: 'A'),))() == 'A'
    assert get_repr_function(D(), ((A, lambda x: 'A'),))() == 'A'
    assert get_repr_function(E(), ((A, lambda x: 'A'),))() == 'A'
    assert get_repr_function(A(), ((B, lambda x: 'B'),))() == repr

# Generated at 2022-06-16 19:31:39.025419
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int'),)) == 'int'
    assert get_repr_function(1.0, ((int, lambda x: 'int'),)) == repr
    assert get_repr_function(1.0, ((float, lambda x: 'float'),)) == 'float'
    assert get_repr_function(1.0, ((float, lambda x: 'float'),
                                   (int, lambda x: 'int'))) == 'float'
    assert get_repr_function(1.0, ((int, lambda x: 'int'),
                                   (float, lambda x: 'float'))) == 'float'
    assert get_repr_function(1, ((int, lambda x: 'int'),
                                 (float, lambda x: 'float'))) == 'int'
   

# Generated at 2022-06-16 19:31:49.111543
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:31:59.629963
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
        def write(self, s):
            pass


# Generated at 2022-06-16 19:32:02.419942
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:13.384621
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, custom_repr=[(int, lambda x: 'int')]) == repr
    assert get_repr_function(1, custom_repr=[(lambda x: True, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, custom_repr=[(lambda x: True, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, custom_repr=[(lambda x: False, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, custom_repr=[(lambda x: False, lambda x: 'int')]) == repr




# Generated at 2022-06-16 19:32:15.596928
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[(int, str)]) == str
    assert get_repr_function(1.0, custom_repr=[(int, str)]) == repr



# Generated at 2022-06-16 19:32:24.091952
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[]) == repr
    assert get_repr_function(1, custom_repr=[(int, str)]) == str
    assert get_repr_function(1, custom_repr=[(lambda x: x == 2, str)]) == repr
    assert get_repr_function(2, custom_repr=[(lambda x: x == 2, str)]) == str
    assert get_repr_function(2, custom_repr=[(lambda x: x == 2, str),
                                             (lambda x: x == 3, str)]) == str
    assert get_repr_function(3, custom_repr=[(lambda x: x == 2, str),
                                             (lambda x: x == 3, str)]) == str
    assert get_repr

# Generated at 2022-06-16 19:32:30.467658
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_text = ''
        def write(self, s):
            self.written_text += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_text == 'hello'



# Generated at 2022-06-16 19:32:36.410450
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_data = ''
        def write(self, s):
            self.written_data += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_data == 'hello'

# Generated at 2022-06-16 19:32:48.383288
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:32:51.241771
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:53.751621
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:00.534194
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:33:10.851815
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) == repr
    assert get_repr_function(1, [(int, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )
    assert get_repr_function(1, [(str, lambda x: 'hi')]) == repr
    assert get_repr_function(1, [(int, lambda x: 'hi'), (str, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )

# Generated at 2022-06-16 19:33:21.600606
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:33:30.985234
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:33:41.161975
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream)

    class MyWritableStream2(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass

    assert issubclass(MyWritableStream2, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream2)

    class MyWritableStream3(WritableStream):
        def foo(self):
            pass

    assert not issubclass(MyWritableStream3, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream3)


# Generated at 2022-06-16 19:33:51.986624
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    class B(A):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)

    class C(WritableStream):
        pass

    assert not issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass

        def other_method(self):
            pass

    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass

        def write(self, s):
            pass

    assert issubclass(E, WritableStream)


# Generated at 2022-06-16 19:34:03.570918
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:10.762063
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X:
        def write(self, s):
            pass

    assert issubclass(X, WritableStream)



# Generated at 2022-06-16 19:34:13.945267
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:16.238231
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:20.892671
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:28.911443
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode('a\x00b\x00c\x00d') == 'a?b?c?d'
    assert shitcode('a\x00b\x00c\x00d\x00e') == 'a?b?c?d?e'
    assert shitcode('a\x00b\x00c\x00d\x00e\x00f') == 'a?b?c?d?e?f'

# Generated at 2022-06-16 19:34:31.599101
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:41.863559
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00\x00b') == 'a??b'
    assert shitcode('a\x00\x00\x00b') == 'a???b'
    assert shitcode('a\x00\x00\x00\x00b') == 'a????b'
    assert shitcode('a\x00\x00\x00\x00\x00b') == 'a?????b'
    assert shitcode('a\x00\x00\x00\x00\x00\x00b') == 'a??????b'

# Generated at 2022-06-16 19:34:46.444274
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = []
        def write(self, s):
            self.written_stuff.append(s)

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    my_writable_stream.write('world')
    assert my_writable_stream.written_stuff == ['hello', 'world']



# Generated at 2022-06-16 19:34:55.355264
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hello')]) == 'hello'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hello')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hello'),
                                 (lambda x: True, lambda x: 'world')]) == 'world'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hello'),
                                 (lambda x: False, lambda x: 'world')]) is repr

# Generated at 2022-06-16 19:35:06.924238
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1, ((str, lambda x: 'str'))) == repr
    assert get_repr_function(1, ((str, lambda x: 'str'), (int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1, ((str, lambda x: 'str'), (int, lambda x: 'int'), (float, lambda x: 'float'))) == 'int'
    assert get_repr_function(1.0, ((str, lambda x: 'str'), (int, lambda x: 'int'), (float, lambda x: 'float'))) == 'float'

# Generated at 2022-06-16 19:35:32.834413
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((lambda x: True, lambda x: 'hello'))) == 'hello'
    assert get_repr_function(1, ((lambda x: False, lambda x: 'hello'))) is repr
    assert get_repr_function(1, ((lambda x: True, lambda x: 'hello'),
                                 (lambda x: True, lambda x: 'world'))) == 'hello'
    assert get_repr_function(1, ((lambda x: False, lambda x: 'hello'),
                                 (lambda x: True, lambda x: 'world'))) == 'world'

# Generated at 2022-06-16 19:35:37.152182
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str),
                                 (lambda x: True, str)]) is str

# Generated at 2022-06-16 19:35:49.330925
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == 'bye'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')]) is repr

# Generated at 2022-06-16 19:35:52.439945
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:55.396168
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:58.423501
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:01.612271
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:10.173553
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass

    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass

    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
        write = None

    assert not issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
        write = None

# Generated at 2022-06-16 19:36:17.013530
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 1, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) == repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) == str



# Generated at 2022-06-16 19:36:19.232857
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:43.498088
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'

# Generated at 2022-06-16 19:36:53.854902
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: '1')]) == (
        lambda x: '1'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: '1')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'),
                                 (lambda x: True, lambda x: '2')]) == (
        lambda x: '2'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'),
                                 (lambda x: False, lambda x: '2')]) == repr



# Generated at 2022-06-16 19:37:05.640989
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 1, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) == repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 3, str)])

# Generated at 2022-06-16 19:37:16.081342
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        write = None
    assert not issubclass(E, WritableStream)


# Generated at 2022-06-16 19:37:18.678525
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:37:22.804979
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written_string == 'abc'



# Generated at 2022-06-16 19:37:27.736740
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'



# Generated at 2022-06-16 19:37:37.951264
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''

    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(123, max_length=3) == '123'
    assert get_shortish_repr(1234, max_length=3) == '123...'


# Generated at 2022-06-16 19:37:49.825512
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:38:01.073946
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((lambda x: x == 1, str),)) is str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) is repr
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) is str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str))) is str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 3, str))) is str
   