

# Generated at 2022-06-16 19:28:29.825184
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=3, normalize=True) == "'he...'"
    assert get_shortish_repr('hello', max_length=4, normalize=True) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5, normalize=True) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6, normalize=True) == "'hello'"
    assert get_shortish_repr('hello', max_length=7, normalize=True) == "'hello'"

# Generated at 2022-06-16 19:28:42.231922
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, lambda x: 'int'))) == (lambda x: 'int')
    assert get_repr_function(1, ((int, lambda x: 'int'), (str, lambda x: 'str'))) == (lambda x: 'int')
    assert get_repr_function('1', ((int, lambda x: 'int'), (str, lambda x: 'str'))) == (lambda x: 'str')
    assert get_repr_function(1, ((str, lambda x: 'str'), (int, lambda x: 'int'))) == (lambda x: 'int')

# Generated at 2022-06-16 19:28:53.495301
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((lambda x: x == 1, str),)) is str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) is repr
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) is str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str))) is str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 3, str))) is str
   

# Generated at 2022-06-16 19:29:04.584444
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:29:12.917122
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, [(str, lambda x: 'str')]) != 'str'
    assert get_repr_function(1, [(lambda x: isinstance(x, int),
                                  lambda x: 'int')]) == 'int'
    assert get_repr_function(1, [(lambda x: isinstance(x, str),
                                  lambda x: 'str')]) != 'str'



# Generated at 2022-06-16 19:29:24.448600
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'

# Generated at 2022-06-16 19:29:35.303975
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, custom_repr=[(int, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, custom_repr=[(float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, custom_repr=[(float, lambda x: 'float'),
                                               (int, lambda x: 'int')]) == 'float'
    assert get_repr_function(1, custom_repr=[(float, lambda x: 'float'),
                                             (int, lambda x: 'int')]) == 'int'

# Generated at 2022-06-16 19:29:42.190872
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:29:53.065968
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00\x01b') == 'a??b'

# Generated at 2022-06-16 19:29:59.811077
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'),
                                             (str, lambda x: 'str'))) == 'int'
    assert get_repr_function('1', custom_repr=((int, lambda x: 'int'),
                                               (str, lambda x: 'str'))) == 'str'
    assert get_repr_function(1, custom_repr=((str, lambda x: 'str'),
                                             (int, lambda x: 'int'))) == 'int'

# Generated at 2022-06-16 19:30:14.241501
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10)

# Generated at 2022-06-16 19:30:23.301154
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:30:34.153957
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:30:42.821537
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: True, lambda x: 'one')]) == 'one'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'one')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'one'),
                                 (lambda x: True, lambda x: 'two')]) == 'two'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'one'),
                                 (lambda x: False, lambda x: 'two')]) == repr

# Generated at 2022-06-16 19:30:54.567297
# Unit test for function get_repr_function

# Generated at 2022-06-16 19:31:05.086780
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(int, str), (str, int)]) is str
    assert get_repr_function(1, [(str, int)]) is repr
    assert get_repr_function(1, [(lambda x: x == 1, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) is repr
    assert get_repr_function(1, [(lambda x: x == 1, str), (lambda x: x == 2,
                                                           int)]) is str

# Generated at 2022-06-16 19:31:12.391313
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_strings = []
        def write(self, s):
            self.written_strings.append(s)

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    my_writable_stream.write('world')
    assert my_writable_stream.written_strings == ['hello', 'world']



# Generated at 2022-06-16 19:31:15.008437
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:16.232133
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyStream, WritableStream)



# Generated at 2022-06-16 19:31:27.543298
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\x00\x01\x02') == '???'

# Generated at 2022-06-16 19:31:41.443318
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00\x01') == 'abc??'
    assert shitcode('abc\x00\x01\x02') == 'abc???'
    assert shitcode('abc\x00\x01\x02\x03') == 'abc????'
    assert shitcode('abc\x00\x01\x02\x03\x04') == 'abc?????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05') == 'abc??????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06') == 'abc???????'

# Generated at 2022-06-16 19:31:50.398629
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:32:00.723964
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'hi')]) is repr

# Generated at 2022-06-16 19:32:11.957153
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:32:14.868109
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = []
        def write(self, s):
            self.written_stuff.append(s)
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_stuff == ['hello']



# Generated at 2022-06-16 19:32:23.699198
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:32:35.665871
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'),)) == \
                                                                      'int'
    assert get_repr_function(1, custom_repr=((str, lambda x: 'str'),)) == \
                                                                      repr
    assert get_repr_function(1, custom_repr=((str, lambda x: 'str'),
                                             (int, lambda x: 'int'))) == \
                                                                      'int'
    assert get_repr_function(1, custom_repr=((str, lambda x: 'str'),
                                             (int, lambda x: 'int'),
                                             (float, lambda x: 'float'))) == \
                                                                      'int'

# Generated at 2022-06-16 19:32:38.311684
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:48.246564
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)
    assert issubclass(A, collections_abc.Iterable)
    assert not issubclass(A, collections_abc.Iterator)
    assert not issubclass(A, collections_abc.Container)
    assert not issubclass(A, collections_abc.Sized)
    assert not issubclass(A, collections_abc.Callable)
    assert not issubclass(A, collections_abc.Hashable)
    assert not issubclass(A, collections_abc.Sequence)
    assert not issubclass(A, collections_abc.Mapping)
    assert not issubclass(A, collections_abc.MutableSequence)

# Generated at 2022-06-16 19:32:57.528633
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10)

# Generated at 2022-06-16 19:33:10.823024
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'hi2')]) == 'hi2'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'hi2')]) is repr

# Generated at 2022-06-16 19:33:21.603105
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00\x01') == 'abc??'
    assert shitcode('abc\x00\x01\x02') == 'abc???'
    assert shitcode('abc\x00\x01\x02\x03') == 'abc????'
    assert shitcode('abc\x00\x01\x02\x03\x04') == 'abc?????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05') == 'abc??????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06') == 'abc???????'

# Generated at 2022-06-16 19:33:30.984499
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[]) == repr

# Generated at 2022-06-16 19:33:41.105751
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(WritableStream):
        def write(self, s):
            pass

    assert issubclass(B, WritableStream)

    class C(A, B):
        pass

    assert issubclass(C, WritableStream)

    class D(A):
        pass

    assert issubclass(D, WritableStream)

    class E(A):
        def write(self, s):
            pass

    assert issubclass(E, WritableStream)

    class F(A):
        def write(self, s):
            pass

    assert issubclass(F, WritableStream)

    class G(A):
        def write(self, s):
            pass



# Generated at 2022-06-16 19:33:44.165346
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:47.874965
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:55.113452
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:05.311492
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode('a\x00b\x00c\x00') == 'a?b?c?'
    assert shitcode('\x00a\x00b\x00c\x00') == '?a?b?c?'
    assert shitcode('\x00a\x00b\x00c\x00d\x00') == '?a?b?c?d?'
    assert shitcode('\x00a\x00b\x00c\x00d\x00e\x00') == '?a?b?c?d?e?'

# Generated at 2022-06-16 19:34:15.550435
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C(A): pass
    class D(C): pass
    class E(D): pass
    class F(D): pass
    class G(F): pass
    class H(G): pass
    class I(H): pass
    class J(I): pass
    class K(J): pass
    class L(K): pass
    class M(L): pass
    class N(M): pass
    class O(N): pass
    class P(O): pass
    class Q(P): pass
    class R(Q): pass
    class S(R): pass
    class T(S): pass
    class U(T): pass
    class V(U): pass
    class W(V): pass
    class X(W): pass
    class Y(X): pass

# Generated at 2022-06-16 19:34:20.493713
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.0, custom_repr=((int, str),)) == repr
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str))) == str
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str),
                                               (object, str))) == str
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str),
                                               (object, str), (str, str))) == str

# Generated at 2022-06-16 19:34:25.396439
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:32.861193
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == '1'
    assert get_shortish_repr(1, max_length=-2) == '1'
    assert get_shortish_repr(1, max_length=-3) == '1'

# Generated at 2022-06-16 19:34:42.827920
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:34:45.820814
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:54.890456
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, []) is repr
    assert get_repr_function(None, [(lambda x: True, lambda x: 'hi')])() == 'hi'
    assert get_repr_function(None, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(None, [(lambda x: False, lambda x: 'hi'),
                                    (lambda x: True, lambda x: 'bye')])() == 'bye'
    assert get_repr_function(None, [(lambda x: False, lambda x: 'hi'),
                                    (lambda x: False, lambda x: 'bye')]) is repr

# Generated at 2022-06-16 19:35:06.530382
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\x00') == '?'
    assert shitcode('\x01') == '?'
    assert shitcode('\x02') == '?'
    assert shitcode('\x03') == '?'
    assert shitcode('\x04') == '?'
    assert shitcode('\x05') == '?'
    assert shitcode('\x06') == '?'
    assert shitcode('\x07') == '?'
    assert shitcode('\x08') == '?'
    assert shitcode('\t') == '?'
    assert shitcode('\n') == '?'
    assert shitcode('\x0b') == '?'
    assert shitcode('\x0c') == '?'
    assert shitcode('\r') == '?'

# Generated at 2022-06-16 19:35:16.853408
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def foo(self):
            pass

    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
        write = None

    assert not issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:23.478055
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:35:32.782171
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=5) == "'he...'"
    assert get_shortish_repr('hello', max_length=5, normalize=True) == "'he...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=6, normalize=True) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=7, normalize=True) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_

# Generated at 2022-06-16 19:35:33.696086
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:50.367869
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:36:02.054922
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:36:04.600129
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:11.997461
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass

# Generated at 2022-06-16 19:36:20.190217
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'a')]) == 'a'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'a')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'a'),
                                 (lambda x: True, lambda x: 'b')]) == 'b'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'a'),
                                 (lambda x: False, lambda x: 'b')]) is repr
    assert get_repr_function(1, [(int, lambda x: 'a')]) == 'a'

# Generated at 2022-06-16 19:36:31.857096
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, str)]) == str
    assert get_repr_function(1, [(lambda x: False, str)]) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(float, str)]) == repr
    assert get_repr_function(1.0, [(float, str)]) == str
    assert get_repr_function(1.0, [(float, str), (int, str)]) == str
    assert get_repr_function(1, [(float, str), (int, str)]) == str

# Generated at 2022-06-16 19:36:35.315123
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:43.095312
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1, [(lambda x: True, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'int')]) != 'int'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'int'),
                                 (lambda x: True, lambda x: 'int')]) == 'int'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'int'),
                                 (lambda x: False, lambda x: 'int')]) != 'int'

# Generated at 2022-06-16 19:36:51.709344
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00def') == 'abc?def'
    assert shitcode('abc\x00def\x01') == 'abc?def?'
    assert shitcode('abc\x00def\x01\x7f') == 'abc?def??'
    assert shitcode('abc\x00def\x01\x7f\x80') == 'abc?def???'
    assert shitcode('abc\x00def\x01\x7f\x80\xff') == 'abc?def????'




# Generated at 2022-06-16 19:36:58.360738
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, ((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(3.5, ((int, lambda x: 'int'))) == repr
    assert get_repr_function(3.5, ((float, lambda x: 'float'))) == 'float'
    assert get_repr_function(3.5, ((float, lambda x: 'float'),
                                   (int, lambda x: 'int'))) == 'float'
    assert get_repr_function(3, ((float, lambda x: 'float'),
                                 (int, lambda x: 'int'))) == 'int'

# Generated at 2022-06-16 19:37:11.951089
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    class B(WritableStream):
        def write(self, s):
            pass

    class C(B):
        pass

    class D(B):
        def write(self, s):
            pass

    class E(B):
        def write(self, s):
            pass

    class F(B):
        def write(self, s):
            pass

    class G(B):
        def write(self, s):
            pass

    class H(B):
        def write(self, s):
            pass

    class I(B):
        def write(self, s):
            pass

    class J(B):
        def write(self, s):
            pass


# Generated at 2022-06-16 19:37:21.561171
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hello')]) == 'hello'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hello')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hello'),
                                 (lambda x: True, lambda x: 'world')]) == 'world'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hello'),
                                 (lambda x: False, lambda x: 'world')]) is repr

# Generated at 2022-06-16 19:37:30.401201
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == 'bye'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')]) is repr
    assert get_repr_function(1, [(int, lambda x: 'hi')]) == 'hi'

# Generated at 2022-06-16 19:37:33.222395
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:37:38.312017
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 1, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) == repr



# Generated at 2022-06-16 19:37:50.073516
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:38:01.253137
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream2(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

    assert issubclass(MyWritableStream2, WritableStream)

    class MyWritableStream3(WritableStream):
        def write_again(self, s):
            pass

    assert not issubclass(MyWritableStream3, WritableStream)

    class MyWritableStream4(WritableStream):
        def write(self, s):
            pass

        def write(self, s):
            pass

    assert issubclass(MyWritableStream4, WritableStream)


# Generated at 2022-06-16 19:38:05.063343
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:38:10.230056
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 1, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) is repr

