

# Generated at 2022-06-16 19:28:28.294694
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:28:39.895264
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:28:49.874490
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:28:56.507674
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = ''
        def write(self, s):
            self.written_stuff += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hi')
    assert my_writable_stream.written_stuff == 'hi'

# Generated at 2022-06-16 19:29:08.507359
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(int, str), (lambda x: True, str)]) is str
    assert get_repr_function(1, [(int, str), (lambda x: False, str)]) is str
    assert get_repr_function(1, [(int, str), (lambda x: True, str),
                                 (lambda x: False, str)]) is str

# Generated at 2022-06-16 19:29:17.374678
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:29:27.403157
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(int, str), (str, int)]) is str
    assert get_repr_function('1', [(int, str), (str, int)]) is int
    assert get_repr_function('1', [(int, str), (str, int), (str, str)]) is str
    assert get_repr_function('1', [(int, str), (str, int), (str, str),
                                   (str, lambda x: x + '!')]) == '1!'

# Generated at 2022-06-16 19:29:30.112804
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:29:39.790761
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1.0, custom_repr=((int, lambda x: 'int'))) == repr
    assert get_repr_function(1.0, custom_repr=((float, lambda x: 'float'))) == 'float'
    assert get_repr_function(1.0, custom_repr=((float, lambda x: 'float'),
                                               (int, lambda x: 'int'))) == 'float'
    assert get_repr_function(1, custom_repr=((float, lambda x: 'float'),
                                             (int, lambda x: 'int'))) == 'int'

# Generated at 2022-06-16 19:29:43.195215
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:29:55.529696
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
        def write(self, s):
            pass


# Generated at 2022-06-16 19:30:00.460752
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream)



# Generated at 2022-06-16 19:30:05.598961
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10)

# Generated at 2022-06-16 19:30:17.341287
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, str)]) == str
    assert get_repr_function(1, [(lambda x: False, str)]) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(float, str)]) == repr
    assert get_repr_function(1.0, [(float, str)]) == str
    assert get_repr_function(1.0, [(float, str), (int, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, str)]) == str

# Generated at 2022-06-16 19:30:23.703675
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 1, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) == repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) == str



# Generated at 2022-06-16 19:30:34.391317
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'

    assert get_shortish_repr(1, max_length=1, normalize=True) == '1'
    assert get_shortish_repr(1, max_length=0, normalize=True) == ''
    assert get_shortish_repr(1, max_length=None, normalize=True) == '1'


# Generated at 2022-06-16 19:30:45.263217
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: True, lambda x: '1')]) == '1'
    assert get_repr_function(1, [(lambda x: False, lambda x: '1')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'),
                                 (lambda x: True, lambda x: '2')]) == '2'
    assert get_repr_function(1, [(lambda x: True, lambda x: '1'),
                                 (lambda x: True, lambda x: '2')]) == '1'
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'),
                                 (lambda x: False, lambda x: '2')]) == repr

# Generated at 2022-06-16 19:30:56.571970
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'

# Generated at 2022-06-16 19:31:05.861778
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(int, str), (str, int)]) is str
    assert get_repr_function(1, [(str, int)]) is repr
    assert get_repr_function(1, [(lambda x: x == 1, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) is repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) is str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str),
                                 (str, int)]) is str


# Generated at 2022-06-16 19:31:17.830454
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=3, normalize=True) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=4, normalize=True) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=5, normalize=True) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"


# Generated at 2022-06-16 19:31:30.305173
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00\x01\x02b') == 'a???b'
    assert shitcode('a\x00\x01\x02b\x00\x01\x02') == 'a???????'
    assert shitcode('a\x00\x01\x02b\x00\x01\x02c') == 'a??????c'
    assert shitcode('a\x00\x01\x02b\x00\x01\x02c\x00\x01\x02') == 'a??????c??????'



# Generated at 2022-06-16 19:31:36.059708
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hi')
    assert my_writable_stream.written == 'hi'



# Generated at 2022-06-16 19:31:41.739992
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = []
        def write(self, s):
            self.written_stuff.append(s)

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_stuff == ['hello']



# Generated at 2022-06-16 19:31:50.547976
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(D): pass

    assert get_repr_function(A(), []) is repr
    assert get_repr_function(B(), []) is repr
    assert get_repr_function(C(), []) is repr
    assert get_repr_function(D(), []) is repr
    assert get_repr_function(E(), []) is repr

    assert get_repr_function(A(), [(A, lambda x: 'A')]) is repr
    assert get_repr_function(B(), [(A, lambda x: 'A')]) is repr
    assert get_repr_function(C(), [(A, lambda x: 'A')]) is repr
    assert get_repr_

# Generated at 2022-06-16 19:32:00.791583
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == \
                                                                    (lambda x: 'hi')
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == \
                                                                    (lambda x: 'hi')
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == \
                                                                    (lambda x: 'bye')

# Generated at 2022-06-16 19:32:12.054911
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_

# Generated at 2022-06-16 19:32:21.571575
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:32:27.784619
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('hello\n') == 'hello\n'
    assert shitcode('hello\r') == 'hello\r'
    assert shitcode('hello\r\n') == 'hello\r\n'
    assert shitcode('hello\n\r') == 'hello\n\r'
    assert shitcode('hello\r\n\r\n') == 'hello\r\n\r\n'

# Generated at 2022-06-16 19:32:39.993301
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'

    assert get_shortish_repr(123456789, max_length=1) == '...'

# Generated at 2022-06-16 19:32:49.211051
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int'),)) == 'int'
    assert get_repr_function(1.0, ((int, lambda x: 'int'),)) == repr
    assert get_repr_function(1.0, ((float, lambda x: 'float'),)) == 'float'
    assert get_repr_function(1.0, ((float, lambda x: 'float'),
                                   (int, lambda x: 'int'))) == 'float'
    assert get_repr_function(1.0, ((int, lambda x: 'int'),
                                   (float, lambda x: 'float'))) == 'float'
    assert get_repr_function(1, ((int, lambda x: 'int'),
                                 (float, lambda x: 'float'))) == 'int'
   

# Generated at 2022-06-16 19:33:00.736288
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, str)]) == str
    assert get_repr_function(1, [(lambda x: False, str)]) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.0, [(int, str)]) == repr
    assert get_repr_function(1.0, [(float, str)]) == str
    assert get_repr_function(1.0, [(float, str), (int, str)]) == str
    assert get_repr_function(1, [(float, str), (int, str)]) == str

# Generated at 2022-06-16 19:33:10.850672
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: '1')]) == '1'
    assert get_repr_function(1, [(lambda x: False, lambda x: '1')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'),
                                 (lambda x: True, lambda x: '2')]) == '2'
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'),
                                 (lambda x: False, lambda x: '2')]) is repr

# Generated at 2022-06-16 19:33:14.381790
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:22.897044
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1.0, custom_repr=((int, lambda x: 'int'))) == repr
    assert get_repr_function(1.0, custom_repr=((float, lambda x: 'float'))) == 'float'
    assert get_repr_function(1.0, custom_repr=((float, lambda x: 'float'),
                                               (int, lambda x: 'int'))) == 'float'
    assert get_repr_function(1, custom_repr=((float, lambda x: 'float'),
                                             (int, lambda x: 'int'))) == 'int'

# Generated at 2022-06-16 19:33:31.392355
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'a')]) == 'a'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'a')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'a'),
                                 (lambda x: True, lambda x: 'b')]) == 'b'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'a'),
                                 (lambda x: False, lambda x: 'b')]) is repr

# Generated at 2022-06-16 19:33:36.505046
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
        def write(self, s):
            pass


# Generated at 2022-06-16 19:33:48.285261
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: True, lambda x: 'one')]) == 'one'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'one')]) == repr
    assert get_repr_function(1, [(int, lambda x: 'one')]) == 'one'
    assert get_repr_function(1, [(float, lambda x: 'one')]) == repr
    assert get_repr_function(1, [(int, lambda x: 'one'), (float, lambda x: 'two')]) == 'one'
    assert get_repr_function(1.0, [(int, lambda x: 'one'), (float, lambda x: 'two')]) == 'two'

# Generated at 2022-06-16 19:33:55.307287
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str),
                                 (lambda x: True, str)]) is str

# Generated at 2022-06-16 19:34:05.438873
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:15.649984
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == (
        lambda x: 'bye'
    )

# Generated at 2022-06-16 19:34:36.653727
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.0, custom_repr=((int, str),)) == repr
    assert get_repr_function(1, custom_repr=((float, str),)) == repr
    assert get_repr_function(1.0, custom_repr=((float, str),)) == str
    assert get_repr_function(1, custom_repr=((lambda x: x == 1, str),)) == str
    assert get_repr_function(1.0, custom_repr=((lambda x: x == 1, str),)) == \
                                                                        repr

# Generated at 2022-06-16 19:34:46.455885
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream)
    assert not issubclass(object, MyWritableStream)
    assert not issubclass(object, WritableStream)
    assert not issubclass(MyWritableStream, object)
    assert not issubclass(WritableStream, object)

    class MyWritableStream2(WritableStream):
        pass
    assert not issubclass(MyWritableStream2, WritableStream)



# Generated at 2022-06-16 19:34:48.050311
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:56.553380
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((lambda x: True, lambda x: 'hi'))) == 'hi'
    assert get_repr_function(1, ((lambda x: False, lambda x: 'hi'))) is repr
    assert get_repr_function(1, ((lambda x: True, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'hi'))) == 'hi'
    assert get_repr_function(1, ((lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'hi'))) == 'hi'

# Generated at 2022-06-16 19:35:08.286082
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((lambda x: x == 1, lambda x: '1'))) == (
        lambda x: '1'
    )
    assert get_repr_function(1, ((lambda x: x == 2, lambda x: '2'))) == repr
    assert get_repr_function(1, ((int, lambda x: 'int'))) == (
        lambda x: 'int'
    )
    assert get_repr_function(1, ((str, lambda x: 'str'))) == repr
    assert get_repr_function(1, ((int, lambda x: 'int'), (str, lambda x: 'str'))) == (
        lambda x: 'int'
    )

# Generated at 2022-06-16 19:35:18.445888
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=5) == "'he...'"
    assert get_shortish_repr('hello', max_length=5, normalize=True) == "'he...'"
    assert get_shortish_repr('hello', max_length=5, normalize=True) == "'he...'"
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=5, normalize=True) == '1'
    assert get_shortish_repr(1, max_length=5, normalize=True) == '1'
    assert get_

# Generated at 2022-06-16 19:35:30.354215
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((lambda x: True, lambda x: 'hi'))) == \
                                                                     (lambda x: 'hi')
    assert get_repr_function(1, ((lambda x: False, lambda x: 'hi'))) == repr
    assert get_repr_function(1, ((int, lambda x: 'hi'))) == (lambda x: 'hi')
    assert get_repr_function(1.0, ((int, lambda x: 'hi'))) == repr
    assert get_repr_function(1, ((int, lambda x: 'hi'), (float, lambda x: 'hi'))) == \
                                                                     (lambda x: 'hi')

# Generated at 2022-06-16 19:35:38.513109
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:35:48.131747
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream2(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

    assert issubclass(MyWritableStream2, WritableStream)

    class MyWritableStream3(WritableStream):
        def write_again(self, s):
            pass

    assert not issubclass(MyWritableStream3, WritableStream)



# Generated at 2022-06-16 19:35:54.785859
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:36:39.672008
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
        def write(self, s):
            pass


# Generated at 2022-06-16 19:36:50.778850
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'abc\u1234') == u'abc?'
    assert shitcode(u'abc\u1234\u5678') == u'abc??'
    assert shitcode(u'abc\u1234\u5678\u9abc') == u'abc???'
    assert shitcode(u'abc\u1234\u5678\u9abc\udef0') == u'abc????'
    assert shitcode(u'abc\u1234\u5678\u9abc\udef0\u1234') == u'abc?????'
    assert shitcode(u'abc\u1234\u5678\u9abc\udef0\u1234\u5678') == u'abc??????'
    assert shitcode

# Generated at 2022-06-16 19:36:52.122182
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:58.581859
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, str)]) == str
    assert get_repr_function(1, [(lambda x: False, str)]) == repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: True, str)]) == str
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str)]) == repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str),
                                 (lambda x: True, str)]) == str

# Generated at 2022-06-16 19:37:02.181438
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(MyWritableStream(), WritableStream)



# Generated at 2022-06-16 19:37:13.515790
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) is repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'hi')]) == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'hi')]) is repr

# Generated at 2022-06-16 19:37:22.480636
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:37:25.038777
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:37:37.508713
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(D): pass

    assert get_repr_function(A(), []) == repr
    assert get_repr_function(B(), []) == repr
    assert get_repr_function(C(), []) == repr
    assert get_repr_function(D(), []) == repr
    assert get_repr_function(E(), []) == repr


# Generated at 2022-06-16 19:37:43.217672
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((int, str), (str, int), (int, int))) is int
    assert get_repr_function(1, ((int, str), (str, int), (int, int),
                                 (int, lambda x: x + 1))) is int
    assert get_repr_function(1, ((int, str), (str, int), (int, int),
                                 (int, lambda x: x + 1), (int, lambda x: x))) \
                                                                          is int

# Generated at 2022-06-16 19:38:05.968492
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:38:15.281630
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10)