

# Generated at 2022-06-16 19:28:29.601481
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream2(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream2, WritableStream)

    class MyWritableStream3(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream3, WritableStream)

    class MyWritableStream4(WritableStream):
        pass

    assert not issubclass(MyWritableStream4, WritableStream)

    class MyWritableStream5(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream5, WritableStream)

# Generated at 2022-06-16 19:28:41.771429
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: '1')]) == (
        lambda x: '1'
    )
    assert get_repr_function(1, [(int, lambda x: '1')]) == (
        lambda x: '1'
    )
    assert get_repr_function(1, [(int, lambda x: '1'), (lambda x: True, lambda x: '2')]) == (
        lambda x: '1'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: '1'), (lambda x: True, lambda x: '2')]) == (
        lambda x: '2'
    )

# Generated at 2022-06-16 19:28:53.496189
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:28:56.510877
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 1, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) == repr



# Generated at 2022-06-16 19:29:08.555863
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, ()) is repr
    assert get_repr_function(3, ((int, str),)) is str
    assert get_repr_function(3, ((lambda x: x == 3, str),)) is str
    assert get_repr_function(3, ((lambda x: x == 4, str),)) is repr
    assert get_repr_function(3, ((lambda x: x == 4, str), (int, str))) is str
    assert get_repr_function(3, ((lambda x: x == 4, str), (int, str),
                                 (lambda x: x == 3, str))) is str
    assert get_repr_function(3, ((lambda x: x == 4, str), (int, str),
                                 (lambda x: x == 4, str))) is str




# Generated at 2022-06-16 19:29:17.405667
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:29:27.435629
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
        def write(self, s):
            pass


# Generated at 2022-06-16 19:29:38.012858
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((str, int), (int, str))) is str
    assert get_repr_function(1, ((str, int), (int, str), (str, str))) is str
    assert get_repr_function(1, ((str, int), (int, str), (str, str),
                                 (int, int))) is int
    assert get_repr_function(1, ((str, int), (int, str), (str, str),
                                 (int, int), (int, str))) is str
    assert get_repr_function

# Generated at 2022-06-16 19:29:50.071927
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:29:52.547817
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:30:07.040464
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass

    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass

    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write2(self, s):
            pass
        def write3(self, s):
            pass

    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass

# Generated at 2022-06-16 19:30:18.778609
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int'),)) == 'int'
    assert get_repr_function(1.0, ((int, lambda x: 'int'),)) == repr
    assert get_repr_function(1.0, ((float, lambda x: 'float'),)) == 'float'
    assert get_repr_function(1.0, ((float, lambda x: 'float'),
                                   (int, lambda x: 'int'))) == 'float'
    assert get_repr_function(1.0, ((int, lambda x: 'int'),
                                   (float, lambda x: 'float'))) == 'float'

# Generated at 2022-06-16 19:30:31.192972
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is repr
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((int, str), (str, int), (int, int))) is int
    assert get_repr_function(1, ((int, str), (str, int), (int, int), (int, str))) is str
    assert get_repr_function(1, ((int, str), (str, int), (int, int), (int, str), (int, int))) is int

# Generated at 2022-06-16 19:30:35.359724
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    MyWritableStream.write('hi')



# Generated at 2022-06-16 19:30:43.424179
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, str)]) is str
    assert get_repr_function(1, [(int, str), (int, repr)]) is str
    assert get_repr_function(1, [(int, str), (float, repr)]) is str
    assert get_repr_function(1.0, [(int, str), (float, repr)]) is repr
    assert get_repr_function(1.0, [(int, str), (float, str)]) is str
    assert get_repr_function(1.0, [(int, str), (float, str), (float, repr)]) \
                                                                       is str

# Generated at 2022-06-16 19:30:44.761474
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:30:50.991914
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 1, str),)) == str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) == repr
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 1, str))) == str
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str),
                                 (lambda x: x == 3, str))) == str
   

# Generated at 2022-06-16 19:31:02.586453
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B:
        pass

    assert not issubclass(B, WritableStream)

    class C:
        def write(self, s):
            pass

        def write_again(self, s):
            pass

    assert issubclass(C, WritableStream)

    class D:
        def write(self, s):
            pass

        def write_again(self, s):
            pass

        def write(self, s):
            pass

    assert issubclass(D, WritableStream)

    class E:
        def write(self, s):
            pass

        def write_again(self, s):
            pass

        def write(self, s):
            pass


# Generated at 2022-06-16 19:31:14.813511
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'

# Generated at 2022-06-16 19:31:21.221135
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'



# Generated at 2022-06-16 19:31:25.498412
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:32.183843
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode('a\x00b\x00c\x00') == 'a?b?c?'
    assert shitcode('\x00a\x00b\x00c\x00') == '?a?b?c?'
    assert shitcode('\x00a\x00b\x00c\x00d') == '?a?b?c?d'
    assert shitcode('\x00a\x00b\x00c\x00d\x00') == '?a?b?c?d?'

# Generated at 2022-06-16 19:31:43.939038
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:31:46.280935
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:57.756291
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:32:00.032875
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:11.274466
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:32:20.971893
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x01') == 'abc?'
    assert shitcode('abc\x02') == 'abc?'
    assert shitcode('abc\x03') == 'abc?'
    assert shitcode('abc\x04') == 'abc?'
    assert shitcode('abc\x05') == 'abc?'
    assert shitcode('abc\x06') == 'abc?'
    assert shitcode('abc\x07') == 'abc?'
    assert shitcode('abc\x08') == 'abc?'
    assert shitcode('abc\x09') == 'abc?'
    assert shitcode('abc\x0a') == 'abc?'
    assert shitcode('abc\x0b') == 'abc?'

# Generated at 2022-06-16 19:32:31.750829
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10)

# Generated at 2022-06-16 19:32:43.753125
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:32:48.831920
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:57.972179
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((int, str), (str, int), (int, int))) is int
    assert get_repr_function(1, ((int, str), (str, int), (int, int), (int, str))) is str
    assert get_repr_function(1, ((int, str), (str, int), (int, int), (int, str), (str, str))) is str

# Generated at 2022-06-16 19:33:02.865476
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'one')]) == 'one'
    assert get_repr_function(1.0, [(int, lambda x: 'one')]) == repr



# Generated at 2022-06-16 19:33:09.349478
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=5) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5, normalize=True) == "'hel...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=6, normalize=True) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=7, normalize=True) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_

# Generated at 2022-06-16 19:33:20.576813
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00\x01\x02') == 'abc???'
    assert shitcode('abc\x00\x01\x02\x03') == 'abc????'
    assert shitcode('abc\x00\x01\x02\x03\x04') == 'abc?????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05') == 'abc??????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06') == 'abc???????'

# Generated at 2022-06-16 19:33:30.050829
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.0, custom_repr=((int, str),)) == repr
    assert get_repr_function(1.0, custom_repr=((float, str),)) == str
    assert get_repr_function(1.0, custom_repr=((float, str), (int, str))) == str
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str))) == str
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str),
                                               (float, str))) == str

# Generated at 2022-06-16 19:33:40.206401
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\x00') == '?'
    assert shitcode('\x01') == '?'
    assert shitcode('\x02') == '?'
    assert shitcode('\x03') == '?'
    assert shitcode('\x04') == '?'
    assert shitcode('\x05') == '?'
    assert shitcode('\x06') == '?'
    assert shitcode('\x07') == '?'
    assert shitcode('\x08') == '?'
    assert shitcode('\x09') == '?'
    assert shitcode('\x0a') == '?'
    assert shitcode('\x0b') == '?'
    assert shitcode('\x0c') == '?'
    assert shitcode('\x0d') == '?'
   

# Generated at 2022-06-16 19:33:51.332482
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:03.091622
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((str, int), (int, str))) is str
    assert get_repr_function(1, ((str, int), (int, str), (str, str))) is str
    assert get_repr_function(1, ((str, int), (int, str), (str, str),
                                 (str, int))) is int
    assert get_repr_function(1, ((str, int), (int, str), (str, str),
                                 (str, int), (int, int))) is int
    assert get_repr_function

# Generated at 2022-06-16 19:34:14.345623
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, custom_repr=[(int, lambda x: 'int')]) == repr
    assert get_repr_function(1, custom_repr=[(int, lambda x: 'int'),
                                             (float, lambda x: 'float')]) == 'int'
    assert get_repr_function(1.0, custom_repr=[(int, lambda x: 'int'),
                                               (float, lambda x: 'float')]) == 'float'

# Generated at 2022-06-16 19:34:20.260155
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:28.565994
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:32.914512
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s
    stream = MyWritableStream()
    stream.write('hello')
    assert stream.written == 'hello'



# Generated at 2022-06-16 19:34:42.867625
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:47.934186
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written == 'abc'

# Generated at 2022-06-16 19:34:56.480765
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:34:59.405870
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:10.670184
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'),)) == 'int'
    assert get_repr_function(1.0, custom_repr=((int, lambda x: 'int'),)) == repr
    assert get_repr_function(1, custom_repr=((float, lambda x: 'float'),)) == repr
    assert get_repr_function(1.0, custom_repr=((float, lambda x: 'float'),)) == 'float'
    assert get_repr_function(1, custom_repr=((float, lambda x: 'float'),
                                             (int, lambda x: 'int'))) == 'int'

# Generated at 2022-06-16 19:35:20.192852
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:35:31.063982
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)
    assert issubclass(A, WritableStream)
    assert issubclass(A, WritableStream)
    assert issubclass(A, WritableStream)
    assert issubclass(A, WritableStream)
    assert issubclass(A, WritableStream)
    assert issubclass(A, WritableStream)
    assert issubclass(A, WritableStream)
    assert issubclass(A, WritableStream)
    assert issubclass(A, WritableStream)
    assert issubclass(A, WritableStream)
    assert issubclass(A, WritableStream)
    assert issubclass(A, WritableStream)

# Generated at 2022-06-16 19:35:40.662690
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:35:51.140005
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00def') == 'abc?def'
    assert shitcode('abc\x00\x01\x02\x03') == 'abc????'
    assert shitcode('abc\x00\x01\x02\x03def') == 'abc????def'
    assert shitcode('abc\x00\x01\x02\x03def\x04\x05\x06\x07') == 'abc????def????'
    assert shitcode('abc\x00\x01\x02\x03def\x04\x05\x06\x07ghi') == 'abc????def????ghi'



# Generated at 2022-06-16 19:36:02.480642
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:36:10.819337
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: False, str),
                                 (lambda x: False, str),
                                 (lambda x: True, str)]) is str

# Generated at 2022-06-16 19:36:19.718004
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:36:31.816423
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == '1'
    assert get_shortish_repr(1, max_length=-2) == '1'

# Generated at 2022-06-16 19:36:41.507586
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:36:43.633413
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:54.474373
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:37:06.029363
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'

# Generated at 2022-06-16 19:37:21.384885
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:37:26.517052
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'



# Generated at 2022-06-16 19:37:37.790708
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('hello\n') == 'hello\n'
    assert shitcode('hello\r') == 'hello\r'
    assert shitcode('hello\r\n') == 'hello\r\n'
    assert shitcode('hello\r\n\r\n') == 'hello\r\n\r\n'
    assert shitcode('hello\r\n\r\n\r\n') == 'hello\r\n\r\n\r\n'
    assert shitcode('hello\r\n\r\n\r\n\r\n') == 'hello\r\n\r\n\r\n\r\n'
    assert shitcode('hello\r\n\r\n\r\n\r\n\r\n')

# Generated at 2022-06-16 19:37:43.455315
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('ab\xc3\xa9') == 'ab?'
    assert shitcode('ab\xc3\xa9'.decode('utf8')) == 'ab?'
    assert shitcode('ab\xc3\xa9'.decode('utf8').encode('latin1')) == 'ab?'
    assert shitcode('ab\xc3\xa9'.decode('utf8').encode('latin1').decode('utf8')) == 'ab?'
    assert shitcode('ab\xc3\xa9'.decode('utf8').encode('latin1').decode('utf8').encode('latin1')) == 'ab?'

# Generated at 2022-06-16 19:37:54.490451
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''

    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_

# Generated at 2022-06-16 19:37:58.884463
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream)



# Generated at 2022-06-16 19:38:08.062687
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == (
        lambda x: 'bye'
    )



# Generated at 2022-06-16 19:38:16.384193
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10)