

# Generated at 2022-06-16 19:28:24.096179
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (int, int))) is int
    assert get_repr_function(1, ((int, str), (int, int), (int, float))) is float

# Generated at 2022-06-16 19:28:26.712909
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:28:29.185287
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:28:41.026088
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:28:50.132835
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, str)]) == str
    assert get_repr_function(1, [(lambda x: False, str)]) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(int, str), (lambda x: True, str)]) == str
    assert get_repr_function(1, [(int, str), (lambda x: False, str)]) == str
    assert get_repr_function(1, [(int, str), (lambda x: True, str),
                                 (lambda x: False, str)]) == str

# Generated at 2022-06-16 19:28:59.011330
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'

    assert issubclass(MyWritableStream, WritableStream)
    assert isinstance(my_writable_stream, WritableStream)



# Generated at 2022-06-16 19:29:10.858691
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00\x01\x02b') == 'a???b'
    assert shitcode('a\x00\x01\x02b\xFF') == 'a???b?'
    assert shitcode('a\x00\x01\x02b\xFF\xFE\xFD') == 'a???b???'
    assert shitcode('a\x00\x01\x02b\xFF\xFE\xFD\x00') == 'a???b????'
    assert shitcode('a\x00\x01\x02b\xFF\xFE\xFD\x00\x01') == 'a???b?????'

# Generated at 2022-06-16 19:29:18.630975
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, [(float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'),
                                   (int, lambda x: 'int')]) == 'float'
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int')]) == 'int'

# Generated at 2022-06-16 19:29:27.819477
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: True, lambda x: 'one')]) == 'one'
    assert get_repr_function(1, [(lambda x: False, lambda x: 'one')]) == repr
    assert get_repr_function(1, [(int, lambda x: 'one')]) == 'one'
    assert get_repr_function(1, [(float, lambda x: 'one')]) == repr
    assert get_repr_function(1, [(int, lambda x: 'one'),
                                 (float, lambda x: 'two')]) == 'one'
    assert get_repr_function(1.0, [(int, lambda x: 'one'),
                                   (float, lambda x: 'two')]) == 'two'

# Generated at 2022-06-16 19:29:38.358629
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (int, lambda x: '1'))) is str
    assert get_repr_function(1, ((int, str), (int, lambda x: '1'),
                                 (int, lambda x: '2'))) is str
    assert get_repr_function(1, ((int, str), (int, lambda x: '1'),
                                 (int, lambda x: '2'), (int, lambda x: '3'))) \
                                                                          is str

# Generated at 2022-06-16 19:29:52.812054
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    class B(A):
        pass

    class C(B):
        def write(self, s):
            pass

    class D(C):
        pass

    class E(D):
        def write(self, s):
            pass

    class F(E):
        pass

    class G(F):
        def write(self, s):
            pass

    class H(G):
        pass

    class I(H):
        def write(self, s):
            pass

    class J(I):
        pass

    class K(J):
        def write(self, s):
            pass

    class L(K):
        pass

    class M(L):
        def write(self, s):
            pass


# Generated at 2022-06-16 19:29:59.666953
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr('hello', max_length=3) == 'hel'
    assert get_shortish_repr('hello', max_length=4) == 'hell'
    assert get_shortish_repr('hello', max_length=5) == 'hello'
    assert get_shortish_repr('hello', max_length=6) == 'hello'
    assert get_shortish_repr('hello', max_length=7) == 'hello'
    assert get_shortish_repr('hello', max_length=8) == 'hello'
    assert get_shortish_repr('hello', max_length=9) == 'hello'

# Generated at 2022-06-16 19:30:10.178466
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyStream, WritableStream)
    assert isinstance(MyStream(), WritableStream)
    assert not issubclass(int, WritableStream)
    assert not issubclass(list, WritableStream)
    assert not issubclass(dict, WritableStream)
    assert not issubclass(str, WritableStream)
    assert not issubclass(bytes, WritableStream)
    assert not issubclass(tuple, WritableStream)
    assert not issubclass(set, WritableStream)
    assert not issubclass(frozenset, WritableStream)
    assert not issubclass(object, WritableStream)
    assert not issubclass(type, WritableStream)
    assert not issubclass

# Generated at 2022-06-16 19:30:21.329452
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == \
                                                                   (lambda x: 'hi')
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'hi')]) == \
                                                                   (lambda x: 'hi')
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'hi')]) == repr

# Generated at 2022-06-16 19:30:33.272353
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:30:36.451491
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:30:44.030989
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, str)]) == str
    assert get_repr_function(1, [(lambda x: False, str)]) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(float, str)]) == repr
    assert get_repr_function(1.0, [(float, str)]) == str
    assert get_repr_function(1.0, [(float, str), (int, str)]) == str
    assert get_repr_function(1, [(float, str), (int, str)]) == str

# Generated at 2022-06-16 19:30:55.321179
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:31:05.415889
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:31:08.351986
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:31:23.363548
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)
    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)
    class C(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(C, WritableStream)
    class D(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
        def bar(self):
            pass
    assert issubclass(D, WritableStream)
    class E(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
        def bar(self):
            pass


# Generated at 2022-06-16 19:31:31.139393
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass

    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

        def write(self, s):
            pass

    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass


# Generated at 2022-06-16 19:31:37.527454
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_text = ''
        def write(self, s):
            self.written_text += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    assert my_writable_stream.written_text == 'abc'



# Generated at 2022-06-16 19:31:47.639154
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')]) == (
        lambda x: 'hi'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: True, lambda x: 'bye')]) == (
        lambda x: 'bye'
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: 'hi'),
                                 (lambda x: False, lambda x: 'bye')]) == repr

# Generated at 2022-06-16 19:31:58.696940
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(1.0, ((int, lambda x: 'int'))) == repr
    assert get_repr_function(1, ((int, lambda x: 'int'), (float, lambda x: 'float'))) == 'int'
    assert get_repr_function(1.0, ((int, lambda x: 'int'), (float, lambda x: 'float'))) == 'float'
    assert get_repr_function(1.0, ((int, lambda x: 'int'), (float, lambda x: 'float'), (lambda x: True, lambda x: 'true'))) == 'float'

# Generated at 2022-06-16 19:32:01.835876
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:07.788924
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'



# Generated at 2022-06-16 19:32:10.419614
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:32:20.264643
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'),)) == \
                                                                      'int'
    assert get_repr_function(1.0, custom_repr=((int, lambda x: 'int'),)) == \
                                                                      repr
    assert get_repr_function(1, custom_repr=((float, lambda x: 'float'),)) == \
                                                                      repr
    assert get_repr_function(1.0, custom_repr=((float, lambda x: 'float'),)) \
                                                                      == 'float'
    assert get_repr_function(1, custom_repr=((float, lambda x: 'float'),
                                             (int, lambda x: 'int'))) == 'int'
    assert get_repr_

# Generated at 2022-06-16 19:32:26.996258
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\x00') == '?'
    assert shitcode('\x01') == '?'
    assert shitcode('\x02') == '?'
    assert shitcode('\x03') == '?'
    assert shitcode('\x04') == '?'
    assert shitcode('\x05') == '?'
    assert shitcode('\x06') == '?'
    assert shitcode('\x07') == '?'
    assert shitcode('\x08') == '?'
    assert shitcode('\t') == '?'
    assert shitcode('\n') == '?'
    assert shitcode('\x0b') == '?'
    assert shitcode('\x0c') == '?'
    assert shitcode('\r') == '?'

# Generated at 2022-06-16 19:32:45.194392
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=-2) == ''
    assert get_shortish_repr(1, max_length=-3) == ''
    assert get_shortish_repr(1, max_length=-4) == ''
    assert get_shortish_re

# Generated at 2022-06-16 19:32:49.898906
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_text = ''
        def write(self, s):
            self.written_text += s
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_text == 'hello'



# Generated at 2022-06-16 19:32:58.764104
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x01') == 'abc?'
    assert shitcode('abc\x02') == 'abc?'
    assert shitcode('abc\x03') == 'abc?'
    assert shitcode('abc\x04') == 'abc?'
    assert shitcode('abc\x05') == 'abc?'
    assert shitcode('abc\x06') == 'abc?'
    assert shitcode('abc\x07') == 'abc?'
    assert shitcode('abc\x08') == 'abc?'
    assert shitcode('abc\x09') == 'abc?'
    assert shitcode('abc\x0a') == 'abc?'
    assert shitcode('abc\x0b') == 'abc?'

# Generated at 2022-06-16 19:33:09.873679
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:33:21.042950
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr('hello', max_length=2) == 'he...'
    assert get_shortish_repr('hello', max_length=3) == 'hel...'
    assert get_shortish_repr('hello', max_length=4) == 'hell...'
    assert get_shortish_repr('hello', max_length=5) == 'hello'
    assert get_shortish_repr('hello', max_length=6) == 'hello'
    assert get_shortish_repr('hello', max_length=7) == 'hello'
    assert get_shortish_repr('hello', max_length=8) == 'hello'
    assert get_shortish_repr('hello', max_length=9)

# Generated at 2022-06-16 19:33:30.495589
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) != 'int'
    assert get_repr_function(1.0, [(int, lambda x: 'int')]) == repr
    assert get_repr_function(1.0, [(float, lambda x: 'float')]) == 'float'
    assert get_repr_function(1.0, [(float, lambda x: 'float'),
                                   (int, lambda x: 'int')]) == 'float'
    assert get_repr_function(1, [(float, lambda x: 'float'),
                                 (int, lambda x: 'int')]) == 'int'

# Generated at 2022-06-16 19:33:32.870442
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:33:43.760481
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 1, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str)]) == repr
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) == str
    assert get_repr_function(1, [(lambda x: x == 2, str), (int, str)]) == str

# Generated at 2022-06-16 19:33:47.011857
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert isinstance(A(), WritableStream)

# Generated at 2022-06-16 19:33:49.428706
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:14.080569
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(WritableStream):
        pass
    assert not issubclass(B, WritableStream)

    class C(WritableStream):
        def write(self, s):
            pass
        def write_again(self, s):
            pass
    assert issubclass(C, WritableStream)

    class D(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(WritableStream):
        def write(self, s):
            pass
        def write(self, s):
            pass
        def write(self, s):
            pass


# Generated at 2022-06-16 19:34:24.938357
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def foo(self):
            pass
    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(MyWritableStream, WritableStream)


# Generated at 2022-06-16 19:34:28.599161
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:29.793561
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)



# Generated at 2022-06-16 19:34:39.281397
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def write(self, s):
            pass
    assert issubclass(Foo, WritableStream)

    class Bar(Foo):
        pass
    assert issubclass(Bar, WritableStream)

    class Baz(Bar):
        def write(self, s):
            pass
    assert issubclass(Baz, WritableStream)

    class Qux(Baz):
        pass
    assert issubclass(Qux, WritableStream)

    class Quux(Qux):
        pass
    assert issubclass(Quux, WritableStream)

    class Corge(WritableStream):
        pass
    assert not issubclass(Corge, WritableStream)

    class Grault(Corge):
        pass
    assert not issubclass(Grault, WritableStream)



# Generated at 2022-06-16 19:34:42.822405
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:48.512864
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is str
    assert get_repr_function(1, ((int, str), (str, int))) is str
    assert get_repr_function(1, ((str, int), (int, str))) is int
    assert get_repr_function(1, ((lambda x: x == 1, str),)) is str
    assert get_repr_function(1, ((lambda x: x == 2, str),)) is repr
    assert get_repr_function(1, ((lambda x: x == 2, str), (int, str))) is str



# Generated at 2022-06-16 19:34:50.008814
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:34:58.046964
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: 'int'),)) == \
                                                                      'int'
    assert get_repr_function(1.0, custom_repr=((int, lambda x: 'int'),)) == \
                                                                      repr
    assert get_repr_function(1.0, custom_repr=((float, lambda x: 'float'),)) \
                                                                      == 'float'
    assert get_repr_function(1.0, custom_repr=((float, lambda x: 'float'),
                                               (int, lambda x: 'int'),)) \
                                                                      == 'float'

# Generated at 2022-06-16 19:35:03.048651
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(int, WritableStream)
    assert not issubclass(WritableStream, int)



# Generated at 2022-06-16 19:35:30.986934
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:38.933029
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def foo(self):
            pass
    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert issubclass(MyWritableStream, WritableStream)


# Generated at 2022-06-16 19:35:46.137256
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_string == 'hello'



# Generated at 2022-06-16 19:35:48.696856
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:35:55.075336
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) is repr
    assert get_repr_function(None, ((lambda x: True, lambda x: 'hi'))) == 'hi'
    assert get_repr_function(None, ((lambda x: False, lambda x: 'hi'))) is repr
    assert get_repr_function(None, ((lambda x: False, lambda x: 'hi'),
                                    (lambda x: True, lambda x: 'bye'))) == 'bye'
    assert get_repr_function(None, ((lambda x: False, lambda x: 'hi'),
                                    (lambda x: False, lambda x: 'bye'))) is repr

# Generated at 2022-06-16 19:36:03.052461
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

        def write_again(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write_again(self, s):
            pass

    assert not issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:36:11.164220
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
    assert get_shortish_repr('hello', max_length=6) == "'hello'"
    assert get_shortish_repr('hello', max_length=7) == "'hello'"
    assert get_shortish_repr('hello', max_length=8) == "'hello'"
    assert get_shortish_repr('hello', max_length=9) == "'hello'"
    assert get_shortish_repr('hello', max_length=10)

# Generated at 2022-06-16 19:36:19.777981
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\x00\x01\x02') == '???'

# Generated at 2022-06-16 19:36:23.592551
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    MyWritableStream().write('abc')



# Generated at 2022-06-16 19:36:35.219520
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'
    assert get_shortish_repr(1, max_length=7) == '1'

# Generated at 2022-06-16 19:37:33.348279
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[(int, str)]) == str
    assert get_repr_function(1.0, custom_repr=[(int, str)]) == repr
    assert get_repr_function(1, custom_repr=[(lambda x: x == 1, str)]) == str
    assert get_repr_function(2, custom_repr=[(lambda x: x == 1, str)]) == repr



# Generated at 2022-06-16 19:37:36.325356
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:37:38.620841
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:37:50.495927
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.0, custom_repr=((int, str),)) == repr
    assert get_repr_function(1.0, custom_repr=((int, str), (float, str))) == str
    assert get_repr_function(1.0, custom_repr=((float, str), (int, str))) == str
    assert get_repr_function(1.0, custom_repr=((float, str), (int, str),
                                               (float, str))) == str
    assert get_repr_function(1.0, custom_repr=((float, str), (int, str),
                                               (float, str), (float, str))) == str


# Generated at 2022-06-16 19:37:53.454734
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-16 19:38:03.097515
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-1) == '1'
    assert get_shortish_repr(1, max_length=-2) == '1'
    assert get_shortish_repr(1, max_length=-3) == '1'

# Generated at 2022-06-16 19:38:08.788305
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written == 'hello'

