

# Generated at 2022-06-20 12:38:16.744563
# Unit test for constructor of class WritableStream
def test_WritableStream():
    try:
        class MyClass(WritableStream):
            def write(self, s):
                pass
                print(s)
        MyClass()
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-20 12:38:20.423872
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(42, []) == repr
    assert get_repr_function(42, [(int, str)]) == str
    assert get_repr_function(42, [(str, str)]) == repr
    assert get_repr_function('42', [(str, str)]) == str
    assert get_repr_function('42', [(str, str), (int, str)]) == str
    assert get_repr_function('42', [(int, str), (str, str)]) == str



# Generated at 2022-06-20 12:38:26.578777
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('a\r\n') == 'a\r\n'

    # The following test works on Linux, but not on Windows.
    # This is because \x00 is not a valid unicode character,
    # and it's read as a different character in Linux and Windows.
    if sys.platform.startswith('win'):
        assert shitcode('\x00') == '\x00'
    # else:
    #     assert shitcode('\x00') == '?'

# Generated at 2022-06-20 12:38:37.470418
# Unit test for function normalize_repr
def test_normalize_repr():

    class X:
        pass

    assert normalize_repr('asdf') == 'asdf'
    assert normalize_repr('hey') == 'hey'
    assert normalize_repr('') == ''

    assert normalize_repr('asdf at 0x1234') == 'asdf'
    assert normalize_repr('hey at 0x1234') == 'hey'
    assert normalize_repr(' at 0x1234') == ''

    assert normalize_repr('asdf at 0x1234 at 0x4321') == 'asdf at 0x4321'
    assert normalize_repr('hey at 0x1234 at 0x4321') == 'hey at 0x4321'

# Generated at 2022-06-20 12:38:41.048067
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('spam') == 'spam'
    assert normalize_repr('eggs at 0x100') == 'eggs'
    assert normalize_repr('spam at 0x1234') == 'spam'



# Generated at 2022-06-20 12:38:43.450753
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(object):
        def write(self, s): pass
    assert issubclass(Foo, WritableStream)



# Generated at 2022-06-20 12:38:47.338312
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def __init__(self):
            self.storage = ''
        def write(self, s):
            self.storage += s

    a = A()
    a.write('hello')
    assert a.storage == 'hello'



# Generated at 2022-06-20 12:38:51.739825
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from weakref import ref
    class W(WritableStream):
        def __init__(self):
            self._s = ''
            self._refs = []
        def write(self, s):
            self._s += s
            self._refs.append(ref(s))
    w = W()
    assert isinstance(w, WritableStream)
    assert isinstance(w, W)
    w.write('spam')
    assert w._s == 'spam'
    assert [x() for x in w._refs] == [None] * 3
    w.write('eggs')
    assert w._s == 'spameggs'
    assert [x() for x in w._refs] == [None] * 6

# Generated at 2022-06-20 12:38:54.954228
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(None) == (None,)



# Generated at 2022-06-20 12:39:04.092890
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'אבג') == u'אבג'
    assert shitcode(u'אבГ') == u'אבГ'
    assert shitcode(u'אב\xee') == u'אב?'
    assert shitcode(u'אב\x01\x02\x03\x04\x05') == u'אב?????'
    assert shitcode(u'abc\x01\x02\x03\x04\x05') == u'abc?????'
    assert shitcode(u'אב\x01\x02\x03\x04\x05def') == u'אב?????def'



# Generated at 2022-06-20 12:39:14.418858
# Unit test for function normalize_repr
def test_normalize_repr():
    import sys
    assert normalize_repr(sys.version) == sys.version
    if sys.platform == 'win32':
        assert normalize_repr(repr(b'')) == repr(b'')
    else:
        assert normalize_repr(repr(b'')) == r"b''"
    assert normalize_repr(repr([1, 2, 3])) == repr([1, 2, 3])

# Generated at 2022-06-20 12:39:15.945448
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("baaz at 0x4d0") == "baaz"

# Generated at 2022-06-20 12:39:26.394204
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(()) == tuple()
    assert ensure_tuple(2) == (2,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple([1, 2]) != (1, 2)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple('abc') != ('abc',)
    assert ensure_tuple(set([1, 2])) == (1, 2)
    assert ensure_tuple(set([1, 2])) != (1, 2)
    class X(object):
        def __iter__(self):
            yield 1
            yield 2
    assert ensure_tuple(X()) == (1, 2)

# Generated at 2022-06-20 12:39:33.631400
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class C(object):
        def __init__(self):
            self.name = 'C'
        def __repr__(self):
            return self.name

    assert get_shortish_repr(C()) == 'C'
    assert get_shortish_repr(C(), max_length=2) == 'C'
    assert get_shortish_repr(C(), max_length=1) == 'C'
    assert get_shortish_repr(C(), max_length=0) == 'C'
    assert get_shortish_repr(C(), max_length=-1) == 'C'
    assert get_shortish_repr(C(), max_length=None) == 'C'

    class D(object):
        def __init__(self):
            self.name = 'D'
       

# Generated at 2022-06-20 12:39:36.089273
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class WritableTest(WritableStream):

        def write(self, s):
            self._log.append(s)

    writable_test = WritableTest()
    writable_test._log = []
    writable_test.write('testing')
    assert writable_test._log == ['testing']



# Generated at 2022-06-20 12:39:46.352413
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MockWritableStream(WritableStream):
        def __init__(self, *args, **kwargs):
            self.written = []
        def write(self, s):
            self.written.append(s)

    assert issubclass(MockWritableStream, WritableStream)

    mock_writable_stream = MockWritableStream()

    assert isinstance(mock_writable_stream, WritableStream)

    mock_writable_stream.write('hello')
    mock_writable_stream.write('world')

    assert mock_writable_stream.written == ['hello', 'world']

    class MockWritableStream2(WritableStream):
        def __init__(self):
            self.written = []

    assert issubclass(MockWritableStream2, WritableStream)
    assert not isinstance

# Generated at 2022-06-20 12:39:50.466737
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(range(10)) == tuple(range(10))

# Generated at 2022-06-20 12:39:58.264667
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnopqrstuvwxyz', None) == \
                                             'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 30) == \
                                             'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 1) == '...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 2) == '...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 3) == '...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 4) == 'a...'


# Generated at 2022-06-20 12:40:00.780696
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass
    assert isinstance(A(), WritableStream)



# Generated at 2022-06-20 12:40:03.903632
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream:
        def write(self, s):
            pass

    my_writable_stream = MyWritableStream()
    assert isinstance(my_writable_stream, WritableStream)



# Generated at 2022-06-20 12:40:11.970667
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .legacy_tools.tests.test_misc_tools import assert_equal, assert_raises
    import io
    class X(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s
    x = X()
    x.write('happy')
    assert_equal(x.s, 'happy')
    assert_raises(TypeError, x.write, 5)

# Generated at 2022-06-20 12:40:16.615232
# Unit test for function truncate
def test_truncate():
    assert truncate(u'12345', 5) == u'12345'
    assert truncate(u'12345', 10) == u'12345'
    assert truncate(u'12345', 4) == u'1...5'
    assert truncate(u'12345', 3) == u'1...'
    assert truncate('12345', 3) == u'1...'
    assert truncate('12345', 6) == u'12345'
    assert truncate('12345', 7) == u'12345'
    assert truncate('12345', 8) == u'12345'



# Generated at 2022-06-20 12:40:18.210903
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('בְּ') == '??'

# Generated at 2022-06-20 12:40:22.165440
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(('abc',)) == ('abc',)
    assert ensure_tuple(123) == (123,)
    assert ensure_tuple([123]) == (123,)



# Generated at 2022-06-20 12:40:24.599558
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Stream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(Stream, WritableStream)


# Generated at 2022-06-20 12:40:27.660420
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import io
    class X(WritableStream):
        def write(self, s):
            pass

    assert issubclass(X, WritableStream)
    assert not issubclass(io.StringIO, WritableStream)

# Generated at 2022-06-20 12:40:36.497646
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('a' * 100) == "'{}'".format('a' * 100)
    assert get_shortish_repr('a' * 100, max_length=12) == \
        "'{}...'".format('a' * 7)

    assert get_shortish_repr(set([1, 2, 3]), max_length=12) == \
        '{1, 2, 3}'
    assert get_shortish_repr(set([1, 2, 3]), max_length=10) == \
        '{1, 2, ...}'


# Generated at 2022-06-20 12:40:37.923915
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamTest(WritableStream):
        def write(self, s):
            pass
    WritableStreamTest()

# Generated at 2022-06-20 12:40:43.991187
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', 8) == '1234567890'
    assert truncate('1234567890', 9) == '12345...890'
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('1234567890', 11) == '1234567890'
    assert truncate('1234567890', None) == '1234567890'
    assert truncate('1234567890', 0) == ''
    assert truncate('1234567890', -1) == ''
    assert truncate('1234567890', -3) == ''

# Generated at 2022-06-20 12:40:52.942183
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    string = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    shortish_repr = get_shortish_repr(string, max_length=None)
    assert shortish_repr == string
    shortish_repr = get_shortish_repr(string, max_length=10)
    assert shortish_repr == 'ABCDEFGHIJ...XYZ'
    shortish_repr = get_shortish_repr(string, max_length=11)
    assert shortish_repr == 'ABCDEFGHIJK...Z'
    shortish_repr = get_shortish_repr(string, max_length=25)
    assert shortish_repr == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    shortish_repr = get_short

# Generated at 2022-06-20 12:41:04.208145
# Unit test for function truncate
def test_truncate():
    assert truncate(string='abc',               max_length=3) == 'abc'
    assert truncate(string='abcd',              max_length=3) == 'a...'
    assert truncate(string='abcdef',            max_length=3) == 'a...'
    assert truncate(string='abcdef',            max_length=4) == 'a...'
    assert truncate(string='abcdefg',           max_length=4) == 'a...'
    assert truncate(string='abcdefgh',          max_length=4) == 'a...'
    assert truncate(string='abcdefgh',          max_length=5) == 'ab...'
    assert truncate(string='abcdefghij',        max_length=5) == 'ab...'

# Generated at 2022-06-20 12:41:14.472085
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'רם') == '????'
    assert shitcode(u'רם'.encode('utf-8')) == '????'
    assert shitcode(u'חיים') == '????'
    assert shitcode(u'חיים'.encode('utf-8')) == '????'
    assert shitcode(u'אבי') == '????'
    assert shitcode(u'אבי'.encode('utf-8')) == '????'
    assert shitcode('חיים') == '????'
    assert shitcode(u'בר הצ')[-1] == '?'
    assert shitcode(u'בר הצ'.encode('utf-8'))[-1] == '?'

# Generated at 2022-06-20 12:41:25.835217
# Unit test for function truncate
def test_truncate():
    assert truncate('', None) == ''
    assert truncate('', 1) == ''
    assert truncate('', 0) == ''
    assert truncate('', -1) == ''
    assert truncate('x', None) == 'x'
    assert truncate('x', 1) == 'x'
    assert truncate('x', 0) == ''
    assert truncate('x', -1) == ''
    assert truncate('xx', None) == 'xx'
    assert truncate('xx', 1) == 'x'
    assert truncate('xx', 0) == ''
    assert truncate('xx', -1) == ''
    assert truncate('xxx', None) == 'xxx'
    assert truncate('xxx', 1) == 'x'
    assert truncate('xxx', 2) == 'x'

# Generated at 2022-06-20 12:41:28.821299
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdef', 10) == 'abcdef'
    assert truncate('abcdef', 6) == 'abcdef'
    assert truncate('abcdef', 5) == 'ab...'
    assert truncate('abcdef', 4) == 'a...'
    assert truncate('abcdef', 1) == '...'
    assert truncate('abcdef', 0) == '...'



# Generated at 2022-06-20 12:41:34.546880
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple('hello') == ('hello',)

# Generated at 2022-06-20 12:41:36.092369
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Obj:
        def write(self, s):
            pass

    assert isinstance(Obj(), WritableStream)

# Generated at 2022-06-20 12:41:38.568185
# Unit test for function normalize_repr
def test_normalize_repr():
    result = normalize_repr(object().__repr__())
    assert result[:78] == '[object object] at 0x'
    assert result[-1] == '>'


# Generated at 2022-06-20 12:41:41.689108
# Unit test for function normalize_repr
def test_normalize_repr():
    assert (
        normalize_repr('A at 0x7fe55112be60 [id=1]') ==
        'A at 0x[a-f0-9A-F]{7} [id=1]'
    )



# Generated at 2022-06-20 12:41:45.767685
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            return s
    assert issubclass(MyWritableStream, WritableStream)
    m = MyWritableStream()
    assert m.write('hello') == 'hello'



JYTHON = sys.platform.startswith('java')

# Generated at 2022-06-20 12:41:49.535596
# Unit test for function normalize_repr
def test_normalize_repr():
    import random
    assert normalize_repr('hello') == 'hello'
    for i in range(1000):
        r = random.randint(0, sys.maxsize)
        assert ' at 0x%x' % r not in normalize_repr('hi at 0x%x' % r)

# Generated at 2022-06-20 12:41:56.092224
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(0) == (0,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(range(4)) == (0, 1, 2, 3)



# Generated at 2022-06-20 12:42:01.308615
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, str),)) is repr
    assert get_repr_function(1, ((int, lambda x: x - 1),)) == (lambda x: x -
                                                              1)
    assert get_repr_function(1, ((str, int),)) is repr



# Generated at 2022-06-20 12:42:05.412771
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X(WritableStream): pass
    class Y(WritableStream):
        def write(self, s):
            pass
    assert issubclass(Y, WritableStream)
    assert not issubclass(X, WritableStream)



# Generated at 2022-06-20 12:42:14.753519
# Unit test for function truncate
def test_truncate():
    assert truncate('', 0) == ''
    assert truncate('', 1) == ''
    assert truncate('', 2) == ''
    assert truncate('', 3) == ''
    assert truncate('', 100) == ''
    assert truncate('abc', 0) == ''
    assert truncate('abc', 1) == '...'
    assert truncate('abc', 2) == '...'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 4) == 'abc'
    assert truncate('abc', 5) == 'abc'
    assert truncate('abc', 6) == 'abc'
    assert truncate('abc', 100) == 'abc'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 0) == ''

# Generated at 2022-06-20 12:42:22.374238
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('a at 0xf00') == 'a'
    assert normalize_repr('a at 0xf00 at 0xf00') == 'a at 0xf00'
    assert normalize_repr('a at 0xf00000') == 'a'
    assert normalize_repr('a at 0xf00000 at 0xf00000') == 'a at 0xf00000'
    assert normalize_repr('a at 0xf00000') == 'a'
    assert normalize_repr('\n\n\na at 0xf00000\n\n') == '\n\n\na\n\n'



# Generated at 2022-06-20 12:42:29.109043
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 6) == 'hello'
    assert truncate('hello', 7) == 'hello'
    assert truncate('hello', None) == 'hello'
    assert truncate('hello', 3) == '...'
    assert truncate('hello', 4) == 'he...'
    assert truncate('hello', 2) == '...'
    assert truncate('hello', 1) == '...'
    assert truncate('hello', 0) == '...'



# Generated at 2022-06-20 12:42:31.173406
# Unit test for function normalize_repr
def test_normalize_repr():
    assert re.match(r'<.* at 0x.*>', repr(object()))
    assert normalize_repr(repr(object())) == '<object object at 0x...>'

# Generated at 2022-06-20 12:42:36.807391
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(42) == (42,)
    assert ensure_tuple((42,)) == (42,)
    assert ensure_tuple((42,))[0] == 42
    assert ensure_tuple((42,))[-1] == 42
    assert ensure_tuple(('spam', 'ham')) == ('spam', 'ham')
    assert ensure_tuple(['spam', 'ham']) == ('spam', 'ham')
    assert ensure_tuple([42]) == (42,)
    assert ensure_tuple((x for x in 'spam')) == ('s', 'p', 'a', 'm')
    assert ensure_tuple(set(range(5))) == (0, 1, 2, 3, 4)

# Generated at 2022-06-20 12:42:44.056862
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class MyWritableStream(WritableStream):

        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(MyWritableStream, int)
    assert not issubclass(MyWritableStream, str)

    assert isinstance(MyWritableStream(), WritableStream)
    assert not isinstance(MyWritableStream(), int)
    assert not isinstance(MyWritableStream(), str)



# Generated at 2022-06-20 12:42:45.950559
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class foo(metaclass=ABCMeta):
        def write(self, s):
            pass
    assert isinstance(foo(), WritableStream)

# Generated at 2022-06-20 12:43:03.559042
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(('a', 'b')) == ('a', 'b')
    assert ensure_tuple('a') == ('a',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == ([1],)
    assert ensure_tuple({'a': 'b'}) == ({'a': 'b'},)
    assert ensure_tuple(set(['a', 'b'])) == ({'a', 'b'},)
    assert ensure_tuple(2j) == (2j,)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(u'a') == (u'a',)
    assert ensure_tuple(r'a') == (r'a',)

# Generated at 2022-06-20 12:43:11.044293
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', None) == '1234567890'
    assert truncate('1234567890', -1) == '1234567890'
    assert truncate('1234567890', 0) == '1234567890'
    assert truncate('1234567890', 1) == '...'
    assert truncate('1234567890', 2) == '...'
    assert truncate('1234567890', 3) == '...'
    assert truncate('1234567890', 4) == '1...'
    assert truncate('1234567890', 5) == '1...'
    assert truncate('1234567890', 6) == '12...'
    assert truncate('1234567890', 7) == '12...'

# Generated at 2022-06-20 12:43:12.152125
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert isinstance(sys.stdout, WritableStream)

# Generated at 2022-06-20 12:43:17.952975
# Unit test for function shitcode
def test_shitcode():
    for in_s, expected in (
        (u'abc', u'abc'),
        (u'a\U0001f4a9c', u'a?\U0001f4a9c'),
        (b'abc', u'abc'),
        (b'a\xff', u'a\u00ff'),
    ):
        got = shitcode(in_s)
        assert got == expected, \
               'Expected %r, got %r.' % (expected, got)

# Generated at 2022-06-20 12:43:22.404840
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple({1, 2, 3}) == (1, 2, 3)
    assert ensure_tuple(1) == (1,)

# Generated at 2022-06-20 12:43:33.239898
# Unit test for function get_repr_function
def test_get_repr_function():
    assert (get_repr_function('', []) == repr)
    assert (get_repr_function('', [(lambda x: True, None)]) == None)
    assert (get_repr_function('', [(lambda x: False, None)]) == repr)
    assert (get_repr_function('', [('', repr)]) == repr)
    assert (get_repr_function('', [(str, repr)]) == repr)
    assert (get_repr_function('', [('', lambda x: 'hello')]) == None)
    assert (get_repr_function(1, [('', lambda x: 'hello')]) == repr)
    assert (get_repr_function(1, [(str, lambda x: 'hello')]) == None)

# Generated at 2022-06-20 12:43:39.239021
# Unit test for function shitcode
def test_shitcode():
    for (i, o) in ((u'abc', 'abc'),
                   (u'\N{SNOWMAN}', '?'),
                   (u'\N{SNOWMAN}☃', '?\N{SNOWMAN}'),
                   (u'\u1234', '?'),
                   (u'\U00012345', '?'),
                   (u'\U000abcd0', '\U000abcd0'),
                   (u'\u3E3E\U000b0000', '??\U000b0000'),
                  ):
        assert shitcode(i) == o

# Generated at 2022-06-20 12:43:43.821227
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass
    assert isinstance(A(), WritableStream)
    class B: pass
    assert not isinstance(B(), WritableStream)
    class C(A):
        def close(self):
            pass
    assert isinstance(C(), WritableStream)
    class D(C):
        def write(self, s):
            pass
    assert isinstance(D(), WritableStream)
    class E(D):
        def close(self):
            pass
        def write(self, s):
            pass
    assert isinstance(E(), WritableStream)

# Generated at 2022-06-20 12:43:52.675406
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(B): pass
    class D(B): pass
    class E(C): pass

    assert get_repr_function(A(), ()) == repr
    assert get_repr_function(B(), ((A, str),)) == str
    assert get_repr_function(C(), ((A, str), (B, str))) == str
    assert get_repr_function(D(), ((A, str), (B, str))) == str
    assert get_repr_function(E(), ((A, str), (B, str))) == str



# Generated at 2022-06-20 12:44:02.385500
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello world') == 'hello world'
    assert shitcode('µπ') == '??'
    assert shitcode('µπ'.encode('utf-8')) == '??'
    assert shitcode('abcdefghijklmnopqrstuvwxyz') == \
        'abcdefghijklmnopqrstuvwxyz'
    assert shitcode('abcdefghijklmnopqrstuvwxyz' * 100) == \
        'abcdefghijklmnopqrstuvwxyz' * 100
    assert shitcode('abcdefghijklmnopqrstuvwxyz'[:-1] + '\x00') == \
        'abcdefghijklmnopqrstuvwxyz'[:-1] + '?'
    assert shitcode

# Generated at 2022-06-20 12:44:20.103298
# Unit test for function normalize_repr
def test_normalize_repr():

    def test(x):
        assert normalize_repr(repr(x)) == repr(x)

    test('')
    test('x')
    test('xyz')
    test('xyz xyz')
    test('''xyz xyz''')
    test(list(range(100))) # Just a big thing that should have a memory address
    test(set(range(100))) # Just a big thing that should have a memory address
    test(tuple(range(100))) # Just a big thing that should have a memory address
    test(dict((i, i + 1) for i in range(100))) # Just a big thing that should have a memory address



# Generated at 2022-06-20 12:44:22.241516
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert isinstance(sys.stdout, WritableStream)
    assert not isinstance(str, WritableStream)
    assert not isinstance(list, WritableStream)



# Generated at 2022-06-20 12:44:27.999571
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("<object object at 0x7f8d1c44f6d0>") == "<object object>"
    assert normalize_repr("<object object at 0x7f8d1c44f6d0>,") == "<object object>,"
    assert normalize_repr("<object object at 0x7f8d1c44f6d0>, at 0x7f8d1c44f6d0") == "<object object>, at 0x7f8d1c44f6d0"
    assert normalize_repr("<object object at 0x7f8d1c44f6d0>, at foo bar 0x7f8d1c44f6d0") == "<object object>, at foo bar 0x7f8d1c44f6d0"


# Unit

# Generated at 2022-06-20 12:44:36.871234
# Unit test for function normalize_repr
def test_normalize_repr():

    class A(object):
        def __init__(self, i):
            self.i = i
        def __repr__(self):
            return 'A({}) at 0x{:x}'.format(self.i, id(self))

    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('A(1) at 0x12345678') == 'A(1)'
    # the following gives a warning and is therefore not tested
    #assert normalize_repr(A(1)) == 'A(1)'
    assert normalize_repr('A(1) at junk') == 'A(1) at junk'



del ABC

# Generated at 2022-06-20 12:44:42.784241
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeA:
        write = 1

    class FakeB:
        write = None

    class FakeC:
        pass

    assert WritableStream.__subclasshook__(FakeA) is NotImplemented
    assert WritableStream.__subclasshook__(FakeB) is NotImplemented
    assert WritableStream.__subclasshook__(FakeC) is NotImplemented

    class FakeD:
        write = lambda self, s: None

    assert WritableStream.__subclasshook__(FakeD) is True



# Generated at 2022-06-20 12:44:51.273765
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import os
    from . import path_tools
    from . import temp_file_tools
    from . import console_write

    def test_iterable(iterable_type, output_stream_types, **kwargs):
        with temp_file_tools.create_temp_file() as temp_file_path:
            with path_tools.open_file(temp_file_path, 'w') as temp_file:
                for output_stream_type in output_stream_types:
                    with output_stream_type(temp_file.fileno(),
                                            **kwargs) as output_stream:
                        iterable = iterable_type()
                        output_stream.write(iterable)

# Generated at 2022-06-20 12:45:00.279728
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import sys
    import six

    class FakeStream(object):
        def __init__(self, *args, **kwargs):
            self.written = ''

        def write(self, s):
            self.written += s

    # First test: A built-in class
    console = io.TextIOWrapper(FakeStream())
    assert isinstance(console, WritableStream)

    # Second test: A custom class
    class CustomStream(object):
        def write(self, s):
            self.written += s
    console = CustomStream()
    assert isinstance(console, WritableStream)



# Generated at 2022-06-20 12:45:09.918474
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(
        1,
        custom_repr=(
            (lambda x: isinstance(x, int),
             lambda x: 'int {}'.format(x)),
        )
    )(1) == 'int 1'
    assert get_repr_function(
        '',
        custom_repr=(
            (lambda x: isinstance(x, int),
             lambda x: 'int {}'.format(x)),
        )
    )('') == "''"
    assert get_repr_function(
        '',
        custom_repr=(
            (lambda x: isinstance(x, int),
             lambda x: 'int {}'.format(x)),
        )
    )('') == "''"

# Generated at 2022-06-20 12:45:13.889896
# Unit test for constructor of class WritableStream
def test_WritableStream(): # pragma: no cover
    if sys.version_info > (3, 5):
        assert issubclass(sys.stdout.__class__, WritableStream)
        assert issubclass(sys.stdout.__class__, collections_abc.Sized)
        assert issubclass(sys.stdout.__class__, collections_abc.Iterable)
        assert issubclass(sys.stdout.__class__, collections_abc.Container)

# Generated at 2022-06-20 12:45:15.154072
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Test(WritableStream):
        pass
    Test()



# Generated at 2022-06-20 12:45:32.730984
# Unit test for function shitcode
def test_shitcode():

    def _test_shitcode(s):
        assert shitcode(s) == s

    _test_shitcode('a')
    _test_shitcode('a' * 256)
    _test_shitcode('a' * 256 + chr(0))
    _test_shitcode('a' * 256 + chr(1))
    _test_shitcode('a' * 256 + chr(127))



# Generated at 2022-06-20 12:45:38.674259
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr('foo') == "'foo'"
    assert get_shortish_repr(re.compile('ab')) == "re.compile(r'ab')"
    assert get_shortish_repr('foo', (('x', 'hi'),), normalize=True) == "'foo'"
    assert get_shortish_repr('foo', (('x', lambda x: True),), normalize=True) == \
           "'foo'"
    assert get_shortish_repr(
        'x' * 500,
        max_length=30,
        normalize=True
    ) == "'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx...xxxxxxxxxx'"

# Generated at 2022-06-20 12:45:44.973558
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class Works(WritableStream):
        def write(self, s):
            return

    class MissingWrite(WritableStream):
        def foo(self):
            pass

    class WrongSignature(WritableStream):
        def write(self):
            pass

    assert issubclass(Works, WritableStream)
    assert not issubclass(MissingWrite, WritableStream)
    assert not issubclass(WrongSignature, WritableStream)

# Generated at 2022-06-20 12:45:48.965044
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        written = False
        def write(self, s):
            self.written = True

    my_writable_stream = MyWritableStream()
    assert my_writable_stream.written is False
    my_writable_stream.write('whatever')
    assert my_writable_stream.written is True

# Generated at 2022-06-20 12:45:51.219226
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class FakeWritableStream(WritableStream):
        def write(self):
            pass
    FakeWritableStream()



# Generated at 2022-06-20 12:45:57.589329
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [
        (lambda x: False, None),
    ]) is repr
    assert get_repr_function(1, [
        (lambda x: False, 'a'),
    ]) is str
    assert get_repr_function(1, [
        (lambda x: False, None),
        (lambda x: False, 'b'),
    ]) is str
    assert get_repr_function(1, [
        (lambda x: False, 'a'),
        (lambda x: False, 'b'),
    ]) is str
    assert get_repr_function(1, [
        (lambda x: False, None),
        (lambda x: False, None),
    ]) is repr

# Generated at 2022-06-20 12:46:02.119164
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class ToDict(object):
        def write(self, s):
            self.dict = {c: ord(c) for c in s}

    ToDict().write('Python rocks')
    assert list(sorted(ToDict().dict.values())) == [
        ord(c) for c in 'Ptbyn ocraks'
    ]

# Generated at 2022-06-20 12:46:10.641269
# Unit test for function get_repr_function
def test_get_repr_function():
    assert_get_repr_function(
        "str", custom_repr=((str, shitcode), ),
        expected_result=shitcode
    )
    assert_get_repr_function(
        "int", custom_repr=((str, shitcode), ),
        expected_result=repr
    )
    assert_get_repr_function(
        "int", custom_repr=((None, shitcode), ),
        expected_result=shitcode
    )
    assert_get_repr_function(
        "int", custom_repr=((1, shitcode), ),
        expected_result=repr
    )
    assert_get_repr_function(
        "int", custom_repr=((lambda x: x == 1, shitcode), ),
        expected_result=shitcode
    )

# Generated at 2022-06-20 12:46:20.871906
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class Foo(object):
        def __repr__(self):
            return 'hi there'

    assert get_shortish_repr(Foo(), max_length=3) == 'h...'
    assert get_shortish_repr(Foo(), max_length=6) == 'hi...'
    assert get_shortish_repr(Foo(), max_length=7) == 'hi ...'
    assert get_shortish_repr(Foo(), max_length=12) == 'hi there'
    assert get_shortish_repr(Foo(), max_length=None) == 'hi there'

    assert get_shortish_repr('hello world', max_length=5) == 'he...'
    assert get_shortish_repr('hello world', max_length=10) == 'hello w...'

# Generated at 2022-06-20 12:46:23.645031
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream:
        def write(self, s):
            return len(s)
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-20 12:46:58.715674
# Unit test for function get_repr_function
def test_get_repr_function():
    def _(a):
        assert get_repr_function(a, custom_repr=[(int, lambda x: 'int')]) == \
                                                                int.__repr__

    _(1)
    _(1.0)
    _(True)
    assert get_repr_function(1.0, custom_repr=[(int, lambda x: 'int')]) == \
                                                                float.__repr__
    assert get_repr_function(True, custom_repr=[(int, lambda x: 'int')]) == \
                                                                bool.__repr__


# Generated at 2022-06-20 12:47:09.770175
# Unit test for function normalize_repr
def test_normalize_repr():
    import inspect
    import sys

    class C(object): pass

    # if "PyPy" in sys.version:
    #     assert (normalize_repr(f"{C()}") == repr(C()))
    #     assert (normalize_repr(f"{C}") == repr(C))
    #     assert (normalize_repr(f"{type(C)}") == repr(type(C)))
    #     assert (normalize_repr(f"{inspect.getargspec}") == repr(inspect.getargspec))
    # else:
    #     assert (normalize_repr(f"{C()}") == "<__main__.C object at -")
    #     assert (normalize_repr(f"{C}") == "<class '__main__.C'>

# Generated at 2022-06-20 12:47:19.009431
# Unit test for function get_repr_function
def test_get_repr_function():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    assert get_repr_function(A(), (
        (B, lambda x: 'B'),
        (C, lambda x: 'C'),
        (lambda x: isinstance(x, A), lambda x: 'A'),
        (lambda x: not isinstance(x, A), lambda x: 'X'),
    )) == 'A'
    assert get_repr_function(B(), (
        (B, lambda x: 'B'),
        (C, lambda x: 'C'),
        (lambda x: isinstance(x, A), lambda x: 'A'),
        (lambda x: not isinstance(x, A), lambda x: 'X'),
    )) == 'B'

# Generated at 2022-06-20 12:47:24.551037
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):

        def __init__(self):
            self.written_stuff = []

        def write(self, s):
            self.written_stuff.append(s)

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_stuff == ['hello']



# Generated at 2022-06-20 12:47:34.914744
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(42) == (42,)
    assert ensure_tuple('meow') == tuple('meow')
    assert ensure_tuple(3.14) == (3.14,)
    assert ensure_tuple(['a', 'b']) == ('a', 'b')
    assert ensure_tuple(('a', 'b')) == ('a', 'b')
    assert ensure_tuple((x for x in range(3))) == (0, 1, 2)
    assert ensure_tuple({'a', 'b'}) == ('a', 'b')
    assert ensure_tuple({'a': 'b'}) == (('a', 'b'),)
    assert ensure_tuple(set()) == ()



# Generated at 2022-06-20 12:47:41.723533
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, custom_repr=[(int, lambda x: 'test')]) == 'test'

    assert get_repr_function(4.4, custom_repr=[(int, lambda x: 'test')]) != 'test'

    class Foo(object):
        pass
    assert get_repr_function(Foo(), custom_repr=[(Foo, lambda x: 'test')]) == 'test'

    assert get_repr_function(Foo, custom_repr=[(Foo, lambda x: 'test')]) != 'test'

    assert get_repr_function([1, 2, 3], custom_repr=[(list, lambda x: 'test')]) == 'test'


# Generated at 2022-06-20 12:47:48.942085
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('אאא') == '???'
    assert shitcode('aaa') == 'aaa'
    assert shitcode(('a', 'a', 'a')) == 'aaa'
    assert shitcode(('a', 'א', 'a')) == 'a?a'
    assert shitcode(('a', 'א', 'a'), max_length=1) == 'a'
    assert shitcode(('a', 'א', 'a'), max_length=2) == 'a?'
    assert shitcode(('a', 'א', 'a'), max_length=3) == 'a?a'

# Generated at 2022-06-20 12:47:51.301794
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('d') == ('d',)
    assert ensure_tuple(['d']) == ('d',)
    assert ensure_tuple(('d',)) == ('d',)



# Generated at 2022-06-20 12:48:00.945939
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(r'<module ') == r'<module '
    assert normalize_repr(r'<module at 0x000001>') == r'<module>'
    assert normalize_repr(r'<module at 0x0000ABCD01>') == r'<module>'
    assert normalize_repr(r'<module at 0x0000ABCD01EF>') == r'<module>'
    assert normalize_repr(r'<module at 0x0000ABCD01ef>') == r'<module>'
    assert normalize_repr(r'<module at 0x01ABCD01Ef>') == r'<module>'
    assert normalize_repr(r'<module at 0x01ABCD01Ef>') == r'<module>'


# Generated at 2022-06-20 12:48:04.925707
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 'a')) == (1, 'a')
    assert ensure_tuple([1, 'a']) == (1, 'a')

