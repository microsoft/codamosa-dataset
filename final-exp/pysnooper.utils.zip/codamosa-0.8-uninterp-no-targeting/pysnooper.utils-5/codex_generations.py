

# Generated at 2022-06-20 12:38:14.239989
# Unit test for function truncate
def test_truncate():
    assert truncate('', 5) == ''
    assert truncate('a', 5) == 'a'
    assert truncate('abcdefghijkl', 5) == 'abcde...kl'
    assert truncate('abcde', 5) == 'abcde'
    assert truncate('abc', 5) == 'abc'



# Generated at 2022-06-20 12:38:19.957864
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x123') == 'hello'
    assert normalize_repr('hello at 0x123 at 0x456') == 'hello'
    assert normalize_repr('hello at 0x123a') == 'hello at 0x123a'
    assert normalize_repr(' at 0x123a') == ''
    assert normalize_repr(' at 0x123a at 0x456') == ''

# Generated at 2022-06-20 12:38:26.852793
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('foo') == 'foo'
    assert normalize_repr('foo at 0x12345678') == 'foo'
    assert normalize_repr('foo at 0x12345678 at 0x12345678') == 'foo'
    assert normalize_repr('foo at 0x12345678 bar at 0x12345678') == \
                                                         'foo bar at 0x12345678'
    assert normalize_repr('foo at 0x12345678 bar at 0x12345678 bar') == \
                                                         'foo bar at 0x12345678'
    assert normalize_repr('foo at 0x12345678 bar at 0x12345678 bar at 0x12345678') == \
                                                         'foo bar at 0x12345678'

# Generated at 2022-06-20 12:38:37.473263
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(42) == '42'
    assert get_shortish_repr(42, max_length=3) == '42'
    assert get_shortish_repr(42, max_length=2) == '42'
    assert get_shortish_repr(42, max_length=1) == '...'
    assert get_shortish_repr((1, 2, 3), max_length=8) == '(1, 2, 3)'
    assert get_shortish_repr((1, 2, 3), max_length=7) == '(1, 2...'
    assert get_shortish_repr((1, 2, 3), max_length=6) == '(1...'

# Generated at 2022-06-20 12:38:44.982283
# Unit test for function truncate
def test_truncate():
    assert truncate(u'', 1) == ''
    assert truncate(u'', None) == ''
    assert truncate(u'x', 1) == 'x'
    assert truncate(u'x', None) == 'x'
    assert truncate(u'abcd', None) == 'abcd'
    assert truncate(u'abcde', 5) == 'abcde'
    assert truncate(u'abcdef', 5) == '...ef'
    assert truncate(u'abcdef', 5, midpoint=True) == 'a...f'
    assert truncate(u'abcdef', 4) == '...f'
    assert truncate(u'abcdef', 4, midpoint=True) == '...f'
    assert truncate(u'abcdefg', 6) == 'abcdefg'

# Generated at 2022-06-20 12:38:54.808215
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(set([1])) == "{1}"
    assert get_shortish_repr(set([2])) != "{1}"
    assert get_shortish_repr(set([1]), custom_repr=[(set, lambda x: '123')]) == '123'
    assert get_shortish_repr(set([2]), custom_repr=[(set, lambda x: '123')]) == '123'
    assert get_shortish_repr(set([1]), custom_repr=[(list, lambda x: '123')]) == '{1}'
    assert get_shortish_repr(set([2]), custom_repr=[(list, lambda x: '123')]) == '{2}'

    assert get_shortish_repr(list([1])) == "[1]"

# Generated at 2022-06-20 12:38:56.765217
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class F(WritableStream):
        def write(self, s):
            return

    F()

# Generated at 2022-06-20 12:39:06.946795
# Unit test for function normalize_repr
def test_normalize_repr():
    import types
    import weakref
    class Foo(object):
        pass
    foo = Foo()
    assert normalize_repr('<object at 0x00000123456789AB>') == \
                          '<object>'
    assert normalize_repr('<function at 0x00000123456789AB>') == \
                          '<function>'
    assert normalize_repr('<type at 0x00000123456789AB>') == \
                          '<type>'
    assert normalize_repr('<module at 0x00000123456789AB>') == \
                          '<module>'

# Generated at 2022-06-20 12:39:13.473439
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(0) == '0'
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(2) == '2'
    assert get_shortish_repr('') == "''"
    assert get_shortish_repr('a') == "'a'"
    assert get_shortish_repr('ab') == "'ab'"
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abcd') == "'abcd'"
    assert get_shortish_repr('abcde') == "'abcde'"
    assert get_shortish_repr('abcdef') == "'abcde...f'"
    assert get_shortish_repr('abcdefg') == "'abcde...g'"

# Generated at 2022-06-20 12:39:16.268211
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('Hello world!') == 'Hello world!'
    assert shitcode(b'Hello world!') == 'Hello world!'
    assert shitcode(b'\x80') == '?'

# Generated at 2022-06-20 12:39:31.006384
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1.5) == '1.5'
    assert get_shortish_repr('hi') == "'hi'"

    assert get_shortish_repr('hello, I am a very long string', max_length=15) == \
                                                                    "'hello, I am...'"
    assert get_shortish_repr(','.join(str(n) for n in range(20)), max_length=10) == \
                                  "", "'0,1,2,3,4,5,6,7...'"

    assert get_shortish_repr(range(20), max_length=10) == 'range(0, 20)'

    class C: pass


# Generated at 2022-06-20 12:39:40.837160
# Unit test for function truncate
def test_truncate():
    assert truncate('hi', 2) == 'hi'
    assert truncate('hi', 3) == 'hi'
    assert truncate('hello', 2) == 'he...'
    assert truncate('hello', 3) == 'he...'
    assert truncate('hello', 4) == 'he...'
    assert truncate('hello', 5) == 'he...'
    assert truncate('hello', 6) == 'hello'
    assert truncate('hello world', 9) == 'hell...'
    assert truncate('hello world', 10) == 'hell...'
    assert truncate('hello world', 11) == 'hello w...'
    assert truncate('hello world', 12) == 'hello w...'
    assert truncate('hello world', 13) == 'hello wo...'

# Generated at 2022-06-20 12:39:44.488955
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)



# Generated at 2022-06-20 12:39:47.490841
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(['a', 'b']) == ('a', 'b')
    assert ensure_tuple('a') == ('a',)
    assert ensure_tuple(()) == tuple()
    assert ensure_tuple(None) == (None,)






# Generated at 2022-06-20 12:39:55.754497
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStream1(WritableStream):
        def write(self, s):
            pass

    class WritableStream2(WritableStream):
        def write(self, s):
            pass

        def write_with_two_args(self, s, t):
            pass

    class WritableStream3(WritableStream):
        def write(self, s):
            pass

        def read(self, s):
            pass

    assert issubclass(WritableStream1, WritableStream)
    assert issubclass(WritableStream2, WritableStream)
    assert not issubclass(WritableStream3, WritableStream)


if __name__ == '__main__':
    pytest_plugins = 'pytest_monkeypatch'

# Generated at 2022-06-20 12:40:07.639898
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    test_write('Testing get_shortish_repr... ')
    class X(object):
        def __repr__(self):
            return 'abcdefghijkl'
    assert get_shortish_repr(X(), custom_repr=()) == 'abcdefghijkl'
    assert get_shortish_repr(X(), custom_repr=(), max_length=10) == 'abcdefghi...'
    assert get_shortish_repr(X(), custom_repr=((True, lambda: 'xyz'),)) == 'xyz'
    assert get_shortish_repr(X(), custom_repr=((True, 'xyz'),)) == 'xyz'

# Generated at 2022-06-20 12:40:10.061516
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(object):
        def write(self, s):
            print(s)
    assert isinstance(X(), WritableStream)
    x = X()
    x.write('abc')



# Generated at 2022-06-20 12:40:14.450721
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 5) == '12...89'
    assert truncate('123456789', 2) == '12...'
    assert truncate('123456789', 1) == '...'
    assert truncate('123456789', 0) == '...'
    assert truncate('123456789', -1) == '...'
    assert truncate('123456789', None) == '123456789'

# Generated at 2022-06-20 12:40:27.234932
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', 2) == 'ab...'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 4) == 'abc'
    assert truncate('abc', 5) == 'abc'
    assert truncate('abc', 6) == 'abc'
    assert truncate('abcdefg', 7) == 'abcdefg'
    assert truncate('abcdefg', 8) == 'abcdefg'
    assert truncate('abcdefg', 9) == 'abcdefg'
    assert truncate('abcdefg', 10) == 'abcdefg'
    assert truncate('abcdefg', 11) == 'abcdefg'
    assert truncate('abcdefg', 12) == 'abcdefg'
    assert truncate('abcdefg', 13) == 'abcdefg'

# Generated at 2022-06-20 12:40:28.838260
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)

# Generated at 2022-06-20 12:40:51.621006
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Stream(WritableStream):
        def write(self, s):
            pass
    assert isinstance(Stream(), WritableStream)


    class Stream(WritableStream):
        def pmew(self, s):
            pass
    assert not isinstance(Stream(), WritableStream)


    class Stream(WritableStream):
        def write(self, s):
            pass
        def close(self):
            pass
    assert isinstance(Stream(), WritableStream)


    class Stream(WritableStream):
        def write(self, s):
            pass
        def close(self):
            pass
        def flush(self):
            pass
    assert isinstance(Stream(), WritableStream)



# Generated at 2022-06-20 12:41:00.867670
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None) is repr
    assert get_repr_function(1) is repr
    assert get_repr_function('a') is repr

    class X(object): pass
    class Y(X): pass
    class Z(X): pass

    custom_repr = (
        (str, 'str'),
        (int, 'int'),
        (X, 'X'),
        (Z, 'Z'),
    )

    assert get_repr_function(1, custom_repr) is repr
    assert get_repr_function('a', custom_repr) is str
    assert get_repr_function(X(), custom_repr) is repr
    assert get_repr_function(Y(), custom_repr) is repr

# Generated at 2022-06-20 12:41:11.998167
# Unit test for function normalize_repr
def test_normalize_repr():
    assert '<object at>' == normalize_repr('<object at 0x0e4da1b0>')
    assert '<object at>' == normalize_repr('<object at 0x00e4da1b0>')
    assert '<object at>' == normalize_repr('<object at 0x0000e4da1b0>')
    assert '<object at>' == normalize_repr('<object at 0xa0e4da1b0>')
    assert '<object at>' == normalize_repr('<object at 0x0E4DA1B0>')
    assert '<object at>' == normalize_repr('<object at 0x00E4DA1B0>')

# Generated at 2022-06-20 12:41:19.033345
# Unit test for function get_repr_function
def test_get_repr_function():
    class X(object): pass
    x = X()

    def repr_1(x):
        return '1'
    def repr_2(x):
        return '2'

    assert get_repr_function(x, ((X, repr_1),
                                 (None, repr_2))) is repr_1

    assert get_repr_function(x, ((None, repr_2),
                                 (X, repr_1))) is repr_1

    assert get_repr_function(x, ((True, repr_1),
                                 (False, repr_2))) is repr_1

    assert get_repr_function(x, ((lambda t: isinstance(t, X), repr_1),
                                 (lambda t: True, repr_2))) is repr_1


# Generated at 2022-06-20 12:41:22.669890
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(('hello',)) == ('hello',)
    assert ensure_tuple(['hello']) == ('hello',)

# Generated at 2022-06-20 12:41:29.824450
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Stream(WritableStream):
        def __init__(self):
            self.written_data = bytearray()
        def write(self, s):
            self.written_data.extend(s)
    stream = Stream()
    stream.write('asdf'.encode('utf-8'))
    assert stream.written_data == b'asdf'
    stream.write('qwer'.encode('utf-8'))
    assert stream.written_data == b'asdfqwer'
    stream.write(''.encode('utf-8'))
    assert stream.written_data == b'asdfqwer'



# Generated at 2022-06-20 12:41:33.368113
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple(1) == (1,)




# Generated at 2022-06-20 12:41:41.105276
# Unit test for function get_repr_function
def test_get_repr_function():
    # Tests for no custom repr:
    assert get_repr_function(object(), custom_repr=()) is repr
    assert get_repr_function(int(), custom_repr=()) is repr
    assert get_repr_function(str(), custom_repr=()) is repr
    assert get_repr_function(dict(), custom_repr=()) is repr
    assert get_repr_function(list(), custom_repr=()) is repr
    assert get_repr_function(Exception(), custom_repr=()) is repr
    assert get_repr_function(UnicodeError(), custom_repr=()) is repr

    # Tests for custom repr:

# Generated at 2022-06-20 12:41:45.808300
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo(object): pass
    assert get_repr_function(3, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function('3', [(int, lambda x: 'int')]) == repr
    assert get_repr_function(Foo(), [(Foo, lambda x: 'Foo')]) == 'Foo'

    assert get_repr_function(3, ())(3) == '3'


# Generated at 2022-06-20 12:41:55.645821
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("<function <lambda> at 0x11c9f5a60>") == \
                                                      "<function <lambda>>"
    assert normalize_repr("<function <lambda> at 0x11c9f5a60>") == \
                                                      "<function <lambda>>"
    assert normalize_repr("<function <lambda> at 0x11c9f5a60>") == \
                                                      "<function <lambda>>"
    assert normalize_repr("<function <lambda> at 0x11c9f5a60>") == \
                                                      "<function <lambda>>"

    assert normalize_repr("word at 0x11c9f5a60") == "word"

# Generated at 2022-06-20 12:42:16.796859
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, custom_repr=((int, lambda i: 'int: %s' % i),)) == 'int: 3'
    assert get_repr_function(3, custom_repr=((int, lambda i: 'int: %s' % i),)).__name__ == '<lambda>'

    class Foo:
        pass

    assert get_repr_function(Foo(), custom_repr=((Foo, lambda i: 'Foo'),)) == 'Foo'
    assert get_repr_function(Foo(), custom_repr=((Foo, lambda i: 'Foo'),)).__name__ == '<lambda>'


# Generated at 2022-06-20 12:42:18.904876
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyStream, WritableStream)


# Generated at 2022-06-20 12:42:22.457725
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'\u2713') == '?'
    assert shitcode(u'$') == '$'
    assert shitcode('\U0001F422') == '?'
    assert shitcode('\x56') == 'V'



# Generated at 2022-06-20 12:42:26.412106
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(None) == (None,)

# Generated at 2022-06-20 12:42:31.731503
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)

    class Iterable(object):
        def __iter__(self):
            return iter((1, 2, 3))
        def __len__(self):
            return 3
        def __getitem__(self, index):
            return (1, 2, 3)[index]
        def __repr__(self):
            return 'Iterable()'

    assert ensure_tuple(Iterable()) == (1, 2, 3)

# Generated at 2022-06-20 12:42:43.144635
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    test_string = 'ʊf ǝlᴉɹǝuᴉlᴉɟ oʇ'

    assert get_shortish_repr(test_string) == \
           'ʊf \\u02ccl\\u025f\\u1d31\\u028br\\u025f\\u1d33u\\u025fl\\u025f\\u02bf o\\u02c7'

    test_list = ['ʊf ǝlᴉɹǝuᴉlᴉɟ oʇ', 'ɔıɹɐɯs ǝɹɐnoɟ ']


# Generated at 2022-06-20 12:42:46.392154
# Unit test for function shitcode
def test_shitcode():

    from .test_tools import assert_equal
    
    assert_equal(shitcode('test'), 'test')
    assert_equal(shitcode('שלום'), '???ם')
    assert_equal(shitcode(u'\u03c0'), '?')



# Generated at 2022-06-20 12:42:50.690802
# Unit test for function normalize_repr
def test_normalize_repr():
    class A(object): pass
    a = A()

    repr1 = repr(a)  # <__main__.A object at 0x000000000212C7F0>
    repr2 = normalize_repr(repr1)  # <__main__.A object>

    assert repr1 != repr2
    assert repr2 == '<__main__.A object>'

# Generated at 2022-06-20 12:43:01.682789
# Unit test for function get_repr_function
def test_get_repr_function():

    foo = _SentinelObject()
    bar = object()

    assert get_repr_function(foo, custom_repr=(
        (lambda x: x is foo, lambda x: 'foo'),
        (type(_SentinelObject), lambda x: '_SentinelObject')
    ))() == 'foo'

    assert get_repr_function(bar, custom_repr=(
        (lambda x: x is foo, lambda x: 'foo'),
        (type(_SentinelObject), lambda x: '_SentinelObject')
    ))() == '<object object at 0x%x>' % id(bar)

    assert get_repr_function(foo, custom_repr=(
        (type(_SentinelObject), lambda x: '_SentinelObject'),
        (lambda x: x is foo, lambda x: 'foo')
    ))

# Generated at 2022-06-20 12:43:10.035695
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello!') == 'hello!'
    assert get_shortish_repr('X' * 21) == 'X' * 21
    assert get_shortish_repr('X' * 22, max_length=22) == 'X' * 22
    assert get_shortish_repr('X' * 23, max_length=22) == 'X' * 18 + '...' + 'X'
    assert get_shortish_repr('X' * 23, max_length=22, normalize=True) == \
                                                     'X' * 20 + '...'
    assert get_shortish_repr('X' * 27, max_length=22) == 'X' * 18 + '...' + 'X'

# Generated at 2022-06-20 12:43:28.557727
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.buffer = ''

        def write(self, s):
            self.buffer += s

    stream = MyWritableStream()
    stream.write('meow')
    assert stream.buffer == 'meow'


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-20 12:43:33.000495
# Unit test for method write of class WritableStream

# Generated at 2022-06-20 12:43:40.404632
# Unit test for function truncate
def test_truncate():
    assert truncate(None, None) == None
    assert truncate('foobar', None) == 'foobar'
    assert truncate('foobar', 10) == 'foobar'
    assert truncate('foobar', 6) == 'foobar'
    assert truncate('foobar', 5) == 'fooba...'
    assert truncate('foobar', 4) == 'foob...'
    assert truncate('foobar', 3) == 'foo...'
    assert truncate('foobar', 2) == 'fo...'
    assert truncate('foobar', 1) == 'f...'
    assert truncate('foobar', 0) == '...'
    assert truncate('foobar', -1) == '...'




# Generated at 2022-06-20 12:43:46.083035
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class MyBrokenWritableStream(WritableStream):
        def wnte(self, s):
            pass
    assert not issubclass(MyBrokenWritableStream, WritableStream)

# Generated at 2022-06-20 12:43:50.998297
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X(object):
        pass
    class Y(object):
        def write(self, s):
            pass
    class Z(object):
        pass
    assert isinstance(X(), WritableStream) == False
    assert isinstance(Y(), WritableStream) == True
    assert isinstance(Z(), WritableStream) == False

# Generated at 2022-06-20 12:43:57.858165
# Unit test for function truncate
def test_truncate():
    assert truncate('12345', 4) == '123...'
    assert truncate('12345', 5) == '12345'
    assert truncate('12345', 6) == '12345'
    assert truncate('12345', 7) == '12345'
    assert truncate('12345', 3) == '123...'
    assert truncate('12345', 2) == '12...'
    assert truncate('12345', 1) == '1...'
    assert truncate('12345', 0) == '...'



# Generated at 2022-06-20 12:44:01.628831
# Unit test for function ensure_tuple
def test_ensure_tuple():
    class foo(object):
        def __iter__(self):
            yield "bar"
    assert ensure_tuple("bar") == ("bar",)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple(foo()) == ("bar",)

# Generated at 2022-06-20 12:44:03.768562
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1]) == (1,)

# Generated at 2022-06-20 12:44:09.987339
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('hello\x00') == 'hello\x00'
    assert shitcode('hello\x7f') == 'hello\x7f'
    assert shitcode('hello\x80') == 'hello\x80'


if sys.version_info.major == 2:
    def is_in_range(x):
        return isinstance(x, (xrange, int))
else:
    def is_in_range(x):
        return isinstance(x, range)

# Generated at 2022-06-20 12:44:16.671582
# Unit test for function normalize_repr
def test_normalize_repr():
    from .python_toolbox.string_tools import remove_last
    

# Generated at 2022-06-20 12:44:34.037676
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def write(self, s):
            pass
    class B:
        def write(self, s):
            pass
    class C:
        def not_write(self, s):
            pass
    assert issubclass(A, WritableStream)
    assert not issubclass(B, WritableStream)
    assert not issubclass(C, WritableStream)

# Generated at 2022-06-20 12:44:43.604187
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('foo') == 'foo'
    assert normalize_repr('foo at 0x123456') == 'foo'
    assert normalize_repr('foo at 0xABCD123456') == 'foo'
    assert normalize_repr('foo at 0xffff') == 'foo'
    assert normalize_repr('foo at 0xffffffffffffffff') == 'foo'
    assert normalize_repr('foo at 0xFF') == 'foo'
    assert normalize_repr('foo at 0x1F') == 'foo'
    assert normalize_repr('foo at 0x123F') == 'foo'
    assert normalize_repr('foo at 0x12FF') == 'foo'
    assert normalize_repr('foo at 0x12Ff') == 'foo'

# Generated at 2022-06-20 12:44:51.920936
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(2, [(int, str)])(2) == '2'
    assert get_repr_function('hi', [(int, str)])('hi') == "'hi'"
    assert get_repr_function((2, 3), [(tuple, str)])(2, 3) == '(2, 3)'
    assert get_repr_function(2, [(int, str), (str, str)])(2) == '2'
    assert get_repr_function('hi', [(int, str), (str, str)])('hi') == "'hi'"
    assert get_repr_function(
        (2, 3),
        [(tuple, str), (int, str), (str, str)]
    )((2, 3)) == '(2, 3)'



# Generated at 2022-06-20 12:44:53.872418
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X(object):
        def write(self, s):
            pass
    assert issubclass(X, WritableStream)



# Generated at 2022-06-20 12:45:04.853960
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    a = {1: 2}
    assert get_shortish_repr(a) == '{1: 2}'
    assert get_shortish_repr(a, max_length=8) == '{1: 2}'
    assert get_shortish_repr(a, max_length=7) == '{1: 2}'
    assert get_shortish_repr(a, max_length=6) == '{1: 2}'
    assert get_shortish_repr(a, max_length=5) == '{1: 2}'
    assert get_shortish_repr(a, max_length=4) == '{1:}'
    assert get_shortish_repr(a, max_length=3)

# Generated at 2022-06-20 12:45:13.400458
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('Hello', max_length=None) == 'Hello'
    assert get_shortish_repr('Hello', max_length=5) == 'Hello'
    assert get_shortish_repr('Hello', max_length=4) == 'Hell'
    assert get_shortish_repr('Hello', max_length=3) == 'Hel'
    assert get_shortish_repr('Hello', max_length=2) == 'He'
    assert get_shortish_repr('Hello', max_length=1) == 'H'
    assert get_shortish_repr('Hello', max_length=0) == ''
    assert get_shortish_repr('Hello', max_length=1) == 'H'

# Generated at 2022-06-20 12:45:16.838067
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, b):
            pass
    a = A()
    assert (isinstance(a, WritableStream))

    class B:
        pass
    b = B()
    assert (not isinstance(b, WritableStream))




# Generated at 2022-06-20 12:45:22.309775
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('a\x00') == 'a?'
    assert shitcode(u'a\u2500') == 'a?'
    assert shitcode(u'\u2500a') == '?a'



# Generated at 2022-06-20 12:45:30.800525
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A(object):
        def __repr__(self):
            return 'A()'
    class B(A):
        pass
    class C(A):
        def __repr__(self):
            return 'C()'
    class D(C):
        pass
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, normalize=True) == '1'
    assert get_shortish_repr('asd', max_length=6) == 'asd'
    assert get_shortish_repr('asd', max_length=5) == 'asd'
    assert get_shortish_repr('asd', max_length=4) == 'as...'

# Generated at 2022-06-20 12:45:37.899611
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    from .read_write import WriteReadOnlyFileDescriptor

    class MyWritableFile(WritableStream):
        def __init__(self, fd):
            self.fd = fd
        def write(self, s):
            return self.fd.write(s)

    for stream in sys.stdout, sys.stderr:

        class MyWritableStream(WritableStream):
            def write(self, s):
                fd = stream.fileno()
                os.write(fd, s.encode('utf-8'))

        writable_stream = MyWritableStream()

        writable_stream.write('hi')

        fd = io.open(os.dup(stream.fileno()), mode='w', encoding='utf-8')

        writable_file_descriptor = WriteReadOnlyFile

# Generated at 2022-06-20 12:46:12.322626
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr("abcde") == "abcde"
    assert get_shortish_repr("abcde", max_length=2) == "ab..."
    assert get_shortish_repr("abcde", max_length=3) == "ab..."
    assert get_shortish_repr("abcde", max_length=4) == "ab..."
    assert get_shortish_repr("abcde", max_length=5) == "abcde"
    assert get_shortish_repr("abcde", max_length=6) == "abcde"
    assert get_shortish_repr("abcde\nfghi\njkl", max_length=10) == "abcde fghi jkl"


# Generated at 2022-06-20 12:46:15.715567
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class W(WritableStream):
        def write(self, s):
            pass

    assert issubclass(W, WritableStream)
    assert issubclass(W, ABC)
    assert isinstance(W(), WritableStream)



# Generated at 2022-06-20 12:46:22.863338
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Dummy(WritableStream):
        def write(self, s): pass
    assert issubclass(Dummy, WritableStream)

    class Dummy2:
        def write(self, s): pass
    assert not issubclass(Dummy2, WritableStream)

    class Dummy3(WritableStream):
        def lala(self, s): pass
    assert not issubclass(Dummy3, WritableStream)

# Generated at 2022-06-20 12:46:29.852948
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 5) == '12345...'
    assert truncate('123456789', 7) == '1234567...'
    assert truncate('123456789', 8) == '12345678...'
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 10) == '123456789'
    assert truncate('123456789', None) == '123456789'



# Generated at 2022-06-20 12:46:33.452305
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple({1, 2, 3}) == (1, 2, 3)
    assert ensure_tuple(object()) == (object(),)



# Generated at 2022-06-20 12:46:36.334044
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple(set([1, 2])) == (1, 2)

# Generated at 2022-06-20 12:46:38.202495
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'באהל אברהם שלמה היה') == '?????? ?????? ?????'



# Generated at 2022-06-20 12:46:42.140508
# Unit test for constructor of class WritableStream
def test_WritableStream():
    WritableStream.register(object)
    assert issubclass(object, WritableStream)
    assert not issubclass(list, WritableStream)
    assert not issubclass(list, WritableStream)
    assert not issubclass(str, WritableStream)
    assert issubclass(sys.stdout, WritableStream)

# Generated at 2022-06-20 12:46:51.328336
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass

    assert get_repr_function(1, ((int, lambda x: '<int>'),)) == '<int>'
    assert get_repr_function(A(), ((A, lambda x: '<A>'), (B, lambda x: '<B>'))) == '<A>'
    assert get_repr_function(B(), ((A, lambda x: '<A>'), (B, lambda x: '<B>'))) == '<B>'
    assert get_repr_function(1, ((int, lambda x: '<int>'),)) == '<int>'
    assert get_repr_function(1, ((int, lambda x: '<int>'), (float, lambda x: '<float>'))) == '<int>'

# Generated at 2022-06-20 12:46:57.856719
# Unit test for function get_repr_function
def test_get_repr_function():

    assert get_repr_function([2, 3], custom_repr=()) == repr
    assert get_repr_function([2, 3], custom_repr=[(list, 'lol')]) == 'lol'
    assert get_repr_function([2, 3], custom_repr=[(list, 'lol'), (int, '2')]) == 'lol'
    assert get_repr_function(2, custom_repr=[(list, 'lol'), (int, '2')]) == '2'
    assert get_repr_function(None, custom_repr=[(list, 'lol'), (int, '2')]) == repr

    assert get_repr_function(1, custom_repr=[(lambda x: x % 2 == 0, id)]) == id