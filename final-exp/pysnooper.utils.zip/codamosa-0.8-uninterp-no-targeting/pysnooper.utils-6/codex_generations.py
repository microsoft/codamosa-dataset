

# Generated at 2022-06-20 12:38:17.180054
# Unit test for function truncate
def test_truncate():

    assert truncate('abc', None) == 'abc'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 2) == 'ab'
    assert truncate('abc', 5) == 'abc'
    assert truncate('abc', 1) == 'a'
    assert truncate('abc', 0) == ''
    assert truncate('abcd', 2) == 'a...'



# Generated at 2022-06-20 12:38:19.057427
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X(WritableStream):
        pass
    try:
        X()
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-20 12:38:24.536547
# Unit test for constructor of class WritableStream
def test_WritableStream():
    """
    This tests the constructor of class `WritableStream` by making sure it's
    not possible to create a subclass that doesn't implement `write` but
    still gets recognized as a `WritableStream`.
    """
    class A:
        pass

    assert not issubclass(A, WritableStream)

    class B(A):
        write = None

    assert not issubclass(B, WritableStream)

    class C(A):
        def write(self, s):
            pass

    assert issubclass(C, WritableStream)



# Generated at 2022-06-20 12:38:26.578301
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X(WritableStream):
        def write(self, s):
            pass

    assert issubclass(X, WritableStream)



# Generated at 2022-06-20 12:38:29.712778
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    A()
    assert isinstance(A(), WritableStream)



# Generated at 2022-06-20 12:38:35.109292
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(2) == (2,)
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(range(3)) == (0, 1, 2)
    assert ensure_tuple((3, 6, 9)) == (3, 6, 9)



# Generated at 2022-06-20 12:38:38.790593
# Unit test for function truncate
def test_truncate():
    assert truncate('abcde', None) == 'abcde'
    assert truncate('abcde', 1) == 'a'
    assert truncate('abcde', 2) == 'a'
    assert truncate('abcde', 3) == 'a'
    assert truncate('abcde', 4) == 'ab'
    assert truncate('abcde', 5) == 'abcde'
    assert truncate('abcde', 6) == 'abcde'



# Generated at 2022-06-20 12:38:48.907372
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo(object): pass
    class Bar(object): pass
    class Baz(object): pass

    foos = (Foo(), Foo())
    bars = (Bar(),)
    bazs = (Baz(),)

    def custom_repr_for_foo(x):
        assert isinstance(x, Foo)
        return 'foo'

    def custom_repr_for_bar_and_baz(x):
        assert isinstance(x, (Bar, Baz))
        return 'bar-or-baz'

    def custom_repr_condition_function(x):
        return x is foos

    assert get_repr_function(foos,
                             (custom_repr_condition_function,
                              custom_repr_for_foo)) is custom_repr_for_foo

    assert get_

# Generated at 2022-06-20 12:38:57.087069
# Unit test for function normalize_repr
def test_normalize_repr():
    from .defcon import defcon
    from .defcon.selector import Selector
    from .defcon.condition import Condition

    d = defcon('d')
    d.custom_repr = (
        (isinstance, normalize_repr),
        (lambda x: isinstance(x, Selector), lambda x: 'selector'),
        (lambda x: isinstance(x, Condition), lambda x: 'condition'),
    )

# Generated at 2022-06-20 12:39:00.662291
# Unit test for function shitcode
def test_shitcode():
    for c in range(256):
        c = chr(c)
        assert shitcode(c) == c
    for c in '\u2714\u2716\u2718':
        assert shitcode(c) == '?'



# Generated at 2022-06-20 12:39:08.601913
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from io import StringIO
    from .pycompat import StringIO as StringIO_Python2
    StringIO_Python2 = StringIO_Python2()


    assert isinstance(StringIO(), WritableStream)
    assert isinstance(StringIO_Python2, WritableStream)




# Generated at 2022-06-20 12:39:13.909241
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<function repr at 0x923fa4>') == '<function repr>'
    assert normalize_repr('<function repr at 0x923fa4>') != '<function repr at 0x123>'
    assert normalize_repr('<function repr at 0x923fa4>') != '<function repr at 0x7f892d74>'

# Generated at 2022-06-20 12:39:15.817276
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class FakeFile(WritableStream):
        def write(self):
            pass
    FakeFile()

# Generated at 2022-06-20 12:39:26.320241
# Unit test for function get_repr_function
def test_get_repr_function():
    import pytest

    assert get_repr_function(1, ()) == repr
    assert get_repr_function('a', ()) == repr
    assert get_repr_function((1, 2), ()) == repr

    assert get_repr_function(1, ((int, str), lambda x: 'woof')) == repr
    assert get_repr_function('a', ((int, str), lambda x: 'woof')) == repr
    assert get_repr_function((1, 2), ((int, str), lambda x: 'woof')) == repr

    assert get_repr_function(1, ((lambda x: isinstance(x, int), str),
                                 lambda x: 'woof')) == 'woof'

# Generated at 2022-06-20 12:39:35.528770
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('shit') == 'shit'
    assert shitcode(u'\u00f8') == '?'
    assert shitcode(u'\ue7e8') == '?' # This character is outside the ASCII range
    assert shitcode(u'\ue000') == u'\ue000' # This character is inside the ASCII range
    assert shitcode(u'\U000FFFFE') == '?'
    assert shitcode(u'\U000FFFFF') == '?'
    assert shitcode(u'\U00100000') == u'\U00100000'
    assert shitcode(u'\U0010FFFF') == u'\U0010FFFF'

# Generated at 2022-06-20 12:39:45.370577
# Unit test for function truncate
def test_truncate():
    assert truncate(u'abcde', max_length=None) == u'abcde'
    assert truncate(u'abcde', max_length=5) == u'abcde'
    assert truncate(u'abcde', max_length=4) == u'abcd...'
    assert truncate(u'abcde', max_length=3) == u'a...'
    assert truncate(u'abcde', max_length=2) == u'...'
    assert truncate(u'abcde', max_length=1) == u'...'
    assert truncate(u'abcde', max_length=0) == u'...'
    assert truncate(u'abcde', max_length=-1) == u'...'

# Generated at 2022-06-20 12:39:53.862554
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 3) == '123...789'
    assert truncate('123456789', 4) == '1234...789'
    assert truncate('123456789', 5) == '12345...789'
    assert truncate('123456789', 6) == '12345...789'
    assert truncate('123456789', 7) == '1234567...789'
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 10) == '123456789'
    assert truncate('123456789', 11) == '123456789'
    assert truncate('1234567', 3) == '123...7'

# Generated at 2022-06-20 12:39:55.619502
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyStream(WritableStream):
        def write(self, s):
            pass
    assert isinstance(MyStream(), WritableStream)

# Generated at 2022-06-20 12:40:00.314251
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hi') == 'hi'
    assert shitcode('hi\x7f') == 'hi?'
    assert shitcode('hi\xb3') == 'hi?'
    assert shitcode(u'\u2122') == '?'

# Generated at 2022-06-20 12:40:08.661492
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    '''
    Test that the `write` method of `WritableStream` is abstract.
    '''
    class NotWritableStream:
        pass
    assert issubclass(NotWritableStream, WritableStream)

    class NoMethod(WritableStream):
        pass
    assert issubclass(NoMethod, WritableStream)

    class WritableStreamWithNone(WritableStream):
        write = None
    assert issubclass(WritableStreamWithNone, WritableStream)

    class WritableStreamWithMethod(WritableStream):
        def write(self, x):
            pass
    assert issubclass(WritableStreamWithMethod, WritableStream)

# Generated at 2022-06-20 12:40:14.932660
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Object(object):
        def __init__(self, write_output):
            self.write_output = write_output

        def write(self, s):
            self.write_output.append(s)

    write_output = []

    file_object = Object(write_output)
    assert isinstance(file_object, WritableStream)

    file_object.write('bye bye')
    assert write_output == ['bye bye']

# Generated at 2022-06-20 12:40:17.793011
# Unit test for function shitcode
def test_shitcode():
    shit_code_1 = shitcode('\U0001F6B2') # 🚲
    assert shit_code_1 == '?'
    shit_code_2 = shitcode('\x0d')      # CR
    assert shit_code_2 == '?'


if __name__ == '__main__':

    test_shitcode()

    import doctest
    doctest.testmod()

# Generated at 2022-06-20 12:40:27.810891
# Unit test for function normalize_repr
def test_normalize_repr():
    repr_example = repr(set([1,2,3]))
    assert repr_example == 'set([1, 2, 3])'

    repr_example_truncated = repr_example[:-7] + '...'
    assert repr_example_truncated == 'set([1, 2, ...'

    repr_example_normalized = normalize_repr(repr_example)
    assert repr_example_normalized == 'set([1, 2, 3])'

    repr_example_normalized_truncated = normalize_repr(repr_example_truncated)
    assert repr_example_normalized_truncated == 'set([1, 2, ...'



# Generated at 2022-06-20 12:40:34.449139
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple((1, (2, 3))) == (1, (2, 3))
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('asdf') == ('asdf',)



# Generated at 2022-06-20 12:40:36.725244
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Dummy(object):
        pass
    assert issubclass(Dummy, WritableStream)



# Generated at 2022-06-20 12:40:39.955923
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert hasattr(sys.stdout, 'write')
    assert isinstance(sys.stdout, WritableStream)
    with open('test_WritableStream_write.txt', 'w'):
        pass
    assert isinstance(open('test_WritableStream_write.txt', 'w'), WritableStream)

# Generated at 2022-06-20 12:40:41.846892
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Writable(WritableStream):
        def write(self, s):
            pass
    assert issubclass(Writable, WritableStream)



# Generated at 2022-06-20 12:40:50.521598
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(
        'hello world',
        max_length=None,
        normalize=False,
    ) == 'hello world'

    assert get_shortish_repr(
        'hello world',
        max_length=10,
        normalize=False,
    ) == 'hello wo...'

    assert get_shortish_repr(
        'hello world',
        max_length=4,
        normalize=False,
    ) == 'hel...'

    assert get_shortish_repr(
        'hello world',
        max_length=None,
        normalize=True,
    ) == 'hello world'


# Generated at 2022-06-20 12:41:00.145940
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(WritableStream, object)
    assert issubclass(WritableStream, ABC)
    assert not issubclass(object, WritableStream)
    assert not issubclass(ABC, WritableStream)

    import io
    assert issubclass(io.IOBase, WritableStream)
    assert not issubclass(io.IOBase, object)
    assert not issubclass(io.IOBase, ABC)

    class A(object):
        def write(self):
            pass

    assert issubclass(A, WritableStream)

    class B(ABC):
        def write(self):
            pass

    assert issubclass(B, WritableStream)
    assert not issubclass(object, B)
    assert not issubclass(ABC, B)


# Generated at 2022-06-20 12:41:08.732838
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmn', 3) == 'abc'
    assert truncate('abcdefghijklmn', 5) == 'abcde'
    assert truncate('abcdefghijklmn', 7) == 'abcdefg'
    assert truncate('abcdefghijklmn', 9) == 'abcdefghi'
    assert truncate('abcdefghijklmn', 100) == 'abcdefghijklmn'
    assert truncate('abcdefghijklmn', None) == 'abcdefghijklmn'
    assert truncate('abcdefghijklmn', 0) == ''

# Generated at 2022-06-20 12:41:13.192807
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X:
        def write(self, s): pass
    assert issubclass(X, WritableStream)



# Generated at 2022-06-20 12:41:15.744774
# Unit test for function ensure_tuple
def test_ensure_tuple():
    class X():
        def __iter__(self):
            yield 1
            yield 2
        
    x = X()
    
    assert ensure_tuple(x) == (1, 2)
    
    
    
    

# Generated at 2022-06-20 12:41:26.955161
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyStream(WritableStream):
        def write(self, s):
            """My stream's write method"""
            pass

    assert issubclass(MyStream, WritableStream)

    class MyOtherStream(WritableStream):
        pass

    try:
        assert issubclass(MyOtherStream, WritableStream)
    except TypeError:
        print('OK')
    else:
        raise AssertionError('Expected an exception.')

    # Note that this is using the `__subclasshook__` method of `WritableStream`,
    # which is used by `issubclass` to check.
    class MyOtherStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyOtherStream, WritableStream)


# Generated at 2022-06-20 12:41:31.521069
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('1') == '1'
    assert normalize_repr('1 at 0xF0F0') == '1'
    assert normalize_repr('1 at 0xF0F0 at 1') == '1 at 1'
    assert normalize_repr('1 at 0xF0F0 at 1 at 0xF0F0') == '1 at 1'
    assert normalize_repr('1 at 0xF0F0 at 1 at 0xF0F0F0') == '1 at 1 at 0xF0F0F0'

# Generated at 2022-06-20 12:41:40.269087
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .test_tools import assert_equal

    assert_equal(get_shortish_repr(5), '5')
    assert_equal(get_shortish_repr(5, max_length=3), '5')
    assert_equal(get_shortish_repr('abcdefghijklmnopqrstuvwxyz'),
                 'abcdefghijklmnopqrstuvwxyz')
    assert_equal(get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=3),
                 'abcdefghijklmnopqrstuvwxyz')
    assert_equal(get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=4),
                 'abcd...xyz')



# Generated at 2022-06-20 12:41:43.169724
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C:
        def write(self, s):
            return s + '\n'
    c = C()
    assert issubclass(C, WritableStream)
    assert c.write('hey') == 'hey\n'



# Generated at 2022-06-20 12:41:54.449558
# Unit test for function get_repr_function
def test_get_repr_function():
    from .tests.test_toolz import A, B, C
    assert get_repr_function(A(), ()) == repr
    assert get_repr_function(B(), ()) == repr
    assert get_repr_function(C(), ()) == repr

# Generated at 2022-06-20 12:42:00.124753
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('foobar') == 'foobar'
    assert shitcode('baz\u1234') == 'baz?'
    assert shitcode('baz\xfc') == 'baz?'


if sys.version_info[:2] >= (3, 4):
    class ContextDecorator(ABC):
        @abc.abstractmethod
        def __enter__(self):
            pass

        @abc.abstractmethod
        def __exit__(self, exc_type, exc_value, traceback):
            pass

        @classmethod
        def __subclasshook__(cls, C):
            if cls is ContextDecorator:
                if _check_methods(C, '__enter__', '__exit__'):
                    return True
            return NotImplemented

# Generated at 2022-06-20 12:42:09.448266
# Unit test for function normalize_repr
def test_normalize_repr():
    class A(object): pass
    a = A()
    assert normalize_repr(repr(a)) == repr(a)
    assert normalize_repr('blah at 0x1234') == 'blah'
    assert normalize_repr('blah at 0x1234567890') == 'blah'
    assert normalize_repr('blah at 0x123456') == 'blah'
    assert normalize_repr('blah at 0x1234567890ef') == 'blah'
    assert normalize_repr('blah at 0x1234567890ef1234') == 'blah'



# Generated at 2022-06-20 12:42:12.438461
# Unit test for function shitcode
def test_shitcode():
    for c in map(chr, range(256)):
        assert shitcode(c) == c
    for c in map(chr, range(256, 2 ** 16)):
        assert shitcode(c) == '?'



# Generated at 2022-06-20 12:42:18.382630
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple((5,)) == (5,)
    assert ensure_tuple([5]) == (5,)
    assert ensure_tuple(((5,),)) == ((5,),)



# Generated at 2022-06-20 12:42:28.414029
# Unit test for function normalize_repr
def test_normalize_repr():
    from .constants import __version__
    from . import project_versions
    assert normalize_repr("'sweet-and-sour' at 0x7f4d69bb9780") == \
                                                      "'sweet-and-sour'"
    assert normalize_repr("'sweet-and-sour' at 0x7f4d69bb9780a") == \
                                                      "'sweet-and-sour'"
    assert normalize_repr("'sweet-and-sour' at 0x7f4d69bb97") == \
                                                      "'sweet-and-sour'"
    assert normalize_repr("'sweet-and-sour' at 0X7F4D69BB9780") == \
                                                      "'sweet-and-sour'"

# Generated at 2022-06-20 12:42:31.694162
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('hi') == ('hi',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((3, 4)) == (3, 4)
    assert ensure_tuple([5, 6]) == (5, 6)



# Generated at 2022-06-20 12:42:37.184654
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def write(self, s):
            assert isinstance(s, str)
    class B(WritableStream):
        def foo(self):
            pass
    class C(WritableStream):
        pass
    assert issubclass(A, WritableStream)
    assert not issubclass(B, WritableStream)
    assert not issubclass(C, WritableStream)

# Generated at 2022-06-20 12:42:43.617449
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def write(self, s):
            pass

    class B:
        def write(self, s):
            pass

    class C(A, B):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)
    assert not issubclass(C, WritableStream)

# Generated at 2022-06-20 12:42:50.627538
# Unit test for function truncate
def test_truncate():
    assert truncate('foo bar', None) == 'foo bar'
    assert truncate('foo bar', 100) == 'foo bar'
    assert truncate('foo bar', 6) == 'foo...'
    assert truncate('foo bar', 2) == 'fo...'
    assert truncate('foo bar', 1) == '...'
    assert truncate('foo bar', 0) == '...'
    assert truncate('foo bar', -1) == '...'
    assert truncate('foo bar', 5) == 'foo ...'
    assert truncate('foo bar', 4) == 'foo ...'
    assert truncate('foo bar', 3) == 'foo ...'
    assert truncate('foo bar', 2) == 'fo...'
    assert truncate('foo bar', 1) == '...'
    assert truncate('foo bar', 0)

# Generated at 2022-06-20 12:43:01.681911
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert \
        get_shortish_repr('abc') == 'abc'
    assert \
        get_shortish_repr('x' * 100) == 'x' * 100
    assert \
        get_shortish_repr('x' * 100, max_length=100) == 'x' * 100
    assert \
        get_shortish_repr('x' * 100, max_length=33) == 'x' * 30 + '...'
    assert \
        get_shortish_repr([1, 2, 3], max_length=100,
                                                 normalize=True) \
                                                           == '[1, 2, 3]'
    assert \
        get_shortish_repr([1, 2, 3], max_length=5,
                                                 normalize=True) \
                                                

# Generated at 2022-06-20 12:43:03.203789
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import sys

    assert isinstance(sys.stdout, WritableStream)

# Generated at 2022-06-20 12:43:10.836553
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('pigdog', ()) is repr
    assert get_repr_function(8.22, []) is repr
    assert get_repr_function('pigdog', [(str, str)]) is str
    assert get_repr_function(8.22, [(str, str)]) is repr
    assert get_repr_function('pigdog', [(str, str), (bool, bool)]) is str
    assert get_repr_function('pigdog', [(int, int), (bool, bool)]) is repr
    assert get_repr_function(True, [(int, int), (bool, bool)]) is bool
    assert get_repr_function(8.22, [(int, int), (bool, bool)]) is repr

# Generated at 2022-06-20 12:43:19.908557
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('混乱') == '??'
    assert shitcode('\x00\x01\x02') == '\x00\x01\x02'
    assert shitcode('\x80\x81\x82') == '??'
    assert shitcode('\x00\x01\x02混乱') == '\x00\x01\x02??'
    assert shitcode('混乱\x00\x01\x02') == '??\x00\x01\x02'
    assert shitcode('混\x00乱\x01\x02') == '混\x00乱\x01\x02'

# Generated at 2022-06-20 12:43:32.226065
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [
        (lambda x: isinstance(x, int), lambda x: 'heh'),
        (lambda x: isinstance(x, list), repr),
    ]
    assert get_repr_function(1, custom_repr) == 'heh'
    assert get_repr_function([1,2], custom_repr) == repr
    assert get_repr_function((1, 2, 3), custom_repr) == repr
    custom_repr.append(
        (lambda x: True, 'heh')
    )
    assert get_repr_function((1, 2, 3), custom_repr) == 'heh'

# Generated at 2022-06-20 12:43:37.167196
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = []
        def write(self, s):
            self.written.append(s)

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('abc')
    my_writable_stream.write('def')
    assert my_writable_stream.written == ['abc', 'def']



# Generated at 2022-06-20 12:43:42.595860
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.contents = ''
        def write(self, s):
            self.contents += s
        def flush(self):
            self.contents = ''
    my_writable_stream = MyWritableStream()
    my_writable_stream.write('meow')
    assert my_writable_stream.contents == 'meow'
    my_writable_stream.flush()
    assert my_writable_stream.contents == ''
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-20 12:43:54.472799
# Unit test for function normalize_repr
def test_normalize_repr():
    """Test normalize_repr inside the test_writer module"""
    from types import SimpleNamespace
    a = SimpleNamespace()
    a.foo = 42
    a.bar = 'baz'
    a.glob = [1, 2, 3]
    assert normalize_repr("<test_writer.test.test_normalize_repr.<locals>.<lambda> object at 0x7fbc15bc5f60>") == "<test_writer.test.test_normalize_repr.<locals>.<lambda>>"
    assert normalize_repr("<class 'types.SimpleNamespace'>") == "<class 'types.SimpleNamespace'>"

# Generated at 2022-06-20 12:44:01.669881
# Unit test for function ensure_tuple
def test_ensure_tuple():
    a = 'b'
    b = [1, 2]
    c = ('a', 'b', 'c')
    d = set(['a', 'b'])
    e = (1, 2, 3)
    assert ensure_tuple(a) == ('b',)
    assert ensure_tuple(b) == (1, 2)
    assert ensure_tuple(c) == ('a', 'b', 'c')
    assert ensure_tuple(d) == ('a', 'b')
    assert ensure_tuple(e) == (1, 2, 3)




# Generated at 2022-06-20 12:44:05.889711
# Unit test for function truncate
def test_truncate():
    assert truncate('', 5) == ''
    assert truncate('a', 5) == 'a'
    assert truncate('abcde', 5) == 'abcde'
    assert truncate('abcdef', 5) == 'a...f'
    assert truncate('abcdef', 4) == 'a...f'
    assert truncate('abcdef', 3) == 'abcdef'
    assert truncate('abcdef', 2) == 'abcdef'
    assert truncate('abcdef', 1) == 'abcdef'

    assert truncate((1, 2, 3), 5) == (1, 2, 3)
    assert truncate(range(5), 5) == range(5)
    assert truncate((1, 2, 3, 4, 5, 6), 5) == (1, 2, 3, 4, 5, 6)
    assert trunc

# Generated at 2022-06-20 12:44:10.493956
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('שלום') == '?????'
    assert shitcode('abc\x00\x00\x00') == 'abc???'
    assert shitcode(chr(255)) == '?'
    assert shitcode(chr(0)) == '?'





# Generated at 2022-06-20 12:44:22.061146
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(10, ()) is repr
    assert get_repr_function('a', ()) is repr
    assert get_repr_function(True, ()) is repr
    assert get_repr_function(False, ()) is repr
    assert get_repr_function(None, ()) is repr
    assert get_repr_function(0.5, ()) is repr
    assert get_repr_function(1j, ()) is repr
    assert get_repr_function([1], ()) is repr
    assert get_repr_function(set(), ()) is repr
    assert get_repr_function({1}, ()) is repr
    assert get_repr_function((1,), ()) is repr
    assert get_repr_function(set([1, 2]), ()) is repr

# Generated at 2022-06-20 12:44:26.509668
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('hey') == ('hey',)
    assert ensure_tuple(('hey',)) == ('hey',)
    assert ensure_tuple(['hey']) == ('hey',)
    assert ensure_tuple([]) == ()
    assert ensure_tuple(123) == (123,)
    assert ensure_tuple(range(3)) == (0, 1, 2)
    assert ensure_tuple(x for x in range(3)) == (0, 1, 2)



# Generated at 2022-06-20 12:44:32.213603
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr('hello', max_length=4) == 'hel...'
    assert get_shortish_repr('hello', max_length=5) == 'hello'
    assert get_shortish_repr('hello', max_length=7) == 'hello'





# Generated at 2022-06-20 12:44:44.131408
# Unit test for function get_repr_function
def test_get_repr_function():
    def func1(thing):
        return 'func1'
    def func2(thing):
        return 'func2'
    def func3(thing):
        return 'func3'
    reprs = (
        (1, func1),
        (lambda x: x == 'b', func2),
        (True, func3),
    )
    assert get_repr_function(1, reprs) is func1
    assert get_repr_function('b', reprs) is func2
    assert get_repr_function('c', reprs) is not func2
    assert get_repr_function('b', reprs) is not func1
    assert get_repr_function('c', reprs) is func3

# Generated at 2022-06-20 12:44:45.509989
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .stringio import StringIO

    assert isinstance(StringIO(), WritableStream)

# Generated at 2022-06-20 12:44:53.652615
# Unit test for function get_repr_function
def test_get_repr_function():

    assert get_repr_function(
        1,
        custom_repr=(
            (lambda _: True, lambda _: 'wow'),
            (lambda _: False, lambda _: 'not wow'),
        )
    ) is str

    assert get_repr_function(
        'a',
        custom_repr=(
            (lambda _: True, lambda _: 'wow'),
            (lambda _: False, lambda _: 'not wow'),
        )
    ) is str

    assert get_repr_function(
        object(),
        custom_repr=(
            (lambda _: True, lambda _: 'wow'),
            (lambda _: False, lambda _: 'not wow'),
        )
    ) is str


# Generated at 2022-06-20 12:45:04.652073
# Unit test for function truncate
def test_truncate():
    assert truncate(u'אבגד', 7) == u'אבגד'
    assert truncate(u'אבגדהוזח', 7) == u'אב...ח'
    assert truncate(u'אבגדהוזח', 10) == u'אבגדהוזח'
    assert truncate(u'אבגד', 3) == u'א...'
    assert truncate(u'אבגד', 1) == u'...'
    assert truncate(u'אבגד', None) == u'אבגד'
    assert truncate(u'אבגד', 0) == u'...'

# Generated at 2022-06-20 12:45:10.154749
# Unit test for function truncate
def test_truncate():
    assert truncate('12345', 4) == '123...'
    assert truncate('12345', 5) == '12345'
    assert truncate('12345', 6) == '12345'
    assert truncate('1234567', 7) == '123...7'
    assert truncate('1234567', 8) == '1234567'
    assert truncate('1234567', 9) == '1234567'



# Generated at 2022-06-20 12:45:13.400643
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert isinstance(ensure_tuple(5), tuple)
    assert ensure_tuple(5)[0] == 5
    assert isinstance(ensure_tuple([5, 7]), tuple)
    assert ensure_tuple([5, 7])[0] == 5
    assert ensure_tuple([5, 7])[1] == 7

# Generated at 2022-06-20 12:45:22.814974
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeStringIO(WritableStream):
        def __init__(self):
            self.s = ''

        def write(self, s):
            self.s += s

    fake_string_io = FakeStringIO()
    assert fake_string_io.s == ''
    fake_string_io.write(u'abc')
    assert fake_string_io.s == u'abc'
    fake_string_io.write(u'def')
    assert fake_string_io.s == u'abcdef'


if __name__ == '__main__':
    test_WritableStream_write()
    print("All tests passed.")

# Generated at 2022-06-20 12:45:26.430284
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<@@@ at 0x4ab3d1b0>') == '<@@@>'
    assert normalize_repr('<@@@ at 0x4ab3d1b0') == '<@@@ at 0x4ab3d1b0'



# Generated at 2022-06-20 12:45:34.318095
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnop', max_length=None) == 'abcdefghijklmnop'
    assert truncate('abcdefghijklmnop', max_length=0) == ''
    assert truncate('', max_length=0) == ''
    assert truncate('', max_length=1) == ''
    assert truncate('', max_length=2) == ''
    assert truncate('', max_length=3) == ''
    assert truncate('abcdefghijklmnop', max_length=1) == 'a'
    assert truncate('abcdefghijklmnop', max_length=2) == 'a.'
    assert truncate('abcdefghijklmnop', max_length=3) == 'a..'

# Generated at 2022-06-20 12:45:37.601728
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u"hello") == u"hello"
    assert shitcode(u"זיו") == u"????"
    assert shitcode(u"วิดีโอ") == u"?????"
    assert shitcode(u"Привет") == u"?????"

# Generated at 2022-06-20 12:45:46.133046
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)




# Generated at 2022-06-20 12:45:54.880526
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(5, max_length=5) == '5'
    assert get_shortish_repr(5, max_length=4) == '5'
    assert get_shortish_repr(5, max_length=3) == '5'
    assert get_shortish_repr(5, max_length=2) == '...'
    assert get_shortish_repr(5, max_length=1) == '...'
    assert get_shortish_repr(5, max_length=0) == '...'

    assert get_shortish_repr('abc', max_length=6) == 'abc'
    assert get_shortish_repr('abc', max_length=5) == 'abc'

# Generated at 2022-06-20 12:46:05.587031
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class VeryLongRepr(object):
        def __repr__(self):
            return 'a' * 100

    assert get_shortish_repr('foo') == "'foo'"
    assert get_shortish_repr([1, 2, 3], max_length=7) == "[1, 2,...]"
    assert get_shortish_repr([1, 2, 3], max_length=6) == "[1, 2]"
    assert get_shortish_repr(VeryLongRepr(), max_length=7) == "REPR FAILED"
    assert get_shortish_repr(VeryLongRepr(), max_length=7, normalize=True) == \
                                                                       'REPR FAILED'

# Generated at 2022-06-20 12:46:11.568171
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('I am a string') == 'I am a string'
    assert normalize_repr('I am a string at 0x1234') == 'I am a string'
    assert normalize_repr('I am a string at 0xabcdef') == 'I am a string'
    assert normalize_repr('I am a string at 0xABCDEF') == 'I am a string'
    assert normalize_repr('I am a string at 0x123456789') == 'I am a string'
    assert normalize_repr('I am a string at 0xABCDEFgh') == 'I am a string'

# Generated at 2022-06-20 12:46:22.863493
# Unit test for function normalize_repr
def test_normalize_repr():
    reprs = ['<module \'builtins\' (built-in)>',
             '<module \'test_normalize_repr\' from \'test_normalize_repr.py\'>',
             '<module \'test_smart_repr\' from \'test_smart_repr.py\'>',
             '<function smart_repr at 0x7f1b8bbab488>',
             '<function test_smart_repr at 0x7f1b8bbab488>',
             '<function test_normalize_repr at 0x7f1b8bbab488>',
             '<function test_ensure_tuple at 0x7f1b8bba81e0>']
    for r in reprs:
        normalized_r = normalize_repr(r)

# Generated at 2022-06-20 12:46:30.631558
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, (
        (str, str),
        (int, int.__repr__),
    )) == repr

    assert get_repr_function(5, (
        (str, str),
        (int, str),
    )) == str

    f = lambda x: x

    assert get_repr_function(5, (
        (str, str),
        (lambda x: x, f),
    )) == f

    assert get_repr_function(5, (
        (lambda x: False, f),
    )) == repr

# Generated at 2022-06-20 12:46:32.886295
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abcd') == 'abcd'
    assert shitcode('abc\x04\x05\x06d') == 'abc???'



# Generated at 2022-06-20 12:46:39.850479
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    import math

    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr(False) == 'False'
    assert get_shortish_repr(math) == repr(math)
    assert get_shortish_repr(math, max_length=88) == truncate(repr(math), 88)
    assert get_shortish_repr([1, 2, 3], max_length=None) == repr([1,2,3])
    assert get_shortish_repr([1, 2, 3], max_length=10) == truncate(repr([1,2,3]), 10)

# Generated at 2022-06-20 12:46:46.049724
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s): pass
    assert issubclass(A, WritableStream)

    class B: pass
    assert not issubclass(B, WritableStream)

    a = A()
    assert isinstance(a, WritableStream)

    b = B()
    assert not isinstance(b, WritableStream)

    class C:
        def not_write(self, s): pass
        write = None
    assert not issubclass(C, WritableStream)

# Generated at 2022-06-20 12:46:51.655312
# Unit test for function truncate
def test_truncate():
    assert truncate(u'12345678', 5) == u'12345'
    assert truncate(u'12345', 5) == u'12345'
    assert truncate(u'12345678', 8) == u'12345678'
    assert truncate(u'12345678', 0) == u''
    assert truncate(u'12345678', None) == u'12345678'
    assert truncate(u'12345678', max_length=5) == u'12345'



# Generated at 2022-06-20 12:47:06.885304
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr(b'hello') == "b'hello'"
    assert get_shortish_repr(u'hello') == "'hello'"
    assert get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert get_shortish_repr((1, 2, 3)) == '(1, 2, 3)'
    assert get_shortish_repr(('a', 'bcd')) == "('a', 'bcd')"
    assert get_shortish_repr({(1, 2): 3, 4: 5}) == '{(1, 2): 3, 4: 5}'

# Generated at 2022-06-20 12:47:10.549570
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)
    a = A()
    isinstance(a, WritableStream)



# Generated at 2022-06-20 12:47:19.472203
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class WeirdRepr(object):
        def __repr__(self):
            return 'Hello' * 1000

    # Test that it works with the default repr
    assert get_shortish_repr(WeirdRepr()) == 'Hello' * 1000

    # Test that it works with a custom repr
    assert get_shortish_repr(WeirdRepr(), ((WeirdRepr, lambda x: 'Howdy'))) == 'Howdy'

    # Test that it truncates too long reprs
    assert get_shortish_repr(WeirdRepr(), max_length=10) == 'HelloHello...'

    # Test that it truncates too long custom reprs

# Generated at 2022-06-20 12:47:22.084505
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('asd') == 'asd'
    assert shitcode('asd\xd7\x91') == 'asd?\xd7\x91'

# Generated at 2022-06-20 12:47:25.208151
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(2) == (2,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple(xrange(1, 3)) == (1, 2)




# Generated at 2022-06-20 12:47:36.162285
# Unit test for function truncate
def test_truncate():
    assert truncate('', 3) == ''
    assert truncate('a', 3) == 'a'
    assert truncate('ab', 3) == 'ab'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abcd', 3) == '...'
    assert truncate('abcde', 3) == '...'
    assert truncate('abcde', 4) == 'a...'
    assert truncate('abcde', 5) == 'a...e'
    assert truncate('abcde', 6) == 'ab...e'
    assert truncate('life is what happens when you are making other plans') == \
                                  'life is what happens when you are making ' \
                                  'other plans'

# Generated at 2022-06-20 12:47:42.961282
# Unit test for function normalize_repr
def test_normalize_repr():
    from pytest import raises
    raises(AssertionError, normalize_repr, '1')
    raises(AssertionError, normalize_repr, '1 at 0x')
    assert normalize_repr('1 at 0x01') == '1'
    assert normalize_repr('1 at 0x01234') == '1'
    assert normalize_repr('1 at 0xabcd01234') == '1'
    assert normalize_repr('1 at 0x01234f') == '1'
    assert normalize_repr('1 at 0x01234F') == '1'

# Generated at 2022-06-20 12:47:51.914341
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(repr(3)) == '3'
    assert normalize_repr(repr(3)) == '3'
    assert normalize_repr(repr(3)) == '3'
    assert normalize_repr(repr(3)) == '3'
    assert normalize_repr(repr(3)) == '3'
    assert normalize_repr(repr(3)) == '3'
    assert normalize_repr(repr(3)) == '3'
    assert normalize_repr(repr(3)) == '3'
    assert normalize_repr(repr(3)) == '3'
    assert normalize_repr(repr(3)) == '3'
    assert normalize_repr(repr(3)) == '3'
   

# Generated at 2022-06-20 12:48:01.552644
# Unit test for function truncate
def test_truncate():
    assert truncate('a', 2) == 'a'
    assert truncate('ab', 2) == 'a...'
    assert truncate('abc', 2) == 'a...'
    assert truncate('abcd', 2) == 'a...'
    assert truncate('abcde', 2) == 'a...'
    assert truncate('abcdef', 2) == 'a...'
    assert truncate(u'abcdef', 2) == u'a...'

    assert truncate('he', 4) == 'he'
    assert truncate('hel', 4) == 'hel'
    assert truncate('hell', 4) == 'h...'
    assert truncate('hello', 4) == 'h...'
    assert truncate('hello world', 4) == 'h...'
    assert truncate(u'hello world', 4) == u

# Generated at 2022-06-20 12:48:05.811231
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class TestWritableStream(WritableStream):
        def __init__(self):
            self.written_objects = []
        def write(self, x):
            self.written_objects.append(x)
    a = TestWritableStream()
    a.write('hey')
    assert a.written_objects == ['hey']

