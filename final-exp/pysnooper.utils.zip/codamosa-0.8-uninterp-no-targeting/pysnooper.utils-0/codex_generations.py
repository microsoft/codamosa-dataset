

# Generated at 2022-06-20 12:38:17.530797
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(
        None,
        custom_repr=((lambda x: True, len),),
    ) == len
    assert get_repr_function(3) == repr
    assert get_repr_function(3.0, custom_repr=((float, len),)) == len
    assert get_repr_function(
        '',
        custom_repr=((lambda x: True, len),),
    ) == len



# Generated at 2022-06-20 12:38:19.684622
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .my_io import MyIO

    my_io = MyIO()
    assert isinstance(my_io, WritableStream)
    my_io.write('hello')

# Generated at 2022-06-20 12:38:25.162893
# Unit test for function ensure_tuple
def test_ensure_tuple():
    # Imports are here to avoid circular import issues:
    from .testing import TestCase

    class MyTestCase(TestCase):
        def test(self):
            self.assertEqual(ensure_tuple('hello'), ('hello',))
            self.assertEqual(ensure_tuple(('hello',)), ('hello',))
            self.assertEqual(ensure_tuple(iter('hello')), ('hello',))
            self.assertEqual(ensure_tuple(list('hello')), ['h', 'e', 'l', 'l',
                                                           'o'])
            self.assertEqual(ensure_tuple(x for x in 'hello'),
                             tuple('hello'))
            self.assertEqual(ensure_tuple(1), (1,))

# Generated at 2022-06-20 12:38:33.065106
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from six.moves import StringIO
    from six import PY2
    class WritableStream:
        def write(self, s):
            pass
    assert WritableStream.__subclasshook__(StringIO) is True
    if not PY2:
        import io
        assert WritableStream.__subclasshook__(io.StringIO) is True
    class WritableStream:
        def write(self):
            pass
    assert WritableStream.__subclasshook__(StringIO) is NotImplemented



# Generated at 2022-06-20 12:38:37.954267
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('bla') == 'bla'
    assert normalize_repr('bla ') == 'bla '
    assert normalize_repr(' bla') == ' bla'
    assert normalize_repr('bla at 0xFA') == 'bla'
    assert normalize_repr('bla at 0x12345') == 'bla'
    assert normalize_repr('bla at 0x1234567') == 'bla'
    assert normalize_repr('bla at 0x123456789') == 'bla'
    assert normalize_repr('bla at 0x1234567890') == 'bla'
    assert normalize_repr('bla at 0x1234567890A') == 'bla at 0x1234567890A'


# Generated at 2022-06-20 12:38:42.482042
# Unit test for function normalize_repr
def test_normalize_repr():
    from random import randint

    for _ in range(100):
        fake_address = '0x{:x}'.format(randint(10000, 1000000))
        assert normalize_repr(fake_address) == ''

    assert normalize_repr('something') == 'something'
    assert normalize_repr('somethingelse') == 'somethingelse'

# Generated at 2022-06-20 12:38:47.950441
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class SomeClass(object): pass
    class A(SomeClass):
        def write(self, s):
            pass
    class B(SomeClass): pass
    class C(B):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)
    assert issubclass(C, WritableStream)
    assert not issubclass(B, WritableStream)




# Generated at 2022-06-20 12:38:53.478318
# Unit test for function truncate
def test_truncate():
    assert truncate('hello!', 10) == 'hello!'
    assert truncate('hello!', 5) == 'hello!'
    assert truncate('hello!', 3) == '...'
    assert truncate('hello!', 2) == '...'
    assert truncate('hello!', 1) == '...'
    assert truncate('hello!', 0) == '...'
    assert truncate('hello!', -1) == '...'



# Generated at 2022-06-20 12:39:04.188687
# Unit test for function get_repr_function
def test_get_repr_function():
    import io
    import builtins
    class A: pass
    class B(A): pass
    class C(B): pass
    class E: pass
    class F(A): pass
    class G(A): pass
    def A_repr(x):
        return 'A'
    def E_repr(x):
        return 'E'
    def A_F_G_repr(x):
        if isinstance(x, F):
            return 'F'
        if isinstance(x, G):
            return 'G'
        return 'A'
    def abcdefg_repr(x):
        return ''.join(
            (c if (0 < ord(c) < 256) else '?') for c in repr(x)
        )
    def shitcode_repr(x):
        return

# Generated at 2022-06-20 12:39:06.166703
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('שלום') == '???'



# Generated at 2022-06-20 12:39:12.945095
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('fraky at 0x0123456789') == 'fraky'
    assert normalize_repr('fraky at 0x01234567890') == 'fraky'
    assert normalize_repr('fraky') == 'fraky'



# Generated at 2022-06-20 12:39:22.975692
# Unit test for function truncate
def test_truncate():
    assert truncate('', 0) == ''
    assert truncate('a', 1) == 'a'
    assert truncate('ab', 1) == 'a...'
    assert truncate('abc', 2) == 'a...'
    assert truncate('abcd', 3) == 'a...'
    assert truncate('abcde', 3) == 'a...'
    assert truncate('abcdef', 4) == 'ab...'
    assert truncate('abcdefg', 4) == 'a...g'
    assert truncate('abcdefgh', 5) == 'a...h'
    assert truncate('abcdefgh', 6) == 'ab...h'
    assert truncate('abcdefghi', 7) == 'ab...hi'



# Generated at 2022-06-20 12:39:25.787230
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(object):
        def write(self, s):
            raise NotImplementedError
    assert WritableStream.__subclasshook__(A) is True



# Generated at 2022-06-20 12:39:32.589783
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo:
        pass
    foo = Foo()
    assert get_repr_function(foo, []) is repr
    assert get_repr_function(foo, [(type(Foo()), str)]) is str
    assert get_repr_function(foo, [(Foo, str)]) is str
    assert get_repr_function(foo, [(type(Foo), str)]) is str
    assert get_repr_function(foo, [(lambda x: False, str)]) is repr
    assert get_repr_function(foo, [(lambda x: True, str)]) is str
    assert get_repr_function(12345, [(Foo, str)]) is repr


# Generated at 2022-06-20 12:39:39.810759
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', None) == 'abc'
    assert truncate('abc', 0) == 'abc'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 4) == 'abc'
    assert truncate('abc', 5) == 'abc'
    assert truncate('abc', 6) == 'abc'
    assert truncate('abc', 7) == 'abc'
    assert truncate('abc', 8) == 'abc'
    assert truncate('abc', 9) == 'abc'
    assert truncate('abc', 10) == 'abc'
    assert truncate('abc', 2) == '...'
    assert truncate('abc', 1) == '...'
    assert truncate('abc', 0) == '...'
    assert truncate('abc', -1) == '...'

# Generated at 2022-06-20 12:39:42.403030
# Unit test for function normalize_repr
def test_normalize_repr():

    from .test_tools import assert_equal

    class A(object): pass
    a = A()

    assert_equal(normalize_repr(repr(a)), repr(a))

# Generated at 2022-06-20 12:39:50.600663
# Unit test for function truncate

# Generated at 2022-06-20 12:39:58.352794
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello there') == "'hello there'"
    assert get_shortish_repr('hello there', max_length=13) == "'hello there'"
    assert get_shortish_repr('hello there', max_length=12) == "'hello th...'"
    assert get_shortish_repr('hello there', max_length=11) == "'hello ...'"
    assert get_shortish_repr('hello there', max_length=10) == "'hello ...'"
    assert get_shortish_repr('hello there', max_length=9) == "'hello ...'"
    assert get_shortish_repr('hello there', max_length=8) == "'he...'"

# Generated at 2022-06-20 12:40:05.788048
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijk', None) == 'abcdefghijk'
    assert truncate('abcdefghijk', 3) == 'abcdefghijk'
    assert truncate('abcdefghijk', 4) == 'a...k'
    assert truncate('abcdefghijk', 5) == 'a...k'
    assert truncate('abcdefghijk', 12) == 'abcdefghijk'
    assert truncate('abcdefghijk', 13) == 'abcdefghijk'



# Generated at 2022-06-20 12:40:09.455158
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)


from . import less_obnoxious_repr


# Generated at 2022-06-20 12:40:27.909669
# Unit test for function truncate
def test_truncate():
    assert truncate('', None) == ''
    assert truncate('asd', None) == 'asd'

    assert truncate('', 4) == ''
    assert truncate('asd', 4) == 'a...'
    assert truncate('asdf', 4) == 'as...'
    assert truncate('asdff', 4) == 'as...'

    assert truncate('asdf', 0) == '...'
    assert truncate('asdf', 1) == '...'
    assert truncate('asdf', 2) == '...'
    assert truncate('asdf', 3) == 'a...'
    assert truncate('asdf', 4) == 'as...'
    assert truncate('asdf', 5) == 'asdf'
    assert truncate('asdf', 6) == 'asdf'



# Generated at 2022-06-20 12:40:38.865871
# Unit test for function get_repr_function
def test_get_repr_function():
    def my_repr(x, b = False):
        return str(x) + ' ' + str(b)
    def f(x):
        return x % 2 == 0

    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(f, my_repr)]) == repr
    assert get_repr_function(2, [(f, my_repr)]) == my_repr
    assert get_repr_function(3, [(f, my_repr)]) == repr

    assert get_repr_function(1, [(int, my_repr)]) == repr
    assert get_repr_function(3, [(int, my_repr)]) == my_repr



# Generated at 2022-06-20 12:40:43.920894
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FileLikeObject(WritableStream):
        def write(self, s):
            pass
    FileLikeObject().write('hi')


# def print_to_object():
#     class A(object):
#         def __init__(self):
#             self.lines = []
#         def write(self, s):
#             self.lines.append(s)
#     sys.stdout = qb = A()
#     print('hi')
#     print(qb.lines)

# Generated at 2022-06-20 12:40:50.196005
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefg', None) == 'abcdefg'
    assert truncate('abcdefg', 3) == 'abcdefg'
    assert truncate('abcdefg', 7) == 'abcdefg'
    assert truncate('abcdefg', 8) == 'abcdefg'
    assert truncate('abcdefg', 9) == 'abc...fg'
    assert truncate('abcdefg', 10) == 'abc...fg'
    assert truncate('abcdefg', 11) == 'abc...g'
    assert truncate('abcdefg', 12) == 'abc...g'
    assert truncate('abcdefg', 13) == 'ab...g'
    assert truncate('abcdefg', 14) == 'ab...fg'
    assert truncate('abcdefg', 15) == 'ab...fg'
   

# Generated at 2022-06-20 12:40:54.606682
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('h\xef') == 'h?'
    assert shitcode('\xef') == '?'
    assert shitcode(u'\xef') == '?'
    assert shitcode(u'ab\xefc') == 'ab?c'

# Generated at 2022-06-20 12:40:56.418557
# Unit test for function normalize_repr
def test_normalize_repr():
    a = {'a': 'b'}
    assert normalize_repr(repr(a)) == '{' + repr('a') + ': ' + repr('b') + '}'



# Generated at 2022-06-20 12:41:04.036654
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MockedStdout(WritableStream):
        def write(self, string):
            self.stdout_buffer.append(string)

    mocked_stdout = MockedStdout()
    mocked_stdout.stdout_buffer = []

    # Opening the print function's stream
    stdout = sys.stdout
    sys.stdout = mocked_stdout
    print('hello', 'cow')
    print('hello', 'cow', end='!', sep=', ')
    print(file=mocked_stdout)

    # Closing the print function's stream
    sys.stdout = stdout

    # Asserting the result
    assert mocked_stdout.stdout_buffer == ['hello cow\n', 'hello, cow!\n', '\n']



# Generated at 2022-06-20 12:41:14.355971
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([1, 2, 3]) == '(1, 2, 3)'
    assert get_shortish_repr([1, [2], 3]) == '(1, [2], 3)'
    assert get_shortish_repr([1, [2, 3], 3]) == '(1, [2, ...], 3)'
    assert get_shortish_repr([1, [2, 3, 4], 3]) == '(1, [2, ...], 3)'
    assert get_shortish_repr([1, [2, 3, 4, 5], 3]) == '(1, [2, ...], 3)'
    assert get_shortish_repr(set([1, 3, 2])) == '{1, 2, 3}'

# Generated at 2022-06-20 12:41:16.722580
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc123') == 'abc123'
    assert shitcode('שלום') == '???'




# Generated at 2022-06-20 12:41:27.708542
# Unit test for function normalize_repr
def test_normalize_repr():
    class Test(object):
        pass
    test_object = Test()
    assert normalize_repr(repr(test_object)) == repr(test_object)
    test_object.some_attr = test_object
    assert normalize_repr(repr(test_object)) == repr(test_object)
    test_object.some_other_attr = 'some_value'
    assert normalize_repr(repr(test_object)) == repr(test_object)
    test_object.some_attr = 'something else'
    assert normalize_repr(repr(test_object)) == repr(test_object)
    test_object.some_other_attr = test_object
    assert normalize_repr(repr(test_object)) == repr(test_object)
    test_object.some_

# Generated at 2022-06-20 12:41:48.526582
# Unit test for function normalize_repr
def test_normalize_repr():
    normalize_repr_standard = re.compile(r"^<[a-zA-Z0-9_]+ at 0x[a-f0-9A-F]+>$")
    normalize_repr_with_dots = re.compile(r"^<[a-zA-Z0-9_]+ at 0x[a-f0-9A-F]+\.\.\.$")
    normalize_repr_nodots = re.compile(r"^<[a-zA-Z0-9_]+ at 0x[a-f0-9A-F]+[^.]$")
    for i in range(100):
        random_class = type('%i' % random.randint(0, sys.maxsize), (object,), {})
        obj = random_class()

# Generated at 2022-06-20 12:41:57.988653
# Unit test for function get_repr_function
def test_get_repr_function():
    from .test_python_toolbox import AssertIsSubclass
    from .test_python_toolbox.counter import Counter

    assert get_repr_function(1, custom_repr=()) == repr

# Generated at 2022-06-20 12:42:09.300456
# Unit test for function truncate
def test_truncate():
    assert truncate(u'123456789', 10) == u'123456789'
    assert truncate(u'123456789', 9) == u'123456789'
    assert truncate(u'123456789', 8) == u'123456789'
    assert truncate(u'123456789', 7) == u'123456789'
    assert truncate(u'123456789', 6) == u'123...9'
    assert truncate(u'123456789', 5) == u'12...9'
    assert truncate(u'123456789', 4) == u'1...9'
    assert truncate(u'123456789', 3) == u'...9'
    assert truncate(u'123456789', 2) == u'..9'

# Generated at 2022-06-20 12:42:17.346169
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(42, max_length=2) == '4'
    assert get_shortish_repr(42, max_length=3) == '42'
    assert get_shortish_repr(42, max_length=4) == '42'
    assert get_shortish_repr(42, max_length=5) == '42'

    assert get_shortish_repr(42, max_length=2, normalize=True) == '4'
    assert get_shortish_repr(42, max_length=3, normalize=True) == '42'
    assert get_shortish_repr(42, max_length=4, normalize=True) == '42'
    assert get_shortish_repr(42, max_length=5, normalize=True)

# Generated at 2022-06-20 12:42:21.832906
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abcdef') == 'abcdef'
    assert shitcode('צגק') == '???'
    assert shitcode('ץגק') == '???'
    assert shitcode('ץג') == '??'
    assert shitcode(unichr(0xffff)) == '?'

# Generated at 2022-06-20 12:42:26.455199
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X:
        pass
    assert WritableStream.register(X)
    x = X()
    assert issubclass(X, WritableStream)
    x.write = lambda s: print(s)
    assert isinstance(x, WritableStream)


if __name__ == '__main__':
    test_WritableStream()

# Generated at 2022-06-20 12:42:29.200295
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C(WritableStream):
        _last_written = None
        def write(self, s):
            self._last_written = s
    assert issubclass(C, WritableStream)
    c = C()
    c.write('meow')
    assert c._last_written == 'meow'
    assert not issubclass(object, WritableStream)

# Generated at 2022-06-20 12:42:31.010303
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('こんにちは') == '???????'
    assert shitcode('こんにちは'.encode('utf-8')) == 'こんにちは'

# Generated at 2022-06-20 12:42:31.682251
# Unit test for function truncate
def test_truncate():
    assert truncate('abcd', 3) == 'abc'

# Generated at 2022-06-20 12:42:33.781682
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import doctest
    return doctest.testmod()


if not hasattr(sys, 'maxsize'):
    print('Fixing maxsize in sys.')
    sys.maxsize = (1 << 31) - 1

# Generated at 2022-06-20 12:43:10.378146
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1fbc') == 'a????????????????????????bc'
    assert shitcode(u'a\u0100bc') == 'a?bc'
    assert shitcode(u'a\u0100bc'.encode('utf-8')) == 'a?bc'



# Generated at 2022-06-20 12:43:19.633251
# Unit test for function get_repr_function
def test_get_repr_function():

    class Class(object):
        pass

    class_instance = Class()

    assert get_repr_function(
        object(),
        custom_repr=(
            (Class, lambda x: 'Class'),
            ('object', lambda x: 'object'))
    ) is repr


# Generated at 2022-06-20 12:43:30.257601
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', None) == 'abc'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 2) == 'ab'
    assert truncate('abcdefg', 5) == 'abcde'
    assert truncate('abcdefg', 4) == 'a...g'
    assert truncate('abcdefg', 4) == 'a...g'
    assert truncate('abc', 1) == 'a'
    assert truncate('abcd', 3) == 'a..'
    assert truncate('abcd', 2) == 'a.'
    assert truncate('abcd', 1) == 'a'
    assert truncate('abcdefg', 1) == 'a'
    assert truncate('abcdefg', 2) == 'ab'

# Generated at 2022-06-20 12:43:38.959753
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class Item(object):
        def __repr__(self):
            return 'someitem'

    class Item2(object):
        def __repr__(self):
            return 'item number 2'

    custom_repr = (
        (lambda item: item == 'c', lambda item: 'customer'),
        (lambda item: item == 'd', lambda item: 'default')
    )
    assert get_shortish_repr('a', max_length=5) == 'a'
    assert get_shortish_repr('ab', max_length=5) == 'ab'
    assert get_shortish_repr('abc', max_length=5) == 'abc'
    assert get_shortish_repr('abcd', max_length=5) == 'abcd'
    assert get_shortish_repr

# Generated at 2022-06-20 12:43:45.560144
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class FakeStream(object):
        def __init__(self):
            self.has_write = False

        def write(self, s):
            self.has_write = True

    fake_stream = FakeStream()

    assert not fake_stream.has_write

    assert issubclass(FakeStream, WritableStream)
    assert issubclass(sys.stdout.__class__, WritableStream)

    fake_stream.write('hello')
    assert fake_stream.has_write

# Generated at 2022-06-20 12:43:46.605518
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(object):
        def write(self, s):
            pass
    assert isinstance(MyWritableStream(), WritableStream)

# Generated at 2022-06-20 12:43:49.949229
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """Tests `WritableStream.write`."""
    class TestStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(TestStream(), WritableStream)





# Generated at 2022-06-20 12:43:57.267904
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', 7) == '1234567...'
    assert truncate('1234567890', 8) == '123456...'
    assert truncate('123', 6) == '123'
    assert truncate('123', 5) == '123'
    assert truncate('123', 4) == '123'
    assert truncate('123', 3) == '123'
    assert truncate('123', 0) == ''
    assert truncate('123', -7) == ''
    assert truncate('123', None) == '123'


# Generated at 2022-06-20 12:43:58.794945
# Unit test for function normalize_repr
def test_normalize_repr():
    import sys
    assert normalize_repr(repr(sys.modules)) == "dict_keys([...])"

# Generated at 2022-06-20 12:44:05.415430
# Unit test for function ensure_tuple
def test_ensure_tuple():
    class C: pass
    class D(collections_abc.Iterable): pass
    class E(collections_abc.Iterable, string_types): pass
    assert ensure_tuple(C()) == (C(),)
    assert ensure_tuple(D()) == (D(),)
    assert ensure_tuple(E()) == (E(),)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(['a', 'b', 'c']) == ('a', 'b', 'c')
    assert ensure_tuple('a') == ('a',)



# Generated at 2022-06-20 12:44:33.347294
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(('woof',)) == ('woof',)
    assert ensure_tuple(('woof', 'meow')) == ('woof', 'meow')



# Generated at 2022-06-20 12:44:42.526955
# Unit test for function truncate
def test_truncate():
    assert truncate('', 1) == ''
    assert truncate('a', 1) == 'a'
    assert truncate('ab', 1) == 'a...'
    assert truncate('abc', 1) == 'a...'
    assert truncate('abcd', 1) == 'a...'
    assert truncate('abcde', 1) == 'a...'
    assert truncate('abcdef', 1) == 'a...'
    assert truncate('abcdefg', 1) == 'a...'
    assert truncate('abcdefgh', 1) == 'a...'
    assert truncate('abcdefghi', 1) == 'a...'
    assert truncate('abcdefghij', 1) == 'a...'

    assert truncate('', 2) == ''
    assert truncate('a', 2) == 'a'
   

# Generated at 2022-06-20 12:44:49.456590
# Unit test for function get_repr_function
def test_get_repr_function():
    class Custom(object):
        pass
    class Custom2(Custom):
        pass
    assert get_repr_function(None, ()) is repr
    assert get_repr_function(1, (Custom, str,)) is str
    def is_custom(x):
        return isinstance(x, Custom)
    assert get_repr_function(Custom(), ((is_custom, str,),)) is str
    assert get_repr_function(None, ((Custom, str,),)) is repr
    assert get_repr_function(Custom2(), ((Custom, str,),)) is str

# Generated at 2022-06-20 12:44:52.545296
# Unit test for function normalize_repr
def test_normalize_repr():
    class A(object):
        def __repr__(self):
            return '<A at 0x%x>' % id(self)
    a = A()
    assert normalize_repr(repr(a)) == '<A>'



# Generated at 2022-06-20 12:44:58.733528
# Unit test for function shitcode
def test_shitcode():
    non_ascii_character = u'\xfa'
    assert shitcode(u'a') == u'a'
    assert shitcode(non_ascii_character) == '?'
    assert shitcode(u'a' + non_ascii_character + u'b') == 'a?b'
    assert shitcode(non_ascii_character * 123) == '?' * 123



# Generated at 2022-06-20 12:45:03.740799
# Unit test for function truncate
def test_truncate():
    assert truncate('', 7) == ''
    assert truncate('abc', 7) == 'abc'
    assert truncate('abcdefg', 7) == 'abcdefg'
    assert truncate('abcdefgh', 7) == 'abc...gh'
    assert truncate('abcdefgh', 6) == 'abc...'
    assert truncate('nice code', 7) == 'ni...ode'

# Generated at 2022-06-20 12:45:08.327452
# Unit test for function truncate
def test_truncate():
    assert truncate('12345', 1) == '12345'
    assert truncate('12345', 6) == '12345'
    assert truncate('12345', 3) == '...'
    assert truncate('12345', 4) == '1...'
    assert truncate('12345', 5) == '12...'



# Generated at 2022-06-20 12:45:14.325085
# Unit test for function truncate
def test_truncate():
    assert truncate('123456', None) == '123456'
    assert truncate('123456', -1) == '123456'
    assert truncate('123456', 1) == '...'
    assert truncate('123456', 2) == '...'
    assert truncate('123456', 4) == '...'
    assert truncate('123456', 5) == '123...'
    assert truncate('123456', 8) == '123...456'
    assert truncate('123456', 9) == '123...456'
    assert truncate('123456', 10) == '123...456'
    assert truncate('123456', 11) == '123456'

# Generated at 2022-06-20 12:45:23.840606
# Unit test for function normalize_repr
def test_normalize_repr():
    assert(normalize_repr('hello') == 'hello')
    assert(normalize_repr('hello at 0x123') == 'hello')
    assert(normalize_repr('hello at 0x12345') == 'hello')
    assert(normalize_repr('hello at 0xAB1234') == 'hello')
    assert(normalize_repr('hello at 0x123456') == 'hello')
    assert(normalize_repr('hello at 0xABC123') == 'hello')
    assert(normalize_repr('hello at 0x1234567') == 'hello at 0x1234567')




# Generated at 2022-06-20 12:45:32.060570
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=0, normalize=True) == '1'
    assert get_shortish_repr(1, max_length=1, normalize=True) == '1'
    assert get_shortish_repr(1, max_length=5, normalize=True) == '1'
    assert get_shortish_repr('abc', max_length=5) == 'abc'
    assert get_shortish_re

# Generated at 2022-06-20 12:46:32.698445
# Unit test for function shitcode
def test_shitcode():
    def do_test(x,y):
        assert shitcode(x)==y
    examples = {
        'אב' : u'?\?',
        'abcd' : 'abcd',
        'אב\nגד' : u'?\?\n?\?',
        'א\nב\nג' : u'?\n?\n?',
        '\n\n' : '\n\n',
        '\t\t' : '\t\t',
    }
    for k,v in examples.items():
        do_test(k,v)
    # try other unicode encodings
    if sys.version_info[0]==2:
        utf8 = lambda x: x.encode('UTF-8')
        utf16 = lambda x: x

# Generated at 2022-06-20 12:46:34.689563
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        def write(self, s):
            print('write is called with', repr(s))

    assert isinstance(Foo(), WritableStream)




# Generated at 2022-06-20 12:46:40.210431
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    class B(A):
        pass

    assert issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)

    class F(A):
        def write(self, s):
            pass

    assert issubclass(F, WritableStream)

    class G(F):
        pass

    assert issubclass(G, WritableStream)

    class C:
        def write(self, s):
            pass

    assert not issubclass(C, WritableStream)

    class D(C):
        pass

    assert not issubclass(D, WritableStream)

# Generated at 2022-06-20 12:46:45.464589
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('spam') == 'spam'
    assert normalize_repr('spam at 0x123') == 'spam'
    assert normalize_repr('spam at 0x123 at 0x456') == 'spam'
    assert normalize_repr('spam at 0x123 at 0x456 at 0x798') == 'spam'





# Generated at 2022-06-20 12:46:53.805654
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(3) == '3'
    assert get_shortish_repr(3, max_length=2) == '3'
    assert get_shortish_repr(3, max_length=1) == '3'
    assert get_shortish_repr(3, max_length=0) == '...'
    assert get_shortish_repr(3, max_length=5) == '3'
    assert get_shortish_repr('abcde', max_length=5) == 'abcde'
    assert get_shortish_repr('abcde', max_length=3) == 'a...'
    assert get_shortish_repr('abcde', max_length=0) == '...'

# Generated at 2022-06-20 12:46:58.581412
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, custom_repr=[]) is repr


# Generated at 2022-06-20 12:47:07.342025
# Unit test for function get_repr_function
def test_get_repr_function():
    def custom_repr_function(item):
        return 'custom_repr_function'

    assert get_repr_function('abc', [(str, custom_repr_function)]) is \
           custom_repr_function

    assert get_repr_function(123, [(str, custom_repr_function)]) is repr

    assert get_repr_function('abc', [(lambda s: True, custom_repr_function)])\
           is custom_repr_function

    assert get_repr_function(123, [(lambda s: True, custom_repr_function)])\
           is custom_repr_function




# Generated at 2022-06-20 12:47:17.226723
# Unit test for function normalize_repr
def test_normalize_repr():

    import re
    from .my_collections import OrderedDict
    from .my_reprlib import Repr

    def assert_normalize_repr_works(item):

        item_repr = normalize_repr(repr(item))
        assert ' at 0x' not in item_repr

        if isinstance(item, list):
            assert normalize_repr(str(item)) == item_repr

        if hasattr(item, '__class__'):
            item_repr = normalize_repr(item.__class__.__repr__(item))
            assert ' at 0x' not in item_repr

        if isinstance(item, set):
            item_repr = normalize_repr(reprlib.repr(item))

# Generated at 2022-06-20 12:47:24.297046
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('bla') == 'bla'
    assert normalize_repr('bla at 0x9B') == 'bla'
    assert normalize_repr('bla at 0x9Bab') == 'bla'
    assert normalize_repr('bla at 0x9BabCD'
                          ) == 'bla'
    assert normalize_repr('bla at 0x9BabCDEf'
                          ) == 'bla'


if __name__ == '__main__':
    test_normalize_repr()

# Generated at 2022-06-20 12:47:35.332768
# Unit test for function get_repr_function
def test_get_repr_function():
    def repr_float(x):
        return 'float is here'
    def repr_int(x):
        return 'int is here'
    def repr_default(x):
        return 'default is here'

    custom_repr = (
        (int, repr_int),
        (float, repr_float),
    )

    assert get_repr_function(5, custom_repr) == repr_int
    assert get_repr_function(5.0, custom_repr) == repr_float
    assert get_repr_function('5', custom_repr) == repr_default

    custom_repr = (
        (lambda x: isinstance(x, int), repr_int),
        (lambda x: isinstance(x, float), repr_float),
    )
