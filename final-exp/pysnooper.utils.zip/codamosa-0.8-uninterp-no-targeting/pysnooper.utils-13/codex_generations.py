

# Generated at 2022-06-20 12:38:19.137550
# Unit test for function normalize_repr
def test_normalize_repr():
    def _test_normalize_repr(repr_, expected, normalize=True):
        expected = expected if normalize else repr_
        assert normalize_repr(repr_) == expected
    _test_normalize_repr('', '')
    _test_normalize_repr('a', 'a', False)
    _test_normalize_repr('a at', 'a at')
    _test_normalize_repr('a at 0x', 'a at 0x')
    _test_normalize_repr('a at 0x234', 'a at 0x')
    _test_normalize_repr('a at 0xab6c0d6234', 'a at 0x')

# Generated at 2022-06-20 12:38:24.769714
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(12, max_length=2) == '12'
    assert get_shortish_repr(12, max_length=3) == '12'
    assert get_shortish_repr(12, max_length=4) == '12'
    assert get_shortish_repr(12345, max_length=3) == '...'
    assert get_shortish_repr(12345, max_length=4) == '...'
    assert get_shortish_repr(12345, max_length=5) == '1...5'
    assert get_shortish_repr(12345, max_length=6) == '1...5'
    assert get_shortish_repr(12345, max_length=7) == '12345'

    assert get_short

# Generated at 2022-06-20 12:38:31.435713
# Unit test for function get_repr_function
def test_get_repr_function():

    def repr_item(item):
        return f'item={item}'

    def repr_int(item):
        return f'int={item}'

    custom_repr = ((lambda x: True, repr_item),
                   (int, repr_int))

    assert get_repr_function(1, custom_repr) == repr_int
    assert get_repr_function(None, custom_repr) == repr_item

# Generated at 2022-06-20 12:38:37.781619
# Unit test for function normalize_repr
def test_normalize_repr():
    u = lambda x: repr(x).replace('\r', '').replace('\n', '')
    assert normalize_repr(u([])) == '[]'
    assert normalize_repr(u({})) == '{}'
    assert normalize_repr(u(set())) == 'set()'
    assert normalize_repr(u(frozenset())) == 'frozenset()'



# Generated at 2022-06-20 12:38:42.878552
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Writable(WritableStream):
        def __init__(self):
            self.write_called = False

        def write(self, s):
            self.write_called = True

    Writable()

    class NotWritable:
        pass

    try:
        NotWritable()
        raise AssertionError()
    except TypeError:
        pass


# Generated at 2022-06-20 12:38:48.355873
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, ((int, str) ,lambda x: 'int!')) == repr
    assert get_repr_function('heh', ((int, str) ,lambda x: 'int!')) == 'int!'
    assert get_repr_function(5, ((str, ) ,lambda x: 'str!')) == repr
    assert get_repr_function('heh', ((str, ) ,lambda x: 'str!')) == 'str!'
    assert get_repr_function(5, ((int, str) ,lambda x: 'int!') \
                                ,(object, lambda x: 'object!')) == repr
    assert get_repr_function('heh', ((int, str) ,lambda x: 'int!') \
                                ,(object, lambda x: 'object!')) == 'int!'


# Generated at 2022-06-20 12:38:56.899305
# Unit test for function truncate
def test_truncate():
    assert truncate('hello world!', 20) == 'hello world!'
    assert truncate('hello world!', 3) == '...'
    assert truncate('hello world!', 2) == '...'
    assert truncate('hello world!', 1) == '...'
    assert truncate('hello world!', 0) == '...'
    assert truncate('hello world!', -1) == '...'
    assert truncate('hello world!', -2) == '...'
    assert truncate('hello world!', -3) == '...'
    assert truncate('hello world!', 12) == 'hello world!'
    assert truncate('hello world!', 11) == 'hello worl...'
    assert truncate('hello world!', 10) == 'hello ...'

# Generated at 2022-06-20 12:39:07.064140
# Unit test for function get_repr_function
def test_get_repr_function():
    # Unpacking the output to compare with the input
    assert get_repr_function(1, []) == get_repr_function(1, ())


    def unless_int(i):
        return hash(i)


    assert get_repr_function(1, [unless_int]) == get_repr_function(1,
                                                                  [(int, str)]) == str


    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, repr)]) == repr


    assert get_repr_function(1, [lambda x: False]) == get_repr_function(
        1, [lambda x: True]) == repr


    assert get_repr_function(1, [])(1) == repr(1)
    assert get

# Generated at 2022-06-20 12:39:12.278799
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('+-') == '+-'
    # Check we handle non-ascii values
    assert shitcode('\u2603') == '?'
    assert shitcode('\u2603\u2603') == '??'
    assert shitcode('\u2603\u2603\u2603') == '???'
    assert shitcode('\u2603\u2603\u2603\u2603') == '???'
    # Check we don't mangle ascii values
    assert shitcode('ab') == 'ab'
    assert shitcode('ab\u2603') == 'ab?'
    assert shitcode('ab\u2603\u2603') == 'ab??'



# Generated at 2022-06-20 12:39:15.142947
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(WritableStream):
        def write(self, s):
            pass

    assert issubclass(Foo, WritableStream)



# Generated at 2022-06-20 12:39:19.808505
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('a\x00') == 'a?'
    assert shitcode('a\x0c\x00\xff') == 'a?\x0c?\xff'



# Generated at 2022-06-20 12:39:29.673053
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr('hello world') == "'hello world'"
    assert get_shortish_repr(b'hello world') == "b'hello world'"
    assert get_shortish_repr(b'hello world', max_length=14) == "b'hello worl..."
    assert get_shortish_repr(b'hello world', max_length=12) == "b'hello wo..."
    assert get_shortish_repr(b'hello world', max_length=11) == "b'hello w..."
    assert get_shortish_repr(b'hello world', max_length=10) == "b'hello..."

# Generated at 2022-06-20 12:39:31.550515
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)




# Generated at 2022-06-20 12:39:33.805824
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(()) == ()
    assert ensure_tuple(2) == (2,)
    assert ensure_tuple([2, 3]) == (2, 3)
    assert ensure_tuple((2, 3)) == (2, 3)




# Generated at 2022-06-20 12:39:41.005431
# Unit test for function get_repr_function
def test_get_repr_function():
    from python_toolbox import cute_testing
    f = get_repr_function
    assert f(5, [(lambda x: x == 5, str)]) == str
    assert f(5, [(lambda x: x == 5, lambda x: x + 1)])(5) == 6
    cute_testing.assert_polite_wrapper(f, 5, [(5, str)]) == str
    cute_testing.assert_polite_wrapper(f, 5, [type(5), str]) == str
    cute_testing.assert_polite_wrapper(f, 5, [(lambda x: x == 5, str)]) == str
    cute_testing.assert_polite_wrapper(f, 5, [(lambda x: x > 5, str)]) == repr

# Generated at 2022-06-20 12:39:43.527492
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('שלום') == '???'
    assert shitcode('א') == '?'



# Generated at 2022-06-20 12:39:47.841734
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', None) == 'abc'
    assert truncate('abc', 100) == 'abc'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 2) == 'ab...'
    assert truncate('abc', 1) == 'a...'
    assert truncate('abc', 0) == '...'
    assert truncate('abc', -1) == '...'

# Generated at 2022-06-20 12:39:50.297727
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWriteableStream(object):
        def write(self, s):
            pass

    assert issubclass(MyWriteableStream, WritableStream)




# Generated at 2022-06-20 12:39:57.668326
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('blah blah blah at 0xA') == 'blah blah blah'

    assert (
            normalize_repr(
                    'blah blah blah at 0xABCDE123456789ABCDEF12DEADBEEF'
            ) == 'blah blah blah'
    )

    assert (
            normalize_repr('blah blah blah') == 'blah blah blah'
    )

    assert (
            normalize_repr(
                    'blah blah blah at 0xABCDE123456789ABCDEF'
                    '12DEADBEEF at 0xA'
            ) == 'blah blah blah at 0xABCDE123456789ABCDEF12DEADBEEF'
    )

# Generated at 2022-06-20 12:40:08.423200
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('abc') == 'abc'
    assert shitcode('abcdef') == 'abcdef'

    if sys.version_info[0] < 3:
        assert shitcode('a\xfd') == 'a?'
        assert shitcode('\xfd') == '?'

    assert shitcode('\x01') == '\x01'
    assert shitcode('\x00') == '\x00'
    assert shitcode('\xFF') == '\xFF'
    assert shitcode('\xfe') == '\xfe'

    assert shitcode('a\xfdabcdef') == 'a?abcdef'
    assert shitcode('abcdef\xfd') == 'abcdef?'

    if sys.version_info[0] < 3:
        assert shitcode

# Generated at 2022-06-20 12:40:20.193657
# Unit test for function truncate
def test_truncate():
    assert truncate(u'asd', 0) == u''
    assert truncate(u'asd', 1) == u'a'
    assert truncate(u'asd', 2) == u'as'
    assert truncate(u'asd', 3) == u'asd'
    assert truncate(u'asd', 4) == u'asd'
    assert truncate(u'asd', 5) == u'a...d'
    assert truncate(u'asd', 6) == u'as...d'
    assert truncate(u'asdfgh', 5) == u'a...g'



# Generated at 2022-06-20 12:40:30.458701
# Unit test for function truncate
def test_truncate():

    assert truncate('') == ''
    assert truncate('a') == 'a'
    assert truncate('ab') == 'ab'
    assert truncate('abc') == 'abc'
    assert truncate('abcd') == 'abcd'
    assert truncate('abcde') == 'ab...e'
    assert truncate('abcdef') == 'ab...f'
    assert truncate('abcdefg') == 'ab...fg'
    assert truncate('abcdefgh') == 'a...gh'
    assert truncate('abcdefghi') == 'a...hi'
    assert truncate('abcdefghij') == 'a...ij'
    assert truncate('abcdefghijk') == 'a...jk'
    assert truncate('abcdefghijkl') == 'a...kl'

# Generated at 2022-06-20 12:40:33.868025
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('abc') == 'abc'
    assert normalize_repr('abc at 0x12') == 'abc'
    assert normalize_repr('abc at 0x1234') == 'abc'
    assert normalize_repr('abc at 0x1234ab00') == 'abc'

# Generated at 2022-06-20 12:40:42.181215
# Unit test for function truncate
def test_truncate():
    assert truncate('0123456789', None) == '0123456789'
    assert truncate('0123456789', 10) == '0123456789'
    assert truncate('0123456789', 9) == '0123...89'
    assert truncate('0123456789', 8) == '0123...89'
    assert truncate('0123456789', 7) == '0123...89'
    assert truncate('0123456789', 6) == '0123...89'
    assert truncate('0123456789', 5) == '0123...89'
    assert truncate('0123456789', 4) == '0123...89'
    assert truncate('0123456789', 3) == '0123...89'

# Generated at 2022-06-20 12:40:50.891671
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyWritableStream(WritableStream):
        pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

        def other_method(self):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class OtherWritableStream(WritableStream):
        def __init__(self):
            self.write = lambda s: None

    assert issubclass(OtherWritableStream, WritableStream)


# Generated at 2022-06-20 12:40:58.079894
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A:pass

    with pytest.raises(TypeError):
        issubclass(A, WritableStream)


    class A:
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)


    class A:
        def write(self, s):
            pass

        def flush(self):
            pass

    assert not issubclass(A, WritableStream)


    class A:
        def write(self, s):
            return 's'

    assert not issubclass(A, WritableStream)




# Generated at 2022-06-20 12:41:00.595987
# Unit test for function shitcode
def test_shitcode():
    r'''
    >>> shitcode('מישהו')
    '??????'
    >>> shitcode('םיישהו')
    '??????'
    '''


# Generated at 2022-06-20 12:41:02.660839
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X:
        def write(self, s):
            pass
    assert isinstance(X(), WritableStream)
    assert not isinstance(object(), WritableStream)

# Generated at 2022-06-20 12:41:07.259387
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert issubclass(WritableStream, ABC)
    assert issubclass(sys.stdout, WritableStream)
    class Foo(WritableStream):
        def write(self, s):
            pass
    Foo.register(sys.stdout)

# Generated at 2022-06-20 12:41:11.627800
# Unit test for function ensure_tuple
def test_ensure_tuple():
    x = [4, 5]
    assert ensure_tuple(x) == (4, 5)
    assert ensure_tuple(4) == (4,)

    class MyList(list): pass
    y = MyList([6, 7])
    assert ensure_tuple(y) == (6, 7)

# Generated at 2022-06-20 12:41:16.723785
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Test:
        def write(self):
            pass
    assert isinstance(Test(), WritableStream)



# Generated at 2022-06-20 12:41:26.320625
# Unit test for function shitcode
def test_shitcode():
    string = u'''
    Is n't это חייל לא כן ما هو ليس
    '''
    assert shitcode(string) == (
        '    Is nt  \xed\xe5\xea \xd7\xa7 \xd7\x99\xd7\x99\xd6\xbc '
        '\xd7\x9c\xd7\x90 \xd9\x83\xd9\x86 \xec\x83\x9d \xd9\x84'
        '\xd9\x8a\xd8\xb3\n    '
    )



# Generated at 2022-06-20 12:41:31.949005
# Unit test for function truncate
def test_truncate():
    assert truncate('0123', 1) == '.'
    assert truncate('0123', 2) == '..'
    assert truncate('0123', 3) == '01.'
    assert truncate('0123', 4) == '012.'
    assert truncate('0123', 5) == '0123'
    assert truncate('0123', 6) == '0123'
    assert truncate('0123456789', 7) == '0123...'
    assert truncate('01234567890', 10) == '01234567890'
    assert truncate(u'0123', 5) == u'0123'
    assert truncate(u'01234567890', 10) == u'01234567890'



# Generated at 2022-06-20 12:41:40.488775
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode(u'hello') == 'hello'
    assert shitcode('hello\xab') == 'hello?'
    assert shitcode(u'hello\xab') == 'hello?'
    assert shitcode(b'hello\xab') == 'hello\xab'
    assert shitcode(b'hello\xab', treat_bytes_as_unicode=True) == 'hello?'
    assert shitcode(bytearray(b'hello\xab')) == 'hello\xab'
    assert shitcode(bytearray(b'hello\xab'), treat_bytes_as_unicode=True) == 'hello?'
    assert shitcode('hello\udc80') == 'hello\udc80'

# Generated at 2022-06-20 12:41:48.124369
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(u"hello") == u"hello"
    assert get_shortish_repr(u"hello", max_length=3) == u"hel"
    assert get_shortish_repr(u"hello", max_length=2) == u"he"
    assert get_shortish_repr(u"hello", max_length=1) == u"h"
    assert get_shortish_repr(u"hello", max_length=0) == u""
    assert get_shortish_repr(u"hello", max_length=4) == u"hell"
    assert get_shortish_repr(u"hello", max_length=5) == u"hello"
    assert get_shortish_repr(u"hello", max_length=6) == u"hello"

# Generated at 2022-06-20 12:41:51.667570
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(str) == str
    assert shitcode(u'asdf') == u'asdf'

    import sys
    assert shitcode(sys.version_info) == str(sys.version_info)




# Generated at 2022-06-20 12:41:55.729142
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            self.s = s

    a = A()
    WritableStream.register(A)
    assert isinstance(a, WritableStream)
    a.write('hi')
    assert a.s == 'hi'



# Generated at 2022-06-20 12:42:00.318123
# Unit test for function normalize_repr
def test_normalize_repr():
    import math
    def f():
        pass
    class C():
        def __init__(self):
            self.x = 4
    c = C()
    l = [1, 2, 3]
    d = {'a': 1, 'b': 2}
    s = {1, 2, 3}
    for item in (4, 1.23, 'a', 'abc', f, c, l, d, s):
        assert repr(item) == normalize_repr(repr(item))



# Generated at 2022-06-20 12:42:10.316193
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefg', None) == 'abcdefg'
    assert truncate('abcdefg', 5) == 'ab...'
    assert truncate('abcdefg', 6) == 'ab...'
    assert truncate('abcdefg', 7) == 'abcdefg'
    assert truncate('abcdefg', 8) == 'abcdefg'


PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3


try:
    from inspect import signature
except ImportError:
    executor_walker_class = None
else:
    from .executor_walker import ExecutorWalker
    executor_walker_class = ExecutorWalker

# Generated at 2022-06-20 12:42:19.630311
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Writable(WritableStream):
        def __init__(self):
            self.writes = []

        def write(self, s):
            self.writes.append(s)

    a, b, c = Writable(), Writable(), Writable()

    for x in [[a, b, c], (a, b, c), (a, (b, c))]:
        for i in range(3):
            for stream in ensure_tuple(x):
                stream.write(i)

        assert a.writes == [0, 1, 2]
        assert b.writes == [0, 1, 2]
        assert c.writes == [0, 1, 2]




# Generated at 2022-06-20 12:42:31.513966
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class SillyWritableStream(WritableStream):
        def write(self, s):
            return NotImplemented

    s = SillyWritableStream()
    try:
        s.write('hi')
    except NotImplementedError:
        pass # Good.
    else:
        raise AssertionError('Calling `write` should raise exception '
                             '`NotImplementedError`')


    class SillyWritableStream(WritableStream):
        def write(self):
            return NotImplemented

    s = SillyWritableStream()
    try:
        s.write('hi')
    except TypeError:
        pass # Good.
    else:
        raise AssertionError('Calling `write` should raise exception '
                             '`TypeError`')




# Generated at 2022-06-20 12:42:33.754816
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        pass

    with pytest.raises(TypeError):
        Foo()



# Generated at 2022-06-20 12:42:42.387049
# Unit test for function get_repr_function
def test_get_repr_function():
    class MyType(str): pass

    def my_repr(x):
        return 'MY REPR ' + repr(x)
    custom_repr = [
        (MyType, my_repr),
        (TypeError, lambda x: 'TYPE ERROR REPR'),
    ]

    assert get_repr_function(TypeError(), custom_repr) == my_repr
    assert get_repr_function(MyType(), custom_repr) == my_repr
    assert get_repr_function(Exception(), custom_repr) == repr



# Generated at 2022-06-20 12:42:48.121771
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("obj at 0x1234561") == "obj"
    assert normalize_repr("obj at 0x1") == "obj"
    assert normalize_repr("obj at 0x") == "obj"
    assert normalize_repr("obj at 0x1234567890abcdef") == "obj"
    assert normalize_repr("obj at 0x1234567890ABCDEF") == "obj"
    assert normalize_repr("obj at 0x10") == "obj"



# Generated at 2022-06-20 12:42:58.114754
# Unit test for function normalize_repr
def test_normalize_repr():
    string_010 = '<__main__.TestClass object at 0x012345678>'
    string_011 = '<__main__.TestClass object at 0x0123456789abcdef>'
    string_fail = '<__main__.TestClass at 0x0123456789abcdef>'

    assert normalize_repr(string_010) == '<__main__.TestClass object>'
    assert normalize_repr(string_011) == '<__main__.TestClass object>'
    assert normalize_repr(string_fail) == '<__main__.TestClass at 0x0123456789abcdef>'
    return 'test passed'


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-20 12:43:07.971965
# Unit test for function get_repr_function
def test_get_repr_function():
    for item, expected_result in (
            (1, repr), (1.0, repr), ('a', repr), ('', repr), ('ab', repr),
            (b'a', repr), (b'', repr), (b'ab', repr), (u'\u2620', repr),
            ([], repr), ([1], repr), ((), repr), ((1,), repr), ({}, repr),
            ({1: 2}, repr), (set(), repr), (set([1]), repr),
            (object(), repr), (object, repr), (None, repr)):
        assert get_repr_function(item, ()) is expected_result
    assert get_repr_function(None, ((None, 'hello'))) == 'hello'

# Generated at 2022-06-20 12:43:18.069032
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(123) == '123'
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr('meow') == "'meow'"
    assert get_shortish_repr(u'\u05d0') == "u'\u05d0'"
    assert get_shortish_repr(5.5) == '5.5'
    assert get_shortish_repr(['x', 'y']) == "['x', 'y']"
    assert get_shortish_repr((1, 2, 3)) == '(1, 2, 3)'
    assert get_shortish_repr(object()) == '<object object at 0x%x>' % \
                                            id(object())
    assert get_shortish_repr

# Generated at 2022-06-20 12:43:20.846614
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(['a', 'b']) == ('a', 'b')



# Generated at 2022-06-20 12:43:22.718316
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(object):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

# Generated at 2022-06-20 12:43:33.736953
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'a') == u'a'
    assert shitcode(u'\u05d0'*3) == u'???'
    assert shitcode(u'\u05d0'*3) == u'???'
    assert shitcode(u'\u05d0'*2+u'a') == u'??a'
    assert shitcode(u'a'+u'\u05d0'*2) == u'a??'
    if sys.maxunicode >= 1114111:
        assert shitcode(unichr(1000000)) == u'?'
        assert shitcode(unichr(1000000)*3) == u'???'
    assert shitcode(bytearray(b'abcdefg')) == u'abcdefg'

# Generated at 2022-06-20 12:43:42.494272
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('������������') == '????????????'
    assert shitcode('') == ''
    assert shitcode('a') == 'a'
    assert shitcode('é') == '?'
    assert shitcode('é'*1000) == '?'*1000

# Generated at 2022-06-20 12:43:54.473597
# Unit test for function get_repr_function
def test_get_repr_function():
    class X: pass
    class Y(X): pass
    class Z(Y): pass
    assert get_repr_function(X(), custom_repr=[(X, lambda x: 'X')])() == 'X'
    assert get_repr_function(X())() == '<__main__.X object at 0x00000000027B4B70>'
    assert get_repr_function(Y(), custom_repr=[(X, lambda x: 'X')])() == 'X'
    assert get_repr_function(Y())() == '<__main__.Y object at 0x00000000027B4B00>'
    assert get_repr_function(Z(), custom_repr=[(X, lambda x: 'X')])() == 'X'

# Generated at 2022-06-20 12:44:00.005144
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo:
        def write(self, s):
            pass

    assert isinstance(Foo(), WritableStream)

    class Bar:
        pass

    assert not isinstance(Bar(), WritableStream)

    class Baz:
        def write(self, s):
            pass

        def __subclasshook__(cls, C):
            return True

    assert isinstance(Baz(), WritableStream)



# Generated at 2022-06-20 12:44:07.287395
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1, custom_repr=((lambda x: x > 0, str),)) == str
    assert get_repr_function(1, custom_repr=((lambda x: x > 0, str), (int,
                                                                     int))) == int
    assert get_repr_function(1, custom_repr=((lambda x: x > 0, str), (int,
                                                                     int))) == int
    assert get_repr_function('', custom_repr=((lambda x: x > 0, str), (int,
                                                                     int))) == repr
    assert get_repr_function(1, custom_repr=()) == repr


# Unit tests for function get_

# Generated at 2022-06-20 12:44:19.095887
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', None) == 'hello'
    assert truncate('hello', 2) == 'he'
    assert truncate('hello', 3) == 'hel'
    assert truncate('hello', 4) == 'hell'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 6) == 'hello'
    assert truncate('hello', 7) == 'hello'
    assert truncate('hello', 8) == 'hello'
    assert truncate('hello', 9) == 'hello'
    assert truncate('hello', 10) == 'hello'

    assert truncate('hello', 1) == 'h'
    assert truncate('hello', 0) == ''

    assert truncate('hello', -1) == ''
    assert truncate('hello', -5) == ''


# Generated at 2022-06-20 12:44:24.484417
# Unit test for function get_repr_function
def test_get_repr_function():
    assert u'Hello' == get_shortish_repr(u'Hello', ())
    assert u'\U00026f90' == get_shortish_repr(u'\U00026f90', ())
    assert 'Hello' == get_shortish_repr(b'Hello', ())
    assert '\\x26f90' == get_shortish_repr(b'\xf0\x9f\x9b\xb0', ())
    
    


# Generated at 2022-06-20 12:44:33.719456
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1.1, custom_repr=[]) == repr
    assert get_repr_function(1.1, custom_repr=[(float, str)]) == str
    assert get_repr_function(1.1, custom_repr=[(lambda x: False, str)]) == repr
    assert get_repr_function(1.1, custom_repr=[(False, str)]) == repr
    assert get_repr_function(
        1.1,
        custom_repr=[(float, str), (float, str)]
    ) == str
    assert get_repr_function(
        1.1,
        custom_repr=[(float, str), (True, str)]
    ) == str

# Generated at 2022-06-20 12:44:43.078686
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .mock import Mock
    assert get_shortish_repr('a') == "'a'"
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(
        {'a': 3, 'b': 4},
        custom_repr=(
            (lambda x: 'b' in x, lambda x: ','.join(sorted(x))),
        )
    ) == "{'a': 3, 'b': 4}"

    class Foo(object):
        def __repr__(self):
            return 'foo'

    assert get_shortish_repr(Foo()) == 'foo'
    assert get_shortish_repr(Mock(repr='foo')) == 'foo'


# Generated at 2022-06-20 12:44:46.376895
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyFileStream(object):
        def write(self, s):
            return s
    assert isinstance(DummyFileStream(), WritableStream)
    assert not isinstance(object(), WritableStream)



# Generated at 2022-06-20 12:44:49.075113
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('\xff') == '?'
    assert shitcode('\u200e') == '?'
    assert shitcode('\ud834\udd1e') == '??'



# Generated at 2022-06-20 12:45:05.702135
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('helo') == 'hel?o'
    assert shitcode('hel☃o') == 'hel?o'
    assert shitcode('喃藏ㄩ鎰措措') == '?????'
    assert shitcode('abc' + chr(133)) == 'abc?'
    assert shitcode(chr(0) + chr(1) + chr(2)) == '???'
    assert shitcode('asd' + chr(256) + chr(257)) == 'asd??'
    assert shitcode(chr(0) + chr(257)) == '??'
    assert shitcode('hello' + chr(2)) == 'hello?'

# Generated at 2022-06-20 12:45:13.763334
# Unit test for function ensure_tuple
def test_ensure_tuple():
    import pytest
    assert ensure_tuple('hi') == ('hi',)
    assert ensure_tuple(('hi',)) == ('hi',)
    assert ensure_tuple(['hi']) == ('hi',)
    assert ensure_tuple(('hi', 'hello')) == ('hi', 'hello')
    assert ensure_tuple(['hi', 'hello']) == ('hi', 'hello')
    assert ensure_tuple('hi' * 50) == ('hi' * 50,)
    assert ensure_tuple(('hi',) * 50) == ('hi',) * 50
    assert ensure_tuple(['hi'] * 50) == ('hi',) * 50
    assert ensure_tuple(('hi', 'hello') * 50) == ('hi', 'hello') * 50

# Generated at 2022-06-20 12:45:18.036326
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple((5, 6)) == (5, 6)
    assert ensure_tuple('foo') == ('foo',)
    assert ensure_tuple((5, 6, 7)) == (5, 6, 7)



# Generated at 2022-06-20 12:45:26.466345
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', None) == 'hello'
    assert truncate('hello', 10) == 'hello'
    assert truncate('hello', 3) == 'he...'
    assert truncate('hello', 4) == 'he...'
    assert truncate('hello', 5) == 'he...'
    assert truncate('hello', 6) == 'he...'
    assert truncate('hello', 7) == 'hel...'
    assert truncate('hello', 8) == 'hel...'
    assert truncate('hello', 9) == 'hel...'
    assert truncate('hello', 10) == 'hello'





# Generated at 2022-06-20 12:45:28.549667
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(('a', 'b')) == ('a', 'b')
    assert ensure_tuple('c') == ('c',)




# Generated at 2022-06-20 12:45:30.909311
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class SomeClass(WritableStream):
        def write(self, s):
            pass
    assert issubclass(SomeClass, WritableStream)
    assert isinstance(SomeClass(), WritableStream)



# Generated at 2022-06-20 12:45:32.237025
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Test:
        def write(self, s):
            pass

    Test.__subclasshook__(Test) is True

# Generated at 2022-06-20 12:45:37.529225
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('cool') == 'cool'
    assert normalize_repr('neat at 0x02A3') == 'neat'
    assert normalize_repr('') == ''
    assert normalize_repr(' at 0x02A3') == ''
    assert normalize_repr('cool') == 'cool'
    assert normalize_repr('neat at 0x02A3') == 'neat'
    assert normalize_repr('') == ''
    assert normalize_repr(' at 0x02A3') == ''





# Generated at 2022-06-20 12:45:47.470834
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, custom_repr=((int, 'hi'),)) == 'hi'
    assert get_repr_function(5, custom_repr=((float, 'hi'),)) != 'hi'
    def f(x):
        return getsattr(x, 'a')
    assert get_repr_function(
        object(), custom_repr=((f, 'yo'),)
    ) != 'yo'
    class C:
        a = 5
    assert get_repr_function(C, custom_repr=((f, 'yo'),)) == 'yo'
    assert get_repr_function(object(), custom_repr=((f, 'yo'),)) != 'yo'

# Generated at 2022-06-20 12:45:52.146598
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Method write of class WritableStream.
    class ExampleStream(WritableStream):
        def __init__(self):
            self.list = []
        def write(self, s):
            self.list.append(s)
    stream = ExampleStream()
    stream.write('hi')
    assert stream.list == ['hi']


# Generated at 2022-06-20 12:46:07.686038
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert (get_shortish_repr('hello') == 'hello')
    assert (get_shortish_repr('hello', max_length=10) == 'hello')
    assert (get_shortish_repr('hello', max_length=1) == 'h...')
    assert (get_shortish_repr('hellox', max_length=4) == 'h...')
    assert (get_shortish_repr(u'\u05e9') == u"u'\\u05e9'")
    assert (get_shortish_repr(u'\u05e9', max_length=10) == u"u'\\u05e9'")
    assert (get_shortish_repr(u'\u05e9', max_length=1) == "u'...'")



# Generated at 2022-06-20 12:46:12.515462
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<foo at 0x7fcaeba21e10>') == '<foo>'
    assert normalize_repr('<foo at 0x7fcaeba21e10>bar') == '<foo>bar'
    assert normalize_repr('<foo at 0x7fcaeba21e10>') == '<foo>'
    assert normalize_repr('<foo at 0x7fcaeba21e10>bar') == '<foo>bar'



# Generated at 2022-06-20 12:46:23.567685
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', 5) == 'abc'
    assert truncate('abcdef', 5) == 'ab...f'
    assert truncate('abcdef', 5, left=True) == 'abc...'
    assert truncate('abcdef', 5, left=False) == '...def'
    assert truncate('', 5) == ''
    assert truncate('a', 5) == 'a'
    assert truncate('a', 0) == ''
    assert truncate('a', None) == 'a'
    assert truncate('abcdef', None) == 'abcdef'
    assert truncate('abcdef', 3) == 'abc'
    assert truncate('abcdef', 3, left=True) == 'abc'
    assert truncate('abcdef', 3, left=False) == 'def'

# Generated at 2022-06-20 12:46:33.342587
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .testing import TestCase, MagicMock
    from .testing.remove_exception_from_traceback import \
                                                 remove_exception_from_traceback
    foo = TestCase()
    class Class(metaclass=ABC):
        def write(self, s):
            pass
    class Subclass(Class):
        pass
    assert issubclass(Subclass, WritableStream)
    assert WritableStream.__subclasscheck__(Subclass)
    assert not WritableStream.__subclasscheck__(Class)
    foo.assertRaises(TypeError,
                     lambda: WritableStream.register(Class))
    with remove_exception_from_traceback(TypeError):
        WritableStream.register(Subclass)
    assert WritableStream.__subclasscheck__(Subclass)

# Generated at 2022-06-20 12:46:40.126060
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, ()) == '1'
    assert get_shortish_repr('hello', max_length=5) == 'hello'
    assert get_shortish_repr('hello', max_length=2) == 'he...'
    assert get_shortish_repr('hello', max_length=7) == 'hello'
    assert get_shortish_repr('hello', max_length=3) == 'hel...'
    assert get_shortish_repr('hello', max_length=1) == '...'

# Generated at 2022-06-20 12:46:49.689701
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class DummyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(DummyWritableStream, WritableStream)

    class DummyWritableStream2:
        def write(self, s):
            pass

    assert not issubclass(DummyWritableStream2, WritableStream) # Wrong behaviour!

    class DummyWritableStream3:
        def write(self, s):
            pass

        def foo(self):
            pass

    assert not issubclass(DummyWritableStream3, WritableStream)

    class DummyWritableStream4(WritableStream):
        def write(self, s):
            pass

        def write_foo(self, s):
            pass

    assert issubclass(DummyWritableStream4, WritableStream)


# Generated at 2022-06-20 12:46:52.839635
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple(2) == (2, )
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(set([1, 2, 3])) == (1, 2, 3)

# Generated at 2022-06-20 12:46:55.157033
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamImplementation(WritableStream):
        def write(self, s):
            print(s)

    WritableStreamImplementation()

# Generated at 2022-06-20 12:47:05.145148
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass
    assert get_repr_function(A(), ()) == repr
    assert get_repr_function(A(), ((A, str),)) == str
    assert get_repr_function(B(), ((A, str),)) == str
    assert get_repr_function(B(), ((A, str), (B, lambda x: 'a'))) == str
    assert get_repr_function(B(), ((A, str), (B, lambda x: 'b'))) == 'b'
    assert get_repr_function(B(), ((A, str), (B, lambda x: 'b')),
                             custom_repr=((B, lambda x: 'c'))) == 'c'

# Generated at 2022-06-20 12:47:15.388204
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(True, max_length=10) == 'True'
    assert get_shortish_repr(None, max_length=10) == 'None'
    assert get_shortish_repr('a' * 30, max_length=None) == 'a' * 30
    assert get_shortish_repr('a' * 30, max_length=20) == 'a' * 17 + '...' + 'a'
    assert get_shortish_repr('a' * 30, max_length=1) == 'a'
    assert get_shortish_repr('a' * 30, max_length=20, normalize=True) == \
                                                              'a' * 17 + '...'

# Generated at 2022-06-20 12:47:40.693587
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello world') == "'hello world'"
    assert get_shortish_repr(5j) == '5j'
    assert get_shortish_repr(5j, normalize=True) == '5j'
    assert get_shortish_repr(5j, max_length=5) == '5j'
    assert get_shortish_repr(5j, max_length=4) == '5j'
    assert get_shortish_repr(5j, max_length=3) == '...'
    assert get_shortish_repr(5j, normalize=True, max_length=3) == '...'
    assert get_shortish_repr(5j, max_length=2) == '..'

# Generated at 2022-06-20 12:47:49.797605
# Unit test for function get_repr_function
def test_get_repr_function():
    import pytest
    custom_repr = [(1, lambda x: 'I am 1'),
                   (list, lambda x: 'list %s' % str(x)),
                   ((3, 5), lambda x: '3 or 5')]

# Generated at 2022-06-20 12:47:58.948614
# Unit test for function truncate
def test_truncate():
    assert truncate('', None) == ''
    assert truncate('', 0) == ''
    assert truncate('', 1) == ''
    assert truncate('', 2) == ''
    assert truncate('', 3) == ''
    
    assert truncate('123456789', None) == '123456789'
    assert truncate('123456789', 0) == ''
    assert truncate('123456789', 1) == '1'
    assert truncate('123456789', 2) == '12'
    assert truncate('123456789', 3) == '123'
    assert truncate('123456789', 4) == '1...'
    assert truncate('123456789', 5) == '12...'
    assert truncate('123456789', 6) == '123...'

# Generated at 2022-06-20 12:48:07.653341
# Unit test for function normalize_repr
def test_normalize_repr():
    from garlicsim.general_misc.third_party import (
        test_tools as test_tools_module
    )
    test_case = test_tools_module.TestCase

    normalize_repr_ = normalize_repr

    def test_normalize_repr(self):
        x = 'something'
        hex_address = hex(id(x))[2:]
        repr_string = repr(x)
        assert repr_string.endswith(hex_address)
        normalized_repr_string = normalize_repr_(repr_string)
        self.assertNotEqual(repr_string, normalized_repr_string)
        self.assertNotIn(hex_address, normalized_repr_string)
