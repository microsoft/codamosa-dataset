

# Generated at 2022-06-20 12:38:19.571215
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Testing with a large string that is longer than max_length
    long_string = """this is a long string
    this is a long string
this is a long string
    this is a long string
this is a long string
this is a long string
this is a long string
this is a long string
this is a long string
this is a long string
this is a long string
this is a long string
this is a long string
this is a long string
this is a long string
this is a long string
this is a long string
this is a long string
this is a long string
        """
    assert get_shortish_repr(
        long_string,
        max_length=100
    ) == "this is a long string\n    this is a long string\nthi..."

    # Testing with a long number that is longer than max

# Generated at 2022-06-20 12:38:26.581458
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)



if sys.version_info[0] == 2:
    def _write_shell_friendly(s):
        """
        Write a string to stdout in a way that won't cause trouble with the
        shell.

        For example, `\r` is converted to ESC[1G.

        (This is currently only necessary/useful in Python 2.)
        """
        s = s.replace('\r', '\x1b[1G')
        try:
            sys.stdout.write(s)
        except IOError:
            pass

# Generated at 2022-06-20 12:38:32.875800
# Unit test for function ensure_tuple
def test_ensure_tuple():
    foo = lambda: 3
    assert ensure_tuple(foo()) == (3,)
    assert ensure_tuple(foo) == (foo,)
    assert ensure_tuple(()) == ()
    assert ensure_tuple([]) == ()
    assert ensure_tuple('') == ('',)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 12:38:38.336970
# Unit test for function normalize_repr
def test_normalize_repr():
    from .testing.test_tools import assert_equal

    class MyClass(object):
        pass

    my_object = MyClass()
    my_object.a_special_attr = 3


    assert_equal(
        normalize_repr(repr(my_object)),
        # This is fragile, but hopefully not too likely to change...
        repr(MyClass) + ' object'
    )

# Generated at 2022-06-20 12:38:45.028847
# Unit test for constructor of class WritableStream
def test_WritableStream():
    """Make sure that `WritableStream`'s constructor works correctly."""
    class A(WritableStream):
        pass

    class B(object):
        pass

    class C(WritableStream):
        def write(self, s):
            pass

    assert WritableStream.__subclasshook__(A) is NotImplemented
    assert WritableStream.__subclasshook__(B) is NotImplemented
    assert WritableStream.__subclasshook__(C) is True

    if sys.version_info >= (3, 6):
        class D(collections_abc.Collection):
            def write(self, s):
                pass
        # On Py3.6, this works thanks to `__instancecheck__` doing magic
        # (I think)
        assert isinstance(A(), WritableStream)

# Generated at 2022-06-20 12:38:48.761666
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from io import StringIO, BytesIO
    assert issubclass(StringIO, WritableStream)
    assert issubclass(BytesIO, WritableStream)
    assert not issubclass(str, WritableStream)


# Generated at 2022-06-20 12:38:52.779692
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import StringIO
    s = StringIO()
    assert isinstance(s, WritableStream)
    s.write('hihi')
    assert s.getvalue() == 'hihi'
    s.write('hi')
    assert s.getvalue() == 'hihihi'

# Generated at 2022-06-20 12:38:57.726525
# Unit test for function truncate
def test_truncate():
    assert truncate('abcd', 3) == 'abc'
    assert truncate('abcd', 4) == 'abcd'
    assert truncate('abcd', 5) == 'abcd'
    assert truncate('abcd', 10) == 'abcd'
    assert truncate('abcdefghijklmnop', 10) == 'abc...nop'
    assert truncate('abcdefghijklmnop', 11) == 'abc...nop'
    assert truncate('abcdefghijklmnop', 12) == 'abc...mnop'

# Generated at 2022-06-20 12:39:01.143605
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    assert issubclass(A, WritableStream)



# Generated at 2022-06-20 12:39:02.267868
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(WritableStream, ABC)
    assert issubclass(sys.stdout, WritableStream)



# Generated at 2022-06-20 12:39:07.714447
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    class B(A):
        pass

    assert issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)



# Generated at 2022-06-20 12:39:13.920797
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class C: pass
    c = C()
    def custom_repr(x):
        return repr(c)

    assert get_shortish_repr(object()) == '<object object at 0x%x>' % id(object())
    assert get_shortish_repr(object(), max_length=8) == '<object...>'
    assert get_shortish_repr(object(), max_length=23) == '<object object at 0x%x>' % id(object())

    assert get_shortish_repr(c, custom_repr=()) == '<__main__.C object at 0x%x>' % id(c)

# Generated at 2022-06-20 12:39:24.672546
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', None) == 'hello'
    assert truncate('hello', 10) == 'hello'
    assert truncate('hello', 1) == 'h'
    assert truncate('hello', 2) == 'he'
    assert truncate('hello', 3) == 'hel'
    assert truncate('hello', 4) == 'hell'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 6) == 'hello'
    assert truncate('hello', 7) == 'hello'
    assert truncate('hello', 8) == 'hello'
    assert truncate('hello', 9) == 'hello'
    assert truncate('hello', 10) == 'hello'
    assert truncate('hello', 11) == 'hello'
    assert truncate('hello', 12) == 'hello'
    assert trunc

# Generated at 2022-06-20 12:39:28.660641
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('A') == ('A',)
    assert ensure_tuple(['A']) == (['A'],)
    assert ensure_tuple(['A', 'B']) == (['A', 'B'],)


# Note: This `with` thing was copied from `contextlib.redirect_stdout`.

# Generated at 2022-06-20 12:39:35.403073
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(xrange(5)) == (0, 1, 2, 3, 4)
    assert ensure_tuple(set([1, 2, 3])) == (1, 2, 3)
    assert ensure_tuple(set(xrange(5))) == (0, 1, 2, 3, 4)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple('hi') == ('hi',)




# Generated at 2022-06-20 12:39:40.973414
# Unit test for function truncate
def test_truncate():
    assert truncate('asdf', None) == 'asdf'
    assert truncate('asdf', 7) == 'asdf'
    assert truncate('asdf', 3) == 'asdf'
    assert truncate('asdf', 2) == 'as...'
    assert truncate('asdf', 1) == '...'



# Generated at 2022-06-20 12:39:49.377669
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('123456789', max_length=8) == '1234567...'
    assert get_shortish_repr('123456789', max_length=9) == '123456789'
    assert get_shortish_repr('123456789', max_length=10) == '123456789'
    assert get_shortish_repr('123456789', max_length=5) == '12...'
    assert get_shortish_repr('123456789', max_length=4) == '...'
    assert get_shortish_repr('123456789', max_length=3) == '...'
    assert get_shortish_repr('123456789', max_length=2) == '...'
    assert get_shortish_

# Generated at 2022-06-20 12:39:57.202637
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda a: isinstance(a, type),
         lambda b: 'a' + str(b)),
        (str,
         lambda b: 'b' + str(b)),
        (lambda a: isinstance(a, (int, float)),
         lambda b: 'c' + str(b)),
    )

# Generated at 2022-06-20 12:40:08.218961
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (
        (lambda x: isinstance(x, str), lambda x: '...' + truncate(x, 7) + '...')
    )) == repr
    assert get_repr_function(1, (
        (lambda x: isinstance(x, int), lambda x: '...' + str(x) + '...'),
        (lambda x: isinstance(x, str), lambda x: '...' + truncate(x, 7) + '...'),
    )) == (lambda x: '...' + str(x) + '...')

# Generated at 2022-06-20 12:40:11.038411
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)




# Generated at 2022-06-20 12:40:27.236251
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('abc') == 'abc'
    assert normalize_repr('abc at 0x1234') == 'abc'
    assert normalize_repr('abc at 0x123456') == 'abc'
    assert normalize_repr('abc at 0x123456789') == 'abc'
    assert normalize_repr('abc at 0x123456789A') == 'abc'
    assert normalize_repr('abc at 0x123456789AB') == 'abc'
    assert normalize_repr('abc at 0x123456789ABC') == 'abc'
    assert normalize_repr('abc at 0x123456789ABCD') == 'abc'
    assert normalize_repr('abc at 0x123456789ABCDE') == 'abc'
    assert normalize_

# Generated at 2022-06-20 12:40:30.717646
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert(ensure_tuple((1, 2, 3)) == (1, 2, 3))
    assert(ensure_tuple([1, 2, 3]) == (1, 2, 3))
    assert(ensure_tuple(1) == (1,))



# Generated at 2022-06-20 12:40:37.061662
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    class Test:
        pass
    assert ensure_tuple(Test()) == (Test(),)
    assert ensure_tuple('q') == ('q',)
    assert ensure_tuple(['q']) == ('q',)



# Generated at 2022-06-20 12:40:44.679035
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1234567, max_length=3) == '...'
    assert get_shortish_repr(1234567, max_length=4) == '1...'

# Generated at 2022-06-20 12:40:48.188308
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple('hello') == ('hello',)

# Generated at 2022-06-20 12:40:52.978483
# Unit test for constructor of class WritableStream
def test_WritableStream():
    """Test that `WritableStream` works as a metaclass."""
    class MyWritableStream(WritableStream): pass
    assert issubclass(MyWritableStream, WritableStream)
    assert 'write' in MyWritableStream.__dict__

    class MyWritableStream2(WritableStream):
        def write(self): pass
    assert issubclass(MyWritableStream2, WritableStream)





# Generated at 2022-06-20 12:40:56.426423
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(object):
        def write(self, s):
            return

    class B(object):
        pass

    assert issubclass(A, WritableStream)
    assert not issubclass(B, WritableStream)

# Generated at 2022-06-20 12:40:59.491227
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X:
        def write(self, s):
            raise RuntimeError('state machine error')
    assert (isinstance(X(), WritableStream) is NotImplemented)

    # Unit test for method __subclasshook__ of class WritableStream
    assert (issubclass(X, WritableStream))


if __name__ == '__main__':
    test_WritableStream_write()

# Generated at 2022-06-20 12:41:03.587484
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([3, 4, 5]) == (3, 4, 5)
    assert ensure_tuple([3, 4, 5, 6]) == (3, 4, 5, 6)
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((3, 4)) == (3, 4)

    assert ensure_tuple('text') == ('text',)



# Generated at 2022-06-20 12:41:12.608872
# Unit test for function shitcode
def test_shitcode():
    s = shitcode(b'\xaa\xbb\xff\x00\xff')
    assert s == '??\xff\x00\xff'
    s = shitcode('\xaa\xbb\xff\x00\xff')
    assert s == '\xaa\xbb\xff\x00\xff'

# Generated at 2022-06-20 12:41:28.226141
# Unit test for function get_repr_function
def test_get_repr_function():
    foo = object()
    assert shitcode(get_repr_function(foo, (
        (
            lambda y: isinstance(y, str),
            lambda y: 'shitcode(' + repr(y) + ')'
        ),
    ))) == "shitcode('bar')"
    assert get_repr_function(foo, (
        (
            lambda y: isinstance(y, str),
            lambda y: 'shitcode(' + repr(y) + ')'
        ),
    )) == "shitcode('bar')"

    class Foo(object): pass

# Generated at 2022-06-20 12:41:30.792991
# Unit test for function normalize_repr
def test_normalize_repr():
    class A(object):
        pass
    a = A()
    assert normalize_repr(repr(a)) == '<fake_repr.test_normalize_repr.A object at 0x0>'  # noqa
    assert normalize_repr(repr('a')) =="'a'"

# Generated at 2022-06-20 12:41:33.906004
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(repr(1)) == '1'
    assert normalize_repr('hi there') == 'hi there'



# Generated at 2022-06-20 12:41:36.458085
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)



# Generated at 2022-06-20 12:41:41.868023
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5) == repr
    class A(object):
        def __repr__(self):
            return 'a'
    assert get_repr_function(A()) == repr
    assert get_repr_function([1, 2, 3, 4], custom_repr=((list, str),)) == str
    assert get_repr_function([1, 2, 3, 4], custom_repr=((list, repr),)) == repr
    assert get_repr_function(5, custom_repr=((list, str),)) == repr
    assert get_repr_function(6, custom_repr=((6, str),)) == str



# Generated at 2022-06-20 12:41:48.855046
# Unit test for function truncate
def test_truncate():
    assert truncate(u'0123456789', 4) == u'012...789'
    assert truncate(u'0123456789', None) == u'0123456789'
    assert truncate(u'0123456789', 20) == u'0123456789'
    assert truncate(u'0123', 4) == u'0123'
    assert truncate(u'01', 4) == u'01'
    assert truncate(u'', 4) == u''
    assert truncate(u'0123456789', 2) == u'01...89'
    assert truncate(u'0123456789', 3) == u'012...89'
    assert truncate(u'0123456789', 5) == u'01234...789'

# Generated at 2022-06-20 12:41:57.132959
# Unit test for function normalize_repr
def test_normalize_repr():
    from . import testing_tools
    with testing_tools.AssertPrints('<__main__.C at 0x7ff65>'):
        class C: pass
        print(normalize_repr(repr(C)))
    with testing_tools.AssertPrints('<__main__.C object at 0x7ff65>'):
        class C: pass
        print(normalize_repr(repr(C())))
    with testing_tools.AssertPrints('<__main__.B object at 0x7ff65>'):
        class B(object): pass
        print(normalize_repr(repr(B())))

# Generated at 2022-06-20 12:42:00.144980
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass
    assert isinstance(WritableStreamSubclass(), WritableStream)



# Generated at 2022-06-20 12:42:08.032788
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<module \'os\' from \'c:\\python27'
                          '\\lib\\os.pyc\'> at 0x01ADB9D0') == \
                          '<module \'os\' from \'c:\\python27' \
                          '\\lib\\os.pyc\'>'
    assert normalize_repr('foo at 0x7ff8dbbd8b30') == 'foo'
    assert normalize_repr('bar') == 'bar'

# Generated at 2022-06-20 12:42:17.797026
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=10) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr('1234567890', max_length=10) == '1234567890'
    assert get_shortish_repr('1234567890', max_length=11) == '1234567890'
    assert get

# Generated at 2022-06-20 12:42:26.730399
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(['a', 'b']) == ('a', 'b')
    assert ensure_tuple(('a', 'b')) == ('a', 'b')



# Generated at 2022-06-20 12:42:28.671163
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X:
        def write(self, s):
            print(s)

    assert issubclass(X, WritableStream)

# Generated at 2022-06-20 12:42:31.583027
# Unit test for function shitcode
def test_shitcode():
    import collections
    import string
    
    s = ''.join(chr(i) for i in range(256) + [512, 513])
    assert shitcode(s) == s[:256] + '??'



# Generated at 2022-06-20 12:42:38.764100
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<function func1 at 0x123456>') == '<function func1>'
    assert normalize_repr('<function func2 at 0x456>') == '<function func2>'
    assert normalize_repr('<function func3 at 0x>') == '<function func3>'
    assert normalize_repr('<function func4 at 0xabcdefABCDEF>') == '<function func4>'



# Generated at 2022-06-20 12:42:45.950824
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefg', 10) == 'abcdefg'
    assert truncate('abcdefg', 5) == 'abcde'
    assert truncate('abcdefg', 2) == 'ab'
    assert truncate('abcdefg', 3) == 'abc'
    assert truncate('abcdefg', 4) == 'abcd'
    assert truncate('abcdefg', 7) == 'abcdefg'
    assert truncate('abcdefg', 6) == 'ab...g'
    assert truncate('abcdefg', 8) == 'abc...fg'



# Generated at 2022-06-20 12:42:50.589170
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((3,)) == (3,)
    assert ensure_tuple([3]) == (3,)
    assert ensure_tuple((3, 4)) == (3, 4)
    assert ensure_tuple([3, 4]) == (3, 4)
    assert ensure_tuple(tuple(range(5))) == tuple(range(5))
    assert ensure_tuple(range(5)) == tuple(range(5))
    assert ensure_tuple('hello') == ('hello',)





# Generated at 2022-06-20 12:43:01.636940
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, 'x')]) == 'x'
    assert type(get_repr_function(1, [(int, 'x')])) is type
    assert get_repr_function(2, [(int, 'x')]) != 'x'
    assert get_repr_function(2, [(int, 'x')]) == repr

    assert get_repr_function(1, [(lambda x: x == 1, 'x')]) == 'x'
    assert get_repr_function(2, [(lambda x: x == 1, 'x')]) != 'x'
    assert get_repr_function(2, [(lambda x: x == 1, 'x')]) == repr


# Generated at 2022-06-20 12:43:05.302357
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\x20\x80\xA0\xC0\xF0') == '   ?? ?'
    assert shitcode('abc\x80\xFF') == 'abc??'
    assert shitcode('abc\xff') == 'abc\xff'



# Generated at 2022-06-20 12:43:09.165621
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple((1, 'q')) == (1, 'q')



# Generated at 2022-06-20 12:43:18.792227
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    for item in (1, 1.2):
        assert repr(item) == get_shortish_repr(item)

    for item in (None, True, False):
        assert repr(item) == get_shortish_repr(item, normalize=True)

    assert get_shortish_repr('abcde', max_length=4) == 'ab...'
    assert get_shortish_repr('abcdefghij', max_length=10) == 'abcdefghij'

    assert get_shortish_repr(range(10), max_length=10) == 'range(0, 10)'

    assert get_shortish_repr(range(10), max_length=10, normalize=True) == \
                                                                 'range(0, 10)'


# Generated at 2022-06-20 12:43:28.262215
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("<function at 0xac34>") == "<function>"
    assert normalize_repr("<typing.SetGenerator at 0xac34>") == "<typing.SetGenerator>"



# Generated at 2022-06-20 12:43:33.893447
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('hi') == ('hi',)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(x * 2 for x in (1, 2, 3)) == (2, 4, 6)
    assert ensure_tuple(iter([1, 2, 3])) == (1, 2, 3)

# Generated at 2022-06-20 12:43:41.421674
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', 5) == '1234567890' # Too short
    assert truncate('1234567890', 20) == '1234567890' # Too long
    assert truncate('1234567890', 10) == '1234567890' # The right length
    assert truncate('1234567890', 9) == '12345...890' # Right side
    assert truncate('1234567890', 8) == '1234...890' # Right side
    assert truncate('1234567890', 7) == '123...890' # Right side
    assert truncate('1234567890', 6) == '12...890' # Right side
    assert truncate('1234567890', 5) == '1...90' # Right side

# Generated at 2022-06-20 12:43:47.124596
# Unit test for function normalize_repr
def test_normalize_repr():
    class Foo(object):
        pass

    foo = Foo()
    default_repr = repr(foo)
    assert normalize_repr(default_repr) == repr(foo)
    foo.bar = Foo()
    assert normalize_repr(default_repr) == repr(foo)

# Generated at 2022-06-20 12:43:53.092723
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import io
    import unittest

    class MyStream(io.TextIOBase):
        def write(self, s):
            pass

    assert issubclass(MyStream, WritableStream)

    class MyStream2(io.TextIOBase):
        def write(self, s):
            pass

    class MyStream3(MyStream2):
        pass

    assert issubclass(MyStream3, WritableStream)



# Generated at 2022-06-20 12:43:57.909318
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('a') == 'a'
    assert shitcode('abc') == 'abc'
    assert shitcode('ab\x90c') == 'ab?c'
    assert shitcode('ab\x00c') == 'ab?c'
    assert shitcode('ab\x01c') == 'ab?c'

# Generated at 2022-06-20 12:44:06.201827
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    long_list = list(range(10000))

    assert get_shortish_repr(long_list, max_length=1) == '['
    assert get_shortish_repr(long_list, max_length=2) == '['
    assert get_shortish_repr(long_list, max_length=3) == '[0'
    assert get_shortish_repr(long_list, max_length=4) == '[0,'
    assert get_shortish_repr(long_list, max_length=5) == '[0, 1'
    assert get_shortish_repr(long_list, max_length=6) == '[0, 1,'
    assert get_shortish_repr(long_list, max_length=7) == '[0, 1, 2'
    assert get_shortish

# Generated at 2022-06-20 12:44:09.291474
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)

test_ensure_tuple() # Run the unit test



# Generated at 2022-06-20 12:44:15.816241
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    item = A()
    assert get_repr_function(item, custom_repr=()) == repr

    assert get_repr_function(item, ((A, lambda _: 'my repr'),)) == 'my repr'

    assert (
        get_repr_function(item, ((B, lambda _: 'my repr'),)) == repr
    )



# Generated at 2022-06-20 12:44:25.299866
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, []) == repr
    assert get_repr_function(None, []) == repr
    assert get_repr_function(None, [(lambda x: False, int)]) == repr
    assert get_repr_function(None, [(lambda x: False, int)]) == repr
    assert get_repr_function(None, [(lambda x: False, int)]) == repr
    assert get_repr_function(None, [(lambda x: True, int)]) == int
    assert get_repr_function(None, [(lambda x: True, int)]) == int
    assert get_repr_function(None, [(lambda x: True, int)]) == int

# Generated at 2022-06-20 12:44:48.998246
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamMock(WritableStream):
        def __init__(self):
            self.text = ''
        def write(self, s):
            self.text += str(s)
            return len(s)
    stream = WritableStreamMock()
    stream.write('hello')
    assert stream.text == 'hello'

# Generated at 2022-06-20 12:44:53.656774
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(123) == (123,)
    assert ensure_tuple(('abc',)) == ('abc',)
    assert ensure_tuple(set('abc')) == ('a', 'b', 'c')
    assert ensure_tuple(['abc']) == ('abc',)
    assert ensure_tuple(range(3)) == (0, 1, 2)



# Generated at 2022-06-20 12:45:02.726738
# Unit test for function normalize_repr
def test_normalize_repr():
    class C:
        pass

    c = C()
    base_repr = '<__main__.C object at 0x%x>' % id(c)
    assert normalize_repr(base_repr) == '<__main__.C object>'

    # noinspection PyUnboundLocalVariable
    assert normalize_repr(repr(c)) == base_repr

    assert (normalize_repr('\nHello\nWorld\n%d' % id(c)) ==
            'HelloWorld%d' % id(c))


test_normalize_repr()




# Generated at 2022-06-20 12:45:11.851953
# Unit test for function truncate
def test_truncate():
    assert truncate('abcd', 9) == 'abcd'
    assert truncate('abcd', 8) == 'abcd'
    assert truncate('abcd', 4) == 'abcd'
    assert truncate('abcd', 3) == 'abc...'
    assert truncate('abcd', 2) == 'abc...'
    assert truncate('abcd', 1) == 'a...'
    assert truncate('abcd', 0) == '...'
    assert truncate('abcd', -1) == '...'
    assert truncate('abcd', -2) == '...'
    assert truncate('abcd', -3) == '...'
    assert truncate('abcd', -4) == '...'
    assert truncate('abcd', -5) == '...'



# Generated at 2022-06-20 12:45:15.909503
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyClass:
        pass
    c = MyClass()
    assert not issubclass(MyClass, WritableStream)
    c.write = lambda s: None # No-op
    assert not issubclass(MyClass, WritableStream)
    c.flush = lambda: None # No-op
    assert issubclass(MyClass, WritableStream)



# Generated at 2022-06-20 12:45:19.459671
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, custom_repr=[(type(str), str)]) == repr
    assert get_repr_function('3', custom_repr=[(type(str), str)]) == str

# Generated at 2022-06-20 12:45:28.183907
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('lala') == 'lala'
    assert normalize_repr('a at 0x1234') == 'a'
    assert normalize_repr('  a at 0x1234  ') == '  a  '
    assert normalize_repr('  a at 0x1234 more') == '  a more'
    assert normalize_repr('a at 0x1234 at 0x5678') == 'a at 0x5678'
    assert normalize_repr('a at 0x1234 at 0x5678 at 0x9abc') == \
                                                  'a at 0x5678 at 0x9abc'



# Generated at 2022-06-20 12:45:34.972999
# Unit test for function get_repr_function
def test_get_repr_function():
    from .dot_dict import DotDict
    
    assert get_repr_function(
        DotDict({'a': 1}),
        custom_repr=(
            (lambda x: isinstance(x, DotDict), lambda x: '!DOTDICT!')
        )
    )(DotDict({'a': 1})) == '!DOTDICT!'
    
    assert get_repr_function(
        DotDict({'a': 1}),
        custom_repr=(
            (DotDict, lambda x: '!DOTDICT!')
        )
    )(DotDict({'a': 1})) == '!DOTDICT!'

# Generated at 2022-06-20 12:45:39.637023
# Unit test for function shitcode
def test_shitcode():
    for c in range(256):
        if sys.version_info < (3,):
            s = chr(c)
        else:
            s = bytes([c])
        if not ((0 < ord(s) < 256) or (s == '?')):
            return False
    for c in range(256):
        if sys.version_info < (3,):
            s = chr(c)
        else:
            s = bytes([c])
        if (c < ord(shitcode(s))) and (c > 0):
            return False
    assert shitcode('') == ''
    assert shitcode('\u0000\u0001\u0002') == '???'
    return True

# Generated at 2022-06-20 12:45:47.578989
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function((), []) == repr
    assert get_repr_function((), [(lambda x: True, str)]) == str
    assert get_repr_function((), [((0,), str)]) == repr
    assert get_repr_function((0,), [((0,), str)]) == str
    assert get_repr_function((int,), [(type, str)]) == str
    assert get_repr_function(int, [(type, str)]) == str
    assert get_repr_function(int, [(type, str)]) == str



# Generated at 2022-06-20 12:46:09.396779
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FileType:
        def write(self, s):
            if isinstance(s, str):
                return len(s)
            raise TypeError

    class FileLike:
        def write(self, s):
            if not isinstance(s, str):
                raise TypeError
            self.write_called_with = s
            return len(s)

    class NonWritable:
        pass

    assert isinstance(FileType(), WritableStream)
    assert isinstance(FileLike(), WritableStream)
    assert not isinstance(NonWritable(), WritableStream)



if __name__ == '__main__':
    write = sys.stdout.write
    def unicode_write(s):
        write(s.encode('utf-8'))

# Generated at 2022-06-20 12:46:15.186491
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class A(object):
        def __repr__(self):
            return 'A()'

    assert get_shortish_repr(A()) == 'A()'
    assert get_shortish_repr(
        A(),
        max_length=2,
    ) == 'A'
    assert get_shortish_repr(
        A(),
        max_length=3,
    ) == 'A'
    assert get_shortish_repr(
        A(),
        max_length=4,
    ) == 'A()'
    assert get_shortish_repr(
        A(),
        max_length=5,
    ) == 'A()'
    assert get_shortish_repr(
        A(),
        max_length=14,
    ) == 'A()'




# Generated at 2022-06-20 12:46:18.038274
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)


# Generated at 2022-06-20 12:46:27.495735
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str

    class Foo: pass
    f = Foo()
    assert get_repr_function(f, [(Foo, str)]) is repr

    assert get_repr_function(f, [(type(f), str)]) is str

    assert get_repr_function(f, [(Foo, str), (type(f), str)]) is str
    assert get_repr_function(f, [(type(f), str), (Foo, str)]) is str

    assert get_repr_function(f, [('garbage', str)]) is repr



# Generated at 2022-06-20 12:46:29.582882
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert isinstance(ensure_tuple('a'), tuple)
    assert isinstance(ensure_tuple(['a']), tuple)

# Generated at 2022-06-20 12:46:36.853464
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((3,)) == (3,)
    assert ensure_tuple((3, 4)) == (3, 4)
    assert ensure_tuple(('a', 'b')) == ('a', 'b')
    assert ensure_tuple(['a', 'b']) == ('a', 'b')
    assert ensure_tuple(set(['a', 'b'])) == ('a', 'b')
    assert ensure_tuple({'a', 'b'}) == ('a', 'b')
    assert ensure_tuple([(1, 2), (3, 4)]) == ((1, 2), (3, 4))




# Generated at 2022-06-20 12:46:41.227515
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple([1]) == ([1],)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1, 2]) == ([1, 2],)
    assert ensure_tuple((1, 2)) == (1, 2)



# Generated at 2022-06-20 12:46:50.622012
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert (get_shortish_repr(1, (), 5) == '1')
    assert (get_shortish_repr(1, (), 4) == '1')
    assert (get_shortish_repr(1, (), 3) == '1')
    assert (get_shortish_repr(1, (), 2) == '1')
    assert (get_shortish_repr(1, (), 1) == '1')
    assert (get_shortish_repr(1, (), 0) == '1')
    assert (get_shortish_repr(1, (), None) == '1')


    assert (get_shortish_repr(12345, (), 5) == '12345')
    assert (get_shortish_repr(12345, (), 4) == '12345')

# Generated at 2022-06-20 12:46:57.554789
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Testing the abstractmethod
    from .testing_tools.asserting import assert_not_implemented_message

    class C(WritableStream): pass

    assert_not_implemented_message(
        C.write,
        C(),
        '`{}` must implement `{}`.'.format(C.__qualname__, 'write')
    )

    # Testing the subclasshook
    class D(WritableStream): pass
    class E(D): pass
    class F(E): pass
    class G(F): pass

    class H(G): pass
    class I(H): pass
    class J(I): pass

    class K(J): pass

# Generated at 2022-06-20 12:47:01.800727
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(StrStream, WritableStream)
    assert issubclass(BytesStream, WritableStream)
    assert issubclass(BytesNewlineStream, BytesStream)
    assert not issubclass(GetItemMapping, WritableStream)



# Generated at 2022-06-20 12:47:23.733523
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout.__class__, WritableStream)

# Generated at 2022-06-20 12:47:34.825278
# Unit test for function truncate
def test_truncate():
    assert truncate(u'Hello', None) == u'Hello'
    assert truncate(u'Hello', 5) == u'Hello'
    assert truncate(u'Hello', 4) == u'Hell'
    assert truncate(u'Hello', 3) == u'Hel'
    assert truncate(u'Hello', 2) == u'He'
    assert truncate(u'Hello', 1) == u'H'
    assert truncate(u'Hello', 0) == u''
    assert truncate(u'Hello', -1) == u''
    assert truncate(u'foo bar', 10) == u'foo bar'
    assert truncate(u'foo bar', 9) == u'foo bar'
    assert truncate(u'foo bar', 8) == u'foo bar'

# Generated at 2022-06-20 12:47:39.580813
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('1234567890', 9) == '1234567...'
    assert truncate('1234567890', 8) == '12345...'
    assert truncate('1234567890', 7) == '1234...'
    assert truncate('1234567890', 6) == '123...'
    assert truncate('1234567890', 3) == '123'



# Generated at 2022-06-20 12:47:48.790759
# Unit test for function shitcode
def test_shitcode():
    import random
    assert shitcode(u'') == u''
    assert shitcode(u'\x00\x01\x02\x03') == u'\x00\x01\x02\x03'
    assert shitcode(u'abcd') == u'abcd'
    assert shitcode(u'a\x00bc\x02d') == u'a\x00bc\x02d'
    assert shitcode(u'a\x00bc\x02d\x05\x07') == u'a\x00bc\x02d\x05\x07'
    assert shitcode(u'a\x7fbc\x02d') == u'a?bc\x02d'

# Generated at 2022-06-20 12:47:51.182652
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)



# Generated at 2022-06-20 12:47:54.760503
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('''
a: abc
b: דג
c: 1, 2, 3, 4, 5
''') == '''
a: abc
b: ?
c: 1, 2, 3, 4, 5
'''



# Generated at 2022-06-20 12:48:04.480289
# Unit test for function get_repr_function
def test_get_repr_function():
    item = object()
    assert get_repr_function(item, ()) is repr
    assert get_repr_function(item,
                             ((lambda x: False, None),)) is repr
    assert get_repr_function(item, ((lambda x: True, None),)) is None
    assert get_repr_function(item,
                             ((lambda x: True, None),
                              (lambda x: True, None))) is None
    assert get_repr_function(item,
                             ((lambda x: True, None),
                              (lambda x: False, lambda i: 'meh')))() == 'meh'
    assert get_repr_function(item, ((None, None),)) is None

# Generated at 2022-06-20 12:48:10.426939
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hello', custom_repr=[]) == repr

    assert get_repr_function(
        'hello',
        custom_repr=[
            (lambda x: x.startswith('he'),
             lambda x: 'foo'),
        ]
    ) == (lambda x: 'foo')

    assert get_repr_function(
        'hello',
        custom_repr=[
            (lambda x: False, lambda x: 'foo'),
        ]
    ) == repr

