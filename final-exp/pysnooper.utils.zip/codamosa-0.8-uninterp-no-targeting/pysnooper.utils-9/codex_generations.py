

# Generated at 2022-06-20 12:38:16.520558
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Stream(WritableStream):
        def __init__(self):
            self.written = []
        def write(self, s):
            self.written.append(s)
    
    stream = Stream()
    stream.write('hello')
    assert stream.written == ['hello']

# Generated at 2022-06-20 12:38:24.403879
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnopqrstuvwxyz', 10) == 'abcd...xyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', None) == \
           'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 26) == \
           'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 27) == \
           'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 25) == 'abcd...wxyz'

# Generated at 2022-06-20 12:38:28.123947
# Unit test for constructor of class WritableStream
def test_WritableStream():
    """Implementation of `WritableStream` is correct"""
    class WritableStreamTest(WritableStream):
        def write(self, s):
            return s
    assert issubclass(WritableStreamTest, WritableStream)


# Generated at 2022-06-20 12:38:35.157573
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('') == ''

    assert normalize_repr('a') == 'a'

    assert normalize_repr('a at 0x0000') == 'a'

    assert normalize_repr('a at 0xFFFFFF') == 'a'

    assert normalize_repr('a at 0xFFFFFFF') == 'a at 0xFFFFFFF'

    assert normalize_repr('a at 0xFFFFFAA') == 'a at 0xFFFFFAA'

# Generated at 2022-06-20 12:38:45.557694
# Unit test for function truncate
def test_truncate():
    assert truncate(None, 3) is None
    assert truncate('', 3) == ''
    assert truncate('hi', None) == 'hi'
    assert truncate('hi', 0) == 'hi'
    assert truncate('hi', 1) == 'h...'
    assert truncate('hi', 2) == 'hi'
    assert truncate('hi', 3) == 'hi'
    assert truncate('hi', 4) == 'hi'
    assert truncate('hi', 5) == 'hi'
    assert truncate('hello', 3) == '...'
    assert truncate('hello', 4) == 'h...'
    assert truncate('hello', 5) == 'he...'
    assert truncate('hello', 6) == 'hel...'
    assert truncate('hello', 7) == 'hello'
    assert truncate

# Generated at 2022-06-20 12:38:54.399380
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(()) == ()
    assert ensure_tuple([]) == ()
    assert ensure_tuple(set()) == ()
    assert ensure_tuple('x') == ('x',)
    assert ensure_tuple(('x',)) == ('x',)
    assert ensure_tuple(['x']) == ('x',)
    assert ensure_tuple({'x'}) == ('x',)
    assert ensure_tuple(('x', 'y')) == ('x', 'y')
    assert ensure_tuple(['x', 'y']) == ('x', 'y')
    assert ensure_tuple({'x', 'y'}) == ('x', 'y')




# Generated at 2022-06-20 12:39:02.898669
# Unit test for function truncate
def test_truncate():
    for s in [
        '',
        'a',
        'aa',
        'aaa',
        'aaaa',
        'a' * 1000,
    ]:
        assert truncate(s, max_length=100) == s

    assert truncate('abcdefghijklmnopqrstuvwxyz', 4) == 'a...z'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 5) == 'ab...z'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 6) == 'ab...yz'



# Generated at 2022-06-20 12:39:08.586622
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<function> at 0x123') == '<function>'
    assert normalize_repr('<function> at 0x123123123123123') == '<function>'
    assert normalize_repr('<function> at 0x123123123 (test)') == \
           '<function> at 0x123123123 (test)'
    assert normalize_repr('<function> at 0x123') == '<function>'
    assert normalize_repr('\\x00\\x00\\x00\\x00') == '\\x00\\x00\\x00\\x00'
    assert normalize_repr('\\n') == '\\n'

# Generated at 2022-06-20 12:39:11.670469
# Unit test for function normalize_repr
def test_normalize_repr():
    import random
    for n in range(100):
        s = ''.join(random.choice('abcdefghijklmno') for i in range(n))
        assert normalize_repr(repr(s)) == repr(s)

# Generated at 2022-06-20 12:39:22.341173
# Unit test for function get_repr_function
def test_get_repr_function():
    get_repr = get_repr_function

    str_repr = get_repr('meow', custom_repr=(
        (str, lambda s: '<repr: string>'),
    ))
    assert str_repr == '<repr: string>'

    class Meow: pass
    class Woof: pass
    class Dog: pass

    meow_repr = get_repr(Meow(), custom_repr=(
        (Meow, lambda m: '<repr: Meow>'),
    ))
    assert meow_repr == '<repr: Meow>'

    meow_repr = get_repr(Woof(), custom_repr=(
        (Meow, lambda m: '<repr: Meow>'),
    ))
    assert meow_repr == repr(Woof())

# Generated at 2022-06-20 12:39:32.503365
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    for item, expected_repr in [
        ({}, '{}'),
        ({1, 2, 3}, '{1, 2, 3}'),
        ({1: 'a', 2: 'b', 3: 'c'}, "{1: 'a', 2: 'b', ...}"),
        (set([1, 2, 3]), '{1, 2, 3}'),
        ((1, 2, 3), '(1, 2, 3)'),
        ([1, 2, 3], '[1, 2, 3]'),
        (1, '1'),
        (1.0, '1.0'),
        ('foo', "'foo'"),
        (['long', 'list'], "['long', 'l...']")
    ]:
        assert get_shortish_repr(item, max_length=10) == expected_repr

# Generated at 2022-06-20 12:39:36.304398
# Unit test for constructor of class WritableStream
def test_WritableStream():
    def MyWritable(_file):
        class MyWritableStream(WritableStream):
            def write(self, s):
                _file.write(s)
        return MyWritableStream()
    import io
    a = MyWritable(io.StringIO())
    a.write(u'abc\r\n')
    assert a.write(u'def\r\n') is None


if __name__ == '__main__':
    test_WritableStream()

# Generated at 2022-06-20 12:39:41.018912
# Unit test for function truncate
def test_truncate():
    assert truncate('', None) == ''
    assert truncate('', 0) == ''
    assert truncate('', 10) == ''
    assert truncate('', 100) == ''
    assert truncate('1234567890', None) == '1234567890'
    assert truncate('1234567890', 0) == ''
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('1234567890', 4) == '...'
    assert truncate('1234567890', 5) == '1...0'
    assert truncate('1234567890', 6) == '12...0'
    assert truncate('1234567890', 7) == '12...90'
    assert truncate('1234567890', 8) == '12...890'

# Generated at 2022-06-20 12:39:48.784510
# Unit test for function shitcode
def test_shitcode():
    r'''
    Given a sequence that's a mixture of crappy and good characters,
    the shitcode function should replace the crappy ones with
    question marks.
    '''
    from . import string_tools
    high_numbers = []
    for i in range(256, 1000):
        c = chr(i)
        try:
            string_tools.ensure_unicode(c)
        except UnicodeDecodeError:
            high_numbers.append(c)
    assert shitcode('good') == 'good'
    assert shitcode('good\xff') == 'good?'
    assert shitcode('good' + ''.join(chr(i) for i in range(256, 1000))) == \
                                                            'good' + '?' * len(
                                                            high_numbers)

# Generated at 2022-06-20 12:39:56.184891
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, ((int, str),)) == str
    assert get_repr_function(0, ((str, list),)) == repr
    assert get_repr_function(0, ((str, list), (int, str))) == str
    assert get_repr_function(0, ((str, list), (str, list))) == repr
    assert get_repr_function(0, ((str, list), (1, str))) == repr
    assert get_repr_function(0, ((str, list), (1, list))) == repr
    assert get_repr_function([], ((str, list), (1, list))) == list.__repr__




# Generated at 2022-06-20 12:39:59.304839
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('\u0410') == '?'
    assert shitcode('ab\u0400cd') == 'ab?cd'
    assert shitcode('ab\ubc00cd') == 'ab?cd'
    assert shitcode('Ыкщла') == '?к?ла'



# Generated at 2022-06-20 12:40:09.685530
# Unit test for function truncate
def test_truncate():

    assert truncate(u'a', 1) == u'a'
    assert truncate(u'abc', 2) == u'ab'
    assert truncate(u'abc', 3) == u'abc'
    assert truncate(u'abc', 4) == u'a...c'
    assert truncate(u'abcdef', 4) == u'a...f'
    assert truncate(u'abcdef', 5) == u'ab...f'
    assert truncate(u'abcdef', 6) == u'abc...f'
    assert truncate(u'abcdef', 7) == u'a...ef'
    assert truncate(u'abcdefg', 7) == u'a...fg'
    assert truncate(u'abcdefgh', 7) == u'ab...gh'

# Generated at 2022-06-20 12:40:10.745008
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import io
    assert isinstance(io.BytesIO(), WritableStream)


# Generated at 2022-06-20 12:40:21.701834
# Unit test for function truncate

# Generated at 2022-06-20 12:40:31.635742
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('kdjfhkjds 0xdeadbeef') == 'kdjfhkjds '
    assert normalize_repr('kdjfhkjds 0xdeadbee') == 'kdjfhkjds 0xdeadbee'
    assert normalize_repr('kdjfhkjds 0xdeadbeef0') == 'kdjfhkjds 0xdeadbeef0'
    assert normalize_repr('kdjfhkjds 0xdeadbeef') == 'kdjfhkjds '
    assert normalize_repr('kdjfhkjds 0x') == 'kdjfhkjds 0x'
    assert normalize_repr('kdjfhkjds 0xef') == 'kdjfhkjds 0xef'

# Generated at 2022-06-20 12:40:42.552439
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('sdalkjh') == 'sdalkjh'
    assert normalize_repr('sdalkjh at 0x1234') == 'sdalkjh'
    assert normalize_repr('sdalkjh at 0x123456789') == 'sdalkjh'
    assert normalize_repr('sdalkjh at 0') == 'sdalkjh'
    assert normalize_repr('sdalkjh at 0') == 'sdalkjh'
    assert normalize_repr('sdalkjh at 0x1') == 'sdalkjh'
    assert normalize_repr('sdalkjh at 0x12') == 'sdalkjh'
    assert normalize_repr('sdalkjh at 0x123') == 'sdalkjh'
    assert normal

# Generated at 2022-06-20 12:40:48.594417
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hi there') == 'hi there'
    assert normalize_repr('hi there at 0x1234') == 'hi there'
    assert normalize_repr('hi there at 0x12345') == 'hi there'
    assert normalize_repr('hi there at 0x123456') == 'hi there'
    assert normalize_repr('hi there at 0x1234567') == 'hi there'
    assert normalize_repr('hi there at 0x12345678') == 'hi there'
    assert normalize_repr('hi there at 0x123456789') == 'hi there'
    assert normalize_repr('hi there at 0x123456789A') == 'hi there'

# Generated at 2022-06-20 12:40:56.062186
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr('a') == 'a'
    assert get_shortish_repr('a' * 50) == 'a' * 50
    assert get_shortish_repr('a' * 50, max_length=15) == 'a' * 15 + '...'
    assert get_shortish_repr('a' * 50, max_length=16) == 'a' * 15 + '...'
    assert get_shortish_repr('a' * 50, max_length=17) == 'a' * 8 + '...' + 'a' * 8
    assert get_shortish_repr('a' * 51, max_length=17) == 'a' * 8 + '...' + 'a' * 8
    assert get

# Generated at 2022-06-20 12:40:57.270651
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout, WritableStream)
    assert issubclass(sys.stderr, WritableStream)

# Generated at 2022-06-20 12:41:01.887309
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple('hi') == ('hi',)
    assert ensure_tuple(set([1, 2])) == (1, 2)
    assert ensure_tuple(set([1, 2, 1])) == (1, 2)



# Generated at 2022-06-20 12:41:05.256229
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Temp(WritableStream):
        pass
    Temp.register(sys.stdout.__class__)

    assert isinstance(sys.stdout, WritableStream)

# Generated at 2022-06-20 12:41:12.007818
# Unit test for function shitcode
def test_shitcode():
    tests = [
        ('a', 'a'),
        ('a\r\nb', 'a?b'),
        ('a\r\nb\r\nαβγ', 'a?b?αβγ'),
        ('\r', '?'),
        ('\n', '?'),
        ('', ''),
        ('αβγ', 'αβγ'),
    ]
    for raw, expected in tests:
        assert shitcode(raw) == expected



# Generated at 2022-06-20 12:41:24.058019
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import nose.tools
    nose.tools.assert_equal(
        get_shortish_repr(100, max_length=1, normalize=False),
        '100'
    )
    nose.tools.assert_equal(
        get_shortish_repr('abc', max_length=1, normalize=False),
        "'a...'"
    )
    nose.tools.assert_equal(
        get_shortish_repr('abc', max_length=3, normalize=False),
        "'abc'"
    )
    nose.tools.assert_equal(
        get_shortish_repr('abcdefghijklmnopqrstuvwxyz',
                          max_length=10, normalize=False),
        "'abcdefghi...xyz'"
    )

# Generated at 2022-06-20 12:41:28.188499
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x0') == 'hello'
    assert normalize_repr('hello at 0xFF12A1D') == 'hello'
    assert normalize_repr('hello at 0x') == 'hello at 0x'



# Generated at 2022-06-20 12:41:33.660804
# Unit test for function get_repr_function
def test_get_repr_function():
    import collections

    assert get_repr_function(1, custom_repr=((int, lambda _: '1'),)) == '1'
    assert get_repr_function(1, custom_repr=((int, lambda _: '1'),),
                             ) == repr

    assert get_repr_function((1,), custom_repr=((tuple, lambda _: 'tuple'),)) == 'tuple'
    assert get_repr_function((1,), custom_repr=((tuple, lambda _: 'tuple'),),
                             ) == repr

    assert get_repr_function((1,), custom_repr=((collections.abc.Iterable,
                                                 lambda _: 'iterable'),)) == 'iterable'

# Generated at 2022-06-20 12:41:44.979512
# Unit test for function get_repr_function
def test_get_repr_function():

    class A(object): pass
    class B(A): pass
    class C(object): pass

    for (repr_source, repr_target) in [
        (repr, repr),
        (str, repr),
        (A, str),
        (A, lambda: 'hi'),
        (B, str),
        (A, str),
        (C, repr),
    ]:
        assert (get_repr_function(repr_source, [
            (repr, repr_target),
            (str, str),
        ]) == repr_target)



# Generated at 2022-06-20 12:41:51.667088
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.my_string = ''
        def write(self, s):
            self.my_string += s

    my_writable_stream = MyWritableStream()

    my_writable_stream.write('Hello!')

    assert my_writable_stream.my_string == 'Hello!'

    my_writable_stream.write(' Goodbye!')

    assert my_writable_stream.my_string == 'Hello! Goodbye!'



# Generated at 2022-06-20 12:41:53.979134
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class DummyWritableStream(WritableStream):
        def write(self, s):
            pass

    DummyWritableStream()

# Generated at 2022-06-20 12:42:01.212066
# Unit test for function truncate
def test_truncate():
    assert(truncate('hello', 10) == 'hello')
    assert(truncate('hello', 5) == 'hello')
    assert(truncate('hello', 4) == 'he...')
    assert(truncate('hello', 3) == 'h...')
    assert(truncate('hello', 2) == '...')



if not hasattr(sys.stdout, 'buffer'): # Python 2
    class OneLinePrinter(object):
        def __init__(self, stream=sys.stdout):
            self.stream = stream
        def write(self, s):
            l = s.replace('\r\n', '\n').replace('\r', '\n').splitlines()

# Generated at 2022-06-20 12:42:06.634627
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .context_tools import ContextManaged
    class CustomObj(ContextManaged):
        __repr__ = ContextManaged.create_repr('test_repr')
    custom_repr = (((CustomObj, ), lambda x: 'custom'),)
    assert get_shortish_repr(CustomObj('foo'), custom_repr) == 'custom'

# Generated at 2022-06-20 12:42:15.041537
# Unit test for function shitcode
def test_shitcode():
    # A test for the function shitcode; makes sure it works for all bytes
    for i in range(256):
        if i in (ord('?'), ord('\\')):
            continue
        s = bytes([i])
        s2 = shitcode(s)
        assert isinstance(s, bytes)
        assert isinstance(s2, str)
        assert len(s2) == 1
        assert ord(s2) == i

    assert shitcode('asdf') == 'asdf'
    assert shitcode('\x80\x81\x82') == '???'
    assert shitcode('\x80\x81\x82\x83\x84') == '?????'
    assert shitcode('\xff\xee\xdd\xcc') == '????'



# Generated at 2022-06-20 12:42:17.640349
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        pass

    A()
    assert issubclass(object, WritableStream)
    assert not issubclass(A, object)

# Generated at 2022-06-20 12:42:24.423547
# Unit test for function get_repr_function
def test_get_repr_function():

    x = get_repr_function('hello', [(int, repr), (float, repr)])
    assert x == repr

    def repr_number(x):
        if isinstance(x, (int, float)):
            return str(x)
        raise TypeError
    x = get_repr_function(1.1, [(int, repr), (float, repr_number)])
    assert x(1.1) == '1.1'

    def repr_number_or_nothing(x):
        if isinstance(x, (int, float)):
            return str(x)
        if isinstance(x, string_types):
            return ''
        raise TypeError
    x = get_repr_function(1.1, [(int, repr),
                                (float, repr_number_or_nothing)])
   

# Generated at 2022-06-20 12:42:33.194975
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('foo', custom_repr=[(str, str)]) == str
    assert get_repr_function('foo', custom_repr=[(int, str)]) == repr
    assert get_repr_function(1, custom_repr=[(str, str)]) == repr
    assert get_repr_function(1, custom_repr=[(int, str)]) == str
    assert get_repr_function('foo', custom_repr=[(str, str), (int, str)]) == str
    assert get_repr_function(1, custom_repr=[(str, str), (int, str)]) == str
    assert get_repr_function([1, 2, 3], custom_repr=[(str, str), (list, str)]) == str
    assert get_re

# Generated at 2022-06-20 12:42:40.683998
# Unit test for function truncate
def test_truncate():
    assert truncate('', 5) == ''
    assert truncate('x', 5) == 'x'
    assert truncate('xxx', 5) == 'xxx'
    assert truncate('xxxxx', 5) == 'xxxxx'
    assert truncate('xxxxxx', 5) == '...xx'
    assert truncate('xxxxxxx', 5) == '...xxx'
    assert truncate('xxxxxxxx', 5) == '...xxx'
    assert truncate('xxxxxxxxx', 5) == '...xxxx'

# Generated at 2022-06-20 12:42:56.124595
# Unit test for function normalize_repr
def test_normalize_repr():
    class A(object):
        pass
    a = A()
    if sys.flags.optimize >= 1:
        a_repr = '<A object>'
    else:
        a_repr = '<__main__.A object at 0x' + hex(id(a))[:-1] + '>'

    assert normalize_repr(a_repr) == '<__main__.A object>'



# Generated at 2022-06-20 12:43:02.109214
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: x == 1, False)]) is False
    assert get_repr_function(1, [(lambda x: x != 1, False)]) is repr
    assert get_repr_function(dict(), [(dict, False)]) is False
    assert get_repr_function(dict(), [(dict, False), (dict, True)]) is True



# Generated at 2022-06-20 12:43:10.233924
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import truncating_stream
    truncating_stream.DEFAULT_MAX_LENGTH = 50
    assert get_shortish_repr(3, max_length=50) == '3'
    assert get_shortish_repr(3, max_length=4) == '3'
    assert get_shortish_repr(3, max_length=3) == '3'
    assert get_shortish_repr(3, max_length=2) == '3'
    assert get_shortish_repr(3, max_length=1) == '3'
    assert get_shortish_repr(3, max_length=0) == '...'
    assert get_shortish_repr(3, max_length=None) == '3'


# Generated at 2022-06-20 12:43:17.177319
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (str, str)) == str
    assert get_repr_function('1', (str, str)) == str
    assert get_repr_function(1, (1, str)) == str
    assert get_repr_function(2, (1, str)) == repr
    assert get_repr_function(1, (lambda x: x==1, str)) == str
    assert get_repr_function(2, (lambda x: x==1, str)) == repr



# Generated at 2022-06-20 12:43:22.952730
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    try:
        class _WritableStream(WritableStream):
            def __init__(self):
                pass
    except TypeError:
        print('Subclassing by class without implementing abstract method write'
              ' causes exception:')
        sys.excepthook(*sys.exc_info())
    else:
        print('Subclassing by class without implementing abstract method write'
              ' does not cause exception.')

    try:
        class _WritableStream(WritableStream):
            def __init__(self):
                pass
            def foo():
                pass
    except TypeError:
        print('Subclassing by class with unimplemented abstract method write'
              ' and extra method causes exception:')
        sys.excepthook(*sys.exc_info())

# Generated at 2022-06-20 12:43:33.737593
# Unit test for function shitcode
def test_shitcode():
    import sys
    if sys.implementation.name == 'ironpython':
        pass # Can't support this in IronPython at the moment.
    else:
        assert shitcode('a') == 'a'
        assert shitcode('"') == '\\"'
        assert shitcode('\n') == '\n'
        assert shitcode('\r') == '\r'
        assert shitcode('\t') == '\t'
        assert shitcode('☺') == '?'
        assert shitcode('☻') == '?'
        assert shitcode('\U0001F44D') == '?'
        assert shitcode('\U0001F44E') == '?'
        assert shitcode('\U0001F44F') == '?'
        assert shitcode('\U0001F450') == '?'

# Generated at 2022-06-20 12:43:36.989485
# Unit test for function get_repr_function
def test_get_repr_function():
    int_repr = lambda i: 'int %s' % i
    my_int = type('my_int', (int,), {})
    sample_custom_repr = ((str, str), (lambda x: x > 5, int),
                          (my_int, int_repr))
    for sample in ('a', 7, my_int(6), 7.5):
        repr_function = get_repr_function(sample, sample_custom_repr)
        print(sample)
        print(repr_function)
        print(repr_function(sample))
        print()


if __name__ == '__main__':
    test_get_repr_function()

# Generated at 2022-06-20 12:43:40.632765
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import sys
    assert isinstance(sys.stdout, WritableStream)
    assert isinstance(sys.stderr, WritableStream)
    class Good(object):
        def write(self, s):
            pass
    class Bad(object):
        pass
    assert isinstance(Good(), WritableStream)
    assert not isinstance(Bad(), WritableStream)



# Generated at 2022-06-20 12:43:45.983608
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('this is a string') == 'this is a string'
    assert normalize_repr('this is a string at 0x5') == 'this is a string'
    assert normalize_repr('this is a string at 0xABCABC') == 'this is a string'

# Generated at 2022-06-20 12:43:51.263877
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class C(metaclass=ABCMeta):
        @abc.abstractmethod
        def write(self, s):
            pass
        def read(self):
            pass

    assert issubclass(C, WritableStream)
    assert not issubclass(WritableStream, C)
    assert not issubclass(int, WritableStream)
    assert not issubclass(C, int)

# Generated at 2022-06-20 12:44:15.386970
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class DummyWritableStream(WritableStream):
        def write(self, s):
            pass

    DummyWritableStream()

# Generated at 2022-06-20 12:44:20.239695
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple({1, 2, 3}) == ({1, 2, 3},)



# Generated at 2022-06-20 12:44:25.841326
# Unit test for constructor of class WritableStream
def test_WritableStream():
    """
    Assert that the following classes are all `WritableStream`s.
    """
    assert issubclass(int, WritableStream) # int can `write` to ints like `1+2`
    assert issubclass(list, WritableStream) # lists can append
    assert issubclass(dict, WritableStream) # dicts can setitem
    assert issubclass(file, WritableStream) # files can do `.write`
    assert issubclass(sys.stdout, WritableStream) # `print` is `write`



# Generated at 2022-06-20 12:44:35.726438
# Unit test for function truncate
def test_truncate():
    assert truncate('asdf', None) == 'asdf'
    assert truncate('asdf', 10) == 'asdf'
    assert truncate('asdf', 3) == 'asd'
    assert truncate('asdf', 4) == 'asdf'
    assert truncate('asdf', 5) == 'asdf'
    assert truncate('asdf', 6) == 'asdf'
    assert truncate('asdf', 7) == 'asdf'
    assert truncate('asdf', 8) == 'asdf'
    assert truncate('asdf', 9) == 'asd...f'
    assert truncate('asdf', 2) == 'a...'
    assert truncate('asdf', 1) == '...'
    assert truncate('asdf', 0) == ''

# Generated at 2022-06-20 12:44:44.671396
# Unit test for function shitcode
def test_shitcode():
    def _test_shitcode(s):
        return (s, shitcode(s))
    tests = [
        _test_shitcode(''),
        _test_shitcode('a'),
        _test_shitcode('abc'),
        _test_shitcode('abcdefg'),
        _test_shitcode(u'\u1234'),
        _test_shitcode(u'\u1234\u5678\u9012'),
    ]
    assert tests == [
        ('', ''),
        ('a', 'a'),
        ('abc', 'abc'),
        ('abcdefg', 'abcdefg'),
        (u'\u1234', '?'),
        (u'\u1234\u5678\u9012', '???'),
    ]



# Generated at 2022-06-20 12:44:49.077010
# Unit test for function ensure_tuple
def test_ensure_tuple():
    from python_toolbox import cute_testing
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((4, 5)) == (4, 5)
    with cute_testing.RaiseAssertor(TypeError):
        assert ensure_tuple(u'hello')
    with cute_testing.RaiseAssertor(TypeError):
        assert ensure_tuple(list(range(10)))

# Generated at 2022-06-20 12:44:58.976030
# Unit test for function ensure_tuple
def test_ensure_tuple():
    import pytest

# Generated at 2022-06-20 12:45:00.894283
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class W(WritableStream):
        def write(self, s):
            pass
    W()



# Generated at 2022-06-20 12:45:07.866951
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.1, [(int, str)]) == repr
    assert get_repr_function(1, [(_.__lt__, str)]) == str
    assert get_repr_function(1, [(lambda x: x > 0, str)]) == str
    assert get_repr_function(1, [(lambda x: x > 100, str)]) == repr



# Generated at 2022-06-20 12:45:11.571981
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self._buffer = []

        def write(self, s):
            self._buffer.append(s)

    mws = MyWritableStream()
    mws.write('spam')
    assert mws._buffer == ['spam']



# Generated at 2022-06-20 12:45:31.601799
# Unit test for function normalize_repr
def test_normalize_repr():
    from .python_toolbox.temp_value_setters import TempValueSetter
    from .abc import CustomRepr
    from .string_tools import pluralize
    
    assert normalize_repr('[1, 2, 3] at 0x123456') == '[1, 2, 3]'
    assert normalize_repr('[1, 2, 3]') == '[1, 2, 3]'
    
    
    class AddressfulRepr(CustomRepr):
        def __init__(self):
            def funky_repr(address):
                return lambda obj: '[{}] at 0x{:x}'.format(obj, address)
            self.funky_repr = funky_repr
            

# Generated at 2022-06-20 12:45:32.411445
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<type \'int\'> at 0x0A47E430') == '<type \'int\'>'



# Generated at 2022-06-20 12:45:36.119079
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(('a', 'b')) == ('a', 'b')
    assert ensure_tuple(['a', 'b']) == ('a', 'b')
    assert ensure_tuple('ab') == ('ab',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1,)) == (1,)

# Generated at 2022-06-20 12:45:39.194434
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('ěščřžýáíé') == '????r??y?i?'
    assert shitcode(u'ěščřžýáíé') == '????r??y?i?'



# Generated at 2022-06-20 12:45:49.265714
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([1, 2, 'a'], max_length=10) == "[1, 2, 'a']"
    assert get_shortish_repr([1, 2, 'a'], max_length=8) == "[1, 2, 'a']"
    assert get_shortish_repr([1, 2, 'a'], max_length=7) == "[1, 2..."
    assert get_shortish_repr([1, 2, 'a'], max_length=6) == "[1, 2..."
    assert get_shortish_repr([1, 2, 'a'], max_length=5) == "[1, 2..."
    assert get_shortish_repr([1, 2, 'a'], max_length=3) == "[1, 2..."
    assert get_short

# Generated at 2022-06-20 12:45:56.718855
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<unittest.TestCase testMethod=test_normalize_repr>') == \
           '<unittest.TestCase testMethod=test_normalize_repr>'
    assert normalize_repr('<unittest.TestCase testMethod=test_normalize_repr at 0x0BADF00D>') == \
           '<unittest.TestCase testMethod=test_normalize_repr>'
    assert normalize_repr('<unittest.TestCase testMethod=test_normalize_repr at 0x0BADF00D> asdf') == \
           '<unittest.TestCase testMethod=test_normalize_repr> asdf'

# Generated at 2022-06-20 12:46:05.135529
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple([5, 6]) == (5, 6)
    assert ensure_tuple(xrange(5)) == (0, 1, 2, 3, 4)
    assert ensure_tuple({5, 6}) == ({5, 6},)  # Not (5, 6): A set is hashable
    assert ensure_tuple({'a': 'b'}) == ({'a': 'b'},)
    assert ensure_tuple(set(xrange(5))) == ({0, 1, 2, 3, 4},)



# Generated at 2022-06-20 12:46:06.579620
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class C(WritableStream):
        def write(self, s):
            pass
    c = C()

# Generated at 2022-06-20 12:46:13.468466
# Unit test for function truncate
def test_truncate():
    assert truncate('some string', None) == 'some string'
    assert truncate('some string', 10) == 'some string'
    assert truncate('some string', 9) == 'some ...ing'
    assert truncate('some string', 8) == 'some ...ng'
    assert truncate('some string', 7) == 'some ...ng'
    assert truncate('some string', 6) == 'some ...'
    assert truncate('some string', 5) == 'som...'
    assert truncate('some string', 4) == 'som...'
    assert truncate('some string', 3) == 'som...'
    assert truncate('some string', 2) == 'so...'
    assert truncate('some string', 1) == '...'
    assert truncate('some string', 0) == '...'



# Generated at 2022-06-20 12:46:20.134380
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.text = ''

        def write(self, s):
            self.text += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    my_writable_stream.write(' world')
    assert my_writable_stream.text == 'hello world'

# Generated at 2022-06-20 12:46:50.337967
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [lambda x: isinstance(x, type(''))]) == repr
    assert get_repr_function(1, [lambda x: isinstance(x, int)]) == repr
    assert get_repr_function(1, [lambda x: isinstance(x, int), lambda x: x+1]) == (1).__add__
    assert get_repr_function(1, [(int, lambda x: x+1)]) == (1).__add__

# Generated at 2022-06-20 12:46:57.319367
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple((1, (2, 3))) == (1, (2, 3))
    assert ensure_tuple((1, [2, 3])) == (1, [2, 3])
    assert ensure_tuple((1, {2: 3})) == (1, {2: 3})
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple([1, [2, 3]]) == (1, [2, 3])
    assert ensure_tuple([1, {2: 3}]) == (1, {2: 3})

# Generated at 2022-06-20 12:47:08.001180
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('a') == 'a'
    assert shitcode('a' * 1000) == 'a' * 1000
    assert shitcode('abcdefghijklmnopqrstuvwxyz') == \
                                                 'abcdefghijklmnopqrstuvwxyz'
    assert shitcode('\U0001f60b') == '?'
    assert shitcode('\U0001f60b' * 1000) == '?' * 1000
    assert shitcode('\n') == '\n'
    assert shitcode('\n' * 1000) == '\n' * 1000
    assert shitcode('\xE0\xA4\xA7') == '?'

# Generated at 2022-06-20 12:47:12.041973
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(()) == ()
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple('abc') == ('abc',)



# Generated at 2022-06-20 12:47:14.559591
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)

# Generated at 2022-06-20 12:47:19.116664
# Unit test for function truncate
def test_truncate():
    strings = ['a', '12345', '1234567890', '12345678901234567890']
    max_lengths = [None, 1, 3, 4, 5, 10, 20]
    for string in strings:
        for max_length in max_lengths:
            assert truncate(string, max_length) ==  \
                                      string[:max_length].ljust(max_length, '.')



# Generated at 2022-06-20 12:47:24.136637
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, 'hello'),
                                 (str, 'world'))) == 'hello'
    assert get_repr_function('yes', ((int, 'hello'),
                                     (str, 'world'))) == 'world'
    assert get_repr_function([], ((int, 'hello'),
                                  (str, 'world'))) == repr

# Generated at 2022-06-20 12:47:33.806529
# Unit test for function truncate
def test_truncate():
    assert truncate('12345', 4) == '...5'
    assert truncate('12345', 5) == '1...5'
    assert truncate('12345', 6) == '12345'
    assert truncate('12345', None) == '12345'
    assert truncate('123456789', 6) == '1...9'
    assert truncate('123456789', 7) == '12...9'
    assert truncate('123456789', 8) == '123...9'
    assert truncate('123456789', 9) == '1234...9'
    assert truncate('123456789', None) == '123456789'



# Generated at 2022-06-20 12:47:41.131470
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', None) == '1234567890'
    assert truncate('1234567890', 8) == '123...890'
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('1234567890', 12) == '1234567890'
    assert truncate('1234567890', 5) == '123...'
    assert truncate('1234567890', 0) == '...'
    assert truncate('1234567890', 1) == '...'
    assert truncate('1234567890', 2) == '...'
    assert truncate('1234567890', 3) == '...'
    assert truncate('1234567890', 4) == '1...'

# Generated at 2022-06-20 12:47:44.979855
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(('a', 'b')) == ('a', 'b')
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple('') == ('',)
    assert ensure_tuple(None) == (None,)

