

# Generated at 2022-06-20 12:38:16.743268
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcd', max_length=2) == 'ab...'
    assert get_shortish_repr('abcd', max_length=3) == 'abc...'
    assert get_shortish_repr('abcd', max_length=4) == 'abcd'
    assert get_shortish_repr('abcd', max_length=5) == 'abcd'

    assert get_shortish_repr('abcd') == 'abcd'


if __name__ == '__main__':
    import nose
    nose.run_module()

# Generated at 2022-06-20 12:38:20.520408
# Unit test for function truncate
def test_truncate():
    assert truncate('hello world', None) == 'hello world'
    assert truncate('hello world', 11) == 'hello world'
    assert truncate('hello world', 10) == 'hello...ld'
    assert truncate('hello world', 5) == 'h...d'
    assert truncate('hello world', 13) == 'hello world'



# Generated at 2022-06-20 12:38:21.852515
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout.__class__, WritableStream)

# Generated at 2022-06-20 12:38:32.252318
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, [(lambda x: True, lambda x: 'is zero')])() == \
                                                                        'is zero'
    assert get_repr_function(0, [(lambda x: False, lambda x: 'is zero')])() == \
                                                                             '0'
    assert get_repr_function(0, [(lambda x: False, lambda x: 'is zero'),
                                 (lambda x: True, lambda x: 'actually is zero')])() == \
                                                                    'actually is zero'

    assert get_repr_function(0, [(int, lambda x: 'is zero')])() == 'is zero'
    assert get_repr_function('hi', [(int, lambda x: 'is zero')])() == "'hi'"




# Generated at 2022-06-20 12:38:35.613534
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class TestClass(WritableStream):
        def write(self, s):
            pass
    TestClass()




# Note: This seems to be Python 2.6-compatible, so we're using it directly.
# From https://github.com/python/cpython/blob/2.7/Lib/collections.py#L82 :

# Generated at 2022-06-20 12:38:43.528847
# Unit test for function truncate
def test_truncate():
    assert truncate('a'*5, None) == 'a'*5
    assert truncate('a'*5, 10) == 'a'*5
    assert truncate('a'*5, 4) == 'a'*4
    assert truncate('a'*5, 3) == 'aaa'
    assert truncate('a'*5, 2) == 'aa'
    assert truncate('a'*5, 1) == 'a'
    assert truncate('a'*5, 0) == ''
    assert truncate('a'*5, -1) == ''
    assert truncate('a'*1, None) == 'a'
    assert truncate('a'*1, 10) == 'a'
    assert truncate('a'*1, 4) == 'a'

# Generated at 2022-06-20 12:38:46.238380
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)



# Generated at 2022-06-20 12:38:55.793612
# Unit test for function normalize_repr
def test_normalize_repr():
    import pytest

    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0xDEADBEEF') == 'hello'
    assert normalize_repr('hello at 0xDEADBEEF at 0xBADC0FFE') == 'hello'
    assert normalize_repr('hello at 0xDEADBEEF at 0xBADC0FFE at 0xDEADBEEF') == \
        'hello'
    assert normalize_repr('hello at 0xDEADBEEF at 0xBADC0FFE at 0xBABABABA') == \
        'hello'
    assert normalize_repr('') == ''
    assert normalize_repr('at 0xDEADBEEF') == ''
    assert normalize_re

# Generated at 2022-06-20 12:39:06.002222
# Unit test for function get_repr_function
def test_get_repr_function():

    assert get_repr_function(1, []) == repr
    assert get_repr_function(1.5, []) == repr

    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.5, [(int, str)]) == repr

    assert get_repr_function(1, [(str, str)]) == repr
    assert get_repr_function(1.5, [(str, str)]) == repr

    assert get_repr_function('1', []) == repr
    assert get_repr_function('1.5', []) == repr

    assert get_repr_function('1', [(int, str)]) == repr
    assert get_repr_function('1.5', [(int, str)]) == repr

    assert get_re

# Generated at 2022-06-20 12:39:12.915025
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) is repr

    custom_repr = ((None, lambda x: 'None'),
                   (set, lambda x: str(x)),
                   (dict, lambda x: str(list(x.items()))))

    assert get_repr_function(None, custom_repr)() == 'None'
    assert get_repr_function({'hey': 'ho'}, custom_repr)() == "dict_items([('hey', 'ho')])"
    assert get_repr_function('yo', custom_repr)() == "'yo'"

    custom_repr2 = ((str, lambda x: x.lower()),
                    (dict, lambda x: str(x.items())))


# Generated at 2022-06-20 12:39:21.494781
# Unit test for function truncate
def test_truncate():
    assert truncate('12345', 6) == '12345'
    assert truncate('12345', 5) == '12345'
    assert truncate('12345', 4) == '1...5'
    assert truncate('12345', 3) == '1...5'
    assert truncate('12345', 2) == '1...5'
    assert truncate('12345', 1) == '...'
    assert truncate('12345', 0) == '...'
    assert truncate('12345', -1) == '...'
    assert truncate('12345', -2) == '...'
    assert truncate('12345', -3) == '...'



# Generated at 2022-06-20 12:39:28.272665
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    from shleem import class_tools

    test_StringIO = io.StringIO()

    writable_streams = [
        sys.stdout,
        sys.stderr,
        test_StringIO,
        class_tools.ObjectWithStreams(output_stream=test_StringIO),
    ]

    for writable_stream in writable_streams:
        writable_stream.write('Hello world!')

    assert test_StringIO.getvalue() == 'Hello world!' * len(writable_streams)

# Generated at 2022-06-20 12:39:32.675840
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('[1, 2, 3] at 0x1234') == '[1, 2, 3]'
    assert normalize_repr('[1, 2, 3]') == '[1, 2, 3]'
    assert normalize_repr('[1, 2, 3] at 0x123456789') == '[1, 2, 3]'



# Generated at 2022-06-20 12:39:36.477350
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple(1) == (1, )
    assert ensure_tuple([1]) == ([1],)
    assert ensure_tuple([1, 2, 3]) == ([1, 2, 3],)
    assert ensure_tuple((1, 2)) == ((1, 2),)
    assert ensure_tuple('lol') == ('lol',)
    assert ensure_tuple(x for x in 'lol') == ('l', 'o', 'l')

# Generated at 2022-06-20 12:39:39.495516
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    
    assert isinstance(MyWritableStream(), WritableStream)
    
    

# Generated at 2022-06-20 12:39:48.287810
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from io import BytesIO
    from .logging_tools import LazyStream
    from .frozen_stream import FrozenStream
    from .collection_tools import CyclicListWrapper
    from .sequence_tools import cycle_method
    from .byte_io import ByteStringIOSource
    for s in (sys.stdout,
              sys.stderr,
              BytesIO(),
              LazyStream(BytesIO),
              FrozenStream(BytesIO),
              BytesIO(),
              CyclicListWrapper(BytesIO(), 'write'),
              cycle_method(BytesIO(), 'write'),
              ByteStringIOSource(),
              ByteStringIOSource()):
        assert isinstance(s, WritableStream)
    assert not isinstance({}, WritableStream)
    assert not isinstance([], WritableStream)

# Generated at 2022-06-20 12:39:55.660269
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import math
    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr(5, max_length=None) == '5'
    assert get_shortish_repr(5, max_length=5) == '5'
    assert get_shortish_repr(5, max_length=4) == '5'
    assert get_shortish_repr((1, 2)) == '(1, 2)'
    assert get_shortish_repr((1, 2), max_length=7) == '(1, 2)'
    assert get_shortish_repr((1, 2), max_length=6) == '(1, 2)'
    assert get_shortish_repr((1, 2), max_length=5) == '(...)'
    assert get_shortish_repr

# Generated at 2022-06-20 12:40:01.713602
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s

    foo = Foo()
    foo.write('meow')
    assert foo.s == 'meow'


# Unit tests for method __subclasshook__ of class WritableStream

# Generated at 2022-06-20 12:40:09.023064
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdef', None) == 'abcdef'
    assert truncate('abcdef', 6) == 'abcdef'
    assert truncate('abcdef', 7) == 'abcdef'

    assert truncate('abcdef', 5) == '...ef'
    assert truncate('abcdef', 4) == '...f'
    assert truncate('abcdef', 3) == '...'

    assert truncate('ab', 3) == 'ab'
    assert truncate('ab', 2) == 'ab'
    assert truncate('ab', 1) == '.'



# Generated at 2022-06-20 12:40:14.142549
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(b'\xfd\xefe') == '??'
    assert shitcode(b'\xfd\xefe\xff\x11\x22') == '?????'
    assert shitcode(b'\xfd') == '?'
    assert shitcode(b'\xfe') == '?'
    assert shitcode(b'\xff') == '?'
    assert shitcode(b'\xfc') != '?'
    assert shitcode(b'') == ''
    assert shitcode('\xff') == '?'
    assert shitcode('\xfd') == '?'





# Generated at 2022-06-20 12:40:26.065067
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('Føø') == 'F??'
    assert shitcode('bææ') == 'b??'
    assert shitcode('\xf8\xee\xf9\xeb') == '????'
    assert shitcode('\n') == '\n'
    assert shitcode('\r') == '\r'
    assert shitcode('\n\r\t') == '\n\r\t'
    assert shitcode('øøø') == '???', shitcode('øøø')
    assert shitcode('Føø bar') == 'F?? bar'





# Generated at 2022-06-20 12:40:34.635204
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    print(get_shortish_repr('xyz'))
    print(get_shortish_repr(''))
    print(get_shortish_repr(u'xyz'))
    print(get_shortish_repr('xyz', max_length=3))
    print(get_shortish_repr(u'xyz', max_length=3))
    print(get_shortish_repr('xyz', max_length=2))
    print(get_shortish_repr('xyz', max_length=1))
    print(get_shortish_repr('xyz', max_length=0))
    print(get_shortish_repr('xy', max_length=3))
    print(get_shortish_repr('x', max_length=3))

# Generated at 2022-06-20 12:40:40.726270
# Unit test for function shitcode
def test_shitcode():
    def run(s, expected):
        actual = shitcode(s)
        assert actual == expected, (actual, expected)
    run('', '')
    run('abc', 'abc')
    run('abc\n', 'abc\n')
    run('abc\n', 'abc\n')
    run('\nabc\n', '\nabc\n')
    run('a\x00b', 'a?b')
    run(u'a\u0442b', u'a?b')



# Generated at 2022-06-20 12:40:47.814200
# Unit test for function get_repr_function
def test_get_repr_function():

    assert get_repr_function(1, (lambda x: False, lambda x: '__int__')) == repr
    assert get_repr_function(1, (lambda x: True, lambda x: '__int__')) == '__int__'

    assert get_repr_function(1.0, (lambda x: False, lambda x: '__float__')) == repr
    assert get_repr_function(1.0, (lambda x: True, lambda x: '__float__')) == '__float__'

    assert get_repr_function((1,), (lambda x: False, lambda x: '__tuple__')) == repr
    assert get_repr_function((1,), (lambda x: True, lambda x: '__tuple__')) == '__tuple__'

    assert get_

# Generated at 2022-06-20 12:40:53.068376
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(x for x in range(3)) == (0, 1, 2)



# Generated at 2022-06-20 12:40:56.468558
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        pass

    a = A()
    try:
        a.write('foo')
    except:
        exception = sys.exc_info()
        return False
    else:
        return True

# Generated at 2022-06-20 12:41:04.288103
# Unit test for function truncate
def test_truncate():
    assert truncate('', None) == ''
    assert truncate('', 0) == ''
    assert truncate('', 1) == ''
    assert truncate('', 2) == ''
    assert truncate('123', None) == '123'
    assert truncate('123', 0) == ''
    assert truncate('123', 1) == '1'
    assert truncate('123', 2) == '12'
    assert truncate('123', 3) == '123'
    assert truncate('123', 4) == '123'
    assert truncate('1234', None) == '1234'
    assert truncate('1234', 0) == ''
    assert truncate('1234', 1) == '1'
    assert truncate('1234', 2) == '12'
    assert truncate('1234', 3) == '123'

# Generated at 2022-06-20 12:41:07.555228
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class DummyWritableStream(object):
        def write(self, s):
            pass

    assert issubclass(DummyWritableStream, WritableStream)

# Generated at 2022-06-20 12:41:11.196444
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(1) == (1,)



# Generated at 2022-06-20 12:41:13.673615
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert isinstance(ensure_tuple(1), tuple)
    assert isinstance(ensure_tuple([1]), tuple)
    assert not isinstance(ensure_tuple('1'), tuple)



# Generated at 2022-06-20 12:41:27.499206
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class Foo(WritableStream):
        def write(self, s):
            pass

    assert issubclass(Foo, WritableStream)

    class Bar(Foo):
        pass

    assert issubclass(Bar, WritableStream)

    class FooBar(WritableStream):
        pass

    assert not issubclass(FooBar, WritableStream)

    class FooFoo(Foo):
        def write(self, s):
            pass

    assert issubclass(FooFoo, WritableStream)

    class FooBar(Foo, FooFoo):
        pass

    assert issubclass(FooBar, WritableStream)

    class FooBarBar(FooBar):
        pass

    assert issubclass(FooBarBar, WritableStream)


# Generated at 2022-06-20 12:41:31.024973
# Unit test for function truncate
def test_truncate():
    import pytest
    assert truncate('123456789', 5) == '12...89'
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 8) == '123456...'
    assert truncate('123456789', 7) == '12345...'
    with pytest.raises(ValueError):
        truncate('123456789', 6)



# Generated at 2022-06-20 12:41:38.414951
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(int, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream)
    assert not issubclass(MyWritableStream, MyWritableStream)
    assert not issubclass(WritableStream, WritableStream)

    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO

    assert issubclass(StringIO, WritableStream)



# Generated at 2022-06-20 12:41:47.293506
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import sys
    assert get_shortish_repr(123) == '123'
    assert get_shortish_repr('123') == "'123'"
    assert get_shortish_repr(u'123') == "u'123'"
    assert get_shortish_repr(u'123' * 1000, max_length=20) == \
                                                 'u\'1231231231231231...123\''
    assert get_shortish_repr(u'123\n456', max_length=20) == 'u\'123\\n456\''
    assert get_shortish_repr(u'123\r456', max_length=20) == 'u\'123\\n456\''

# Generated at 2022-06-20 12:41:57.056142
# Unit test for function truncate
def test_truncate():
    assert truncate(b'test', 4) == b'test'
    assert truncate(b'test', 3) == b'tes'
    assert truncate(b'test', 2) == b'te'
    assert truncate(b'test', 1) == b't'
    assert truncate(b'test', 0) == b''
    assert truncate(b'test', -1) == b''
    assert truncate(b'test', None) == b'test'
    assert truncate(b'test', 0.5) == b''
    assert truncate(b'test', 2.5) == b'te'
    assert truncate(b'test', 5) == b'test'
    assert truncate(b'test', 6) == b'test'

# Generated at 2022-06-20 12:42:08.828492
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert (
        get_shortish_repr('x'*5, max_length=7) == 'xxxxxxxxx'
    )
    assert (
        get_shortish_repr('x'*5, max_length=6) == 'xxxxx'
    )
    assert (
        get_shortish_repr('x'*5, max_length=5) == 'xxxxx'
    )
    assert (
        get_shortish_repr('x'*5, max_length=4) == 'x...x'
    )
    assert (
        get_shortish_repr('x'*5, max_length=3) == 'x...'
    )
    assert (
        get_shortish_repr('x'*5, max_length=2) == 'x...'
    )


# Generated at 2022-06-20 12:42:15.580125
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def __init__(self):
            self.x = 0
        def write(self, s):
            self.x += s
    a = A()
    a.write(1)
    assert a.x == 1
    a.write(2)
    assert a.x == 3
    a.write('3')
    assert a.x == 6
    b = A()
    assert (str(b) == u"<class 'test__misc.A'>")
    assert (repr(b) == u"<test__misc.A at 0x%x>"
            % sys.getrefcount(b))

# Generated at 2022-06-20 12:42:17.758510
# Unit test for constructor of class WritableStream
def test_WritableStream():


    class TestClass(object):
        def write(self, s):
            pass

    assert isinstance(TestClass(), WritableStream)
    assert not isinstance(object(), WritableStream)

# Generated at 2022-06-20 12:42:27.730156
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(123) == '123'
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr(None) == 'None'
    my_list = [1, 2, 3, 4]
    assert get_shortish_repr(my_list) == 'my_list'
    assert get_shortish_repr(my_list, max_length=10) == 'my_list'
    assert get_shortish_repr(my_list, max_length=9) == 'my_lis...'
    assert get_shortish_repr(my_list, max_length=8) == 'my_lis...'

# Generated at 2022-06-20 12:42:34.360321
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .typing import NoneType
    from .fake_filesystem import FakeFile
    from .stdout import Stdout

    with FakeFile.create_context():
        with FakeFile.create('file.txt') as file:
            assert isinstance(file.write, collections_abc.Callable)
            assert isinstance(file.write, collections_abc.Callable)
            assert isinstance(file.write, collections_abc.Callable)
            file.write('hello')
            assert file.text == 'hello'

        assert isinstance(sys.stdout.write, collections_abc.Callable)
        assert isinstance(sys.stdout.write, collections_abc.Callable)
        assert isinstance(sys.stdout.write, collections_abc.Callable)


# Generated at 2022-06-20 12:42:43.152661
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, string):
            pass

    assert isinstance(A(), WritableStream)
    class B(A):
        pass
    assert isinstance(B(), WritableStream)
    class C(A):
        def write(self, string):
            pass
        write = None
    assert not isinstance(C(), WritableStream)



# Generated at 2022-06-20 12:42:51.284487
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcdefghijklmnop') == 'abcdefghijklmnop'
    assert get_shortish_repr('abcdefghijklmnop', max_length=5) == 'ab...'
    assert get_shortish_repr('abcdefghijklmnop', max_length=6) == 'ab...'
    assert get_shortish_repr('abcdefghijklmnop', max_length=7) == 'abc...'
    assert get_shortish_repr('abcdefghijklmnop', max_length=8) == 'abc...'
    assert get_shortish_repr('abcdefghijklmnop', max_length=9) == 'abcd...'

# Generated at 2022-06-20 12:43:02.390988
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('') == ''
    assert normalize_repr('a') == 'a'
    assert normalize_repr('aaa') == 'aaa'
    assert normalize_repr('aaa at 0x') == 'aaa at 0x'
    assert normalize_repr('aaa at 0x8888') == 'aaa'
    assert normalize_repr('aaa at 0x at 0x8888') == 'aaa at 0x'
    assert normalize_repr('aaa at 0x at 0x') == 'aaa at 0x'
    assert normalize_repr('aaa at 0x8888 at 0x8888') == 'aaa'
    assert normalize_repr('aaa at 0x8888 at 0x88ff') == 'aaa'

# Generated at 2022-06-20 12:43:06.516931
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(x for x in 'a') == ('a',)



# Generated at 2022-06-20 12:43:13.411166
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test for emulating a stream with a list of written data,
    # so we can examine later what was written to it:
    class TestStream:
        def __init__(self):
            self.data = []
        def write(self, s):
            self.data.append(s)

    t = TestStream()
    WritableStream.register(TestStream)

    assert isinstance(t, WritableStream)

    t.write('hi')
    assert t.data == ['hi']




# Generated at 2022-06-20 12:43:17.689730
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple([3]) == ([3],)
    assert ensure_tuple((3,)) == (3,)
    assert ensure_tuple([3, 4]) == ([3, 4],)
    assert ensure_tuple((3, 4)) == (3, 4)

# Generated at 2022-06-20 12:43:19.115452
# Unit test for constructor of class WritableStream
def test_WritableStream():
    with open(sys.executable, 'rb') as f:
        assert isinstance(f, WritableStream)

# Generated at 2022-06-20 12:43:29.638003
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('1234567890') == '1234567890'
    assert get_shortish_repr('1234567890', max_length=10) == '1234567890'
    assert get_shortish_repr('1234567890', max_length=9) == '1234567890'
    assert get_shortish_repr('1234567890', max_length=8) == '12345...'
    assert get_shortish_repr('1234567890', max_length=7) == '12345...'
    assert get_shortish_repr('1234567890', max_length=6) == '1...'
    assert get_shortish_repr('1234567890', max_length=5) == '1...'
    assert get_shortish_re

# Generated at 2022-06-20 12:43:38.486426
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import pytest
    _get_shortish_repr = get_shortish_repr

    s = '0123456789' * 16
    assert _get_shortish_repr(s, normalize=True) == s
    assert _get_shortish_repr(s, normalize=True, max_length=None) == s
    assert _get_shortish_repr(s, normalize=True, max_length=16) == s[:8] + '...' + s[-8:]
    assert _get_shortish_repr(s, normalize=True, max_length=15) == (s[:4] + '...' + s[-4:])

# Generated at 2022-06-20 12:43:48.426153
# Unit test for function truncate
def test_truncate():
    assert truncate('hello world', 10) == 'hello wor'
    assert truncate('hello world', 12) == 'hello world'
    assert truncate('hello world', 13) == 'hello world'
    assert truncate('hello world', 15) == 'hello world'
    assert truncate('hello world!', 10) == 'hello wor'
    assert truncate('hello world!', 12) == 'hello world'
    assert truncate('hello world!', 13) == 'hello world'
    assert truncate('hello world!', 15) == 'hello world'
    assert truncate('hello world!', 16) == 'hello world!'
    assert truncate('hello world!', 17) == 'hello world!'



# Generated at 2022-06-20 12:43:54.531249
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FooStream(WritableStream):
        def write(self, s):
            self.s = s
    f = FooStream()
    f.write('meow')
    assert f.s == 'meow'



# Generated at 2022-06-20 12:44:03.949974
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([65, 66, 67]) == (65, 66, 67)
    assert ensure_tuple(iter([65, 66, 67])) == (65, 66, 67)
    assert ensure_tuple('ABC') == ('ABC',)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple({'A': 65}) == ({'A': 65},)


if sys.version_info[:2] < (2, 7):
    def unicode_to_str(x):
        return str(x)
else:
    def unicode_to_str(x):
        return str(x, 'utf-8')


# This is a copy of the `patch` function from `six`. The license is:
# Copyright (c) 2010-2018 Benjamin Peterson
#
# Permission is

# Generated at 2022-06-20 12:44:09.854070
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(['a']) == ('a',)
    assert ensure_tuple([[1, 2, 3], ['a', 'b', 'c']]) == ((1, 2, 3),
                                                          ('a', 'b', 'c'))



# Generated at 2022-06-20 12:44:17.936741
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(10) == (10,)
    assert ensure_tuple((10, 20)) == (10, 20)
    assert ensure_tuple([10, 20]) == (10, 20)
    assert ensure_tuple((10,)) == (10,)
    assert ensure_tuple([10]) == (10,)
    assert ensure_tuple([]) == ()
    assert ensure_tuple(range(5)) == (0, 1, 2, 3, 4)





# Generated at 2022-06-20 12:44:26.110292
# Unit test for function get_repr_function
def test_get_repr_function():
    def f(x):
        return (x + '.') * 3 + '\n'
    custom_repr = (
        (lambda x: x == 'abc', lambda x: '%s!' % x),
        (lambda x: x == 'def', lambda x: '%s!' % x),
        (float, lambda x: '%s?' % x)
    )
    assert get_repr_function('abc', custom_repr)('def') == 'def!'
    assert get_repr_function(123, custom_repr) == repr
    assert get_repr_function(1 + 5j, custom_repr) == repr
    assert get_repr_function('abc', custom_repr)('def') == 'def!'

# Generated at 2022-06-20 12:44:33.926499
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcde') == 'abcde'
    assert get_shortish_repr('abcdef', max_length=None) == 'abcdef'
    assert get_shortish_repr('abcdef', max_length=5) == 'a...f'
    assert get_shortish_repr('abcdef', max_length=6) == 'a...f'
    assert get_shortish_repr('abcdef', max_length=7) == 'abc...f'
    assert get_shortish_repr('abcdef', max_length=8) == 'abcd...f'



# Generated at 2022-06-20 12:44:38.560646
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(1.0) == (1.0,)



# Generated at 2022-06-20 12:44:45.242352
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.wrote = False

        def write(self, s):
            self.wrote = True

    class UnWritableStream(WritableStream):
        def __init__(self):
            self.wrote = False

    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(UnWritableStream, WritableStream)
    assert not issubclass(object, WritableStream)
    assert not issubclass(int, WritableStream)





# Generated at 2022-06-20 12:44:50.430326
# Unit test for function normalize_repr
def test_normalize_repr():
    '''test normalize_repr'''
    class Foo(object):
        def __repr__(self):
            return '<Foo object at 0x%x>' % id(self)
    foo = Foo()
    assert normalize_repr(repr(foo)) == '<Foo object>'
    assert normalize_repr('bar') == 'bar'
    assert normalize_repr('bar at 0x%x' % id(foo)) == 'bar'





# Generated at 2022-06-20 12:44:56.022167
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr(0) == '0'
    assert get_shortish_repr(0.5) == '0.5'
    assert get_shortish_repr(0.7 + 0.2j) == '(0.7+0.2j)'
    assert '...' not in get_shortish_repr('a', max_length=3)
    assert '...' in get_shortish_repr('abcd', max_length=3)
    assert '...' in get_shortish_repr('abcd', max_length=4)
    assert 'a' in get_shortish_repr('abcd', max_length=4)



# Generated at 2022-06-20 12:45:01.022808
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(dict, WritableStream):
        pass

    assert isinstance(Foo(), WritableStream)



# Generated at 2022-06-20 12:45:10.598070
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class MyClass(object):
        def __repr__(self):
            return '<This is my class>'

    item = MyClass()
    assert get_shortish_repr(item) == '<This is my class>'
    assert get_shortish_repr(item, max_length=10) == '<This is...>'
    assert get_shortish_repr(item, max_length=15) == '<This is my...>'
    assert get_shortish_repr(item, max_length=16) == '<This is my class>'
    assert get_shortish_repr(item, max_length=20) == '<This is my class>'
    assert get_shortish_repr(item, max_length=27) == '<This is my class>'

# Generated at 2022-06-20 12:45:14.156743
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple({1, 2}) == ({1, 2},)
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(None) == (None,)


# Generated at 2022-06-20 12:45:25.323953
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(12) == '12'
    assert get_shortish_repr([12, 13, 14], max_length=10) == '[12, 13, 14]'
    assert get_shortish_repr([12, 13, 14], max_length=11) == '[12, 13,...'
    assert get_shortish_repr([12, 13, 14], max_length=12) == '[12, 13, 14]'
    assert get_shortish_repr([12, 13, 14], max_length=13) == '[12, 13, 14]'
    assert get_shortish_repr([12, 13, 14], max_length=14) == '[12, 13, 14]'


# Generated at 2022-06-20 12:45:27.412861
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    MyWritableStream()

test_WritableStream()

# Generated at 2022-06-20 12:45:32.411341
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("hello") == "hello"
    assert normalize_repr("hello at 0x1234") == "hello"
    assert normalize_repr("hello at 0x12345678") == "hello"
    assert normalize_repr("hello at 0x012345678") == "hello"
    assert normalize_repr("hello at 0x1234567890") == "hello"
    assert normalize_repr("hello at 0x12345678901234567890") == "hello"

# Generated at 2022-06-20 12:45:38.834921
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(3) == '3'
    assert get_shortish_repr(3, custom_repr=((lambda x: True, str),),
                             max_length=None) == '3'
    assert get_shortish_repr(3, custom_repr=((lambda x: True, str),),
                             max_length=10) == '3'
    assert get_shortish_repr(3, custom_repr=((lambda x: True, str),),
                             max_length=2) == '3'
    assert get_shortish_repr(3, custom_repr=((lambda x: True, str),),
                             max_length=1) == '3'

# Generated at 2022-06-20 12:45:45.138064
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStream(object):
        def __init__(self):
            self.written_stuff = []

        def write(self, stuff):
            if isinstance(stuff, unicode):
                stuff = stuff.encode('utf-8')
            self.written_stuff.append(stuff)

    assert issubclass(WritableStream,
                      WritableStream)


if __name__ == '__main__':
    test_WritableStream()

# Generated at 2022-06-20 12:45:48.029988
# Unit test for function normalize_repr
def test_normalize_repr():
    from .python_toolbox import cute_testing
    suite = cute_testing.suite_from_functions(vars())
    cute_testing.logging.root.setLevel(10) # Hide test logging
    return suite()



# Generated at 2022-06-20 12:45:50.393532
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class DummyWritableStream(WritableStream):
        def write(self, s):
            pass

    DummyWritableStream()

# Generated at 2022-06-20 12:46:02.572191
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('a' * 3) == 'a' * 3
    assert shitcode(u'a') == 'a'
    assert shitcode(u'a' * 3) == 'a' * 3

    if sys.version_info.major == 2:
        assert shitcode(u'a\u2000b') == 'a?b'
    else:
        assert shitcode('a\u2000b') == 'a?b'

# Generated at 2022-06-20 12:46:10.934966
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(123) == '123'
    assert get_shortish_repr(123, max_length=4) == '123'
    assert get_shortish_repr(123, max_length=3) == '123'
    assert get_shortish_repr(123, max_length=2) == '1...'
    assert get_shortish_repr(123, max_length=1) == '...'
    assert get_shortish_repr(123, max_length=0) == '...'

    assert get_shortish_repr(123.456) == '123.456'
    assert get_shortish_repr(123.456, max_length=7) == '123.456'

# Generated at 2022-06-20 12:46:14.606976
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple([1, (2, 3)]) == (1, (2, 3))



# Generated at 2022-06-20 12:46:17.319124
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        pass
    
    assert issubclass(A, WritableStream)

# Generated at 2022-06-20 12:46:23.783187
# Unit test for function normalize_repr
def test_normalize_repr():
    from .three_way_comparison import compare
    from .diff_format import red, grey
    assert compare(normalize_repr('abcdefg at 0x1234'),
                   'abcdefg')
    assert compare(normalize_repr('abc at 0x1234'),
                   'abc')
    assert compare(normalize_repr('abc at 0x1234  qwerjhi123'),
                   'abc  qwerjhi123')



# Generated at 2022-06-20 12:46:31.665726
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('1234567890') == '1234567890'
    assert get_shortish_repr('1234567890', max_length=5) == '12345...90'
    assert get_shortish_repr('1234567890', max_length=None) == '1234567890'
    assert get_shortish_repr(2) == '2'
    assert get_shortish_repr(None, max_length=5) == 'None'
    assert get_shortish_repr(3.14, max_length=5) == '3.14'



# Generated at 2022-06-20 12:46:38.763251
# Unit test for function normalize_repr
def test_normalize_repr():
    from .sys_tools import monkeypatch_method
    from .pycompat import xrange

    class Foo(object):
        def __repr__(self):
            return '<{}: {}>'.format(
                self.__class__.__name__,
                id(self)
            )

    class Bar(object):
        def __repr__(self):
            return '<{}: {}>'.format(
                self.__class__.__name__,
                id(self)
            )

    class Qux(object):
        def __repr__(self):
            return '<{}: {}>'.format(
                self.__class__.__name__,
                id(self)
            )

    class Baz(object):
        def __repr__(self):
            return '<class {}>'.format

# Generated at 2022-06-20 12:46:45.099413
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('abc') == 'abc'
    assert normalize_repr('abc at 0xABC') == 'abc'
    assert normalize_repr('abc at 0xABC at 0xDEF') == 'abc'
    assert normalize_repr('abc at 0xABC at 0xDEF at 0xGHI') == 'abc'
    assert (normalize_repr('abc at 0xABC at 0xDEF at 0xGHI') ==
                                                         'abc at 0xABC...')

# Generated at 2022-06-20 12:46:47.711956
# Unit test for constructor of class WritableStream
def test_WritableStream():
    # This constructor implicitly tests the __subclasshook__ method
    assert isinstance(sys.stderr, WritableStream)
    assert not isinstance(1, WritableStream)

# Generated at 2022-06-20 12:46:54.220494
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(str, custom_repr=()) == repr
    assert get_repr_function(str, custom_repr=[(str, str)]) == str
    assert get_repr_function(str, custom_repr=[(str, str), (bool, bool)]) == str
    assert get_repr_function(str, custom_repr=[(str, str), (bool, bool)]) == str
    assert get_repr_function(str, custom_repr=[(str, str), (bool, bool)]) == str
    assert get_repr_function(1, custom_repr=[(str, str), (bool, bool)]) == repr

# Generated at 2022-06-20 12:47:10.551778
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr('hi') == "'hi'"
    assert get_shortish_repr('hi', max_length=3) == "'hi'"
    assert get_shortish_repr('hi', max_length=2) == "'h..."
    assert get_shortish_repr('hi', max_length=1) == "'..."
    assert get_shortish_repr('hi', max_length=0) == '...'
    assert get_shortish_repr(u'\u3450', max_length=1) == \
                                               u"'\u3450'"

# Generated at 2022-06-20 12:47:17.692552
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo: pass
    class Bar: pass

    foo = Foo()
    bar1 = Bar()
    bar2 = Bar()

    assert get_repr_function(foo, custom_repr=((Foo, id),))(foo) == '54'
    assert get_repr_function(foo, custom_repr=((Bar, id),))(foo) == '<__main__.Foo object at 0x%x>' % id(foo)

    assert get_repr_function(bar1, custom_repr=((Foo, id), (Bar, id))) == id

# Generated at 2022-06-20 12:47:20.632482
# Unit test for constructor of class WritableStream
def test_WritableStream():
    '''
    >>> from . import WritableStream
    >>> import io
    >>> b = io.BytesIO()
    >>> isinstance(b, WritableStream)
    True
    '''



# Generated at 2022-06-20 12:47:22.987195
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C(WritableStream):
        def write(self, s):
            assert len(s)

    C()



# Generated at 2022-06-20 12:47:27.780945
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass

    class B:
        pass

    class C:
        def write(self, s):
            pass

        def close(self):
            pass

    assert isinstance(A(), WritableStream)
    assert not isinstance(B(), WritableStream)
    assert isinstance(C(), WritableStream)



# Generated at 2022-06-20 12:47:34.619127
# Unit test for function normalize_repr
def test_normalize_repr():
    test_class = type('test_class', (object,), {})
    assert repr(test_class)
    assert repr(test_class()).startswith('<test_class object at ')
    assert normalize_repr(repr(test_class)) == '<class "test_class">'
    assert normalize_repr(repr(test_class())) == '<test_class object>'



# Generated at 2022-06-20 12:47:41.004194
# Unit test for function shitcode
def test_shitcode():
    """This function tests the `shitcode` function."""
    assert shitcode('abc') == 'abc'
    assert shitcode('😀') == '?'
    assert shitcode('ab😀c') == 'ab?c'
    assert shitcode(u'abc') == 'abc'
    assert shitcode(u'😀') == '?'
    assert shitcode(u'ab😀c') == 'ab?c'
    if sys.maxunicode > 0xffff:
        import itertools
        for i in itertools.count(0x10000):
            c = chr(i)
            assert shitcode(c) == '?'
            if i > sys.maxunicode:
                break

# Generated at 2022-06-20 12:47:44.543160
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.text = ''
        def write(self, s):
            self.text += s
        def flush(self):
            pass
        
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-20 12:47:53.681103
# Unit test for function truncate
def test_truncate():
    assert truncate('', None) == ''
    assert truncate('', 0) == ''
    assert truncate('', 1) == ''
    assert truncate('', 2) == ''
    assert truncate('', 3) == ''
    assert truncate('', 4) == ''
    assert truncate('', sys.maxsize) == ''
    assert truncate('a', None) == 'a'
    assert truncate('a', 0) == ''
    assert truncate('a', 1) == 'a'
    assert truncate('a', 2) == 'a'
    assert truncate('a', 3) == 'a'
    assert truncate('a', 4) == 'a'
    assert truncate('a', sys.maxsize) == 'a'
    assert truncate('ab', None) == 'ab'

# Generated at 2022-06-20 12:48:03.600283
# Unit test for function truncate
def test_truncate():
    assert 'a' == truncate('a', 4)
    assert 'a' == truncate('a', 3)
    assert 'a' == truncate('a', 2)
    assert 'a' == truncate('a', 1)
    assert '' == truncate('a', 0)

    assert 'a...a' == truncate('aaaa', 5)
    assert 'a...a' == truncate('aaaa', 4)
    assert 'a...a' == truncate('aaaa', 3)
    assert 'aa...' == truncate('aaaa', 2)
    assert 'aa...' == truncate('aaaa', 1)
    assert '...' == truncate('aaaa', 0)

    assert 'ab...ab' == truncate('ababab', 7)
    assert 'ab...ab' == truncate('ababab', 6)