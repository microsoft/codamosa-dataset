

# Generated at 2022-06-20 12:38:19.647452
# Unit test for function shitcode

# Generated at 2022-06-20 12:38:25.144076
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None) is repr
    assert get_repr_function(1) is repr
    assert get_repr_function(1.1) is repr
    assert get_repr_function(type) is repr
    assert get_repr_function('1') is repr

    def f1(x):
        return str(x)

    def f2(x):
        return x

    def f3(x):
        return len(x)

    custom_repr = ((type(1), f1), (type('str'), f2), (re.compile('.'), f3),)
    assert get_repr_function(1, custom_repr) is f1
    assert get_repr_function('1', custom_repr) is f2

# Generated at 2022-06-20 12:38:36.265786
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(()) == ()
    assert ensure_tuple(tuple()) == ()
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple([1, 2, [3]]) == (1, 2, [3])
    assert ensure_tuple((1, 2, [3])) == (1, 2, [3])
    assert ensure_tuple(x for x in [1, 2, 3]) == (1, 2, 3)



# Generated at 2022-06-20 12:38:43.645641
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(b'a') == 'a'
    assert shitcode(b'abc') == 'abc'
    assert shitcode(b'\x82') == '?'
    assert shitcode(b'\x82a') == '?a'
    assert shitcode(b'\x82abc') == '?abc'
    assert shitcode(b'a\x82') == 'a?'
    assert shitcode(b'ab\x82c') == 'ab?c'
    assert shitcode(b'a\x82bc') == 'a?bc'
    assert shitcode(b'\x82abc') == '?abc'
    assert shitcode(b'\x82\x83abc') == '??abc'
    assert shitcode(b'a\x82\x83abc') == 'a??abc'
   

# Generated at 2022-06-20 12:38:53.691118
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, ()) == repr
    assert get_repr_function(5, [(lambda x: True, str)]) == str
    assert get_repr_function('5', [(lambda x: True, str)]) == str
    assert get_repr_function('5', [(lambda x: False, str)]) == repr
    assert get_repr_function('5', [(str, str)]) == str
    assert get_repr_function(5, [(str, str)]) == repr
    assert get_repr_function(5.0, [(str, str)]) == repr
    assert get_repr_function((1, 2, 3), [(str, str)]) == repr

# Generated at 2022-06-20 12:39:04.339667
# Unit test for function truncate
def test_truncate():
    assert truncate('', 10) == ''
    assert truncate('123456789', 10) == '123456789'
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 8) == '123456789'
    assert truncate('123456789', 7) == '12345...'
    assert truncate('123456789', 6) == '1234...'
    assert truncate('123456789', 5) == '123...'
    assert truncate('123456789', 4) == '12...'
    assert truncate('123456789', 3) == '1...'
    assert truncate('123456789', 2) == '1...'
    assert truncate('123456789', 1) == '1...'


# Generated at 2022-06-20 12:39:08.202494
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from . import string_tools
    custom_repr = (
        (string_tools.Path, lambda path: path.string),
        (e for e in [Exception] if e is not Exception)
    )
    return get_shortish_repr('some\nlong\nstring\n', custom_repr, 18)




# Generated at 2022-06-20 12:39:17.513372
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    repr_function = get_repr_function(238, custom_repr=[(A, str)])
    assert repr_function == repr

    a = A()
    repr_function = get_repr_function(a, custom_repr=[(A, str)])
    assert repr_function == str

    repr_function = get_repr_function(a, custom_repr=[(A, lambda x: 'baba')])
    assert repr_function(a) == 'baba'

    repr_function = get_repr_function(
        a, custom_repr=[(A, lambda x: 'baba'), (str, lambda x: 'yaya')]
    )
    assert repr_function(a) == 'baba'



# Generated at 2022-06-20 12:39:27.870829
# Unit test for function truncate
def test_truncate():
    assert truncate('', None) == ''
    assert truncate('', 10) == ''
    assert truncate('123', None) == '123'
    assert truncate('123', 10) == '123'
    assert truncate('1234567890', None) == '1234567890'
    assert truncate('1234567890', 10) == '1234567890'

    assert truncate('1234567890', 9) == '12345...'
    assert truncate('1234567890', 8) == '12345...'
    assert truncate('1234567890', 7) == '12345...'
    assert truncate('1234567890', 6) == '12345...'
    assert truncate('1234567890', 5) == '12345...'

# Generated at 2022-06-20 12:39:31.644290
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('αβγδ') == '????'
    assert shitcode('') == ''
    assert shitcode('a') == 'a'
    assert shitcode('a' * 100 + 'α' + 'a' * 100) == ('a' * 100 + '?' + 'a' * 100)



# Generated at 2022-06-20 12:39:44.313863
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("<type 'int'>") == "<type 'int'>"
    assert normalize_repr("<type 'int' at 0x7ffd25086818>") == "<type 'int'>"
    assert normalize_repr("<type 'int' at 0x7ffd2508681>") == "<type 'int'>"

# Generated at 2022-06-20 12:39:47.633272
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Test(WritableStream):
        def __init__(self):
            self.output = ''
        def write(self, s):
            assert isinstance(s, string_types)
            self.output += s
    t = Test()
    t.write('fish')
    assert t.output == 'fish'

# Generated at 2022-06-20 12:39:49.575278
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A:
        def write(self, s):
            pass
    assert isinstance(A(), WritableStream)

# Generated at 2022-06-20 12:39:56.783873
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    """
    Make sure this function returns a valid repr, but of a limited length.
    """
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=12) == '1'
    assert get_shortish_repr(1, max_length=15) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'



# Generated at 2022-06-20 12:39:59.745940
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((3,)) == (3,)



# Generated at 2022-06-20 12:40:09.847483
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Bla(WritableStream):
        pass
    assert not issubclass(Bla, WritableStream)

    class Bla(WritableStream):
        def write(self, s):
            pass
    assert issubclass(Bla, WritableStream)

    class Bla(WritableStream):
        def write(self, s):
            print(s)
    assert issubclass(Bla, WritableStream)

    class Bla(WritableStream):
        def write(self):
            print(s)
    assert not issubclass(Bla, WritableStream)

    class Bla(WritableStream):
        def write(self, f):
            pass
    assert issubclass(Bla, WritableStream)

    class Bla(WritableStream):
        pass

# Generated at 2022-06-20 12:40:14.756707
# Unit test for function get_repr_function
def test_get_repr_function():
    import collections.abc
    assert get_repr_function(3, ()) is repr
    assert get_repr_function('a', ()) is repr
    assert get_repr_function('a', ((int, lambda x: 'int'))) is repr
    assert get_repr_function(3, ((int, lambda x: 'int'))) == 'int'
    assert get_repr_function(3, ((str, lambda x: 'str'),
                                 (int, lambda x: 'int'))) == 'int'
    assert get_repr_function(3, ((list, lambda x: 'list'),
                                 (int, lambda x: 'int'))) == 'int'
    assert get_repr_function([], ((list, lambda x: 'list'),
                                 (int, lambda x: 'int'))) == 'list'


# Generated at 2022-06-20 12:40:19.697285
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)




# Generated at 2022-06-20 12:40:26.261565
# Unit test for function truncate
def test_truncate():
    assert truncate('', 2) == ''
    assert truncate('x', 2) == 'x'
    assert truncate('xx', 2) == 'xx'
    assert truncate('xxx', 2) == '...'
    assert truncate('xxxx', 2) == '...'
    assert truncate('xxxxx', 2) == '...'
    assert truncate('xxxxxx', 2) == '...'
    assert truncate('xxxxxxx', 2) == '...'



# Generated at 2022-06-20 12:40:30.425666
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(WritableStream):
        pass
    class Bar(Foo):
        def write(self, s):
            pass
    class NotReally(Foo):
        pass
    assert issubclass(Bar, WritableStream)
    assert not issubclass(NotReally, WritableStream)



# Generated at 2022-06-20 12:40:36.876345
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(3) == (3,)


# def get_callable_name(callable):
#     return getattr(callable, '__name__', repr(callable))


# Generated at 2022-06-20 12:40:39.598914
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple({1}) == (1,)





# Generated at 2022-06-20 12:40:43.813351
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class TestingWritableStream(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s

    t = TestingWritableStream()
    t.write('hello')
    assert t.s == 'hello'

    assert isinstance(t, WritableStream)
    assert issubclass(TestingWritableStream, WritableStream)

# Generated at 2022-06-20 12:40:48.441793
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            print(s)
    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(1, WritableStream)
    assert not issubclass(MyWritableStream, int)
    assert not issubclass(WritableStream, MyWritableStream)



# Generated at 2022-06-20 12:40:55.975483
# Unit test for function normalize_repr
def test_normalize_repr():
    import pytest

    def assert_equal(x, y):
        if x != y:
            raise AssertionError("{!r} != {!r}".format(x, y))


# Generated at 2022-06-20 12:41:03.950276
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('') == ''
    assert normalize_repr(None) == 'None'
    assert normalize_repr('abc') == 'abc'
    assert normalize_repr('abc at 0xabcdef') == 'abc'
    assert normalize_repr('abc at 0xabCDef') == 'abc'
    assert normalize_repr('abc at 0xabcdZef') == 'abc at 0xabcdZef'
    assert normalize_repr('abc at 0xabcdZefg') == 'abc at 0xabcdZefg'
    assert normalize_repr('abc at 0xa') == 'abc at 0xa'
    assert normalize_repr('abc at 0x') == 'abc at 0x'

# Generated at 2022-06-20 12:41:13.402430
# Unit test for function normalize_repr
def test_normalize_repr():
    from collections import defaultdict

    assert normalize_repr('bla at 0x123456789') == 'bla'
    assert normalize_repr('bla at 0x123456789 bla bla') == 'bla at 0x123456789 bla bla'

    assert normalize_repr('bla at 0x12345a6789') == 'bla at 0x12345a6789'
    assert normalize_repr('bla at 0x123456789 bla at 0x123456789') == 'bla at 0x123456789 bla'

    d = defaultdict()
    assert normalize_repr(repr(d)) == 'defaultdict(None, {})'

# Generated at 2022-06-20 12:41:25.363933
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmn', None) == 'abcdefghijklmn'
    assert truncate('abcdefghijklmn', 10) == 'abcdefghijklmn'
    assert truncate('abcdefghijklmn', 11) == 'abcdefghijklmn'
    assert truncate('abcdefghijklmn', 12) == 'abcdefghijklmn'
    assert truncate('abcdefghijklmn', 13) == 'abcdefghijklmn'
    assert truncate('abcdefghijklmn', 14) == 'abcdefghijklmn'
    assert truncate('abcdefghijklmn', 15) == 'abcdefghijklmn'
    assert truncate('abcdefghijklmn', 16) == 'abcdefghijklmn'

# Generated at 2022-06-20 12:41:28.159592
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(ABC):
        def write(self, s):
            pass
    class Bar(Foo):
        pass
    class Baz(object):
        pass

    assert issubclass(Foo, WritableStream)
    assert issubclass(Bar, WritableStream)
    assert not issubclass(Baz, WritableStream)





# Generated at 2022-06-20 12:41:31.574522
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', 6) == 'hello'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 4) == 'hel...'
    assert truncate('hello', 3) == '...'
    assert truncate('hello', 2) == '..'
    assert truncate('hello', 1) == '.'
    assert truncate('hello', 0) == ''



# Generated at 2022-06-20 12:41:42.732742
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hey there') == 'hey there'
    assert normalize_repr(r'hey there at 0x82FF') == 'hey there'
    assert normalize_repr(r'hey there at 0x82FF at 0xF0f0') == 'hey there'
    assert normalize_repr(r'0xF0F0 at 0x82FF') == r'0xF0F0'
    assert normalize_repr(r'0xF0F0') == r'0xF0F0'
    assert normalize_repr('hey there at 0x82FF') == 'hey there'
    assert normalize_repr('0xF0F0') == r'0xF0F0'
    assert normalize_repr('') == ''
    assert normalize_

# Generated at 2022-06-20 12:41:44.441847
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def write(self, s):
            pass

    assert isinstance(A(), WritableStream)



# Generated at 2022-06-20 12:41:46.471265
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)



# Generated at 2022-06-20 12:41:54.449285
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello', max_length=3) == '...'
    assert get_shortish_repr('hello', max_length=4) == 'he...'
    assert get_shortish_repr('hello', max_length=5) == 'hel...'
    assert get_shortish_repr('hello', max_length=6) == 'hello'
    assert get_shortish_repr('hello', max_length=7) == 'hello'
    assert get_shortish_repr('hello', max_length=8) == 'hello'


# Generated at 2022-06-20 12:41:57.534469
# Unit test for function ensure_tuple
def test_ensure_tuple():
    x = 1
    assert ensure_tuple(x) == (x,)
    x = 'abc'
    assert ensure_tuple(x) == (x,)
    x = (1, 2, 3)
    assert ensure_tuple(x) == x



# Generated at 2022-06-20 12:42:07.804182
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('asdf') == 'asdf'
    assert normalize_repr('asdf at 0x12345') == 'asdf'
    assert normalize_repr('asdf at 0x0') == 'asdf'
    assert normalize_repr('asdf at 0x012345') == 'asdf'
    assert normalize_repr('asdf  at   0x012345') == 'asdf'
    assert normalize_repr('asdf at 0x012345678') == 'asdf'
    assert normalize_repr('asdf at 0x012345678 at 0x012345678') == 'asdf'

# Generated at 2022-06-20 12:42:13.514061
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple(()) == ()
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(range(5)) == (0, 1, 2, 3, 4)

    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple([1, 2, 3, 4, 5]) == (1, 2, 3, 4, 5)




# Generated at 2022-06-20 12:42:20.320788
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr('meow') == "'meow'"
    assert get_shortish_repr(object) == 'object'
    assert get_shortish_repr(get_shortish_repr) == '<function get_shortish_repr at 0x000000000314BF28>'
    assert get_shortish_repr({}) == '{}'
    assert get_shortish_repr(sys) == '<module \'sys\' (built-in)>'
    assert get_shortish_repr((1, 2, 3)) == '(1, 2, 3)'
    assert get_shortish_repr((), max_length=4) == '()'

# Generated at 2022-06-20 12:42:29.991880
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, (
        (int, lambda x: '<int %s>' % x),
    ))(0) == '<int 0>'

    assert get_repr_function(0, (
        (int, lambda x: '<int %s>' % x),
        (float, lambda x: '<float %s>' % x),
    ))(0) == '<int 0>'

    assert get_repr_function(0.0, (
        (int, lambda x: '<int %s>' % x),
        (float, lambda x: '<float %s>' % x),
    ))(0.0) == '<float 0.0>'


# Generated at 2022-06-20 12:42:34.161000
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(set([1, 2])) == (1, 2)
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(u'hello') == (u'hello',)





# Generated at 2022-06-20 12:42:46.110765
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert isinstance(ensure_tuple([1, 2, 3]), tuple)
    assert isinstance(ensure_tuple(1), tuple)
    assert isinstance(ensure_tuple((1, 2, 3)), tuple)
    assert ensure_tuple((1, 2, 3))[0:2] == (1, 2)
    assert ensure_tuple(1)[0] == 1
    assert ensure_tuple((1, 2, 3))[0:2] == (1, 2)



# Generated at 2022-06-20 12:42:50.862285
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefg', None) == 'abcdefg'
    assert truncate('abcdefg', 10) == 'abcdefg'
    assert truncate('abcdefg', 5) == 'ab...g'
    assert truncate('abcdefg', 4) == 'ab...g'
    assert truncate('abcdefg', 3) == 'abcdefg'
    assert truncate('abcdefg', 2) == 'abcdefg'
    assert truncate('abcdefg', 1) == 'abcdefg'
    assert truncate('abcdefg', 0) == 'abcdefg'



# Generated at 2022-06-20 12:42:55.507069
# Unit test for function ensure_tuple
def test_ensure_tuple():
    for x in (1, [1], range(4), (4,)):
        if isinstance(x, collections_abc.Iterable) and \
                                               not isinstance(x, string_types):
            assert ensure_tuple(x) == tuple(x)
        else:
            assert ensure_tuple(x) == (x,)

# Generated at 2022-06-20 12:43:06.026845
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('"a"') == '"a"'
    assert normalize_repr('"bc"') == '"bc"'
    assert normalize_repr('"def"') == '"def"'

    assert normalize_repr('"abc" at 0x1234') == '"abc"'
    assert normalize_repr('"abc" at 0x12345678') == '"abc"'
    assert normalize_repr('"abc" at 0xFF') == '"abc"'
    assert normalize_repr('"abc" at 0xFF0') == '"abc"'

    assert normalize_repr('"abc" at 0x00001234') == '"abc"'
    assert normalize_repr('"abc" at 0x000012345678') == '"abc"'
    assert normalize

# Generated at 2022-06-20 12:43:12.301772
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnopqrstuvwxyz', 10) == 'abcdefghi...yz'
    assert truncate('€₪₡₢$¢₣₤₥₦₧₨₩₪₫£₭₮₯₹₺₻₼₽₾₿', 27) == '€₪₡₢$¢₣₤₥₦₧₨₪₫£...₭₮₯₹₺₻₼₽₾₿'

# Generated at 2022-06-20 12:43:20.729735
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('abc at 0x123') == 'abc'
    assert normalize_repr('abc at 0x123 at 0x456') == 'abc at 0x456'
    assert normalize_repr('abc at 0x123 at 0x456x') == 'abc at 0x456x'
    assert normalize_repr('abc at 0x123 at 0x123') == 'abc at 0x123'
    assert normalize_repr('abc at 0x123 at 0x123 at 0x456') == 'abc at 0x123 at 0x456'
    assert normalize_repr('abc abc at 0x123 at 0x123 at 0x456') == 'abc abc at 0x123 at 0x456'

# Generated at 2022-06-20 12:43:24.848612
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('45') == ('45',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)

# Generated at 2022-06-20 12:43:35.248498
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, ((int, 'bla'), )) == 'bla'
    assert get_repr_function(2.5, ((int, 'bla'), )) == repr
    assert get_repr_function('', ((lambda x: x == 'aha', 'bla'), )) == 'bla'
    assert get_repr_function('', ((lambda x: x == 'aha', 'bla'), )) == 'bla'
    assert get_repr_function('', ((lambda x: x == 'aha', 'bla'),
                                  (lambda x: x == 'baba', 'blabla'))) == 'bla'

# Generated at 2022-06-20 12:43:39.556539
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('x') == ('x',)
    assert ensure_tuple(('x', 'y')) == ('x', 'y')
    assert ensure_tuple(['x', 'y']) == ('x', 'y')
    assert ensure_tuple(set(['x', 'y'])) == ('x', 'y')
    assert ensure_tuple(set(['x', 'y'])) == ('x', 'y')

# Generated at 2022-06-20 12:43:50.955415
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple(('hello', 'world')) == ('hello', 'world')
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((i for i in range(7))) == (0, 1, 2, 3, 4, 5, 6)
    assert ensure_tuple(b'test') == ('t', 'e', 's', 't')
    assert ensure_tuple('test') == ('t', 'e', 's', 't')
    class X:
        def __iter__(self):
            yield 1
            yield 2
    assert ensure_tuple(X()) == (1, 2)
    assert ensure_tuple(7) == (7,)
    assert ensure_tuple(None) == (None,)

# Generated at 2022-06-20 12:44:06.184507
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .settings import MAX_ITEM_LENGTH
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr('12345') == '12345'
    assert get_shortish_repr('123456', max_length=5) == '12...'



# Generated at 2022-06-20 12:44:12.338861
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('a ') == 'a '
    assert shitcode('a\r') == 'a?'
    assert shitcode('\rb') == '?b'
    assert shitcode('\n') == '?'
    assert shitcode('\n\r') == '??'
    assert shitcode('d\x07') == 'd?'
    print('\npassed test_shitcode')

# Generated at 2022-06-20 12:44:18.435904
# Unit test for function shitcode
def test_shitcode():
    '''
    test_shitcode()
    Tests function `shitcode`.
    '''
    assert shitcode('foo') == 'foo'
    assert shitcode('foo\x00bar') == 'foo?bar'
    assert shitcode('foo\x00\x00\x00\x00\x00bar') == 'foo?????bar'

# Generated at 2022-06-20 12:44:21.296590
# Unit test for function shitcode
def test_shitcode():
    assert (shitcode('hello') == 'hello')
    assert (shitcode('héllø') == 'h?ll?')
    assert (shitcode('hélløք') == 'h?ll?ք')

# Generated at 2022-06-20 12:44:29.185275
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple(('abc',)) == ('abc',)
    assert ensure_tuple((5,)) == (5,)
    assert ensure_tuple([5]) == (5,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(x for x in range(2)) == (0, 1)



# Generated at 2022-06-20 12:44:39.102201
# Unit test for function get_repr_function

# Generated at 2022-06-20 12:44:44.755247
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hi ةصثخحجكقفغعظطضصشسرذزخحجكقفغعظطضصشسرذزشسرذزفغعظطضصشسرذز') == 'hi ??????????????'

# Generated at 2022-06-20 12:44:48.851352
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            self.last_write = s

    _file = A()
    _file.write(1)
    assert _file.last_write == 1

    if sys.version_info.major >= 3:
        _file = A()
        assert _file.write('1') is None



# Generated at 2022-06-20 12:44:52.825399
# Unit test for function shitcode
def test_shitcode():

    assert shitcode(u'ñ') == '?'

    assert shitcode(u'\xa1') == '?'

    assert shitcode(u'\u1234') == '?'

    assert shitcode(u'\uD834\uDD1E') == '?'

    assert shitcode(u'\U0001f4a9') == '?'

# Generated at 2022-06-20 12:45:02.243818
# Unit test for function normalize_repr
def test_normalize_repr():
    class AClass: pass
    a_class = AClass()
    assert normalize_repr(repr(a_class)) == '<__main__.AClass object at 0x...>'
    assert normalize_repr('') == ''
    assert normalize_repr(' ') == ' '
    assert normalize_repr('test') == 'test'
    assert normalize_repr('<test>') == '<test>'
    assert normalize_repr('<test at 0x...>') == '<test>'
    assert (normalize_repr('<test at 0x... at 0x...>') ==
            '<test at 0x...>')



# Generated at 2022-06-20 12:45:20.677171
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.items = []

        def write(self, item):
            self.items.append(item)

    writable_stream = MyWritableStream()
    writable_stream.write('foo')
    writable_stream.write('bar')
    assert writable_stream.items == ['foo', 'bar']



# Generated at 2022-06-20 12:45:24.769312
# Unit test for function normalize_repr
def test_normalize_repr():
    """Test that normalize_repr returns a repr without memory address (0x...)"""
    class DummyClass(object):
        pass
    dummy_class = DummyClass()
    assert normalize_repr(repr(dummy_class)) == '<__main__.DummyClass object at 0x'

# Generated at 2022-06-20 12:45:30.227548
# Unit test for function ensure_tuple
def test_ensure_tuple():
    for _ in range(1000):
        x = random.randrange(100)
        assert ensure_tuple(x) == (x,)

        x = [random.randrange(100) for _ in range(random.randrange(100))]
        assert ensure_tuple(x) == tuple(x)

        x = ''.join(random.choice((chr(i) for i in range(128))) for _ in
                    range(random.randrange(100)))
        assert ensure_tuple(x) == (x,)

# Generated at 2022-06-20 12:45:37.601950
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<class \'pdb.Pdb\'>') == '<class \'pdb.Pdb\'>'
    assert normalize_repr('<class \'pdb.Pdb\' at 0x247f2e8>') == '<class \'pdb.Pdb\'>'
    assert normalize_repr('<class \'pdb.Pdb\' at 0x247f2e8>') != '<class \'pdb.Pdb\' at 0x247f2ec>'
    assert normalize_repr('<class \'pdb.Pdb\' at 0x247f2e>') == '<class \'pdb.Pdb\' at 0x247f2e>'

# Generated at 2022-06-20 12:45:47.544113
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr('hello', max_length=2) == 'he...'

    assert get_shortish_repr(b'hello') == "b'hello'"
    assert get_shortish_repr(b'hello', max_length=2) == "b'he...'"

    d = {'a': 'b', }
    assert get_shortish_repr(d) == "{'a': 'b'}"
    assert get_shortish_repr(d, max_length=2) == "{'a': 'b'}"

    import datetime
    assert get_shortish_repr(datetime.datetime.now()) == 'datetime.datetime'


# Generated at 2022-06-20 12:45:55.781155
# Unit test for function get_repr_function
def test_get_repr_function():

    class A(object): pass
    class B(object): pass
    class C(A): pass

    a = A()
    b = B()
    c = C()

    def reprA(x):
        assert isinstance(x, A)
        return 'A!'

    def reprC(x):
        assert isinstance(x, C)
        return 'C!'

    def reprB(x):
        assert isinstance(x, B)
        return 'B!'

    repr_function = get_repr_function(
        a,
        (
            (lambda x: isinstance(x, A), reprA),
            (C, reprC),
        )
    )
    assert repr_function(a) == 'A!'
    assert repr_function(c) == 'C!'

# Generated at 2022-06-20 12:46:00.729717
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyFile(WritableStream):
        def __init__(self):
            self.string = ''

        def write(self, s):
            self.string += s
    my_file = MyFile()
    my_file.write('spam')
    my_file.write(' and eggs')
    assert my_file.string == 'spam and eggs'




# Generated at 2022-06-20 12:46:04.843809
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def write(self):
            pass
    class B:
        pass
    A()
    assert issubclass(A, WritableStream)
    assert not issubclass(B, WritableStream)


# Unit tests for `shitcode`

# Generated at 2022-06-20 12:46:12.232578
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    def _test_cases(cases, custom_repr=(), max_length=None, normalize=False):
        for item, repr_ in cases:
            assert get_shortish_repr(item, custom_repr, max_length,
                                     normalize) == repr_


# Generated at 2022-06-20 12:46:15.585200
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple([3, 2, 1]) == (3, 2, 1)
    assert ensure_tuple((3, 2, 1)) == (3, 2, 1)



# Generated at 2022-06-20 12:46:49.040767
# Unit test for function truncate
def test_truncate():
    assert truncate(None, 10) == ''
    assert truncate('abcdefghijklmn', 10) == 'abcdefghijklmn'
    assert truncate('abcdefghijklmno', 10) == 'abcdefghij...o'
    assert truncate('abcdefghijklmnop', 10) == 'abcdefghij...p'
    assert truncate('abcdefghijklmnopq', 10) == 'abcdefghij...q'
    assert truncate('abcdefghijkl', 10) == 'abcdefghijkl'
    assert truncate('abcdefghijk', 10) == 'abcdefghijk'
    assert truncate('abcdefghij', 10) == 'abcdefghij'
    assert truncate('abcdefghi', 10) == 'abcdefghi'

# Generated at 2022-06-20 12:46:56.727324
# Unit test for function get_repr_function
def test_get_repr_function():
    def f(x):
        return x

    assert get_repr_function(3, []) is repr
    assert get_repr_function(3, [(lambda x: True, f)]) is f
    assert get_repr_function(4, [(4, f)]) is f
    assert get_repr_function(5, [(5, f)]) is f
    assert get_repr_function(6, [(lambda x: x == 6, f)]) is f
    assert get_repr_function(7, [(7, f), (lambda x: False, repr)]) is f
    assert get_repr_function(8, [(lambda x: False, repr), (8, f)]) is f
    assert get_repr_function(9, [(9, f), (lambda x: False, repr)]) is f


# Generated at 2022-06-20 12:47:07.258208
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple(x for x in range(3)) == (0, 1, 2)


# Defining a function that returns `True` if the string is a valid identifier
# according to the Python syntax
if sys.hexversion < 0x03000000:
    _valid_identifier_regex = re.compile(r'^[a-z_][a-z0-9_]*$', re.I)
    _valid_identifier_int_regex = re.compile(r'^[1-9][0-9]*$')

# Generated at 2022-06-20 12:47:13.861798
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefg', 4) == 'abcd'
    assert truncate('abcdefg', 5) == 'abcde'
    assert truncate('abcdefg', 6) == 'abcdef'
    assert truncate('abcdefg', 7) == 'abcdefg'
    assert truncate('abcdefg', 8) == 'abcdefg'
    assert truncate('abcdefg', None) == 'abcdefg'
    assert truncate('abcdefg', 15) == 'abcdefg'



# Generated at 2022-06-20 12:47:15.431897
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class C:
        def write(self):
            pass
    assert issubclass(C, WritableStream)

# Generated at 2022-06-20 12:47:17.875861
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple((1, 2)) == (1, 2)



# Generated at 2022-06-20 12:47:28.204131
# Unit test for function truncate
def test_truncate():
    assert truncate('', None) == ''
    assert truncate('', 0) == ''
    assert truncate('a', 1) == 'a'
    assert truncate('a', 0) == ''
    assert truncate('abc', 1) == 'a'
    assert truncate('abc', 2) == 'ab'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 4) == 'abc'
    assert truncate('abc', 5) == 'abc'
    assert truncate('abcdefghijklmnopqrstuv', 10) == 'abcdefghij...opqrstuv'
    assert truncate('abcdefghijklmnopqrstuv', 11) == 'abcdefghijk...rstuv'

# Generated at 2022-06-20 12:47:38.337607
# Unit test for function normalize_repr
def test_normalize_repr():
    actual = normalize_repr("<object at 0x10503f780>")
    expected = "<object>"
    assert actual == expected

    actual = normalize_repr("<str at 0x10503f780>")
    expected = "<str>"
    assert actual == expected

    actual = normalize_repr("<type at 0x10503f780>")
    expected = "<type>"
    assert actual == expected

    actual = normalize_repr("<class at 0x10503f780>")
    expected = "<class>"
    assert actual == expected

    actual = normalize_repr("<type 'type'>")
    expected = "<type 'type'>"
    assert actual == expected

    actual = normalize_repr("<type 'type' at 0x10503f780>")

# Generated at 2022-06-20 12:47:47.522745
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(12345) == '12345'
    assert get_shortish_repr(1234, max_length=5) == '1234'
    assert get_shortish_repr(12345, max_length=5) == '1...5'
    assert get_shortish_repr(123, max_length=5) == '123'
    assert get_shortish_repr(12, max_length=5) == '12'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=5) == 'abcde...yz'

# Generated at 2022-06-20 12:47:56.419283
# Unit test for function truncate
def test_truncate():
    assert truncate(u'hello world', 20) == u'hello world'
    assert truncate(u'hello world', 11) == u'hello world'
    assert truncate(u'hello world', 10) == u'hello w...'
    assert truncate(u'hello world', 9) == u'hello w...'
    assert truncate(u'hello world', 8) == u'hello ...'
    assert truncate(u'hello world', 7) == u'hello ...'
    assert truncate(u'hello world', 6) == u'hello...'
    assert truncate(u'hello world', 5) == u'hello...'
    assert truncate(u'hello world', 4) == u'he...'
    assert truncate(u'hello', 4) == u'he...'