

# Generated at 2022-06-20 12:38:18.065724
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(4) == (4,)
    assert ensure_tuple([4]) == (4,)
    assert ensure_tuple((4, 2)) == (4, 2)
    assert ensure_tuple((4,)) == (4,)
    class A:
        def __iter__(self):
            yield 4
    assert ensure_tuple(A()) == (4,)
    assert ensure_tuple('hello world') == ('hello world',)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(xrange(2)) == (0, 1)
    assert ensure_tuple(xrange(0)) == tuple()

# Generated at 2022-06-20 12:38:21.367990
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo:
        def write(self, s): pass
    assert issubclass(Foo, WritableStream)
    assert not issubclass(object, WritableStream)
    assert not issubclass(int, WritableStream)

    assert isinstance(Foo(), WritableStream)



# Generated at 2022-06-20 12:38:31.972379
# Unit test for function truncate
def test_truncate():
    assert truncate('foo', 2) == 'fo'
    assert truncate('foo', 3) == 'foo'
    assert truncate('foo', 4) == 'foo'
    assert truncate('foo', 5) == 'foo'
    assert truncate('foobar', 5) == 'foo...'
    assert truncate('foobar', 6) == 'foobar'
    assert truncate('foobar', 7) == 'foobar'
    assert truncate('foobar', 8) == 'foobar'
    assert truncate('foobar', 9) == 'foobar'
    assert truncate('foobar', 10) == 'foobar'
    assert truncate('foobar', 11) == 'foobar'
    assert truncate('foobar', 12) == 'foobar'
    assert truncate('foobar', 13) == 'foobar'

# Generated at 2022-06-20 12:38:34.297363
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class SomeClass(object):
        def write(self, s):
            pass

    assert isinstance(SomeClass(), WritableStream)




# Generated at 2022-06-20 12:38:41.797251
# Unit test for function ensure_tuple
def test_ensure_tuple():

    class TestClass(object):
        def __repr__(self):
            return '<TestClass>'

    assert ensure_tuple(()) == ()
    assert ensure_tuple([]) == ()
    assert ensure_tuple(set()) == ()

    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(set((1, 2))) == (1, 2)

    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('yo') == ('yo',)
    assert ensure_tuple(TestClass()) == (TestClass(), )

    assert ensure_tuple(set([1, 2])) == (1, 2)



# Generated at 2022-06-20 12:38:52.190808
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("hello world") == "hello world"
    assert normalize_repr("hello world at 0xDEADBEEF") == "hello world"
    assert normalize_repr("hello at 0xDEADBEEF world") == "hello at 0xDEADBEEF world"
    assert normalize_repr("hello at 0xDEADBEEF world at 0xCAFEBABE") == "hello at 0xDEADBEEF world"
    assert normalize_repr("hello 0xDEADBEEF world") == "hello 0xDEADBEEF world"
    assert normalize_repr("hello 0xDEADBEEFworld") == "hello 0xDEADBEEFworld"

# Generated at 2022-06-20 12:38:57.107388
# Unit test for function truncate
def test_truncate():
    assert truncate('spam', 5) == 'spam'
    assert truncate('spam', 4) == 'spam'
    assert truncate('spam', 3) == 'spa'
    assert truncate('spam', 2) == 's?'
    assert truncate('spam', 1) == '?'
    assert truncate('spam', 0) == ''
    assert truncate('spam', None) == 'spam'
    assert truncate('spam', -1) == ''



# Generated at 2022-06-20 12:39:05.963042
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == ([1],)
    assert ensure_tuple(x for x in range(10)) == (x for x in range(10))
    for x in range(10):
        assert ensure_tuple(x) == (x,)
    for x in range(10):
        assert ensure_tuple([x]) == ([x],)
    for x in range(10):
        assert ensure_tuple((x,)) == ((x,),)
    for x in range(10):
        assert ensure_tuple((x, x)) == ((x, x),)




# Generated at 2022-06-20 12:39:08.637294
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\0') == '?'
    assert shitcode('\0\0\0') == '???'
    assert shitcode('\0\255') == '?\xff'




# Generated at 2022-06-20 12:39:14.441965
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('x', []) is repr
    assert get_repr_function('x', [(str, shitcode)]) is shitcode
    assert get_repr_function('x', [(str, shitcode), (int, str)]) is shitcode
    assert get_repr_function('x', [(int, str), (str, shitcode)]) is shitcode
    assert get_repr_function(5, [(str, shitcode), (int, str)]) is str
    assert get_repr_function(5, [(str, shitcode)]) is repr
    assert get_repr_function(3.14, [(str, shitcode), (int, str)]) is repr
    assert get_repr_function(3.14, [(str, shitcode)]) is repr


# Generated at 2022-06-20 12:39:26.647264
# Unit test for function truncate
def test_truncate():
    assert truncate('', 5) == ''
    assert truncate('loh', 5) == 'loh'
    assert truncate('long', 5) == 'long'
    assert truncate('longer', 5) == 'lon...'
    assert truncate('longer', 6) == 'longer'
    assert truncate('longer', 7) == 'longer'
    assert truncate('longer', 8) == 'longer'



# Generated at 2022-06-20 12:39:32.475593
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('foo') == 'foo'
    assert normalize_repr('foo at 0x1234') == 'foo'
    assert normalize_repr('foo at 0x12345') == 'foo'
    assert normalize_repr('foo at 0x12345678') == 'foo'
    assert normalize_repr('foo at 0x123456789abc') == 'foo'




# Generated at 2022-06-20 12:39:42.490402
# Unit test for function get_repr_function
def test_get_repr_function():
    def _repr(item_):
        return '_repr({})'.format(item_)
    def _str(item_):
        return '_str({})'.format(item_)

    assert get_repr_function(0, (
        (lambda item: item < 0, _repr),
        (lambda item: item == 0, _str),
        (lambda item: item > 0, _repr),
    )) == _str
    assert get_repr_function(1, (
        (lambda item: item < 0, _repr),
        (lambda item: item == 0, _str),
        (lambda item: item > 0, _repr),
    )) == _repr

# Generated at 2022-06-20 12:39:45.247314
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    stream = io.StringIO()
    assert isinstance(stream, WritableStream)
    stream.write('hello')
    assert stream.getvalue() == 'hello'



# Generated at 2022-06-20 12:39:51.008161
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(('abc', 'def')) == ('abc', 'def')
    assert ensure_tuple(['abc', 'def']) == ('abc', 'def')
    assert ensure_tuple([]) == ()
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(Iterator(['a', 'b', 'c'])) == ('a', 'b', 'c')



# Generated at 2022-06-20 12:39:58.577094
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(0) == '0'
    assert get_shortish_repr(0, max_length=1) == '0'
    assert get_shortish_repr(0, max_length=2) == '0'
    assert get_shortish_repr(123, max_length=3) == '123'
    assert get_shortish_repr(123, max_length=2) == '1...'
    assert get_shortish_repr(123, max_length=1) == '...'
    assert get_shortish_repr(123, max_length=0) == ''
    assert get_shortish_repr('hello', max_length=3) == 'hel'
    assert get_shortish_repr('hello', max_length=8) == 'hello'

# Generated at 2022-06-20 12:40:05.602627
# Unit test for function truncate
def test_truncate():
    assert truncate('asdf', None) == 'asdf'
    assert truncate('asdf', 3) == 'asd'
    assert truncate('asdf', 4) == 'asdf'
    assert truncate('asdf', 2) == 'as'
    assert truncate('asdf', 6) == 'asdf'
    assert truncate('asdf', 10) == 'asdf'
    assert truncate('asdf', 5) == 'as...'



# Generated at 2022-06-20 12:40:10.664680
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object):
        def __repr__(self):
            return 'A'
    class B(object):
        def __repr__(self):
            return 'B'
    class C(object):
        def __repr__(self):
            return 'C'
    assert get_repr_function(A(), [(B, lambda: 'b')])() == 'A'
    assert get_repr_function(B(), [(B, lambda: 'b')])() == 'b'
    assert get_repr_function(C(), [(B, lambda: 'b')])() == 'C'
    assert get_repr_function(B(), [(B, lambda: 'b'), (A, lambda: 'a')])() == 'b'

# Generated at 2022-06-20 12:40:21.600159
# Unit test for function get_repr_function
def test_get_repr_function():
    def r(x):
        return get_repr_function(x, custom_repr=[(int, repr), (float, repr)])
    assert r(1) == repr
    assert r(1.0) == repr
    assert r('hello') == repr

    def r(x):
        return get_repr_function(x, custom_repr=[(int, int), (float, float)])
    assert r(1) == int
    assert r(1.0) == float
    assert r('hello') == repr

    def r(x):
        return get_repr_function(x, custom_repr=[(str, str), (float, float)])
    assert r(1) == repr
    assert r(1.0) == float
    assert r('hello') == str



# Generated at 2022-06-20 12:40:27.303297
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == ([1],)
    assert ensure_tuple((1,)) == ((1,),)
    assert ensure_tuple([1, 2]) == ([1, 2],)
    assert ensure_tuple((1, 2)) == ((1, 2),)
    assert ensure_tuple("hello") == ("hello",)



# Generated at 2022-06-20 12:40:34.635154
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class DummyWritableStream(WritableStream):
        write_calls = []
        def write(self, s):
            self.write_calls.append(s)

    dummy_writable_stream = DummyWritableStream()
    dummy_writable_stream.write('hello')
    dummy_writable_stream.write('world')
    assert dummy_writable_stream.write_calls == ['hello', 'world']



# Generated at 2022-06-20 12:40:37.756485
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A:
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)
    a = A()
    assert isinstance(a, WritableStream)

# Generated at 2022-06-20 12:40:40.593863
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1, )
    assert ensure_tuple((2, )) == (2, )
    assert ensure_tuple([3, ]) == (3, )
    assert ensure_tuple([4, 4]) == (4, 4)



# Generated at 2022-06-20 12:40:43.597112
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyFile(WritableStream):
        def __init__(self):
            self.data = ''
        def write(self, s):
            self.data += s
    my_file = MyFile()
    assert isinstance(my_file, WritableStream)


# Generated at 2022-06-20 12:40:45.953796
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple((5,)) == (5,)
    assert ensure_tuple([5]) == (5,)
    assert ensure_tuple({5}) == (5,)

# Generated at 2022-06-20 12:40:54.287669
# Unit test for function truncate
def test_truncate():
    # Testing normal usage
    assert truncate("", 3) == ""
    assert truncate("a", 3) == "a"
    assert truncate("asd", 3) == "..."
    assert truncate("asdf", 3) == "..."
    assert truncate("asdfg", 3) == "..."
    assert truncate("asdfgh", 3) == "..."
    assert truncate("asdfghj", 3) == "..."
    
    assert truncate("asdf", 4) == "asdf"
    assert truncate("asdfg", 4) == "a..."
    assert truncate("asdfgh", 4) == "a..."
    assert truncate("asdfghj", 4) == "a..."
    
    assert truncate("asdf", 5) == "asdf"

# Generated at 2022-06-20 12:40:58.631879
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: True, lambda y: 'hi')])() == 'hi'
    assert get_repr_function(1, [(lambda x: False, lambda y: 'hi')]) == repr
    assert get_repr_function(1, [(int, lambda y: 'hi')])() == 'hi'
    assert get_repr_function(1, [(float, lambda y: 'hi')]) == repr
    assert get_repr_function(1.0, [(int, lambda y: 'hi'),
                                   (float, lambda y: 'hihi')])() == 'hihi'



# Generated at 2022-06-20 12:41:03.454874
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .string_io import BytesIOWrapper as BIO
    class A(WritableStream):
        pass
    print('issue with bpo-36766; remove the following line:')
    print(WritableStream.__subclasshook__(BIO))
    assert issubclass(BIO, WritableStream)
    assert issubclass(BIO, A)
    assert not issubclass(A, BIO)
    assert not issubclass(object, BIO)

# Generated at 2022-06-20 12:41:11.831039
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghij', 3) == 'abcdefghij'
    assert truncate('abcdefghij', 5) == 'abc...hij'
    assert truncate('abcdefghij', 6) == 'abcde...ij'
    assert truncate('abcdefghij', 7) == 'abcdef...ij'
    assert truncate('abcdefghij', 8) == 'abcdefg...ij'
    assert truncate('abcdefghij', 9) == 'abcdefgh...ij'
    assert truncate('abcdefghij', 10) == 'abcdefghij'

# Generated at 2022-06-20 12:41:15.406450
# Unit test for function truncate
def test_truncate():
    assert truncate('abcd', 2) == 'ab...'
    assert truncate('abcd', 3) == 'ab...'
    assert truncate('abcd', 4) == 'abc...'
    assert truncate('abcd', 5) == 'abcd'
    assert truncate('abcd', 6) == 'abcd'



# Generated at 2022-06-20 12:41:30.371634
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    long_str = 'This is a long string.'
    assert get_shortish_repr(long_str, max_length=len(long_str)) == long_str
    assert get_shortish_repr(long_str, max_length=len(long_str) - 1) == \
           long_str[:-2] + '..'
    assert get_shortish_repr(long_str, max_length=len(long_str) - 2) == \
           long_str[:-3] + '...'
    assert get_shortish_repr(long_str, max_length=len(long_str) - 3) == \
           long_str[:-4] + '...'

# Generated at 2022-06-20 12:41:34.751839
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Demo(WritableStream):
        def __init__(self):
            self.result = ''
        def write(self, s):
            self.result += s
    demo = Demo()
    demo.write('a')
    assert demo.result == 'a'

# Generated at 2022-06-20 12:41:41.393371
# Unit test for function shitcode
def test_shitcode():
    r'''This function is a unit test for the function `shitcode`.
    
    Use this command to run it:
    
        python3 -c 'import sys; sys.path.append("."); from . import auxiliar; auxiliar.test_shitcode()'
    
    '''

    assert '?' not in shitcode('What the fuck')
    assert '??' not in shitcode('What the fuck')
    assert shitcode('כאן וכאן לפעמים נשיפה מים מציגים כמה משחק') == '??????????? ???????? ??? ???? ??? ????? ???? ?????'



# Generated at 2022-06-20 12:41:48.550981
# Unit test for function truncate
def test_truncate():
    assert truncate(u'hello', 7) == u'hello'
    assert truncate(u'hello', 6) == u'hello'
    assert truncate(u'hello', 5) == u'hello'
    assert truncate(u'hello', 4) == u'hell'
    assert truncate(u'hello', 3) == u'...'
    assert truncate(u'hello', 2) == u'..'
    assert truncate(u'hello', 1) == u'.'
    assert truncate(u'hello', 0) == u''

    assert truncate(u'hello', None) == u'hello'
    assert truncate(u'hello', -1) == u'hello'
    assert truncate(u'hello', -2) == u'hello'

# Generated at 2022-06-20 12:41:54.588905
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        def write(self, s):
            pass

    assert issubclass(Foo, WritableStream)

    class Bar:
        def write(self, s):
            pass
        def read(self, s):
            pass

    assert not issubclass(Bar, WritableStream)

    class Baz:
        def read(self, s):
            pass

    assert not issubclass(Baz, WritableStream)




# Generated at 2022-06-20 12:41:59.214754
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(()) == ()
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple([]) == ()
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple({}) == ()
    assert ensure_tuple({1: 2}) == (1,)
    assert ensure_tuple({1, 2}) == (1, 2)
    assert ensure_tuple(set([1, 2])) == (1, 2)

# Generated at 2022-06-20 12:42:06.634917
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # If a class doesn't have a `write` method, it's not a `WritableStream`:
    assert not issubclass(object, WritableStream)
    assert not issubclass(int, WritableStream)
    assert not issubclass(str, WritableStream)

    # If a class has a `write` method, it is a `WritableStream:
    class Foo(object):
        def write(self, s): pass
    assert issubclass(Foo, WritableStream)

# Generated at 2022-06-20 12:42:10.049209
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('你好') == '??'
    assert shitcode(chr(300)) == '?'
    assert shitcode('hello\x80world') == 'hello?world'
    assert shitcode('\n\r\xab\xcd') == '\n\r\xab\xcd'


# Generated at 2022-06-20 12:42:14.170436
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        class __metaclass__(type):
            def __subclasshook__(cls, C):
                if cls is WritableStream:
                    return _check_methods(C, 'write')
                return NotImplemented

    class B(A):
        def write(self, s):
            pass

    assert isinstance(B(), WritableStream)

# Generated at 2022-06-20 12:42:24.674326
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnopqrstuvwxyz', max_length=None) == \
                                                                          'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', max_length=3) == '...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', max_length=4) == 'a...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', max_length=6) == 'a...yz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', max_length=10) == 'ab...uvwxyz'

# Generated at 2022-06-20 12:42:34.242530
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('\x00\x01\x02\x03\x04\x05\x06\x07') == '????????'
    assert shitcode(unichr(0) + 'a' + unichr(1) + 'b') == '?a?b'



# Generated at 2022-06-20 12:42:38.661805
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class NoopStream(object): pass
    class WriteStream(object):
        def write(self, s): pass
    assert not issubclass(NoopStream, WritableStream)
    assert issubclass(WriteStream, WritableStream)

# Generated at 2022-06-20 12:42:41.133483
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeFile(WritableStream):
        def write(self, s):
            assert s == 'foo'
    FakeFile().write('foo')

# Generated at 2022-06-20 12:42:45.466489
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1j, [(lambda x: True, lambda x: 'hello')]) == 'hello'
    assert get_repr_function(1j, [(complex, lambda x: 'hello')]) == 'hello'
    assert get_repr_function(1, [(complex, lambda x: 'hello')]) == repr



# Generated at 2022-06-20 12:42:48.996161
# Unit test for function shitcode
def test_shitcode():
    def checker(source, expected):
        assert shitcode(source) == expected
    checker('ABCDEF', 'ABCDEF')
    checker(b'ABCDEF', 'ABCDEF')
    checker(u'שלום', '???')
    checker(b'\xff', '?')



# Generated at 2022-06-20 12:42:55.126317
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, custom_repr=((int, str),)) == str
    assert get_repr_function('hello', custom_repr=((int, str),)) == repr
    assert get_repr_function(3, custom_repr=((lambda x: x % 2, str),)) == str
    assert get_repr_function('hello',
                             custom_repr=((lambda x: x % 2, str),)) == repr



# Generated at 2022-06-20 12:43:05.737255
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import collections
    items = [
        'foo',
        'fo' * 50,
        123456789,
        12345678.9,
        u'foo',
        u'fo' * 50,
        collections.defaultdict,
    ]
    custom_repr = (
        (_is_my_class, lambda item: 'MY-CLASS'),
        (lambda item: True, lambda item: 'ALWAYS'),
    )
    def _is_my_class(item):
        return type(item) is my_class
    class my_class(object): pass
    items.append(my_class())

# Generated at 2022-06-20 12:43:15.960304
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, custom_repr=((int, str),)) == '1'
    assert get_shortish_repr(1, max_length=10) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'

    assert get_shortish_repr((1,)) == '(1,)'

# Generated at 2022-06-20 12:43:20.623577
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'shít') == 'shit'
    assert shitcode(u'shít') == 'shit'
    assert shitcode(u'שתק') == '?'

    assert shitcode(u'shít') == 'shit'
    assert shitcode(u'shít') == 'shit'
    assert shitcode(u'שתק') == '?'

    assert shitcode(u'\U0001F363') == '?'




# Generated at 2022-06-20 12:43:31.428358
# Unit test for function normalize_repr
def test_normalize_repr():
    import re
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0xABCDE') == 'hello'
    assert normalize_repr('hello at 0x0123456789ABCDE') == 'hello'
    assert re.match(r'^hello at 0x0*$', normalize_repr('hello at 0x0'))
    # Make sure it does not clash with "at" inside strings
    assert normalize_repr('hello at world') == 'hello at world'
    assert normalize_repr('hello at world at 0xABCDE') == 'hello at world'
    assert normalize_repr('hello at world at 0x0123456789ABCDE') == \
                                                             'hello at world'




# Generated at 2022-06-20 12:43:43.652432
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('MyClass object at 0x1234') == 'MyClass object'
    assert normalize_repr('') == ''
    assert normalize_repr('my string') == 'my string'
    assert normalize_repr(u'my string') == u'my string'
    assert normalize_repr('MyClass object at 0x1234567890abcdef') == \
                                                             'MyClass object'
    assert normalize_repr('MyClass object at 0xBEEF') == 'MyClass object'
    assert normalize_repr('MyClass object at 0x1001') == 'MyClass object'
    assert normalize_repr(u'MyClass object at 0x1234567890abcdef') == \
                                                             'MyClass object'



# Generated at 2022-06-20 12:43:48.222245
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'a' * 0x100) == u'a' * 0x100  # No truncation
    assert shitcode(u'a' * 0x100 + u'\U0001f4a9') == u'a' * 0x100 + u'?'



# Generated at 2022-06-20 12:43:53.133853
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (
        (lambda x: x > 0, str),
    )) == str
    assert get_repr_function(1, (
        (type(1), str),
    )) == str
    assert get_repr_function(type(1), (
        (type(1), str),
    )) == repr

# Generated at 2022-06-20 12:43:55.157403
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert isinstance(sys.stdout, WritableStream)
    assert isinstance('spam', WritableStream) == NotImplemented



# Generated at 2022-06-20 12:44:01.995032
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert isinstance(ensure_tuple(3), tuple)
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((3,)) == (3,)
    assert ensure_tuple([3]) == (3,)
    assert ensure_tuple((3, 5, 6)) == (3, 5, 6)
    assert ensure_tuple([5, 6, 5]) == (5, 6, 5)
    assert ensure_tuple([5, [6], 5]) == (5, [6], 5)



# Generated at 2022-06-20 12:44:05.874896
# Unit test for constructor of class WritableStream
def test_WritableStream():
    """
    Must have a write method.
    """

    class A:
        def write(self, s):
            return s

    assert issubclass(A, WritableStream)

    class B:
        pass

    assert not issubclass(B, WritableStream)

    class C:
        write = None

    assert issubclass(C, WritableStream)

test_WritableStream()

# Generated at 2022-06-20 12:44:11.711490
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('') == ('',)
    assert ensure_tuple([]) == ([],)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2]) == ([1, 2],)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple((1, 2, (3, 4))) == (1, 2, (3, 4))



# Generated at 2022-06-20 12:44:14.721609
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class ExampleClass(WritableStream):
        def write(self, s):
            pass
    assert issubclass(ExampleClass, WritableStream)

# Generated at 2022-06-20 12:44:24.733831
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .programs.hello_world import hello_world
    from .programs.multi_line import multi_line
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr(b'abc') == "b'abc'"
    assert get_shortish_repr(u'abc') == "u'abc'"
    assert get_shortish_repr(object()) == 'REPR FAILED'
    assert get_shortish_repr(hello_world) == '<programs.hello_world.hello_world object at'
    assert get_shortish_repr(hello_world, max_length=25) == '<programs.hello_world.hello_world'

# Generated at 2022-06-20 12:44:26.663128
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('☃') == '?'
    assert shitcode('\x01\x02') == '??'



# Generated at 2022-06-20 12:44:40.531700
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('\xff') == '\xff'
    assert shitcode(chr(255)) == chr(255)
    assert shitcode(chr(256)) == '?'
    assert shitcode(chr(0)) == '?'
    assert shitcode('a\0') == 'a?'
    assert shitcode('a\xff') == 'a\xff'
    assert shitcode('a\x100') == 'a?'
    assert shitcode(chr(256) + chr(257)) == '??'
    assert shitcode('\U0010FFFF') == '\U0010FFFF'
    assert shitcode('\U0010FFFE') == '?'




# Generated at 2022-06-20 12:44:43.846901
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(('a', 'b')) == ('a', 'b')
    assert ensure_tuple([1, 2]) == (1, 2)




# Generated at 2022-06-20 12:44:46.897684
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class C(object):
        def write(self):
            pass
    assert isinstance(C(), WritableStream)
    class D(object):
        pass
    assert not isinstance(D(), WritableStream)



# Generated at 2022-06-20 12:44:50.429745
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(2, (((lambda x: x % 2 == 0), int.__str__),)) is int.__str__
    assert get_repr_function(3, (((lambda x: x % 2 == 0), int.__str__),)) is repr



# Generated at 2022-06-20 12:44:52.673759
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1]) == (1,)



# Generated at 2022-06-20 12:45:03.466904
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcde') == 'abcde'
    assert get_shortish_repr('abcde', max_length=5) == 'abcde'
    assert get_shortish_repr('abcde', max_length=4) == 'abcd...'
    assert get_shortish_repr('abcde', max_length=3) == 'abc...'
    assert get_shortish_repr('abcde', max_length=2) == 'ab...'
    assert get_shortish_repr('abcde', max_length=1) == 'a...'
    assert get_shortish_repr('abcde', max_length=0) == '...'
    assert get_shortish_repr('abcde', max_length=None) == 'abcde'
    assert get_short

# Generated at 2022-06-20 12:45:12.393371
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3,)
    assert ensure_tuple(xrange(3)) == (0, 1, 2,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3,)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple('') == ('',)
    assert ensure_tuple('abc') == ('abc',)

    for x in [
            [], (), set(), frozenset(), dict(), {}, bytearray(), b'',
            b'abc', bytearray(b'abc')
    ]:
        assert ensure_tuple(x) == (x,)




# Generated at 2022-06-20 12:45:19.129185
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', None) == 'hello'
    assert truncate('hello', 3) == 'hel'
    assert truncate('hello', 4) == 'hell'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 6) == 'hello'
    assert truncate('hello', 7) == 'hello'
    assert truncate('hello', 8) == 'hello'
    assert truncate('hello', 1000) == 'hello'
    assert truncate('x' * 1000, 20) == 'xxxxxxxxxxxxxxx...xxxxxxxxxx'

# Generated at 2022-06-20 12:45:25.698387
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert ensure_tuple([]) == ()
    assert ensure_tuple('a') == ('a',)
    assert ensure_tuple(('a',)) == ('a',)
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((3,)) == (3,)
    assert ensure_tuple(None) == (None,)




# Generated at 2022-06-20 12:45:29.112937
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert isinstance(ensure_tuple((2, 3)), tuple)
    assert isinstance(ensure_tuple([2, 3]), tuple)
    assert ensure_tuple('he') == ('he',)
    assert ensure_tuple(3) == (3,)




# Generated at 2022-06-20 12:45:45.715947
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'\N{HIRAGANA LETTER A}') == '?'
    assert shitcode(u'a\N{HIRAGANA LETTER A}') == 'a?'
    assert shitcode('a') == 'a'
    assert shitcode('\n\r') == '\n\r'
    assert shitcode(u'') == u''
    assert shitcode('') == ''




# Generated at 2022-06-20 12:45:52.954221
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = []

        def write(self, s):
            self.written.append(s)

    # Correct usage:
    MyWritableStream()
    writeable_stream = MyWritableStream()
    writeable_stream.write('foo')
    writeable_stream.write('bar')
    assert writeable_stream.written == ['foo', 'bar']

    # Incorrect usage:
    # class Z: pass
    # Z()
    # z = Z()
    # z.write('foo')

# Generated at 2022-06-20 12:45:54.649697
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X(WritableStream):
        def write(self, s):
            return None
    assert issubclass(X, WritableStream)



# Generated at 2022-06-20 12:46:05.333994
# Unit test for function normalize_repr
def test_normalize_repr():
    class A(object):
        pass
    assert normalize_repr("<magic_repr.A object at 0x1006793b0>") == \
                                               "<magic_repr.A object>"
    assert normalize_repr("<magic_repr.A object at 0xffffffff>") == \
                                               "<magic_repr.A object>"
    assert normalize_repr("<magic_repr.A object at 0xdeadbeef>") == \
                                               "<magic_repr.A object>"
    assert normalize_repr("<magic_repr.A object at 0x13371337>") == \
                                               "<magic_repr.A object>"

# Generated at 2022-06-20 12:46:11.865924
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda x: isinstance(x, int), lambda x: 'int:' + str(x)),
        (lambda x: isinstance(x, str), lambda x: 'str:' + str(x)),
        (lambda x: isinstance(x, (tuple, list)), lambda x: 'list:' + str(x)),
    )
    assert get_repr_function(1, custom_repr) == custom_repr[0][1]
    assert get_repr_function('str', custom_repr) == custom_repr[1][1]
    assert get_repr_function([1, 2], custom_repr) == custom_repr[2][1]



# Generated at 2022-06-20 12:46:22.298972
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .utils import doctest_tools

    assert get_shortish_repr(5, normalize=True) == '5'

    assert get_shortish_repr('123456789', max_length=9) == '123456789'
    assert get_shortish_repr('123456789', max_length=8) == '123...89'
    assert get_shortish_repr('123456789', max_length=7) == '12...89'
    assert get_shortish_repr('123456789', max_length=6) == '1...89'
    assert get_shortish_repr('123456789', max_length=5) == '1...9'
    assert get_shortish_repr('123456789', max_length=4) == '1...'

# Generated at 2022-06-20 12:46:27.401262
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('Hello') == 'Hello'
    assert normalize_repr('Hello at 0x1234') == 'Hello'
    assert normalize_repr('Hello at 0x123456789') == 'Hello'
    assert normalize_repr('Hello at 0x12') == 'Hello at 0x12'

# Generated at 2022-06-20 12:46:36.065147
# Unit test for function shitcode
def test_shitcode():
    def test_shitcode_ch(c):
        assert shitcode(c) == c
    test_shitcode_ch('a')
    test_shitcode_ch('b')
    test_shitcode_ch('c')
    test_shitcode_ch('d')
    test_shitcode_ch('e')
    test_shitcode_ch('f')
    test_shitcode_ch('g')
    test_shitcode_ch('h')
    test_shitcode_ch('i')
    test_shitcode_ch('j')
    test_shitcode_ch('k')
    test_shitcode_ch('l')
    test_shitcode_ch('m')
    test_shitcode_ch('n')
    test_shitcode_ch('o')
    test_shitcode_ch('p')
   

# Generated at 2022-06-20 12:46:39.375253
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == ((1, 2),)
    assert ensure_tuple([1, 2]) == ([1, 2],)
    assert ensure_tuple(range(3)) == (range(3),)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(()) == ((),)




# Generated at 2022-06-20 12:46:42.087903
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    assert isinstance(MyWritableStream(), WritableStream)

# Generated at 2022-06-20 12:47:09.093052
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello', max_length=30) == 'hello'
    assert get_shortish_repr('hello', max_length=5) == 'hello'
    assert get_shortish_repr('helloxxx', max_length=5) == 'hell...'
    assert get_shortish_repr('hexxx', max_length=5) == 'he...'



# Generated at 2022-06-20 12:47:18.621309
# Unit test for function truncate
def test_truncate():
    assert truncate(u'hello world!', None) == u'hello world!'
    assert truncate(u'hello world!', 5) == u'he...!'
    assert truncate(u'abcdef', 5) == u'ab...'
    assert truncate(u'abcde', 5) == u'abcde'
    assert truncate(u'abcde', 4) == u'a...'
    assert truncate(u'abcde', 3) == u'a..'
    assert truncate(u'abcde', 2) == u'a.'
    assert truncate(u'abcde', 1) == u'a'
    assert truncate(u'abcde', 0) == u''



# Taken from https://stackoverflow.com/a/32411679/1967196

# Generated at 2022-06-20 12:47:27.416948
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(42) == u'42'
    assert get_shortish_repr([1,2,3]) == u'[1, 2, 3]'
    assert get_shortish_repr(set([(1, 2), (3, 4)])) == u'{(1, 2), (3, 4)}'
    assert get_shortish_repr(set([(u'س', 2), (3, 4)])) == u"{('\\u0633', 2), (3, 4)}"
    assert get_shortish_repr('ש') == u"'\\u05e9'"


module = sys.modules[__name__]


# Generated at 2022-06-20 12:47:34.322065
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import sys

    class BlackHole(WritableStream):
        def write(self, s):
            pass

    assert isinstance(sys.stdout, WritableStream)
    assert isinstance(io.StringIO(), WritableStream)
    assert isinstance(BlackHole(), WritableStream)

    class Unwritable(object):
        pass

    assert not isinstance(Unwritable(), WritableStream)



# Generated at 2022-06-20 12:47:35.597080
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc\u0001') == 'abc?'



# Generated at 2022-06-20 12:47:38.231184
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(4) == (4,)
    assert ensure_tuple((5, 6)) == (5, 6)



# Generated at 2022-06-20 12:47:40.297503
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Test(WritableStream):
        def write(self, s):
            pass

    test = Test()
    assert issubclass(Test, WritableStream)



# Generated at 2022-06-20 12:47:47.845301
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode(u'abc') == u'abc'
    assert shitcode('\x00\x01\x02') == '???'
    assert shitcode(u'\x00\x01\x02') == '???'
    assert shitcode(u'a\xffb\xc3c\x04') == u'a?b?c?'
    assert shitcode('a\xffb\xc3c\x04') == 'a?b?c?'
    assert shitcode('\x00') == '?'
    assert shitcode(u'\x00') == '?'




# Generated at 2022-06-20 12:47:51.803046
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.result = []

        def write(self, s):
            self.result.append(s)
    assert MyWritableStream.__subclasshook__(MyWritableStream) is True
    assert MyWritableStream.__subclasshook__(Exception) is NotImplemented

# Generated at 2022-06-20 12:47:57.052733
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc', max_length=None) == 'abc'
    assert get_shortish_repr('abc', max_length=2) == 'ab...'
    assert get_shortish_repr('abc', max_length=1) == 'a...'
    assert get_shortish_repr('abc', max_length=0) == '...'
