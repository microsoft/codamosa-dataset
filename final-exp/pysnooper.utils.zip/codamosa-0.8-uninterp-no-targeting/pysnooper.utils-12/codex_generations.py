

# Generated at 2022-06-20 12:38:18.600148
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\x00') == '?'
    assert shitcode('\x1F') == '?'
    assert shitcode('\x7F') == '?'
    assert shitcode(u'\x7F') == '?'
    assert shitcode(u'\x80') == '?'
    assert shitcode(u'\uFFFF') == '?'
    assert shitcode('$') == '$'
    assert shitcode(u'$') == '$'
    assert shitcode('\n') == '\n'
    assert shitcode(u'\n') == '\n'
    assert shitcode(u'\u2026') == '\u2026' # Horizontal ellipsis (…)
    assert shitcode(u'\u2122') == '\u2122' # Trade mark sign (™)
   

# Generated at 2022-06-20 12:38:21.224016
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(['hello', 'hi']) == ('hello', 'hi')
    assert ensure_tuple(('hello', 'hi')) == ('hello', 'hi')
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(1) == (1,)

# Generated at 2022-06-20 12:38:31.790236
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo(object):
        pass
    def repr_function_1(x):
        return 'i am a repr function'
    def repr_function_2(x):
        return 'i am another repr function'
    conditions = [
        lambda x: isinstance(x, Foo),
        lambda x: isinstance(x, str)
    ]
    actions = [
        repr_function_1,
        repr_function_2
    ]
    custom_repr = tuple(zip(conditions, actions))

    assert get_repr_function(Foo(), custom_repr) == repr_function_1
    assert get_repr_function('a string', custom_repr) == repr_function_2
    assert get_repr_function(1, custom_repr) == repr


# Generated at 2022-06-20 12:38:35.256740
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [(lambda x: True, lambda x: x+' world')]
    repr_function = get_repr_function(1, custom_repr)
    assert repr_function(1) == '1 world'

# Generated at 2022-06-20 12:38:38.057507
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s
    stream = MyStream()
    stream.write('hello')
    assert stream.written == 'hello'



# Generated at 2022-06-20 12:38:48.097405
# Unit test for function get_repr_function
def test_get_repr_function():
    # The default repr is used if no condition is fulfilled
    assert get_repr_function('foo', custom_repr=()) == repr

    # Custom repr functions
    def custom_repr_1(s):
        return 'custom_repr_1: ' + str(s)
    def custom_repr_2(s):
        return 'custom_repr_2: ' + str(s)

    # The custom repr functions are used when the conditions are fulfilled
    assert get_repr_function('foo', custom_repr=(
        (str.startswith, custom_repr_1),
        (lambda s: s.endswith('f'), custom_repr_2),
    )) == custom_repr_2

    # If the custom repr functions fail, the default repr is used

# Generated at 2022-06-20 12:38:53.609710
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple((1, 2, 3, 4)) == (1, 2, 3, 4)
    assert ensure_tuple([1, 2, 3, 4]) == (1, 2, 3, 4)
    assert ensure_tuple({1, 2, 3, 4}) == (1, 2, 3, 4)




# Generated at 2022-06-20 12:39:04.258181
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(A): pass

    assert get_repr_function(1, custom_repr=[(A, int.__repr__)]) == int.__repr__
    assert get_repr_function(1, custom_repr=[(B, int.__repr__)]) != int.__repr__
    assert get_repr_function('foo', custom_repr=[(A, int.__repr__)]) != \
                                                                int.__repr__
    assert get_repr_function(1, custom_repr=[(int, int.__repr__)]) == \
                                                                int.__repr__

# Generated at 2022-06-20 12:39:07.454513
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hello', ((str, 's'), (int, 'i'))) == 's'
    assert get_repr_function(123, ((str, 's'), (int, 'i'))) == 'i'



# Generated at 2022-06-20 12:39:13.162214
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    big_string = 'abcdefghijklmnopqrstuvwxyz'
    for max_length in (None, 0, 5, 10, 15, 20, 26):
        assert get_shortish_repr(big_string, max_length=max_length) == big_string[:max_length]

    custom_repr = [(lambda x: True, lambda x: x * 100)]

    class Foo(object):
        def __init__(self, i):
            self.i = i
    objs = [Foo(i) for i in range(10)]


# Generated at 2022-06-20 12:39:26.814467
# Unit test for function get_repr_function
def test_get_repr_function():
    class SomeClass(object): pass
    class SomeClass2(object): pass
    class SomeClass3(SomeClass2): pass
    custom_repr = (
        (lambda x: isinstance(x, SomeClass), lambda x: 'A' + repr(x)),
        (lambda x: isinstance(x, SomeClass2), lambda x: 'B' + repr(x)),
        (SomeClass3, lambda x: 'C' + repr(x)),
        (7, lambda x: 'D' + repr(x))
    )
    assert get_repr_function('x', custom_repr) == repr
    assert get_repr_function('x', ()) == repr
    assert get_repr_function(SomeClass(), custom_repr) == custom_repr[0][1]

# Generated at 2022-06-20 12:39:31.176333
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Stream(WritableStream):
        def __init__(self):
            self.items = []

        def write(self, item):
            self.items.append(item)

    stream = Stream()
    stream.write('foo')
    assert stream.items == ['foo']



# Generated at 2022-06-20 12:39:36.272195
# Unit test for function normalize_repr
def test_normalize_repr():
    from .pretty import normalize_repr
    assert normalize_repr('') == ''
    assert normalize_repr('0x123') == '0x123'
    assert normalize_repr('hi') == 'hi'
    assert normalize_repr('hi at 0x123') == 'hi'
    assert normalize_repr('hi at 0x123 at 0x456') == 'hi'
    assert normalize_repr('hi at 0x123 at 0x456 at 0x789') == 'hi'


_FORMAT_SPEC_RE = re.compile(r'\{(.+?)([:-]?(?:[0-9\. ]+))?\}')




# Generated at 2022-06-20 12:39:38.393990
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(()) == ()
    assert ensure_tuple([]) == ()
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)

# Generated at 2022-06-20 12:39:44.954944
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    custom_repr = (
        ('A', lambda s: 'A'),
        ('B', lambda s: 'B'),
        ('C', lambda s: 'C'),
        ('D', lambda s: 'D'),
        ('E', lambda s: 'E')
    )
    assert get_shortish_repr('A', custom_repr=custom_repr) == 'A'
    assert get_shortish_repr('B', custom_repr=custom_repr) == 'B'
    assert get_shortish_repr('C', custom_repr=custom_repr) == 'C'
    assert get_shortish_repr('D', custom_repr=custom_repr) == 'D'

# Generated at 2022-06-20 12:39:54.370246
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijk', None) == 'abcdefghijk'
    assert truncate('abcdefghijkl', None) == 'abcdefghijkl'
    assert truncate('abcdefghijklmn', None) == 'abcdefghijklmn'

    assert truncate('abcdefghijk', 10) == 'abcdefghijk'
    assert truncate('abcdefghijkl', 10) == 'abcdefghijkl'
    assert truncate('abcdefghijklmn', 10) == 'abcdef...klmn'

    assert truncate('abcdefghijk', 5) == 'ab...k'
    assert truncate('abcdefghijkl', 5) == 'a...l'
    assert truncate('abcdefghijklmn', 5) == '...mn'

test_truncate()




# Generated at 2022-06-20 12:40:05.835182
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: x + 1)]) == (
        lambda x: x + 1
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: x + 1)]) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: x + 1),
                                 (lambda x: True, lambda x: x + 2)]) == (
        lambda x: x + 2
    )
    assert get_repr_function(1, [(lambda x: False, lambda x: x + 1),
                                 (lambda x: True, lambda x: x + 2)]) == (
        lambda x: x + 2
    )

# Generated at 2022-06-20 12:40:13.429994
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abcé') == 'abc?'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode(u'abc') == 'abc'
    assert shitcode(u'abc\x00') == 'abc?'
    assert shitcode(u'abcé') == 'abc?'
    assert shitcode(chr(0)) == '?'
    assert shitcode(chr(127)) == '?'
    assert shitcode(chr(128)) == '?'
    assert shitcode(chr(255)) == '?'
    assert shitcode(chr(256)) == '?'
    assert shitcode(chr(300)) == '?'
    assert shitcode(chr(10000)) == '?'

# Generated at 2022-06-20 12:40:17.077230
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hi at 0x1234') == 'hi'
    def f(): pass
    assert normalize_repr(repr(f)) == repr(f)

# Generated at 2022-06-20 12:40:24.970796
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Thing:
        def write(self, s):
            pass
    assert issubclass(Thing, WritableStream)

    class Thing2:
        pass
    assert not issubclass(Thing2, WritableStream)

    class Thing3:
        def write(self, s):
            pass
        def write2(self, s):
            pass
    assert issubclass(Thing3, WritableStream)



if __name__ == '__main__':
    test_WritableStream()

# Generated at 2022-06-20 12:40:33.445036
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .stringio_tools import StringIO

    class MyStream(WritableStream):
        def __init__(self):
            self.stream = StringIO()
        def write(self, s):
            self.stream.write(s)

    ms = MyStream()
    ms.write('meow')
    assert ms.stream.getvalue() == 'meow'


if __name__ == '__main__':
    test_WritableStream_write()

# Generated at 2022-06-20 12:40:36.213721
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass
    assert isinstance(WritableStreamSubclass(), WritableStream)


# Generated at 2022-06-20 12:40:43.773621
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<module \'re\' from \'/usr/lib/python2.7/re.pyc\'>') == '<module \'re\' from \'/usr/lib/python2.7/re.pyc\'>'
    assert normalize_repr('<module \'re\' from \'/usr/lib/python2.7/re.pyc\' at 0x7f8d28fadcc0>') == '<module \'re\' from \'/usr/lib/python2.7/re.pyc\'>'

# Generated at 2022-06-20 12:40:52.839144
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', 5) == 'abc'
    assert truncate('abc', 2) == 'ab...'
    assert truncate('abc', 1) == '...'
    assert truncate('abc', 0) == '...'
    assert truncate('abc', None) == 'abc'
    assert truncate(b'abc', 5) == b'abc'
    assert truncate(b'abc', 2) == b'ab...'
    assert truncate(b'abc', 1) == b'...'
    assert truncate(b'abc', 0) == b'...'
    assert truncate(b'abc', None) == b'abc'



if __name__ == '__main__':
    test_truncate()
    print('tests passed')

# Generated at 2022-06-20 12:41:01.860417
# Unit test for function get_repr_function
def test_get_repr_function():
    import pytest

    example_class = type('ExampleClass', (), {})

    custom_repr = [
        (lambda x: x == 1, repr),
        (lambda x: x == 2, str),
        (lambda x: x == 3, len),
        (lambda x: x == 4, example_class.__repr__),
        (example_class, example_class.__repr__),
        (lambda x: False, example_class.__repr__),
    ]

    assert get_repr_function(1, custom_repr) is repr
    assert get_repr_function(2, custom_repr) is str
    assert get_repr_function(3, custom_repr) is len
    assert get_repr_function(4, custom_repr) is example_class.__repr

# Generated at 2022-06-20 12:41:08.343251
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abcd efgh') == 'abcd efgh'
    assert shitcode(u'abcd\u1234efgh') == 'abcd?efgh'
    assert shitcode(u'\u1234') == '?'
    assert shitcode('\u1234') == '?'
    assert shitcode('\u12345') == '\u12345'

# Generated at 2022-06-20 12:41:13.875004
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TechnicallyWritableStream:
        def __init__(self, items):
            self.items = items

        def write(self, s):
            self.items.append(s)

    assert issubclass(TechnicallyWritableStream, WritableStream)

    class TechnicallyNotWritableStream:
        def __init__(self, items):
            self.items = items

    assert not issubclass(TechnicallyNotWritableStream, WritableStream)



# Generated at 2022-06-20 12:41:15.751498
# Unit test for function normalize_repr

# Generated at 2022-06-20 12:41:23.083464
# Unit test for method write of class WritableStream
def test_WritableStream_write():


    class Working(object):
        def write(self, s):
            pass

    assert issubclass(Working, WritableStream)


    class NotWorking(object):
        pass
    assert not issubclass(NotWorking, WritableStream)


    class NotWorking2(object):
        def write(self, s):
            pass
        def write2(self, s):
            pass
    assert not issubclass(NotWorking2, WritableStream)



# Generated at 2022-06-20 12:41:28.040442
# Unit test for function truncate
def test_truncate():
    assert truncate(u'', 3) == u''
    assert truncate(u'123456', 3) == u'123...'
    assert truncate(u'123456', 4) == u'1...6'
    assert truncate(u'123456', 10) == u'123456'
    assert truncate(u'123456', None) == u'123456'



# Generated at 2022-06-20 12:41:39.821778
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<function foo at 0x1254>') == '<function foo>'
    assert normalize_repr('<function foo>') == '<function foo>'
    assert normalize_repr('<function foo at 0x12542>') == '<function foo>'
    assert normalize_repr('<function foo at 0x1254222>') == '<function foo>'
    assert normalize_repr('<function foo at 0x12542223>') == '<function foo>'
    assert normalize_repr('<function foo at 0x125422233>') == '<function foo>'
    assert normalize_repr('<function foo at 0x1254222333>') == '<function foo>'

# Generated at 2022-06-20 12:41:44.943514
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('ă') == '?'
    assert shitcode('ă' + '\xFF') == '? ?'
    assert shitcode('\x00') == '?'
    assert shitcode('\x00' + '\xFF') == '? ?'
    assert shitcode('\x00' + '\xFF' + 'ă') == '? ? ?'



# Generated at 2022-06-20 12:41:54.806920
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class MyClass(object):
        def __repr__(self):
            return 'MyClass()'

    my_class = MyClass()

    assert get_shortish_repr(my_class) == 'MyClass()'

    assert get_shortish_repr(my_class, custom_repr=[(MyClass, lambda x: '42')]) == '42'

    assert get_shortish_repr(my_class, custom_repr=[(MyClass, lambda x: '42'),
                                                    (object, lambda x: '43')]) == '42'

    assert get_shortish_repr(my_class, custom_repr=[(object, lambda x: '43'),
                                                    (MyClass, lambda x: '42')]) == '42'


# Generated at 2022-06-20 12:42:01.678059
# Unit test for function truncate
def test_truncate():
    string = '0123456789'

    assert truncate(string, None) == '0123456789'
    assert truncate(string, 0) == '0123456789'
    assert truncate(string, 10) == '0123456789'
    assert truncate(string, 9) == '01234...789'
    assert truncate(string, 8) == '012...789'
    assert truncate(string, 7) == '012345...'
    assert truncate(string, 6) == '0123...'
    assert truncate(string, 5) == '01...'
    assert truncate(string, 4) == '0...'
    assert truncate(string, 3) == '...'
    assert truncate(string, 2) == '..'

# Generated at 2022-06-20 12:42:10.783336
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Printable(WritableStream):
        def write(self, s):
            print(s)

    try:
        class Unprintable(WritableStream):
            pass
    except TypeError:
        pass
    else:
        raise Exception("Shouldn't be able to instantiate abstract class")


PY3 = sys.version_info >= (3, 0)
if not (PY3):
  if hasattr(sys, 'maxunicode') and sys.maxunicode > 65535:
    UNICODE_WIDE = True
  else:
    UNICODE_WIDE = False
else:
    UNICODE_WIDE = True



# Generated at 2022-06-20 12:42:15.077976
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<spam at 0xfedabcd>') == '<spam>'
    assert normalize_repr('<spam at 0xfedabcdef>') == '<spam>'
    assert normalize_repr('<spam at 0xfedabcd, with eggs at 0xefef>') == \
                                                       '<spam, with eggs>'



# Generated at 2022-06-20 12:42:25.055632
# Unit test for function get_repr_function
def test_get_repr_function():
    def my_repr(x):
        return '<my repr for %s>' % (x,)
    assert get_repr_function(3, [(int, my_repr)]) == my_repr
    assert get_repr_function(3.0, [(int, my_repr)]) != my_repr
    assert get_repr_function(3, [(lambda x: x == 3.0, my_repr)]) == my_repr
    assert get_repr_function(3.0, [(lambda x: x == 3.0, my_repr)]) == my_repr
    assert get_repr_function('3', [(lambda x: x == '3', my_repr)]) == my_repr

# Generated at 2022-06-20 12:42:29.748770
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('1234567890', 5) == '...890'
    assert truncate('1234567890', 6) == '1...890'
    assert truncate('123', 4) == '123'
    assert truncate('1234567890', 3) == '...'

# Generated at 2022-06-20 12:42:39.960684
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=5) == \
                                                                          'ab...y'
    assert get_shortish_repr('abcde', max_length=5) == 'abcde'
    assert get_shortish_repr('abcdefghijklmnop', max_length=None) == \
                                                            'abcdefghijklmnop'
    class C:
        pass
    custom_repr = get_shortish_repr(C(), max_length=None, normalize=True)
    assert custom_repr == '<__main__.C object at 0x'
    assert get_shortish_repr(C(), max_length=None, normalize=False) != \
                                                                   custom_

# Generated at 2022-06-20 12:42:48.772869
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('123') == '123'
    assert normalize_repr('123 at 0xdd4d4') == '123'
    assert normalize_repr('123 at 0xdd4d4 (myfile.py:123)') == '123'
    assert normalize_repr('123 at 0xdd4d4 (myfile.py:123)') == '123'
    assert normalize_repr('123 at 0xdd4d4 (myfile.py:123) at 0xdd4d4 (myfile.py:123)') == '123'

    assert normalize_repr('123 at 0xdd4d4 (myfile.py:123) at 0xdd4d4') == '123'

# Generated at 2022-06-20 12:42:57.376810
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)

# Generated at 2022-06-20 12:43:07.107449
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('a') == (u'a',)
    assert ensure_tuple(('a',)) == (u'a',)
    assert ensure_tuple([]) == ()
    assert ensure_tuple([u'a']) == (u'a',)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(['a', 'b', 'c']) == (u'a', u'b', u'c')
    assert ensure_tuple(('a', 'b', 'c')) == (u'a', u'b', u'c')
    assert ensure_tuple({'a', 'b', 'c'}) == (u'a', u'b', u'c')

# Generated at 2022-06-20 12:43:09.541047
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class ConcreteWritableStream(WritableStream):
        def write(self, s):
            pass
    ConcreteWritableStream()



# Generated at 2022-06-20 12:43:19.041899
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('a at 0xqwer') == 'a'
    assert normalize_repr('b at 0xZ') == 'b'
    assert normalize_repr('c at 0x') == 'c'
    assert normalize_repr('d at 0x1') == 'd'
    assert normalize_repr('e at 0xasdf') == 'e'
    assert normalize_repr('f at 0xqwerty') == 'f'
    assert normalize_repr('g at 0xasdfqwer') == 'g'
    assert normalize_repr('h at 0xQWE') == 'h'
    assert normalize_repr('i at 0x123456') == 'i'
    assert normalize_repr('j at 0x123ab') == 'j'


# Generated at 2022-06-20 12:43:29.541282
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\x7F') == '?'
    assert shitcode('\x80') == '?'

# Generated at 2022-06-20 12:43:31.851120
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Test(WritableStream):
        def write(self, s):
            pass

    assert issubclass(Test, WritableStream)

# Generated at 2022-06-20 12:43:40.011602
# Unit test for function get_repr_function
def test_get_repr_function():

    class C(object):
        pass

    class D(C):
        pass

    assert get_repr_function(1, ((int, repr),)) == repr
    assert get_repr_function(1, ((str, repr),)) == repr

    assert get_repr_function(1, ((lambda: True, repr),)) == repr
    assert get_repr_function(1, ((lambda: False, repr),)) == repr

    assert get_repr_function(1, ((lambda x: True, repr),)) == repr
    assert get_repr_function(1, ((lambda x: False, repr),)) == repr

    assert get_repr_function(1, ((lambda x, y: True, repr),)) == repr
    assert get_repr_function(1, ((lambda x, y=1: False, repr),))

# Generated at 2022-06-20 12:43:42.989880
# Unit test for function normalize_repr
def test_normalize_repr():

    class foo(object):
        pass

    assert normalize_repr("<instance of foo at 0x7f5f564354b0>") == "<instance of foo>"
    assert normalize_repr("a_string") == "a_string"
    assert normalize_repr("[1, 2, 3]") == "[1, 2, 3]"



# Generated at 2022-06-20 12:43:54.078698
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghij', None) == 'abcdefghij'
    assert truncate('abcdefghij', 10) == 'abcdefghij'
    assert truncate('abcdefghij', 9) == 'abcdefghij'

    assert truncate('abcdefghij', 8) == 'abcdefg...'
    assert truncate('abcdefghij', 7) == 'abcdefg...'
    assert truncate('abcdefghij', 6) == 'abcd...'
    assert truncate('abcdefghij', 5) == 'abc...'
    assert truncate('abcdefghij', 4) == 'ab...'
    assert truncate('abcdefghij', 3) == 'a...'
    assert truncate('abcdefghij', 2) == '...'

# Generated at 2022-06-20 12:44:03.659237
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s = s

    class B(A):
        def __init__(self):
            self.s = ''


    a = A()
    a.write('abc')
    assert a.s == 'abc'
    b = B()
    b.write('def')
    assert b.s == 'def'
    assert issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)
    assert A() is not None
    assert B() is not None
    class C: pass
    assert not issubclass(C, WritableStream)

if __name__ == '__main__':
    test_WritableStream()

# Generated at 2022-06-20 12:44:23.220972
# Unit test for function normalize_repr
def test_normalize_repr():
    class A(object):
        pass
    a = A()

    assert normalize_repr('abc') == 'abc'
    assert normalize_repr(repr(a)) == repr(a)
    assert normalize_repr(repr(a)[:-1]) == repr(a)[:-1]
    assert normalize_repr(repr(a)[:-3]) == repr(a)[:-3]
    assert normalize_repr(repr(a)[:-4]) == repr(a)[:-4]
    print('normalize_repr() passed all tests.')


if __name__ == '__main__':
    test_normalize_repr()

# Generated at 2022-06-20 12:44:32.174615
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567', None) == '1234567'
    assert truncate('123', None) == '123'
    assert truncate('0', None) == '0'
    assert truncate('123456789', 5) == '12...89'
    assert truncate('123', 5) == '123'
    assert truncate('0', 5) == '0'
    assert truncate(u'1234567', None) == u'1234567'
    assert truncate(u'123', None) == u'123'
    assert truncate(u'0', None) == u'0'
    assert truncate(u'123456789', 5) == u'12...89'
    assert truncate(u'123', 5) == u'123'

# Generated at 2022-06-20 12:44:41.551520
# Unit test for function truncate
def test_truncate():

    # Basic use
    assert truncate('1234567890123456789012345678901234567890', 40) == \
                                                           '1234567890123456789012345678901234567890'

    assert truncate('1234567890123456789012345678901234567890', 30) == \
                                                           '123456789012345678901234567...67890'

    assert truncate('1234567890123456789012345678901234567890', 20) == \
                                                           '12345678901234567...4567890'


# Generated at 2022-06-20 12:44:44.173159
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Example(WritableStream):
        def write(self, s): pass
    assert issubclass(Example, WritableStream)
    
    
    

# Generated at 2022-06-20 12:44:48.126373
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Test that `WritableStream.write` always accepts a string (as long as
    # `NotImplemented` is not returned)
    class A(WritableStream):
        def write(self, s):
            assert isinstance(s, string_types)

    a = A()
    a.write('meow')



# Generated at 2022-06-20 12:44:53.744468
# Unit test for function get_repr_function
def test_get_repr_function():
    def x_repr(x):
        return 'x'
    assert get_repr_function(5, custom_repr=[(int, x_repr)]) is repr
    assert get_repr_function(5.5, custom_repr=[(int, x_repr)]) is repr
    assert get_repr_function(5, custom_repr=[(float, x_repr)]) is repr
    assert get_repr_function(5.5, custom_repr=[(float, x_repr)]) is x_repr
    assert get_repr_function('abcde', custom_repr=[(float, x_repr)]) is repr



# Generated at 2022-06-20 12:44:58.001640
# Unit test for function normalize_repr
def test_normalize_repr():
    import datetime
    d = datetime.datetime(1997, 6, 5, 3, 2, 1)
    assert normalize_repr(repr(d)) == "datetime.datetime(1997, 6, 5, 3, 2, 1)"

# Generated at 2022-06-20 12:45:01.332588
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeWritableStream:
        def write(self, s):
            assert isinstance(s, string_types)
            self.string = s

    assert isinstance(FakeWritableStream(), WritableStream)



# Generated at 2022-06-20 12:45:10.897273
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1., []) == repr
    assert get_repr_function(1j, []) == repr

    assert get_repr_function(1, [(int, repr)]) == repr
    assert get_repr_function(1., [(int, repr)]) == repr
    assert get_repr_function(1j, [(int, repr)]) == repr

    assert callable(get_repr_function(1, [(int, int)]))
    assert callable(get_repr_function(1., [(int, int)]))
    assert callable(get_repr_function(1j, [(int, int)]))
    assert get_repr_function(1, [(int, int)])(1) == '1'


# Generated at 2022-06-20 12:45:21.212321
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass
    assert issubclass(WritableStreamSubclass, WritableStream)
    assert not issubclass(WritableStreamSubclass, BytesIO)

    class FailingWritableStreamSubclass1(WritableStream):
        pass
    assert not issubclass(FailingWritableStreamSubclass1, WritableStream)

    class FailingWritableStreamSubclass2(WritableStream):
        def write(self, s):
            pass
        write2 = write
    assert not issubclass(FailingWritableStreamSubclass2, WritableStream)

    assert isinstance(open('/dev/null', 'w'), WritableStream)
    assert not isinstance(open('/dev/null', 'w'), BytesIO)

# Generated at 2022-06-20 12:45:37.221170
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class _(object):
        def __repr__(self):
            return 'mega-mega-mega-mega-mega-mega-mega-mega-mega-mega-mega-mega'
    assert get_shortish_repr(_()) == 'mega-mega-mega-mega-mega-mega-mega-' \
                                     'mega-mega-mega-mega-mega...mega'
    assert get_shortish_repr(object) == '<type object>'
    assert get_shortish_repr(object(), custom_repr=((object, str),)) == \
                                                                       'object'



# Generated at 2022-06-20 12:45:38.979460
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class TestWritableStream(WritableStream):
        def write(self, s):
            pass
    TestWritableStream()



# Generated at 2022-06-20 12:45:46.758902
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abcd') == 'abcd'
    assert shitcode('אבגד') == '????'
    assert shitcode('ab\xc3\xa5cd') == 'ab?cd'


if sys.version_info > (3, 0):
    import builtins
    exec_ = getattr(builtins, 'exec')

    def exec_with_globals(code, global_vars):
        exec_(code, global_vars)

else:

    def exec_with_globals(code, global_vars):
        exec('exec code in global_vars')

# Generated at 2022-06-20 12:45:55.395080
# Unit test for function truncate
def test_truncate():
    assert truncate('abcde', max_length=None) == 'abcde'
    assert truncate('abcde', max_length=5) == 'abcde'
    assert truncate('abcde', max_length=4) == 'abcd'
    assert truncate('abcde', max_length=3) == 'abc'
    assert truncate('abcde', max_length=2) == 'ab'
    assert truncate('abcde', max_length=1) == 'a'
    assert truncate('abcde', max_length=0) == ''

    assert truncate('abcdef', max_length=5) == 'ab...f'
    assert truncate('abcdef', max_length=4) == 'ab..f'
    assert truncate('abcdef', max_length=3) == 'a...f'

# Generated at 2022-06-20 12:46:05.770694
# Unit test for function normalize_repr
def test_normalize_repr():
    """Test `normalize_repr`."""
    assert normalize_repr('<Test at 0x7f4f1b9328c0>') == '<Test>'
    assert normalize_repr('<Test at 0x0123456789>') == '<Test>'
    assert normalize_repr('<Test at 0x00000000>') == '<Test>'
    assert normalize_repr('<Test at 0x00000000>') == '<Test>'
    assert normalize_repr(123) == '123'
    assert normalize_repr('<Test at 0x0123456789') == '<Test at 0x0123456789'
    assert normalize_repr('<Test at 0x0123456789') == '<Test at 0x0123456789'


# Generated at 2022-06-20 12:46:12.885675
# Unit test for function shitcode
def test_shitcode():
    unicode_super_a = chr(0x1d49c)  # A SUPER-LATIN LETTER
    assert shitcode(
        'abcd'
    ) == 'abcd'

    assert shitcode(
        b'\x80\x7f'
    ) == '??'

    assert shitcode(
        b'\x80\x7f'
    ) == '??'

    assert shitcode(
        b'\x80\x7f'
    ) == '??'

    assert shitcode(
        'asdf\x80\x7fasd'
    ) == 'asdf??asd'

    assert shitcode(
        'asdf\x80\x7fasd'
    ) == 'asdf??asd'


# Generated at 2022-06-20 12:46:24.015408
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(4) == '4'
    assert get_shortish_repr(4, max_length=2) == '4'
    assert get_shortish_repr(4, max_length=1) == '4'
    assert get_shortish_repr(4, max_length=0) == '...'
    assert get_shortish_repr("bla") == "'bla'"
    assert get_shortish_repr("bla", max_length=None) == "'bla'"
    assert get_shortish_repr("bla", max_length=4) == "'bla'"
    assert get_shortish_repr("bla", max_length=3) == "'b...'"
    assert get_shortish_repr("bla", max_length=2)

# Generated at 2022-06-20 12:46:31.093434
# Unit test for constructor of class WritableStream
def test_WritableStream():
    is_writable_stream = WritableStream.__subclasshook__


    class GoodWritableStream:
        def write(self, _):
            pass

    assert is_writable_stream(GoodWritableStream)

    class BadWritableStream1:

        def notwrite(self, _):
            pass

    assert is_writable_stream(BadWritableStream1) is NotImplemented

    class BadWritableStream2:
        pass

    assert is_writable_stream(BadWritableStream2) is NotImplemented

# Generated at 2022-06-20 12:46:33.600127
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo:
        def write(self, s):
            pass
    assert issubclass(Foo, WritableStream)

    class Bar:
        pass
    assert not issubclass(Bar, WritableStream)

# Generated at 2022-06-20 12:46:40.274760
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None) is repr
    assert get_repr_function(1) is repr
    assert get_repr_function(True) is repr
    assert get_repr_function(1.0) is repr
    assert get_repr_function((1, 2, 3)) is repr
    assert get_repr_function('spam') is repr
    assert get_repr_function([1, 2, 3]) is repr
    assert get_repr_function(set((1, 2, 3))) is repr
    assert get_repr_function({1, 2, 3}) is repr
    assert get_repr_function(dict(((1, 2), (3, 4)))) is repr

    s = get_repr_function(None, custom_repr=((str, str),))

# Generated at 2022-06-20 12:46:55.030990
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from pickle import Pickler
    assert isinstance(Pickler, type)
    assert issubclass(Pickler, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(MyWritableStream(), WritableStream)

# Generated at 2022-06-20 12:47:00.920949
# Unit test for function normalize_repr
def test_normalize_repr():
    class Foo:
        pass
    foo = Foo()
    assert normalize_repr(repr(foo)) == repr(foo)
    class Bar:
        def __init__(self, x):
            self.x = x

        def __repr__(self):
            return 'Bar({}) at 0x1234'.format(self.x)

    assert normalize_repr(repr(Bar(3))) == 'Bar(3)'

# Generated at 2022-06-20 12:47:11.324056
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    max_length = 30
    assert get_shortish_repr(
        'A' * max_length,
        max_length=max_length
    ) == 'A' * max_length
    assert get_shortish_repr(
        'A' * (max_length + 1),
        max_length=max_length
    ) == 'A' * (max_length - 3) + '...'
    assert get_shortish_repr(
        'A' * (max_length + 1),
        max_length=max_length
    ) == 'A' * (max_length - 3) + '...'

# Generated at 2022-06-20 12:47:17.691941
# Unit test for function truncate
def test_truncate():
    assert truncate('', 5) == ''
    assert truncate('abcde', 5) == 'abcde'
    assert truncate('abcdef', 5) == 'ab...f'
    assert truncate('abcdef', 6) == 'abcdef'
    assert truncate('abcdef', 10) == 'abcdef'
    assert truncate('abcdef', None) == 'abcdef'
    assert truncate('abcdef', 0) == '...'
    assert truncate('abcdef', -1) == '...'



# Generated at 2022-06-20 12:47:22.260520
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A:
        def write(self, s):
            pass

    assert isinstance(A(), WritableStream)
    assert isinstance(sys.stdout, WritableStream)

    class B:
        pass

    assert not isinstance(B(), WritableStream)
    assert not isinstance(B, WritableStream)

    class C:
        def write(self, s):
            pass

        @classmethod
        def __subclasshook__(cls, C):
            return False

    assert not isinstance(A(), WritableStream)

    class D:
        def write(self, s):
            pass

    assert isinstance(D(), WritableStream)

    class E:
        def write(self, s):
            return None

    assert not isinstance(E(), WritableStream)

# Generated at 2022-06-20 12:47:33.451682
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=-1) == '1'

    assert get_shortish_repr(123456, max_length=3) == '12...'
    assert get_shortish_repr(123456, max_length=2) == '12...'
    assert get_shortish_repr(123456, max_length=1) == '12...'
    assert get_shortish_repr

# Generated at 2022-06-20 12:47:35.771035
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hello', ((re.compile(r'^.*o$'), lambda s: '!'))) \
                                                                           == '!'



# Generated at 2022-06-20 12:47:42.523113
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple(x for x in range(10)) == tuple(range(10))
    assert ensure_tuple([y for y in range(10) if y % 2]) == tuple(range(1, 10, 2))



# Generated at 2022-06-20 12:47:48.089223
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'משהו בעברית') == u'??? ??? ????'
    assert shitcode(u'\u2605') == u'?'
    assert shitcode(u'\u2605') == u'?'
    assert shitcode(u'\u2605') == u'?'
    assert shitcode(u'\u2605') == u'?'

# Generated at 2022-06-20 12:47:57.092803
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X:
        def __init__(self, v):
            self.v = v
        def write(self, s):
            pass
    x = X(2)
    assert issubclass(X, WritableStream)
    assert isinstance(x, WritableStream)


PY3 = sys.version_info[0] > 2


if PY3:
    # Python 3

    def unicode_input(prompt, **kwargs):
        import builtins
        return builtins.input(prompt, **kwargs)


else:

    # Python 2

    import codecs
    import locale
    import sys


    def unicode_input(prompt, **kwargs):
        import builtins
        # For Python 2, convert `raw_input()` to be `input()`