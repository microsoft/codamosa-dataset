

# Generated at 2022-06-20 12:38:14.858882
# Unit test for function normalize_repr
def test_normalize_repr():
    """Test if normalize_repr is working."""

    # This can be avoided for not used platforms, but we don't want to
    # make assumptions about the future.
    platforms = ('linux', 'darwin', 'win32')
    assert sys.platform in platforms

    items = [
        object(),
        [],
        '',
        (1, 2, 3),
        1,
        2.0,
    ]

    for x in items:
        x_repr = repr(x)
        x_repr = normalize_repr(x_repr)
        assert '0x' not in x_repr

# Generated at 2022-06-20 12:38:23.116939
# Unit test for function get_shortish_repr
def test_get_shortish_repr():


    class SpecialRepr(object):
        def __repr__(self):
            return 'foo\nbar'

    assert get_shortish_repr(SpecialRepr()) == 'foo bar'

    assert get_shortish_repr(SpecialRepr(), max_length=5) == 'foo ba'

    assert get_shortish_repr(SpecialRepr(), max_length=4) == 'foo...'

    assert get_shortish_repr(SpecialRepr(), max_length=8) == 'foo ba'

    assert get_shortish_repr(SpecialRepr(), max_length=7) == 'foo...'

    assert get_shortish_repr(SpecialRepr(), max_length=3) == 'REPR FAILED'


# Generated at 2022-06-20 12:38:24.666924
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Thing(WritableStream):
        def write(self):
            pass
    assert issubclass(Thing, WritableStream)



# Generated at 2022-06-20 12:38:28.077227
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\xab\xcd') == '??'
    assert shitcode(u'\u1234') == '?'
    assert shitcode('ab') == 'ab'



# Generated at 2022-06-20 12:38:38.194086
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, normalize=True) == '1'
    assert get_shortish_repr(1, normalize=True, max_length=3) == '1'
    assert get_shortish_repr(1, normalize=True, max_length=2) == '1'
    assert get_shortish_repr(1, normalize=True, max_length=1) == '1'
    assert get_shortish_repr(1, normalize=True, max_length=0) == '1'

    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'

# Generated at 2022-06-20 12:38:42.605164
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class Foo(WritableStream):
        written_string = ''
        def write(self, s):
            self.written_string += s
    
    foo = Foo()

    assert foo.written_string == ''

    foo.write('hello!')

    assert foo.written_string == 'hello!'

    foo.write(u'这是中文')

    assert foo.written_string == 'hello!这是中文'



# Generated at 2022-06-20 12:38:48.908252
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from io import StringIO
    from .pycompat import ABC

    assert issubclass(StringIO, WritableStream)
    assert not issubclass(int, WritableStream)
    assert not issubclass(ABC, WritableStream)
    class Foo(object):
        def write(self, x): pass
    assert issubclass(Foo, WritableStream)
    class Bar(object):
        write = None
    assert issubclass(Bar, WritableStream)



# Generated at 2022-06-20 12:38:57.091462
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello world', 5) == 'hel...'
    assert truncate('hello\rworld', 5) == 'hel...'
    assert truncate('hello\tworld', 5) == 'hel...'
    assert truncate('hello\nworld', 5) == 'hel...'
    assert truncate('hello\xabworld', 5) == 'hel...'
    assert truncate('hello\x1fworld', 5) == 'hel...'
    assert truncate('hello\x1Ahello world\n', 5) == 'hel...'
    assert truncate('hello\x0Ahello world\x0A', 5) == 'hel...'
    # (This illustrates an issue with \x0A and \n when truncating.)



# Generated at 2022-06-20 12:39:07.255309
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr(42) == '42'
    assert get_shortish_repr(3.14, max_length=5) == '3.14'
    assert get_shortish_repr(3.14, max_length=3) == '3.1'
    assert get_shortish_repr(3.14, max_length=None) == '3.14'
    assert get_shortish_repr(3.14, max_length=4) == '3.1'
    assert get_shortish_repr(3.14, max_length=7) == '3.14'
    assert get_shortish_repr(3.14, max_length=6) == '3.14'

# Generated at 2022-06-20 12:39:13.680398
# Unit test for function get_repr_function
def test_get_repr_function():

    assert get_repr_function(None, [(lambda x: True, lambda x: 'hi')])() == 'hi'
    assert get_repr_function(None, [(bool, lambda x: 'hi')])() == 'hi'
    assert get_repr_function(None, [(bool, lambda x: 'hi')]) is False
    assert get_repr_function(None, [(lambda x: x == False, lambda x: 'hi')]) is \
                                                                          False
    assert get_repr_function(None, [(lambda x: x is False, lambda x: 'hi')]) is \
                                                                          False
    assert get_repr_function(False, [(bool, lambda x: 'hi')]) is False

# Generated at 2022-06-20 12:39:25.219971
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefgh', 3) == '...'
    assert truncate('abcdefgh', 4) == 'a...'
    assert truncate('abcdefgh', 5) == 'a...h'
    assert truncate('abcdefgh', 6) == 'a...gh'
    assert truncate('abcdefgh', 7) == 'ab...gh'
    assert truncate('abcdefgh', 8) == 'abcdefgh'
    assert truncate('abcdefgh', 9) == 'abcdefgh'
    assert truncate('abcdefgh', None) == 'abcdefgh'



# Generated at 2022-06-20 12:39:27.147639
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import sys
    assert isinstance(sys.stdout, WritableStream)
    assert not isinstance(sys.stdin, WritableStream)

# Generated at 2022-06-20 12:39:33.704950
# Unit test for function ensure_tuple
def test_ensure_tuple():
    l = [1, 2, 3]
    assert ensure_tuple(l) is not l
    assert ensure_tuple(l) == (1, 2, 3)

    t = (1, 2, 3)
    assert ensure_tuple(t) is t
    assert ensure_tuple(t) == (1, 2, 3)

    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(10) == (10,)
    assert ensure_tuple('meow') == ('meow',)

# Generated at 2022-06-20 12:39:36.426277
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple([]) == ()



# Generated at 2022-06-20 12:39:39.444761
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(()) == ()
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple([5, 6]) == (5, 6)

# Generated at 2022-06-20 12:39:47.134445
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hi') == 'hi'
    assert normalize_repr('hi at 0x123456') == 'hi'
    assert normalize_repr('hi at 0x12345678') == 'hi'
    assert normalize_repr('hi at 0x1234567890') == 'hi'
    assert normalize_repr('hi at 0x123456789ABCDEF') == 'hi'




py3 = sys.version_info.major == 3
if py3:
    def iter_items(d):
        return iter(d.items())
else:
    def iter_items(d):
        return iter(d.iteritems())

# Generated at 2022-06-20 12:39:56.046632
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(123) == '123'
    assert get_shortish_repr('hi') == "'hi'"
    assert get_shortish_repr('hi', max_length=3) == "'hi'"
    assert get_shortish_repr('hi', max_length=2) == "'...'"
    assert get_shortish_repr(b'hi') == "b'hi'"
    assert get_shortish_repr(b'hi', max_length=3) == "b'hi'"
    assert get_shortish_repr(b'hi', max_length=2) == "b'...'"
    assert get_shortish_repr(u'hi') == "'hi'"
    assert get_shortish_repr(u'hi', max_length=3) == "'hi'"


# Generated at 2022-06-20 12:40:07.725749
# Unit test for function truncate
def test_truncate():
    assert truncate('', 0) == ''
    assert truncate('', 5) == ''
    assert truncate('01234', 5) == '01234'
    assert truncate('012345', 5) == '01...5'
    assert truncate('012345', 1) == '.'
    assert truncate('012345', 3) == '...'
    assert truncate('012345', 4) == '.3..'
    assert truncate('012345', 2) == '.4'
    assert truncate('012345', 6) == '012345'
    assert truncate('01234', 2) == '..4'
    assert truncate('0123456', 6) == '01..56'
    assert truncate('01234567', 6) == '0...67'

# Generated at 2022-06-20 12:40:17.595315
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (type(None), lambda x: 'None'),
        (type(1), lambda x: str(x)),
        (lambda x: isinstance(x, int), lambda x: str(x)),
        (type(True), lambda x: str(x)),
        (lambda x: x == 'abc', lambda x: str(x)),
        (lambda x: x == 4, lambda x: str(x)),
    )
    assert get_repr_function(None, custom_repr)() == 'None'
    assert get_repr_function(1, custom_repr)() == '1'
    assert get_repr_function(True, custom_repr)() == 'True'
    assert get_repr_function('abc', custom_repr)() == "'abc'"
    assert get_

# Generated at 2022-06-20 12:40:27.460769
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(2) == (2,)
    assert ensure_tuple('hi') == ('hi',)


if sys.version_info.major == 3:
    class Stream(WritableStream):
        def write(self, s):
            raise NotImplementedError

        def flush(self):
            pass
else:
    from StringIO import StringIO as Stream



# Generated at 2022-06-20 12:40:35.939006
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class F(object):
        def __init__(self):
            self.__s = ''
        def write(self, s):
            self.__s += s

    f = F()
    f.write('x')
    assert f._F__s == 'x'



# Generated at 2022-06-20 12:40:41.770941
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)

    assert ensure_tuple(1) == (1,)

    assert ensure_tuple(None) == (None,)

    assert ensure_tuple(range(5)) == (0, 1, 2, 3, 4)

    assert ensure_tuple('hello') == ('hello',)


if __name__ == '__main__':
    test_ensure_tuple()



# Generated at 2022-06-20 12:40:44.812558
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def __init__(self):
            self.text = ''

        def write(self, text):
            self.text += text

    stream = MyStream()
    stream.write('hello')
    stream.write(' world')
    assert stream.text == 'hello world'

# Generated at 2022-06-20 12:40:47.243598
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('Hello world!') == 'Hello world!'
    assert get_shortish_repr(lambda x: x) == '<function <lambda>>'

# Generated at 2022-06-20 12:40:49.192956
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('αβγ') == 'αβγ'
    assert shitcode('\xab\xcd') == '??'



# Generated at 2022-06-20 12:40:53.549850
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', None) == '123456789'
    assert truncate('123456789', 3) == '123'
    assert truncate('123456789', 8) == '1234567'
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 10) == '123456789'




# Generated at 2022-06-20 12:41:00.514792
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C: pass
    custom_repr = ((A, lambda x: 'A'), (B, 'B'), (lambda x: True, 'LAMBDA'))
    assert get_repr_function(A(), custom_repr)() == 'A'
    assert get_repr_function(B(), custom_repr)() == 'B'
    assert get_repr_function(C(), custom_repr)() == 'LAMBDA'
    assert get_repr_function(C(), ())() == 'C'

# Generated at 2022-06-20 12:41:06.680705
# Unit test for function get_repr_function
def test_get_repr_function():

    class TestClass(object):
        pass

    class TestClass2(object):
        pass

    class TestClass3(object):
        pass


# Generated at 2022-06-20 12:41:13.402189
# Unit test for function truncate
def test_truncate():
    assert truncate('a', None) == 'a'
    assert truncate('a', 1) == 'a'
    assert truncate('ab', 1) == 'a...'
    assert truncate('ab', 2) == 'a...'
    assert truncate('ab', 3) == 'a...'
    assert truncate('abc', 3) == 'a...'
    assert truncate('abc', 4) == 'ab...'
    assert truncate('abc', 5) == 'abc'
    assert truncate('abc', 6) == 'abc'



# Generated at 2022-06-20 12:41:19.682068
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Dummy(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s
    x = Dummy()
    x.write('hello, ')
    x.write('world!\n')
    assert x.s == 'hello, world!\n'
    print(x)

# Generated at 2022-06-20 12:41:31.962168
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .test_tools import assert_equal
    assert_equal(get_shortish_repr(1), '1')
    assert_equal(get_shortish_repr(1, max_length=1), '1')
    assert_equal(get_shortish_repr(1, max_length=2), '1')
    assert_equal(get_shortish_repr(1, max_length=3), '1')
    assert_equal(get_shortish_repr(1, max_length=4), '1')

# Generated at 2022-06-20 12:41:38.376043
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(set([1, 2, 3])) == (1, 2, 3)
    assert ensure_tuple(tuple([1, 2, 3])) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(1) == (1,)




# Generated at 2022-06-20 12:41:46.624722
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(42) == (42,)
    assert ensure_tuple({4, 2}) == (4, 2)
    assert ensure_tuple([4, 2]) == (4, 2)
    assert ensure_tuple((4, 2)) == (4, 2)
    assert ensure_tuple('yo!') == ('yo!',)
    assert ensure_tuple(None) == (None,)

    a = ensure_tuple([1, 2])
    assert a == (1, 2)
    assert isinstance(a, tuple)

    a = ensure_tuple([1, [2]])
    assert a == (1, [2]) # This is different than `tuple(a)`, which is (1, 2)




# Generated at 2022-06-20 12:41:48.972180
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .console import Console
    from .terminal import Terminal
    assert isinstance(Console(), WritableStream)
    assert isinstance(Terminal(), WritableStream)

# Generated at 2022-06-20 12:41:58.363570
# Unit test for function shitcode
def test_shitcode():
    """Test whether `shitcode` works correctly."""
    assert shitcode(chr(0)) == '?'
    assert shitcode(chr(127)) == '?'
    assert shitcode(chr(128)) == '?'
    assert shitcode(chr(255)) == '?'
    assert shitcode(chr(1)) == chr(1)
    assert shitcode(chr(126)) == chr(126)
    assert shitcode(chr(256)) == '?'
    assert shitcode('abcd') == 'abcd'
    assert shitcode('\x00') == '?'
    assert shitcode(u'\x00') == '?'
    assert shitcode('\u042a') == '?'
    assert shitcode('\u042a'.encode('utf-8')) == '?'

# Generated at 2022-06-20 12:42:01.922117
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(1) == (1, )



# Generated at 2022-06-20 12:42:09.491572
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .testing_tools import make_cute_repr_function
    cute_repr = make_cute_repr_function(max_length=8)
    class MockWritableStream(WritableStream):
        def __init__(self):
            self.output = ''

        def write(self, s):
            self.output += s
    mock_writable_stream = MockWritableStream()
    mock_writable_stream.write('bla')
    assert mock_writable_stream.output == 'bla'

# Generated at 2022-06-20 12:42:14.402105
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("<module 'NoneType' (built-in)>") == \
        "<module 'NoneType' (built-in)>"
    assert normalize_repr("<abc.abc.ABCMeta object at 0x7f437e0ea510>") == \
        "<abc.abc.ABCMeta object>"
    assert normalize_repr("<module 'NoneType'>") == "<module 'NoneType'>"



# Generated at 2022-06-20 12:42:24.673973
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class MyClass(object):
        def __repr__(self):
            return '<{}>'.format(self.__class__.__name__)


    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr(5.5) == '5.5'
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(MyClass()) == '<MyClass>'
    assert get_shortish_repr('a') == "'a'"
    assert get_shortish_repr('a' * 100) == "'a' * 100"
    assert get_shortish_repr('a', max_length=1) == "'a'"

# Generated at 2022-06-20 12:42:30.464010
# Unit test for constructor of class WritableStream
def test_WritableStream():

    import io
    x = io.BytesIO()
    assert isinstance(x, WritableStream)
    assert isinstance(x, io.IOBase)
    assert isinstance(x, (io.TextIOBase, io.IOBase))
    assert issubclass(io.TextIOBase, WritableStream)

    class C:
        def write(self, s):
            pass

    assert not isinstance(C(), WritableStream)
    assert not issubclass(C, WritableStream)

# Generated at 2022-06-20 12:42:44.802382
# Unit test for function truncate
def test_truncate():
    assert truncate('', max_length=4) == ''
    assert truncate('a', max_length=4) == 'a'
    assert truncate('ab', max_length=4) == 'ab'
    assert truncate('abc', max_length=4) == 'abc'
    assert truncate('abcd', max_length=4) == 'abcd'
    assert truncate('abcde', max_length=4) == 'a...e'
    assert truncate('abcdef', max_length=4) == 'a...f'
    assert truncate('abcdef', max_length=None) == 'abcdef'




# Generated at 2022-06-20 12:42:50.697330
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_text = ''
            self.is_closed = False
        def write(self, text):
            self.written_text += text
        def close(self):
            self.is_closed = True

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.written_text == 'hello'
    assert not my_writable_stream.is_closed
    my_writable_stream.close()
    assert my_writable_stream.is_closed



# Unit testing for truncate:


# Generated at 2022-06-20 12:43:01.301312
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('') == ''
    assert normalize_repr('blah blah') == 'blah blah'
    assert normalize_repr('blah blah at 0x12345678') == 'blah blah'
    assert normalize_repr('blah blah at 0x12345678blah blah') == 'blah blah at 0x12345678blah blah'
    assert normalize_repr('blah blah at 0x12345678 blah blah') == 'blah blah at 0x12345678 blah blah'
    assert normalize_repr('blah blah at 0x12345678 blah blah at 0x12345678901234') == 'blah blah at 0x12345678 blah blah at 0x12345678901234'



# Generated at 2022-06-20 12:43:07.261872
# Unit test for function normalize_repr
def test_normalize_repr():
    from .test_tools import assert_equal
    assert_equal(normalize_repr("hey"), "hey")
    assert_equal(normalize_repr("hey at 0x0123"), "hey")
    assert_equal(normalize_repr("hey at 0x012345678"), "hey")
    assert_equal(normalize_repr("hey "), "hey ")
    assert_equal(normalize_repr("hey at 0x0123 hey"), "hey hey")



# Generated at 2022-06-20 12:43:12.152241
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MockStream(object):
        def write(self, s):
            assert isinstance(s, str)
            self.s = s

    MockStream.__bases__ = (WritableStream,)
    stream = MockStream()
    stream.write('meow')
    assert stream.s == 'meow'


# Generated at 2022-06-20 12:43:20.651088
# Unit test for function get_repr_function
def test_get_repr_function():

    class A(object): pass
    class B(A): pass
    class C(object): pass

    def a_action(x): return 'a_action({})'.format(x)
    def b_action(x): return 'b_action({})'.format(x)
    def c_action(x): return 'c_action({})'.format(x)
    def default_action(x): return 'default_action({})'.format(x)

    custom_repr = (
        (A, a_action),
        (B, b_action),
        (C, c_action),
    )

    a = A()
    b = B()
    c = C()
    d = object()

    assert get_repr_function(a, custom_repr) == a_action
    assert get_repr_function

# Generated at 2022-06-20 12:43:22.831904
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Stream(WritableStream):
        def write(self, s):
            pass
    Stream()



# Generated at 2022-06-20 12:43:33.735968
# Unit test for function normalize_repr
def test_normalize_repr():
    from itertools import starmap
    from .assertion_utils import assert_equal
    import collections


# Generated at 2022-06-20 12:43:37.162334
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    x = get_shortish_repr


# Generated at 2022-06-20 12:43:44.868868
# Unit test for function get_repr_function
def test_get_repr_function():
    def r(x):
        return 'r'

    def rr(x):
        return 'rr'

    assert r'r' == get_repr_function(1, ((int, r),))(1)
    assert r'r' == get_repr_function(1, ((int, r), (float, rr)))(1)
    assert r'rr' == get_repr_function(1.0, ((int, r), (float, rr)))(1.0)
    assert r'<function r>' == get_repr_function(1, ((int, r), (float, rr)))(2)

# Generated at 2022-06-20 12:43:56.972441
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyClass(WritableStream):
        def write(self, s):
            pass



# Generated at 2022-06-20 12:43:58.191626
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout.__class__, WritableStream)

# Generated at 2022-06-20 12:44:06.171224
# Unit test for function get_repr_function
def test_get_repr_function():
    def custom_repr_f(x):
        if x is 1:
            return '1'
        if isinstance(x, int):
            return 'i'
        if isinstance(x, str):
            return 'str'
        return 'default'

    assert get_repr_function(1, ((int, custom_repr_f),))(1) == '1'
    assert get_repr_function(2, ((int, custom_repr_f),))(2) == 'i'
    assert get_repr_function('a', ((int, custom_repr_f),))('a') == 'str'
    assert get_repr_function((1,), ((int, custom_repr_f),))((1,)) == 'default'



# Generated at 2022-06-20 12:44:11.666533
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyWritableStream(WritableStream):
        def __init__(self):
            self._data = []

        def write(self, s):
            self._data.append(s)

    stream = DummyWritableStream()

    stream.write('hi')
    assert stream._data == ['hi']

    stream.write('there')
    assert stream._data == ['hi', 'there']

# Generated at 2022-06-20 12:44:19.092448
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple([x for x in range(1000)]) == tuple(range(1000))
    assert ensure_tuple(b'abc') == (b'abc',)

# Generated at 2022-06-20 12:44:21.575244
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = ((lambda x: True, lambda x: 'Test'),)
    assert get_repr_function([], custom_repr)([]) == 'Test'



# Generated at 2022-06-20 12:44:29.606346
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class T(WritableStream):
        def write(self, s):
            pass

    assert issubclass(T, WritableStream)

    # Make sure __subclasshook__ is being called and not __mro__:
    class T(WritableStream):
        def w(self, s):
            pass

    assert not issubclass(T, WritableStream)

    class T(WritableStream):
        def write(self, s):
            pass

        def w(self, s):
            pass

    assert issubclass(T, WritableStream)

    # Make sure __subclasshook__ is being called and not __mro__:
    class T(WritableStream):
        def write(self, s):
            pass

    try:
        T.write(None, 'foo')
    except TypeError:
        pass

# Generated at 2022-06-20 12:44:34.004425
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X:
        def write(self, s): pass

    class Y: pass

    assert issubclass(X, WritableStream)
    assert not issubclass(Y, WritableStream)
    assert issubclass(sys.stdout.__class__, WritableStream)
    assert WritableStream.register(sys.stdout.__class__)

# Generated at 2022-06-20 12:44:40.847607
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', 4) == 'abc'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 2) == 'ab'
    assert truncate('abc', 1) == 'a'
    assert truncate('abc', 0) == ''
    assert truncate('abcde', 4) == 'a...e'
    assert truncate('abcde', 5) == 'a...e'
    assert truncate('abcde', 6) == 'abcde'
    assert truncate('abcdef', 6) == 'a...f'



# Generated at 2022-06-20 12:44:42.784253
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestClass(WritableStream):
        def write(self, s):
            pass

    assert issubclass(TestClass, WritableStream)

# Generated at 2022-06-20 12:45:05.495228
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('あ') == '?'
    assert shitcode('aあ') == 'a?'



# Generated at 2022-06-20 12:45:11.818359
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    a = A()
    assert isinstance(a, WritableStream)
    assert WritableStream.__subclasshook__(A) is True
    class B(object):
        def write(self, s):
            pass
    b = B()
    assert WritableStream.__subclasshook__(B) is True
    class C(WritableStream):
        pass
    assert WritableStream.__subclasshook__(C) is NotImplemented





# Generated at 2022-06-20 12:45:13.368994
# Unit test for function normalize_repr
def test_normalize_repr():
    class Foo(object):
        pass
    foo = Foo()
    assert normalize_repr(repr(foo)) == repr(foo)

# Generated at 2022-06-20 12:45:16.774307
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(xrange(3)) == (0, 1, 2)

# Generated at 2022-06-20 12:45:25.541681
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567', 0) == '1234567'
    assert truncate('1234567', None) == '1234567'
    assert truncate('123', 7) == '123'
    assert truncate('123', 6) == '123'
    assert truncate('123', 5) == '123'
    assert truncate('123', 4) == '123'
    assert truncate('123', 3) == '123'
    assert truncate('123', 2) == '12...'
    assert truncate('123', 1) == '...'
    assert truncate('123', 0) == '...'

# Generated at 2022-06-20 12:45:31.599782
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Dummy(object):
        pass
    
    class Dummy2(Dummy):
        def write(self, s):
            pass
    
    class Dummy3(Dummy):
        def write(self, s):
            return NotImplemented
    
    class Dummy4(Dummy2):
        def write(self, s):
            return NotImplemented
    
    assert issubclass(Dummy2, WritableStream)
    assert not issubclass(Dummy3, WritableStream)
    assert not issubclass(Dummy4, WritableStream)

# Generated at 2022-06-20 12:45:38.205236
# Unit test for function get_repr_function
def test_get_repr_function():

    class C(object):
        pass
    class D(C):
        pass
    class E(C):
        pass

    def f_c(x): return 'WOW'
    def f_d(x): return 'WEEEE'

    def f(x): return ':)'

    custom_repr = (
        (C, f_c),
        (D, f_d),
        (f, f),
    )

    assert get_repr_function(C(), custom_repr) is f_c
    assert get_repr_function(D(), custom_repr) is f_d
    assert get_repr_function(E(), custom_repr) is f_c
    assert get_repr_function(str, custom_repr) is f




# Generated at 2022-06-20 12:45:44.480017
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'אבג') == '???'
    assert shitcode(u'אבג\nדהו') == '???\x00\x00\x00???\x00'
    assert shitcode(u'אבג\rדהו') == '???\x00\x00\x00???\x00'
    assert shitcode(u'ab©') == 'ab?'

# Generated at 2022-06-20 12:45:50.918604
# Unit test for function shitcode
def test_shitcode():
    for s in (
        'abcde',
        '\x81\x82\x83\x84\x85',
        '\xff\xff' + 'a' * 10 + '\xff\xff',
        'a\x81b\x82c\x83d\x84e\x85',
        '\x00' + 'a' * 10 + '\x00',
    ):
        assert shitcode(s) == s.encode('ascii', 'replace').decode('ascii')



# Generated at 2022-06-20 12:45:55.672229
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('foo at 0x12345678') == 'foo'
    assert normalize_repr('foo at 0x123456789') == 'foo'
    assert normalize_repr('foo at 0x12345678abcd') == 'foo'
    assert normalize_repr('foo at 12345678') == 'foo at 12345678'
    assert normalize_repr('foo at 12345678abcd') == 'foo at 12345678abcd'



# Generated at 2022-06-20 12:46:47.753289
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', None) == 'abc'
    assert truncate('abc', 2) == 'a...'
    assert truncate('abc', 5) == 'abc'
    assert truncate('abc', 6) == 'abc'
    assert truncate('abcdef', 6) == 'abc...'
    assert truncate('abcdef', 7) == 'abcdef'
    assert truncate('abcdef', 8) == 'abcdef'
    assert truncate('abcdef', 9) == 'abc...f'
    assert truncate('abcdef', 11) == 'abc...def'
    assert truncate('abcdef', 13) == 'abc...def'
    assert truncate('abcdef', 14) == 'ab...def'
    assert truncate('abcdef', 15) == 'abcdef'
    assert truncate('abcdef', 16)

# Generated at 2022-06-20 12:46:55.433982
# Unit test for function get_repr_function
def test_get_repr_function():

    def _ignore(x): return

    _int_repr = lambda x: 'an int'
    _list_repr = lambda x: 'a list'
    _str_repr = lambda x: 'a str'

    for item in (1, 'hi', [], {}, object()):
        assert normalize_repr(get_shortish_repr(item)) == repr(item)

    for item in (1, 'hi', [], {}):
        assert get_shortish_repr(item, ((lambda y: True, _ignore))) == ''

    for item in (1, 'hi', [], {}):
        assert get_shortish_repr(item, ((int, _int_repr),)) == 'an int'

# Generated at 2022-06-20 12:46:57.347860
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamTester(WritableStream):
        def write(self, s):
            pass
    assert WritableStream.__subclasshook__(WritableStreamTester)





# Generated at 2022-06-20 12:47:04.049042
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple((1, [2, 3])) == (1, (2, 3))
    assert ensure_tuple(set([1, 2])) == (1, 2)



# Generated at 2022-06-20 12:47:06.550388
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    MyWritableStream()




# Generated at 2022-06-20 12:47:10.549325
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .simulate import simulate_WritableStream

    class MyOutput(WritableStream):
        def write(self, s):
            self.s = s

    o = MyOutput()

    simulate_WritableStream(o)

    assert o.s == 'a'

# Generated at 2022-06-20 12:47:12.583242
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'אבג') == u'???'



# Generated at 2022-06-20 12:47:17.610002
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamSubclass1(WritableStream):
        def write(self, s):
            pass

    class WritableStreamSubclass2(WritableStream):
        def write(self, s):
            pass

    assert issubclass(WritableStreamSubclass1, WritableStream)
    assert issubclass(WritableStreamSubclass2, WritableStream)



# Generated at 2022-06-20 12:47:27.616681
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('abc at 0xabc') == 'abc'
    assert normalize_repr('abc at 0xabcdefg') == 'abc'
    assert normalize_repr('abc at 0xABC') == 'abc'
    assert normalize_repr('abc at 0xABCDEFG') == 'abc'
    assert normalize_repr('abc at 0xbcde') == 'abc'
    assert normalize_repr('abc at 0xBCDE') == 'abc'
    assert normalize_repr('abc at 0x345678') == 'abc'
    assert normalize_repr('abc at 0xf00') == 'abc'
    assert normalize_repr('abc at 0xABCDEFG') == 'abc'

# Generated at 2022-06-20 12:47:31.275948
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(1) == (1,)