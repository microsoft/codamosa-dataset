

# Generated at 2022-06-20 12:38:15.677676
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('Hello') == 'Hello'
    assert normalize_repr('Hello, world!') == 'Hello, world!'
    assert normalize_repr('a at 0xABCD') == 'a'
    assert normalize_repr('a at 0xABCD at 0x1234') == 'a at 0xABCD'
    assert normalize_repr('a at 0xABCD, world!') == 'a at 0xABCD, world!'
    assert normalize_repr('a at 0xABCD at 0x1234, world!') == 'a at 0xABCD, world!'

# Generated at 2022-06-20 12:38:21.439463
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from . import six
    from .six.moves import StringIO
    from .six.moves import cStringIO
    class FileLike(WritableStream):
        def __init__(self):
            self.data = ''
        def write(self, s):
            self.data += s
    assert issubclass(FileLike, WritableStream)
    assert issubclass(StringIO, WritableStream)
    assert issubclass(cStringIO.OutputType, WritableStream)
    assert not issubclass(six.StringIO, WritableStream)

# Generated at 2022-06-20 12:38:23.678464
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple((5,)) == (5,)
    assert ensure_tuple([5]) == (5,)



# Generated at 2022-06-20 12:38:34.481341
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    r = get_shortish_repr(
        [
            'Whatever',
            (1, 2, 3),
            {'foo': 'bar'},
            set('cat'),
            ['cat', 'dog', 'mouse', 'gopher'],
            {'foo', 'bar', 'baz', 'qux'},
            sys.maxsize,
            (1, {'foo'}, 3),
            {'some', (1, 2, 3), 'set'},
        ]
    )

# Generated at 2022-06-20 12:38:42.301572
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('Hola', custom_repr=[(str, lambda x: x[::-1])]) == 'aloH'
    assert get_shortish_repr('Hola', max_length=3) == 'Hol'
    assert get_shortish_repr('Lo que es una larga', max_length=10) == 'Lo que e...'
    assert get_shortish_repr('Lo que es una larga', max_length=19) == 'Lo que es una larga'
    assert get_shortish_repr('Lo que es una larga', max_length=20) == 'Lo que es una larga'
    assert get_shortish_repr('Lo que es una larga', max_length=21) == 'Lo que es una larga'




# Generated at 2022-06-20 12:38:43.556305
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, custom_repr=((int, str),)) == str



# Generated at 2022-06-20 12:38:48.900240
# Unit test for function truncate
def test_truncate():
    assert truncate('ram', 3) == 'ram'
    assert truncate('ram', 4) == 'ram'
    assert truncate('ram', 5) == 'ram'
    assert truncate('ram', 6) == 'ram'
    assert truncate('ram', 3) == 'ram'
    assert truncate('ram', 7) == 'ram'
    assert truncate('ram', 2) == 'ra...'
    assert truncate('ram', 1) == '...'
    assert truncate('ram', 0) == '...'
    assert truncate('ram', -1) == '...'
    assert truncate('ram', -2) == '...'
    assert truncate('ram', -3) == '...'
    assert truncate('ram', -4) == '...'

# Generated at 2022-06-20 12:38:52.554954
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(WritableStream):
        def __init__(self, output):
            self.output = output
        def write(self, s):
            self.output.append(s)
    x = X([])
    x.write('abc')
    assert x.output == ['abc']

# Generated at 2022-06-20 12:38:57.134370
# Unit test for function normalize_repr
def test_normalize_repr():
    from .testing_tools import assert_equal
    assert_equal(normalize_repr('snabla at 0x123456'), 'snabla')
    assert_equal(normalize_repr('snabla at 0x123456789ab'), 'snabla')
    assert_equal(normalize_repr('snabla'), 'snabla')

# Generated at 2022-06-20 12:39:05.960575
# Unit test for function get_repr_function
def test_get_repr_function():
    # Test getting the right repr function
    custom_repr = (
        (1.234, lambda x: 'one and a quarter'),
        (None, lambda x: 'nothing'),
        (lambda x: (isinstance(x, type('')) and len(x) < 5),
                                                        lambda x: 'string')
    )

    assert get_repr_function(1.234, custom_repr)(1.234) == 'one and a quarter'
    assert get_repr_function('abc', custom_repr)('abc') == 'string'
    assert get_repr_function([], custom_repr)([]) == repr([])



# Generated at 2022-06-20 12:39:11.648209
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert ensure_tuple({'a': 'b'}) == ({'a': 'b'},)



# Generated at 2022-06-20 12:39:22.290412
# Unit test for function shitcode
def test_shitcode():
    for s in ['abcdefg', 'abcdefg\xab', 'abcdefg\xab\x12', 'abcdefg\0']:
        assert shitcode(s) == s
    assert shitcode('abcdefg\x01') == 'abcdefg?'
    assert shitcode('abcdefg\x01\xab') == 'abcdefg?\xab'
    assert shitcode('abcdefg\x01\xab\x12') == 'abcdefg?\xab\x12'
    assert shitcode('abcdefg\x01\xab\x12\x00') == 'abcdefg?\xab\x12\0'

# Generated at 2022-06-20 12:39:31.174349
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode(u'hello') == 'hello'
    assert shitcode(b'hello') == 'hello'
    assert shitcode(bytearray(b'hello')) == 'hello'

    assert shitcode('דוד') == '????'
    assert shitcode(u'דוד') == '????'
    assert shitcode(b'\xd7\x93\xd7\x95\xd7\x93') == '????'
    assert shitcode(bytearray(b'\xd7\x93\xd7\x95\xd7\x93')) == '????'

    assert shitcode('¿') == '?'
    assert shitcode(u'¿') == '?'

# Generated at 2022-06-20 12:39:35.592397
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class GoodWritableStream(WritableStream):
        def write(self, s):
            pass
    class BadWritableStream(WritableStream):
        pass
    assert issubclass(GoodWritableStream, WritableStream)
    assert isinstance(GoodWritableStream(), WritableStream)
    assert not issubclass(BadWritableStream, WritableStream)
    assert not isinstance(BadWritableStream(), WritableStream)

# Generated at 2022-06-20 12:39:42.214083
# Unit test for function truncate
def test_truncate():
    assert truncate(123, 5) == 123
    assert truncate(123, 0) == 123
    assert truncate(123, -1) == 123
    assert truncate(123, None) == 123
    assert truncate(123, 3) == 123
    assert truncate('qiyamah', 2) == '...'
    assert truncate('') == ''


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-20 12:39:50.440874
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(3) == '3'
    assert get_shortish_repr(3, max_length=0) == ''
    assert get_shortish_repr(3, max_length=2) == '3'
    assert get_shortish_repr(333, max_length=2) == '3..'
    assert get_shortish_repr(3, custom_repr=[(bool, str)]) == '3'
    assert get_shortish_repr(3, custom_repr=[(str, lambda x: 'meow')]) == '3'
    assert get_shortish_repr(3, custom_repr=[(int, lambda x: 'meow')]) \
                                                                    == 'meow'

# Generated at 2022-06-20 12:39:55.574964
# Unit test for function get_repr_function
def test_get_repr_function():
    item = 'tralalala'
    assert get_repr_function(item) == repr
    assert get_repr_function(item, ((re.compile(r'.*la'), lambda x: x))) == (
        lambda x: x
    )
    assert get_repr_function(item, ((re.compile(r'.*la'), lambda x: 'lalala'))) == (
        lambda x: 'lalala'
    )



# Generated at 2022-06-20 12:39:57.440046
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('[1, 2, 3] at 0x1234') == normalize_repr('[1, 2, 3]')



# Generated at 2022-06-20 12:40:01.434019
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x03') == 'abc?'
    assert shitcode('abc\x03def') == 'abc?def'
    assert shitcode('abc\x03def\x03') == 'abc?def?'
    assert shitcode('\x03def\x03') == '??def?'
    assert shitcode('abc\x03def\x03') == 'abc?def?'
    assert shitcode('abcdef\x03\x03ghij') == 'abcdef??ghij'



# Generated at 2022-06-20 12:40:10.923908
# Unit test for function normalize_repr
def test_normalize_repr():
    import sys
    if sys.version_info[0] >= 3:
        # test with a default builtin subclass
        class Test(list):
            pass
        assert normalize_repr(Test([1, 2]).__repr__()) == 'Test([1, 2])'
        # test with a UUID4 object
        import uuid
        string = uuid.uuid4().__repr__()
        assert string != normalize_repr(string)
    else:
        # test with a default builtin subclass
        class Test(list):
            def __repr__(self):
                return 'Test([1, 2])'
        assert normalize_repr('Test([1, 2])') == 'Test([1, 2])'
        # test with a default user-defined subclass

# Generated at 2022-06-20 12:40:18.209344
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            self.s = s
    a = A()
    a.write('foo')
    assert a.s == 'foo'

# Generated at 2022-06-20 12:40:21.081631
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X(WritableStream):
        def write(self, s):
            pass
    assert issubclass(X, WritableStream)


# Generated at 2022-06-20 12:40:23.913527
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X:
        def write(self, s):
            pass

    x = X()
    assert isinstance(x, WritableStream)




# Generated at 2022-06-20 12:40:33.227409
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    custom_repr = ((lambda x: True, lambda x: 'custom'),)
    assert get_shortish_repr(1, custom_repr) == 'custom'
    assert get_shortish_repr(1, custom_repr, max_length=3) == 'cus'
    assert get_shortish_repr(1, custom_repr, max_length=4) == 'cust'
    assert get_shortish_repr(1, custom_repr, max_length=5) == 'custom'
    assert get_shortish_repr(1, custom_repr, max_length=6) == 'custom'
    assert get_shortish_repr(1, max_length=3) == '1'

# Generated at 2022-06-20 12:40:34.914764
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class TestWritableStream(WritableStream):
        pass

    TestWritableStream()



# Generated at 2022-06-20 12:40:39.016562
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'ֻ\n') == u'?\n'
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'\t') == u'\t'
    assert shitcode(u'\r') == u'\r'
    assert shitcode(u'\n') == u'\n'

# Generated at 2022-06-20 12:40:46.535485
# Unit test for function normalize_repr
def test_normalize_repr():
    def make(name):
        return Class(name)

    class Class(object):
        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return 'Class(name={})'.format(self.name)

    assert normalize_repr(repr(make('a'))) == 'Class(name=a)'
    assert normalize_repr(repr(make('abc'))) == 'Class(name=abc)'
    assert ' at' not in normalize_repr(repr(make('abc')))
    assert ' at' not in normalize_repr(repr(make('a')))
    assert '0x' not in normalize_repr(repr(make('a')))

# Generated at 2022-06-20 12:40:54.665759
# Unit test for function truncate
def test_truncate():
    assert truncate(u'Hello world!', None) == u'Hello world!'
    assert truncate(u'Hello world!', 0) == u''
    assert truncate(u'Hello world!', 6) == u'Hello...'
    assert truncate(u'Hello world!', 11) == u'Hello world!'
    assert truncate(u'Hello world!', 12) == u'Hello world!'
    assert truncate(u'Hello world!', 13) == u'Hello world!'
    assert truncate(u'Hello world!', 14) == u'Hello world!'
    assert truncate(u'Hello world!', 15) == u'Hello world!'
    assert truncate(u'Hello world!', 16) == u'Hello world!'
    assert truncate(u'Hello world!', 17) == u'Hello world!'

# Generated at 2022-06-20 12:40:55.452945
# Unit test for function shitcode
def test_shitcode():
    s = 'aåá'
    assert shitcode(s) == 'a??'

# Generated at 2022-06-20 12:41:00.432155
# Unit test for function get_repr_function
def test_get_repr_function():
    def foo(x):
        return 'foo: ' + str(x)
    assert get_repr_function(1, ((int, foo),)) == foo
    assert get_repr_function(1., ((int, foo),)) == repr
    assert get_repr_function(1., ((lambda x: x > 0, foo),)) == foo
    assert get_repr_function(-1., ((lambda x: x > 0, foo),)) == repr

# Generated at 2022-06-20 12:41:10.299315
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [(lambda x: True, lambda x: '{} class'.format(x.__class__))]
    repr_function = get_repr_function('a', custom_repr)
    assert repr_function('a') == "'a' class"


test_custom_repr = (
    (lambda x: True, lambda x: '{} class'.format(x.__class__))
)



# Generated at 2022-06-20 12:41:17.888254
# Unit test for function get_repr_function
def test_get_repr_function():

    class A: pass
    class B: pass

    assert get_repr_function(A(), custom_repr=[]) == repr
    assert get_repr_function(A(), custom_repr=[(A, str)]) == str
    assert get_repr_function(B(), custom_repr=[(A, str)]) == repr
    assert get_repr_function(A(), custom_repr=[(A, str), (B, int)]) == str
    assert get_repr_function(B(), custom_repr=[(A, str), (B, int)]) == int
    assert get_repr_function(
        A(), custom_repr=[(int, float), (A, str), (B, float)]
    ) == str

# Generated at 2022-06-20 12:41:28.297987
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<module at 0x02677530>') == '<module>'
    assert normalize_repr('<type at 0x01C0E8B0>') == '<type>'
    assert normalize_repr('<type at 0x01C0E8B0: str>') == '<type: str>'
    assert normalize_repr('<type at 0x01C0E8B0: list>') == '<type: list>'
    assert normalize_repr('<type at 0x01C0E8B0: set>') == '<type: set>'
    assert normalize_repr('<type at 0x01C0E8B0: tuple>') == '<type: tuple>'

# Generated at 2022-06-20 12:41:34.794938
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class FooStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(FooStream(), WritableStream)

    class FooStream(object):
        def write(self, s):
            pass

    assert not isinstance(FooStream(), WritableStream)

# Generated at 2022-06-20 12:41:41.725046
# Unit test for function truncate
def test_truncate():
    def _assert(x, expected_value):
        assert truncate(x, max_length=17) == expected_value
        assert truncate(x, max_length=17) == expected_value
        assert truncate(x, max_length=17) == expected_value
        assert truncate(x, max_length=17) == expected_value
        assert truncate(x, max_length=17) == expected_value
        assert truncate(x, max_length=17) == expected_value
        assert truncate(x, max_length=17) == expected_value
        assert truncate(x, max_length=17) == expected_value
        assert truncate(x, max_length=17) == expected_value
        assert truncate(x, max_length=17) == expected_value

# Generated at 2022-06-20 12:41:45.842545
# Unit test for function truncate
def test_truncate():
    s = '1234567890'
    assert truncate(s, 5) == '12...'
    assert truncate(s, 3) == '...'
    assert truncate(s, 2) == '..'
    assert truncate(s, 1) == '.'
    assert truncate(s, 0) == ''
    assert truncate(s, -5) == ''





# Generated at 2022-06-20 12:41:50.023109
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyClass(object):
        def __init__(self):
            self.s = ''

        def write(self, s):
            self.s += s

    my_object = MyClass()

    assert issubclass(MyClass, WritableStream)
    assert isinstance(my_object, WritableStream)





# Generated at 2022-06-20 12:41:55.807336
# Unit test for function normalize_repr
def test_normalize_repr():
    assert (normalize_repr('spam') == 'spam')
    assert (normalize_repr('spam at 0x1234') == 'spam')
    assert (normalize_repr('spam at 0x0123456789ABCDEF') == 'spam')
    assert (normalize_repr('spam at 0x0123456789ABCDEF at 0x0123456789ABCDEF') == 'spam')



# Generated at 2022-06-20 12:42:05.512732
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import cStringIO
    file_object = cStringIO.StringIO()
    assert isinstance(file_object, WritableStream)
    class A(WritableStream):
        def write(self, s):
            pass
        def writelines(self, iterator):
            pass

    assert isinstance(A(), WritableStream)

    class B(object):
        def write(self, s):
            pass

    assert not isinstance(B(), WritableStream)

    class C(object):
        def writelines(self, iterator):
            pass

    assert not isinstance(C(), WritableStream)

    class D(WritableStream):
        pass

    assert not isinstance(D(), WritableStream)


# Generated at 2022-06-20 12:42:14.555950
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .dummy_repr import Dummy
    assert get_shortish_repr('foobar') == "'foobar'"
    assert get_shortish_repr('foobar', max_length=3) == "'..."
    assert get_shortish_repr(Dummy(123)) == "Dummy(123, 456, 789)"
    assert get_shortish_repr(Dummy(123), max_length=30) == "Dummy(123, 456, 789)"
    assert get_shortish_repr(Dummy(123), max_length=10) == "..."
    assert get_shortish_repr(Dummy(123), max_length=10, normalize=True) == "..."
    assert get_shortish_repr(Dummy(123), max_length=30, normalize=True)

# Generated at 2022-06-20 12:42:27.215685
# Unit test for function get_repr_function
def test_get_repr_function():

    def repr_function_1(x):
        return '1{}1'.format(x)

    def repr_function_2(x):
        return '2{}2'.format(x)

    assert get_repr_function(
        3,
        custom_repr=(
            (int, repr_function_1),
            (str, repr_function_2),
        )
    ) == repr_function_1

    assert get_repr_function(
        'a',
        custom_repr=(
            (int, repr_function_1),
            (str, repr_function_2),
        )
    ) == repr_function_2


# Generated at 2022-06-20 12:42:32.377345
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class Writable(object):
        def write(self, s):
            print('Writing', s)

    print(issubclass(Writable, WritableStream))

    assert issubclass(Writable, WritableStream)

    print('helllo')

    writable = Writable()

    writable.write('hello there')

    print('goodbye')

    class Writable(object):
        def write(self, s):
            print('Writing', s)

    print(issubclass(Writable, WritableStream))

    assert issubclass(Writable, WritableStream)

    writable = Writable()

    writable.write('hello there')

    writable = Writable()

    writable.write('hello there')


# Generated at 2022-06-20 12:42:43.660184
# Unit test for function normalize_repr
def test_normalize_repr():
    class Thing:
        def __init__(self, xs):
            self.xs = xs
        def __repr__(self):
            return '{}({})'.format(self.__class__.__name__, self.xs)
    assert normalize_repr('hello at 0x') == 'hello at 0x'
    assert normalize_repr('hello at 0x123') == 'hello at 0x123'
    assert normalize_repr('hello at 0x123456') == 'hello'
    assert normalize_repr('hello at 0x12345678') == 'hello'
    assert normalize_repr('hello at 0x1234567890') == 'hello'
    assert normalize_repr('') == ''

# Generated at 2022-06-20 12:42:48.748531
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'') == u''
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'a\x00b\x01') == u'a?b?'
    assert shitcode(u'a\x7fb\xac') == u'a?b?'
    assert shitcode(u'a\x7fb\xff') == u'a?b?'
    assert shitcode(u'a\x7fb\u0200') == u'a?b?'



# Generated at 2022-06-20 12:42:53.250219
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("<__main__.C object at 0x7ff7f505a850>") == \
                                                        "<__main__.C object>"
    assert normalize_repr("{}") == "{}"
    assert normalize_repr("'{asdf}'") == "'{asdf}'"

# Generated at 2022-06-20 12:43:04.095402
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\xad') == '\xad'
    assert shitcode('\xad\xbc') == '\xad\xbc'
    assert shitcode('\xad\xbc\xff') == '\xad\xbc\xff'
    assert shitcode('\x01\xad\xbc\xff') == '\x01\xad\xbc\xff'
    assert shitcode('\x01\xad\xff\xff') == '\x01\xad???\xff'
    assert shitcode('\xff\xff') == '??'
    assert shitcode('\xff\xbc\xff') == '?\xbc?'
    assert shitcode('\xff\xbc') == '?\xbc'

# Generated at 2022-06-20 12:43:11.326671
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class Dummy(object):
        def __init__(self, s):
            self.s = s
        def __repr__(self):
            return self.s

    assert get_shortish_repr([1, 2, 3], max_length=10) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=9) == '[1,...3]'
    assert get_shortish_repr([1, 2, 3], max_length=5) == '[...3]'
    assert get_shortish_repr([1, 2, 3], max_length=4) == '[...3]'
    assert get_shortish_repr([1, 2, 3], max_length=3) == '[...]'

# Generated at 2022-06-20 12:43:15.832878
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def __init__(self):
            self.output = ''
        def write(self, s):
            self.output = s
    a = A()
    assert isinstance(a, WritableStream)


    a.write('meow')
    assert a.output == 'meow'



# Generated at 2022-06-20 12:43:17.379523
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert (get_shortish_repr('hello!', max_length=5) ==
            'he...')



# Generated at 2022-06-20 12:43:25.834086
# Unit test for function truncate
def test_truncate():
    assert truncate('abcde', None) == 'abcde'
    assert truncate('abcde', 0) == 'abcde'
    assert truncate('abcde', 1) == '...'
    assert truncate('abcde', 2) == '...'
    assert truncate('abcde', 3) == '...'
    assert truncate('abcde', 4) == 'a...'
    assert truncate('abcde', 5) == 'a...'
    assert truncate('abcde', 6) == 'a...e'
    assert truncate('abcde', 7) == 'a...de'
    assert truncate('abcde', 8) == 'abcde'




# Generated at 2022-06-20 12:43:33.040309
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout, WritableStream)
    assert not issubclass(str, WritableStream)



# Generated at 2022-06-20 12:43:38.485548
# Unit test for function get_repr_function
def test_get_repr_function():
    get_repr_function(
        'hello',
        (
            (lambda x: isinstance(x, int), lambda x: '42'),
            (lambda x: isinstance(x, str), lambda x: 'hello world'),
        )
    )
    get_repr_function(
        42,
        (
            (lambda x: isinstance(x, int), lambda x: '42'),
            (lambda x: isinstance(x, str), lambda x: 'hello world'),
        )
    )



# Generated at 2022-06-20 12:43:41.023576
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Regression test for issue #14:
    assert get_shortish_repr(...) == '...'


if __name__ == '__main__':
    test_get_shortish_repr()

# Generated at 2022-06-20 12:43:49.027382
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FileLike(WritableStream):
        def write(self, s):
            return len(s)

    assert isinstance(FileLike(), WritableStream)
    assert not isinstance(123, WritableStream)

    class FileLike2(WritableStream):
        pass

    assert not isinstance(FileLike2(), WritableStream)
    assert not isinstance(123, WritableStream)


if __name__ == '__main__':
    test_WritableStream_write()




# Generated at 2022-06-20 12:43:58.953240
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple((i, i) for i in range(3)) == ((0, 0), (1, 1), (2, 2))
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple(((1, 2), (3, 4))) == ((1, 2), (3, 4))


if sys.version_info >= (3,):
    from io import StringIO
else:
    from StringIO import StringIO

if sys.version_info >= (3,):
    from io import BytesIO as BytesIOCompat

# Generated at 2022-06-20 12:44:03.926415
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class TestClass(object):
        pass

    assert not issubclass(TestClass, WritableStream)

    class TestClass(object):
        pass

    TestClass.write = None

    assert not issubclass(TestClass, WritableStream)

    class TestClass(object):
        def write(self, *args, **kwargs):
            pass

    assert issubclass(TestClass, WritableStream)

# Generated at 2022-06-20 12:44:05.025863
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)



# Generated at 2022-06-20 12:44:16.240685
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello at 0x123456789') == 'hello'
    assert normalize_repr('hello at 0x1234567890') == 'hello'
    assert normalize_repr('hello at 0x1234567890AB') == 'hello'
    assert normalize_repr('hello at 0x1234567890ABC') == 'hello'
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('') == ''
    assert normalize_repr('hello at 0x') == 'hello at 0x'
    assert normalize_repr('hello at 0x1234') == 'hello at 0x1234'

# Generated at 2022-06-20 12:44:20.886537
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, string):
            self.written_string += string
    stream = MyWritableStream()
    stream.write('chicken')
    assert stream.written_string == 'chicken'

# Generated at 2022-06-20 12:44:24.456766
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == ((1, 2),)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(x for x in (1, 2)) == (1, 2)

# Generated at 2022-06-20 12:44:44.298994
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .tictactoe import Game, Terminal, HumanPlayer, RandomPlayer
    import time
    import sys

    class WritableStreamTest(WritableStream):
        def write(self, s):
            print(s)

    sys.stdout = WritableStreamTest()

    g = Game(2, RandomPlayer(), HumanPlayer(1, 'x'))
    while not isinstance(g.winner, Terminal):
        g.winner = g.winner.play()
        time.sleep(0.1)

    sys.stdout = sys.__stdout__
    assert isinstance(sys.stdout, WritableStream)

# Generated at 2022-06-20 12:44:49.112810
# Unit test for function normalize_repr
def test_normalize_repr():

    class A:
        def __repr__(self):
            return super(A, self).__repr__() + ' at 0x7f93d6afca10'

    a = A()

    assert normalize_repr(repr(a)) == repr(a)

    assert normalize_repr("a at 0x7f93d6afca10") == 'a'

    assert normalize_repr("a") == 'a'

# Generated at 2022-06-20 12:44:52.545160
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(set([1, 2, 3])) == (1, 2, 3)

# Generated at 2022-06-20 12:44:57.592555
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple((5,)) == (5,)
    assert ensure_tuple([5]) == (5,)
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple([5, 6, 7]) == (5, 6, 7)




# Generated at 2022-06-20 12:44:59.113271
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout.__class__, WritableStream)

# Generated at 2022-06-20 12:45:05.233226
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefg', None) == 'abcdefg'
    assert truncate('abcdefg', 7) == 'abcdefg'
    assert truncate('abcdefg', 6) == 'ab...g'
    assert truncate('abcdefg', 4) == '...fg'
    assert truncate('abcdefg', 2) == '...'
    assert truncate('abcdefg', 1) == '...'
    assert truncate('abcdefg', 0) == '...'

# Generated at 2022-06-20 12:45:07.410565
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class F(WritableStream):
        def write(self, s):
            pass
    f = F()
    f.write('hi')

# Generated at 2022-06-20 12:45:10.633761
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamSubclass(WritableStream):
        def __init__(self):
            self.written_string = ''
        def write(self, s):
            self.written_string += s

    assert isinstance(WritableStreamSubclass(), WritableStream)

# Generated at 2022-06-20 12:45:14.964856
# Unit test for function get_repr_function
def test_get_repr_function():
    from .string_tools import guess_encoding
    def custom_repr(_1, _2):
        pass
    x = get_repr_function([1, 2, 3], ((0, custom_repr),
                                      (lambda x: isinstance(x, dict),
                                       custom_repr)))
    assert x is custom_repr
    y = get_repr_function([1, 2, 3], ((0, custom_repr),
                                      (lambda x: isinstance(x, list),
                                       custom_repr)))
    assert y is repr



# Generated at 2022-06-20 12:45:25.068760
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(87) == (87,)
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(['meow']) == (['meow'],)
    assert ensure_tuple(('meow',)) == (('meow',),)
    assert ensure_tuple(x for x in range(4)) == (0, 1, 2, 3)
    assert ensure_tuple(range(4)) == (0, 1, 2, 3)
    assert ensure_tuple(set(range(4))) == (0, 1, 2, 3)
    assert ensure_tuple([x for x in range(4)]) == (0, 1, 2, 3)



# Generated at 2022-06-20 12:46:06.586020
# Unit test for function normalize_repr
def test_normalize_repr():
    class Potato(object):
        def __repr__(self):
            return 'potato'
    class Potato2(object):
        def __repr__(self):
            return 'potato at 0x9876'

    assert normalize_repr('potato') == 'potato'
    assert normalize_repr('potato at 0x1234') == 'potato'
    assert normalize_repr(Potato()) == 'potato'
    assert normalize_repr(Potato2()) == 'potato'



# Generated at 2022-06-20 12:46:13.458676
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    integer = 123456789012345678901234567890123456789
    
    assert get_shortish_repr(integer, max_length=50) \
                                   == '123456789012345678901234567890123456789'
    assert get_shortish_repr(integer, max_length=50, normalize=True) \
                                          == '123456789012345678901234567890123'
    
    assert get_shortish_repr(integer, max_length=35) \
                                          == '123456789012345678901234567890123'

# Generated at 2022-06-20 12:46:22.631527
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=5) == "'he...'"
    assert get_shortish_repr('hello', max_length=6) == "'hel...'"
    assert get_shortish_repr('hello', max_length=6, normalize=True) == "'hello'"

    class Foo(object):
        pass
    foo = Foo()
    assert get_shortish_repr(
        foo, max_length=len(repr(foo)) + 2, normalize=True
    ) == repr(foo)


# Generated at 2022-06-20 12:46:32.811265
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('bla') == 'bla'
    assert normalize_repr('bla at 0x234') == 'bla'
    assert normalize_repr('bla at 0x234234') == 'bla'
    assert normalize_repr('bla at 0x234234234') == 'bla'
    assert normalize_repr('bla at 0x234234234234') == 'bla'
    assert normalize_repr('bla at 0x234234x') == 'bla at 0x234234x'
    assert normalize_repr('bla at 0x234234x234') == 'bla at 0x234234x234'
    assert normalize_repr('bla at 0x234234x234x') == 'bla at 0x234234x234x'

# Generated at 2022-06-20 12:46:37.450666
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('foo') == ('foo',)
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple((5,)) == (5,)
    assert ensure_tuple((5, 6, 7)) == (5, 6, 7)
    assert ensure_tuple([5]) == (5,)
    assert ensure_tuple([5, 6, 7]) == (5, 6, 7)



# Generated at 2022-06-20 12:46:40.099456
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)



# Generated at 2022-06-20 12:46:49.654646
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A:
        def __repr__(self):
            return 'REPR A'

    class B:
        def __repr__(self):
            return 'REPR B'

    class C(A):
        pass

    custom_repr = ((B, lambda _: 'CUSTOM B'),)

    assert normalize_repr('REPR A at 0x1234') == 'REPR A'

    assert get_shortish_repr(A(), custom_repr, 12) == 'REPR A'
    assert get_shortish_repr(B(), custom_repr, 12) == 'CUSTOM B'
    assert get_shortish_repr(C(), custom_repr, 12) == 'REPR A'


# Generated at 2022-06-20 12:46:54.545839
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    """ Unit test for method write of class WritableStream."""
    from python_toolbox.temp_value_setting import TempValueSetting
    from .contextmanagers import make_file
    from .file_writing_tools.write_to_file import write_to_file
    with make_file() as f:
        with TempValueSetting(sys.stdout, f):
            write_to_file(sys.stdout, 'hello there')
        f.seek(0)
        assert f.read() == 'hello there'

# Generated at 2022-06-20 12:46:59.260591
# Unit test for function truncate
def test_truncate():
    assert truncate('Hello', 5) == 'Hello'
    assert truncate('Hello', 4) == 'Hell'
    assert truncate('Hello', 3) == 'Hel'
    assert truncate('Hello', 2) == 'He'
    assert truncate('Hello', 1) == 'H'
    assert truncate('Hello', 0) == ''


if __name__ == '__main__':
    test_truncate()

# Generated at 2022-06-20 12:47:06.331578
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, ()) is repr

    def my_repr(x):
        return 'MY REPR'

    assert get_repr_function('bla', ((str, unicode), my_repr)) is my_repr

    assert get_repr_function(3, ((int,), my_repr)) is repr
    assert get_repr_function(3.0, ((int,), my_repr)) is repr



# Generated at 2022-06-20 12:48:02.535249
# Unit test for function truncate
def test_truncate():
    assert truncate('123', None) == '123'
    assert truncate('1234567', 10) == '1234567'
    assert truncate('123', 2) == '1...'
    assert truncate('123', 3) == '123'
    assert truncate('123', 4) == '1...'
    assert truncate('123456789', 8) == '1...89'
    assert truncate('123456789', 9) == '123...89'
    assert truncate('123456789', 10) == '123456789'
    assert truncate('123456789', 11) == '123456789'
    assert truncate('123456789', 12) == '123456789'