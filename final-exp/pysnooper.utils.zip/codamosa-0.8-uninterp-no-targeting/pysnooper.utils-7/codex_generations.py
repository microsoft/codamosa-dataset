

# Generated at 2022-06-20 12:38:18.599110
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc¾') == 'abc¾'
    assert shitcode('abc\xe6') == 'abc?'
    assert shitcode('abc\xe6\xf8') == 'abc??'
    assert shitcode('abc\xe6\xf8\x10') == 'abc???'
    assert shitcode('abc\xe6\xf8\x80') == 'abc???'
    assert shitcode('abc\xe6\xf8\x81') == 'abc??\x81'
    assert shitcode(u'abc\u1234') == 'abc?'

# Generated at 2022-06-20 12:38:24.157263
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyWritableStream(WritableStream):
        def __init__(self, string, max_length=None):
            self.string = string
            self.max_length = max_length
            self.written = ''
        def write(self, s):
            self.written += s[:self.max_length]
        def flush(self):
            pass

    dummy_writable_stream = DummyWritableStream('hello')
    dummy_writable_stream.write('world')

    assert dummy_writable_stream.written == 'world'



# Generated at 2022-06-20 12:38:27.772537
# Unit test for function truncate
def test_truncate():
    assert truncate('abcde', 5) == 'abcde'
    assert truncate('abcde', 4) == 'abcd...'
    assert truncate('tuvwxyz', 5) == 't...z'
    assert truncate('tuvwxyz', 6) == 't...yz'
    assert truncate('tuvwxyz', 7) == 'tuvwxyz'
    assert truncate('tuvwxyz', 8) == 'tuvwxyz'

# Generated at 2022-06-20 12:38:38.089003
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, custom_repr=[]) == repr
    assert get_repr_function(0.0, custom_repr=[]) == repr
    assert get_repr_function('', custom_repr=[]) == repr
    assert get_repr_function([], custom_repr=[]) == repr

    assert get_repr_function(0, custom_repr=[(int, str)]) == str
    assert get_repr_function(0.0, custom_repr=[(int, str)]) == repr
    assert get_repr_function([], custom_repr=[(int, str)]) == repr
    custom_repr = [(int, str), (float, lambda x: 'float: ' + repr(x))]

# Generated at 2022-06-20 12:38:43.200280
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .abc import WriteableStream
    from .abc import ReadableStream
    from .abc import Stream
    from .abc import TextStream
    from .abc import BinaryStream

    class Dummy(object):
        pass

    assert issubclass(Dummy, Stream)
    assert issubclass(Dummy, TextStream)
    assert issubclass(Dummy, BinaryStream)
    assert issubclass(Dummy, ReadableStream)
    assert issubclass(Dummy, WriteableStream)

    assert not issubclass(Dummy, Stream)

# Generated at 2022-06-20 12:38:50.686478
# Unit test for function shitcode
def test_shitcode():
    assert shitcode() == ''
    assert shitcode(1) == '1'
    assert shitcode(b'foo') == 'foo'
    assert shitcode(b'foo\x01') == 'foo?'
    assert shitcode('foo') == 'foo'
    assert shitcode('foo\x01') == 'foo?'
    assert shitcode('foo\xa1') == 'foo?'
    assert shitcode('foo\xa1'.encode('latin1')) == 'foo?'
    assert shitcode('foo\x01'.encode('latin1')) == 'foo?'
    return

# Generated at 2022-06-20 12:38:58.226498
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo(object): pass
    class Bar(object): pass

    my_dict = {(1, 2, 3): 100}
    my_int_dict = {1: 100}
    my_set = set([1, 2, 3, 4])
    my_int_set = set([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    my_list = list(range(10))
    my_int_list = list(range(100))
    my_tuple = tuple(range(10))
    my_int_tuple = tuple(range(100))

    assert get_repr_function(100, [(dict, str), (int, str), (float, str)]) == str

# Generated at 2022-06-20 12:39:07.451437
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Y:
        pass
    class MyStream(WritableStream):
        def write(self, s):
            s = s.upper()
            # print(s, file=sys.stderr)
            self.stderr.write(s)
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.stderr = open('stderr.txt', 'w') # For unit test
        def __del__(self):
            self.stderr.close()
    assert isinstance(MyStream(), WritableStream)
    assert not isinstance(Y(), WritableStream)

# Generated at 2022-06-20 12:39:16.746300
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr(10) == '10'
    assert get_shortish_repr(10, max_length=3) == '10'
    assert get_shortish_repr(10, max_length=2) == '1...'
    assert get_shortish_repr(10, max_length=1) == '...'
    assert get_shortish_repr(10, max_length=0) == '...'
    assert get_shortish_repr(10, max_length=5) == '10'
    assert get_shortish_repr(10, max_length=6) == '10'
    assert get_shortish_repr(-10, max_length=6) == '-10'

# Generated at 2022-06-20 12:39:27.190282
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklm', None) == 'abcdefghijklm'
    assert truncate('abcdefghijklm', 0) == ''
    assert truncate('abcdefghijklm', 15) == 'abcdefghijklm'
    assert truncate('abcdefghijklm', 16) == 'abcdefghijklm'
    assert truncate('abcdefghijklm', 17) == 'abcdefghijklm...'
    assert truncate('abcdefghijklm', 18) == 'abcdefghijklm...'
    assert truncate('abcdefghijklm', 19) == 'abcdefghijklm.....'
    assert truncate('abcdefghijklm', 9) == 'abcde...m'

# Generated at 2022-06-20 12:39:38.013623
# Unit test for function truncate
def test_truncate():
    assert truncate(u'hello', 5) == u'hello'
    assert truncate(u'hello', 6) == u'hello'
    assert truncate(u'hello', 7) == u'hello'
    assert truncate(u'hello', 4) == u'h...'
    assert truncate(u'hello', 3) == u'...'
    assert truncate(u'hello', 2) == u'..'
    assert truncate(u'hello', 1) == u'.'
    assert truncate(u'hello', 0) == u''
    assert truncate(u'hello', -1) == u''
    assert truncate(u'hello', None) == u'hello'



# Generated at 2022-06-20 12:39:42.357351
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("<function test_normalize_repr at 0x7f9fe4687a60>") \
                       == "<function test_normalize_repr>"
    assert normalize_repr("<function test_normalize_repr>") \
                       == "<function test_normalize_repr>"

# Generated at 2022-06-20 12:39:50.567771
# Unit test for function truncate
def test_truncate():
    assert truncate(123456789, max_length=None) == '123456789'
    assert truncate(123456789, max_length=1) == '1'
    assert truncate(123456789, max_length=2) == '1...'
    assert truncate(123456789, max_length=3) == '1..'
    assert truncate(123456789, max_length=4) == '1...9'
    assert truncate(123456789, max_length=5) == '12..9'
    assert truncate(123456789, max_length=6) == '12..89'
    assert truncate(123456789, max_length=7) == '12..789'

# Generated at 2022-06-20 12:39:58.322352
# Unit test for function ensure_tuple
def test_ensure_tuple():
    # All of the following should return tuples:
    assert isinstance(ensure_tuple(None), tuple)
    assert isinstance(ensure_tuple(()), tuple)
    assert isinstance(ensure_tuple([]), tuple)
    assert isinstance(ensure_tuple({}), tuple)
    assert isinstance(ensure_tuple(set()), tuple)
    assert isinstance(ensure_tuple(''), tuple)
    assert isinstance(ensure_tuple('a'), tuple)
    assert isinstance(ensure_tuple('ab'), tuple)
    assert isinstance(ensure_tuple(123), tuple)
    assert isinstance(ensure_tuple(12.3), tuple)
    assert isinstance(ensure_tuple(object()), tuple)

# Generated at 2022-06-20 12:40:04.969605
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x123456') == 'hello'
    assert normalize_repr('hello at 0x1234567890') == 'hello'
    assert normalize_repr('hello at 0x1234567890abcdef') == 'hello'
    assert normalize_repr('hello at 0x1234567890abcdef12345678') == 'hello'

# Generated at 2022-06-20 12:40:12.878991
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnopqrstuvwxyz', 0) == ''
    assert truncate('abcdefghijklmnopqrstuvwxyz', 3) == '...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 4) == 'a...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 5) == 'a...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 6) == 'ab...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 7) == 'ab...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 8) == 'ab...'

# Generated at 2022-06-20 12:40:17.233111
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pythontest import assert_true, assert_is_none


    class TestWritableStream(WritableStream):
        def __init__(self):
            self.data = ''

        def write(self, s):
            self.data += s


    w = TestWritableStream()
    w.write('hello ')
    w.write('world')
    assert_true(isinstance(w, WritableStream))
    assert_is_none(w.__class__.__subclasshook__(TestWritableStream))
    assert_true(w.data == 'hello world')



# Generated at 2022-06-20 12:40:28.695501
# Unit test for function get_repr_function
def test_get_repr_function():
    def my_bytes_repr(b):
        return str(b) if sys.version_info[0] < 3 else str(b, 'utf-8')

    assert get_repr_function(b'hi', custom_repr=((bytes, my_bytes_repr),))(b'hi') == 'hi'
    assert get_repr_function(b'hi', custom_repr=((str, my_bytes_repr),))(b'hi') == "b'hi'"

    class A: pass
    assert get_repr_function(A(), custom_repr=((A, my_bytes_repr),))(A()) == 'A'

# Generated at 2022-06-20 12:40:36.676554
# Unit test for function truncate
def test_truncate():
    assert truncate('', 5) == ''
    assert truncate('a' * 2, 5) == 'a' * 2
    assert truncate('a' * 5, 5) == 'a' * 5
    assert truncate('a' * 6, 5) == 'a' * 3 + '...'
    assert truncate('a' * 10, 5) == 'a' * 3 + '...'
    assert truncate('a' * 3 + 'b' * 3 + 'c' * 3 + 'd', 5) == 'a' * 3 + '...'

# Generated at 2022-06-20 12:40:44.477157
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcde', max_length=5) == 'abcde'
    assert get_shortish_repr('abcdef', max_length=5) == 'ab...f'
    assert get_shortish_repr('abcde', max_length=None) == 'abcde'
    assert get_shortish_repr(12345, max_length=5) == '12345'
    assert get_shortish_repr(123456, max_length=5) == '1...6'
    assert get_shortish_repr(123456, custom_repr=(
        (lambda x: True, lambda x: 'x'),
    ), max_length=5) == 'x'

# Generated at 2022-06-20 12:40:51.013561
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class StringWriter(WritableStream):
        def write(self, s):
            self.text = s
    string_writer = StringWriter()
    string_writer.write('foo')
    assert string_writer.text == 'foo'
    string_writer.write('bar')
    assert string_writer.text == 'foobar'



# Generated at 2022-06-20 12:40:53.179141
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)



# Generated at 2022-06-20 12:40:57.954891
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(()) == ()
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple('hi!') == ('hi!',)



# Generated at 2022-06-20 12:41:00.829578
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class FakeStringIO(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s
    assert issubclass(FakeStringIO, WritableStream)



# Generated at 2022-06-20 12:41:02.809172
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestWritableStream(WritableStream):
        def write(self, s): pass
    assert issubclass(TestWritableStream, WritableStream)



# Generated at 2022-06-20 12:41:10.748064
# Unit test for function get_repr_function
def test_get_repr_function():
    def x(s):
        return (s + 'x')
    assert get_repr_function(4, [(int, x)]) is repr
    assert get_repr_function(4, [(str, x)]) is repr
    assert get_repr_function('4', [(str, x)]) is x
    assert get_repr_function('4', [(lambda s: s == '4', x)]) is x
    assert get_repr_function('4', [(None, x)]) is x



# Generated at 2022-06-20 12:41:13.141422
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('a') == ('a',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(['a', 'b']) == ('a', 'b')



# Generated at 2022-06-20 12:41:19.767910
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C(A): pass
    class D(C): pass

    a = A()
    b = B()
    c = C()
    d = D()

    custom_repr = (
        (A, lambda a: 'A!'),
        (B, lambda b, y=2: 'B!'),
        (lambda x: isinstance(x, C), lambda c: 'C!'),
    )


# Generated at 2022-06-20 12:41:26.709379
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((3,)) == (3,)
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(['hello']) == ('hello',)
    assert ensure_tuple(iter(['hello'])) == ('hello',)
    assert ensure_tuple(frozenset(['hello'])) == ('hello',)
    assert ensure_tuple(set(['hello'])) == ('hello',)




# Generated at 2022-06-20 12:41:30.592550
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self, *args, **kwargs):
            self.write_called = False
        def write(self, *args, **kwargs):
            self.write_called = True

    x = MyWritableStream()
    assert not x.write_called
    x.write('hi')
    assert x.write_called



# Generated at 2022-06-20 12:41:40.938678
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', None) == 'hello'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 4) == 'hell'
    assert truncate('hello', 3) == 'hel'
    assert truncate('hell', 5) == 'hell'
    assert truncate('hell', 4) == 'hell'
    assert truncate('hell', 3) == 'hel'
    assert truncate('hell', 2) == 'he'
    assert truncate('hell', 1) == 'h'
    assert truncate('hell', 0) == ''
    assert truncate('hello', 6) == 'hello'
    assert truncate('hello', 7) == 'hello'
    assert truncate('hello', 8) == 'hello'
    assert truncate('hello', 9) == 'hello'

# Generated at 2022-06-20 12:41:48.341549
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda x: x > 5, lambda x: '>5'),
        (lambda x: x % 2, lambda x: 'odd'),
        (int, lambda x: 'int')
    )
    assert get_repr_function(6, custom_repr) is repr
    assert get_repr_function(7, custom_repr) is repr
    assert get_repr_function(4, custom_repr) is repr
    assert get_repr_function(5, custom_repr) is repr
    assert get_repr_function(6, custom_repr) is repr
    assert get_repr_function(7, custom_repr) is repr
    assert get_repr_function(4, custom_repr)(4) == 'int'
    assert get_repr_

# Generated at 2022-06-20 12:41:51.900017
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello world!') == 'hello world!'
    assert normalize_repr('hello world! at 0x123456789ABC') == 'hello world!'


# TODO: Test this one.

# Generated at 2022-06-20 12:41:56.824650
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(12) == (12,)
    assert ensure_tuple([12]) == (12,)
    assert ensure_tuple([12, 13]) == (12, 13)
    assert ensure_tuple(iter([1, 2])) == (1, 2)
    assert ensure_tuple(i for i in 'abcd') == ('a', 'b', 'c', 'd')



# Generated at 2022-06-20 12:42:01.871086
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('a') == ('a',)
    assert ensure_tuple(('a',)) == ('a',)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)

# Generated at 2022-06-20 12:42:05.162946
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            print(s)
    MyWritableStream().write('Yo!')



# Generated at 2022-06-20 12:42:08.914346
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(4) == (4,)
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple((9,)) == (9,)
    assert ensure_tuple([7, 9]) == (7, 9)





# Generated at 2022-06-20 12:42:17.034282
# Unit test for function truncate
def test_truncate():
    assert truncate('', max_length=None) == ''
    assert truncate('', max_length=0) == ''
    assert truncate('', max_length=1) == ''
    assert truncate('', max_length=2) == ''
    assert truncate('', max_length=3) == ''

    assert truncate('123456', max_length=None) == '123456'
    assert truncate('123456', max_length=0) == ''
    assert truncate('123456', max_length=1) == '...'
    assert truncate('123456', max_length=2) == '...'
    assert truncate('123456', max_length=3) == '...'
    assert truncate('123456', max_length=4) == '1...'

# Generated at 2022-06-20 12:42:26.215815
# Unit test for function ensure_tuple
def test_ensure_tuple():
    for X, Y in (
        ('aaa', ('aaa',)),
        ('aaa, bbb, ccc', ('aaa', ' bbb', ' ccc')),
        (('aaa',), ('aaa',)),
        (['aaa'], ('aaa',)),
        ([['aaa'], 'bbb'], (['aaa'], 'bbb')),
    ):
        assert ensure_tuple(X) == Y

    class A(object):
        def __iter__(self):
            return iter(('aaa',))

    class B(object):
        def __repr__(self):
            return 'B()'

    assert ensure_tuple(A()) == ('aaa',)
    assert ensure_tuple(B()) == (B(),)



# Generated at 2022-06-20 12:42:29.322342
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('1' * 100) == '1' * 100
    assert get_shortish_repr('1' * 100, max_length=10) == '1' * 10 + '...'



# Generated at 2022-06-20 12:42:40.391270
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        pass

    assert WritableStream.__subclasshook__(A) is NotImplemented

    class B(WritableStream):
        def write(self):
            pass

    assert WritableStream.__subclasshook__(B) is NotImplemented

    class C:
        pass

    assert WritableStream.__subclasshook__(C) is NotImplemented

    class D(WritableStream):
        def write(self, s):
            pass

    assert WritableStream.__subclasshook__(D) is True



# Generated at 2022-06-20 12:42:45.356744
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('asdf') == "'asdf'"
    assert get_shortish_repr('x' * 100) == "'" + 'x' * 72 + '...' + 'x' * 23 + "'"
    assert get_shortish_repr('x' * 100, max_length=None) == "'" + 'x' * 100 + "'"
    assert get_shortish_repr('x' * 100, max_length=None, normalize=True) == "'" + 'x' * 100 + "'"
    assert get_shortish_repr('x' * 100, max_length=70, normalize=True) == "'" + 'x' * 68 + '...' + 'x' * 1 + "'"

# Generated at 2022-06-20 12:42:51.447624
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(2, ((int, str), (int, list))) == str
    assert get_repr_function('hi', ((int, str), (int, list))) == str
    assert get_repr_function(2, ((int, str), (int, list))) == str
    assert get_repr_function([3], ((int, str), (int, list))) == list
    assert get_repr_function([3], ((int, str), (int, list))) == list
    assert get_repr_function([3], ((int, str), (int, list))) == list
    assert get_repr_function(range(5), ((int, str), (int, list))) == list
    assert get_repr_function(range(5), ((int, str), (int, list))) == list
    assert get

# Generated at 2022-06-20 12:42:55.423739
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)



# Generated at 2022-06-20 12:42:59.372950
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A:
        def write(self): pass
    assert issubclass(A, WritableStream)

    class B:
        def write(self): pass
        def write2(self): pass
    assert not issubclass(B, WritableStream)



# Generated at 2022-06-20 12:43:08.842147
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz') == "'abcdefghijklmnopqrstuvwxyz'"
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=20) == "'abcdefghijklmn...xyz'"
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=1) == "'a'"
    assert get_shortish_repr(u'abcdefghijklmnopqrstuvwxyz', max_length=1) == u"'a'"

# Generated at 2022-06-20 12:43:18.644098
# Unit test for function normalize_repr
def test_normalize_repr():
    class Foo(object): pass

    foo = Foo()
    normal_repr = repr(foo)
    no_address_repr = normalize_repr(normal_repr)

    assert normal_repr.startswith('<'), normal_repr
    assert normal_repr.endswith('>'), normal_repr
    assert normal_repr.endswith('>'), normal_repr
    assert normal_repr.endswith(' at 0x')
    assert not no_address_repr.endswith(' at 0x')

    assert normal_repr == '<__main__.Foo object at 0x{}>'.format(
        hex(id(foo))
    )
    assert no_address_repr == '<__main__.Foo object>'

    assert normalize_repr

# Generated at 2022-06-20 12:43:21.138024
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(x, y): pass

    assert isinstance(A(), WritableStream)
    assert not isinstance(A, WritableStream)

# Generated at 2022-06-20 12:43:24.538613
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((3,)) == (3,)
    assert ensure_tuple([3]) == (3,)
    assert ensure_tuple({3}) == ({3},)
    



# Generated at 2022-06-20 12:43:27.208321
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

# Generated at 2022-06-20 12:43:38.959939
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('משה') == '???'
    assert shitcode(b'meow') == 'meow'
    assert shitcode(b'\xff') == '?'
    assert shitcode(b'\x00\x20') == '? '
    assert shitcode(b'\x0a\x00\x20\xff') == '\n ??'
    assert shitcode(u'meow') == 'meow'
    assert shitcode(u'\u0645\u0634\u0627') == '???a'
    assert shitcode(u'\u0a00') == '?'



# Generated at 2022-06-20 12:43:47.702092
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('foo') == 'foo'
    assert normalize_repr('foo at 0x1234') == 'foo'
    assert normalize_repr('foo at 0x123456') == 'foo'
    assert normalize_repr('foo at 0x12345678') == 'foo'
    assert normalize_repr('foo at 0xA') == 'foo'
    assert normalize_repr('foo at 0x0') == 'foo'
    assert normalize_repr('foo at 0x123456789') == 'foo at 0x123456789'





# Generated at 2022-06-20 12:43:56.013959
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStream(object):
        def write(self, s):
            pass

    assert isinstance(WritableStream(), WritableStream)

    class WritableStream(object):
        pass

    assert isinstance(WritableStream(), WritableStream)

    class WritableStream(object):
        def write(self, s):
            pass
        def foo(self):
            pass

    assert not isinstance(WritableStream(), WritableStream)

    class FileLikeObject(object):
        def write(self, s):
            pass
        def tell(self):
            pass

    assert isinstance(FileLikeObject(), WritableStream)



# Generated at 2022-06-20 12:44:01.266191
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x1234') == 'hello'
    assert normalize_repr('hello at 0x1234ABC') == 'hello'
    assert normalize_repr('hello at 0x123A2F') == 'hello'
    assert normalize_repr('hello at 0x1234abC') == 'hello'



# Generated at 2022-06-20 12:44:07.786625
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr(3, max_length=10) == '3'
    assert get_shortish_repr(3, max_length=2) == '3'
    assert get_shortish_repr(3, max_length=1) == '3'
    assert get_shortish_repr(3, max_length=0) == '3'

    assert get_shortish_repr(3.14159, max_length=10) == '3.14159'
    assert get_shortish_repr(3.14159, max_length=6) == '3.141'
    assert get_shortish_repr(3.14159, max_length=5) == '3.14'

# Generated at 2022-06-20 12:44:11.074618
# Unit test for function shitcode
def test_shitcode():
    s = 'אבגדהוזחטיכלמנסעפצקרשת'
    assert shitcode(s) == '?????????', shitcode(s)



# Generated at 2022-06-20 12:44:18.295366
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MockWritableStream:
        def __init__(self):
            self.content = ''
        def write(self, s):
            self.content += s
    stream = MockWritableStream()
    stream.write('he')
    stream.write('ll')
    stream.write('o ')
    stream.write('world!')
    assert stream.content == 'hello world!'



# Generated at 2022-06-20 12:44:21.453538
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('aaa') == 'aaa'
    assert shitcode('aaa\x04bbb') == 'aaa?bbb'
    assert shitcode(b'aaa\x04bbb') == b'aaa?bbb'



# Generated at 2022-06-20 12:44:24.941487
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Garply:
        def write(self, s):
            return s + 5

    class Grault(Garply):
        pass

    class Fred(Grault):
        pass

    assert issubclass(Garply, WritableStream)
    assert issubclass(Grault, WritableStream)
    assert issubclass(Fred, WritableStream)



# Generated at 2022-06-20 12:44:32.370150
# Unit test for function normalize_repr
def test_normalize_repr():
    class A(object):
        pass
    a = A()
    a.foo = A()
    a.bar = [A(), A()]
    assert normalize_repr("<__main__.A object at 0xFFFF>") == "<__main__.A object>"
    assert normalize_repr("[<__main__.A object at 0xFFFF>, <__main__.A object at 0xFFFF>, <__main__.A object at 0xFFFF>]") == "[<__main__.A object>, <__main__.A object>, <__main__.A object>]"
    
    
    
    
    

# Generated at 2022-06-20 12:44:47.507743
# Unit test for function get_repr_function
def test_get_repr_function():
    assert normalize_repr(
        'hello'
    ) == 'hello'

    assert normalize_repr(
        'hello at 0x1234'
    ) == 'hello'

    assert normalize_repr(
        'hello at 0x1234 and 0x5678'
    ) == 'hello'

    assert normalize_repr(
        'hello at 0x1234 and 0x5678 at 0x9ABC'
    ) == 'hello'

    assert get_repr_function(1, ((int, str), lambda x: 'int or str')) == repr

    assert get_repr_function(1.0, ((int, str), lambda x: 'int or str')) == (
        lambda x: 'int or str'
    )


# Generated at 2022-06-20 12:44:51.022358
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(2) == (2,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple({3, 4}) == (3, 4)
    assert ensure_tuple({5: 6}) == ({5: 6},)




# Generated at 2022-06-20 12:44:54.817890
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', None) == 'abc'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 2) == 'ab...'
    assert truncate('abc', 1) == 'a...'
    assert truncate('abc', 0) == '...'
    assert truncate('abc', -1) == '...'
    assert truncate('abcde', 4) == 'a...e'
    assert truncate('abcdef', 4) == 'a...f'



# Generated at 2022-06-20 12:45:00.737353
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(['abc', 'def']) == ('abc', 'def')
    assert ensure_tuple(('abc', 'def')) == ('abc', 'def')
    assert ensure_tuple({'abc', 'def'}) == ('abc', 'def')

# Generated at 2022-06-20 12:45:10.340123
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, [(int, lambda x: 'int number')]) == (
                                                              lambda x: 'int number')
    assert get_repr_function(1, [(str, lambda x: 'str number')]) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 'true number')]) == (
                                                             lambda x: 'true number')
    assert get_repr_function('1', [(int, lambda x: 'int number')]) == repr
    assert get_repr_function('1', [(str, lambda x: 'str number')]) == (
                                                              lambda x: 'str number')

# Generated at 2022-06-20 12:45:13.763014
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'\u20ac') == '?'
    assert shitcode(u'\N{euro sign}') == '?'
    assert shitcode('\xfe') == '?'
    assert shitcode('\xff') == '?'
    assert shitcode('\x80') == '?'
    assert shitcode('\x81') == '?'



# Generated at 2022-06-20 12:45:24.956516
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert (get_shortish_repr(1) == '1')
    assert (get_shortish_repr(1, max_length=2) == '1')
    assert (get_shortish_repr(1, max_length=1) == '1')
    assert (get_shortish_repr(1, max_length=1) == '1')
    assert (get_shortish_repr(1, max_length=0) == '')
    assert (get_shortish_repr(1, max_length=-1) == '')
    assert (get_shortish_repr((1, 2, 3), max_length=8) == '(1, 2, 3)')

# Generated at 2022-06-20 12:45:28.920473
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyClass(WritableStream):
        def write(self, s): pass
    MyClass()



from .pycompat import PY2, PY3




if PY2:
    from .pycompat import get_default_encoding
else:
    def get_default_encoding():
        return None

# Generated at 2022-06-20 12:45:35.913476
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert isinstance(MyWritableStream(), WritableStream)
    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(None, WritableStream)
    class NotWritableStream(object): pass
    assert not issubclass(NotWritableStream, WritableStream)
    class MyWritableStream(object):
        @staticmethod
        def write(s): pass
    assert not issubclass(MyWritableStream, WritableStream)


TEST_REPR_RE = re.compile(r' at 0x[a-f0-9A-F]{4,}')


# Generated at 2022-06-20 12:45:40.801109
# Unit test for function truncate
def test_truncate():
    assert truncate('abcde', 4) == 'abc...'
    assert truncate('abcde', 5) == 'abcde'
    assert truncate('abcde', 6) == 'abcde'
    assert truncate('abcde', 7) == 'abcde'
    assert truncate('abcde', None) == 'abcde'
    assert truncate('abcde', 0) == ''



# Generated at 2022-06-20 12:45:50.879813
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass
    class E(C, B): pass
    class F(D, E): pass

    assert(issubclass(WritableStream, F))

# Generated at 2022-06-20 12:45:57.394989
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('this is a cute function') \
        == 'this is a cute function'
    assert get_shortish_repr('this is a cute function', max_length=3) \
        == 'thi'
    assert get_shortish_repr('this is a cute function', max_length=8) \
        == 'this is'
    assert get_shortish_repr('this is a cute function', max_length=10) \
        == 'this is a'
    assert get_shortish_repr('this is a cute function', max_length=11) \
        == 'this is a c'
    assert get_shortish_repr('this is a cute function', max_length=12) \
        == 'this is a cu'

# Generated at 2022-06-20 12:46:07.095794
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(u'Hello, world!', max_length=30) == \
                                                          u'Hello, world!'
    assert get_shortish_repr(u'Hello, world!', max_length=13) == \
                                                             u'Hello,...d!'
    assert get_shortish_repr(u'Hello, world!', max_length=13, normalize=True) == \
                                                          u'Hello,...orld!'

    class Foo(object):
        def __repr__(self):
            return '<Foo>'

    assert get_shortish_repr(Foo(), max_length=13, normalize=True) == '<Foo>'

    class Bar(object):
        pass


# Generated at 2022-06-20 12:46:09.396007
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import check
    from .pycompat import StringIO
    w = WritableStream()
    w.write('')
    b = check(False, isinstance, w, StringIO)

# Generated at 2022-06-20 12:46:15.166708
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(6) == '6'
    assert get_shortish_repr((1, 2, 3)) == '(1, 2, 3)'
    assert get_shortish_repr(object) == "<class 'object'>"
    assert get_shortish_repr(get_shortish_repr, max_length=2) == '<fu...>'

    class A(object):
        def __repr__(self):
            return 'A'
    a = A()
    assert get_shortish_repr(a) == 'A'

    class B(object):
        def __repr__(self):
            return 'B'
    b = B()

# Generated at 2022-06-20 12:46:18.858914
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('helló') == 'hell?'
    assert shitcode(u'helló') == 'hell?'
    assert shitcode(u'òòò') == '???'



# Generated at 2022-06-20 12:46:20.486426
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert 'write' in WritableStream.__abstractmethods__



# Generated at 2022-06-20 12:46:22.110159
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('אושר') == shitcode(u'אושר') == '?????'



# Generated at 2022-06-20 12:46:32.440391
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr("hello world",
                             normalize=False, max_length=None) == \
                                                             "hello world"
    assert get_shortish_repr("hello world xxx",
                             normalize=False, max_length=None) == \
                                                        "hello world xxx"
    assert get_shortish_repr("hello world",
                             normalize=False, max_length=12) == \
                                                             "hello world"
    assert get_shortish_repr("hello world xxx",
                             normalize=False, max_length=12) == \
                                                        "hello world..."


# Generated at 2022-06-20 12:46:34.152854
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X:
        def write(self, s):
            return s + ' is cool'
    assert issubclass(X, WritableStream)



# Generated at 2022-06-20 12:46:45.821151
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('moo') == 'moo'
    assert normalize_repr('moo at 0x1234') == 'moo'
    assert normalize_repr('moo at 0x2345') == 'moo'
    assert normalize_repr('moo at 0xa0b0c0d0') == 'moo'
    assert normalize_repr('moo at 0x12384x') == 'moo at 0x12384x'

# Generated at 2022-06-20 12:46:54.120568
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, custom_repr=((int, int.__repr__),)) == \
                                                                   int.__repr__
    assert get_repr_function(None, custom_repr=((unicode, unicode.__repr__),)) == \
                                                                unicode.__repr__
    assert get_repr_function(0, custom_repr=((int, int.__repr__),)) == \
                                                                   int.__repr__
    assert get_repr_function(u'hey', custom_repr=((unicode, unicode.__repr__),)) == \
                                                                unicode.__repr__

# Generated at 2022-06-20 12:46:59.857548
# Unit test for function truncate

# Generated at 2022-06-20 12:47:10.550571
# Unit test for function normalize_repr
def test_normalize_repr():
    import collections

    class C(collections.abc.Iterable):
        def __repr__(self):
            return '<1234567890>'
    c = C()

    class D(collections.abc.Iterable):
        def __repr__(self):
            return '<1234567890 at 0x1234567890>'

    d = D()

    class E(collections.abc.Iterable):
        def __init__(self):
            pass

    e = E()

    assert normalize_repr(repr(c)) == '<1234567890>'
    assert normalize_repr(repr(d)) == '<1234567890 at 0x...>'

    # Test that it's robust to a `__repr__` that doesn't return a string.
    assert normalize

# Generated at 2022-06-20 12:47:11.882656
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout.__class__, WritableStream)

# Generated at 2022-06-20 12:47:19.609390
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = ((int, lambda x: 'int: %s' % x),
                   (str, lambda x: 'str: %s' % repr(x)),
                   (list, lambda x: 'list: %s' % repr(x)))

    assert get_repr_function(5, custom_repr) == custom_repr[0][1]
    assert get_repr_function('foo', custom_repr) == custom_repr[1][1]
    assert get_repr_function([5, 'foo'], custom_repr) == custom_repr[2][1]


if __name__ == '__main__':
    test_get_repr_function()

# Generated at 2022-06-20 12:47:21.110362
# Unit test for function shitcode
def test_shitcode():
    s = 'hello שלום'
    assert shitcode(s) == 'hello ???'

# Generated at 2022-06-20 12:47:27.010829
# Unit test for function shitcode
def test_shitcode():

    assert shitcode(u'♥') == u'?'
    assert shitcode(u'♥'.encode('utf-8')) == u'?'
    assert shitcode(u'a') == u'a'
    assert shitcode(u'a♥') == u'a?'
    assert shitcode(u'♥a') == u'?a'
    assert shitcode(u'♥♥♥') == u'???'



# Generated at 2022-06-20 12:47:36.588041
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1.0) == '1.0'
    assert get_shortish_repr('a') == "'a'"
    assert get_shortish_repr('a' * 10) == "'aaaaaaaaaa'"
    assert normalize_repr('hello at 0xf5') == 'hello'
    assert (get_shortish_repr(b'\x01\x02\x03\x04\x05' * 100, max_length=30,
                              normalize=True) ==
                                          b"b'\\x01\\x02\\x03\\x04\\x05...")

# Generated at 2022-06-20 12:47:44.424099
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=50) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr('bla', max_length=50) == 'bla'
    assert get_shortish_repr('bla', max_length=4) == 'bla'
    assert get_shortish_repr('bla', max_length=3) == 'bl...'
    assert get_shortish_repr('bla', max_length=2) == 'bl...'
    assert get_shortish_repr('bla', max_length=1) == 'b...'



# Generated at 2022-06-20 12:48:05.282355
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('אאאאאאאאאאאאאאאאאאאאאאאאאאאאאאאאאאאאאאאאא') == (
        '???????????????????????????????????????'
    )

    assert shitcode('test') == 'test'

    assert shitcode('test\r\n') == 'test'

    assert shitcode('test\r') == 'test'

    assert shitcode('test\n') == 'test'

    assert shitcode('test\r\x00\n') == 'test\x00'
