

# Generated at 2022-06-20 12:38:06.164357
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Something(WritableStream):
        pass
    assert issubclass(Something, WritableStream)



# Generated at 2022-06-20 12:38:15.466146
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hihi') == normalize_repr('hihi at 0x12345678') == \
                                                                          'hihi'
    assert normalize_repr('') == ''
    assert normalize_repr('hihi at 0x12345678') == 'hihi'
    assert normalize_repr('hihi at 0x12345678 at at 0x12345678') == \
                                                              'hihi at at 0x12345678'
    assert normalize_repr('hihi at 0x12345678 at') == 'hihi at'
    assert normalize_repr('hihi at 0x12345678 at 0x12345678') == \
                                                        'hihi at 0x12345678'



# Generated at 2022-06-20 12:38:18.480540
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('foo') == 'foo'
    assert shitcode('f\x00o\x00o') == 'f??o??o'
    assert shitcode('\x8b\x9c') == '??'



# Generated at 2022-06-20 12:38:21.476676
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeFile(WritableStream):
        def __init__(self):
            self.text = ''

        def write(self, s):
            self.text += s

    f = FakeFile()
    f.write('hi')
    assert f.text == 'hi'



# Generated at 2022-06-20 12:38:23.716276
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == 'abc'
    assert shitcode(u'\u05d0') == '?'
    assert shitcode(u'\x7f') == '?'



# Generated at 2022-06-20 12:38:34.534592
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(3) == '3'
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=4) == "'he...'"
    assert get_shortish_repr('hello', max_length=0) == '...'
    assert get_shortish_repr('hello', max_length=1) == '...'
    assert get_shortish_repr('hello', max_length=2) == '...'
    assert get_shortish_repr('hello', max_length=3) == '...'
    assert get_shortish_repr('hello', max_length=4) == "'he...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"
   

# Generated at 2022-06-20 12:38:39.936709
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghi', 5) == '...hi'
    assert truncate('abcdefghi', 8) == 'a...hi'
    assert truncate('abcdefghi', 9) == 'ab...hi'
    assert truncate('abcdefghi', 10) == 'abcdefghi'
    assert truncate('abcdefghi', None) == 'abcdefghi'
    assert truncate('abcdefghi', 11) == 'abcdefghi'



# Generated at 2022-06-20 12:38:50.275612
# Unit test for function truncate
def test_truncate():
    assert truncate(u'hello, world!', max_length=None) == u'hello, world!'
    assert truncate(u'hello, world!', max_length=13) == u'hello, world!'
    assert truncate(u'hello, world!', max_length=12) == u'hello, worl...'
    assert truncate(u'hello, world!', max_length=11) == u'hel...orld!'
    assert truncate(u'hello, world!', max_length=10) == u'he...orld!'
    assert truncate(u'hello, world!', max_length=9) == u'h...orld!'
    assert truncate(u'hello, world!', max_length=8) == u'...orld!'

# Generated at 2022-06-20 12:38:58.014246
# Unit test for function get_repr_function
def test_get_repr_function():
    class MyType1(object): pass
    class MyType2(object): pass
    def my_custom_repr_for_type1(x):
        assert isinstance(x, MyType1)
        return 'type1 is {}'.format(x)
    def my_custom_repr_for_type2(x):
        assert isinstance(x, MyType2)
        return 'type2 is {}'.format(x)
    def my_custom_repr_for_type2_again(x):
        assert isinstance(x, MyType2)
        return 'type2 again is {}'.format(x)
    def my_custom_repr_for_three(x):
        return 'three is {}'.format(x)

# Generated at 2022-06-20 12:39:04.723860
# Unit test for function normalize_repr
def test_normalize_repr():
    def test(obj):
        print('{!r} -> {!r}'.format(obj, normalize_repr(repr(obj))))
    test([1,2,3])
    test(['a', 'b', 'c'])
    test(set([1, 2, 3]))
    test({'a': 1, 'b': 2})
    test((1, 2, 3))
    test({'a': 1, 'b': 2, 'c': 3})



# Generated at 2022-06-20 12:39:12.593997
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(True) == (True,)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(i for i in range(3)) == (0, 1, 2)
    assert ensure_tuple(iter((1, 2))) == (1, 2)
    assert ensure_tuple('abcd') == ('abcd',)
    assert ensure_tuple(1234) == (1234,)
    assert ensure_tuple('') == ('',)

# Generated at 2022-06-20 12:39:18.765499
# Unit test for function normalize_repr
def test_normalize_repr():
    import nose
    class Test(object):
        pass

    nose.tools.assert_true(
        re.match(
            u'<.*\.Test object at 0x[0-9a-f]{4,}>',
            repr(Test())
        )
    )
    nose.tools.assert_equal(
        normalize_repr(repr(Test())),
        u'<.*\.Test object>'
    )

# Generated at 2022-06-20 12:39:20.999992
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass
    assert isinstance(A(), WritableStream)



# Generated at 2022-06-20 12:39:30.446443
# Unit test for function get_repr_function
def test_get_repr_function():

    import math
    import sys
    from .python_toolbox import cute_testing

    infinity = float('inf')
    nan = float('nan')

    def positive_infinity_repr(x):
        if x == infinity:
            return '∞'
        else:
            return repr(x)

    custom_repr = (
        (
            lambda x: x == infinity,
            positive_infinity_repr
        ),
        (
            lambda x: x is sys.stdout,
            lambda x: '<stdout>'
        ),
        (
            lambda x: x is sys.stderr,
            lambda x: '<stderr>'
        ),
        (
            math.atan2,
            lambda f: 'atan2'
        ),
    )


# Generated at 2022-06-20 12:39:40.145167
# Unit test for function get_repr_function
def test_get_repr_function():

    # This is a dictionary which will be used to recreating the functions
    # and instances used in the test.
    # Important note: it was assumed that the repr should not get any of the
    # local variables values.
    repr_dict = {
        'class_': type(None),
        'instance': None,
        'type_': type,
        'type_instance': type(None),
    }

    class Class(object):
        pass

    class Instance(object):
        pass

    type_ = type(Class)

    type_instance = type(Instance)

    repr_dict = {
        'class_': Class,
        'instance': Instance(),
        'type_': type_,
        'type_instance': type_instance,
    }

    # The tests cases.
    # The idea is to use the dictionary

# Generated at 2022-06-20 12:39:42.900961
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple([3]) == (3,)
    assert ensure_tuple((3,)) == (3,)
    assert ensure_tuple(xrange(3)) == (0, 1, 2,)
    assert ensure_tuple(xrange(3)) == (0, 1, 2,)
    assert ensure_tuple("ab") == ('a', 'b')

# Generated at 2022-06-20 12:39:50.897125
# Unit test for function truncate
def test_truncate():
    assert truncate('foo', None) == 'foo'
    assert truncate('foo', 2) == 'foo'
    assert truncate('foo', 3) == 'foo'
    assert truncate('foo', 5) == 'foo'
    assert truncate('foo', 6) == 'foo'
    assert truncate('foo', 7) == 'foo'
    assert truncate('foo', -1) == 'foo'
    assert truncate('foo', 0) == ''
    assert truncate('foo', 1) == 'f'
    assert truncate('foo', 2) == 'fo'
    assert truncate('foo', 3) == 'foo'
    assert truncate('foo', 4) == 'foo'
    assert truncate('foo', 5) == 'foo'
    assert truncate('foo', 6) == 'foo'
    assert truncate

# Generated at 2022-06-20 12:39:52.686373
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    MyWritableStream().write('')


# Generated at 2022-06-20 12:39:56.577441
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('a string at 0x1325') == 'a string'
    assert normalize_repr('another string at 0x134525') == 'another string'
    assert normalize_repr('0x1526') == '0x1526'
    assert normalize_repr('string') == 'string'


if __name__ == '__main__':
    test_normalize_repr()

# Generated at 2022-06-20 12:40:05.504951
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('a') == "'a'"
    assert get_shortish_repr('abcdefghijklmno') == "'abcdefghijklmno'"
    assert get_shortish_repr('abcdefghijklmnop') == "'abcdefghi...nop'"
    assert get_shortish_repr('abcdefghijklmnop', max_length=2) == "'a...'"
    assert get_shortish_repr(b'abcdefghijklmnop', max_length=2) == "b'a...'"

# Generated at 2022-06-20 12:40:18.159120
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    def get_b_repr(b): return 'b'
    def get_a_repr(a): return 'a'
    def get_x_repr(x): return 'x'
    assert get_repr_function(B(), (
        (B, get_b_repr),
        (A, get_a_repr),
        (object, get_x_repr)
    )) is get_b_repr
    assert get_repr_function(A(), (
        (B, get_b_repr),
        (A, get_a_repr),
        (object, get_x_repr)
    )) is get_a_repr

# Generated at 2022-06-20 12:40:23.353980
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(x for x in (1, 2)) == (1, 2)

# Generated at 2022-06-20 12:40:32.754734
# Unit test for function truncate
def test_truncate():
    # Check that a short string is not truncated
    short_string = 'my short string'
    assert truncate(short_string, 50) == short_string
    # Test strings that truncate in the middle
    assert truncate('this is a long string that should be truncated', 20) == \
                                                'this is a long...ated'
    assert truncate('this is a LONG string that should be truncated', 20) == \
                                                'this is a L...ated'
    assert truncate('this is a long string that should be truncated', 10) == \
                                                'th...ated'
    assert truncate('this is a LONG string that should be truncated', 10) == \
                                                'th...ated'
    # Test strings that truncate at the beginning

# Generated at 2022-06-20 12:40:36.798840
# Unit test for function shitcode
def test_shitcode():
    s = 'קוראת לך השכנה. קוראת לך השכנה.'
    s = s.encode('cp1255').decode('cp866')
    assert shitcode(s) == '??? ????? ??????.? ??? ????? ??????.'

# Generated at 2022-06-20 12:40:44.498433
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<cool.package.type object at 0x7ffa3f3e23d0>') == \
                                                '<cool.package.type object>'
    assert normalize_repr('<cool.package.type object at 0x7ffa3f3e23d0>   ') == \
                                                '<cool.package.type object>'
    assert normalize_repr('   <cool.package.type object at 0x7ffa3f3e23d0>') == \
                                                '<cool.package.type object>'
    assert normalize_repr('   <cool.package.type object at 0x7ffa3f3e23d0>   ') == \
                                                '<cool.package.type object>'

# Generated at 2022-06-20 12:40:45.871609
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'



# Generated at 2022-06-20 12:40:54.225825
# Unit test for function get_repr_function
def test_get_repr_function():

    class x(object): pass
    class y(x): pass
    class z(y): pass

    assert get_repr_function(z(), (
        (y, lambda x: 'y!!!'),
    ))(z()) == 'y!!!'
    assert get_repr_function(z(), (
        (x, lambda x: 'x!!!'),
    ))(z()) == 'x!!!'
    assert get_repr_function(z(), (
        (z, lambda x: 'z!!!'),
    ))(z()) == 'z!!!'

    assert get_repr_function(z(), (
        (x, lambda x: 'x!!!'),
        (y, lambda x: 'y!!!'),
    ))(z()) == 'y!!!'

# Generated at 2022-06-20 12:41:00.029809
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('abcde') == 'abcde'
    assert normalize_repr('abcde at 0x12345') == 'abcde'
    assert normalize_repr('abcde at 0x1234567890a') == 'abcde'
    assert normalize_repr('abcde at 0x1234567890a at 0x1234567890a') == \
                                                       'abcde at 0x1234567890a'

# Generated at 2022-06-20 12:41:11.042710
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import collections

    # Case 1: check that custom repr works
    my_dict = collections.OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    assert get_shortish_repr(
        my_dict,
        custom_repr=(
            (collections.OrderedDict, lambda x: 'OrderedDict' + str(list(x))),
        )
    ) == 'OrderedDict[(\'a\', 1), (\'b\', 2), (\'c\', 3)]'

    # Case 2: check that "normalize" works
    my_dict = collections.OrderedDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-20 12:41:18.385702
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', None) == 'hello'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 4) == 'hell'
    assert truncate('hello', 3) == 'hel'
    assert truncate('hello', 2) == 'he'
    assert truncate('hello', 1) == 'h'
    assert truncate('hello', 0) == ''
    assert truncate('hello', -1) == ''
    assert truncate('hello', -2) == ''
    assert truncate('hello', -3) == ''
    assert truncate('hello', -4) == ''
    assert truncate('hello', -5) == ''
    assert truncate('hello', -6) == ''
    assert truncate('hello', -7) == ''



# Generated at 2022-06-20 12:41:31.788018
# Unit test for function ensure_tuple
def test_ensure_tuple():
    
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple(5) != 5
    
    assert ensure_tuple((5,)) == (5,)
    assert ensure_tuple((5,)) != 5
    
    assert ensure_tuple([5]) == (5,)
    assert ensure_tuple([5]) != 5
    
    assert ensure_tuple(('5',)) == ('5',)
    assert ensure_tuple(('5',)) != '5'


# Generated at 2022-06-20 12:41:40.408502
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .test_tools import assert_true, assert_false
    from io import StringIO

    class Subclass(WritableStream):
        def write(self, s):
            pass

    class Subclass2(WritableStream):
        def write(self, s):
            return s * 2

    class Subclass3(WritableStream):
        def foo(self, s):
            return s * 2

    class Subclass4:
        def write(self, s):
            return s * 2

    assert_true(issubclass(sys.stdout.__class__, WritableStream))
    assert_true(issubclass(Subclass, WritableStream))
    assert_true(issubclass(Subclass2, WritableStream))
    assert_true(issubclass(Subclass4, WritableStream))

# Generated at 2022-06-20 12:41:48.098116
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    s = '123456789012345678901234'
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(s) == s
    assert get_shortish_repr(s, max_length=5) == '1234...'
    assert get_shortish_repr(s, max_length=5, normalize=True) == '1234...'
    assert get_shortish_repr(1.5, custom_repr=[(int, float.hex)]) == '0x1.8000000000000p+0'
    assert get_shortish_repr(1.5, max_length=5, custom_repr=[(int, float.hex)]) == '0x1.8...'

# Generated at 2022-06-20 12:41:53.755604
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('\x80') == '\x80'
    assert shitcode(u'a') == 'a'
    assert shitcode(u'\x80') == '?'
    assert shitcode(bytearray('\x80')) == '\x80'
    assert shitcode(b'\x80') == '\x80'



# Generated at 2022-06-20 12:42:01.065131
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('this is my string') == 'this is my string'

    assert get_shortish_repr(lambda: 1) == '<function <lambda> at 0x' \
                                          '048AFB90>'

    assert get_shortish_repr('this is my string', (str, str)) == \
                                                             'this is my string'

    assert get_shortish_repr(True, (bool, lambda x: 'yes')) == 'yes'

    assert get_shortish_repr('this is my string', custom_repr=(),
                             max_length=11) == 'this is my...'


# Generated at 2022-06-20 12:42:07.040601
# Unit test for function truncate
def test_truncate():
    assert truncate(u'Hello', 5) == u'Hello'
    assert truncate(u'Hello', 4) == u'H...'
    assert truncate(u'Hello', 3) == u'...'
    assert truncate(u'Hello', 2) == u'..'
    assert truncate(u'Hello', 1) == u'.'



# Generated at 2022-06-20 12:42:11.605455
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'אבגדה') == '????'
    assert shitcode(u'\u2302') == '?'
    assert shitcode(u'\u0000') == '\x00'
    assert shitcode(u'\xab') == '\xab'
    assert shitcode(u'hello') == 'hello'



# Generated at 2022-06-20 12:42:17.726480
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('b', []) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function('', [('', str)]) is str
    assert get_repr_function({}, [(dict, str), (int, str)]) is str
    assert get_repr_function(set(), [(dict, str), (int, str)]) is repr
    assert get_repr_function(set(), [(dict, str), (set, str)]) is str

# Generated at 2022-06-20 12:42:26.265529
# Unit test for function truncate
def test_truncate():
    s = '123456'
    assert truncate(s, None) == s
    assert truncate(s, len(s) + 1) == s
    assert truncate(s, len(s)) == s
    assert truncate(s, len(s) - 1) == '1...6'
    assert truncate(s, len(s) - 2) == '1...6'
    assert truncate(s, len(s) - 3) == '12...6'
    assert truncate(s, len(s) - 5) == '12...6'
    assert truncate(s, len(s) - 6) == '12...6'
    assert truncate('', 5) == ''

# Generated at 2022-06-20 12:42:34.273237
# Unit test for function get_repr_function
def test_get_repr_function():
    global_repr_function = get_repr_function(None, ())
    assert global_repr_function is repr

    class A: pass
    class B: pass
    class C(A): pass
    class D(C, B): pass
    class E(D): pass

    class F(object): pass
    class G(object): pass
    class H(F): pass
    class I(H, G): pass
    class J(I): pass

    assert get_repr_function(A(), ()) is repr
    assert get_repr_function(B(), ()) is repr
    assert get_repr_function(C(), ()) is repr
    assert get_repr_function(D(), ()) is repr
    assert get_repr_function(E(), ()) is repr
    assert get_repr_function(F(), ()) is repr

# Generated at 2022-06-20 12:43:00.098196
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'hello') == 'hello'
    # python3
    assert shitcode(b'hello') == 'hello'
    # python2
    assert shitcode(b'hello') == shitcode(u'hello')
    assert shitcode(b'\xbd\xb2\x3d\xbc\x20\xe2\x8c\x98') == '??? ???~'

# Generated at 2022-06-20 12:43:05.425645
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(('a', 'b')) == ('a', 'b')
    assert ensure_tuple(('a',)) == ('a',)
    assert ensure_tuple('a') == ('a',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(('a',),) == (('a',),)


test_ensure_tuple()

# Generated at 2022-06-20 12:43:12.029966
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, []) == repr

# Generated at 2022-06-20 12:43:20.596214
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A:
        def __init__(self, writer):
            self.writer = writer

        def write(self, item):
            self.writer.write(item)

    assert WritableStream.__subclasshook__(A)

    class B:
        def __init__(self, writer):
            self.writer = writer

        def write(self, item):
            self.writer.write(item)

        def flush(self):
            pass

    assert WritableStream.__subclasshook__(B)

    class C:
        def __init__(self, writer):
            self.writer = writer

        def write(self, item):
            self.writer.write(item)

        def flush(self):
            pass

        def close(self):
            pass


# Generated at 2022-06-20 12:43:22.495488
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('123') == '123'
    assert normalize_repr('123 at 0x12345678') == '123'

# Generated at 2022-06-20 12:43:27.034181
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyWritableStream(WritableStream):
        def write(self, s):
            return s

    assert isinstance(MyWritableStream(), WritableStream)

    class MyWritableStream2:
        def write(self, s):
            return s

    assert not isinstance(MyWritableStream2(), WritableStream)

# Generated at 2022-06-20 12:43:32.553609
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.buffer = b''

        def write(self, s):
            self.buffer += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write(b'abc')
    assert my_writable_stream.buffer == b'abc'

# Generated at 2022-06-20 12:43:40.562802
# Unit test for function get_repr_function
def test_get_repr_function():

    assert get_repr_function(None, (
        (lambda item: isinstance(item, type(None)), lambda item: 'None'),
        (lambda item: isinstance(item, int), lambda item: 'int'),
        (lambda item: isinstance(item, type(float)), lambda item: 'float'),
    ))(None) == 'None'

    assert get_repr_function(1, (
        (lambda item: isinstance(item, type(None)), lambda item: 'None'),
        (lambda item: isinstance(item, int), lambda item: 'int'),
        (lambda item: isinstance(item, type(float)), lambda item: 'float'),
    ))(1) == 'int'


# Generated at 2022-06-20 12:43:47.749462
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(['a', 'b', 'c']) == ('a', 'b', 'c')
    assert ensure_tuple(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(42) == (42,)



# Generated at 2022-06-20 12:43:57.897919
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', 3) == 'hel'
    assert truncate('hello', 4) == 'hell'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 6) == 'hello'
    assert truncate('hello', 7) == 'hello'
    assert truncate('hello', 8) == 'hello'
    assert truncate('hello', 9) == 'hello'
    assert truncate('hello', 10) == 'hello'
    assert truncate('hello', 11) == 'hello'
    assert truncate('hello', 12) == 'hello'
    assert truncate('hello', 13) == 'hello'
    assert truncate('hello', 14) == 'hello'
    assert truncate('hello', 15) == 'hello'

    assert truncate('hello', 2) == 'he'
    assert trunc

# Generated at 2022-06-20 12:44:46.378127
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'f') == u'f'
    assert shitcode(u'\x00') == u'?'
    assert shitcode(u'\x00\x00') == u'??'
    assert shitcode(u'\x00\x00f') == u'??f'
    assert shitcode(u'\x00\x00\x00') == u'???'
    assert shitcode(u'\x01\x02\x03\x04\x05') == u'?????'.encode('utf-8')
# end of test_shitcode



# Generated at 2022-06-20 12:44:52.825089
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x1234') == 'hello'
    assert normalize_repr('hello at 0x12345678') == 'hello'
    assert normalize_repr('hello at 0x12345678 at 0x1234') == 'hello at 0x1234'
    assert normalize_repr('hello at 0x12345678 at 0x12345678') == \
                                                             'hello at 0x12345678'



# Generated at 2022-06-20 12:44:54.587401
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class A(WritableStream):

        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

# Generated at 2022-06-20 12:45:01.140851
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [(str, lambda x: 'ho'), (int, lambda x: 'hey')]
    for item, expected_representation in (
        ('', 'ho'),
        (1, 'hey'),
        (1.6, repr(1.6)),
    ):
        assert get_repr_function(item, custom_repr)(item) == expected_representation



# Generated at 2022-06-20 12:45:10.708423
# Unit test for function shitcode
def test_shitcode():

    def test_shitcode(s, expected_result):
        result = shitcode(s)
        assert result == expected_result

    test_shitcode('foo', 'foo')
    test_shitcode('f?o', 'f?o')
    test_shitcode('f\x00o', 'f?o')
    test_shitcode('f\x00o', 'f?o')

    test_shitcode('f\xFFoo', 'f?oo')
    test_shitcode('f\xFF\xFFoo', 'f??oo')
    test_shitcode('f\xFF\xFF\xFFoo', 'f???oo')
    test_shitcode('f\xFF\xFF\xFF\xFFoo', 'f????oo')

# Generated at 2022-06-20 12:45:15.868835
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1234567890, max_length=4) == '123...'
    assert get_shortish_repr((1, 2, 3), max_length=8) == '(1, 2, 3)'
    assert get_shortish_repr((1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12),
                             max_length=8) == ('(1, 2, 3, 4,...'
                                               if sys.version_info[0] == 3
                                               else '(1, 2, 3, ...')

# Generated at 2022-06-20 12:45:24.566071
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(WritableStream):
        pass

    assert not issubclass(Foo, WritableStream)
    Foo.write = lambda self, s: print(s)
    assert issubclass(Foo, WritableStream)
    # TODO: Test that the returned value of `__subclasshook__` is indeed
    # implemented, meaning that if it returns true, then after writing all the
    # methods, the subclass will still be considered a subclass of
    # `WritableStream`. (otherwise the subclass hook wouldn't be any useful as a
    # shortcut...)



# Generated at 2022-06-20 12:45:28.478009
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'אבג') == u'???'
    assert shitcode(u'µ') == u'?'
    assert shitcode(u'\u2603') == u'?'
    assert shitcode(u'€') == u'?'

# Generated at 2022-06-20 12:45:29.599227
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout.__class__, WritableStream)

# Generated at 2022-06-20 12:45:30.723562
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Mock:
        def write(self, s):
            pass

# Generated at 2022-06-20 12:46:57.450291
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X(WritableStream):
        def write(self, s): pass
    assert issubclass(X, WritableStream)




# Generated at 2022-06-20 12:47:01.406567
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(123) == (123,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)

# Generated at 2022-06-20 12:47:11.883373
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(2) == (2,)
    assert ensure_tuple((2,)) == (2,)
    assert ensure_tuple((2, 3)) == (2, 3)
    assert ensure_tuple([2, 3]) == (2, 3)
    assert ensure_tuple([2]) == (2,)
    assert ensure_tuple([]) == ()
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple('abcdef') == ('abcdef',)
    assert ensure_tuple('abcdefg') == ('abcdefg',)
    assert ensure_tuple((1, (2, 3), [4, (5, 6)])) == \
                                             (1, (2, 3), [4, (5, 6)])

# Generated at 2022-06-20 12:47:17.225632
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hi') == "'hi'"
    assert get_shortish_repr('hi', max_length=3) == "'h..."
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr([1, 2, 3], max_length=5) == '[1, 2...'


# Unit tests for function truncate

# Generated at 2022-06-20 12:47:20.082004
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(
        'asd',
        custom_repr=(
            (str, lambda x: '<STR>'),
            (int, lambda x: '<INT>')
        )
    ) is str


# Generated at 2022-06-20 12:47:22.731798
# Unit test for function normalize_repr
def test_normalize_repr():
    return normalize_repr('<function get_shortish_repr at 0x000001D28BB76E18>') == '<function get_shortish_repr>'

# Generated at 2022-06-20 12:47:27.536852
# Unit test for function ensure_tuple
def test_ensure_tuple():
    class MyIterable(object):
        def __iter__(self):
            yield 1
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple(MyIterable()) == (1,)

# Generated at 2022-06-20 12:47:31.163914
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('hello\x00') == 'hello\x00'
    assert shitcode('hello\x01') == 'hello?'
    assert shitcode('hello\xFF') == 'hello?'

# Generated at 2022-06-20 12:47:38.444433
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr(u'\u05e9\u05dc\u05d5\u05dd') == \
                                                      u'\u05e9\u05dc\u05d5\u05dd'
    assert normalize_repr(u'\u05e9\u05dc\u05d5\u05dd at 0x0000') == \
                                                      u'\u05e9\u05dc\u05d5\u05dd'




# Generated at 2022-06-20 12:47:44.940016
# Unit test for function truncate
def test_truncate():
    assert truncate('123456', 3) == '123...'
    assert truncate('123456', 4) == '1234...'
    assert truncate('123456', 5) == '12345...'
    assert truncate('123456', 6) == '123456'
    assert truncate(u'123456', 5) == u'12345...'
    assert truncate(u'123456', 4) == u'1234...'
    assert truncate(u'123456', 3) == u'123...'
    assert truncate(u'123456', 6) == u'123456'