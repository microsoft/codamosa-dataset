

# Generated at 2022-06-20 12:38:16.878259
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple('asdf') == ('asdf',)
    assert ensure_tuple(b'asdf') == (b'asdf',)




# Generated at 2022-06-20 12:38:22.355860
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 8) == '123456789'
    assert truncate('123456789', 7) == '1234567...'
    assert truncate('123456789', 10) == '123456789'
    assert truncate('123456789', None) == '123456789'
    assert truncate('1234567', None) == '1234567'
    assert truncate('123', None) == '123'
    assert truncate('1', None) == '1'
    assert truncate('', None) == ''
    assert truncate('123456789', 5) == '12...'
    assert truncate('123456789', 3) == '1...'

# Generated at 2022-06-20 12:38:26.477137
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'עברית') == '???'
    assert shitcode(u'A\u001aB') == 'A?B'
    assert shitcode(u'A\x7fB') == 'A?B'
    assert shitcode('A\x00B') == 'A?B'



# Generated at 2022-06-20 12:38:31.639116
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\n\r') == 'abc\n\r'
    assert shitcode(u'\u2022') == '?'
    assert shitcode(u'\u2022\u0010') == '?\x10'



# Generated at 2022-06-20 12:38:35.064400
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, [(int, lambda x: 'asdf')]) == 'asdf'
    assert get_repr_function(0.0, [(int, lambda x: 'asdf')]) != 'asdf'



# Generated at 2022-06-20 12:38:41.521534
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    get_shortish_repr(1)
    get_shortish_repr(1, max_length=10)
    get_shortish_repr((1, 2, 3), max_length=10)
    get_shortish_repr([1, 2, 3], max_length=10)
    get_shortish_repr('hello', max_length=10)
    get_shortish_repr('hello there', max_length=10)
    get_shortish_repr('hello there my friend', max_length=10)




# Generated at 2022-06-20 12:38:47.590445
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple({'a': 1}) == ({'a': 1},)



# Generated at 2022-06-20 12:38:50.468140
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestWritableStream(WritableStream):
        def write(self, s):
            assert isinstance(s, bytes)
            return len(s)
    TestWritableStream().write(b'lalala')



# Generated at 2022-06-20 12:38:54.537623
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)

# Generated at 2022-06-20 12:38:57.523930
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple([5]) == (5,)
    assert ensure_tuple((5,)) == (5,)



# Generated at 2022-06-20 12:39:10.018755
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, ((int, lambda x: 'int!'),)) == 'int!'
    assert get_repr_function(5.5, ((int, lambda x: 'int!'),)) == repr
    assert get_repr_function(5.5, ((int, 'int!'),)) == repr
    assert get_repr_function(5.5, ()) == repr

    assert get_repr_function('foo', ((int, lambda x: 'int!'),
                                     (str, lambda x: x + '!'))) == 'foo!'
    assert get_repr_function(5, ((int, lambda x: 'int!'),
                                 (str, lambda x: x + '!'))) == 'int!'

# Generated at 2022-06-20 12:39:16.956721
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'😒') == '?'
    assert shitcode(u'still works') == 'still works'
    assert shitcode(u'\u1234\u2345') == '??'
    assert shitcode(u'\u12340\u23450') == '????'
    assert shitcode(u'\u1234\u2345\u3456') == '???'
    assert shitcode(u'\u1234\u2345\u3456\u4567') == '????'



# Generated at 2022-06-20 12:39:24.658075
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from queue import Queue
    from threading import Thread
    from time import sleep, time

    class WriteCatcher(WritableStream):
        def __init__(self):
            self.queue = Queue()

        def write(self, s):
            self.queue.put(s)

    write_catcher = WriteCatcher()
    writer = Thread(target=write_catcher.write, args=('hi',))
    writer.start()
    written = write_catcher.queue.get()
    assert written == 'hi'



# Generated at 2022-06-20 12:39:32.877307
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 3) == '123...789'
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 10) == '123456789'
    assert truncate('123456789', None) == '123456789'
    assert truncate('123456789', 100) == '123456789'
    assert truncate('123456789', 0) == '123456789'
    assert truncate(123456789, 3) == '123...789'
    assert truncate(123, 3) == '123'

# Generated at 2022-06-20 12:39:40.148446
# Unit test for function get_repr_function
def test_get_repr_function():

    class A: pass
    class B(A): pass
    class C(B): pass
    class D(A): pass
    class E: pass

    def repr_A(x):
        return 'A'
    def repr_B(x):
        return 'B'
    def repr_C(x):
        return 'C'
    def repr_True(x):
        return 'True'
    def repr_False(x):
        return 'False'
    def repr_default(x):
        return 'default'

    assert get_repr_function(A(), (
        (lambda x: isinstance(x, A), repr_A),
        (lambda x: isinstance(x, D), repr_default),
        (lambda x: True, repr_default),
    )) is repr_A
    assert get_repr_

# Generated at 2022-06-20 12:39:42.313249
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("tuple at 0x123") == "tuple"


# Unit tests for function truncate

# Generated at 2022-06-20 12:39:49.241415
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr('hello', max_length=None) == "'hello'"
    assert get_shortish_repr('hello', max_length=1) == "'h'"
    assert get_shortish_repr((1, 2, 3)) == '(1, 2, 3)'
    assert get_shortish_repr((1, 2, 3), max_length=5) == '(1, 2, 3)'
    assert get_shortish_repr((1, 2, 3), max_length=4) == '(1,...'



# Generated at 2022-06-20 12:39:56.020680
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from . import this_is_a_test_file

    assert get_shortish_repr(this_is_a_test_file, max_length=None) == \
                                                    "<module 'this_is_a_test_file' from 'this_is_a_test_file.py'>"
    assert get_shortish_repr(this_is_a_test_file, max_length=6) == \
                                                    "<module 'this_is_a_test_file'..."
    assert get_shortish_repr(this_is_a_test_file, max_length=0) == '...'





# Generated at 2022-06-20 12:40:05.115446
# Unit test for function get_repr_function
def test_get_repr_function():
    get_repr_function(1, custom_repr=((int, lambda x: 'int'),))
    get_repr_function(1, custom_repr=(int, lambda x: 'int'))
    get_repr_function(1, custom_repr=((lambda x: True, lambda x: 'int')))
    get_repr_function(1, custom_repr=((lambda x: True, lambda x: 'int'),))
    get_repr_function(1, custom_repr=((lambda x: False, lambda x: 'int'),))




# Generated at 2022-06-20 12:40:10.388987
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class MyClass(object):
        def __repr__(self):
            return 'My object!'

    for item, max_length, expected_repr in (
        (MyClass(), None, 'My object!'),
        ('a' * 10, 5, 'aaaaa...'),
        ('a' * 10, 20, 'aaaaa...aaaaa'),

    ):
        assert get_shortish_repr(item, max_length=max_length) == expected_repr



# Generated at 2022-06-20 12:40:20.726905
# Unit test for function normalize_repr
def test_normalize_repr():
    return normalize_repr("<function f at 0x00000000022F2F28>") == \
                                                           "<function f at ?>"



# Generated at 2022-06-20 12:40:30.926946
# Unit test for constructor of class WritableStream
def test_WritableStream():
    # We don't really test that this class is an abstract class. It's a
    # relatively naive implementation and it's enough to test that it's not
    # instanciable and that it has the relevant `__subclasshook__`.
    class Dummy(object):
        pass
    assert issubclass(WritableStream, Dummy) is True
    assert issubclass(Dummy, WritableStream) is NotImplemented
    assert issubclass(object, WritableStream) is NotImplemented
    assert issubclass(Dummy, WritableStream) is NotImplemented
    try:
        WritableStream()
    except TypeError:
        pass
    else:
        raise Exception
    assert issubclass(object, WritableStream) is NotImplemented


# Generated at 2022-06-20 12:40:40.283099
# Unit test for function shitcode
def test_shitcode():

    assert shitcode(u'a') == u'a'
    assert shitcode(u'π') == u'?'
    assert shitcode(u'ab πd') == u'ab ?d'
    assert shitcode(u'אa') == u'??a'


if sys.version_info[0] == 2:
    def import_string(dotted_path):
        """
        Import a dotted module path and return the attribute/class designated
        by the last name in the path. Raise ImportError if the import failed.
        """
        try:
            module_path, class_name = dotted_path.rsplit('.', 1)
        except ValueError:
            msg = "%s doesn't look like a module path" % dotted_path
            raise ImportError(msg)


# Generated at 2022-06-20 12:40:45.792127
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdef', 6) == 'abcdef'
    assert truncate('abcdef', 5) == 'abcde'
    assert truncate('abcdef', 4) == 'abcd'
    assert truncate('abcdef', 3) == 'abc'
    assert truncate('abcdef', 2) == 'ab'
    assert truncate('abcdef', 1) == 'a'
    assert truncate('abcdef', 0) == ''
    assert truncate('abcdef', -1) == ''
    assert truncate('abcdef', None) == 'abcdef'



# Generated at 2022-06-20 12:40:51.782664
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 7) == '12...89'
    assert truncate('123456789', 8) == '123...89'
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', None) == '123456789'
    assert truncate('123456789', 0) == ''
    assert truncate('123456789', -7) == ''
    assert truncate('123456789', 10) == '123456789'

# Generated at 2022-06-20 12:40:55.148790
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyFile(WritableStream):
        def write(self, s):
            self.s = s

    f = MyFile()
    f.write('intro')
    assert f.s == 'intro'



# Generated at 2022-06-20 12:41:00.554863
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(42) == (42,)
    assert ensure_tuple(('Hello',)) == ('Hello',)
    assert ensure_tuple(('Hello', 'World')) == ('Hello', 'World')
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(range(20)) == tuple(range(20))
    assert ensure_tuple([5, 6, 7]) == (5, 6, 7)

# Generated at 2022-06-20 12:41:11.624491
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'this is fine') == u'this is fine'
    assert shitcode(u'שָׁלוֹם') == u'?????'
    assert shitcode(b'this is fine') == u'this is fine'
    assert shitcode(b'\x09\x0a\x0b\x0c\x0d\x20\x7f\x80\x81\x82\x83\x84') == \
           u'\t\n\x0b\x0c\r ???'
    assert shitcode(b'\x86\x87\x88\x89\x8a\x8b\x8c\x8d\x8e\x8f\x90') == \
           u'???'

# Generated at 2022-06-20 12:41:18.797250
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1.0, []) == repr
    assert get_repr_function('1', []) == repr
    assert get_repr_function((1, ), []) == repr
    assert get_repr_function([1], []) == repr
    assert get_repr_function(None, []) == repr


# Generated at 2022-06-20 12:41:28.975586
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 5) == '1...9'
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 10) == '123456789'
    assert truncate('123456789', 11) == '123456789'
    assert truncate('123456789', 8) == '12...789'
    assert truncate('123456789', 7) == '1...789'
    assert truncate('123456789', 6) == '1...9'
    assert truncate('123456789', 4) == '1...'
    assert truncate('123456789', 3) == '...'
    assert truncate('123456789', 2) == '..'

# Generated at 2022-06-20 12:41:45.978055
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(45) == '45'
    assert get_shortish_repr(45.8) == '45.8'
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr(u'a\U0001f4a9z') == "'a\\U0001f4a9z'"
    assert get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert get_shortish_repr((1, 2, 3)) == '(1, 2, 3)'
    assert get_shortish_repr({1, 2, 3}) == 'set([1, 2, 3])'

# Generated at 2022-06-20 12:41:55.808076
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyWritableStream(WritableStream):
        def __init__(self):
            self.written_texts = []
        def write(self, text):
            self.written_texts.append(text)

    writeable_stream = DummyWritableStream()
    writeable_stream.write("hello")
    assert writeable_stream.written_texts == ["hello"]

    writeable_stream = DummyWritableStream()
    writeable_stream.write("hello")
    writeable_stream.write("world")
    assert writeable_stream.written_texts == ["hello", "world"]

    writeable_stream = DummyWritableStream()
    writeable_stream.write("\n")
    assert writeable_stream.written_texts == ["\n"]

    writeable_stream = DummyWrit

# Generated at 2022-06-20 12:42:02.054085
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple(tuple(range(5))) == tuple(range(5)), \
                                                           'Succeeded for tuple'
    assert ensure_tuple(list(range(5))) == tuple(range(5)), \
                                                            'Succeeded for list'
    assert ensure_tuple(range(5)) == tuple(range(5)), \
                                                      'Succeeded for range'
    assert ensure_tuple(set((0, 1, 2))) == (0, 1, 2), \
                                          'Succeeded for set'
    assert ensure_tuple(5) == (5,), 'Succeeded for single'
    assert ensure_tuple(None) == (None,), 'Succeeded for None'



# Generated at 2022-06-20 12:42:10.977070
# Unit test for function normalize_repr
def test_normalize_repr():
    from .testing import assert_equal
    from .testing.auto_doctest_if_installed import auto_doctest_if_installed

    assert_equal(normalize_repr('a'), 'a')
    assert_equal(normalize_repr('a at 0x123'), 'a')

    class MyClass:
        def __repr__(self):
            return 'MyClass at 0x123'
    assert_equal(normalize_repr(MyClass()), 'MyClass')

    assert_equal(normalize_repr('a at 0x123 at 0x456'), 'a at 0x123')

    auto_doctest_if_installed()

# Generated at 2022-06-20 12:42:21.618336
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import pytest # type: ignore

    assert get_shortish_repr(iter([])) == ''
    assert get_shortish_repr(iter([]), max_length=20) == ''

    assert get_shortish_repr(iter([1, 2, 3]), max_length=20) == \
        '<list_iterator object at 0x...>'

    assert get_shortish_repr(iter([]),
                             custom_repr=((lambda x: True,
                                           lambda x: '(an iterator)'),)) == \
        '(an iterator)'

    assert get_shortish_repr(iter([]),
                             custom_repr=((lambda x: True,
                                           lambda x: '(an iterator)'),),
                             max_length=20) == '(an iterator)'

    assert get

# Generated at 2022-06-20 12:42:26.216393
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .stdstream import stdstreams
    assert isinstance(sys.stderr, WritableStream)
    assert isinstance(sys.stdout, WritableStream)
    assert isinstance(stdstreams['stderr'], WritableStream)
    assert isinstance(stdstreams['stdout'], WritableStream)



# Generated at 2022-06-20 12:42:27.496018
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Test(object):
        def write(self, s):
            pass

    Test()
    assert issubclass(Test, WritableStream)

# Generated at 2022-06-20 12:42:30.759568
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple(('a', 'b')) == ('a', 'b')
    assert ensure_tuple(set('abc')) == ('a', 'b', 'c')
    assert ensure_tuple(['a', 'b']) == ('a', 'b')


# Unit tests for function truncate

# Generated at 2022-06-20 12:42:41.608579
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class GoodClass(object):
        def write(self, s):
            pass
    assert issubclass(GoodClass, WritableStream)
    instance_of_good_class = GoodClass()
    assert isinstance(instance_of_good_class, WritableStream)
    del instance_of_good_class
    del GoodClass

    class BadClass(object):
        pass
    assert not issubclass(BadClass, WritableStream)
    instance_of_bad_class = BadClass()
    assert not isinstance(instance_of_bad_class, WritableStream)
    del instance_of_bad_class
    del BadClass

    class ClassWithNoneWrite(object):
        write = None
    assert not issubclass(ClassWithNoneWrite, WritableStream)
    instance_with_none_write = ClassWithNoneWrite()

# Generated at 2022-06-20 12:42:44.539771
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyWritableStream(object):
        def write(self, s):
            self.s = s
    dummy_writable_stream = DummyWritableStream()
    assert isinstance(dummy_writable_stream, WritableStream)
    assert not hasattr(dummy_writable_stream, 's')
    dummy_writable_stream.write('meow')
    assert dummy_writable_stream.s == 'meow'

# Generated at 2022-06-20 12:42:53.065264
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        pass
    A() # Shouldn't raise error



# Generated at 2022-06-20 12:42:57.376329
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class W(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s
    w = W()
    w.write('hi')
    assert w.written == 'hi'
    assert isinstance(w, WritableStream)

# Generated at 2022-06-20 12:43:00.377841
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MySubclass(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MySubclass, WritableStream)
    print('cool!')

# Generated at 2022-06-20 12:43:04.952586
# Unit test for function shitcode
def test_shitcode():
    def compare(s):
        assert shitcode(s) == s.encode('ascii', 'replace').decode('ascii')

    compare('foo')
    compare('Hello world!')
    compare('')
    compare('\x7F')
    compare('\x80')
    compare('\xFF')



# Generated at 2022-06-20 12:43:09.168611
# Unit test for function truncate
def test_truncate():
    import pytest
    assert truncate(u'hello', 100) == u'hello'
    assert truncate(u'hello', 3) == u'...'
    assert truncate(u'hello', 4) == u'he...'
    assert truncate(u'hello', 5) == u'he...'
    assert truncate(u'hello', 6) == u'hello'



# Generated at 2022-06-20 12:43:18.791962
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        pass
    assert issubclass(A, WritableStream)
    assert WritableStream.__subclasshook__(A) is True

    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)
    assert WritableStream.__subclasshook__(A) is True

    class A(WritableStream):
        def write(self, s):
            pass
        def writable(self):
            pass
    assert issubclass(A, WritableStream)
    assert WritableStream.__subclasshook__(A) is True

    class A(WritableStream):
        writable = None
    assert issubclass(A, WritableStream)
    assert WritableStream.__subclasshook__(A) is Not

# Generated at 2022-06-20 12:43:29.326499
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('tësT') == 't??T'
    assert shitcode('\x80') == '?'
    assert shitcode('\x81') == '?'
    assert shitcode('\x82') == '?'
    assert shitcode('\x83') == '?'
    assert shitcode('\x84') == '?'
    assert shitcode('\x85') == '?'
    assert shitcode('\x86') == '?'
    assert shitcode('\x87') == '?'
    assert shitcode('\x88') == '?'
    assert shitcode('\x89') == '?'
    assert shitcode('\x8a') == '?'
    assert shitcode('\x8b') == '?'
    assert shitcode('\x8c') == '?'
    assert shitcode('\x8d')

# Generated at 2022-06-20 12:43:31.669762
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X(WritableStream):
        def write(self, s):
            pass
    assert issubclass(X, WritableStream)




# Generated at 2022-06-20 12:43:34.068068
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import sys
    assert isinstance(sys.stdout, WritableStream)
    assert not isinstance('hello', WritableStream)
    assert not isinstance([], WritableStream)

# Generated at 2022-06-20 12:43:39.771246
# Unit test for function truncate
def test_truncate():
    assert truncate('12345', 5) == '12345'
    assert truncate('12345', 4) == '12345'
    assert truncate('12345', 3) == '12...'
    assert truncate('12345', 2) == '1...'
    assert truncate('12345', 1) == '...'
    assert truncate('12345', 0) == '...'
    assert truncate('12345', -1) == '...'
    assert truncate('12345', -2) == '...'
    assert truncate('12345', -3) == '...'

# Generated at 2022-06-20 12:43:51.860029
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hi') == 'hi'
    assert normalize_repr('hi at 0xC0FFEE') == 'hi'
    assert normalize_repr('hi at 0xC0FFEE at 0xB00') == 'hi at 0xB00'


if __name__ == '__main__':
    test_normalize_repr()
    print('All tests passed!')

# Generated at 2022-06-20 12:43:53.918037
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class DummyWritableStream(WritableStream):
        pass
    assert issubclass(DummyWritableStream, WritableStream)



# Generated at 2022-06-20 12:43:59.558192
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .file_writing import FileWriting

    class Thing(FileWriting):
        def write(self, s):
            pass

    assert isinstance(Thing(), WritableStream)

    class Thing(FileWriting):
        pass

    assert not isinstance(Thing(), WritableStream)

    class Thing(FileWriting):
        def write(self, x):
            return '', x

    assert not isinstance(Thing(), WritableStream)



# Generated at 2022-06-20 12:44:05.313652
# Unit test for function normalize_repr
def test_normalize_repr():
    test_input = '<python-cute.tests.settings.test_normalize_repr.<locals>.X object at 0x7fa8f7fa8f7fa8f7fa8f7fa8f7fa8f7f>'
    assert normalize_repr(test_input) == '<python-cute.tests.settings.test_normalize_repr.<locals>.X object>'

if __name__ == '__main__':
    test_normalize_repr()
    print('All tests passed!')

# Generated at 2022-06-20 12:44:07.110660
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        pass
    assert A.__subclasshook__(A) == True



# Generated at 2022-06-20 12:44:14.141404
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function('str', ((str, str),)) is str
    assert get_repr_function('str', ((str, 7),)) is repr
    assert get_repr_function(7, ((str, 7),)) is 7
    assert get_repr_function(7, ((str, 7), (1, 1))) is 1
    assert get_repr_function(list, ((type, list),)) is list

# Generated at 2022-06-20 12:44:18.070307
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x01def') == 'abc?def'
    assert shitcode('\xC3\xA9') == '??'



# Generated at 2022-06-20 12:44:21.226112
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(('hello',)) == ('hello',)
    assert ensure_tuple(['hello']) == ('hello',)
    assert ensure_tuple(('hello', 'world')) == ('hello', 'world')
    assert ensure_tuple('hello world'.split()) == ('hello', 'world')



# Generated at 2022-06-20 12:44:22.959959
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((2,)) == (2,)
    assert ensure_tuple([3]) == (3,)

# Generated at 2022-06-20 12:44:31.921201
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class E(A):
        pass
    a = A()
    b = B()
    c = C()
    d = D()
    e = E()
    assert get_repr_function(a, custom_repr=(
        (A, lambda x: 'A was here'),
        (B, lambda x: 'B too'),
        (C, lambda x: 'C as well'),
        (D, lambda x: 'D finally'),
        (E, lambda x: 'this is an E')
    )) == (lambda x: 'A was here')

# Generated at 2022-06-20 12:44:52.825206
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo(object): pass
    class Bar(object): pass
    class Baz(Bar): pass

    assert get_repr_function(3,            ()) == repr
    assert get_repr_function(3.5,          ()) == repr
    assert get_repr_function("hello",      ()) == repr
    assert get_repr_function(Foo(),        ()) == repr
    assert get_repr_function(Bar(),        ()) == repr
    assert get_repr_function(Baz(),        ()) == repr
    assert get_repr_function(3,            [(int, lambda x: u'_')]) == \
                                                                        _
    assert get_repr_function(3.5,          [(int, lambda x: u'_')]) == repr

# Generated at 2022-06-20 12:44:54.915531
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            print(s)
    assert issubclass(MyWritableStream, WritableStream)

# Generated at 2022-06-20 12:45:02.732371
# Unit test for function shitcode
def test_shitcode():
    def fuckcode(s):
        return ''.join(
            '?' if (0 < ord(c) < 256) else c for c in s
        )

    assert shitcode(fuckcode('12345')) == '12345'
    assert shitcode(fuckcode('12345\x80')) == '12345?'
    assert shitcode(fuckcode('12345\xff')) == '12345?'
    assert shitcode(fuckcode('12345\x80\xff')) == '12345??'


# Generated at 2022-06-20 12:45:04.481893
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Dummy(WritableStream): pass
    Dummy().write('hi') # Shouldn't raise exception

# Generated at 2022-06-20 12:45:08.314887
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A:
        def __repr__(self):
            return 'c' * 1000
    assert len(get_shortish_repr(A())) <= 60
    assert len(get_shortish_repr(repr(A()))) <= 60


import string


# Generated at 2022-06-20 12:45:14.325063
# Unit test for function truncate
def test_truncate():

    assert truncate('123456', 6) == '123456'
    assert truncate('123456', 5) == '12345'
    assert truncate('123456', 4) == '1...6'
    assert truncate('123456', 3) == '1...6'
    assert truncate(u'123456', 5) == u'12345'
    assert truncate(u'123456', 4) == u'1...6'
    assert truncate(u'123456', 3) == u'1...6'
    assert truncate('123456', None) == '123456'
    assert truncate(u'123456', None) == u'123456'



# Generated at 2022-06-20 12:45:17.772428
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('abc') == 'abc'
    assert normalize_repr('abc at 0x1234') == 'abc'
    assert normalize_repr('abc at 0x12345678901234') == 'abc'

# Generated at 2022-06-20 12:45:28.331846
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('אאאאאאאאאאאאאאאאאאאאאאאאאאאאאא') == \
                                                    '?????????????????????'
    assert shitcode('123123123123123123123123123123') == \
                                                    '123123123123123123123123123123'

# Generated at 2022-06-20 12:45:35.949528
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None) is repr
    assert get_repr_function('') is repr
    assert get_repr_function(1) is repr
    assert get_repr_function(1.0) is repr
    assert get_repr_function([]) is repr
    assert get_repr_function({}) is repr
    assert get_repr_function(()) is repr
    assert get_repr_function(set()) is repr
    assert get_repr_function(tuple()) is repr
    assert get_repr_function(sys) is repr
    assert get_repr_function(sys.modules) is repr


# Generated at 2022-06-20 12:45:45.716903
# Unit test for function truncate
def test_truncate():
    assert truncate(b'abc', None) == b'abc'
    assert truncate(b'abc', 0) == b'abc'
    assert truncate(b'abc', 1) == b'abc'
    assert truncate(b'abc', 2) == b'abc'
    assert truncate(b'abc', 3) == b'abc'
    assert truncate(b'abc', 4) == b'abc'
    assert truncate(b'abc', 5) == b'abc'

    assert truncate(b'abc', -1) == b'abc'
    assert truncate(b'abc', -2) == b'abc'
    assert truncate(b'abc', -3) == b'abc'
    assert truncate(b'abc', -4) == b'abc'

# Generated at 2022-06-20 12:46:06.392389
# Unit test for function normalize_repr
def test_normalize_repr():
    if sys.version_info[0] == 2:
        assert normalize_repr(u'<__main__.A object at 0x00000000023A5AC8>') == \
               u'<__main__.A object>'
        assert normalize_repr(u"<type 'A'>") == u"<type 'A'>"
    else:
        assert normalize_repr(u'<__main__.A object at 0x00000000023A5AC8>') == \
               u'<__main__.A object>'
        assert normalize_repr(u"<class 'A'>") == u"<class 'A'>"

# Generated at 2022-06-20 12:46:12.435582
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(12, max_length=2) == '12'
    assert get_shortish_repr(1234, max_length=2) == '12...34'
    assert get_shortish_repr(1234, max_length=3) == '123...34'
    assert get_shortish_repr(1234, max_length=4) == '1234'




# Generated at 2022-06-20 12:46:14.756556
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('שלום') == '???'
    assert shitcode('ab\xbad') == 'ab?ad'

# Generated at 2022-06-20 12:46:26.257776
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class FakeFile(WritableStream):
        def __init__(self, stdout):
            self.stdout = stdout

        def write(self, s):
            self.stdout.write('FAKE: ' + s)

    ###########################################################################
    # Test the patch
    ###########################################################################

    import sys
    import time
    import threading

    original_sys_stdout = sys.stdout

    # stdout is a global variable, which means that if we change it here all
    # code that runs in this process will use our fake stdout. This is a
    # dangerous thing to do but we're doing it anyway in this demonstration.

    sys.stdout = FakeFile(original_sys_stdout)
    assert isinstance(sys.stdout, FakeFile)

    print('Hello, world!')

    #

# Generated at 2022-06-20 12:46:31.870205
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple([3]) == ([3],)
    assert ensure_tuple((3,)) == ((3,),)
    assert ensure_tuple(range(3)) == (range(3),)
    assert ensure_tuple(xrange(3)) == (xrange(3),)
    assert ensure_tuple((range(3),)) == ((range(3),),)



# Generated at 2022-06-20 12:46:33.931817
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-20 12:46:39.579742
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(WritableStream):
        def write(self, s):
            pass
    Foo()

    class Bar(WritableStream):
        pass
    try:
        # This should fail, because it doesn't implement `write`
        Bar()
    except NotImplementedError:
        pass
    else:
        raise Exception("Shouldn't have happened")

    try:
        # This should fail, because it doesn't implement `write`
        class Baz(WritableStream):
            pass
    except NotImplementedError:
        pass
    else:
        raise Exception("Shouldn't have happened")

test_WritableStream()

# Generated at 2022-06-20 12:46:47.449981
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('a') == 'a'
    assert normalize_repr('a at 0xfffff') == 'a'
    assert normalize_repr('a at 0x1234567890') == 'a'
    assert normalize_repr('a at 0x1234567890  ') == 'a at 0x1234567890  '
    assert normalize_repr('abc123def at 0x1234567890') == 'abc123def'
    assert normalize_repr('abc123def at 0x1234567890   ') == 'abc123def at 0x1234567890   '



# Generated at 2022-06-20 12:46:55.077462
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda x: isinstance(x, int), lambda x: '%s is int' % x),
        (lambda x: x is None, lambda x: '%r is None' % x),
        (lambda x: x is not None, lambda x: '%r is not None' % repr(x)),
    )
    # inline lambda to short repr:
    def custom_repr_short(x):
        get = lambda f: lambda x: '%s' % f(x)
        d={}
        for condition, action in custom_repr:
            d[get(condition)] = get(action)
        return d


# Generated at 2022-06-20 12:46:58.770625
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(['woof', 'bark']) == ('woof', 'bark')
    assert ensure_tuple(('tweet', 'chirp')) == ('tweet', 'chirp')



# Generated at 2022-06-20 12:47:24.681700
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    text = 'hello\xe4'
    assert shitcode(text) == text.decode('utf-8', 'replace').encode('ascii')




# Generated at 2022-06-20 12:47:29.126079
# Unit test for function shitcode
def test_shitcode():
    y = shitcode(u'ab\xa4')
    assert y == u'ab?'

    y = shitcode(u'ab\u2603')
    assert y == u'ab?'

    y = shitcode(u'ab\U0001f4a9')
    assert y == u'ab?'

# Generated at 2022-06-20 12:47:39.230492
# Unit test for function get_repr_function
def test_get_repr_function():

    class Foo(object):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return '<Foo: {}>'.format(self.value)


    custom_repr = (
        (lambda x: False, lambda x: 'False'),
        (lambda x: x[0][1] == 'bar', lambda x: 'bar'),
        ((lambda x: x[0][1] == 'baz'), lambda x: 'baz'),
        (lambda x: 'default', lambda x: 'default'),
    )

    assert get_repr_function(('False', 'foo', None), custom_repr)() == 'False'
    assert get_repr_function(('bar', 'foo', None), custom_repr)() == 'bar'
    assert get_re

# Generated at 2022-06-20 12:47:41.392381
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamExample(WritableStream):
        def write(self, s):
            pass

    assert issubclass(WritableStreamExample, WritableStream)




# Generated at 2022-06-20 12:47:50.531562
# Unit test for function truncate
def test_truncate():
    assert truncate('pam pam pam', 1) == 'p'
    assert truncate('pam pam pam', 2) == 'pa'
    assert truncate('pam pam pam', 3) == 'pam'
    assert truncate('pam pam pam', 4) == 'pam '
    assert truncate('pam pam pam', 5) == 'pam p'
    assert truncate('pam pam pam', 6) == 'pam pa'
    assert truncate('pam pam pam', 7) == 'pam pa'
    assert truncate('pam pam pam', 8) == 'pam pam '
    assert truncate('pam pam pam', 9) == 'pam pam p'

# Generated at 2022-06-20 12:47:53.803020
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("bla") == "bla"
    assert normalize_repr("bla at 0x1234") == "bla"
    assert normalize_repr("bla at 0x1234567890abc") == "bla"

# Generated at 2022-06-20 12:48:03.726123
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A(object):
        def __init__(self, x):
            self.x = x
        def __repr__(self):
            return 'A({})'.format(self.x)

    assert(get_shortish_repr((1, 2, 3), max_length=5) == '(1, 2...)')
    assert(get_shortish_repr((1, 2, 3), max_length=20) == '(1, 2, 3)')
    assert(get_shortish_repr((1, 2, 3), max_length=None) == '(1, 2, 3)')
    assert(get_shortish_repr(A(1), max_length=10) == 'A(1)')


# Generated at 2022-06-20 12:48:12.895238
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(int) == 'int'
    assert get_shortish_repr(int, max_length=3) == 'int'
    assert get_shortish_repr(int, max_length=5) == 'int'
    assert get_shortish_repr(int, max_length=4) == 'int'
    assert get_shortish_repr(int, max_length=3, normalize=True) == 'int'
    assert get_shortish_repr(int, max_length=5, normalize=True) == 'int'
    assert get_shortish_repr(int, max_length=4, normalize=True) == 'int'
    assert get_shortish_repr(None)