

# Generated at 2022-06-22 18:26:00.335110
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Writeable(WritableStream):
        def __init__(self, x):
            self.x = x
        def write(self, s):
            assert self.x == s
            self.x = s
    s = Writeable('kappa')
    s.write('kappa')

    # Unit test for method __subclasshook__ of class WritableStream
    class DummyWritable(object):
        pass
    assert WritableStream.__subclasshook__(DummyWritable) is NotImplemented

    class DummyWriteable(object):
        def write(self, s):
            pass
    assert WritableStream.__subclasshook__(DummyWriteable) is True

# Generated at 2022-06-22 18:26:08.984711
# Unit test for function truncate
def test_truncate():
    assert truncate('honey', max_length=None) == 'honey'
    assert truncate('honey', max_length=0) == ''
    assert truncate('honey', max_length=1) == 'h...'
    assert truncate('honey', max_length=2) == 'ho...'
    assert truncate('honey', max_length=3) == 'h...'
    assert truncate('honey', max_length=4) == 'hon...'
    assert truncate('honey', max_length=5) == 'honey'
    assert truncate('honey', max_length=6) == 'honey'
    assert truncate('honey', max_length=7) == 'honey'
    assert truncate('honey', max_length=8) == 'honey'

# Generated at 2022-06-22 18:26:10.445025
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class B(ABC, object):
        @staticmethod
        def write(s): pass
    assert issubclass(B, WritableStream)

# Generated at 2022-06-22 18:26:12.482529
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Example(WritableStream):
        def write(self, s):
            pass
    assert issubclass(Example, WritableStream)

# Generated at 2022-06-22 18:26:15.940107
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)

# Generated at 2022-06-22 18:26:19.030698
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple({1, 2}) == (1, 2)
    assert ensure_tuple(1) == (1,)



# Generated at 2022-06-22 18:26:22.239669
# Unit test for function normalize_repr
def test_normalize_repr():
    class C(object):
        pass
    c = C()
    assert normalize_repr(repr(c)) == normalize_repr('<__main__.C object at 0x000002BD9A83CAC8>')





# Generated at 2022-06-22 18:26:25.723112
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import sys
    assert isinstance(sys.stdout, WritableStream)
    assert not isinstance(object(), WritableStream)



# Generated at 2022-06-22 18:26:31.480749
# Unit test for function get_repr_function
def test_get_repr_function():
    get_repr_function(1.23, ((int, safe_repr), (float, lambda x: 'float %s' % x))) == repr
    get_repr_function(1, ((int, safe_repr), (float, lambda x: 'float %s' % x))) == safe_repr
    get_repr_function(1.23, ((float, lambda x: 'float %s' % x), (int, safe_repr))) == repr



# Generated at 2022-06-22 18:26:37.470001
# Unit test for function get_repr_function
def test_get_repr_function():
    
    class MyObject(object):
        def my_repr(self):
            return 'hi'

    my_object = MyObject()

    def x_repr(x):
        return 'x'

    assert get_repr_function(
        my_object,
        custom_repr=[(lambda x: 1, 'repr_1'),(MyObject, x_repr)]
    ) is x_repr
    assert get_repr_function(1, custom_repr=[(1, 'repr_1')]) == 'repr_1'
    assert get_repr_function(set(), custom_repr=[(set, 'repr_set')]) == 'repr_set'
    # The first condition that matches wins

# Generated at 2022-06-22 18:26:40.505237
# Unit test for function shitcode
def test_shitcode():
    for s in [u'smit', b'smit', 'sm\x00i\xfft']:
        assert shitcode(s) == 'smi?t'



# Generated at 2022-06-22 18:26:41.843618
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('héllò') == 'h??ll?'


if __name__ == '__main__':
    test_shitcode()

# Generated at 2022-06-22 18:26:46.864827
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(2) == (2,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(x + 1 for x in range(3)) == (1, 2, 3)
    assert ensure_tuple('hi') == ('hi',)

# Generated at 2022-06-22 18:26:57.709652
# Unit test for function get_repr_function
def test_get_repr_function():
    def custom_repr_int(x):
        return 'int: ' + str(x)
    def custom_repr_string(x):
        x = x.replace('\n', '\\n')
        x = x.replace('\r', '\\r')
        x = x.replace('\t', '\\t')
        return 'string: ' + x

    def test_get_repr_function(item, custom_repr, expected):
        result = get_repr_function(item, custom_repr)
        assert result is expected
        assert result(item) == expected(item)

    test_get_repr_function(1, [], repr)
    test_get_repr_function(1, [(int, custom_repr_int)], custom_repr_int)
    test_get

# Generated at 2022-06-22 18:27:05.076932
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('Hello world!') == 'Hello world!'
    assert shitcode('שלום עולם!') == '???? ????!'
    assert shitcode(b'Hello world!') == 'Hello world!'
    assert shitcode(b'\x80\x81\x82') == '???'
    assert shitcode(u'Hello world!') == 'Hello world!'
    assert shitcode(u'\x80\x81\x82') == '???'
    assert shitcode(u'שלום עולם!') == '???? ????!'
    assert shitcode(bytearray(b'Hello world!')) == 'Hello world!'
    assert shitcode(bytearray(b'\x80\x81\x82')) == '???'



# Generated at 2022-06-22 18:27:14.175969
# Unit test for function get_repr_function
def test_get_repr_function():
    c = (
        (lambda a: len(a) in (4, 5), ''),
        (lambda a: isinstance(a, type(7)), ''),
        (lambda a: isinstance(a, type(None)), ''),
        (lambda a: isinstance(a, type('str')), 'str'),
        (lambda a: isinstance(a, type(list)), 'list'),
        (lambda a: isinstance(a, type(type)), 'type'),
        (lambda a: isinstance(a, type), 'type'),
    )
    f = get_repr_function(7, c)
    assert f(7) == ''
    g = get_repr_function('hello', c)
    assert g('hello') == 'str'
    h = get_repr_function([1, 2, 3], c)

# Generated at 2022-06-22 18:27:19.286405
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple('foo') == ('foo',)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple({'a': 1}) == ({'a': 1},)



# Generated at 2022-06-22 18:27:22.240118
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class W(WritableStream):
        def write(self, s):
            pass

    assert issubclass(W, WritableStream)
    w = W()
    w.write('hi')



# Generated at 2022-06-22 18:27:27.986518
# Unit test for function truncate
def test_truncate():
    assert repr(truncate('aaaaa', None)) == repr('aaaaa')
    assert repr(truncate('aaaaa', 5)) == repr('aaaaa')
    assert repr(truncate('aaaaa', 3)) == repr('aaa')
    assert repr(truncate('aaaaa', 1)) == repr('a')
    assert repr(truncate('aaaab', 2)) == repr('aa')
    assert repr(truncate('aaaab', 3)) == repr('aaa')
    assert repr(truncate('aaaab', 4)) == repr('aaab')



# Generated at 2022-06-22 18:27:30.386989
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass
    class B:
        pass
    assert issubclass(A, WritableStream)
    assert not issubclass(B, WritableStream)

# Generated at 2022-06-22 18:27:36.972551
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

    class BadWritableStream1:
        pass

    assert not issubclass(BadWritableStream1, WritableStream)

    class BadWritableStream2:
        def write(self, s):
            pass

    assert not issubclass(BadWritableStream2, WritableStream)
    BadWritableStream2.write = None

    class BadWritableStream3():
        def foo(self, s):
            pass

    assert not issubclass(BadWritableStream3, WritableStream)

# Generated at 2022-06-22 18:27:47.916411
# Unit test for function truncate
def test_truncate():
    assert truncate('abcde', None) == 'abcde'
    assert truncate('abcde', 7) == 'abcde'
    assert truncate('abcde', 3) == '...'
    assert truncate('abcde', 4) == 'a...'
    assert truncate('abcde', 5) == 'a...e'
    assert truncate('abcde', 6) == 'ab...e'
    assert truncate('abcde', 2) == '...'
    assert truncate('abcde', 1) == '...'
    assert truncate('abcde', 0) == '...'
    assert truncate('abcde', -1) == '...'

    assert truncate(u'abcdé', 5) == u'abcdé'
    assert truncate(u'abcdé', 4) == u'a...'


# Generated at 2022-06-22 18:27:57.283255
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import pytest
    obj = [1, 2, 3]
    assert get_shortish_repr(obj) in {"[1, 2, 3]", 'REPR FAILED'}
    assert get_shortish_repr(obj, max_length=2) == '...'
    assert get_shortish_repr(obj, max_length=7) == '[1, 2, ...'
    assert get_shortish_repr(obj, max_length=8) == '[1, 2, ...'
    assert get_shortish_repr(obj, max_length=9) == '[1, 2, 3]'
    assert get_shortish_repr(obj, max_length=10) == '[1, 2, 3]'

# Generated at 2022-06-22 18:28:06.364886
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('spam at 0xF0F0F0F0') == 'spam'
    assert normalize_repr('spam') == 'spam'
    assert normalize_repr('spam at 0xF0F0F0F0F0') == 'spam'
    assert normalize_repr('spam at 0x1') == 'spam'
    assert normalize_repr('spam at 0x123456789') == 'spam'
    assert normalize_repr('spam at 0xFFFFFFFF') == 'spam'
    assert normalize_repr('spam at 0xA') == 'spam'
    assert normalize_repr('spam at 0xABCDEF0123456789') == 'spam'

# Generated at 2022-06-22 18:28:14.282915
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, )) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple(3.5) == (3.5,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple([]) == ()


if sys.version_info[0] == 3:
    string_types = str,
    try:
        string_types += (unicode,)
    except NameError:
        pass



# Generated at 2022-06-22 18:28:18.928584
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class Test(WritableStream):
        def __init__(self):
            self.called_write = False
        def write(self, s):
            self.called_write = True

    test = Test()
    test.write('something')

    assert test.called_write is True



# Generated at 2022-06-22 18:28:28.632337
# Unit test for function normalize_repr
def test_normalize_repr():
    import pytest
    assert normalize_repr(
        "Kitty.__init__(object at 0x000000000230D208)"
    ) == normalize_repr(
        "<python_toolbox.temp_value_set.core.Kitty object at 0x000000000230D208>"
    ) == "Kitty.__init__(object)"


# Generated at 2022-06-22 18:28:33.085299
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: str(x)),)) == str
    assert get_repr_function(1, ((lambda x: False, lambda x: str(x)),)) == repr
    assert get_repr_function('', ((lambda x: False, lambda x: str(x)),)) == repr
    assert get_repr_function(1.0, ((int, lambda x: str(x)),)) == repr



# Generated at 2022-06-22 18:28:35.472440
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Dummy(WritableStream):
        def write(self, s):
            self.s = s

    dummy = Dummy()
    dummy.write(5)
    print(dummy.s)

# Generated at 2022-06-22 18:28:38.029318
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(x for x in range(3)) == (0, 1, 2)

# Generated at 2022-06-22 18:28:42.830206
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(3, max_length=3) == '3'
    assert get_shortish_repr(3, max_length=4) == '3'
    assert get_shortish_repr(3, max_length=2) == '3'
    assert get_shortish_repr(3, max_length=10) == '3'
    assert get_shortish_repr([1, 2, 3], max_length=3) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=4) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=2) == '[1, 2, 3]'

# Generated at 2022-06-22 18:28:47.908047
# Unit test for function ensure_tuple
def test_ensure_tuple():
    from .test_tools import TestCase

    class TestEnsureTuple(TestCase):
        def test_ensure_tuple(self):

            assert ensure_tuple('12') == ('12',)
            assert ensure_tuple((1, 2)) == (1, 2)



# Generated at 2022-06-22 18:28:56.932036
# Unit test for function normalize_repr
def test_normalize_repr():
    from random import choice
    from string import lowercase
    from string import uppercase
    from string import digits
    from string import whitespace
    from string import hexdigits

    for i in range(10000):
        s = ''.join(choice(whitespace + lowercase + uppercase + digits +
                           '_' + hexdigits)
                    for _ in range(100))
        memory_address = '0x' + ''.join(choice(hexdigits) for _ in range(50))
        s += ' at ' + memory_address
        r = normalize_repr(s)
        assert r == s[:s.index(' at ')]



# Generated at 2022-06-22 18:29:07.126934
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A1: pass
    class A2(object): pass
    class A3(A1): pass
    class A4(A2): pass
    class A5(A3, A4): pass
    class A6(A3, A4):
        def write(self, s):
            pass
    class A7(A3, A4):
        write = None
    class A8(A3, A4):
        def write(self, s):
            pass
    class A9(A3, A4):
        write = None
    assert issubclass(A1, WritableStream) is False
    assert issubclass(A2, WritableStream) is False
    assert issubclass(A3, WritableStream) is False
    assert issubclass(A4, WritableStream) is False
    assert issub

# Generated at 2022-06-22 18:29:17.678624
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(object(), max_length=10) == '<object object at 0x...>'
    assert get_shortish_repr(object(), max_length=None) == '<object object at 0x...>'
    assert get_shortish_repr(object(), max_length=50) == '<object object at 0x...>'

    assert get_shortish_repr(list(), max_length=10) == '[]'
    assert get_shortish_repr(list(), max_length=None) == '[]'
    assert get_shortish_repr(list(), max_length=50) == '[]'

    assert get_shortish_repr(None, max_length=10) == 'None'

# Generated at 2022-06-22 18:29:19.066123
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('רם') == '??'



# Generated at 2022-06-22 18:29:29.917049
# Unit test for function normalize_repr
def test_normalize_repr():
    r = normalize_repr(r'<reprlib._recursive_repr.<locals>.Recursion instance at 0x7f3e6a82d6c8>')
    assert r == r'<reprlib._recursive_repr.<locals>.Recursion instance>'

    r = normalize_repr(r'<reprlib._recursive_repr.<locals>.Recursion instance at 0x7f3e6a82d6c8> ')
    assert r == r'<reprlib._recursive_repr.<locals>.Recursion instance> '

    r = normalize_repr(r' <reprlib._recursive_repr.<locals>.Recursion instance at 0x7f3e6a82d6c8>')

# Generated at 2022-06-22 18:29:32.761489
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(object):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    assert issubclass(object, WritableStream) is False

# Generated at 2022-06-22 18:29:35.209750
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import tempfile
    fh = tempfile.TemporaryFile()
    assert isinstance(fh, WritableStream)


# Generated at 2022-06-22 18:29:40.099470
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('', []) == repr
    assert get_repr_function(1, [(int, int)]) == int
    assert get_repr_function('', [(int, int)]) == repr
    assert get_repr_function(1, [(lambda x: x == 1, int)]) == int
    assert get_repr_function(2, [(lambda x: x == 1, int)]) == repr





# Generated at 2022-06-22 18:29:50.903423
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(2) == '2'
    assert get_shortish_repr(2, max_length=1) == '2'
    assert get_shortish_repr(2, max_length=2) == '2'
    assert get_shortish_repr(2, max_length=3) == '2'
    assert get_shortish_repr(2, max_length=4) == '2'
    assert get_shortish_repr(2, max_length=5) == '2'
    assert get_shortish_repr(2, max_length=6) == '2'
    assert get_shortish_repr(2, max_length=7) == '2'

# Generated at 2022-06-22 18:29:52.902259
# Unit test for function normalize_repr
def test_normalize_repr():
    example_repr = "Hello world at 0xdeadbeef"
    assert normalize_repr(example_repr) == "Hello world"

# Generated at 2022-06-22 18:30:00.247886
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class SomeStream(WritableStream):
        def write(self, s):
            pass
    assert isinstance(SomeStream(), WritableStream)
    assert issubclass(SomeStream, WritableStream)

    class SomeStream(WritableStream):
        pass
    assert not isinstance(SomeStream(), WritableStream)
    assert not issubclass(SomeStream, WritableStream)

    class SomeStream(WritableStream):
        def write(self, s):
            pass
        @classmethod
        def __subclasshook__(cls, C):
            return False
    assert not isinstance(SomeStream(), WritableStream)
    assert not issubclass(SomeStream, WritableStream)

    class SomeStream(WritableStream):
        def write(self, s):
            pass

# Generated at 2022-06-22 18:30:05.110970
# Unit test for function shitcode
def test_shitcode():
    s = 'דבר זה נראה כמו ברור'
    s = s.encode('utf-8').decode('cp1255').encode('utf-8').decode('utf-8')
    assert shitcode(s) == '??? ?? ???? ????'
    assert shitcode('abc') == 'abc'
    assert shitcode('ab\xc3\x9f') == 'ab?'

# Generated at 2022-06-22 18:30:12.577643
# Unit test for function normalize_repr
def test_normalize_repr():
    from .python_toolbox import cute_testing
    example_object = object()
    repr_function = get_repr_function(example_object)
    assert repr_function(example_object) == repr(example_object)
    assert repr_function(example_object) != normalize_repr(repr(example_object))
    assert (normalize_repr(repr(example_object)) ==
            "{}()".format(type(example_object).__name__))
    assert (normalize_repr(repr(example_object)) ==
            "{}()".format(example_object.__class__.__name__))




# Generated at 2022-06-22 18:30:22.693887
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, []) == repr
    assert get_repr_function({},
                             [(lambda x: not isinstance(x, dict), lambda x: 'X')]) == repr
    assert get_repr_function({}, [(dict, lambda x: 'X')]) == 'X'
    assert get_repr_function([],
                             [(None, lambda x: 'X'), (dict, lambda x: 'DICT')]) == 'X'
    assert get_repr_function({},
                             [(None, lambda x: 'X'), (dict, lambda x: 'DICT')]) == 'DICT'
    assert get_repr_function([],
                             [(None, lambda x: 'X'), (list, lambda x: 'LIST')]) == 'LIST'


# Generated at 2022-06-22 18:30:33.693476
# Unit test for function normalize_repr
def test_normalize_repr():
    import sys

    assert normalize_repr('') == ''
    assert normalize_repr(' ') == ' '
    assert normalize_repr('  ') == '  '
    assert normalize_repr('a') == 'a'
    assert normalize_repr('b') == 'b'
    assert normalize_repr('') == ''
    assert normalize_repr(' \t ') == ' \t '
    assert normalize_repr('f') == 'f'
    assert normalize_repr('g') == 'g'

    assert normalize_repr('0') == '0'
    assert normalize_repr('0 ') == '0 '
    assert normalize_repr('0a') == '0a'

# Generated at 2022-06-22 18:30:44.227255
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None) == 'None'

    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr(object()) == '<object object at 0x%x>' % id(object())
    assert get_shortish_repr((1, 2, 3), normalize=True) == '(1, 2, 3)'

    assert get_shortish_repr(type(None)) == '<type \'NoneType\'>'
    assert get_shortish_repr(1.0) == '1.0'
    assert get_shortish_repr(1j) == '1j'

    assert get_shortish_repr(u'my unicode') == u'my unicode'

# Generated at 2022-06-22 18:30:52.503908
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('spam') == 'spam'
    assert normalize_repr('spam at 0x123456') == 'spam'
    assert normalize_repr('spam at 0x12345678') == 'spam'
    assert normalize_repr('spam at 0x1234') == 'spam at 0x1234'
    assert normalize_repr('spam at 0x1') == 'spam at 0x1'
    assert normalize_repr('spam at 0x1234567890') == 'spam at 0x1234567890'



# Generated at 2022-06-22 18:30:55.453738
# Unit test for function truncate
def test_truncate():
    assert truncate(u'a', 5) == u'a'
    assert truncate(u'abcdefg', 5) == u'a...g'
    assert truncate(u'abcdefgh', 5) == u'a...h'
    assert truncate(u'abcdefghi', 5) == u'a...i'

# Generated at 2022-06-22 18:30:58.120705
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple((3, 5)) == (3, 5)
    assert ensure_tuple([3, 5]) == (3, 5)
    assert ensure_tuple(x for x in range(5)) == (0, 1, 2, 3, 4)



# Generated at 2022-06-22 18:31:00.751107
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class ExampleClass(WritableStream):
        def __init__(self):
            self.string = ''
        def write(self, s):
            self.string += s
    assert isinstance(ExampleClass(), WritableStream)




# Generated at 2022-06-22 18:31:04.364853
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('hello\x01') == 'hello?'
    assert shitcode('hello\x01\x02\x03') == 'hello???'



# Generated at 2022-06-22 18:31:14.975719
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A:
        def __init__(self, x):
            self.x = x

        def __repr__(self):
            return 'A(%s)' % self.x

    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr(5, max_length=2) == '5'
    assert get_shortish_repr(5, max_length=1) == '5'
    assert get_shortish_repr(5, max_length=0) == '...'

    assert get_shortish_repr(A(5)) == 'A(5)'
    assert get_shortish_repr(A(5), max_length=3) == 'A(...)'

# Generated at 2022-06-22 18:31:19.190520
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(xrange(3)) == (0, 1, 2)
    assert ensure_tuple(iter([1, 2, 3])) == (1, 2, 3)
    assert ensure_tuple(x for x in [1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple('yo') == ('yo',)


# Generated at 2022-06-22 18:31:30.522710
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('sdfsdfsdfsdfsdfsdfsdf at 0x12345678') == \
          'sdfsdfsdfsdfsdfsdfsdf'

    assert normalize_repr('sdfsdfsdfsdfsdfsdfsdf at 0x1234567') == \
          'sdfsdfsdfsdfsdfsdfsdf at 0x1234567'

    assert normalize_repr('sdfsdfsdfsdfsdfsdfsdf at 0x12345') == \
          'sdfsdfsdfsdfsdfsdfsdf at 0x12345'


# Generated at 2022-06-22 18:31:37.764188
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda x: isinstance(x, int), lambda x: hex(x)),
        (lambda x: isinstance(x, str), lambda x: ''.join('.' if c == '_'
                                                          else c for c in x)),
        (lambda x: isinstance(x, set), set.__repr__),
    )

    assert get_repr_function(3, custom_repr) == hex
    assert get_repr_function(3.1, custom_repr) == repr
    assert get_repr_function('a_b', custom_repr) == (lambda x: 'a.b')
    assert get_repr_function({'a_b'}, custom_repr) == repr

# Generated at 2022-06-22 18:31:49.234414
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr('hello!') == 'hello!'
    assert get_shortish_repr(b'hello!') == "b'hello!'"
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr('hello!', max_length=4) == 'he...'
    assert get_shortish_repr('hello!', max_length=5) == 'hel...'
    assert get_

# Generated at 2022-06-22 18:31:53.425276
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple(['wee', 'dee']) == ('wee', 'dee')
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(1) == (1,)



# Generated at 2022-06-22 18:32:03.394834
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello', normalize=True) == 'hello'
    assert get_shortish_repr(2 + 2j, normalize=True) == '(2+2j)'
    assert get_shortish_repr('\nhello\n', normalize=True) == 'hello'
    assert get_shortish_repr('hello\n', normalize=True) == 'hello'
    assert get_shortish_repr('hello', normalize=True, max_length=5) == 'hello'  # noqa
    assert get_shortish_repr('hello', normalize=True, max_length=6) == 'hello'  # noqa
    assert get_shortish_repr('hello', normalize=True, max_length=7) == 'hello'  # noqa
    assert get

# Generated at 2022-06-22 18:32:09.600232
# Unit test for function truncate
def test_truncate():
    s = 'abcdefghijklmnopqrstuvwxyz'
    s2 = 'abcde'
    s3 = ''
    assert truncate(s, 27) == s
    assert truncate(s, 26) == s
    assert truncate(s, 25) == 'abcdefghijklmnopqrstuvw...z'
    assert truncate(s, 24) == 'abcdefghijklmnopqrstuv...yz'
    assert truncate(s, 23) == 'abcdefghijklmnopqrstu...xyz'
    assert truncate(s, 22) == 'abcdefghijklmnopqrst...wxyz'
    assert truncate(s, 21) == 'abcdefghijklmnopqrs...vwxyz'

# Generated at 2022-06-22 18:32:15.110526
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(object):
        def write(self, s):
            return s
    x = X()

    assert isinstance(x, WritableStream)

    assert x.write('abc') == 'abc'

# Generated at 2022-06-22 18:32:20.802462
# Unit test for function normalize_repr
def test_normalize_repr():
    for item in (1, 'a', b'b', {'a': 1, 'b': 2}, (1, 2, 3)):
        item_repr = repr(item)
        assert normalize_repr(item_repr) == item_repr
        assert normalize_repr(item_repr.upper()) == item_repr

    assert normalize_repr('12 at 0x1234567') == '12'

# Generated at 2022-06-22 18:32:22.948134
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass
    assert isinstance(WritableStreamSubclass(), WritableStream)



# Generated at 2022-06-22 18:32:26.024519
# Unit test for function truncate
def test_truncate():
    assert truncate('abcd efgh', 4) == 'abcd...'
    assert truncate(u'abcd efgh', 4) == u'abcd...'
    assert truncate('abcdefgh', 4) == 'abcdefgh'



# Generated at 2022-06-22 18:32:37.218793
# Unit test for constructor of class WritableStream
def test_WritableStream():
    """
    This test demonstrates the __subclasshook__ method inspection, as
    well as the isinstance method.
    """
    assert isinstance(sys.stdout, WritableStream)
    assert not isinstance(5, WritableStream)

    class MyFile(object):
        def write(self, s):
            pass
    assert isinstance(MyFile(), WritableStream)

    class MyOtherFile(object):
        def write(self, s):
            pass
        def foo(self):
            pass
    assert not isinstance(MyOtherFile(), WritableStream)

    class MyFile(WritableStream):
        def write(self, s):
            pass
    assert isinstance(MyFile(), WritableStream)

    class MyOtherFile(WritableStream):
        def write(self, s):
            pass

# Generated at 2022-06-22 18:32:44.667307
# Unit test for function truncate
def test_truncate():
    assert truncate('abcd', 4) == 'abcd'
    assert truncate('abcdefg', 4) == 'a...g'
    assert truncate('abcdefg', 5) == 'a...g'
    assert truncate('abcdefgh', 5) == 'a...h'
    assert truncate('abcdef', 3) == 'abcdef'
    assert truncate('abc', 10) == 'abc'
    assert truncate('a', 10) == 'a'
    assert truncate('', 10) == ''



# Generated at 2022-06-22 18:32:51.252151
# Unit test for function normalize_repr
def test_normalize_repr():

    from .exceptions import StacklessError

    assert normalize_repr(repr(None)) == 'None'
    assert normalize_repr(repr(1)) == '1'
    assert normalize_repr(repr(bool)) == '<class \'bool\'>'
    assert normalize_repr(repr([])) == '[]'
    assert normalize_repr(repr((1, 2, 3))) == '(1, 2, 3)'
    assert normalize_repr(repr({'a': 1, 'b': None})) == "{'a': 1, 'b': None}"
    assert normalize_repr(repr({1, 2, 3})) == '{1, 2, 3}'


# Generated at 2022-06-22 18:32:55.932098
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((type, lambda x: 'a'),)) == 'a'
    assert get_repr_function(1.0, ((type, lambda x: 'a'),)) == 'a'
    assert get_repr_function([1], ((type, lambda x: 'a'),)) == 'a'
    assert get_repr_function(set([1]), ((type, lambda x: 'a'),)) == 'a'
    assert get_repr_function(set([1]), ((set, lambda x: 'b'),)) == 'b'
    assert get_repr_function(set([1]), ((lambda x: True, lambda x: 'c'),)) == 'c'
    assert get_repr_function(set([1]), ((lambda x: False, lambda x: 'd'),)) == repr


# Unit

# Generated at 2022-06-22 18:33:02.319490
# Unit test for function get_repr_function
def test_get_repr_function():


    assert get_repr_function(
        100,
        custom_repr=((lambda x: x == 100, lambda i: 'hello'),)
    )(100) == 'hello'


    assert get_repr_function(
        100,
        custom_repr=((lambda x: x == 200, lambda i: 'hello'),)
    )(100) != 'hello'


    assert get_repr_function(
        200,
        custom_repr=((lambda x: x == 200, lambda i: 'hello'),)
    )(200) == 'hello'


    assert get_repr_function(
        100,
        custom_repr=((100, lambda i: 'hello'),)
    )(100) == 'hello'



# Generated at 2022-06-22 18:33:07.460554
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(repr(set())) == 'set()'
    assert normalize_repr(repr([1, 2, 3])) == '[1, 2, 3]'
    assert normalize_repr(repr(lambda: 1)) == '<function <lambda> at 0x...>'

# Generated at 2022-06-22 18:33:17.885083
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(list(xrange(3))) == '[0, 1, 2]'
    assert get_shortish_repr(list(xrange(3)), max_length=1) == '[0,...'
    assert get_shortish_repr(list(xrange(3)), max_length=10) == '[0, 1, 2]'
    assert get_shortish_repr(list(xrange(3)), max_length=11) == '[0, 1, 2]'
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr('hello', max_length=4) == "'hel...'"
    assert get_shortish_repr('hello', max_length=5) == "'hell...'"



# Generated at 2022-06-22 18:33:23.898223
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghij', 5) == 'ab...j'
    assert truncate('abcdefghij', None) == 'abcdefghij'
    assert truncate('abcdefghij', 10) == 'abcdefghij'
    assert truncate('abcdefghij', 9) == 'abcdefghi...'
    assert truncate('abcdefghij', 8) == 'ab...ij'



# Generated at 2022-06-22 18:33:27.571925
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            assert s == 'bla'

    stream = MyWritableStream()
    stream.write('bla')



# Generated at 2022-06-22 18:33:31.281627
# Unit test for constructor of class WritableStream
def test_WritableStream():
    def check(T):
        assert issubclass(T, WritableStream)

    class WSt(WritableStream):
        def write(self, s):
            pass

    check(WSt)

    class WSt2(WSt):
        pass

    check(WSt2)

# Generated at 2022-06-22 18:33:42.614897
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple(()) == ()
    assert ensure_tuple([]) == ()
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)

    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(2) == (2,)
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple('hi') == ('hi',)

# Generated at 2022-06-22 18:33:45.678596
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class T():
        pass

    class Printable:
        def write(self, s):
            print(s)


    assert isinstance(T(), WritableStream) is False
    assert issubclass(Printable, WritableStream) is True

# Generated at 2022-06-22 18:33:55.965668
# Unit test for function get_repr_function
def test_get_repr_function():
    from collections import OrderedDict
    from pprint import saferepr

    def show(x):
        print(get_repr_function(x, custom_repr))

    custom_repr = [
        (lambda x: isinstance(x, dict), dict.__repr__),
        (lambda x: isinstance(x, OrderedDict), OrderedDict.__repr__),
    ]

    show({'a': 1, 'b': 2})
    show(OrderedDict([('z', 'z'), ('y', 'y')]))
    show('hello')

# test_get_repr_function()

# Generated at 2022-06-22 18:34:02.162753
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class FooStream(object):
        def write(self, s): pass

    assert isinstance(FooStream(), WritableStream)

    class BarStream(object):
        pass

    assert not isinstance(BarStream(), WritableStream)

    class BazStream(object):
        def write(self, s):
            pass

        def close(self):
            pass

    assert isinstance(BazStream(), WritableStream)

# Generated at 2022-06-22 18:34:10.683383
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefg', None) == 'abcdefg'
    assert truncate('abcdefg', 3) == 'abcdefg'
    assert truncate('abcdefg', 4) == 'abcdefg'
    assert truncate('abcdefg', 5) == 'abcdefg'
    assert truncate('abcdefg', 6) == 'abcdefg'
    assert truncate('abcdefg', 7) == 'abcdefg'
    assert truncate('abcdefg', 8) == 'abcdefg'
    assert truncate('abcdefg', 9) == 'abcdefg'

    assert truncate('abcdefg', 2) == '...'
    assert truncate('abcdefg', 3) == 'abcdefg'
    assert truncate('abcdefg', 4) == 'abcd...'
    assert trunc

# Generated at 2022-06-22 18:34:12.735981
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('\u2603') == '?'
    assert shitcode('xxx') == 'xxx'



# Generated at 2022-06-22 18:34:19.090850
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.data = b''
        def write(self, s):
            self.data += s
    
    stream = MyWritableStream()
    stream.write(b'hey')
    stream.write(b'you')
    assert stream.data == b'heyyou'


# Generated at 2022-06-22 18:34:24.470900
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(0) == (0,)
    assert ensure_tuple('test') == ('test',)
    assert ensure_tuple(('test',)) == ('test',)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(('a', 'b', 'c')) == ('a', 'b', 'c')


if __name__ == '__main__':
    test_ensure_tuple()

# Generated at 2022-06-22 18:34:36.023352
# Unit test for function normalize_repr
def test_normalize_repr():
    from pytest import approx

    assert normalize_repr('asdf') == 'asdf'
    assert normalize_repr('asdf at 0x1234') == 'asdf'
    assert normalize_repr('asdf at 0x12345678') == 'asdf'
    assert normalize_repr('asdf at 0x123456789abc') == 'asdf'
    assert normalize_repr('asdf at 0x123456789abcdef') == 'asdf'
    assert normalize_repr('asdf at 0x123456789ABCDEF') == 'asdf'
    assert normalize_repr('asdf at 0xA') == 'asdf'


# Generated at 2022-06-22 18:34:39.159532
# Unit test for function normalize_repr
def test_normalize_repr():

    def normalize(x):
        return normalize_repr(repr(x))

    assert normalize(str) == normalize('str')

    class Class(object):
        pass

    obj = Class()
    assert normalize(obj) == normalize(obj.__dict__)

# Generated at 2022-06-22 18:34:44.267251
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # if issubclass(WritableStream, object) and \
    #                                       not sys.version_info.major == 2:
    #     assert True
    # else:
    #     # Python 2 doesn't allow to do this.
    #     assert False

    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

# Generated at 2022-06-22 18:34:48.973854
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(iter([1, 2])) == (1, 2)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)



# Generated at 2022-06-22 18:34:53.033334
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(6) == (6,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple({1, 2}) == (1, 2)



# Generated at 2022-06-22 18:34:57.525559
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(['a', 'b']) == ('a', 'b')
    assert ensure_tuple(('c', 'd')) == ('c', 'd')
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(5) == (5,)




# Generated at 2022-06-22 18:35:03.569166
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    file_obj = io.BytesIO()
    b = WritableStream()
    b.write = lambda s: file_obj.write(s.encode('utf8'))
    b.write('היי')
    assert file_obj.getvalue() == b'\xd7\x94\xd7\x99\xd7\x99'
    assert isinstance(b, WritableStream)
    assert b.write == (lambda s: file_obj.write(s.encode('utf8')))

# Generated at 2022-06-22 18:35:15.191195
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamSubclass1(object):
        def write(self, s):
            pass
        def foo(self):
            pass

    from collections import UserList
    class WritableStreamSubclass2(UserList):
        def write(self, s):
            pass
        def foo(self):
            pass

    class WritableStreamSubclass3(list):
        def write(self, s):
            pass
        def foo(self):
            pass

    class WritableStreamSubclass4(WritableStreamSubclass1):
        def write(self, s):
            pass

    class WritableStreamSubclass5(WritableStreamSubclass3):
        def write(self, s):
            pass


# Generated at 2022-06-22 18:35:20.360876
# Unit test for constructor of class WritableStream
def test_WritableStream():
    with open('test_WritableStream.txt', 'wb') as output_file:
        output_file.write(b'This file was used to test the `WritableStream` class.')
        output_file.write(b'\n')
        output_file.write(b'You can delete it without worrying.')
    assert issubclass(output_file.__class__, WritableStream)



# Generated at 2022-06-22 18:35:25.788438
# Unit test for function truncate
def test_truncate():
    assert truncate(None, None) == None
    assert truncate(None, 5) == None
    assert truncate('hi', None) == 'hi'
    assert truncate('hi', 5) == 'hi'
    assert truncate('hi', 2) == 'hi'
    assert truncate('hi', 1) == 'hi'
    assert truncate('hi', 0) == 'hi'
    assert truncate('supercalifragilisticexpialidocious',
                    9) == 'super...ous'

# Generated at 2022-06-22 18:35:29.206047
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass
    assert issubclass(WritableStreamSubclass, WritableStream) is True


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 18:35:37.093480
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('string') == ('string',)
    assert ensure_tuple(123) == (123,)
    assert ensure_tuple(['a', 'b', 'c']) == ('a', 'b', 'c')
    assert ensure_tuple(set('dog')) == ('d', 'g', 'o')
    assert ensure_tuple(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert ensure_tuple(('a', 'b', 'c', 'd', 'e')) == ('a', 'b', 'c', 'd', 'e')



# Generated at 2022-06-22 18:35:47.561350
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple((1, 2, 3, 4, 5, 6, 7, 8)) == (1, 2, 3, 4, 5, 6, 7, 8)

    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(10) == (10,)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(['a', 'b', 'c']) == (['a', 'b', 'c'],)

# Generated at 2022-06-22 18:35:53.234454
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('foo') == 'foo'
    for char in range(256):
        assert shitcode(chr(char)) == chr(char)
    assert shitcode('a' * 1023 + chr(0) + 'b' * 1023) == \
                                          'a' * 1023 + '?' + 'b' * 1023