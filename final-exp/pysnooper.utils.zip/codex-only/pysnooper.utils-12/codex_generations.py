

# Generated at 2022-06-22 18:25:56.082179
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyClass(WritableStream):
        def __init__(self):
            pass

        def write(self, s):
            pass

    assert isinstance(MyClass(), WritableStream)



# Generated at 2022-06-22 18:26:01.069365
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple((5, 6)) == (5, 6)
    assert ensure_tuple([5, 6]) == (5, 6)
    assert ensure_tuple((5, 6, 7)) == (5, 6, 7)
    assert ensure_tuple(set((5, 6, 7))) == (5, 6, 7)
    assert ensure_tuple(set((5, 6, 7, 7))) == (5, 6, 7)



# Generated at 2022-06-22 18:26:03.404494
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class StubWritable(object):
        def write(self, s):
            pass
    stub_writable = StubWritable()
    assert isinstance(stub_writable, WritableStream)



# Generated at 2022-06-22 18:26:07.839456
# Unit test for function truncate
def test_truncate():
    result = truncate('123456789', max_length=5)
    assert result == '1...9'

    result = truncate('123456789', max_length=9)
    assert result == '123456789'

    result = truncate('1', max_length=None)
    assert result == '1'






# Generated at 2022-06-22 18:26:18.096951
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("<class 'module_name.module_name.module_name'>: "
                          "hello") == "<class 'module_name.module_name.module_name'>: hello"
    assert normalize_repr("<class 'module_name.module_name.module_name'>: "
                          "hello at 0x00012345") == "<class 'module_name.module_name.module_name'>: hello"
    assert normalize_repr("<class 'module_name.module_name.module_name'>: "
                          "hello at 0xABCDEF0123456789") == "<class 'module_name.module_name.module_name'>: hello"

# Generated at 2022-06-22 18:26:29.227532
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'
    assert get_shortish_repr(1, max_length=-10) == '1'
    assert get_shortish_repr(123456789, max_length=3) == '123...789'

# Generated at 2022-06-22 18:26:31.157747
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class TestClass(WritableStream):
        def write(self, s):
            pass
    assert issubclass(TestClass, WritableStream)



# Generated at 2022-06-22 18:26:37.314744
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (
        (int, 'hi'),
    )) == 'hi'
    assert get_repr_function(1, (
        (lambda x: x == 1, 'hi'),
    )) == 'hi'
    assert get_repr_function(1, (
        (lambda x: x == 2, 'hi'),
    )) == repr
    assert get_repr_function(1, (
        (lambda x: x == 2, 'hi'),
        (int, 'hello'),
    )) == 'hello'
    assert get_repr_function(1, (
        (lambda x: x == 2, 'hi'),
        (float, 'hello'),
    )) == repr

# Generated at 2022-06-22 18:26:42.302502
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(x for x in range(3)) == (0, 1, 2)



# Generated at 2022-06-22 18:26:50.901865
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A(object):
        __repr__ = lambda self: '123456789'

    class B(object):
        pass

    assert get_shortish_repr(A()) == '123456789'
    assert get_shortish_repr(A(), max_length=5) == '12345'
    assert get_shortish_repr(A(), max_length=9) == '123456789'
    assert get_shortish_repr(A(), max_length=10) == '123456789'
    assert get_shortish_repr(A(), max_length=3) == '123...89'

    assert get_shortish_repr(A(), custom_repr=((A, lambda x: 'A!'))) == 'A!'

# Generated at 2022-06-22 18:26:55.156547
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple([5, 6]) == (5, 6)
    assert ensure_tuple('meow') == ('meow',)

# Generated at 2022-06-22 18:27:03.586019
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple({1, 2, 3}) == ({1, 2, 3},)
    assert ensure_tuple({'a': 1, 'b': 2, 'c': 3}) == ({'a': 1, 'b': 2, 'c': 3},)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(1j + 2) == (1j + 2,)
    assert ensure_tuple(x for x in 'hello') == (x for x in 'hello')




# Generated at 2022-06-22 18:27:13.880436
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(
        5,
        (
            (lambda x: isinstance(x, int), lambda x: 'int: %s' % str(x)),
            (lambda x: isinstance(x, list), lambda x: 'list: %s' % str(x))
        )
    )(5) == "int: 5"
    assert get_repr_function(
        [],
        (
            (lambda x: isinstance(x, int), lambda x: 'int: %s' % str(x)),
            (lambda x: isinstance(x, list), lambda x: 'list: %s' % str(x))
        )
    )([5, 'a']) == "list: [5, 'a']"

# Generated at 2022-06-22 18:27:22.919085
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("<String at 0x12345678>") == "<String>"
    assert normalize_repr("<String>") == "<String>"
    assert normalize_repr("<String at 0x12345678> at 0x1234") == "<String> at 0x1234"
    assert normalize_repr("<String at 0x12345678> (0x1234)") == "<String> (0x1234)"
    assert normalize_repr("<String> (0x1234)") == "<String> (0x1234)"
    assert normalize_repr("<String> at 0x1234") == "<String> at 0x1234"

# Generated at 2022-06-22 18:27:25.288283
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(WritableStream):
        pass
    try:
        issubclass(X, WritableStream)
    except TypeError:
        pass
    else:
        raise TypeError



# Generated at 2022-06-22 18:27:28.330566
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcdef') == 'abcdef'



# Generated at 2022-06-22 18:27:33.262817
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def __init__(self):
            self.output = []

        def write(self, s):
            self.output.append(s)
    a = A()
    a.write('meow')
    assert a.output == ['meow']
    assert isinstance(a, WritableStream)

# Generated at 2022-06-22 18:27:44.168499
# Unit test for function ensure_tuple
def test_ensure_tuple():
    class MyClass:
        pass

    # Test that number is put in a tuple:
    assert ensure_tuple(3) == (3,)

    # Test that string is put in a tuple:
    assert ensure_tuple('abc') == ('abc',)

    # Test that list is put in a tuple:
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)

    # Test that set is put in a tuple:
    assert ensure_tuple({1, 2, 3}) == (1, 2, 3)

    # Test that tuple is not changed:
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)

    # Test that object is put in a tuple:
    assert ensure_tuple(MyClass()) == (MyClass(),)

    # Test that None is put in

# Generated at 2022-06-22 18:27:51.828702
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdef', 10) == 'abcdef'
    assert truncate('abcdef', 6) == 'abcdef'
    assert truncate('abcdef', 5) == 'ab...f'
    assert truncate('abcdef', 3) == 'a...f'
    assert truncate('abcdef', 1) == '...'
    assert truncate('abcdef', 0) == ''
    assert truncate('abcdef', -1) == ''
    assert truncate('abcdef', None) == 'abcdef'

# Generated at 2022-06-22 18:27:55.248332
# Unit test for function normalize_repr
def test_normalize_repr():
    class Foo(object):
        def __init__(self, x):
            self.x = x
        def __repr__(self):
            return 'f({})'.format(self.x)
    foo = Foo(3)

    assert normalize_repr(repr(foo)) == 'f(3)'

# Generated at 2022-06-22 18:27:58.122823
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(1) == (1,)




# Generated at 2022-06-22 18:28:06.974156
# Unit test for function truncate
def test_truncate():
    assert truncate('123456', None) == '123456'
    assert truncate('123456', 7) == '123456'
    assert truncate('123456', 6) == '1...6'
    assert truncate('123456', 5) == '1...6'
    assert truncate('123456', 4) == '1...'
    assert truncate('123456', 3) == '1..'
    assert truncate('123456', 2) == '1.'
    assert truncate('123456', 1) == '.'
    assert truncate('123456', 0) == ''
    assert truncate('', 0) == ''
    assert truncate('', 10) == ''
    assert truncate('1234567890', 10) == '1234567890'




# Generated at 2022-06-22 18:28:14.534816
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'hi') == u'hi'
    assert shitcode(u'hi\n') == u'hi\n'
    assert shitcode(u'hi\r') == u'hi\r'
    assert shitcode(u'hi\r\n') == u'hi\r\n'
    assert shitcode(u'hi\r\nthere') == u'hi\r\nthere'
    assert shitcode('hi') == 'hi'
    assert shitcode('hi\n') == 'hi\n'
    assert shitcode('hi\r') == 'hi\r'
    assert shitcode('hi\r\n') == 'hi\r\n'
    assert shitcode('hi\r\nthere') == 'hi\r\nthere'

# Generated at 2022-06-22 18:28:24.817095
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((1, '1'))) == '1'
    assert get_repr_function(1, ((1, '1'),)) == '1'
    assert get_repr_function(1, ((int, 'i'))) == 'i'
    assert get_repr_function(1.5, ((int, 'i'),)) == repr
    assert get_repr_function(1.5, ((float, 'f'))) == 'f'
    assert get_repr_function(1, ((str, 's'), (float, 'f'))) == repr
    assert get_repr_function(1, ((int, 'i'), (float, 'f'))) == 'i'

# Generated at 2022-06-22 18:28:29.416699
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(['meow', 'purr']) == ('meow', 'purr')
    assert ensure_tuple(('meow', 'purr')) == ('meow', 'purr')
    assert ensure_tuple((k for k in (3, 4))) == (3, 4)



# Generated at 2022-06-22 18:28:33.012622
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'hello') == u'hello'
    assert shitcode(u'cyrilic Абв абв') == u'cyrilic ? ? ? ? ?'
    assert shitcode(u'£∞àáç»ç«') == u'?? ? ? ? ?'




# Generated at 2022-06-22 18:28:39.059738
# Unit test for function normalize_repr
def test_normalize_repr():
    x = list(range(10))
    address = hex(id(x))
    assert normalize_repr(repr(x)).endswith('>')
    assert normalize_repr(repr(x)).startswith('[')
    assert normalize_repr(repr(x))[1:-1] == '0, 1, 2, 3, 4, 5, 6, 7, 8, 9'
    assert normalize_repr(repr(x)) not in [repr(x), address]
    assert normalize_repr(repr(x)) not in [repr(x), ' ' + address]


# Generated at 2022-06-22 18:28:45.670459
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', 9) == 'hello'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 4) == 'he...'
    assert truncate('hello', 3) == 'he...'
    assert truncate('hello', 2) == 'he...'
    assert truncate('hello', 1) == 'h...'
    assert truncate('hello', 0) == '...'
    assert truncate('hello', -1) == '...'

# Generated at 2022-06-22 18:28:56.510579
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A:
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)
    class B:
        pass
    assert not issubclass(B, WritableStream)
    class C:
        def write(self, s):
            pass
        def flush(self):
            pass
    assert issubclass(C, WritableStream)
    class D(C):
        pass
    assert issubclass(D, WritableStream)
    class E:
        def write(self, s):
            return 'bleh'
    assert not issubclass(E, WritableStream)
    class F:
        def write(self, s):
            pass
        def flush(self):
            pass
        def close(self):
            pass
    assert issubclass(F, WritableStream)

# Generated at 2022-06-22 18:29:00.064687
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('blah blah blah') == 'blah blah blah'
    assert normalize_repr('blah blah blah at 0x5678') == 'blah blah blah'



# Generated at 2022-06-22 18:29:04.528736
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    a = A()

    assert isinstance(a, WritableStream)

    class B(WritableStream):
        pass

    b = B()

    assert not isinstance(b, WritableStream)




# Generated at 2022-06-22 18:29:11.987278
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C: pass
    class D: pass
    class E: pass
    a = A()
    b = B()
    c = C()
    d = D()
    assert get_repr_function(a, ((A, lambda a: 'a'),)) == 'a'
    assert get_repr_function(a, ((B, lambda a: 'b'),)) != 'b'
    assert get_repr_function(a, ((B, None),)) is None
    assert get_repr_function(a, ((b, lambda a: 'b'),)) == 'b'
    assert get_repr_function(a, ((b, None),)) is None

# Generated at 2022-06-22 18:29:22.887574
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f') == '\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'

# Generated at 2022-06-22 18:29:32.579296
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 8) == '12345...'
    assert truncate('123456789', 7) == '1234...'
    assert truncate('123456789', 6) == '123...'
    assert truncate('123456789', 5) == '12...'
    assert truncate('123456789', 4) == '1...'
    assert truncate('123456789', 3) == '...'
    assert truncate('123456789', 2) == '...'
    assert truncate('123456789', 1) == '...'
    assert truncate('123456789', 0) == '...'



# Generated at 2022-06-22 18:29:36.177172
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class IntWriter(WritableStream):

        def __init__(self):
            self.foos = []


        def write(self, s):
            self.foos.extend(list(map(int, list(s))))

    IntWriter()

# Generated at 2022-06-22 18:29:38.433516
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s): pass
        def __init__(self): self.write('hi')
    MyWritableStream()

# Generated at 2022-06-22 18:29:42.553143
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Good(WritableStream):
        def write(self, s):
            pass
    class Bad(WritableStream):
        write = None
    assert issubclass(Good, WritableStream)
    assert not issubclass(Bad, WritableStream)

# Generated at 2022-06-22 18:29:46.563936
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    r = get_shortish_repr(object(), max_length=10)
    assert len(r) == 10
    assert r[-3:] == '...'
    assert r[:7] == '<object'



# Generated at 2022-06-22 18:29:50.845112
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function('a', ((str, str),)) is str
    assert get_repr_function('a', ((str, str), (dict, dict))) is str
    assert get_repr_function(1, ((str, str), (dict, dict))) is repr

# Generated at 2022-06-22 18:29:58.948868
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnopqrstuvwxyz', max_length=10) == \
                                                           'abcdefg...stuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', max_length=11) == \
                                                           'abcdefg...stuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', max_length=12) == \
                                                           'abcdefgh...stuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', max_length=None) == \
                                                 'abcdefghijklmnopqrstuvwxyz'

# Generated at 2022-06-22 18:30:08.604799
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('a') == 'a'
    assert shitcode('#') == '#'
    assert shitcode('עברית') == '?' * 6
    assert shitcode(u'אותיות יווניות ελληνικά') == '?' * 28
    assert shitcode('\x00\x00') == '??'
    assert shitcode('\xff\xff') == '??'
    assert shitcode('\x7f\x00') == '?\x00'
    assert shitcode('\x00\x7f') == '\x00?'
    assert shitcode('\x80\x00') == '?' * 2

# Generated at 2022-06-22 18:30:20.466590
# Unit test for constructor of class WritableStream
def test_WritableStream():

    from .warnings import warning
    from .passthrough_stream import PassthroughStream

    class TestWritableStream(WritableStream):
        def write(self, s):
            pass

    TestWritableStream()

    class TestWritableStream(object):
        def write(self, s):
            pass

    try:
        TestWritableStream()
    except TypeError:
        pass
    else:
        warning('Expected TestWritableStream() to fail because it does not '
                'inherit from `WritableStream`.')

    class TestWritableStream(WritableStream):
        pass

    try:
        TestWritableStream()
    except TypeError:
        pass
    else:
        warning('Expected TestWritableStream() to fail because it does not '
                'implement `write`')


# Generated at 2022-06-22 18:30:27.903876
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from myhdl import Signal, intbv, simSignals

    custom_repr = (
        (Signal, lambda x: str(x))
    )

    class A(object):
        def __repr__(self):
            return 'A'
    a = A()

    assert get_shortish_repr(a, custom_repr) == 'A'

    sig = Signal(bool(1))
    assert get_shortish_repr(sig, custom_repr) == 'True'

    class B(object):
        def __repr__(self):
            raise ValueError('bad repr')

    b = B()
    assert get_shortish_repr(b, custom_repr) == 'REPR FAILED'

    iv = intbv(5)
    assert get_shortish_

# Generated at 2022-06-22 18:30:32.533513
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import contextlib


    class A(contextlib.contextmanager):

        def __enter__(self):
            pass

        def __exit__(self, *args):
            pass
    with A() as a:
        assert isinstance(a, WritableStream)

# Generated at 2022-06-22 18:30:37.828049
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('abc') == 'abc'
    assert normalize_repr('abc at 0x1234567') == 'abc'
    assert normalize_repr('abc at 0x123456789ABC') == 'abc'
    assert normalize_repr('abc at 0x123') == 'abc at 0x123'




# Generated at 2022-06-22 18:30:46.867470
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1234567, max_length=1) == '1...7'
    assert get_shortish_repr(1234567, max_length=3) == '1...7'
    assert get_shortish_repr(1234567, max_length=4) == '12...7'
    assert get_shortish_repr(1234567, max_length=5) == '123...7'
    assert get_shortish_repr(1234567, max_length=6) == '1...67'

# Generated at 2022-06-22 18:30:55.058628
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(object): pass
    a = A()
    b = B()
    assert (get_repr_function(a, [
        (A, lambda: 'A'),
        (B, lambda: 'B'),
    ]))() == 'A'
    assert (get_repr_function(b, [
        (A, lambda: 'A'),
        (B, lambda: 'B'),
    ]))() == 'B'
    assert (get_repr_function(42, [
        (A, lambda: 'A'),
        (B, lambda: 'B'),
    ]))() == '42'
    assert (get_repr_function(42, [
        (A, lambda: 'A'),
        (B, lambda: 'B'),
    ]))() == '42'

# Generated at 2022-06-22 18:31:02.621360
# Unit test for function truncate
def test_truncate():
    assert truncate('', 0) == ''
    assert truncate('', 1) == ''
    assert truncate('hello world', None) == 'hello world'
    assert truncate('hello world', 11) == 'hello world'
    assert truncate('hello world', 10) == 'hello worl'
    assert truncate('hello world', 9) == 'hello wo'
    assert truncate('hello world', 8) == 'hello w'
    assert truncate('hello world', 7) == 'hello '
    assert truncate('hello world', 6) == 'hello'
    assert truncate('hello world', 5) == 'he'
    assert truncate('hello world', 4) == 'h'
    assert truncate('hello world', 3) == 'h'
    assert truncate('hello world', 2) == 'h'

# Generated at 2022-06-22 18:31:04.584738
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class T:
        pass
    assert issubclass(T, WritableStream)



# Generated at 2022-06-22 18:31:08.992007
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(tuple(range(5))) == (0, 1, 2, 3, 4)

# Generated at 2022-06-22 18:31:12.364048
# Unit test for function normalize_repr
def test_normalize_repr():
    class X(object):
        def __repr__(self):
            return '<X at 0xDEADBEEF>'
    
    assert normalize_repr(repr(X())) == '<X>'

# Generated at 2022-06-22 18:31:16.598277
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import io
    class A:
        pass
    class B(A):
        def write(self, s):
            pass

    assert issubclass(io.BytesIO, WritableStream)
    assert issubclass(io.StringIO, WritableStream)
    assert not issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)
    assert not issubclass(WritableStream, WritableStream)

# Generated at 2022-06-22 18:31:23.186050
# Unit test for function normalize_repr
def test_normalize_repr():
    all_repr = [
        (normalize_repr(repr(x)), repr(x))
        for x in [5, 'a', 'abcdef', [5, 6, 7], {5: 67}]
    ]
    all_repr += [
        (normalize_repr(repr(object())), '<object object at 0x%x>' % id(object()))
    ]
    for normalized_repr, repr_ in all_repr:
        assert DEFAULT_REPR_RE.search(normalized_repr) is None, repr_


if __name__ == '__main__':
    test_normalize_repr()

# Generated at 2022-06-22 18:31:32.797366
# Unit test for function normalize_repr
def test_normalize_repr():
    def assert_normalize(input, output):
        assert normalize_repr(input) == output
        
    assert_normalize(r'a', r'a')
    assert_normalize(r'a at 0x1', r'a')
    assert_normalize(r'a at 0x123ffa', r'a')
    assert_normalize(r'a at 0x123ffad', r'a')
    assert_normalize(r'a at 0x123ffadf', r'a')
    assert_normalize(r'a at 0x123ffadffa', r'a')
    assert_normalize(r'a at 0x123ffadffad', r'a')
    assert_normalize(r'a at 0x123ffadffadf', r'a')
    assert_normal

# Generated at 2022-06-22 18:31:35.703672
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream): pass
    assert MyWritableStream()

# Unit tests for ensure_tuple

# Generated at 2022-06-22 18:31:40.438639
# Unit test for function ensure_tuple
def test_ensure_tuple():
    my_list = [1, 2, 3]
    my_tuple = (1, 2, 3)
    my_int = 1
    assert ensure_tuple(my_list) == (1, 2, 3)
    assert ensure_tuple(my_tuple) == (1, 2, 3)
    assert ensure_tuple(my_int) == (1,)



# Generated at 2022-06-22 18:31:50.956845
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass

    a = A()
    b = B()

    custom_repr = [(A, lambda x: 'A!'), (B, lambda x: 'B!')]

    assert get_repr_function(a, custom_repr) is repr
    assert get_repr_function(b, custom_repr) is repr

    assert get_repr_function(a, custom_repr+[(lambda x: True, lambda x: 'x')])(a) == 'A!'
    assert get_repr_function(b, custom_repr+[(lambda x: True, lambda x: 'x')])(b) == 'B!'

    assert get_repr_function({}, custom_repr) is repr

# Generated at 2022-06-22 18:31:58.320094
# Unit test for function get_shortish_repr

# Generated at 2022-06-22 18:32:00.359523
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', 5) == '12...'

if __name__ == '__main__':
    test_truncate()

# Generated at 2022-06-22 18:32:08.454480
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('python\u2019s') == 'python?s'
    assert shitcode('\u2013') == '?'
    assert shitcode('\u2072') == '?'
    assert shitcode('\u3044') == '?'
    assert shitcode('\u0BAD') == '?'
    assert shitcode('\uFFF9') == '?'
    assert shitcode('\u00FF') == '\xFF'


test_shitcode()

# Generated at 2022-06-22 18:32:11.943110
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from . import mock_stream

    class MyMockWritableStream(mock_stream.MockStream):
        __metaclass__ = WritableStream
        def write(self, s):
            pass

    my_mock_writable_stream = MyMockWritableStream()
    isinstance(my_mock_writable_stream, WritableStream)

# Generated at 2022-06-22 18:32:22.412064
# Unit test for function normalize_repr

# Generated at 2022-06-22 18:32:28.129144
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(()) == ()
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(u'abc') == (u'abc',)
    assert ensure_tuple(type(None)) == (type(None),)
    assert ensure_tuple(set('foo')) == ('f', 'o')

# Generated at 2022-06-22 18:32:39.553897
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (
        (lambda x: x == 1, lambda x: '1'),
    ))(1) == '1'
    assert get_repr_function(1, (
        (lambda x: x == 2, lambda x: '2'),
    ))(1) == repr(1)
    assert get_repr_function(1.5, (
        (lambda x: x == 1, str),
    ))(1.5) == str(1.5)
    assert get_repr_function('a', (
        (lambda x: x == 1, str),
        (lambda x: x == 1, str),
        (lambda x: x == 'a', lambda x: 'A'),
    ))('a') == 'A'
    the_type = type(1)
    assert get_

# Generated at 2022-06-22 18:32:47.683890
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    if sys.version_info.major < 3:
        from StringIO import StringIO
        class MyStringIO(StringIO):
            def write(self, s):
                StringIO.write(self, s)
        my_string_io = MyStringIO()
        assert isinstance(my_string_io, WritableStream)
    else:
        from io import StringIO
        class MyStringIO(StringIO):
            def write(self, s):
                StringIO.write(self, s)
        my_string_io = MyStringIO()
        assert isinstance(my_string_io, WritableStream)
    assert isinstance(my_string_io, WritableStream)



# Generated at 2022-06-22 18:32:49.586539
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class TestClass(WritableStream):
        def write(self, s):
            return s

    test_class = TestClass()

    class TestSubClass(TestClass):
        pass

    test_sub_class = TestSubClass()

# Generated at 2022-06-22 18:32:52.340781
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert isinstance(MyWritableStream(), WritableStream)



# Generated at 2022-06-22 18:32:59.693942
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(3.7) == (3.7,)
    assert ensure_tuple('hey') == ('hey',)

    assert ensure_tuple(()) == ()
    assert ensure_tuple([]) == ()
    assert ensure_tuple('') == ('',)

    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([3.7]) == (3.7,)

    assert ensure_tuple((3, 7)) == (3, 7)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)






# Generated at 2022-06-22 18:33:05.839193
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, custom_repr=[(lambda x: True,
                                              lambda y: 'custom')]) == 'custom'

    assert get_shortish_repr(object) == '<class \'object\'>'



# Generated at 2022-06-22 18:33:15.510167
# Unit test for function get_repr_function
def test_get_repr_function():
    import re
    assert get_repr_function(None, custom_repr=()) is repr
    assert get_repr_function("hello", custom_repr=()) is repr

    assert get_repr_function(
        None, custom_repr=((None, lambda i: '<>'),)
    )(None) == '<>'
    assert get_repr_function(
        "hello", custom_repr=((None, lambda i: '<>'),)
    )("hello") == '<>'

    assert get_repr_function(
        None, custom_repr=((lambda i: i is None, lambda i: '<>'),)
    )(None) == '<>'

# Generated at 2022-06-22 18:33:19.755909
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('xyz') == 'xyz'
    assert shitcode('xy\x01z') == 'xy?z'
    assert shitcode(u'\u0411') == '?'
    assert shitcode('xy\u0411z') == 'xy?z'
    assert shitcode('\x01') == '?'



# Generated at 2022-06-22 18:33:31.037805
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890ABCDE', 0) == ''
    assert truncate('1234567890ABCDE', 1) == '1'
    assert truncate('1234567890ABCDE', 2) == '12'
    assert truncate('1234567890ABCDE', 3) == '123'
    assert truncate('1234567890ABCDE', 4) == '1234'
    assert truncate('1234567890ABCDE', 5) == '12345'
    assert truncate('1234567890ABCDE', 6) == '123456'
    assert truncate('1234567890ABCDE', 7) == '1234567'
    assert truncate('1234567890ABCDE', 8) == '12345678'
    assert truncate('1234567890ABCDE', 9) == '123456789'
   

# Generated at 2022-06-22 18:33:34.742574
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(400) == (400,)
    assert ensure_tuple((400,)) == (400,)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(dict()) == ({},)
    assert ensure_tuple([]) == ([],)
    assert ensure_tuple(([],)) == ([],)



# Generated at 2022-06-22 18:33:37.264338
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Something(WritableStream):
        def write(self, s):
            pass
    assert issubclass(Something, WritableStream)



# Generated at 2022-06-22 18:33:42.030932
# Unit test for function truncate
def test_truncate():
    for string, max_length, result in [
        ('', 3, ''),
        ('a', 3, 'a'),
        ('ab', 3, 'ab'),
        ('abc', 3, 'abc'),
        ('abcd', 3, '...'),
        ('abcde', 3, '...'),
        ('abcdefg', 3, '...'),
    ]:
        assert truncate(string, max_length) == result



# Generated at 2022-06-22 18:33:47.980058
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('אאאאא') == '?????'
    assert shitcode(u'אאאאא') == '?????'
    assert shitcode('abc') == 'abc'
    assert shitcode(u'abc') == 'abc'
    assert shitcode(('טוב', 'אמור')) == '????,????'
    assert shitcode((u'טוב', u'אמור')) == '????,????'
    assert shitcode(['טוב', 'אמור']) == '????,????'
    assert shitcode([u'טוב', u'אמור']) == '????,????'
    assert shitcode(('abc', 'abc')) == 'abc,abc'

# Generated at 2022-06-22 18:33:51.159287
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class StreamImplementation(WritableStream):
        def write(self, s):
            pass

    stream_implementation = StreamImplementation()
    stream_implementation.write('yo')

# Generated at 2022-06-22 18:33:54.054878
# Unit test for function shitcode
def test_shitcode():
    assert shitcode("test") == "test"
    assert shitcode("test\x00") == "test?"
    assert shitcode("test\xff") == "test?"


# Generated at 2022-06-22 18:33:59.239448
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Fooble(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s
    
    f = Fooble()
    f.write('hi')
    assert f.s == 'hi'


# TODO: add tests for ensure_tuple and get_repr_function

# Generated at 2022-06-22 18:34:06.063526
# Unit test for function normalize_repr
def test_normalize_repr():
    from pickle import dumps

    class C(object):
        def __init__(self, x):
            self.x = x
        def __repr__(self):
            return 'C({})'.format(self.x)

    objects = [
        1,
        '1',
        C(1)
    ]

    for obj in objects:
        assert normalize_repr(repr(obj)) == repr(obj)
        assert normalize_repr(repr(dumps(obj))) == repr(dumps(obj))



# Generated at 2022-06-22 18:34:09.515208
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .pycompat import BytesIO
    import io
    assert issubclass(io.TextIOWrapper, WritableStream)
    assert issubclass(io.BufferedWriter, WritableStream)
    assert issubclass(BytesIO, WritableStream)



# Generated at 2022-06-22 18:34:14.896074
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStr(str):
        pass

    assert not isinstance(MyStr, WritableStream)

    class MyWritableStr(str, metaclass=ABC):
        @abc.abstractmethod
        def write(self, s):
            pass

    assert isinstance(MyWritableStr, WritableStream)



# Generated at 2022-06-22 18:34:24.419750
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(['1']) == ('1',)
    assert ensure_tuple(('1', )) == ('1',)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple([(1, )]) == ((1, ),)
    assert ensure_tuple(((1, ), )) == ((1, ),)
    assert ensure_tuple([([1], ), ([1, 2], )]) == (([1], ), ([1, 2], ))


# Generated at 2022-06-22 18:34:35.977836
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class X(object):
        def __repr__(self):
            return 'REPR'

        def __str__(self):
            return 'STR'

    # should use default repr
    assert get_shortish_repr(1) == '1'

    # should use the custom repr
    assert get_shortish_repr(1, custom_repr=[(int, lambda x: '2')]) == '2'

    # should use custom repr for the subclasses of int
    assert get_shortish_repr(1.0, custom_repr=[(int, lambda x: '2')]) == '2.0'

    # should use default repr for the float
    assert get_shortish_repr(1.0, custom_repr=[(int, lambda x: '2')]) == '2.0'

   

# Generated at 2022-06-22 18:34:45.342102
# Unit test for function truncate
def test_truncate():
    # `assert` calls `truncate` to generate an error message if fails.
    # So we can't use `assert` in this test, to avoid infinite recursion.
    assert truncate('spam', 5) == 'spam'
    assert truncate('spam', 6) == 'spam'
    assert truncate('spam', 7) == 'spam'
    assert truncate('spam', 3) == 'spa'
    assert truncate('spam', 2) == 's'
    assert truncate('spam', 4) == 'spa'
    assert truncate('spam', 5) == 'spam'
    assert truncate('spam', 6) == 'spam'
    assert truncate('spam', 10) == 'spam'



# Generated at 2022-06-22 18:34:48.289217
# Unit test for function truncate
def test_truncate():
    assert truncate('abcd', None) == 'abcd'
    assert truncate('abcd', 4) == 'abcd'
    assert truncate('abcd', 3) == 'abc'
    assert truncate('abcd', 1) == 'a'
    assert truncate('abcd', 0) == ''



# Generated at 2022-06-22 18:34:53.159523
# Unit test for constructor of class WritableStream
def test_WritableStream():
    """
    This tests the purpose of the constructor of class WritableStream by
    verifying that a class that implements the required abstract methods
    is recognized as subclass of WritableStream.
    """
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

# Generated at 2022-06-22 18:35:00.942160
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(('meow',)) == ('meow',)
    assert ensure_tuple(['meow']) == ('meow',)
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(('m', 'e', 'o', 'w')) == ('m', 'e', 'o', 'w')
    assert ensure_tuple(set('meow')) == ('e', 'm', 'o', 'w')
    assert ensure_tuple(range(5)) == (0, 1, 2, 3, 4)
    assert ensure_tuple(()) == ()
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple(None) == (None,)






# Generated at 2022-06-22 18:35:12.658206
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', 3) == 'hel'
    assert truncate('hello', 4) == 'hell'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 6) == 'hello'
    assert truncate('hello', 7) == 'hello'
    assert truncate('hello', 8) == 'hello'
    assert truncate('hello', 9) == 'hello'
    assert truncate('hello', 10) == 'hello'
    assert truncate('hello', 11) == 'hello'
    assert truncate('hello', 12) == 'hello'
    assert truncate('hello', 13) == 'hello'
    assert truncate('hello', None) == 'hello'
    assert truncate('hello', None) == 'hello'
    assert truncate('hello', 14) == 'hello'
    assert trunc

# Generated at 2022-06-22 18:35:15.576676
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'\0\1') == '??'

# Generated at 2022-06-22 18:35:20.399299
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    long_string = 'this_is_a_long_string'
    assert get_shortish_repr(long_string, max_length=10) == truncate(long_string, 10)

    assert get_shortish_repr(long_string, max_length=1000) == long_string

    assert get_shortish_repr(long_string) == long_string

# Generated at 2022-06-22 18:35:24.479848
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple('hi') == ('hi',)
    assert ensure_tuple((4, 5, 6)) == (4, 5, 6)



# Generated at 2022-06-22 18:35:31.953339
# Unit test for function get_repr_function
def test_get_repr_function():
    def int_repr(i):
        return str(i + 1)
    result = get_repr_function(5, custom_repr=[(int, int_repr)])
    assert result(5) == '6'
    assert get_repr_function('s', custom_repr=[(int, int_repr)]) == repr
    assert get_repr_function('s', custom_repr=[(int, int_repr), (1, repr)]) is repr
    assert get_repr_function(5, custom_repr=[(int, int_repr), (1, repr)]) is int_repr



# Generated at 2022-06-22 18:35:37.740029
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple([3]) == (3,)
    assert ensure_tuple((3,)) == (3,)

    class FakeIterable(object):
        def __iter__(self):
            return iter([3])
    fake_iterable = FakeIterable()
    assert ensure_tuple(fake_iterable) == (3,)

# Generated at 2022-06-22 18:35:43.114531
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple(1) == (1,)

# Generated at 2022-06-22 18:35:46.159370
# Unit test for function normalize_repr
def test_normalize_repr():
    class MyClass(object):
        pass
    my_object = MyClass()
    assert 'MyClass' in repr(my_object)
    assert 'MyClass' in normalize_repr(repr(my_object))



# Generated at 2022-06-22 18:35:57.077169
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class C(object):
        def __repr__(self):
            return '<C>'
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abcdefg') == "'abcdefg'"
    assert get_shortish_repr('abcdefghj') == "'abcdefg...j'"
    assert get_shortish_repr(C()) == '<C>'
    assert get_shortish_repr(C(), max_length=2) == '<C>'
    assert get_shortish_repr(C(), max_length=3) == '<C>'
    assert get_shortish_repr(C(), max_length=4) == '<C>'
    assert get_shortish_repr(C(), max_length=5)