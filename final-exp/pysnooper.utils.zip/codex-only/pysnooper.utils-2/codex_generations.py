

# Generated at 2022-06-22 18:25:57.864147
# Unit test for function shitcode
def test_shitcode():
    test_strings = [
        'Hello world!',
        'Hello 😄 world!',
        'Hello \uFFFF\xFF world!'
    ]
    for s in test_strings:
        assert shitcode(s) == shitcode(s.encode('utf-8'))




# Generated at 2022-06-22 18:26:01.242264
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple([5]) == ([5],)
    assert ensure_tuple([5, 6]) == ([5, 6],)
    assert ensure_tuple(('5', 6)) == (('5', 6),)

# Generated at 2022-06-22 18:26:09.620004
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, lambda _: 'banana')]) == 'banana'

    class Class(object): pass
    obj = Class()
    assert get_repr_function(obj, [(Class, lambda _: 'banana')]) == 'banana'
    assert get_repr_function(obj, [(Class, lambda _: 'banana'),
                                   (int, lambda _: 'pear')]) == 'banana'
    assert get_repr_function(obj, [(int, lambda _: 'pear')]) == repr
    assert get_repr_function(obj, [(Class, None),
                                   (int, lambda _: 'pear')]) == repr

# Generated at 2022-06-22 18:26:20.074105
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class C: pass
    repr_of_c = repr(C())
    assert repr_of_c == "__main__.C()"
    assert get_shortish_repr(C(), max_length=6) == "__main__.C()"
    assert get_shortish_repr(C(), max_length=7) == "__main__.C()"
    assert get_shortish_repr(C(), max_length=8) == "__main__.C()"
    assert get_shortish_repr(C(), max_length=9) == "__main__.C()"
    assert get_shortish_repr(C(), max_length=10) == "__main__.C()"

# Generated at 2022-06-22 18:26:22.239830
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo:
        def write(self, s):
            return s
    class Bar:
        pass
    assert(issubclass(Foo, WritableStream))
    assert(not issubclass(Bar, WritableStream))



# Generated at 2022-06-22 18:26:32.849791
# Unit test for function truncate
def test_truncate():
    """
    This unit-test tests the `truncate' function, which truncates its input.
    """
    # The do-nothing cases:
    assert truncate('abcdef', None) == 'abcdef'
    assert truncate('abcdef', 6) == 'abcdef'
    assert truncate('abcdef', 7) == 'abcdef'
    assert truncate('abcdef', 100) == 'abcdef'

    # The real cases:
    assert truncate('abcdef', 5) == 'a...f'
    assert truncate('abcdef', 4) == 'a...f'
    assert truncate('abcdef', 3) == 'a...'
    assert truncate('abcdef', 2) == 'a...'
    assert truncate('abcdef', 1) == 'a'

# Generated at 2022-06-22 18:26:35.356725
# Unit test for function shitcode
def test_shitcode():
    for s in [u'שלום', 'שלום']:
        assert shitcode(s) == '????'



# Generated at 2022-06-22 18:26:41.938953
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 5) == '123...9'
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 10) == '123456789'
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('1234567890', 11) == '1234567890'



# Generated at 2022-06-22 18:26:45.086768
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class X(object):
        def write(self, s):
            pass

    x = X()

    assert isinstance(x, WritableStream)
    assert not isinstance(object(), WritableStream)

# Generated at 2022-06-22 18:26:49.509469
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(('meow',)) == ('meow',)
    assert ensure_tuple(('meow1', 'meow2')) == ('meow1', 'meow2')
    assert ensure_tuple((('meow1', 'meow2'),)) == (('meow1', 'meow2'),)



# Generated at 2022-06-22 18:26:54.635632
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', None) == 'hello'
    assert truncate('hello world', None) == 'hello world'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 4) == 'hello'
    assert truncate('hello', 3) == '...'
    assert truncate('hello', 2) == '...'
    assert truncate('hello', 1) == '...'
    assert truncate('hello world', 11) == 'hello world'
    assert truncate('hello world', 10) == '...orld'
    assert truncate('hello world', 9) == '...orld'
    assert truncate('hello world', 8) == '...orld'
    assert truncate('hello world', 7) == '...orld'
    assert truncate('hello world', 6) == '...orld'
    assert trunc

# Generated at 2022-06-22 18:26:58.163885
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from garlicsim_lib.general_misc._utils import WritableStream
    class Test(WritableStream):
        def write(self, s):
            pass
    x = Test()
    assert isinstance(x, WritableStream)

# Generated at 2022-06-22 18:27:00.778988
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(()) == ()
    assert ensure_tuple(4) == (4,)
    assert ensure_tuple([1, 2]) == (1, 2)




# Generated at 2022-06-22 18:27:03.917673
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple([3, 4]) == (3, 4)
    assert ensure_tuple((3, 4)) == (3, 4)



# Generated at 2022-06-22 18:27:05.811038
# Unit test for function shitcode

# Generated at 2022-06-22 18:27:09.651859
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            print('writing', s)
            self.s = s

    s = MyWritableStream()
    s.write('apple')
    assert s.s == 'apple'




# Generated at 2022-06-22 18:27:12.422356
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class MyWritableStream(WritableStream):

        def write(s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-22 18:27:16.488260
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1]) == (1,)
    assert ensur

# Generated at 2022-06-22 18:27:23.311763
# Unit test for function shitcode
def test_shitcode():
    # Regular characters
    assert shitcode('hello') == 'hello'
    assert shitcode('abcd efgh') == 'abcd efgh'

    # Non-printable characters
    assert shitcode(u'\n') == '?'
    assert shitcode(u'\r') == '?'
    assert shitcode(u'\x0b') == '?'
    assert shitcode(u'\x0c') == '?'

    # Unicode characters
    assert shitcode(u'\u1f4a9') == '?'



# Generated at 2022-06-22 18:27:29.543441
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', 4) == 'abc'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 2) == 'ab...'
    assert truncate('abc', 1) == 'a...'
    assert truncate('abc', 0) == '...'



# Generated at 2022-06-22 18:27:35.154414
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(
        u'abc' + chr(0) + chr(1) + chr(3) + chr(255) + chr(256) + 'def'
    ) == 'abc?\x01\x03?def'


if sys.version_info[0] >= 3: # pragma: no cover
    def to_bytes(s):
        return s.encode('utf-8')
else:
    def to_bytes(s):
        return s

# Generated at 2022-06-22 18:27:43.731688
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\x00\x01\x02\x03') == '??\x01\x02\x03', shitcode('\x00\x01\x02\x03')
    assert shitcode('\x07\x01\x02\x03') == '\x07\x01\x02\x03', shitcode('\x07\x01\x02\x03')
    assert shitcode(u'\u1234') == '?', shitcode(u'\u1234')
    assert shitcode(u'\U00098123') == '?', shitcode(u'\U00098123')

# Generated at 2022-06-22 18:27:48.263671
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple((1, 2)) == (1, 2)



# Generated at 2022-06-22 18:27:52.672498
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(b'\x00\x01\x02\x03\x04\x05\x06\x07'
                    b'\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F') == b'????????????????'



# Generated at 2022-06-22 18:27:59.413662
# Unit test for function truncate
def test_truncate():
    assert truncate('abcde', max_length=2) == 'ab'
    assert truncate('abcde', max_length=3) == 'abc'
    assert truncate('abcde', max_length=None) == 'abcde'
    assert truncate('abcde', max_length=30) == 'abcde'
    assert truncate(u'abcde', max_length=3) == u'abc'
    assert truncate(u'abcde', max_length=None) == u'abcde'
    assert truncate(u'abcde', max_length=30) == u'abcde'

# Generated at 2022-06-22 18:28:02.358969
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    def f():
        for i in range(3):
            yield i
    assert ensure_tuple(f()) == (0, 1, 2)



# Generated at 2022-06-22 18:28:05.784455
# Unit test for function shitcode
def test_shitcode():
    if sys.version_info[0] == 3:
        assert shitcode('abc') == 'abc'
        assert shitcode('あいう') == '????'
    else:
        assert shitcode(u'abc') == 'abc'
        assert shitcode(u'あいう') == '???'



# Generated at 2022-06-22 18:28:13.991802
# Unit test for function truncate
def test_truncate():
    assert truncate('a'*10, 10) == 'a'*10
    assert truncate('a'*10, None) == 'a'*10
    assert truncate('a'*10, 100) == 'a'*10
    assert truncate('a'*10, 9) == 'a'*10
    assert truncate('a'*10, 5) == 'aa...a'
    assert truncate('a'*10, 6) == 'aaa...a'
    assert truncate('a'*10, 7) == 'aaaa...a'
    assert truncate('a'*10, 8) == 'aaaa...aa'
    assert truncate('a'*5, 8) == 'aaaa...'
    assert truncate('a'*5, 4) == '...'
    assert truncate('a'*5, 3)

# Generated at 2022-06-22 18:28:22.966065
# Unit test for function shitcode
def test_shitcode():
    for l in (
        'unicode',
        '\u1234',
#        '\U00012345',
        'abc' + '\U00012345',
        'abc' + '\U000123456',
        r'\x20',
        r'\xff',
        '',
        '\\'
    ):
        for i in range(0, len(l), 1):
            l_ = l[:i] + chr(256 + ord(l[i])) + l[i + 1:]
            assert shitcode(l_) == shitcode(l)
    print('shitcode is good to go, sir!')




# Generated at 2022-06-22 18:28:28.250336
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple('abc') == ('abc',)



# Generated at 2022-06-22 18:28:30.970463
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A:
        def __init__(self):
            self.data = b''

        def write(self, data):
            self.data += data

    a = A()
    assert isinstance(a, WritableStream)



# Generated at 2022-06-22 18:28:37.893752
# Unit test for function normalize_repr
def test_normalize_repr():

    class SampleClass:
        pass
    some_instance = SampleClass()

    tests = [
        (1, '1'),
        ('a', "'a'"),
        (1.99, '1.99'),
        ((1, 2, 3), '(1, 2, 3)'),
        (some_instance, 'SampleClass()'),
    ]

    for item, correct_repr in tests:
        raw_repr = repr(item)
        normalized_repr = normalize_repr(raw_repr)
        print(raw_repr)
        assert normalized_repr == correct_repr



if __name__ == '__main__':

    test_normalize_repr()

# Generated at 2022-06-22 18:28:42.805023
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    long_string = 'A' * 100
    assert get_shortish_repr(long_string, max_length=10) == 'AAAAAAAAAA...AAAAAAA'
    assert get_shortish_repr(long_string, max_length=None) == long_string
    assert get_shortish_repr(long_string, max_length=100) == long_string



# Generated at 2022-06-22 18:28:47.493522
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    for x in (None, [1], (2,), set([3])):
        y = tuple(x)
        assert ensure_tuple(x) == y
        assert ensure_tuple(y) == y





# Generated at 2022-06-22 18:28:57.833270
# Unit test for function truncate
def test_truncate():
    assert truncate('123', None) == '123'
    assert truncate('12345678', 8) == '12345678'
    assert truncate('12345678', 7) == '123...8'
    assert truncate('12345678', 6) == '1...8'
    assert truncate('12345678', 5) == '...8'
    assert truncate('12345678', 4) == '...'
    assert truncate('12345678', 3) == '...'
    assert truncate('12345678', 2) == '...'
    assert truncate('12345678', 1) == '...'
    assert truncate('12345678', 0) == '...'
    assert truncate('12345678', -1) == '...'
    assert truncate('12345678', -2) == '...'


# Generated at 2022-06-22 18:29:01.698293
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(io.StringIO, WritableStream)

# Generated at 2022-06-22 18:29:04.273054
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):

        def write(self, s):
            pass

    a = A()
    assert isinstance(a, WritableStream)


# Generated at 2022-06-22 18:29:11.833856
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'

    assert get_shortish_repr(1234567890, max_length=3) == '12...90'
    assert get_shortish_repr(12345678901234567890, max_length=3) == '123...890'
    assert get_short

# Generated at 2022-06-22 18:29:22.703197
# Unit test for function truncate
def test_truncate():
    assert truncate('0123456789', 10) == '0123456789'
    assert truncate('0123456789', 9) == '0123456789'
    assert truncate('0123456789', 8) == '...6789'
    assert truncate('0123456789', 7) == '...6789'
    assert truncate('0123456789', 6) == '...789'
    assert truncate('0123456789', 5) == '...789'
    assert truncate('012', 3) == '012'
    assert truncate('012', 2) == '..'
    assert truncate('012', 1) == '.'
    assert truncate('012', 0) == '.'
    assert truncate('012', -4) == '.'
    assert truncate('012', None)

# Generated at 2022-06-22 18:29:26.586105
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyStdout(WritableStream):
        def write(self, s):
            sys.stdout.write(s)
            return len(s)

    my_stdout = MyStdout()
    my_stdout.write('Hello')

# Generated at 2022-06-22 18:29:37.797945
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1.1, []) == repr
    assert get_repr_function('hello', []) == repr

    assert get_repr_function(1, [(int, len)]) == len
    assert get_repr_function(1.1, [(int, len)]) == repr
    assert get_repr_function('hello', [(int, len)]) == repr

    assert get_repr_function(1, [lambda x: x == 1, len]) == len
    assert get_repr_function(2, [lambda x: x == 1, len]) == repr
    assert get_repr_function('hello', [lambda x: x == 1, len]) == repr



# Generated at 2022-06-22 18:29:40.187162
# Unit test for function normalize_repr
def test_normalize_repr():
    assert '<' not in normalize_repr('<__main__.Test instance at 0x1234567>')

# Generated at 2022-06-22 18:29:42.748097
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\x00\x01\x7f\xff') == '?\x01?\xff'



# Generated at 2022-06-22 18:29:46.735947
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        pass

    assert isinstance(A(), WritableStream)

    class B(WritableStream):
        def write(self, s):
            pass

    assert isinstance(B(), WritableStream)

# Generated at 2022-06-22 18:29:48.515928
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass

    assert issubclass(WritableStreamSubclass, WritableStream)

# Generated at 2022-06-22 18:29:53.530445
# Unit test for function truncate
def test_truncate():
    assert truncate('12345', 3) == '...'
    assert truncate('12345', 4) == '1...'
    assert truncate('12345', 5) == '12...'
    assert truncate('12345', 6) == '12345'
    assert truncate('12345', 7) == '12345'
    assert truncate('12345', None) == '12345'



# Generated at 2022-06-22 18:29:57.465815
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('abc at 0x123456') == 'abc'
    assert normalize_repr('abc at 0x1234') == 'abc at 0x1234'
    assert normalize_repr('abc at 0x12') == 'abc at 0x12'
    assert normalize_repr('abc at 0x1') == 'abc at 0x1'



# Generated at 2022-06-22 18:30:01.074158
# Unit test for function normalize_repr
def test_normalize_repr():
    random_object = lambda: None
    cases = (0, 'string', [0, 1, 2], {}, random_object)
    for item in cases:
        item_repr = repr(item)
        normalized_repr = normalize_repr(item_repr)
        normalized_repr = normalized_repr.replace(' at 0x', ' at 0X')
        assert item_repr == normalized_repr.replace('...', '... at 0X...')

# Generated at 2022-06-22 18:30:06.690461
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(['abc']) == ('abc',)
    assert ensure_tuple(('abc',)) == ('abc',)
    assert ensure_tuple((2, 3)) == (2, 3)
    assert ensure_tuple((2, 'a')) == (2, 'a')
    assert ensure_tuple({1, 2}) == (1, 2)
    assert ensure_tuple({'a': 1, 'b': 2}) == ('a', 'b')
    assert ensure_tuple(range(10)) == tuple(range(10))



# Generated at 2022-06-22 18:30:12.216929
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyClass(WritableStream):
        def __init__(self):
            self.result = b''

        def write(self, s):
            self.result += s

    class MySubclass(MyClass):
        pass

    assert issubclass(MySubclass, MyClass)
    assert issubclass(MySubclass, WritableStream)
    assert not issubclass(MyClass, WritableStream)
    assert _check_methods(MySubclass, 'write') == True

# Generated at 2022-06-22 18:30:21.068719
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('א') == '?'
    assert shitcode('אבג') == '???'
    assert shitcode('abc') == 'abc'
    assert shitcode('ab' + chr(0x88) + 'c') == 'ab?c'
    assert shitcode('ab' + chr(0x00) + 'c') == 'ab?c'
    assert shitcode('ab' + chr(0xFF) + 'c') == 'ab?c'
    assert shitcode('ab' + chr(0x49) + 'c') == 'abIc'


if sys.version_info >= (3,):
    from .py3 import rerun

# Generated at 2022-06-22 18:30:28.263977
# Unit test for function truncate
def test_truncate():
    assert truncate('', max_length=1) == ''
    assert truncate('', max_length=2) == ''
    assert truncate('', max_length=3) == ''
    assert truncate('a', max_length=1) == 'a'
    assert truncate('a', max_length=2) == 'a'
    assert truncate('abc', max_length=1) == '...'
    assert truncate('abc', max_length=2) == 'a...'
    assert truncate('abc', max_length=3) == 'abc'
    assert truncate('abc', max_length=4) == 'abc'
    assert truncate('abc', max_length=5) == 'abc'
    assert truncate('abc', max_length=6) == 'abc'

# Generated at 2022-06-22 18:30:38.935152
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import re
    d = dict(a=lambda x: '*' + x,
             b=re.compile(r'\w+'))
    assert get_shortish_repr('abc', (d['a'],)) == '*abc'
    assert not get_shortish_repr('abc', (d['b'],)) == 'abc'
    assert get_shortish_repr('abc', custom_repr=(d['b'], lambda x: 'X')) == 'X'
    assert get_shortish_repr('a' * 5, max_length=4) == 'a...'
    assert get_shortish_repr('a' * 5, max_length=4, normalize=True) == 'a...'



# Generated at 2022-06-22 18:30:41.295786
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class DummyFile(WritableStream):
        pass
    assert issubclass(DummyFile, WritableStream)

# Generated at 2022-06-22 18:30:47.464304
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert isinstance(ensure_tuple('x'), tuple)
    assert isinstance(ensure_tuple([]), tuple)
    assert isinstance(ensure_tuple(['x']), tuple)
    assert isinstance(ensure_tuple('x'), tuple)
    assert isinstance(ensure_tuple((x for x in range(3))), tuple)
    assert isinstance(ensure_tuple(range(3)), tuple)
    assert isinstance(ensure_tuple(xrange(3)), tuple)
    assert isinstance(ensure_tuple((3, xrange(3))), tuple)



# Generated at 2022-06-22 18:30:53.471587
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello at 0x1234') == 'hello'
    assert normalize_repr('hello at 0x123456') == 'hello'
    assert normalize_repr('hello at 0x000000') == 'hello'
    assert normalize_repr('hello at 0x1234567') == 'hello at 0x1234567'
    assert normalize_repr('hello at 0x123k') == 'hello at 0x123k'
    assert normalize_repr('hello at 0x123') == 'hello at 0x123'

# Generated at 2022-06-22 18:31:01.692087
# Unit test for function truncate
def test_truncate():
    assert truncate(u'abcdef', 6) == u'abcdef'
    assert truncate(u'abcdef', 5) == u'abcde'
    assert truncate(u'abcdef', 4) == u'abcd'
    assert truncate(u'abcdef', 3) == u'a...'
    assert truncate(u'abcdef', 2) == u'a.'
    assert truncate(u'abcdef', 1) == u'a'
    assert truncate(u'abcdef', 0) == u''
    assert truncate(u'abcdef', -1) == u''
    assert truncate('abcdef', 6) == 'abcdef'
    assert truncate('abcdef', 5) == 'abcde'
    assert truncate('abcdef', 4) == 'abcd'

# Generated at 2022-06-22 18:31:07.066219
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .test_tools.test_case_insensitive_dict import \
                                                TupleStream, StringStream
    assert issubclass(TupleStream, WritableStream)
    assert issubclass(StringStream, WritableStream)
    assert not issubclass(int, WritableStream)

# Generated at 2022-06-22 18:31:15.974826
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .banana_settings import banana_settings
    banana_settings.max_string_length = 20
    assert get_shortish_repr(4) == '4'
    assert get_shortish_repr((4, 5)) == '(4, 5)'
    assert get_shortish_repr(u'hello') == 'hello'
    assert get_shortish_repr(u'hello world', max_length=5) == 'he...ld'
    assert get_shortish_repr(u'hello world', max_length=20) == 'hello world'
    assert get_shortish_repr(u'hello world', max_length=20) == 'hello world'
    assert get_shortish_repr(u'hello world', max_length=20) == 'hello world'
    assert get_shortish_re

# Generated at 2022-06-22 18:31:21.085768
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('a') == 'a'
    assert normalize_repr('a at 0x1234') == 'a'
    assert normalize_repr('a at 0x123456') == 'a'
    assert normalize_repr(
        'a at 0x123456789abcdef1234567890abcdef'
    ) == 'a'

# Generated at 2022-06-22 18:31:31.469693
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(123) == '123'

    assert (
        get_shortish_repr(123, max_length=3) ==
        get_shortish_repr(123, max_length=4) ==
        '123'
    )

    assert get_shortish_repr(123, max_length=2) == '123'[:2]

    assert get_shortish_repr(123, normalize=True) == '123'
    assert get_shortish_repr(123, normalize=True, max_length=3) == '123'
    assert get_shortish_repr(123, normalize=True, max_length=2) == '123'[:2]

    assert get_shortish_repr(123, max_length=2, normalize=True)

# Generated at 2022-06-22 18:31:36.227972
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .quack_file_stream import QuackFileStream
    from .testing import make_sure_it_doesnt_raise
    make_sure_it_doesnt_raise(
        lambda: isinstance(QuackFileStream(sys.stdout), WritableStream)
    )
    
    
    
    
    
    
    

# Generated at 2022-06-22 18:31:42.442411
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(object):
        def write(self, s):
            pass
    class B(object):
        def write(self, s):
            """Docstring for method write of class B."""
            pass
    class C(object):
        def write(self, s):
            """Docstring for method write of class C."""
        write.__doc__ = None
    class D(object):
        pass
    assert WritableStream.__subclasshook__(A)
    assert WritableStream.__subclasshook__(B)
    assert WritableStream.__subclasshook__(C)
    assert WritableStream.__subclasshook__(D) is NotImplemented
    assert WritableStream.__subclasshook__(object) is NotImplemented

# Generated at 2022-06-22 18:31:52.979196
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(repr('hello world')) == repr('hello world')
    assert normalize_repr(repr(5)) == repr(5)
    assert normalize_repr('hello world') == 'hello world'
    assert normalize_repr('hello at 0x1234') == 'hello at 0x1234'
    assert normalize_repr('hello world at 0x1234') == 'hello world'
    assert normalize_repr('hello world at 0x1234 at 0xabcd') == 'hello world'
    assert normalize_repr('hello world at 0x1234 at 0xabcd and then some more')
    assert normalize_repr('hello world at 0x1234 at 0xabcd at 0x1234')

# Generated at 2022-06-22 18:32:02.089638
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class MyWritableStream(WritableStream):

        def write(self, s):
            pass

    class WrongWritableStream1(object):
        pass

    class WrongWritableStream2(WritableStream):
        def write(self, s):
            pass
        def other_method(self, s):
            pass

    class WrongWritableStream3(WritableStream):
        pass

    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(WrongWritableStream1, WritableStream)
    assert not issubclass(WrongWritableStream2, WritableStream)
    assert not issubclass(WrongWritableStream3, WritableStream)

# Generated at 2022-06-22 18:32:08.838712
# Unit test for function ensure_tuple
def test_ensure_tuple():
    # If a string isn't iterable, it should be transformed to a singleton tuple:
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)





# Generated at 2022-06-22 18:32:14.058017
# Unit test for function get_repr_function
def test_get_repr_function():
    class Animal(object):
        pass
    class Dog(Animal):
        pass
    class Cat(Animal):
        pass
    class Cow(Animal):
        pass
    custom_repr = (
        (Dog, 'DOG'),
        ((Cat, Cow), lambda x: 'NOT A DOG')
    )
    assert get_repr_function(Dog(), custom_repr)() == 'DOG'
    assert get_repr_function(Cat(), custom_repr)() == 'NOT A DOG'
    assert get_repr_function(Cow(), custom_repr)() == 'NOT A DOG'
    assert get_repr_function('Hello', custom_repr)() == "'Hello'"


# Generated at 2022-06-22 18:32:16.559035
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X:
        def write(self, s):
            pass
    assert issubclass(X, WritableStream)



# Generated at 2022-06-22 18:32:28.038769
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class CustomWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = ''
        def write(self, stuff):
            self.written_stuff += stuff

    class CustomWritableStream2(CustomWritableStream):
        def __init__(self):
            self.written_stuff = ''
            self.write = None

    class NotCustomWritableStream(object):
        def write(self, stuff):
            raise AssertionError()

    assert issubclass(CustomWritableStream, WritableStream)
    assert issubclass(CustomWritableStream2, WritableStream)
    assert not issubclass(NotCustomWritableStream, WritableStream)

    custom_writable_stream = CustomWritableStream()
    custom_writable_stream.write('ram')
    assert custom_writable

# Generated at 2022-06-22 18:32:34.656828
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(1, 2, 3) == (1,)
    assert ensure_tuple({1, 2, 3}) == ({1, 2, 3},)
    assert ensure_tuple(None) == (None,)



# Generated at 2022-06-22 18:32:42.259343
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnop', 5) == 'a...n'
    assert truncate('abcdefghij', 5) == 'a...j'
    assert truncate('ab', 5) == 'ab'
    assert truncate('abcdefgh', None) == 'abcdefgh'
    assert truncate('abc', None) == 'abc'
    assert truncate('abcdefghijklmnop', 1) == 'a'
    assert truncate('abcdefghijklmnop', 2) == 'a...'
    assert truncate('abcdefghijklmnop', 3) == 'a...p'
    assert truncate('abcdefghijklmnop', 4) == 'a...p'
    assert truncate('abcdefghijklmnop', 5) == 'a...n'

# Generated at 2022-06-22 18:32:45.448605
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .abstract import AbstractMethod
    class MyWritableStream(WritableStream): pass
    assert set(dir(MyWritableStream)) == set(dir(WritableStream))
    assert isinstance(MyWritableStream().write, AbstractMethod)

# Generated at 2022-06-22 18:32:54.616121
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'מה העניין') == u'???????????'
    assert shitcode(u'\U0001F4A9') == u'?'
    assert shitcode(u'سلام') == u'????'
    assert shitcode(u'\u2070') == u'?'
    assert shitcode(u'\U0001F4A9\u2070') == u'??'
    assert shitcode('\x00') == u'?'
    assert '\x00' == b'\x00'
    assert '\x00' != u'\x00'



# Generated at 2022-06-22 18:33:01.829460
# Unit test for function normalize_repr
def test_normalize_repr():
    case_insensitive_re = re.compile('(?i)^(' + re.escape(' '.join(
        'at 0x0{x:x}'.format(x=x) for x in range(15)
    )) + ')')
    def assert_normalize_repr(assertion, *args):
        assertion = assertion.replace('{...}', '.*')
        assertion = assertion.replace('{x}', '[0-9a-f]')
        assertion = assertion.replace('{X}', '[0-9A-F]')
        assertion = case_insensitive_re.sub('(\\1)', assertion)
        assertion = re.compile(assertion)

# Generated at 2022-06-22 18:33:10.289039
# Unit test for function get_repr_function
def test_get_repr_function():
    
    def float_repr(f):
        return 'float %s' % f
    
    def int_repr(i):
        return 'int %s' % i
    
    custom_repr = ((float, float_repr), (int, int_repr))
    
    assert get_repr_function(float, custom_repr) is float_repr
    
    assert get_repr_function(1, custom_repr) is int_repr
    assert get_repr_function(1.0, custom_repr) is float_repr
    
    
    
    

# Generated at 2022-06-22 18:33:14.783048
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, ((lambda x: isinstance(x, int),
                                  lambda x: 'integer'))) == 'integer'
    assert get_repr_function(5.0, ((lambda x: isinstance(x, int),
                                    lambda x: 'integer'))) == repr



# Generated at 2022-06-22 18:33:18.874591
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'הגיית') == u'?????????'
    assert shitcode(u'הגיית'.encode('utf-8')) == u'???????'
    assert shitcode(u'ה7גיית') == u'?7??????'
    assert shitcode(u'ה7גיית'.encode('utf-8')) == u'7??????'

# Generated at 2022-06-22 18:33:30.314453
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Check we can get a normal repr without fail
    normal_list_repr = get_shortish_repr([1, 2, 3])
    assert normal_list_repr == '[1, 2, 3]'

    # Check repr fails if repr fails, and repr fails gracefully if repr blows up
    class MyClass(object):
        def __repr__(self):
            raise RuntimeError('This error is expected, please ignore')

    repr_error = get_shortish_repr(MyClass())
    assert repr_error == 'REPR FAILED'

    # Check we can get a truncated repr
    truncated_list_repr = get_shortish_repr([1, 2, 3], max_length=10)

    assert truncated_list_repr == '[1, 2,...'

    # Check we can get a

# Generated at 2022-06-22 18:33:41.581610
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class CustomObjectWithWriteMethod:
        def write(self, s):
            print('got: %s' % (s,))

    assert isinstance(CustomObjectWithWriteMethod(), WritableStream)

    class CustomObjectWithNoneWriteMethod:
        def write(self, s):
            pass

    assert not isinstance(CustomObjectWithNoneWriteMethod(), WritableStream)

    class CustomObjectWithoutWriteMethod:
        pass

    assert not isinstance(CustomObjectWithoutWriteMethod(), WritableStream)

    class CustomObjectWithWriteMethodInherited:
        pass

    class InheritingClass(CustomObjectWithWriteMethodInherited):
        pass

    assert not isinstance(InheritingClass(), WritableStream)

    class CustomObjectWithWriteMethodInherited:
        def write(self, s):
            pass


# Generated at 2022-06-22 18:33:43.461560
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyClass(WritableStream):
        def write(self, s):
            pass
    MyClass()




# Generated at 2022-06-22 18:33:48.859710
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcdefghijklmnop') == 'abcdefghijklmnop'
    assert get_shortish_repr('abcdefghijklmnop', max_length=10) == \
                                                            'abcdefghij...'
    assert get_shortish_repr('abcdefghijklmnop', max_length=11) == \
                                                           'abcdefghijk...'
    assert get_shortish_repr('abcdefghijklmnop', max_length=12) == \
                                                          'abcdefghijkl...'
    assert get_shortish_repr('abcdefghijklmnop', max_length=13) == \
                                                         'abcdefghijklm...'

# Generated at 2022-06-22 18:33:59.155633
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(B): pass

    assert get_repr_function(C(), custom_repr=(
        (A, lambda x: 'A'),
        (B, lambda x: 'B'),
    )) is repr

    assert get_repr_function(C(), custom_repr=(
        (A, lambda x: 'A'),
    )) is repr

    assert get_repr_function(C(), custom_repr=(
        (B, lambda x: 'B'),
    )) == (lambda x: 'B')

    assert get_repr_function(C(), custom_repr=(
        (B, lambda x: 'B')
    )) == (lambda x: 'B')




# Generated at 2022-06-22 18:34:08.915430
# Unit test for function truncate
def test_truncate():
    x = '1234567890'
    assert truncate(x, None) == x
    assert truncate(x, 10) == x
    assert truncate(x, 11) == x
    assert truncate(x, 5) == '12345...'
    assert truncate(x, 4) == '1234...'
    assert truncate(x, 3) == '123...'
    assert truncate(x, 4) == '1234...'
    assert truncate(x, 2) == '1...'
    assert truncate(x, 1) == '...'
    assert truncate(x, 0) == '...'

    assert truncate(u'שלום עולם', 6) == u'שלום...'

# Generated at 2022-06-22 18:34:20.983278
# Unit test for function truncate
def test_truncate():

    assert truncate('abcdefghij', 10) == 'abcdefghij'
    assert truncate('abcdefghij', 5) == 'abcde...hij'
    assert truncate('abcdefghij', 4) == '...'
    assert truncate('abcdefghij', 3) == '...'
    assert truncate('abcdefghij', 2) == '..'
    assert truncate('abcdefghij', 1) == '.'
    assert truncate('abcdefghij', 0) == ''
    assert truncate('abcdefghij', -1) == ''
    assert truncate('abcdefghij', None) == 'abcdefghij'

    assert truncate(u'abcdefghij', 10) == u'abcdefghij'

# Generated at 2022-06-22 18:34:23.737339
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('a\xc2') == 'a?'
    assert shitcode('a\xc2\xab') == 'a??'
    assert shitcode('a\xc2\xab\xef') == 'a???'



# Generated at 2022-06-22 18:34:35.603584
# Unit test for function normalize_repr
def test_normalize_repr():
    from collections import Counter

    strep = str(repr(1))
    res = normalize_repr(strep)
    assert res == strep

    strep = str(repr(Counter()))
    res = normalize_repr(strep)
    assert res != strep
    assert DEFAULT_REPR_RE.sub('', res) == res

    strep = str(repr("123456"))
    res = normalize_repr(strep)
    assert res == strep

    obj = lambda x:x
    strep = str(repr(obj))
    res = normalize_repr(strep)
    assert res == strep

    import logging
    from logging import Logger, handlers
    obj = Logger('name')
    strep = str(repr(obj))

# Generated at 2022-06-22 18:34:45.343127
# Unit test for function get_repr_function
def test_get_repr_function():
    assert (get_repr_function(42, []) == repr)
    assert (get_repr_function([42], []) == repr)
    assert (get_repr_function(u'a', []) == repr)

    def my_repr(x):
        return 'my-repr'

    assert (get_repr_function(42, [(int, my_repr)]) == my_repr)
    assert (get_repr_function(42.0, [(int, my_repr)]) == repr)
    assert (get_repr_function(42, [(float, my_repr)]) == repr)
    assert (get_repr_function(42.0, [(float, my_repr)]) == my_repr)


# Generated at 2022-06-22 18:34:49.289421
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(
        '<function f at 0xDEADBEEF>'
    ) == '<function f>'
    assert normalize_repr(
        '<function f at 0xDEADBEEFABCD>'
    ) == '<function f>'
    assert normalize_repr(
        '<function f at 0xDEADBEEF0>'
    ) == '<function f>'




# Generated at 2022-06-22 18:34:54.069434
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_stuff = ''
        def write(self, s):
            self.written_stuff += s
    stream = MyWritableStream()
    stream.write('abc')
    assert stream.written_stuff == 'abc'



# Generated at 2022-06-22 18:34:57.996988
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple(()) == ()
    assert ensure_tuple(('stuff',)) == ('stuff',)
    assert ensure_tuple({'r': 'stuff'}) == ({'r': 'stuff'},)
    assert ensure_tuple('stuff') == ('stuff',)
    assert ensure_tuple(5) == (5,)



# Generated at 2022-06-22 18:34:59.890797
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hebrew: טייטט טאטאטא') == 'hebrew: ???? ???'



# Generated at 2022-06-22 18:35:05.694809
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 8) == '123456789'
    assert truncate('123456789', 7) == '123...89'
    assert truncate('123456789', 6) == '123...89'
    assert truncate('123456789', 5) == '123...89'
    assert truncate('123456789', 4) == '1...9'
    assert truncate('123456789', 3) == '1...9'
    assert truncate('123456789', 2) == '1...9'
    assert truncate('123456789', 1) == '.'
    assert truncate('123456789', 0) == ''

# Generated at 2022-06-22 18:35:17.199817
# Unit test for function truncate
def test_truncate():
    assert truncate(u'abcde', 4) == u'a...e'
    assert truncate(u'abcde', None) == u'abcde'
    assert truncate(u'abcdefghijklmnopqrstuvwxyz', 10) == u'abcd...stuv'
    assert truncate(u'a', 4) == u'a'
    assert truncate(u'ab', 4) == u'ab'
    assert truncate(u'abc', 4) == u'abc'
    assert truncate(u'abcd', 4) == u'abc...'
    assert truncate(u'abcde', 4) == u'a...e'
    assert truncate(u'abcdef', 4) == u'a...f'

# Generated at 2022-06-22 18:35:27.477010
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, []) is repr
    assert get_repr_function(3, [(lambda x: x % 2 == 0, str)]) is repr
    assert get_repr_function(4, [(lambda x: x % 2 == 0, str)]) is str

    class Foo(object):
        pass
    foo = Foo()
    assert get_repr_function(foo, [(type(foo), repr)]) is repr
    assert get_repr_function(foo, [
        (type(foo), repr),
        (type(Foo), repr)
    ]) is repr
    assert get_repr_function(foo, [
        (type(foo), repr),
        (type(Foo), str)
    ]) is repr

# Generated at 2022-06-22 18:35:29.810768
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)
    assert A.__mro__[1] == WritableStream

# Generated at 2022-06-22 18:35:34.553340
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(lambda x: False, str)]) is repr
    assert get_repr_function(1, [(lambda x: True, str)]) is str
    assert get_repr_function(1, [(lambda x: True, str),
                                        (lambda x: True, str)]) is str
    assert get_repr_function('a', [(lambda x: True, str)]) is str
    assert get_repr_function('a', [(str, str)]) is str

# Generated at 2022-06-22 18:35:36.929434
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableFileObject(WritableStream):
        def write(self, s):
            pass

    assert issubclass(WritableFileObject, WritableStream)

# Generated at 2022-06-22 18:35:47.159740
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Custom(object):
        def write(self, x):
            pass

    assert issubclass(Custom, WritableStream)

    class Custom: pass
    assert not issubclass(Custom, WritableStream)

    class Custom:
        def write(self, x):
            pass
        def foo(self):
            pass

    assert issubclass(Custom, WritableStream)

    class Custom:
        def write(self, x):
            pass
        def write(self, x):
            pass

    assert issubclass(Custom, WritableStream)

    class Custom:
        def write(self, x):
            pass
        def write(self, x, y):
            pass

    assert not issubclass(Custom, WritableStream)

    class Custom(object):
        def write(self, x):
            pass
       

# Generated at 2022-06-22 18:35:52.708464
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # WritableStream.write is abstract, so we can't test it directly.
    # Let's test if a class that implements it passes the isinstance check.
    class MyWritableStream(WritableStream):
        def write(self, stuff):
            pass
    assert isinstance(MyWritableStream(), WritableStream)

