

# Generated at 2022-06-22 18:25:54.717792
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x1234') == 'hello'
    assert normalize_repr('hello at 0x12345678') == 'hello'


if __name__ == '__main__':
    test_normalize_repr()

# Generated at 2022-06-22 18:26:03.892858
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .context_management import captured_output

    class Dummy(object):
        repr = '__repr__'
        custom_repr = 'custom_repr'
        str = '__str__'
        custom_str = 'custom_str'

    class Dummy2(Dummy):
        pass

    long_string = 'Hello!' * 100

    def custom_repr(x):
        return 'custom_repr'

    def custom_str(x):
        return 'custom_str'

    custom_repr_arguments = (
        (Dummy, custom_repr),
        (Dummy2, custom_str),
    )

    assert get_shortish_repr(Dummy()) == 'REPR FAILED'

# Generated at 2022-06-22 18:26:07.619719
# Unit test for function ensure_tuple
def test_ensure_tuple():
    from .python_toolbox.expecting import expect_equal

    expect_equal(ensure_tuple('abc'), ('abc',))
    expect_equal(ensure_tuple(('abc',)), ('abc',))
    expect_equal(ensure_tuple(['abc']), ('abc',))



# Generated at 2022-06-22 18:26:17.662466
# Unit test for function get_repr_function
def test_get_repr_function():
    item = tuple()
    assert get_repr_function(item) is repr
    assert get_repr_function(item, (
        (lambda x: x == 1, lambda x: 'one'),
        (lambda x: x == 2, lambda x: 'two'),
        (lambda x: x == 3, lambda x: 'three'),
        (lambda x: x == 4, lambda x: 'four'),
    )) is repr


# Generated at 2022-06-22 18:26:28.629644
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .writeable_stream_dummy import WritableStreamDummy

    class TestWritableStream(WritableStreamDummy, WritableStream):
        pass

    class TestWritableStream2(WritableStreamDummy, WritableStream):
        def write(self, s):
            return s * 2

    assert issubclass(TestWritableStream, WritableStream)
    assert issubclass(TestWritableStream2, WritableStream)

    a = TestWritableStream()
    assert a.write('b') == 'b'
    assert a.write('x' * 10) == 'x' * 10

    b = TestWritableStream2()
    assert b.write('b') == 'bb'
    assert b.write('x' * 10) == 'x' * 20

# Generated at 2022-06-22 18:26:32.199060
# Unit test for function shitcode
def test_shitcode():
    s = 'שלום עולם'

    assert shitcode(s) == '???? ????'

    s = ''

    assert shitcode(s) == ''

    s = 'こんにちは世界'

    assert shitcode(s) == '???? ????'

# Generated at 2022-06-22 18:26:43.649585
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(
        1,
        (
            (lambda x: x == 0, lambda x: 'zero'),
            (int, lambda x: 'int'),
            (object, lambda x: 'object')
        )
    )(1) == 'int'

    assert get_repr_function(
        'a',
        (
            (lambda x: x == 0, lambda x: 'zero'),
            (int, lambda x: 'int'),
            (object, lambda x: 'object')
        )
    )(1) == 'object'


# Generated at 2022-06-22 18:26:50.285405
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import sys

    class MockFile(object):
        def write(self, s):
            return s

    assert issubclass(MockFile, WritableStream)
    assert issubclass(sys.stderr, WritableStream)

    with open(__file__, 'r') as f:
        assert not issubclass(f, WritableStream)
    with open(__file__, 'w') as f:
        assert not issubclass(f, WritableStream)
    with open(__file__, 'a') as f:
        assert not issubclass(f, WritableStream)

# Generated at 2022-06-22 18:26:58.345241
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(42, ((int, str),)) == str
    assert get_repr_function(42.0, ((int, str),)) == repr
    assert get_repr_function(42, ((lambda x: x > 10, str),)) == str
    assert get_repr_function(9, ((lambda x: x > 10, str),)) == repr
    assert get_repr_function(9, ((lambda x: x > 10, str), (int, str))) == str

# Generated at 2022-06-22 18:27:05.363388
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class A(object):
        pass


    class B(object):
        pass


    class C(object):
        pass


    class D(object):
        pass


    class E(object):
        pass



    def _repr_b(x):
        return 'b'


    def _repr_c(x):
        return 'c'


    def _repr_d(x):
        return 'd'


    def _repr_e(x):
        return 'e'





# Generated at 2022-06-22 18:27:10.595295
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            return s + 'A'

    class B(A):
        def write(self, s):
            return s + 'B'

    class C(object):
        def write(self, s):
            return s + 'C'

    class D(C, B):
        pass

    assert issubclass(D, WritableStream)



# Generated at 2022-06-22 18:27:16.537291
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        pass

    assert issubclass(A, WritableStream) is True

    class B(WritableStream):
        def write(self):
            pass

    assert issubclass(B, WritableStream) is True

    class C(WritableStream):
        def write(self):
            pass

    assert issubclass(C, WritableStream) is True



# Generated at 2022-06-22 18:27:24.293385
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    s = get_shortish_repr('hello')
    assert s == repr('hello')
    s = get_shortish_repr('hello'*10)
    assert s == repr('hello'*10)
    s = get_shortish_repr('hello'*10, max_length=20)
    assert s == repr('hello'*4 + '...' + 'hello')
    s = get_shortish_repr('hello'*10, max_length=20, normalize=True)
    assert s == normalize_repr(repr('hello'*4 + '...' + 'hello'))



# Generated at 2022-06-22 18:27:35.532262
# Unit test for function normalize_repr
def test_normalize_repr():
    from py_common_crawl.types_infrastructure.file_type import FileType

    if sys.version_info[0] == 2:
        from py_common_crawl.types_infrastructure.file_type import file_type2
    else:
        from py_common_crawl.types_infrastructure.file_type import file_type3

    def assert_normalize_repr(item, expected_normalized_repr):
        actual_normalized_repr = normalize_repr(repr(item))
        assert expected_normalized_repr == actual_normalized_repr

    assert_normalize_repr(FileType, "<class 'py_common_crawl.types_infrastructure.file_type.FileType'>")

# Generated at 2022-06-22 18:27:45.943636
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('a at 0x10') == 'a'
    assert normalize_repr('a at 0x10 at 0x20') == 'a at 0x20'
    assert normalize_repr('a at 0x10 at hi') == 'a at hi'
    assert normalize_repr('a at 0x10 at 0x20 at gol') == 'a at 0x20 at gol'
    assert normalize_repr('a at 0x10 at 0x20') == 'a at 0x20'
    assert normalize_repr('a at 0x10 at 0x20 at 0x30') == 'a at 0x20 at 0x30'
    assert normalize_repr('a at 0x10 at hi at 0x30') == 'a at hi at 0x30'



# Generated at 2022-06-22 18:27:51.921391
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, ()) is repr
    assert get_repr_function(5, ((int, str),)) == str
    assert get_repr_function(5, ((lambda x: x == 5, str),)) == str
    assert get_repr_function(5, ((lambda x: x == 6, str),)) == repr



# Generated at 2022-06-22 18:27:58.399864
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('{} at 0x1234567890') == '{}'
    assert normalize_repr('{} at 0xabcdef') == '{}'
    assert normalize_repr('{} at 0xABCDEF') == '{}'
    assert normalize_repr('{} at 0x0123456789') == '{}'
    assert normalize_repr('{} at 0x0') == '{}'
    assert normalize_repr('{} at 0xF0F0F') == '{}'


if __name__ == '__main__':
    test_normalize_repr()

# Generated at 2022-06-22 18:28:07.648329
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    a = [1, 2, 3]
    assert get_shortish_repr(a) == '[1, 2, 3]'
    assert get_shortish_repr(a, max_length=10) == '[1, 2, 3]'
    assert get_shortish_repr(a, max_length=9) == '[1, 2, 3]'
    assert get_shortish_repr(a, max_length=8) == '[1, 2, ...'
    assert get_shortish_repr(a, max_length=7) == '[1, 2, ...'
    assert get_shortish_repr(a, max_length=6) == '[1, 2, ...'
    assert get_shortish_repr(a, max_length=5) == '[1, 2, ...'
    assert get_short

# Generated at 2022-06-22 18:28:14.320464
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('a', []) is repr
    assert get_repr_function('a', [(str, str)]) is str
    assert get_repr_function('a', [(str, str.upper)]) is str.upper
    assert get_repr_function('a', [(str, str.upper), (str, str)]) is str
    assert get_repr_function('a', [(str, str.upper), (str, str), (str, repr)])\
                        is repr
    assert get_repr_function('a', [(str, str.upper), (str, str), (str, repr),
                                   (str, str.count)]) is str.count



# Generated at 2022-06-22 18:28:24.652168
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert (
        get_shortish_repr(long(1)) == '1L' if sys.version_info[0] == 2
                                  else '1'
    )
    assert get_shortish_repr(1, normalize=True) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=1, normalize=True) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=2, normalize=True) == '1'

# Generated at 2022-06-22 18:28:30.855348
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass
        pass

    assert issubclass(WritableStreamSubclass, WritableStream)

    class MyException(Exception):
        def write(self, s):
            pass
        pass

    class WritableStreamSubclassWithMyException(WritableStream):
        def write(self, s):
            raise MyException
        pass

    assert issubclass(WritableStreamSubclassWithMyException, WritableStream)


test_WritableStream_write()

# Generated at 2022-06-22 18:28:39.993509
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', None) == '123456789'
    assert truncate('123456789', 5) == '...789'
    assert truncate('123456789', 10) == '123456789'
    assert truncate('123456789', 8) == '12...89'
    assert truncate('123456789', 6) == '1...9'
    assert truncate('123456789', 4) == '1...'
    assert truncate('123456789', 2) == '...'
    assert truncate('123', 0) == '...'
    assert truncate('123', -1) == '...'



# Generated at 2022-06-22 18:28:43.528423
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'\u2959\u2959') == u'??'
    assert shitcode(u'abc\u2959\u2959') == u'abc??'



# Generated at 2022-06-22 18:28:55.378917
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abc' * 100) == "'abcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabc'"

# Generated at 2022-06-22 18:29:00.806610
# Unit test for function get_repr_function
def test_get_repr_function():
    def repr_func(x):
        return 'custom'

    assert get_repr_function(1, (
        (lambda x: x % 2 == 0, repr_func)
    )) is repr_func

    assert normalize_repr('a at 0x12345678') == 'a'



# Generated at 2022-06-22 18:29:04.476857
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream)

# Generated at 2022-06-22 18:29:14.286226
# Unit test for function get_repr_function
def test_get_repr_function():

    class X(object): pass
    x = X()

    assert get_repr_function(x, (
        (X, lambda x: 'Y'), (lambda x: True, lambda x: 'Z'),
    )) is str

    assert get_repr_function(x, (
        (lambda x: True, lambda x: 'Z'), (X, lambda x: 'Y'),
    )) is str

    def Z(x):
        return 'Z'

    assert get_repr_function(x, ((lambda x: True, Z),)) is Z

    assert get_repr_function(x, (
        (X, lambda x: 'Y'),
    ))(x) == 'Y'

    assert get_repr_function(x, ((lambda x: True, lambda x: 'Z'),))(x) == 'Z'

   

# Generated at 2022-06-22 18:29:25.508853
# Unit test for function truncate
def test_truncate():
    assert truncate(string='abcdefghijklmnopqrstuvwxyz', max_length=None) == \
    'abcdefghijklmnopqrstuvwxyz'
    assert truncate(string='abcdefghijklmnopqrstuvwxyz', max_length=10) == \
    'abcdefg...vwxyz'
    assert truncate(string='abcdefghijklmnopqrstuvwxyz', max_length=26) == \
    'abcdefghijklmnopqrstuvwxyz'
    assert truncate(string='abcdefghijklmnopqrstuvwxyz', max_length=27) == \
    'abcdefghijklmnopqrstuvwxyz'

# Generated at 2022-06-22 18:29:29.550030
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s
    a = A()
    a.write('hello')
    assert a.s == 'hello'

# Generated at 2022-06-22 18:29:39.468903
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('[a] at 0x7f1bf59bd9e0') == '[a]'
    assert normalize_repr('[a] at 0x7f1bf59bd9e01') == '[a] at 0x7f1bf59bd9e01'
    assert normalize_repr('[a] at 0x7f1bf59bd9e01') == '[a] at 0x7f1bf59bd9e01'
    assert normalize_repr('[a] at 0x7f1bf59bd9e01') == '[a] at 0x7f1bf59bd9e01'
    assert normalize_repr('[a] at 0x7f1bf59bd9e01') == '[a] at 0x7f1bf59bd9e01'



# Generated at 2022-06-22 18:29:49.224189
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    class A: pass
    class B: pass
    class C: pass
    def repr_func(x):
        return 'repr_func'
    assert get_repr_function(A(), ((A, repr_func), (B, lambda x: 'nother'), (1, 'fail'))) is repr_func
    assert get_repr_function(B(), ((A, repr_func), (B, lambda x: 'nother'), (1, 'fail'))) == 'nother'
    assert get_repr_function(C(), ((A, repr_func), (B, lambda x: 'nother'), (1, 'fail'))) is repr



# Generated at 2022-06-22 18:29:56.125043
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(x for x in [1, 2]) == (1, 2)

    assert ensure_tuple(['a', 'b']) == ('a', 'b')
    assert ensure_tuple('abc') == ('a', 'b', 'c')
    assert ensure_tuple('ab'.encode('utf-8')) == (b'a', b'b')



# Generated at 2022-06-22 18:30:05.834327
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('a' * 15) == 'a' * 15
    assert get_shortish_repr('a' * 17) == 'a' * 14 + '...' + 'a' * 3

    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(-123) == '-123'
    assert get_shortish_repr(b'abcd') == 'b\'abcd\''
    assert get_shortish_repr(b'abcde' * 1000) == 'b\'abcde\'...\'abcde\''
    assert get_shortish_repr(b'a' * 17, max_length=20) == 'b\'a\'...\'a\''

# Generated at 2022-06-22 18:30:08.604318
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestStream(WritableStream):
        def write(self, s):
            pass
    TestStream()



# Generated at 2022-06-22 18:30:20.466271
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', None) == '123456789'
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 10) == '123456789'
    assert truncate('123456789', 11) == '123456789'
    assert truncate('123456789', 8) == '12345...'
    assert truncate('123456789', 7) == '1234...'
    assert truncate('123456789', 6) == '123...'
    assert truncate('123456789', 5) == '12...'
    assert truncate('123456789', 4) == '1...'
    assert truncate('123456789', 3) == '...'

# Generated at 2022-06-22 18:30:24.408422
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Stream(WritableStream):
        def __init__(self):
            self.content = ''
        def write(self, s):
            self.content += s

    class NonStream:
        pass

    assert issubclass(Stream, WritableStream)
    assert not issubclass(NonStream, WritableStream)



# Generated at 2022-06-22 18:30:30.512900
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def write(self, s):
            pass

    a = A()
    assert isinstance(a, WritableStream)

    class B(WritableStream):
        def write(self, s):
            pass
        def close(self):
            pass

    b = B()
    assert isinstance(b, WritableStream)

# Generated at 2022-06-22 18:30:41.580299
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    
    assert get_shortish_repr(99, max_length=12, normalize=True) == '99'
    assert get_shortish_repr(99, max_length=12) == '99'
    assert get_shortish_repr(99, max_length=12, normalize=False) == '99'
    
    assert get_shortish_repr((99,), max_length=12) == '(99,)'
    assert get_shortish_repr((99,), max_length=12, normalize=True) == '(99,)'
    assert get_shortish_repr((99,), max_length=12, normalize=False) == '(99,)'
    
    assert get_shortish_repr([99], max_length=12) == '[99]'
    assert get_shortish

# Generated at 2022-06-22 18:30:45.541894
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyClass(WritableStream):
        def write(self, s):
            pass
    assert isinstance(MyClass(), WritableStream)
    assert not isinstance(MyClass(), ABC)
    assert not issubclass(list, WritableStream)
    assert not issubclass(ABC, WritableStream)



# Generated at 2022-06-22 18:30:54.770798
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    
    def __test(item, custom_repr, max_length, normalize, expected_result):
        shortish_repr = get_shortish_repr(item, custom_repr=custom_repr,
                                          max_length=max_length,
                                          normalize=normalize)
        assert shortish_repr == expected_result, \
            (shortish_repr, expected_result)
    
    __test(1, custom_repr=[], max_length=None, normalize=False,
           expected_result='1')
    __test(1, custom_repr=[], max_length=None, normalize=True,
           expected_result='1')

# Generated at 2022-06-22 18:31:02.449320
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, custom_repr=[(str, lambda x: '3')]) == repr
    assert get_repr_function(3, custom_repr=[(int, lambda x: '3')]) == repr

# Generated at 2022-06-22 18:31:05.779816
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((3, 4)) == (3, 4)



# Generated at 2022-06-22 18:31:12.363884
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('Hello\xc3\xb1world') == 'Hello?world'
    assert shitcode('\xc3\xb1world') == '?world'
    assert shitcode('\xc3\xb1') == '?'
    assert shitcode('') == ''
    assert shitcode('\n') == '\n'
    assert shitcode('\n\r\x00\xff') == '\n\r\x00\xff'



# Generated at 2022-06-22 18:31:16.181702
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\x00\x00\x00') == '???'
    assert shitcode('\x0a\d\x0c') == '\n\r\x0c'



# Generated at 2022-06-22 18:31:17.760480
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C:
        def write(self, s): pass

    assert issubclass(C, WritableStream)

# Generated at 2022-06-22 18:31:27.308245
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'bla') == u'bla'
    assert shitcode('bla') == 'bla'
    assert shitcode(u'bla\r\n') == u'bla\n'
    assert shitcode('bla\r\n') == 'bla\n'
    assert shitcode(u'bla aø') == u'bla?a?'
    assert shitcode('bla aø') == 'bla?a?'
    assert shitcode(u'bla a\xeb') == u'bla a?'
    assert shitcode('bla a\xeb') == 'bla a?'

# Generated at 2022-06-22 18:31:36.732280
# Unit test for function get_repr_function
def test_get_repr_function():

    class Banana:
        pass

    def banana_repr(x):
        assert x is banana
        return 'A banana!'

    def banana_repr_as_banana_repr(x):
        assert x is banana
        return banana_repr.__name__

    banana = Banana()
    custom_repr = [
        (Banana, banana_repr),
        (banana_repr, banana_repr_as_banana_repr)
    ]

    assert get_repr_function(banana, custom_repr=custom_repr) is banana_repr
    assert get_repr_function(
        banana_repr,
        custom_repr=custom_repr
    ) is banana_repr_as_banana_repr

# Generated at 2022-06-22 18:31:42.121385
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((3,)) == (3,)
    assert ensure_tuple([3]) == (3,)
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(['hello']) == ('hello',)
    assert ensure_tuple((x for x in range(3))) == (0, 1, 2)

# Generated at 2022-06-22 18:31:52.752355
# Unit test for function ensure_tuple
def test_ensure_tuple():
    class A(object): pass
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(()) == ()
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple('a') == ('a',)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple({1: 2, 3: 4}) == ({1: 2, 3: 4},)
    assert ensure_tuple(A()) == (A(),)
    assert ensure_tuple(A) == (A,)
    assert ensure_tuple(True) == (True,)
    assert ensure_tuple(False) == (False,)
    assert ensure_tuple(1) == (1,)

# Generated at 2022-06-22 18:32:03.073253
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X(object):
        def write(self, s):
            return s
    assert isinstance(X(), WritableStream)

    class Y(object):
        def write(self, s):
            return s
        def flush(self):
            return None
    assert isinstance(Y(), WritableStream)

    class Z(WritableStream):
        def write(self, s):
            return s
    assert isinstance(Z(), WritableStream)

    class BadWritableStream(WritableStream):
        pass

    class BadWritableStream2(WritableStream):
        def write(self, s):
            return s

    class BadWritableStream3(WritableStream):
        def write(self, s):
            return s
        def flush(self):
            return None


# Generated at 2022-06-22 18:32:07.601617
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeStream:
        def write(self, s):
            pass

    class RealStream(object):
        def write(self, s):
            pass

    assert isinstance(RealStream(), WritableStream) is True
    assert isinstance(FakeStream(), WritableStream) is True

# Generated at 2022-06-22 18:32:11.187691
# Unit test for function shitcode
def test_shitcode():
    s = u'abcde עלמה'
    assert shitcode(s) == 'abcde ???', repr(shitcode(s))
    assert shitcode(s.encode('utf8')) == b'abcde \xf9\xe5\xec\xe5', \
                                                            repr(shitcode(s))

# Generated at 2022-06-22 18:32:20.839087
# Unit test for function truncate
def test_truncate():
    assert truncate('abcde', 5) == 'abcde'
    assert truncate('abcde', 4) == 'abc...'
    assert truncate('abcde', 3) == 'abc...'
    assert truncate('abcde', 2) == 'a...'
    assert truncate('abcde', 1) == 'a...'
    assert truncate('abcde', 0) == '...'
    assert truncate('abcde', -1) == '...'
    assert truncate('abcde', None) == 'abcde'
    assert truncate('abcde', -5) == 'abcde'
    assert truncate('abcde', -10) == 'abcde'






# Generated at 2022-06-22 18:32:30.159925
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', None) == '1234567890'
    assert truncate('1234567890', 9) == '1234567890'
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('1234567890', 11) == '1234567890'
    assert truncate('1234567890', 15) == '1234567890'
    assert truncate('1234567890', 16) == '123456789...34567890'
    assert truncate('1234567890', 17) == '123456789...34567890'
    assert truncate('1234567890', 20) == '123456789...34567890'
    assert truncate('1234567890', 4) == '1...0'

# Generated at 2022-06-22 18:32:36.472258
# Unit test for constructor of class WritableStream
def test_WritableStream():
    try:
        WritableStream()
    except TypeError:
        pass
    else:
        raise AssertionError

    class A(WritableStream):
        write = None

    try:
        A()
    except TypeError:
        pass
    else:
        raise AssertionError

    class B(WritableStream):
        def write(self, s):
            pass

    B()



# Generated at 2022-06-22 18:32:46.440265
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    def WritableStream_mock_write(s):
        return s

    class WritableStream_mock(WritableStream):
        def write(self, s):
            return WritableStream_mock_write(s)
    assert WritableStream.__subclasshook__(WritableStream_mock)

    # Make sure that `string_types` is a proxy for `basestring`
    if sys.version_info >= (3,):
        assert not string_types[0] is str

    def test_write_mock(s):
        if not isinstance(s, string_types):
            raise TypeError

    def test_write(s):
        test_write_mock(s)
        return s

    class TestWritableStream(WritableStream):
        def write(self, s):
            return test_

# Generated at 2022-06-22 18:32:57.587462
# Unit test for function normalize_repr
def test_normalize_repr():
    from .python_toolbox import pretty_ending

    assert normalize_repr('asd') == 'asd'
    assert normalize_repr('Foo at 0xBABABA') == 'Foo'
    assert normalize_repr('Foo at 0xBAB4B4B4') == 'Foo'
    assert normalize_repr('Foo asdf at 0xBAB4B4B4a') == 'Foo asdf'
    assert normalize_repr('Foo at 0xBAB4B4B4F') == 'Foo'
    assert normalize_repr('Foo ') == 'Foo '
    assert normalize_repr('Foo ' * 10) == 'Foo Foo Foo Foo Foo Foo Foo Foo Foo ' \
                                         'Foo '
    assert normalize_re

# Generated at 2022-06-22 18:33:02.963885
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple((1,)) == (1,)





# Generated at 2022-06-22 18:33:12.552907
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('abc') == 'abc'
    assert normalize_repr('abc at 0x123') == 'abc'
    assert normalize_repr('abc at 0x123A23') == 'abc'
    assert normalize_repr('abc at 0x123A23A123') == 'abc'
    assert normalize_repr('abc at 0x123A23A123123') == 'abc'
    assert normalize_repr('abc at 0x123A23A123123A23A') == 'abc'
    assert (normalize_repr('abc at 0x123A23A123123A23A at 0x123') ==
            'abc at 0x123A23A123123A23A')




# Generated at 2022-06-22 18:33:20.529745
# Unit test for function normalize_repr
def test_normalize_repr():
    from . import scripting_tools
    from .python_toolbox import caching
    assert normalize_repr('<scripting_tools.test_scripting_tools.MyClass '
                          'object at 0x10dc58f50>') == \
        str('<scripting_tools.test_scripting_tools.MyClass object '
            'at 0x10dc58f50>')
    assert normalize_repr('<caching.InMemoryCachesSet '
                          'object at 0x10dc58f50>') == \
        str('<caching.InMemoryCachesSet object at 0x10dc58f50>')

# Generated at 2022-06-22 18:33:21.447167
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<instance object at 0x1234>') == '<instance object>'



# Generated at 2022-06-22 18:33:31.818316
# Unit test for function truncate
def test_truncate():
    assert truncate('12345678', 8) == '12345678'
    assert truncate('12345678', 7) == '1234567...'
    assert truncate('12345678', 6) == '1234...'
    assert truncate('12345678', 5) == '12...'
    assert truncate('12345678', 4) == '1...'
    assert truncate('12345678', 3) == '...'
    assert truncate('12345678', 2) == '...'
    assert truncate('12345678', 1) == '...'
    assert truncate('12345678', 0) == '...'
    assert truncate('12345678', -1) == '...'
    assert truncate('12345678', 9) == '12345678'



# Generated at 2022-06-22 18:33:41.742422
# Unit test for function shitcode
def test_shitcode():
    def test(string, expected_output):
        actual_output = shitcode(string)
        if actual_output != expected_output:
            raise Exception(f'Got {actual_output!r} instead of '
                            f'{expected_output!r} when shitcoding '
                            f'{string!r}')

    test('זיַן', '??')
    test('זיַן', '??')
    test('a', 'a')
    test('', '')
    test('\r\n', '\r\n')
    test('\x04', '?')
    test('\u1234', '?')
    test('\x01', '?')

# Generated at 2022-06-22 18:33:44.868510
# Unit test for function shitcode
def test_shitcode():
    assert(shitcode('Hello, world!') == 'Hello, world!')
    assert(shitcode('\xff\x96\xe7') == '???\xe7')
    assert(shitcode(u'\xff\x96\xe7') == '???\xe7')
    assert(shitcode('') == '')




# Generated at 2022-06-22 18:33:50.351178
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('foo') == 'foo'
    assert normalize_repr('foo at 0xBEEF') == 'foo'
    assert normalize_repr('a at 0xbEEF and b at 0xc001') == 'a and b'



# Generated at 2022-06-22 18:33:58.221277
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStringIO(WritableStream):
        def __init__(self, *args, **kwargs):
            self._buffer = []
            self.flush_history = {}

        def write(self, s):
            self._buffer.append(s)


        def getvalue(self):
            return ''.join(self._buffer)

        def flush(self):
            pass

    writable_string_io = WritableStringIO()
    assert isinstance(writable_string_io, WritableStream)



# Generated at 2022-06-22 18:34:07.525634
# Unit test for function get_repr_function
def test_get_repr_function():

    def wrong_repr(x):
        raise NotImplementedError

    assert get_repr_function(None, (('a', wrong_repr),)) == repr
    assert get_repr_function(None, (('b', wrong_repr), (None, wrong_repr))) \
                                                                         == repr
    assert get_repr_function(None, ((None, wrong_repr), (None, wrong_repr))) \
                                                                         == repr
    assert get_repr_function(None, ((None, wrong_repr), (None, repr))) == repr
    assert get_repr_function(None, ((None, repr), (None, wrong_repr))) == repr
    assert get_repr_function(None, ((None, repr),)) == repr


    class A(object): pass

   

# Generated at 2022-06-22 18:34:09.724294
# Unit test for function shitcode
def test_shitcode():
    unicode_string = 'אבגדהוזחטיכ'
    assert shitcode(unicode_string) == '??????'
    return True

# Generated at 2022-06-22 18:34:13.156116
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X:
        def write(self, s):
            return s
    assert issubclass(X, WritableStream)
    x = X()
    assert x.write('a') == 'a'



# Generated at 2022-06-22 18:34:21.305043
# Unit test for method write of class WritableStream
def test_WritableStream_write():


    class WritableStreamMock(WritableStream):
        def write(self, s):
            self.s = s

    writable_stream_mock = WritableStreamMock()
    writable_stream_mock.write('something')
    assert isinstance(writable_stream_mock, WritableStream)
    assert writable_stream_mock.s == 'something'
    if sys.version_info[:2] < (3, 3):
        assert WritableStream.__subclasshook__(WritableStreamMock) is True
    else:
        assert isinstance(WritableStreamMock, WritableStream)

# Generated at 2022-06-22 18:34:28.084387
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr((1, 2, 3, {4, 5, 6})) == \
                           "((1, 2, 3, set([4, 5, 6])))"
    assert len(get_shortish_repr((1, 2, 3, {4, 5, 6}), max_length=15)) == 15
    assert len(get_shortish_repr((1, 2, 3, {4, 5, 6}), max_length=12)) == 12
    assert len(get_shortish_repr((1, 2, 3, {4, 5, 6}), max_length=10)) == 10
    assert len(get_shortish_repr((1, 2, 3, {4, 5, 6}), max_length=9)) == 9

# Generated at 2022-06-22 18:34:38.941595
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnopqrstuvwxyz', 10) == 'abcdefghij...vwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 20) == 'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 27) == 'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 5) == '...xyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 3) == '...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 1) == '.'

# Generated at 2022-06-22 18:34:48.685516
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 8) == '123456789'
    assert truncate('123456789', 7) == '12345...'
    assert truncate('123456789', 6) == '12...'
    assert truncate('123456789', 5) == '12345'
    assert truncate('123456789', 4) == '123...'
    assert truncate('123456789', 3) == '12...'
    assert truncate('123456789', 2) == '1...'
    assert truncate('123456789', 1) == '...'
    assert truncate('123456789', 0) == '...'

# Generated at 2022-06-22 18:34:51.126460
# Unit test for function truncate
def test_truncate():
    assert truncate('yo mama', 5) == 'yo ma'
    assert truncate('yo mama', 20) == 'yo mama'

# Generated at 2022-06-22 18:34:55.864079
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.string_written = ''
        def write(self, s):
            self.string_written += s
    MyWritableStream()

    # Should raise TypeError:
    class MyNotWritableStream(WritableStream):
        pass
    MyNotWritableStream()



# Generated at 2022-06-22 18:34:59.718468
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == [1]
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == [1, 2]
    assert ensure_tuple(range(3)) == (0, 1, 2)

# Generated at 2022-06-22 18:35:02.696453
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u"abc") == u"abc"
    assert shitcode(u"abc\n") == u"abc?"
    assert shitcode(u"abc中") == u"abc??"
    assert shitcode(u"中") == u"??"



# Generated at 2022-06-22 18:35:13.448245
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import numbers
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(11, max_length=4) == '11'
    assert get_shortish_repr(111, max_length=4) == '111'
    assert get_shortish_repr(1111, max_length=4) == '...'

# Generated at 2022-06-22 18:35:16.326397
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyStream(WritableStream):
        pass

    assert issubclass(MyStream, WritableStream)

# Generated at 2022-06-22 18:35:26.869405
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnopqrstuvwxyz', None) == 'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 27) == 'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 26) == 'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 25) == 'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 10) == 'abcdefghijklmnopqrstuvwxyz'

# Generated at 2022-06-22 18:35:32.772921
# Unit test for function truncate
def test_truncate():
    assert truncate('123456', None) == '123456'
    assert truncate('123456', 1) == '1...'
    assert truncate('123456', 2) == '12...'
    assert truncate('123456', 3) == '123...'
    assert truncate('123456', 4) == '1234...'
    assert truncate('123456', 5) == '12345...'
    assert truncate('123456', 6) == '123456'
    assert truncate('123456', 7) == '123456'
    assert truncate('123456', 8) == '123456'



# Generated at 2022-06-22 18:35:36.175723
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\x00\x02\x04\x06') == '???'
    assert shitcode('') == ''



# Generated at 2022-06-22 18:35:46.199982
# Unit test for function get_repr_function
def test_get_repr_function():

    def custom_repr_for_numbers(x):
        return 'cust'

    custom_repr = ((int, custom_repr_for_numbers),)

    assert get_repr_function(0, custom_repr) is custom_repr_for_numbers
    assert get_repr_function(0.0, custom_repr) == repr
    assert get_repr_function('', custom_repr) == repr

    def custom_repr_for_even_numbers(x):
        assert x % 2 == 0
        if x % 4 == 0:
            return 'x is divisible by 4'
        else:
            return 'x is not divisible by 4'


# Generated at 2022-06-22 18:35:56.995841
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''

    assert get_shortish_repr(1.5) == '1.5'
    assert get_shortish_repr(1.5, max_length=3) == '1.5'
    assert get_shortish_repr(1.5, max_length=2) == '1'
    assert get_shortish_repr(1.5, max_length=1) == '1'