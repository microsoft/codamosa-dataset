

# Generated at 2022-06-22 18:25:58.714548
# Unit test for function truncate
def test_truncate():
    assert truncate('', 100) == ''
    assert truncate('a', 100) == 'a'
    assert truncate('abc', 100) == 'abc'
    assert truncate('abc', 2) == 'ab...'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 4) == 'abc'
    assert truncate('abcd', 4) == 'a...'
    assert truncate('abcde', 4) == 'a...'
    assert truncate('abcdef', 4) == 'a...'

# Generated at 2022-06-22 18:26:04.751719
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written = ''

        # Should pass
        def write(self, s):
            self.written += s


    # Should not pass
    class MyEvilWritableStream(WritableStream):
        def __init__(self):
            self.written = ''

        def write2(self, s):
            self.written += s

    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(MyEvilWritableStream, WritableStream)

# Generated at 2022-06-22 18:26:12.057581
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([2, 3]) == '[2, 3]'
    assert get_shortish_repr([2, 3], max_length=1) == '[...]'
    assert get_shortish_repr([2, 3], max_length=2) == '[...]'
    assert get_shortish_repr([2, 3], max_length=3) == '[...]'
    assert get_shortish_repr([2, 3], max_length=4) == '[...]'
    assert get_shortish_repr([2, 3], max_length=5) == '[...]'
    assert get_shortish_repr([2, 3], max_length=6) == '[...]'
    assert get_shortish_repr([2, 3], max_length=7) == '[2, 3]'
   

# Generated at 2022-06-22 18:26:22.722620
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(10, max_length=3, normalize=True) == '10'
    assert get_shortish_repr(10, max_length=4, normalize=True) == '10'

    assert get_shortish_repr(10, max_length=2, normalize=True) == '...'
    assert get_shortish_repr(10, max_length=1, normalize=True) == '...'
    assert get_shortish_repr(10, max_length=0, normalize=True) == '...'
    assert get_shortish_repr(10, max_length=-1, normalize=True) == '...'


# Generated at 2022-06-22 18:26:26.846483
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(2) == (2,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)

# Generated at 2022-06-22 18:26:35.123071
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', None) == 'abc'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abcdefghi', 9) == 'abcdefghi'
    assert truncate('abcdefghi', 8) == 'abcdefg...'
    assert truncate('abcdefghi', 7) == 'abcde...'
    assert truncate('abcdefghi', 6) == 'abc...'
    assert truncate('abcdefghi', 5) == 'ab...'
    assert truncate('abcdefghi', 4) == 'a...'
    assert truncate('abcdefghi', 3) == '...'
    assert truncate('abcdefghi', 2) == '..'
    assert truncate('abcdefghi', 1) == '.'

# Generated at 2022-06-22 18:26:46.506455
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 9) == '123456789'
    assert truncate('12345678', 9) == '12345678'
    assert truncate('1234567', 9) == '1234567'
    assert truncate('123456', 9) == '123456'
    assert truncate('12345', 9) == '12345'
    assert truncate('1234', 9) == '1234'
    assert truncate('123', 9) == '123'
    assert truncate('12', 9) == '12'
    assert truncate('1', 9) == '1'
    assert truncate('', 9) == ''
    
    assert truncate('123456789', 8) == '123456789'
    assert truncate('12345678', 8) == '12345678'

# Generated at 2022-06-22 18:26:48.825751
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(12) == '12'
    assert get_shortish_repr([1, 2, 3], max_length=5) == '[1, 2]'



# Generated at 2022-06-22 18:26:50.123839
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C:
        def write(self, s):
            pass

    assert isinstance(C(), WritableStream)

# Generated at 2022-06-22 18:26:53.072363
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple({'a': 1}) == ({'a': 1},)





# Generated at 2022-06-22 18:27:03.024340
# Unit test for function shitcode
def test_shitcode():

    # Unicode characters:
    assert shitcode(u'ششششش') == u'?????'

    # Non-ascii characters:
    assert shitcode(u'אאאאא') == u'?????'

    # Control characters:
    assert shitcode('\x00') == '?'
    assert shitcode('\x01') == '?'
    assert shitcode('\x02') == '?'
    assert shitcode('\x03') == '?'
    assert shitcode('\x04') == '?'
    assert shitcode('\x05') == '?'
    assert shitcode('\x06') == '?'
    assert shitcode('\x07') == '?'
    assert shitcode('\x08') == '?'
    assert shitcode('\x09') == '?'
    assert shitcode

# Generated at 2022-06-22 18:27:09.296931
# Unit test for function normalize_repr
def test_normalize_repr():
    class A(object):
        pass
    assert normalize_repr(repr(A())) != repr(A()) # noqa # I used to use `A()` instead of `A()` here
    assert normalize_repr(repr(A())) == '<__main__.A object at 0x01234567>'



# Generated at 2022-06-22 18:27:12.472501
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyStream(WritableStream):
        def write(self, s):
            self.s = s
    stream = MyStream()
    stream.write('abc')
    assert stream.s == 'abc'

# Generated at 2022-06-22 18:27:17.808050
# Unit test for function truncate
def test_truncate():
    def ttt(string, length, expected_result):
        actual_result = truncate(string, length)
        assert actual_result == expected_result

    ttt('0123456789a123456789b123456789', None, '0123456789a123456789b123456789')
    ttt('0123456789a123456789b123456789', 0, '0123456789a123456789b123456789')
    ttt('0123456789a123456789b123456789', 1, '...')
    ttt('0123456789a123456789b123456789', 2, '0...')
    ttt('0123456789a123456789b123456789', 3, '01...')
    t

# Generated at 2022-06-22 18:27:20.636100
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeStream(WritableStream):
        def write(self, *args, **kwargs):
            pass
    assert issubclass(FakeStream, WritableStream)



# Generated at 2022-06-22 18:27:26.078629
# Unit test for function truncate
def test_truncate():
    assert truncate(u'', 10) == u''
    assert truncate(u'12345', 10) == u'12345'
    assert truncate(u'123456789', 10) == u'123456789'
    assert truncate(u'12345678901', 10) == u'12345...101'
    assert truncate(u'1234567890', 10) == u'12345...90'
    assert truncate(u'1234567890', 3) == u'123...'



# Generated at 2022-06-22 18:27:31.460307
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A:
        def void():
            pass
    assert _check_methods(A, 'void') is NotImplemented

    class B(object):
        def void(self):
            pass
    assert _check_methods(B, 'void') is True

    class C(object):
        def void(self):
            pass
        void = None
    assert _check_methods(C, 'void') is NotImplemented

    class D(object):
        def write(self, s):
            pass
    assert issubclass(D, WritableStream) is True



# Generated at 2022-06-22 18:27:35.858321
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A:
        def write(self, s):
            pass
    assert WritableStream.register(A)


# Testing `truncate()`

# Generated at 2022-06-22 18:27:46.189048
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5) is repr
    assert get_repr_function(5, [(lambda x: True, str)]) is str
    assert get_repr_function('hello', [(lambda x: True, str)]) is str
    assert get_repr_function(5, [(int, str)]) is str
    assert get_repr_function('hello', [(int, str)]) is repr
    assert get_repr_function(5, [(lambda x: False, str)]) is repr
    assert get_repr_function(5, [(lambda x: False, str), (lambda x: True, str)]) is str
    assert get_repr_function(5, [(lambda x: False, str), (lambda x: True, str), (lambda x: False, str)]) is str
    assert get_repr

# Generated at 2022-06-22 18:27:56.174791
# Unit test for function normalize_repr
def test_normalize_repr():
    # pylint: disable=undefined-all-variable
    def tester(input_repr, expected_output):
        """Test a single case, then undo the test"""
        # pylint: disable=unused-variable
        real_repr = object.__repr__
        object.__repr__ = lambda x: input_repr
        answer = normalize_repr(object)
        object.__repr__ = real_repr
        assert answer == expected_output, '%s != %s for %s' % (answer,
                                                              expected_output,
                                                              input_repr)
        return answer


# Generated at 2022-06-22 18:28:05.551328
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('a') == 'a'
    assert get_shortish_repr('a' * 100) == 'a' * 100
    assert get_shortish_repr('a' * 100, max_length=99) == 'a' * 99
    assert get_shortish_repr('a' * 101, max_length=100) == 'a' + 'a' * 97 + '...'
    assert get_shortish_repr('a' * 101, max_length=99) == 'a' * 97 + '...'
    assert get_shortish_repr('1' * 2000000, max_length=20) == '1' * 17 + '...'
    assert get_shortish_repr('a' * 100, max_length=101) == 'a' * 100
    assert get

# Generated at 2022-06-22 18:28:07.741522
# Unit test for function shitcode
def test_shitcode():
    msg = "Hello in Hebrew שלום"
    assert shitcode(msg) == "Hello in Hebrew ??????"



# Generated at 2022-06-22 18:28:13.069771
# Unit test for function shitcode
def test_shitcode():
    r'''
    >>> shitcode(b'\xff\xfe\x01')
    '??\x01'
    >>> shitcode(bytearray(b'\xff\xfe\x01'))
    '??\x01'
    >>> shitcode(bytearray(b'\xff\xfe\x01'))
    '??\x01'
    >>> shitcode(u'\xff\xfe\x01')
    '??\x01'
    '''



# Generated at 2022-06-22 18:28:19.063685
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    writable_stream, = (os for type_name in ('WritableStream', 'FileIO')
                        for os in sys.modules.itervalues()
                        if hasattr(os, type_name) and (os.__name__.startswith('io') or
                                                       os.__name__.startswith('os')))
    assert issubclass(writable_stream.__class__, WritableStream)

# Generated at 2022-06-22 18:28:24.277540
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x123') == 'hello'
    assert normalize_repr('hello at 0x1234') == 'hello'
    assert normalize_repr('hello at 0x1234') == 'hello'
    assert normalize_repr('hello at 0x123456789abc') == 'hello'

# Generated at 2022-06-22 18:28:31.833283
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class A(object):
        def __repr__(self):
            return 'repr'*200
    a = A()
    assert get_shortish_repr(a, max_length=10) == 'reprreprr...prrepr'
    assert get_shortish_repr(a, max_length=202) == 'repr' * 200
    assert get_shortish_repr(a, max_length=None) == 'repr' * 200
    assert get_shortish_repr(a, max_length=0) == ''
    assert get_shortish_repr(a, max_length=-1) == ''



# Generated at 2022-06-22 18:28:39.338731
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .repr_tools import get_shortish_repr

    repr_is_short = lambda x: len(get_shortish_repr(x)) < 10

    assert repr_is_short(_test_get_shortish_repr)
    assert get_shortish_repr(_test_get_shortish_repr) == 'function'
    assert get_shortish_repr(3) == '3'

    def must_not_be_too_long(x):
        assert len(get_shortish_repr(x, max_length=10)) <= 10

    must_not_be_too_long(' '.join(str(i) for i in range(10))*10)
    must_not_be_too_long(' '.join(str(i) for i in range(10)))
    must_not

# Generated at 2022-06-22 18:28:50.263023
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert get_shortish_repr(u'hello') == "u'hello'"
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(10) == '10'
    assert get_shortish_repr(10, max_length=1) == '1...0'
    assert get_shortish_repr(10, max_length=3) == '1...0'
    assert get_shortish_repr(100, max_length=3) == '100'
    assert get_shortish_repr('hello', max_length=3) == "'he...'"
    assert get_shortish_repr(true) == 'True'



# Generated at 2022-06-22 18:28:59.102055
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    import python_toolbox.nifty_collections

    # A straightforward string:
    assert get_shortish_repr('a' * 100, max_length=5) == 'a' * 5

    # A number
    assert get_shortish_repr(3) == '3'

    # A custom repr
    assert get_shortish_repr(3, custom_repr=[(int, str)]) == '3'

    # Multiple custom reprs
    assert get_shortish_repr(3.0, custom_repr=((int, str),)) == '3.0'

    # Custom repr for a container:

# Generated at 2022-06-22 18:29:04.253287
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream): pass
    assert issubclass(A, WritableStream)
    class B(A): pass
    assert issubclass(B, WritableStream)
    class C: pass
    assert not issubclass(C, WritableStream)
    class D(C, A): pass
    assert issubclass(D, WritableStream)



# Generated at 2022-06-22 18:29:07.736722
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout.__class__, WritableStream)
    assert not issubclass(object, WritableStream)
    assert not issubclass(5, WritableStream)

# Generated at 2022-06-22 18:29:11.033423
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s): pass
        def other(self): pass

    assert issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def other(self): pass

    assert not issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-22 18:29:16.556199
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.text = ''
        def write(self, s):
            self.text += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('hello')
    assert my_writable_stream.text == 'hello'



# Generated at 2022-06-22 18:29:23.356186
# Unit test for function truncate
def test_truncate():
    assert truncate('', 3) == ''
    assert truncate('1234', 3) == '123'
    assert truncate('1234', None) == '1234'
    assert truncate('1234567890', None) == '1234567890'
    assert truncate('1234567890', 3) == '123...890'
    assert truncate('1234567890', 2) == '1...0'
    assert truncate('1234567890', 1) == '...'



# Generated at 2022-06-22 18:29:27.274909
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('aaa', custom_repr=((1, 'BBB'),)) == repr
    assert get_repr_function(1, custom_repr=((1, 'BBB'),)) == 'BBB'



# Generated at 2022-06-22 18:29:29.489453
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from ..abc_tools import WritableStream
    import io
    assert issubclass(io.StringIO, WritableStream)



# Generated at 2022-06-22 18:29:38.271175
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class Foo(object):
        def __repr__(self):
            return 'Foo()'
        def custom_repr(self):
            return 'custom Foo()'

    assert get_shortish_repr('Hello', max_length=None) == 'Hello'
    assert get_shortish_repr('Hello', max_length=3) == 'Hel...'

    assert get_shortish_repr(Foo(), custom_repr=(
        (Foo, Foo.custom_repr),
    )) == 'custom Foo()'
    assert get_shortish_repr(Foo(), max_length=3, custom_repr=(
        (Foo, Foo.custom_repr),
    )) == 'c...'

    assert get_shortish_repr(None, max_length=None) == 'None'

# Generated at 2022-06-22 18:29:42.013892
# Unit test for function truncate
def test_truncate():
    assert truncate('', 10) == ''
    assert truncate('hi', 10) == 'hi'
    assert truncate('hello, world', 10) == 'hello...rld'



# Generated at 2022-06-22 18:29:46.325171
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(10) == (10,)
    assert ensure_tuple((10,)) == (10,)
    assert ensure_tuple([10]) == (10,)
    assert ensure_tuple({10}) == (10,)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(['a', 'b', 'c']) == ('a', 'b', 'c')
    assert ensure_tuple(x for x in (1, 2, 3)) == (1, 2, 3)




# Generated at 2022-06-22 18:29:50.685373
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C: pass

    a = A()
    b = B()
    c = C()

    class D(A, B): pass

    d = D()

    custom_repr = ((A, lambda a: 'A is good'), (B, lambda b: 'B is good'))


# Generated at 2022-06-22 18:29:52.128236
# Unit test for function normalize_repr
def test_normalize_repr():
    dic = {'key': 'value'}
    assert normalize_repr(repr(dic)) == normalize_repr(repr(dic))



# Generated at 2022-06-22 18:29:54.660921
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<dog at 0x123456>') == '<dog>'
    assert normalize_repr('<cat at 0x5678>') == '<cat>'



# Generated at 2022-06-22 18:29:57.909169
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout, WritableStream)
    assert not issubclass(object, WritableStream)
    assert not issubclass(3, WritableStream)
    assert not issubclass('a', WritableStream)
    assert not issubclass(tuple(), WritableStream)



# Generated at 2022-06-22 18:30:00.468230
# Unit test for constructor of class WritableStream
def test_WritableStream():

    import zlib

    assert issubclass(zlib.Compress, WritableStream)

# Generated at 2022-06-22 18:30:05.268944
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self, source):
            self.source = source

        def write(self, s):
            self.source.append(s)

    source = []
    w = MyWritableStream(source)
    w.write('helllllllllllllllllllllo')
    source_expected = ['helllllllllllllllllllllo']
    assert source == source_expected

# Generated at 2022-06-22 18:30:09.283874
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(1) == (1,)



# Generated at 2022-06-22 18:30:15.055515
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class FileLike: pass
    assert not issubclass(FileLike, WritableStream)
    FileLike.write = None
    assert not issubclass(FileLike, WritableStream)
    FileLike.write = lambda self, s: None
    assert issubclass(FileLike, WritableStream)




# Generated at 2022-06-22 18:30:24.484377
# Unit test for function truncate
def test_truncate():
    assert truncate('', None) == ''
    assert truncate('', 10) == ''
    assert truncate('x', None) == 'x'
    assert truncate('x', 10) == 'x'
    assert truncate('12345678901234567890', 10) == '12345...67890'
    assert truncate('123456789012345678901234', 20) == '1234...901234'
    assert truncate('1234567890123456789012345678901234567890', 40) == \
                                                         '1234...67890'


REPR_OPTIONS = (
    ('repr_function', 'custom_repr'),
    ('max_length', 'max_length'),
    ('normalize', 'normalize')
)



# Generated at 2022-06-22 18:30:36.192742
# Unit test for function truncate
def test_truncate():
    s = 'abcdefghijklmnopqrstuvwxyz'
    assert truncate(s, 100) == s
    assert truncate(s, 10) == 'abcdef...xyz'
    assert truncate(s, 9) == 'abcdef...xyz'
    assert truncate(s, 8) == '...qrstuvwxyz'
    assert truncate(s, 0) == ''
    assert truncate(s, -1) == ''
    assert truncate(s, None) == s.strip()
    assert truncate(s + ' ' + s, 100) == s + ' ' + s
    assert truncate(s + ' ' + s, 50) == 'abcdefghijklmnopqrstuvwxyz abcdefghijklmnopqrstuvwxyz'
   

# Generated at 2022-06-22 18:30:39.982415
# Unit test for function truncate
def test_truncate():
    assert truncate(u'hello', 5) == u'hello'
    assert truncate(u'hello', 4) == u'he...'
    assert truncate(u'hello', 3) == u'h...'
    assert truncate(u'hello', 2) == u'...'
    assert truncate(u'hello', 1) == u'.'
    assert truncate(u'hello', 0) == u''
    assert truncate(u'hello', -1) == u''
    assert truncate(u'helloworld', 5) == u'...ld'
    assert truncate(u'helloworld', 2) == u'...'
    assert truncate(u'helloworld', 10) == u'helloworld'



# Generated at 2022-06-22 18:30:45.050165
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(file, WritableStream)
    assert issubclass(sys.stdout.__class__, WritableStream)
    assert not issubclass(object, WritableStream)

    class A:
        def write(self, s):
            pass

    class B:
        def write(self, x):
            pass

    assert issubclass(A, WritableStream)
    assert not issubclass(B, WritableStream)

# Generated at 2022-06-22 18:30:50.441860
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hi') == 'hi'
    assert normalize_repr('hi at 0x1234') == 'hi'
    assert normalize_repr(' at 0x1234') == ''
    assert normalize_repr(' at oxFF67') == ''


# Generated at 2022-06-22 18:30:56.289934
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert isinstance(StringIO(), WritableStream)
    assert not isinstance(StringIO(), SequentialStream)
    assert isinstance(StringIO(), SequentialStreamMixin)
    assert not isinstance(StringIO(), SequentialStreamMixin)


# It's theoretically possible to write a class which is both writable and
# readable without inheriting from the other, so we have to check for both.

# Generated at 2022-06-22 18:30:59.070341
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)



# Generated at 2022-06-22 18:31:10.599810
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    my_repr = lambda x: 'b'
    assert get_shortish_repr(['a'], [(lambda x: True, my_repr)]) == 'b'
    assert get_shortish_repr(['a'], [(list, my_repr)]) == 'b'
    assert get_shortish_repr(['a'], [(lambda x: True, lambda x: 'c')]) == 'c'
    assert get_shortish_repr(['a']) == "['a']"
    assert get_shortish_repr('a') == "'a'"
    assert get_shortish_repr('a', max_length=2) == "'a'"
    assert get_shortish_repr('a', max_length=1) == "'a'"

# Generated at 2022-06-22 18:31:18.239611
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C(A): pass
    assert get_repr_function(A(), ()) == repr
    assert get_repr_function(A(), ((A, None),)) == None
    assert get_repr_function(A(), ((A, 1),)) == 1
    assert get_repr_function(A(), ((A, lambda: 2),)) == 2
    assert get_repr_function(A(), ((B, 3),)) == repr
    assert get_repr_function(C(), ((A, 4),)) == 4






# Generated at 2022-06-22 18:31:24.404650
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FooBar(WritableStream):
        def write(self, x):
            return 'foo' + x + 'bar'

    assert isinstance(FooBar(), WritableStream)

    class NotImplementedFooBar(FooBar):
        write = None

    assert not isinstance(NotImplementedFooBar(), WritableStream)



# Generated at 2022-06-22 18:31:27.262089
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout.__class__, WritableStream)

    class Foo(object): pass
    assert not issubclass(Foo, WritableStream)

# Generated at 2022-06-22 18:31:29.013995
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import io
    assert WritableStream.__subclasshook__(io.StringIO) is True



# Generated at 2022-06-22 18:31:37.357466
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('xxx') == ('xxx',)
    assert ensure_tuple(['xxx']) == ('xxx',)
    assert ensure_tuple(('xxx',)) == ('xxx',)
    assert ensure_tuple(['xxx', 'yyy']) == ('xxx', 'yyy')
    assert ensure_tuple('xxx', 'yyy') == ('xxx',)
    assert ensure_tuple(['xxx', 'yyy'], 'zzz') == ('xxx', 'yyy')
    assert ensure_tuple(['xxx', 'yyy'], ['zzz']) == ('xxx', 'yyy')
    assert ensure_tuple(['xxx', 'yyy'], ('zzz',)) == ('xxx', 'yyy')

# Generated at 2022-06-22 18:31:44.441208
# Unit test for function truncate
def test_truncate():
    assert truncate('', None) == ''
    assert truncate('abcdef', None) == 'abcdef'
    assert truncate('a' * 100, None) == 'a' * 100
    assert truncate('', 5) == ''
    assert truncate('abcdef', 5) == 'ab...'
    assert truncate('a' * 100, 5) == 'a...'

if __name__ == '__main__':
    test_truncate()
    print('ok!')

# Generated at 2022-06-22 18:31:48.637677
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class WritableStreamTester(object):
        def write(self, s):
            pass

    assert isinstance(WritableStreamTester(), WritableStream)
    assert not isinstance(WritableStream() if sys.version_info[0] == 2 else
                          object(), WritableStream)

# Generated at 2022-06-22 18:31:52.928306
# Unit test for function truncate
def test_truncate():
    assert truncate(None, None) is None
    assert truncate(123, None) == 123
    assert truncate(123, 1) == 123
    assert truncate(123, 2) == 123
    assert truncate(123, 3) == 123
    assert truncate(123, 4) == 123
    assert truncate(123, 5) == 123
    assert truncate(123, 6) == 123
    assert truncate(123, 7) == 123

    assert truncate('', None) == ''
    assert truncate('', 1) == ''
    assert truncate('', 2) == ''
    assert truncate('', 3) == ''
    assert truncate('', 4) == ''
    assert truncate('', 5) == ''
    assert truncate('', 6) == ''
    assert truncate('', 7) == ''

    assert trunc

# Generated at 2022-06-22 18:31:57.690732
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('Hello, world') == 'Hello, world'
    assert shitcode(u'\U0001F44C') == '?'
    assert shitcode(u'\u2028') == '?'



# Generated at 2022-06-22 18:32:01.656552
# Unit test for function truncate
def test_truncate():
    assert truncate('abcd', 4) == 'abcd'
    assert truncate('abcd', 3) == 'abcd'
    assert truncate('abcd', 2) == 'abcd'
    assert truncate('abcd', 1) == 'a...'
    assert truncate('abcd', 0) == '...'



# Generated at 2022-06-22 18:32:07.336278
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamImplementation(WritableStream):
        def __init__(self):
            self.data = b''
        def write(self, s):
            self.data += s
    assert issubclass(WritableStreamImplementation, WritableStream)
    WritableStreamImplementation()



# Generated at 2022-06-22 18:32:13.762677
# Unit test for function truncate
def test_truncate():
    assert truncate('Hello, World!', max_length=12) == 'Hello, World!'
    assert truncate('Hello, World!', max_length=13) == 'Hello, World!'
    assert truncate('Hello, World!', max_length=14) == 'Hello, World!'

    assert truncate('Hello, World!', max_length=11) == 'Hello, Wor...'
    assert truncate('Hello, World!', max_length=10) == 'Hello, Wo...'
    assert truncate('Hello, World!', max_length=9) == 'Hello, W...'
    assert truncate('Hello, World!', max_length=8) == 'Hello, ...'
    assert truncate('Hello, World!', max_length=7) == 'Hello...'

# Generated at 2022-06-22 18:32:17.949255
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    #    def test_writable_stream_write():
    import io
    stream = io.StringIO()
    assert isinstance(stream, WritableStream)
    stream.write('hey')
    assert stream.getvalue() == 'hey'

# Generated at 2022-06-22 18:32:27.221372
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((3,)) == (3,)
    assert ensure_tuple((3, 5)) == (3, 5)
    assert ensure_tuple({3, 5}) == ({3, 5},)
    assert ensure_tuple([3, 5]) == ([3, 5],)
    assert ensure_tuple([3]) == ([3],)
    assert ensure_tuple([]) == tuple()
    assert ensure_tuple(3) == (3,)
    def f():
        yield 5
    assert ensure_tuple(f()) == ((5,))



# Generated at 2022-06-22 18:32:38.628879
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x1234') == 'hello'
    assert normalize_repr('hello at 0x12345') == 'hello'
    assert normalize_repr('hello at 0x123456789') == 'hello'
    assert normalize_repr('hello at 0x1234567890') == 'hello'
    assert normalize_repr('hello at 0x1234567890123') == 'hello'
    assert normalize_repr('hello at 0x12345678901') == 'hello'
    assert normalize_repr('hello at 0x12345678901234') == 'hello'
    assert normalize_repr('hello at 0x123456789012345') == 'hello'
    assert normalize

# Generated at 2022-06-22 18:32:47.779192
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(u'סטרינג', max_length=100) == u'סטרינג'
    assert get_shortish_repr(u'סטרינג', max_length=6) == u'סטרינ...'
    assert get_shortish_repr(u'סטרינג', max_length=5) == u'סטר...'
    assert get_shortish_repr('abcdef', max_length=6) == 'abcdef'
    assert get_shortish_repr('abcdef', max_length=5) == 'ab...'
    assert get_shortish_repr('abcdef', max_length=4) == '...'
    assert get

# Generated at 2022-06-22 18:32:53.376234
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('asdf') == 'asdf'
    assert shitcode('asdf\n') == 'asdf\n'
    assert shitcode('asdf\r\n') == 'asdf\r\n'
    assert shitcode('asdf') == shitcode(b'asdf')
    assert shitcode('asdf') == shitcode('asdf'.encode('utf-8'))
    assert shitcode('asdf') == shitcode('asdf'.encode('utf-16'))
    assert shitcode('asdf') == shitcode('asdf'.encode('utf-32'))
    assert shitcode('asdf') == shitcode('asdf'.encode('latin1'))
    assert shitcode('₪') == shitcode('₪'.encode('utf-8'))

# Generated at 2022-06-22 18:32:57.340742
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)



# Generated at 2022-06-22 18:33:09.262850
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(None, (lambda x: x is None, lambda x: '!')) is (
        lambda x: '!')
    assert get_repr_function(None, (lambda x: False, lambda x: '!')) is repr
    assert get_repr_function(1, ((lambda x: x is 1, lambda x: 'one'))) is (
        lambda x: 'one')
    assert get_repr_function(1, ((lambda x: False, lambda x: 'one'))) is repr
    assert get_repr_function(1, ((lambda x: False, lambda x: 'one'),
                                 (lambda x: True, lambda x: 'two'))) is (
                                 lambda x: 'two')
    assert get_repr_

# Generated at 2022-06-22 18:33:15.146517
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyStream:
        def write(self, s):
            self.s = s
    
    dummy_stream = DummyStream()
    
    assert issubclass(DummyStream, WritableStream)
    
    dummy_stream.write('hey')
    assert dummy_stream.s == 'hey'
    
    dummy_stream.write('ho')
    assert dummy_stream.s == 'ho'

# Generated at 2022-06-22 18:33:20.198455
# Unit test for function shitcode
def test_shitcode():
    message = ('testing if shitcode works correctly')
    if sys.version_info < (3,):
        string = '\xdd\xdd\xdd\xdd'
        expected = '????'
    else:
        string = '\xdd\xdd\xdd\xdd'.encode('iso8859-1')
        expected = '????'
    assert shitcode(
        string
    ) == expected, message




# Generated at 2022-06-22 18:33:31.397373
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'z') == u'z'
    assert shitcode(u'é') == u'?'
    assert shitcode(u'\u1234') == u'?'
    assert shitcode(u'\u1234' + u'z') == u'?z'
    assert shitcode(u'\u1234' + u'é') == u'??'
    assert shitcode(u'\u1234' + u'\u1234') == u'??'
    assert shitcode('z') == u'z'
    assert shitcode('\xc3\xa9') == u'?'
    assert shitcode('\xe1\x88\xb4') == u'?'
    assert shitcode('\xe1\x88\xb4' + 'z') == u'?z'

# Generated at 2022-06-22 18:33:36.300624
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(()) == ()
    assert ensure_tuple([]) == ()
    assert ensure_tuple(42) == (42,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)



# Generated at 2022-06-22 18:33:44.631103
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('abcde') == 'abcde'
    assert shitcode('abcde\xff') == 'abcde?'
    assert shitcode('abcde\xff') == 'abcde?'
    assert shitcode('abcde\x00') == 'abcde?'
    assert shitcode('abcde\x00\xff') == 'abcde??'
    assert shitcode('abcde\xff\x00') == 'abcde??'
    assert shitcode('\xff') == '?'
    assert shitcode('\xff\x00') == '??'
    assert shitcode('\x00\xff') == '??'
    assert shitcode('\x00') == '?'



# Generated at 2022-06-22 18:33:48.098046
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('None') == 'None'
    assert normalize_repr('None at 0x12345') == 'None'




# Generated at 2022-06-22 18:33:59.278705
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class ExampleWritableStream(WritableStream):
        def __init__(self):
            self.written_strings = []
        def write(self, s):
            self.written_strings.append(s)
    # should accept method write
    assert issubclass(ExampleWritableStream, WritableStream)
    # should accept method write with object instance
    WritableStream.register(ExampleWritableStream)
    assert issubclass(ExampleWritableStream, WritableStream)
    if sys.version_info[:2] == (2, 6):
        # should not accept method write with None as default
        class ExampleWritableStream2(ExampleWritableStream):
            def write(self, s=None):
                pass
        assert not issubclass(ExampleWritableStream2, WritableStream)
        # should not accept method write with no args

# Generated at 2022-06-22 18:34:04.185705
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class Cat(object):
        def __repr__(self):
            return 'a' * 100
    assert get_shortish_repr(Cat(), max_length=50) == 'a' * 50 + '...' + 'a' * 50


if __name__ == '__main__':
    test_get_shortish_repr()

# Generated at 2022-06-22 18:34:14.697823
# Unit test for function shitcode
def test_shitcode():
    # If you're unlucky enough to get an invalid UTF-8 character in a
    # string in python 2, then the unicode string will contain a literal
    # \xFF character.  This will break the write() method of file objects
    # because the encoded string will be cut off at the invalid byte
    # sequence, and the write will fail with a UnicodeEncodeError instead
    # of succeeding after replacing the byte 0xFF with a question mark.

    line = '\n'.join((
        b'\xff'.decode('utf8'),
        b'\x00'.decode('utf8'),
        b'xxx',
        b'\xfe\xff'.decode('utf8'),
        b'\xff\xfe'.decode('utf8'),
        b'\xff\xff'.decode('utf8'),
    ))


# Generated at 2022-06-22 18:34:20.943862
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', 20) == '1234567890'
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('1234567890', 9) == '1234567890'
    assert truncate('1234567890', 8) == '12345...'
    assert truncate('1234567890', 0) == ''

# Generated at 2022-06-22 18:34:27.787059
# Unit test for function get_repr_function
def test_get_repr_function():
    default_repr = '{!r}'.format
    class Thing:
        pass
    other_thing = type('Thing', (object,), {})

    custom_repr = (
        (lambda x: isinstance(x, Thing),
         lambda x: 'the Thing'),
        (other_thing,
         lambda x: 'other_thing'),
    )

    a = Thing()
    assert get_repr_function(a, custom_repr) == custom_repr[0][1]
    assert get_repr_function(other_thing(), custom_repr) == custom_repr[1][1]
    assert get_repr_function(2, custom_repr) == default_repr
    assert get_repr_function('hello', custom_repr) == default_repr


    # Test

# Generated at 2022-06-22 18:34:36.648912
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((i + 2 for i in (1, 2, 3))) == (3, 4, 5)
    assert ensure_tuple(set('meow')) == ('e', 'm', 'o', 'w')

# Generated at 2022-06-22 18:34:47.113872
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("<thingy at 0x7f6bc0f6a410>") == "<thingy>"
    assert normalize_repr("<thingy at 0xBEEF>") == "<thingy>"
    assert normalize_repr("<thingy at 0xbeef>") == "<thingy>"
    assert normalize_repr("<thingy at 0x7f6bc0f6a410>") == "<thingy>"
    assert normalize_repr("<thingy at 0xBEEF>") == "<thingy>"
    assert normalize_repr("<thingy at 0xbeef>") == "<thingy>"
    assert normalize_repr("<thingy at 0x7FAFFCD09550>") == "<thingy>"

# Generated at 2022-06-22 18:34:51.876561
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamTester(WritableStream):
        def write(self, s):
            pass

    assert issubclass(WritableStreamTester, WritableStream)

    class NotWritableStreamTester(object):
        pass

    assert not issubclass(NotWritableStreamTester, WritableStream)

# Generated at 2022-06-22 18:34:53.634247
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('my_str at 0x12345678') == 'my_str'


# Generated at 2022-06-22 18:35:01.313912
# Unit test for function normalize_repr
def test_normalize_repr():
    # assert isinstance(normalize_repr, (staticmethod, classmethod))
    assert normalize_repr('') == ''
    assert normalize_repr(' ') == ' '
    assert normalize_repr('  ') == '  '
    assert normalize_repr('   ') == '   '
    assert normalize_repr('    ') == '    '
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello ') == 'hello '
    assert normalize_repr(' hello') == ' hello'
    assert normalize_repr(' hello ') == ' hello '
    assert normalize_repr('hello world') == 'hello world'
    assert normalize_repr('hello worldokay') == 'hello worldokay'
    assert normalize

# Generated at 2022-06-22 18:35:04.840170
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)

# Generated at 2022-06-22 18:35:09.422638
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple((5, 6)) == (5, 6)
    assert ensure_tuple([5, 6]) == (5, 6)
    assert ensure_tuple({5, 6}) == (5, 6)



# Generated at 2022-06-22 18:35:20.047981
# Unit test for function truncate
def test_truncate():
    assert truncate('', max_length=5) == ''
    assert truncate('hello', max_length=5) == 'hello'
    assert truncate('hello', max_length=5) == 'hello'
    assert truncate('hello', max_length=4) == 'he...'
    assert truncate('hello', max_length=3) == 'h...'
    assert truncate('hello', max_length=2) == 'h...'
    assert truncate('hello', max_length=1) == 'h...'
    assert truncate('hello', max_length=0) == 'h...'
    assert truncate('hello', max_length=None) == 'hello'
    assert truncate('hell', max_length=4) == 'hell'

# Generated at 2022-06-22 18:35:28.471227
# Unit test for function get_repr_function
def test_get_repr_function():
    from types import FunctionType
    from types import GeneratorType
    from types import ModuleType
    from types import TypeType

    assert get_repr_function(3, custom_repr=[]) == repr

    # Checking default types:

    assert get_repr_function(3, custom_repr=[(str, list)]) == repr
    assert get_repr_function('', custom_repr=[(str, list)]) == list

    assert get_repr_function(3, custom_repr=[(int, list)]) == list
    assert get_repr_function(3.3, custom_repr=[(int, list)]) == repr

    assert get_repr_function(3, custom_repr=[(FunctionType, list)]) == list

# Generated at 2022-06-22 18:35:33.111611
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('cool') == 'cool'
    assert normalize_repr('cool at 0x123') == 'cool'
    assert normalize_repr('cool at 0xCOOL') == 'cool'
    assert normalize_repr('cool at 0xC00L') == 'cool'
    assert normalize_repr('cool at 0xC00L at 0xBEEF') == 'cool at 0xBEEF'

# Generated at 2022-06-22 18:35:37.274269
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode(u'hello') == 'hello'
    assert shitcode(b'hello') == 'hello'
    assert shitcode(b'hello\x00') == 'hello\x00'
    assert shitcode(u'h\u1234') == 'h?'

# Generated at 2022-06-22 18:35:47.741467
# Unit test for function normalize_repr
def test_normalize_repr():
    from .test_tools import assert_equal, assert_not_equal
    assert_equal(normalize_repr('x'), 'x')
    assert_equal(normalize_repr('x at 0x123'), 'x')
    assert_equal(normalize_repr('x at 0xasdf'), 'x at 0xasdf')
    assert_equal(normalize_repr('x at 0x123455'), 'x')
    assert_equal(normalize_repr('x at 0x123455678'), 'x')
    assert_equal(normalize_repr('x at 0x12345678'), 'x at 0x12345678')
    assert_equal(normalize_repr('x at 0x123456789'), 'x')

# Generated at 2022-06-22 18:35:52.152851
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'hello\r\nworld\r\n') == u'hello\r\nworld\r\n'
    if sys.maxunicode >= 0x10ffff:
        assert shitcode(u'\U0001f60a') == '?'