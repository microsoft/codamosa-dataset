

# Generated at 2022-06-22 18:26:00.552232
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class T:
        pass

    t = T()

    assert get_shortish_repr(t, max_length = None) == 'test_get_shortish_repr.<locals>.T object at ' \
                                                     '0x000001B1F7A39128'
    assert get_shortish_repr(t, max_length = 10) == 'test_g...t 0x000001B1F7A39128'
    assert get_shortish_repr(t, max_length = 20) == 'test_get_shortish_...128'
    assert get_shortish_repr(t, max_length = 20, normalize=True) == 'test_get_shortish_...'



# Generated at 2022-06-22 18:26:04.631493
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) is repr
    assert get_repr_function(0, ((int, lambda x: 'foo!'),)) == 'foo!'
    assert get_repr_function('', ((str, lambda x: 'foo!'),)) == 'foo!'
    assert get_repr_function([], ((str, lambda x: 'foo!'),)) is repr

# Generated at 2022-06-22 18:26:07.594904
# Unit test for function shitcode
def test_shitcode():
    for number in range(256):
        assert shitcode(chr(number)) == chr(number)
    assert shitcode('רחום') == '????????'
    assert shitcode('Hello world!') == 'Hello world!'

# Generated at 2022-06-22 18:26:17.616710
# Unit test for function shitcode

# Generated at 2022-06-22 18:26:21.512839
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hello', custom_repr=((str, lambda x: x[::-1]),)) \
                                                                     == 'olleh'
    assert get_repr_function([1, 2, 3], custom_repr=((list, lambda x: x[::-1]))) \
                                                                          == [3, 2, 1]
    assert get_repr_function(1, custom_repr=((list, lambda x: x[::-1]))) == 1
    assert get_repr_function(1, custom_repr=((list, lambda x: x[::-1]),)) == repr

# Generated at 2022-06-22 18:26:31.719762
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import threading
    import queue
    import time

    class TestWritableStream(WritableStream):
        def write(self, s):
            time.sleep(1)

    class ThreadMethodCalls(threading.Thread):
        def __init__(self, writable_stream, *args, **kwargs):
            threading.Thread.__init__(self, *args, **kwargs)
            self.writable_stream = writable_stream
            self.return_values = queue.Queue()

        def run(self):
            self.return_values.put(self.writable_stream.write('a'))
            self.return_values.put(self.writable_stream.write('s'))
            self.return_values.put(self.writable_stream.write('d'))

    writable_stream

# Generated at 2022-06-22 18:26:43.277993
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(NotImplemented) == 'NotImplemented'
    assert get_shortish_repr(Ellipsis) == 'Ellipsis'
    assert get_shortish_repr(False) == 'False'
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr(5.5) == '5.5'
    assert get_shortish_repr(1 + 2j) == '(1+2j)'
    assert get_shortish_repr('Hello world') == "'Hello world'"
    assert get_shortish_repr({'a': 5}) == "{'a': 5}"
   

# Generated at 2022-06-22 18:26:48.607477
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('a\x00b') == 'a?b'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode('a\x00b\x00c\x00d') == 'a?b?c?d'
    assert shitcode('¡') == '¡'
    assert shitcode('©') == '©'

# Generated at 2022-06-22 18:26:54.156798
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import types

    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=20) == '1'
    assert get_shortish_repr(1, max_length=20) == get_shortish_repr(1, max_length=40)
    assert get_shortish_repr((1, 2), max_length=20) == '(1, 2)'
    assert get_shortish_repr((1, 2), max_length=8) == '...(...'
    assert get_shortish_repr((1, 2, 3), max_length=8) == '...(...'
    assert get_shortish_repr((1, 2, 3, 4), max_length=8) == '...(...'
    assert get_short

# Generated at 2022-06-22 18:26:58.440120
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('a b c') == 'a b c'
    assert normalize_repr('a b c at 0xFF00') == 'a b c'
    assert normalize_repr('a b c at 0xFF00 at 0xFF0F') == 'a b c'



# Generated at 2022-06-22 18:27:00.622360
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((3, 4)) == (3, 4)



# Generated at 2022-06-22 18:27:12.101511
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('baba\nmama\rpapa') == 'baba mama papa'
    assert get_shortish_repr('ba', max_length=5) == 'ba'
    assert get_shortish_repr('baba', max_length=5) == 'baba'
    assert get_shortish_repr('bababa', max_length=5) == 'baba...a'
    assert get_shortish_repr('bababa', max_length=4) == 'ba...'
    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr(5, max_length=3) == '5'
    assert get_shortish_repr(None) == 'None'

# Generated at 2022-06-22 18:27:19.116682
# Unit test for function ensure_tuple
def test_ensure_tuple():
    class DummyIterable(object):
        def __init__(self, data):
            self.data = data
        def __iter__(self):
            return iter(self.data)

    for iterable in [[1, 2, 3], (1, 2, 3), {1, 2, 3}, 'abc', DummyIterable([1, 2, 3])]:
        assert ensure_tuple(iterable) == tuple(iterable)

    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(None) == (None,)



# Generated at 2022-06-22 18:27:24.293224
# Unit test for function normalize_repr
def test_normalize_repr():

    class Foo(): pass
    assert normalize_repr(repr(Foo())) == '<__main__.Foo instance>'
    assert normalize_repr(repr(1)) == '1'
    assert normalize_repr(repr((1,))) == '(1,)'
    assert normalize_repr(repr(())) == '()'
    assert normalize_repr(repr([1])) == '[1]'

# Generated at 2022-06-22 18:27:31.709826
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from collections import namedtuple
    from . import test_tools
    from . import test_helpers
    
    assert get_shortish_repr(5) == '5'
    assert get_shortish_repr(5, max_length=2) == '5'
    assert get_shortish_repr(5, max_length=1) == '5'
    assert get_shortish_repr(5, max_length=0) == '...'
    assert get_shortish_repr('hello', max_length=3) == 'hel...'
    assert get_shortish_repr('hello', max_length=4) == 'hell...'
    assert get_shortish_repr('hello', max_length=5) == 'hello'

# Generated at 2022-06-22 18:27:38.422156
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(
        "repr_test_module.MockReprClass at 0x7f9c7f9e6090>"
    ) == "repr_test_module.MockReprClass>"
    assert normalize_repr(
        "repr_test_module.MockReprClass at 0xdeadbeef"
    ) == "repr_test_module.MockReprClass>"
    assert normalize_repr(
        "repr_test_module.MockReprClass at 0x12345678"
    ) == "repr_test_module.MockReprClass>"

# Generated at 2022-06-22 18:27:45.984643
# Unit test for function normalize_repr
def test_normalize_repr():
    from .third_party import hypothesis

# Generated at 2022-06-22 18:27:49.435908
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Entity(object):
        def write(self, s): pass

    stream = Entity()
    assert isinstance(stream, WritableStream) == True



# Generated at 2022-06-22 18:27:52.152288
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-22 18:28:01.312141
# Unit test for function shitcode
def test_shitcode():
    for ascii_char in map(chr, list(range(256))):
        assert shitcode(ascii_char) == ascii_char

    assert shitcode('\x7f') == '?'
    assert shitcode('\xff') == '?'

    assert shitcode('\x00') == '\x00'
    assert shitcode('\x01') == '\x01'
    assert shitcode('\x02') == '\x02'
    assert shitcode('\x03') == '\x03'

    assert shitcode('☺') == '?'

    assert shitcode(u'☺') == '?'
    assert shitcode(u'☺') == shitcode(u'☺'.encode(sys.getdefaultencoding(), 'ignore'))
    assert shitcode(u'☺')

# Generated at 2022-06-22 18:28:05.718666
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<GoodObject object at 0x7fdbf07dca90>') == \
                                                       '<GoodObject object>'
    assert normalize_repr(
        '<GoodObject object at 0x7fdbf07dca90> <BadObject object at 0x1f38a30>'
    ) == '<GoodObject object> <BadObject object>'



# Generated at 2022-06-22 18:28:11.391615
# Unit test for function normalize_repr
def test_normalize_repr():
    class MyClass(object): pass
    my_class = MyClass()
    assert normalize_repr(repr(my_class)) == '<__main__.MyClass object at 0x{}>'.format(hex(id(my_class))[2:])
    assert normalize_repr(repr(my_class)) != '<__main__.MyClass object at 0x{}>'.format(hex(id(my_class))[3:])

# Generated at 2022-06-22 18:28:19.483784
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, []) == repr
    assert get_repr_function(5, [(lambda x: x == 5, lambda x: '*')]) == '*'
    assert get_repr_function(6, [(lambda x: x == 5, lambda x: '*')]) == repr
    assert get_repr_function(6, [(int, lambda x: '*')]) == '*'
    assert get_repr_function(6.0, [(int, lambda x: '*')]) == repr

# Generated at 2022-06-22 18:28:28.749975
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('hello') == 'hello'
    assert shitcode('\xff') == '\xff'
    assert shitcode('\xff\x25\x77\x00\x08') == '\xff%w\x00\x08'
    assert shitcode(u'\U0001f4a9') == '?'
    assert shitcode(u'\u00FF') == '\xFF'
    assert shitcode(u'\U0001F4A9') == '?'
    assert shitcode(u'\uFEFF') == '\xFF'
    assert shitcode(u'\u20AC') == '?'
    assert shitcode(u'\u20AC\u00a2') == '?\xa2'

# Generated at 2022-06-22 18:28:33.624651
# Unit test for function shitcode
def test_shitcode():
    
    s = 'אבגדהוזחטיכלמנסעפצק'
    assert shitcode(s) == '??????????????'

    s = 'abc123$'
    assert shitcode(s) == s

    # `shitcode` should accept only strings:
    assert shitcode(42) == '?'

# Generated at 2022-06-22 18:28:36.741457
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class SomeClass(object):
        pass

    assert not isinstance(SomeClass(), WritableStream)

    class SomeClassWithWriteMethod(object):
        def write(self):
            pass

    assert isinstance(SomeClassWithWriteMethod(), WritableStream)

# Generated at 2022-06-22 18:28:48.012038
# Unit test for function truncate
def test_truncate():
    assert truncate('abcde', None) == 'abcde'
    assert truncate('abcde', 10) == 'abcde'
    assert truncate('abcde', 0) == 'abcde'
    assert truncate('abcde', 4) == 'abc...'
    assert truncate('abcde', 3) == 'abc...'
    assert truncate('abcde', 2) == 'a...'
    assert truncate('abcde', 1) == 'a...'
    assert truncate('abcde', 2, right_side_first=True) == '...e'
    assert truncate('abcde', 1, right_side_first=True) == '...e'
    assert truncate('abcde', 0, right_side_first=True) == 'abcde'

# Generated at 2022-06-22 18:28:54.507964
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'האם תרומות ייצאו') == u'???? ??? ?????? ???'
    assert shitcode(b'\x00\x01\x00\xff\x00\x03\x00\x01\x00\x02') == \
                                                              '??\x00?\x00??\x00?'



# Generated at 2022-06-22 18:29:02.609609
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = [
        ((lambda x: x == 'a'), lambda x: 'b'),
        (list, repr),
    ]
    assert get_repr_function('a', custom_repr)() == 'b'
    assert get_repr_function([1, 2], custom_repr)() == '[1, 2]'
    assert get_repr_function(1, custom_repr)() == '1'
    assert get_repr_function(None, custom_repr)() == 'None'
    assert get_repr_function(True, custom_repr)() == 'True'
    assert get_repr_function(4.5, custom_repr)() == '4.5'
    assert get_repr_function(set, custom_repr)() == 'set'

# Generated at 2022-06-22 18:29:11.927070
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)

    class B(A):
        pass
    assert issubclass(B, WritableStream)

    class C(WritableStream):
        pass
    assert not issubclass(C, WritableStream)

    class D(C):
        def write(self, s):
            pass
    assert issubclass(D, WritableStream)

    class E(D):
        def write(self, s):
            pass
    assert issubclass(E, WritableStream)

    class F(E):
        pass
    assert issubclass(F, WritableStream)

    class G(F):
        pass
    assert issubclass(G, WritableStream)


# Generated at 2022-06-22 18:29:14.768545
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    with open(__file__, 'rb') as f:
        assert isinstance(f, WritableStream)
        f.write(b'abc123')
        f.close()


# Generated at 2022-06-22 18:29:17.960976
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple((5, 6)) == (5, 6)
    assert ensure_tuple(set((5, 6))) == (5, 6)

# Generated at 2022-06-22 18:29:22.334621
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import io

    class FileLikeObject(WritableStream):
        def write(self, s):
            print(s)

    def test(arg):
        assert issubclass(arg, WritableStream)

    test(io.StringIO)
    test(io.BytesIO)
    test(FileLikeObject)

# Generated at 2022-06-22 18:29:28.692829
# Unit test for function truncate
def test_truncate():
    assert truncate('Hello, world!', 13) == 'Hello, world!'
    assert truncate('Hello, world!', 12) == 'Hello, w...'
    assert truncate('Hello, world!', 11) == 'Hello, w...'
    assert truncate('Hello, world!', 10) == 'Hello, w...'
    assert truncate('Hello, world!', 9) == 'Hello,...'
    assert truncate('Hello, world!', 8) == 'Hello,...'
    assert truncate('Hello, world!', 7) == 'Hell...'
    assert truncate('Hello, world!', 6) == 'Hell...'
    assert truncate('Hello, world!', 5) == 'He...'
    assert truncate('Hello, world!', 4) == 'He...'
    assert truncate('Hello, world!', 3)

# Generated at 2022-06-22 18:29:37.801074
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=6) == '1'

    assert get_shortish_repr(11, max_length=1) == '...'

# Generated at 2022-06-22 18:29:49.100550
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)

    assert ensure_tuple(()) == ()
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)

    assert ensure_tuple(range(0)) == ()
    assert ensure_tuple(range(1)) == (0,)
    assert ensure_tuple(range(2)) == (0, 1)

# Generated at 2022-06-22 18:29:57.801247
# Unit test for function normalize_repr
def test_normalize_repr():
    class x: pass

    assert normalize_repr(repr(x())) == '<tests.stdlib_patch.test_normalize_repr.<locals>.x object at 0x000001B657F61470>'

    class y(x): pass

    assert normalize_repr(repr(y())) == '<tests.stdlib_patch.test_normalize_repr.<locals>.y object at 0x000001B657F61940>'

    class z(x): pass

    assert normalize_repr(repr(z())) == '<tests.stdlib_patch.test_normalize_repr.<locals>.z object at 0x000001B657F61EB0>'

    assert normalize_repr(repr(None)) == 'None'

    assert normalize_repr

# Generated at 2022-06-22 18:30:02.467433
# Unit test for function shitcode
def test_shitcode():
    '''
    This unit test currently tests that shitcode is doing the right thing in
    Python 2. In Python 3 this function should always return the normal string
    and not do anything weird.
    '''
    s = 'abc'
    assert shitcode(s) == 'abc'

    s = u'abc'
    assert shitcode(s) == 'abc'

    s = u'abc\xab'
    assert shitcode(s) == shitcode(s.encode('cp1255'))

    s = (u'abc\xab' + u'\u1234').encode('utf-16')
    assert shitcode(s) == shitcode(s.decode('utf-16'))



# Generated at 2022-06-22 18:30:09.241838
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(b'abc') == 'abc'
    assert shitcode(b'abc\xff') == 'abc?'
    assert shitcode(u'abc') == 'abc'
    assert shitcode(u'abc\uffff') == 'abc?'
    assert shitcode(u'abc\uffff\u1234') == 'abc??'
    assert shitcode(u'\u1234') == '?'




# Generated at 2022-06-22 18:30:15.050484
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert not issubclass(object, WritableStream)
    assert issubclass(Test1, WritableStream)
    assert issubclass(Test2, WritableStream)
    assert issubclass(Test3, WritableStream)
    assert not issubclass(Test4, WritableStream)



# Generated at 2022-06-22 18:30:23.227297
# Unit test for function truncate
def test_truncate():
    assert truncate('12345', None) == '12345'
    assert truncate('12345', 10) == '12345'
    assert truncate('123456', 5) == '123...6'
    assert truncate('123', 5) == '123'
    assert truncate('1234567', 5) == '12...7'
    assert truncate('12345', 5) == '12345'
    assert truncate('123456', 4) == '123...'
    assert truncate('123', 4) == '123'
    assert truncate('1234567', 4) == '12...'
    assert truncate('12345', 4) == '12345'



# Generated at 2022-06-22 18:30:34.714339
# Unit test for function get_repr_function
def test_get_repr_function():

    def f1(x):
        return 'f1' + repr(x)

    def f2(x):
        return 'f2' + repr(x)

    assert 'f1' in get_repr_function(1, ((int, f1),))(1)
    assert 'f2' in get_repr_function(1, ((float, f2),))(1)
    assert 'f2' in get_repr_function(1.0, ((float, f2),))(1)
    assert 'f2' in get_repr_function(1.0, ((lambda x: True, f2),))(1)
    assert normalize_repr(repr(1)) == normalize_repr(get_repr_function(1, ())(1))



# Generated at 2022-06-22 18:30:36.192432
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("hello world") == "hello world"


# Generated at 2022-06-22 18:30:42.736801
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello', max_length=3) == 'hel'
    assert get_shortish_repr('hello', max_length=100) == 'hello'
    assert get_shortish_repr('hello', max_length=None) == 'hello'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=100) == '1'



# Generated at 2022-06-22 18:30:46.913347
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('אבגד') == '???'
    assert shitcode('abcd') == 'abcd'



# Generated at 2022-06-22 18:30:48.861007
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(None) == (None,)

# Generated at 2022-06-22 18:30:56.457203
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('bla') == 'bla'
    assert normalize_repr('bla at 0x12345') == 'bla'
    assert normalize_repr('bla at 0x12345 at 0x6789') == 'bla at 0x6789'
    assert normalize_repr('bla at 0x123456789ABC') == 'bla'



# Generated at 2022-06-22 18:31:01.254292
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class Foo(WritableStream):

        def __init__(self, data=None):
            self.data = data or []

        def write(self, s):
            self.data.append(s)

    foo = Foo()
    foo.write('thing1')
    foo.write('thing2')

    assert foo.data == ['thing1', 'thing2']

    sys.stdout.write('hi')
    assert sys.stdout.data == ['hi']

# Generated at 2022-06-22 18:31:08.898123
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('') == ''
    assert normalize_repr('hi') == 'hi'
    assert normalize_repr('hi at 0x12345') == 'hi '
    assert normalize_repr('at 0x12345') == ' '
    assert normalize_repr('hi at 0x12345 ') == 'hi  '
    assert normalize_repr('hi at 0x12345 at 0x12346') == 'hi   '



# Generated at 2022-06-22 18:31:14.157448
# Unit test for function ensure_tuple
def test_ensure_tuple():
    # A tuple should stay a tuple
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)

    # A list should become a tuple
    assert ensure_tuple([1, 2]) == (1, 2)

    # A string should become a tuple
    assert ensure_tuple('hello') == ('hello',)

    # A number should become a tuple
    assert ensure_tuple(1) == (1,)



# Generated at 2022-06-22 18:31:19.093063
# Unit test for function truncate
def test_truncate():
    assert truncate('abcde', None) == 'abcde'
    assert truncate('abcde', 5) == 'abcde'
    assert truncate('abcde', 3) == 'abcde'
    assert truncate('abcde', 2) == '...'
    assert truncate('abcde', 6) == 'abcde'
    assert truncate('abcde', 7) == 'abcde'





# Generated at 2022-06-22 18:31:24.605458
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Stream(WritableStream):
        def write(self, s): pass
    stream = Stream()
    assert isinstance(stream, WritableStream)


    class Stream2(WritableStream):
        pass
    stream2 = Stream2()
    assert not isinstance(stream2, WritableStream)



# Generated at 2022-06-22 18:31:29.595850
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    def write_subclass(output):
        class A(object):
            def write(self, s):
                output.write(s)
        return A()
    class B(object):
        pass
    assert isinstance(write_subclass(sys.stdout), WritableStream)
    assert not isinstance(B(), WritableStream)
    assert not isinstance(object(), WritableStream)

# Generated at 2022-06-22 18:31:34.491074
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((4, 5)) == (4, 5)
    assert ensure_tuple([6, 7]) == (6, 7)
    assert ensure_tuple([8]) == (8,)
    assert ensure_tuple([]) == tuple()
    assert ensure_tuple('abc') == ('abc',)



# Generated at 2022-06-22 18:31:41.752033
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', None) == '123456789'
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 8) == '12345...'
    assert truncate('123456789', 7) == '1234...'
    assert truncate('123456789', 6) == '123...'
    assert truncate('123456789', 5) == '12...'
    assert truncate('123456789', 4) == '1...'
    assert truncate('123456789', 3) == '...'
    assert truncate('123456789', 2) == '..'
    assert truncate('123456789', 1) == '.'
    assert truncate('123456789', 0) == '.'

   

# Generated at 2022-06-22 18:31:52.441587
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abc', max_length=2) == "'a'"
    assert get_shortish_repr('abc', max_length=3) == "'ab'"
    assert get_shortish_repr('abc', max_length=4) == "'ab'"
    assert get_shortish_repr('abc', max_length=5) == "'ab'"
    assert get_shortish_repr('abc', max_length=6) == "'abc'"
    assert get_shortish_repr(12345) == '12345'
    assert get_shortish_repr(12345, max_length=2) == "12"
    assert get_shortish_repr(12345, max_length=3) == "123"


# Generated at 2022-06-22 18:32:01.859691
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Base(WritableStream):
        def write(self, s): pass
    def dec(cls):
        class N(cls):
            def write(self, s): pass
        return N
    def cls(decorated):
        class C(WritableStream):
            def write(self, s): pass
            @decorated
            def write2(self, s): pass
        return C
    assert issubclass(Base, WritableStream)
    assert issubclass(dec(Base), WritableStream)
    assert issubclass(cls(abc.abstractmethod), WritableStream)
    assert not issubclass(int, WritableStream)
    assert not issubclass(type(None), WritableStream)



# Generated at 2022-06-22 18:32:08.961797
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class Parent(object):
        def __repr__(self):
            return 'parent'
    class Child(Parent):
        def __repr__(self):
            return 'child'
    child = Child()
    for x, y in ((2, '[1, 2, 3]'), (Child, 'child'), (child, 'child')):
        assert get_shortish_repr(x, max_length=5) == y

# Generated at 2022-06-22 18:32:12.993166
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'

    assert shitcode('abc\x00def') == 'abc\x00def'

    assert shitcode('abc\xFFdef') == 'abc?def'

    assert shitcode('abc\x00def\xFFghi') == 'abc\x00def?ghi'

    # Do a bunch of random tests with random data:
    from .random_tools import random_bytes
    for i in range(100):
        assert shitcode(random_bytes(100))

# Generated at 2022-06-22 18:32:16.516646
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(metaclass=ABC):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

# Generated at 2022-06-22 18:32:20.199896
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x253523') == 'hello'
    assert normalize_repr('hello at 0x253523, world') == 'hello at 0x253523, world'



# Generated at 2022-06-22 18:32:25.754162
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdef', 5) == 'abcde'
    assert truncate('abcdef', 6) == 'abcdef'
    assert truncate('abcdef', 7) == 'abcdef'
    assert truncate('a...f', 7) == 'a...f'
    assert truncate('a...f', 8) == 'a...f'
    assert truncate('abcdef', None) == 'abcdef'



# Generated at 2022-06-22 18:32:27.749379
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class DummyStream(WritableStream):
        def write(self, s):
            pass

    DummyStream() # Checking this doesn't fail

# Generated at 2022-06-22 18:32:39.223983
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, ()) == repr
    assert get_repr_function(False, ()) == repr
    assert get_repr_function('abc', ()) == repr
    assert get_repr_function((1, 2, 3), ()) == repr
    assert get_repr_function([1, 2, 3], ()) == repr
    assert get_repr_function(set([1, 2, 3]), ()) == repr
    assert get_repr_function({'a': 1, 'b': 2}, ()) == repr

    assert get_repr_function(0, ((1, lambda: '0'))) == repr
    assert get_repr_function(False, ((1, lambda: '0'))) == repr
    assert get_repr_function('abc', ((1, lambda: '0'))) == repr
    assert get

# Generated at 2022-06-22 18:32:48.204088
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1, [
        (int, str),
        (float, repr),
    ]) == str
    assert get_repr_function(1.0, [
        (int, str),
        (float, repr),
    ]) == repr
    assert get_repr_function(1, [(lambda x: x > 0, str)]) == str
    assert get_repr_function(1, [(lambda x: x > 2, str)]) == repr

    assert get_repr_function(1, [(None, str)]) == str


    def my_repr(x):
        if x > 2:
            return 'hi'

# Generated at 2022-06-22 18:32:52.510852
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(123) == (123,)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(object()) == (object(),)
    assert ensure_tuple([]) == ([],)
    assert ensure_tuple(()) == ((),)
    assert ensure_tuple({}) == ({},)
    assert ensure_tuple(set()) == (set(),)



# Generated at 2022-06-22 18:32:57.124068
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    assert issubclass(io.StringIO, WritableStream)
    assert issubclass(io.BytesIO, WritableStream)
    assert issubclass(sys.stdout.__class__, WritableStream)
    assert not issubclass(object, WritableStream)


if __name__ == '__main__':

    test_WritableStream_write()

# Generated at 2022-06-22 18:32:58.872344
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(b'\x80') == b'?'
    assert shitcode('a\x80') == 'a?'



# Generated at 2022-06-22 18:33:06.928249
# Unit test for function truncate
def test_truncate():
    assert truncate('01234', None) == '01234'
    assert truncate('01234', 5) == '01234'
    assert truncate('01234', 3) == '012'
    assert truncate('01234', 2) == '00'
    assert truncate('01234', 1) == '0'
    assert truncate('01234', 0) == ''
    assert truncate('01234', -1) == ''



# Generated at 2022-06-22 18:33:09.755800
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class DummyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(DummyWritableStream, WritableStream)

    assert not issubclass(object, WritableStream)

# Generated at 2022-06-22 18:33:18.943965
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class X4(object):
        def __repr__(self):
            return '<X4 #4>'
    assert '<X4 #4>' == get_shortish_repr(X4())
    assert '<X4 #4>' == get_shortish_repr(X4(), max_length=6)
    assert '<X4>' == get_shortish_repr(X4(), max_length=5)
    assert '<X...>' == get_shortish_repr(X4(), max_length=7)
    assert '<X...>' == get_shortish_repr(X4(), max_length=8)

# Generated at 2022-06-22 18:33:23.145489
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello world') == 'hello world'
    assert normalize_repr('hello world at 0x12345') == 'hello world'
    assert normalize_repr('hello world at 0x12345 at 0x23456') == 'hello world'



# Generated at 2022-06-22 18:33:31.206181
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('f') == 'f'
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr('hello', max_length=10) == 'hello'
    assert get_shortish_repr('1234567890') == '1234567890'
    assert get_shortish_repr('1234567890', max_length=10) == '1234567890'
    assert get_shortish_repr('1234567890', max_length=9) == '1234567...'

# Generated at 2022-06-22 18:33:37.400343
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import io
    import codecs
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.buffer = b''
        def write(self, s):
            self.buffer += s
    my_writable_stream = MyWritableStream()
    assert isinstance(my_writable_stream, WritableStream)
    my_writable_stream.write(b'abc')
    assert my_writable_stream.buffer == b'abc'
    my_writable_stream.write(b'def')
    assert my_writable_stream.buffer == b'abcdef'

    # It works for both `io.FileIO` and `codecs.StreamWriter`:
    assert isinstance(io.FileIO(__file__, 'w'), WritableStream)

# Generated at 2022-06-22 18:33:41.015804
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(['a', 'b', 'c']) == ('a', 'b', 'c')
    assert ensure_tuple(('a', 'b', 'c')) == ('a', 'b', 'c')



# Generated at 2022-06-22 18:33:43.312716
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(['abc', 'def']) == ('abc', 'def')



# Generated at 2022-06-22 18:33:47.373280
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijkl', 9) == 'abcdefghi'
    assert truncate('abcdefghijkl', 10) == 'abcdefghij'
    assert truncate('abcdefghijkl', 11) == 'abcdefghijk'
    assert truncate('abcdefghijkl', 12) == 'abcdefghijkl'
    assert truncate('abcdefghijkl', 13) == 'abcdefghijkl'
    assert truncate('abcdefghijkl', None) == 'abcdefghijkl'



# Generated at 2022-06-22 18:33:52.472863
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from io import StringIO
    from .test_tools import get_test_stream

    _test_stream = get_test_stream()

    class TestStream(WritableStream):
        def write(self, s):
            _test_stream.write(s)

    TestStream() # doesn't raise exception is success




# Generated at 2022-06-22 18:34:03.429166
# Unit test for function get_shortish_repr

# Generated at 2022-06-22 18:34:05.177774
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'hi') == u'hi'
    assert shitcode(u'היי') == u'???'

# Generated at 2022-06-22 18:34:14.142831
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1.1, ()) is repr
    assert get_repr_function(1j, ()) is repr
    assert get_repr_function('a', ()) is repr
    assert get_repr_function(u'b', ()) is repr
    assert get_repr_function(b'c', ()) is repr
    assert get_repr_function(bytearray(b'b'), ()) is repr

    class Foo: pass
    class Bar: pass
    def a(x):
        return str(x)

    custom_repr = ((Foo, a), (1, a))
    assert get_repr_function(1, custom_repr) is a

# Generated at 2022-06-22 18:34:18.179209
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .mock import Mock

    class StreamImpl(WritableStream):
        def write(self, s):
            pass

    stream = StreamImpl()

    assert isinstance(stream, WritableStream)

    with Mock(sys, 'stdout') as mock_stdout:
        assert isinstance(mock_stdout, WritableStream)

# Generated at 2022-06-22 18:34:23.314227
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple({}) == ({},)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)

# Generated at 2022-06-22 18:34:29.388211
# Unit test for function ensure_tuple
def test_ensure_tuple():
    class Record(object):
        pass

    record1 = Record()
    record2 = Record()
    record3 = Record()

    # When you pass a single object
    assert ensure_tuple(record1) == (record1, )

    # When you pass a tuple
    assert ensure_tuple((record1, record2)) == (record1, record2)
    assert ensure_tuple((record1, (record2, record3))) == (record1, (record2,
                                                                   record3))

    # When you pass a list
    assert ensure_tuple([record1, record2]) == (record1, record2)
    assert ensure_tuple([record1, [record2, record3]]) == (record1,
                                                          [record2, record3])

    # When you pass a generator
    assert ensure

# Generated at 2022-06-22 18:34:33.348491
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('a\u203C') == 'a?'
    assert shitcode('a\u203C\u0BC0') == 'a??'

# Generated at 2022-06-22 18:34:40.933985
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'

    assert get_shortish_repr(12345, max_length=None) == '12345'
    assert get_shortish_repr(12345, max_length=5) == '12345'
    assert get_shortish_repr(12345, max_length=4) == '12345'
    assert get_shortish_repr(12345, max_length=3) == '123...5'
    assert get_shortish

# Generated at 2022-06-22 18:34:48.289266
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    def examine_WritableStream(WritableStream):
        WritableStream().write('_')

    try:
        examine_WritableStream(list)
    except AttributeError:
        pass
    else:
        raise Exception("Didn't raise `AttributeError`")
    try:
        examine_WritableStream(dict)
    except AttributeError:
        pass
    else:
        raise Exception("Didn't raise `AttributeError`")
    examine_WritableStream(sys.stdout)
    examine_WritableStream(open(__file__, 'r'))
    class MyStream(WritableStream):
        def write(self, s):
            pass
    MyStream().write('_')



# Generated at 2022-06-22 18:34:54.353607
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('Ram') == ('Ram',)
    assert ensure_tuple(('Miriam',)) == ('Miriam',)
    assert ensure_tuple(('Miriam', 'Rachum')) == ('Miriam', 'Rachum')
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple((5,)) == (5,)
    assert ensure_tuple((5, 6)) == (5, 6)

# Generated at 2022-06-22 18:35:01.371376
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(WritableStream):
        def write(self, s):
            pass
    class Y(WritableStream):
        pass
    class Z(WritableStream):
        def write(self, s):
            pass
    assert issubclass(X, WritableStream)
    assert not issubclass(Y, WritableStream)
    assert issubclass(Z, WritableStream)

# Generated at 2022-06-22 18:35:08.127511
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import sys

    class MyWritableStream(WritableStream):
        def write(self, s):
            sys.stdout.write(s)

    MyWritableStream().write('hello')

    assert (
        isinstance(sys.stdout, WritableStream)
        is True
    )
    assert (
        isinstance(io.StringIO(), WritableStream)
        is True
    )

# Generated at 2022-06-22 18:35:18.986239
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    # Test exception handling
    class A(object):
        def __repr__(self):
            raise Exception

    assert get_shortish_repr(A(), max_length=None) == 'REPR FAILED'

    class B(object):
        def __repr__(self):
            raise Exception("Something bad happened")

    assert get_shortish_repr(B(), max_length=None) == 'REPR FAILED'

    # Test custom repr
    def custom_repr(item):
        if isinstance(item, int):
            return '<int {0}>'.format(item)
        elif isinstance(item, str):
            return '<str {0}>'.format(item)
        else:
            return repr(item)


# Generated at 2022-06-22 18:35:27.778352
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, ()) == repr
    assert get_repr_function(1, ()) == repr
    assert get_repr_function('abc', ()) == repr
    assert get_repr_function(lambda x: x, ()) == repr
    assert get_repr_function([], ()) == repr

    assert get_repr_function(None, ((None, 'a'),)) == 'a'
    assert get_repr_function(1, ((None, 'a'),)) == 'a'
    assert get_repr_function('abc', ((None, 'a'),)) == 'a'
    assert get_repr_function(lambda x: x, ((None, 'a'),)) == 'a'
    assert get_repr_function([], ((None, 'a'),)) == 'a'

    assert get_re

# Generated at 2022-06-22 18:35:34.582672
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .delegation import Self
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr('abcd' * 100) == '{}'.format(('abcd' * 100)[:50])
    assert get_shortish_repr(Self) == 'Self'
    assert get_shortish_repr(Self, custom_repr=[(Self, lambda: '123')]) == '123'
    assert get_shortish_repr(Self, custom_repr=[(object, lambda: '123')]) \
                                                                       == 'Self'
    assert get_shortish_repr(Self, custom_repr=[(object, lambda: '123')],
                             max_length=3) == '12...'

# Generated at 2022-06-22 18:35:42.528451
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, []) == repr
    assert get_repr_function(1, [(lambda x: x < 5, str)]) == str
    assert get_repr_function(1, [(lambda x: x > 5, str)]) == repr
    assert get_repr_function(1, [(int, str)]) == str
    assert get_repr_function(1.0, [(int, str), (float, float.hex)]) == float.hex
    assert get_repr_function(1, [(int, float.hex)]) == float.hex
    assert get_repr_function(1, [(float, float.hex)]) == repr



# Generated at 2022-06-22 18:35:50.532432
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('hello\nworld') == 'hello\nworld'
    assert shitcode('אאאאאאאאאאאאאאאא') == '??????'
    assert shitcode('אאאאאאאאאאאאאאא') == '??????'
    assert shitcode(' \u200b\u200b') == ' ????'
    assert shitcode(str(b'\x00\xff\xee\x20\x80', 'latin1')) == '??????'
    assert shitcode(str(b'\x00\xff\xee\x20\x80', 'utf8')) == '??????'