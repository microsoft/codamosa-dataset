

# Generated at 2022-06-22 18:26:00.988016
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class WritableStreamTest(WritableStream):
        def write(self, s):
            pass

    assert issubclass(WritableStreamTest, WritableStream)

    # Test that it fails if we don't implement write()
    class BadWritableStreamTest(WritableStream):
        pass

    assert not issubclass(BadWritableStreamTest, WritableStream)


    # Test that it fails if we don't implement write()
    class SuperBadWritableStreamTest(WritableStream):
        def write(self, s):
            return super(SuperBadWritableStreamTest, self).write(s)

    assert not issubclass(SuperBadWritableStreamTest, WritableStream)


    # Test that it fails if we don't implement write()

# Generated at 2022-06-22 18:26:06.729939
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', 10) == 'hello'
    assert truncate('helloworld', 10) == 'helloworl...'
    assert truncate('helloworld', 6) == 'he...'
    assert truncate('helloworld', 2) == '...'
    assert truncate('helloworld', 1) == '...'
    assert truncate('helloworld', 0) == '...'
    assert truncate('helloworld', -1) == '...'

# Generated at 2022-06-22 18:26:10.518543
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(()) == ()
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple(1) == (1,)



# Generated at 2022-06-22 18:26:20.979866
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import io
    class A: pass
    class B(A): pass
    class C(io.TextIOBase): pass
    class D(io.StringIO): pass
    class E(B):
        def write(self, s): pass
    assert issubclass(C, WritableStream)
    assert issubclass(D, WritableStream)
    assert not issubclass(E, WritableStream)
    assert not issubclass(A, WritableStream)
    assert not issubclass(B, WritableStream)


test_WritableStream()




if sys.platform == 'darwin':
    from .darwin import \
        get_file_size_with_command, \
        get_file_size_with_python
    get_file_size = get_file_size_with_command

# Generated at 2022-06-22 18:26:28.285282
# Unit test for function normalize_repr
def test_normalize_repr():
    for object_, expected in (
        (None, 'None'),
        ('', "''"),
        (' ', "' '"),
        ('foo', "'foo'"),
        ('foo bar', "'foo bar'"),
        ('foo bar', "'foo bar'"),
        (('foo', 'bar'), "('foo', 'bar')"),
        (('foo', 'bar bar'), "('foo', 'bar bar')"),
    ):
        assert normalize_repr(repr(object_)) == normalize_repr(expected)



# Generated at 2022-06-22 18:26:31.108829
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'\u2605') == u'?'
    assert shitcode(u'\u2605ab\u2605') == u'?ab?'

# Generated at 2022-06-22 18:26:37.501728
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(['meow']) == ('meow',)
    assert ensure_tuple(('meow')) == ('meow',)
    assert ensure_tuple(('meow', 'purr')) == ('meow', 'purr')
    assert ensure_tuple(set('meow')) == ('e', 'm', 'o', 'w')



# Generated at 2022-06-22 18:26:40.901143
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)



# Generated at 2022-06-22 18:26:49.959178
# Unit test for function shitcode

# Generated at 2022-06-22 18:26:54.689460
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyClass(WritableStream):
        def __init__(self):
            self.written_stuff = ''
        def write(self, s):
            self.written_stuff += s
    x = MyClass()



# Generated at 2022-06-22 18:27:00.258434
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(1, 2) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple({1, 2}) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple('hi') == ('hi',)

# Generated at 2022-06-22 18:27:04.865336
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(()) == ()
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)



# Generated at 2022-06-22 18:27:11.078573
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class A(WritableStream):
        def write(self, s):
            assert isinstance(s, str)
            print(s)
    a = A()
    a.write('hello')

    class B:
        pass
    b = B()
    try:
        isinstance(b, WritableStream)
    except TypeError:
        pass
    else:
        raise Exception("Failed to raise TypeError.")



# Generated at 2022-06-22 18:27:21.755461
# Unit test for function truncate
def test_truncate():
    assert truncate(u'123456789', 9) == u'123456789'
    assert truncate(u'123456789', 8) == u'1234567...'
    assert truncate(u'123456789', 7) == u'1234...'
    assert truncate(u'123456789', 6) == u'123...'
    assert truncate(u'123456789', 5) == u'12...'
    assert truncate(u'123456789', 4) == u'1...'
    assert truncate(u'123456789', 3) == u'...'
    assert truncate(u'123456789', 2) == u'..'
    assert truncate(u'123456789', 1) == u'.'

# Generated at 2022-06-22 18:27:26.340826
# Unit test for function get_repr_function
def test_get_repr_function():
    def repr_foo(foo):
        return '<friendly foo>'

    custom_repr = ((lambda foo: getattr(foo, '__class__', object)
                                                             == ComposedFoo,
                    repr_foo),)
    assert get_repr_function(Foo(), custom_repr) is repr
    assert get_repr_function(ComposedFoo(), custom_repr) is repr_foo



# Generated at 2022-06-22 18:27:30.220534
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('Hi there') == 'Hi there'
    assert shitcode('Hi\u2028there') == 'Hi?there'
    assert shitcode('Hi\u1688there') == 'Hi?there'
    assert shitcode('Hi\u1701there') == 'Hi?there'
    assert shitcode('Hi\U000209e5there') == 'Hi?there'

# Generated at 2022-06-22 18:27:37.904744
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\x82\x7f') == '??'
    assert shitcode('\x7f\x82') == '??'
    assert shitcode('\x7f') == '?'
    assert shitcode('\x7f\x7f') == '??'
    assert shitcode('\x7f\x82\x7f') == '????'
    assert shitcode('\x82') == '?'
    assert shitcode('a\x82a') == 'a?a'
    assert shitcode('a\x82') == 'a?'
    assert shitcode('\x82\x7f\x82\x7f\x82\x7f\x82\x7f') == '????????'

# Generated at 2022-06-22 18:27:49.084388
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abcd') == 'abcd'
    assert shitcode('\xff') == '?'
    assert shitcode('\xf0') == '?'
    assert shitcode('\x00') == '?'

# Generated at 2022-06-22 18:27:53.155694
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([3, 4]) == (3, 4)
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple((1, 'meow')) == (1, 'meow')



# Generated at 2022-06-22 18:27:58.518598
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X(object):
        pass

    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)

    class B(object):
        def write(self, s):
            pass

    assert not issubclass(B, WritableStream)

    class C(object):
        def write(self, s):
            pass

    assert not issubclass(C, WritableStream)

    class D(WritableStream):
        pass

    assert not issubclass(D, WritableStream)

# Generated at 2022-06-22 18:28:07.696430
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    if __name__ == '__main__':
        assert get_shortish_repr('') == "''"
        assert get_shortish_repr(()) == '()'
        assert get_shortish_repr([]) == '[]'
        assert get_shortish_repr("1234567", max_length=2) == "'1...'"
        assert get_shortish_repr("1234567", max_length=3) == "'12...'"
        assert get_shortish_repr("1234567", max_length=4) == "'123...'"
        assert get_shortish_repr("1234567", max_length=5) == "'1...7'"
        assert get_shortish_repr("1234567", max_length=6) == "'12...7'"
        assert get_shortish

# Generated at 2022-06-22 18:28:09.474778
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class C:
        def write(self): pass

    assert issubclass(C, WritableStream)

# Generated at 2022-06-22 18:28:20.334517
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(r'<coin <coin <coin>>') == r'<coin <coin <coin>>>'
    assert normalize_repr(r' <coin <coin <coin>>>') == r' <coin <coin <coin>>>'
    assert normalize_repr(r'<coin <coin <coin>>>') == r'<coin <coin <coin>>>'
    assert normalize_repr(r' <coin <coin <coin>>>') == r' <coin <coin <coin>>>'
    assert normalize_repr(r' <coin <coin <coin> at 0x1234>>') == \
                                              r' <coin <coin <coin> at 0x1234>>>'

# Generated at 2022-06-22 18:28:30.039865
# Unit test for function get_repr_function
def test_get_repr_function():
    def custom_repr(x):
        if isinstance(x, type):
            return 'the class {!r}'.format(x.__name__)
        elif isinstance(x, str):
            return 'the string {!r}'.format(x)
        else:
            return 'the {} {!r}'.format(type(x).__name__, x)

    assert get_repr_function(int, custom_repr) == repr
    assert get_repr_function(1, custom_repr) == repr
    assert get_repr_function('hello', custom_repr) == custom_repr
    assert get_repr_function((1, 2, 3), custom_repr) == repr
    assert get_repr_function(tuple, custom_repr) == custom_repr

   

# Generated at 2022-06-22 18:28:34.591902
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)



# Generated at 2022-06-22 18:28:38.822331
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('foo') == ('foo',)
    assert ensure_tuple(('foo',)) == ('foo',)
    assert ensure_tuple(['foo']) == ('foo',)
    assert ensure_tuple('foo') == ('foo',)
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple([5]) == (5,)
    assert ensure_tuple((5,)) == (5,)



# Generated at 2022-06-22 18:28:50.158633
# Unit test for function normalize_repr
def test_normalize_repr():
    from .expected import assert_expected
    assert_expected(
        normalize_repr('hello'),
        'hello'
    )
    assert_expected(
        normalize_repr('hello at 0x12345'),
        'hello'
    )
    assert_expected(
        normalize_repr('hello at 0x1234'),
        'hello'
    )
    assert_expected(
        normalize_repr('hello at 0x345'),
        'hello'
    )
    assert_expected(
        normalize_repr('hello at 0x1234\n'),
        'hello at 0x1234'
    )
    assert_expected(
        normalize_repr('hello at 0x12345\n'),
        'hello'
    )

# Generated at 2022-06-22 18:28:59.051253
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import pytest
    with pytest.raises(ValueError):
        get_shortish_repr(1, max_length=-1)

    assert get_shortish_repr(1, max_length=10) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'

    assert get_shortish_repr('abc', max_length=10) == 'abc'
    assert get_shortish_repr('abc', max_length=2) == 'ab...'
    assert get_shortish_repr('abc', max_length=3) == 'abc'

# Generated at 2022-06-22 18:29:01.160581
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)



# Generated at 2022-06-22 18:29:09.941566
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class Number(object):
        def __init__(self, num):
            self.num = num
        def __repr__(self):
            return 'Number({})'.format(self.num)
    assert get_shortish_repr(Number(3)) == 'Number(3)'
    assert get_shortish_repr(Number(4), max_length=12, normalize=True) == \
                                                           'Number(4)'
    assert get_shortish_repr(Number(12345), max_length=12, normalize=True) == \
                                                            'Number(1...45)'
    assert get_shortish_repr(Number(12345), max_length=2, normalize=True) == \
                                                             'Number(...'




# Generated at 2022-06-22 18:29:14.377886
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            assert s == 'spam'

    assert isinstance(A(), WritableStream)

    try:
        class B:
            pass
        isinstance(B(), WritableStream)
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-22 18:29:25.508679
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(False) == (False,)
    assert ensure_tuple(u'hi') == (u'hi',)
    assert ensure_tuple(1.5) == (1.5,)
    assert ensure_tuple((1, 2, (3, 4))) == (1, 2, (3, 4))
    assert ensure_tuple([1, 2, (3, 4)]) == (1, 2, (3, 4))
    assert ensure_tuple({1: 2}) == ({1: 2},)
    assert ensure_tuple([]) == ()
    assert ensure_tuple(set()) == ()
    assert ensure_tuple(9) == (9,)



# Generated at 2022-06-22 18:29:33.329564
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('2') == ('2',)
    assert ensure_tuple(True) == (True,)
    assert ensure_tuple((3, 4)) == (3, 4)
    assert ensure_tuple([5, 6]) == (5, 6)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(xrange(7)) == (0, 1, 2, 3, 4, 5, 6)
    assert ensure_tuple({8: 9}) == ({8: 9},)



# Generated at 2022-06-22 18:29:36.176831
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abcd') == 'abcd'
    assert shitcode('\n\n') == '??'
    assert shitcode(chr(200)) == '?'

# Generated at 2022-06-22 18:29:42.394918
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(123, max_length=5) == '123'
    assert get_shortish_repr([123, 456], max_length=5) == '[123, 456]'
    assert get_shortish_repr([123, 456], max_length=4) == '[1...6]'
    assert get_shortish_repr([123, 456], max_length=3) == '[1...6]'
    assert get_shortish_repr([123, 456], max_length=2) == '[...]'
    assert get_shortish_repr([123, 456], max_length=1) == '[...]'
    assert get_shortish_repr([123, 456], max_length=0) == '[...]'

# Generated at 2022-06-22 18:29:47.612428
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(Ellipsis, max_length=10) == 'Ellipsis'
    assert get_shortish_repr(Ellipsis) == 'Ellipsis'
    assert get_shortish_repr(Ellipsis, max_length=4) == '...'
    assert get_shortish_repr(Ellipsis, max_length=3) == '...'
    assert get_shortish_repr(Ellipsis, max_length=2) == '.'
    assert get_shortish_repr(Ellipsis, max_length=1) == ''
    assert get_shortish_repr(Ellipsis, max_length=0) == ''



# Generated at 2022-06-22 18:29:50.820457
# Unit test for function truncate
def test_truncate():
    assert truncate(1, 3) == '1'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 2) == '...'
    assert truncate('abc', 5) == 'abc'
    assert truncate('abcde', 5) == '...de'
    assert truncate('abcdef', 5) == '...f'





# Generated at 2022-06-22 18:29:58.916798
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, (2, 3))) == (1, (2, 3))
    assert ensure_tuple([1, [2, 3]]) == (1, [2, 3])
    assert ensure_tuple(((4, 5), [6, 7])) == ((4, 5), [6, 7])
    assert ensure_tuple([(4, 5), [6, 7]]) == [(4, 5), [6, 7]]
    assert ensure_tuple('asdf') == ('asdf',)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(1) == (1,)

# Generated at 2022-06-22 18:30:03.194624
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([]) == ()
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)



# Generated at 2022-06-22 18:30:13.065494
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefg', None) == 'abcdefg'
    assert truncate('abcdefg', 0) == ''
    assert truncate('abcdefg', 7) == 'abcdefg'
    assert truncate('abcdefg', 8) == 'abcdefg'
    assert truncate('abcdefg', 5) == 'ab...g'
    assert truncate('abcdefg', 4) == 'a...g'
    assert truncate('abcdefg', 3) == '...g'
    assert truncate('abcdefg', 2) == '..g'
    assert truncate('abcdefg', 1) == '.g'
    assert truncate('abcdefg', -1) == ''
    assert truncate('ab', 5) == 'ab'
    assert truncate('ab', 4) == 'ab'

# Generated at 2022-06-22 18:30:19.059778
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0xFFFF') == 'hello'
    assert normalize_repr('hello at 0xFFFF at 0xFFFF') == 'hello'
    assert normalize_repr('hello at 0xFFFF at 0xFFFF at 0xFFFF') == 'hello'
    assert normalize_repr('hello at 0xFFFF at 0xFFFF at 0xFFFF at 0xFFFF') \
                                                                      == 'hello'
    assert normalize_repr('hello at 0xFFFF at 0xFFFF at 0xFFFF at 0xFFFF at 0xFFFF') == 'hello'
    assert normalize_repr('hello at 0xFFFF at 0xFFFF at 0xFFFF at 0xFFFF at 0xFFFF at 0xFFFF') == 'hello'


# Unit test

# Generated at 2022-06-22 18:30:27.078219
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class Class(object):
        def __repr__(self):
            return '<Class {}>'.format(self)
    class RealClass(Class):
        pass
    class BrokenClass(Class):
        def __repr__(self):
            raise Exception("BrokenClass will not __repr__")
    class NothingClass(object):
        pass

    assert get_shortish_repr(0, custom_repr=[]) == '0'
    assert get_shortish_repr(0, custom_repr=[(int, str)]) == '0'
    assert get_shortish_repr(0, custom_repr=[(None, str)]) == '0'
    assert get_shortish_repr(0, custom_repr=[(None, str)]) == '0'
    assert get_shortish_

# Generated at 2022-06-22 18:30:33.773863
# Unit test for function shitcode
def test_shitcode():
    def test(s):
        assert shitcode(s) == s
    test('a')
    test('ab')
    test('a\nb')
    test('a\x00b')
    test('a\x00\x01\x02b')
    test('\x01\x02\x03')
    test(u'\x01\x02\x03')


# Unit tests for function get_repr_function

# Generated at 2022-06-22 18:30:39.709865
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass

    assert isinstance(WritableStream(), WritableStream)

    if sys.version_info[0] == 2:
        # Python 2 weirdness
        assert issubclass(WritableStreamSubclass, WritableStream)
    else:
        assert isinstance(WritableStreamSubclass(), WritableStream)

# Generated at 2022-06-22 18:30:47.567832
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import types
    class C(object):
        def write(self, s): pass
    assert issubclass(C, WritableStream)
    assert not issubclass(object, WritableStream)
    assert not issubclass(types.ModuleType, WritableStream)
    class D(C):
        pass
    assert issubclass(D, WritableStream)
    class E(object):
        def write(self, s): pass
        def writelines(self, s): pass
    assert not issubclass(E, WritableStream)
    class F(C):
        def writelines(self, s): pass
    assert issubclass(F, WritableStream)
    class G(C):
        def write(self): pass
    assert not issubclass(G, WritableStream)

# Generated at 2022-06-22 18:30:49.550393
# Unit test for function shitcode
def test_shitcode():
    string = '\x1b[?1034h'
    assert shitcode(string) == '?'



# Generated at 2022-06-22 18:30:55.100058
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class C(WritableStream):
        def write(self, x): pass
    assert issubclass(C, WritableStream)
    assert issubclass(open(__file__, 'rb'), WritableStream)
    assert not issubclass(object(), WritableStream)

# Generated at 2022-06-22 18:30:56.674794
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\xc3\x85') == '?'
    assert shitcode('abc') == 'abc'
    assert shitcode('a\xc3\x85b') == 'a?b'

# Generated at 2022-06-22 18:30:58.530369
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .pycompat import BytesIO
    WritableStream.register(BytesIO)
    assert isinstance(BytesIO(), WritableStream)



# Generated at 2022-06-22 18:31:02.474292
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Good(WritableStream):
        def write(self, s):
            pass
        
    class Bad1(WritableStream):
        def write(self, t):
            pass
        
    class Bad2:
        def write(self, s):
            pass
        
    assert issubclass(Good, WritableStream)
    assert not issubclass(Bad1, WritableStream)
    assert not issubclass(Bad2, WritableStream)

# Generated at 2022-06-22 18:31:13.524344
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .pycompat import range
    f = get_shortish_repr
    assert f(range(1000)) == "range(1000)"
    assert f(range(1000), max_length=14) == "range(1000)"
    assert f(range(1000), max_length=13) == "ran..."
    assert f(range(1000), max_length=12) == "ra..."

    assert f(range(1000), custom_repr=[(list, lambda x: 'hi')]) == "hi"
    assert f(
        range(1000), max_length=14,
        custom_repr=[(list, lambda x: 'hi' + 'a'*1000)]
    ) == "hi"

# Generated at 2022-06-22 18:31:17.172235
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(object):
        def write(self, s):
            return s
    assert issubclass(Foo, WritableStream)
    assert not issubclass(str, WritableStream)
    assert not issubclass(object, WritableStream)



# Generated at 2022-06-22 18:31:28.573947
# Unit test for function normalize_repr
def test_normalize_repr():
    import textwrap
    class SilentStream(object):
        def write(self, s):
            pass
        def writelines(self, s):
            pass
        def flush(self):
            pass

    class PrintedStream(object):
        def write(self, s):
            pass
        def writelines(self, s):
            pass
        def flush(self):
            pass

    real_stdout = sys.stdout

# Generated at 2022-06-22 18:31:31.773173
# Unit test for function truncate
def test_truncate():
    assert truncate('123', 3) == '123'
    assert truncate('1234', 3) == '...'
    assert truncate('12345', 4) == '1...'

# Generated at 2022-06-22 18:31:37.440597
# Unit test for function normalize_repr
def test_normalize_repr():
    from .python_toolbox import cute_testing
    assert normalize_repr('spam at 0x123') == 'spam'
    assert normalize_repr('spam at 0x123456789ABCDEF') == 'spam'
    assert normalize_repr('spam') == 'spam'
    with cute_testing.RaiseAssertor(TypeError):
        normalize_repr(None)



# Generated at 2022-06-22 18:31:48.919145
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("<SomeClass at 0x000001B7F904D3C8>") == "<SomeClass>"
    assert normalize_repr("<SomeClass at 0x000001B7F904D3C8> fds") == "<SomeClass> fds"
    assert normalize_repr("<SomeClass> fds at 0x000001B7F904D3C8") == "<SomeClass> fds at 0x000001B7F904D3C8"

# Generated at 2022-06-22 18:31:53.119829
# Unit test for function shitcode
def test_shitcode():
    one_byte_characters = (chr(i) for i in range(32, 256))
    assert [shitcode(c) for c in one_byte_characters] == list(one_byte_characters)


    def test(bytes_, expected_result):
        assert shitcode(bytes_.decode('utf8')) == expected_result

    if sys.version < '3':
        from codecs import BOM_UTF8
        test(BOM_UTF8, '\ufeff')

    test('\x80', '?')
    test('\x81', '?')
    test('\x9f', '?')
    test('\xa0', '?')
    test('\xfe', '?')
    test('\xff', '?')
    test('\u0100', '?')
   

# Generated at 2022-06-22 18:32:03.363554
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnop', 5) == 'ab...'
    assert truncate('abcdefghijklmnop', 6) == 'ab...'
    assert truncate('abcdefghijklmnop', 7) == 'ab...'
    assert truncate('abcdefghijklmnop', 8) == 'abc...'
    assert truncate('abcdefghijklmnop', 9) == 'abc...'
    assert truncate('abcdefghijklmnop', 10) == 'abc...'
    assert truncate('abcdefghijklmnop', 11) == 'abcd...'
    assert truncate('abcdefghijklmnop', 12) == 'abcd...'
    assert truncate('abcdefghijklmnop', 13) == 'abcd...'

# Generated at 2022-06-22 18:32:06.244939
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DerpWritableStream(WritableStream):
        def write(self, *args, **kwargs):
            pass

    assert isinstance(DerpWritableStream(), WritableStream)

    class HerpWritableStream(WritableStream):
        def write(self):
            pass

    assert not isinstance(HerpWritableStream(), WritableStream)



# Generated at 2022-06-22 18:32:12.454426
# Unit test for function shitcode
def test_shitcode():
    exec('''if 1:
        assert shitcode('hello') == 'hello'
        assert shitcode('\x01\x02\x03') == '???'
        assert shitcode('\x01\x02\x03hello') == '???'
        assert shitcode('\x01\x02\x03hello\x01\x02\x03') == '???hello???'
        assert shitcode('hello\x01\x02\x03') == 'hello???'
        assert shitcode('hello\x01\x02\x03hello\x01\x02\x03') == 'hello???hello???'
    ''')

# Generated at 2022-06-22 18:32:22.693128
# Unit test for function normalize_repr
def test_normalize_repr():
    class SomeObject:
        def __init__(self, name):
            self.name = name
        def __repr__(self):
            return '{}(name={}) at 0x{:x}'.format(
                type(self).__name__,
                shitcode(repr(self.name)),
                id(self)
            )

    assert normalize_repr('hi') == 'hi'
    assert normalize_repr('hi at 0x1234') == 'hi'
    assert normalize_repr('hi at 0x1234 at 0x5678') == 'hi at 0x5678'
    assert normalize_repr(SomeObject('g')) == 'SomeObject(name="g")'
    assert normalize_repr(SomeObject('g')) == SomeObject('g').__repr__

# Generated at 2022-06-22 18:32:29.983302
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object):
        pass
    class B(A):
        pass
    class C(object):
        pass
    class D(object):
        pass
    assert get_repr_function(A(), [(C, 1)]) is repr
    assert get_repr_function(A(), [(C, 1), (A, 2), (D, 3)]) is repr
    assert get_repr_function(B(), [(C, 1), (A, 2), (D, 3)]) is repr
    assert get_repr_function(B(), [(D, 1)]) is repr
    assert get_repr_function(D(), [(D, 1)]) == 1
    assert get_repr_function(D(), [(D, 1), (C, 2)]) == 1

# Generated at 2022-06-22 18:32:35.082408
# Unit test for function shitcode
def test_shitcode():
    def assert_shitcode_correct(s):
        assert shitcode(s) == s

    def assert_shitcode_incorrect(s):
        assert shitcode(s) != s

    assert_shitcode_correct('abc')
    assert_shitcode_correct('a\bb')
    assert_shitcode_inco

# Generated at 2022-06-22 18:32:42.572064
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .test_utils import assert_equal
    assert_equal(get_shortish_repr(4), '4')
    assert_equal(get_shortish_repr(4, max_length=2), '4')
    assert_equal(get_shortish_repr(4, max_length=1), '4')
    assert_equal(get_shortish_repr(4, max_length=1, normalize=True), '4')
    assert_equal(get_shortish_repr(4, max_length=3), '4')
    assert_equal(get_shortish_repr((1, 'abc'), max_length=10), "(1, 'abc')")

# Generated at 2022-06-22 18:32:44.679013
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)





# Generated at 2022-06-22 18:32:56.072081
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('Hello at 0x1234') == 'Hello'
    assert normalize_repr('Hello at 0x12345678') == 'Hello'
    assert normalize_repr('Hello') == 'Hello'
    assert normalize_repr('Hello at 0x') == 'Hello at 0x'
    assert normalize_repr('Hello at 0x1') == 'Hello at 0x1'
    assert normalize_repr('Hello at 0x12') == 'Hello at 0x12'
    assert normalize_repr('Hello at 0x123') == 'Hello at 0x123'
    assert normalize_repr('Hello at 0x1234') == 'Hello'
    assert normalize_repr('Hello at 0x12345678') == 'Hello'



# Generated at 2022-06-22 18:33:01.217132
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnopqrstuvwxyz', 10) == 'abcdefg...xyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 4) == '...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 26) == 'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 27) == 'abcdefghijklmnopqrstuvwxyz'



# Generated at 2022-06-22 18:33:12.282235
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo(object):
        def __repr__(self):
            return 'foo'

    class Bar(object):
        def __str__(self):
            return 'bar'

    class DunderStr(object):
        def __str__(self):
            return 'str'

        def __repr__(self):
            return 'repr'

    f = Foo()
    b = Bar()
    d = DunderStr()

    assert get_repr_function(f, ())(f) == 'foo'
    assert get_repr_function(b, ())(b) == 'bar'
    assert get_repr_function(d, ())(d) == 'repr'

    assert get_repr_function(f, ((lambda x: True, str),))(f) == 'foo'
    assert get_

# Generated at 2022-06-22 18:33:20.374150
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .fuzzytestcase import FuzzyTestCase
    class MyTestCase(FuzzyTestCase):
        def test(self):
            self.assertFuzzyEqual(
                get_shortish_repr(['a', 'b', 'c']),
                "'a', 'b', 'c'"
            )
            self.assertFuzzyEqual(
                get_shortish_repr(['a', 1, 'c']),
                "['a', 1, 'c']"
            )
            self.assertFuzzyEqual(
                get_shortish_repr(['a', 'b', 'c'], max_length=3),
                "['a', .."
            )

# Generated at 2022-06-22 18:33:24.396449
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass
    assert get_repr_function(A(), (
        (lambda x: x.__class__.__name__ == 'A', repr),
        (lambda x: x.__class__.__name__ == 'B', repr),
        (str, lambda x: 'STR'),
        (int, lambda x: 'INT')
    )) is repr
    assert get_repr_function(A(), (
        (lambda x: x.__class__.__name__ == 'B', repr),
        (lambda x: x.__class__.__name__ == 'A', repr),
        (str, lambda x: 'STR'),
        (int, lambda x: 'INT')
    )) is repr

# Generated at 2022-06-22 18:33:34.127408
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Writable:
        def write(self, s):
            pass
    w = Writable()
    assert isinstance(w, WritableStream)
    assert issubclass(Writable, WritableStream)

    class Writable:
        pass
    assert not isinstance(Writable, WritableStream)
    assert not issubclass(Writable, WritableStream)

    class Writable:
        def x(self, s):
            pass
    assert not isinstance(Writable, WritableStream)
    assert not issubclass(Writable, WritableStream)

    class Writable:
        def write(self, s):
            pass
        def x(self, s):
            pass
    w = Writable()
    assert isinstance(w, WritableStream)
    assert issubclass(Writable, WritableStream)



# Generated at 2022-06-22 18:33:38.142317
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass
    assert issubclass(WritableStreamSubclass, WritableStream)
    assert issubclass(sys.stdout.__class__, WritableStream)



# Generated at 2022-06-22 18:33:41.715781
# Unit test for function truncate
def test_truncate():
    assert truncate('1234', 3) == '...'
    assert truncate('1234', 4) == '1...'
    assert truncate('1234', 5) == '12...'
    assert truncate('1234', 6) == '1234'


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-22 18:33:50.253551
# Unit test for constructor of class WritableStream
def test_WritableStream():
    """
    If you want to run this unit test, you can do so by running
    `python -m test_stuff.test_WritableStream`.
    """

    class StreamExample(WritableStream):
        def __init__(self):
            self.written_bytes = b''

        def write(self, s):
            assert isinstance(s, binary_type)
            self.written_bytes += s


    StreamExample()

    print('\n\n' "All OK.")


if __name__ == '__main__':
    test_WritableStream()

# Generated at 2022-06-22 18:33:56.967817
# Unit test for function normalize_repr
def test_normalize_repr():
    bad_reprs = [
        "abc at 0x123123",
        "abc at 0x0",
        "abc at 0xffffffff",
        "abc at 0xABABABABABABAB",
    ]
    good_repr = "abc"
    for bad_repr in bad_reprs:
        assert normalize_repr(bad_repr) == good_repr
    assert normalize_repr('abc') == 'abc'

# Generated at 2022-06-22 18:34:05.561724
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(42, ()) == repr
    assert get_repr_function('hi', (
        (str, lambda x: f'a string: {x}'),
    )) == (lambda x: f'a string: {x}')
    assert get_repr_function(42, (
        (str, lambda x: f'a string: {x}'),
    )) == repr
    assert get_repr_function("hi", (
        (42, lambda x: f'a 42: {x}'),
    )) == repr
    assert get_repr_function(42, (
        (42, lambda x: f'a 42: {x}'),
    )) == (lambda x: f'a 42: {x}')



# Generated at 2022-06-22 18:34:08.387286
# Unit test for function normalize_repr
def test_normalize_repr():
    from .testing.asserting import assert_not_equal
    class Foo(object):
        pass

    assert normalize_repr(repr(Foo)) != repr(Foo)



# Generated at 2022-06-22 18:34:15.083709
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self):
            self.written_string = ''

        def write(self, s):
            self.written_string += s

    my_writable_stream = MyWritableStream()
    my_writable_stream.write('Hello, ')
    my_writable_stream.write('world!')
    assert my_writable_stream.written_string == 'Hello, world!'



# Generated at 2022-06-22 18:34:21.508901
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('ร่าเริง') == 'ร่าเริง'
    assert shitcode('האוהבים') == 'האוהבים'
    assert shitcode(u'\u200eabc') == '?abc'



# Generated at 2022-06-22 18:34:22.826001
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamImpl(WritableStream):
        def write(self, s):
            pass

    WritableStreamImpl()

# Generated at 2022-06-22 18:34:32.257112
# Unit test for function truncate
def test_truncate():
    values_list = [
        ('test', 5, 'test'),
        ('test', 4, 'test'),
        ('test', 3, 'tes'),
        ('test', 2, 'te'),
        ('test', 1, 't'),
        ('test', 0, ''),
        ('test', -1, ''),
        ('foo', 1, 'f'),
        ('foo', 2, 'fo'),
        ('foo', 3, 'foo'),
        ('foo', 4, 'foo'),
    ]

    for string, max_length, expected in values_list:
        assert truncate(string, max_length) == expected



# Generated at 2022-06-22 18:34:40.468215
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(b'a\nb') == "b'a\\\\nb'"
    assert get_shortish_repr(1, custom_repr=[(lambda x: True, lambda x: 'a')]) == 'a'
    assert get_shortish_repr(
        str,
        custom_repr=[(str, lambda x: 'a'), (bytes, lambda x: 'b')]
    ) == 'a'
    assert get_shortish_repr(b'a\nb', max_length=6) == "b'a\\\\nb'"
    assert get_shortish_repr(b'a\nb', max_length=4) == "b'a\\\\nb'"

# Generated at 2022-06-22 18:34:44.470696
# Unit test for function shitcode
def test_shitcode():
    print('shitcode:', end=' ')
    c = u'á'
    c_shitcoded = shitcode(c)
    print(c_shitcoded, end=' ')
    assert c_shitcoded == u'?'
    print('ok')





# Generated at 2022-06-22 18:34:49.055236
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', 4) == 'abc'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 2) == 'ab...'
    assert truncate('abc', 1) == 'a...'
    assert truncate('abc', 0) == '...'
    assert truncate('abc', -1) == '...'
    assert truncate('abc', 2002) == 'abc'
    assert truncate('abc', sys.maxsize) == 'abc'
    assert truncate('abc', None) == 'abc'

# Generated at 2022-06-22 18:34:51.958927
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('Hello') == 'Hello'
    assert shitcode('Héllö') == 'H?ll?'
    assert shitcode('A\x03B') == 'A?B'

# Generated at 2022-06-22 18:34:57.852885
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(123) == (123,)
    assert ensure_tuple([1, 2, 3]) == ([1, 2, 3],)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3],) == ([1, 2, 3],)
    assert ensure_tuple((1, 2, 3),) == (1, 2, 3)



# Generated at 2022-06-22 18:35:01.512177
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(['a', 'b']) == ('a', 'b')
    assert ensure_tuple('ab') == ('ab',)
    assert ensure_tuple(None) == (None,)



# Generated at 2022-06-22 18:35:06.418845
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyClass(WritableStream):
        def write(self, s):
            return s.upper()

    assert issubclass(MyClass, WritableStream)


if __name__ == '__main__':
    test_WritableStream()
    print("Everything passed.")

# Generated at 2022-06-22 18:35:11.108437
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io

    class TestWritableStream(WritableStream):
        def write(self, s):
            self.s = s

    test_writable_stream = TestWritableStream()
    stream = io.StringIO()
    test_writable_stream.write(stream)

    assert test_writable_stream.s is stream



# Generated at 2022-06-22 18:35:22.002323
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr(set()) == 'set()'
    assert get_shortish_repr(set, max_length=5) == 'set'
    assert get_shortish_repr(set, max_length=4) == 'set'
    assert get_shortish_repr(set, max_length=3) == 'set'
    assert get_shortish_repr(set, max_length=2) == 'set'
    assert get_shortish_repr(set, max_length=1) == 'set'
    assert get_shortish_repr(set, max_length=0) == 'set'
    assert get_shortish_repr(set, max_length=None) == 'set()'


# Generated at 2022-06-22 18:35:26.925802
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefg', 7) == 'abcdefg'
    assert truncate('abcdefg', 4) == 'a...g'
    assert truncate('abcdefg', 5) == 'a...g'
    assert truncate('abcdefg', 6) == 'ab...g'
    assert truncate('abcdefg', 2) == 'a...'
    assert truncate('abcdefg', 3) == 'a...'
    assert truncate('abc', 2) == 'a...'



# Generated at 2022-06-22 18:35:28.544250
# Unit test for constructor of class WritableStream
def test_WritableStream():
    # A file object is a WritableStream.
    assert isinstance(sys.stdout, WritableStream)

# Generated at 2022-06-22 18:35:31.045781
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('Hi!') == 'Hi!'
    assert shitcode('Hi!\u2026') == 'Hi!...'
    assert shitcode('\u2026') == '...'


# Unit tests for function truncate

# Generated at 2022-06-22 18:35:34.193584
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(('a', 'b')) == ('a', 'b')
    assert ensure_tuple(('a', )) == ('a', )
    assert ensure_tuple(('a', 1)) == ('a', 1)
    assert ensure_tuple('a') == ('a',)
    assert ensure_tuple(1) == (1,)



# Generated at 2022-06-22 18:35:39.432401
# Unit test for function ensure_tuple
def test_ensure_tuple():
    nose.tools.assert_equal(ensure_tuple(5), (5,))
    nose.tools.assert_equal(ensure_tuple(5.5), (5.5,))
    nose.tools.assert_equal(ensure_tuple((1, 2, 3)), (1, 2, 3))
    nose.tools.assert_equal(ensure_tuple([1, 2, 3]), (1, 2, 3))
    nose.tools.assert_equal(ensure_tuple(range(1, 4)), (1, 2, 3))

# Generated at 2022-06-22 18:35:42.237928
# Unit test for function shitcode
def test_shitcode():
    shit = shitcode('áéíóú')
    assert shit == '?éíóú'


from .sixcompat import SimpleNamespace



# Generated at 2022-06-22 18:35:46.390679
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple('foo') == ('foo',)
    assert ensure_tuple({}) == ({},)



# Generated at 2022-06-22 18:35:51.144987
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    def writes_nothing(stream):
        stream.write('hey')
        return True
    class Stream(WritableStream):
        def write(self, s): pass

    assert writes_nothing(Stream())

