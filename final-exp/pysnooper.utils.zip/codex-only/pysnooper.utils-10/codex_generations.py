

# Generated at 2022-06-22 18:26:00.949008
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    b = B()
    my_repr = get_repr_function(b, ((lambda a: isinstance(a, A), 'a'),
                                    (B, 'b')))

    assert my_repr(b) == 'b'
    assert my_repr(A()) == 'a'
    assert my_repr(None) == 'None'
    assert my_repr(()) == '()'
    my_repr = get_repr_function(3, ((type(None), 'n'),))
    assert my_repr(3) == '3'
    assert my_repr(None) == 'n'
    assert my_repr(()) == '()'



# Generated at 2022-06-22 18:26:02.639896
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from pytoolbox import module_test_suite
    from texttest_differ import console
    return module_test_suite(console)

# Generated at 2022-06-22 18:26:11.302381
# Unit test for function truncate
def test_truncate():

    assert truncate(u'hi', 3) == u'hi'
    assert truncate(u'hi', 2) == u'hi'
    assert truncate(u'hi', 1) == u'h'
    assert truncate(u'hi', 4) == u'hi'

    assert truncate(u'hi', 3) == u'hi'
    assert truncate(u'hi', 2) == u'hi'
    assert truncate(u'hi', 1) == u'h'
    assert truncate(u'hi', 4) == u'hi'


    assert truncate(u'hi there', 7) == u'hi ...re'
    assert truncate(u'hi there', 6) == u'hi ...e'
    assert truncate(u'hi there', 5) == u'hi ...'
    assert trunc

# Generated at 2022-06-22 18:26:16.052013
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            print('A.write', s)

    class B(A):
        def write(self, s):
            print('B.write', s)

    assert not isinstance(object(), WritableStream)
    assert isinstance(A(), WritableStream)
    assert isinstance(B(), WritableStream)





# Generated at 2022-06-22 18:26:21.224397
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', 3) == 'abc'
    assert truncate('abcdef', 3) == 'abc'
    assert truncate('abcdef', 6) == 'abc...f'
    assert truncate('abcdef', 7) == 'abc...ef'
    assert truncate('abcdef', 8) == 'abc...def'


# Generated at 2022-06-22 18:26:25.250083
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((5, 6)) == (5, 6)
    assert ensure_tuple([5, 6]) == (5, 6)
    assert ensure_tuple({5, 6}) == (5, 6)

# Generated at 2022-06-22 18:26:28.297643
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import StringIO
    try:
        from cStringIO import StringIO as StringIO2
    except ImportError:
        StringIO2 = StringIO

    class A:
        def write(self, s):
            pass

    assert issubclass(StringIO, WritableStream)
    assert issubclass(StringIO2, WritableStream)
    assert issubclass(A, WritableStream)
    assert not issubclass(object, WritableStream)

# Generated at 2022-06-22 18:26:30.049109
# Unit test for function normalize_repr
def test_normalize_repr():
    obj = object()
    r = repr(obj)
    assert r.startswith('<object object at 0x')
    assert normalize_repr(r).startswith('<object object')



# Generated at 2022-06-22 18:26:33.362279
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'ab😂c') == u'ab?c'
    assert shitcode(u'ab😂c') == u'ab?c'
    try:
        shitcode(u'abc'.encode('utf-8'))
    except TypeError:
        # Only unicode strings are accepted by shitcode
        pass
    else:
        assert False, 'shitcoded a bytestring'
    assert shitcode(u'©') == u'?'



# Generated at 2022-06-22 18:26:45.183532
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x00') == 'abc?'
    assert shitcode('abc\x00\x01') == 'abc??'
    assert shitcode('abc\x00\x01\x02\x03\x04') == 'abc?????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a') == 'abc???????????'
    assert shitcode('abc\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\xff') == 'abc????????????'

# Generated at 2022-06-22 18:26:49.295553
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('yo') == ('yo',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)

# Generated at 2022-06-22 18:27:00.663013
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode(b'abc') == 'abc'
    assert shitcode('\x7f') == '?'
    assert shitcode('\xa5') == '?'
    assert shitcode('\xa5\xe3') == '??'
    assert shitcode('\xa5\xe3\x123') == '???'
    assert shitcode('\xff') == '?'
    assert shitcode('abc\x7fxyz') == 'abc?xyz'
    assert shitcode('abc\xffxyz') == 'abc?xyz'
    assert shitcode('abc\xffxyz\x7f') == 'abc?xyz?'
    assert shitcode('') == ''
    assert shitcode('\x00') == '?'
    assert shitcode('') == ''
   

# Generated at 2022-06-22 18:27:06.488423
# Unit test for function truncate
def test_truncate():
    assert truncate('12345678', 5) == '12345...'
    assert truncate('123', 5) == '123'
    assert truncate('') == ''
    assert truncate('') == ''
    assert truncate('12345678', None) == '12345678'



# Generated at 2022-06-22 18:27:10.399121
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr([1, 2, 3, 4, 5, 6, 7], max_length=5) == \
                                                                '[1, 2, ...]'
    assert get_shortish_repr('hello', max_length=5) == 'hello'



# Generated at 2022-06-22 18:27:19.704565
# Unit test for function truncate
def test_truncate():
    assert truncate('', None) == ''
    assert truncate('', 10) == ''
    assert truncate('123456789', None) == '123456789'
    assert truncate('123456789', 10) == '123456789'
    assert truncate('1234567890', None) == '1234567890'
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('12345678901', None) == '12345678901'
    assert truncate('12345678901', 10) == '1234567...01'
    assert truncate('12345678901', 2) == '...'



# Generated at 2022-06-22 18:27:28.086783
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello\r\nworld!') == 'hello\r\nworld!'
    assert shitcode('hello\r\n\u041c\u0438\u0440') == 'hello\r\n???'
    assert shitcode('\u041c\u0438\u0440') == '???'
    assert shitcode('\u041cб\u0438') == '??б?'
    assert shitcode('\u041cб\u0438\u0440') == '??б?'
    assert shitcode('\u041c\u0438\u0440б') == '???б'
    assert shitcode('\u041c\u0438б\u0440') == '???б'

# Generated at 2022-06-22 18:27:36.921124
# Unit test for function truncate
def test_truncate():
    assert truncate(u'1234567890', 10) == u'1234567890'
    assert truncate(u'1234567890', 9) == u'1234567890'
    assert truncate(u'1234567890', 8) == u'1234567890'
    assert truncate(u'1234567890', 7) == u'1234567...'
    assert truncate(u'1234567890', 6) == u'1234567...'
    assert truncate(u'1234567890', 5) == u'12345...'
    assert truncate(u'1234567890', 4) == u'12345...'
    assert truncate(u'1234567890', 3) == u'1234...'

# Generated at 2022-06-22 18:27:45.682252
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('', []) is repr

    assert get_repr_function('', [
        (lambda x: x==1, lambda x: 'ONE')
    ]) is repr

    assert get_repr_function(3, [
        (lambda x: x==1, lambda x: 'ONE')
    ]) == 'ONE'

    assert get_repr_function('', [
        (str, lambda x: 'ONE')
    ]) == 'ONE'

    assert get_repr_function('', [
        (str, lambda x: 'ONE'),
        (lambda x: x==1, lambda x: 'ONE')
    ]) == 'ONE'



# Generated at 2022-06-22 18:27:53.037934
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import BytesIO

    class DummyWritableStream(BytesIO):
        pass

    dummy_stream = DummyWritableStream()
    assert isinstance(dummy_stream, WritableStream)
    our_abc = WritableStream.__mro__[-2]
    assert dummy_stream.__class__.__mro__[-2] is our_abc
    dummy_stream.write(b'hi')
    assert dummy_stream.getvalue() == b'hi'

# Generated at 2022-06-22 18:27:56.216497
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class TestClass(WritableStream):
        def __init__(self):
            self.string = ''

        def write(self, s):
            self.string += s

    TestClass()



# Generated at 2022-06-22 18:27:59.890322
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)



# Generated at 2022-06-22 18:28:04.145679
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(WritableStream, MyWritableStream)

    class MyBadWritableStream(WritableStream):
        pass
    assert not issubclass(MyBadWritableStream, WritableStream)



# Generated at 2022-06-22 18:28:13.202500
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('\x7f') == '\x7f'
    assert shitcode('\x80') == '?'
    assert shitcode('\x7f\x80\x81') == '\x7f?\x81'
    assert shitcode('\xff') == '\xff'
    assert shitcode('\xfe') == '?'
    assert shitcode('\xff\xfe\xfd') == '\xff?\xfd'
    assert shitcode('\u03c3') == '?'
    assert shitcode('\u03c3\x7f\x80\x81\xfe\xff') == '?\x7f?\x81?\xff'

# Generated at 2022-06-22 18:28:21.881914
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 5) == '12345...789'
    assert truncate('123456789', 4) == '123...789'
    assert truncate('123456789', 1) == '...'
    assert truncate('123456789', 0) == '...'
    assert truncate('123456789', -1) == '...'
    assert truncate('123456789', None) == '123456789'
    assert truncate('123456789', ) == '123456789'



# Generated at 2022-06-22 18:28:31.327034
# Unit test for function normalize_repr
def test_normalize_repr():
    import pytest

# Generated at 2022-06-22 18:28:32.150908
# Unit test for method write of class WritableStream

# Generated at 2022-06-22 18:28:34.237563
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .six import StringIO
    stream = WritableStream(StringIO())
    stream.write('spam eggs')
    assert stream.getvalue() == 'spam eggs'

# Generated at 2022-06-22 18:28:36.869105
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Wacky:
        x = 12
        def write(self, s):
            pass

    assert (issubclass(Wacky, WritableStream)
            and isinstance(Wacky(), WritableStream))



# Generated at 2022-06-22 18:28:43.392571
# Unit test for function ensure_tuple
def test_ensure_tuple():
    from python_toolbox.nifty_collections import OrderedSet
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple([5]) == (5,)
    assert ensure_tuple(set([5])) == (5,)
    assert ensure_tuple((5,)) == (5,)
    assert ensure_tuple(OrderedSet([5])) == (5,)
    assert ensure_tuple('abc') == ('abc',)



# Generated at 2022-06-22 18:28:50.785064
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('my_apple at 0x7f2') == 'my_apple'
    assert normalize_repr('my_apple at 0x7f2 at 0x3') == 'my_apple at 0x3'
    assert normalize_repr('my_apple at 0x7f2 at 0x3 at 0x1a') == \
                                                       'my_apple at 0x3 at 0x1a'

# Generated at 2022-06-22 18:28:59.275437
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C: pass
    class D: pass
    class E: pass
    class F: pass
    class G: pass

    def repr_a(a): return 'repr_a'
    def repr_b(a): return 'repr_b'
    def repr_c(a): return 'repr_c'
    custom_repr = (
        (lambda x: isinstance(x, A), repr_a),
        (B, repr_b),
        (C, repr_c),
    )

    assert get_repr_function(A(), custom_repr) is repr_a
    assert get_repr_function(B(), custom_repr) is repr_b
    assert get_repr_function(C(), custom_repr) is repr_c


# Generated at 2022-06-22 18:29:02.112668
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamWithWrite(WritableStream):
        def write(self, s):
            pass

    assert issubclass(WritableStreamWithWrite, WritableStream)



# Generated at 2022-06-22 18:29:06.708895
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .fakes import OutStream


    class TestWritableStream(WritableStream):

        def __init__(self):
            self.output_strings = []

        def write(self, item):
            self.output_strings.append(item)

    t = TestWritableStream()
    s = 'foo'
    t.write(s)
    assert t.output_strings == [s]



# Generated at 2022-06-22 18:29:16.922317
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    long_repr = '<__main__.A instance at 0xDEADBEEF>'
    assert get_shortish_repr(A()) == long_repr

    assert get_shortish_repr(
        A(),
        custom_repr=(
            (lambda x: True, lambda x: 's'*100),
        ),
        max_length=50
    ) == 's'*50

    assert get_shortish_repr(
        A(),
        custom_repr=(
            (lambda x: True, lambda x: 's'*5),
        ),
        max_length=50
    ) == 's'*5


# Generated at 2022-06-22 18:29:18.686942
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('spam at 0x1234') == 'spam'



# Generated at 2022-06-22 18:29:21.557064
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)

# Generated at 2022-06-22 18:29:23.916067
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Something:
        def write(self, s):
            pass

    assert issubclass(Something, WritableStream)



# Generated at 2022-06-22 18:29:25.840452
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'דוגמה') == u'???'



# Generated at 2022-06-22 18:29:30.901159
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('some string at 0x123435') == 'some string'
    assert normalize_repr('some string at 0x123435 some string at 0x123435') == \
                                                          'some string at 0x123435 some string'
    assert normalize_repr('some string at 0x123435 at 0x123435') == \
                                                          'some string at 0x123435'
    assert normalize_repr('some string at 0x123435 more some string at 0x123435') == \
                                                         'some string at 0x123435 more some string'
    assert normalize_repr('some string at 0x123435 some string at 0x123435 more') == \
                                                         'some string at 0x123435 some string'

# Generated at 2022-06-22 18:29:34.307539
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(123) == (123,)
    assert ensure_tuple([1, 2]) == (1, 2)


if __name__ == '__main__':
    test_ensure_tuple()

# Generated at 2022-06-22 18:29:43.015141
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'abc\n') == u'abc\n'
    assert shitcode(u'abc\x00') == u'abc?'

    # Check that shitcode doesn't shitcode by default to a non ASCII str:
    assert isinstance(shitcode('\xc3\xa9'), str)

    # Check that shitcode doesn't shitcode by default to a non ASCII unicode:
    assert isinstance(shitcode(u'\xc3\xa9'), unicode)

    # Test with non ASCII unicode input:
    assert shitcode(u'\xc3\xa9') == u'\xc3\xa9'
    assert shitcode(u'\xc3\xa9\n') == u'\xc3\xa9\n'
    assert shitcode

# Generated at 2022-06-22 18:29:53.153763
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(4, [(int, lambda x: '<int %s>')]) == \
                                                             '<int 4>'

    assert get_repr_function(4.0, [(int, lambda x: '<int %s>')]) == repr
    assert get_repr_function(4, [(int, None)]) == repr

    assert get_repr_function(4, [(int, lambda x: '<int %s>'),
                                 (float, lambda x: '<float %s>')]) == \
                                                             '<int 4>'


# Generated at 2022-06-22 18:29:54.660694
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from . import StringIO
    assert issubclass(StringIO.StringIO, WritableStream)

# Generated at 2022-06-22 18:30:05.317534
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=-1) == '1'
    assert get_shortish_repr(1, max_length=None) == '1'

    assert get_shortish_repr(1234567, max_length=5) == '123...7'
    assert get_shortish_repr(1234567, max_length=6) == '123...7'

# Generated at 2022-06-22 18:30:08.117408
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(4) == (4,)
    assert ensure_tuple((4, 5, 6)) == (4, 5, 6)



# Generated at 2022-06-22 18:30:19.785680
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class WritableStream1(WritableStream):
        def write(self, s):
            pass

    class WritableStream2:
        def write(self, s):
            pass

    writable_stream1 = WritableStream1()

    assert isinstance(writable_stream1, WritableStream)
    assert issiubclass(WritableStream1, WritableStream)

    writable_stream2 = WritableStream2()

    assert not isinstance(writable_stream2, WritableStream)
    assert not issiubclass(WritableStream2, WritableStream)

    assert WritableStream.register(WritableStream2)

    assert issiubclass(WritableStream2, WritableStream)

    assert isinstance(writable_stream2, WritableStream)

# Generated at 2022-06-22 18:30:23.538188
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple((1, 2)) == ((1, 2),)
    assert ensure_tuple((1, 2, 3, 4)) == ((1, 2, 3, 4),)



# Generated at 2022-06-22 18:30:29.599899
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import unittest

    class AnythingStream(WritableStream):
        def __init__(self):
            self.written = []

        def write(self, s):
            self.written.append(s)

    class StrangeStream(WritableStream):
        pass

    class NoWriteStream(WritableStream):
        pass

    class NoInitStream(WritableStream):
        def write(self, s):
            pass

    class NoSelfWriteStream(WritableStream):
        def write(s):
            pass

    class ExceptionStream(WritableStream):
        def write(self, s):
            raise Exception()

    class BadReturnStream(WritableStream):
        def write(self, s):
            return 10

    class NullStream(WritableStream):
        def write(self, s):
            pass


# Generated at 2022-06-22 18:30:33.967503
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .contextlib_builtins import open
    from .abc import ABC, abstractmethod
    from .pycompat import namedtuple
    from io import StringIO
    class MyStream(WritableStream):
        def __init__(self):
            pass
        def write(self, s):
            pass

    MyStream()
    assert issubclass(MyStream, WritableStream)
    class BrokenStream(WritableStream):
        def __init__(self):
            pass
    assert not issubclass(BrokenStream, WritableStream)
    class BrokenStream(WritableStream):
        def __init__(self):
            pass
        def write(self, s):
            pass
        def something_else(self, s):
            pass

    assert not issubclass(BrokenStream, WritableStream)
    # Testing string_

# Generated at 2022-06-22 18:30:35.174198
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([0]) == (0,)
    assert ensure_tuple((0)) == (0,)
    assert ensure_tuple(0) == (0,)

# Generated at 2022-06-22 18:30:37.871386
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Magic(WritableStream):
        def write(self, s):
            return s * 2
    assert Magic.__subclasshook__(Magic) is True



# Generated at 2022-06-22 18:30:46.895352
# Unit test for function get_repr_function
def test_get_repr_function():
    import decimal

# Generated at 2022-06-22 18:30:48.115555
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(MyWritableStream(), WritableStream)

# Generated at 2022-06-22 18:30:55.626679
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello world') == "'hello world'"
    assert get_shortish_repr('hello world', max_length=3) == "'h...'"
    assert get_shortish_repr('hello world', max_length=6) == "'h...d'"
    assert get_shortish_repr('hello world', max_length=7) == "'h...ld'"
    assert get_shortish_repr('hello world', max_length=8) == "'he...ld'"
    assert get_shortish_repr('hello world', max_length=9) == "'hel...ld'"
    assert get_shortish_repr('hello world', max_length=10) == "'hell...ld'"
    assert get_shortish_repr('hello world', max_length=11) == "'hello...ld'"

# Generated at 2022-06-22 18:31:03.145369
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class superlong:
        def __repr__(self):
            return 'superlong' * 1000
    class WithCustomRepr:
        def __repr__(self):
            return 'This is a long repr for an object with a custom repr'
    assert get_shortish_repr(None, max_length=50) == 'None'
    assert get_shortish_repr(WithCustomRepr, max_length=50) == (
        'This is a long repr for an object with a custom repr'
    )
    assert get_shortish_repr(superlong, max_length=50) == (
        'superlongsuperlongsuperlongsuperlongsuperlongsu...'
        'perlongsuperlong'
    )
    assert get_shortish_repr(superlong, max_length=50, normalize=True)

# Generated at 2022-06-22 18:31:06.275756
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class C:
        def write(self, s):
            pass

    C.__subclasshook__(C) == True

# Generated at 2022-06-22 18:31:12.283461
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import sys
    class MyOutput(WritableStream):
        def write(self, s):
            sys.stderr.write(s)
    MyOutput().write('hello')
    # issue #2433: passing unicode to file.write() led to a TypeError
    # in Python 2.7.
    f = io.BytesIO()
    MyOutput.write(f, u'\xc2')
    assert f.getvalue() == b'\xc2'

# Generated at 2022-06-22 18:31:16.970440
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(4, [(int, lambda x: 'int')]) == 'int'
    assert get_repr_function([4], [(list, lambda x: 'list')]) == 'list'
    assert get_repr_function([4], [(tuple, lambda x: 'list')]) != 'list'
    assert get_repr_function([4], [(list, lambda x: 'list')]) == 'list'
    assert get_repr_function(4, []) == repr



# Generated at 2022-06-22 18:31:21.481168
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('meow') == ('meow',)



# Generated at 2022-06-22 18:31:25.304668
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritable(WritableStream):
        def write(self, s):
            print(s)
    x = MyWritable()
    x.write('hello world')




# Generated at 2022-06-22 18:31:27.990091
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class TestClass(WritableStream):
        def write(self, s):
            pass
    TestClass()


if __name__ == '__main__':
    test_WritableStream()

# Generated at 2022-06-22 18:31:37.223933
# Unit test for function get_repr_function
def test_get_repr_function():
    def f1(x): return x + 5
    def f2(x): return x * 10
    def f3(x): return 'Hello %s' % x
    def f4(x): return 'Hello %s' % x

# Generated at 2022-06-22 18:31:48.636649
# Unit test for function get_shortish_repr

# Generated at 2022-06-22 18:31:53.741687
# Unit test for function truncate
def test_truncate():
    assert truncate('12345', 4) == '12345'
    assert truncate('12345', 5) == '12345'
    assert truncate('12345', 6) == '12345'
    assert truncate('12345', None) == '12345'
    assert truncate('12345', 3) == '...'
    assert truncate('123456789', 6) == '123...'


if __name__ == '__main__':
    test_truncate()

# Generated at 2022-06-22 18:31:56.450275
# Unit test for function shitcode
def test_shitcode():
    my_string = '*æøåÆØÅ*'
    assert shitcode(my_string) == '*???***'

# Generated at 2022-06-22 18:32:02.807590
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abcdefg') == 'abcdefg'
    assert shitcode('\x00abcdefg') == '?abcdefg'
    assert shitcode('abcdefg\x00') == 'abcdefg?'
    assert shitcode('abc\x00defg') == 'abc?defg'
    assert shitcode('\x00ab\x00cdefg') == '??cdefg'
    assert shitcode('\x00\x00\x00\x00ab\x00cdefg') == '????cdefg'
    assert shitcode('abcdefg\x00\x00\x00\x00') == 'abcdefg????'
    assert shitcode('abc\x00defg\x00\x00\x00\x00') == 'abc?defg????'

# Generated at 2022-06-22 18:32:08.285295
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestStream(WritableStream):
        def __init__(self, written_string=''):
            self.written_string = written_string
        def write(self, s):
            self.written_string += s

    stream = TestStream()
    stream.write('abc')
    assert stream.written_string == 'abc'

# Generated at 2022-06-22 18:32:10.749491
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    class MyNonWritableStream(object):
        pass

    assert issubclass(MyWritableStream, WritableStream)
    assert not issubclass(MyNonWritableStream, WritableStream)

# Generated at 2022-06-22 18:32:18.089958
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(1, 2) == (1, 2)
    assert ensure_tuple(set([1])) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple('Hello') == ('Hello',)
    assert ensure_tuple((1,)) == (1,)



# Generated at 2022-06-22 18:32:26.805501
# Unit test for function truncate
def test_truncate():
    assert truncate('', 10) == ''
    assert truncate('123456789', 10) == '123456789'
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('12345678901', 10) == '12345...901'
    assert truncate('123456789012', 10) == '123456...012'
    assert truncate('1234567890123', 10) == '1234...0123'
    assert truncate('12345678901234', 10) == '1234...1234'




# Generated at 2022-06-22 18:32:38.168044
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(u'jumpland') == u"'jumpland'"
    assert get_shortish_repr(u'jumpland', max_length=4) == u"'ju...'"
    assert get_shortish_repr(u'jumpland', max_length=3) == u"'ju...'"
    assert get_shortish_repr(u'jumpland', max_length=2) == u"'...'"
    assert get_shortish_repr(u'jumpland', max_length=1) == u"'...'"
    assert get_shortish_repr(u'jumpland', max_length=0) == u"'...'"

# Generated at 2022-06-22 18:32:47.418105
# Unit test for function get_shortish_repr

# Generated at 2022-06-22 18:32:51.604278
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(WritableStream):
        def write(self, s):
            pass
    assert issubclass(Foo, WritableStream)
    assert issubclass(Foo, ABC)
    assert not issubclass(Foo, type)
    assert hasattr(Foo, '__subclasshook__')
    assert isinstance(Foo(), WritableStream)

    class Bar(WritableStream):
        pass
    assert not issubclass(Bar, WritableStream)
    assert not isinstance(Bar(), WritableStream)



# Generated at 2022-06-22 18:32:55.552607
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)


if sys.version_info[:2] >= (2, 7):
    from collections import OrderedDict
else:
    from .ordered_dict import OrderedDict

# Generated at 2022-06-22 18:33:00.008316
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('some string') == 'some string'
    assert shitcode('some\xffstring') == 'some?string'
    assert shitcode('some\xff\xffstring') == 'some??string'
    assert shitcode('some\xff\xffstring\xff') == 'some??string?'
    assert shitcode('some\xff\xffstring\xff\xff') == 'some??string??'



# Generated at 2022-06-22 18:33:01.889112
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(object):
        def write(self, s):
            pass

# Generated at 2022-06-22 18:33:10.322780
# Unit test for function truncate
def test_truncate():
    assert truncate('hello!', 9) == 'hello!'
    assert truncate('hello!', 7) == 'he...!'
    assert truncate('abcdefghi', 8) == 'ab...hi'
    assert truncate('hello!', 5) == 'he...'
    assert truncate('hello!', 4) == 'h...'
    assert truncate('hello!', 3) == '...'
    assert truncate('hello!', 2) == '..'
    assert truncate('hello!', 1) == '.'
    assert truncate('hello!', 0) == ''
    assert truncate('hello!', None) == 'hello!'



# Generated at 2022-06-22 18:33:14.896828
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("<module '__main__' (<string>)>") == "<module '__main__'>"
    assert normalize_repr("<module '__main__' (<string>)> at 0x1234FF") == "<module '__main__'>"



# Generated at 2022-06-22 18:33:21.659165
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Mark writer
    class MarkWriter:
        def __init__(self):
            self.mark = None
        def write(self, mark):
            self.mark = mark

    # class with write method
    class Writable(object):
        def write(self, mark):
            pass
    w1 = Writable()
    assert issubclass(Writable, WritableStream)
    assert issubclass(w1.__class__, WritableStream)
    assert isinstance(w1, WritableStream)

    # class without write method
    class NotWritable(object):
        pass
    w2 = NotWritable()
    assert not issubclass(NotWritable, WritableStream)
    assert not issubclass(w2.__class__, WritableStream)
    assert not isinstance(w2, WritableStream)

# Generated at 2022-06-22 18:33:26.819999
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class A(object):
        def write(self, s):
            pass

    class B(A):
        def poo(self):
            pass

    class C(object):
        def write(self, s):
            pass

    class D(C):
        def __init__(self):
            self.write = 'a'

    class E(WritableStream):
        pass

    class F(object):
        pass

    assert isinstance(A(), WritableStream)
    assert isinstance(B(), WritableStream)
    assert isinstance(C(), WritableStream)
    assert not isinstance(D(), WritableStream)
    assert isinstance(E(), WritableStream)
    assert not isinstance(F(), WritableStream)

# Generated at 2022-06-22 18:33:35.025826
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnopqrstuvwxyz', 4) == '...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 5) == 'a...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 6) == 'a...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 7) == 'ab...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 8) == 'ab...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 9) == 'abc...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 10) == 'abc...'
    assert truncate

# Generated at 2022-06-22 18:33:44.667780
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, (
        (lambda x: True, str),

        # Test the different forms of conditions:
        ((6,), lambda x: x*x),
        (lambda x: x == 5, lambda x: 'five'),
        (int, lambda x: 'int'),
        ((lambda x: x == 'abc',), (lambda x: None,),
         lambda x: 'not None'),
    )) == 'five'


# Generated at 2022-06-22 18:33:47.611434
# Unit test for function normalize_repr
def test_normalize_repr():
    x = 'hello'
    assert normalize_repr(repr(x)) == repr(x)



# Generated at 2022-06-22 18:33:52.281352
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    for chr_number in range(256):
        assert shitcode(chr(chr_number)) == chr(chr_number)
    assert shitcode(chr(256)) == '?'



# Generated at 2022-06-22 18:33:55.965517
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(('a', 'b')) == ('a', 'b')



# Generated at 2022-06-22 18:34:01.150462
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(object):
        def write(self, s):
            return s * 2
    assert issubclass(Foo, WritableStream)
    assert isinstance(Foo(), WritableStream)
    assert Foo().write('abc') == 'abcabc'
    assert Foo().write(u'abc') == u'abcabc'




# Generated at 2022-06-22 18:34:10.052429
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'abc\xe9') == u'abc?'
    assert shitcode(u'abc\u071AA') == u'abc?'
    assert shitcode(u'abc\u071AA\xe9') == u'abc??'
    assert shitcode(u'abc\xe9\u071AA') == u'abc??'
    assert shitcode((u'abc\u071AA\xe9', ord)) == u'abc??' # doctest: +IGNORE_EXCEPTION_DETAIL
    assert shitcode(u'abc\xe9\u071AA\u071AA\xe9\u071AA') == u'abc???'

# Generated at 2022-06-22 18:34:19.730832
# Unit test for function truncate
def test_truncate():
    assert truncate('', 1) == ''
    assert truncate('', 2) == ''
    assert truncate('', None) == ''
    assert truncate('abcdefg', 1) == 'abcdefg'
    assert truncate('abcdefg', 2) == 'abcdefg'
    assert truncate('abcdefg', 7) == 'abcdefg'

    assert truncate('abcdefg', 6) == 'abc...'
    assert truncate('abcdefg', 6, '') == 'abc...'
    assert truncate('abcdefg', 6, '...') == 'abc...'
    assert truncate('abcdefg', 6, ' ') == 'abcdefg'
    assert truncate('abcdefg', 6, 'ABC') == 'abcA...'

# Generated at 2022-06-22 18:34:26.775789
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'áéîøü') == u'???'
    assert shitcode(u'0') == u'0'
    assert shitcode(u'$') == u'$'
    assert shitcode(u'2^') == u'2^'
    assert shitcode(u'p=£') == u'p=?'
    assert shitcode(u'\xa9') == u'?'
    import sys
    if sys.version_info.major == 3:
        assert shitcode(chr(945)) == '?'
    else:
        assert shitcode(unicode(u'α')) == u'?'
    assert shitcode(u'\x00') == u'?'
    assert shitcode(u'\x10') == u'?'
    assert shitcode(u'\x20') == u

# Generated at 2022-06-22 18:34:35.476109
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1j, ((lambda x: True, lambda x: 'gotcha!'),)) == \
                                                                 'gotcha!'
    assert get_repr_function(2, ((int, lambda x: 'gotcha!'),)) == 'gotcha!'
    assert get_repr_function(3, ((complex, lambda x: 'gotcha!'),)) != 'gotcha!'
    assert get_repr_function(1j, ((complex, lambda x: 'gotcha!'),)) == 'gotcha!'



# Generated at 2022-06-22 18:34:40.416680
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def __init__(self):
            self.in_memory_text = ''
            super(A, self).__init__()

        def write(self, s):
            self.in_memory_text += s

    a = A()
    assert a.in_memory_text == ''
    a.write('abc')
    assert a.in_memory_text == 'abc'
    a.write('def')
    assert a.in_memory_text == 'abcdef'



# Generated at 2022-06-22 18:34:43.770430
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', None) == '1234567890'
    assert truncate('1234567890', 9) == '1234567890'
    assert truncate('1234567890', 8) == '12345678...'

test_truncate()

# Generated at 2022-06-22 18:34:48.033245
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Test(WritableStream):
        pass
    Test()

    class Test: pass
    try:
        Test()
    except TypeError:
        pass
    else:
        raise AssertionError('__subclasshook__ of WritableStream not working.')


if __name__ == '__main__':
    test_WritableStream()

# Generated at 2022-06-22 18:34:54.810255
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('this is a string') == "this is a string"
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr([1, 2, 3, 4, 5], max_length=20) == '[1, 2, 3, 4, 5]'
    assert get_shortish_repr([1, 2, 3, 4, 5], max_length=4) == '[1, 2, 3, ...]'



# Generated at 2022-06-22 18:35:04.361115
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr("1234567890", max_length=8) == "1234567890"
    assert get_shortish_repr("1234567890", max_length=9) == "1234567890"
    assert get_shortish_repr("1234567890", max_length=10) == "1234567890"
    assert get_shortish_repr("1234567890", max_length=11) == "1234567890"
    assert get_shortish_repr("1234567890", max_length=12) == "1234567890"
    assert get_shortish_repr("1234567890", max_length=13) == "1234567890"

# Generated at 2022-06-22 18:35:11.795508
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', None) == 'hello'
    assert truncate('hello', 10) == 'hello'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello my name is dan', 15) == 'hello my n...'
    assert truncate('hello my name is dan', 5) == 'he...'
    assert truncate('hello my name is dan', 4) == '...'
    assert truncate('hello my name is dan', 3) == '...'



# Generated at 2022-06-22 18:35:20.047696
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', None) == 'abc'
    assert truncate('abc', 2) == 'ab...'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 4) == 'abc'
    assert truncate('abc', 5) == 'abc'
    assert truncate('apple', 4) == 'a...e'
    assert (truncate('finding_dory_squid_baby', 15) ==
            'finding_dory...baby')
    assert (truncate('finding_dory_squid_baby', 16) ==
            'finding_dory_...baby')

# Generated at 2022-06-22 18:35:24.756728
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        pass

    assert isinstance(A, type)
    assert issubclass(list, collections_abc.Iterable)
    assert not issubclass(list, string_types)
    assert not issubclass(list, collections_abc.Sized)
    assert issubclass(list, collections_abc.Container)
    assert issubclass(list, collections_abc.MutableSequence)

# Generated at 2022-06-22 18:35:31.294294
# Unit test for function get_repr_function
def test_get_repr_function():
    customs = ((lambda x: x % 2, lambda x: 'odd' + repr(x)),
               (str, str),
               (int, lambda x: 'int{}'.format(x)),
               (type, type))
    for x in range(10):
        assert get_repr_function(x, customs)(x) in 'odd0int1odd2int3odd4int5odd6int7odd8int9'
    assert get_repr_function(10, customs)(10) == 'int10'
    assert get_repr_function('', customs)('') == "''"
    assert get_repr_function(type, customs)(type) == '<type \'type\'>'

# Generated at 2022-06-22 18:35:37.290113
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, (
        ((lambda x: True), (lambda x: '5yay!'))
    ))(5) == '5yay!'
    assert get_repr_function(5, (
        (int, (lambda x: '5yay!'))
    ))(5) == '5yay!'
    assert get_repr_function(5, (
        (int, (lambda x: '5yay!')),
        ((lambda x: True), (lambda x: 'wuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu'))
    ))(5) == '5yay!'

# Generated at 2022-06-22 18:35:41.314368
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)



# Generated at 2022-06-22 18:35:49.673026
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import StringIO
    class Writable(WritableStream):
        def write(self, s):
            pass
    assert issubclass(Writable, WritableStream)
    class Unwritable(object):
        def write(self, s):
            pass
    assert not issubclass(Unwritable, WritableStream)
    class Writable2(WritableStream):
        def write(self, s):
            return True
    assert issubclass(Writable2, WritableStream)
    class Writable3(WritableStream):
        pass
    assert not issubclass(Writable3, WritableStream)

    Writable()
    Unwritable()
    Writable2()
    Writable3()

    writable_stream = WritableStream()

# Generated at 2022-06-22 18:35:54.391588
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Works(WritableStream):
        def write(self, s):
            pass

    class DoesnWork(WritableStream):
        pass

    assert issubclass(Works, WritableStream)
    assert not issubclass(DoesnWork, WritableStream)


