

# Generated at 2022-06-22 18:26:01.547565
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('fuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu!')
    assert normalize_repr(str(set([1, 2, 3])))
    assert normalize_repr(repr(set([1, 2, 3])))

# Generated at 2022-06-22 18:26:10.968678
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None, max_length=10) == 'None'
    assert get_shortish_repr(1, max_length=10) == '1'
    assert get_shortish_repr('abc', max_length=10) == 'abc'
    assert get_shortish_repr(1.2, max_length=10) == '1.2'

    assert get_shortish_repr([None], max_length=10) == '[None]'
    assert get_shortish_repr([1], max_length=10) == '[1]'
    assert get_shortish_repr(['abc'], max_length=10) == "['abc']"
    assert get_shortish_repr([1.2], max_length=10) == '[1.2]'

    assert get

# Generated at 2022-06-22 18:26:19.707377
# Unit test for function truncate
def test_truncate():
    assert truncate('', 5) == ''
    assert truncate('1234567890', 5) == '12345...67890'
    assert truncate('1234567890', 4) == '1...0'
    assert truncate('1234567890', 3) == '1...0'
    assert truncate('1234567890', 2) == '1...0'
    assert truncate('1234567890', 1) == '...'
    assert truncate('1234567890', 0) == '...'
    assert truncate('1234567890', -1) == '...'
    assert truncate('1234567890', None) == '1234567890'

# Generated at 2022-06-22 18:26:24.705765
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream, object): pass
    assert A.__subclasshook__(A)
    class B(object):
        def write(self, x): pass
    assert WritableStream.__subclasshook__(B)
    class C(object): pass
    assert not WritableStream.__subclasshook__(C)
    class D(B): pass
    assert WritableStream.__subclasshook__(D)
    class E(B):
        def write(self, x): pass
    assert WritableStream.__subclasshook__(E)


if __name__ == '__main__':
    test_WritableStream_write()

# Generated at 2022-06-22 18:26:34.149373
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert normalize_repr('foo at 0x28a0a30') == 'foo'
    assert normalize_repr('foo') == 'foo'
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr({1: 2}, max_length=10) == "{1: 2}"
    assert get_shortish_repr({1: 2}, max_length=4) == "{1: 2}"
    assert get_shortish_repr({1: 2}, max_length=6) == "{1: 2}"
    assert get_shortish_repr({1: 2}, max_length=7) == "{1: 2}"
    assert get_shortish_repr({1: 2}, max_length=8) == "{1: 2}"
    assert get_shortish_repr

# Generated at 2022-06-22 18:26:45.954036
# Unit test for function get_repr_function
def test_get_repr_function():
    from weakref import ref
    x = object()
    assert get_repr_function(1, ((lambda x: x == 2, None),
                                 (lambda x: x == 1, None))) is None

    assert get_repr_function(1, ((lambda x: x == 2, None),
                                 (lambda x: x == 1, lambda x: 'a'))) == 'a'

    assert get_repr_function(1, ((int, None), (lambda x: x == 1, lambda x: 'a'))) \
        == 'a'

    assert get_repr_function(1, ((int, None), (lambda x: x == 1, lambda x: 'a'))) \
        == 'a'


# Generated at 2022-06-22 18:26:48.645698
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyClass(object):
        def write(self, s):
            '''Write a string to the stream.'''

    assert issubclass(MyClass, WritableStream)
    assert not issubclass(int, WritableStream)

# Generated at 2022-06-22 18:26:58.115705
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple({1, 2, 3}) == ({1, 2, 3},)
    assert ensure_tuple({'a': 1}) == ({'a': 1},)
    assert ensure_tuple('a') == ('a',)



# Generated at 2022-06-22 18:27:01.908937
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(4) == (4,)



# Generated at 2022-06-22 18:27:09.911775
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Test(WritableStream):
        def write(self, s):
            print(s)
    Test()
    class Test:
        def write(self, s):
            print(s)
    Test()
    # Confirm that the below don't raise errors:
    assert issubclass(WritableStream, WritableStream)
    assert issubclass(Test, WritableStream)
    assert isinstance(Test(), WritableStream)
    assert isinstance(Test(), object)
    assert isinstance(Test(), object)

# Generated at 2022-06-22 18:27:20.779402
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo: pass
    class Bar: pass
    class Bird: pass

    def repr_function(item):
        return '[{}]'.format(repr(item))

    assert get_repr_function(Foo(), [(int, repr_function)]) == repr
    assert get_repr_function(int(5), [(int, repr_function)]) == repr_function
    assert get_repr_function(Bar(), [(Bar, repr_function)]) == repr_function

    assert get_repr_function(Foo(), [(Foo, repr_function), (type(5), repr_function)]) == repr
    assert get_repr_function(5, [(Foo, repr_function), (type(5), repr_function)]) == repr_function


# Generated at 2022-06-22 18:27:23.428166
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class MyWritableStream(WritableStream):

        def write(self, s):
            raise NotImplementedError
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-22 18:27:26.678394
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\rdef') == 'abc?def'
    assert shitcode('abc\ndef') == 'abc?def'
    assert shitcode(b'abc\ndef'.decode('utf-8')) == 'abc?def'



# Generated at 2022-06-22 18:27:31.283318
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class CustomWritableStream(WritableStream):
        pass

    class CustomWritableStream2(WritableStream):
        def write(self, s):
            pass

    class CustomWritableStream3(WritableStream):
        def write(self, s):
            pass

        def write2(self, s):
            pass

    class CustomWritableStream4(WritableStream):
        def write(self, s):
            pass

    CustomWritableStream4.write2 = None

    class CustomWritableStream5(WritableStream):
        def write(self, s):
            pass

    class CustomWritableStream6(CustomWritableStream5):
        write2 = None

    class CustomWritableStream7(object):
        def __init__(self):
            self.write = None


# Generated at 2022-06-22 18:27:34.674271
# Unit test for function normalize_repr
def test_normalize_repr():
    class MyClass:
        pass
    assert normalize_repr(repr(MyClass)) == '<class __main__.MyClass>'
    assert normalize_repr(repr([1, 2, 3])) == '[1, 2, 3]'
    
    

# Generated at 2022-06-22 18:27:38.764612
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('simple') == 'simple'
    assert shitcode('שלום') == '? ?'
    assert shitcode(u'simple') == 'simple'
    assert shitcode(u'שלום') == '? ?'



# Generated at 2022-06-22 18:27:43.172317
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            return

    assert isinstance(MyWritableStream(), MyWritableStream)
    assert not isinstance(MyWritableStream, WritableStream)
    assert isinstance(MyWritableStream, type)



# Generated at 2022-06-22 18:27:51.223583
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .pycompat import StringIO
    from .abc import WritableStream

    class BangWritableStream(WritableStream):
        def write(self, s):
            return '!' + s + '!'

    bang_writable_stream = BangWritableStream()
    assert isinstance(bang_writable_stream, WritableStream)

    bang_writable_stream.write('foo') == '!foo!'


    with pytest.raises(TypeError):
        class NotWritableStream(WritableStream):
            pass



# Generated at 2022-06-22 18:27:53.261198
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X(object):
        def write(self, s):
            assert isinstance(s, str)
    assert isinstance(X(), WritableStream)

# Generated at 2022-06-22 18:27:54.947853
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    stream = TestStream()
    stream.write('hello')
    assert stream.data == 'hello'
    print('passed!')



# Generated at 2022-06-22 18:28:01.269939
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple(5, 5) == (5, 5)
    assert ensure_tuple([5, 5]) == (5, 5)
    assert ensure_tuple({5, 5}) == (5, 5)
    assert ensure_tuple((5, 5)) == (5, 5)
    assert ensure_tuple(None) == (None,)

# Generated at 2022-06-22 18:28:08.043076
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(r'{}') == r'{}'
    assert normalize_repr(r'{} at 0x1234') == r'{}'
    assert normalize_repr(r'{} at 0x123456789abcde') == r'{}'
    assert normalize_repr(r'{} at 0x123456789ABCDFFF') == r'{}'
    assert normalize_repr(r'{} at 0x123456789ABCDFFF and at 0x1234') == r'{}'



# Generated at 2022-06-22 18:28:15.061611
# Unit test for function truncate
def test_truncate():
    assert truncate('qwertyuiop', None) == 'qwertyuiop'
    assert truncate('qwertyuiop', 10) == 'qwertyuiop'
    assert truncate('qwertyuiop', 9) == 'qwertyuiop'
    assert truncate('qwertyuiop', 1) == 'q...p'
    assert truncate('qwertyuiop', 2) == 'qw...p'
    assert truncate('qwertyuiop', 3) == 'qwe...p'
    assert truncate('qwertyuiop', 4) == 'qwe...op'
    assert truncate('qwertyuiop', 5) == 'qwert...p'
    assert truncate('qwertyuiop', 6) == 'qwerty...p'

# Generated at 2022-06-22 18:28:16.772795
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream): pass
    assert issubclass(A, WritableStream)

# Generated at 2022-06-22 18:28:23.300542
# Unit test for function get_repr_function
def test_get_repr_function():
    from .carriage import Carriage
    class Foo(Carriage):
        def carsand(self):
            return 1
    assert get_repr_function(Foo(), ()) is repr
    assert get_repr_function(1, []) is repr

    assert get_repr_function(Foo(), [(Carriage, lambda x: x.carsand())]) is not repr
    assert get_repr_function(1, [(Carriage, lambda x: x.carsand())]) is repr



# Generated at 2022-06-22 18:28:32.549034
# Unit test for function truncate
def test_truncate():
    assert truncate('abcd', None) == 'abcd'
    assert truncate('abcd', 3) == 'abcd'
    assert truncate('abcd', 4) == 'abcd'
    assert truncate('abcd', 5) == 'abcd'
    assert truncate('abcd', 8) == 'abcd'

    assert truncate('abcd', 2) == 'a...'
    assert truncate('abcd', 3) == 'a...'
    assert truncate('abcd', 4) == 'ab...'
    assert truncate('abcd', 5) == 'ab...'

    assert truncate('abcdefg', 4) == 'a...'
    assert truncate('abcdefg', 5) == 'a...g'
    assert truncate('abcdefg', 6) == 'ab...g'

# Generated at 2022-06-22 18:28:39.820498
# Unit test for function truncate
def test_truncate():
    assert truncate(u'hello', None) == u'hello'
    assert truncate(u'hello', 5) == u'hello'
    assert truncate(u'hello', 4) == u'hell...'
    assert truncate(u'hello', 3) == u'hel...'
    assert truncate(u'hello', 2) == u'he...'
    assert truncate(u'hello', 1) == u'h...'

    assert truncate(u'hello world', 10) == u'hello wo...'
    assert truncate(u'hello world', 9) == u'hello...'
    assert truncate(u'hello world', 8) == u'hello...'
    assert truncate(u'hello world', 7) == u'hello...'

# Generated at 2022-06-22 18:28:44.859844
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('\x7f') == '\x7f'
    assert shitcode('\x80') == '?'
    assert shitcode('\xff') == '?'
    assert shitcode('\x80\xff') == '??'
    assert shitcode('') == ''

# Generated at 2022-06-22 18:28:50.786679
# Unit test for function normalize_repr
def test_normalize_repr():

    class A(object):
        def __repr__(self):
            return "<A at 0x%X>" % id(self)

    from .testing import TestCase
    test = TestCase()
    a = A()
    test.assertEqual(normalize_repr(repr(a)), '<A at 0x%X>' % id(a))



# Generated at 2022-06-22 18:28:56.688916
# Unit test for function shitcode
def test_shitcode():
    import string
    assert shitcode(string.printable) == string.printable
    assert shitcode('\0\r\n\t!') == '\0\r\n\t!'
    for i in range(256):
        assert len(shitcode(chr(i))) == 1
    assert shitcode(u'\u043d\u0435\u0432\u0435\u0441\u0442') == '??????'



# Generated at 2022-06-22 18:29:05.473422
# Unit test for function normalize_repr
def test_normalize_repr():
    class Test(object):

        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return '{} at 0x{:x}'.format(self.name, id(self))

    for i in range(4):
        t1 = Test('t1')
        t2 = Test('t2')
        assert normalize_repr(repr(t1)) == repr(t1).replace(' at 0x', ' ')
        assert normalize_repr(repr(t2)) == repr(t2).replace(' at 0x', ' ')




# Generated at 2022-06-22 18:29:12.277737
# Unit test for function normalize_repr
def test_normalize_repr():
    normalize_repr_outputs = [
        [None, 'None'],
        [True, 'True'],
        [False, 'False'],
        [object(), '<object>'],
        [object(), '<object>'],
        [object(), '<object>'],

    ]
    for item, output in normalize_repr_outputs:
        assert normalize_repr(repr(item)) == output

# Generated at 2022-06-22 18:29:16.985262
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(None) == (None,)





# Generated at 2022-06-22 18:29:26.582798
# Unit test for function truncate
def test_truncate():
    assert truncate('abcde', None) == 'abcde'
    assert truncate('abcde', 5) == 'abcde'
    assert truncate('abcde', 4) == 'abcd'
    assert truncate('abcde', 3) == 'abc'
    assert truncate('abcde', 2) == 'ab'
    assert truncate('abcde', 1) == 'a'
    assert truncate('abcde', 0) == ''
    assert truncate('abcde', 6) == 'abcde'
    assert truncate('abcde', 7) == 'abcde'
    assert truncate('abcde', 8) == 'abcde'
    assert truncate('abcde', 9) == 'abcde'
    assert truncate('abcde', 10) == 'abcde'

# Generated at 2022-06-22 18:29:29.539005
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('a\xFFb') == 'a?b'
    assert shitcode('a\xFFb\x80') == 'a?b?'

# Generated at 2022-06-22 18:29:35.436901
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple(1.5) == (1.5,)
    assert ensure_tuple(x for x in [1]) == (1,)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(x for x in [1, 2]) == (1, 2)



# Generated at 2022-06-22 18:29:42.274500
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    import sys
    import tempfile

    with tempfile.TemporaryDirectory() as temp_dir:
        filename = temp_dir + '\\temp.txt'
        with open(filename, 'w') as f:
            f.write('hello')
        with open(filename, 'r') as f:
            assert isinstance(f, WritableStream)
        sio = io.StringIO()
        assert isinstance(sio, WritableStream)
        assert isinstance(sys.stderr, WritableStream)
        assert isinstance(sys.stdout, WritableStream)
        assert isinstance(sys.stdin, WritableStream)

# Generated at 2022-06-22 18:29:48.725079
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<class \'foo.bar\'> at 0x8E5A6E4>') == \
        "<class 'foo.bar'>"
    assert normalize_repr('<function foo at 0x8E5A6E4(y)>') == \
        '<function foo(y)>'
    assert normalize_repr('<function foo at 0x8E5A6E4>') == \
        '<function foo>'



# Generated at 2022-06-22 18:29:53.068992
# Unit test for function truncate
def test_truncate():
    assert truncate('abcde', 5) == 'abcde'
    assert truncate('abcdefghijk', 7) == 'abcd...ij'
    assert truncate('asdf', 4) == 'asdf'
    assert truncate('asdf', 3) == 'asd'
    assert truncate('012', 2) == '01'

# Generated at 2022-06-22 18:29:57.942995
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class TestWritableStream(WritableStream):

        def __init__(self):
            self.buffer = u''

        def write(self, s):
            self.buffer += s

    TestWritableStream.__subclasshook__.__module__ = 'testfakemodule'
    TestWritableStream.__module__ = 'testfakemodule'

    from . import stream_tools as __stream_tools
    __stream_tools.test_WritableStream_write()



# Generated at 2022-06-22 18:30:00.451507
# Unit test for function truncate
def test_truncate():
    assert truncate('123456', 6) == '123456'
    assert truncate('123456', 5) == '12345'
    assert truncate('123456', 4) == '123...'
    assert truncate('123456', 3) == '12...'
    assert truncate('123456', 2) == '1...'
    assert truncate('123456', 1) == '...'



# Generated at 2022-06-22 18:30:03.194328
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout, WritableStream)
    assert not issubclass(object, WritableStream)



# Generated at 2022-06-22 18:30:10.914368
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('foo bar') == 'foo bar'
    assert get_shortish_repr('foo\nbar') == 'foo\\nbar'
    assert get_shortish_repr('foo\r\nbar') == 'foo\\nbar'
    assert len(get_shortish_repr(
        'abcdefghijklmnopqrstuvwxyz0123456789',
        max_length=12
    )) == 12



# Generated at 2022-06-22 18:30:17.082968
# Unit test for function shitcode
def test_shitcode():
    s = 'abc'
    assert shitcode(s) == 'abc'
    assert shitcode(s.encode('utf-8')) == 'abc'
    assert shitcode(s.encode('utf-8')[:-1]) == 'ab?'
    assert shitcode(b'\xe2\x98\x83') == '\xe2\x98\x83'



# Generated at 2022-06-22 18:30:20.161336
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A:
        def write(self, s):
            return 'I got string %s' % s
    a = A()
    assert isinstance(a, WritableStream)



# Generated at 2022-06-22 18:30:23.964858
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 4) == '1234'
    assert truncate('123456789', 6) == '12...9'
    assert truncate('123456789', 15) == '123456789'
    assert truncate('123456789', None) == '123456789'

# Generated at 2022-06-22 18:30:35.414511
# Unit test for function get_repr_function
def test_get_repr_function():
    from .test_tools import test_equality

    class A(object): pass
    class B(object): pass
    class C(object): pass


    def my_repr(x): return 'my_repr'


# Generated at 2022-06-22 18:30:45.293414
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass
    b = B()
    assert (get_repr_function(0, ()) is None)
    assert (get_repr_function(1.5, ()) is None)
    assert (get_repr_function(b, ()) is None)
    assert get_repr_function(0, ((A, lambda: 'A')))(0) == '0'
    assert get_repr_function(0, ((0, lambda x: '0')))(0) == '0'
    assert get_repr_function(0, ((int, lambda x: '0')))(0) == '0'
    assert get_repr_function(0, ((int, lambda x: 'int')))(0) == 'int'

# Generated at 2022-06-22 18:30:49.902129
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1j, ()) == repr

# Generated at 2022-06-22 18:30:56.577390
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'hello.') == u'hello.'
    assert shitcode(u'\u20b9') == u'?'
    assert shitcode(u'\xe2\x82\xb9') == u'?'
    # Verifying for Python 2.7 and Python 3
    assert shitcode(b'\xe2\x82\xb9') == u'?'



# Generated at 2022-06-22 18:30:59.341636
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    with open(sys.executable) as f:
        def write_f(s):
            f.write(s)

        assert isinstance(f, WritableStream)
        assert isinstance(write_f, WritableStream)



# Generated at 2022-06-22 18:31:02.321628
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    def get_repr_function():
        def repr_function(x):
            if isinstance(x, int):
                return 'int({})'.format(x)

        return repr_function

    repr_function = get_repr_function()

    assert get_shortish_repr(1000000000000000, custom_repr=((int, repr_function),)) == 'int(1000000000000000)'
    assert get_shortish_repr(1, custom_repr=((int, repr_function),)) == '1'
    assert get_shortish_repr([10, 20, 30], custom_repr=((int, repr_function),)) == "[10, 20, 30]"



# Generated at 2022-06-22 18:31:13.415009
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(4) == '4'
    assert get_shortish_repr(4, max_length=3) == '4'
    assert get_shortish_repr('foo', max_length=3) == 'foo'
    assert get_shortish_repr('foobar', max_length=3) == '...'
    assert get_shortish_repr('foobar', max_length=4) == '...'
    assert get_shortish_repr('foobar', max_length=5) == 'f...r'
    assert get_shortish_repr('foobar', max_length=6) == 'fo...r'
    assert get_shortish_repr('foobar', max_length=7) == 'foo...r'

# Generated at 2022-06-22 18:31:16.100385
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class DummyWriter:
        def write(self, s):
            pass

    dummy_writer = DummyWriter()

    assert isinstance(dummy_writer, WritableStream)

# Generated at 2022-06-22 18:31:18.073784
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class ASet(WritableStream):
        def write(self, s):
            pass
    assert isinstance(set(), ASet)



# Generated at 2022-06-22 18:31:29.468082
# Unit test for function truncate

# Generated at 2022-06-22 18:31:36.124485
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import sys
    assert get_shortish_repr(sys.stdout.write,
                             max_length=100) == '<built-in method write of ' \
                                                'file object at ' \
                                                '0x'
    def custom_repr(x): return 'spam!'
    assert get_shortish_repr(3.14, custom_repr=((lambda x: isinstance(x, float), custom_repr),))
    assert get_shortish_repr(('a', 'b'), custom_repr=((lambda x: isinstance(x, (tuple, list)), custom_repr),))



# Generated at 2022-06-22 18:31:42.549919
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1.0) == '1.0'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=-1) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish

# Generated at 2022-06-22 18:31:45.510312
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0xabcd') == 'hello'

# Generated at 2022-06-22 18:31:51.996253
# Unit test for function normalize_repr
def test_normalize_repr():
    class Point:
        def __init__(self, x, y):
            self.x = x
            self.y = y
        def __repr__(self):
            return 'Point(%r, %r) at 0x%x' % (self.x, self.y, id(self))

    p = Point(1, 2)
    assert normalize_repr(p) == 'Point(1, 2)'
    assert normalize_repr(p) == 'Point(1, 2)'

# Generated at 2022-06-22 18:32:02.027520
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('bla') == 'bla'
    assert normalize_repr('bla at 0x1234') == 'bla'
    assert normalize_repr('bla at 0x1234 at 0x4321') == 'bla at 0x4321'
    assert normalize_repr('bla at 0x1234 at 0x4321 at 0x5678') == \
                                                 'bla at 0x4321 at 0x5678'
    assert normalize_repr('bla at 0x1234 at 0') == 'bla at 0'
    assert normalize_repr('bla at 0xabcd at 0') == 'bla at 0'
    assert normalize_repr('bla at 0xabcd') == 'bla'



# Generated at 2022-06-22 18:32:10.065051
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x108c0') == 'hello'
    assert normalize_repr('hello at 0xf01234567890') == 'hello'
    assert normalize_repr('hello\n    at 0x108c0') == 'hello\n    at 0x108c0'
    assert normalize_repr('hello\n\n    at 0x108c0') == 'hello\n\n    at 0x108c0'


# Generated at 2022-06-22 18:32:14.348865
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def write(self, s):
            return

    assert issubclass(A, WritableStream)



# Generated at 2022-06-22 18:32:23.366593
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('Ram') == 'Ram'
    assert shitcode('') == ''
    assert shitcode(u'Ram') == 'Ram'
    assert shitcode('ןדקמ') == '????'
    assert shitcode('\r\x1c\x15') == '\r??'
    assert shitcode('\r\n\x1c\x15') == '\r\n??'
    assert shitcode('\r\n\x1c\x15') == '\r\n??'
    assert shitcode('\x1c\x15') == '??'
    assert shitcode('\x1c') == '?'
    assert shitcode('\x15') == '?'
    assert shitcode('\x15\x1c\x15') == '???'

# Generated at 2022-06-22 18:32:29.553323
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("My string at 0x123") == "My string"
    assert normalize_repr("My string at 0x123456789") == "My string"
    assert normalize_repr("My string at 0x123456789 at 0x567") == "My string at 0x567"
    assert normalize_repr("My string") == "My string"
    assert normalize_repr("My string at 0x123 at 0x567") == "My string at 0x567"
    assert normalize_repr("My string at 0x123 at 0x567 at 0x3") == "My string at 0x567 at 0x3"

# Generated at 2022-06-22 18:32:33.453297
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple(0) == (0,)

    assert ensure_tuple((0, 1)) == (0, 1)

    assert ensure_tuple([0, 1]) == (0, 1)

# Generated at 2022-06-22 18:32:41.191328
# Unit test for function truncate
def test_truncate():
    assert truncate('', 10) == ''
    assert truncate('123456789', 10) == '123456789'
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('1234567890123', 10) == '1234567...123'
    assert truncate('123456789012345678901234567890', 30) == \
                                                  '123456789012345678901234567890'
    assert truncate('123456789012345678901234567890', 29) == \
                                                  '123456789012345678901234...90'

# Generated at 2022-06-22 18:32:45.017414
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritable(WritableStream):
        def write(self):
            pass

    class MyOtherWritable:
        def write(self):
            pass

    assert issubclass(MyWritable, WritableStream)
    assert not issubclass(MyOtherWritable, WritableStream)

# Generated at 2022-06-22 18:32:51.495633
# Unit test for function truncate
def test_truncate():

    def assert_truncate(original, max_length, expected_result):
        assert truncate(original, max_length) == expected_result

    assert_truncate(None, None,      None)
    assert_truncate('',    None,      '')
    assert_truncate('',     1,       '')
    assert_truncate('a',    None,     'a')
    assert_truncate('a',     0, '')
    assert_truncate('a',     1,  'a')
    assert_truncate('a',     2,  'a')
    assert_truncate('ab',    0, '')
    assert_truncate('ab',    1,  'a')
    assert_truncate('ab',    2,  'a')
    assert_tr

# Generated at 2022-06-22 18:32:56.732381
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert isinstance(ensure_tuple(1), tuple)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert isinstance(ensure_tuple([1, 2, 3]), tuple)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert isinstance(ensure_tuple((1, 2, 3)), tuple)

# Generated at 2022-06-22 18:33:08.893590
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(['hi', 'there'], max_length=7) == \
                                                              "['hi', 't']..."
    assert get_shortish_repr('hello world', max_length=7) == 'hello...'
    assert get_shortish_repr('hello world', max_length=8) == 'hello...'
    assert get_shortish_repr('hello world', max_length=12) == 'hello world'
    assert get_shortish_repr('hello world', max_length=11) == 'hello worl'
    assert get_shortish_repr('hello world', max_length=10) == 'hello wo'
    assert get_shortish_repr('hello world', max_length=9) == 'hello w'
    assert get_shortish_repr

# Generated at 2022-06-22 18:33:18.471100
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(123) == '123'
    assert get_shortish_repr(123, normalize=True) == '123'
    assert get_shortish_repr(object, normalize=True) == '<object object at 0x008BF8E0>'
    assert get_shortish_repr(object) == '<object object at 0x008BF8E0>'
    assert get_shortish_repr(123, (int, str), normalize=True) == '123'
    assert get_shortish_repr(123, (int, str)) == '123'
    assert get_shortish_repr(123, (lambda x: x == 1, str)) == '123'

# Generated at 2022-06-22 18:33:29.933095
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .asserts import assert_equal, assert_not_equal

    for arg in range(10):
        assert_equal(get_shortish_repr(arg), repr(int(arg)))

    for arg in range(10, 20):
        assert_equal(get_shortish_repr(arg, max_length=5),
                     truncate(repr(int(arg)), 5))

    class DummyClass(object):
        pass

    dc = DummyClass()

    assert_equal(get_shortish_repr(dc), repr(dc))

    def repr_function(obj):
        assert_equal(obj, dc)
        return '<DUMMY>'


# Generated at 2022-06-22 18:33:40.921361
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    def my_write_method(s):
        with open(r'c:\a.txt', 'wb') as f:
            f.write(s.encode('utf-8'))
    assert issubclass(int, WritableStream) is False
    assert issubclass(type(sys.stdout), WritableStream) is True
    assert issubclass(type(open('a.txt', 'wb')), WritableStream) is True
    assert issubclass(type(lambda: None), WritableStream) is False
    class X: write = lambda self, s: None
    assert issubclass(type(X()), WritableStream) is True
    class X: pass
    assert issubclass(type(X()), WritableStream) is NotImplemented
    assert issubclass(type(X), WritableStream) is Not

# Generated at 2022-06-22 18:33:43.848175
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class DefectStream(WritableStream):
        def write(self):
            pass

    class MyStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(MyStream(), WritableStream)
    assert not isinstance(DefectStream(), WritableStream)



# Generated at 2022-06-22 18:33:56.149490
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class A(object):
        def __init__(self):
            self.my_repr = lambda: 'The repr of A'
        def __repr__(self):
            return self.my_repr()

    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr('hello, world!') == 'hello, world!'
    assert get_shortish_repr('hello, world!', max_length=4) == 'hell...'
    assert get_shortish_repr('hello, world!', max_length=5) == 'hello...'

# Generated at 2022-06-22 18:34:03.947764
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyFileObject(object):
        def write(self, s):
            pass
    mfo = MyFileObject()
    assert isinstance(mfo, WritableStream)
    assert issubclass(MyFileObject, WritableStream)

    class MyStringObject(object):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s
    mso = MyStringObject()
    assert isinstance(mso, WritableStream)
    assert issubclass(MyStringObject, WritableStream)



# Generated at 2022-06-22 18:34:06.646914
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    
    


# Generated at 2022-06-22 18:34:12.373278
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'כדור') == u'????'
    assert shitcode(u'\u2318') == u'?'
    assert shitcode('\x01') == '?'
    assert shitcode('\u2318') == '?'


# Generated at 2022-06-22 18:34:23.816762
# Unit test for function truncate
def test_truncate():
    assert truncate('xyz', 3) == 'xyz'
    assert truncate('xyz', 2) == 'xyz'
    assert truncate('xyz', 1) == 'xyz'
    assert truncate('xyz', 0) == 'xyz'
    assert truncate('xyz', -1) == 'xyz'

    assert truncate('xyz', 4) == 'xyz'
    assert truncate('xyz', 5) == 'xyz'
    assert truncate('xyz', 6) == 'xyz'

    assert truncate('xyz', None) == 'xyz'
    assert truncate('xyz', 100000) == 'xyz'


    assert truncate('abcdefg', 5) == 'ab...g'
    assert truncate('abcdefg', 6) == 'ab...g'


# Generated at 2022-06-22 18:34:26.527942
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('haim') == ('haim',)
    assert ensure_tuple(['haim', 'moshe']) == ('haim', 'moshe')

# Generated at 2022-06-22 18:34:30.720868
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple(123) == (123,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)

# Generated at 2022-06-22 18:34:36.578051
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(u'1') == u'1'
    assert normalize_repr(u'a at 0x12AB') == u'a'
    assert normalize_repr(u'Ω at 0x12AB') == u'Ω'
    assert normalize_repr(u'aaaaaaaaaa at 0x123456789') == u'aaaaaaaaaa'


# Generated at 2022-06-22 18:34:40.453301
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(WritableStream):
        def write(self, s):
            pass
    assert isinstance(Foo(), WritableStream)
    assert isinstance(Foo(), WritableStream)

# Generated at 2022-06-22 18:34:48.506087
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C: pass
    assert get_repr_function(A(), [
        (lambda i: isinstance(i, A), lambda i: 'foo'),
    ])() == 'foo'
    assert get_repr_function(B(), [
        (lambda i: isinstance(i, A), lambda i: 'foo'),
        (B, lambda i: 'bar'),
    ])() == 'bar'
    assert get_repr_function(C(), [
        (lambda i: isinstance(i, A), lambda i: 'foo'),
        (B, lambda i: 'bar'),
    ])() == '<__main__.C object at 0x%s>' % hex(id(C()))



# Generated at 2022-06-22 18:34:58.341938
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    try:
        class T(WritableStream): pass
    except TypeError:
        pass
    else:
        assert False, 'The class `T` should not be allowed to miss `write`'
    try:
        class T(WritableStream):
            def write(self, s): pass
    except TypeError:
        pass
    else:
        assert False, 'The class `T` should not be allowed to have a write'

    class T(WritableStream):
        def write(self, s):
            pass

    try:
        T()
    except TypeError:
        pass
    else:
        assert False, 'The class `T` should not be allowed to miss `write`'

    class T(WritableStream):
        def write(self, s):
            pass

    t = T()


# Generated at 2022-06-22 18:35:02.022928
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def __init__(self):
            self.s = ''

        def write(self, s):
            self.s += s

    a = A()
    a.write('hi')
    assert a.s == 'hi'

# Generated at 2022-06-22 18:35:06.881125
# Unit test for function truncate
def test_truncate():
    assert truncate('abcd', None) == 'abcd'
    assert truncate('abcd', 5) == 'abcd'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 10) == 'abcdefg...vwxyz'





# Generated at 2022-06-22 18:35:18.096226
# Unit test for function get_repr_function
def test_get_repr_function():

    c1 = lambda x: isinstance(x, int)
    c2 = lambda x: isinstance(x, str)
    c3 = lambda x: True
    a1 = lambda x: ('Got int', x)
    a2 = lambda x: ('Got str', x)
    a3 = lambda x: ('Got something else', x)

    cr = (
        (c1, a1),
        (c2, a2),
        (c3, a3),
    )

    assert get_repr_function(3, cr) is a1
    assert get_repr_function('3', cr) is a2
    assert get_repr_function(3.0, cr) is a3
    assert get_repr_function(4j, cr) is a3


# Generated at 2022-06-22 18:35:27.617120
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello', max_length=2) == 'h...'
    assert get_shortish_repr('hello', max_length=3) == 'he...'
    assert get_shortish_repr('hello', max_length=4) == 'hel...'
    assert get_shortish_repr('hello', max_length=5) == 'hello'
    assert get_shortish_repr('hello', max_length=6) == 'hello'
    assert get_shortish_repr('hello', max_length=7) == 'hello'
    assert get_shortish_repr('hello', max_length=None) == 'hello'

    assert get_shortish_repr((1, 2, 3), max_length=8) == '(1, 2, 3)'

    assert get_

# Generated at 2022-06-22 18:35:29.630394
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class ReallyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert isinstance(ReallyWritableStream(), WritableStream)


# Generated at 2022-06-22 18:35:38.702362
# Unit test for function truncate
def test_truncate():
    def test(string, max_length, expected_result):
        assert truncate(string, max_length) == expected_result

    test('a' * 1000, 1000, 'a' * 1000)
    test('a' * 500, 1000, 'a' * 500)
    test('a' * 1000, 500, 'a' * 500 + '...')
    test('a' * 500, 500, 'a' * 500)
    test('a' * 500, 200, 'a' * 200 + '...')
    test('a' * 500, 199, '...')
    test('a' * 500, 3, '...')
    test('a' * 500, 2, '..')
    test('a' * 500, 1, '.')
    test('a' * 500, 0, '.')

# Generated at 2022-06-22 18:35:45.684836
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Writable(object):
        def write(self, s):
            pass

    assert WritableStream.__subclasshook__(Writable) is True

    class NotWritable(object):
        pass

    assert WritableStream.__subclasshook__(NotWritable) is NotImplemented

    class Writable2(Writable):
        def __init__(self):
            self.write = None

    assert WritableStream.__subclasshook__(Writable2) is NotImplemented

# Generated at 2022-06-22 18:35:50.953481
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'hello') == 'hello'
    assert shitcode(u'\xe8') == '?'
    assert shitcode(u'\u20ac') == '?'



# Generated at 2022-06-22 18:35:58.187419
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('5', max_length=5) == '5'
    assert get_shortish_repr('53123123123123', max_length=5) == '53...'
    assert get_shortish_repr('53123123123123', max_length=6) == '53...'
    assert get_shortish_repr('53123123123123', max_length=7) == '53...3'
    assert get_shortish_repr('53123123123123', max_length=8) == '53...3'
    assert get_shortish_repr('53123123123123', max_length=9) == '53123123'
    assert get_shortish_repr('53123123123123', max_length=10) == '53123123'
    assert get_