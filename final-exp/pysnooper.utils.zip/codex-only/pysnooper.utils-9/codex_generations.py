

# Generated at 2022-06-22 18:26:00.496307
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('\x00\x01\x02') == '\x00\x01\x02'
    assert shitcode('\xFF') == '\xFF'
    assert shitcode('\x01\x02\xF1') == '\x01\x02?\xF1?'
    assert shitcode('\x01\x02\xFF') == '\x01\x02\xFF'
    assert shitcode('\x01\x02\xFF\xF1') == '\x01\x02\xFF?\xF1?'



# Generated at 2022-06-22 18:26:07.804689
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0xABCD') == 'hello'
    assert normalize_repr('hello at 0xABCDACDA') == 'hello'
    assert normalize_repr('hello at 0xABCDACDAE') == 'hello'
    assert normalize_repr('hello at 0xABCDEFEF') == 'hello'
    assert normalize_repr('hello at 0xABCDEEFEF') == 'hello'
    assert normalize_repr('hello at 0xABCDEFEFE') == 'hello'



# Generated at 2022-06-22 18:26:10.377033
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:

        def write(self, s):
            pass

    assert isinstance(A(), WritableStream)



# Generated at 2022-06-22 18:26:20.023380
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import random
    for i in range(100):
        max_length = random.randint(5, 100)
        string = (''.join(
            chr(random.randint(0, 255)) for _ in range(100)
        ))
        assert len(truncate(string, max_length)) <= max_length
        a = tuple(random.randint(0, 1000) for _ in range(100))
        assert '...' in get_shortish_repr(a, max_length=70)
        assert '...' not in get_shortish_repr(a, max_length=1000)
        assert 'repr' in get_shortish_repr(
            set([get_shortish_repr]))



# Generated at 2022-06-22 18:26:25.748723
# Unit test for function truncate
def test_truncate():
    assert truncate('a' * 100, None) == 'a' * 100
    assert truncate('a' * 100, 200) == 'a' * 100
    assert truncate('a' * 100, 99) == 'a' * 99
    assert truncate('a' * 100, 3) == '...'
    assert truncate('a' * 100, 4) == 'a...'
    assert truncate('a' * 100, 5) == 'a...'
    assert truncate('a' * 100, 6) == 'aa...'
    assert truncate('a' * 100, 7) == 'aa...'
    assert truncate('a' * 100, 8) == 'aa...'
    assert truncate('a' * 100, 9) == 'aaa...'
    assert truncate('a' * 100, 10) == 'aaa...'

# Generated at 2022-06-22 18:26:30.483062
# Unit test for function normalize_repr
def test_normalize_repr():
    from .testing_tools import assert_equals, assert_false, assert_true
    assert_equals(normalize_repr('4'), '4')
    assert_equals(normalize_repr('4 at 0x2345'), '4')
    assert_equals(normalize_repr('4 at 0x2345678910'), '4')



# Generated at 2022-06-22 18:26:36.982972
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .state import State
    from .thread import Thread
    from .timing_wheel import TimingWheel

    class Foo(object):
        pass

    class Bar(object):
        pass

    foo = Foo()
    bar = Bar()

    import datetime
    datetime_now = datetime.datetime.now()

    def get_repr_function(item, custom_repr):
        for condition, action in custom_repr:
            if isinstance(condition, type):
                condition = lambda x, y=condition: isinstance(x, y)
            if condition(item):
                return action
        return repr

    assert(get_shortish_repr('short' * 30) == 'shortshortshortshortshortshortshortshortshortshortshortshortshortshortshortshortshortshortshortshortshortshortshortshortshortshortshortshortshort')


# Generated at 2022-06-22 18:26:40.987007
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)



# Generated at 2022-06-22 18:26:49.990120
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == "'hello'"
    assert (get_shortish_repr('hello') ==
            get_shortish_repr(ensure_tuple('hello')))
    assert get_shortish_repr('x' * 1000) == '{!r}...{!r}'.format('x' * 1000,
                                                                'x' * 992)
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1.5) == '1.5'
    assert (get_shortish_repr(1.5, max_length=1) ==
            get_shortish_repr(1.5, max_length=0))
    assert get_shortish_repr("12345678", max_length=3)

# Generated at 2022-06-22 18:27:00.130471
# Unit test for function truncate
def test_truncate():
    assert truncate(u'12345', 6) == u'12345'
    assert truncate(u'12345', 4) == u'12...5'
    assert truncate(u'12345', 5) == u'12...5'
    assert truncate(u'12345', 3) == u'123'
    assert truncate(u'123456789', 8) == u'123...89'
    assert truncate(u'123456789', 9) == u'123...789'
    assert truncate(u'123456789', 10) == u'123456789'
    assert truncate(u'123456789', 11) == u'123456789'

# Generated at 2022-06-22 18:27:01.987409
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyFile(WritableStream):
        def write(self, s):
            pass

# Generated at 2022-06-22 18:27:09.986226
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, shitcode),)) == shitcode
    assert get_repr_function(1, ((float, shitcode),)) != shitcode
    fucked_up_unicode = chr(0xD800)
    assert get_repr_function(fucked_up_unicode, (
        (lambda x: True, lambda x: x),
    )) == fucked_up_unicode

if __name__ == '__main__':
    test_get_repr_function()

# Generated at 2022-06-22 18:27:13.993250
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(set([1, 2])) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)

# Generated at 2022-06-22 18:27:24.100911
# Unit test for function normalize_repr
def test_normalize_repr():
    normalize_repr('asfd')
    normalize_repr('asfd at 0x10dabb0')
    normalize_repr('asfd at 0x10dabb0 at 0x10dabb0')
    normalize_repr('asfd at 0x00D00BABABABABABABAB0')
    normalize_repr('asfd at 0x00D00BABABABABABABAB0 at 0x00D00BABABABABABABAB0')
    normalize_repr('asfd at 0xD00BABABABABABABABAB0')
    normalize_repr('asfd at 0xD00BABABABABABABABAB0 at 0xD00BABABABABABABABAB0')



# Generated at 2022-06-22 18:27:31.563369
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', 5) == '12345...'
    assert truncate('1234567890', 11) == '1234567890'
    assert truncate('1234567890', None) == '1234567890'
    assert truncate('12345', 10) == '12345'
    assert truncate('', 1) == ''
    assert truncate('', None) == ''
    assert truncate('1234567890', 1) == '1...'
    assert truncate('1234567890', 0) == '...'
    assert truncate('1234567890', -1) == '...'
    assert truncate('1234567890', -2) == '...'
    assert truncate('1234567890', -3) == '...'
    assert truncate('1234567890', -4)

# Generated at 2022-06-22 18:27:37.494762
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: x == 1, float)]) is float
    assert get_repr_function(1.0, [(lambda x: x == 1, float)]) is float
    assert get_repr_function(2, [(lambda x: x == 1, float)]) is repr

# Generated at 2022-06-22 18:27:41.892517
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)

# Generated at 2022-06-22 18:27:46.071518
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\0abc') == 'abc?abc'
    assert shitcode('123' + chr(0) + '456') == '123?456'
    assert shitcode('123' + chr(255)) == '123?'



# Generated at 2022-06-22 18:27:56.068230
# Unit test for function get_repr_function
def test_get_repr_function():
    def custom_repr(x):
        return "custom repr"

    assert get_repr_function(3, ((int, custom_repr),)) is custom_repr
    assert get_repr_function(3.0, ((int, custom_repr),)) is not custom_repr
    assert get_repr_function(3.0, ((int, custom_repr), (float, custom_repr))) is custom_repr
    assert get_repr_function(3, ((float, custom_repr), (int, custom_repr))) is custom_repr
    assert get_repr_function(3, ((lambda x: x == 3, custom_repr),)) is custom_repr
    assert get_repr_function('hello', ((lambda x: x == 3, custom_repr),)) is not custom

# Generated at 2022-06-22 18:27:58.801789
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((3,)) == (3,)
    assert ensure_tuple([3]) == (3,)

# Generated at 2022-06-22 18:28:07.999769
# Unit test for function get_repr_function
def test_get_repr_function():
    class MockClass(object): pass
    class MockClass2(MockClass): pass
    class MockClass3(MockClass): pass

    def class_repr(x):
        return '{}({})'.format(x.__class__.__name__, repr(x.value))

    item = MockClass()
    item.value = 'foo'

    assert get_repr_function(item) == repr
    assert get_repr_function(item, [(MockClass, class_repr)]) == class_repr
    assert get_repr_function(item, [(MockClass2, class_repr)]) == repr
    assert get_repr_function(item, [(MockClass3, class_repr)]) == repr

# Generated at 2022-06-22 18:28:12.750257
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([4, 4, 5, 6]) == (4, 4, 5, 6)


if sys.version_info < (3, 3):
    from .backports.shutilwhich import which

    def which_multi(*args, **kwargs):
        return which(*args, **kwargs)

else:
    from shutil import which as which_multi

# Generated at 2022-06-22 18:28:23.396978
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(('a', 'b')) == "('a', 'b')"
    assert get_shortish_repr(('a', 'b'), max_length=5) == "('a', 'b')"
    assert get_shortish_repr(('a', 'b'), max_length=6) == "('a', 'b')"
    assert get_shortish_repr(('a', 'b'), max_length=7) == "('a', 'b')"
    assert get_shortish_repr(('a', 'b'), max_length=8) == "('a', 'b')"

# Generated at 2022-06-22 18:28:30.195734
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x9FDE') == 'hello'
    assert normalize_repr('hello at 0x9FDE at 0xBEEF') == 'hello'
    assert normalize_repr('hello at 0x9FDEat0xBEEF') == 'helloat0xBEEF'
    assert normalize_repr('hello at 0x9FDEat0xBEEF:') == 'helloat0xBEEF:'

# Generated at 2022-06-22 18:28:34.242922
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(WritableStream):
        def write(self, s):
            print(s)
    assert isinstance(Foo(), WritableStream)
    assert not isinstance(Foo(), type)



# Generated at 2022-06-22 18:28:37.968769
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'abcá') == u'abc?'
    assert shitcode(u'abc\n') == u'abc\n'
    assert shitcode(u'abcé') == u'abc?'
    assert shitcode('abcá') == u'abc?'
    assert shitcode('abc\n') == u'abc\n'
    assert shitcode('abcé') == u'abc?'



# Generated at 2022-06-22 18:28:40.617659
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple((5, 6)) == (5, 6)
    assert ensure_tuple(range(5)) == tuple(range(5))
    assert ensure_tuple(set('hello')) == ('e', 'l', 'o', 'h')



# Generated at 2022-06-22 18:28:52.679245
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, custom_repr=(
        (lambda x: x is None, lambda x: 'NONE'),
    ))('anything') == 'NONE'

    assert get_repr_function(None, custom_repr=(
        (lambda x: x is None, lambda x: 'NONE'),
        (lambda x: x is not None, lambda x: 'NOT_NONE'),
    ))('anything') == 'NONE'

    assert get_repr_function(object, custom_repr=(
        (lambda x: x is None, lambda x: 'NONE'),
        (lambda x: x is not None, lambda x: 'NOT_NONE'),
    ))('anything') == 'NOT_NONE'


# Generated at 2022-06-22 18:28:58.575567
# Unit test for function get_repr_function
def test_get_repr_function():

    def my_repr_function(x):
        return 'my_repr_function(%s)' % x


    assert get_repr_function(1, (tuple,)) == repr
    assert get_repr_function(tuple(), (tuple, my_repr_function)) == my_repr_function
    assert get_repr_function(tuple() + (1,), (tuple, my_repr_function)) == repr
    assert get_repr_function(1, (tuple, my_repr_function)) == repr



# Generated at 2022-06-22 18:29:07.444471
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', 5) == 'abc'
    assert truncate('abc', 2) == 'a...'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 4) == 'a...'
    assert truncate('abcde', 5) == 'a...e'
    assert truncate('abcde', 6) == 'abcde'
    assert truncate(u'אבגד', 5) == u'אב...'
    assert truncate(u'אבגד', 6) == u'אבגד'
    assert truncate(r'\r', 5) == r'\r'



# Generated at 2022-06-22 18:29:18.009587
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=20) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=-1) == '1'


    assert get_shortish_repr(1234, max_length=20) == '1234'

# Generated at 2022-06-22 18:29:20.172650
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('תוכניות') == '?????????'
    assert shitcode('abcde') == 'abcde'



# Generated at 2022-06-22 18:29:31.068423
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None, max_length=100) == 'None'
    assert get_shortish_repr(set(), max_length=100) == 'set()'
    assert get_shortish_repr('1234567890', max_length=100) == '1234567890'
    assert get_shortish_repr('1234567890', max_length=5) == '12...90'
    assert get_shortish_repr('1234567890', max_length=4) == '12...90'
    assert get_shortish_repr('1234567890', max_length=3) == '123...0'
    assert get_shortish_repr('1234567890', max_length=2) == '123...0'

# Generated at 2022-06-22 18:29:40.932804
# Unit test for function truncate
def test_truncate():

    assert truncate(1, None) == 1
    assert truncate(1, 0) == 1
    assert truncate(1, 1) == 1
    assert truncate(1, 2) == 1
    assert truncate(1, 3) == 1
    assert truncate(1, 4) == 1

    assert truncate('1', None) == '1'
    assert truncate('1', 0) == '1'
    assert truncate('1', 1) == '1'
    assert truncate('1', 2) == '1'
    assert truncate('1', 3) == '1'
    assert truncate('1', 4) == '1'

    assert truncate('12', None) == '12'
    assert truncate('12', 0) == '12'
    assert truncate('12', 1) == '12'
   

# Generated at 2022-06-22 18:29:46.162414
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple((TextIOWrapper,)) == (TextIOWrapper,)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('a') == ('a',)



# Generated at 2022-06-22 18:29:48.582132
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import io
    assert isinstance(io.IOBase(), WritableStream)
    assert isinstance(io.TextIOBase(), WritableStream)
    assert isinstance(io.StringIO(), WritableStream)  # `UnicodeIO` in 2.7



# Generated at 2022-06-22 18:29:54.257311
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class GoodClass1(WritableStream):
        def write(self, s):
            pass

    class GoodClass2(WritableStream):
        def write(self, s):
            return super(WritableStream, self).write(s)

    class BadClass1:
        def write(self, s):
            pass

    class BadClass2:
        def write(self, s):
            return super(WritableStream, self).write(s)

    assert issubclass(GoodClass1, WritableStream)
    assert issubclass(GoodClass2, WritableStream)

    assert not issubclass(BadClass1, WritableStream)
    assert not issubclass(BadClass2, WritableStream)

# Generated at 2022-06-22 18:30:01.033636
# Unit test for function shitcode

# Generated at 2022-06-22 18:30:07.454254
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(u'str') == u"u'str'"
    assert get_shortish_repr(u'str', max_length=10) == u"u'str'"
    assert get_shortish_repr(u'str', max_length=3) == u"u'st'"
    assert get_shortish_repr(u'str', max_length=2) == u"u's'"
    assert get_shortish_repr(u'str', max_length=1) == u"u''"
    assert get_shortish_repr(u'str', max_length=0) == u"u''"
    assert get_shortish_repr(u'str', max_length=None) == u"u'str'"

# Generated at 2022-06-22 18:30:15.980949
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abcdef') == 'abcdef'
    assert shitcode('abcdef\n') == 'abcdef\n'
    assert shitcode('abcdef\r') == 'abcdef\r'
    assert shitcode('abcdef\r\n') == 'abcdef\r\n'
    assert shitcode('\x00\x01\x02\x03\x04\x05\x06\x07') == '???????\x07'



# Generated at 2022-06-22 18:30:25.136848
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(0) == '0'
    assert get_shortish_repr(0.2) == '0.2'
    assert get_shortish_repr('spam') == "'spam'"
    assert get_shortish_repr([1, 2, 3], max_length=3) == '[1, 2...]'
    assert get_shortish_repr([1, 2, 3], max_length=5) == '[1, 2...]'
    assert get_shortish_repr([1, 2, 3], max_length=6) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=7) == '[1, 2, 3]'
    assert get

# Generated at 2022-06-22 18:30:36.726068
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class ReprObject():
        def __repr__(self):
            return '''
            <
            big
            repr
            >
            '''

    class CustomReprObject():
        def __repr__(self):
            return '''
            <
            big
            repr
            >
            '''
        def __nicerepr__(self):
            return 'nicer'

    assert get_shortish_repr('asdf') == 'asdf'
    assert get_shortish_repr('asdf', max_length=2) == 'as...'
    assert get_shortish_repr(ReprObject()) == '< big repr >'

# Generated at 2022-06-22 18:30:41.062665
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('aֿbc') == 'a?bc'
    assert shitcode(u'aֿbc') == 'a?bc'
    assert shitcode('\xe9') == '?'



# Generated at 2022-06-22 18:30:48.334858
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class _TestStream(WritableStream):
        def __init__(self):
            super(_TestStream, self).__init__()
            self.written_text = ''
        def write(self, s):
            self.written_text += s
    
    test_stream = _TestStream()
    assert isinstance(test_stream, WritableStream)
    test_stream.write('test')
    assert test_stream.written_text == 'test'
    
    try:
        class _TestStream2(WritableStream):
            def write(self, s):
                pass
    except TypeError:
        pass
    else:
        raise Exception
    
    try:
        class _TestStream3(WritableStream):
            pass
    except TypeError:
        pass
    else:
        raise Exception

# Generated at 2022-06-22 18:31:00.026834
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(0, custom_repr=((str, str),)) == str
    assert get_repr_function(0, custom_repr=((str, 'str'),)) == 'str'
    assert get_repr_function(0, custom_repr=((str, 'str'), (int, 'int'))) \
                                                              == 'int'
    assert get_repr_function(0, custom_repr=((str, 'str'), (float, 'float'))) \
                                                              == repr
    assert get_repr_function(
        'a', custom_repr=((str, 'str'), (int, 'int'), (float, 'float'))
    ) == 'str'

# Generated at 2022-06-22 18:31:06.218888
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class T():
        def write(self, x):
            pass
    t1 = T()
    assert(isinstance(t1, WritableStream))
    assert(WritableStream.__subclasshook__(T))
    assert(issubclass(T, WritableStream))



# Generated at 2022-06-22 18:31:15.439752
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    class TestClass(object):
        def __repr__(self):
            return '<TestClass object>'

    def custom_repr(x):
        return 'custom_repr'

    custom_reprs = (
        (lambda x: isinstance(x, TestClass), custom_repr),
    )

    assert get_shortish_repr(TestClass) == '<type \'TestClass\'>'
    assert get_shortish_repr(TestClass(), custom_reprs) == 'custom_repr'
    assert get_shortish_repr(34) == '34'
    assert get_shortish_repr((23, 4), max_length=7) == '(23, 4)'
    assert get_shortish_repr((23, 4), max_length=5) == '(23, 4)'

# Generated at 2022-06-22 18:31:21.677958
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object):
        pass
    class B(A):
        pass
    class C(object):
        pass
    assert get_repr_function(A(), ((A, lambda x: 'y')))() == 'y'
    assert get_repr_function(B(), ((A, lambda x: 'y')))() == 'y'
    assert get_repr_function(C(), ((A, lambda x: 'y')))() == repr(C())



# Generated at 2022-06-22 18:31:31.922896
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert normalize_repr('foo at 0x000000000') == 'foo'
    assert normalize_repr('foo') == 'foo'

    class X:
        def __str__(self):
            return 'x'

        def __repr__(self):
            return 'y'

    class Y(X): pass
    x = X()
    y = Y()

    assert get_repr_function('foo', ((str, lambda x: 'str'),))(x) == 'foo'
    assert get_repr_function('foo', ((str, lambda x: 'str'),))(y) == 'foo'
    assert get_repr_function(x, ((str, lambda x: 'str'),))(x) == 'str'
    assert get_repr_function(x, ((X, lambda x: 'x'),))

# Generated at 2022-06-22 18:31:35.704473
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class C(WritableStream):
        def write(self, s):
            pass

    assert isinstance(C(), WritableStream), (
        "Class `C` wasn't recognized as a subclass of `WritableStream`."
    )

# Generated at 2022-06-22 18:31:37.721570
# Unit test for function normalize_repr
def test_normalize_repr():
    from .test_tools.test_misc.test_misc_tools import test_normalize_repr as t
    t(normalize_repr)



# Generated at 2022-06-22 18:31:44.492470
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hi') == 'hi'
    assert normalize_repr('hi at 0xAB5A') == 'hi'
    assert normalize_repr('hi at 0xAB5A ') == 'hi at 0xAB5A '
    assert normalize_repr('hi at 0xAB5AAB5A') == 'hi'
    assert normalize_repr('') == ''



# Generated at 2022-06-22 18:31:48.685264
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(('a', 'b')) == ('a', 'b')
    assert ensure_tuple(('a',)) == ('a',)
    assert ensure_tuple(('a')) == ('a',)
    assert ensure_tuple('x') == ('x',)

# Generated at 2022-06-22 18:31:54.493363
# Unit test for function shitcode
def test_shitcode():

    def ensure_contains_only_ascii_characters(s):
        assert all(ord(c) < 256 for c in s)

    ensure_contains_only_ascii_characters(shitcode('Hello'))
    ensure_contains_only_ascii_characters(shitcode('Hellø'))
    ensure_contains_only_ascii_characters(shitcode('\x1d'))
    ensure_contains_only_ascii_characters(
        shitcode('\x1d' * 1000)
    )

# Generated at 2022-06-22 18:31:57.188870
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass

    assert issubclass(A, WritableStream)


# Generated at 2022-06-22 18:32:01.825255
# Unit test for function normalize_repr
def test_normalize_repr():
    item = 3
    source_repr = str(hex(id(item)))[2:]
    source_repr = ' at 0x' + source_repr.zfill(4 + (len(source_repr) - 4) % 5)
    target_repr = normalize_repr(hex(id(item)) + source_repr)
    assert target_repr == hex(id(item))

# Generated at 2022-06-22 18:32:06.726224
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(open(__file__, 'w'), WritableStream)
    assert issubclass(open(__file__, 'wb'), WritableStream)
    assert issubclass(sys.stdout, WritableStream)

# Generated at 2022-06-22 18:32:09.488895
# Unit test for function normalize_repr
def test_normalize_repr():
    from .contexts import FakeClass
    F = FakeClass()
    r = repr(F)
    assert r.startswith("tests.test_python_toolbox.FakeClass("), repr(r)
    assert normalize_repr(r) == "tests.test_python_toolbox.FakeClass("

# Generated at 2022-06-22 18:32:22.092900
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=1) == '...'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1, max_length=4) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'

    assert get_shortish_repr(12345, max_length=1) == '...'
    assert get_shortish_repr(12345, max_length=2) == '...'
    assert get_shortish_repr(12345, max_length=3) == '...'

# Generated at 2022-06-22 18:32:26.622495
# Unit test for function normalize_repr
def test_normalize_repr():
    import collections
    r = repr(collections.defaultdict(lambda: 'a', {'b': 'c'}))
    assert r == """defaultdict(<function <lambda> at 0x...>, {'b': 'c'})"""
    r = normalize_repr(r)
    assert r == """defaultdict(<function <lambda>...>, {'b': 'c'})"""



# Generated at 2022-06-22 18:32:38.004996
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('rabbits at 0x1234') == 'rabbits'
    assert normalize_repr('rabbits at 0x1234 and sheep at 0xABCD') == \
                                                           'rabbits and sheep'

    assert normalize_repr('rabbits at 0x123456789') == 'rabbits'
    assert normalize_repr('rabbits at 0x123456789ABCDE') == 'rabbits'

    assert normalize_repr('rabbits at 0x123456789 and sheep at 0xABCDE1234') == \
                                                    'rabbits and sheep'


# Generated at 2022-06-22 18:32:41.920456
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(WritableStream):
        def write(self, s):
            pass

    class Bar(object):
        def write(self, s):
            pass

    assert isinstance(Foo(), WritableStream)
    assert not isinstance(Bar(), WritableStream)

# Generated at 2022-06-22 18:32:45.133521
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    WritableStream.register(MyWritableStream)
    assert isinstance(MyWritableStream(), WritableStream)



# Generated at 2022-06-22 18:32:51.576932
# Unit test for function normalize_repr
def test_normalize_repr():
    from .six import reraise
    from .python_toolbox import cute_testing
    def _():
        assert normalize_repr('[]') == '[]'
        assert normalize_repr('[] at 0x12345678') == '[]'
        assert normalize_repr('foo at 0x12345678') == 'foo'
        assert normalize_repr('foo[] at 0x12345678') == 'foo[]'
        assert normalize_repr('foo[] at 0x12345678 at 0x12345679') == (
            'foo[] at 0x12345678'
        )
        assert normalize_repr('foo[] at 0x12345678 at 0x123456789') == (
            'foo[] at 0x12345678'
        )

# Generated at 2022-06-22 18:32:54.115966
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class X(WritableStream):
        def write(self, stuff):
            pass

    x = X()
    assert isinstance(x, WritableStream)



# Generated at 2022-06-22 18:33:01.578335
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import six
    class Spam(object):
        def __repr__(self):
            return '<eggs>'
    custom_repr = (
        (Spam, lambda x: '<spam>'),
    )
    normal_reprs = ('abc', 1, float('inf'))
    for r in normal_reprs:
        assert get_shortish_repr(r, custom_repr) == repr(r)

# Generated at 2022-06-22 18:33:08.371946
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', 3) == 'abc'
    assert truncate('abcde', 3) == 'abc'
    assert truncate('abcdef', 3) == 'abc'
    assert truncate('abcdefg', 3) == 'abc'
    assert truncate('abcdefgh', 3) == 'abc'
    assert truncate('abcdefghij', 3) == 'abc'



# Unit tests for function Shitcode

# Generated at 2022-06-22 18:33:18.165148
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(2, ((lambda x: x % 2, lambda x: x))) == (
        lambda x: x
    )
    assert get_repr_function(2, ((lambda x: x % 3, lambda x: x))) == repr
    assert get_repr_function(2, ((int, lambda x: x))) == (lambda x: x)
    assert get_repr_function('bla', ((str, lambda x: x))) == (lambda x: x)
    assert get_repr_function('bla', ((int, lambda x: x))) == repr
    assert get_repr_function(2.4, ()) == repr
    assert get_repr_function(2.4, ((lambda x: x > 2, lambda x: x)))

# Generated at 2022-06-22 18:33:29.932291
# Unit test for function get_repr_function
def test_get_repr_function():
    import pytest

    assert get_repr_function(None, custom_repr=((int, lambda x: 'int!'))) == \
                                                                         repr
    assert get_repr_function(None, custom_repr=((None, lambda x: 'int!'))) == \
                                                                         repr
    assert get_repr_function(None, custom_repr=((type(None),
                                                 lambda x: 'int!'))) == \
                                                                         repr
    assert get_repr_function(None, custom_repr=((lambda x: x is None,
                                                 lambda x: 'int!'))) == \
                                                          'int!'

# Generated at 2022-06-22 18:33:40.883971
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(object):
        def a(self):
            pass
    class B(object):
        def b(self):
            pass
    assert type(WritableStream.__subclasshook__(A)) == type(NotImplemented)
    assert type(WritableStream.__subclasshook__(B)) == type(NotImplemented)
    class C(object):
        def write(self, s):
            pass
    assert type(WritableStream.__subclasshook__(C)) == type(True)
    assert WritableStream.__subclasshook__(C)
    class D(C):
        pass
    assert type(WritableStream.__subclasshook__(D)) == type(True)
    assert WritableStream.__subclasshook__(D)

# Generated at 2022-06-22 18:33:44.593538
# Unit test for constructor of class WritableStream
def test_WritableStream(): # pragma: no cover
    class W(object):
        def write(self, s): pass
    assert isinstance(W(), WritableStream)
    class W(object):
        def write(self, s): pass
        def flush(self): pass
    assert isinstance(W(), WritableStream)
    class W(object):
        pass
    assert not isinstance(W(), WritableStream)




# Generated at 2022-06-22 18:33:46.856730
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, []) == repr

# Generated at 2022-06-22 18:33:50.203980
# Unit test for function normalize_repr
def test_normalize_repr():
    from .clonable import Clonable
    assert normalize_repr(repr(Clonable())) == 'Clonable()'



# Generated at 2022-06-22 18:34:01.807282
# Unit test for function normalize_repr
def test_normalize_repr():
    from .test_toolbox import TestCase
    from .classtools import TypedProperty

    class A(object):
        a_prop = TypedProperty('a_prop', int)

    class B(object):
        __repr__ = lambda self: 'B' * 40

    class C(object):
        __repr__ = lambda self: 'C'

        class CustomRepr(object):
            __repr__ = lambda self: 'CR'

        custom_repr = CustomRepr()


    class TestNormalizeRepr(TestCase):
        def test_default_repr(self):
            self.assertEqual(normalize_repr(A().__repr__()),
                             'A()')


# Generated at 2022-06-22 18:34:07.744884
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('abc') == 'abc'
    assert normalize_repr('abc at 0x01234567') == 'abc'
    assert normalize_repr('abc at 0x0123456789ABCDEF') == 'abc'


# `deepish_getsizeof` was copied from `getsizeof` from `guppy/heapy/heapyc.py`
#  by Will McGugan and Richard Jones; it was MIT-licensed.

# Generated at 2022-06-22 18:34:11.474334
# Unit test for function shitcode
def test_shitcode():
    """
    Test the `shitcode` function.

    The `shitcode` function is used to convert unicode text to ASCII text,
    by replacing non-ASCII characters with '?'.
    """

    # The Hebrew word for "Python"
    word = 'פיתון'

    assert shitcode(word) == '??????'

# Generated at 2022-06-22 18:34:22.244929
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hi at 0x1234') == 'hi'
    assert normalize_repr('hi at 0x12345678') == 'hi'
    assert normalize_repr('hi at 0x123456789') == 'hi'
    assert normalize_repr('hi at 0x1234567890') == 'hi'
    assert normalize_repr('hi at 0x123456789012345') == 'hi'
    assert normalize_repr('hi at 0x12345678901234567890') == 'hi'
    assert normalize_repr('hi') == 'hi'
    assert normalize_repr(r'hi at 0x1\nhi') == r'hi at 0x1\nhi'

# Generated at 2022-06-22 18:34:28.750527
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from nose_parameterized import parameterized

    def get_shortish_repr(item, custom_repr=(), max_length=None,
                          normalize=False):
        repr_function = get_repr_function(item, custom_repr)
        try:
            r = repr_function(item)
        except Exception:
            r = 'REPR FAILED'
        r = r.replace('\r', '').replace('\n', '')
        if normalize:
            r = normalize_repr(r)
        if max_length:
            r = truncate(r, max_length)
        return r


# Generated at 2022-06-22 18:34:36.293456
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = ((int, str),)
    assert get_repr_function(1, custom_repr) is str
    assert get_repr_function(None, custom_repr) is repr
    assert get_repr_function('meow', custom_repr) is repr
    custom_repr = ((str, str),)
    assert get_repr_function(1, custom_repr) is repr
    assert get_repr_function('meow', custom_repr) is str



# Generated at 2022-06-22 18:34:45.277375
# Unit test for function shitcode
def test_shitcode():
    def assert_shitcode(s, expected):
        assert shitcode(s) == expected
    assert_shitcode('hello', 'hello')
    assert_shitcode('he\nllo', 'he\nllo')
    assert_shitcode('\xe4', '?')
    assert_shitcode('\xe4\xbf', '??')
    assert_shitcode('\xe4\xbf\x9d', '???')
    assert_shitcode('\xe4\xbf\x9d\x9d', '????')
    assert_shitcode('\xe4\xbf\x9d\x9d\xe4\xbf\x9d', '??????')


from python_toolbox import math_tools



# Generated at 2022-06-22 18:34:55.444983
# Unit test for function shitcode
def test_shitcode():
    def test(s, expected_result):
        assert shitcode(s) == expected_result
    test('', '')
    test('a', 'a')
    test(u'abc', 'abc')
    test(u'\u0627\u062a\u0635', '???\u0635')
    test(u'\u0627\u062a\u0635\u0637\u0638', '?????\u0638')
    test(u'\xab\xac\xad', '\xab\xac\xad')
    test(u'\xab\xac\xad\xae\xaf', '\xab\xac\xad\xae\xaf')

# Generated at 2022-06-22 18:35:03.410143
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(['meow']) == ('meow',)
    assert ensure_tuple([]) == ()
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple((1, 'meow')) == (1, 'meow')



# todo: should also support ensuring we have an iterable of strings
if sys.version_info < (3,):
    def ensure_text(string):
        return string.decode('utf-8')
else:
    def ensure_text(string):
        return string


# Generated at 2022-06-22 18:35:15.063788
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    long_string = 'x' * 256
    assert (get_shortish_repr(long_string) ==
            truncate(long_string, max_length=None))

    assert (get_shortish_repr(long_string, max_length=None) ==
            truncate(long_string, max_length=None))

    assert (get_shortish_repr(long_string, max_length=256) ==
            truncate(long_string, max_length=256))

    assert (get_shortish_repr(long_string, max_length=255) ==
            truncate(long_string, max_length=255))

    assert (get_shortish_repr(long_string, max_length=50) ==
            truncate(long_string, max_length=50))


# Unit test

# Generated at 2022-06-22 18:35:18.720378
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(int, ()) is repr
    assert get_repr_function(3, ((int, repr),)) is repr
    assert get_repr_function(3, ((float, lambda x: 'a'), (int, repr))) is repr

# Generated at 2022-06-22 18:35:23.512506
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('a') == ('a',)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple(range(2)) == (0, 1)
    assert ensure_tuple(x for x in range(2)) == (0, 1)



# Generated at 2022-06-22 18:35:30.459075
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass
    class C(B): pass
    assert get_repr_function(A(), []) == repr
    assert get_repr_function(A(), [(B, str)]) == repr
    assert get_repr_function(B(), [(B, str)]) == str
    assert get_repr_function(C(), [(B, str)]) == str
    assert get_repr_function(A(), [(B, str), (A, lambda x: 'a')]) == repr

# Generated at 2022-06-22 18:35:39.295284
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .python_toolbox import cute_testing
    from .transcoding import to_str
    from .collections_tricks import (BadKey, BadValue)
    assert get_shortish_repr('hello') == 'hello'
    assert get_shortish_repr(b'hello') == 'b\'hello\''
    assert get_shortish_repr(2) == '2'
    assert get_shortish_repr(BadKey('hello', 0)) == 'BadKey(\'hello\', 0)'
    assert get_shortish_repr(BadValue(2, 0)) == 'BadValue(2, 0)'
    assert get_shortish_repr(BadKey('hello', 0), max_length=14) == \
                                                           'BadKey(\'hell...\''
    assert get_shortish_

# Generated at 2022-06-22 18:35:42.092175
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class TestClass(WritableStream):
        def write(self, s):
            return True

    assert TestClass is WritableStream



# Generated at 2022-06-22 18:35:46.906576
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class MyWritableStream(object):
        def write(self, s):
            pass

    my_writable_stream = MyWritableStream()

    assert isinstance(my_writable_stream, WritableStream)
    assert isinstance(sys.stdout, WritableStream)

    # We're not checking for TextIOBase because we want aything that can write
    # to work, not only strings



# Generated at 2022-06-22 18:35:52.307099
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('\x01\x02\x03') == '\x01\x02\x03'
    assert shitcode(u'') == u''
    assert shitcode(u'\U0001F638') == u'?'

