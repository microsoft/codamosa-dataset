

# Generated at 2022-06-22 18:25:59.047856
# Unit test for function truncate
def test_truncate():
    assert truncate('12345', 4) == '123...'
    assert truncate('12345', 5) == '12345'
    assert truncate('12345', 6) == '12345'
    assert truncate('12345', 1) == '...'
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
# Copied from Python's `reprlib`.
MAX_LENGTH = 100



# Generated at 2022-06-22 18:26:04.060246
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(('meow',)) == ('meow',)
    assert ensure_tuple(('meow', 1)) == ('meow', 1)
    assert ensure_tuple(('meow', 1, 'woof')) == ('meow', 1, 'woof')
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(None) == (None,)



# Generated at 2022-06-22 18:26:11.780845
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    a = A()
    b = B()
    assert get_repr_function(a, (
        (None, lambda x: '<A>'),
    )) == get_repr_function(a, (
        (lambda x: True, lambda x: '<A>'),
    )) == get_repr_function(a, (
        (type(a), lambda x: '<A>'),
    )) == '<A>'
    assert get_repr_function(a, (
        (A, lambda x: '<A>'),
    )) == '<A>'

# Generated at 2022-06-22 18:26:19.084460
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(1.2) == (1.2,)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(set([1, 2, 3])) == (1, 2, 3)
    assert ensure_tuple(range(3)) == (0, 1, 2)




# Generated at 2022-06-22 18:26:23.724588
# Unit test for constructor of class WritableStream
def test_WritableStream():
    def write(self, s):
        pass

    class A(object): pass
    A.write = write
    assert isinstance(A(), WritableStream)
    assert not isinstance(object(), WritableStream)



# Generated at 2022-06-22 18:26:27.289439
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(metaclass=ABCMeta):
        @abc.abstractmethod
        def write(self, s):
            pass
        @classmethod
        def __subclasshook__(cls, C):
            if cls is A:
                return _check_methods(C, 'write')
            return NotImplemented
    assert issubclass(WritableStream, A)

    class B:
        def write(self, s):
            pass
    assert issubclass(B, WritableStream)

# Generated at 2022-06-22 18:26:35.397090
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    x = {
        1: u'a',
        (1, 2): u'b',
        lambda x: x: u'c',
        u'\u05d0': u'\u05d1'
    }
    for y, z in x.items():
        assert get_shortish_repr(y, max_length=len(z) + 2) == z
        assert get_shortish_repr(y, max_length=len(z)) == z
        assert get_shortish_repr(y, max_length=len(z) - 2) == z[:-1]
        assert get_shortish_repr(y, max_length=1) == z[0]
        assert get_shortish_repr(y, max_length=0) == ''
        assert get_shortish_re

# Generated at 2022-06-22 18:26:46.787221
# Unit test for function shitcode
def test_shitcode():

    def test_case(real, expected_shitcoded):
        shitcoded = shitcode(real)
        assert shitcoded == expected_shitcoded
        assert isinstance(shitcoded, type(real))


    test_case('abc', 'abc')

    test_case(u'a\u05e9\u05d5\u05d0c', u'a\u05e9\u05d5\u05d0c')

    test_case(b'abc', b'abc')

    test_case(b'a\xe9\xfd\xd0c', b'a?c')

    test_case(b'a\xef\xbf\xbdc', b'a\xef\xbf\xbdc')


# Generated at 2022-06-22 18:26:53.165406
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'\u200e') == '?'
    assert shitcode(u'\u200d') == '?'
    assert shitcode(u'\u200f') == '?'
    assert shitcode(u'\u200b') == '?'
    assert shitcode(u'\u2062') == '?'
    assert shitcode(u'\u2060') == '?'
    assert shitcode(u'\uFFF9') == '?'
    assert shitcode(u'\uFFFA') == '?'
    assert shitcode(u'\uFFFB') == '?'
    assert shitcode(u'\uFFFC') == '?'
    assert shitcode(u'\uD800') == '?'
    assert shitcode(u'\uDBFF') == '?'

# Generated at 2022-06-22 18:27:03.097038
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklm', 13) == 'abcdefghijklm'
    assert truncate('abcdefghijklm', 12) == 'abcdefghijklm'
    assert truncate('abcdefghijklm', 11) == 'abcdefghijk...'
    assert truncate('abcdefghijklm', 10) == 'abcdefghi...'
    assert truncate('abcdefghijklm', 9) == 'abcdef...'
    assert truncate('abcdefghijklm', 8) == 'abcdef...'
    assert truncate('abcdefghijklm', 7) == 'abc...'
    assert truncate('abcdefghijklm', 6) == 'ab...'
    assert truncate('abcdefghijklm', 5) == 'a...'
    assert trunc

# Generated at 2022-06-22 18:27:12.667833
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 9) == '123456789'
    assert truncate('12345', 9) == '12345'
    assert truncate('12345', 5) == '12345'
    assert truncate('12345', 4) == '123...'
    assert truncate('12345', 3) == '12...'
    assert truncate('12345', 2) == '...'
    assert truncate('12345', 1) == '...'
    assert truncate('12345', 0) == '...'
    assert truncate('12345', -1) == '...'
    assert truncate('12345', None) == '12345'



# Generated at 2022-06-22 18:27:17.943702
# Unit test for function get_shortish_repr

# Generated at 2022-06-22 18:27:26.934997
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from six.moves import io
    from .pycompat import InMemoryTextIOWrapper

    class MyWritableStream(WritableStream):

        def write(self, s): pass

    S = MyWritableStream()

    assert isinstance(S, WritableStream)

    S.write('')
    S.write('a')
    S.write('a'*10)
    S.write(u'a')
    S.write(u'a'*10)

    assert isinstance(S, WritableStream)

    try:
        S.write(None)
        raise AssertionError("Didn't raise TypeError on `S.write(None)`")
    except TypeError:
        pass

    assert isinstance(io.StringIO(), WritableStream)



# Generated at 2022-06-22 18:27:28.852981
# Unit test for function ensure_tuple
def test_ensure_tuple():
    x = 5
    assert ensure_tuple(x) == (x,)
    x = (1, 2)
    assert ensure_tuple(x) == x
    x = [3, 4]
    assert ensure_tuple(x) == tuple(x)



# Generated at 2022-06-22 18:27:34.064783
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 5) == '123456789'
    assert truncate('123456789', 4) == '123456789'
    assert truncate('123456789', 6) == '123...89'
    assert truncate('123456789', 5) == '123...89'
    assert truncate('123456789', 4) == '123...89'
    assert truncate('123456789', 3) == '123...89'
    assert truncate('123456789', 2) == '123...89'
    assert truncate('123456789', 1) == '123...89'
    assert truncate('123456789', 0) == '123...89'
    assert truncate('123456789', -1) == '123...89'

# Generated at 2022-06-22 18:27:36.735424
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X:
        def write(self, s):
            return s + '!'
    x = X()
    assert isinstance(x, WritableStream)

# Generated at 2022-06-22 18:27:47.721686
# Unit test for function truncate
def test_truncate():
    assert truncate('', None) == ''
    assert truncate('', 100) == ''
    assert truncate('abcdef', None) == 'abcdef'
    assert truncate('abcdef', 8) == 'abcdef'
    assert truncate('abcdef', 7) == 'a...f'
    assert truncate('abcdef', 6) == 'a...f'
    assert truncate('abcdef', 5) == 'a...f'
    assert truncate('abcdef', 4) == 'a...f'
    assert truncate('abcdef', 3) == 'a...f'
    assert truncate('abcdef', 2) == 'a...'
    assert truncate('abcdef', 1) == 'a...'
    assert truncate('abcdef', 0) == ''

# Generated at 2022-06-22 18:27:53.610893
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(
        normalize_repr(
            '<_io.TextIOWrapper name=\'<stdout>\' mode=\'w\' encoding=\'UTF-8\' '
            'at 0x02C82CD8>'
        )
    ) == '<_io.TextIOWrapper name=\'<stdout>\' mode=\'w\' encoding=\'UTF-8\'>'



# Generated at 2022-06-22 18:27:55.995791
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)

# Generated at 2022-06-22 18:28:03.416114
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('potato at 0x123') == 'potato'
    assert normalize_repr('potato at 0x123123123') == 'potato'
    assert normalize_repr('potato at 0x123a') == 'potato'
    assert normalize_repr('potato') == 'potato'
    assert normalize_repr(' potat o') == ' potat o'
    assert normalize_repr('potato at 0x123a123123123123123123123123123123') == (
        'potato'
    )



# Generated at 2022-06-22 18:28:12.220286
# Unit test for function get_repr_function
def test_get_repr_function():
    from .python_toolbox import misc_tools
    from .python_toolbox import cute_testing
    from .python_toolbox import sequence_tools

    # `repr(x)` is the default repr:
    default_repr = lambda x: repr(x)

    assert get_repr_function(3, []) == default_repr
    assert get_repr_function('meow', []) == default_repr
    assert get_repr_function(misc_tools.misc_tools, []) == default_repr


# Generated at 2022-06-22 18:28:23.160866
# Unit test for function normalize_repr
def test_normalize_repr():
    DEFAULT_REPR = "CuteDog(name=u'Gillespie', breed=u'mixed')"
    NORMALIZED_REPR = "CuteDog(name=u'Gillespie', breed=u'mixed')"
    assert normalize_repr(DEFAULT_REPR) == NORMALIZED_REPR

    DEFAULT_REPR = "CuteDog(name=u'Gillespie', breed=u'mixed', \
at 0x7fc17d091c18>"
    NORMALIZED_REPR = "CuteDog(name=u'Gillespie', breed=u'mixed',"
    assert normalize_repr(DEFAULT_REPR) == NORMALIZED_REPR


# Generated at 2022-06-22 18:28:27.345821
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('meep') == ('meep',)
    assert ensure_tuple(['meep', 'moop']) == ('meep', 'moop')
    assert ensure_tuple(('meep', 'moop')) == ('meep', 'moop')

# Generated at 2022-06-22 18:28:35.088375
# Unit test for function get_repr_function
def test_get_repr_function():
    objects = [
        (list,),
        ([],),
        (dict,),
        ({},),
        (object,),
        (-1234,)
    ]
    assert (
        [get_repr_function(o, []) for o in objects] == [
            repr,
            repr,
            repr,
            repr,
            repr,
            repr
        ]
    )

    assert (
        [get_repr_function(o, [(list, lambda x: x)]) for o in objects] == [
            lambda x: x, list,
            repr,
            repr,
            repr,
            repr
        ]
    )


# Generated at 2022-06-22 18:28:42.683725
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('1234567890', 9) == '1234567890'
    assert truncate('1234567890', 8) == '12345678...'
    assert truncate('1234567890', 7) == '1234567...'
    assert truncate('1234567890', 6) == '123456...'
    assert truncate('1234567890', 5) == '1234...'
    assert truncate('1234567890', 4) == '123...'

# Generated at 2022-06-22 18:28:55.258187
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('Blah') == "'Blah'"
    assert get_shortish_repr('Blah', max_length=4) == "'Bla..."
    assert get_shortish_repr('\nBlah') == "'\\nBlah'"
    assert get_shortish_repr('\nBlah', max_length=4) == "'\\nB..."
    assert get_shortish_repr({}) == '{}'
    assert get_shortish_repr({}, max_length=4) == '{...'

# Generated at 2022-06-22 18:28:58.907325
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Test(WritableStream):

        def write(self, s):
            self.written = s

    Test().write('woohoo')



# Generated at 2022-06-22 18:29:00.241005
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Check:
        pass
    check = Check()
    try:
        check.write()
    except AttributeError:
        pass



# Generated at 2022-06-22 18:29:07.239862
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(object):
        def write(self, s): pass
    assert issubclass(A, WritableStream)

    class B(object): pass
    assert not issubclass(B, WritableStream)

    class C(object):
        def write(self, s): pass
    assert not issubclass(C, WritableStream)
    C.write = None
    assert issubclass(C, WritableStream)

# Generated at 2022-06-22 18:29:12.112718
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abcd') == 'abcd'
    assert shitcode(u'abcd') == 'abcd'
    assert shitcode(u'abæøåcd') == 'ab??cd'
    assert shitcode(u'ab\u00e6\u00f8\u00e5cd') == 'ab??cd'


# Unit tests for function truncate

# Generated at 2022-06-22 18:29:17.580179
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('asds at 0x23asdf') == 'asds'
    assert normalize_repr('asds at 0x23asdf and some more stuff') == 'asds and some more stuff'
    assert normalize_repr('asds at 0x23asdf and 0x23asdf') == 'asds and 0x23asdf'

# Generated at 2022-06-22 18:29:28.363369
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import pytest
    def r(x, **kwargs):
        return get_shortish_repr(x, **kwargs)
    assert r(3) == '3'
    assert r(3, max_length=2) == '3'
    assert r(3, max_length=1) == '...'
    assert r(3, max_length=0) == '...'
    assert r(3, max_length=None) == '3'
    assert r(1337, max_length=4) == '1...'
    assert r(1337, max_length=5) == '13...'
    assert r(1337, max_length=6) == '133...'
    assert r(1337, max_length=7) == '1337'

# Generated at 2022-06-22 18:29:37.491068
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr('abcdefghijklmn', max_length=5) == 'abcd...n'
    assert get_shortish_repr('abcdefghijklmn', max_length=6) == 'abcde...n'
    assert get_shortish_repr('abcdefghijklmn', max_length=7) == 'abcdef...n'
    assert get_shortish_repr('abcdefghijklmn', max_length=8) == 'abcdefg...n'
    assert get_shortish_repr('abcdefghijklmn', max_length=9) == 'abcdefghi...n'

# Generated at 2022-06-22 18:29:41.323544
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream:
        def write(self, s):
            pass
    assert isinstance(MyWritableStream(), WritableStream)



# Generated at 2022-06-22 18:29:47.542564
# Unit test for function truncate
def test_truncate():
    assert truncate('  abcdef  ', 3) == 'abcd...'
    assert truncate('a' * 100, 50) == 'a' * 50 + '...a' * 25
    assert truncate('a' * 100, 100) == 'a' * 100
    assert truncate('a' * 100, 101) == 'a' * 100
    assert truncate('a' * 100, None) == 'a' * 100



# Generated at 2022-06-22 18:29:51.120129
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class B(object):
        pass

    class C(WritableStream, B):
        def write(self, s):
            pass

    assert issubclass(C, WritableStream)

    c = C()
    assert isinstance(c, WritableStream)



# Generated at 2022-06-22 18:29:59.144163
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(12345, max_length=5) == '12345'
    assert get_shortish_repr(12345, max_length=4) == '1...5'
    assert get_shortish_repr(12345, max_length=3) == '...5'
    assert get_shortish_repr(12345, max_length=2) == ''
    assert get_shortish_repr(12345, max_length=1) == ''
    assert get_shortish_repr(12345, max_length=0) == ''
    assert get_shortish_repr(12345, max_length=None) == '12345'

    assert get_shortish_repr(123.0, max_length=5) == '123.0'
    assert get_short

# Generated at 2022-06-22 18:30:05.206261
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) == repr

# Generated at 2022-06-22 18:30:09.044932
# Unit test for function get_repr_function
def test_get_repr_function():

    def is_string(x):
        return isinstance(x, str)

    def to_upper(x):
        return x.upper()

    def to_lower(x):
        return x.lower()

    custom_repr = (
        (is_string, to_upper),
        (lambda x: is_string(x) and len(x) <= 5, to_lower),
    )

    my_list = ['foo', 'bar', 'baz', 123]
    assert get_repr_function(12, custom_repr) == repr
    assert get_repr_function('abcd', custom_repr) == to_upper

    assert get_shortish_repr(12, custom_repr) == '12'

# Generated at 2022-06-22 18:30:20.720638
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(r'test at 0x10') == r'test'
    assert normalize_repr(r'test at 0x10000000') == r'test'
    assert normalize_repr(r'test at 0x1abcdefg') == r'test'
    assert normalize_repr(r' test at 0x1abcdefg') == r' test'
    assert normalize_repr(r' test at 0x1abcdefg') == r' test'
    assert normalize_repr(r' test at 0x1abcdefg') == r' test'
    assert normalize_repr(r' test at 0x1abcdefg') == r' test'
    assert normalize_repr(r'test') == r'test'

# Generated at 2022-06-22 18:30:22.733279
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((2, 3)) == (2, 3)



# Generated at 2022-06-22 18:30:24.612468
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass


test_WritableStream()

# Generated at 2022-06-22 18:30:27.195991
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout.__class__, WritableStream)
    assert not issubclass(1, WritableStream)



# Generated at 2022-06-22 18:30:38.556334
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .testing import assert_equal

    # Testing defaults:
    assert_equal(get_shortish_repr(None), 'None')
    assert_equal(get_shortish_repr(1), '1')
    assert_equal(get_shortish_repr('hello'), "'hello'")
    assert_equal(get_shortish_repr('hello\nworld'), "'hello\\nworld'")
    assert_equal(get_shortish_repr(['hello world']), "['hello world']")

    # Testing max_length:
    assert_equal(get_shortish_repr(range(1, 1000), max_length=15),
                 'range(1, 1000)') # Didn't truncate, because repr is short.

# Generated at 2022-06-22 18:30:44.573930
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'hello') == u'hello'
    assert shitcode(u'hello\u00ff') == u'hello\u00ff'
    assert shitcode(u'hello\u0100') == u'hello?'
    assert shitcode(b'hello') == u'hello'
    assert shitcode(b'hello\xff') == u'hello\u00ff'
    assert shitcode(b'hello\x0100') == u'hello?'



# Generated at 2022-06-22 18:30:50.664870
# Unit test for function shitcode
def test_shitcode():
    def test_shitcode_of(string, result):
        assert shitcode(string) == result
    test_shitcode_of('hello שלום world', 'hello ? world')
    test_shitcode_of('I love €', 'I love ?')
    test_shitcode_of('שלום עולם', '???? ?')



# Generated at 2022-06-22 18:30:55.191740
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple('hi') == ('hi',)
    assert ensure_tuple(('hi',)) == ('hi',)





# Generated at 2022-06-22 18:31:02.691726
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1, max_length=100) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=-100) == ''

    assert get_shortish_repr('hello world!', max_length=100) == 'hello world!'
    assert get_shortish_repr('hello world!', max_length=0) == ''
    assert get_shortish_repr('hello world!', max_length=-100) == ''
    assert get_shortish_repr('hello world!', max_length=11) == 'hello world!'
    assert get_shortish_repr('hello world!', max_length=10) == 'hello wor'

# Generated at 2022-06-22 18:31:07.074356
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class CustomWritableStream(object):
        def __init__(self):
            pass
        def write(self, s):
            pass

    assert isinstance(CustomWritableStream(), WritableStream)



# Generated at 2022-06-22 18:31:11.597660
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(x for x in range(3)) == (0, 1, 2)



# Generated at 2022-06-22 18:31:15.089208
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('צלם בוקר אופניים') == '\x80\x81\x94 \x88\x93 \x85\x8f\x94\x91\x93\x80\x8f'



# Generated at 2022-06-22 18:31:26.104761
# Unit test for function normalize_repr
def test_normalize_repr():
    import pytest
    normal = normalize_repr
    assert normal('') == ''
    assert normal(' ') == ' '
    assert normal('a') == 'a'
    assert normal('ab') == 'ab'
    assert normal('a b') == 'a b'
    assert normal('a b c') == 'a b c'
    assert normal('a\nb\nc') == 'a\nb\nc'
    assert normal('a\nb\nc') == 'a\nb\nc'
    assert normal('a b at 0xAB') == 'a b'
    assert normal('a b at 0xA1B2') == 'a b'
    assert normal('a b at 0xFFFFFFFAB') == 'a b'
    assert normal('a b at 0xFFFFFFFA1B2') == 'a b'

# Generated at 2022-06-22 18:31:31.653481
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('a') == 'a'
    assert shitcode('ab') == 'ab'

# Generated at 2022-06-22 18:31:39.344119
# Unit test for function get_repr_function
def test_get_repr_function():
    my_list = [1, 2, 3]
    my_set = set(my_list)
    my_dict = dict(zip(my_list, my_list))
    my_tuple = (1, 2, 3)
    my_str = '123'
    my_int = 123
    nums = (my_list, my_set, my_dict, my_tuple, my_str, my_int)
    repr_functions = (
        get_repr_function(num, ((collections_abc.Sequence, list.__repr__),))
        for num in nums
    )

# Generated at 2022-06-22 18:31:42.165277
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-22 18:31:48.206561
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('spam at 0xFFFFFF') == 'spam'
    assert normalize_repr('spam at 0xF') == 'spam at 0xF'
    assert normalize_repr('spam at 0xFFFF') == 'spam at 0xFFFF'
    assert normalize_repr('spam at 0xFFFFF') == 'spam'

# Generated at 2022-06-22 18:31:50.998806
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00\x80b') == 'a?b'
    assert shitcode('\x00\xff') == '??'



# Generated at 2022-06-22 18:31:54.355171
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple((1,2,3)) == (1,2,3)
    assert ensure_tuple((1,2,3)) == (1,2,3)
    assert ensure_tuple(set([1,2,3])) == (1,2,3)


# Generated at 2022-06-22 18:31:58.218381
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            print(s)

    my_writable_stream = MyWritableStream()
    assert isinstance(my_writable_stream, WritableStream)



# Generated at 2022-06-22 18:32:05.782881
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnopqrstuvwxyz', max_length=26) == \
                                                  'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', max_length=25) == \
                                                'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', max_length=24) == \
                                              'abcdefghijklmnopqrstuvwxy...'
    assert truncate('abcdefghijklmnopqrstuvwxyz', max_length=23) == \
                                              'abcdefghijklmnopqrstuvwxy...'
    assert trunc

# Generated at 2022-06-22 18:32:13.129282
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import pytest
    from . import my_set

    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr('a', max_length=4) == 'a'
    assert get_shortish_repr('hello', max_length=4) == 'he...'
    assert get_shortish_repr(
        'hello',
        custom_repr=(
            (string_types, lambda x: 'abc{}abc'.format(len(x))),
        ),
        max_length=4,
    ) == 'abc5abc'
    assert get_shortish_repr(my_set.MySet(range(5)), max_length=5) == \
                                                               '{0, 1...'

# Generated at 2022-06-22 18:32:20.121418
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # Note that the `repr` of a `repr` is `repr`
    assert get_shortish_repr(repr) == '<built-in function repr>'

    assert get_shortish_repr(123, max_length=10) == '123'
    assert get_shortish_repr(123, max_length=3) == '123'
    assert get_shortish_repr(123, max_length=2) == '1...'
    asser

# Generated at 2022-06-22 18:32:23.137025
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class Stream:

        def write(self, s):
            pass

    Stream()

    assert issubclass(Stream, WritableStream)



# Generated at 2022-06-22 18:32:25.908755
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestWritableStream(WritableStream):
        def __init__(self):
            self.written = ''
        def write(self, s):
            self.written += s

    TestWritableStream().write('meow')




# Generated at 2022-06-22 18:32:28.852868
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout, WritableStream)
    assert issubclass(sys.stderr, WritableStream)
    assert issubclass(sys.stdin, WritableStream)
    assert 'stdout'.encode('utf-8') in WritableStream.__subclasscheck__(sys.stdout)

# Generated at 2022-06-22 18:32:31.152414
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestStream(WritableStream):
        def write(self, s):
            pass
    assert isinstance(TestStream(), WritableStream)



# Generated at 2022-06-22 18:32:42.826167
# Unit test for function normalize_repr
def test_normalize_repr():
    from .pycompat import int_types
    max_len = 20
    repr_str = 'test repr'
    repr_int = max_len * 2
    repr_list = [0] * max_len
    repr_re = DEFAULT_REPR_RE
    repr_r = repr_list + [repr_list]
    repr_t = tuple(repr_r)
    repr_set = set(repr_r)
    repr_dict = {i: j for i, j in zip(repr_r, repr_r)}
    repr_frozenset = frozenset(repr_r)

    import types
    repr_types_dict = {}

# Generated at 2022-06-22 18:32:53.528024
# Unit test for function get_repr_function
def test_get_repr_function():

    class C(object):
        pass

    class D(C):
        pass

    class E(object):
        pass

    assert get_repr_function(1, custom_repr=[(int, 'lol'), (C, 'rofl')]) is repr
    assert get_repr_function(C(), custom_repr=[(int, 'lol'), (C, 'rofl')]) == 'rofl'
    assert get_repr_function(D(), custom_repr=[(int, 'lol'), (C, 'rofl')]) == 'rofl'
    assert get_repr_function(E(), custom_repr=[(int, 'lol'), (C, 'rofl')]) is repr

    assert get_repr_function(E, custom_repr=[(type, 'rofl')]) == 'rofl'
   

# Generated at 2022-06-22 18:32:58.444398
# Unit test for function ensure_tuple
def test_ensure_tuple():
    
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(set([1, 2, 3])) == (1, 2, 3)

# Generated at 2022-06-22 18:33:09.961954
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class C(A): pass
    class D(B, C): pass

    def str_repr(x, s=str):
        return s(x)

    def int_repr(x, i=int):
        return i(x)

    def complex_repr(x, c=complex):
        return c(x)

    assert get_repr_function(D(), [(D, str_repr), (str, int_repr)]) is str_repr
    assert get_repr_function(1, [(D, str_repr), (str, int_repr)]) is int_repr
    assert get_repr_function('a', [(D, str_repr), (str, int_repr)]) is str_repr
    assert get_

# Generated at 2022-06-22 18:33:15.464460
# Unit test for function normalize_repr
def test_normalize_repr():
    """
    >>> test_normalize_repr()
    assert 'C' == 'C'
    """
    assert "class C at 0x0000" == normalize_repr("class C at 0x0000012345")
    assert "class D" == normalize_repr("class D")


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 18:33:18.096213
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(WritableStream):
        def __init__(self):
            pass

        def write(self, s):
            pass

    foo = Foo()
    assert isinstance(foo, WritableStream)



# Generated at 2022-06-22 18:33:24.483172
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'') == ''
    assert shitcode(u'hello') == 'hello'
    assert shitcode(u'hello' + chr(20)) == 'hello?'
    assert shitcode(u'hello' + chr(0)) == 'hello?'
    assert shitcode(u'hello' + chr(255)) == 'hello?'
    assert shitcode(u'hello' + chr(256)) == 'hello?'





# Generated at 2022-06-22 18:33:32.255316
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A:
        def write(self, s):
            pass

    assert isinstance(A(), WritableStream)

    class B:
        pass

    assert not isinstance(B(), WritableStream)

    class C:
        pass

    assert isinstance(C(), WritableStream)

    class D:
        def write(self, s):
            pass

        def flush(self):
            pass

    assert isinstance(D(), WritableStream)

    class E:
        def flush(self):
            pass

    assert not isinstance(E(), WritableStream)



# Generated at 2022-06-22 18:33:40.689747
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('להיות') == '?' * len('להיות')
    assert shitcode('שלום עולם') == '?' * len('שלום עולם')
    assert shitcode('hello world') == 'hello world'
    assert shitcode('בגדדהוזחטיךכלםמןנסעףפץצקרשת') == '????????????????????????'
    assert shitcode('') == ''



# Generated at 2022-06-22 18:33:44.656677
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', 6) == 'hello'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 4) == 'he...'
    assert truncate('hello', 3) == 'h...'
    assert truncate('hello', 2) == 'h...'
    assert truncate('hello', 1) == '...'
    assert truncate('hello', 0) == '...'



# Generated at 2022-06-22 18:33:50.504465
# Unit test for function ensure_tuple
def test_ensure_tuple():
    x = 1
    assert ensure_tuple(x) == (x,)
    assert ensure_tuple((x,)) == (x,)
    assert ensure_tuple([x]) == (x,)
    assert ensure_tuple("y") == ("y",)
    assert ensure_tuple("y") == ("y",)

# Generated at 2022-06-22 18:33:59.317062
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('foobar') == 'foobar'
    assert normalize_repr('foo at 0x4CAFBAR') == 'foo'
    assert normalize_repr(
        'foo at 0x4CAFBAR, bar at 0x5CAFBAR') == 'foo, bar'


if __name__ == '__main__':
    normalize_repr('foobar')
    normalize_repr('foo at 0x4CAFBAR')
    normalize_repr(
        'foo at 0x4CAFBAR, bar at 0x5CAFBAR')
    print('`normalize_repr` looks good.')

# Generated at 2022-06-22 18:34:08.311840
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=-1) == ''
    assert get_shortish_repr(1, max_length=None) == '1'

    assert get_shortish_repr('hi', max_length=2) == 'hi'
    assert get_shortish_repr('hi', max_length=1) == 'h'
    assert get_shortish_repr('hi', max_length=0) == ''
    assert get_

# Generated at 2022-06-22 18:34:13.862640
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class DevNull(object):
        def write(self, s):
            pass

    assert isinstance(DevNull(), WritableStream)


    class FileObject(object):
        def __init__(self):
            self.stringio = sys.stdout

        def write(self, s):
            self.stringio.write(s)

    assert isinstance(FileObject(), WritableStream)

# Generated at 2022-06-22 18:34:21.509395
# Unit test for function get_repr_function
def test_get_repr_function():

    def my_repr(x):
        if isinstance(x, str):
            return x[::-1]
        else:
            return None

    for item in (1, 'x', {'x': 4}, set('xyz')):
        assert get_repr_function(item, ((str, my_repr),))(item) == \
                                                            item[::-1]
    assert get_repr_function(1, ((str, my_repr),))(1) is None

# Generated at 2022-06-22 18:34:26.693865
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(1) == '1'

    assert get_shortish_repr(object) == '<class \'object\'>'
    assert get_shortish_repr(object()) == '<object object at 0x.........>'

    assert get_shortish_repr(1, custom_repr=[(int, str)]) == '1'
    assert get_shortish_repr(1, custom_repr=[(int, lambda z: z + 1)]) == '2'



# Generated at 2022-06-22 18:34:37.200636
# Unit test for function normalize_repr
def test_normalize_repr():
    class Foo:
        def __init__(self, a):
            self.a = a

    f = Foo(3)
    repr_ = repr(f)
    original_repr = repr_
    assert repr_ == original_repr
    repr_ = repr_.replace('<','').replace('>','')

    normalized_repr = normalize_repr(original_repr)
    assert repr_ == normalized_repr

    s = '    '
    assert normalize_repr(s + original_repr[0]) == s + repr_[0]
    assert normalize_repr(s + original_repr[0]) == s + normalized_repr[0]

# Generated at 2022-06-22 18:34:46.081582
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('a') == 'a'
    assert shitcode('ab') == 'ab'
    assert shitcode('abcd') == 'abcd'
    assert shitcode('abxcd') == 'ab?cd'
    assert shitcode('ab\x00cd') == 'ab?cd'
    assert shitcode('ab\x00\x01cd') == 'ab??cd'
    assert shitcode('ab\xFF\x00cd') == 'ab??cd'
    assert shitcode('abc\xFF\x00d') == 'abc??d'
    assert shitcode('ab%c' % 255) == 'ab?'



# Generated at 2022-06-22 18:34:51.492882
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class WritableStreamSubclass(WritableStream):
        def __init__(self):
            self.string_written_to = ''
        def write(self, string):
            self.string_written_to += string

    s = WritableStreamSubclass()
    s.write('spam')
    assert s.string_written_to == 'spam'



# Generated at 2022-06-22 18:35:00.222525
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import numbers
    import collections.abc
    class A(object):
        def __repr__(self):
            return 'r' * 1000
    a = A()
    assert get_shortish_repr(a, max_length=3) == 'r' * 3
    assert get_shortish_repr(a, max_length=10) == 'r' * 10
    assert get_shortish_repr(a, max_length=1000) == 'r' * 1000
    #
    assert get_shortish_repr(a, max_length=1001) == 'r' * 1000
    #
    assert get_shortish_repr(a, max_length=1100) == 'r' * 1000
    #
    assert get_shortish_repr(a, max_length=10000) == 'r' * 1000

# Generated at 2022-06-22 18:35:03.817969
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(object):
        @property
        def write(self):
            return None
    assert WritableStream.__subclasshook__(A) is NotImplemented
    class B(object):
        def write(self, s):
            pass
    assert WritableStream.__subclasshook__(B) is True
    assert issubclass(B, WritableStream)



# Generated at 2022-06-22 18:35:15.436944
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 2)]) == 2
    assert get_repr_function(1, [(lambda x: False, lambda x: 2)]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: 2),
                                 (lambda x: False, lambda x: 3)]) == repr
    assert get_repr_function(1, [(lambda x: True, lambda x: 2),
                                 (lambda x: False, lambda x: 3)]) == 2
    assert get_repr_function(1, [(lambda x: False, lambda x: 2),
                                 (lambda x: True, lambda x: 3)]) == 3

# Generated at 2022-06-22 18:35:26.356634
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from itertools import product
    import numpy
    l = [
        [1, '1'],
        [1, '1', 1],
        [1, '1', None],
        [1, '1', 1, None],
        [1, '1', None, None],
        [None, None],
        [1, None],
        [1, '1', 1, None, None],
        [1, '1', 1, 2, None, None],
        [1, '1', 1, 2, 3, None, None],
    ]
    for max_length, normalize in product(list(l) + [None], (True, False)):
        max_length = ensure_tuple(max_length)
        normalize = ensure_tuple(normalize)
        assert get_shortish_repr

# Generated at 2022-06-22 18:35:28.888315
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(1) == (1,)

# Generated at 2022-06-22 18:35:31.636082
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s): pass

    assert issubclass(MyWritableStream, WritableStream)
    assert MyWritableStream is WritableStream.__subclasscheck__(MyWritableStream)



# Generated at 2022-06-22 18:35:35.677818
# Unit test for function shitcode
def test_shitcode():
    for c in 'abc':
        assert shitcode(c) == c

    assert shitcode('\x00') == '?'
    assert shitcode('\xFF') == '?'

    assert shitcode(u'\u2603\u2603') == '??'



# Generated at 2022-06-22 18:35:45.480556
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, []) == repr
    assert get_repr_function(None, [(lambda x: True, 'foo')]) == 'foo'
    assert get_repr_function(None, [(lambda x: False, 'foo')]) == repr
    assert get_repr_function(None, [(lambda x: False, 'foo'),
                                    (lambda x: False, 'foo')]) == repr
    assert get_repr_function(None, [(lambda x: False, 'foo'),
                                    (lambda x: True, 'bar')]) == 'bar'

    assert get_repr_function(None, [(type(None), 'foo')]) == 'foo'
    assert get_repr_function(None, [((int, str), 'foo')]) == 'foo'
    assert get_repr_function

# Generated at 2022-06-22 18:35:56.944622
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x333337') == 'hello'
    assert normalize_repr('hello at 0x333337 dude') == 'hello at 0x333337 dude'
    assert normalize_repr('hello at 0x333337 at 0x333337 dude') == \
                                         'hello at 0x333337 at 0x333337 dude'
    assert normalize_repr('hello at 0x333337 dude at 0x333337') == \
                                          'hello at 0x333337 dude at 0x333337'
    assert normalize_repr('hello at 0x333337 and 0x333337 dude') == \
                                           'hello at 0x333337 and 0x333337 dude'