

# Generated at 2022-06-22 18:25:56.184726
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import io

    class SomeWritableStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(SomeWritableStream(), WritableStream)
    assert isinstance(io.StringIO(), WritableStream)
    assert not isinstance(io.BytesIO(), WritableStream)
    assert not isinstance(set(), WritableStream)
    assert sys.stdout
    assert isinstance(sys.stdout, WritableStream)

# Generated at 2022-06-22 18:26:02.950798
# Unit test for function get_repr_function
def test_get_repr_function():
    import datetime
    class A: pass
    class B(object): pass
    class C(A): pass
    class D(A): pass
    class E(B, A): pass
    class F(E, C, D): pass
    class G: pass
    class H(G): pass
    class I(H): pass

    def short(x):
        return getattr(x, 'name', '<'+x.__class__.__name__+'>')

    assert get_repr_function(A(), []) is repr
    assert get_repr_function(B(), []) is repr
    assert get_repr_function(C(), []) is repr
    assert get_repr_function(D(), []) is repr
    assert get_repr_function(E(), []) is repr
    assert get_repr

# Generated at 2022-06-22 18:26:10.866406
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(WritableStream): pass

    class SubclassABC(X):  # `X` is an ABC
        def write(self, s):
            pass

    class SubclassABC_Defer(X):  # `X` is an ABC
        def write(self, s):
            return 'Got %r' % (s,)

    class SubclassABC_Reject(X):  # `X` is an ABC
        def write(self, s):
            return super(SubclassABC_Reject, self).write(s)

    class SubclassABC_Failure(X):  # `X` is an ABC
        def write(self, s):
            return 1 / 0

    class SubclassABC_Success(X):  # `X` is an ABC
        def write(self, s):
            return True


# Generated at 2022-06-22 18:26:17.442991
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    from .contextlib_tools import SuppressStdoutAndStderr


    class WritableStreamSubclass(WritableStream):
        def __init__(self):
            self.buffer = io.StringIO()
        def write(self, s):
            return self.buffer.write(s)

    WS = WritableStreamSubclass
    ws = WS()
    ws.write('some text')
    assert ws.buffer.getvalue() == 'some text'
    assert isinstance(ws, WritableStream)




# Generated at 2022-06-22 18:26:20.831310
# Unit test for function truncate
def test_truncate():
    assert truncate('sdfsdfs', 8) == 'sdfsdfs'
    assert truncate('sdfsdfs', 5) == 'sdfs...'
    assert truncate('sdfsdfs', 4) == 'sdfs...'
    assert truncate('sdfsdfs', 3) == 'sdf...'
    assert truncate('sdfsdfs', 2) == 'sd...'
    assert truncate('sdfsdfs', 1) == 's...'



# Generated at 2022-06-22 18:26:31.107359
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(
        '<weakref.ref object at 0x7f1f4b1a03b0>'
    ) == '<weakref.ref object>'
    assert normalize_repr(
        '<weakref.ref object at  0x7f1f4b1a03b0>'
    ) == '<weakref.ref object>'
    assert normalize_repr(
        '<weakref.ref object at 0x7f1f4b1a03b0 >'
    ) == '<weakref.ref object>'
    assert normalize_repr(
        '<weakref.ref object at  0x7f1f4b1a03b0 >'
    ) == '<weakref.ref object>'

# Generated at 2022-06-22 18:26:35.424031
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(
        "class greeter at 0x7fc312c13f50"
    ) == "class greeter"
    assert normalize_repr(
        "class greeter at 0x7fc312c13f50\n"
        " |  Method resolution order:"
        " |      greeter"
        " |      object"
    ) == "class greeter\n |  Method resolution order:\n |      greeter\n |      object"



# Generated at 2022-06-22 18:26:40.798160
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('a\x00b\x00c') == 'a?b?c'
    assert shitcode(chr(256) + chr(0) + chr(10)) == '?\x00\n'



# Generated at 2022-06-22 18:26:47.609009
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .fake_file import FakeFile

    class MyStream(WritableStream):
        def __init__(self, stream=sys.stdout):
            self.stream = stream
        def write(self, s):
            self.stream.write('WRITING ' + s)
            return len(s)

    my_stream = MyStream(stream=FakeFile())

    my_stream.write('hi!')
    assert my_stream.stream.out == 'WRITING hi!'
    assert len(my_stream.stream.out) == 12

# Generated at 2022-06-22 18:26:56.667484
# Unit test for function truncate
def test_truncate():
    assert truncate('', 1) == ''
    assert truncate('', None) == ''
    assert truncate('a' * 10, 1) == 'a'
    assert truncate('a' * 10, None) == 'a' * 10
    assert truncate('a' * 10, 5) == 'a' * 5 + '...'
    assert truncate('a' * 10, 6) == 'a' * 3 + '...' + 'a' * 3
    assert truncate('a' * 10, 7) == 'a' * 3 + '...' + 'a' * 4


# Unit tests for function get_shortish_repr

# Generated at 2022-06-22 18:26:58.789000
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class FakeWritableStream(WritableStream):
        def write(self, s):
            pass
    assert isinstance(FakeWritableStream(), WritableStream)

# Generated at 2022-06-22 18:27:05.384526
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=[(int, str)]) == str
    assert get_repr_function(1.5, custom_repr=[(int, str)]) == repr
    assert get_repr_function(1, custom_repr=[(int, str), (float, float.hex)]) == str
    assert get_repr_function(1.5, custom_repr=[(int, str), (float, float.hex)]) == float.hex
    assert get_repr_function(1, custom_repr=[(lambda x: False, str)]) == repr

    def condition(x):
        return True
    condition.__name__ = 'condition'
    assert get_repr_function(1, (condition, str)) == str

# Generated at 2022-06-22 18:27:15.048286
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B: pass
    class B2(B): pass
    class C(A, B2): pass
    class D(C): pass
    class E(D): pass
    class F(E): pass

    repr_ = repr

    def repr__(item):
        return repr(item).replace('_', '')

    custom_repr = [
        (D, repr__),
        (int, lambda item: str(item) + 'i'),
        (C, repr__),
    ]
    assert get_repr_function(D(), custom_repr) is repr__
    assert get_repr_function(C(), custom_repr) is repr__
    assert get_repr_function(E(), custom_repr) is repr__

# Generated at 2022-06-22 18:27:20.447595
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('foo at 0x1001') == 'foo'
    assert normalize_repr('foo bar at 0x1001') == 'foo bar'
    assert normalize_repr('foo bar at 0x1001 at 0x1002') == 'foo bar'
    assert normalize_repr('foo bar at 0x1001 0x1002') == 'foo bar'

# Generated at 2022-06-22 18:27:28.808638
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    def test(assertion):
        try:
            assert assertion()
        except AssertionError:
            raise AssertionError('Assertion failed for item `%s`' % repr(item))


# Generated at 2022-06-22 18:27:32.132634
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class CustomStream(WritableStream):
        def write(self, s):
            pass

    CustomStream().write('bla')
    assert issubclass(CustomStream, WritableStream)



# Generated at 2022-06-22 18:27:34.853344
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello, עולם!') == 'hello, ??'



# Generated at 2022-06-22 18:27:42.695998
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', 10) == 'hello'
    assert truncate('hello', 7) == 'hello'
    assert truncate('hello', 6) == 'hello'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 4) == 'hell'
    assert truncate('hello', 3) == 'hel'
    assert truncate('hello', 2) == 'he'
    assert truncate('hello', 1) == 'h'
    assert truncate('hello', 0) == ''
    assert truncate('hello', -1) == ''



# Generated at 2022-06-22 18:27:45.109495
# Unit test for function get_repr_function
def test_get_repr_function():
    r = get_repr_function('hello')
    assert r('hello') == 'hello' and r(3) == '3'



# Generated at 2022-06-22 18:27:54.138344
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('ab\xe9\xefcd') == 'ab??cd'
    assert shitcode(b'ab\xe9\xefcd') == 'ab??cd'

    assert shitcode(u'\xe2\x82\xac') == u'\u20ac'
    assert shitcode(u'\xe2\x82\xac') == u'\u20ac'

    assert shitcode(b'\xe2\x82\xac') == u'\\xe2\\x82\\xac'
    assert shitcode(b'\xe2\x82\xac') == u'\\xe2\\x82\\xac'



# Generated at 2022-06-22 18:27:58.920612
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("<__main__.A object at 0x7f8f71c7d668>") == \
           "<__main__.A object>"
    assert normalize_repr("<__main__.B object at 0x11be16b90>") == \
           "<__main__.B object>"
    assert normalize_repr("<built-in function id>") == \
           "<built-in function id>"


if '__main__' == __name__:
    # Ensure the function `normalize_repr` works as intended
    test_normalize_repr()

# Generated at 2022-06-22 18:28:08.124026
# Unit test for function truncate
def test_truncate():
    assert truncate(None, 20) is None
    assert truncate('', 20) == ''
    assert truncate('abc', 20) == 'abc'
    assert truncate('abcdefghij', 20) == 'abcdefghij'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 20) == 'abcdefghij...xyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 30) == \
                                        'abcdefghij...stuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 100) == \
                                        'abcdefghij...stuvwxyz'

# Generated at 2022-06-22 18:28:15.099850
# Unit test for function get_repr_function
def test_get_repr_function():

    class a(object): pass
    class b(a): pass
    class c(object): pass

    def function1(x):
        return 'function1'

    def function2(x):
        return 'function2'

    def function3(x):
        return 'function3'

    custom_repr = [
        (a, function1),
        (b, function2)
    ]

    assert get_repr_function(a(), custom_repr) == function1
    assert get_repr_function(b(), custom_repr) == function2
    assert get_repr_function(c(), custom_repr) == repr

    # This is to test that after finding function1, it raises an exception and
    # returns the default repr

# Generated at 2022-06-22 18:28:19.669293
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple('a') == ('a',)
    assert ensure_tuple(['a']) == ('a',)

# Generated at 2022-06-22 18:28:29.482850
# Unit test for function truncate
def test_truncate():
    string = '1234567890'
    assert truncate(string, max_length=None) == string
    assert truncate(string, max_length=len(string)) == string
    assert truncate(string, max_length=len(string) + 1) == string
    assert truncate(string, max_length=len(string) - 1) == '1234567...'
    assert truncate(string, max_length=len(string) - 2) == '1234...'
    assert truncate(string, max_length=5) == '12...'
    assert truncate(string, max_length=4) == '1...'
    assert truncate(string, max_length=3) == '...'



if __name__ == '__main__':
    import pytest; pytest.main(__file__)

# Generated at 2022-06-22 18:28:35.346196
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(42, custom_repr=((int, str),)) == str
    assert get_repr_function(42.0, custom_repr=((int, str),)) == repr
    assert get_repr_function('42', custom_repr=((int, str),)) == repr
    assert get_repr_function(42, custom_repr=((lambda x: True, str),)) == str
    assert get_repr_function(42.0, custom_repr=((lambda x: True, str),)) == str
    assert get_repr_function('42', custom_repr=((lambda x: True, str),)) == str



# Generated at 2022-06-22 18:28:39.412517
# Unit test for function normalize_repr
def test_normalize_repr():
    class X(object):
        pass
    assert normalize_repr(repr(X())) == '<badwing.utils.terminal_utils.test_normalize_repr.<locals>.X object at ?>'



# Generated at 2022-06-22 18:28:47.250981
# Unit test for function truncate
def test_truncate():
    assert truncate(u'12345', 5) == u'12345'
    assert truncate(u'12345', 7) == u'12345'
    assert truncate(u'12345', 4) == u'123...'
    assert truncate(u'') == u''
    assert truncate(u'123', 0) == u'...'
    assert truncate(u'123', None) == u'123'
    assert truncate(u'', None) == u''
    assert truncate(u'123456789', 3) == u'1...9'

# Generated at 2022-06-22 18:28:54.591124
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: True, 9)]) == 9
    assert get_repr_function(1, [(lambda x: False, 9)]) == repr
    assert get_repr_function(1, [(lambda x: False, 9), (lambda x: True, 8)]) == 8
    assert get_repr_function(1, [(lambda x: False, 9), (lambda x: False, 8)]) == repr



# Generated at 2022-06-22 18:29:02.681945
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(
        4,
        [
            (lambda x: x % 2 == 0, lambda x: 'even'),
            (lambda x: x % 2 == 1, lambda x: 'odd'),
        ]
    ) is repr
    assert get_repr_function(
        6,
        [
            (lambda x: x % 2 == 0, lambda x: 'even'),
            (lambda x: x % 2 == 1, lambda x: 'odd'),
        ]
    )(6) == 'even'
    assert get_repr_function(
        7,
        [
            (lambda x: x % 2 == 0, lambda x: 'even'),
            (lambda x: x % 2 == 1, lambda x: 'odd'),
        ]
    )(7) == 'odd'
    assert get_repr

# Generated at 2022-06-22 18:29:12.021643
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def write(self, s):
            return s + 1

    assert issubclass(A, WritableStream)
    assert not issubclass(WritableStream, A)
    assert not issubclass(A, A)
    assert not issubclass(A(), WritableStream)
    assert not issubclass(A(), A)
    assert not issubclass(A(), A())

    class B(WritableStream):
        pass

    assert not issubclass(B, WritableStream)
    assert not issubclass(B(), WritableStream)

    class C(WritableStream):
        def write(self, s):
            return s + 1

        @classmethod
        def __subclasshook__(cls, C):
            if cls is WritableStream:
                return True
           

# Generated at 2022-06-22 18:29:19.066955
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class CowStream(WritableStream):
        def write(self, s):
            assert isinstance(s, str)
            if s == 'foo':
                return 'foo'
            else:
                raise ValueError("I'm a cow!")


    cow_stream = CowStream()
    assert cow_stream.write('foo') == 'foo'
    raised = False
    try:
        cow_stream.write('bar')
    except ValueError:
        raised = True
    assert raised




# Generated at 2022-06-22 18:29:22.794407
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStub(WritableStream):
        pass

    try:
        WritableStub()
    except TypeError:
        pass
    else:
        assert False, "Wrong behaviour: WritableStream should be abstract"



# Generated at 2022-06-22 18:29:26.310170
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(('a' * 1000) + 'b' * 1000, max_length=5) == \
                                                            'aaaaa...bbbbb'



# Generated at 2022-06-22 18:29:33.121624
# Unit test for function normalize_repr
def test_normalize_repr():
    import pytest
    assert normalize_repr('REPR at 0x123') == 'REPR'
    assert normalize_repr('REPR at 0x1234567890ab') == 'REPR'
    assert normalize_repr('REPR at 0x1234567890abcd') == 'REPR'
    assert normalize_repr('REPR at 0x1234567890') == 'REPR'
    assert normalize_repr('REPR at 0x123456789') == 'REPR at 0x123456789'



# Generated at 2022-06-22 18:29:42.075548
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(r'<object at 0x7f0d301e7f60>') == \
                                                         r'<object>'
    assert normalize_repr(r'<object at 0x7f0d301e7f60> with some more info') == \
                                                     r'<object> with some more info'
    assert normalize_repr(r'<object at 0x7f0d301e7f60 and at 0x7f0d301e7f60>') == \
                                                                r'<object>'
    assert normalize_repr(r'<object at 0x7f0d301e7f60 and at 0x7f0d301e7f60> with some more info') == \
                                                        r'<object> with some more info'

# Generated at 2022-06-22 18:29:51.245485
# Unit test for function truncate
def test_truncate():
    assert truncate('hi there', 4) == 'hi ...'
    assert truncate('hi there', 7) == 'hi ...re'
    assert truncate('hi there', 10) == 'hi there'
    assert truncate('hi there', 9) == 'hi ther...'
    assert truncate('hi there', 2) == 'hi...'
    assert truncate('hi there', 1) == '...'
    assert truncate('hi there', 9999) == 'hi there'
    assert truncate('hi there', None) == 'hi there'
    assert truncate(u'hi there', None) == u'hi there'
    assert truncate(str('hi there'), None) == str('hi there')

# Generated at 2022-06-22 18:29:53.889333
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)



# Generated at 2022-06-22 18:29:59.382165
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('ram', max_length=2) == 'ra...'
    assert get_shortish_repr('ram', max_length=3) == 'ram'
    assert get_shortish_repr('ram', max_length=4) == 'ram'
    assert get_shortish_repr('ram', max_length=5) == 'ram'
    assert get_shortish_repr('ram', max_length=None) == 'ram'
    assert get_shortish_repr('ram') == 'ram'



# Generated at 2022-06-22 18:30:02.133930
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', 10) == 'hello'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 4) == 'h...'




# Generated at 2022-06-22 18:30:07.496835
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(object):
        def write(self, s):
            print('Writing s="{}"'.format(shitcode(s)))
    assert issubclass(Foo, WritableStream)


if __name__ == '__main__':
    test_WritableStream_write()
    sys.stdin.read()

# Generated at 2022-06-22 18:30:14.431821
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(['meow']) == (['meow'],)
    assert ensure_tuple(('meow',)) == (('meow',),)

# Generated at 2022-06-22 18:30:23.950864
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None, custom_repr=[(type(None), shitcode)]) \
           == shitcode
    assert get_repr_function(None, custom_repr=[(type(1), shitcode)]) \
           != shitcode
    assert get_repr_function(None, custom_repr=[(lambda x: False, lambda x: x)]) \
           != shitcode
    assert get_repr_function(None, custom_repr=[(lambda x: True, lambda x: x)]) \
           != shitcode
    assert get_repr_function(None, custom_repr=[(lambda x: False, shitcode)]) \
           != shitcode
    assert get_repr_function(None, custom_repr=[(lambda x: True, shitcode)]) \
           == shitcode

# Generated at 2022-06-22 18:30:28.743342
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class StringHolder:
        def __init__(self, string):
            self.string = string
        def write(self, something):
            assert isinstance(something, str), repr(something)
            self.string += something
    sh = StringHolder('initial')
    assert isinstance(sh, WritableStream), repr(type(sh))
    sh.write('...')
    assert sh.string == 'initial...', repr(sh.string)
    class Unwriteable:
        pass
    u = Unwriteable()
    assert not isinstance(u, WritableStream), repr(type(u))

# Generated at 2022-06-22 18:30:39.667416
# Unit test for function shitcode

# Generated at 2022-06-22 18:30:45.014441
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import sys
    sys_stream = sys.stdout
    assert isinstance(sys_stream, WritableStream)
    class A(WritableStream):
        def write(self, s): pass
    a = A()
    assert isinstance(a, WritableStream)
    class B(WritableStream):
        def notwrite(self, s): pass
    b = B()
    assert not isinstance(b, WritableStream)

# Generated at 2022-06-22 18:30:52.791806
# Unit test for function truncate
def test_truncate():
    cases = [(('0123456789', 10), '0123456789'),
             (('0123456789', 3), '012...789'),
             (('0123456789', 1), '...'),
             (('0123456789', None), '0123456789'),
             (('0123456789', 0), '...'),
             (('0123456789', -1), '...'),
             ]
    assert all(truncate(x, y) == expected for (x, y), expected in cases)



# Generated at 2022-06-22 18:30:56.554895
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(('meow',)) == ('meow',)
    assert ensure_tuple(('meow', 'roar')) == ('meow', 'roar')
    assert ensure_tuple([]) == ()
    assert ensure_tuple(('meow', [], {'a': 1})) == ('meow', [], {'a': 1})
    assert ensure_tuple(None) == (None, )



# Generated at 2022-06-22 18:30:59.575058
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple({1, 2}) == (1, 2)
    assert ensure_tuple('a' * 10) == ('a' * 10,)

# Generated at 2022-06-22 18:31:06.762150
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple({'a': 'b'}) == ({'a': 'b'},)



# Generated at 2022-06-22 18:31:14.974653
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hi') == 'hi'
    assert normalize_repr('hi at 0x1234') == 'hi'
    assert normalize_repr('hi at 0x12345') == 'hi'
    assert normalize_repr('hi at 0x12345678') == 'hi'
    assert normalize_repr('hi at 0x12345678\n') == 'hi at 0x12345678'
    assert normalize_repr('hi at 0x12345678\n at 0x2345') == 'hi at 0x12345678'
    assert normalize_repr('hi at 0x1234567877') == 'hi at 0x1234567877'



# Generated at 2022-06-22 18:31:25.958634
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            pass

    class B:
        def write(self, s):
            pass

    class C(object):
        def write(self, s):
            pass


    class D(object):
        def write(self, s):
            pass

    class E(D):
        pass

    class F:
        def write(self, s):
            pass

    class G(F):
        pass

    class H:
        def write(self, s):
            pass

    class BadJ:
        pass

    class BadK(object):
        pass

    assert issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)
    assert issubclass(C, WritableStream)
    assert issubclass(D, WritableStream)


# Generated at 2022-06-22 18:31:29.014312
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(
        '<typing.ValuesView object at 0x7f907a59dba8>'
    ) == '<typing.ValuesView object>'
#

# Generated at 2022-06-22 18:31:33.946085
# Unit test for function normalize_repr
def test_normalize_repr():
    import pytest
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x1') == 'hello'
    assert normalize_repr('hello at 0x1234567890') == 'hello'
    assert normalize_repr('hello at 0x1234') == 'hello'



# Generated at 2022-06-22 18:31:39.367159
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abcdefg') == 'abcdefg'
    assert shitcode(u'abcdefg') == 'abcdefg'
    assert shitcode('\x85\xE5\xA5') == '???'
    assert shitcode(b'\x85\xE5\xA5') == '???'
    assert shitcode(b'\x85\xE5\xA5'.decode('cp437')) == '???'.decode('cp437')

# Generated at 2022-06-22 18:31:43.745821
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(iter((1, 2, 3))) == (1, 2, 3)
    assert ensure_tuple(5) == (5,)



# Generated at 2022-06-22 18:31:49.754421
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'בדיקה') == u'??????'
    assert shitcode('foo') == 'foo'
    assert shitcode(chr(0)) == '?'
    assert shitcode(chr(1)) == chr(1)
    assert shitcode(chr(255)) == chr(255)
    assert shitcode(chr(256)) == '?'



# Generated at 2022-06-22 18:31:56.544468
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(3) == '3'
    assert get_shortish_repr('hi there!') == "'hi there!'"
    assert get_shortish_repr(b'hi there!') == "b'hi there!'"
    assert get_shortish_repr(r'hi there!') == "'hi there!'"
    assert get_shortish_repr(u'hi there!') == "'hi there!'"

# Generated at 2022-06-22 18:31:59.629573
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('hello') == ('hello',)

# Generated at 2022-06-22 18:32:10.031551
# Unit test for function normalize_repr
def test_normalize_repr():
    point_repr = "point(x='1', y='1')"
    normalized_point_repr = "point(x='1', y='1')"
    assert normalize_repr(point_repr) == normalized_point_repr

    long_repr = "MyBigLongClassName(first_arg='1', second_arg='2', third_arg='3', fourth_arg='4') at 0xef1232"
    truncated_repr = "MyBigLongClassName(first_arg='1', second_arg='2', third_arg='3', fourth_arg='4')"
    assert normalize_repr(long_repr) == truncated_repr

# Generated at 2022-06-22 18:32:19.771325
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('a') == 'a'
    assert shitcode(u'\U0001F4A9') == '?'
    assert shitcode(chr(30)) == '?'
    assert shitcode(chr(13)) == '?'
    assert shitcode('abc\ndef') == 'abcdef'
    assert shitcode('abc\n\xFFdef') == 'abc?def'
    assert shitcode(chr(12)) == '?'
    assert shitcode('abc' + chr(12)) == 'abc?'

# Generated at 2022-06-22 18:32:27.852709
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: True, lambda x: 'hi')])() == 'hi'
    assert get_repr_function(1.0, [(lambda x: True, lambda x: 'hi')])() == 'hi'
    assert get_repr_function('yo', [(lambda x: True, lambda x: 'hi')])() == 'hi'
    class Han: pass
    class Shot: pass
    assert get_repr_function(Han(), [(Han, lambda x: 'hahaha')])() == 'hahaha'
    assert get_repr_function(Shot(), [(Han, lambda x: 'hahaha')])() == repr(Shot())

# Generated at 2022-06-22 18:32:31.428908
# Unit test for function truncate
def test_truncate():
    assert truncate(None, 10) is None
    assert truncate(1, 10) == 1
    assert truncate('hello', 10) == 'hello'
    assert truncate('hello', 3) == 'hel...'



# Generated at 2022-06-22 18:32:43.020088
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x1') == 'hello'
    assert normalize_repr('hello at 0x1A') == 'hello'
    assert normalize_repr('hello at 0xF1A') == 'hello'
    assert normalize_repr('hello at 0xF1AAAAAA') == 'hello'
    assert normalize_repr('hello at 0xF1AAAAAAXXX') == 'hello at 0xF1AAAAAAXXX'
    assert normalize_repr('hello at 0xF1AAAAAAAA') == 'hello'
    assert normalize_repr('hello at 0xF1A') == 'hello'
    assert normalize_repr('hello at 0xF1') == 'hello'
    assert normalize_repr

# Generated at 2022-06-22 18:32:53.900487
# Unit test for function truncate
def test_truncate():
    t = truncate
    assert t('hello', None) == 'hello'
    assert t('hello', 8) == 'hello'
    assert t('hello', 5) == 'hello'
    assert t('hello', 4) == 'h...'
    assert t('hello', 3) == 'h...'
    assert t('hello', 2) == 'h...'
    assert t('hello', 1) == '...'
    assert t('hello', 0) == '...'
    assert t('hell', 4) == 'hell'
    assert t('hell', 3) == 'h...'
    assert t('hell', 2) == 'h...'
    assert t('hell', 1) == '...'
    assert t('hell', 0) == '...'
    assert t('hell', 0) == '...'





# Generated at 2022-06-22 18:33:01.104084
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MockWritable(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MockWritable, WritableStream)
    assert isinstance(MockWritable(), WritableStream)

    class MockFail(WritableStream):
        def write(self, s):
            pass

        def __repr__(self):
            pass

    assert not issubclass(MockFail, WritableStream)
    assert not isinstance(MockFail(), WritableStream)

    class MockFail2(WritableStream):
        def write(self, s):
            pass

    assert not issubclass(MockFail2, WritableStream)
    assert not isinstance(MockFail2(), WritableStream)

# Generated at 2022-06-22 18:33:06.098119
# Unit test for function shitcode
def test_shitcode():
    def assert_shitcode(input_string, expected_output):
        assert shitcode(input_string) == expected_output
    assert_shitcode('hello world', 'hello world')
    assert_shitcode('hello\u263a world', 'hello? world')
    assert_shitcode('hello!\u263a world', 'hello!? world')
    assert_shitcode('hello\u263a! world', 'hello?! world')
    assert_shitcode('\u263ahello!\u263a world', '?hello!? world')
    assert_shitcode('\u263ahello!\u263a! world', '?hello!?! world')
    assert_shitcode('\u263ahello\u263a! world', '?hello?! world')

# Generated at 2022-06-22 18:33:13.055960
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            print('A', repr(s))
    class B:
        def write(self, s):
            print('B', repr(s))
    class C(WritableStream): pass
    class D(C): pass
    class E(C):
        def write(self, s):
            print('E', repr(s))

    for x in (A(), B(), C(), D(), E()):
        assert isinstance(x, WritableStream)

    class F: pass
    assert not isinstance(F(), WritableStream)

# Generated at 2022-06-22 18:33:19.984678
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class TestClass(WritableStream):
        def __init__(self):
            self.__test_list = []

        def write(self, line):
            self.__test_list.append(line)

        def get_list(self):
            return self.__test_list

    assert isinstance(TestClass(), WritableStream)
    assert not isinstance(object(), WritableStream)

    # Test a class that has an __init__ method
    class TestClass2(WritableStream):
        def write(self, line):
            pass

    assert isinstance(TestClass2(), WritableStream)



# Generated at 2022-06-22 18:33:29.190351
# Unit test for function normalize_repr
def test_normalize_repr():
    import pytest

    def prepare(item):
        return normalize_repr(get_shortish_repr(item, max_length=None))

    class Foo:
        pass

    assert prepare('hi') == 'hi'
    assert prepare(b'hi') == 'hi'

    f = Foo()
    assert prepare(f) == '<tests.common.Foo object at 0x'
    
    assert prepare(123) == '123'
    assert prepare(123.4) == '123.4'

    assert prepare(set('hi')) == "{'i', 'h'}"



# Generated at 2022-06-22 18:33:33.978614
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MockWritableStream(WritableStream):
        def write(self, s):
            assert isinstance(s, str)

    mock_writable_stream = MockWritableStream()

    mock_writable_stream.write('abc')

# Generated at 2022-06-22 18:33:38.622963
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(WritableStream):
        def write(self, s): pass

    assert isinstance(X(), WritableStream)

    try:
        class Y(WritableStream):
            def f(self): pass

        assert not isinstance(Y(), WritableStream)
    except TypeError:
        pass





# Generated at 2022-06-22 18:33:42.165187
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('a') == 'a'
    assert shitcode('a\r\nb') == 'a??b'
    assert shitcode('a\rb') == 'a?b'
    assert shitcode(u'a\u1234') == u'a?'
    assert shitcode('a\x01b') == 'a?b'



# Generated at 2022-06-22 18:33:53.911798
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('  str at 0x7ff4690d6888 ') == '  str  '
    assert normalize_repr('  str at 0x7ff4690d6888\n') == '  str\n'
    assert normalize_repr('  str at 0x7ff4690d6888 (') == '  str ('
    assert normalize_repr('  str at 0x7ff4690d6888 [') == '  str ['
    assert normalize_repr('  str at 0x7ff4690d6888 {') == '  str {'
    assert normalize_repr('  str at 0x7ff4690d6888 {') == '  str {'

# Generated at 2022-06-22 18:34:02.802667
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple(xrange(2)) == (0, 1)
    assert ensure_tuple(iter((1, 2))) == (1, 2)
    assert ensure_tuple(x for x in [1, 2]) == (1, 2)



# Generated at 2022-06-22 18:34:10.054479
# Unit test for function normalize_repr
def test_normalize_repr():
    from .python_toolbox.temp_value_setting import TempValueSetting

    class X(object):
        pass

    x = X()

    x_repr = repr(x)
    x_normalized_repr = normalize_repr(x_repr)

    assert x_repr != x_normalized_repr

    with TempValueSetting(sys, 'maxsize', sys.maxsize + 1):
        class Y(object):
            pass

        y = Y()

        y_repr = repr(y)
        y_normalized_repr = normalize_repr(y_repr)

        assert y_repr != y_normalized_repr

# Generated at 2022-06-22 18:34:14.795977
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(()) == ()
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([]) == ()


# Generated at 2022-06-22 18:34:17.526406
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class _(WritableStream):
        def write(self, s):
            pass
    _()



# Generated at 2022-06-22 18:34:27.588714
# Unit test for function normalize_repr
def test_normalize_repr():
    import builtins
    class X(object):
        pass


# Generated at 2022-06-22 18:34:38.823014
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (
        (lambda x: x == 2, repr),
        (lambda x: x == 3, lambda x: 'three'),
    )) is repr
    assert get_repr_function(1, (
        (lambda x: x == 2, repr),
        (lambda x: x == 3, lambda x: 'three'),
    )) is repr
    assert get_repr_function(1, (
        (lambda x: x > 2, repr),
        (lambda x: x == 3, lambda x: 'three'),
    )) is repr
    assert get_repr_function(1, (
        (lambda x: x > 2, repr),
        (lambda x: x == 3, lambda x: 'three'),
    )) is repr

# Generated at 2022-06-22 18:34:48.549662
# Unit test for function get_repr_function
def test_get_repr_function():
    def types_repr(item):
        return 'Types-repr'
    def repr_repr(item):
        return 'Repr-repr'
    custom_repr = (
        (type, types_repr),
        (lambda x: True, repr_repr),
    )
    assert get_repr_function(123, custom_repr) is types_repr
    assert get_repr_function(None, custom_repr) is types_repr
    assert get_repr_function({}, custom_repr) is types_repr
    assert get_repr_function([], custom_repr) is types_repr
    assert get_repr_function(lambda x: x, custom_repr) is types_repr
    assert get_repr_function('', custom_repr)

# Generated at 2022-06-22 18:34:58.409080
# Unit test for function get_repr_function
def test_get_repr_function():

    assert get_repr_function(1, custom_repr=()) == repr
    assert get_repr_function(1, custom_repr=((int, str),)) == str

    assert get_repr_function(1, custom_repr=((int, str),
                                             (lambda x: x > 2, int))) == str
    assert get_repr_function(3, custom_repr=((int, str),
                                             (lambda x: x > 2, int))) == int

    assert get_repr_function(1, custom_repr=((lambda x: x > 2, str),
                                             (int, int))) == int
    assert get_repr_function(3, custom_repr=((lambda x: x > 2, str),
                                             (int, int))) == str


#

# Generated at 2022-06-22 18:35:09.964852
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Naive implementation
    class MyWritableStream:
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)

    class AbstractWritableStream(WritableStream): pass

    # Can't instantiate abstract class
    with pytest.raises(TypeError):
        AbstractWritableStream()

    # Can instantiate subclass
    MyWritableStream()

    class MyWritableStream(WritableStream): pass

    # Fails because it's not a subclass of io.IOBase and doesn't implement
    # write()
    assert not issubclass(MyWritableStream, WritableStream)

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    # Success!
    assert issubclass(MyWritableStream, WritableStream)

# Generated at 2022-06-22 18:35:12.533568
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass
    assert WritableStream.__subclasshook__(WritableStreamSubclass)

# Generated at 2022-06-22 18:35:20.087111
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('ab\xe7') == 'ab?'
    assert shitcode('\xe9\x0a\x0d') == '?\n\r'
    assert shitcode('\u2200') == '?'
    assert shitcode('') == ''
    assert shitcode('ab\xe7def\xe9') == 'ab?def?'
    assert shitcode('\xe9\x0a\x0d\u2200') == '?\n\r?'



# Generated at 2022-06-22 18:35:24.216368
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('\x7f') == '\x7f'
    assert shitcode('\x80') == '?'
    assert shitcode('\xff') == '?'
    assert shitcode('abc\x80\x7f\xff') == 'abc\x7f??'

# Generated at 2022-06-22 18:35:27.806438
# Unit test for function ensure_tuple
def test_ensure_tuple():
    ensure_tuple_ = ensure_tuple
    assert ensure_tuple_(1) == (1,)
    assert ensure_tuple_((1, 2)) == (1, 2)
    assert ensure_tuple_([1, 2]) == (1, 2)

# Generated at 2022-06-22 18:35:34.604149
# Unit test for function truncate
def test_truncate():

    assert truncate('', 30) == ''
    assert truncate('', None) == ''
    assert truncate('x' * 30, 30) == 'x' * 30
    assert truncate('x' * 40, 30) == 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx...'
    assert truncate('x' * 40 + 'y' * 40, 80) == (
        'xxxxxxxxx...' + 'y' * 40
    )
    assert truncate('x' * 40 + 'y' * 40, 79) == (
        'xxxxxxxxx...' + 'y' * 38 + '...'
    )
    assert truncate('x' * 40 + 'y' * 40, 78) == (
        'xxxxxxxxx...' + 'y' * 38 + '...'
    )

# Generated at 2022-06-22 18:35:37.046434
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, hex), (str, len))) == hex
    assert get_repr_function('foo', ((int, hex), (str, len))) == len
    assert get_repr_function(3.4, ((int, hex), (str, len))) == repr



# Generated at 2022-06-22 18:35:42.882083
# Unit test for function normalize_repr
def test_normalize_repr():
    """
    Change the function _test_normalize_repr in order to test the function
    _normalize_repr.
    """
    assert normalize_repr('hello world') == 'hello world'
    assert normalize_repr('hello world at 0x123') == 'hello world'

if __name__ == '__main__':
    test_normalize_repr()

# Generated at 2022-06-22 18:35:47.633352
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamImpl(WritableStream):
        '''A writable stream that writes to `.result`.'''
        def __init__(self):
            self.result = ''

        def write(self, s):
            self.result += s

    writable_stream = WritableStreamImpl()
    writable_stream.write('abc')
    assert writable_stream.result == 'abc'



# Generated at 2022-06-22 18:35:51.048531
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStream(object):
        def write(self, s):
            pass

    assert isinstance(WritableStream(), WritableStream)

