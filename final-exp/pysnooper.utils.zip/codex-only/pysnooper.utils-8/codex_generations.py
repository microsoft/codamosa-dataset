

# Generated at 2022-06-22 18:25:54.946332
# Unit test for function shitcode
def test_shitcode():

    def assert_shitcode_works(s, s_standard):
        assert shitcode(s) == shitcode(s_standard)

    assert_shitcode_works(u'abcdefg', u'abcdefg')
    assert_shitcode_works(u'\u0411', '?')



# Generated at 2022-06-22 18:26:02.459429
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello') == u'hello'
    assert get_shortish_repr(u'hello') == u'hello'
    assert get_shortish_repr(u'hello', max_length=10) == u'hello'
    assert get_shortish_repr(u'hello', max_length=4) == u'hel...'
    assert get_shortish_repr(u'hello', max_length=5) == u'hello'
    assert get_shortish_repr(u'hello\nworld', max_length=10) == u'hello world'



# Generated at 2022-06-22 18:26:11.066218
# Unit test for function truncate
def test_truncate():
    assert truncate('', 0) == ''
    assert truncate('a', 0) == 'a'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 0) == \
                                                     'abcdefghijklmnopqrstuvwxyz'
    assert truncate('', 1) == ''
    assert truncate('a', 1) == 'a'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 1) == '...'
    assert truncate('', 2) == ''
    assert truncate('a', 2) == 'a'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 2) == '...'
    assert truncate('', 3) == ''
    assert truncate('a', 3) == 'a'


# Generated at 2022-06-22 18:26:21.552479
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hi') == "'hi'"
    assert get_shortish_repr(u'hi') == "'hi'"

    assert get_shortish_repr(u'b\u05d0') == "'b\\u05d0'"
    assert get_shortish_repr(u'b\u05d0'.encode('utf-8')) == \
                                                           "'b\\xe4\\xb8\\x80'"

    class C(object):
        def __repr__(self):
            return '<C>'
    assert get_shortish_repr(C()) == '<C>'
    assert get_shortish_repr(C(), max_length=2) == '<C>'
    assert get_shortish_repr(C(), max_length=3)

# Generated at 2022-06-22 18:26:31.761628
# Unit test for function get_repr_function
def test_get_repr_function():
    def repr_function(x):
        '''Docs'''

# Generated at 2022-06-22 18:26:36.418245
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 2) == 'ab'
    assert truncate('abc', 1) == 'a'
    assert truncate('abc', 0) == ''
    assert truncate('abcd', 3) == '...'
    assert truncate('abcd', 4) == 'a...'
    assert truncate('abcd', 5) == 'ab...'
    assert truncate('abcd', 6) == 'abc...'
    assert truncate('abcd', 7) == 'abcd'



# Generated at 2022-06-22 18:26:41.422472
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass

    assert issubclass(WritableStreamSubclass, WritableStream)

    class NotWritable:
        pass

    assert not issubclass(NotWritable, WritableStream)





# Generated at 2022-06-22 18:26:49.223405
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)


if sys.version_info[0] < 3:
    def cast_as_callable_if_possible(x):
        '''Cast a value to a callable if it is possible.'''
        if callable(x):
            return x
        else:
            return lambda: x
else:
    def cast_as_callable_if_possible(x):
        '''Cast a value to a callable if it is possible.'''
        if callable(x):
            return x
        else:
            return lambda: x



# Generated at 2022-06-22 18:26:51.846822
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(
        '<function at 0x0123456789ABCDEF>'
    ) == '<function>'
    assert normalize_repr(
        '<function at 0x0123456789ABCDEF>'
    ) == '<function>'



# Generated at 2022-06-22 18:26:56.459820
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(MyWritableStream(), WritableStream)
    assert not isinstance(MyWritableStream(), collections_abc.Iterable)



# Generated at 2022-06-22 18:27:04.412714
# Unit test for function truncate
def test_truncate():
    assert truncate('abcd', 8) == 'abcd'
    assert truncate('abcdefghijklmnop', 8) == 'abc...p'
    assert truncate('abcdefghijklmnopq', 8) == 'abc...q'
    assert truncate('abcdefghijklmnopqr', 8) == 'abcde...qr'
    assert truncate('ab', 5) == 'ab'
    assert truncate('ab', 2) == 'ab'
    assert truncate('ab', 1) == 'a...'
    # assert truncate(u'\u0628\u0628\u0628\u0628\u0628\u0628\u0628\u0628'
    #                  u'\u0628\u0628\u0628\u0628\u0628\u

# Generated at 2022-06-22 18:27:08.625234
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WriteableStreamImplementation(WritableStream):
        pass
    WriteableStreamImplementation.register(str)
    assert issubclass(str, WritableStream)
    assert isinstance('', WritableStream)

# Generated at 2022-06-22 18:27:19.705445
# Unit test for function truncate
def test_truncate():
    assert truncate('short', 10) == 'short'
    assert truncate('short', 5) == 'short'
    assert truncate('short', 4) == 'shor'
    assert truncate('short', 3) == 'sho'
    assert truncate('short', 2) == 'sh'
    assert truncate('short', 1) == 's'
    assert truncate('short', 0) == ''
    assert truncate(u'ΣΤΡΟՇ', 10) == u'ΣΤΡΟՇ'
    assert truncate(u'ΣΤΡΟՇ', 7) == u'ΣΤΡΟՇ'

# Generated at 2022-06-22 18:27:28.086866
# Unit test for function truncate
def test_truncate():
    assert truncate('abcd', None) == 'abcd'
    assert truncate('abcd', 4) == 'abcd'
    assert truncate('abcd', 3) == 'abc'
    assert truncate('abcd', 2) == 'ab'
    assert truncate('abcd', 1) == 'a'
    assert truncate('abcd', 0) == ''
    assert truncate('abcd', -1) == ''
    assert truncate('abcd', -2) == ''
    assert truncate('abcd', -3) == ''
    assert truncate('abcd', -4) == ''
    assert truncate('abcd', -5) == ''
    assert truncate('abcd', -100) == ''
    assert truncate('abcd', 5) == 'a...d'

# Generated at 2022-06-22 18:27:33.794637
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (int, lambda x: 'oh,...')) == repr
    assert get_repr_function(1, (int, lambda x: 'oh,...',)) == 'oh,...'
    assert get_repr_function(1.0, (int, lambda x: 'oh,...',)) == repr
    assert get_repr_function([1], (int, lambda x: 'oh,...',)) == repr
    assert get_repr_function([1], (list, lambda x: 'oh,...',)) == 'oh,...'
    assert get_repr_function([1], ((int, list), lambda x: 'oh,...',)) == 'oh,...'
    assert get_repr_function([1], ((list, int), lambda x: 'oh,...',)) == 'oh,...'


# Generated at 2022-06-22 18:27:37.259590
# Unit test for function shitcode
def test_shitcode():
    mystring = 'הָאָרֶץ, הָאָרֶץ'
    assert shitcode(mystring) == '????, ????'



# Generated at 2022-06-22 18:27:45.942888
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<Test at 0x12345>') == '<Test>'
    assert normalize_repr('<Test at 0x123456789>') == '<Test>'
    assert normalize_repr('<Test at 0x1234567890>') == '<Test>'
    assert normalize_repr('<Test at 0x12345678912345>') == '<Test>'
    assert normalize_repr('<Test at 0x123456789abcdef>') == '<Test>'
    assert normalize_repr('<Test at 0x00123456789abcdef>') == '<Test>'



# Generated at 2022-06-22 18:27:50.792854
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('This is a good string.') == 'This is a good string.'
    assert shitcode(u'This is a \N{GREEK CAPITAL LETTER DELTA} good string.') \
                                                      == 'This is a ? good string.'



# Generated at 2022-06-22 18:27:57.088598
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('אבג') == '????'
    assert shitcode(u'אבג') == '????'
    assert shitcode(b'a') == 'a'
    assert shitcode(bytearray(b'a')) == 'a'
    assert shitcode(b'\xFF') == '?'
    assert shitcode(bytearray(b'\xFF')) == '?'



# Generated at 2022-06-22 18:28:02.318324
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple([3]) == ([3],)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple([1, 2, 3]) == ([1, 2, 3],)
    assert ensure_tuple(('abc', [1, 2, 3])) == ('abc', [1, 2, 3])



# Generated at 2022-06-22 18:28:08.070799
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello!') == 'hello!'
    assert shitcode('\x00') == '?'
    assert shitcode('\x00\x10') == '??'
    assert shitcode('\x00\x10\x90') == '???'
    assert shitcode('\x00\x10\x90\xFF') == '????'
    assert u'\u2019' in shitcode(u'\u2019') # should not crash

# Generated at 2022-06-22 18:28:10.196496
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyFile(object):
        def write(self, s):
            pass

    assert isinstance(MyFile(), WritableStream)



# Generated at 2022-06-22 18:28:19.147782
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class MockFile(WritableStream):
        def write(self, s):
            pass

    class UselessClass(object):
        def method(self):
            pass

    assert issubclass(MockFile, WritableStream)
    assert not issubclass(UselessClass, WritableStream)
    # This does not need an assert statement because the global
    # function `issubclass` will raise a `TypeError` if it is passed
    # something that is not a class.
    issubclass(MockFile, None)
    issubclass(MockFile, object)
    issubclass(MockFile, MockFile)

# Generated at 2022-06-22 18:28:24.317521
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Test(WritableStream):
        def __init__(self):
            self.written_bytes = b''

        def write(self, b):
            self.written_bytes += b

    t = Test()
    t.write(b'yo')
    assert t.written_bytes == b'yo'
    assert isinstance(t, WritableStream)
    assert issubclass(Test, WritableStream)

# Generated at 2022-06-22 18:28:29.841296
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('\U000F0000') == '?'
    assert shitcode('\uFFFF') == '?'
    assert shitcode('\U000F0000a\uFFFF') == '??a?'
    assert shitcode('\U000F0000\uFFFF') == '??'
    assert shitcode('abc') == 'abc'
    assert shitcode('a\U000F0000\uFFFFb') == 'a??b'



# Generated at 2022-06-22 18:28:31.837082
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    WritableStream.register(open)
    WritableStream.register(sys.stdout)
    WritableStream.register(sys.stderr)

# Generated at 2022-06-22 18:28:35.472735
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class W(WritableStream):
        def __init__(self):
            self.counter = 0
        def write(self, s):
            self.counter += 1
    assert isinstance(W(), WritableStream)
    assert W().counter == 0
    W().write('')
    assert W().counter == 1




# Generated at 2022-06-22 18:28:46.850444
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(u'<__main__.Foo object at 0x03827D50>') == (
        u'<__main__.Foo object>'
    )
    assert normalize_repr(u'<__main__.Foo object>') == (
        u'<__main__.Foo object>'
    )
    assert normalize_repr(u'<__main__.Foo object at 0x00000000>') == (
        u'<__main__.Foo object>'
    )
    assert normalize_repr(u'<__main__.Foo object at 0x0000000000>') == (
        u'<__main__.Foo object>'
    )

# Generated at 2022-06-22 18:28:55.575682
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(x for x in range(3)) == (0, 1, 2)
    assert ensure_tuple(set('hello')) == ('e', 'l', 'o', 'h')
    assert ensure_tuple(tuple('hello')) == ('h', 'e', 'l', 'l', 'o')



# Generated at 2022-06-22 18:29:04.021167
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmn', 10) == 'abcdef...mn'
    assert truncate('abcdefghijklmn', None) == 'abcdefghijklmn'
    assert truncate('abcdefghijklmn', 30) == 'abcdefghijklmn'
    assert truncate('abc', 10) == 'abc'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 2) == '...'
    assert truncate('abc', 1) == '...'




# Generated at 2022-06-22 18:29:07.932186
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    class MyNotWritableStream(object):
        pass
    assert not issubclass(MyNotWritableStream, WritableStream)

# Generated at 2022-06-22 18:29:18.498545
# Unit test for function truncate
def test_truncate():
    for string, max_length in (
        ('', 1), ('', None), ('a', 1), ('ab', 2), ('abc', 3), ('abcd', 3),
        ('abc', None)
    ):
        assert truncate(string, max_length) == string

    for string, max_length, expected_truncated in (
        ('abcd', 2, 'ab...'), ('abcde', 3, 'ab...'), ('abcdef', 4, 'a...f'),
        ('abcdefg', 4, 'a...g'), ('abcdefgh', 4, '...h'), (
            'abcde', 1, '...e'
        ),
    ):
        truncated = truncate(string, max_length)
        assert len(truncated) == 4
        assert truncated == expected_truncated



# Generated at 2022-06-22 18:29:24.618183
# Unit test for function shitcode
def test_shitcode():
    def t(s, correct_shitcode):
        assert shitcode(s) == correct_shitcode

    t('', '')
    t('abc', 'abc')
    t('this is a טקסט', 'this is a טקסט')
    t(u'\u05d0\u05d1\u05d2', '???')
    t(u'\U0001f60d', '?')




# Generated at 2022-06-22 18:29:29.990046
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', None) == 'abc'
    assert truncate('abc', 2) == '...'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 4) == 'abc'
    assert truncate('abc', 5) == 'abc'
    assert truncate('abc', 6) == 'abc'
    assert truncate('abc', 7) == '...'
    assert truncate('abc', 8) == '...'
    assert truncate('abc', 9) == '...'
    assert truncate('abc', 10) == '...'
    assert truncate('abcde', 3) == '...'
    assert truncate('abcde', 4) == 'a...'
    assert truncate('abcde', 5) == 'ab..'

# Generated at 2022-06-22 18:29:38.611152
# Unit test for function truncate
def test_truncate():
    t = truncate,

# Generated at 2022-06-22 18:29:41.962960
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple((1,)) == (1,)

# Generated at 2022-06-22 18:29:43.373875
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567', 5) == '12...'



# Generated at 2022-06-22 18:29:53.448886
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<a at 0x123456789>') == '<a>'
    assert normalize_repr('<a at 0x1234567>') == '<a>'
    assert normalize_repr('<a at 0x1>') == '<a>'
    assert normalize_repr('<a at 0x1234567890123456789>') == '<a>'
    assert normalize_repr('<a at 0x123456789012345>') == '<a>'
    assert normalize_repr('<a at 0x12345678901234>') == '<a>'
    assert normalize_repr('<a at 0xa>') == '<a>'

# Generated at 2022-06-22 18:29:57.428798
# Unit test for function get_repr_function
def test_get_repr_function():

    class Abc(object): pass
    class Abcd(Abc): pass

    assert get_repr_function(Abcd(), []) is repr
    assert get_repr_function(Abcd(), [(Abc, lambda: 'abc')]) == 'abc'
    assert get_repr_function(Abcd(), [(Abc, lambda: 'abc')]) is not 'abc'



# Generated at 2022-06-22 18:30:00.119351
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple('s') == ('s',)



# Generated at 2022-06-22 18:30:07.115240
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('abcdef') == 'abcdef'
    assert normalize_repr('abc at 0xdef') == 'abc'
    assert normalize_repr('abc at 0x1def') == 'abc at 0x1def'
    assert normalize_repr('abc at 0xDEADBEEF') == 'abc'
    assert normalize_repr('abc at 0xEAFAADEE') == 'abc'
    assert normalize_repr('abc at 0x11111111') == 'abc'

# Generated at 2022-06-22 18:30:12.440245
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream:
        def write(self, s):
            pass
    MyWritableStream.__bases__ = ()
    MyWritableStream.__name__ = 'MyWritableStream'

    assert issubclass(MyWritableStream, WritableStream)
    MyWritableStream.write = None
    assert not issubclass(MyWritableStream, WritableStream)
    del MyWritableStream.write
    assert not issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-22 18:30:22.650847
# Unit test for function truncate
def test_truncate():

    assert truncate('abc', None) == 'abc'
    assert truncate('abc', 0) == 'abc'
    assert truncate('abc', 3) == 'abc'
    assert truncate('abc', 4) == 'abc'
    assert truncate('abc', 5) == 'abc...'

    assert truncate('abcd', 4) == 'a...'
    assert truncate('abcd', 5) == 'ab...'
    assert truncate('abcd', 6) == 'abcd'
    assert truncate('abcd', 7) == 'abcd...'

    assert truncate('abcde', 4) == 'a...'
    assert truncate('abcde', 5) == 'ab...'
    assert truncate('abcde', 6) == 'abcd...'

# Generated at 2022-06-22 18:30:29.118971
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('') == ''
    assert normalize_repr('') == ''
    assert normalize_repr('xyz') == 'xyz'
    assert normalize_repr('xyz at 0x1234567890') == 'xyz'
    assert normalize_repr('xyz at 0x123') == 'xyz'
    assert normalize_repr('xyz at 0x1234567890 at 0x9') == 'xyz at 0x9'
    assert normalize_repr('xyz at 0x1234567890 at 0x9') == 'xyz at 0x9'
    assert normalize_repr('xyz at 0x1234567890 at 0x9') == 'xyz at 0x9'

# Generated at 2022-06-22 18:30:40.663690
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('DEFAULT PYTHON REPR') == \
                                                 'DEFAULT PYTHON REPR'
    assert normalize_repr('DEFAULT PYTHON REPR at 0x12345678') == \
                                                 'DEFAULT PYTHON REPR'
    assert normalize_repr('DEFAULT PYTHON REPR at 0x1234567890') == \
                                                 'DEFAULT PYTHON REPR'
    assert normalize_repr('DEFAULT PYTHON REPR at 0x1234567890 at 0x12345678') \
                                                  == 'DEFAULT PYTHON REPR'
    assert normalize_repr('DEFAULT PYTHON REPR at 0x1234567890 at 0x12345678  ') \
                                                 

# Generated at 2022-06-22 18:30:44.724631
# Unit test for function truncate
def test_truncate():
    assert truncate('abcde', 2) == 'ab...'
    assert truncate('abcde', 3) == 'abc...'
    assert truncate('abcde', 4) == 'ab...e'
    assert truncate('abcde', 5) == 'abcde'
    assert truncate('abcde', 6) == 'abcde'



# Generated at 2022-06-22 18:30:54.437056
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io
    ws = WritableStream.register(io.TextIOWrapper)
    assert ws.write('a') is None
    assert ws.write('b') is None
    assert ws.write(None) is None
    assert ws.write('') is None
    assert ws.write(1) is None
    assert ws.write(0) is None


from . import pycompat
if pycompat.is_pypy:
    # TODO: See issue #2 on github.
    pass
elif sys.version_info >= (2, 6):
    try:
        test_WritableStream_write()
    except AttributeError:
        # We're running on an older version of python that's missing the
        # required attributes on file-like objects.
        pass

# Generated at 2022-06-22 18:30:56.775627
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(42, []) is repr
    assert get_repr_function(42, [(lambda x: x == 42, str)]) == str



# Generated at 2022-06-22 18:31:01.254445
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('foo at 0x1234') == 'foo'
    assert normalize_repr('foo at 0x12345678') == 'foo'
    assert normalize_repr('bar at 0x123456789ABCDEF') == 'bar'
    assert normalize_repr('baz at 0x123456789ABCDEFG') == 'baz at 0x123456789ABCDEFG'



# Generated at 2022-06-22 18:31:12.771300
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A: pass
    class B(A): pass
    class C(A): pass
    class D(B, C): pass

    class E(WritableStream):
        @classmethod
        def __subclasshook__(cls, C):
            if cls is WritableStream:
                return _check_methods(C, 'write')
            return NotImplemented

    assert E.__subclasshook__(A) is NotImplemented
    assert E.__subclasshook__(B) is NotImplemented
    assert E.__subclasshook__(C) is NotImplemented
    assert E.__subclasshook__(D) is NotImplemented

    class F(C, D):
        def write(self, s):
            pass

    assert E.__subclasshook__(F) is True


# Generated at 2022-06-22 18:31:22.677209
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class Foo:
        def write(self, s):
            pass

    assert isinstance(Foo(), WritableStream)

    class Bar:
        pass

    assert not isinstance(Bar(), WritableStream)

    class Baz:
        def write(self, s):
            pass
        def write2(self, s):
            pass

    assert isinstance(Baz(), WritableStream)

    class Qux:
        def write(self, s):
            pass
        write2 = None

    assert not isinstance(Qux(), WritableStream)

    class Dum:
        def write(self, s):
            pass
        @property
        def write2(self):
            pass

    assert not isinstance(Dum(), WritableStream)




# Generated at 2022-06-22 18:31:30.166064
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(()) == ()
    assert ensure_tuple('a') == ('a',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([]) == ()
    assert ensure_tuple(()) == ()
    assert ensure_tuple({}) == ({},)
    assert ensure_tuple(set()) == (set(),)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple({1}) == ({1},)

# Generated at 2022-06-22 18:31:37.499684
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'אאא') == '???', shitcode(u'אאא')
    assert shitcode(u'אאא'.encode('utf8')) == '???', \
           shitcode(u'אאא'.encode('utf8'))
    assert shitcode(u'אאא'.encode('utf16')) == '???', \
           shitcode(u'אאא'.encode('utf16'))
    assert shitcode(b'abc') == b'abc', shitcode(b'abc')
    assert shitcode(u'abc') == 'abc', shitcode(u'abc')

    bytes_with_weird_characters = [chr(i).encode('utf8') for i in range(128)]

# Generated at 2022-06-22 18:31:42.023143
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .pycompat import file_type

    class C(object):
        def write(self, s):
            pass

    assert isinstance(sys.stdout, WritableStream)
    assert isinstance(open('test.out', 'w'), WritableStream)
    assert isinstance(C(), WritableStream)



# Generated at 2022-06-22 18:31:52.675191
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from python_toolbox import cute_testing
    from itertools import count
    def test_custom_repr(Integer):
        for i in count(0):
            if i >= 100:
                raise StopIteration()
            yield (lambda x: isinstance(x, Integer),
                   lambda x: 'Integer({})'.format(x))

    with cute_testing.RaiseAssertor(AssertionError):
        normalize_repr('hello')

    assert truncate('hello', None) == 'hello'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 3) == 'hel...'
    assert truncate('hello', 2) == 'h...'
    assert truncate('hello', 1) == '...'

    assert normalize_repr('hello') == 'hello'


# Generated at 2022-06-22 18:31:57.393145
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class SimpleFileLikeObject(WritableStream):
        def write(self, s): pass

    class NoWriteMethod(WritableStream): pass

    assert issubclass(SimpleFileLikeObject, WritableStream)
    assert not issubclass(NoWriteMethod, WritableStream)

# Generated at 2022-06-22 18:32:01.134276
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(xrange(5)) == tuple(xrange(5))
    assert ensure_tuple(tuple(xrange(5))) == tuple(xrange(5))
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple(None) == (None,)



# Generated at 2022-06-22 18:32:10.558669
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class CanWrite(object):
        def write(self, s):
            pass
    class CantWrite(object):
        pass
    class CanWriteButNone(object):
        def write(self, s):
            pass
        write = None
    class CantWriteButWriteIsNone(object):
        write = None

    for writable_stream in (CanWrite, sys.stdout):
        assert issubclass(writable_stream, WritableStream)

    for non_writable_stream in (CantWrite, CanWriteButNone,
                                CantWriteButWriteIsNone):
        assert not issubclass(non_writable_stream, WritableStream)
    

    



# Generated at 2022-06-22 18:32:22.158552
# Unit test for function normalize_repr
def test_normalize_repr():
    from python_toolbox import cute_testing
    normalize_repr_ = cute_testing.AssertEqual(normalize_repr)
    normalize_repr_('abc')
    normalize_repr_('abc at 0x00')
    normalize_repr_('abc at 0x000000000')
    normalize_repr_('abc at 0x000000000000')
    normalize_repr_('abc at 0x000000000 at 0x000000000')
    normalize_repr_('abc at 0x000000000000 at 0x000000000000')
    normalize_repr_('abc at 0x000000000 at 0x000000000000')
    normalize_repr_('abc at 0x000000000000 at 0x000000000')

# Generated at 2022-06-22 18:32:29.732407
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('A string at 0x1234') == 'A string'
    assert normalize_repr('A string at 0x1234FAFAF') == 'A string'
    assert normalize_repr('A string at 0x1234FAFAFAB45') == 'A string'
    assert normalize_repr('A string at 0x1234FAFAFAB45') == 'A string'
    assert normalize_repr('A string at 0x1234FAFAFAB45FFFA') == 'A string'
    assert normalize_repr('A string') == 'A string'
    assert normalize_repr(u'A string') == 'A string'

# Generated at 2022-06-22 18:32:35.483434
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('repr me') == 'repr me'
    assert get_shortish_repr('repr me', max_length=3) == 'rep...'
    assert get_shortish_repr('repr me', max_length=4) == 'repr...'
    assert get_shortish_repr('repr me', max_length=5) == 'repr...'
    assert get_shortish_repr('repr me', max_length=6) == 'repr m...'
    assert get_shortish_repr('repr me', max_length=7) == 'repr me'
    assert get_shortish_repr('repr me', max_length=8) == 'repr me'

# Generated at 2022-06-22 18:32:45.742670
# Unit test for function get_repr_function
def test_get_repr_function():
    from .identity_dict import IdentityDict
    from .ordered_dict import OrderedDict
    from . import misc
    for i in range(10):
        d = IdentityDict()
        d[misc.Object()] = i
        assert get_repr_function(d, ((dict, str),))(d) == '{}'
        assert get_repr_function(d, ((dict, str),))(d) == str(d)
        assert get_repr_function(d, ((dict, str),))(d) != repr(d)
        assert get_repr_function(d, ((type(None), str),))(None) == 'None'
        assert get_repr_function(d, ((type(None), str),))(None) == str(None)
        assert get_repr_function

# Generated at 2022-06-22 18:32:49.501261
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-22 18:32:51.839754
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(object):
        def write(self, s): pass
    x = X()
    assert isinstance(x, WritableStream)

# Generated at 2022-06-22 18:33:01.841578
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert issubclass(list, WritableStream)
    assert not issubclass(int, WritableStream)

    assert issubclass(sys.stdout.__class__, WritableStream)


    # Unit tests for method get_shortish_repr of module misc
    def assert_result(result):
        assert isinstance(result, str)
        assert len(result) <= 26
        assert result == result.replace('\r', '').replace('\n', '')

    assert_result(get_shortish_repr(5))
    assert_result(get_shortish_repr([5, 5]))
    assert_result(get_shortish_repr(Ellipsis))
    assert_result(get_shortish_repr([]))

# Generated at 2022-06-22 18:33:10.289287
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(['hello']) == ('hello',)
    assert ensure_tuple(('hello',)) == ('hello',)
    assert ensure_tuple(['hello', 'hella', 'holla']) == ('hello', 'hella',
                                                          'holla')
    assert ensure_tuple(('hello', 'hella', 'holla')) == ('hello', 'hella',
                                                          'holla')
    assert ensure_tuple(123) == (123,)
    assert ensure_tuple(None) == (None,)



# Generated at 2022-06-22 18:33:19.205546
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', None) == '123456789'
    assert truncate('123456789', 11) == '123456789'
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 8) == '1...789'
    assert truncate('123456789', 7) == '1...89'
    assert truncate('123456789', 6) == '1...9'
    assert truncate('123456789', 5) == '1...9'
    assert truncate('123456789', 4) == '1...'
    assert truncate('123456789', 3) == '...'
    assert truncate('123456789', 2) == '..'

# Generated at 2022-06-22 18:33:23.807413
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def __init__(self):
            pass

    writable_stream_subclass = WritableStreamSubclass()
    assert isinstance(writable_stream_subclass, WritableStream)
    writable_stream_subclass.write('hello')
    assert False

# Generated at 2022-06-22 18:33:26.294144
# Unit test for function shitcode
def test_shitcode():
    u = '婆'
    s = shitcode(u)
    assert len(s) == 1




# Generated at 2022-06-22 18:33:33.898665
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('yo') == ('yo',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(b'abc') == (b'abc',)
    assert ensure_tuple(u'abc') == (u'abc',)
    assert ensure_tuple(set([1, 2, 3])) == (1, 2, 3)
    assert ensure_tuple(dict(a=1)) == (dict(a=1),)



# Generated at 2022-06-22 18:33:40.807772
# Unit test for function normalize_repr
def test_normalize_repr():
    from .test_tools.test_misc import assert_equal

    class C: pass
    class C2(C): pass
    class C3(C2): pass
    assert_equal(normalize_repr(repr(C)), "<class '__main__.C'>")
    assert_equal(normalize_repr(repr(C2)), "<class '__main__.C2'>")
    assert_equal(normalize_repr(repr(C3)), "<class '__main__.C3'>")



# Generated at 2022-06-22 18:33:44.008891
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(WritableStream):
        def __init__(self):
            self.written = None
        def write(self, written):
            self.written = written

    foo = Foo()
    assert foo.written is None
    foo.write('heyo')
    assert foo.written == 'heyo'


# Generated at 2022-06-22 18:33:48.234699
# Unit test for function ensure_tuple
def test_ensure_tuple():
    x = ensure_tuple(10)
    assert isinstance(x, tuple), type(x)
    assert x == (10,), x
    x = ensure_tuple((10,))
    assert isinstance(x, tuple), type(x)
    assert x == (10,), x
    x = ensure_tuple('ram')
    assert isinstance(x, tuple), type(x)
    assert x == ('ram',), x
    x = ensure_tuple([10, 20])
    assert isinstance(x, tuple), type(x)
    assert x == (10, 20), x



# Generated at 2022-06-22 18:33:50.398753
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('Hello') == 'Hello'
    assert shitcode('你好') == '????'

# Generated at 2022-06-22 18:34:01.985766
# Unit test for function truncate
def test_truncate():
    assert(truncate(u'123456789', None) == u'123456789')
    assert(truncate(u'123456789', 9) == u'123456789')
    assert(truncate(u'123456789', 8) == u'1234567...')
    assert(truncate(u'123456789', 5) == u'1...89')
    assert(truncate(u'123456789', 4) == u'1...')
    assert(truncate(u'123456789', 3) == u'1...')
    assert(truncate(u'123456789', 2) == u'1...')
    assert(truncate(u'123456789', 1) == u'...')

# Generated at 2022-06-22 18:34:11.752464
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr

    def custom_repr_for_one(x):
        if isinstance(x, int):
            return str(x)
        else:
            return repr(x) # pragma: no cover
    assert get_repr_function(1, (
        (lambda x: isinstance(x, int), custom_repr_for_one),
    )) is custom_repr_for_one

    def custom_repr_for_two(x):
        if isinstance(x, int):
            return str(x)
        else:
            return repr(x) # pragma: no cover

# Generated at 2022-06-22 18:34:15.552340
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)



# Generated at 2022-06-22 18:34:18.364274
# Unit test for function ensure_tuple
def test_ensure_tuple():

    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple((1,2)) == (1,2)



# Generated at 2022-06-22 18:34:21.509274
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1, )
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)

# Generated at 2022-06-22 18:34:24.794430
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(7) == (7,)
    assert ensure_tuple('hi') == ('hi',)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(None) == (None,)

if __name__ == '__main__':
    test_ensure_tuple()

# Generated at 2022-06-22 18:34:31.304953
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple(set([1, 2, 3])) == (1, 2, 3)



# Generated at 2022-06-22 18:34:37.406140
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(()) == ()



# Generated at 2022-06-22 18:34:47.724747
# Unit test for function truncate
def test_truncate():

    assert truncate(None, None) == None
    assert truncate(None, 10) == None

    assert truncate(1, None) == 1
    assert truncate(1, 10) == 1

    assert truncate('', None) == ''
    assert truncate('', 10) == ''

    assert truncate('a', None) == 'a'
    assert truncate('a', 10) == 'a'

    assert truncate('abcdefghijk', None) == 'abcdefghijk'
    assert truncate('abcdefghijk', 10) == 'abcdefghijk'

    assert truncate('abcdefghijkl', None) == 'abcdefghijkl'
    assert truncate('abcdefghijkl', 10) == 'abcdef...jkl'


# Generated at 2022-06-22 18:34:57.563872
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    import random
    import string

    assert get_shortish_repr('') == "''"
    assert get_shortish_repr('abcd') == "'abcd'"
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(('ab', 'cd')) == "('ab', 'cd')"
    assert get_shortish_repr(('ab', 'cd'), max_length=4) == "('...'"
    assert get_shortish_repr(('ab', 'cd'), max_length=5) == "('a...'"
    assert get_shortish_repr(('ab', 'cd'), max_length=6) == "('ab...'"

# Generated at 2022-06-22 18:35:04.337015
# Unit test for function normalize_repr
def test_normalize_repr():
    if sys.version_info[0] < 3:
        assert normalize_repr("<str object at 0x7f85b5da49c8>") \
                                                     == "<str object>"
    else:
        assert normalize_repr("<str object at 0x7f85b5da49c8>") \
                                                     == "<str object>"
    assert normalize_repr("<str object>") == "<str object>"
    assert normalize_repr("<str objectat 0x7f85b5da49c8>") \
                                                      == "<str objectat 0x7f85b5da49c8>"

# Generated at 2022-06-22 18:35:08.995215
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(['a', 'b']) == ('a', 'b')
    assert ensure_tuple('a') == ('a',)
    assert ensure_tuple(None) == (None,)
    assert ensure_tuple(1) == (1,)

# Generated at 2022-06-22 18:35:15.717583
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, str),)) == str
    assert get_repr_function(1.0, custom_repr=((int, str),)) == repr
    assert get_repr_function(1.0, custom_repr=((int, None),)) == repr
    assert get_repr_function(
        1.0, custom_repr=((int, None), (float, str))
    ) == str

# Generated at 2022-06-22 18:35:20.943775
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo: pass
    class FooWritableStream(WritableStream):
        def write(self, x): pass
    class Bar:
        def write(self, x): pass

    assert isinstance(FooWritableStream(), WritableStream)
    assert not isinstance(Foo(), WritableStream)
    assert not isinstance(Bar(), WritableStream)






# Generated at 2022-06-22 18:35:28.927412
# Unit test for function normalize_repr

# Generated at 2022-06-22 18:35:38.133083
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr([1, 2, 3], max_length=16) == "[1, 2, 3]"
    assert get_shortish_repr([1, 2, 3], max_length=8) == "[1, 2..."
    assert get_shortish_repr((1, 2, 3), max_length=8) == "(1, 2..."
    assert get_shortish_repr((1, 2, 3), max_length=7) == "(1, 2..."
    assert get_shortish_repr((1, 2, 3), max_length=6) == "(1..."
    assert get_shortish_repr((1, 2, 3), max_length=5) == "(1..."

# Generated at 2022-06-22 18:35:46.653546
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('abc\x7f') == 'abc?'
    assert shitcode('abc\xaa') == 'abc?'
    assert shitcode('abc\xFF') == 'abc?'
    assert shitcode('abc\x00') == 'abc\x00'
    assert shitcode('abc\x01') == 'abc\x01'
    assert shitcode('abc\x1f') == 'abc\x1f'
    assert shitcode('abc\x20') == 'abc\x20'
    assert shitcode('abc\x7e') == 'abc\x7e'



# Generated at 2022-06-22 18:35:57.115487
# Unit test for function get_repr_function
def test_get_repr_function():

    # will be used as a function's return value
    obj = object()

    # Test not specifying any custom repr
    assert get_repr_function(object(), ()) is repr

    # Test specifying a custom repr for an unrelated class
    assert get_repr_function(object(), ((float, object),)) is repr

    # Test specifying a custom repr for a superclass of the object
    assert get_repr_function(obj, ((object, obj),)) is obj

    # Test specifying a custom repr for a parent superclass of the object
    assert get_repr_function(obj, ((object, lambda: obj),)) is obj

    # Test specifying a custom repr for a parent superclass of the object
    assert get_repr_function(obj, ((lambda x: 0, lambda: obj),)) is obj

    # Test specifying a custom repr for the object's