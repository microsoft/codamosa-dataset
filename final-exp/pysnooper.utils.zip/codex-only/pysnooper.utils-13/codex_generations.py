

# Generated at 2022-06-22 18:26:00.793792
# Unit test for function get_repr_function
def test_get_repr_function():
    def test_str(x):
        return 'strified'
    def test_int(x):
        return 'intified'
    class TestClass(object): pass
    class TestClass2(object): pass
    assert get_repr_function(1, ((test_int, 'intified'))) == 'intified'
    assert get_repr_function('1', ((test_str, 'strified'))) == 'strified'
    assert get_repr_function(1,
                             ((basestring, test_str), (int, test_int))
                            ) == test_int
    assert get_repr_function('1',
                             ((basestring, test_str), (int, test_int))
                            ) == test_str

# Generated at 2022-06-22 18:26:09.319582
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X(object): pass
    class Y(X):
        @abc.abstractmethod
        def write(self, *args): pass

    class Z(X): pass
    class A(object):
        def write(self, *args): pass
    class B(A):
        def write(self, *args): pass
    class C(A):
        def write(self, *args): pass
    class D(C):
        def write(self, *args): pass

    class E(A): pass
    class F(E):
        @abc.abstractmethod
        def write(self, *args): pass

    class G(A):
        def write(self, *args): pass

    assert WritableStream.__subclasshook__(X) is NotImplemented

# Generated at 2022-06-22 18:26:14.001197
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class X:
        def write(self, s):
            pass

    class Y:
        def write(self, s):
            pass

        @staticmethod
        def close():
            pass

    class Z:
        pass

    assert issubclass(X, WritableStream)
    assert issubclass(Y, WritableStream)
    assert not issubclass(Z, WritableStream)

# Generated at 2022-06-22 18:26:24.930141
# Unit test for function truncate
def test_truncate():
    assert truncate('0123456789', 10) == '0123456789'
    assert truncate('0123456789', 5) == '0123456789'
    assert truncate('0123456789', 9) == '0123456...'
    assert truncate('0123456789', 8) == '0123...'
    assert truncate('0123456789', 7) == '012...'
    assert truncate('0123456789', 6) == '01...'
    assert truncate('0123456789', 4) == '01...'
    assert truncate('0123456789', 3) == '0...'
    assert truncate('0123456789', 2) == '0...'
    assert truncate('0123456789', 1) == '...'
   

# Generated at 2022-06-22 18:26:30.651425
# Unit test for function get_repr_function
def test_get_repr_function():

    assert get_repr_function(3, ((lambda x: x >= 0, str),)) == str
    assert get_repr_function(3, ((lambda x: x < 0, str),)) == repr
    assert get_repr_function(3, ((lambda x: x < 0, str), (lambda x: x > 0,
                                                          str))) == str
    assert get_repr_function(3, ((lambda x: x < 0, str), (lambda x: x > 4,
                                                          str))) == repr
    assert get_repr_function(-3, ((lambda x: x < 0, str),)) == str
    assert get_repr_function(-3, ((lambda x: x > 0, str),)) == repr

# Generated at 2022-06-22 18:26:41.384558
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcdef', max_length=5) == 'abcde...'
    assert get_shortish_repr('abcdef', max_length=6) == 'abcdef'
    assert get_shortish_repr('abcdef', max_length=None) == 'abcdef'
    assert get_shortish_repr('ab\ncde\ \f', max_length=6) == 'ab cde ...'
    assert get_shortish_repr('ab\ncde\ \f', max_length=None) == 'ab cde  '
    assert get_shortish_repr('ab\ncde\ \f', max_length=6, normalize=True) \
        == 'ab cde'

# Generated at 2022-06-22 18:26:45.275305
# Unit test for function shitcode
def test_shitcode():
    # I have no idea how to test this. Need a way to write a non-ascii
    # non-unicode character to a file so it'll get read as regular bytes.
    # But I can't even find the right character in the python console.
    pass



# Generated at 2022-06-22 18:26:47.910478
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X:
        def write(self, s):
            pass
    assert issubclass(X, WritableStream)
    assert issubclass(int, WritableStream) == False




# Generated at 2022-06-22 18:26:51.095901
# Unit test for function normalize_repr
def test_normalize_repr():
    """
    Tests that `normalize_repr` works as expected.
    """
    assert normalize_repr('[]') == '[]'
    assert normalize_repr('[] at 0x101') == '[]'
    assert normalize_repr('[] at 0x101 at 0xFFFF') == '[]'



# Generated at 2022-06-22 18:26:57.846238
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class SampleStream(WritableStream):
        def write(self, s):
            print(s)
    assert isinstance(sys.stdout, WritableStream)
    assert isinstance(SampleStream(), WritableStream)
    class SampleStream2:
        def write(self, s):
            print(s)
    assert not isinstance(SampleStream2(), WritableStream)





# Generated at 2022-06-22 18:27:05.145139
# Unit test for function truncate
def test_truncate():
    assert truncate('xyz', 2) == 'xy'
    assert truncate('xyz', 3) == 'xyz'
    assert truncate('xyz', 4) == 'xyz'
    assert truncate('xyz', 5) == 'xyz'
    assert truncate('xyz', 6) == 'xyz'
    assert truncate('xyz', 100) == 'xyz'

    assert truncate('xyzqrs', 2) == 'xy'
    assert truncate('xyzqrs', 3) == 'xy...'
    assert truncate('xyzqrs', 4) == 'xyz...'
    assert truncate('xyzqrs', 5) == 'xyz...'
    assert truncate('xyzqrs', 6) == 'xyzqrs'

# Generated at 2022-06-22 18:27:12.133658
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((int, lambda x: '!'),)) == '!'
    assert get_repr_function(1.5, custom_repr=((int, lambda x: '!'),)) != '!'
    assert get_repr_function(1, custom_repr=((lambda x: x > 1, lambda x: '!'),)) == '!'
    assert get_repr_function(1, custom_repr=((lambda x: x < 1, lambda x: '!'),)) != '!'

# Generated at 2022-06-22 18:27:14.906285
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert isinstance(open('the_file', 'w'), MyWritableStream)

# Generated at 2022-06-22 18:27:21.801041
# Unit test for function truncate
def test_truncate():
    from shackles import assert_equal
    assert_equal(truncate('abc', None), 'abc')
    assert_equal(truncate('abcd', None), 'abcd')
    assert_equal(truncate('abcde', None), 'abcde')
    assert_equal(truncate('abcde', 5), 'abcde')
    assert_equal(truncate('abcdef', 5), 'a...f')
    assert_equal(truncate('abcdefg', 5), 'a...g')

# Generated at 2022-06-22 18:27:24.709296
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert not isinstance(ensure_tuple([1, 2]), list)
    assert not isinstance(ensure_tuple((1, 2)), list)



# Generated at 2022-06-22 18:27:35.667625
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr(
        "abcdef"
    ) == "abcdef"
    assert normalize_repr(
        "abcdef at 0x1234"
    ) == "abcdef"
    assert normalize_repr(
        "abcdef at 0xBEEF"
    ) == "abcdef"
    assert normalize_repr(
        "abcdef at 0x1234 at 0x5678"
    ) == "abcdef at 0x5678"
    assert normalize_repr(
        "abcdef at 0x1234 important stuff here at 0x5678"
    ) == "abcdef at 0x1234 important stuff here at 0x5678"

# Generated at 2022-06-22 18:27:46.032178
# Unit test for function truncate
def test_truncate():
    assert truncate('12345', 5) == '12345'
    assert truncate('12345', 8) == '12345'
    assert truncate('12345', 4) == '1...5'
    assert truncate('12345', 3) == '...'
    assert truncate('12345', 2) == '..'
    assert truncate('12345', 1) == '.'
    assert truncate('12345', 0) == ''
    assert truncate('12345', -3) == '12345'
    assert truncate('12345678', 3) == '...'
    assert truncate('12345678', 4) == '1...8'
    assert truncate('12345678', 5) == '12...8'
    assert truncate('12345678', 6) == '123...8'

# Generated at 2022-06-22 18:27:52.337253
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(set([1, 2, 3])) == (1, 2, 3)
    assert ensure_tuple('abc') == ('abc',)
    assert ensure_tuple(3) == (3,)

# Generated at 2022-06-22 18:27:55.648480
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Test(WritableStream):

        def write(self, s):
            pass

    assert WritableStream.__subclasshook__(Test)
    assert issubclass(Test, WritableStream)



# Generated at 2022-06-22 18:28:00.318107
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class SomeStream(WritableStream):
        def write(self, s): pass

    assert issubclass(SomeStream, WritableStream)
    assert SomeStream().write('') is None

    class BadStream(WritableStream): pass # type: ignore

    assert not issubclass(BadStream, WritableStream)




# Generated at 2022-06-22 18:28:01.739481
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('blah') == 'blah'
    assert shitcode(u'זהו') == u'?????'
    assert shitcode('זהו'.decode('utf8')) == u'?????'

# Generated at 2022-06-22 18:28:06.359438
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Stream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(Stream, WritableStream)
    assert issubclass(
        collections_abc.TextIOBase,
        WritableStream if sys.version_info[0] < 3
        else collections_abc.StreamWriter
    )
    assert not issubclass(list, WritableStream)


# Generated at 2022-06-22 18:28:14.222732
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: 'the int {}'.format(x)),)) == \
                                                      'the int 1'
    assert get_repr_function('1', ((str, lambda x: 'the str {}'.format(x)),)) == \
                                                      'the str 1'
    assert get_repr_function(1, ((float, lambda x: 'the float {}'.format(x)),)) == \
                                                      repr
    assert get_repr_function(1.1, ((float, lambda x: 'the float {}'.format(x)),)) == \
                                                      'the float 1.1'

# Generated at 2022-06-22 18:28:24.652041
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(2 ** 1000) == repr(2 ** 1000)
    assert get_shortish_repr(object) == repr(object)
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr(5, max_length=5) == '5'
    assert get_shortish_repr(5, max_length=3) == '5'
    assert get_shortish_repr(5, max_length=2) == '5'
    assert get_shortish_repr(5, max_length=1) == '5'
    assert get_shortish_repr(5, max_length=0) == '5'

# Generated at 2022-06-22 18:28:29.613252
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(()) == ()
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(set([1, 2])) == (1, 2)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple('abc') == ('abc',)



# Generated at 2022-06-22 18:28:35.024256
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestClass(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s
    test_class = TestClass()
    assert test_class.s == ''
    test_class.write('meow')
    assert test_class.s == 'meow'




# Generated at 2022-06-22 18:28:36.412490
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2)) == (1, 2)



# Generated at 2022-06-22 18:28:38.920894
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('Hélĺô') == 'H?l???'



# Generated at 2022-06-22 18:28:47.540218
# Unit test for function normalize_repr
def test_normalize_repr():
    class Foo(object):
        pass

    assert normalize_repr(repr(Foo())) == normalize_repr(repr(Foo()))
    assert normalize_repr(repr(Foo() + Foo())) == normalize_repr(repr(Foo() +
                                                                      Foo()))




if sys.platform.startswith('java'):
    # Workaround for http://bugs.jython.org/issue2134
    def _init_subclass(object):
        pass
    classmetas = type, ABC
else:
    classmetas = type

import collections

# Generated at 2022-06-22 18:28:54.204647
# Unit test for function truncate
def test_truncate():
    assert truncate(u'this', 10) == u'this'
    assert truncate(u'this', 3) == u'thi'
    assert truncate(u'this', 1) == u't'
    assert truncate(u'this', 0) == u''
    assert truncate(u'this', -1) == u''
    assert truncate(u'this', None) == u'this'



# Generated at 2022-06-22 18:28:57.758830
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple('hi') == ('hi',)
    assert ensure_tuple(['hi']) == ('hi',)



# Generated at 2022-06-22 18:29:03.680163
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class B:
        def __init__(self, x):
            self.x = x

        def write(self, s):
            self.x += 1

    b = B(2)
    assert isinstance(b, WritableStream)

    class C:
        def __init__(self, x):
            self.x = x

    assert not isinstance(C(4), WritableStream)

# Generated at 2022-06-22 18:29:06.457401
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Test(WritableStream):
        def write(self, s):
            pass
    # These shouldn't raise an `TypeError`
    Test()
    Test.__subclasshook__(Test)



# Generated at 2022-06-22 18:29:12.773140
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('abc') == 'abc'
    assert shitcode('\0a\0b\0c') == '\0a\0b\0c'
    assert shitcode('a\0b\0c\0') == 'a\0b\0c\0'
    assert shitcode('🐍') == '?'
    assert shitcode('abc🐍') == 'abc?'
    assert shitcode('🐍🐍') == '??'

# Generated at 2022-06-22 18:29:15.381114
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class DummyWritableStream(WritableStream):
        def write(self, s):
            pass
    DummyWritableStream().write('')

# Generated at 2022-06-22 18:29:23.129773
# Unit test for function get_repr_function
def test_get_repr_function():

    def string_repr(s):
        return 'string: ' + s

    def int_repr(i):
        return 'int: ' + str(i)

    custom_repr = (
        (lambda x: isinstance(x, str), string_repr),
        (int, int_repr)
    )

    print(get_repr_function('Hi', custom_repr))

    print(get_repr_function(3, custom_repr))

    print(get_repr_function(3.2, custom_repr))

# Generated at 2022-06-22 18:29:27.804323
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class StubWritableStream(WritableStream):
        def __init__(self):
            self.data = ''
        def write(self, s):
            self.data += s

    sws = StubWritableStream()
    sws.write('spam')
    assert sws.data == 'spam'



# Generated at 2022-06-22 18:29:37.053385
# Unit test for function truncate
def test_truncate():
    # `max_length` is `None`:
    assert truncate('123', None) == '123'
    assert truncate('123456789', None) == '123456789'
    # `max_length` is in the middle of the string:
    assert truncate('123456789', 5) == '123...9'
    # `max_length` is at the end of the string:
    assert truncate('123456789', 9) == '123456789'
    # `max_length` is bigger than the string:
    assert truncate('123456789', 10) == '123456789'
    # `max_length` is even:
    assert truncate('123456789', 4) == '12...9'
    # `max_length` is odd:

# Generated at 2022-06-22 18:29:49.022502
# Unit test for function normalize_repr
def test_normalize_repr():
    from random import random
    from .pycompat import StringIO
    from .temp_file_tools import make_temp_folder, file_text
    import os
    import sys

    def _test():
        items = [2, 3.1, 'hello', (1, 2), set([4, 4]), [4]]
        io = StringIO()
        sys.stdout = io

        for item in items:
            print(repr(item))
            original_repr = io.getvalue()
            normalized_repr = normalize_repr(original_repr)
            assert normalized_repr != original_repr
            assert normalized_repr[-1] == '\n'
            assert normalized_repr[:-1] == repr(item)

    _test()


# Generated at 2022-06-22 18:29:57.727088
# Unit test for function normalize_repr
def test_normalize_repr():
    from_repr = normalize_repr
    def to_repr(x):
        try:
            return repr(x)
        except Exception:
            return 'repr_error'

    a = 1
    assert from_repr(to_repr(a)) == repr(a)
    b = 'x'
    assert from_repr(to_repr(b)) == repr(b)
    c = [10, 15]
    assert from_repr(to_repr(c)) == repr(c)

    class X(object):
        def __init__(self):
            self.x = 15

        __repr__ = lambda self: 'repr_here'

    d = X()
    assert from_repr(to_repr(d)) == 'repr_here'
    assert from_

# Generated at 2022-06-22 18:30:02.116614
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class Yes(WritableStream):
        def write(self, s):
            pass

    assert isinstance(Yes(), WritableStream)

    class No(WritableStream):
        pass

    assert not isinstance(No(), WritableStream)

    class Maybe(WritableStream):
        def write(self, s):
            pass

        def foo(self):
            pass

    assert isinstance(Maybe(), WritableStream)

    class MaybeNot(WritableStream):
        def write(self, s):
            pass

        def __hash__(self):
            pass

    assert not isinstance(MaybeNot(), WritableStream)





# Generated at 2022-06-22 18:30:12.276362
# Unit test for function normalize_repr
def test_normalize_repr():
    import random
    from .backports import memoryview
    from .misc import FrozenDict
    from .cute_iter_tools import first
    from .six import BytesIO

    class CustomRepr(object):
        def __repr__(self):
            return 'custom repr'

    class CustomReprNoCall(object):
        __repr__ = 'custom repr'

    class CustomReprRaises(object):
        def __repr__(self):
            raise Exception()

    class CustomReprLambda(object):
        def __repr__(self):
            return lambda: "custom repr"
        

# Generated at 2022-06-22 18:30:22.552242
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    # test default values
    assert get_shortish_repr('abc') == "'abc'"
    assert get_shortish_repr((1,2)) == '(1, 2)'
    # test with max_length < len of repr
    assert get_shortish_repr('abc', max_length=2) == "'a..."
    # test with max_length > len of repr
    assert get_shortish_repr('abc', max_length=5) == "'abc'"
    # test with max_length = len of repr
    assert get_shortish_repr('abc', max_length=3) == "'abc'"
    # test with max_length < len of repr and truncated repr end with single quote
    assert get_shortish_repr((1,'abc'), max_length=4) == '(1, '
    # test with

# Generated at 2022-06-22 18:30:25.786625
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .redirect import TTYWriter, RawWriter, UTF8Writer, ASCIIWriter
    assert issubclass(TTYWriter, WritableStream)
    assert issubclass(RawWriter, WritableStream)
    assert issubclass(UTF8Writer, WritableStream)
    assert issubclass(ASCIIWriter, WritableStream)

# Generated at 2022-06-22 18:30:31.839272
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(range(4)) == (0, 1, 2, 3)
    assert ensure_tuple('1234') == ('1234',)

# Generated at 2022-06-22 18:30:41.943015
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    # Check that it can be called from subclasses that don't have `write` but
    # have `write_byte` and `write_bytes` instead:
    class MyWritableStream(WritableStream):
        def write_byte(self, byte):
            print('write_byte:', byte)

        def write_bytes(self, bytes):
            print('write_bytes:', bytes)

    MyWritableStream().write('abc')

    if not hasattr(sys.stdout, 'write_byte'):
        return # We're not in a bare-bones environment

    # Check that it can be called from the stdout:
    sys.stdout.write(b'abc')
    sys.stdout.write('abc')


test_WritableStream_write()

# Generated at 2022-06-22 18:30:43.908798
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A:
        def write(s, t):
            pass
    assert (isinstance(A(), WritableStream))



# Generated at 2022-06-22 18:30:54.034388
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', None) == 'hello'
    assert truncate('hello', 2) == 'he...'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 6) == 'hello'
    assert truncate('hello', 7) == 'hello'
    assert truncate('hello', 8) == 'hello'
    assert truncate('hello', 100) == 'hello'

    assert truncate('hello world', 5) == 'he...'
    assert truncate('hello world', 6) == 'he...'
    assert truncate('hello world', 7) == 'he...'
    assert truncate('hello world', 8) == 'hello...'
    assert truncate('hello world', 9) == 'hello...'
    assert truncate('hello world', 10) == 'hello...'
    assert truncate

# Generated at 2022-06-22 18:31:02.054579
# Unit test for function normalize_repr
def test_normalize_repr():
    from . import tuple_tools
    assert normalize_repr('bla at 0x12345678901234567890') == 'bla'
    assert normalize_repr('bla at 0x12345678901234567J') == 'bla at 0x12345678901234567J'
    assert normalize_repr('bla something 0x12345678901234567890 something something') == 'bla something 0x12345678901234567890 something something'
    assert normalize_repr(tuple_tools.get_shortish_repr(
        [1, 2, 'a', [4, 5, 6], 7])
    ) == 'bla something 0x12345678901234567890 something something'


from . import pycompat

# Generated at 2022-06-22 18:31:13.229652
# Unit test for function get_repr_function
def test_get_repr_function():
    class A:
        pass

    class B:
        def __repr__(self):
            return 'B!'

    class C:
        def __init__(self, s):
            self.s = s

        def __repr__(self):
            return 'C<{}>'.format(self.s)

    class D:
        def __repr__(self):
            return 'D!'

    assert get_repr_function(A(), [(A, lambda a: 'A!')])() == 'A!'
    assert get_repr_function(A(), [(B, lambda a: 'B!')])() == \
                                              normalize_repr(repr(A()))

# Generated at 2022-06-22 18:31:24.251148
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('spam') == 'spam'
    assert normalize_repr('spam at 0x7f0bde4fd1f8') == 'spam'
    assert normalize_repr('spam at 0x7f0bde4fd1f8 at 0x7f0bde4fd1f8') == \
                                                                      'spam'
    assert normalize_repr('spam at 0x7f0bde4fd1f8 at 0x7f0bde4fd1f8 at') == \
                                                                      'spam'
    assert normalize_repr('') == ''
    assert normalize_repr('spam at 0x7f0bde4fd1f8 at') == 'spam'

# Generated at 2022-06-22 18:31:33.401872
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abc') == 'abc'
    assert get_shortish_repr('abc\ndef') == 'abc def'
    assert get_shortish_repr('abc') == 'abc'
    assert get_shortish_repr('a' * 100) == 'a' * 100
    assert get_shortish_repr('a' * 100, max_length=6) == 'a' * 6 + '...'
    assert get_shortish_repr('a' * 100, max_length=7) == 'a' * 7 + '...'
    assert (get_shortish_repr('a' * 100, max_length=8) == 'a' * 8 + '...')

# Generated at 2022-06-22 18:31:41.471108
# Unit test for function normalize_repr

# Generated at 2022-06-22 18:31:44.724026
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)



# Generated at 2022-06-22 18:31:54.010437
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from . import testing_tools
    from . import assert_equal

    assert_equal(get_shortish_repr(None), 'None')
    assert_equal(get_shortish_repr(1), '1')
    assert_equal(get_shortish_repr(testing_tools.TrivialClass()),
                 'trivial_class')
    assert_equal(get_shortish_repr(testing_tools.TrivialClass.__dict__['__init__']),
                 '<function trivial_class>')

    assert_equal(get_shortish_repr(testing_tools.TrivialClass(), max_length=2),
                 't.')
    assert_equal(get_shortish_repr(testing_tools.TrivialClass(), max_length=3),
                 'tr.')


# Generated at 2022-06-22 18:31:59.567577
# Unit test for function shitcode
def test_shitcode():
    """ Testing shitcode using helpers """
    message = 'That\'s a {}.'.format(shitcode('maïs'))
    assert message == 'That\'s a ma?s.', message
    message = 'That\'s a {}.'.format(shitcode('maïs'.encode('utf-8')))
    assert message == 'That\'s a ma?s.', message



# Generated at 2022-06-22 18:32:03.348352
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class _WritableStream(WritableStream):
        pass
    assert WritableStream.__subclasshook__(_WritableStream)



# Generated at 2022-06-22 18:32:07.470885
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('a at 0x1234') == 'a'
    assert normalize_repr('a') == 'a'

    assert normalize_repr('a at 0x123456789abcdef') == 'a'



# Generated at 2022-06-22 18:32:11.422067
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    # Testing "normalized"
    assert get_shortish_repr(5, normalize=True) == '5'
    assert get_shortish_repr((5,), normalize=True) == '(5,)'
    assert get_shortish_repr((5, 6, 7), normalize=True) == '(5, 6, 7)'
    assert get_shortish_repr((5,), normalize=True,) == '(5,)'
    assert get_shortish_repr(5., normalize=True) == '5.0'
    assert get_shortish_repr(5., normalize=True) == '5.0'
    assert get_shortish_repr(5+6j, normalize=True) == '(5+6j)'

# Generated at 2022-06-22 18:32:22.286852
# Unit test for function get_repr_function
def test_get_repr_function():
    from .compatibility.abc import abstractmethod

    f = get_repr_function

    class D(object): pass
    class C(D): pass

    def repr_function_1(item, ignored_argument=None): return 'repr_function_1'
    def repr_function_2(item, ignored_argument=None): return 'repr_function_2'
    def repr_function_3(item, ignored_argument=None): return 'repr_function_3'
    def repr_function_4(item, ignored_argument=None): return 'repr_function_4'
    def repr_function_5(item, ignored_argument=None): return 'repr_function_5'

    assert f(C, custom_repr=[]) == repr


# Generated at 2022-06-22 18:32:25.204836
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(42) == (42,)
    assert ensure_tuple([42, 'hello', True]) == (42, 'hello', True)
    assert ensure_tuple((42, 'hello', True)) == (42, 'hello', True)

# Generated at 2022-06-22 18:32:31.316467
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', 11) == '1234567890'
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('1234567890', 9) == '1234567890'
    assert truncate('1234567890', 8) == '1234567890'
    assert truncate('1234567890', 7) == '12345...'
    assert truncate('1234567890', 6) == '12345...'
    assert truncate('1234567890', 5) == '12345...'
    assert truncate('1234567890', 4) == '12345...'
    assert truncate('1234567890', 3) == '12345...'
    assert truncate('1234567890', 2) == '12345...'

# Generated at 2022-06-22 18:32:33.725878
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('עברית') == '?????'



# Generated at 2022-06-22 18:32:38.890438
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def __init__(self, *args, **kwargs):
            self.buffer = []
        def write(self, s):
            self.buffer.append(s)

    writable_stream = MyWritableStream()
    writable_stream.write('hello')
    assert writable_stream.buffer == ['hello']



# Generated at 2022-06-22 18:32:43.675929
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == ([1],)
    assert ensure_tuple([1, 2]) == ([1, 2],)
    assert ensure_tuple({1: 2}) == ({1: 2},)
    assert ensure_tuple((1, 2)) == ((1, 2),)
    assert ensure_tuple((1,)) == ((1,),)
    assert ensure_tuple('abc') == ('abc',)



# Generated at 2022-06-22 18:32:50.582244
# Unit test for function normalize_repr
def test_normalize_repr():
    def test(repr_string):
        assert repr_string == normalize_repr(repr_string)
    test('hello')
    test('hello world')
    test('"hello"')
    test('')
    test('    ')
    test('\n\r')
    test('\n\r\t')
    test('"hello" world')
    test('"hello"\n\rworld')
    test('"hello"\n\rworld')
    test('"hello"\n\rworld"goodbye"')
    test('"hello"\n\rworld\n"goodbye"')
    test('"hello"\n\rworld\n"goodbye"\n')
    test('"hello"\n\rworld\n"goodbye"\n\t')
    test

# Generated at 2022-06-22 18:32:59.687975
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', None) == 'hello'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 4) == 'hell...'
    assert truncate('hello', 1) == 'he...'
    assert truncate('hello', 2) == 'he...'
    assert truncate('hello', 3) == 'he...'
    assert truncate('hello', 7) == ' hello'
    assert truncate('hello', 8) == ' hello'
    assert truncate('hello', 9) == 'hello'
    assert truncate('hello', 10) == 'hello'
    assert truncate('hello', 11) == 'hello'
    assert truncate('hello', 1) == 'he...'
    assert truncate('hello', 2) == 'he...'

# Generated at 2022-06-22 18:33:10.028105
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .pycompat import StringIO
    import contextlib

    @contextlib.contextmanager
    def _mock_stdout():
        original = sys.stdout
        sys.stdout = StringIO()
        yield sys.stdout
        sys.stdout = original

    with _mock_stdout() as stdout:
        stdout.write('test')
        assert issubclass(type(stdout), WritableStream)
        class A(WritableStream):
            def write(self, s):
                pass
        class B(A):
            def __init__(self):
                pass
        a = A()
        b = B()
        assert isinstance(a, WritableStream)
        assert isinstance(b, WritableStream)

# Generated at 2022-06-22 18:33:19.033078
# Unit test for function shitcode
def test_shitcode():
    string = r'hello, world!'
    assert shitcode(string) == string
    assert shitcode(u'привет') == '??????'
    assert shitcode(u'hello, world!') == string
    assert shitcode(b'hello, world!') == string
    assert shitcode(b'\xC4\xF1\xEB\xE5\xFF') == '???'
    assert shitcode(bytearray(b'hello, world!')) == string
    assert shitcode(bytearray(b'\xC4\xF1\xEB\xE5\xFF')) == '???'
    assert shitcode([1, 2, 3]) == '[1, 2, 3]'

# Generated at 2022-06-22 18:33:30.441645
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr_1 = (
        (str, lambda _: 'str'),
        (list, lambda x: 'list of {}'.format(
            ','.join(str(item) for item in x)))
    )
    custom_repr_2 = custom_repr_1 + (
        (set, lambda x: 'set of {}'.format(
            ','.join(str(item) for item in x)))
    )
    def check(item, custom_repr, expected_result):
        repr_function = get_repr_function(item, custom_repr)
        assert repr_function(item) == expected_result

    check('l', custom_repr_1, 'str')
    check(['l'], custom_repr_1, 'list of l')

# Generated at 2022-06-22 18:33:41.703188
# Unit test for function get_repr_function
def test_get_repr_function():
    from .constants import ETC

    a = (1, 2)
    b = [1, 2]
    c = {1, 2}
    d = {'a': 1, 'b': 2}
    e = 5
    f = 'hello world!'
    thing_list = [a, b, c, d, e, f]

    custom_repr = (
        (lambda x: isinstance(x, tuple), str),
        (lambda x: isinstance(x, list), str),
        (lambda x: isinstance(x, set), str),
        (lambda x: isinstance(x, dict), str),
        (lambda x: isinstance(x, int), str),
        (lambda x: isinstance(x, str), str),
    )


# Generated at 2022-06-22 18:33:47.762759
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)

    assert ensure_tuple(3) == (3,)
    assert ensure_tuple('meow') == ('meow',)

if __name__ == '__main__':
    test_ensure_tuple()

# Generated at 2022-06-22 18:33:52.800482
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('שלום עולם') == '?? ???'
    assert shitcode('אבגדהוזחטיכלמנסעפצקרשת') == '??????? ???? ???????'


# Generated at 2022-06-22 18:34:00.281141
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(int, lambda x: str(x + 1))]) == '2'
    assert get_repr_function(1, [(str, lambda x: str(x + 1))]) == repr
    assert get_repr_function(1, [(lambda x, y=1: x == y, lambda x: str(x + 1))]) == '2'
    assert get_repr_function(1, [(lambda x, y=1: x != y, lambda x: str(x + 1))]) == repr
    assert get_repr_function(1, []) == repr



# Generated at 2022-06-22 18:34:07.276468
# Unit test for function truncate
def test_truncate():
    assert truncate('abcde', 3) == 'abcde'
    assert truncate('abcde', None) == 'abcde'
    assert truncate('abcde', 5) == 'abcde'
    assert truncate('abcde', 8) == 'abcde'
    assert truncate('abcde', 3, ellipsis=True) == 'abc...'
    assert truncate('abcde', 8, ellipsis=True) == 'abcde'
    assert truncate('abcde', 5, ellipsis=True) == 'abcde'
    assert truncate('abcde', 4, ellipsis=True) == 'ab...'

# Generated at 2022-06-22 18:34:10.188802
# Unit test for function ensure_tuple
def test_ensure_tuple():
    for x in 'abc', [1, 2, 3], (4, 5, 6), 123:
        assert isinstance(ensure_tuple(x), tuple)
        assert ensure_tuple(x) == (x,)

# Generated at 2022-06-22 18:34:14.112670
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x26dee') == 'hello'
    assert normalize_repr('hello at 0x26dee and world at 0x26def') == \
                                                                  'hello and world'

# Generated at 2022-06-22 18:34:25.690593
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('viva la vida at 0xDEAD') == 'viva la vida'
    assert normalize_repr('viva la vida at 0xDEAD') == 'viva la vida'
    assert normalize_repr('viva la vida at 0xDEAD1234') == 'viva la vida'
    assert normalize_repr('viva la vida at 0x1234DEAD') == 'viva la vida'
    assert normalize_repr('viva la vida at 0xDEADBEEF') == 'viva la vida'
    assert normalize_repr('viva la vida at 0xDEADBEAF') == 'viva la vida'


# Generated at 2022-06-22 18:34:28.964175
# Unit test for function normalize_repr
def test_normalize_repr():
    s = 'CuteFile at 0x7F648F89665C>'
    assert normalize_repr(s) == 'CuteFile>'

# Unit tests for function truncate

# Generated at 2022-06-22 18:34:35.777691
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hi mom') == 'hi mom'

    assert shitcode(u'hi mom') == 'hi mom'

    assert shitcode(u'a\xA2m') == 'a?m'

    assert shitcode(u'a\u2500m') == 'a?m'

    if sys.version_info[0] < 3:
        assert shitcode(bytearray('a\xA2m')) == 'a?m'

# Generated at 2022-06-22 18:34:39.628296
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X:
        def write(self, s):
            pass

    class Y(X):
        pass

    assert_equal(issubclass(X, WritableStream), True)
    assert_equal(issubclass(Y, WritableStream), True)
    assert_equal(issubclass(type, WritableStream), False)



# Generated at 2022-06-22 18:34:45.358512
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(5) == (5,)
    assert ensure_tuple([5]) == ([5],)
    assert ensure_tuple((5,)) == (5,)
    assert ensure_tuple('foo') == ('foo',)
    assert ensure_tuple(u'foo') == (u'foo',)
    assert ensure_tuple('foo') == ensure_tuple(('foo',))
    assert ensure_tuple(None) == (None,)



# Generated at 2022-06-22 18:34:51.063272
# Unit test for function truncate
def test_truncate():
    max_length = 10

    def call_truncate(string):
        return truncate(string, max_length)

    assert call_truncate('') == ''
    assert call_truncate('abc') == 'abc'
    assert call_truncate('abcdefghij') == 'abcdefghij'
    assert call_truncate('abcdefghijk') == '...hijk'
    assert call_truncate('abcdefghijkl') == '...ijkl'
    assert call_truncate('abcdefghijklm') == '...jklm'
    assert call_truncate('abcdefghijklmn') == '...klmn'
    assert call_truncate('abcdefghijklmno') == '...lmno'

# Generated at 2022-06-22 18:34:56.899092
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import io
    class A(WritableStream):
        def __init__(self, file_object):
            self.file_object = file_object
        def write(self, s):
            return self.file_object.write(s)

    file_object = io.StringIO()
    writable_stream = A(file_object)
    assert sys.stdout.writable() == True
    assert isinstance(writable_stream, WritableStream)



# Generated at 2022-06-22 18:35:01.144921
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("hello at 0x12345678") == "hello"
    assert normalize_repr("hi at 0x78563412") == "hi"
    assert normalize_repr("hi") == "hi"



# Generated at 2022-06-22 18:35:11.294092
# Unit test for function normalize_repr
def test_normalize_repr():
    from .pycompat import StringIO

    class Test:
        def __repr__(self):
            return 'repr'

    class Test2:
        def __str__(self):
            return 'str'

    assert normalize_repr(repr(Test())) == 'repr'
    assert normalize_repr(str(Test2())) == 'str'

    assert normalize_repr('12345') == '12345'
    assert normalize_repr('a' * 100) == 'a' * 100

    assert normalize_repr(repr(StringIO('a' * 100))) == repr(StringIO('a' * 100))

# Generated at 2022-06-22 18:35:22.138149
# Unit test for function normalize_repr
def test_normalize_repr():
    for obj in [
        123,
        u'abc',
        set((1, 2, 3))
    ]:
        assert normalize_repr(repr(obj)) == repr(obj)

    for obj in [
        {},
        {1: 2},
        set(),
        set((1, 2, 3)),
        [],
        [1, 2, 3],
        123,
        u'abc',
    ]:
        repr(obj)
        repr_before = repr(obj)
        repr_after = normalize_repr(repr_before)
        assert repr_after.startswith('{') or repr_after.startswith('[') or \
                                                                repr_after[0].isnumeric()
        assert repr_after.endswith('}') or repr_after.end

# Generated at 2022-06-22 18:35:23.688816
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Planet(WritableStream):
        def write(self, thing):
            print(thing, end='')
    Planet().write('hello')

# Generated at 2022-06-22 18:35:25.362144
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abcd') == 'abcd'
    assert shitcode('ab\x00cd') == 'ab?cd'

# Generated at 2022-06-22 18:35:27.806548
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('meow') == ('meow',)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)

# Generated at 2022-06-22 18:35:37.130739
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x0000') == 'hello'
    assert normalize_repr('hello at 0x0000000') == 'hello'
    assert normalize_repr('hello at 0xAAAA0000') == 'hello'
    assert normalize_repr('hello at 0x0000AAAA') == 'hello'
    assert normalize_repr('hello...at...0x0000AaAA') == 'hello...at...0x0000AaAA'
    assert normalize_repr('...hello...at...0x0000AaAA...') == '...hello...at...0x0000AaAA...'

# Generated at 2022-06-22 18:35:47.598502
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(5, []) == repr
    assert get_repr_function(5, [(lambda x: x%2, lambda x: 'x%2')]) == repr

# Generated at 2022-06-22 18:35:53.234474
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=10) == '1'
    assert get_shortish_repr(1, max_length=0) == '1'
    assert get_shortish_repr(1, max_length=5) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=1, normalize=True) == '1'
    assert get_shortish_repr(1.5, max_length=1, normalize=True) == '1.5'
    assert get_shortish_