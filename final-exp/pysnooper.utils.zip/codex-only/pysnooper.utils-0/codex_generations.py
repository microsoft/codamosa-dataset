

# Generated at 2022-06-22 18:26:00.792683
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert 'hey' == get_shortish_repr('hey')
    assert 'hey' == get_shortish_repr('hey', max_length=5)
    assert 'hey' == get_shortish_repr('hey', max_length=6)
    assert 'he...' == get_shortish_repr('hey', max_length=5, normalize=True)
    assert 'he...' == get_shortish_repr('hey', max_length=4, normalize=True)
    assert 'foo...' == get_shortish_repr('foobarbaz', max_length=7,
                                         normalize=True)
    assert get_repr_function(3, [(lambda x: isinstance(x, int), str)]) == str

# Generated at 2022-06-22 18:26:09.319758
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'hello') == 'hello'
    assert shitcode(u'שלום') == '????'
    assert shitcode(u'\u263a') == '?'
    assert shitcode(u'\u0001') == '?'
    assert shitcode(u'\u0002') == '?'
    assert shitcode(u'\u0003') == '?'
    assert shitcode(u'\u0004') == '?'
    assert shitcode(u'\u0005') == '?'
    assert shitcode(u'\u0006') == '?'
    assert shitcode(u'\u0007') == '?'
    assert shitcode(u'\u0008') == '?'
    assert shitcode(u'\u000e') == '?'

# Generated at 2022-06-22 18:26:11.058186
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)

# Generated at 2022-06-22 18:26:15.052244
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from . import stdout
    from .stdout import stdout
    from .terminal import Terminal
    from .dummy import Dummy
    assert issubclass(stdout.Stdout, WritableStream)
    assert issubclass(Terminal, WritableStream)
    assert issubclass(Dummy, WritableStream)

# Generated at 2022-06-22 18:26:20.602737
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x1234') == 'hello'
    assert normalize_repr('hello at 0x1234 at 0x5678') == 'hello'
    assert normalize_repr('hello at 0x1234 at 0x5678 at 0x9012') == 'hello'



# Generated at 2022-06-22 18:26:30.909541
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .length import Length
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr('a') == "'a'"
    assert get_shortish_repr(Length('1m')) == "Length('1m')"
    assert get_shortish_repr((1, 2, 3)) == '(1, 2, 3)'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr((1, 2, 3), max_length=3) == '(1, 2, 3)'
    assert get_shortish_repr((1, 2, 3), max_length=2) == '(1, 2, ...)'

# Generated at 2022-06-22 18:26:41.939516
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("MyClass object at 0x10fb291d0") == "MyClass object"
    assert normalize_repr("MyClass object at 0x10fb291d0"
                          ".MyClass object at 0x10fb291d0")=="MyClass object"
    assert normalize_repr("MyClass object") == "MyClass object"
    assert normalize_repr("MyClass") == "MyClass"
    assert normalize_repr("MyClass.MyClass") == "MyClass.MyClass"
    assert normalize_repr("MyClass.MyClass at 0x120817950")=="MyClass.MyClass"
    assert normalize_repr("MyClass.MyClass.MyClass") == "MyClass.MyClass.MyClass"

# Generated at 2022-06-22 18:26:46.627192
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class TestWritableStream(WritableStream):
        string = None
        def write(self, s):
            self.string = s
    test_writable_stream = TestWritableStream()
    test_writable_stream.write('hello world')
    assert test_writable_stream.string == 'hello world'



# Generated at 2022-06-22 18:26:51.175227
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert get_shortish_repr([1, 2, 3], max_length=3) == '[1...]'
    assert get_shortish_repr([1, 2, 3], normalize=True) == '[1, 2, 3]'



# Generated at 2022-06-22 18:26:55.064230
# Unit test for function shitcode
def test_shitcode():
    u = u'\N{GREEK CAPITAL LETTER SIGMA}'
    r = shitcode(u)
    assert r == u'?'
    assert isinstance(r, str)

# Generated at 2022-06-22 18:26:58.551845
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(WritableStream):
        def __init__(self):
            pass
    class Bar:
        pass
    assert issubclass(Foo, WritableStream)
    assert not issubclass(Bar, WritableStream)

# Generated at 2022-06-22 18:27:05.431316
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('Hello world!', max_length=None) == 'Hello world!'
    assert get_shortish_repr('Hello world!', max_length=11) == 'Hello world!'
    assert get_shortish_repr('Hello world!', max_length=10) == 'Hello worl...'
    assert get_shortish_repr('Hello world!', max_length=9) == 'Hello wor...'
    assert get_shortish_repr('Hello world!', max_length=8) == 'Hello wo...'
    assert get_shortish_repr('Hello world!', max_length=7) == 'Hello w...'
    assert get_shortish_repr('Hello world!', max_length=6) == 'Hello ...'

# Generated at 2022-06-22 18:27:15.049171
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(3) == '3'
    assert get_shortish_repr(3.3) == '3.3'
    assert get_shortish_repr(object) == '<class \'object\'>'
    assert get_shortish_repr(object(), max_length=11) == 'REPR FAILED'
    assert get_shortish_repr(object(), max_length=40) == '<object object at 0x000000000000002>'
    assert get_shortish_repr('a' * 200, max_length=40) == "'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa...aaaaaaaaaaaaaa'"


    class MyClass(object):
        def __repr__(self):
            raise ValueError


# Generated at 2022-06-22 18:27:23.909567
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hello', ()) == repr
    assert get_repr_function(1, ()) == repr
    assert get_repr_function(1, ((int, str), lambda x: 'int!')) == repr
    assert get_repr_function(1, ((int, str), lambda x: 'int!')) == repr
    assert get_repr_function(1, ((int, str), lambda x: 'int!')) == repr
    assert get_repr_function('1', ((int, str), lambda x: 'int!')) == 'int!'
    assert get_repr_function(1, ((int, str), lambda x: 'int!')) == repr




# Generated at 2022-06-22 18:27:28.335773
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    class MyWritableStream(WritableStream):
        def write(self, s):
            assert isinstance(s, str)
            return len(s)
        def __init__(self, stream):
            self.stream = stream
        def flush(self):
            self.stream.flush()
        def close(self):
            self.stream.close()

    my_writable_stream = MyWritableStream(sys.stdout)

# Generated at 2022-06-22 18:27:29.950019
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass



# Generated at 2022-06-22 18:27:37.731684
# Unit test for constructor of class WritableStream
def test_WritableStream():
    # A class with a `write` method
    class WritableStream1(object):
        def write(self, s):
            return s

    # A class with a `write` method in base class
    class WritableStream2(object):
        pass

    class WritableStream2Base(object):
        def write(self, s):
            return s

    WritableStream2.__bases__ += (WritableStream2Base,)

    # A base class with a `write` method in subclass
    class WritableStream3Base(object):
        pass

    # A subclass with a `write` method in base class
    class WritableStream3(WritableStream3Base):
        def write(self, s):
            return s

    # A base class with a `write` method in base class of subclass

# Generated at 2022-06-22 18:27:43.645129
# Unit test for function ensure_tuple
def test_ensure_tuple():
    x = ()
    assert ensure_tuple(x) is x
    x = (1,2)
    assert ensure_tuple(x) is x
    assert ensure_tuple(range(3)) == (0,1,2)
    assert ensure_tuple(12) == (12,)
    assert ensure_tuple("ab") == ("ab",)
    assert ensure_tuple("a") == ("a",)



# Generated at 2022-06-22 18:27:54.361159
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(2, [(lambda x: True, lambda x: x)])(2) == 2
    assert get_repr_function(3, [(lambda x: True, lambda x: x)])(3) == 3
    assert get_repr_function(2, [(lambda x: x == 3, lambda x: x)])(2) == '2'
    assert get_repr_function(3, [(lambda x: x == 3, lambda x: x)])(3) == 3
    assert get_repr_function(2, [((int, str), lambda x: x)])(2) == 2
    assert get_repr_function(3.0, [((int, str), lambda x: x)])(3.0) == '3.0'

# Generated at 2022-06-22 18:27:56.247111
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'hello') == u'hello'
    assert shitcode(u'\u2713') == u'?'



# Generated at 2022-06-22 18:28:02.401939
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Pipe(WritableStream):
        def __init__(self): self.data = ''
        def write(self, s): self.data += s
    one_line = 'abc\ndef\n'
    multi_line = 'abc\ndef\n'
    pipe = Pipe()
    pipe.write(one_line)
    assert pipe.data == one_line
    pipe = Pipe()
    pipe.write(multi_line)
    assert pipe.data == multi_line

# Generated at 2022-06-22 18:28:04.358566
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritable(object):
        def write(self, s):
            print('write called')

    assert isinstance(MyWritable(), WritableStream)

# Generated at 2022-06-22 18:28:09.237726
# Unit test for constructor of class WritableStream
def test_WritableStream():
    """
    This class is just an interface. It doesn't really have a behavior, but
    we still want to test that our implementation is compatible with classes
    that inherit it. So we'll just try to inherit it and check that the
    inheritance succeeds.
    """
    class Test(WritableStream):
        pass
    assert issubclass(Test, WritableStream)



# Generated at 2022-06-22 18:28:20.004842
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert '234567890' == get_shortish_repr('234567890', max_length=None)
    assert '234567890' == get_shortish_repr('234567890', max_length=10)
    assert '23...7890' == get_shortish_repr('234567890', max_length=7)
    assert '[23, 45, ..., 89, 0]' == get_shortish_repr(range(10), max_length=17)
    assert 'range(...' == get_shortish_repr(range(10), max_length=10)
    assert '[1, 2, 3, ...]' == get_shortish_repr([1, 2, 3, 4, 5, 6], max_length=17)

# Generated at 2022-06-22 18:28:29.765626
# Unit test for function shitcode
def test_shitcode():
    example_strings = [
        '',
        'a',
        'Hello, world!',
        '♥',
        '♥♥♥♥♥♥♥♥♥♥',
        'ÞÞÞÞÞÞÞÞÞÞÞÞÞÞÞÞ',
        'ĦĦĦĦĦĦĦĦĦĦĦĦĦĦĦĦĦĦĦĦ',
    ]
    for s in example_strings:
        assert shitcode(s) == s
        s += '\0'
        assert shitcode(s) == s[:-1] + '?'
        s += '\1\2\3\4\5'
        assert shitcode(s) == s[:-5]

# Generated at 2022-06-22 18:28:33.263521
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class JustWriter(WritableStream):
        def __init__(self):
            self.observed_things = []
        def write(self, s):
            self.observed_things.append(s)
    jw = JustWriter()
    assert jw.observed_things == []
    jw.write('hello')
    assert jw.observed_things == ['hello']

# Generated at 2022-06-22 18:28:35.621926
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class X:
        def write(self, s):
            pass

    class Y:
        pass

    assert issubclass(X, WritableStream)
    assert not issubclass(Y, WritableStream)

# Generated at 2022-06-22 18:28:38.677632
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple('hello') == ('hello',)



# Generated at 2022-06-22 18:28:49.989818
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from six import StringIO
    class Test1(object):
        pass
    assert not isinstance(Test1(), WritableStream)

    class Test2(object):
        def write(self, s):
            return s
    assert isinstance(Test2(), WritableStream)

    class Test3(object):
        def write(self, s):
            return s.upper()
    assert isinstance(Test3(), WritableStream)

    class Test4(object):
        def write(self, s):
            return s
        def write_uppercase(self, s):
            return s.upper()
    assert isinstance(Test4(), WritableStream)

    class Test5(object):
        def write_uppercase(self, s):
            return s.upper()
    assert not isinstance(Test5(), WritableStream)



# Generated at 2022-06-22 18:28:58.975572
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ()) is repr
    assert get_repr_function(1, ((int, lambda: 'int'),)) == 'int'
    assert get_repr_function(1, ((lambda x: x > 5, lambda: '>5'),)) == '>5'
    assert get_repr_function(1,
                             ((lambda x: x > 5, lambda: '>5'),
                              (int, lambda: 'int'))
                            ) == 'int'
    assert get_repr_function(1,
                             ((lambda x: x > 5, lambda: '>5'),
                              (lambda x: x == 1, lambda: '==1'),
                              (int, lambda: 'int'))
                            ) == '==1'

# Generated at 2022-06-22 18:29:08.334834
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from . import assert_equal, assert_all

    class A(object):
        def __repr__(self):
            return '<A>'

    class B(object):
        def __repr__(self):
            return '<B>'

    assert_equal(
        get_shortish_repr(123, custom_repr=[(int, 'INTEGER')]),
        'INTEGER'
    )
    assert_equal(get_shortish_repr(A()), '<A>')
    assert_equal(get_shortish_repr(B()), '<B>')

    assert_equal(get_shortish_repr(A(), custom_repr=[(A, 'yes')]), 'yes')


# Generated at 2022-06-22 18:29:18.876052
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdefghijklmnopqrstuvwxyz', None) == \
                          'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 26) == \
                          'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 25) == \
                          'abcdefghijklmnopqrstuvwxyz'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 24) == \
                          'abcdefghijklmnopqrstuv...'

# Generated at 2022-06-22 18:29:29.774687
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    custom_reprs = (
        (lambda x: isinstance(x, list),       lambda x: u'LIST({})'.format(truncate(str(x), 20))),
        (lambda x: isinstance(x, set),        lambda x: u'SET({})'.format(truncate(str(x), 20))),
        (lambda x: isinstance(x, dict),       lambda x: u'DICT({})'.format(truncate(str(x), 20))),
        (lambda x: isinstance(x, tuple),      lambda x: u'TUPLE({})'.format(truncate(str(x), 20))),
        (lambda x: isinstance(x, string_types), lambda x: truncate(x, 20).encode('ascii', 'replace')),
    )

    assert get_

# Generated at 2022-06-22 18:29:32.309396
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr("<__main__.Foo object at 0x000002DBF0AC76D8>") == "<__main__.Foo object>"



# Generated at 2022-06-22 18:29:40.033587
# Unit test for function get_repr_function
def test_get_repr_function():
    from .custom_repr import CustomRepr, CustomReprException

    class A(object):
        def __init__(self, x):
            self.x = x

    class B(A):
        def __init__(self, x, y):
            super(B, self).__init__(x)
            self.y = y

    class C(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

    class D(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

    # Test that we get different reprs for different criteria

# Generated at 2022-06-22 18:29:48.477432
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, [(lambda x: True, lambda x: '123')]) == '123'
    assert get_repr_function(1, [(lambda x: False, lambda x: '123')]) == repr
    assert get_repr_function(1, [(lambda x: False, lambda x: '123'),
                                 (lambda x: True, lambda x: '456')]) == '456'
    assert get_repr_function(1, [(lambda x: True, lambda x: '123'),
                                 (lambda x: True, lambda x: '456')]) == '123'



# Generated at 2022-06-22 18:29:51.369473
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert isinstance(MyWritableStream, WritableStream)
    assert issubclass(MyWritableStream, WritableStream)

# Generated at 2022-06-22 18:29:59.325908
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(5, max_length=5) == '5'
    assert get_shortish_repr(5, max_length=6) == '5'
    assert get_shortish_repr(5, max_length=7) == '5'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=5) == \
                                                                    'ab...yz'
    assert get_shortish_repr('abcdefghijklmnopqrstuvwxyz', max_length=6) == \
                                                                    'ab...yz'

# Generated at 2022-06-22 18:30:04.466775
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyStream(WritableStream):
        def __init__(self):
            self.data = ''

        def write(self, s):
            self.data += s

    my_stream = MyStream()
    assert issubclass(MyStream, WritableStream)
    assert isinstance(my_stream, WritableStream)

    my_stream.write('Hey')
    assert my_stream.data == 'Hey'



# Generated at 2022-06-22 18:30:11.193172
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    my_writable_stream = MyWritableStream()
    assert isinstance(my_writable_stream, WritableStream)

    class NotMyWritableStream(WritableStream):
        def write(self, s):
            pass
        def foo(self):
            pass

    my_not_writable_stream = NotMyWritableStream()
    assert not isinstance(my_not_writable_stream, WritableStream)

# Generated at 2022-06-22 18:30:21.814558
# Unit test for function truncate
def test_truncate():
    assert truncate('', 0) == ''
    assert truncate('', 1) == ''
    assert truncate('', 2) == ''

    assert truncate('a', 0) == ''
    assert truncate('a', 1) == 'a'
    assert truncate('a', 2) == 'a'
    assert truncate('a', 3) == 'a'

    assert truncate('ab', 0) == ''
    assert truncate('ab', 1) == '.'
    assert truncate('ab', 2) == 'a'
    assert truncate('ab', 3) == 'a.'
    assert truncate('ab', 4) == 'ab'

    assert truncate('a\nb', 0) == ''
    assert truncate('a\nb', 1) == '.'
    assert truncate('a\nb', 2) == 'a'


# Generated at 2022-06-22 18:30:25.819573
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr([1, 23], max_length=5) == '[1,...]'
    assert get_shortish_repr([1, 23], max_length=3) == '[...]'
    assert get_shortish_repr(1, normalize=True) == '1'



# Generated at 2022-06-22 18:30:37.233113
# Unit test for function truncate
def test_truncate():
    assert truncate('Hi there', None) == 'Hi there'
    assert truncate('Hi there', 10) == 'Hi there'
    assert truncate('Hi there', 9) == 'Hi there'
    assert truncate('Hi there', 8) == 'Hi th...'
    assert truncate('Hi there', 7) == 'Hi...'
    assert truncate('Hi there', 6) == 'Hi...'
    assert truncate('Hi there', 5) == 'Hi...'
    assert truncate('Hi there', 4) == 'H...'
    assert truncate('Hi there', 3) == '...'
    assert truncate('Hi there', 2) == '...'
    assert truncate('Hi there', 1) == '...'
    assert truncate('Hi there', 0) == '...'

# Generated at 2022-06-22 18:30:44.233273
# Unit test for function get_repr_function
def test_get_repr_function():
    class A(object): pass
    class B(A): pass

    assert get_repr_function(A(), ((int, str), id)) == id
    assert get_repr_function(A(), ((A, str), id)) == id
    assert get_repr_function(B(), ((int, str), id)) == id
    assert get_repr_function(B(), ((A, str), id)) == id
    assert get_repr_function(B(), ((A, str), 'wrong'))() == 'wrong'



# Generated at 2022-06-22 18:30:52.902740
# Unit test for constructor of class WritableStream
def test_WritableStream():
    import pytest
    from .pycompat import PY2
    class A(WritableStream):
        def write(self, s):
            pass
    class B(A):
        pass
    class C(B):
        def writable(self):
            pass
    class D(C):
        pass
    assert issubclass(A, WritableStream)
    assert issubclass(B, WritableStream)
    assert not issubclass(C, WritableStream)
    if PY2:
        assert issubclass(D, WritableStream)
    else:
        assert not issubclass(D, WritableStream)

# Generated at 2022-06-22 18:30:58.333605
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=0) == ''
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=1, normalize=True) == '1'
    assert get_shortish_repr(1, max_length=1, normalize=True) == '1'
    assert get_shortish_repr(
        object(),
        max_length=1
    ) == r"<object object at 0x[a-f0-9A-F]{4,}>"
    assert get_shortish_repr

# Generated at 2022-06-22 18:30:59.329021
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(3) == (3,)
    assert ensure_tuple((1,2)) == (1,2)



# Generated at 2022-06-22 18:31:03.141448
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import StringIO
    class O(object):
        pass
    class C(object):
        def write(self, s):
            pass
    assert WritableStream.__subclasshook__(O) is NotImplemented
    assert WritableStream.__subclasshook__(C) is True
    assert WritableStream.__subclasshook__(StringIO()) is True
    assert WritableStream.__subclasshook__(1) is NotImplemented



# Generated at 2022-06-22 18:31:14.024288
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function('hi', ()) == repr
    assert get_repr_function('hi', map(None, ()))(42) == '42'
    assert get_repr_function('hi', (lambda x: isinstance(x, str),)) == str
    assert get_repr_function(123, ((lambda x: x == 'hi', str),)) == repr
    assert get_repr_function('hi', ((lambda x: x == 'hi', str),)) == str
    assert get_repr_function('hi', ((str, str),)) == str
    assert get_repr_function('hi', ((str,),)) == str
    assert get_repr_function('hi', (str,)) == str
    assert get_repr_function('hi', ((str,), (int, lambda x: int(x))))

# Generated at 2022-06-22 18:31:19.382213
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('1234567890', 5) == '12...90'
    assert truncate('1234567890', 4) == '1...0'


with_repr = lambda item: '{} ({})'.format(
    item[0],
    get_shortish_repr(item[1], max_length=40)
)



# Generated at 2022-06-22 18:31:30.672254
# Unit test for function normalize_repr
def test_normalize_repr():
    cases = [
        (
            '<function foo at 0x7f1894d2d400>',
            '<function foo>'
        ),
        (
            '<function foo at 0x7f1894d2d400>',
            '<function foo>'
        ),
        (
            '<function foo at 0x7f1894d2d400>',
            '<function foo>'
        ),
        (
            '<function foo at 0x7f1894d2d400>',
            '<function foo>'
        ),
        (
            '<function foo at 0x7f1894d2d400>',
            '<function foo>'
        ),
    ]
    for case in cases:
        assert normalize_repr(case[0]) == case[1]

# Generated at 2022-06-22 18:31:34.425783
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('hello') == 'hello'
    assert shitcode('hello\xa6') == 'hello?'
    assert shitcode('hello\xa6\xa7\xa8\xa9\xaa\xab\xac\xad\xae\xaf') == \
                                                   'hello??????????'



# Generated at 2022-06-22 18:31:37.111207
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc´def') == 'abc?def'
    assert shitcode('abc\rdef') == 'abcdef'
    assert shitcode('abc\ndef') == 'abcdef'

# Generated at 2022-06-22 18:31:41.509527
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'abc') == u'abc'
    assert shitcode(u'a\xefbc') == u'a?bc'
    assert shitcode(u'a\x00bc') == u'a?bc'
    assert shitcode(u'a\x01bc') == u'a?bc'

# Generated at 2022-06-22 18:31:52.241654
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', 3) == 'hel...'
    assert truncate('hello', 6) == 'hello'
    assert truncate('hello', 10) == 'hello'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', None) == 'hello'
    assert truncate(u'hello', 3) == u'hel...'
    assert truncate(u'hello', 6) == u'hello'
    assert truncate(u'hello', 10) == u'hello'
    assert truncate(u'hello', 5) == u'hello'
    assert truncate(u'hello', None) == u'hello'
    assert truncate(b'hello', 3) == b'hel...'
    assert truncate(b'hello', 6) == b'hello'

# Generated at 2022-06-22 18:31:59.569135
# Unit test for function shitcode
def test_shitcode():
    x = shitcode(u'ab\x80\x90\xAD\xCf\xE0\x5f')  # non-ascii
    assert x == u'ab???????_'


if sys.version_info >= (3, 4):
    from .abc3 import abstractmethod, abstractproperty, abstractclassmethod
else:
    from abc import abstractmethod, abstractproperty, abstractclassmethod
    ## See for `abstractproperty`: https://stackoverflow.com/a/31872138/2609272

# Generated at 2022-06-22 18:32:07.289792
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'') == ''
    assert shitcode(u'abc') == 'abc'
    if sys.com_index is not None:
        assert shitcode(u'\uFFFF') == u'\uFFFF' # nop for wide string
    else:
        assert shitcode(u'\uFFFF') == '?'
    assert shitcode(u'\xFF') == '?'



# Generated at 2022-06-22 18:32:13.742830
# Unit test for function truncate

# Generated at 2022-06-22 18:32:23.209421
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    my_type = type(lambda: 0)
    class MyClass(object): pass
    my_class = MyClass()
    assert 'repr' == get_shortish_repr(lambda: 0)
    assert 'repr' == get_shortish_repr(lambda: 0, custom_repr=[])
    assert 'function' == get_shortish_repr(lambda: 0, custom_repr=[
        (lambda x: x, lambda x: 'function')
    ])
    assert 'lambda' == get_shortish_repr(lambda: 0, custom_repr=[
        (lambda x: x, lambda x: 'lambda')
    ])
    assert 'type' == get_shortish_repr(type(None), custom_repr=[
        (lambda x: x, lambda x: 'type')
    ])


# Generated at 2022-06-22 18:32:25.043341
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class A(WritableStream):
        def write(self, s):
            pass
    assert issubclass(A, WritableStream)



# Generated at 2022-06-22 18:32:27.050501
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class FakeFile(WritableStream):
        def write(self, s):
            pass

    f = FakeFile()
    f.write('bla')



# Generated at 2022-06-22 18:32:35.408983
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import StringIO

    class StdOut:
        """A fake `sys.stdout` object."""
        def write(self, s):
            sys.__stdout__.write(s)


    class MyWritableStream(WritableStream):
        def write(self, s):
            pass

    assert issubclass(MyWritableStream, WritableStream)
    assert issubclass(StringIO.StringIO, WritableStream)
    assert not issubclass(object, WritableStream)
    assert not issubclass(StdOut, WritableStream)



# Generated at 2022-06-22 18:32:39.734395
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import BytesIO
    from .py3compat import Bytes
    ws = WritableStream()
    b = BytesIO()
    b.write = lambda x: ws.write(x.decode())
    b.write(Bytes('text', 'utf-8'))

# Generated at 2022-06-22 18:32:45.813061
# Unit test for function get_repr_function
def test_get_repr_function():
    class A: pass
    class B(A): pass
    class C(A): pass

    repr_function = get_repr_function(B(), [
        (A, lambda x: 'A'),
        (B, lambda x: 'B'),
        (C, lambda x: 'C'),
    ])
    assert repr_function(A()) == 'A'
    assert repr_function(B()) == 'B'
    assert repr_function(C()) == 'C'



# Generated at 2022-06-22 18:32:56.945413
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None) is None

    assert get_repr_function(
        None,
        custom_repr=(
            (lambda x: x is None, repr),
            (lambda x: x is not None, None),
        )
    ) is repr

    assert get_repr_function(
        False,
        custom_repr=(
            (lambda x: x is not None, None),
        )
    ) is None

    assert get_repr_function(
        True,
        custom_repr=(
            (lambda x: x is not None, None),
            (bool, repr),
        )
    ) is repr


# Generated at 2022-06-22 18:33:03.958239
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', None) == 'hello'
    assert truncate('hello', 20) == 'hello'

    assert truncate('hello', 3) == 'he...'
    assert truncate('hello', 4) == 'h...o'
    assert truncate('hello', 2) == '...'
    assert truncate('hello', 1) == '.'
    assert truncate('hello', 0) == '.'

# Generated at 2022-06-22 18:33:06.897493
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyFile(WritableStream):
        def write(self, s):
            pass
    assert isinstance(MyFile(), WritableStream)



# Generated at 2022-06-22 18:33:09.438549
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class XD(WritableStream):
        pass
    assert not issubclass(object, WritableStream)
    assert issubclass(XD, WritableStream)
test_WritableStream()




# Generated at 2022-06-22 18:33:18.771381
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(()) == '()'
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr('asdfasdf') == "'asdfasdf'"
    assert get_shortish_repr('asdfasdf', max_length=5) == "'as...'"
    assert get_shortish_repr([1, 2, 3], max_length=5) == '(1, 2...'
    assert get_shortish_repr([1, 2, 3], max_length=10) == '(1, 2, 3)'
    assert get_shortish_repr([1, 2, 3], max_length=8) == '(1, 2...'

# Generated at 2022-06-22 18:33:22.202271
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(object):
        pass
    a = A()
    a.write = lambda s: sys.stdout.write(s)
    assert isinstance(a, WritableStream)



# Generated at 2022-06-22 18:33:32.504391
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('bla bla bla at 0x08262EEF') == 'bla bla bla'
    assert normalize_repr('bla bla bla at 0x08262EEFABCF') == 'bla bla bla'
    assert normalize_repr('bla bla bla at 0x08262EEF at 0x08262EEF') == \
           'bla bla bla at 0x08262EEF'
    assert normalize_repr('') == ''
    assert normalize_repr('bla bla bla') == 'bla bla bla'
    assert normalize_repr('bla bla bla at 0x08262EEF bla bla bla') == \
           'bla bla bla bla bla bla'

# Generated at 2022-06-22 18:33:40.729421
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdef', None) == 'abcdef'
    assert truncate('abcdef', 6) == 'abcdef'
    assert truncate('abcdef', 7) == 'abcdef'
    assert truncate('abcdef', 5) == 'ab...f'
    assert truncate('abcdef', 4) == 'ab...f'
    assert truncate('abcdef', 3) == '...f'
    assert truncate('abcdef', 2) == '...f'
    assert truncate('abcdef', 1) == '...'
    assert truncate('abcdef', 0) == '...'



# Generated at 2022-06-22 18:33:47.108474
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(complex(1, 2), (
        (complex, lambda x: 'complex number: %s' % x),
    )) == 'complex number: (1+2j)'

    assert get_repr_function(int, (
        (complex, lambda x: 'complex number: %s' % x),
    )) == repr

    assert get_repr_function(int, (
        (int, lambda x: 'int %i' % x),
    )) == 'int 42'

    assert get_repr_function(42, (
        (int, lambda x: 'int %i' % x),
    )) == 'int 42'

    assert get_repr_function(42, (
        (float, lambda x: 'floating-point number %f' % x),
    )) == repr


# Generated at 2022-06-22 18:33:55.814516
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .strings import ue
    class WritableStreamEmulator(object):
        def __init__(self):
            self.the_string = ue('')
        def write(self, s):
            assert isinstance(s, str)
            self.the_string += s
            return None
    wse = WritableStreamEmulator()
    wse.write('1')
    wse.write('2')
    wse.write('3')
    assert wse.the_string == '123'
    print('passed')




# Generated at 2022-06-22 18:33:57.919079
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import io

    assert WritableStream.__subclasshook__(io.StringIO) is True

# Generated at 2022-06-22 18:34:02.203537
# Unit test for function shitcode
def test_shitcode():
    s = 'a'
    for i in range(255):
        assert shitcode(s) == 'a'
        s = s + chr(i)
    s = chr(0) + chr(255)
    assert shitcode(s) == '??'

# Generated at 2022-06-22 18:34:11.892918
# Unit test for function get_shortish_repr
def test_get_shortish_repr():

    assert get_shortish_repr(None) == 'None'
    assert get_shortish_repr(True) == 'True'
    assert get_shortish_repr(False) == 'False'

    assert get_shortish_repr(3) == '3'
    assert get_shortish_repr(3.5) == '3.5'

    assert get_shortish_repr('') == "''"
    assert get_shortish_repr('Hi') == "'Hi'"
    assert get_shortish_repr('A' * 50) == "'" + 'A' * 46 + "...'"

    assert get_shortish_repr(['A', 'B']) == "['A', 'B']"

# Generated at 2022-06-22 18:34:22.659975
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Good:
        def write(self, s):
            pass

    class Bad:
        pass

    class Bad2:
        def write(self, s):
            pass

        def writelines(self, lines):
            pass

    class Good2(Bad):
        def write(self, s):
            pass

    assert issubclass(Good, WritableStream)
    assert issubclass(Good2, WritableStream)
    assert not issubclass(Bad, WritableStream)
    assert not issubclass(Bad2, WritableStream)

    assert isinstance(Good(), WritableStream)
    assert isinstance(Good2(), WritableStream)
    assert not isinstance(Bad(), WritableStream)
    assert not isinstance(Bad2(), WritableStream)



# Generated at 2022-06-22 18:34:26.100883
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple(('a', 'b')) == ('a', 'b')






# Generated at 2022-06-22 18:34:35.382891
# Unit test for function normalize_repr
def test_normalize_repr():
    print(normalize_repr('stack.'))
    print(normalize_repr('stack. at 0x0123456789'))
    print(normalize_repr('stack. at 0x123456789'))
    print(normalize_repr('stack. at 0x12345'))
    print(normalize_repr('stack. at 0x123456789ABC'))
    print(normalize_repr('stack. at 0xabcdef0123456789'))
    print(normalize_repr('stack. at 0xabcdef0123456789ABC'))





# Generated at 2022-06-22 18:34:45.244756
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('ábç') == '?b?'
    assert shitcode('\x00\x01\x02') == '\x00\x01\x02'
    assert shitcode('\xff') == '\xff'
    assert shitcode(u'\u1100') == '?'


if __name__ == '__main__':

    assert get_shortish_repr('abc', max_length=2) == "'a'"

    assert get_shortish_repr('abc', max_length=3) == "'ab'"

    assert get_shortish_repr('abc', max_length=4) == "'abc'"

    assert get_shortish_repr('abc', max_length=5) == "'abc'"


# Generated at 2022-06-22 18:34:47.112756
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('meep') == ('meep',)

    assert ensure_tuple(['meep']) == ('meep',)



# Generated at 2022-06-22 18:34:57.295514
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(4) == (4,)
    assert ensure_tuple((4,)) == (4,)
    assert ensure_tuple([4]) == (4,)
    assert ensure_tuple("a") == ("a",)
    assert ensure_tuple("abc") == ("abc",)
    assert ensure_tuple({}) == ({},)
    assert ensure_tuple({9: 17}) == ({9: 17},)
    assert ensure_tuple(None) == (None,)



# Cute hack: If we're running as a doctest, we want to make the functions above
# automatically available under the `cute_testing_tools` namespace, for easy
# importing, since we don't want to import the whole cute_testing_tools module.
#
# But if we're not running as a doctest, we want our namespace

# Generated at 2022-06-22 18:35:02.754343
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<Foo at 0x000007F8D11B1E10>') == '<Foo>'
    assert normalize_repr('<Foo at 0x7F8D11B1E10>') == '<Foo>'
    assert normalize_repr('<Foo object at 0x7F8D11B1E10>') == '<Foo object>'

# Generated at 2022-06-22 18:35:13.487318
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from garlicsim.general_misc.infinity import infinity
    from garlicsim.general_misc.constants import ZERO
    from garlicsim.general_misc import address_tools
    from garlicsim.general_misc.human_readable_repr import HumanReadableRepr
    from garlicsim.general_misc.misc_tools import (
        type_checked_property,
        type_checked_getter,
        type_checked_setter,
        TypeCheckedPropertyMeta,
        TypeCheckedGetterMeta,
        TypeCheckedSetterMeta
    )
    

# Generated at 2022-06-22 18:35:17.846093
# Unit test for constructor of class WritableStream
def test_WritableStream():
    assert issubclass(sys.stdout, WritableStream)
    assert issubclass(sys.stderr, WritableStream)
    assert issubclass('q', WritableStream) == False



# Generated at 2022-06-22 18:35:27.510393
# Unit test for function get_repr_function
def test_get_repr_function():

    class A(object): pass
    class B(A): pass
    class C(B): pass

    class D(object): pass
    class E(D): pass

    def repr_for_a(x):
        assert isinstance(x, A)
        return 'this is an A'

    def repr_for_b(x):
        assert isinstance(x, B)
        return 'this is a B'

    def repr_for_c(x):
        assert isinstance(x, C)
        return 'this is a C'

    def repr_for_d(x):
        assert isinstance(x, D)
        return 'this is a D'


# Generated at 2022-06-22 18:35:28.618469
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('test at 0x00000010') == 'test'

# Generated at 2022-06-22 18:35:36.135926
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(1.5) == (1.5,)
    assert ensure_tuple('abc') == ('abc',)


if __name__ == '__main__':
    test_ensure_tuple()

# Generated at 2022-06-22 18:35:39.132739
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'\u2665a\u2665') == '?a?'
    assert shitcode(u'💩a💩') == '?a?'
    assert shitcode(u'a') == 'a'



# Generated at 2022-06-22 18:35:48.230793
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<module> at 0x304e290>') == '<module>'
    assert normalize_repr('<module> at 0x304e290') == '<module> at 0x304e290'
    assert normalize_repr('<module> at 0x304e') == '<module> at 0x304e'
    assert normalize_repr('<module> at 0x304e2') == '<module> at 0x304e2'
    assert normalize_repr('<module> at 0x304e294') == '<module> at 0x304e294'
    assert normalize_repr('<module> at 0x304e29f5') == '<module> at 0x304e29f5'

# Generated at 2022-06-22 18:35:56.129565
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert WritableStream.register(file)

    assert WritableStream.register(sys.stdout)

    #assert not WritableStream.register(5) # NotImplementedError


#def test_custom_repr():
#    assert get_repr_function('spam', ((str, id_repr),)) == id_repr
#    assert get_repr_function('spam', ((int, id_repr),)) == repr
#    assert get_repr_function('spam', ((int, id_repr),
#                                      (str, id_repr))) == id_repr