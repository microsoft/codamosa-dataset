

# Generated at 2022-06-22 18:25:57.201400
# Unit test for function truncate
def test_truncate():
    assert truncate('abc', 4) == 'abc'
    assert truncate('abcdefgh', 4) == '...h'

    assert truncate(123, 4) == '123'
    assert truncate(123456789, 4) == '...9'

# Generated at 2022-06-22 18:26:06.896342
# Unit test for method write of class WritableStream
def test_WritableStream_write():

    import unittest

    class Test(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s

    Test().write('hi') # This should not throw an exception.

    class Test2:
        def write(self, s):
            pass

    assert WritableStream.__subclasshook__(Test2) is NotImplemented

    class Test3:
        def write(self, s):
            pass

        @classmethod
        def __subclasshook__(cls, C):
            return NotImplemented

    assert WritableStream.__subclasshook__(Test3) is NotImplemented

    class Test4:
        def write(self, s):
            pass


# Generated at 2022-06-22 18:26:17.361941
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('Hello') == 'Hello'
    assert normalize_repr('Hello at 0x2345AB') == 'Hello'
    assert normalize_repr('   Hello at 0x2345AB') == '   Hello'
    assert normalize_repr('Hello at 0x2345AB   ') == 'Hello   '
    assert normalize_repr('   Hello at 0x2345AB   ') == '   Hello   '
    assert normalize_repr(u'Hello at 0x2345AB') == u'Hello'
    assert normalize_repr(u'   Hello at 0x2345AB') == u'   Hello'
    assert normalize_repr(u'Hello at 0x2345AB   ') == u'Hello   '

# Generated at 2022-06-22 18:26:22.372834
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc123') == 'abc123'
    assert shitcode('abc\xfc') == 'abc?'
    assert shitcode('abc\x7f') == 'abc?'
    assert shitcode(u'abc\xfc') == 'abc?'
    assert shitcode(u'abc\x7f') == 'abc?'
    assert shitcode(b'abc\xfc') == 'abc?'
    assert shitcode(b'abc\x7f') == 'abc?'
    assert shitcode('abc\xfc') == 'abc?'
    assert shitcode('abc\x7f') == 'abc?'
    assert shitcode('abc\x01') == 'abc?'
    assert shitcode('abc\x1f') == 'abc?'
    assert shitcode('abc\x00') == 'abc?'

# Generated at 2022-06-22 18:26:28.913147
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('') == ''
    assert normalize_repr('hello') == 'hello'
    assert normalize_repr('hello at 0x1234') == 'hello'
    assert normalize_repr('hello at 0x12345678') == 'hello'
    assert normalize_repr('hello at 0x12345678asdf') == 'hello at 0x12345678asdf'

# Generated at 2022-06-22 18:26:31.841774
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Spam:
        pass

    class Foo(WritableStream):
        def write(self, s):
            pass

    assert issubclass(Foo, WritableStream)
    assert not issubclass(Spam, WritableStream)

# Generated at 2022-06-22 18:26:43.417372
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    from .test_tools import assert_equal
    from .custom_repr import CustomReprType

    assert_equal(get_shortish_repr(1), '1')

    a = CustomReprType(1)
    assert_equal(get_shortish_repr(a), 'my repr for 1')

    a = CustomReprType(None)
    assert_equal(get_shortish_repr(a), 'my repr for None')

    a = CustomReprType(1)
    assert_equal(get_shortish_repr(a, max_length=1), 'm...')

    assert_equal(get_shortish_repr(1, max_length=1), '1')
    assert_equal(get_shortish_repr(1, max_length=10), '1')


# Unit

# Generated at 2022-06-22 18:26:49.580919
# Unit test for function get_repr_function
def test_get_repr_function():
    custom_repr = (
        (lambda x: isinstance(x, int), lambda x: 'X'),
        (float, lambda x: 'Y'),
    )

    assert get_repr_function(1, custom_repr) == custom_repr[0][1]
    assert get_repr_function(1.0, custom_repr) == custom_repr[1][1]
    assert get_repr_function('1', custom_repr) == repr



# End unit test for function get_repr_function



# Generated at 2022-06-22 18:26:51.334694
# Unit test for function shitcode
def test_shitcode():
    u = '你'
    assert shitcode(u.encode('utf-8')) == '??'



# Generated at 2022-06-22 18:26:58.552080
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<object at 0xFFFFFFFF>') == '<object>'
    assert normalize_repr('<object at 0xFFFFFFFFF>') == '<object>'
    assert normalize_repr('<object at 0xFFFF>') == '<object>'
    assert normalize_repr('<object>') == '<object>'
    assert normalize_repr('') == ''



# Generated at 2022-06-22 18:27:05.425768
# Unit test for function truncate
def test_truncate():
    assert truncate('1234567890', None) == '1234567890'
    assert truncate('1234567890', 100) == '1234567890'
    assert truncate('1234567890', 10) == '1234567890'
    assert truncate('1234567890', 9) == '1234567...'
    assert truncate('1234567890', 8) == '1234567...'
    assert truncate(u'1234567890', 10) == u'1234567890'
    assert truncate(b'1234567890', 10) == b'1234567890'
    assert truncate(u'1234567890', 9) == u'1234567...'
    assert truncate('12345\u1234', 7) == '12345\u1234'

# Generated at 2022-06-22 18:27:15.048320
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, []) is repr
    assert get_repr_function(None, [(None, lambda x: 'bla')]) == 'bla'
    assert get_repr_function('', [('', lambda: 'oops')]) == 'oops'
    assert get_repr_function(object(), [(object, lambda: 'sorry')]) == 'sorry'
    assert get_repr_function(2.5, [
        (int, lambda x: 'int!'),
        (float, lambda x: 'float!')
    ]) == 'float!'
    assert get_repr_function(1, [
        (int, lambda x: 'int!'),
        (float, lambda x: 'float!')
    ]) == 'int!'

# Generated at 2022-06-22 18:27:17.842098
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WriteableStream_test(WritableStream):
        def write(self, s):
            pass

    x = WriteableStream_test()

test_WritableStream()

# Generated at 2022-06-22 18:27:21.023055
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .pycompat import StringIO
    stream = StringIO()
    WritableStream.register(type(stream))
    stream.write('baba')
    assert stream.getvalue() == 'baba'

# Generated at 2022-06-22 18:27:25.153438
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('') == ''
    assert normalize_repr('hafjfasdlkjh') == 'hafjfasdlkjh'
    assert normalize_repr('hafjfasdlkjh asdkf asjdfha at 0x1230') == 'hafjfasdlkjh asdkf asjdfha'
    assert normalize_repr('hafjfasdlkjh asdkf asjdfha at 0x12345678') == 'hafjfasdlkjh asdkf asjdfha'
    assert normalize_repr('hafjfasdlkjh at 0x12345678 asdkf asjdfha') == 'hafjfasdlkjh asdkf asjdfha'

# Generated at 2022-06-22 18:27:35.934318
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('abcdefg') == 'abcdefg'
    assert get_shortish_repr('abc') == 'abc'
    assert get_shortish_repr('abcdefghij', max_length=8) == 'abc...ij'
    assert get_shortish_repr('abcdefghij', max_length=7) == 'abc...i'
    assert get_shortish_repr('abcdefghij', max_length=6) == 'abc...'
    assert get_shortish_repr('abcdefghij', max_length=5) == 'abc..'
    assert get_shortish_repr('abcdefghij', max_length=4) == 'abc.'
    assert get_shortish_repr('abcdefghij', max_length=3) == 'ab.'

# Generated at 2022-06-22 18:27:38.141198
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    assert issubclass(type(sys.stdout), WritableStream)
    assert not issubclass(type(object), WritableStream)

# Generated at 2022-06-22 18:27:40.318484
# Unit test for function normalize_repr
def test_normalize_repr():
    import doctest
    assert doctest.testmod(normalize_repr).failed == 0




# Generated at 2022-06-22 18:27:51.308832
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(5, max_length=3) == '5'
    assert get_shortish_repr((1, 2, set((3, 4))), max_length=20) == \
                                            '({}, {}, {...})'.format(1, 2, set((3, 4)))
    assert get_shortish_repr((1, 2, set((3, 4))), max_length=40) == \
                            '({}, {}, {3, 4})'.format(1, 2)
    assert get_shortish_repr(set((1, 2, set((3, 4)))), max_length=20) == \
                            '{...}'

# Generated at 2022-06-22 18:28:00.505889
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(123) == '123'
    assert get_shortish_repr('hello world') == 'hello world'
    assert get_shortish_repr(123, max_length=1, normalize=True) == '1...3'
    assert get_shortish_repr('hello world', max_length=1, normalize=True) \
                                                                   == 'h...d'
    assert get_shortish_repr(123, max_length=5, normalize=True) == '123'
    assert get_shortish_repr(123, max_length=4, normalize=True) == '...3'
    assert get_shortish_repr(123, max_length=4, normalize=False) == '...3'

# Generated at 2022-06-22 18:28:05.666514
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Bogus(WritableStream):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
        def write(self, s):
            return s

    assert isinstance(Bogus(1, 2, 3, foo=5, bar=7), WritableStream)


if __name__ == '__main__':
    import shutil, sys
    test_WritableStream_write()

# Generated at 2022-06-22 18:28:08.203994
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class Foo(WritableStream):
        def write(self, s):
            pass
    assert issubclass(Foo, WritableStream)



# Generated at 2022-06-22 18:28:14.806761
# Unit test for function truncate
def test_truncate():
    assert truncate('123456789', 9) == '123456789'
    assert truncate('123456789', 8) == '12345...'
    assert truncate('123456789', 7) == '123...'
    assert truncate('123456789', 6) == '12...'
    assert truncate('123456789', 5) == '1...'
    assert truncate('123456789', 4) == '...'
    assert truncate('123456789', 3) == '...'
    assert truncate('123456789', 2) == '...'
    assert truncate('123456789', 1) == '...'
    assert truncate('123456789', 0) == '...'

# Generated at 2022-06-22 18:28:23.616646
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(None,
                                   ((lambda x: x is None, lambda x: 'None.'))) == 'None.'
    assert get_repr_function('',
                              ((lambda x: not x, lambda x: '(empty string)'))) == '(empty string)'
    assert get_repr_function(1, ((int, lambda x: 'here'))) == 'here'
    assert get_repr_function(1.0, ((float, lambda x: 'here'))) == 'here'
    assert get_repr_function(
        1.0, (((int, float), lambda x: 'here'))) == 'here'



# Generated at 2022-06-22 18:28:27.264453
# Unit test for function shitcode
def test_shitcode():
    def assert_shitcode(s, expected):
        assert shitcode(s) == expected

    assert_shitcode('abc', 'abc')
    assert_shitcode('abc\0', 'abc?')



# Generated at 2022-06-22 18:28:30.970833
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def __init__(self):
            self.written = []
        def write(self, s):
            self.written.append(s)
    a = A()
    a.write('hi')
    a.write('bye')
    assert a.written == ['hi', 'bye']



# Generated at 2022-06-22 18:28:38.677947
# Unit test for function get_repr_function
def test_get_repr_function():
    def assert_repr_function(item, custom_repr, expected_repr):
        assert callable(expected_repr)
        assert get_repr_function(item, custom_repr) is expected_repr

    # Baseline
    assert_repr_function(
        'a',
        custom_repr=[],
        expected_repr=repr,
    )
    # First match
    assert_repr_function(
        'a',
        custom_repr=[
            (str, lambda _: 'str'),
            (int, lambda _: 'int'),
        ],
        expected_repr=lambda _: 'str',
    )
    # Second match

# Generated at 2022-06-22 18:28:40.767319
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class MyStream(WritableStream):
        def __init__(self, s):
            self.s = s

        def write(self, x):
            self.s += x

    my_stream = MyStream('z')
    assert isinstance(my_stream, WritableStream)

# Generated at 2022-06-22 18:28:52.845034
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(1, max_length=2) == '1'
    assert get_shortish_repr(1, max_length=1) == '1'
    assert get_shortish_repr(1, max_length=0) == '...'
    assert get_shortish_repr(1, max_length=3) == '1'
    assert get_shortish_repr(1234567890, max_length=10) == '1234567890'
    assert get_shortish_repr(1234567890, max_length=9) == '12345...0'
    assert get_shortish_repr(1234567890, max_length=8) == '1234...90'
    assert get

# Generated at 2022-06-22 18:29:00.302782
# Unit test for function truncate
def test_truncate():
    assert truncate('abcd', max_length=None) == 'abcd'
    assert truncate('abcdefgh', max_length=None) == 'abcdefgh'
    assert truncate('abcdefghijk', max_length=None) == 'abcdefghijk'
    assert truncate('abcd', max_length=3) == 'abcd'
    assert truncate('abcdefgh', max_length=3) == 'a...h'
    assert truncate('abcdefghijk', max_length=3) == 'a...k'
    assert truncate('abcdefghijkl', max_length=3) == 'a...l'
    assert truncate('abcd', max_length=4) == 'abcd'
    assert truncate('abcdefgh', max_length=4) == 'a...h'

# Generated at 2022-06-22 18:29:04.172246
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('abc') == 'abc'
    assert shitcode('שלום') == '???'
    assert shitcode('שלום' + chr(400)) == '?????'

# Generated at 2022-06-22 18:29:10.780671
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('x at 0x00000') == 'x'
    assert normalize_repr('x at 0x000001') == 'x'
    assert normalize_repr('x at 0x0000000') == 'x'
    assert normalize_repr('x at 0x00000002') == 'x'
    assert normalize_repr('x at 0x0000000000000') == 'x'
    assert normalize_repr('x at 0x00000000000001') == 'x'
    assert normalize_repr('x at 0x00000000000000') == 'x'
    assert normalize_repr('x at 0x000000000000000') == 'x'


# Generated at 2022-06-22 18:29:21.602645
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('hello', max_length=8) == 'hello'
    assert get_shortish_repr('hello', max_length=9) == 'hello'
    assert get_shortish_repr('hello', max_length=10) == 'hello'
    assert get_shortish_repr('hello', max_length=6) == 'he...'
    assert get_shortish_repr('hello', max_length=5) == 'he...'
    s = 'hello' + chr(1233) + chr(0xFF)
    assert get_shortish_repr(s, max_length=10) == shitcode(s)
    assert get_shortish_repr(s, max_length=11) == shitcode(s)

# Generated at 2022-06-22 18:29:32.171947
# Unit test for function normalize_repr
def test_normalize_repr():
    x = [1,2,3]
    b = u'בָּרָק'
    items = [
        'a'
        u'\uFEFFb'
        (1,2,3),
        [1,2,3],
        {(1,2,3)},
        set([1,2,3]),
        {1:2,3:4},
        {1,2,3},
        b,
        x,
        b'\xef\xbb\xbf \xec\xbd\x94',
        (1,x),
        ]

    def repr_function(item):
        return repr(item)

    repr_result = repr(items)
    def repr_function(item):
        return repr(item)

    repr_result = repr(items)


# Generated at 2022-06-22 18:29:35.529253
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(3, ((int, 'int'),)) == 'int'
    assert get_repr_function(3.5, ((int, 'int'),)) == repr



# Generated at 2022-06-22 18:29:39.735265
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class X(WritableStream):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s

    x = X()
    assert isinstance(x, WritableStream)
    assert issubclass(X, WritableStream)

    x.write('hello')
    x.write('world')
    assert x.s == 'helloworld'




# Generated at 2022-06-22 18:29:43.820484
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class SomeClass(object):
        pass

    assert isinstance(SomeClass(), WritableStream)
    try:
        assert not isinstance(WritableStream, WritableStream)
    except TypeError:
        pass
    else:
        raise Exception("This should fail.")

    class SomeOtherClass(WritableStream):
        pass

    assert isinstance(SomeOtherClass(), WritableStream)




# Generated at 2022-06-22 18:29:47.927568
# Unit test for function truncate
def test_truncate():
    assert truncate('', 8) == ''
    assert truncate('hello', 8) == 'hello'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 4) == 'hel...'
    assert truncate('hello', 3) == 'he...'
    assert truncate('hello', 2) == 'h...'
    assert truncate('hello', 1) == '...'



_slicable_types = (list, tuple, set, frozenset, buffer,
                   collections_abc.Sequence, collections_abc.Set)

# Generated at 2022-06-22 18:29:50.662840
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1, )
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple(x for x in [1, 2]) == (1, 2)



# Generated at 2022-06-22 18:29:59.859303
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('asdasd') == "'asdasd'"
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(2.0) == '2.0'
    assert get_shortish_repr(3, max_length=3) == '3'
    assert get_shortish_repr(3, max_length=2) == '3'
    assert get_shortish_repr(3, max_length=1) == '...'

    # Check that max_length can be disabled:
    assert get_shortish_repr(3, max_length=None) == '3'

    # x = 3

    # assert get_shortish_repr(x, max_length=3) == '3'


# Unit test

# Generated at 2022-06-22 18:30:05.342563
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import StringIO

    class StringIOWritableStream(WritableStream):
        def __init__(self, stringio):
            """StringIO object that should be written to."""
            self.stringio = stringio

        def write(self, s):
            self.stringio.write(s)

    a = StringIO.StringIO()
    assert isinstance(a, WritableStream)
    a = StringIOWritableStream(a)
    assert isinstance(a, WritableStream)



# Generated at 2022-06-22 18:30:13.430776
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)
    assert ensure_tuple((x for x in range(100))) == tuple(range(100))
    assert ensure_tuple([1, 2, 3]) == (1, 2, 3)


if sys.version_info >= (2, 6):
    def importlib_import(module_name):
        import importlib as importlib_module
        return importlib_module.import_module(module_name)
else:
    def importlib_import(module_name):
        # A backport of `importlib.import_module` for the 2.5 case:
        __import__(module_name)
        return sys.modules[module_name]

# Generated at 2022-06-22 18:30:16.431794
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple([1]) == (1,)
    assert ensure_tuple((1,)) == (1,)





# Generated at 2022-06-22 18:30:25.481734
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    from .fs_tools import open_text_file
    from .string_tools import open_string_as_text_file
    import codecs
    import io
    import os
    import sys

    assert isinstance(sys.stdout, WritableStream)
    assert isinstance(sys.stderr, WritableStream)

    assert not issubclass(object, WritableStream)
    assert not issubclass(str, WritableStream)

    if sys.platform.startswith('java'):
        assert issubclass(sys.stdout.__class__, WritableStream)
        assert issubclass(sys.stderr.__class__, WritableStream)
    else:
        assert not issubclass(sys.stdout.__class__, WritableStream)

# Generated at 2022-06-22 18:30:37.759623
# Unit test for function get_repr_function
def test_get_repr_function():
    class Foo(object): pass
    foo = Foo()

# Generated at 2022-06-22 18:30:46.845447
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)

    assert ensure_tuple(1, 2, 3) == (1, 2, 3)

    assert ensure_tuple((1, 2, 3)) == (1, 2, 3)

    assert ensure_tuple(set([1, 2, 3])) == (1, 2, 3)

    assert ensure_tuple((1, 2)) == (1, 2)

    assert ensure_tuple(range(3)) == (0, 1, 2)

    assert ensure_tuple(range(5), range(5), range(5)) == \
                                             (0, 1, 2, 3, 4, 0, 1, 2, 3, 4,
                                              0, 1, 2, 3, 4)


# Generated at 2022-06-22 18:30:49.979245
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class MyWritableStream(WritableStream):
        def write(self, s):
            pass
    assert issubclass(MyWritableStream, WritableStream)
    assert isinstance(MyWritableStream(), WritableStream)

# Generated at 2022-06-22 18:31:00.359074
# Unit test for function truncate
def test_truncate():
    assert truncate(u'', 3) == u''
    assert truncate(u'a', 3) == u'a'
    assert truncate(u'aa', 3) == u'aa'
    assert truncate(u'aaa', 3) == u'aaa'
    assert truncate(u'aaaa', 3) == u'...'
    assert truncate(u'aaaa', 4) == u'a...'
    assert truncate(u'aaaaa', 4) == u'a...'
    assert truncate(u'aaaaa', 5) == u'...'
    assert truncate(u'aaaaa', 6) == u'a...'
    assert truncate(u'aaaaaa', 6) == u'a...'
    assert truncate(u'aaaaaa', 7) == u'a...'

# Generated at 2022-06-22 18:31:09.763502
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1, )
    assert ensure_tuple((1,)) == (1, )
    assert ensure_tuple([1]) == (1, )
    assert ensure_tuple({1}) == (1, )
    assert ensure_tuple('1') == ('1', )
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(('1', '2')) == ('1', '2')
    assert ensure_tuple({'1', '2'}) == ('1', '2')

# Generated at 2022-06-22 18:31:13.192307
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, ((int, lambda x: '1!'))) == '1!'
    assert get_repr_function(1, ((lambda x: True, lambda x: '1!'))) == '1!'
    assert get_repr_function(1) == repr

# Generated at 2022-06-22 18:31:15.177425
# Unit test for function normalize_repr
def test_normalize_repr():
    a = normalize_repr("<function blah at 0x91d50>")
    assert a == "<function blah>"

# Generated at 2022-06-22 18:31:26.204323
# Unit test for function get_repr_function
def test_get_repr_function():
    class Abc(object): pass
    class Xyz(Abc): pass
    def f(x): return 'bar'
    def f2(x): raise Exception
    def g(x): return 'baz'
    assert get_repr_function(1, []) is repr
    assert get_repr_function(1, [(int, f)]) is f
    assert get_repr_function(1, [(str, f)]) is repr
    assert get_repr_function(1, [(int, f), (str, f)]) is f
    assert get_repr_function(1, [(int, f), (str, f), (Abc, f)]) is f

# Generated at 2022-06-22 18:31:35.947632
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    import six
    import io
    class MockBinaryStream(WritableStream):
        def __init__(self):
            self.bytes = bytearray()

        def write(self, s):
            self.bytes.extend(s)

    mock_binary_stream = MockBinaryStream()

    string = 'No no no no no no, no no no there is no limit'
    if six.PY3:
        mock_binary_stream.write(string.encode('utf-8'))
    else:
        mock_binary_stream.write(string)
    assert mock_binary_stream.bytes == string.encode('utf-8')

    mock_binary_stream = MockBinaryStream()

    mock_binary_stream.write(bytearray(b'a'))
    mock_binary_stream.write

# Generated at 2022-06-22 18:31:41.900720
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        write = None
    A.__bases__ = ()
    assert isinstance(A(), WritableStream)
    assert A.__subclasshook__(A) is True

    class B(WritableStream):
        def write(self, value):
            pass
    assert isinstance(B(), WritableStream)
    assert B.__subclasshook__(B) is True

    from .pycompat import RawIOBase
    assert RawIOBase.__subclasshook__(RawIOBase) is True
    assert WritableStream.__subclasshook__(RawIOBase) is True
    assert isinstance(sys.stdout, WritableStream)
    sys.stdout.write('')

# Generated at 2022-06-22 18:31:51.581517
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert normalize_repr(get_shortish_repr({})) == normalize_repr(repr({}))

    assert get_shortish_repr(
        {1, 2, 3},
        custom_repr=((set, lambda s: 'set([{}])'.format(sorted(s))),),
        normalize=True
    ) == normalize_repr('set([1, 2, 3])')

    assert get_shortish_repr(
        {1, 2, 3},
        custom_repr=((set, lambda s: 'this is a long custom representation'),),
        max_length=10
    ) == 'this is ...'



# Generated at 2022-06-22 18:31:54.067391
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class AbstractWritableStream(WritableStream):
        pass
    AbstractWritableStream()

    class MyWritableStream(object):
        def write(self, s):
            pass

    assert isinstance(MyWritableStream(), WritableStream)

# Generated at 2022-06-22 18:31:57.239858
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class WritableStreamSubclass(WritableStream):
        def write(self, s):
            pass
    assert issubclass(WritableStreamSubclass, WritableStream)



# Generated at 2022-06-22 18:32:00.719524
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple((1, 2)) == (1, 2)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(['a']) == ('a',)




# Generated at 2022-06-22 18:32:08.329128
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple('hello') == ('hello',)
    assert ensure_tuple(('hello',)) == ('hello',)
    assert ensure_tuple([1, 2]) == (1, 2)



#TODO: write a line_separated_to_tuple and tuple_to_line_separated,
# which will use `repr` and `ast.literal_eval` to read and write from a
# line-separated text.




# Generated at 2022-06-22 18:32:11.605095
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'עברית') == '???', repr(shitcode(u'עברית'))
    assert shitcode(u'English') == 'English', repr(shitcode(u'English'))
    assert shitcode(u'שלום') == '???', repr(shitcode(u'שלום'))
    assert shitcode(u'123') == '123', repr(shitcode(u'123'))



# Generated at 2022-06-22 18:32:22.287214
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, (int, lambda x: str(x*2), float, repr)) == repr
    assert get_repr_function(2, (int, lambda x: str(x*2), float, repr)) == \
                                                            (lambda x: str(x*2))
    assert get_repr_function(1.0, (int, lambda x: str(x*2), float, repr)) == repr
    assert get_repr_function(2.0, (int, lambda x: str(x*2), float, repr)) == \
                                                                     repr
    assert get_repr_function(1, ((1,), lambda x: str(x*2), float, repr)) == \
                                                             (lambda x: str(x*2))
    assert get_repr_function

# Generated at 2022-06-22 18:32:29.777860
# Unit test for function normalize_repr
def test_normalize_repr():
    for i in range(7):
        for j in range(7):
            for k in range(7):
                x = 'x{}y{}z{}'.format(i, j, k)
                assert not x.startswith('x'), x
                assert not x.endswith('z'), x
                assert 'y' in x, x
                assert 'y{}'.format(j) in x, x
                assert normalize_repr(x) == x

    for i in range(7):
        for j in range(7):
            x = 'x{}y{}z'.format(i, j)
            assert normalize_repr(x) == x

    for i in range(7):
        x = 'x{}yz'.format(i)

# Generated at 2022-06-22 18:32:34.476810
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple((1,)) == (1,)
    assert ensure_tuple([1, 2]) == (1, 2)
    assert ensure_tuple({1, 2}) == (1, 2)



# Generated at 2022-06-22 18:32:36.810773
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Foo(WritableStream):
        def write(self, s):
            print(s)

    Foo().write('hello')
    assert issubclass(Foo, WritableStream)
    assert not issubclass(Foo, ABC)



# Generated at 2022-06-22 18:32:43.643128
# Unit test for function truncate
def test_truncate():
    assert truncate('hello, world!', None) == 'hello, world!'
    assert truncate('hello, world!', 0) == ''
    assert truncate('hello, world!', 10) == 'hello, wo...'
    assert truncate('hello, world!', 11) == 'hello, worl...'
    assert truncate('hello, world!', 12) == 'hello, world!'
    assert truncate('hello, world!', 13) == 'hello, world!'



# Generated at 2022-06-22 18:32:46.845174
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    if sys.version_info[:2] == (3, 4):
        return True
    class A:
        def write(self, s):
            pass
    class B:
        pass
    assert issubclass(A, WritableStream)
    assert not issubclass(B, WritableStream)

# Generated at 2022-06-22 18:32:57.953595
# Unit test for function get_repr_function
def test_get_repr_function():
    assert get_repr_function(1, custom_repr=((lambda x: x % 2, repr))) == repr
    assert get_repr_function(0, custom_repr=((lambda x: x % 2, repr))) == repr
    assert get_repr_function(0, custom_repr=((lambda x: x % 3, repr))) == repr
    assert get_repr_function(1, custom_repr=((lambda x: x % 3, repr))) == repr
    assert get_repr_function('a', custom_repr=((lambda x: x == 'a', repr))) == repr
    assert get_repr_function('a', custom_repr=((lambda x: x == 'b', repr))) == repr

# Generated at 2022-06-22 18:33:03.252776
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class Broken(object):
        pass
    class Good(object):
        def write(self, s):
            pass
    broken = Broken()
    good = Good()
    assert not isinstance(broken, WritableStream)
    assert issubclass(Good, WritableStream)
    assert isinstance(good, WritableStream)

# Generated at 2022-06-22 18:33:14.365193
# Unit test for function normalize_repr
def test_normalize_repr():
    assert normalize_repr('<what at 0xabcdef>') == '<what>'
    assert normalize_repr('<what at 0xabcdef at 0x123>') == '<what>'
    assert normalize_repr('<what at 0xabcdef and 0x123>') == \
           '<what at 0xabcdef and 0x123>'
    assert normalize_repr('<what at 0xabcdefand 0x123>') == \
           '<what at 0xabcdefand 0x123>'
    assert normalize_repr('<what at 0xabcDEf>') == '<what>'
    assert normalize_repr('<what at 0x>') == '<what>'

# Generated at 2022-06-22 18:33:19.062698
# Unit test for function truncate
def test_truncate():
    assert truncate('abcd', 1) == 'a'
    assert truncate('abcde', 1) == 'a...e'
    assert truncate('abcdef', 1) == 'a...f'
    assert truncate('a', 1) == 'a'
    assert truncate('a', 2) == 'a'
    assert truncate('ab', 2) == 'a...b'
    assert truncate('abc', 2) == 'a...c'



# Generated at 2022-06-22 18:33:23.784383
# Unit test for constructor of class WritableStream
def test_WritableStream():
    class WritableStreamSubclass(WritableStream):
        def write(self, s): pass
    assert issubclass(WritableStreamSubclass, WritableStream)

    class NonWritableStream(WritableStream):
        pass
    assert not issubclass(NonWritableStream, WritableStream)

    class NonWritableStream(WritableStream):
        def write(self, s): pass
        def banana(self): pass
    assert not issubclass(NonWritableStream, WritableStream)

    class WritableStreamSubclass(WritableStream):
        def __init__(self):
            self.write = None
    assert not issubclass(WritableStreamSubclass, WritableStream)

    class WritableStreamSubclass(WritableStream):
        def write(self, s): pass

# Generated at 2022-06-22 18:33:30.058454
# Unit test for function ensure_tuple
def test_ensure_tuple():

    def assert_equal(x, y):
        assert x == y

    assert_equal(ensure_tuple(7), (7,))


    assert_equal(ensure_tuple((7,)), (7,))


    assert_equal(ensure_tuple((7, 8)), (7, 8))


    assert_equal(ensure_tuple([]), ())





# Generated at 2022-06-22 18:33:34.540776
# Unit test for constructor of class WritableStream
def test_WritableStream():
    _WritableStream = WritableStream

    class WritableStream(object):
        def write(self, s):
            return super().write(s)

    assert issubclass(WritableStream, _WritableStream)

    class WritableStream(object):
        def write(self):
            pass

    assert not issubclass(WritableStream, _WritableStream)

    class WritableStream(object):
        pass

    assert not issubclass(WritableStream, _WritableStream)

# Generated at 2022-06-22 18:33:44.348285
# Unit test for function normalize_repr
def test_normalize_repr():
    from garlicsim.general_misc.cute_iter_tools import pairwise
    from garlicsim.general_misc.pretty_repr import pretty_repr
    import garlicsim
    import garlicsim_lib
    import sys

# Generated at 2022-06-22 18:33:47.611063
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('עברית') == '????????'
    assert shitcode('Hello world') == 'Hello world'



# Generated at 2022-06-22 18:33:59.037580
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(1) == '1'
    assert get_shortish_repr(b'hi') == "b'hi'"
    assert get_shortish_repr(['H', 'e', 'l', 'l', 'o']) == "['H', 'e', 'l', 'l', 'o']"
    for custom_repr in [], [('hi', 'yo')]:
        assert get_shortish_repr('hi', custom_repr) == 'hi'

    assert get_shortish_repr(['H', 'e', 'l', 'l', 'o'], max_length=3) == '...'
    assert get_shortish_repr(['H', 'e', 'l', 'l', 'o'], max_length=4) == '...'

# Generated at 2022-06-22 18:34:02.983152
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'חייה') == '???'
    assert shitcode(u'רם רחום') == '?? ??'
    assert shitcode(u'Rachum') == 'Rachum'

# Generated at 2022-06-22 18:34:09.007369
# Unit test for function normalize_repr
def test_normalize_repr():
    from .unicode_dump import UnicodeDumpTest
    assert truncate(UnicodeDumpTest.__repr__(), 100) == \
                                           '<unicode_dump_tests.UnicodeDumpTest ' \
                                           'object at 0x0000000003D2D2B0>'
    assert truncate(normalize_repr(UnicodeDumpTest.__repr__()), 100) == \
                                           '<unicode_dump_tests.UnicodeDumpTest ' \
                                           'object>'

# Generated at 2022-06-22 18:34:12.467767
# Unit test for function shitcode
def test_shitcode():
    assert shitcode(u'myślę') == u'my??l?'
    assert shitcode(u'myślę'.encode('utf-8')) == u'my??l?'

# Generated at 2022-06-22 18:34:14.503382
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A:
        def write(self, s):
            self.s = s
    A()



# Generated at 2022-06-22 18:34:20.780988
# Unit test for function shitcode
def test_shitcode():
    assert shitcode('') == ''
    assert shitcode('hello') == 'hello'
    assert shitcode('π') == '?'
    assert shitcode('πhello') == '?hello'
    assert shitcode('πhelloπ') == '?hello?'
    assert shitcode('π') == '?'
    assert shitcode('πhelloπ') == '?hello?'

# Generated at 2022-06-22 18:34:27.672573
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class A(WritableStream):
        def write(self, s):
            pass
    class B(WritableStream):
        def write(self, s):
            pass
    class C(B):
        pass
    assert WritableStream.__subclasshook__(A) is True
    assert WritableStream.__subclasshook__(B) is True
    assert WritableStream.__subclasshook__(C) is True

    class D(A):
        pass
    class E(B):
        def flush(self):
            pass
    class F(C):
        def flush(self):
            pass
    class G(D):
        def flush(self):
            pass
    class H(E):
        pass
    class I(F):
        pass

# Generated at 2022-06-22 18:34:32.852331
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    written = []
    class Shmeckers(WritableStream):
        def write(self, s):
            written.append(s)

    Shmeckers().write('hello')
    assert written == ['hello']



# Generated at 2022-06-22 18:34:37.407040
# Unit test for method write of class WritableStream
def test_WritableStream_write():
    class _WritableStream(WritableStream):
        def write(self, s):
            pass
    assert isinstance(_WritableStream(), WritableStream)

    class _WritableStream2(WritableStream):
        pass
    assert not isinstance(_WritableStream2(), WritableStream)

# Generated at 2022-06-22 18:34:47.725093
# Unit test for function truncate
def test_truncate():
    assert truncate('hello', None) == 'hello'
    assert truncate('hello', 5) == 'hello'
    assert truncate('hello', 3) == 'he...'
    assert truncate('hello', 4) == 'he...'
    assert truncate('hello', 2) == 'h...'
    assert truncate('hello', 2) == 'h...'
    assert truncate('hello', 1) == '...'
    assert truncate('hello', 0) == '...'
    assert truncate('hello', -1) == '...'
    assert truncate('hello', -2) == '...'
    assert truncate('hello', -3) == '...'

    assert truncate(u'\U0001f633', 6) == u'\U0001f633'

# Generated at 2022-06-22 18:34:57.563763
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr(5, max_length=10) == '5'
    assert get_shortish_repr(5, max_length=1) == '5'
    assert get_shortish_repr(5, max_length=0) == '5'
    assert get_shortish_repr(5, max_length=None) == '5'
    assert get_shortish_repr(5, max_length=-1) == '5'
    assert get_shortish_repr(5, max_length=-100) == '5'
    assert get_shortish_repr(5, max_length=2) == '5'
    assert get_shortish_repr(5, max_length=3) == '5'

# Generated at 2022-06-22 18:35:01.685212
# Unit test for constructor of class WritableStream
def test_WritableStream():
    from .stdout_redirector import StdoutRedirector

    sys.stdout = StdoutRedirector()
    sys.stdout.write('hi')
    assert sys.stdout.getvalue() == 'hi'

# Generated at 2022-06-22 18:35:12.865562
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    class X(object):
        def __repr__(self):
            return '<Very long repr>'

    assert get_shortish_repr('abc def' * 1000) == 'abc defabc defabc defabc defabc defabc defabc defabc defabc defabc defabc defabc defabc defabc defabc defabc def'
    assert get_shortish_repr(X(), max_length=10) == '<Very lon...'
    assert get_shortish_repr(X(), max_length=None) == '<Very long repr>'
    assert get_shortish_repr(X(), max_length=15, custom_repr=((X, str),)) == "'abc def'"

# Generated at 2022-06-22 18:35:16.420095
# Unit test for constructor of class WritableStream
def test_WritableStream():

    class Whatever(WritableStream):
        def write(self, s):
            print(s)

    instance = Whatever()
    assert isinstance(instance, WritableStream)

# Generated at 2022-06-22 18:35:21.566220
# Unit test for function normalize_repr
def test_normalize_repr():
    from .modulefinder import _modulefinder_test_data
    from .persist import Persist

    class MockPersist(Persist):
        def __init__(self):
            pass

    for item in _modulefinder_test_data:
        assert (normalize_repr(repr(item)) == normalize_repr(repr(
            MockPersist())))





# Generated at 2022-06-22 18:35:25.470606
# Unit test for function ensure_tuple
def test_ensure_tuple():
    assert ensure_tuple(1) == (1,)
    assert ensure_tuple(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert ensure_tuple(['a', 'b', 'c']) == ('a', 'b', 'c')
    assert ensure_tuple('abc') == ('abc',)

# Generated at 2022-06-22 18:35:34.815203
# Unit test for function get_shortish_repr
def test_get_shortish_repr():
    assert get_shortish_repr('123') == "'123'"
    assert get_shortish_repr(123) == '123'
    assert get_shortish_repr(Ellipsis) == 'Ellipsis'
    assert get_shortish_repr(Ellipsis, max_length=None) == 'Ellipsis'
    assert get_shortish_repr(Ellipsis, max_length=5) == 'Ellipsis'
    assert get_shortish_repr(Ellipsis, max_length=6) == 'Ellipsis'
    assert get_shortish_repr(Ellipsis, max_length=7) == 'Ellipsis'

    assert get_shortish_repr(Ellipsis, max_length=8) == 'Ellipsis'
    assert get_shortish_repr

# Generated at 2022-06-22 18:35:41.400423
# Unit test for function get_repr_function
def test_get_repr_function():

    def classy_repr(x):
        if isinstance(x, MyClass):
            return "MyClass"
        else:
            return repr(x)

    class MyClass: pass

    assert get_repr_function(MyClass(), custom_repr=((MyClass, classy_repr),)) == classy_repr
    assert get_repr_function(MyClass(), custom_repr=()) == repr

    assert get_repr_function(MyClass(), custom_repr=((str, classy_repr),)) == repr

    my_object = object()
    assert get_repr_function(my_object, custom_repr=((str, classy_repr),)) == repr

    assert get_repr_function(my_object, custom_repr=((my_object, classy_repr),)) == classy_

# Generated at 2022-06-22 18:35:49.728161
# Unit test for function truncate
def test_truncate():
    assert truncate('abcdef', None) == 'abcdef'
    assert truncate('abcdef', 6) == 'abcdef'
    assert truncate('abcdef', 7) == 'abcdef'
    assert truncate('abcdef', 4) == 'abc...'
    assert truncate('abcdef', 5) == 'abcde...'
    assert truncate('abcd', 4) == 'a...'
    assert truncate('a', 3) == 'a...'
    assert truncate('abcd', 3) == 'a...'
    assert truncate('abcde', 3) == 'a...'
    assert truncate('abcdef', 3) == 'a...'
    assert truncate('abcdef', 2) == 'a...'
    assert truncate('abcdef', 1) == 'a...'

# Generated at 2022-06-22 18:35:57.969760
# Unit test for function truncate
def test_truncate():
    assert truncate('', 30) == ''
    assert truncate('a', 30) == 'a'
    assert truncate('abc', 30) == 'abc'
    assert truncate('abcde', 30) == 'abcde'
    assert truncate('abcdef', 30) == 'abcdef'
    assert truncate('abcdefg', 30) == 'abcdefg'
    assert truncate('abcdefgh', 30) == 'abcdefgh'
    assert truncate('abcdefghi', 30) == 'abcdefghi'
    assert truncate('abcdefghijklmnopqrstuvwxyz', 30) == \
                                             'abcdefghijklmnopqrstuvwxyz'