

# Generated at 2022-06-18 15:48:06.300527
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    sockssocket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    sockssocket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, username='username', password='password')
    sockssocket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, username='username', password='password', remote_dns=False)
    sockssocket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, username='username', password='password', remote_dns=True)


# Generated at 2022-06-18 15:48:12.239093
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    assert s._proxy.type == ProxyType.SOCKS5
    assert s._proxy.host == '127.0.0.1'
    assert s._proxy.port == 1080
    assert s._proxy.username is None
    assert s._proxy.password is None
    assert s._proxy.remote_dns is True
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, username='user', password='pass')
    assert s._proxy.username == 'user'
    assert s._proxy.password == 'pass'
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, rdns=False)

# Generated at 2022-06-18 15:48:22.562132
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import sys
    import time

    class TestSocksSocket(unittest.TestCase):
        def test_recvall(self):
            s = sockssocket()
            s.connect(('127.0.0.1', 80))
            s.sendall(b'GET / HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n')
            data = s.recvall(4096)
            self.assertTrue(data.startswith(b'HTTP/1.1 200 OK'))

    unittest.main()

# Generated at 2022-06-18 15:48:32.998205
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1080)
    assert s._proxy.type == ProxyType.SOCKS4
    assert s._proxy.host == '127.0.0.1'
    assert s._proxy.port == 1080
    assert s._proxy.username is None
    assert s._proxy.password is None
    assert s._proxy.remote_dns is True
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, username='user', password='pass')
    assert s._proxy.type == ProxyType.SOCKS5
    assert s._proxy.host == '127.0.0.1'
    assert s._proxy.port == 1080
    assert s._proxy.username == 'user'

# Generated at 2022-06-18 15:48:42.936869
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    assert s._proxy.type == ProxyType.SOCKS5
    assert s._proxy.host == '127.0.0.1'
    assert s._proxy.port == 1080
    assert s._proxy.username is None
    assert s._proxy.password is None
    assert s._proxy.remote_dns is True
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, username='user', password='pass')
    assert s._proxy.type == ProxyType.SOCKS5
    assert s._proxy.host == '127.0.0.1'
    assert s._proxy.port == 1080
    assert s._proxy.username == 'user'

# Generated at 2022-06-18 15:48:54.798296
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    ss = sockssocket()
    ss.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1080)
    assert ss._proxy.type == ProxyType.SOCKS4
    assert ss._proxy.host == '127.0.0.1'
    assert ss._proxy.port == 1080
    assert ss._proxy.username is None
    assert ss._proxy.password is None
    assert ss._proxy.remote_dns is True
    ss.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 1080, False, 'user', 'pass')
    assert ss._proxy.type == ProxyType.SOCKS4A
    assert ss._proxy.host == '127.0.0.1'
    assert ss._proxy.port == 1080

# Generated at 2022-06-18 15:48:59.205842
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    except Socks5Error as e:
        assert e.args[0] == Socks5Error.ERR_GENERAL_FAILURE
        assert e.args[1] == 'general SOCKS server failure'


# Generated at 2022-06-18 15:49:05.732183
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import string
    import sys

    class TestSocksSocketRecvAll(unittest.TestCase):
        def test_recvall(self):
            s = sockssocket()
            s.connect(('www.google.com', 80))
            s.sendall(b'GET / HTTP/1.1\r\nHost: www.google.com\r\n\r\n')
            data = s.recvall(1024)
            self.assertTrue(data.startswith(b'HTTP/1.1'))

        def test_recvall_eof(self):
            s = sockssocket()
            s.connect(('www.google.com', 80))

# Generated at 2022-06-18 15:49:12.166242
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import os
    import sys
    import unittest
    import tempfile

    class SocksSocketTest(unittest.TestCase):
        def setUp(self):
            self.sock = sockssocket()
            self.sock.bind(('127.0.0.1', 0))
            self.port = self.sock.getsockname()[1]
            self.sock.listen(1)

        def tearDown(self):
            self.sock.close()

        def test_recvall(self):
            def _test_recvall(sock, data):
                self.assertEqual(sock.recvall(len(data)), data)
                self.assertRaises(EOFError, sock.recvall, len(data) + 1)

            client = sockssocket()
           

# Generated at 2022-06-18 15:49:17.347925
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080, username='username', password='password')
    assert s._proxy.type == ProxyType.SOCKS5
    assert s._proxy.host == '127.0.0.1'
    assert s._proxy.port == 8080
    assert s._proxy.username == 'username'
    assert s._proxy.password == 'password'
    assert s._proxy.remote_dns


# Generated at 2022-06-18 15:49:45.811868
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    sockssocket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    sockssocket.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1080)
    sockssocket.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 1080)


# Generated at 2022-06-18 15:49:58.432839
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import string
    import time

    class TestSocksSocket(unittest.TestCase):
        def setUp(self):
            self.sock = sockssocket()
            self.sock.bind(('127.0.0.1', 0))
            self.sock.listen(1)
            self.sock.settimeout(5)
            self.client_sock = sockssocket()
            self.client_sock.connect(self.sock.getsockname())
            self.conn, _ = self.sock.accept()

        def tearDown(self):
            self.conn.close()
            self.sock.close()
            self.client_sock.close()


# Generated at 2022-06-18 15:50:01.578710
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(0, 'test')
    except ProxyError as e:
        assert e.args[0] == 0
        assert e.args[1] == 'test'


# Generated at 2022-06-18 15:50:10.766385
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    assert s._proxy.type == ProxyType.SOCKS5
    assert s._proxy.host == '127.0.0.1'
    assert s._proxy.port == 1080
    assert s._proxy.username is None
    assert s._proxy.password is None
    assert s._proxy.remote_dns is True
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, username='user', password='pass')
    assert s._proxy.type == ProxyType.SOCKS5
    assert s._proxy.host == '127.0.0.1'
    assert s._proxy.port == 1080
    assert s._proxy.username == 'user'

# Generated at 2022-06-18 15:50:17.193022
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import mock

    class TestSocksSocket(unittest.TestCase):
        def test_recvall(self):
            with mock.patch('socket.socket.recv') as mock_recv:
                mock_recv.side_effect = [b'abc', b'def', b'ghi']
                s = sockssocket()
                self.assertEqual(s.recvall(9), b'abcdefghi')

    unittest.main()

# Generated at 2022-06-18 15:50:27.047808
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import random
    import time
    import unittest

    class TestSocksSocketRecvAll(unittest.TestCase):
        def setUp(self):
            self.sock = sockssocket()
            self.sock.settimeout(1)
            self.sock.connect(('127.0.0.1', 80))

        def tearDown(self):
            self.sock.close()

        def test_recvall(self):
            self.sock.sendall(b'GET / HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n')
            self.sock.recvall(4)


# Generated at 2022-06-18 15:50:31.203177
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(91)
    except Socks4Error as e:
        assert e.args[0] == 91
        assert e.args[1] == 'request rejected or failed'


# Generated at 2022-06-18 15:50:42.770483
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(code=None, msg=None)
    except ProxyError as e:
        assert e.args[0] == None
        assert e.args[1] == None
    try:
        raise ProxyError(code=0, msg=None)
    except ProxyError as e:
        assert e.args[0] == 0
        assert e.args[1] == None
    try:
        raise ProxyError(code=None, msg='test')
    except ProxyError as e:
        assert e.args[0] == None
        assert e.args[1] == 'test'
    try:
        raise ProxyError(code=0, msg='test')
    except ProxyError as e:
        assert e.args[0] == 0
        assert e.args[1] == 'test'

# Unit

# Generated at 2022-06-18 15:50:51.001727
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import mock

    class TestSocksSocket(unittest.TestCase):
        def test_recvall(self):
            with mock.patch('socket.socket.recv') as mock_recv:
                mock_recv.side_effect = [b'\x00', b'\x01', b'\x02', b'\x03']
                s = sockssocket()
                self.assertEqual(s.recvall(4), b'\x00\x01\x02\x03')

    unittest.main()

# Generated at 2022-06-18 15:50:53.091142
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError(0, 'test').args == (0, 'test')
    assert ProxyError(1).args == (1, 'unknown error')
    assert ProxyError().args == (None, None)


# Generated at 2022-06-18 15:51:07.902598
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import mock

    class TestSocksSocket(unittest.TestCase):
        def test_recvall(self):
            with mock.patch('socket.socket.recv') as mock_recv:
                mock_recv.side_effect = [b'abc', b'def', b'ghi']
                s = sockssocket()
                self.assertEqual(s.recvall(9), b'abcdefghi')

    unittest.main()

# Generated at 2022-06-18 15:51:17.541095
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    sockssocket.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1080)
    sockssocket.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 1080)
    sockssocket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    sockssocket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, username='test', password='test')
    sockssocket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, username='test', password='test', remote_dns=False)


# Generated at 2022-06-18 15:51:28.609243
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import string

    class TestSockssocketRecvall(unittest.TestCase):
        def test_recvall(self):
            s = sockssocket()
            s.connect(('www.google.com', 80))
            s.sendall(b'GET / HTTP/1.1\r\nHost: www.google.com\r\n\r\n')
            data = s.recvall(1024)
            self.assertTrue(data.startswith(b'HTTP/1.1'))

        def test_recvall_with_random_data(self):
            s = sockssocket()
            s.connect(('www.google.com', 80))

# Generated at 2022-06-18 15:51:37.765866
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import string

    class TestSocksSocketRecvAll(unittest.TestCase):
        def setUp(self):
            self.sock = sockssocket()
            self.sock.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
            self.sock.connect(('127.0.0.1', 1080))

        def tearDown(self):
            self.sock.close()

        def test_recvall(self):
            for i in range(0, 10):
                data = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(i))
                self.sock.sendall(data)

# Generated at 2022-06-18 15:51:45.006353
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import mock

    class TestSockssocketRecvall(unittest.TestCase):
        def test_recvall(self):
            with mock.patch('socks.sockssocket.sockssocket.recv') as mock_recv:
                mock_recv.side_effect = [b'abc', b'def', b'ghi']
                self.assertEqual(sockssocket().recvall(9), b'abcdefghi')

    unittest.main()

# Generated at 2022-06-18 15:51:48.707848
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import mock

    class TestSocksSocket(unittest.TestCase):
        def test_recvall(self):
            with mock.patch('socket.socket.recv') as mock_recv:
                mock_recv.side_effect = [b'foo', b'bar', b'baz']
                s = sockssocket()
                self.assertEqual(s.recvall(9), b'foobarbaz')

    unittest.main()

# Generated at 2022-06-18 15:52:00.039004
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import string
    import time
    import sys

    class TestSocksSocket(unittest.TestCase):
        def setUp(self):
            self.sock = sockssocket()
            self.sock.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
            self.sock.connect(('127.0.0.1', 80))

        def tearDown(self):
            self.sock.close()

        def test_recvall(self):
            # Send a random string to the server
            random_string = ''.join(random.choice(string.ascii_letters) for _ in range(1024))
            self.sock.sendall(random_string.encode('utf-8'))

            # Wait for the server

# Generated at 2022-06-18 15:52:10.352045
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1080)
    assert s._proxy.type == ProxyType.SOCKS4
    assert s._proxy.host == '127.0.0.1'
    assert s._proxy.port == 1080
    assert s._proxy.username is None
    assert s._proxy.password is None
    assert s._proxy.remote_dns is True
    s.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 1080, username='user', password='pass', remote_dns=False)
    assert s._proxy.type == ProxyType.SOCKS4A
    assert s._proxy.host == '127.0.0.1'
    assert s._proxy.port == 1080

# Generated at 2022-06-18 15:52:21.307168
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import socket
    import threading
    import time

    class TestSockssocketRecvall(unittest.TestCase):
        def setUp(self):
            self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server.bind(('127.0.0.1', 0))
            self.server.listen(1)
            self.server_thread = threading.Thread(target=self.server_thread)
            self.server_thread.daemon = True
            self.server_thread.start()
            self.client = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
            self

# Generated at 2022-06-18 15:52:25.628746
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import string
    import time

    class TestSocksSocket(unittest.TestCase):
        def setUp(self):
            self.sock = sockssocket()
            self.sock.bind(('127.0.0.1', 0))
            self.sock.listen(1)
            self.sock.settimeout(1)

        def test_recvall(self):
            # Create a random string
            random_string = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
            random_string_bytes = random_string.encode('utf-8')

            # Start a new thread to send the random string

# Generated at 2022-06-18 15:53:47.502454
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import mock

    class TestSockssocketRecvall(unittest.TestCase):
        def test_recvall(self):
            with mock.patch('socket.socket.recv') as mock_recv:
                mock_recv.side_effect = [b'\x00\x01', b'\x02\x03', b'\x04\x05']
                sock = sockssocket()
                self.assertEqual(sock.recvall(4), b'\x00\x01\x02\x03')
                self.assertEqual(sock.recvall(2), b'\x04\x05')

        def test_recvall_eof(self):
            with mock.patch('socket.socket.recv') as mock_recv:
                mock

# Generated at 2022-06-18 15:53:56.190970
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest

    class TestSocksSocketRecvAll(unittest.TestCase):
        def test_recvall(self):
            import random
            import string
            import time

            def random_string(length):
                return ''.join(random.choice(string.ascii_letters) for _ in range(length))

            def random_bytes(length):
                return ''.join(chr(random.randint(0, 255)) for _ in range(length))

            def random_int(length):
                return random.randint(0, (1 << (length * 8)) - 1)

            def random_ipv4():
                return '.'.join(str(random_int(1)) for _ in range(4))


# Generated at 2022-06-18 15:54:05.638768
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import time
    import threading
    import socket

    class SocksSocketTest(unittest.TestCase):
        def setUp(self):
            self.socks = sockssocket()
            self.socks.bind(('127.0.0.1', 0))
            self.socks.listen(1)
            self.socks_thread = threading.Thread(target=self.socks_thread_func)
            self.socks_thread.start()
            self.socks_client, _ = self.socks.accept()

        def tearDown(self):
            self.socks_client.close()
            self.socks.close()
            self.socks_thread.join()

        def socks_thread_func(self):
            self.socks_client

# Generated at 2022-06-18 15:54:16.232887
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import string
    import time

    class SocksSocketTest(unittest.TestCase):
        def test_recvall(self):
            s = sockssocket()
            s.setblocking(False)
            s.settimeout(1)
            s.connect(('127.0.0.1', 80))
            time.sleep(0.1)
            s.sendall(b'GET / HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n')
            time.sleep(0.1)
            data = s.recvall(20)
            self.assertEqual(data, b'HTTP/1.1 200 OK\r\n')

    unittest.main()

# Generated at 2022-06-18 15:54:24.834589
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import mock

    class TestSocksSocket(unittest.TestCase):
        def test_recvall(self):
            with mock.patch('socket.socket.recv') as mock_recv:
                mock_recv.side_effect = [b'123', b'456', b'789', b'']
                s = sockssocket()
                self.assertEqual(s.recvall(9), b'123456789')
                self.assertEqual(mock_recv.call_count, 4)
                self.assertEqual(mock_recv.call_args_list, [
                    mock.call(9), mock.call(6), mock.call(3), mock.call(3)])

    unittest.main()

# Generated at 2022-06-18 15:54:35.562998
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import string

    class TestSocksSocketRecvAll(unittest.TestCase):
        def test_recvall(self):
            s = sockssocket()
            s.connect(('www.google.com', 80))
            s.sendall(b'GET / HTTP/1.0\r\n\r\n')
            data = s.recvall(1024)
            self.assertTrue(data.startswith(b'HTTP/1.0 200 OK'))

        def test_recvall_random(self):
            s = sockssocket()
            s.connect(('www.google.com', 80))
            s.sendall(b'GET / HTTP/1.0\r\n\r\n')

# Generated at 2022-06-18 15:54:45.171065
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import mock

    class TestSocksSocket(unittest.TestCase):
        def test_recvall(self):
            with mock.patch('socket.socket.recv') as mock_recv:
                mock_recv.side_effect = [b'foo', b'bar', b'baz']
                s = sockssocket()
                self.assertEqual(s.recvall(9), b'foobarbaz')
                self.assertEqual(mock_recv.call_count, 3)
                mock_recv.side_effect = [b'foo', b'bar', b'']
                s = sockssocket()
                self.assertRaises(EOFError, s.recvall, 9)

# Generated at 2022-06-18 15:54:55.799555
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import random
    import unittest

    class TestSocksSocketRecvAll(unittest.TestCase):
        def test_recvall(self):
            s = sockssocket()
            s.setproxy(ProxyType.SOCKS5, 'localhost', 1080)
            s.connect(('google.com', 80))
            s.sendall(b'GET / HTTP/1.0\r\n\r\n')
            data = s.recvall(1024)
            self.assertTrue(data.startswith(b'HTTP/1.0'))

        def test_recvall_eof(self):
            s = sockssocket()
            s.setproxy(ProxyType.SOCKS5, 'localhost', 1080)
            s.connect(('google.com', 80))

# Generated at 2022-06-18 15:55:04.717510
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import random
    import string
    import unittest

    class TestSocksSocket(unittest.TestCase):
        def test_recvall(self):
            s = sockssocket()
            s.settimeout(1)
            s.connect(('localhost', 80))
            s.sendall(b'GET / HTTP/1.1\r\nHost: localhost\r\n\r\n')
            data = s.recvall(1024)
            self.assertTrue(data.startswith(b'HTTP/1.1'))

        def test_recvall_random(self):
            s = sockssocket()
            s.settimeout(1)
            s.connect(('localhost', 80))

# Generated at 2022-06-18 15:55:15.092101
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import time

    class TestSocksSocketRecvAll(unittest.TestCase):
        def test_recvall(self):
            s = sockssocket()
            s.bind(('', 0))
            s.listen(1)
            s.settimeout(1)

            t = sockssocket()
            t.settimeout(1)
            t.connect(s.getsockname())

            c, _ = s.accept()
            c.settimeout(1)

            for i in range(10):
                data = b''
                for j in range(random.randint(1, 10)):
                    data += compat_struct_pack('!B', random.randint(0, 255))
                t.sendall(data)

# Generated at 2022-06-18 15:57:14.638071
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import string

    class SocksSocketTestCase(unittest.TestCase):
        def setUp(self):
            self.sock = sockssocket()
            self.sock.bind(('localhost', 0))
            self.sock.listen(1)
            self.client = sockssocket()
            self.client.connect(self.sock.getsockname())

        def tearDown(self):
            self.client.close()
            self.sock.close()

        def test_recvall(self):
            for _ in range(10):
                data = ''.join(random.choice(string.ascii_letters) for _ in range(random.randint(1, 100)))
                self.client.sendall(data)
                conn, _ = self.sock

# Generated at 2022-06-18 15:57:26.065261
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import string
    import time

    class SockssocketRecvallTest(unittest.TestCase):
        def setUp(self):
            self.sock = sockssocket()
            self.sock.bind(('', 0))
            self.sock.listen(1)
            self.sock.settimeout(1)

        def tearDown(self):
            self.sock.close()

        def test_recvall(self):
            def _test_recvall(sock, cnt):
                data = b''
                while len(data) < cnt:
                    cur = sock.recv(cnt - len(data))
                    if not cur:
                        raise EOFError('{0} bytes missing'.format(cnt - len(data)))

# Generated at 2022-06-18 15:57:35.618147
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import mock

    class TestSocksSocket(unittest.TestCase):
        def test_recvall(self):
            with mock.patch('socket.socket.recv') as mock_recv:
                mock_recv.side_effect = [b'foo', b'bar', b'baz']
                s = sockssocket()
                self.assertEqual(s.recvall(9), b'foobarbaz')
                self.assertEqual(mock_recv.call_count, 3)
                self.assertEqual(mock_recv.call_args_list[0], mock.call(9))
                self.assertEqual(mock_recv.call_args_list[1], mock.call(6))

# Generated at 2022-06-18 15:57:45.710587
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import mock

    class TestSocksSocketRecvAll(unittest.TestCase):
        def test_recvall_success(self):
            with mock.patch('socket.socket.recv') as mock_recv:
                mock_recv.side_effect = [b'abc', b'def', b'ghi']
                s = sockssocket()
                result = s.recvall(9)
                self.assertEqual(result, b'abcdefghi')

        def test_recvall_fail(self):
            with mock.patch('socket.socket.recv') as mock_recv:
                mock_recv.side_effect = [b'abc', b'def', b'']
                s = sockssocket()