

# Generated at 2022-06-24 14:21:19.210110
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-24 14:21:24.536443
# Unit test for constructor of class ProxyError
def test_ProxyError():
    code = 1
    msg = 'test'
    exc = ProxyError(code, msg)
    assert exc.args == (code, msg)

    msg = 'test2'
    exc = ProxyError(msg=msg)
    assert exc.args == (None, msg)

    code = 2

    exc = ProxyError(code)
    assert exc.args == (code, 'unknown error')


# Generated at 2022-06-24 14:21:25.964192
# Unit test for constructor of class sockssocket
def test_sockssocket():
    test_socket = sockssocket()
    assert test_socket is not None

# Generated at 2022-06-24 14:21:32.893711
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    e = Socks4Error(Socks4Error.ERR_SUCCESS)
    assert e.args[0] is Socks4Error.ERR_SUCCESS
    assert e.args[1] is 'request rejected or failed'
    e = Socks4Error()
    assert e.args[0] is None
    assert e.args[1] is None
    e = Socks4Error(41)
    assert e.args[0] is 41
    assert e.args[1] is None
    e = Socks4Error(41, 'My error message')
    assert e.args[0] is 41
    assert e.args[1] is 'My error message'


# Generated at 2022-06-24 14:21:40.709403
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    socks4_command = Socks4Command()
    assert repr(Socks4Command) == "<class '__main__.Socks4Command'>"
    assert repr(socks4_command) == '<__main__.Socks4Command object at %x>' % id(socks4_command)
    assert socks4_command.CMD_CONNECT == SOCKS4_COMMAND_CONNECT
    assert socks4_command.CMD_BIND == SOCKS4_COMMAND_BIND
# Unit test of method _recv_bytes

# Generated at 2022-06-24 14:21:47.036694
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    dest_ip = '1.1.1.1'
    dest_port = 443
    dest_address = (dest_ip, dest_port)
    prox_ip = '2.2.2.2'
    prox_port = 1080
    prox_address = (prox_ip, prox_port)
    prox_username = 'user'
    prox_password = 'pass'
    socks_version = 5
    socks_type = ProxyType.SOCKS5

    # Create the proxy.
    prox_socket = sockssocket()
    prox_socket.setproxy(socks_type, prox_ip, prox_port)
    if socks_version == 5:
        assert prox_socket._proxy.username is None
        assert prox_socket._proxy.password is None

# Generated at 2022-06-24 14:21:48.947040
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    e = Socks4Error(1)
    assert e.args == (1, 'request rejected or failed')

# Generated at 2022-06-24 14:21:50.620480
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    error = InvalidVersionError(0x00, 0x01)
    assert str(error) == 'Invalid response version from server. Expected 00 got 01'

# Generated at 2022-06-24 14:21:59.266193
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    def not_impl():
        pass

    class MockSocket(object):
        def __init__(self, data):
            self._data = data
            self._offset = 0

        def recv(self, cnt):
            if self._offset >= len(self._data):
                return b''
            data = self._data[self._offset:self._offset + cnt]
            self._offset += cnt
            return data

    s = sockssocket()
    s.close = not_impl
    s.sendall = not_impl
    s.connect = not_impl
    s.connect_ex = not_impl

    # Should return correctly
    s._sock = MockSocket(b'\x01\x02\x03\x04')

# Generated at 2022-06-24 14:22:03.271068
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    try:
        assert Socks5Command.CMD_CONNECT == 0x01
        assert Socks5Command.CMD_BIND == 0x02
    except:
        print('Failed to test constructor of class Socks5Command')


# Generated at 2022-06-24 14:22:08.207425
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()

    proxy_info = Proxy(ProxyType.SOCKS5, '127.0.0.1', 1080, 'username', 'password', False)
    s.setproxy(proxy_info.type, proxy_info.host, proxy_info.port, proxy_info.remote_dns, proxy_info.username, proxy_info.password)

    assert s._proxy == proxy_info

# Generated at 2022-06-24 14:22:13.258785
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(0x1)
    except ProxyError as e:
        assert e.code == 0x1
        assert e.msg == 'general SOCKS server failure'
        return True
    except:
        return False
    assert False

if __name__ == '__main__':
    test_Socks5Error()

# Generated at 2022-06-24 14:22:15.128675
# Unit test for constructor of class ProxyType
def test_ProxyType():
    p = ProxyType.SOCKS4
    q = ProxyType.SOCKS5
    assert p != q



# Generated at 2022-06-24 14:22:16.109332
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert isinstance(ProxyError(11, 'Test message'), socket.error)

# Generated at 2022-06-24 14:22:18.342807
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    x = Socks4Command()
    assert x.CMD_CONNECT == 0x01
    assert x.CMD_BIND == 0x02



# Generated at 2022-06-24 14:22:20.986294
# Unit test for constructor of class ProxyError
def test_ProxyError():
    pr = ProxyError()
    assert pr.errno == None
    assert pr.strerror == None

    pr = ProxyError(1, 'Error')
    assert pr.errno == 1
    assert pr.strerror == 'Error'

# Generated at 2022-06-24 14:22:25.896244
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # Connects to google.com via socks5 proxy 127.0.0.1:1080
    # Returns the result of the connection attempt
    # 0 means success
    # Other numbers correspond to various error messages
    test_socket = sockssocket()
    test_socket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    print(test_socket.connect_ex(('google.com', 80)))
    test_socket.close()

# test_sockssocket_connect_ex()

# Generated at 2022-06-24 14:22:27.897442
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    exception = Socks5Error(Socks5Auth.AUTH_NO_ACCEPTABLE)
    assert exception.args == (Socks5Auth.AUTH_NO_ACCEPTABLE, 'all offered authentication methods were rejected')

# Generated at 2022-06-24 14:22:28.961434
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()
    # TODO: Test constructor
    pass

# Generated at 2022-06-24 14:22:30.029750
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sockssocket(type=socket.AF_INET, proto=0)


# Generated at 2022-06-24 14:22:31.268382
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    error = Socks4Error(91)
    assert error.strerror == 'request rejected or failed'


# Generated at 2022-06-24 14:22:36.814885
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(type = 0, host = "0.0.0.0", port = 1080, username = "", password = "", remote_dns = True)
    assert proxy._asdict() == {'type': 0, 'host': "0.0.0.0", 'port': 1080, 'username': "", 'password': "", 'remote_dns': True}

# Generated at 2022-06-24 14:22:41.574919
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04

test_Socks5AddressType()

# Generated at 2022-06-24 14:22:49.817196
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    if not Socks5Auth.__doc__:
        raise ValueError('__doc__ not defined')

    if Socks5Auth.AUTH_NONE is None:
        raise ValueError('AUTH_NONE not defined')
    if Socks5Auth.AUTH_GSSAPI is None:
        raise ValueError('AUTH_GSSAPI not defined')
    if Socks5Auth.AUTH_USER_PASS is None:
        raise ValueError('AUTH_USER_PASS not defined')
    if Socks5Auth.AUTH_NO_ACCEPTABLE is None:
        raise ValueError('AUTH_NO_ACCEPTABLE not defined')

test_Socks5Auth()

# Generated at 2022-06-24 14:22:53.288671
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-24 14:23:01.713141
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    # Sample SOCKS5 proxy
    proxy_host = '127.0.0.1'
    proxy_port = 9050
    # Sample host to connect
    dest_host = 'www.youtube.com'
    dest_port = 80
    # Create a SOCKS5 socket
    proxy_sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    # Set the proxy
    proxy_sock.setproxy(ProxyType.SOCKS5, proxy_host, proxy_port)
    # Connect to host
    proxy_sock.connect((dest_host, dest_port))
    print('Successfully connected to {}:{}'.format(dest_host, dest_port))


sockssocket.test = test_sockssocket_connect



# Generated at 2022-06-24 14:23:08.629026
# Unit test for constructor of class ProxyError
def test_ProxyError():
    old_init = ProxyError.__init__
    assert not hasattr(ProxyError, '__init__')
    ProxyError.__init__ = old_init
    e = ProxyError(code=0, msg='foo')
    assert e.errno == 0
    assert e.strerror == 'foo'
    ProxyError.__init__ = old_init

if __name__ == '__main__':
    test_ProxyError()

# Generated at 2022-06-24 14:23:13.590084
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert(Socks5AddressType.ATYP_IPV4 == 0x01)
    assert(Socks5AddressType.ATYP_DOMAINNAME == 0x03)
    assert(Socks5AddressType.ATYP_IPV6 == 0x04)

if __name__ == '__main__':
    test_Socks5AddressType()

# Generated at 2022-06-24 14:23:15.305902
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()
    assert s._proxy is None


# Generated at 2022-06-24 14:23:19.564664
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    try:
        Socks5Command.CMD_CONNECT
        Socks5Command.CMD_BIND
        Socks5Command.CMD_UDP_ASSOCIATE
    except:
        raise
    print('Test constructor successfully.')


# Generated at 2022-06-24 14:23:23.898845
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(0x01)
    except ProxyError as e:
        assert e.args[0] == 0x01
        assert e.args[1] == 'general SOCKS server failure'


# Generated at 2022-06-24 14:23:31.708767
# Unit test for constructor of class sockssocket
def test_sockssocket():
    from .compat import compat_socket_getaddrinfo
    proxy = Proxy(ProxyType.SOCKS4A, '198.41.0.4', 1080)
    socks = sockssocket()
    socks.setproxy(*proxy)
    for res in compat_socket_getaddrinfo('www.google.com', 'https'):
        af, socktype, proto, canonname, sa = res
        try:
            # Do not use connect_ex, since some platforms throw an exception even if the connection
            # succeeded (see https://bugs.python.org/issue20618).
            socks.connect(sa)
            break
        except socket.error:
            continue
    socks.close()

# Generated at 2022-06-24 14:23:35.605191
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    try:
        a = Socks4Command.CMD_CONNECT
        b = Socks4Command.CMD_BIND
        a = Socks4Command.CMD_UDP_ASSOCIATE
    except Exception as e:
        raise AssertionError(str(e))


# Generated at 2022-06-24 14:23:39.641986
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import socks
    lport = 9090
    lhost = '127.0.0.1'
    s = socks.socksocket()
    try:
        s.bind((lhost,lport))
    except Exception as e:
        print ('Error:', e)
    try:
        s.setproxy(socks.SOCKS5,'127.0.0.1',1234)
    except:
        print ('Error: set proxy fail')
    try:
        s.connect_ex(('127.0.0.1',80))
    except Exception as e:
        print ('Error:', e)


# Generated at 2022-06-24 14:23:41.000232
# Unit test for constructor of class sockssocket
def test_sockssocket():
    test = sockssocket()
    assert test._proxy is None


# Generated at 2022-06-24 14:23:49.480057
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    address = ('www.example.com', 80)
    expected_ip = socket.gethostbyname(address[0])

    socks_sock = sockssocket()
    socks_sock.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8800)
    o = socks_sock.connect_ex(address)
    assert o == 0
    socks_sock.close()

    socks_sock2 = sockssocket()
    socks_sock2.setproxy(ProxyType.SOCKS5, '127.0.0.2', 8800, username='wronguser', password='wrongpass')
    o2 = socks_sock2.connect_ex(address)
    assert o2 != 0
    socks_sock2.close()

    socks_sock3 = sockssocket()
    socks

# Generated at 2022-06-24 14:23:53.947617
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-24 14:23:56.912487
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    addr = '127.0.0.1'
    port = 1080
    s.setproxy(ProxyType.SOCKS4, addr, port)
    return (s._proxy.host == addr and s._proxy.port == port)

# Generated at 2022-06-24 14:24:03.629931
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Start an echo server
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('127.0.0.1', 0))
    server_socket.listen(5)
    _, server_port = server_socket.getsockname()

    server_thread = threading.Thread(target=server_thread_func, args=(server_socket,))
    server_thread.daemon = True
    server_thread.start()

    # Connect to echo server
    proxy_socket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    proxy_socket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 9050)

# Generated at 2022-06-24 14:24:14.081441
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error(0).args[1] == 'request granted'
    assert Socks5Error(1).args[1] == 'general SOCKS server failure'
    assert Socks5Error(2).args[1] == 'connection not allowed by ruleset'
    assert Socks5Error(3).args[1] == 'Network unreachable'
    assert Socks5Error(4).args[1] == 'Host unreachable'
    assert Socks5Error(5).args[1] == 'Connection refused'
    assert Socks5Error(6).args[1] == 'TTL expired'
    assert Socks5Error(7).args[1] == 'Command not supported'
    assert Socks5Error(8).args[1] == 'Address type not supported'

# Generated at 2022-06-24 14:24:16.598034
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s=sockssocket()
    s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 8888)


if __name__ == '__main__':
    test_sockssocket_setproxy()

# Generated at 2022-06-24 14:24:24.550160
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import mock

    class SocksSocketTestCase(unittest.TestCase):
        def test_recvall(self):
            with mock.patch('socket.socket.recv') as recv:
                recv.side_effect = [b'ABC', b'D']
                ss = sockssocket()
                result = ss.recvall(10)
                self.assertEqual(b'ABCD', result)
                recv.assert_has_calls([
                    mock.call(10),
                    mock.call(10),
                ])

    unittest.main()


# Generated at 2022-06-24 14:24:28.641629
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-24 14:24:33.382959
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xff



# Generated at 2022-06-24 14:24:36.582282
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    err = Socks5Error(0x01)
    assert err.args[0] == 0x01, 'tests failed'


# Generated at 2022-06-24 14:24:47.470176
# Unit test for constructor of class ProxyError
def test_ProxyError():
    if 'windows' in sys.platform:
        return
    try:
        raise ProxyError()
    except ProxyError as e:
        assert(e.errno is None and e.strerror is None)
    try:
        raise ProxyError(code=-1)
    except ProxyError as e:
        assert(e.errno == -1 and e.strerror is None)
    try:
        raise ProxyError(msg='test')
    except ProxyError as e:
        assert(e.errno is None and e.strerror == 'test')
    try:
        raise ProxyError(code=1, msg='test')
    except ProxyError as e:
        assert(e.errno == 1 and e.strerror == 'test')

# Generated at 2022-06-24 14:24:49.593398
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    socks5_auth = Socks5Auth()

if __name__ == '__main__':
    test_Socks5Auth()

# Generated at 2022-06-24 14:24:53.273999
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    s4 = Socks4Command()
    s5 = Socks5Command()
    print("Socks4Command: ", s4.CMD_CONNECT)
    print("Socks5Command: ", s5.CMD_CONNECT, s5.CMD_UDP_ASSOCIATE)



# Generated at 2022-06-24 14:24:58.998839
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    # Create the class object
    s5AddrType = Socks5AddressType()
    print('test_Socks5AddressType 0')
    # Test the getter
    assert (s5AddrType.ATYP_IPV4 == 0x01)
    print('test_Socks5AddressType 1')
    assert (s5AddrType.ATYP_DOMAINNAME == 0x03)
    print('test_Socks5AddressType 2')
    assert (s5AddrType.ATYP_IPV6 == 0x04)
    print('test_Socks5AddressType 3')
    print('test_Socks5AddressType 4')


# Generated at 2022-06-24 14:25:03.237386
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS4, '127.0.0.1', 1080, 'username', 'password', True)
    print(proxy)


if __name__ == '__main__':
    test_Proxy()

# Generated at 2022-06-24 14:25:06.304747
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError()
    except Exception as e:
        pass
    assert(isinstance(e, ProxyError))

# Generated at 2022-06-24 14:25:15.793704
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    dummy_data = 'dummy'

    sock = sockssocket()
    sock.recv = lambda n: dummy_data if n <= len(dummy_data) else None
    assert sock.recvall(len(dummy_data)) == dummy_data

    # Raises EOFError if not enough bytes have been received
    sock = sockssocket()
    sock.recv = lambda n: dummy_data
    try:
        dummy_data = 'dummy'
        sock.recvall(len(dummy_data) + 1)
    except EOFError:
        pass
    else:
        assert False, 'sockssocket.recvall does not raise EOFError if not enough bytes have been received.'

# Generated at 2022-06-24 14:25:18.546041
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    if not Socks5Auth.AUTH_NONE == 0x00:
        return 1
    if not Socks5Auth.AUTH_GSSAPI == 0x01:
        return 2
    if not Socks5Auth.AUTH_USER_PASS == 0x02:
        return 3
    if not Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF:
        return 4
    return 0


# Generated at 2022-06-24 14:25:20.652680
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:25:26.923040
# Unit test for constructor of class Proxy
def test_Proxy():
    try:
        proxy = Proxy(ProxyType.SOCKS4, 'localhost', 8080, 'username', 'password', True)
        assert(proxy.type == ProxyType.SOCKS4)
        assert(proxy.host == 'localhost')
        assert(proxy.port == 8080)
        assert(proxy.username == 'username')
        assert(proxy.password == 'password')
        assert(proxy.remote_dns == True)
        print("PASSED: the constructor of class Proxy passes the test!")
    except:
        print("FAILED: the constructor of class Proxy failed the test!")

if __name__ == "__main__":
    test_Proxy()

# Generated at 2022-06-24 14:25:33.593776
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError().msg == 'unknown error'
    assert ProxyError(code=0).msg == 'unknown error'
    assert ProxyError(msg='test').msg == 'test'
    assert ProxyError(code=92).msg == 'request rejected because SOCKS server cannot connect to identd on the client'
    assert ProxyError(code=94).msg == 'unknown error'

# Generated at 2022-06-24 14:25:41.130418
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    sut = Socks5Error(0x01, "general SOCKS server failure")
    assert sut.errno == 0x01
    assert sut.strerror == 'general SOCKS server failure'
    assert sut.args == (0x01, 'general SOCKS server failure')


if __name__ == '__main__':
    test_Socks5Error()

# Generated at 2022-06-24 14:25:49.755921
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    # test for attribute
    assert(Socks5Command.CMD_CONNECT == 0x01)
    assert(Socks5Command.CMD_BIND == 0x02)
    assert(Socks5Command.CMD_UDP_ASSOCIATE == 0x03)
    # ensure that the attribute is not writable
    try:
        Socks5Command.CMD_CONNECT = 0x00
        assert(False)
    except AttributeError:
        assert(True)


# Generated at 2022-06-24 14:25:52.698540
# Unit test for constructor of class ProxyType
def test_ProxyType():
    proxytype = ProxyType()

    assert proxytype.SOCKS4 == 0
    assert proxytype.SOCKS4A == 1
    assert proxytype.SOCKS5 == 2


# Generated at 2022-06-24 14:25:54.335814
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error(0x91).args == (0x91, 'request rejected or failed')


# Generated at 2022-06-24 14:25:56.473653
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    cmd = Socks4Command()
    assert cmd.CMD_CONNECT == 0x01
    assert cmd.CMD_BIND == 0x02



# Generated at 2022-06-24 14:25:58.823265
# Unit test for constructor of class ProxyType
def test_ProxyType():
    http = ProxyType()
    assert(http == 0)
    if http != 0:
        print('test_ProxyType is fail')
    else:
        print('test_ProxyType is pass')

test_ProxyType()


# Generated at 2022-06-24 14:26:04.941468
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
	fsock = sockssocket()
	fsock.setproxy(ProxyType.SOCKS5, 'localhost', 1080, True)
	fsock.connect(("www.google.com", 80))
	fsock.send("GET / HTTP/1.1\r\n\r\n")

# Generated at 2022-06-24 14:26:10.971073
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    socks_addr = Socks5AddressType()
    assert hex(socks_addr.ATYP_IPV4) == "0x1"
    assert hex(socks_addr.ATYP_IPV6) == "0x4"
    assert hex(socks_addr.ATYP_DOMAINNAME) == "0x3"


# Generated at 2022-06-24 14:26:14.115001
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    e = Socks4Error(code=91)
    assert e.errno == 91
    assert str(e) == "91: request rejected or failed"



# Generated at 2022-06-24 14:26:18.792459
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import request
    import os
    import errno
    print(request.getproxy('https'))
    try:
        sockssocket().setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080).connect_ex(('127.0.0.1', 80))
        print(request.getproxy('https'))
    except SocketError as e:
        print(errno.errorcode[e.errno])

# Generated at 2022-06-24 14:26:23.997695
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    err = Socks4Error()
    assert err.errno == 0
    assert str(err) == 'unknown error'

    err = Socks4Error(2)
    assert err.errno == 2
    assert str(err) == 'request rejected because SOCKS server cannot connect to identd on the client'


# Generated at 2022-06-24 14:26:28.832423
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    sockssocket.connect_ex = lambda address: 0

    proxy = ProxyType.SOCKS4
    addr = '127.0.0.1'
    port = '80'

    s = sockssocket()
    s.setproxy(proxy, addr, port)
    code = s.connect_ex((addr, port))

    assert code == 0

# Generated at 2022-06-24 14:26:32.942708
# Unit test for constructor of class sockssocket
def test_sockssocket():
    SOCKET = sockssocket()
    SOCKET.setproxy(ProxyType.SOCKS4, '127.0.0.1', 8080)
    assert SOCKET._proxy == Proxy(ProxyType.SOCKS4, '127.0.0.1', 8080, None, None, True)

# Generated at 2022-06-24 14:26:44.649703
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    address = '127.0.0.1'
    port = 1080

# Generated at 2022-06-24 14:26:46.576498
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert type(Socks5Auth.AUTH_NONE) is int

if __name__ == '__main__':
    test_Socks5Auth()

# Generated at 2022-06-24 14:26:49.374722
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    with sockssocket() as socket_socks:
        socket_socks.setproxy(ProxyType.SOCKS4, '127.0.0.1', 9050)
        assert socket_socks.connect_ex(('127.0.0.1', 9051)) == 0

# Generated at 2022-06-24 14:26:52.154702
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF

# Generated at 2022-06-24 14:26:52.603194
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sock = sockssocket()

# Generated at 2022-06-24 14:26:54.953595
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    ex = Socks5Error(1)
    assert(ex.code == 1)
    assert(ex.errno == 1)
    assert(ex.strerror == 'general SOCKS server failure')
    assert(ex.msg == 'general SOCKS server failure')

# Generated at 2022-06-24 14:27:01.364411
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    host = 'localhost'
    port = 8125
    addr = (host, port)
    socket1 = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    socket1.connect((host, port))
    for i in range(10):
        data = b'hello world'
        socket1.sendall(data)
        recv_data = socket1.recvall(len(data))
        assert recv_data == data
    socket1.close()



# Generated at 2022-06-24 14:27:05.601090
# Unit test for constructor of class ProxyType
def test_ProxyType():
    try:
        type = ProxyType(1, 'a', 3, True, '1', '2')
        print('Test: OK')
    except:
        print('Test: Error')


test_ProxyType()

# Generated at 2022-06-24 14:27:13.042360
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    host = 'www.google.com'
    port = 80
    proxy_host = '127.0.0.1'
    proxy_port = 1080
    proxy_type = ProxyType.SOCKS5
    try:
        s = sockssocket()
        s.setproxy(proxy_type, proxy_host, proxy_port)
        result = s.connect_ex((host, port))
        if result != 0:
            return False
        return True
    except:
        return False

if __name__ == '__main__':
    print(test_sockssocket_connect_ex())

# Generated at 2022-06-24 14:27:14.796569
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02



# Generated at 2022-06-24 14:27:16.718697
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(0, 'testing')
    except ProxyError as e:
        assert e.args[0] == 0
        assert e.args[1] == 'testing'


# Generated at 2022-06-24 14:27:29.187744
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 8888)
    assert (s._proxy == Proxy(ProxyType.SOCKS4, '127.0.0.1', 8888, None, None, True))
    s.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 8888, username='foo', password='bar', remote_dns=False)
    assert (s._proxy == Proxy(ProxyType.SOCKS4A, '127.0.0.1', 8888, 'foo', 'bar', False))
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8888)

# Generated at 2022-06-24 14:27:40.405638
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error()
    assert Socks5Error().args == (None, None)
    assert Socks5Error(Socks5Error.ERR_GENERAL_FAILURE).args == (Socks5Error.ERR_GENERAL_FAILURE, 'general SOCKS server failure')
    assert Socks5Error(None, 'test').args == (None, 'test')
    assert Socks5Error(999, 'test').args == (999, 'test')
    assert Socks5Error(888, None).args == (888, None)

if __name__ == '__main__':
    test_Socks5Error()
    print('Tests passed')

# Generated at 2022-06-24 14:27:48.673004
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    cmd = Socks5Command();
    cmd.CMD_CONNECT = Socks5Command.CMD_CONNECT;
    cmd.CMD_BIND = Socks5Command.CMD_BIND;
    cmd.CMD_UDP_ASSOCIATE = Socks5Command.CMD_UDP_ASSOCIATE;
    assert cmd.CMD_CONNECT == 0x01;
    assert cmd.CMD_BIND == 0x02;
    assert cmd.CMD_UDP_ASSOCIATE == 0x03;


# Generated at 2022-06-24 14:27:51.132736
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    s = Socks5Command()
    print(s.CMD_CONNECT, s.CMD_BIND, s.CMD_UDP_ASSOCIATE)

# Generated at 2022-06-24 14:27:55.314270
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    auth = Socks5Auth()
    assert hasattr(auth, 'AUTH_NONE')
    assert hasattr(auth, 'AUTH_GSSAPI')
    assert hasattr(auth, 'AUTH_USER_PASS')
    assert hasattr(auth, 'AUTH_NO_ACCEPTABLE')



# Generated at 2022-06-24 14:27:56.681913
# Unit test for constructor of class sockssocket
def test_sockssocket():
    obj = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    assert isinstance(obj, sockssocket)
    assert isinstance(obj, socket.socket)

# Generated at 2022-06-24 14:28:00.069347
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    sock = sockssocket()
    sock.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080)
    obj_proxy = Proxy(ProxyType.SOCKS5, '127.0.0.1', 8080, None, None, True)
    assert sock._proxy == obj_proxy

# Generated at 2022-06-24 14:28:04.793951
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04

# Generated at 2022-06-24 14:28:14.109510
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    try:
        Socks5AddressType()
        assert False, "Should've thrown an exception."
    except TypeError:
        pass
    try:
        Socks5AddressType("AAAA")
        assert False, "Should've thrown an exception."
    except TypeError:
        pass
    try:
        Socks5AddressType(0)
    except TypeError:
        assert False, "Shouldn't have thrown an exception."
    try:
        Socks5AddressType(1)
    except TypeError:
        assert False, "Shouldn't have thrown an exception."
    try:
        Socks5AddressType(2)
        assert False, "Should've thrown an exception."
    except TypeError:
        pass

# Generated at 2022-06-24 14:28:22.492986
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    from .fetcher import fetch
    from .config import DEFAULT_SOCKS_HOST, DEFAULT_SOCKS_PORT
    import os

    s = sockssocket()
    s.setproxy(
        ProxyType.SOCKS5, DEFAULT_SOCKS_HOST, DEFAULT_SOCKS_PORT,
        username=os.environ['YTDL_SOCKS_USERNAME'],
        password=os.environ['YTDL_SOCKS_PASSWORD'])
    s.connect(('youtube.com', 443))
    print(fetch(b'https://youtube.com/', socks_socket=s))

if __name__ == '__main__':
    test_sockssocket_connect()

# Generated at 2022-06-24 14:28:24.231275
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    with pytest.raises(TypeError):
        InvalidVersionError()
    error = InvalidVersionError(1, 2)
    assert error.args[0] == 0
    assert error.args[1] == 'Invalid response version from server. Expected 01 got 02'



# Generated at 2022-06-24 14:28:26.581250
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 1
    assert Socks4Command.CMD_BIND == 2


# Generated at 2022-06-24 14:28:28.812317
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    cmd = Socks4Command()

    assert cmd.CMD_CONNECT == 0x01
    assert cmd.CMD_BIND == 0x02


# Generated at 2022-06-24 14:28:35.952843
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    """
    test_sockssocket_recvall()
    """
    import pytest

    s = sockssocket()
    s.bind(("127.0.0.1", 54321))
    s.listen(1)
    c = sockssocket()
    c.setproxy(ProxyType.SOCKS5, '127.0.0.1', 54321)
    c.connect(("127.0.0.1", 54321))
    s, _ = s.accept()
    for i in range(1000000):
        s.sendall(compat_struct_pack('!I', i))
        j = compat_struct_unpack('!I', c.recvall(4))[0]
        if i != j:
            assert False
    c.close()
    s.close()

# Generated at 2022-06-24 14:28:43.736509
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import threading

    class SocketServer(threading.Thread):
        def __init__(self):
            threading.Thread.__init__(self)
            self.sock = None

        def run(self):
            self.sock = socket.socket()
            self.sock.bind(('localhost', 0))
            self.sock.listen(2)
            conn, _ = self.sock.accept()

            msg = conn.recv(1024)
            self.assert_equal(len(msg), 1)
            self.assert_equal(msg[0], 42)
            conn.send(msg)

            msg = conn.recv(1024)
            self.assert_equal(len(msg), 2)
            self.assert_equal(msg[0], 42)

# Generated at 2022-06-24 14:28:48.448339
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-24 14:28:55.926127
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error().errno == None
    assert Socks4Error().strerror == None
    assert Socks4Error(91).errno == 91
    assert Socks4Error(92).errno == 92
    assert Socks4Error(93).errno == 93
    assert Socks4Error(91).strerror == 'request rejected or failed'
    assert Socks4Error(93).strerror == 'request rejected because the client program and identd report different user-ids'
    assert Socks4Error(0, 'foo').errno == 0
    assert Socks4Error(19, 'foo').strerror == 'foo'
    assert Socks4Error(17, 'foo').errno == 17


# Generated at 2022-06-24 14:28:59.389435
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-24 14:29:02.335877
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:29:13.027746
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import random
    import time
    import unittest

    class SocksSocketRecvAllTest(unittest.TestCase):
        def setUp(self):
            self.socket_num = random.randint(1024, 65535)
            self.socket_pair = socket.socketpair()

        def tearDown(self):
            self.socket_pair[0].close()
            self.socket_pair[1].close()

        def test_recvall(self):
            self.socket_pair[0].setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, True)
            self.socket_pair[0].bind(('127.0.0.1', self.socket_num))
            self.socket_pair[0].listen(1)

# Generated at 2022-06-24 14:29:15.913544
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert 0x01 == Socks5AddressType.ATYP_IPV4
    assert 0x03 == Socks5AddressType.ATYP_DOMAINNAME
    assert 0x04 == Socks5AddressType.ATYP_IPV6


# Generated at 2022-06-24 14:29:21.728940
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error(1).code == 1
    assert Socks4Error(92).code == 92
    assert Socks4Error(92).msg == 'request rejected because SOCKS server cannot connect to identd on the client'
    assert Socks4Error(3, 'foo').msg == 'foo'


# Generated at 2022-06-24 14:29:25.411052
# Unit test for constructor of class ProxyType
def test_ProxyType():
    # test object
    proxytype = ProxyType()
    assert proxytype.SOCKS4 == 0
    assert proxytype.SOCKS4A == 1
    assert proxytype.SOCKS5 == 2


# Generated at 2022-06-24 14:29:30.483306
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    socks_socket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    socks_socket.setproxy(
        ProxyType.SOCKS5, '127.0.0.1', 1080, username='username', password='password')
    result = socks_socket.connect_ex(('8.8.8.8', 53))
    print(result)



# Generated at 2022-06-24 14:29:34.817903
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    cmd = Socks4Command()
    assert(cmd.CMD_CONNECT == Socks4Command.CMD_CONNECT)
    assert(cmd.CMD_BIND == Socks4Command.CMD_BIND)



# Generated at 2022-06-24 14:29:35.918070
# Unit test for constructor of class sockssocket
def test_sockssocket():
    return sockssocket()


# Generated at 2022-06-24 14:29:36.705469
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sockssocket.connect('eel')

# Generated at 2022-06-24 14:29:38.501703
# Unit test for constructor of class Proxy
def test_Proxy():
	Proxy(ProxyType.SOCKS4, "66.235.196.131", 1080, None, None, False)


# Generated at 2022-06-24 14:29:40.259260
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sockssocket().connect(('127.0.0.1', 80))

# Generated at 2022-06-24 14:29:43.886494
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    cmd = Socks4Command()
    assert cmd.CMD_CONNECT == 0x01
    assert cmd.CMD_BIND == 0x02


# Generated at 2022-06-24 14:29:45.721713
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sockssocket.connect(('127.0.0.1', 1080))

# Generated at 2022-06-24 14:29:50.068787
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    ssa = Socks5Auth()
    assert ssa.AUTH_NONE == 0
    assert ssa.AUTH_GSSAPI == 1
    assert ssa.AUTH_USER_PASS == 2
    assert ssa.AUTH_NO_ACCEPTABLE == 255


# Generated at 2022-06-24 14:29:58.183075
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import random
    import sys
    import urllib
    import urllib2
    from .compat import (
        compat_str,
        compat_urlparse,
    )
    from .utils import (
        unescapeHTML,
        update_scheme,
    )

    # Check whether it works to use sockssocket for HTTP(S) over SOCKS5 proxy
    socks_proxy = '127.0.0.1:9050'
    scheme = 'https'
    test_url = 'https://www.example.com'
    if sys.version_info[0] < 3:
        test_url = test_url.decode('utf-8')
    sockssocket.setproxy(sockssocket, ProxyType.SOCKS5, *socks_proxy.split(':'))

# Generated at 2022-06-24 14:30:02.251297
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert isinstance(Socks5AddressType.ATYP_DOMAINNAME, int)
    assert isinstance(Socks5AddressType.ATYP_IPV4, int)
    assert isinstance(Socks5AddressType.ATYP_IPV6, int)
    assert Socks5AddressType.ATYP_DOMAINNAME == 3
    assert Socks5AddressType.ATYP_IPV4 == 1
    assert Socks5AddressType.ATYP_IPV6 == 4

# Generated at 2022-06-24 14:30:04.576519
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(7, 8)
    except InvalidVersionError as e:
        assert e.args[0] == 7
        assert e.args[1] == 8
    else:
        assert False, "Exception not raised"


# Generated at 2022-06-24 14:30:06.202148
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 1
    assert Socks4Command.CMD_BIND == 2



# Generated at 2022-06-24 14:30:18.789414
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import sys
    import socks
    import socket
    import logging

    logging.basicConfig(stream=sys.stdout, level=logging.INFO)

    ss = socks.socksocket()
    ss.setproxy(socks.PROXY_TYPE_HTTP, 'proxy.mimic-tile.com', 3128)
    ss.connect(('www.huya.com', 80))
    logging.info('ss connect')
    ss.sendall(b'GET / HTTP/1.1\r\nHost: www.huya.com\r\nConnection: close\r\n\r\n')
    logging.info('ss send')
    while True:
        d = ss.recv(1024)
        if d:
            logging.info(d)
        else:
            break

# Generated at 2022-06-24 14:30:20.609430
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    sockssocket.connect_ex(('13.13.13.13', 80))

# Generated at 2022-06-24 14:30:23.927293
# Unit test for constructor of class sockssocket
def test_sockssocket():
    new_socket = sockssocket()
    assert new_socket.type == socket.SOCK_STREAM
    assert new_socket.timeout == socket._GLOBAL_DEFAULT_TIMEOUT
    assert new_socket.proxies == None


# Generated at 2022-06-24 14:30:28.247176
# Unit test for constructor of class ProxyError
def test_ProxyError():
    ProxyError_ex = ProxyError()
    #assert ProxyError_ex.code == None
    #assert ProxyError_ex.message == None
    print (ProxyError_ex.code)
    print (ProxyError_ex.message)
    print (ProxyError_ex.args)
    print (ProxyError_ex.__str__())


# Generated at 2022-06-24 14:30:31.986554
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-24 14:30:42.141972
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import unittest.mock as mock
    from io import BytesIO

    class MockSocket(object):
        def __init__(self, data):
            self.data = BytesIO(data)

        def recv(self, n):
            return self.data.read(n)

    class TestRecvAll(unittest.TestCase):
        @mock.patch.object(sockssocket, 'recv')
        def test_padded_recv_all(self, mock_recv):
            sock = MockSocket(b'1234')
            mock_recv.side_effect = sock.recv
            got = sockssocket._recv_bytes(sock, 4)
            expected = (49, 50, 51, 52)
            self.assertEqual(got, expected)



# Generated at 2022-06-24 14:30:45.841652
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error(Socks5Error.ERR_GENERAL_FAILURE).errno == Socks5Error.ERR_GENERAL_FAILURE
    assert Socks5Error(Socks5Error.ERR_GENERAL_FAILURE).strerror == 'general SOCKS server failure'



# Generated at 2022-06-24 14:30:46.759324
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()



# Generated at 2022-06-24 14:30:49.099054
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    assert hasattr(sockssocket, 'setproxy')
    assert callable(sockssocket.setproxy)



# Generated at 2022-06-24 14:30:51.059552
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:30:52.877658
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    instance = Socks4Command()
    assert isinstance(instance, object)


# Generated at 2022-06-24 14:30:54.481148
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sockssocket.connect(sockssocket, (host,port))


# Generated at 2022-06-24 14:30:59.572735
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    expected_version, got_version = 1, 2
    exc = InvalidVersionError(expected_version, got_version)
    assert exc.errno == 0
    assert exc.strerror == 'Invalid response version from server. Expected 01 got 02'


# Generated at 2022-06-24 14:31:01.761296
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    expected_result = Socks5Auth()
    assert Socks5Auth.AUTH_NONE == expected_result.AUTH_NONE
    
if __name__ == '__main__':
    test_Socks5Auth()

# Generated at 2022-06-24 14:31:02.436939
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()

# Generated at 2022-06-24 14:31:03.093408
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket()

# Generated at 2022-06-24 14:31:07.290850
# Unit test for constructor of class ProxyError
def test_ProxyError():
    print('Testing constructors of class ProxyError')
    err1 = ProxyError()
    assert err1.strerror is None
    assert err1.errno is None
    print('Passed')

    print('Testing constructors of class ProxyError')
    err2 = ProxyError(code=ProxyError.ERR_SUCCESS, msg='test')
    assert err2.strerror == 'Success'
    assert err2.errno == ProxyError.ERR_SUCCESS
    print('Passed')

# Generated at 2022-06-24 14:31:13.418620
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    # 1st argument, code, is None
    exc_1 = Socks5Error()
    assert exc_1.code == 0
    assert exc_1.msg == 'unknown error'
    # 1st argument, code, is not None
    exc_2 = Socks5Error(code=1)
    assert exc_2.code == 1
    assert exc_2.msg == 'general SOCKS server failure'
    # 2nd argument, msg, is not None
    exc_3 = Socks5Error(msg='General SOCKS server failure')
    assert exc_3.code == 0
    assert exc_3.msg == 'General SOCKS server failure'

# Generated at 2022-06-24 14:31:15.477936
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    c = Socks5Command()
    assert c.CMD_CONNECT == 0x01
    assert c.CMD_BIND == 0x02
    assert c.CMD_UDP_ASSOCIATE == 0x03
