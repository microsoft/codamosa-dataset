

# Generated at 2022-06-24 14:21:19.130235
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error(Socks4Error.ERR_SUCCESS).args == (Socks4Error.ERR_SUCCESS, None)

# Generated at 2022-06-24 14:21:24.464147
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sock = sockssocket()
    assert (sock.type == socket.SOCK_STREAM)
    assert (sock.family == socket.AF_INET)
    assert (sock.proto == socket.IPPROTO_TCP)
    assert (sock.timeout is None)
    return sock

if __name__ == '__main__':
    sock = test_sockssocket()

# Generated at 2022-06-24 14:21:27.402458
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    cmd = Socks5Command()
    cmd.CMD_CONNECT = 0x01
    cmd.CMD_BIND = 0x02
    cmd.CMD_UDP_ASSOCIATE = 0x03


# Generated at 2022-06-24 14:21:30.310637
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04

# Generated at 2022-06-24 14:21:35.256572
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    error = Socks4Error(code=91)
    assert error.code == 91
    assert str(error) == 'request rejected or failed'
    error = Socks4Error(msg='request rejected or failed')
    assert error.code == None
    assert str(error) == 'request rejected or failed'

# Generated at 2022-06-24 14:21:36.992030
# Unit test for constructor of class ProxyType
def test_ProxyType():
    pt = ProxyType()
    assert pt == ProxyType.SOCKS5


# Generated at 2022-06-24 14:21:38.289652
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01


# Generated at 2022-06-24 14:21:44.131343
# Unit test for constructor of class ProxyError
def test_ProxyError():
    error = ProxyError()
    assert error.args[0] == None
    assert error.args[1] == None
    error = ProxyError(0x00)
    assert error.args[0] == 0x00
    assert error.args[1] == None
    error = ProxyError(msg='test message')
    assert error.args[0] == None
    assert error.args[1] == 'test message'
    error = ProxyError(0x00, 'test message')
    assert error.args[0] == 0x00
    assert error.args[1] == 'test message'


# Generated at 2022-06-24 14:21:49.179635
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    from .compat import is_py2

    s = sockssocket()

    s.setproxy(ProxyType.SOCKS4, 'proxyhost', 12345)
    assert s._proxy.type == ProxyType.SOCKS4
    assert s._proxy.host == 'proxyhost'
    assert s._proxy.port == 12345
    assert s._proxy.username is None
    assert s._proxy.password is None
    assert s._proxy.remote_dns is True

    s.setproxy(ProxyType.SOCKS4A, 'proxyhost', 12345, rdns=False, username='user', password='pass')
    if is_py2:
        assert s._proxy.type == ProxyType.SOCKS4A
        assert s._proxy.host == 'proxyhost'
        assert s._proxy.port == 12345


# Generated at 2022-06-24 14:21:51.900697
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    addr = Socks5AddressType
    assert addr.ATYP_IPV4 == 0x01
    assert addr.ATYP_DOMAINNAME == 0x03
    assert addr.ATYP_IPV6 == 0x04


# Generated at 2022-06-24 14:21:52.769715
# Unit test for constructor of class sockssocket
def test_sockssocket():
    socks = sockssocket()
    assert socks is not None

# Generated at 2022-06-24 14:21:56.389091
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError().args == (None, None)
    assert ProxyError(0, 'test').args == (0, 'test')
    assert ProxyError(1).args == (1, 'unknown error')

# Unit tests for constructor of class Socks4Error

# Generated at 2022-06-24 14:22:02.768310
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    s5obj = Socks5Auth()
    print("\n[+] Testing Socks5 Auth class")
    print("\t[+] Testing AUTH_NONE: %d" % (s5obj.AUTH_NONE == 0x00))
    print("\t[+] Testing AUTH_GSSAPI: %d" % (s5obj.AUTH_GSSAPI == 0x01))
    print("\t[+] Testing AUTH_USER_PASS: %d" % (s5obj.AUTH_USER_PASS == 0x02))
    print("\t[+] Testing AUTH_NO_ACCEPTABLE: %d" % (s5obj.AUTH_NO_ACCEPTABLE == 0xFF)) 
    return True


# Generated at 2022-06-24 14:22:13.481904
# Unit test for constructor of class sockssocket
def test_sockssocket():
    Socks = sockssocket()
    # type, host, port, username, password, remote_dns
    Socks._proxy = Proxy(1, '127.0.0.1', 1080, None, None, None)

    # Test function to check if b'\x01' is being returned in a string
    def recv_all(cnt):
        a = b'\x01'
        return a

    Socks.recv = recv_all
    Socks.sendall(b'\x05\x01\x00\x03\x0bping.phishlabs.com\x00\x50')

    #  Assert that b'\x01' is being returned in the string
    assert Socks.recv_bytes(1) == (b'\x01',)


# Generated at 2022-06-24 14:22:15.685473
# Unit test for constructor of class sockssocket
def test_sockssocket():
    client_socket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    assert client_socket

# Generated at 2022-06-24 14:22:18.182473
# Unit test for constructor of class ProxyType
def test_ProxyType():
    proxyType = ProxyType()
    assert proxyType.SOCKS4 == 0
    assert proxyType.SOCKS4A == 1
    assert proxyType.SOCKS5 == 2


# Generated at 2022-06-24 14:22:19.518797
# Unit test for constructor of class ProxyType
def test_ProxyType():
    pt = ProxyType()
    assert pt.SOCKS4 == 0
    assert pt.SOCKS4A == 1
    assert pt.SOCKS5 == 2


# Generated at 2022-06-24 14:22:22.074080
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 1
    assert Socks5Command.CMD_BIND == 2
    assert Socks5Command.CMD_UDP_ASSOCIATE == 3


# Generated at 2022-06-24 14:22:24.628051
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    c = Socks5Command()
    assert c.CMD_CONNECT == 0x01
    assert c.CMD_BIND == 0x02
    assert c.CMD_UDP_ASSOCIATE == 0x03

# Generated at 2022-06-24 14:22:26.695478
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(1, 0)
    except InvalidVersionError as e:
        assert e.msg == 'Invalid response version from server. Expected 01 got 00'


# Generated at 2022-06-24 14:22:29.678104
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        a = InvalidVersionError(0x07, 0x06)
        print('ERROR: InvalidVersionError accepted bad version')
    except:
        print('InvalidVersionError rejected bad version')

if __name__ == '__main__':
    test_InvalidVersionError()

# Generated at 2022-06-24 14:22:32.440146
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04

test_Socks5AddressType()


# Generated at 2022-06-24 14:22:33.375034
# Unit test for constructor of class ProxyError
def test_ProxyError():
    ProxyError(code=0, msg=None)



# Generated at 2022-06-24 14:22:38.534461
# Unit test for constructor of class ProxyType
def test_ProxyType():
    p1 = ProxyType()
    assert p1.SOCKS4 == 0
    assert p1.SOCKS4A == 1
    assert p1.SOCKS5 == 2


# Generated at 2022-06-24 14:22:39.257310
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01



# Generated at 2022-06-24 14:22:47.783432
# Unit test for constructor of class ProxyError
def test_ProxyError():
    # Test basic behavior
    msg = ('Testing ProxyError behavior')
    e = ProxyError(msg)

    try:
        raise e
    except ProxyError:
        pass

    assert e.message == msg, 'Invalid ProxyError message'

    # Test code attributes
    err_code = 55
    e = ProxyError(err_code)

    try:
        raise e
    except ProxyError:
        pass

    assert e.message == e.CODES[err_code], 'Invalid ProxyError code message'

    # Test inheritance
    e = Socks5Error()

    try:
        raise e
    except ProxyError:
        pass


# Generated at 2022-06-24 14:22:57.406231
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import socket
    import socks
    socks.set_default_proxy(socks.SOCKS5, "127.0.0.1", 1080)
    s = socks.socksocket()
    s.connect(('www.baidu.com', 80))
    s.send(b'GET / HTTP/1.1\r\nHost: www.baidu.com\r\nConnection: close\r\n\r\n')
    buffer = []
    while True:
        d = s.recv(1024)
        if d:
            buffer.append(d)
        else:
            break
    data = b''.join(buffer)
    s.close()
    print(data)


# Generated at 2022-06-24 14:22:59.329472
# Unit test for constructor of class ProxyType
def test_ProxyType():

    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2

# Generated at 2022-06-24 14:23:01.206930
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error(1) == Socks4Error(code=1, msg='request rejected or failed')


# Generated at 2022-06-24 14:23:05.203695
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error(Socks4Error.ERR_SUCCESS) is not None



# Generated at 2022-06-24 14:23:13.171456
# Unit test for constructor of class ProxyError
def test_ProxyError():
    # Test constructor with code and msg
    p = ProxyError(91, 'test')
    assert p.args == (91, 'test')

    # Test constructor with None as code and msg
    p = ProxyError(None, None)
    assert p.args == (None, None)

    # Test constructor with code and None as msg
    p = ProxyError(91, None)
    assert p.args == (91, 'request rejected or failed')

    # Test constructor with code and None as msg that
    # is not known in CODES
    p = ProxyError(99, None)
    assert p.args == (99, 'unknown error')

    # Test constructor with None as code
    p = ProxyError(None)
    assert p.args == (None, None)

    # Test constructor with code
    p = ProxyError(91)


# Generated at 2022-06-24 14:23:17.305821
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    command = Socks5Command()
    assert command.CMD_CONNECT == 0x01
    assert command.CMD_BIND == 0x02
    assert command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-24 14:23:20.005143
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    error = Socks5Error(0x02)
    assert error.args == (0x02, 'connection not allowed by ruleset')


# Unit tests for constructor of class InvalidVersionError

# Generated at 2022-06-24 14:23:25.206448
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(1, 'test message')
    except ProxyError as e:
        assert e.args == (1, 'test message'), \
            'Error raised: {0}'.format(e)
    else:
        raise AssertionError('ProxyError not raised')


# Generated at 2022-06-24 14:23:27.360233
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    cmd = Socks4Command()
    print(cmd.CMD_CONNECT)
    print(cmd.CMD_BIND)



# Generated at 2022-06-24 14:23:31.005626
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-24 14:23:35.253327
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(type=ProxyType.SOCKS4, host='localhost', port=123, username='user', password='pass', remote_dns=True)
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == 'localhost'
    assert proxy.port == 123
    assert proxy.username == 'user'
    assert proxy.password == 'pass'
    assert proxy.remote_dns == True
    assert proxy != 'str'
    assert proxy != 123
    assert proxy != None
    assert len(proxy) == 6

# Generated at 2022-06-24 14:23:38.539242
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sockssocket.connect(sockssocket, ('127.0.0.1', 1080))


# Generated at 2022-06-24 14:23:40.671325
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError('A')
    except ProxyError as e:
        assert e.args == (None, 'A')

# Generated at 2022-06-24 14:23:47.520778
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    if Socks5Command.CMD_CONNECT != 0x01:
        raise Exception(
            "Expected value of CMD_CONNECT of class Socks5Command to be 1.")
    if Socks5Command.CMD_BIND != 0x02:
        raise Exception(
            "Expected value of CMD_BIND of class Socks5Command to be 2.")
    if Socks5Command.CMD_UDP_ASSOCIATE != 0x03:
        raise Exception(
            "Expected value of CMD_UDP_ASSOCIATE of class Socks5Command to be 3.")

# Generated at 2022-06-24 14:23:53.291170
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    host = "localhost"
    port = "9090"
    username = "user"
    password = "pass"

    proxy = sockssocket()
    proxy.setproxy(1, host, port)
    assert proxy._proxy.type == 1
    assert proxy._proxy.host == host
    assert proxy._proxy.port == port
    assert proxy._proxy.username is None
    assert proxy._proxy.password is None
    assert proxy._proxy.remote_dns is True

    proxy.setproxy(1, host, port, username=username, password=password)
    assert proxy._proxy.username == username
    assert proxy._proxy.password == password

    proxy.setproxy(1, host, port, username=username, password=password, remote_dns=False)
    assert proxy._proxy.remote_dns is False


# Generated at 2022-06-24 14:23:58.340658
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    print('Testing sockssocket.connect_ex')
    sock = sockssocket()
    sock.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8888)
    sock.connect_ex(('127.0.0.1', 8300))
    print('Passed')

if __name__ == '__main__':
    test_sockssocket_connect_ex()

# Generated at 2022-06-24 14:24:09.341892
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import unittest
    import select
    import time
    import socket

    class WithSocksSocket(unittest.TestCase):
        def setUp(self):
            self.w_sock = sockssocket()

        def tearDown(self):
            self.w_sock.close()

        def test_connect(self):
            self.w_sock.setproxy(ProxyType.SOCKS5, "127.0.0.1", 1080)
            self.w_sock.connect(("www.google.com", 443))
            time.sleep(1)
            self.assertEqual(select.select([self.w_sock], [], [], 0)[0], [self.w_sock])

    unittest.main()


# Generated at 2022-06-24 14:24:21.172583
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    test_cred = {
        'username': 'test',
        'password': 'python'
    }
    test_proxy = {
        'host': '127.0.0.1',
        'port': 4444,
        'username': 'test',
        'password': 'python',
        'remote_dns': True
    }
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, **test_cred)
    assert s._proxy == Proxy(ProxyType.SOCKS5, None, None, *(test_cred.values()), True)
    s.setproxy(ProxyType.SOCKS5, **test_proxy)
    assert s._proxy == Proxy(ProxyType.SOCKS5, **test_proxy)


# Generated at 2022-06-24 14:24:24.357447
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:24:28.441187
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    def validate(code, msg):
        assert msg == Socks5Error.CODES[code]
    for code in Socks5Error.CODES:
        validate(code, Socks5Error(code).strerror)


# Generated at 2022-06-24 14:24:30.650468
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_UDP_ASSOCIATE == 3


# Generated at 2022-06-24 14:24:32.017223
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    error = InvalidVersionError(0, 1)



# Generated at 2022-06-24 14:24:33.683470
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sockssocket(socket.AF_INET, socket.SOCK_STREAM)


# Generated at 2022-06-24 14:24:41.080627
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error().errno == 0
    assert Socks4Error(Socks4Error.ERR_SUCCESS).errno == Socks4Error.ERR_SUCCESS
    assert Socks4Error().msg == 'unknown error'
    assert Socks4Error(Socks4Error.ERR_SUCCESS).msg == 'request rejected or failed'

# Generated at 2022-06-24 14:24:45.142571
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    expected = Socks4Command.CMD_CONNECT
    got = Socks5Command.CMD_CONNECT
    assert expected == got, 'Socks5Command.CMD_CONNECT constructor failed'

# Generated at 2022-06-24 14:24:48.959675
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    from pytube import config
    if config.block_unit_test:
        return

    e = InvalidVersionError(expected_version=1, got_version=2)
    assert str(e) == 'Invalid response version from server. Expected 01 got 02'


# Generated at 2022-06-24 14:24:52.048546
# Unit test for constructor of class ProxyError
def test_ProxyError():
    # Test the success case, when only the code is provided
    assert ProxyError(ProxyError.ERR_SUCCESS).msg == 'success'

    # Test the success case, when the code and the message are provided
    assert ProxyError(0, 'success').msg == 'success'

    # Test the error case, when the code is invalid
    assert ProxyError(100).msg == 'unknown error'

    # Test the error case, when the message is missing
    assert ProxyError(0).msg == None

# Generated at 2022-06-24 14:24:55.071875
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 0)
    except InvalidVersionError as e:
        assert e.code == 0
        assert e.errno == 0
        assert str(e) == '0: Invalid response version from server. Expected 00 got 00'

# Generated at 2022-06-24 14:24:57.165537
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    sockssocket().setproxy(ProxyType.SOCKS4, '127.0.0.1', 9050)

if __name__ == '__main__':
    test_sockssocket_setproxy()

# Generated at 2022-06-24 14:25:09.668912
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import sys
    import logging
    import argparse

    logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)

    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument('proxy_host')
    arg_parser.add_argument('proxy_port', type=int)
    arg_parser.add_argument('host')
    arg_parser.add_argument('port', type=int)
    arg_parser.add_argument('-u', '--user', default=None)
    arg_parser.add_argument('-p', '--password', default=None)
    arg_parser.add_argument('-t', '--type', choices=('SOCKS4', 'SOCKS4A', 'SOCKS5'), default='SOCKS4A')
    arg_

# Generated at 2022-06-24 14:25:15.541686
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import sys
    sock = sockssocket()
    sock.setblocking(0)
    sock.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 1080)
    try:
        sock.connect(('127.0.0.1', 80))
    except:
        print('RUN unit test with: python -m test.unit.test_sockssocket_recvall')
        sys.exit(1)

# Generated at 2022-06-24 14:25:20.333444
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04

# Generated at 2022-06-24 14:25:27.409272
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    ss.bind(('127.0.0.1', 0))
    _, port = ss.getsockname()
    ss.listen(1)

    cs = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    cs.connect(('127.0.0.1', port))

    test_str = 'test_str_for_sockssocket_recvall'
    cs.sendall(test_str)
    ss, _ = ss.accept()
    assert ss.recvall(len(test_str)) == test_str
    ss.close()

if __name__ == '__main__':
    test_sockssocket_recvall()

# Generated at 2022-06-24 14:25:31.562948
# Unit test for constructor of class sockssocket
def test_sockssocket():
    try:
        sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
        assert(isinstance(sock, sockssocket))
    except:
        assert(False)


# Generated at 2022-06-24 14:25:40.253732
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error(0x01).strerror == 'general SOCKS server failure'
    assert Socks5Error(0x02).strerror == 'connection not allowed by ruleset'
    assert Socks5Error(0x03).strerror == 'Network unreachable'
    assert Socks5Error(0x04).strerror == 'Host unreachable'
    assert Socks5Error(0x05).strerror == 'Connection refused'
    assert Socks5Error(0x06).strerror == 'TTL expired'
    assert Socks5Error(0x07).strerror == 'Command not supported'
    assert Socks5Error(0x08).strerror == 'Address type not supported'
    assert Socks5Error(0xFE).strerror == 'unknown username or invalid password'

# Generated at 2022-06-24 14:25:41.294232
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error()


# Generated at 2022-06-24 14:25:43.116792
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    e = InvalidVersionError(0xFF, 0x00)
    assert str(e) == 'Invalid response version from server. Expected ff got 00'

# Generated at 2022-06-24 14:25:52.518491
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # Test connection refused
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # If the error code is EACCES or EAFNOSUPPORT, then the target host was
    # unreachable.
    assert s.connect_ex(('127.0.0.1', 0)) in [errno.EACCES, errno.EAFNOSUPPORT]
    s.close()

    # Test connection succeeded
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    assert s.connect_ex(('127.0.0.1', 80)) == 0
    s.close()

# Generated at 2022-06-24 14:26:00.889127
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket()
    # Python 3 workaround
    sock.send = lambda data: sock._sock.send(data)

    def recv(s, size):
        sock.send(compat_struct_pack('!{0}B'.format(size), *[x for x in range(size)]))
        return compat_struct_unpack('!{0}B'.format(size), sock.recvall(size))

    for i in range(20):
        assert recv(sock, i) == tuple(x for x in range(i))

# Generated at 2022-06-24 14:26:03.821360
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:26:06.398114
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    # Create an instance of class Socks5Auth
    auth = Socks5Auth()

    assert auth.AUTH_NONE == 0x00
    assert auth.AUTH_GSSAPI == 0x01
    assert auth.AUTH_USER_PASS == 0x02
    assert auth.AUTH_NO_ACCEPTABLE == 0xFF

# Generated at 2022-06-24 14:26:14.368534
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    addr = "222.33.3.3"
    port = 80
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM, 0)
    s.setproxy(ProxyType.SOCKS5, addr, port)
    print(s)
    # print(s.getpeername())
    # tcpSocket.connect(('www.google.com', 80))
    # print(tcpSocket.getpeername())


# test_sockssocket_setproxy()

# Generated at 2022-06-24 14:26:21.387748
# Unit test for method connect of class sockssocket

# Generated at 2022-06-24 14:26:22.442501
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    pass



# Generated at 2022-06-24 14:26:26.677838
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    socks5_atype = Socks5AddressType()
    assert socks5_atype.ATYP_IPV4 == 0x01
    assert socks5_atype.ATYP_DOMAINNAME == 0x03
    assert socks5_atype.ATYP_IPV6 == 0x04

# Generated at 2022-06-24 14:26:30.305664
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03



# Generated at 2022-06-24 14:26:31.892408
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert(Socks5Command.CMD_CONNECT == 1)


# Generated at 2022-06-24 14:26:43.801857
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    #SOCKS5_DEFAULT_ADDRESS = '127.0.0.1'
    SOCKS5_DEFAULT_ADDRESS = '10.0.0.9'
    SOCKS5_DEFAULT_PORT = 5555
    SOCKS5_DEFAULT_USERNAME = 'user'
    SOCKS5_DEFAULT_PASSWORD = '1234567890'
    SOCKS5_DEFAULT_DESTINATION_ADDRESS = 'yandex.ru'
    SOCKS5_DEFAULT_DESTINATION_PORT = 80

# Generated at 2022-06-24 14:26:49.374958
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError()
    except ProxyError as e:
        assert e.args[0] is None and e.args[1] is None

    try:
        raise ProxyError(1)
    except ProxyError as e:
        assert e.args[0] == 1 and e.args[1] is not None

    try:
        raise ProxyError(2, 'proxy error')
    except ProxyError as e:
        assert e.args[0] == 2 and e.args[1] == 'proxy error'


# Generated at 2022-06-24 14:26:50.910623
# Unit test for constructor of class Proxy
def test_Proxy():
    assert Proxy(1, '127.0.0.1', 8080, 'username', 'password', True)

# Generated at 2022-06-24 14:26:54.132500
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    cmd = Socks5Command()
    assert cmd.CMD_CONNECT == 0x01
    assert cmd.CMD_BIND == 0x02
    assert cmd.CMD_UDP_ASSOCIATE == 0x03

# Generated at 2022-06-24 14:26:57.601017
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03

# Generated at 2022-06-24 14:27:03.548438
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    proxy = Proxy(ProxyType.SOCKS5, '127.0.0.1', 8080, 'sample', 'sample')
    socket = sockssocket()
    socket.setproxy(proxy.type, proxy.host, proxy.port, proxy.remote_dns, proxy.username, proxy.password)
    socket.settimeout(10)
    result = socket.connect_ex(('127.0.0.1', 80))
    print(result)
    import time
    time.sleep(10)
    socket.close()


# Generated at 2022-06-24 14:27:06.303197
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:27:08.404432
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sock = sockssocket()
    assert isinstance(sock, sockssocket)
    assert isinstance(sock, socket.socket)

# Generated at 2022-06-24 14:27:17.489229
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    def get_version():
        # Raise an exception if socket.socket is not overriden with sockssocket
        assert socket.socket is not sockssocket
        return socket.socket.version.split(' ')[0]

    # For the sake of proper doctest
    socket.socket.version = 'sockssocket 0.1'

    # Connect to a website that does not exist
    s = sockssocket()
    assert s.connect_ex(('www.example.com', 80)) == -2

    # If a non-existent host is used with a proxy server, it would be an error
    # to just return the error code
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4, '', 0)
    assert s.connect_ex(('www.example.com', 80)) == -1

    s = sockssocket()


# Generated at 2022-06-24 14:27:19.510711
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    s4c = Socks4Command()
    assert s4c.CMD_CONNECT == 0x01
    assert s4c.CMD_BIND == 0x02


# Generated at 2022-06-24 14:27:23.987049
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    command = Socks5Command()
    assert command.CMD_CONNECT == 0x01
    assert command.CMD_BIND == 0x02
    assert command.CMD_UDP_ASSOCIATE == 0x03

if __name__ == '__main__':
    test_Socks5Command()

# Generated at 2022-06-24 14:27:31.911629
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sockssocket._setup_socks4 = lambda self, address: address
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    ss.setproxy(ProxyType.SOCKS4, '127.0.0.1', 8080)
    address = '1.2.3.4', 80
    ss.connect(address)
    assert ss._setup_socks4.called
    assert ss._setup_socks4.call_args == ((address,), {})
    ss._setup_socks4 = MagicMock(return_value=0)
    ss.connect(address)
    assert ss._setup_socks4.called
    assert ss._setup_socks4.call_args == ((address,), {})

# Generated at 2022-06-24 14:27:43.931015
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS4, 'host', 8000, 'username', 'password', True)
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == 'host'
    assert proxy.port == 8000
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns == True
    proxy = Proxy(ProxyType.SOCKS4, 'host', 8000, 'username', 'password', False)
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == 'host'
    assert proxy.port == 8000
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns == False

# Generated at 2022-06-24 14:27:54.114167
# Unit test for constructor of class ProxyError
def test_ProxyError():
    # Object ProxyError should be initialized using code and msg
    pe1 = ProxyError(code=1, msg='msg')
    assert pe1.code == 1
    assert pe1.msg == 'msg'
    # Error code is not exist, message should be default
    pe2 = ProxyError(code=2)
    assert pe2.code == 2
    assert pe2.msg == 'unknown error'
    # Error code is None, message should be ''
    pe3 = ProxyError()
    assert pe3.code is None
    assert pe3.msg == ''
    # Error message should be msg
    pe4 = ProxyError(msg='msg')
    assert pe4.msg == 'msg'
    assert pe4.code is None


# Generated at 2022-06-24 14:27:56.662806
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02

if __name__ == '__main__':
    test_Socks4Command()

# Generated at 2022-06-24 14:28:03.020361
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    assert s._proxy is None

    # Test without username
    s.setproxy(ProxyType.SOCKS4, 'example.com', 8080)
    assert s._proxy.type == ProxyType.SOCKS4
    assert s._proxy.host == 'example.com'
    assert s._proxy.port == 8080
    assert s._proxy.username is None
    assert s._proxy.password is None
    assert s._proxy.remote_dns

    # Test with username
    s.setproxy(ProxyType.SOCKS5, 'example.com', 8080, username='username', password='password')
    assert s._proxy.type == ProxyType.SOCKS5
    assert s._proxy.host == 'example.com'
    assert s._proxy.port == 8080
    assert s._proxy

# Generated at 2022-06-24 14:28:07.253531
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    # Constructor
    sc = Socks4Command()
    # Assertions
    assert sc.CMD_CONNECT == 0x01
    assert sc.CMD_BIND == 0x02

# Generated at 2022-06-24 14:28:09.574844
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(1)
    except Socks4Error as err:
        assert err.args[0] == 1

# Generated at 2022-06-24 14:28:12.575249
# Unit test for constructor of class ProxyType
def test_ProxyType():
    a = ProxyType()
    try:
        print(a.SOCKS4, a.SOCKS4A, a.SOCKS5)
    except:
        print("Test fail")



# Generated at 2022-06-24 14:28:18.005688
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF



# Generated at 2022-06-24 14:28:21.956366
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    s4cmd = Socks4Command()
    value = s4cmd.CMD_CONNECT
    assert value == 0x01
    value = s4cmd.CMD_BIND
    assert value == 0x02



# Generated at 2022-06-24 14:28:28.010271
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    from .compat import compat_socket
    socks_socket = sockssocket(compat_socket.AF_INET, compat_socket.SOCK_STREAM)
    socks_socket.setproxy(ProxyType.SOCKS4, "localhost", 1080)
    assert socks_socket.connect_ex(("localhost", 1080)) == 0

if __name__ == '__main__':
    test_sockssocket_connect_ex()

# Generated at 2022-06-24 14:28:30.571459
# Unit test for constructor of class sockssocket
def test_sockssocket():
    try:
        assert isinstance(sockssocket(), socket.socket)
    except:
        raise AssertionError('sockssocket is not a subtype of socket.socket')


# Generated at 2022-06-24 14:28:40.594313
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    from io import BytesIO
    from unittest import TestCase

    class BytesLikeSocket(object):
        def __init__(self, data):
            self._data = BytesIO(data)
        def recv(self, cnt):
            return self._data.read(cnt)

    class Test(TestCase):
        def test_recvall(self):
            s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
            s._sock = BytesLikeSocket(b'\x01\x02\x03\x04')
            self.assertEqual(s.recvall(2), b'\x01\x02')
            self.assertEqual(s.recvall(2), b'\x03\x04')

# Generated at 2022-06-24 14:28:46.775821
# Unit test for constructor of class Proxy
def test_Proxy():
    import unittest
    class ProxyTest(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_Proxy(self):
            proxy = Proxy(2, '192.168.1.1', '8080', 'test', 'testtest', True)
            self.assertEqual(proxy.type, 2)
            self.assertEqual(proxy.host, '192.168.1.1')
            self.assertEqual(proxy.port, '8080')
            self.assertEqual(proxy.username, 'test')
            self.assertEqual(proxy.password, 'testtest')
            self.assertEqual(proxy.remote_dns, True)



# Generated at 2022-06-24 14:28:51.896248
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(
        type=1,
        host='host',
        port=1,
        username='username',
        password='password',
        remote_dns=False)
    assert proxy.type == 1
    assert proxy.host == 'host'
    assert proxy.port == 1
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns == False

# Generated at 2022-06-24 14:28:58.087731
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    # Test for code being set correctly
    se = Socks4Error(Socks4Error.ERR_SUCCESS)
    assert se.errno == Socks4Error.ERR_SUCCESS
    # Test for msg being set correctly
    se = Socks4Error(91)
    assert se.strerror == 'request rejected or failed'
    # Test for code being set correctly
    se = Socks4Error(code=91)
    assert se.errno == 91
    # Test for code being set correctly
    se = Socks4Error(msg='request rejected or failed')
    assert se.strerror == 'request rejected or failed'
    # Test for code being set correctly
    se = Socks4Error(code=93, msg='request rejected or failed')
    assert se.errno == 93
    # Test for code being

# Generated at 2022-06-24 14:29:02.179551
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04

# Generated at 2022-06-24 14:29:04.027494
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-24 14:29:07.823413
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-24 14:29:16.013915
# Unit test for constructor of class Proxy
def test_Proxy():
    test_proxy = Proxy(ProxyType.SOCKS4, 'localhost', 1234, None, None, None)

    if test_proxy.type != ProxyType.SOCKS4:
        raise AssertionError('ProxyType.SOCKS4 expected')
    if test_proxy.host != 'localhost':
        raise AssertionError('localhost expected')
    if test_proxy.port != 1234:
        raise AssertionError('1234 expected')
    if test_proxy.username is not None:
        raise AssertionError('None expected')
    if test_proxy.password is not None:
        raise AssertionError('None expected')
    if test_proxy.remote_dns is not None:
        raise AssertionError('None expected')

# Generated at 2022-06-24 14:29:19.288932
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2

# Generated at 2022-06-24 14:29:30.294354
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # Init
    dest_ip = "127.0.0.1"
    dest_port = 8888
    dest_address = (dest_ip, dest_port)
    socks_ip = "127.0.0.1"
    socks_port = 9090
    socks_address = (socks_ip, socks_port)
    # Create a sockssocket
    sockssocket_test = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    # Set socks proxy
    sockssocket_test.setproxy(ProxyType.SOCKS5, socks_ip, socks_port)
    # Check connect_ex result
    connect_ex_result = sockssocket_test.connect_ex(dest_address)
    # Check SOCKS5_USER_AUTH_VERSION for user pass auth
    assert sockssocket_test

# Generated at 2022-06-24 14:29:33.549011
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    msg = 'unknown error'
    e = Socks4Error()
    assert e.args == (None, msg)
    

# Generated at 2022-06-24 14:29:45.252710
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    x = Socks5Error(0x01)
    assert x.CODES.get(0x01) == 'general SOCKS server failure'
    assert x.CODES.get(0x02) == 'connection not allowed by ruleset'
    assert x.CODES.get(0x03) == 'Network unreachable'
    assert x.CODES.get(0x04) == 'Host unreachable'
    assert x.CODES.get(0x05) == 'Connection refused'
    assert x.CODES.get(0x06) == 'TTL expired'
    assert x.CODES.get(0x07) == 'Command not supported'
    assert x.CODES.get(0x08) == 'Address type not supported'

# Generated at 2022-06-24 14:29:50.800323
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS4, '127.0.0.1', 8000, 'user', 'pass', False)
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 8000
    assert proxy.username == 'user'
    assert proxy.password == 'pass'
    assert proxy.remote_dns

# Generated at 2022-06-24 14:29:58.330779
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    import pytest

    def test_type_invalid():
        ss = sockssocket()
        with pytest.raises(AssertionError):
            ss.setproxy('SOCKS4', 'dummy', 1234)

    def test_type_valid():
        ss = sockssocket()
        ss.setproxy(ProxyType.SOCKS4, 'dummy', 1234)

    def test_validate_socks_proxy_type():
        assert validate_socks_proxy_type(ProxyType.SOCKS4) is True
        assert validate_socks_proxy_type(ProxyType.SOCKS4A) is True
        assert validate_socks_proxy_type(ProxyType.SOCKS5) is True
        assert validate_socks_proxy_type(None) is True

# Generated at 2022-06-24 14:30:02.725495
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error(91).strerror == 'request rejected or failed'
    assert Socks4Error(92).strerror == 'request rejected because SOCKS server cannot connect to identd on the client'
    assert Socks4Error(93).strerror == 'request rejected because the client program and identd report different user-ids'
    assert Socks4Error(90).strerror == 'Unknown error 0'
    assert Socks4Error(90, 'test').strerror == 'test'



# Generated at 2022-06-24 14:30:05.576272
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    Socks5Error01 = Socks5Error(0x01, 'general SOCKS server failure')
    assert Socks5Error01.code == 0x01

# Generated at 2022-06-24 14:30:09.625723
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(1, 'error msg')
    except ProxyError as e:
        assert e.args == (1, 'error msg')


# Generated at 2022-06-24 14:30:14.289938
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0
    assert Socks5Auth.AUTH_GSSAPI == 1
    assert Socks5Auth.AUTH_USER_PASS == 2
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 255



# Generated at 2022-06-24 14:30:20.603572
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # test method
    socks.setdefaultproxy(socks.PROXY_TYPE_SOCKS5, '127.0.0.1', 1081)
    socks.wrapmodule(socket)
    s = socket.socket()
    try:
        result = s.connect_ex(('www.baidu.com', 80))
    except Exception as e:
        result = e
    s.close()
    return result

# Generated at 2022-06-24 14:30:22.717745
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    ex = InvalidVersionError(0, 1)
    assert str(ex) == 'Invalid response version from server. Expected 00 got 01'



# Generated at 2022-06-24 14:30:31.421737
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # This unit test is required to debug the implementation of class sockssocket
    # The unit test verifies that the implementation works for IPv4 and IPv6 addresses
    # The test uses the following Socks5 proxy: port 1080, username: testuser, password: testpassword

    # Test case for IPv4
    with sockssocket() as s:
        s.setproxy(
            proxytype=ProxyType.SOCKS5,
            addr="127.0.0.1",
            port=1080,
            rdns=True,
            username="testuser",
            password="testpassword")
        s.connect_ex(("127.0.0.1", 80))
        print(s.getpeername())

    # Test case for IPv6

# Generated at 2022-06-24 14:30:34.450904
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    socks5Error = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    assert socks5Error.__str__() == '1 (general SOCKS server failure)'

# Generated at 2022-06-24 14:30:44.390629
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    import time

    socks_port = None
    with open('/etc/proxychains.conf', 'r') as f:
        for line in f:
            socks_port = line.split()[-1]
            break
    socks_port = int(socks_port)
    print('Socks port {0}'.format(socks_port))
    host = 'youtube.com'
    port = 80

    conn = sockssocket()
    conn.setproxy(ProxyType.SOCKS4, '127.0.0.1', socks_port)
    start = time.time()
    conn.connect((host, port))
    print('SOCKS4 open connection to {0}:{1} in {2} seconds'.format(host, port, time.time() - start))
    conn.close()

    conn = sockssocket

# Generated at 2022-06-24 14:30:49.110934
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    Socks5Auth()
    pass

# Generated at 2022-06-24 14:31:00.951546
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    def func_test(neq, eq):
        assert neq != eq
    func_test(Socks5Auth.AUTH_NONE, Socks5Auth.AUTH_GSSAPI)
    func_test(Socks5Auth.AUTH_NONE, Socks5Auth.AUTH_USER_PASS)
    func_test(Socks5Auth.AUTH_NONE, Socks5Auth.AUTH_NO_ACCEPTABLE)
    func_test(Socks5Auth.AUTH_GSSAPI, Socks5Auth.AUTH_USER_PASS)
    func_test(Socks5Auth.AUTH_GSSAPI, Socks5Auth.AUTH_NO_ACCEPTABLE)

# Generated at 2022-06-24 14:31:04.070041
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    # Verify that all constants are defined
    assert hasattr(Socks4Command, 'CMD_CONNECT')
    assert hasattr(Socks4Command, 'CMD_BIND')


# Generated at 2022-06-24 14:31:10.442637
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    try:
        # Connect to cnn.com
        socks = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
        socks.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, username='test', password='test')
        socks.connect(('www.cnn.com', 80))
        assert socks.connect_ex(('www.cnn.com', 80)) == 0
        socks.close()
    except:
        import traceback
        traceback.print_exc()

# Generated at 2022-06-24 14:31:13.506750
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    ss = sockssocket()
    assert ss.setproxy(ProxyType.SOCKS4, "127.0.0.1", 1080) is None

# Generated at 2022-06-24 14:31:21.160041
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import threading
    import time
    import unittest

    class TestThread(threading.Thread):

        def run(self):
            s = sockssocket()
            s.connect(('127.0.0.1', 8888))
            s.sendall(b'GET / HTTP/1.1\r\n\r\n')
            assert s.recvall(15) == b'HTTP/1.1 200 OK'

    class Tester(unittest.TestCase):

        def test_sockssocket_recvall(self):
            serv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            serv.bind(('127.0.0.1', 8888))
            serv.listen(5)

            thread = TestThread()
            thread.start()

            conn,