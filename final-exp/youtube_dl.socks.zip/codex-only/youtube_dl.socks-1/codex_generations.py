

# Generated at 2022-06-24 14:21:16.608132
# Unit test for constructor of class ProxyError
def test_ProxyError():
    with pytest.raises(ProxyError) as excinfo:
        raise ProxyError(None, "testing ")
    assert not excinfo.value.__str__()


# Generated at 2022-06-24 14:21:26.148781
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    from .compat import (
        compat_socket_getaddrinfo,
        compat_urllib_request_urlopen,
        )

    socks_port = 3005
    socks5_proxy_address = ('127.0.0.1', socks_port)

    with sockssocket() as s:
        s.settimeout(3)
        s.setproxy(ProxyType.SOCKS5, socks5_proxy_address[0], socks5_proxy_address[1])
        print('connecting to %s:%d...' % socks5_proxy_address)
        s.connect_ex(socks5_proxy_address)

    dest_host = 'www.google.com'
    dest_port = 80
    with sockssocket() as s:
        s.settimeout(3)

# Generated at 2022-06-24 14:21:26.978316
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS5 == 2

# Generated at 2022-06-24 14:21:27.894373
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    Socks4Command()


# Generated at 2022-06-24 14:21:31.702404
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    # Create object of class Socks5AddressType
    address_type = Socks5AddressType()

    assert(address_type.ATYP_IPV4 == 0x01)
    assert(address_type.ATYP_DOMAINNAME == 0x03)
    assert(address_type.ATYP_IPV6 == 0x04)


# Generated at 2022-06-24 14:21:37.492130
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080, rdns=True, username='foo', password='bar')
    print (s.connect_ex(('httpbin.org', 80)))

if __name__ == '__main__':
    test_sockssocket_connect_ex()

# Generated at 2022-06-24 14:21:39.552282
# Unit test for constructor of class ProxyError
def test_ProxyError():
    exc = ProxyError(Code=0, msg='test_ProxyError')
    assert str(exc) == 'test_ProxyError'



# Generated at 2022-06-24 14:21:41.387618
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    socks4_command = Socks4Command()
    assert socks4_command.CMD_CONNECT == 0x01
    assert socks4_command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:21:44.502989
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setblocking(0)
    result = sock.connect_ex(('www.google.com', 80))
    assert result == 0, result

# Generated at 2022-06-24 14:21:51.100019
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # We use https://httpbin.org to test sockssocket.
    # See https://httpbin.org/ip to know the https://httpbin.org's public IP address.
    # See also https://github.com/requests/requests/issues/2061
    socks_host = 'localhost'
    socks_port = 1086
    socks_username = ''
    socks_password = ''
    socks_remote_dns = True
    socks_proxy_type = ProxyType.SOCKS5
    public_ip = '104.24.110.237'
    httpbin_url = 'https://httpbin.org/ip'
    assert public_ip == '104.24.110.237'

# Generated at 2022-06-24 14:21:58.295335
# Unit test for constructor of class Proxy
def test_Proxy():
    expected_type = 'socks4'
    expected_host = '1.1.1.1'
    expected_port = 8080
    expected_username = 'username'
    expected_password = 'password'
    expected_remote_dns = True

    proxy = Proxy(expected_type, expected_host, expected_port, expected_username, expected_password, expected_remote_dns)
    assert proxy.type == expected_type
    assert proxy.host == expected_host
    assert proxy.port == expected_port
    assert proxy.username == expected_username
    assert proxy.password == expected_password
    assert proxy.remote_dns == expected_remote_dns


# Generated at 2022-06-24 14:22:08.090394
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError()
    except ProxyError as e:
        assert e.code == None
        assert e.args[0] == None
        assert e.args[1] == None

    try:
        raise ProxyError(0)
    except ProxyError as e:
        assert e.code == 0
        assert e.args[0] == 0
        assert e.args[1] == 'unknown error'

    try:
        raise ProxyError(0x01)
    except ProxyError as e:
        assert e.code == 0x01
        assert e.args[0] == 0x01
        assert e.args[1] == 'general SOCKS server failure'


if __name__ == '__main__':
    test_ProxyError()

# Generated at 2022-06-24 14:22:16.531197
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    socks4Command = Socks4Command()
    socks4CmdConnect = socks4Command.CMD_CONNECT
    socks4CmdBind = socks4Command.CMD_BIND
    socks5Command = Socks5Command()
    socks5CmdConnect = socks5Command.CMD_CONNECT
    socks5CmdBind = socks5Command.CMD_BIND
    socks5CmdUdpAssociate = socks5Command.CMD_UDP_ASSOCIATE
    assert socks4CmdConnect == socks5CmdConnect
    assert socks4CmdBind == socks5CmdBind
    assert socks5CmdUdpAssociate == 3


# Generated at 2022-06-24 14:22:17.988779
# Unit test for constructor of class sockssocket
def test_sockssocket():
    try:
        s = sockssocket()
        assert True
    except AssertionError:
        assert False

# Generated at 2022-06-24 14:22:20.597925
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(91)
    except ProxyError as proxy_err:
        assert proxy_err.args[0] == 91
        assert proxy_err.args[1] == 'request rejected or failed'


# Generated at 2022-06-24 14:22:24.182022
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    auth = Socks5Auth()
    assert auth.AUTH_NONE == 0x00
    assert auth.AUTH_GSSAPI == 0x01
    assert auth.AUTH_USER_PASS == 0x02
    assert auth.AUTH_NO_ACCEPTABLE == 0xFF


if __name__ == '__main__':
    test_Socks5Auth()

# Generated at 2022-06-24 14:22:27.910911
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.connect(('127.0.0.1', 8888))
    s.sendall('Testing')
    msg = s.recvall(8)
    s.close()
    assert msg == 'Testing', msg

if __name__ == '__main__':
    test_sockssocket_recvall()

# Generated at 2022-06-24 14:22:31.116764
# Unit test for constructor of class Proxy
def test_Proxy():
    p = Proxy(ProxyType.SOCKS4, "127.0.0.1", 1080, "proxyuser", "123456", True)
    assert p.type == ProxyType.SOCKS4
    assert p.host == "127.0.0.1"
    assert p.port == 1080
    assert p.username == "proxyuser"
    assert p.password == "123456"
    assert p.remote_dns == True

# Generated at 2022-06-24 14:22:32.938174
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:22:40.668647
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS4, '127.0.0.1', 1080, 'nobody', None, False)
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 1080
    assert proxy.username == 'nobody'
    assert proxy.password is None
    assert not proxy.remote_dns


# Generated at 2022-06-24 14:22:42.813162
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        proxy_err = ProxyError()
    except Exception as err:
        raise AssertionError('Failed to instantiate class ProxyError: {0}'.format(err))


# Generated at 2022-06-24 14:22:52.900990
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import sys
    import pickle
    import binascii

    from .compat import (
        compat_chr,
    )

    sys.stdout.write("\nStart testing recvall method of class sockssocket\n")
    sys.stdout.flush()

    # Create a socket object
    ss = sockssocket()

    # connect to the socket IP and port
    ss.connect(('localhost', 8000))

    send_msg = b'12345678901'

    length = len(send_msg)
    if sys.version_info[0] < 3:
        l = length
    else:
        l = length.to_bytes(2, 'big')
    ss.send(l)
    ss.send(send_msg)

    recv_msg = ss.recvall(length)

# Generated at 2022-06-24 14:22:57.358018
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    # default proxytype
    ss.setproxy(None, 'github.com', 8080)
    assert ss._proxy.type == ProxyType.SOCKS5
    # none proxy
    ss.setproxy(None, None, None)
    assert ss._proxy == None
    # none proxy can be assigned
    ss.setproxy(None, None, None)
    assert ss._proxy == None
    # valid proxytype
    ss.setproxy(ProxyType.SOCKS5, 'github.com', 8080)
    assert ss._proxy.type == ProxyType.SOCKS5
    # valid proxytype
    ss.setproxy(ProxyType.SOCKS4, 'github.com', 8080)
    assert ss._proxy.type == Proxy

# Generated at 2022-06-24 14:23:02.914667
# Unit test for constructor of class Proxy
def test_Proxy():
    ProxyType = collections.namedtuple('ProxyType', ['type', 'host', 'port', 'username', 'password', 'remote_dns'])
    proxyType = ProxyType(1, '0.0.0.0', 1080, 'user', 'password', False)
    assert proxyType.type == 1
    assert proxyType.host == '0.0.0.0'
    assert proxyType.port == 1080
    assert proxyType.username == 'user'
    assert proxyType.password == 'password'
    assert proxyType.remote_dns == False


# Generated at 2022-06-24 14:23:13.732575
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    try:
        s = sockssocket()
        s.connect(("localhost", 12345))
    except socket.error:
        return True
    else:
        return False

if __name__ == '__main__':
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080)
    s.connect(("www.xvideos.com", 80))
    print("Connected")
    s.sendall(b"GET / HTTP/1.1\r\nHost: www.xvideos.com\r\nConnection: Close\r\n\r\n")
    print("Sent Request")
    resp = s.recvall(4096)
    print("Got Response: {0}".format(resp))
    print("Done")

# Generated at 2022-06-24 14:23:18.343095
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0x05, 0x90)
    except InvalidVersionError as actual:
        assert vars(actual) == {
            'expected_version': 0x05,
            'got_version': 0x90
        }


# Generated at 2022-06-24 14:23:20.206461
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        a = InvalidVersionError(2, 3)
    except:
        assert(False)

# Generated at 2022-06-24 14:23:25.389276
# Unit test for constructor of class Proxy
def test_Proxy():
    p = Proxy(None, 'localhost', '443', None, None, True)
    assert p.type == None
    assert p.host == 'localhost'
    assert p.port == '443'
    assert p.username == None
    assert p.password == None
    assert p.remote_dns == True


# Generated at 2022-06-24 14:23:29.264110
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(expected_version=1, got_version=2)
    except InvalidVersionError as e:
        assert e.args == (0, 'Invalid response version from server. Expected 01 got 02')
    else:
        assert False, 'InvalidVersionError was not raised'


# Generated at 2022-06-24 14:23:33.073596
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error().__str__() == 'Socks5Error: 0: unknown error'
    assert Socks5Error(1).__str__() == 'Socks5Error: 1: general SOCKS server failure'
    assert Socks5Error(2).__str__() == 'Socks5Error: 2: connection not allowed by ruleset'


# Generated at 2022-06-24 14:23:35.605490
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    sockssocket.setproxy(ProxyType.SOCKS5, "127.0.0.1", 1080, False, "user", "pass")

# Generated at 2022-06-24 14:23:40.671566
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03

# Generated at 2022-06-24 14:23:42.397894
# Unit test for constructor of class sockssocket
def test_sockssocket():
    try:
        # Using constructor should be work
        s = sockssocket()
        assert type(s) == sockssocket
    except AssertionError as e:
        raise Exception(e)


# Generated at 2022-06-24 14:23:44.664440
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 1)
    except InvalidVersionError as e:
        code = e.args[0]
        msg = e.args[1]
        assert code == 0
        assert msg == 'Invalid response version from server. Expected 00 got 01'



# Generated at 2022-06-24 14:23:45.228264
# Unit test for method connect of class sockssocket

# Generated at 2022-06-24 14:23:45.703339
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()
    assert s._proxy == None

# Generated at 2022-06-24 14:23:46.907257
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket()
    assert isinstance(ss, sockssocket)


# Generated at 2022-06-24 14:23:48.623460
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    assert isinstance(s, sockssocket)


# Generated at 2022-06-24 14:23:51.880501
# Unit test for constructor of class sockssocket
def test_sockssocket():
    result = sockssocket()
    assert result is not None

if __name__ == '__main__':
    result = sockssocket()
    assert result is not None

# Generated at 2022-06-24 14:23:56.355500
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0
    assert Socks5Auth.AUTH_GSSAPI == 1
    assert Socks5Auth.AUTH_USER_PASS == 2
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 255

# Generated at 2022-06-24 14:23:59.274664
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0x01, 0x02)
    except InvalidVersionError as err:
        assert err.args[1] == 'Invalid response version from server. Expected 01 got 02'


# Generated at 2022-06-24 14:24:01.856470
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04

# Generated at 2022-06-24 14:24:04.414440
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(1, 'test proxy error')
    except Exception as exc:
        assert(isinstance(exc, ProxyError))

# Generated at 2022-06-24 14:24:06.338777
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(
        ProxyType.SOCKS4, '127.0.0.1', 1080, username='',
        password='')


# Generated at 2022-06-24 14:24:12.564842
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket()
    sock.connect(('github.com', 80))
    request = b'GET / HTTP/1.0\n\n'
    sock.sendall(request)
    headers = b''
    while not headers.endswith(b'\n\n'):
        headers += sock.recvall(1)
    print(headers.decode('utf-8').splitlines())
    sock.close()

# Generated at 2022-06-24 14:24:33.725759
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    # Test that Socks4Error raises error with message 'unknown error'
    # when code is not in Socks4Error.CODES
    try:
        raise Socks4Error(2)
    except Socks4Error as err:
        assert err.message == 'unknown error'

    # Test that Socks4Error raises error with message
    # 'request rejected because the client program and identd report different user-ids'
    # when code is in Socks4Error.CODES
    try:
        raise Socks4Error(Socks4Error.ERR_SUCCESS)
    except Socks4Error as err:
        assert err.message == 'request rejected because the client program and identd report different user-ids'

# Generated at 2022-06-24 14:24:39.091413
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sockssocket._setup_socks5 = lambda self, address: None
    sock = sockssocket()
    sock.connect(('www.youtube.com', 443))
    assert isinstance(sock, sockssocket)


# Generated at 2022-06-24 14:24:41.537698
# Unit test for constructor of class sockssocket
def test_sockssocket():
    mysocks = sockssocket(socket.AF_INET, socket.SOCK_STREAM)

# Generated at 2022-06-24 14:24:48.768121
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error('0x01').msg == 'general SOCKS server failure'
    assert Socks5Error().msg == 'unknown error'
    assert Socks5Error(Socks5Auth.AUTH_NO_ACCEPTABLE).msg == 'all offered authentication methods were rejected'
    assert Socks5Error(Socks5Error.ERR_GENERAL_FAILURE).msg == 'general SOCKS server failure'
    assert Socks5Error(10).msg == 'unknown error'


# Generated at 2022-06-24 14:24:53.524811
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    # TODO: Mock socket.socket so we don't need to actually connect to anything
    # for these tests.
    proxies = [
        Proxy(ProxyType.SOCKS4, 'proxy.yandex.ru', 1080),
        Proxy(ProxyType.SOCKS5, 'proxy.yandex.ru', 1080),
        Proxy(ProxyType.SOCKS4A, 'proxy.yandex.ru', 1080),
        Proxy(ProxyType.SOCKS5, 'proxy.yandex.ru', 1080, username='user', password='pass'),
    ]
    for proxy in proxies:
        s = sockssocket(socket.AF_INET)

# Generated at 2022-06-24 14:24:59.956526
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    import unittest
    
    class TestInvalidVersionError(unittest.TestCase):
        def test_constructor(self):
            self.assertRaises(TypeError, InvalidVersionError, 1, 1)
            self.assertRaises(TypeError, InvalidVersionError, 1, 1, 2)
            self.assertRaises(TypeError, InvalidVersionError, 1, 1, 3, 4, 5)
            expected_version = 0xFF
            got_version = 0x00
            message = (
                'Invalid response version from server. Expected {0:02x} got '
                '{1:02x}'.format(expected_version, got_version)
            )
            expected_exception = InvalidVersionError(0, message)
            thrown_exception = InvalidVersionError(expected_version, got_version)
            self

# Generated at 2022-06-24 14:25:10.836852
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    e = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    assert(e.errno == Socks5Error.ERR_GENERAL_FAILURE)
    assert(str(e) == "General SOCKS server failure (1)")
    e = Socks5Error(Socks5Error.ERR_SUCCESS)
    assert(e.errno == Socks5Error.ERR_SUCCESS)
    assert(str(e) == "Success (0)")
    e = Socks5Error(100)
    assert(e.errno == 100)
    assert(str(e) == "unknown error")

# Generated at 2022-06-24 14:25:14.896567
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    error = Socks4Error(code=91, msg='')
    assert error.errno == 91
    assert error.strerror == 'request rejected or failed'
    assert str(error) == 'request rejected or failed'
    assert error.args == (91, 'request rejected or failed')


# Generated at 2022-06-24 14:25:19.556711
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    st = Socks4Error(2)
    assert st.strerror == 'request rejected because SOCKS server cannot connect to identd on the client'


# Generated at 2022-06-24 14:25:22.975931
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    # test for code
    e1 = Socks4Error()
    assert e1.code is None
    e2 = Socks4Error(91)
    assert e2.code == 91
    assert e2.msg == 'request rejected or failed'


# Generated at 2022-06-24 14:25:25.429439
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    err = Socks4Error(91)
    assert 'request rejected or failed' == str(err)



# Generated at 2022-06-24 14:25:37.375930
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    host = '127.0.0.1'
    port = 8888
    proxy_host = '127.0.0.1'
    proxy_port = 1080
    proxy_type = ProxyType.SOCKS5
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.setproxy(proxy_type, proxy_host, proxy_port)
    s.connect((host, port))
    print('Connected to {0}:{1} via {2} proxy at {3}:{4}'.format(host, port, proxy_type, proxy_host, proxy_port))
    s.sendall('GET / HTTP/1.1\r\nAccept: */*\r\n\r\n'.encode('utf-8'))
    print('Response:')

# Generated at 2022-06-24 14:25:42.912694
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert isinstance(Socks5Auth.AUTH_NONE, int)
    assert isinstance(Socks5Auth.AUTH_GSSAPI, int)
    assert isinstance(Socks5Auth.AUTH_USER_PASS, int)
    assert isinstance(Socks5Auth.AUTH_NO_ACCEPTABLE, int)


# Generated at 2022-06-24 14:25:49.845290
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    command = Socks5Command()
    assert (command.CMD_CONNECT == Socks5Command.CMD_CONNECT and
            command.CMD_BIND == Socks5Command.CMD_BIND and
            command.CMD_UDP_ASSOCIATE == Socks5Command.CMD_UDP_ASSOCIATE)

if __name__ == '__main__':
    test_Socks5Command()
    print ('All unit tests passed.')

# Generated at 2022-06-24 14:25:52.429262
# Unit test for constructor of class ProxyType
def test_ProxyType():
    p = ProxyType()
    assert p.SOCKS4 == 0
    assert p.SOCKS4A == 1
    assert p.SOCKS5 == 2


# Generated at 2022-06-24 14:25:57.777185
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    for test_input, expected in [
        (InvalidVersionError(0, 1),
            'Invalid response version from server. Expected 00 got 01'),
        (InvalidVersionError(1, 2),
            'Invalid response version from server. Expected 01 got 02'),
    ]:
        actual = test_input.args[1]
        assert actual == expected, 'Expected %r but got %r' % (expected, actual)

if __name__ == '__main__':
    test_InvalidVersionError()

# Generated at 2022-06-24 14:26:03.382894
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(123)
    except ProxyError as ex:
        assert ex.args[0] == 0
        assert ex.args[1] == 'unknown error'
        assert str(ex) == '(0, unknown error)'


# Generated at 2022-06-24 14:26:05.663311
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2

# Generated at 2022-06-24 14:26:08.196700
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    socks5err = Socks5Error()
    assert socks5err.code == None
    assert socks5err.msg == None
    socks5err = Socks5Error(0x02, 'connection not allowed by ruleset')
    assert socks5err.code == 0x02
    assert socks5err.msg == 'connection not allowed by ruleset'

# Generated at 2022-06-24 14:26:18.332093
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # Create a SOCKS4 proxy server
    proxy = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    proxy.bind(('', 0))
    proxy.listen(5)
    proxy_addr, proxy_port = proxy.getsockname()

    # Create a SOCKS5 proxy server
    proxy_s5 = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    proxy_s5.bind(('', 0))
    proxy_s5.listen(5)
    proxy_s5_addr, proxy_s5_port = proxy_s5.getsockname()

    # Create a SOCKS4a proxy server
    proxy_dns = sockssocket(socket.AF_INET, socket.SOCK_STREAM)

# Generated at 2022-06-24 14:26:21.086215
# Unit test for constructor of class Proxy
def test_Proxy():
    assert Proxy(ProxyType.SOCKS4, '127.0.0.1', 80, None, None, None)
    return


# Generated at 2022-06-24 14:26:25.765537
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(compat_ord('a'), compat_ord('b'))
    except InvalidVersionError as e:
        assert e.args[0] == 0
        assert e.args[1] == 'Invalid response version from server. Expected 61 got 62'


# Generated at 2022-06-24 14:26:33.056116
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    try:
        socket.socket.connect_ex(("www.google.com",80))
    except Exception as e:
        print("Exception: " + str(e))
        return
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4, "172.16.5.5",1080)
    try:
        result = socket.socket.connect_ex(("www.google.com",80))
    except Exception as e:
        print("Exception: " + str(e))
        return
    print("Result: " + str(result))


# Generated at 2022-06-24 14:26:42.530871
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    class FakeSocket(object):
        def __init__(self):
            self.address = None
            self.port = None
        def connect(self, address):
            self.address = address[0]
            self.port = address[1]
            return 0

    fake_socket = FakeSocket()
    proxy = Proxy(ProxyType.SOCKS4, '192.168.1.1', 80)
    sockssocket._make_proxy(fake_socket, ('test.com', 80), proxy)
    assert fake_socket.address == '192.168.1.1'
    assert fake_socket.port == 80

# Generated at 2022-06-24 14:26:50.845350
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    # Check that success is not an error
    proxyError = Socks5Error()
    if proxyError.args[0] != Socks5Error.ERR_SUCCESS:
        return False

    # Check that the constructor gets the error code from the ''msg'' parameter
    proxyError = Socks5Error(msg='general SOCKS server failure')
    if proxyError.args[0] != Socks5Error.ERR_GENERAL_FAILURE:
        return False

    # Check that the constructor gets the error code from the ''code'' parameter
    proxyError = Socks5Error(code=Socks5Error.ERR_GENERAL_FAILURE)
    if proxyError.args[0] != Socks5Error.ERR_GENERAL_FAILURE:
        return False

    return True


# Generated at 2022-06-24 14:26:54.768729
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-24 14:27:03.853142
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    from .compat import is_py2
    from .socks import PROXY_TYPES, socks

    sock = sockssocket()

    proxy_addr = '127.0.0.1'
    proxy_port = 1234
    for proxy_type in PROXY_TYPES.keys():
        sock.setproxy(proxy_type, proxy_addr, proxy_port)
        assert sock._proxy.host == proxy_addr
        assert sock._proxy.port == proxy_port
        assert sock._proxy.type == PROXY_TYPES[proxy_type]

    if is_py2:
        sock.setproxy(socks.PROXY_TYPE_SOCKS5, proxy_addr, proxy_port, True)

# Generated at 2022-06-24 14:27:08.179453
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 1
    assert Socks5AddressType.ATYP_DOMAINNAME == 3
    assert Socks5AddressType.ATYP_IPV6 == 4


if __name__ == '__main__':
    test_Socks5AddressType()

# Generated at 2022-06-24 14:27:10.102307
# Unit test for constructor of class sockssocket
def test_sockssocket():
    try:
        sockssocket().setproxy(1, '1.1.1.1', 1, False)
    except Exception:
        raise Exception('Failed to setproxy and create instance of sockssocket')
    else:
        pass

if __name__ == '__main__':
    test_sockssocket()

# Generated at 2022-06-24 14:27:12.322508
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01 and Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:27:15.743573
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS5, 'host', 5, 'username', 'password', True)
    assert proxy.type == ProxyType.SOCKS5
    assert proxy.host == 'host'
    assert proxy.port == 5
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns == True

# Generated at 2022-06-24 14:27:22.224409
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest

    def recv_mock(sockself, bufsize, p_flags=None):
        assert isinstance(sockself, sockssocket)
        assert isinstance(bufsize, int) and bufsize >= 1
        assert p_flags is None
        if len(test_data) == 0:
            return b''
        elif len(test_data) <= bufsize:
            data = test_data
            test_data = b''
            return data
        else:
            data = test_data[0:bufsize]
            test_data = test_data[bufsize:]
            return data

    class sockssocketTest(unittest.TestCase):
        def test_recvall(self):
            global test_data

# Generated at 2022-06-24 14:27:28.889420
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import socks
    import urllib.request
    socks.setdefaultproxy(socks.PROXY_TYPE_SOCKS5, '127.0.0.1', 8080)
    socket.socket = socks.socksocket

    url = 'http://httpbin.org/ip'
    opener = urllib.request.build_opener()
    print(opener.open(url).read())

if __name__ == '__main__':
    test_sockssocket_connect()

# Generated at 2022-06-24 14:27:34.871463
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error().args == (Socks4Error.ERR_SUCCESS, 'request succeeded')
    assert Socks4Error(91).args == (91, 'request rejected or failed')
    assert Socks4Error(0x99, 'test').args == (0x99, 'test')


# Generated at 2022-06-24 14:27:46.451596
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import itertools
    def check(proxy_address, proxy_port, address, port):
        ss = sockssocket()
        ss.setproxy(
            proxytype = ProxyType.SOCKS5,
            addr = proxy_address,
            port = proxy_port,
            rdns = True,
            username = 'user',
            password = 'password'
        )
        expected_response = 0
        assert ss.connect_ex((address, port)) == expected_response
        ss.close()


# Generated at 2022-06-24 14:27:58.322030
# Unit test for constructor of class ProxyType
def test_ProxyType():
    # Check that ProxyType constructor raises TypeError if called with non-string value as
    # first argument
    try:
        ProxyType(None)
        assert False
    except TypeError:
        pass
    # Check that ProxyType constructor raises TypeError if called with non-string value as
    # second argument
    try:
        ProxyType('foo', None)
        assert False
    except TypeError:
        pass
    # Check that ProxyType constructor raises TypeError if called with non-string value as
    # third argument
    try:
        ProxyType('foo', 'bar', None)
        assert False
    except TypeError:
        pass
    # Check that ProxyType constructor raises ValueError if called with empty string as
    # first argument
    try:
        ProxyType('')
        assert False
    except ValueError:
        pass
    #

# Generated at 2022-06-24 14:28:05.426704
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF



# Generated at 2022-06-24 14:28:06.123998
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    Socks5Command()

# Generated at 2022-06-24 14:28:11.332450
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert(Socks5Auth.AUTH_NONE == 0x00)
    assert(Socks5Auth.AUTH_GSSAPI == 0x01)
    assert(Socks5Auth.AUTH_USER_PASS == 0x02)
    assert(Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF)


# Generated at 2022-06-24 14:28:16.696521
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    expected_version = 0x01
    got_version = 0xFF
    error = InvalidVersionError(expected_version, got_version)

    assert error.args == (0, 'Invalid response version from server. Expected 01 got ff')
    assert str(error) == error.args[1]

# Generated at 2022-06-24 14:28:18.945741
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:28:23.358310
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03



# Generated at 2022-06-24 14:28:25.911782
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error(Socks5Error.ERR_GENERAL_FAILURE).args[1] == 'general SOCKS server failure'

# Generated at 2022-06-24 14:28:29.335415
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-24 14:28:33.223079
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    Socks4Command = Socks4Command()
    Socks4Command.CMD_CONNECT == 0x01
    Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:28:36.765354
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    error = Socks4Error(91)
    assert hasattr(error, '__str__')
    assert hasattr(error, '__int__')
    assert int(error) == 91
    assert error.__str__() == 'request rejected or failed'


# Generated at 2022-06-24 14:28:44.458648
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy('type', 'host', 'port', 'username', 'password', 'remote_dns')
    assert proxy.type == 'type'
    assert proxy.host == 'host'
    assert proxy.port == 'port'
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns == 'remote_dns'


# Generated at 2022-06-24 14:28:48.349773
# Unit test for constructor of class ProxyError
def test_ProxyError():
    e = ProxyError(0)
    assert e.__str__() == '0: unknown error'

    e = ProxyError(1, 'string')
    assert e.__str__() == '1: string'


# Generated at 2022-06-24 14:28:53.007068
# Unit test for constructor of class sockssocket
def test_sockssocket():
    import socket
    try:
        s = sockssocket()
        s.setproxy(ProxyType.SOCKS5, '127.1', 9150)
        s.connect(('www.baidu.com', 80))
        print(s.recv(1024))
    except socket.timeout:
        print('error')

# Generated at 2022-06-24 14:28:58.795661
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
	assert Socks4Error.CODES[91] == 'request rejected or failed'
	assert Socks4Error.CODES[92] == 'request rejected because SOCKS server cannot connect to identd on the client'
	assert Socks4Error.CODES[93] == 'request rejected because the client program and identd report different user-ids'


# Generated at 2022-06-24 14:29:03.824196
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError()
    except ProxyError as e:
        assert e.code is None
        assert e.msg is None

    try:
        raise ProxyError(1)
    except ProxyError as e:
        assert e.code == 1
        assert e.msg == 'unknown error'


# Generated at 2022-06-24 14:29:14.110659
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    import unittest
    from .compat import compat_unittest_skipUnless
    from .compatpatch import ClientCompatPatch

    class SocksSocketTest(unittest.TestCase):
        def test_setproxy(self):
            client = sockssocket()
            client._proxy = Proxy(ProxyType.SOCKS5, 'localhost', 1080)
            client.setproxy(ProxyType.SOCKS5, 'localhost', 1080)
            self.assertEqual(client._proxy.type, ProxyType.SOCKS5)
            self.assertEqual(client._proxy.host, 'localhost')
            self.assertEqual(client._proxy.port, 1080)
            self.assertEqual(client._proxy.username, None)
            self.assertEqual(client._proxy.password, None)

# Generated at 2022-06-24 14:29:20.541406
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    test_expected_version = 0x01
    test_got_version = 0x02
    with pytest.raises(InvalidVersionError) as exc_info:
        raise InvalidVersionError(test_expected_version, test_got_version)

    assert exc_info.value.errno == 0
    assert exc_info.value.strerror == 'Invalid response version from server. Expected 01 got 02'


# Generated at 2022-06-24 14:29:25.561326
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error(91).errno == 91
    assert Socks4Error(code=Socks4Error.ERR_SUCCESS).errno == Socks4Error.ERR_SUCCESS
    assert Socks4Error(code=None, msg='test message').message == 'test message'

# Generated at 2022-06-24 14:29:29.614906
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    socks = sockssocket()
    socks.setproxy(ProxyType.SOCKS5, '127.0.0.1')
    socks.connect(('google.de', 80))
    print(socks.recv(1024))

if __name__ == '__main__':
    test_sockssocket_connect()

# Generated at 2022-06-24 14:29:41.113345
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(91, '')
    except ProxyError as e:
        assert e.errno == 91
        assert e.strerror == 'request rejected or failed'
        e.errno = 92
        e.strerror = 'request rejected because SOCKS server cannot connect to identd on the client'
        try:
            raise ProxyError(e)
        except ProxyError as e:
            assert e.errno == 92
            e.strerror = 'request rejected because the client program and identd report different user-ids'
            assert e.strerror == 'request rejected because the client program and identd report different user-ids'
        assert e.errno == 92
        assert e.strerror == 'request rejected because the client program and identd report different user-ids'



# Generated at 2022-06-24 14:29:46.134284
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    socks5cmd = Socks5Command()
    assert socks5cmd.CMD_CONNECT == 0x01
    assert socks5cmd.CMD_BIND == 0x02
    assert socks5cmd.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-24 14:29:50.845567
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    server_address = ('localhost', 2080)

    sock = sockssocket()
    # Establish a dummy SOCKS connection
    sock.setproxy(ProxyType.SOCKS4A, 'localhost', 2080)
    result = sock.connect_ex(server_address)
    assert result is None

    sock.close()


# Generated at 2022-06-24 14:29:54.800732
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        ss.setproxy(ProxyType.SOCKS5, 'proxy.com', 1234)
        ss.connect(('www.google.com', 80))
    finally:
        ss.close()

# Generated at 2022-06-24 14:30:08.374681
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import select
    import time

    ss = sockssocket()
    ss.setproxy(ProxyType.SOCKS5, 'localhost', 1080)
    try:
        ss.connect(('google.com', 80))
    except socket.error:
        pass
    else:
        assert False, 'sockssocket.connect did not raise socket.error when connecting to a closed port'
    ss.close()

    ss = sockssocket()
    ss.setproxy(ProxyType.SOCKS4A, 'localhost', 1080)
    ss.connect(('google.com', 80))
    ss.sendall('GET / HTTP/1.0\r\n\r\n'.encode('utf-8'))
    t = time.time()

# Generated at 2022-06-24 14:30:11.296342
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:30:16.352186
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    auth = Socks5Auth()
    assert auth.AUTH_NONE == 0x00
    assert auth.AUTH_GSSAPI == 0x01
    assert auth.AUTH_USER_PASS == 0x02
    assert auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-24 14:30:25.006902
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    error = Socks5Error()
    assert error.args == (None, 'unknown error')

    error = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    assert error.args == (Socks5Error.ERR_GENERAL_FAILURE, 'general SOCKS server failure')

    error = Socks5Error(Socks5Auth.AUTH_NO_ACCEPTABLE)
    assert error.args == (Socks5Auth.AUTH_NO_ACCEPTABLE, 'all offered authentication methods were rejected')

    error = Socks5Error(0x02)
    assert error.args == (0x02, 'unknown error')

# Generated at 2022-06-24 14:30:27.834782
# Unit test for constructor of class ProxyType
def test_ProxyType():
    proxy = ProxyType()
    assert(proxy.SOCKS4 == 0)
    assert(proxy.SOCKS4A == 1)
    assert(proxy.SOCKS5 == 2)


# Generated at 2022-06-24 14:30:33.781019
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    except Socks5Error as e:
        assert e.args[0] == Socks5Error.ERR_GENERAL_FAILURE
        assert e.args[1] == 'general SOCKS server failure'
    else:
        assert False, 'Exception not raised'

# End unit test



# Generated at 2022-06-24 14:30:35.898649
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2

# Generated at 2022-06-24 14:30:41.894225
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(1, 2)
    except InvalidVersionError as err:
        assert err.code == 0
        assert err.errno == 0
        assert err.strerror == 'Invalid response version from server. Expected 01 got 02'
        assert str(err) == 'Invalid response version from server. Expected 01 got 02'

# Generated at 2022-06-24 14:30:48.407044
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    socks5_cmd = Socks5Command()
    assert socks5_cmd.CMD_CONNECT == socks5_cmd.CMD_BIND == Socks4Command.CMD_CONNECT == Socks4Command.CMD_BIND == 0x01
    assert socks5_cmd.CMD_UDP_ASSOCIATE == Socks5Command.CMD_UDP_ASSOCIATE == 0x03

if __name__ == '__main__':
    test_Socks5Command()
    print('All tests passed.')

# Generated at 2022-06-24 14:30:50.711704
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2

# Generated at 2022-06-24 14:30:53.627845
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 1
    assert Socks5Command.CMD_BIND == 2
    assert Socks5Command.CMD_UDP_ASSOCIATE == 3

# Generated at 2022-06-24 14:30:59.959373
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    ss = sockssocket()
    ss.setproxy(2, '127.0.0.1', 1080)
    ss.connect_ex(('127.0.0.1', 1080))
    ss.close()
    return True

if __name__ == '__main__':
    assert test_sockssocket_connect_ex()

# Generated at 2022-06-24 14:31:05.913985
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
    assert Socks5Command.CMD_UDP_ASSOCIATE != Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_UDP_ASSOCIATE != Socks4Command.CMD_BIND

# Generated at 2022-06-24 14:31:10.644941
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    e1 = Socks4Error(code=None, msg='test')
    assert e1.args == (None, 'test')
    assert e1.code is None
    assert str(e1) == 'test'

    e2 = Socks4Error(code=Socks4Error.ERR_SUCCESS)
    assert e2.args == (Socks4Error.ERR_SUCCESS, 'request rejected or failed')
    assert e2.code == Socks4Error.ERR_SUCCESS
    assert str(e2) == 'request rejected or failed'


# Generated at 2022-06-24 14:31:12.593193
# Unit test for constructor of class ProxyType
def test_ProxyType():
    pt = ProxyType()


# Generated at 2022-06-24 14:31:14.715485
# Unit test for constructor of class sockssocket
def test_sockssocket():
    socket.socket.__init__(sockssocket, socket.AF_INET, socket.SOCK_STREAM)