

# Generated at 2022-06-24 14:21:19.667611
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, "192.168.3.1", 1080, rdns=True, username='username', password='password')
    print(s.connect_ex(('www.google.com', 80)))
    s.send('GET / HTTP/1.1\r\n\r\n')
    print(s.recv(1024))


# Generated at 2022-06-24 14:21:23.693811
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04

# Generated at 2022-06-24 14:21:31.976406
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    is_socks_proxy = False

    # for tests with proxy
    if is_socks_proxy:
        socks_proxy_addr = '127.0.0.1'
        socks_proxy_port = 9050
        socks_proxy_user = None
        socks_proxy_pass = None
        socks_proxy_dns = True

    # for tests without proxy
    if not is_socks_proxy:
        socks_proxy_addr = None
        socks_proxy_port = None
        socks_proxy_user = None
        socks_proxy_pass = None
        socks_proxy_dns = None

    s = sockssocket()


# Generated at 2022-06-24 14:21:36.677378
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03

# Generated at 2022-06-24 14:21:41.127785
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setproxy(ProxyType.SOCKS4, "127.0.0.1", 1080)
    assert sock._proxy.type == 0
    assert sock._proxy.host == "127.0.0.1"
    assert sock._proxy.port == 1080


# Generated at 2022-06-24 14:21:46.729642
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert isinstance(Socks5AddressType.ATYP_IPV4, Socks5AddressType)
    assert Socks5AddressType.ATYP_IPV4 == 1
    assert isinstance(Socks5AddressType.ATYP_DOMAINNAME, Socks5AddressType)
    assert Socks5AddressType.ATYP_DOMAINNAME == 3
    assert isinstance(Socks5AddressType.ATYP_IPV6, Socks5AddressType)
    assert Socks5AddressType.ATYP_IPV6 == 4

# Generated at 2022-06-24 14:21:52.794377
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error().args[0] is None
    assert Socks4Error().args[1] is None
    assert Socks4Error(1).args[0] == 1
    assert Socks4Error(1).args[1] == 'request rejected or failed'
    assert Socks4Error(1, 'foo bar').args[0] == 1
    assert Socks4Error(1, 'foo bar').args[1] == 'foo bar'


# Generated at 2022-06-24 14:21:54.846660
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    iv = InvalidVersionError(1, 2)
    assert(isinstance(iv, InvalidVersionError))
    assert(isinstance(iv, ProxyError))

# Generated at 2022-06-24 14:21:57.199362
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 2
    assert Socks5Command.CMD_UDP_ASSOCIATE == 3
    assert Socks5Command.CMD_BIND == 2


# Generated at 2022-06-24 14:22:00.237606
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error.ERR_SUCCESS == 90
    assert Socks4Error().args == (None, None)
    assert Socks4Error(0).args == (0, None)
    assert Socks4Error(1).args == (1, 'request rejected or failed')


# Generated at 2022-06-24 14:22:04.311130
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    cmd = Socks5Command()
    assert cmd.CMD_CONNECT == 0x01
    assert cmd.CMD_BIND == 0x02
    assert cmd.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-24 14:22:05.918745
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket()
    return ss


# Generated at 2022-06-24 14:22:12.754992
# Unit test for constructor of class Proxy
def test_Proxy():
    _proxy = Proxy(0, 'host', 'port', 'username', 'password', 'remote_dns')
    assert _proxy.type == 0
    assert _proxy.host == 'host'
    assert _proxy.port == 'port'
    assert _proxy.username == 'username'
    assert _proxy.password == 'password'
    assert _proxy.remote_dns == 'remote_dns'


# Generated at 2022-06-24 14:22:22.312550
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import socket
    import os
    import subprocess
    import time

    host = '127.0.0.1'
    port = 8087
    unix_socket = '/tmp/sock-{}'.format(os.getpid())
    python_bin = '/usr/bin/python3'
    socks_server = '{} {}/socks_server.py -s {}'.format(python_bin, os.path.dirname(os.path.realpath(__file__)), unix_socket)
    print(socks_server)
    sp = subprocess.Popen(socks_server, shell = True)
    time.sleep(0.1)

    sock = sockssocket(socket.AF_UNIX, socket.SOCK_STREAM)

# Generated at 2022-06-24 14:22:29.366035
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import logging
    logger = logging.getLogger()
    sh = logging.StreamHandler()
    logger.addHandler(sh)
    logger.setLevel(logging.DEBUG)

    import random
    import string
    import sys
    import unittest

    def random_letters(length):
        return ''.join(random.choice(string.ascii_letters) for _ in range(length))


    class _TestSSLSockssocket(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(
                '{class_name}.{method_name}'.format(
                    class_name=self.__class__.__name__,
                    method_name=self._testMethodName))

# Generated at 2022-06-24 14:22:32.533867
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    ss = sockssocket()
    ss.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    ss_proxy_type = ss._proxy.type
    assert ss_proxy_type == 2
    print('Test passed')


if __name__ == '__main__':
    test_sockssocket_setproxy()

# Generated at 2022-06-24 14:22:34.024557
# Unit test for constructor of class ProxyType
def test_ProxyType():
    proxy_type = ProxyType()
    assert proxy_type.SOCKS5 == 2


# Generated at 2022-06-24 14:22:35.772013
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert(Socks5AddressType.ATYP_IPV4 == 0x01)
    assert(Socks5AddressType.ATYP_DOMAINNAME == 0x03)
    assert(Socks5AddressType.ATYP_IPV6 == 0x04)

# Generated at 2022-06-24 14:22:41.099168
# Unit test for constructor of class ProxyError
def test_ProxyError():
    code = '0'
    msg = 'A message'
    my_exception = ProxyError(code, msg)

    assert my_exception.errno == int(code)
    assert my_exception.strerror == msg

# Generated at 2022-06-24 14:22:47.614097
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    except Socks5Error as err:
        assert err.code == Socks5Error.ERR_GENERAL_FAILURE
        assert err.msg == 'general SOCKS server failure'
    try:
        raise Socks5Error(12)
    except Socks5Error as err:
        assert err.code == 12
        assert err.msg == 'unknown error'

# Generated at 2022-06-24 14:22:49.105175
# Unit test for constructor of class sockssocket
def test_sockssocket():
    def socket_create():
        return sockssocket()

    return socket_create()

# Generated at 2022-06-24 14:22:54.574898
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, 'localhost', 1080)
    s.connect_ex(('google.com', 22))
    assert s.getpeername() == ('173.194.115.68', 22)
    s.connect_ex(('google.com', 12345))
    assert s.getpeername() == ('173.194.115.68', 12345)
    s.connect_ex(('google.com', 80))
    assert s.getpeername() == ('173.194.115.68', 80)
    s.setproxy(ProxyType.SOCKS4A, 'localhost', 1080)
    s.connect_ex(('google.com', 80))
    assert s.getpeername() == ('173.194.115.68', 80)
    s.connect_

# Generated at 2022-06-24 14:23:14.035720
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-24 14:23:20.309505
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    socks4_error = Socks4Error(0)
    assert socks4_error.args[0] == 0
    assert socks4_error.args[1] == 'request rejected or failed'
    socks4_error = Socks4Error(0x99)
    assert socks4_error.args[0] == 0x99
    assert socks4_error.args[1] == 'unknown error'

# Generated at 2022-06-24 14:23:25.440993
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xff
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02

# Generated at 2022-06-24 14:23:29.350220
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    socks5_error = Socks5Error(0)
    assert socks5_error.args[0] == 0
    assert socks5_error.args[1] == 'general SOCKS server failure'
    assert str(socks5_error) == '0: general SOCKS server failure'


# Generated at 2022-06-24 14:23:33.360756
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS4, host='host', port=4321, username='user', password='pass', remote_dns=True)
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == 'host'
    assert proxy.port == 4321
    assert proxy.username == 'user'
    assert proxy.password == 'pass'
    assert proxy.remote_dns is True

# Generated at 2022-06-24 14:23:42.372388
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    import unittest

    class TestSocks5Error(unittest.TestCase):
        # Test constructor of class Socks5Error
        def test_init(self):
            self.assertEqual(
                Socks5Error(Socks5Error.ERR_GENERAL_FAILURE).strerror,
                'general SOCKS server failure'
            )
        
        def test_init_with_unknown_code(self):
            self.assertEqual(
                Socks5Error(0x02).strerror, 'unknown error'
            )

    unittest.main()


# Generated at 2022-06-24 14:23:49.942117
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket()
    sock.connect(('localhost', 5000))
    try:
        sock.recvall(5)
        assert False
    except EOFError as e:
        assert str(e) == '1 bytes missing'
    sock.close()

if __name__ == '__main__':
    sock = sockssocket()
    try:
        sock.setproxy(ProxyType.SOCKS4, 'localhost', 1080)
        sock.connect(('google.com', 80))
        sock.sendall(b'GET / HTTP/1.1\r\n\r\n')
        print(sock.recv(1024))
    except Exception as e:
        print(e)
    finally:
        sock.close()

# Generated at 2022-06-24 14:23:53.604160
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF, 'testing Socks5Auth.AUTH_NO_ACCEPTABLE'


# Generated at 2022-06-24 14:23:56.788435
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080, True, None, None)
    s.connect(('google.com', 80))



# Generated at 2022-06-24 14:24:00.088355
# Unit test for constructor of class ProxyError
def test_ProxyError():
    """
    >>> str(ProxyError(0, None))
    'unknown error'
    >>> str(ProxyError(0, 'Test'))
    'Test'
    >>> try:
    ...   raise ProxyError(0)
    ... except ProxyError:
    ...   pass
    """



# Generated at 2022-06-24 14:24:01.535031
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sockssocket()
    sockssocket(socket.AF_INET, socket.SOCK_STREAM)

# Generated at 2022-06-24 14:24:07.828259
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(
        type=ProxyType.SOCKS4,
        host='127.0.0.1',
        port=9050,
        username='username',
        password='password',
        remote_dns=True
    )
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 9050
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns == True


# Generated at 2022-06-24 14:24:12.126541
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
    assert Socks5Command.CMD_UDP_ASSOCIATE == 3

# Generated at 2022-06-24 14:24:14.833361
# Unit test for constructor of class ProxyError
def test_ProxyError():
    err = ProxyError(code=0x00, msg='test')
    assert err.args == (0, 'test')
    err = ProxyError(code=0x01)
    assert err.args == (1, 'unknown error')


# Generated at 2022-06-24 14:24:17.218709
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    port = 1883
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4A, '192.168.0.1', 1080)
    s.connect(('localhost', port))

    s.close()

# Generated at 2022-06-24 14:24:19.454552
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04

# Generated at 2022-06-24 14:24:20.719303
# Unit test for constructor of class ProxyType
def test_ProxyType():
	assert ProxyType.SOCKS4 == 0
	assert ProxyType.SOCKS4A == 1
	assert ProxyType.SOCKS5 == 2

# Generated at 2022-06-24 14:24:24.350534
# Unit test for constructor of class Proxy
def test_Proxy():
    """
    >>> p = Proxy(ProxyType.SOCKS5, 'localhost', 3128, 'username', 'password', True)
    >>> p
    Proxy(type=2, host='localhost', port=3128, username='username', password='password', remote_dns=True)
    """

# Unit tests for class socket

# Generated at 2022-06-24 14:24:35.178242
# Unit test for constructor of class ProxyError
def test_ProxyError():
    from pytest import raises
    from .compat import compat_str
    with raises(ProxyError) as err:
        raise ProxyError()
    assert err.value.args == (None, None)
    with raises(ProxyError) as err:
        raise ProxyError(code=None, msg=None)
    assert err.value.args == (None, None)
    with raises(ProxyError) as err:
        raise ProxyError(code=91)
    assert err.value.args[0] == 91
    assert err.value.args[1] == 'request rejected or failed'
    with raises(ProxyError) as err:
        raise ProxyError(code=0)
    assert err.value.args[0] == 0
    assert err.value.args[1] == 'unknown error'

# Generated at 2022-06-24 14:24:45.574737
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import sys
    proxy_host = sys.argv[1]
    proxy_port = int(sys.argv[2])
    socks_host = sys.argv[3]
    socks_port = int(sys.argv[4])

    socks = sockssocket()
    socks.setproxy(ProxyType.SOCKS5, proxy_host, proxy_port)
    value = socks.connect_ex((socks_host, socks_port))
    if value == 0:
        print('Succeeded.')
        socks.close()
    else:
        print('Failed.')

# Generated at 2022-06-24 14:24:47.835043
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error().strerror == 'general SOCKS server failure'
    assert Socks5Error(Socks5Error.ERR_SUCCESS).strerror == 'unknown error'

# Generated at 2022-06-24 14:24:49.360918
# Unit test for constructor of class Socks5Error

# Generated at 2022-06-24 14:24:54.220788
# Unit test for constructor of class ProxyError
def test_ProxyError():
    with pytest.raises(TypeError) as excinfo:
        ProxyError(None, msg="OBJECT_ERROR")
    with pytest.raises(TypeError) as excinfo:
        ProxyError(code=-1, msg="UNKNOWN")


# Generated at 2022-06-24 14:24:57.142622
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert isinstance(ProxyError(), ProxyError)



# Generated at 2022-06-24 14:24:59.012325
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    assert('Invalid response version from server. Expected 00 got 01' == InvalidVersionError(0, 1).msg)

# Generated at 2022-06-24 14:25:01.015159
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError(code=None, msg='test message').strerror == 'test message'


# Generated at 2022-06-24 14:25:02.952412
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    assert InvalidVersionError(3, 4)


# Generated at 2022-06-24 14:25:05.613102
# Unit test for constructor of class sockssocket
def test_sockssocket():
    socks1 = sockssocket()
    assert isinstance(socks1, sockssocket) == True


# Generated at 2022-06-24 14:25:16.274387
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    print('-------------------------')
    print('Test 1 : Check that server is not supported')
    s.setproxy(ProxyType.SOCKS5, 'localhost', 8080)
    print('Check success')
    print('-------------------------')
    print('Test 2 : Check that no host is provided \n')
    s = sockssocket()
    try:
        s.setproxy(ProxyType.SOCKS4A, None, 9050)
        print('Check fail')
    except Exception as e:
        print('Check success')
        print(e)
    print('-------------------------')
    print('Test 3 : Check that no type is provided \n')
    s = sockssocket()

# Generated at 2022-06-24 14:25:20.424144
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    socks4error = Socks4Error(0, "socks4error")
    assert socks4error.code == 0
    assert socks4error.msg == "socks4error"
    assert socks4error.args == (0, "socks4error")

# Generated at 2022-06-24 14:25:23.184917
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    error = InvalidVersionError(0, 1)
    assert 'Invalid response version from server. Expected 00 got 01' == error.args[1]

# Generated at 2022-06-24 14:25:28.639583
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert (Socks5Auth.AUTH_NONE==0x00)
    assert (Socks5Auth.AUTH_GSSAPI==0x01)
    assert (Socks5Auth.AUTH_USER_PASS==0x02)
    assert (Socks5Auth.AUTH_NO_ACCEPTABLE==0xFF)


# Generated at 2022-06-24 14:25:33.640199
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04

# Generated at 2022-06-24 14:25:42.683760
# Unit test for constructor of class sockssocket
def test_sockssocket():
    try:
        sockssocket()
    except TypeError:
        pass


if __name__ == '__main__':
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, 'yandex.ru', 1080)
    s.connect(('93.158.134.52', 80))

    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4, 'yandex.ru', 1080)
    s.connect(('93.158.134.52', 80))

# Generated at 2022-06-24 14:25:52.562237
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    print('Test sockssocket.setproxy() method')
    # Create a sockssocket (inherited from socket)
    socks_socket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    # Now, set the proxy (host, port)
    socks_socket.setproxy(ProxyType.SOCKS5,'localhost', 8080)
    # Test the proxy setting successfully
    if str(socks_socket._proxy) == 'Proxy(type=2, host=localhost, port=8080, '\
            'username=None, password=None, remote_dns=True)':
        print('Testing sockssocket.setproxy() method. Successful\n')
    else:
        print('Testing sockssocket.setproxy() method. Failed')

# Generated at 2022-06-24 14:26:04.373776
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    # Create a new socket object.
    socks_socket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    socks_socket.setproxy(ProxyType.SOCKS5, 'localhost', 9050, username='user', password='pass')
    # Check if the proxy is well configured.
    assert socks_socket._proxy.type == ProxyType.SOCKS5
    assert socks_socket._proxy.host == 'localhost'
    assert socks_socket._proxy.port == 9050
    assert socks_socket._proxy.username == 'user'
    assert socks_socket._proxy.password == 'pass'
    assert socks_socket._proxy.remote_dns

if __name__ == '__main__':
    test_sockssocket_setproxy()

# Generated at 2022-06-24 14:26:09.417990
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks4Command.CMD_CONNECT == Socks5Command.CMD_CONNECT
    assert Socks4Command.CMD_BIND == Socks5Command.CMD_BIND
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03

# Generated at 2022-06-24 14:26:12.765638
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth()._fields == ('AUTH_NONE', 'AUTH_GSSAPI', 'AUTH_USER_PASS', 'AUTH_NO_ACCEPTABLE')


# Generated at 2022-06-24 14:26:14.165254
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket()
    pass


# Generated at 2022-06-24 14:26:24.397118
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    try:
        import socks
    except ImportError:
        assert False, 'The socks module should be available'

    with socks.socksocket() as sock:
        assert sock.connect('localhost', 1) == 0
        assert sock.connect_ex('localhost', 1) == 0
        assert sock.sendall(b'Hello!') == 0
        for i in range(4):
            assert sock.recv(512) == b'Hello!'
        assert sock.close() == 0

    with socks.socksocket(socks.SOCKS4) as sock:
        assert sock.connect('localhost', 1) == 0
        assert sock.sendall(b'Hello!') == 0
        assert sock.close() == 0


# Generated at 2022-06-24 14:26:30.255026
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(expected_version=1, got_version=2)
    except InvalidVersionError as e:
        assert e.args[0] == 0
        assert e.args[1] == 'Invalid response version from server. Expected 01 got 02'
    else:
        assert False, "Didn't raise the proper exception!"

# Unit tests for the methods of sockssocket

# Generated at 2022-06-24 14:26:31.818266
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()
    assert s._proxy is None


# Generated at 2022-06-24 14:26:42.620731
# Unit test for constructor of class ProxyError
def test_ProxyError():
    with pytest.raises(Exception) as exc:
        raise ProxyError()
    assert exc.value.code == 0
    assert 'code' in str(exc.value) and 'msg' not in str(exc.value)
    with pytest.raises(Exception) as exc:
        raise ProxyError(1)
    assert exc.value.code == 1
    assert 'code' in str(exc.value) and 'msg' in str(exc.value)
    with pytest.raises(Exception) as exc:
        raise ProxyError(msg='message')
    assert exc.value.code == 0
    assert 'code' not in str(exc.value) and 'msg' in str(exc.value)


# Generated at 2022-06-24 14:26:49.342059
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()
    assert s.gettimeout() == socket.getdefaulttimeout()
    assert s.family == socket.AF_INET
    assert s.type == socket.SOCK_STREAM
    assert s.proto == socket.IPPROTO_TCP
    assert s.fileno() == -1
    assert s.getsockname() == ('0.0.0.0', 0)
    assert s.getpeername() == ('', 0)
    assert s.getsockopt(socket.SOL_SOCKET, socket.SO_TYPE) == socket.SOCK_STREAM
    assert s._proxy is None


# Generated at 2022-06-24 14:26:53.079346
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error(Socks4Error.ERR_SUCCESS) == \
        Socks4Error(Socks4Error.ERR_SUCCESS, Socks4Error.CODES[Socks4Error.ERR_SUCCESS])



# Generated at 2022-06-24 14:27:02.532851
# Unit test for constructor of class ProxyType
def test_ProxyType():
    # Test for ProxyType(SOCKS4, 'host', 'port', 'username', 'password', 'remote_dns')
    Test_ProxyType = ProxyType(SOCKS4, 'host', 'port', 'username', 'password', 'remote_dns')
    # Test for ProxyType.SOCKS4
    # Test for ProxyType._fields
    # Test for ProxyType._make()
    # Test for ProxyType._asdict()
    # Test for ProxyType._replace()
    # Test for ProxyType._source()
    # Test for ProxyType.__len__()
    # Test for ProxyType.__getitem__()
    # Test for ProxyType.__repr__()
    # Test for ProxyType.__iter__()
    # Test for ProxyType.__eq__()
    # Test for ProxyType.__lt__()

# Generated at 2022-06-24 14:27:08.446902
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    f = Socks4Error
    obj = f()
    assert obj.args[0] == 0
    assert obj.args[1] is None
    obj = f(0)
    assert obj.args[0] == 0
    assert obj.args[1] is None
    obj = f(91)
    assert obj.args[0] == 91
    assert obj.args[1] == 'request rejected or failed'

# Generated at 2022-06-24 14:27:11.404638
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    Socks5Auth.AUTH_NONE
    Socks5Auth.AUTH_GSSAPI
    Socks5Auth.AUTH_USER_PASS
    Socks5Auth.AUTH_NO_ACCEPTABLE

# Generated at 2022-06-24 14:27:13.911569
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-24 14:27:17.510490
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    def try_setproxy():
        sockssocket.setproxy(ProxyType.SOCKS4, '127.0.0.1', 8080,
                             username='username', password='password')
    try_setproxy()

    # In Python 3 setproxy fails with insufficient number of arguments:
    # TypeError: setproxy() missing 2 required positional arguments: 'rdns' and 'username'
    with pytest.raises(TypeError):
        try_setproxy()

# Generated at 2022-06-24 14:27:19.672330
# Unit test for constructor of class ProxyError
def test_ProxyError():
    with pytest.raises(TypeError, match='msg'):
        ProxyError()
    assert ProxyError(code='foo', msg='bar').args == (None, 'bar')
    assert ProxyError(code=ProxyError.ERR_SUCCESS).args == (0, 'unknown error')


# Generated at 2022-06-24 14:27:24.668997
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import pytest

    s = sockssocket()

    s.connect(('localhost', 9050))

    s.sendall('GET / HTTP/1.0\n\n')

    data = s.recvall(1024)

    assert data[0:3] == 'HTTP'
    assert data.count('\n\n') == 1

# Generated at 2022-06-24 14:27:28.794395
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Test case 1
    try:
        s = sockssocket()
        s.recvall(10)
    except EOFError:
        print('Case 1 pass')
    else:
        print('Case 1 fail')

    # Test case 2
    try:
        s = sockssocket()
        s.recvall(10)
    except EOFError:
        print('Case 2 pass')
    else:
        print('Case 2 fail')



# Generated at 2022-06-24 14:27:32.542313
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = (*Proxy._fields, 0)
    assert proxy._make(proxy) == Proxy(0, 0, 0, 0, 0, 0)


# Generated at 2022-06-24 14:27:43.683097
# Unit test for constructor of class ProxyError
def test_ProxyError():
    from .compat import compat_str, compat_bytes

    assert isinstance(ProxyError().args[0], int)
    assert isinstance(ProxyError(0).args[1], compat_str)
    assert isinstance(ProxyError(code=0).args[0], int)
    assert isinstance(ProxyError(code=0).args[1], compat_str)
    assert isinstance(ProxyError(0, 'foo').args[0], int)
    assert isinstance(ProxyError(0, 'foo').args[1], comparator)
    assert isinstance(ProxyError(code=0, msg='foo').args[0], int)
    assert isinstance(ProxyError(code=0, msg='foo').args[1], comparator)



# Generated at 2022-06-24 14:27:55.822660
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    # Prepare mock socket
    class _socket_mock(object):
        def __init__(self, addr, port):
            self.addr, self.port = addr, port
            self.buffer = []

        def close(self):
            pass

        def connect(self, address):
            assert address == (self.addr, self.port)

        def sendall(self, data):
            self.buffer.append(data)

        def recv(self, cnt):
            return (b'\x00\x5a\x00\x00\x00\x00\x00\x00')[:cnt]


# Generated at 2022-06-24 14:27:57.775688
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 1

test_Socks5Command()

# Generated at 2022-06-24 14:28:11.982179
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    e = Socks4Error()
    assert e.strerror == 'unknown error'
    assert e.errno == 0
    e = Socks4Error(code=1)
    assert e.strerror == 'request rejected or failed'
    assert e.errno == 1
    e = Socks4Error(code=10)
    assert e.strerror == 'unknown error'
    assert e.errno == 10
    e = Socks4Error(msg='test error')
    assert e.strerror == 'test error'
    assert e.errno == 0
    e = Socks4Error(code=1, msg='test error')
    assert e.strerror == 'request rejected or failed'
    assert e.errno == 1
    e = Socks4Error(code=10, msg='test error')


# Generated at 2022-06-24 14:28:15.805618
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    invver = InvalidVersionError(1, 2)
    assert invver.args == (0, 'Invalid response version from server. Expected 01 got 02')


# Generated at 2022-06-24 14:28:20.185586
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    socks5cmd = Socks5Command()
    print("test_Socks5Command :")
    print(socks5cmd.__dict__)
    print("test_Socks5Command :")
    # {'CMD_CONNECT': 1, 'CMD_BIND': 2, 'CMD_UDP_ASSOCIATE': 3}


# Generated at 2022-06-24 14:28:24.674322
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    socks5_at = Socks5AddressType()
    print(socks5_at.ATYP_IPV4)
    print(socks5_at.ATYP_DOMAINNAME)
    print(socks5_at.ATYP_IPV6)


# Generated at 2022-06-24 14:28:31.107370
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    socks = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    socks.setproxy(ProxyType.SOCKS4, "127.0.0.1", 9000)
    assert socks._proxy.type == ProxyType.SOCKS4
    assert socks._proxy.host == "127.0.0.1"
    assert socks._proxy.port == 9000
    assert socks._proxy.username is None
    assert socks._proxy.password is None
    assert socks._proxy.remote_dns is True


# Generated at 2022-06-24 14:28:34.398045
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    err = Socks5Error(1)
    expected = 'general SOCKS server failure'
    got = err.msg
    assert got == expected

# Generated at 2022-06-24 14:28:45.932114
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import sys
    for arg in sys.argv[1:]:
        print('Testing', arg)
        port = 1080
        try:
            host, portstr = arg.split(':')
            port = int(portstr)
        except ValueError:
            host = arg

        # Socks4
        s_4a = sockssocket()
        s_4a.setproxy(ProxyType.SOCKS4A, host, port)
        s_4a.connect(('www.google.com', 80))

        # Socks5
        s_5 = sockssocket()
        s_5.setproxy(ProxyType.SOCKS5, host, port)
        s_5.connect(('www.google.com', 80))

        # HTTP
        s_http = sockssocket()

# Generated at 2022-06-24 14:28:48.867389
# Unit test for constructor of class ProxyError
def test_ProxyError():
     pe = ProxyError(code = 0, msg = 'Test')
     assert isinstance(pe, ProxyError)
     assert pe.args == (0, 'Test')

# Generated at 2022-06-24 14:28:53.268814
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    ive = InvalidVersionError(5, 6)
    assert ive.args[0] == 5
    assert ive.args[1] == 'Invalid response version from server. Expected 05 got 06'
    #print(ive)

if __name__ == '__main__':
    test_InvalidVersionError()

# Generated at 2022-06-24 14:28:57.462181
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(100)
    except Socks4Error as e:
        assert e.code == 100
        assert e.errno == 100
        assert str(e) == 'unknown error'



# Generated at 2022-06-24 14:29:02.743241
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(1, 'host', 12345, 'user', 'pass', False)
    assert proxy.type == 1
    assert proxy.host == 'host'
    assert proxy.port == 12345
    assert proxy.username == 'user'
    assert proxy.password == 'pass'
    assert proxy.remote_dns == False



# Generated at 2022-06-24 14:29:05.732189
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    c = Socks4Command()
    assert c.CMD_CONNECT == 0x01
    assert c.CMD_BIND == 0x02


# Generated at 2022-06-24 14:29:12.816527
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError()
    except ProxyError as err:
        assert err.errno is None
        assert err.strerror is None

    try:
        raise ProxyError(1)
    except ProxyError as err:
        assert err.errno == 1
        assert err.strerror == 'unknown error'

    try:
        raise ProxyError(1, 'foo')
    except ProxyError as err:
        assert err.errno == 1
        assert err.strerror == 'foo'



# Generated at 2022-06-24 14:29:16.014209
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    sockssocket.setproxy(sockssocket, proxytype=ProxyType.SOCKS5, addr='foxsocks.in', port=1080, rdns=True, username=None, password=None)
    sockssocket.connect_ex(sockssocket, ('foxsocks.in', 80))


# Generated at 2022-06-24 14:29:19.289225
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError(None, 'test') == ProxyError(None, 'test')

if __name__ == '__main__':
    test_ProxyError()

# Generated at 2022-06-24 14:29:25.854245
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    import requests
    import socks
    # Check valid input
    s = socks.socksocket()
    s.setproxy(2, 'localhost', 9090)
    s.connect(('www.google.com', 80))

    # Check validation of input
    s = socks.socksocket()
    try:
        s.setproxy(3, 'localhost', 9090)
    except ValueError:
        pass
    else:
        assert False

    # Check creation of interception proxy with invalid proxy type
    try:
        proxies = {'http': 'socks://localhost:9090'}
        r = requests.get('http://www.google.com', proxies=proxies)
    except requests.exceptions.SSLError:
        pass
    else:
        assert False

# Generated at 2022-06-24 14:29:30.813004
# Unit test for constructor of class ProxyError
def test_ProxyError():
    if __debug__:
        assert str(ProxyError(code=None, msg=None)) == 'None: None'
        assert str(ProxyError(code=None, msg='test')) == 'None: test'
        assert str(ProxyError(code=0, msg=None)) == '0: None'
        assert str(ProxyError(code=0, msg='test')) == '0: test'


# Generated at 2022-06-24 14:29:35.053098
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    socks = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    socks.setproxy(ProxyType.SOCKS5, "", 0)
    socks.connect_ex(("", 0))
    socks.close()

# Generated at 2022-06-24 14:29:36.133121
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    err = InvalidVersionError(0x01, 0x02)

# Generated at 2022-06-24 14:29:38.500616
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    expected_version = 1
    got_version = 2
    err = InvalidVersionError(expected_version, got_version)
    assert err.args[1] == 'Invalid response version from server. Expected 01 got 02'

# Generated at 2022-06-24 14:29:42.816465
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sockssocket.setproxy(SOCKS4, '127.0.0.1', 7070)
    assert sockssocket.connect('8.8.8.8', 80) == None


# Generated at 2022-06-24 14:29:53.672870
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import time
    import unittest

    class _Example(unittest.TestCase):
        def test_recvall(self):
            ss = sockssocket()
            ss.setblocking(True)
            ss.connect(('green.yt', 80))

            ss.sendall(b'GET / HTTP/1.1\r\nHost: green.yt\r\n\r\n')
            response = ss.recvall(8192)
            # If a timeout happens in _recv_bytes, we will fail to collect the
            # expected number of bytes and raise an error.
            # The default timeout for _recv_bytes is 5 seconds. Wait a bit
            # because 2 seconds are enough for an HTTP request, but usually not
            # enough for an HTTP response.
            time.sleep(7)
            self.assertE

# Generated at 2022-06-24 14:30:00.777356
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    e = Socks4Error(0x91)
    assert e.args[0] == Socks4Error.CODES.get(0x91)


# Generated at 2022-06-24 14:30:04.152207
# Unit test for constructor of class Proxy
def test_Proxy():
    p = Proxy('type', 'host', 'port', 'username', 'password', 'remote_dns')
    assert (p.type == 'type')
    assert (p.host == 'host')
    assert (p.port == 'port')
    assert (p.username == 'username')
    assert (p.password == 'password')
    assert (p.remote_dns == 'remote_dns')



# Generated at 2022-06-24 14:30:12.212630
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    ip = "88.220.246.117"
    port = 80
    ss = sockssocket()
    ss.setproxy(ProxyType.SOCKS4, ip, port)
    try:
        ret = ss.connect_ex((ip, port))
        if ret == 0:
            print('Succeed to connect local host')
            ss.close()
        else:
            print('Failed to connect local host')
    except Exception as ex:
        print(ex.message)


if __name__ == '__main__':
    test_sockssocket_connect_ex()

# Generated at 2022-06-24 14:30:26.263060
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-24 14:30:35.718303
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():

    # Get hostname and port of socks5 proxy server running locally
    from .utils import parse_socks5_proxy
    # Returns object like Proxy(..., host='127.0.0.1', port=1086, ...)
    proxy_info = parse_socks5_proxy('socks5://127.0.0.1')

    # Create socket object
    test_socket = sockssocket()

    # Set proxy parameters
    test_socket.setproxy(ProxyType.SOCKS5, proxy_info.host, proxy_info.port)

    port_number = 80 # Default port number for HTTP service
    host_ip = socket.gethostbyname('www.python.org')
    print(host_ip)

    # Connect to HTTP service running on remote server
    test_socket.connect((host_ip, port_number))


# Generated at 2022-06-24 14:30:41.822462
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    err = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    assert err.args[0] == Socks5Error.ERR_GENERAL_FAILURE
    assert err.args[1] == Socks5Error.CODES[Socks5Error.ERR_GENERAL_FAILURE]

# Generated at 2022-06-24 14:30:44.150638
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    with sockssocket() as sock:
        # Check if connect_ex returns 0 when socks is not set
        sock.connect_ex(('google.com', 80)) == 0

# Generated at 2022-06-24 14:30:45.781776
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:30:51.041847
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    with sockssocket() as sock:
        sock.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)  # SOCKS5 proxy
        sock.connect(('www.example.com', 80))

# Generated at 2022-06-24 14:30:53.627590
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-24 14:31:03.878501
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(
        type = ProxyType.SOCKS4, host = 'localhost', port = 8080,
        username = 'username', password = 'password', remote_dns = True
    )
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == 'localhost'
    assert proxy.port == 8080
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns == True
    assert str(proxy) == "Proxy(type=0, host='localhost', port=8080, username='username', password='password', remote_dns=True)"


# Generated at 2022-06-24 14:31:07.186588
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03

# Generated at 2022-06-24 14:31:12.615637
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    # Test for code
    socks4_error = Socks4Error(Socks4Error.ERR_SUCCESS)
    assert socks4_error.args[0] == 90
    assert socks4_error.args[1] == 'request rejected or failed'
    # Test for msg
    socks4_error_without_code = Socks4Error(msg='test msg')
    assert socks4_error_without_code.args[0] is None
    assert socks4_error_without_code.args[1] == 'test msg'

# Generated at 2022-06-24 14:31:18.367212
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    ATYP_IPV4 = Socks5AddressType.ATYP_IPV4
    ATYP_DOMAINNAME = Socks5AddressType.ATYP_DOMAINNAME
    ATYP_IPV6 = Socks5AddressType.ATYP_IPV6

    assert ATYP_IPV4 == 0x01
    assert ATYP_DOMAINNAME == 0x03
    assert ATYP_IPV6 == 0x04
