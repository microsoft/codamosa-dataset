

# Generated at 2022-06-24 14:21:16.726496
# Unit test for constructor of class sockssocket
def test_sockssocket():
    try:
        s = sockssocket()
    except Exception:
        raise AssertionError('Failed to initialize sockssocket')
    assert isinstance(s, sockssocket)

# Generated at 2022-06-24 14:21:23.539411
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    s = Socks5Auth()

# Generated at 2022-06-24 14:21:30.447477
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import sys
    import socket
    import sockssocket

    sock = sockssocket.socksocket()

    sock.setproxy(sockssocket.ProxyType.SOCKS5, '127.0.0.1', 1080)
    try:
        sock.connect(('127.0.0.1', 8080))
    except Exception as e:
        print('Exception: %s' % e)
        print('Error Number: ' + str(e.errno))
        print('Message: ' + e.strerror)



# Generated at 2022-06-24 14:21:32.008849
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket()
    assert isinstance(ss, socket.socket)
    assert isinstance(ss, sockssocket)

# Generated at 2022-06-24 14:21:36.340016
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    socks = sockssocket()
    socks.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080)
    assert socks.connect_ex(('127.0.0.1', 80)) == 0

# Generated at 2022-06-24 14:21:39.465699
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError().args[0] == None
    assert ProxyError().args[1] == None
    assert ProxyError(1, 'err1').args[0] == 1
    assert ProxyError(1, 'err1').args[1] == 'err1'

# Generated at 2022-06-24 14:21:43.007748
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    result = InvalidVersionError(0x01, 0x02)
    assert result.args == (0, 'Invalid response version from server. Expected 01 got 02')
    result = InvalidVersionError(0x01, 0x02).args
    assert result == (0, 'Invalid response version from server. Expected 01 got 02')


# Generated at 2022-06-24 14:21:50.327115
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    server = socket.socket()

    def bind_to_random_port(sock):
        port = 0
        while port <= 1023:
            port += 1
            try:
                sock.bind(('localhost', port))
                break
            except socket.error as e:
                if e.errno != 98:
                    raise
        sock.listen(1)

    def send_response(sock, status, addr, port):
        version = SOCKS4_REPLY_VERSION
        packet = compat_struct_pack('!BBHIH', version, status, 0, addr, port)
        sock.send(packet)

    def handle_connection(sock):
        client, addr = sock.accept()

# Generated at 2022-06-24 14:21:52.964018
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    u'Test for method setproxy'
    import doctest
    doctest.testmod()
    print('OK')


if __name__ == '__main__':
    test_sockssocket_setproxy()

# Generated at 2022-06-24 14:21:57.050922
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    s = Socks5Error()
    assert s.__str__() == 'unknown error'

    s = Socks5Error(1, 'unknown error')
    assert s.__str__() == 'unknown error'

    s = Socks5Error(1)
    assert s.__str__() == 'general SOCKS server failure'


# Generated at 2022-06-24 14:21:59.094199
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(code=91, msg=None)
    except ProxyError as pe:
        assert pe.args == (91, 'request rejected or failed')


# Generated at 2022-06-24 14:22:01.089815
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:22:04.078897
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:22:09.449891
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(expected_version=5, got_version=5)
    except InvalidVersionError as e:
        print(e)
        assert(e.errno == 0)
        assert(str(e) == 'Invalid response version from server. Expected 05 got 05')
    else:
        assert(False)

# Generated at 2022-06-24 14:22:20.024180
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.setproxy(ProxyType.SOCKS4, 'localhost', 1080)
    assert s._proxy.type == ProxyType.SOCKS4
    assert s._proxy.host == 'localhost'
    assert s._proxy.port == 1080
    assert s._proxy.remote_dns

    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.setproxy(ProxyType.SOCKS5, 'localhost', 1080)
    assert s._proxy.type == ProxyType.SOCKS5
    assert s._proxy.host == 'localhost'
    assert s._proxy.port == 1080
    assert s._proxy.remote_dns


# Generated at 2022-06-24 14:22:25.438682
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(0, 'ERROR_SUCCESS')
    except ProxyError as e:
        assert e.args[0] == 0 and e.args[1] == 'ERROR_SUCCESS'

    try:
        raise ProxyError(1, 'Error 1')
        assert False
    except ProxyError as e:
        assert e.args[0] == 1 and e.args[1] == 'Error 1'

    try:
        raise ProxyError(1)
        assert False
    except ProxyError as e:
        assert e.args[0] == 1 and e.args[1] == 'unknown error'

# Generated at 2022-06-24 14:22:27.320125
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    err = Socks5Error(25)
    assert err.code == 25
    assert str(err) == 'unknown username or invalid password'

# Generated at 2022-06-24 14:22:31.850846
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error().__str__() == 'unknown error'
    assert Socks4Error(code=91).__str__() == 'request rejected or failed'
    assert Socks4Error(code=92).__str__() == 'request rejected because SOCKS server cannot connect to identd on the client'
    assert Socks4Error(code=93).__str__() == 'request rejected because the client program and identd report different user-ids'


# Generated at 2022-06-24 14:22:32.596052
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():

    # this test is meaningless
    assert True



# Generated at 2022-06-24 14:22:40.870667
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy_test = Proxy(ProxyType.SOCKS5, '127.0.0.1', 1080, 'username', 'password', False)
    assert proxy_test.type == ProxyType.SOCKS5
    assert proxy_test.host == '127.0.0.1'
    assert proxy_test.port == 1080
    assert proxy_test.username == 'username'
    assert proxy_test.password == 'password'
    assert proxy_test.remote_dns == False

# Generated at 2022-06-24 14:22:43.004387
# Unit test for constructor of class ProxyType
def test_ProxyType():
    proxy_type = ProxyType()
    assert [proxy_type.SOCKS4, proxy_type.SOCKS4A, proxy_type.SOCKS5] == [0, 1, 2]

# Generated at 2022-06-24 14:22:44.269307
# Unit test for constructor of class ProxyType
def test_ProxyType():
    # Creating object ProxyType.SOCKS5
    assert ProxyType.SOCKS5 is not None

# Generated at 2022-06-24 14:22:46.467728
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sockssocket()

if __name__ == '__main__':
    test_sockssocket()

# Generated at 2022-06-24 14:22:50.107700
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    socks5_error = Socks5Error(0xFF)
    assert socks5_error.args[1] == 'all offered authentication methods were rejected'



# Generated at 2022-06-24 14:22:59.714193
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    ss.setproxy(socks.PROXY_TYPE_SOCKS4, "127.0.0.1", 1080)
    print(ss.connect_ex(('www.sina.com.cn',80)))
    ss.send(b'GET / HTTP/1.1\r\nHost: www.sina.com.cn\r\nConnection: close\r\n\r\n')
    temp = ss.recv(1024)
    while 1:
        if len(temp)>0:
            print(temp)
        else:
            break
        temp = ss.recv(1024)
    ss.close()

if __name__ == '__main__':
    test_sockssocket_connect_ex()

# Generated at 2022-06-24 14:23:01.853667
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-24 14:23:07.717379
# Unit test for constructor of class ProxyError
def test_ProxyError():
    error_code = 0x01
    error = ProxyError(error_code)
    assert error.errno == error_code
    assert str(error).startswith('1')
    assert ProxyError(0).errno == ProxyError.ERR_SUCCESS
    assert str(ProxyError(0)).startswith('0')



# Generated at 2022-06-24 14:23:14.971512
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    with sockssocket() as s:
        s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1080)
        assert s._proxy.type == ProxyType.SOCKS4
        assert s._proxy.host == '127.0.0.1'
        assert s._proxy.port == 1080
        assert s._proxy.username is None
        assert s._proxy.password is None
        assert s._proxy.remote_dns

        s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, username='user', password='pass')
        assert s._proxy.type == ProxyType.SOCKS5
        assert s._proxy.host == '127.0.0.1'
        assert s._proxy.port == 1080
        assert s._proxy.username == 'user'

# Generated at 2022-06-24 14:23:18.882388
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_IPV6 == 0x04
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03


# Generated at 2022-06-24 14:23:24.913497
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    response = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    assert response.args[1] == Socks5Error.CODES[Socks5Error.ERR_GENERAL_FAILURE]
    response = Socks5Error(Socks5Error.ERR_SUCCESS)
    assert response.args[1] == 'unknown error'

# Generated at 2022-06-24 14:23:28.566471
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(code=ProxyError.ERR_SUCCESS, msg='test')
    except ProxyError as e:
        assert e.errno == ProxyError.ERR_SUCCESS
        assert e.strerror == 'test'



# Generated at 2022-06-24 14:23:30.525326
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error(Socks5Error.ERR_SUCCESS).strerror == 'general SOCKS server failure'


# Generated at 2022-06-24 14:23:36.477873
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():

    s4 = sockssocket(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_IP)
    s5 = sockssocket(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_IP)

    s4.setproxy(proxytype=ProxyType.SOCKS4,addr="190.162.103.xxx",port=1080,rdns=True,username="user",password="pass")
    s5.setproxy(proxytype=ProxyType.SOCKS5,addr="190.162.103.xxx",port=1080,rdns=True,username="user",password="pass")
    assert s4._proxy.type == 0
    assert s4._proxy.host == "190.162.103.xxx"
    assert s4._proxy.port == 1080
    assert s4

# Generated at 2022-06-24 14:23:38.851214
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    with pytest.raises(InvalidVersionError):
        raise InvalidVersionError(1, 2)

# Generated at 2022-06-24 14:23:39.493535
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sockssocket()

# Generated at 2022-06-24 14:23:48.382656
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import select
    import threading
    import time
    import unittest

    class T(unittest.TestCase):
        def _send_data(self, ip_addr, port, data):
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.bind((ip_addr, port))
            s.sendto(bytes(data, 'utf-8'), (ip_addr, port))
            s.close()

        def test_recvall(self):
            self.done = False
            self.success = False
            self.error = False
            self.data = ''
            def set_data():
                time.sleep(0.1)

# Generated at 2022-06-24 14:23:50.299478
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError().args == (None, 'unknown error')


# Generated at 2022-06-24 14:23:56.256386
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(1, 'an_address', 2, 'an_username', 'a_password', True)
    assert (proxy.type, proxy.host, proxy.port, proxy.username, proxy.password, proxy.remote_dns) == (
        1, 'an_address', 2, 'an_username', 'a_password', True)


# Generated at 2022-06-24 14:23:58.369949
# Unit test for constructor of class ProxyError
def test_ProxyError():
    err = ProxyError(1, "abc")
    assert err.args[0] == 1
    assert err.args[1] == "abc"


# Generated at 2022-06-24 14:24:03.424858
# Unit test for constructor of class ProxyError
def test_ProxyError():
    e = ProxyError()
    assert e.code == None
    assert e.msg == None
    e = ProxyError(1)
    assert e.code == 1
    assert e.msg == None

# Generated at 2022-06-24 14:24:05.883276
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error().args[0] == 0
    assert Socks5Error(0).args[0] == 0
    assert Socks5Error(1).args[0] == 1
    assert Socks5Error(1).args[1] == 'general SOCKS server failure'

# Generated at 2022-06-24 14:24:07.933923
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0, "ProxyType.SOCKS4 is equal to 0"
    assert ProxyType.SOCKS5 == 2, "ProxyType.SOCKS5 is equal to 2"


# Generated at 2022-06-24 14:24:13.586132
# Unit test for constructor of class sockssocket
def test_sockssocket():
    print("start test sockssocket")
    # 创建sockssocket对象
    sk1 = sockssocket()
    sk2 = sockssocket(sk1.family, sk1.type, sk1.proto) #构造函数接受3个参数:IPv4,TCP,0
    sk3 = sockssocket(sk1.family, sk1.type, sk1.proto, sk1.fileno()) #此构造函数不接受文件号,只能传入一个socket对象
    # sk4 = sockssocket(sk2.family, sk3.type, sk3.proto, sk3.fileno()) #错误的

# Generated at 2022-06-24 14:24:15.573327
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-24 14:24:20.605815
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error()
    assert Socks4Error(91) == (91, 'request rejected or failed')
    assert Socks4Error(99) == (99, 'unknown error')
    assert Socks4Error(-1) == (-1, 'unknown error')


# Generated at 2022-06-24 14:24:21.574444
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sockssocket.connect(0, 0)

# Generated at 2022-06-24 14:24:25.998313
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sockssocket.setproxy(sockssocket, ProxyType.SOCKS4, "45.76.192.35", 1080)
    sockssocket.connect(sockssocket, ("www.google.com", 80))
    print("")

# Generated at 2022-06-24 14:24:29.473989
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    cmd_connect = Socks4Command.CMD_CONNECT
    cmd_bind = Socks4Command.CMD_BIND
    assert cmd_connect == 1
    assert cmd_bind == 2


# Generated at 2022-06-24 14:24:34.044893
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    try:
        sockssocket().connect_ex(('127.0.0.1', 1080))
    except socket.error:
        # This often fails if there is no SOCKS server at the specified address.
        # Let's just ignore this failure and assume the client knows what they are doing.
        pass



# Generated at 2022-06-24 14:24:42.459994
# Unit test for constructor of class ProxyError
def test_ProxyError():
    # Test default constructor
    try:
        raise ProxyError()
    except ProxyError as e:
        assert e.args[0] is None
        assert e.args[1] is None

    # Test explicit value constructor
    try:
        raise ProxyError(12345)
    except ProxyError as e:
        assert e.args[0] == 12345
        assert e.args[1] == 'unknown error'


# Generated at 2022-06-24 14:24:44.339747
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert isinstance(ProxyError(ProxyError.ERR_SUCCESS), Exception)



# Generated at 2022-06-24 14:24:47.094440
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    command = Socks4Command()
    assert command.CMD_CONNECT == 0x01
    assert command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:24:49.639490
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-24 14:24:57.274617
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    socket.error()
    Socks5Error()
    invalid_version_error = InvalidVersionError(SOCKS4_VERSION, SOCKS5_VERSION)
    assert invalid_version_error.strerror == 'Invalid response version from server. Expected 04 got 05'
    assert invalid_version_error.args == (0, 'Invalid response version from server. Expected 04 got 05')

# Generated at 2022-06-24 14:25:06.036825
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error()
    except Socks4Error as error:
        assert error.args == (None, None)

    try:
        raise Socks4Error(code=0x00)
    except Socks4Error as error:
        assert error.args == (0x00, 'request rejected or failed')

    try:
        raise Socks4Error(code=0x01, msg='Invalid code')
    except Socks4Error as error:
        assert error.args == (0x01, 'Invalid code')


# Generated at 2022-06-24 14:25:16.538415
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import socks
    import socket
    hostname = 'example.com'
    port = 80

    proxy_hostname = '127.0.0.1'
    proxy_port = 1080

    directory = os.path.dirname(os.path.abspath(__file__))
    fd = open(os.path.join(directory, "proxychains.conf"), "w")
    fd.write("""
    [ProxyList]
    socks4 %s %s
    """ % (proxy_hostname, proxy_port))
    fd.close()

    socks.setdefaultproxy(socks.PROXY_TYPE_SOCKS4, proxy_hostname, proxy_port)
    socket.socket = sockssocket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s

# Generated at 2022-06-24 14:25:18.962145
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    cmd = Socks5Command()
    assert cmd.CMD_CONNECT == 0x01
    assert cmd.CMD_BIND == 0x02
    assert cmd.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-24 14:25:21.652301
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    # Constructor without error code
    e = Socks5Error()
    assert e.args[0] == None
    assert e.args[1] == None

    e = Socks5Error(0x02)
    assert e.args[0] == 0x02
    assert e.args[1] == "connection not allowed by ruleset"


# Generated at 2022-06-24 14:25:34.902099
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    HOST = '127.0.0.1'
    PORT = 1234

    import threading
    import time

    def server():
        time.sleep(0.1)
        send_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        send_socket.bind((HOST, PORT))
        send_socket.listen(1)
        conn, client_addr = send_socket.accept()
        conn.sendall(b'abc123')
        conn.close()

    def main():
        server_thread = threading.Thread(target=server)
        server_thread.start()

        s = sockssocket()
        s.connect((HOST, PORT))
        assert s.recvall(6) == b'abc123'
        s.close()

    main

# Generated at 2022-06-24 14:25:37.537633
# Unit test for constructor of class ProxyType
def test_ProxyType():
    pt = ProxyType()
    assert pt.SOCKS4 == 0
    assert pt.SOCKS4A == 1
    assert pt.SOCKS5 == 2


# Generated at 2022-06-24 14:25:40.731386
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:25:44.018503
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    cmd_connect = Socks4Command.CMD_CONNECT
    cmd_bind = Socks4Command.CMD_BIND
    assert cmd_connect == 0x01
    assert cmd_bind == 0x02


# Generated at 2022-06-24 14:25:54.929596
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    socks4_proxy_host = '107.151.136.220'
    socks4_proxy_port = 4145
    socks5_proxy_host = '107.151.136.220'
    socks5_proxy_port = 4143
    url = 'http://example.com'
    url_port = 80
    # Test for socks4 proxy
    client = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    client.setproxy(ProxyType.SOCKS4, socks4_proxy_host, socks4_proxy_port)
    result = client.connect_ex((url, url_port))
    assert result == 0, 'Connect to socks4 proxy failed'
    # Test for socks5 proxy
    client = sockssocket(socket.AF_INET, socket.SOCK_STREAM)

# Generated at 2022-06-24 14:25:59.585108
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(2)
    except ProxyError as ex:
        assert(ex.code == 2)
        assert(ex.args[0] == 2)
        assert(ex.args[1] == b'request rejected or failed')


# Generated at 2022-06-24 14:26:01.312309
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    Socks4Error()


# Generated at 2022-06-24 14:26:03.331148
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    return Socks5Command().CMD_BIND


# Generated at 2022-06-24 14:26:04.840756
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    command = Socks5Command()
    print(command.CMD_CONNECT, command.CMD_BIND, command.CMD_UDP_ASSOCIATE)

# Generated at 2022-06-24 14:26:08.123805
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError(99, 'not authorized') == (99, 'not authorized')
    assert ProxyError(123) == (123, 'unknown error')

# Generated at 2022-06-24 14:26:09.310914
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sockssocket()



# Generated at 2022-06-24 14:26:14.978369
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    error = Socks5Error(1)
    assert error.args == (1,)
    assert error.__str__() == 'general SOCKS server failure'
    error = Socks5Error('')
    assert error.args == (0,)
    assert error.__str__() == 'unknown error'


if __name__ == '__main__':
    test_Socks5Error()

# Generated at 2022-06-24 14:26:20.202146
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    socks5 = Socks5AddressType()
    assert(socks5.ATYP_IPV4 == 0x01)
    assert(socks5.ATYP_IPV6 == 0x04)
    assert(socks5.ATYP_DOMAINNAME == 0x03)


# Generated at 2022-06-24 14:26:27.072299
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error()
    except ProxyError as e:
        assert e.args == (None, u'unknown error')

    try:
        raise Socks4Error(91)
    except ProxyError as e:
        assert e.args == (91, u'request rejected or failed')

    try:
        raise Socks4Error(97)
    except ProxyError as e:
        assert e.args == (97, u'unknown error')



# Generated at 2022-06-24 14:26:33.369615
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        # Raise Socks4Error with code 91
        raise Socks4Error(Code=91)
    except Socks4Error as e:
        assert e.args[0] == 91
        assert e.args[1] == "request rejected or failed"
    try:
        # Raise Socks4Error with code 255
        raise Socks4Error(Code=255)
    except Socks4Error as e:
        assert e.args[0] == 255
        assert e.args[1] == "unknown error"

# Generated at 2022-06-24 14:26:39.327919
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket()
    sock.connect(('localhost', 4200))
    try:
        assert sock.recvall(1) == b'x'
    except EOFError as e:
        assert str(e) == '1 bytes missing'
    finally:
        sock.close()


# Generated at 2022-06-24 14:26:44.995669
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    assert sockssocket._len_and_data(b'h') == b'\x01h'
    assert sockssocket._len_and_data(b'\x00') == b'\x01\x00'
    assert sockssocket._len_and_data(b'hello') == b'\x05hello'

    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sock.sendall(b'hello')
    data = sock.recvall(5)
    assert data == b'hello'

# Generated at 2022-06-24 14:26:51.062481
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    Socks5Error()
    Socks5Error(1)
    Socks5Error(0xFF)
    try:
        Socks5Error(0x100)
    except TypeError:
        pass
    else:
        assert False, 'TypeError not raised'


if __name__ == '__main__':
    test_Socks5Error()

# Generated at 2022-06-24 14:26:51.511933
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket()

# Generated at 2022-06-24 14:26:53.431172
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-24 14:26:56.250430
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sock = sockssocket()
    sock.setproxy(ProxyType.SOCKS5, '127.0.0.1', 4444)
    sock.connect(('ipinfo.io', 80))

# Generated at 2022-06-24 14:27:01.117040
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(type=1, host='host', port=1, username='username', password='password', remote_dns=True)
    assert proxy.type == 1
    assert proxy.host == 'host'
    assert proxy.port == 1
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns == True

# Generated at 2022-06-24 14:27:02.895846
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2

# Generated at 2022-06-24 14:27:05.834375
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:27:08.269810
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-24 14:27:17.393668
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import random
    import unittest
    import socks
    import urllib2
    import urllib

    class TestSocksSocket(unittest.TestCase):
        def test_pick_proxy_type(self):
            # Pick a random proxy type
            proxy_types = [socks.PROXY_TYPE_HTTP, socks.PROXY_TYPE_SOCKS4, socks.PROXY_TYPE_SOCKS5]
            proxy_type = random.choice(proxy_types)
            socks.setdefaultproxy(proxy_type)
            self.assertEqual(proxy_type, socks.socksocket()._proxy.type)


# Generated at 2022-06-24 14:27:23.784674
# Unit test for constructor of class ProxyType
def test_ProxyType():
    # In this test, we verify that the constructor of the class
    # ProxyType works properly. This is done by checking if we can
    # get the instance of the proxy.
    # First, we create a ProxyType instance
    sockssocket_inst = sockssocket()
    assert sockssocket_inst._proxy is None


# Generated at 2022-06-24 14:27:31.819810
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(type=ProxyType.SOCKS4, host='localhost', port=1234, username='user', password='pass', remote_dns=True)
    assert 0 == proxy[0]
    assert 'localhost' == proxy[1]
    assert 1234 == proxy[2]
    assert 'user' == proxy[3]
    assert 'pass' == proxy[4]
    assert True == proxy[5]
    assert proxy.type == 0
    assert proxy.host == 'localhost'
    assert proxy.port == 1234
    assert proxy.username == 'user'
    assert proxy.password == 'pass'
    assert proxy.remote_dns == True

    proxy2 = Proxy(type=ProxyType.SOCKS4, host='localhost', port=1234, username='user')
    assert 0 == proxy2[0]


# Generated at 2022-06-24 14:27:43.824975
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import time

    class TestSocksSocket(unittest.TestCase):
        def test_recvall(self):
            ss = sockssocket()
            ss.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)

            def mock_recv(count):
                count_recv = random.randint(0, count)
                data = random.sample(range(256), count_recv)
                return bytes(bytearray(data))

            ss.recv = mock_recv
            cnt = random.randint(1, 1000)
            with self.assertRaises(EOFError) as e:
                ss.recvall(cnt)

# Generated at 2022-06-24 14:27:46.346571
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:27:51.258123
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    socks5AddressType = Socks5AddressType()
    assert socks5AddressType.ATYP_IPV4 == 0x1
    assert socks5AddressType.ATYP_DOMAINNAME == 0x3
    assert socks5AddressType.ATYP_IPV6 == 0x4


# Generated at 2022-06-24 14:27:53.320812
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sock = sockssocket()
    sock.connect(('www.google.com', 80))
    sock.close()



# Generated at 2022-06-24 14:27:58.119805
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    class TestSockssocketRecvall(unittest.TestCase):
        def test_recvall(self):
            sock = sockssocket()
            def my_recv(size):
                return b'a'
            sock.recv = my_recv

            data = sock.recvall(10)

            self.assertEqual(data, b'aaaaaaaaaa')

    unittest.main()



# Generated at 2022-06-24 14:28:03.335267
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(None, None)
    except ProxyError as e:
        assert e.args[0] == e.args[1] == None


# Generated at 2022-06-24 14:28:13.610316
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    # No error should occur when there is no exception
    s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1080)
    s.setproxy(ProxyType.SOCKS4A, 'localhost', 1080)
    s.setproxy(ProxyType.SOCKS5, 'localhost', 1080)
    s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1080, username='username', password='password')
    s.setproxy(ProxyType.SOCKS4A, 'localhost', 1080, username='username', password='password')
    s.setproxy(ProxyType.SOCKS5, 'localhost', 1080, username='username', password='password')



# Generated at 2022-06-24 14:28:17.238191
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:28:21.863036
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 0)
    except InvalidVersionError as err:
        assert err.args[0] == 0
        assert str(err) == ('Invalid response version from server. Expected '
                            '00 got 00')
    else:
        assert False



# Generated at 2022-06-24 14:28:24.620346
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()
    print(s)

if __name__ == '__main__':
    test_sockssocket()

# Generated at 2022-06-24 14:28:33.793704
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # Create SOCKS4 proxy
    proxy_sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    proxy_sock.setproxy(
        socks5=False,
        remote_dns=False,
        addr='127.0.0.1',
        port=8080,
        username='user',
        password='pass'
    )
    # Connect to non-existing destination address
    ret = proxy_sock.connect_ex(('10.255.255.1', 80))
    assert ret != 0

# Generated at 2022-06-24 14:28:36.366467
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    try:
        assert Socks4Command.CMD_CONNECT == 1
        assert Socks4Command.CMD_BIND == 2
    except AssertionError:
        print("test_Socks4Command: AssertionError")
        return
    print("test_Socks4Command: OK")



# Generated at 2022-06-24 14:28:44.012175
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    socks = sockssocket(socket.AF_INET, socket.SOCK_STREAM)

    socks.setproxy(ProxyType.SOCKS5, 'localhost', 80)
    assert socks._proxy == Proxy(ProxyType.SOCKS5, 'localhost', 80, '', '', True)

    socks.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080, False)
    assert socks._proxy == Proxy(ProxyType.SOCKS5, '127.0.0.1', 8080, '', '', False)

    socks.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080, username='foo')

# Generated at 2022-06-24 14:28:51.665818
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    # Check if the connect method of sockssocket work fine
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    ss.setproxy(ProxyType.SOCKS5, host='127.0.0.1', port=9050)
    ss.connect(('127.0.0.1', 80))  # This test should pass when your socksproxy is connected
    # ss.connect(('127.0.0.1', 80))  # This test should fail when your socksproxy is not connected
    ss.close()


# Generated at 2022-06-24 14:28:56.466626
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert (Socks5AddressType.ATYP_IPV4 == 0x01)
    assert (Socks5AddressType.ATYP_DOMAINNAME == 0x03)
    assert (Socks5AddressType.ATYP_IPV6 == 0x04)


# Generated at 2022-06-24 14:29:02.544426
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    socks5_auth = Socks5Auth()
    assert socks5_auth.AUTH_NO_ACCEPTABLE == 0xFF
    assert socks5_auth.AUTH_NONE == 0x00
    assert socks5_auth.AUTH_USER_PASS == 0x02
    assert socks5_auth.AUTH_GSSAPI == 0x01


# Generated at 2022-06-24 14:29:05.148824
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-24 14:29:07.716689
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(91)
    except Socks4Error as e:
        assert e.strerror == 'request rejected or failed'

# Generated at 2022-06-24 14:29:09.567455
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert (Socks4Error(Socks4Error.ERR_SUCCESS).strerror == 'request rejected or failed')

# Generated at 2022-06-24 14:29:15.561009
# Unit test for constructor of class ProxyError
def test_ProxyError():
    error = ProxyError()
    assert error.errno == None

    error = ProxyError(code=0, msg='message')
    assert error.errno == 0
    assert str(error) == 'message'

    error = ProxyError(code=55, msg=None)
    assert error.errno == 55
    assert str(error) == 'unknown error'

    error = ProxyError(code=55, msg='my message')
    assert error.errno == 55
    assert str(error) == 'my message'



# Generated at 2022-06-24 14:29:16.746509
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError(None, None) is not None

# Generated at 2022-06-24 14:29:19.086184
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error.ERR_SUCCESS == 90


# Generated at 2022-06-24 14:29:24.044320
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    test_code = 0x01
    err = Socks5Error(test_code)
    assert err.args == (test_code, 'general SOCKS server failure')
    assert str(err) == 'Socks5Error(0x01, \'general SOCKS server failure\')'



# Generated at 2022-06-24 14:29:30.669727
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    s = sockssocket()
    p_type, p_host, p_port, p_rdns, p_user, p_pass = 4, 'localhost', 1080, True, '', ''
    s.setproxy(p_type, p_host, p_port, p_rdns, p_user, p_pass)
    e1 = s.connect_ex(('localhost', 80))
    assert e1 == 0
#     e2 = s.connect_ex(('localhost', 22))
#     assert e2 != 0

# Generated at 2022-06-24 14:29:39.278298
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    from unittest import TestCase
    import unittest
    import pprint
    tc = TestCase('__init__')

    # Test class Socks5Auth
    auth = Socks5Auth()
    pprint.pprint(auth)
    tc.assertEqual(auth.AUTH_NONE, 0x00)
    tc.assertEqual(auth.AUTH_GSSAPI, 0x01)
    tc.assertEqual(auth.AUTH_USER_PASS, 0x02)
    tc.assertEqual(auth.AUTH_NO_ACCEPTABLE, 0xFF)
unittest.main()

# Generated at 2022-06-24 14:29:44.336807
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(1, 2)
    except InvalidVersionError as exc:
        expected = 'Invalid response version from server. Expected 01 got 02'
        assert exc.__str__() == expected
    else:
        assert False

# Generated at 2022-06-24 14:29:47.176659
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND    == 0x02


# Generated at 2022-06-24 14:29:54.341972
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    test_socket = sockssocket()

    # Exception when recving less than expected
    test_socket.recv = lambda x: [b'\x01'][0:x]
    try:
        test_socket.recvall(2)
    except EOFError:
        pass
    else:
        print('Failed test for method recvall of class sockssocket')

    # Success when recving exactly cnt
    test_socket.recv = lambda x: [b'\x01', b'\x02'][0:x]
    if test_socket.recvall(2) == b'\x01\x02':
        pass
    else:
        print('Failed test for method recvall of class sockssocket')

    # Success when recving exactly cnt

# Generated at 2022-06-24 14:30:08.336733
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import pytest

    def mock_recv(sock, cnt):
        for i in range(cnt):
            sock.recvall_data.append(bytes(bytearray([i])))
        return b''.join(sock.recvall_data)

    def mock_recv_fail(sock, cnt):
        if len(sock.recvall_data) < cnt:
            sock.recvall_data.append(b'\x00')
            return b''.join(sock.recvall_data)
        else:
            return None

    sock = sockssocket()
    sock.recvall_data = []
    sock.recv = mock_recv

    data = sock.recvall(5)

# Generated at 2022-06-24 14:30:11.847259
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
        error_91 = Socks4Error(code=91)
        assert error_91.errno == 91
        assert str(error_91) == "request rejected or failed"

# Generated at 2022-06-24 14:30:16.407877
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    # Required: all values should be different
    assert len(set(Socks5AddressType.__dict__.values())) == len(Socks5AddressType.__dict__)


if __name__ == '__main__':
    # Unit tests
    test_Socks5AddressType()

# Generated at 2022-06-24 14:30:28.459447
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error()
    except Socks4Error as e:
        assert e.strerror == 'unknown error'
        assert e.args[0] == None
        assert e.args[1] == 'unknown error'
    try:
        raise Socks4Error(Socks4Error.ERR_SUCCESS)
    except Socks4Error as e:
        assert e.strerror == 'request accepted'
        assert e.args[0] == Socks4Error.ERR_SUCCESS
        assert e.args[1] == 'request accepted'
    try:
        raise Socks4Error(91)
    except Socks4Error as e:
        assert e.strerror == 'request rejected or failed'
        assert e.args[0] == 91

# Generated at 2022-06-24 14:30:34.069175
# Unit test for constructor of class sockssocket
def test_sockssocket():
    try:
        _socket = sockssocket(family=socket.AF_INET, type=socket.SOCK_STREAM, proto=0)
    except socket.error as error:
        _socket = None
        print('[!] Test failed: %s' % str(error))
    finally:
        if _socket is not None:
            print('[*] Test success: sockssocket used successfully!')

# Generated at 2022-06-24 14:30:43.562377
# Unit test for constructor of class ProxyType
def test_ProxyType():
    test_ProxyType_passed = True
    if (ProxyType.SOCKS4 != 0):
        print("Unit test for constructor of class ProxyType failed: ProxyType.SOCKS4 != 0")
        test_ProxyType_passed = False
    if (ProxyType.SOCKS4A != 1):
        print("Unit test for constructor of class ProxyType failed: ProxyType.SOCKS4A != 1")
        test_ProxyType_passed = False
    if (ProxyType.SOCKS5 != 2):
        print("Unit test for constructor of class ProxyType failed: ProxyType.SOCKS5 != 2")
        test_ProxyType_passed = False
    if test_ProxyType_passed:
        print("Unit test for constructor of class ProxyType passed")


# Generated at 2022-06-24 14:30:48.073600
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    proxy = Proxy(ProxyType.SOCKS5, host='localhost', port=9050, username='username', password='password')
    socks = sockssocket()
    socks.setproxy(proxy=proxy)
    try:
        ret = socks.connect(address=('www.google.com', 443))
        print(ret)
        ret = socks.recvall(1024)
        print(ret)
    except Exception as e:
        print(e)
    finally:
        socks.close()

if __name__ == '__main__':
    test_sockssocket_connect()

# Generated at 2022-06-24 14:31:03.382315
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(1, 2)
    except InvalidVersionError as err:
        assert err.args == (0, 'Invalid response version from server. Expected 1 got 2')
        assert err.msg == 'Invalid response version from server. Expected 1 got 2'
        assert err.code == 0


# Generated at 2022-06-24 14:31:07.450528
# Unit test for constructor of class ProxyError
def test_ProxyError():
    error = ProxyError(0x00, 'test')
    assert error.errno == 0x00
    assert error.strerror == 'test'
    error = ProxyError(0x00)
    assert error.errno == 0x00
    assert error.strerror == 'unknown error'



# Generated at 2022-06-24 14:31:09.082277
# Unit test for constructor of class sockssocket
def test_sockssocket():
    try:
        sockssocket()
    except:
        raise Exception('sockssocket() invocation failed')


# Generated at 2022-06-24 14:31:12.897718
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    cmd = Socks4Command()
    assert cmd.CMD_CONNECT == 0x01
    assert cmd.CMD_BIND == 0x02



# Generated at 2022-06-24 14:31:16.374283
# Unit test for constructor of class ProxyError
def test_ProxyError():
    error = ProxyError(99, "proxy error")
    assert error.args == (99, 'proxy error')

    error = ProxyError(99)
    assert error.args == (99, 'unknown error')
