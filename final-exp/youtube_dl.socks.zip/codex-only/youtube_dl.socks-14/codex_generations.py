

# Generated at 2022-06-24 14:21:23.500066
# Unit test for constructor of class sockssocket
def test_sockssocket():
    import socks

    socks5_param = {'proxy_type': socks.SOCKS5, 'addr': '172.16.32.123',
                    'port': 3128, 'username': 'teddy', 'password': '123456'}
    s = sockssocket()
    s.setproxy(**socks5_param)
    print(s._proxy)
    print(type(s))


if __name__ == '__main__':
    test_sockssocket()

# Generated at 2022-06-24 14:21:31.840987
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()

# Generated at 2022-06-24 14:21:35.021301
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2

# Generated at 2022-06-24 14:21:43.446430
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # Test SOCKS4 proxy connection
    proxy = Proxy(ProxyType.SOCKS4, '127.0.0.1', 1080)
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setproxy(*proxy)
    result = sock.connect_ex(('127.0.0.1', 22))
    assert result == 0, (
        'Unexpected result of connect_ex: {0}. Expected: 0.'.format(result))
    result = sock.connect_ex(('127.0.0.1', 0))
    assert result == 1, (
        'Unexpected result of connect_ex: {0}. Expected: 1.'.format(result))
    # Test SOCKS4A proxy connection

# Generated at 2022-06-24 14:21:45.551270
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    with sockssocket() as s:
        s.setproxy(ProxyType.SOCKS5, "localhost", 1080)
        s.connect(('1.1.1.1', 80))

# Generated at 2022-06-24 14:21:55.906809
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import time
    import random
    import string
    from random import choice as random_choice, randint as random_randint
    from random import shuffle as random_shuffle, sample as random_sample, \
        randrange as random_randrange
    a = sockssocket(socket.AF_INET, socket.SOCK_STREAM)

    def random_string(size=32, chars=string.ascii_letters + string.digits):
        return ''.join([random_choice(chars) for _ in range(size)])

    def random_ip():
        return '.'.join(map(str, (random_randint(0, 255) for _ in range(4))))

    def random_ports():
        return random_randrange(1, 65535), random_randrange(1, 65535)


# Generated at 2022-06-24 14:21:56.436037
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    Socks5Auth()

# Generated at 2022-06-24 14:22:01.009465
# Unit test for constructor of class Proxy
def test_Proxy():
    try:
        Proxy(1, "localhost", 1080, None, None, False)
    except Exception as e:
        print(e)

    try:
        Proxy(1, "localhost", 1080, "timo", "timo", False)
    except Exception as e:
        print(e)

    try:
        Proxy(1, "localhost", 1080, "timo", "timo", True)
    except Exception as e:
        print(e)



# Generated at 2022-06-24 14:22:12.797963
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import sys
    import ssl
    if sys.version_info >= (2, 7, 9):
        ssl_context = ssl.create_default_context()
        # Workaround for https://bugs.python.org/issue25624
        ssl_context.check_hostname = False
    else:
        ssl_context = None

    socks = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    socks.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, rdns=True, username='username', password='password')
    if ssl_context is not None:
        socks = ssl_context.wrap_socket(socks)
    assert socks.connect_ex(('example.com', 443)) == 0



# Generated at 2022-06-24 14:22:15.912342
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF



# Generated at 2022-06-24 14:22:22.349574
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    proxy_urls = [
        'socks5://localhost:1080',
        'socks5h://localhost:1080',
        'socks4://localhost:1080',
        'socks4a://localhost:1080',
    ]

    for url in proxy_urls:
        proxy_type, proxy_host, proxy_port, username, password = parse_proxy(url)

        socks = sockssocket()
        socks.setproxy(proxy_type, proxy_host, proxy_port, username=username, password=password)
        try:
            socks.connect(('youtube.com', 443))
        finally:
            socks.close()


# Generated at 2022-06-24 14:22:24.657244
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    s = Socks4Command()
    assert s.CMD_CONNECT == 0x01
    assert s.CMD_BIND == 0x02
    print("Socks4Command constructor passed")

# Generated at 2022-06-24 14:22:25.809322
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    print(Socks4Error.ERR_SUCCESS)



# Generated at 2022-06-24 14:22:28.956737
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(59, 97)
    except InvalidVersionError as e:
        assert(e.args[0] == 0)
        assert(e.args[1] == 'Invalid response version from server. Expected 3b got 61')


# Generated at 2022-06-24 14:22:30.469210
# Unit test for constructor of class ProxyError
def test_ProxyError():
    error = ProxyError(code=905, msg='Error Code')
    assert error.strerror == 'Error Code'



# Generated at 2022-06-24 14:22:34.024839
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 1)
    except InvalidVersionError as e:
        assert e.args[0] == 0
        print(e)
        assert str(e) == ('Invalid response version from server. Expected 00 '
                          'got 01')



# Generated at 2022-06-24 14:22:39.778212
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    assert InvalidVersionError.__doc__ == ('Invalid response version from server. Expected {0:02x} got {1:02x}'.format('expected_version','got_version'))
    assert InvalidVersionError('expected_version','got_version')

# Generated at 2022-06-24 14:22:43.358252
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(1)
    except ProxyError as e:
        assert e.code == 1
        assert e.msg == 'request rejected or failed'
        assert str(e) == 'request rejected or failed'


# Generated at 2022-06-24 14:22:51.527759
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():

    proxy = Proxy(
        proxytype=ProxyType.SOCKS5,
        host=u'localhost',
        port=8888,
        username=u'user',
        password=u'pwd',
        remote_dns=True
    )

    sockssocket().setproxy(proxy.type, proxy.host, proxy.port, proxy.remote_dns, proxy.username, proxy.password)

    from .client import Socks5Client
    Socks5Client(proxy.host, proxy.port)

    try:
        Socks5Client(proxy.host, proxy.port, username=u'', password=u'pwd')
    except Exception as e:
        print(e)
        pass


# Generated at 2022-06-24 14:23:00.729055
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    # Test when code is not None and msg is None
    socketsock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    socketsock.setproxy(ProxyType.SOCKS4, 'proxyhost', 12345, username='username', password='password')
    #socketsock.connect(('desthost', 80))
    try:
        socketsock.connect(('desthost', 80))
    except Socks4Error as se:
        print(se)
        assert se.errno == 0
        assert se.message == 'unknown error'
    else:
        assert False

    # Test when code is None and msg is not None
    socketsock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)

# Generated at 2022-06-24 14:23:03.780494
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sockssocket_connect(None)

# Generated at 2022-06-24 14:23:08.217907
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError().args == (None, None)
    assert ProxyError(code=Socks4Error.ERR_SUCCESS).args == (Socks4Error.ERR_SUCCESS, 'request rejected or failed')
    assert ProxyError(msg='hello, world').args == (None, 'hello, world')

# Generated at 2022-06-24 14:23:12.981799
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    host = '127.0.0.1'
    port = 9150
    password = 'password'
    socks = sockssocket()
    socks.setproxy(ProxyType.SOCKS5, host, port, username='user', password=password)
    socks.connect(('api.github.com', 80))
    assert socks.sendall(b'GET / HTTP/1.0\r\n\r\n') is None
    socks.close()


# Generated at 2022-06-24 14:23:13.941572
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth()


# Generated at 2022-06-24 14:23:26.008177
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    test_socket = sockssocket()
    test_socket.setproxy(ProxyType.SOCKS5, "127.0.0.1", 9150)
    test_socket.setproxy(ProxyType.SOCKS4, "127.0.0.1", 9150)
    test_socket.setproxy(ProxyType.SOCKS4A, "127.0.0.1", 9150)
    test_socket.setproxy(ProxyType.SOCKS5, "127.0.0.1", 9150, username="foo", password="bar")
    # test_socket.setproxy(ProxyType.SOCKS5, "127.0.0.1", 9150, username="foo", password="bar", remote_dns=False)

# Generated at 2022-06-24 14:23:32.823790
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    # Test attribute Socks5Auth.AUTH_NONE
    assert isinstance(Socks5Auth.AUTH_NONE, int)

    # Test attribute Socks5Auth.AUTH_GSSAPI
    assert isinstance(Socks5Auth.AUTH_GSSAPI, int)

    # Test attribute Socks5Auth.AUTH_USER_PASS
    assert isinstance(Socks5Auth.AUTH_USER_PASS, int)

    # Test attribute Socks5Auth.AUTH_NO_ACCEPTABLE
    assert isinstance(Socks5Auth.AUTH_NO_ACCEPTABLE, int)


# Generated at 2022-06-24 14:23:34.741395
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    assert isinstance(s, socket.socket)

# Generated at 2022-06-24 14:23:37.940318
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
	assert Socks5Command()

if __name__ == '__main__':
    test_Socks5Command()

# Generated at 2022-06-24 14:23:47.224360
# Unit test for constructor of class Proxy
def test_Proxy():
    assert Proxy(proxytype=ProxyType.SOCKS5,
                 host='127.0.0.1',
                 port=8080,
                 username='socksuser',
                 password='socksuser',
                 remote_dns=True) == Proxy(
        proxytype=ProxyType.SOCKS5,
        host='127.0.0.1',
        port=8080,
        username='socksuser',
        password='socksuser',
        remote_dns=True)

# Generated at 2022-06-24 14:23:49.589125
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    socks4command = Socks4Command()
    assert socks4command.CMD_CONNECT == 0x01
    assert socks4command.CMD_BIND == 0x02



# Generated at 2022-06-24 14:23:54.082309
# Unit test for constructor of class Proxy
def test_Proxy():
    assert Proxy(
        type=ProxyType.SOCKS5,
        host='127.0.0.1',
        port=1080,
        username='username',
        password='password',
        remote_dns=False
    ) is not None

# Generated at 2022-06-24 14:23:57.074245
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, 'socksproxy.example.com', 1080)
    assert s.connect_ex(('8.8.8.8', 80)) == 0
# End of unit test for method connect_ex of class sockssocket

# Generated at 2022-06-24 14:24:10.377333
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS5, '127.0.0.1', 8080, None, None, True)
    print(proxy.type)
    print(proxy.host)
    print(proxy.port)
    print(proxy.username)
    print(proxy.password)
    print(proxy.remote_dns)

if __name__ == "__main__":
    test_Proxy()

# Generated at 2022-06-24 14:24:13.200360
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    s.connect(('google.com', 80))
    s.close()


# Generated at 2022-06-24 14:24:21.355432
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():

    proxy_type = ProxyType.SOCKS5
    ip = '127.0.0.1'
    port = 9999
    remote_dns = True

    sockssocket_test = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sockssocket_test.setproxy(proxy_type, ip, port, remote_dns)

    assert sockssocket_test._proxy.host == ip
    assert sockssocket_test._proxy.port == port
    assert sockssocket_test._proxy.remote_dns == remote_dns


# Generated at 2022-06-24 14:24:27.892915
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    socks_proxy_port = 0
    with sockssocket() as sock:
        assert sock.connect_ex(('127.0.0.1', socks_proxy_port)) == 0, 'Failed to connect to SOCKS proxy'

# Run as script to run the test
if __name__ == '__main__':
    test_sockssocket_connect_ex()

# Generated at 2022-06-24 14:24:33.469798
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    code = 91
    msg = 'request rejected or failed'
    e = Socks4Error(code, msg)
    assert e.errno == code
    assert e.strerror == msg
    assert e.args == (code, msg)
    assert e.args[0] == code
    assert e.args[1] == msg
    assert str(e) == msg


# Generated at 2022-06-24 14:24:40.234004
# Unit test for constructor of class ProxyError
def test_ProxyError():
    ProxyError(code = 0, msg = 'Unknown error')
    with pytest.raises(socket.error):
        ProxyError(code = None, msg = None)
    ProxyError(code = 91, msg = None)
    ProxyError(code = None, msg = 'Unknown error')


# Generated at 2022-06-24 14:24:44.987178
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    Socks5Command.CMD_CONNECT = 0x01
    Socks5Command.CMD_BIND = 0x02
    Socks5Command.CMD_UDP_ASSOCIATE = 0x03

# Generated at 2022-06-24 14:24:50.656222
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS4, '127.0.0.1', 1080, 'username', 'password', False)
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 1080
    assert proxy.remote_dns == False
    assert proxy.username == 'username'
    assert proxy.password == 'password'


# Generated at 2022-06-24 14:24:56.448988
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    cmd = Socks5Command()
    assert cmd.CMD_CONNECT == 1
    assert cmd.CMD_BIND == 2
    assert cmd.CMD_UDP_ASSOCIATE == 3

# Generated at 2022-06-24 14:24:58.598964
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
	s = Socks5Auth()
	assert len(s) == 4, 'constructor of class Socks5Auth failed'


# Generated at 2022-06-24 14:25:11.498890
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    from .compat import compat_etree_fromstring

    proxy_addr = '127.0.0.1'
    proxy_port = 9090
    proxy_type = 'SOCKS4A'
    proxy_remote_dns = '0'
    proxy_user = 'testuser'
    proxy_pass = 'password'

    proxy_str = '{0}://{1}:{2}'.format(proxy_type, proxy_addr, proxy_port)
    if proxy_user:
        proxy_str = '{0}@{1}'.format(proxy_user, proxy_str)
    if proxy_pass:
        proxy_str = '{0}:{1}'.format(proxy_pass, proxy_str)


# Generated at 2022-06-24 14:25:14.441276
# Unit test for constructor of class ProxyError
def test_ProxyError():
    with pytest.raises(ProxyError):
        ProxyError()

    with pytest.raises(ProxyError) as e:
        ProxyError(0)

    assert e.value.args == (0, 'unknown error')

    assert ProxyError(0x00, 'test error').args == (0x00, 'test error')


# Generated at 2022-06-24 14:25:24.329806
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    _error = Socks4Error(11)
    print(str(_error))
    assert(str(_error) == 'Unknown error')

    _error = Socks4Error(91)
    print(str(_error))
    assert(str(_error) == 'request rejected or failed')

    _error = Socks4Error(92)
    print(str(_error))
    assert(str(_error) == 'request rejected because SOCKS server cannot connect to identd on the client')

    _error = Socks4Error(93)
    print(str(_error))
    assert(str(_error) == 'request rejected because the client program and identd report different user-ids')


# Generated at 2022-06-24 14:25:27.798747
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    err = Socks4Error(91)
    assert err.errno == 91
    assert err.strerror == 'request rejected or failed'
    assert err.message == 'request rejected or failed [91]'

# Generated at 2022-06-24 14:25:35.419259
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    print('Testing connect() of class sockssocket')

    # Configuration
    host = 'localhost'
    port = 1080
    timeout = 0.5
    remote_addr = 'localhost'
    remote_port = 80

    # Create socket
    client = sockssocket()

    # Set up proxy
    client.setproxy(ProxyType.SOCKS4, host, port)

    # Check for connection
    client.connect((remote_addr, remote_port))


# Generated at 2022-06-24 14:25:37.375053
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    error = Socks4Error(0)
    assert error.strerror == 'request rejected or failed'



# Generated at 2022-06-24 14:25:45.071538
# Unit test for constructor of class Proxy
def test_Proxy():
    host = 'localhost'
    port = 12345
    username = 'toto'
    password = 'tata'
    proxy_type = ProxyType.SOCKS4
    remote_dns = True
    proxy = Proxy(proxy_type, host, port, username, password, remote_dns)
    assert proxy.type == proxy_type
    assert proxy.host == host
    assert proxy.port == port
    assert proxy.username == username
    assert proxy.password == password
    assert proxy.remote_dns == remote_dns

# Generated at 2022-06-24 14:25:56.163685
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF
    assert Socks5Auth.CODES[0x01] == 'general SOCKS server failure'
    assert Socks5Auth.CODES[0x02] == 'connection not allowed by ruleset'
    assert Socks5Auth.CODES[0x03] == 'Network unreachable'
    assert Socks5Auth.CODES[0x04] == 'Host unreachable'
    assert Socks5Auth.CODES[0x05] == 'Connection refused'
    assert Socks5Auth.CODES

# Generated at 2022-06-24 14:26:09.509190
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    # Create a socks server
    socks5_server = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    # Bind and listen
    socks5_server.bind(('127.0.0.1', 9050))
    socks5_server.listen(1)
    # Connect to socks server
    socks5_client = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    socks5_client.setproxy(ProxyType.SOCKS5, '127.0.0.1', 9050)
    socks5_client.connect(('www.google.com', 80))
    # Connected successfully
    assert socks5_client.getpeername() == ('127.0.0.1', 9050)
    # Accept connection
    socks5_server_connection, _ = socks5

# Generated at 2022-06-24 14:26:11.536213
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError(0, 'error message').__str__() == '0 error message'



# Generated at 2022-06-24 14:26:15.382543
# Unit test for constructor of class ProxyError
def test_ProxyError():
    proxy_error = ProxyError(0, 'test message')
    assert proxy_error.__str__() == 'test message'
    assert proxy_error.__unicode__() == 'test message'
    print(proxy_error)



# Generated at 2022-06-24 14:26:26.876417
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    # Create a dummy socket that when recv is called it returns the
    # test string and close the socket
    class fake_sockssocket(sockssocket):
        def recv(self, howmuch):
            retval = self.test_string[:howmuch]
            self.test_string = self.test_string[howmuch:]
            if not self.test_string:
                self.close()
            return retval
    class TestSockssocketMethods(unittest.TestCase):
        # Test recvall method of sockssocket
        def test_recvall_call_recv_once(self):
            s = fake_sockssocket()
            s.test_string = 'test!'
            self.assertEqual(s.recvall(5), b'test!')


# Generated at 2022-06-24 14:26:29.986351
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    error = InvalidVersionError(6, 8)
    assert error.args[0] == 0
    assert error.args[1] == 'Invalid response version from server. Expected 06 got 08'


# Generated at 2022-06-24 14:26:33.336543
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 1080)
    s.connect_ex(('example.org', 80))
    assert isinstance(s, sockssocket)
    s.close()

# Generated at 2022-06-24 14:26:37.138681
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-24 14:26:40.229670
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError()
    assert ProxyError(1)
    assert ProxyError(2, 'test')
    assert ProxyError(code=1)
    assert ProxyError(msg='test')

# Generated at 2022-06-24 14:26:43.837549
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-24 14:26:44.436871
# Unit test for constructor of class ProxyType
def test_ProxyType():
	assert ProxyType()

# Generated at 2022-06-24 14:26:47.028692
# Unit test for constructor of class sockssocket
def test_sockssocket():
    try:
        socks = sockssocket()
    except:
        print("TEST FAILED: Unexpected error!")
    else:
        print("TEST PASSED: sockssocket()")


# Generated at 2022-06-24 14:26:50.317300
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    e = Socks5Error(Socks5Auth.AUTH_NO_ACCEPTABLE)
    assert e.errno == Socks5Auth.AUTH_NO_ACCEPTABLE


# Generated at 2022-06-24 14:26:53.584692
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-24 14:26:54.864790
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(1)
    except Socks5Error as e:
        assert e.code == 1
        assert e.args[1] == 'general SOCKS server failure'

# Generated at 2022-06-24 14:27:03.915541
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # Create a fake socks server
    test_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    test_server.bind(('', 0))
    test_server.listen(1)

    test_server_port = test_server.getsockname()[1]

    # Create a fake client
    test_client = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    test_client.setproxy(ProxyType.SOCKS4, 'localhost', test_server_port, rdns=True)

    # Connect test_client to test_server, and accept this connection on test_server
    test_client.connect(('localhost', test_server_port))
    test_server.accept()

    # The socket must be connected
    assert test_client.getpe

# Generated at 2022-06-24 14:27:09.460300
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    test_socket = sockssocket()
    assert test_socket.recvall(0) == b''

    # Hacking sockssocket to test the method recvall
    test_socket.recv = lambda cnt: b''
    try:
        test_socket.recvall(1)
        assert False, 'EOFError not raised'
    except EOFError:
        pass

    # Hacking sockssocket to test the method recvall
    test_socket.recv = lambda cnt: b'\x00' if cnt == 1 else b''
    assert test_socket.recvall(1) == b'\x00'
    assert test_socket.recvall(2) == b'\x00'

    # Hacking sockssocket to test the method recvall

# Generated at 2022-06-24 14:27:12.467801
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    assert sockssocket.setproxy.__doc__ is None
    assert sockssocket.setproxy.__defaults__ is not None
    assert len(sockssocket.setproxy.__defaults__) == 5


# Generated at 2022-06-24 14:27:17.615403
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    print('test_Socks5Command ...')
    sCmd = Socks5Command()
    print('sCmd.CMD_CONNECT=%d' % sCmd.CMD_CONNECT)
    print('sCmd.CMD_BIND=%d' % sCmd.CMD_BIND)
    print('sCmd.CMD_UDP_ASSOCIATE=%d' % sCmd.CMD_UDP_ASSOCIATE)


# Generated at 2022-06-24 14:27:22.325948
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error()
    except ProxyError as exp:
        assert type(exp) is Socks4Error
    try:
        raise Socks4Error(91)
    except ProxyError as exp:
        assert type(exp) is Socks4Error
        assert exp.code == 91
        assert exp.msg == Socks4Error.CODES[91]
    try:
        raise Socks4Error(9)
    except ProxyError as exp:
        assert type(exp) is Socks4Error
        assert exp.code == 9
        assert exp.msg == 'unknown error'


# Generated at 2022-06-24 14:27:24.111514
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    command = Socks4Command()
    print("Constructor of class Socks4Command")


# Generated at 2022-06-24 14:27:27.341391
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    command = Socks5Command()
    assert(command.CMD_CONNECT == 0x01)
    assert(command.CMD_BIND == 0x02)
    assert(command.CMD_UDP_ASSOCIATE == 0x03)



# Generated at 2022-06-24 14:27:33.693840
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    with sockssocket() as s:
        s.setproxy(ProxyType.SOCKS4, '4.4.4.4', 8888)
        assert (s._proxy.type, s._proxy.host, s._proxy.port) == (
            ProxyType.SOCKS4, '4.4.4.4', 8888)

# Generated at 2022-06-24 14:27:36.726119
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS5, 'host', port=8080, username='user',
                  password='pass', remote_dns=True)


# Generated at 2022-06-24 14:27:39.902192
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-24 14:27:51.340235
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(0x00)
    except Socks4Error as err:
        assert err.code == 0x00
        assert str(err) == 'unknown error'

    try:
        raise Socks4Error(0x5a)
    except Socks4Error as err:
        assert err.code == 0x5a
        assert str(err) == 'unknown error'

    try:
        raise Socks4Error(0x5b)
    except Socks4Error as err:
        assert err.code == 0x5b
        assert str(err) == 'request rejected or failed'

    try:
        raise Socks4Error(0x5c)
    except Socks4Error as err:
        assert err.code == 0x5c

# Generated at 2022-06-24 14:27:55.144607
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0, 'ProxyType.SOCKS4'
    assert ProxyType.SOCKS4A == 1, 'ProxyType.SOCKS4A'
    assert ProxyType.SOCKS5 == 2, 'ProxyType.SOCKS5'


# Generated at 2022-06-24 14:27:59.320368
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    # Normal conditions
    e = Socks4Error(Socks4Error.ERR_SUCCESS)
    assert str(e) == 'request rejected or failed'
    e = Socks4Error(91)
    assert str(e) == 'request rejected or failed'

    # Abnormal conditions
    e = Socks4Error(0xFF)
    assert str(e) == 'unknown error'



# Generated at 2022-06-24 14:28:05.143677
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    e = InvalidVersionError(0x04, 0x05)
    assert type(e) is InvalidVersionError
    assert e.args == (0x04, 0x05)
    assert str(e) == 'Invalid response version from server. Expected 04 got 05'


# Generated at 2022-06-24 14:28:11.301979
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS5, '127.0.0.1', 8080, 'username', 'password', True)
    assert proxy.type == ProxyType.SOCKS5
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 8080
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns


# Generated at 2022-06-24 14:28:15.806274
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 1)
    except InvalidVersionError as e:
        assert e.args[0] == 0x00
        assert e.args[1] == 'Invalid response version from server. Expected 00 got 01'

# Generated at 2022-06-24 14:28:17.541191
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    err = Socks4Error(0x91)
    assert err.args[0] == 0x91
    assert err.args[1] == 'request rejected or failed'



# Generated at 2022-06-24 14:28:23.941401
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    #try:
    assert hasattr(Socks4Command, 'CMD_CONNECT') and Socks4Command.CMD_CONNECT == 0x01
    assert hasattr(Socks4Command, 'CMD_BIND') and Socks4Command.CMD_BIND == 0x02
    #except:
    #    print("Something wrong with the constructor of class Socks4Command")


# Generated at 2022-06-24 14:28:27.156702
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    cmd = Socks5Command.CMD_CONNECT
    assert cmd == 0x01

# Generated at 2022-06-24 14:28:29.213230
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP)
    assert isinstance(s, sockssocket)


# Generated at 2022-06-24 14:28:33.507411
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03

# Generated at 2022-06-24 14:28:37.032830
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03

# Generated at 2022-06-24 14:28:44.437935
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    from .compat import is_py2
    from .compatpatcher import ClientCompatPatcher
    if not is_py2:
        raise NotImplementedError

    proxy_port = 1080
    sockssocket_instance = sockssocket()
    sockssocket_instance.setproxy(ProxyType.SOCKS4, '1.1.1.1', proxy_port)
    assert sockssocket_instance._proxy.type == ProxyType.SOCKS4
    assert sockssocket_instance._proxy.host == '1.1.1.1'
    assert sockssocket_instance._proxy.port == proxy_port

    http_proxy = 'http://1.1.1.1:80'
    sockssocket_instance = sockssocket()
    sockssocket_instance.setproxy(ProxyType.SOCKS5, http_proxy, proxy_port)


# Generated at 2022-06-24 14:28:45.080773
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sockssocket()

# Generated at 2022-06-24 14:28:50.360355
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    err = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE, None)
    print(err)
    assert err.errno == Socks5Error.ERR_GENERAL_FAILURE
    assert str(err) == 'general SOCKS server failure'


# Generated at 2022-06-24 14:28:56.917758
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    ATYP_IPV4 = 0x01
    ATYP_DOMAINNAME = 0x03
    ATYP_IPV6 = 0x04
    return Socks5AddressType.ATYP_IPV4 == ATYP_IPV4 and Socks5AddressType.ATYP_DOMAINNAME == ATYP_DOMAINNAME and Socks5AddressType.ATYP_IPV6 == ATYP_IPV6


# Generated at 2022-06-24 14:28:59.487053
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(90)
    except Socks4Error as error:
        assert error.strerror == 'request rejected or failed'
    else:
        assert False

# Generated at 2022-06-24 14:29:06.864668
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import os

    sock = sockssocket()
    sock.setblocking(True)
    sock.connect(('example.com', 80))
    sock.sendall(b'GET / HTTP/1.1\r\nHost: example.com\r\n\r\n')
    data = sock.recvall(1024)
    sock.close()
    os.write(1, data)


if __name__ == '__main__':
    test_sockssocket_recvall()

# Generated at 2022-06-24 14:29:21.240345
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 1)
    except InvalidVersionError as e:
        assert e.strerror == 'Invalid response version from server. Expected 00 got 01'


# Generated at 2022-06-24 14:29:31.399084
# Unit test for constructor of class sockssocket
def test_sockssocket():
    test_address = ('honganhvu.com', 443)

    #Test proxy type 4
    test_proxy_4 = Proxy(ProxyType.SOCKS4, '45.32.137.249', 4145, None, None, False)
    sock1 = sockssocket()
    sock1.setproxy(test_proxy_4.type, test_proxy_4.host, test_proxy_4.port)
    sock1.connect(test_address)
    sock1.close()

    #Test proxy type 4a
    test_proxy_4a = Proxy(ProxyType.SOCKS4A, '45.32.137.249', 4145, None, None, True)
    sock2 = sockssocket()

# Generated at 2022-06-24 14:29:34.770997
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 is not None
    assert ProxyType.SOCKS4A is not None
    assert ProxyType.SOCKS5 is not None


# Generated at 2022-06-24 14:29:38.043458
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    address_type = Socks5AddressType()
    assert address_type.ATYP_IPV4==1
    assert address_type.ATYP_DOMAINNAME==3
    assert address_type.ATYP_IPV6==4

# Generated at 2022-06-24 14:29:50.132767
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    # SOCKS4 test

    sock = sockssocket()
    sock.setproxy(ProxyType.SOCKS4, '127.0.0.1', 9050)
    sock.connect(('www.google.com', 80))
    sock.close()

    # SOCKS4A test

    sock = sockssocket()
    sock.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 9050)
    sock.connect(('www.google.com', 80))
    sock.close()

    # SOCKS5 test

    sock = sockssocket()
    sock.setproxy(ProxyType.SOCKS5, '127.0.0.1', 9050)
    sock.connect(('www.google.com', 80))
    sock.close()



# Generated at 2022-06-24 14:29:55.893024
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError().code == None and ProxyError().strerror == None
    assert ProxyError(code=1).code == 1 and ProxyError(code=1).strerror == None
    assert ProxyError(msg='message').code == None and ProxyError(msg='message').strerror == 'message'
    assert ProxyError(code=1, msg='message').code == 1 and ProxyError(code=1, msg='message').strerror == 'message'

# Generated at 2022-06-24 14:29:58.384030
# Unit test for constructor of class Proxy
def test_Proxy():
    sockssocket().setproxy(2, 'www.example.com', 80, True, 'user', 'pass')

# Generated at 2022-06-24 14:30:01.257698
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF

# Generated at 2022-06-24 14:30:04.349772
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert type(Socks5AddressType) == type



# Generated at 2022-06-24 14:30:06.448824
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error()
    except Socks5Error as e:
        assert(e.args == (None,))

if __name__ == '__main__':
    test_Socks5Error()

# Generated at 2022-06-24 14:30:10.010834
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    s = sockssocket()
    s.setproxy(socks.PROXY_TYPE_SOCKS5, '127.0.0.1', 9050)
    status = s.connect_ex(('google.com', 443))
    if status == 0:
        print('Connection success!')
    else:
        print('Connection failed!')

if __name__ == '__main__':
    test_sockssocket_connect_ex()

# Generated at 2022-06-24 14:30:15.559190
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND


if __name__ == '__main__':
    # Test for constructor of class Socks5Command
    test_Socks5Command()

# Generated at 2022-06-24 14:30:18.102262
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()
    assert(isinstance(s, sockssocket))
    assert(isinstance(s, socket.socket))


# Generated at 2022-06-24 14:30:21.110933
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    ss = sockssocket()
    ss.setproxy(ProxyType.SOCKS4, 'localhost', 8080)
    ss.connect(('example.com', 80))
    ss.close()

# Generated at 2022-06-24 14:30:27.046678
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 0, True)
    assert s._proxy.username is None
    assert s._proxy.password is None
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 0, True, 'username', 'password')
    assert s._proxy.username == 'username'
    assert s._proxy.password == 'password'


# Generated at 2022-06-24 14:30:30.915517
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        Socks5Error(Socks5Auth.AUTH_NO_ACCEPTABLE)
    except ProxyError as exc:
        assert exc.args[1] == 'all offered authentication methods were rejected'


if __name__ == '__main__':
    test_Socks5Error()

# Generated at 2022-06-24 14:30:40.751356
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(None)
    except ProxyError as e:
        try: assert e.code == None
        except AssertionError: print('assertion error for code of Socks4Error')
        try: assert e.msg == 'Unknown error code'
        except AssertionError: print('assertion error for msg of Socks4Error')
    else: print('Socks4Error does not run exception when code is None')

    try:
        raise Socks4Error(91)
    except ProxyError as e:
        try: assert e.code == 91
        except AssertionError: print('assertion error for code of Socks4Error')
        try: assert e.msg == 'request rejected or failed'
        except AssertionError: print('assertion error for msg of Socks4Error')

# Generated at 2022-06-24 14:30:50.409057
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    a = Socks5Error(code=0x02)
    b = Socks5Error(code=0x03)
    c = Socks5Error(code=0x04)
    d = Socks5Error(code=0x05)
    e = Socks5Error(code=0x06)
    f = Socks5Error(code=0x07)
    g = Socks5Error(code=0x08)
    h = Socks5Error(code=0xFE)
    i = Socks5Error(code=0xFF)
    j = Socks5Error(code=0x99)


# Generated at 2022-06-24 14:31:02.485915
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    import sys
    import socks
    proxytype = None
    proxyaddr = None
    proxyport = None
    rdns = None
    username = None
    password = None
    # use a proxy
    proxytype = socks.PROXY_TYPE_SOCKS5
    proxyaddr = '127.0.0.1'
    proxyport = '9050'
    rdns = True
    username = 'root'
    password = 'root'
    socks.set_default_proxy(proxytype=proxytype, addr=proxyaddr, port=proxyport, rdns=rdns, username=username, password=password)
    # connect to socket
    remotehost = 'www.python.org'
    remoteport = 80
    remotesock = socks.socksocket()
    remotesock.settimeout(10)
   

# Generated at 2022-06-24 14:31:05.484578
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(0)
    except ProxyError as e:
        pass
    assert e.args[0] == 0
    assert e.args[1] == 'unknown error'


# Generated at 2022-06-24 14:31:06.431310
# Unit test for constructor of class ProxyType
def test_ProxyType():
    pass

if __name__ == '__main__':
    test_ProxyType()

# Generated at 2022-06-24 14:31:09.001409
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    ss.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080)
    ss.connect(('www.google.com', 80))

# Generated at 2022-06-24 14:31:10.256274
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()
    assert s.fileno() >= 0


# Generated at 2022-06-24 14:31:13.561634
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    e = Socks4Error(0x01)
    assert(e.args[0] == 0x01)
    assert(e.args[1] == 'request rejected or failed')
    e = Socks4Error(0x00)
    assert(e.args[0] == 0x00)
    assert(e.args[1] == 'unknown error')

# Generated at 2022-06-24 14:31:19.012092
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    test = Socks5AddressType()
    assert test.ATYP_IPV4 == 0x01, 'Failed to assign value to ATYP_IPV4'
    assert test.ATYP_DOMAINNAME == 0x03, 'Failed to assign value to ATYP_DOMAINNAME'
    assert test.ATYP_IPV6 == 0x04, 'Failed to assign value to ATYP_IPV6'
