

# Generated at 2022-06-26 13:54:57.018399
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    socks_socket = sockssocket()

    # Test fail case 1, 2 and 3
    # Test fail case 1:
    # SOCKS server error
    socks_socket.connect(('localhost', 8080))
    try:
        socks_socket.recvall(10)
    except EOFError as e:
        assert unicode(e) == '10 bytes missing'
    else:
        assert False

    # Test fail case 2: not connected
    try:
        socks_socket.recvall(10)
    except socket.error as e:
        assert e.errno == 9 and e.strerror == 'Bad file descriptor'
    else:
        assert False

    # Test fail case 3: socket timeout
    socks_socket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    socks_socket

# Generated at 2022-06-26 13:54:58.773997
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 0)
        assert False
    except InvalidVersionError as e:
        assert True


# Generated at 2022-06-26 13:55:07.185908
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # WS_ACCEPTED = 0
    # AF_INET = 2
    conn = sockssocket(2, 0)
    conn.setproxy(ProxyType.SOCKS5, "127.0.0.1", 8080)
    conn.connect(("127.0.0.1", 8888))
    conn.sendall(b"GET / HTTP/1.1\r\nHost: www.bilibili.com\r\n\r\n")
    packet = conn.recvall(1024)
    #print(packet)
#test_sockssocket_recvall()
#    print("proxy type is:", proxy_type_0)
#test_sockssocket_recvall()
#test_sockssocket_recvall()
#test_sockssocket_recvall()
#test

# Generated at 2022-06-26 13:55:13.300737
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    s.connect(('www.google.com', 80))

    request = (
        'GET / HTTP/1.1\r\n'
        'Host: www.google.com\r\n'
        'Connection: close\r\n'
        '\r\n'
    )
    s.sendall(request.encode('utf-8'))

    while True:
        received = s.recvall(1024)
        if not received:
            break
    s.close()


# Generated at 2022-06-26 13:55:14.099503
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    test_socket = sockssocket()



# Generated at 2022-06-26 13:55:16.792228
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s0 = sockssocket()
    # No parameter should raise EOFError
    with pytest.raises(EOFError):
        s0.recvall()


# Generated at 2022-06-26 13:55:20.634474
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock_0 = sockssocket()
    cnt_0 = 0
    data_0 = sock_0.recvall(cnt_0)
    assert (data_0 == '')


# Generated at 2022-06-26 13:55:29.514414
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import logging
    import sys
    import time
    import unittest


# Generated at 2022-06-26 13:55:30.337084
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    InvalidVersionError(0, 1)


# Generated at 2022-06-26 13:55:31.188954
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    InvalidVersionError(45, 56)


# Generated at 2022-06-26 13:55:48.247402
# Unit test for method recvall of class sockssocket

# Generated at 2022-06-26 13:55:56.582182
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    print('Test recvall')
    # Create a mock response for testing
    _response = 'HTT\x80\x04\x00\x01h\x00\x00\x00hello'
    _length = len(_response)
    
    # Create a mock socket object and configure it to have recv(n) method
    # which will return a part of the response string
    mock_socket = sockssocket()
    mock_socket.connect_ex = lambda x: None
    def recv(_n):
        nonlocal _response, _length
        ret = _response[0:_n]
        _response = _response[_n:]
        _length -= _n
        return ret
    mock_socket.recv = recv

    # Recvall should read all remaining bytes after the first read
    mock_socket.recvall

# Generated at 2022-06-26 13:55:58.665235
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Init a sockssocket object
    sock = sockssocket()

    # Compare the recvall result with the expected value
    assert sock.recvall == 1

# Generated at 2022-06-26 13:56:09.405436
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Initialization
    socks = sockssocket()

    # Test case 0
    # 1. Create a socket
    # 2. Assign it to the variable 'socks'
    # 3. Send some data to the socket
    # 4. Receive all the data sent to the socket and assign it to the variable 'data'
    # 5. Check whether the type of variable 'data' is binary
    # 6. Check whether the variable 'data' contains the data we have sent
    # 7. Close the connection

    # Test case 1
    # 1. Create a socket
    # 2. Assign it to the variable 'socks'
    # 3. Send some data to the socket
    # 4. Receive all the data sent to the socket and break the connection while receiving
    # 5. Check whether the expected error has occured
    # 6. Check whether the variable '

# Generated at 2022-06-26 13:56:11.820249
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    server = sockssocket()
    response = server.recvall(8)
    assert len(response) == 8


# Generated at 2022-06-26 13:56:14.546018
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket()
    assert sock.recvall(12) == b''
    sock.close()


# Generated at 2022-06-26 13:56:21.263563
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Test 1:
    # Create a test sockssocket instance
    # Send 1 byte to the socket
    # Receives the all the bytes from the socket
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    s.connect(s.getsockname())
    s.send(b'a')
    assert s.recvall(1) == b'a'
    s.close()


# Generated at 2022-06-26 13:56:22.806432
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    ssc = sockssocket()
    ssc.recvall(1)

# Generated at 2022-06-26 13:56:24.274167
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.recvall(1)


# Generated at 2022-06-26 13:56:27.129881
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.recvall(0)

if __name__ == '__main__':
    test_case_0()
    test_sockssocket_recvall()

# Generated at 2022-06-26 13:56:46.582787
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(('localhost', 5432))
    recv_bytes = sock.recvall(1)
    sock.close()
    assert len(recv_bytes) == 0


# Generated at 2022-06-26 13:56:51.055093
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    x = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        x.connect(("www.google.com", 80))
        data = x.recvall(1024)
        assert data[0] == 0x47
    except EOFError:
        print("EOFError")   
    finally:
        x.close() 


# Generated at 2022-06-26 13:56:57.057749
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    dest = 'google.com'
    port = 80
    s.setproxy(ProxyType.SOCKS5, 'localhost', 9050)
    s.connect((dest, port))
    s.sendall(b'HEAD / HTTP/1.0\r\n\r\n')
    # Make sure that the call to recvall does not block
    data = s.recvall(40)

if __name__ == '__main__':
    test_sockssocket_recvall()

# Generated at 2022-06-26 13:56:57.970290
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    a = sockssocket()
    a.setproxy()
    a.recvall(12)


# Generated at 2022-06-26 13:57:01.063375
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    try:
        s = sockssocket()
        r = s._recv_bytes(2)
    except Exception as e:
        print("Error: {}".format(e))
    print("Test Case 0: {}".format(r))



# Generated at 2022-06-26 13:57:11.125029
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import socket
    import unittest
    import ssl
    from socks5man import sockssocket
    from socks5man.socks import sockssocket as sockssocket_0
    from socks5man.socks import sockssocket as sockssocket_1
    from socks5man.socks import sockssocket as sockssocket_2
    from socks5man.socks import sockssocket as sockssocket_3


# Generated at 2022-06-26 13:57:13.566628
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    proxy_sockssocket_0 = sockssocket()
    str_0 = proxy_sockssocket_0.recvall(1)


# Generated at 2022-06-26 13:57:14.465014
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Test for raising EOFError
    pass



# Generated at 2022-06-26 13:57:22.796367
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    SOCKET_RECVALL_ERROR_CASE = 1
    SOCKET_RECVALL_SUCCESS_CASE = 2
    SOCKET_RECVALL_TEST_CASE = SOCKET_RECVALL_ERROR_CASE

    # Error case
    if SOCKET_RECVALL_TEST_CASE == SOCKET_RECVALL_ERROR_CASE:
        # Server side
        server_s = sockssocket()
        server_s.bind(("", 0))
        server_s.listen(1)
        port = server_s.getsockname()[1]
        # Client side
        client_s = sockssocket()
        client_s.connect(("localhost", port))
        server_s.settimeout(5)

# Generated at 2022-06-26 13:57:24.548877
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    socket_0 = sockssocket()
    socket_0.close()


# Generated at 2022-06-26 13:58:35.683815
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    test_socket = sockssocket()
    assert_equals(test_socket.recvall(0),b'')


# Generated at 2022-06-26 13:58:40.754387
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    block_size = 1024
    # create a file
    f = open("bla.txt", "w")
    # write some content to file
    f.write("Hello World!")
    # close file
    f.close()
    # read file
    f = open("bla.txt", "r")
    # read content from file
    text = f.read()
    # close file
    f.close()
    # create socket
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    # connect
    s.connect_ex(("127.0.0.1", 7777))
    # send random data
    s.sendall(text)
    # receive same random data
    text2 = s.recvall(len(text))
    # assert equal
    assert text == text

# Generated at 2022-06-26 13:58:46.635590
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Create a new sockssocket instance
    ssock = sockssocket()
    # Set proxy
    ssock.setproxy(ProxyType.SOCKS4, 'localhost', 8080)
    ssock.connect(('localhost', 8080))

    # Try to call recvall(cnt)
    # Not implemented in Python 3
    #result = ssock.recvall(cnt)



# Generated at 2022-06-26 13:58:50.842397
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    ss = sockssocket()
    string = "hello world"
    ss.sendall(string)
    assert ss.recvall(len(string)) == string
    try:
        ss.recvall(len(string) + 1)
        assert False
    except EOFError:
        pass


# Generated at 2022-06-26 13:58:59.093460
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # create inet socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    # bind socket to address localhost:9000
    s.bind(('localhost', 9000))
    # listen for incomming connections
    s.listen(1)
    # create sockssocket
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    # connect to inet socket
    ss.connect(('localhost', 9000))
    # accept incoming connection
    sock, addr = s.accept()
    # send string 'test' to connected socket
    sock.send('test')
    # receive all bytes of string 'test' from connected socket
    # this should

# Generated at 2022-06-26 13:59:05.334902
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Test normal operation
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(('127.0.0.1', 80))
    s.sendall(b'GET / HTTP/1.0\r\n\r\n')
    data = s.recvall(1000)
    assert data.startswith(b'HTTP/')

    # Test raise
    try:
        s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(('127.0.0.1', 80))
        s.sendall(b'GET / HTTP/1.0\r\n\r\n')
        data = s.recvall(1000)
    except Exception as e:
        pass
    assert e.args[0]

# Generated at 2022-06-26 13:59:15.105726
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Create a socket
    try:
        new_socket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    except socket.error:
        print('Failed to create socket')
        sys.exit()

    # Serverside:
    # Read data from client and echo it back
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(('127.0.0.1', 8081))
    s.listen(1)
    conn, addr = s.accept()
    print('Connected by', addr)
    while True:
        data = conn.recv(1024)
        if not data: break

# Generated at 2022-06-26 13:59:18.194174
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # test for normal case
    sockssocket_instance = sockssocket()
    bytes_to_recv = 10
    #assert sockssocket_instance._recv_bytes(bytes_to_recv) == b""
    # test for exception case
    #assert True # TODO: implement your test here



# Generated at 2022-06-26 13:59:21.039424
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Create a socket object.
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Connect the socket to the port where the server is listening
    server_address = ('localhost', 80)
    print('connecting to %s port %s' % server_address)
    sock.connect(server_address)

# Generated at 2022-06-26 13:59:23.397684
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Create a sockssocket object
    ss = sockssocket()
    # Set a buffer of 1 byte
    ss.setbuffer(1)
    # Send one byte
    ss.sendall(b'a')
    # Shouldn't raise an exception
    ss.recvall(1)


# Generated at 2022-06-26 14:00:36.857995
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import random
    import sys
    import unittest

    sys.path.insert(0, '../')
    import socks as _socks

    class TestSocket(object):
        def __init__(self, log_socket_input=False):
            self.log = log_socket_input
            self.buffer = bytes(bytearray(random.randint(1, 100)))
            self.buffer_pos = 0
            self.closed = False

        def recv(self, size):
            if self.buffer_pos == len(self.buffer):
                return b''
            result = bytearray()
            while len(result) < size and self.buffer_pos < len(self.buffer):
                result.append(self.buffer[self.buffer_pos])
                self.buffer_pos += 1

# Generated at 2022-06-26 14:00:38.976125
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.recvall(1)


# Generated at 2022-06-26 14:00:45.572674
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Test for case when everything works normally
    socks = sockssocket()
    assert b'' == socks.recvall(0)
    assert b'a' == socks.recvall(1)

    # Test for when server returns less than required bytes
    def throw_eof_incomplete(count):
        raise EOFError
    socks.recv = throw_eof_incomplete
    try:
        socks.recvall(2)
    except EOFError:
        pass
    else:
        raise AssertionError('Failed to raise EOFError')


# Generated at 2022-06-26 14:00:49.949062
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s4 = sockssocket()
    try:
        s4.connect(('www.google.com', 80))
    except:
        pass
    # Simply check if recvall terminates normally or not
    a = s4.recvall(2)

# Generated at 2022-06-26 14:00:51.694000
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Create a socket
    s = sockssocket()

    # Test if recvall method works well
    s.recvall(2)


# Generated at 2022-06-26 14:00:55.148460
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    test_socks = sockssocket()
    test_socks.setblocking(0)
    data = test_socks.recvall(0)
    if data:
        print("PASS")
    else:
        print("FAIL")


# Generated at 2022-06-26 14:01:01.938804
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Build a dummy socket to test that recvall calls recv()
    # enough times to read the required number of bytes.
    class MockSocket(object):
        def __init__(self, recv_bytes):
            self.recv_bytes = recv_bytes
            self.i = 0

        def recv(self, cnt):
            if self.i >= len(self.recv_bytes):
                return ''
            self.i += 1
            if self.i == len(self.recv_bytes):
                return self.recv_bytes[self.i - 1]
            return self.recv_bytes[self.i - 1] + self.recv_bytes[self.i]

    recv_bytes = [b'12', b'34', b'56', b'78', b'90']
   

# Generated at 2022-06-26 14:01:05.281483
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    ssocket = sockssocket()
    data_expected = b''
    ssocket.recvall(10)
    data = ssocket.recvall(10)
    assert data == data_expected


# Generated at 2022-06-26 14:01:06.363591
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.recvall(10)


# Generated at 2022-06-26 14:01:13.333225
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Initialize a socket instance and a mock receiver
    sock = sockssocket()
    receiver = mock.Mock()

    # Test EOFError when not enough data is received
    receiver.recv.side_effect = [b'abc\n', b'']

    with raises(EOFError):
        sock.recvall(5)

    # Test EOFError when too much data is received
    receiver.reset_mock()
    receiver.recv.side_effect = [b'abc\ndef\n', b'ghi\n']

    with raises(EOFError):
        sock.recvall(5)

    receiver.assert_has_calls([mock.call(5), mock.call(5), mock.call(1)])

    # Test success when enough data is received
    receiver.reset_mock()

# Generated at 2022-06-26 14:02:51.063451
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import mock
    import httplib

    with mock.patch('httplib.HTTPConnection._http_vsn', 9):
        with mock.patch('httplib.HTTPConnection._http_vsn_str', 'HTTP/0.9'):
            # Simulate a response with 2 Headers and 1 content
            resp_contents = (b'HTTP/0.9 200 OK\r\nContent-Type: text/html\r\nContent-Length: 20\r\n\r\nHello World!\r\n')
            # create a socket
            s = sockssocket()
            # mock the recvall method

# Generated at 2022-06-26 14:02:57.394625
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    def test_case_1():
        with sockssocket() as s:
            try:
                s.recvall(1)
            except EOFError:
                pass
    def test_case_2():
        with sockssocket() as s:
            s.sendall(b'a')
            assert(s.recvall(1) == b'a')

    test_case_1()
    test_case_2()


# Generated at 2022-06-26 14:03:03.913944
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():

    # Test that an exception is raised when recvall is called on an invalid file descriptor
    with pytest.raises(OSError) as excinfo:
        sockssocket.recvall(-1, 10)
    assert excinfo.type == OSError

    # Test that an exception is raised when recvall is called without specifying a file descriptor
    with pytest.raises(AttributeError) as excinfo:
        sockssocket.recvall(10)
    assert excinfo.type == AttributeError

# Generated at 2022-06-26 14:03:10.363524
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import os
    import threading
    from wsgiref.simple_server import make_server, demo_app
    def run_server(port):
        httpd = make_server('localhost', port, demo_app)
        httpd.serve_forever()
    server_thread = threading.Thread(target=run_server, args=(8080,))
    server_thread.daemon = True
    server_thread.start()
    sockssocket()

if __name__ == '__main__':
    test_sockssocket_recvall()

# Generated at 2022-06-26 14:03:17.031157
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    class MockSocket(object):

        def recv(self, cnt):
            if self.recv_counter == 0:
                self.recv_counter = self.recv_counter + 1
                return b'111'
            elif self.recv_counter == 1:
                self.recv_counter = self.recv_counter + 1
                return b'222'
            elif self.recv_counter == 2:
                self.recv_counter = self.recv_counter + 1
                return b'333'
            else:
                return b''

        def __init__(self):
            self.recv_counter = 0

    socket = MockSocket()
    s = sockssocket(socket.family, socket.type, socket.proto, _sock=socket)
    s.recvall(6)

# Generated at 2022-06-26 14:03:25.999334
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    t = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    t.bind(('', 0))
    t.listen(1)
    accept_sock, addr = t.accept()
    accept_sock.send(b'\x00\x01\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01')
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((addr[0], addr[1]))
    try:
        version, resp_code, dstport, dsthost = compat_struct_unpack('!BBHI', s.recvall(8))
    except EOFError as e:
        print(e)

# Generated at 2022-06-26 14:03:35.390339
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    try:
        s = sockssocket()
        host = 'www.google.com'
        port = 80
        s.connect((host, port))
        http_request = 'GET / HTTP/1.0\r\nHost: %s\r\n\r\n' % (host)
        s.sendall(http_request.encode('utf-8'))
        http_response = b''
        while True:
            data = s.recv(1024)
            if not data:
                break
            http_response += data
        s.close()
        assert http_response.decode('utf-8').find('<HTML>') > 0
    except:
        traceback.print_exc()
        assert(False)

# Generated at 2022-06-26 14:03:44.551464
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import os
    import errno
    import socket
    from .compat import compat_struct_pack
    from .compat import compat_struct_unpack
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socksock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)

# Generated at 2022-06-26 14:03:52.010077
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    data = b'123456789'
    buffer = b'123456789ABCDEF'
    buffer_len = len(buffer)
    remaining_len = buffer_len - len(data)
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(('www.google.com', 80))
    sock.recvall = lambda cnt: buffer[:cnt]
    assert data == sock.recvall(buffer_len)
    assert data == sock.recvall(remaining_len)
    assert remaining_len < 0
    sock.close()


# Generated at 2022-06-26 14:03:56.810566
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    """
    Unit test for recvall method of class sockssocket
    """
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 8089)
    s.connect(('localhost', 9090))
    s.sendall(b'hello')
    assert s.recvall(5) == b'hello'

