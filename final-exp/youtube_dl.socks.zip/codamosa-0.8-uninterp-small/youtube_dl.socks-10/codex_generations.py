

# Generated at 2022-06-26 13:54:45.305277
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random
    import struct
    ports = random.sample(range(1, 65535), 5)
    host = '127.0.0.1'
    size = 100

    def create_data(size, host, port):
        data = struct.pack('!I', size)
        data += struct.pack('!I', socket.inet_aton(host))
        data += struct.pack('!H', port)
        data += b'a' * size
        return data

    class sockstest(sockssocket):
        def __init__(self, family, type_):
            super(sockstest, self).__init__(family, type_)
        def _makesock(self, address):
            self.recvsock = socket.socket(self.family, self.type)
            self

# Generated at 2022-06-26 13:54:50.029916
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    print("test_sockssocket_recvall start")
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.recvall(1)
    return True
    print("test_sockssocket_recvall end")

if __name__ == '__main__':
    print("socks.py")
    # test_sockssocket_recvall()

# Generated at 2022-06-26 13:54:57.630075
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    proxy_list = (
        Proxy(ProxyType.SOCKS4, '127.0.0.1', 8080),
        Proxy(ProxyType.SOCKS4A, '127.0.0.1', 8080, 'user', 'pass'),
        Proxy(ProxyType.SOCKS5, '127.0.0.1', 8080),
        Proxy(ProxyType.SOCKS5, '127.0.0.1', 8080, 'user', 'pass'),
    )
    for proxy in proxy_list:
        ss = sockssocket()
        ss.setproxy(*proxy)
        assert ss._proxy == proxy


if __name__ == '__main__':
    test_sockssocket_setproxy()

# Generated at 2022-06-26 13:54:58.774260
# Unit test for constructor of class ProxyError
def test_ProxyError():
    err = ProxyError(code=123, msg='msg')


# Generated at 2022-06-26 13:55:05.917804
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    ss = sockssocket()
    ss.setproxy('', '', 0)
    ss.setproxy('', '', 0, False)


if __name__ == '__main__':
    import sys
    import unittest

    class Tests(unittest.TestCase):

        def test_case_0(self):
            test_case_0()

        def test_sockssocket_setproxy(self):
            test_sockssocket_setproxy()

    res = unittest.main(argv=sys.argv[:1], exit=False, verbosity=1)
    sys.exit(res.result.testsRun)

# Generated at 2022-06-26 13:55:11.963159
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    print("Unit test for sockssocket.setproxy")
    socks5_address_type_0 = Socks5AddressType()
    socks5_address_type_0.ATYP_IPV6 = 0x04
    socks5_address_type_0.ATYP_IPV4 = 0x01
    socks5_address_type_0.ATYP_DOMAINNAME = 0x03
    socks5_auth_0 = Socks5Auth()
    socks5_auth_0.AUTH_USER_PASS = 0x02
    socks5_auth_0.AUTH_GSSAPI = 0x01
    socks5_auth_0.AUTH_NO_ACCEPTABLE = 0xFF
    socks5_auth_0.AUTH_NONE = 0x00

# Generated at 2022-06-26 13:55:16.426916
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import os
    import random
    import select
    import string
    import sys
    import unittest
    try:
        from unittest.mock import patch, Mock
    except ImportError:
        from mock import patch, Mock

    try:
        from unittest.mock import create_autospec
    except ImportError:
        from mock import create_autospec

    def _add_data(fd, data):
        os.write(fd, data)

    def _select(fd, timeout=0.0):
        return select.select([fd], [], [], timeout)[0]

    def _recv(fd, size):
        return os.read(fd, size)


# Generated at 2022-06-26 13:55:27.047394
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    ss = sockssocket()
    assert(ss._proxy is None)

    ss.setproxy(ProxyType.SOCKS4, '10.0.0.0', 8080)
    assert(ss._proxy.type == ProxyType.SOCKS4)
    assert(ss._proxy.host == '10.0.0.0')
    assert(ss._proxy.port == 8080)
    assert(ss._proxy.username is None)
    assert(ss._proxy.password is None)
    assert(ss._proxy.remote_dns is True)

    ss.setproxy(ProxyType.SOCKS4A, '10.0.0.0', 8080, False, 'usr', 'pwd')
    assert(ss._proxy.type == ProxyType.SOCKS4A)

# Generated at 2022-06-26 13:55:31.565364
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    from io import BytesIO
    from io import SEEK_CUR
    s = sockssocket()
    s.connect(("http://abc.com",80))
    data=b"http://www.baidu.com"
    length=len(data)
    data_return=s.recvall(length)
    data_return_real=b''
    while length > 0:
        data_return_real=s.recv(length)
        length=length-len(data_return_real)
    assert(data_return == data_return_real)


# Generated at 2022-06-26 13:55:33.307511
# Unit test for constructor of class ProxyError
def test_ProxyError():
    proxy_error = ProxyError()
    assert proxy_error

# Generated at 2022-06-26 13:55:46.403531
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    proxy_type_0 = ProxyType.SOCKS5
    str_0 = 'z.p[@!0r)-3"f0bxF'
    int_0 = sock.connect_ex(str_0)
    # assert that the second parameter is of type str
    assert isinstance(socks4a_error_0, str)
    sock.setproxy(proxy_type_0, str_0, int_0)



# Generated at 2022-06-26 13:55:50.127592
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    ss_0 = sockssocket()
    str_0 = 'M'
    int_0 = 12
    str_1 = ':=5'
    str_2 = 'x)Dkp'
    str_3 = 'E*4`'
    ss_0.setproxy(str_0, int_0, str_1, str_2, str_3)


# Generated at 2022-06-26 13:55:53.533729
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock_0 = sockssocket(
        socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_SCTP)
    cnt_0 = 42
    with pytest.raises(Exception):
        sock_0.recvall(cnt_0)


# Generated at 2022-06-26 13:56:00.774518
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    sockssocket_0 = sockssocket()
    str_0 = 'Rq:'
    socks5_error_0 = Socks5Error(str_0)
    remote_dns_0 = socks5_error_0
    str_1 = '<g3q1l'
    username_0 = str_1
    str_2 = '*hU6Fa'
    password_0 = str_2
    sockssocket_0.setproxy(ProxyType.SOCKS4A, 'e', 'T<#i&', remote_dns_0, username_0, password_0)


# Generated at 2022-06-26 13:56:04.953673
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    sockssocket_instance = sockssocket()
    sockssocket_setproxy_ret = sockssocket_instance.setproxy(
        ProxyType.SOCKS5, '', 0, True, None, None)
    assert sockssocket_setproxy_ret is None



# Generated at 2022-06-26 13:56:13.682159
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    str_0 = 'c'  # str
    str_1 = 'H'  # str
    str_2 = '<'  # str
    str_3 = '^'  # str
    str_4 = 'c'  # str

    # Constructor for class sockssocket
    sockssocket_0 = sockssocket()
    assert sockssocket_0 is not None

    # Method setproxy of class sockssocket
    sockssocket_0.setproxy(str_0, str_1, str_2, str_3, str_4, str_5)

# Generated at 2022-06-26 13:56:24.105363
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sockssocket_0 = sockssocket()
    socket_0 = socket()
    str_0 = 'Rq:'
    try:
        sockssocket_0.recvall(str_0)
        assert False
    except EOFError:
        assert True
    str_1 = ';'
    sockssocket_1 = sockssocket()
    int_0 = 1
    int_1 = 2
    try:
        assert sockssocket_1.recvall(int_0) == sockssocket_1.recvall(int_1), 'AssertionError: {0} == {1}'.format(sockssocket_1.recvall(int_0), sockssocket_1.recvall(int_1))
    except EOFError:
        assert True
    socket_1 = socket()

# Generated at 2022-06-26 13:56:32.492691
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    print("Testing sockssocket.setproxy")
    str_0 = 'Rq:'
    socks4_error_0 = Socks4Error(str_0)
    assert isinstance(socks4_error_0, ProxyError)
    str_1 = 'Rq:'
    socks5_error_0 = Socks5Error(str_1)
    assert isinstance(socks5_error_0, ProxyError)

    status = sockssocket.setproxy(None, socks4_error_0, str_0, True, str_1, str_0)
    assert status is None

if __name__ == '__main__':
    # unit tests
    test_case_0()
    test_sockssocket_setproxy()

    # test code
    s = sockssocket()

# Generated at 2022-06-26 13:56:33.712143
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    ss0 = sockssocket()
    bufsize = 1
    msg_0 = ss0.recvall(bufsize)

# Generated at 2022-06-26 13:56:43.840547
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    str_0 = 'T3\x1c\r\x80'
    sockssocket_0 = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    str_1 = '\x1c\xaf\xaf\xbd'
    str_2 = '\xe1\x83t\x1d\x98\xf9\xd0\xcc\xed\x99'
    try:
        sockssocket_0.connect((str_1, 11128))
        sockssocket_0.sendall(str_2)
        socket_0 = sockssocket_0.recvall(8)
        print('\nRecieved: ' + str(socket_0))
        assert str_0 == socket_0
    finally:
        sockssocket_0.close()

# Generated at 2022-06-26 13:57:15.886818
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(('google.com', 80))
    s.sendall(b'GET / HTTP/1.1\r\nConnection: close\r\nHost: google.com\r\n\r\n')

    response_header = b''
    while True:
        header_line = s.recvall(1)
        response_header += header_line
        if header_line == b'\r\n':
            break

    response_body = s.recvall(int(response_header.split(b'\r\n')[2].split(b': ')[1]))
    assert response_body.startswith(b'<!doctype html>')

# Generated at 2022-06-26 13:57:17.712159
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock_0 = sockssocket()
    buf_0 = ()
    sock_0.recvall(buf_0)


# Generated at 2022-06-26 13:57:27.808838
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock_socks4 = socks4_0_0()
    in_byte_arr_0 = [0, 0, 0, 0]
    in_byte_arr_0 = [0, 0, 0, 0]
    in_byte_arr_0 = [0, 0, 0, 0]
    in_byte_arr_0 = [0, 0, 0, 0]
    in_byte_arr_0 = [0, 0, 0, 0]
    in_byte_arr_0 = [0, 0, 0, 0]
    in_byte_arr_0 = [0, 0, 0, 0]
    in_byte_arr_0 = [0, 0, 0, 0]
    in_byte_arr_0 = [0, 0, 0, 0]

# Generated at 2022-06-26 13:57:30.496423
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock_sockssock_0 = sockssocket()
    cnt_0 = 42
    length_0 = sock_sockssock_0.recvall(cnt_0)



# Generated at 2022-06-26 13:57:33.227197
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Create a sockssocket object
    sockssocket_0 = sockssocket()
    # The following line is expected to crash
    #assert sockssocket_0._recv_bytes()



# Generated at 2022-06-26 13:57:37.375393
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    str_0 = 'r'
    sockssocket_0 = sockssocket(str_0)
    str_1 = 'u'
    sockssocket_0.setproxy(sockssocket_0, str_1, int_0)
    int_1 = sockssocket_0.recvall(int_0)


# Generated at 2022-06-26 13:57:40.622142
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Test case 1
    local_0 = sockssocket()
    local_1 = 3
    local_2 = local_0.recvall(local_1)

    # Test case 2
    local_2 = 3
    local_3 = sockssocket()
    local_3.recvall(local_2)


# Generated at 2022-06-26 13:57:42.840287
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    str_0 = '4'
    socks4_error_0 = Socks4Error(str_0)
    print(socks4_error_0)


# Generated at 2022-06-26 13:57:44.842973
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    connection = sockssocket()
    connection.recvall(10)


# Generated at 2022-06-26 13:57:55.126975
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Test SOCKS4
    try:
        socks4_0 = sockssocket()
        socks4_0.setproxy(ProxyType.SOCKS4, 'localhost', 8080)
        socks4_0.connect(('localhost', 8080))
        assert False
    except ProxyError as e:
        assert e.code == Socks4Error.ERR_SUCCESS
    except:
        assert False
    # Test SOCKS4A
    try:
        socks4_1 = sockssocket()
        socks4_1.setproxy(ProxyType.SOCKS4A, 'localhost', 8080)
        socks4_1.connect(('localhost', 8080))
        assert False
    except ProxyError as e:
        assert e.code == Socks4Error.ERR_SUCCESS
    except:
        assert False

# Generated at 2022-06-26 13:58:29.402066
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock_0 = sockssocket()
    cnt_0 = 0
    try:
        eofferror_0 = EOFError('{0} bytes missing'.format(cnt_0))
    except EOFError:
        pass


# Generated at 2022-06-26 13:58:31.734784
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s_0 = sockssocket()
    cnt = cnt
    value = s_0.recvall(cnt)
    assert value == None
    assert True



# Generated at 2022-06-26 13:58:38.115886
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    str_0 = 'm;tP'
    str_1 = '5XK|'
    str_2 = '"\x7f'
    str_3 = '<B1k'
    str_4 = '"\x7f'
    str_5 = '5XK|'
    str_6 = 'm;tP'
    str_7 = '5XK|'
    str_8 = '5XK|'
    str_9 = 'Rq:w'
    str_10 = '*'
    str_11 = 'Rq:'
    str_12 = '\x0e\x13\x06\x1a\x1a%'
    str_13 = '@\x12'

# Generated at 2022-06-26 13:58:49.162646
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sockssocket_0 = sockssocket()
    str_0 = "M\x01\x07\x00\x00\xa9\x8e\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

# Generated at 2022-06-26 13:58:57.977612
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    str_0 = 'Rq:'
    socks4_error_0 = Socks4Error(str_0)
    str_1 = 'Rq:Rq,;^'
    socks4_error_1 = Socks4Error(str_1)
    str_2 = 'Rq.<l6'
    socks4_error_2 = Socks4Error(str_2)
    str_3 = 'Rq>=Q'
    socks4_error_3 = Socks4Error(str_3)
    str_4 = 'Rq@=Q'
    socks4_error_4 = Socks4Error(str_4)
    str_5 = 'RqA=Q'
    socks4_error_5 = Socks4Error(str_5)
    str_6 = 'RqB"R'


# Generated at 2022-06-26 13:58:59.818166
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sockssocket_0 = sockssocket()
    cnt_0 = 1
    # UNREACHABLE
    # raise NotImplementedError()


# Generated at 2022-06-26 13:59:03.206602
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    try:
        sockssocket_0 = sockssocket()
        sockssocket_0.bind((str_0, int_0))
        num_bytes_0 = cnt
        cnt = num_bytes_0
        sockssocket_0.recvall(cnt)
    except EOFError:
        pass
    finally:
        sockssocket_0.close()


# Generated at 2022-06-26 13:59:12.945212
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Initializing variables
    server_ip = ''
    socks4_error_0 = Socks4Error()
    socks4_error_1 = Socks4Error()
    str_0 = 'Rq:'
    socks4_error_0.__init__(str_0)
    str_1 = '\x0f'
    socks4_error_1.__init__(str_1)
    socks5_error_0 = Socks5Error()
    socks5_error_1 = Socks5Error()
    str_2 = 'Rq:\x00'
    socks5_error_0.__init__(str_2)
    str_3 = '\x08'
    socks5_error_1.__init__(str_3)
    # Function call
    test_case_0()

# Unit

# Generated at 2022-06-26 13:59:17.595091
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    socksocket_0 = sockssocket()
    sock_0 = socksocket_0
    socket_1 = socket.socket()
    send_0 = socket_1.send(send_1)
    recvall_0 = sock_0.recvall(10)
    recvall_0 = sock_0.recvall(20)
    recvall_0 = sock_0.recvall(30)

# Generated at 2022-06-26 13:59:19.610459
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    str_0 = '6Q'
    socks4_error_0 = Socks4Error(str_0)
    assert socks4_error_0.args[0] == str_0


# Generated at 2022-06-26 14:01:06.173784
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket()
    assert sock.recvall(1) == b''


# Generated at 2022-06-26 14:01:13.184382
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    data = 'Rq:Rq:Rq:Rq:Rq:Rq:Rq:Rq:'
    sockssocket_0 = sockssocket()
    sockssocket_1 = sockssocket()
    sockssocket_2 = sockssocket()
    sockssocket_3 = sockssocket()
    sockssocket_4 = sockssocket()
    sockssocket_5 = sockssocket()
    sockssocket_6 = sockssocket()
    sockssocket_7 = sockssocket()
    sockssocket_8 = sockssocket()
    sockssocket_9 = sockssocket()
    sockssocket_10 = sockssocket()
    sockssocket_11 = sockssocket()
    sockssocket_12 = sockssocket()
    sockssocket_13 = sockssocket()
    sockssocket_14 = sockssocket()
    sockssocket_15 = sockssocket()
    sockssocket_16 = sockssocket()



# Generated at 2022-06-26 14:01:22.384103
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    str_0 = 'Rq:'
    socks4_error_0 = Socks4Error(str_0)

    str_1 = 'Y'
    socks4_error_1 = Socks4Error(str_1)

    str_2 = 'Cg'
    socks4_error_2 = Socks4Error(str_2)

    str_3 = '\x02'
    socks5_error_0 = Socks5Error(str_3)

    str_4 = 'H@\x00'
    socks5_error_1 = Socks5Error(str_4)

    str_5 = '*'
    socks5_error_2 = Socks5Error(str_5)

    str_6 = 'V'
    socks5_error_3 = Socks5Error(str_6)

    str

# Generated at 2022-06-26 14:01:23.416096
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.recvall(1)


# Generated at 2022-06-26 14:01:24.570424
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sockssocket_0 = sockssocket(0)



# Generated at 2022-06-26 14:01:31.970276
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    str_0 = str()
    int_0 = int()
    eof_error_0 = EOFError(str_0, int_0)
    int_1 = int()
    int_2 = int()
    int_3 = int()
    int_4 = int()
    int_5 = int()
    int_6 = int()
    int_7 = int()
    int_8 = int()
    int_9 = int()
    int_10 = int()
    int_11 = int()
    int_12 = int()
    int_13 = int()
    int_14 = int()
    int_15 = int()
    int_16 = int()
    int_17 = int()
    int_18 = int()
    int_19 = int()
    int_20 = int()
    int

# Generated at 2022-06-26 14:01:38.929801
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    str_0 = '+:4'
    str_1 = 'm'
    try:
        sockssocket_0 = sockssocket(str_0, str_1)
        sockssocket_0.connect((str_0, int_0))
        buffer_0 = str_1.encode('utf-8')
        sockssocket_0.sendall(buffer_0)
        cnt_0 = int_0
        sockssocket_0.recvall(cnt_0)
    except EOFError as eoferror_0:
        msg_0 = str(eoferror_0)
        str_2 = 'bytes missing'
        assert msg_0.endswith(str_2)


# Generated at 2022-06-26 14:01:44.405581
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    with socket.socket() as sock:
        expected = 'test'
        sock.send(expected)

        wrapping_sockssocket = sockssocket(sock.fileno())
        assert expected == wrapping_sockssocket.recvall(len(expected))

    # EOF
    with socket.socket() as sock:
        with sockssocket(sock.fileno()) as wrapping_sockssocket:
            with pytest.raises(EOFError):
                wrapping_sockssocket.recvall(1)


# Generated at 2022-06-26 14:01:47.348130
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    socket_0 = sockssocket()
    buffer_0 = bytes(3)
    result = socket_0.recvall(buffer_0)
    assert result is None



# Generated at 2022-06-26 14:01:53.876606
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sockssocket_0 = sockssocket()
    str_0 = 'GX\x00\x00\x00\x00\x00'
    sockssocket_0.sendall(str_0)
    str_1 = 'u\x00\x00H\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    str_2 = sockssocket_0.recvall(len(str_1))
    assert(str_1 == str_2)


# Generated at 2022-06-26 14:04:04.173428
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    print('Method: recvall')
    sockssocket.recvall(0)


# Generated at 2022-06-26 14:04:10.388021
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # create a TCP/IP socket
    socks = sockssocket(socket.AF_INET, socket.SOCK_STREAM)

    # connect the socket to the port where the server is listening
    server_address = ('localhost', 9999)
    print('connecting to {} port {}'.format(*server_address))
    socks.connect(server_address)
    data = b'This is the message.  It will be repeated.'
    print('sending {!r}'.format(data))
    socks.sendall(data)

    amount_received = 0
    amount_expected = len(data)
    
    while amount_received < amount_expected:
        #data = socks.recv(16)
        socks.recvall(amount_expected)
        amount_received += len(data)

# Generated at 2022-06-26 14:04:15.773135
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # recvall.test_0(sockssocket)

    # self.assertEqual(self.s.recvall(len(self.data)), self.data)
    # self.assertRaises(EOFError, self.s.recvall, len(self.data) + 1)
    pass


# Generated at 2022-06-26 14:04:18.543348
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sockssocket_0 = sockssocket()
    size = 3
    try:
        result = sockssocket_0.recvall(size)
        print('result: ', result)
    except EOFError as ex:
        print('ex: ', ex)


# Generated at 2022-06-26 14:04:24.339129
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    socket_0 = sockssocket()
    byte_0 = 0xFF
    byte_1 = 0xFF
    byte_2 = 0xFF
    byte_3 = 0xFF
    byte_4 = 0xFF
    byte_5 = 0xFF
    byte_6 = 0xFF
    byte_7 = 0xFF
    byte_8 = 0xFF
    byte_9 = 0xFF
    byte_10 = 0xFF
    byte_11 = 0xFF
    byte_12 = 0xFF
    byte_13 = 0xFF
    byte_14 = 0xFF
    byte_15 = 0xFF
    byte_16 = 0xFF