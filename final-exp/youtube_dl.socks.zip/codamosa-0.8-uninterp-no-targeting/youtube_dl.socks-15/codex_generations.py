

# Generated at 2022-06-22 09:31:55.078198
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    ss = sockssocket()
    assert isinstance(ss, sockssocket)
    assert ss._proxy == None

    ss.setproxy(1, '127.0.0.1', 8118)
    assert ss._proxy.type == 1

# Generated at 2022-06-22 09:32:00.921420
# Unit test for constructor of class Proxy
def test_Proxy():
    p = Proxy
    assert p.type == 'type'
    assert p.host == 'host'
    assert p.port == 'port'
    assert p.username == 'username'
    assert p.password == 'password'
    assert p.remote_dns == 'remote_dns'

if __name__ == '__main__':
    test_Proxy()

# Generated at 2022-06-22 09:32:03.322809
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    invalid_version = InvalidVersionError(expected_version = 1, got_version = 2)
    assert(str(invalid_version) == 'Invalid response version from server. Expected 01 got 02')


# Generated at 2022-06-22 09:32:05.626369
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:32:06.738689
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    print("Class Socks5Command created.")

    pass


# Generated at 2022-06-22 09:32:09.368669
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(('localhost', 8080))
    s.close()


# Generated at 2022-06-22 09:32:19.385930
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import mock
    import unittest
    import time

    class SockssocketRecvallTestCase(unittest.TestCase):

        @mock.patch('socket.socket.recv', return_value=b'abcde')
        def test_recvall_success(self, mocked_socket_recv):
            s = sockssocket()
            result = s.recvall(5)
            self.assertEqual(result, b'abcde')

        @mock.patch('socket.socket.recv', side_effect=[b'abcd', b'e'])
        def test_recvall_success_multiple_calls(self, mocked_socket_recv):
            s = sockssocket()
            result = s.recvall(5)
            self.assertEqual(result, b'abcde')



# Generated at 2022-06-22 09:32:24.497697
# Unit test for constructor of class sockssocket
def test_sockssocket():
    # Verify that we can create an instance of sockssocket
    test = sockssocket()
    assert test.getsockname()[0] == '0.0.0.0'
    assert test.getsockname()[1] == 0

# Generated at 2022-06-22 09:32:32.849819
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    proxyType = ProxyType.SOCKS5
    addr = '192.168.0.1'
    port = 1080
    rdns = True
    username = 'username'
    password = 'password'
    s = sockssocket()
    s.setproxy(proxyType, addr, port, rdns, username, password)
    assert s._proxy.type == proxyType
    assert s._proxy.host == addr
    assert s._proxy.port == port
    assert s._proxy.username == username
    assert s._proxy.password == password
    assert s._proxy.remote_dns == rdns

# Generated at 2022-06-22 09:32:42.481443
# Unit test for constructor of class ProxyError
def test_ProxyError():
    # Test case: check error code is None and msg is None
    e = ProxyError(None, None)
    assert len(e.args) == 2 and e.args[0] is None and e.args[1] is None
    # Test case: check error code is 90 and msg is None
    e = ProxyError(90, None)
    assert len(e.args) == 2 and e.args[0] == 90 and e.args[1] is None
    # Test case: check error code is None and msg is 'unknown error'
    e = ProxyError(None, 'unknown error')
    assert len(e.args) == 2 and e.args[0] is None and e.args[1] == 'unknown error'
    # Test case: check error code is None and msg is 'some error'

# Generated at 2022-06-22 09:32:56.137004
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(proxytype=ProxyType.SOCKS5, host='127.0.0.1', port=1080, username='username', password='password', remote_dns=True)
    assert (proxy.type, proxy.host, proxy.port, proxy.username, proxy.password, proxy.remote_dns) == (2, '127.0.0.1', 1080, 'username', 'password', True)



# Generated at 2022-06-22 09:33:00.066808
# Unit test for constructor of class ProxyType
def test_ProxyType():
    proxy_type = ProxyType()
    assert proxy_type.SOCKS4 == 0
    assert proxy_type.SOCKS4A == 1
    assert proxy_type.SOCKS5 == 2


# Generated at 2022-06-22 09:33:01.877589
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:33:06.006799
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    IPv4 = Socks5AddressType.ATYP_IPV4
    assert IPv4 == 0x01

    Domainname = Socks5AddressType.ATYP_DOMAINNAME
    assert Domainname == 0x03

    IPv6 = Socks5AddressType.ATYP_IPV6
    assert IPv6 == 0x04



# Generated at 2022-06-22 09:33:08.638350
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    command = Socks5Command()
    print(command.CMD_CONNECT)
    print(command.CMD_BIND)
    print(command.CMD_UDP_ASSOCIATE)


# Generated at 2022-06-22 09:33:10.429134
# Unit test for constructor of class ProxyType
def test_ProxyType():
    proxyType = ProxyType()
    assert proxyType.SOCKS4 == 0
    assert proxyType.SOCKS4A == 1
    assert proxyType.SOCKS5 == 2



# Generated at 2022-06-22 09:33:22.808324
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4, 'localhost', 1080)
    assert s._proxy.type == ProxyType.SOCKS4
    assert s._proxy.host == 'localhost'
    assert s._proxy.port == 1080
    assert s._proxy.username is None
    assert s._proxy.password is None
    assert s._proxy.remote_dns is True

    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, 'localhost', 1080, username='a', password='b')
    assert s._proxy.type == ProxyType.SOCKS5
    assert s._proxy.host == 'localhost'
    assert s._proxy.port == 1080
    assert s._proxy.username == 'a'
    assert s._proxy.password == 'b'
    assert s._

# Generated at 2022-06-22 09:33:32.025093
# Unit test for constructor of class Proxy
def test_Proxy():
    from unittest.mock import patch
    proxy = Proxy(ProxyType.SOCKS4, '127.0.0.1', 1080, 'username', 'password', True)
    assert (proxy.type == ProxyType.SOCKS4)
    assert (proxy.host == '127.0.0.1')
    assert (proxy.port == 1080)
    assert (proxy.username == 'username')
    assert (proxy.password == 'password')
    assert (proxy.remote_dns == True)

if __name__ == '__main__':
    test_Proxy()

# Generated at 2022-06-22 09:33:33.118976
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    pass


# Generated at 2022-06-22 09:33:37.597671
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    cmd = Socks4Command.CMD_CONNECT
    assert Socks4Command.CMD_CONNECT == cmd
    cmd = Socks4Command.CMD_BIND
    assert Socks4Command.CMD_BIND == cmd


# Generated at 2022-06-22 09:34:00.645110
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    assert s._proxy is None
    # Test SOCKS4 with remote DNS
    s.setproxy(ProxyType.SOCKS4, 'hostname', 3128)
    assert s._proxy.type == ProxyType.SOCKS4
    assert s._proxy.host == 'hostname'
    assert s._proxy.port == 3128
    assert s._proxy.username is None
    assert s._proxy.password is None
    assert s._proxy.remote_dns
    # Test SOCKS4 with remote DNS with username and password
    s.setproxy(ProxyType.SOCKS4, 'hostname', 3128, username='test', password='test')
    assert s._proxy.type == ProxyType.SOCKS4
    assert s._proxy.host == 'hostname'

# Generated at 2022-06-22 09:34:07.535217
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
    assert hex(Socks5Command.CMD_UDP_ASSOCIATE) == '0x03'
    assert Socks5Command.CMD_UDP_ASSOCIATE == 3


# Generated at 2022-06-22 09:34:09.651589
# Unit test for constructor of class Proxy
def test_Proxy():
    proxyexample = Proxy(type, host, port, username, password, remote_dns)
    assert proxyexample.remote_dns == True


# Generated at 2022-06-22 09:34:13.222893
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
    assert Socks5Command.CMD_UDP_ASSOCIATE == 3

# Generated at 2022-06-22 09:34:15.225828
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:34:18.480877
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    auth = Socks5Auth()
    assert auth.AUTH_NONE == 0x00
    assert auth.AUTH_GSSAPI == 0x01
    assert auth.AUTH_USER_PASS == 0x02
    assert auth.AUTH_NO_ACCEPTABLE == 0xFF
    assert True

# Generated at 2022-06-22 09:34:20.622361
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-22 09:34:26.909719
# Unit test for constructor of class sockssocket
def test_sockssocket():
    socket.socket = sockssocket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 5050, username='foo', password='bar')
    s.connect(('example.com', 443))
    assert True


# Generated at 2022-06-22 09:34:30.738763
# Unit test for constructor of class ProxyError
def test_ProxyError():
    # Invalid version
    e = InvalidVersionError(expected_version=5, got_version=0)
    assert isinstance(e, ProxyError)
    assert e.args == (0, 'Invalid response version from server. Expected 05 got 00')
    # Invalid code
    e = ProxyError(code=255)
    assert isinstance(e, ProxyError)
    assert e.args == (255, 'unknown error')


# Generated at 2022-06-22 09:34:33.428072
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND



# Generated at 2022-06-22 09:34:57.275896
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    with socket.socket() as sock:
        # Create a simple TCP echo server
        server_port = 1234
        server_addr = '127.0.0.1'
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.bind((server_addr, server_port))
        server.listen(1)
        # Create a client and connect it to the server
        client = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((server_addr, server_port))
        # Accept the connection
        conn, _ = server.accept()
        # Send and receive a test message
        msg = 'test'
        conn.sendall(msg + '\r\n')

# Generated at 2022-06-22 09:35:03.722366
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # Not a real test, just a quick way to check that the connect_ex method works
    # when the proxy server is not available.

    socket.setdefaulttimeout(10)

    for proxy_type, proxy_host, proxy_port in [
            (ProxyType.SOCKS4, '127.0.0.1', 1080),
            (ProxyType.SOCKS4A, '127.0.0.1', 1080),
            (ProxyType.SOCKS5, '127.0.0.1', 1080),
    ]:
        s = sockssocket()
        s.setproxy(proxy_type, proxy_host, proxy_port)

# Generated at 2022-06-22 09:35:06.010344
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    exception = InvalidVersionError(expected_version=0x01, got_version=0x02)
    assert exception.strerror == 'Invalid response version from server. Expected 01 got 02'

# Generated at 2022-06-22 09:35:08.224306
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2



# Generated at 2022-06-22 09:35:16.128536
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    class MockSocket(sockssocket):
        def __init__(self):
            self._data = b''
        def recv(self, cnt):
            ret = self._data[:cnt]
            self._data = self._data[cnt:]
            return ret
        def sendall(self, data):
            self._data += data

    def test_connect(proxy_type, expected, address):
        print('Testing sockssocket connect method with proxy type: %d' % proxy_type)
        sock = MockSocket()
        sock.setproxy(proxy_type, 'example.com', 1080, username='user', password='pass')
        sock.connect(address)
        assert sock._data == expected

    # Normal tests

# Generated at 2022-06-22 09:35:20.950219
# Unit test for constructor of class ProxyError
def test_ProxyError():
    err = ProxyError()
    assert isinstance(err, socket.error)
    assert err.args == (None, 'unknown error')

    err = ProxyError(errno.EINVAL)
    assert err.args == (errno.EINVAL, 'Invalid argument')

# Generated at 2022-06-22 09:35:25.405117
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04

# Generated at 2022-06-22 09:35:35.319532
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.setproxy(socks.PROXY_TYPE_SOCKS5, "socks-proxy.example.org", 1080)
    print(s.getproxy())
    s.setproxy(socks.PROXY_TYPE_SOCKS4, "socks-proxy.example.org", 1080)
    print(s.getproxy())
    s.setproxy(socks.PROXY_TYPE_SOCKS4A, "socks-proxy.example.org", 1080)
    print(s.getproxy())
    s.setproxy(socks.PROXY_TYPE_SOCKS5, "socks-proxy.example.org", 1080,
               username="myusername", password="mypassword")
    print(s.getproxy())

# Generated at 2022-06-22 09:35:42.660703
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    """
    This function tests the method setproxy of class sockssocket.
    """
    s = sockssocket()
    arg_dict = {'proxytype': ProxyType.SOCKS5,
                'addr': '127.0.0.1',
                'port': 9050,
                'rdns': True,
                'username': 'testuser',
                'password': 'testpass'
               }
    s.setproxy(**arg_dict)
    assert s._proxy == Proxy(**arg_dict)

# Generated at 2022-06-22 09:35:48.904957
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = socket.socket()
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(("www.google.com", 80))
    sock.send("GET / HTTP/1.1\r\n\r\n")
    data = sock.recvall(1024)
    assert len(data)==1024
    sock.close()

# Generated at 2022-06-22 09:36:29.278237
# Unit test for constructor of class ProxyType
def test_ProxyType():
    proxy = ProxyType.SOCKS4
    assert proxy == 0
    proxy = ProxyType.SOCKS4A
    assert proxy == 1
    proxy = ProxyType.SOCKS5
    assert proxy == 2

# Generated at 2022-06-22 09:36:31.375560
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:36:40.211874
# Unit test for constructor of class Proxy
def test_Proxy():
    import sys
    if sys.version_info[0] >= 3:
        assert eval(repr(Proxy(ProxyType.SOCKS4, '127.0.0.1', 8080, 'timo', 'passw0rd', True))) == \
               Proxy(ProxyType.SOCKS4, '127.0.0.1', 8080, 'timo', 'passw0rd', True)
    else:
        assert str(Proxy(ProxyType.SOCKS4, '127.0.0.1', 8080, 'timo', 'passw0rd', True)) == \
               "Proxy(type=0, host='127.0.0.1', port=8080, username='timo', password='passw0rd', remote_dns=True)"

# Generated at 2022-06-22 09:36:44.295990
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    s = Socks4Error(91)
    assert s.errno == 91
    assert s.msg == 'request rejected or failed'

    s = Socks4Error(1)
    assert s.errno == 1
    assert s.msg == 'unknown error'



# Generated at 2022-06-22 09:36:53.333017
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket()
    assert ss.type == socket.SOCK_STREAM
    assert ss.family == socket.AF_INET
    assert ss.proto == socket.IPPROTO_TCP

    ss = sockssocket(socket.AF_INET)
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP)

    try:
        ss = sockssocket(socket.AF_UNIX)
    except socket.error:
        pass
    else:
        assert False, "shouldn't get here"

    try:
        ss = sockssocket(socket.AF_INET, socket.SOCK_DGRAM)
    except socket.error:
        pass
   

# Generated at 2022-06-22 09:37:01.065588
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 1)
    except InvalidVersionError as e:
        assert type(e) == InvalidVersionError
        assert e.errno == 0
        assert e.strerror == 'Invalid response version from server. Expected 00 got 01'
        assert e.args == (0, 'Invalid response version from server. Expected 00 got 01')
        assert str(e) == 'Invalid response version from server. Expected 00 got 01'
    else:
        raise AssertionError('No exception raised')

# Generated at 2022-06-22 09:37:05.410389
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    obj = Socks5Auth()
    assert obj.AUTH_NONE == 0x00
    assert obj.AUTH_GSSAPI == 0x01
    assert obj.AUTH_USER_PASS == 0x02
    assert obj.AUTH_NO_ACCEPTABLE == 0xff


# Generated at 2022-06-22 09:37:12.648222
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import sys
    import time
    import unittest

    import socket

    host = 'localhost'
    port = 1234

    class TestSockssocketConnectEx(unittest.TestCase):
        def setUp(self):
            self.socket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
            self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server.bind((host, port))
            self.server.listen(1)

        def tearDown(self):
            self.socket.close()
            self.server.close()

        def test_socks4(self):
            self.socket.set

# Generated at 2022-06-22 09:37:14.906283
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01


# Generated at 2022-06-22 09:37:23.282458
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    # Error code 91
    try:
        raise Socks4Error(91)
    except Socks4Error as e:
        assert e.msg == 'request rejected or failed'
        assert e.args[0] == 91

    # Error code 92
    try:
        raise Socks4Error(92)
    except Socks4Error as e:
        assert e.msg == 'request rejected because SOCKS server cannot connect to identd on the client'
        assert e.args[0] == 92

    # Error code 93
    try:
        raise Socks4Error(93)
    except Socks4Error as e:
        assert e.msg == 'request rejected because the client program and identd report different user-ids'
        assert e.args[0] == 93

    # Error code 1

# Generated at 2022-06-22 09:38:49.834256
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    err = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    assert (err.errno == Socks5Error.ERR_GENERAL_FAILURE) and (err.strerror == 'general SOCKS server failure')
    assert Socks5Error(0xFF, 'all offered authentication methods were rejected')



# Generated at 2022-06-22 09:38:53.866259
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    res = Socks4Error(99, 'test')
    assert res.args[0] == 99, 'wrong args[0]'
    assert res.args[1] == 'test', 'wrong args[1]'



# Generated at 2022-06-22 09:38:55.662363
# Unit test for constructor of class ProxyError
def test_ProxyError():
    ProxyError(ProxyError.ERR_SUCCESS, 'success')
    ProxyError(25, 'error 25')


# Generated at 2022-06-22 09:39:01.613821
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert isinstance(Socks5Command.CMD_CONNECT, int)
    assert Socks5Command.CMD_CONNECT == 0x01
    assert isinstance(Socks5Command.CMD_BIND, int)
    assert Socks5Command.CMD_BIND == 0x02
    assert isinstance(Socks5Command.CMD_UDP_ASSOCIATE, int)
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-22 09:39:05.029931
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.sendall(compat_struct_pack('!BI', 0, 6))
    s.sendall(compat_struct_pack('!IHH', 3, 7, 8))
    assert (compat_struct_unpack('!BI', s.recvall(6)) == (0, 6))
    assert (compat_struct_unpack('!IHH', s.recvall(8)) == (3, 7, 8))

# Generated at 2022-06-22 09:39:07.578015
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error
        assert(False)
    except Exception as e:
        assert(isinstance(e, ProxyError))
        assert(not isinstance(e, InvalidVersionError))
        assert(not isinstance(e, Socks5Error))


# Generated at 2022-06-22 09:39:11.573692
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    err = Socks4Error(91)
    assert err.args[0] == 91

# Generated at 2022-06-22 09:39:16.069904
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
	assert Socks5Command.CMD_CONNECT == 0x01, "Fail to create class Socks5Command"
	assert Socks5Command.CMD_BIND == 0x02, "Fail to create class Socks5Command"
	assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03, "Fail to create class Socks5Command"


# Generated at 2022-06-22 09:39:16.679970
# Unit test for constructor of class ProxyType
def test_ProxyType():
    pass

# Generated at 2022-06-22 09:39:26.836008
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    except Socks5Error as e:
        if e.args[0] != Socks5Error.ERR_GENERAL_FAILURE:
            print("Socks5Error constructor with named argument failed!")

    try:
        raise Socks5Error(Socks5Error.ERR_GENERAL_FAILURE, Socks5Error.CODES[Socks5Error.ERR_GENERAL_FAILURE])
    except Socks5Error as e:
        if e.args[0] != Socks5Error.ERR_GENERAL_FAILURE:
            print("Socks5Error constructor with explicit arguments failed!")
    return


# Generated at 2022-06-22 09:41:09.749049
# Unit test for constructor of class ProxyType
def test_ProxyType():
    type = ProxyType.SOCKS4
    type = ProxyType.SOCKS4A
    type = ProxyType.SOCKS5

# Generated at 2022-06-22 09:41:10.766611
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    v = Socks5AddressType()


# Generated at 2022-06-22 09:41:12.754723
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:41:15.260575
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:41:17.561086
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, 'localhost', 9050)
    assert s.connect_ex(('192.0.2.0', 80)) == 0

# Generated at 2022-06-22 09:41:27.154137
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    def _create_socket(*args, **kwargs):
        s = sockssocket(*args, **kwargs)
        s.connect = socket.socket.connect
        s.connect_ex = socket.socket.connect_ex
        return s

    def _test_socks4(*args):
        s = _create_socket(*args)
        s.setproxy(ProxyType.SOCKS4, 'localhost', 1080)
        s.connect(('google.com', 80))
        s.close()

    def _test_socks4a(*args):
        s = _create_socket(*args)
        s.setproxy(ProxyType.SOCKS4A, 'localhost', 1080)
        s.connect(('google.com', 80))
        s.close()

    def _test_socks5(*args):
        s = _