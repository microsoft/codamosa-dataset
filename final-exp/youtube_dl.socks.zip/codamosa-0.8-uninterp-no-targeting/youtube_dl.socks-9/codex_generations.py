

# Generated at 2022-06-22 09:31:47.699538
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
    assert Socks5Command.CMD_UDP_ASSOCIATE


# Generated at 2022-06-22 09:31:53.393442
# Unit test for constructor of class ProxyError
def test_ProxyError():
    def check_proxy_error(cls, instance):
        assert instance.strerror == cls.CODES[instance.errno]

    for cls in (Socks4Error, Socks5Error):
        for err_code in cls.CODES:
            instance = cls(err_code)
            yield check_proxy_error, cls, instance

# Generated at 2022-06-22 09:31:55.416961
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(None)
    except ProxyError as e:
        pass
    except Exception:
        raise


# Generated at 2022-06-22 09:32:05.987844
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    assert(not s._proxy)
    s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1080)
    assert(s._proxy.type == ProxyType.SOCKS4)
    assert(s._proxy.host == '127.0.0.1')
    assert(s._proxy.port == 1080)
    s.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 1080, username='username', password='password')
    assert(s._proxy.type == ProxyType.SOCKS4A)
    assert(s._proxy.host == '127.0.0.1')
    assert(s._proxy.port == 1080)
    assert(s._proxy.username == 'username')

# Generated at 2022-06-22 09:32:11.479006
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    destination = ('httpbin.org', 80)
    test_sock = sockssocket()
    test_sock.settimeout(1)
    test_sock.connect(destination)
    test_sock.sendall(b'GET / HTTP/1.1\r\nHost: httpbin.org\r\n\r\n')
    remaining_buffer = b''
    while True:
        try:
            recv_buffer = test_sock.recvall(10)
            remaining_buffer += recv_buffer
        except EOFError:
            break
    total_content = remaining_buffer.split(b'\r\n\r\n')[1]
    test_sock.close()
    return len(total_content)

# Generated at 2022-06-22 09:32:13.316297
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    Socks5Auth()


# Generated at 2022-06-22 09:32:14.317785
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    assert sockssocket().connect_ex(('example.com', 80))

# Generated at 2022-06-22 09:32:18.954855
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import time
    import proxies
    sockssocket.setproxy(proxies.SOCKS4, "127.0.0.1", 9150)
    sockssocket.connect(("127.0.0.1", 80))
    time.sleep(5)


# Generated at 2022-06-22 09:32:25.020936
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF  # For server response


# Generated at 2022-06-22 09:32:31.157899
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import sys

    if sys.version_info[0] >= 3:
        return
    s = sockssocket()
    s.connect(('localhost', 53))
    s.sendall(b'\x10\x10\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x03\x77\x77\x77\x06\x67\x6f\x6f\x67\x6c\x65\x03\x63\x6f\x6d\x00\x00\x01\x00\x01')
    size = s.recvall(2)
    if size != '\x10\x10':
        s.close()
        raise Exception('recvall failed to receive 2 bytes!')

# Generated at 2022-06-22 09:34:28.863271
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    e = Socks4Error(code=None, msg=None)
    assert e.strerror == 'request rejected or failed'

    e = Socks4Error(code=92, msg=None)
    assert e.strerror == 'request rejected because SOCKS server cannot connect to identd on the client'

    e = Socks4Error(code=93, msg=None)
    assert e.strerror == 'request rejected because the client program and identd report different user-ids'


# Generated at 2022-06-22 09:34:31.995582
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:34:36.824298
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    auth = Socks5Auth()
    assert auth.AUTH_NO_ACCEPTABLE == 0xFF
    assert auth.AUTH_NONE == 0x00
    assert auth.AUTH_GSSAPI == 0x01
    assert auth.AUTH_USER_PASS == 0x02



# Generated at 2022-06-22 09:34:37.955249
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()


# Generated at 2022-06-22 09:34:41.551115
# Unit test for constructor of class ProxyType
def test_ProxyType():
    proxyType = ProxyType()
    assert(proxyType.SOCKS4 == 0)
    assert(proxyType.SOCKS4A == 1)
    assert(proxyType.SOCKS5 == 2)


# Generated at 2022-06-22 09:34:44.195122
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error.ERR_SUCCESS == 90
    assert Socks4Error(Socks4Error.ERR_SUCCESS).args[1] == 'request rejected or failed'


# Generated at 2022-06-22 09:34:55.622267
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error().__str__() == 'unknown error'
    assert Socks4Error(1).__str__() == 'request rejected or failed'
    assert Socks4Error(2).__str__() == (
        'request rejected because SOCKS server '
        'cannot connect to identd on the client')
    assert Socks4Error(3).__str__() == (
        'request rejected because the client program '
        'and identd report different user-ids')
    assert Socks4Error(None, 'something wrong').__str__() == 'something wrong'
    assert Socks4Error(None, b'some \x87 bytes').__str__() == 'some ? bytes'
    assert Socks4Error(None, u'some \u1234 bytes').__str__() == 'some ? bytes'

# Generated at 2022-06-22 09:34:59.342026
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sockssocket = SocksSocket()
    assert (sockssocket.type, sockssocket.host, sockssocket.port, sockssocket.username, sockssocket.password, sockssocket.remote_dns) == (
        None, None, None, None, None, None)

# Generated at 2022-06-22 09:35:01.244576
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert isinstance(Socks5Auth.AUTH_NO_ACCEPTABLE, int)


# Generated at 2022-06-22 09:35:06.555089
# Unit test for constructor of class sockssocket
def test_sockssocket():
    # Check default constructor
    s = sockssocket()
    # Check constructor with parameters
    s = sockssocket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    assert (socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP) == (
        s.family, s.type, s.proto)
    assert s.type == socket.SOCK_DGRAM



# Generated at 2022-06-22 09:35:25.060433
# Unit test for constructor of class ProxyError
def test_ProxyError():
    exception = ProxyError('unknown error')
    assert str(exception) == 'unknown error'

    exception = ProxyError(code='unknown error')
    assert str(exception) == 'unknown error'

    exception = ProxyError(0, 'unknown error')
    assert str(exception) == 'unknown error'

    exception = ProxyError(Socks4Error.ERR_SUCCESS, Socks4Error.CODES.get(Socks4Error.ERR_SUCCESS))
    assert str(exception) == 'request rejected or failed'

# Generated at 2022-06-22 09:35:34.333556
# Unit test for constructor of class sockssocket
def test_sockssocket():
    socksSocket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    socksSocket.setproxy(2, "127.0.0.1", 1080, rdns=True, username='', password='')
    socksSocket.connect(("youtube.com", 80))
    socksSocket.sendall(b'GET / HTTP/1.1\r\n\r\n')
    print(socksSocket.recv(1024))
    socksSocket.close()

if __name__ == '__main__':
    test_sockssocket()

# Generated at 2022-06-22 09:35:38.903234
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    socks = sockssocket()
    socks.settimeout(0.1)
    data = b'test'
    socks.connect(('gist.github.com', 80))
    socks.sendall(b'HTTP/1.0 200 OK\r\n\r\n')
    socks.sendall(data)
    socks.shutdown(socket.SHUT_WR)
    assert socks.recvall(4) == data

# Generated at 2022-06-22 09:35:41.963580
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    # Tests for not passing code
    err = Socks5Error(0x02)
    assert err.args[1] == 'connection not allowed by ruleset'
    err = Socks5Error(0x00)
    assert err.args[1] == 'unknown error'

    # Tests for passing msg
    err = Socks5Error(0x00, msg='Test')
    assert err.args[1] == 'Test'

# Generated at 2022-06-22 09:35:46.378499
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 1
    assert Socks5AddressType.ATYP_DOMAINNAME == 3
    assert Socks5AddressType.ATYP_IPV6 == 4


# Generated at 2022-06-22 09:35:49.235773
# Unit test for constructor of class ProxyType
def test_ProxyType():
    # check that ProxyType.SOCKS5 is 2
    assert ProxyType.SOCKS5 == 2

# Generated at 2022-06-22 09:35:50.541106
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()


# Generated at 2022-06-22 09:35:54.489556
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    try:
        a = Socks5Command()
        b = Socks5Command()
    except:
        raise AssertionError()
    assert a.CMD_CONNECT == b.CMD_CONNECT


# Generated at 2022-06-22 09:36:00.567739
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(1, 'test')
    except ProxyError as e:
        assert e.args == (1, 'test')
        assert str(e) == 'test'
    try:
        raise ProxyError(2)
    except ProxyError as e:
        assert e.args == (2, 'unknown error')
        assert str(e) == 'unknown error'

# Generated at 2022-06-22 09:36:02.403505
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError(Socks4Error.ERR_SUCCESS).strerror == 'request rejected or failed'