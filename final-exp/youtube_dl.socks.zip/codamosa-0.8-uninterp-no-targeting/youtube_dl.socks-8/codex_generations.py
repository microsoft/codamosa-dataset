

# Generated at 2022-06-22 09:31:51.361485
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket()
    assert sock.recvall(5) == b'12345'

# Generated at 2022-06-22 09:31:58.220518
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    socks_error = Socks5Error(1)
    assert(socks_error.errno == 1)
    assert(socks_error.strerror == Socks5Error.CODES[1])
    assert(socks_error.args == (1, Socks5Error.CODES[1]))
    assert(socks_error.msg == Socks5Error.CODES[1])

    socks_error = Socks5Error(0)
    assert(socks_error.errno == 0)
    assert(socks_error.strerror == 'unknown error')
    assert(socks_error.args == (0, 'unknown error'))
    assert(socks_error.msg == 'unknown error')

    socks_error = Socks5Error()

# Generated at 2022-06-22 09:32:02.208669
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03



# Generated at 2022-06-22 09:32:05.952907
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03

# Generated at 2022-06-22 09:32:11.967569
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    assert ProxyType.SOCKS4 is ProxyType.__getitem__('SOCKS4')
    ss = sockssocket()
    assert not ss._proxy
    ss.setproxy(ProxyType.SOCKS4, 'username', 'password')
    assert ss._proxy
    assert ss._proxy.type is ProxyType.SOCKS4
    assert ss._proxy.username == 'username'
    assert ss._proxy.password == 'password'


# Generated at 2022-06-22 09:32:18.526594
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS5, '127.0.0.1', 8888, 'root', 'password', True)
    assert proxy.type == ProxyType.SOCKS5
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 8888
    assert proxy.username == 'root'
    assert proxy.password == 'password'
    assert proxy.remote_dns == True



# Generated at 2022-06-22 09:32:28.338032
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    sock = sockssocket()

    # Test socks4 proxy
    sock.setproxy(ProxyType.SOCKS4, '127.0.0.1', 8080)
    assert sock._proxy.type == ProxyType.SOCKS4
    sock.setproxy(ProxyType.SOCKS4, '127.0.0.1', 8080, username='blabla', password='secret')
    assert sock._proxy.type == ProxyType.SOCKS4
    assert sock._proxy.username == 'blabla'
    assert sock._proxy.password == 'secret'
    assert sock._proxy.remote_dns is True

    # Test socks4a proxy
    sock.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 8080)
    assert sock._proxy.type == ProxyType.SOCKS

# Generated at 2022-06-22 09:32:33.567986
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    socks_5_auth = Socks5Auth()
    assert socks_5_auth.AUTH_NONE == 0x00
    assert socks_5_auth.AUTH_GSSAPI == 0x01
    assert socks_5_auth.AUTH_USER_PASS == 0x02
    assert socks_5_auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:32:41.367693
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00, "expected 0x00, got 0x{:02x}".format(Socks5Auth.AUTH_NONE)
    assert Socks5Auth.AUTH_GSSAPI == 0x01, "expected 0x01, got 0x{:02x}".format(Socks5Auth.AUTH_GSSAPI)
    assert Socks5Auth.AUTH_USER_PASS == 0x02, "expected 0x02, got 0x{:02x}".format(Socks5Auth.AUTH_USER_PASS)
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF, "expected 0xFF, got 0x{:02x}".format(Socks5Auth.AUTH_NO_ACCEPTABLE)
    # test

# Generated at 2022-06-22 09:32:43.266626
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    print(Socks4Command.CMD_CONNECT)
    print(Socks4Command.CMD_BIND)


# Generated at 2022-06-22 09:33:05.073282
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import os

    server_address = os.path.join(os.getcwd(), 'socket_server_test.sock')
    client_address = os.path.join(os.getcwd(), 'socket_client_test.sock')
    pat = b'123456789' * 1024 * 1024 * 4

    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

    if os.path.exists(client_address):
        os.remove(client_address)
    if os.path.exists(server_address):
        os.remove(server_address)

    server.bind(server_address)
    server.listen(5)
    client.connect(client_address)

# Generated at 2022-06-22 09:33:08.264502
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    auth = Socks5Auth()

    assert auth.AUTH_NONE == 0x00
    assert auth.AUTH_GSSAPI == 0x01
    assert auth.AUTH_USER_PASS == 0x02
    assert auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:33:09.379093
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    Socks5Command
    print("Socks5Command() test complete!")


# Generated at 2022-06-22 09:33:12.001386
# Unit test for constructor of class Proxy

# Generated at 2022-06-22 09:33:16.717391
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS4, '127.0.0.1', 8080)
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 8080
    assert proxy.username is None
    assert proxy.password is None
    assert proxy.remote_dns is True

    proxy = Proxy(ProxyType.SOCKS4A, '127.0.0.1', 8080, 'foo', 'bar', remote_dns=False)
    assert proxy.type == ProxyType.SOCKS4A
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 8080
    assert proxy.username == 'foo'
    assert proxy.password == 'bar'
    assert proxy.remote_d

# Generated at 2022-06-22 09:33:21.745602
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(expected_version=0x00, got_version=0xFF)
    except InvalidVersionError as e:
        assert e.args[0] == 0
        assert e.args[1].startswith('Invalid response version from server')
    else:
        raise AssertionError('InvalidVersionError not raised')



# Generated at 2022-06-22 09:33:25.337032
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    code = Socks4Error.ERR_SUCCESS
    msg = Socks4Error.CODES.get(code)
    assert msg == 'request rejected or failed'
    socks4error = Socks4Error(code, msg)
    assert socks4error.errno == code
    assert socks4error.strerror == msg


# Generated at 2022-06-22 09:33:28.929382
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error()
    except Socks4Error as e:
        assert e.args[0] == 0
        assert e.args[1] == 'unknown error'


# Generated at 2022-06-22 09:33:39.546461
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    # Test valid address type
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04

    # Test invalid address type
    try:
        assert Socks5AddressType.ATYP_IPV4 == 0xFF
        assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
        assert Socks5AddressType.ATYP_IPV6 == 0x04
    except Exception as e:
        print("Wrong address type")
        print(e)
        assert str(e) == "Wrong address type"



# Generated at 2022-06-22 09:33:46.758322
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import select
    import random
    import time
    import multiprocessing
    import os

    s = sockssocket()
    server_ip = 'localhost'
    server_port = random.randint(1025, 65535)
    s.bind((server_ip, server_port))
    s.listen(1)

    def client():
        s = sockssocket()
        s.connect((server_ip, server_port))

        def sendall(string):
            assert len(string) <= 255
            length = compat_struct_pack('!B{0}s'.format(len(string)), len(string), string)
            s.sendall(length + string)

        sendall(b'\x03\x03')
        sendall(b'\x01\x00\xFF')

# Generated at 2022-06-22 09:34:12.253905
# Unit test for constructor of class ProxyType
def test_ProxyType():
    pt = ProxyType()
    assert pt.SOCKS4 == 0
    assert pt.SOCKS4A == 1
    assert pt.SOCKS5 == 2


# Generated at 2022-06-22 09:34:19.208892
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    host = "127.0.0.1"
    port = 1080
    proxy_type = ProxyType.SOCKS4
    username = "user"
    password = "pass"
    remote_dns = True

    ss = sockssocket()

    ss.setproxy(proxy_type, host, port, rdns=remote_dns, username=username, password=password)

    assert ss._proxy.type == proxy_type
    assert ss._proxy.host == host
    assert ss._proxy.port == port
    assert ss._proxy.username == username
    assert ss._proxy.password == password
    assert ss._proxy.remote_dns == remote_dns


# Generated at 2022-06-22 09:34:24.516039
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 1
    assert Socks5AddressType.ATYP_DOMAINNAME == 3
    assert Socks5AddressType.ATYP_IPV6 == 4


# Generated at 2022-06-22 09:34:26.714474
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:34:32.896824
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    import inspect
    import subprocess
    import sys
    import types

    sockssocket_filename = inspect.getsourcefile(sockssocket)
    ssh_command = [
        'ssh',
        '-D', '0',
        '-N',
        '-g', '-o', 'ExitOnForwardFailure=yes',
        '-o', 'ControlPath=none',
        '-o', 'ControlMaster=no',
        '-o', 'LocalCommand="cat > /dev/null"',
        '-o', 'ServerAliveInterval=60',
        '-o', 'ServerAliveCountMax=3',
        '-o', 'ConnectTimeout=3',
        '-F', '/dev/null',
        '-l', 'non-existing-user',
        'non-existing-host',
    ]


# Generated at 2022-06-22 09:34:35.662321
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(
        ProxyType.SOCKS4, '127.0.0.1', 21, 'user', 'pass', False
    )
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 21
    assert proxy.username == 'user'
    assert proxy.password == 'pass'
    assert proxy.remote_dns is False


# Generated at 2022-06-22 09:34:45.356832
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    # test_sockssocket_setproxy is a unit test for method setproxy of class sockssocket
    # test if setproxy raises TypeError for wrong types of parameters
    assert_raises(TypeError, sockssocket().setproxy, 5, 2, 3, 4, 5)
    assert_raises(TypeError, sockssocket().setproxy, 'socks4', 2, 3, 4, 5)
    assert_raises(TypeError, sockssocket().setproxy, 'socks5', 2, 3, 4, 5)
    assert_raises(TypeError, sockssocket().setproxy, ProxyType.SOCKS5, 2, 3, 4, 5)
    assert_raises(TypeError, sockssocket().setproxy, ProxyType.SOCKS5, 'abc', 3, 4, 5)

# Generated at 2022-06-22 09:34:54.881705
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error().message == 'unknown error'
    assert Socks5Error(Socks5Error.ERR_GENERAL_FAILURE).message == 'general SOCKS server failure'
    assert Socks5Error(Socks5Error.ERR_SUCCESS).message == 'unknown error'
    assert Socks5Error(1).message == 'general SOCKS server failure'
    assert Socks5Error(Socks5Error.ERR_GENERAL_FAILURE, 'Foo bar').message == 'Foo bar'
    assert repr(Socks5Error(Socks5Error.ERR_GENERAL_FAILURE, 'Foo bar')) == '1 Foo bar'


# Generated at 2022-06-22 09:34:59.675442
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    # ERR_SUCCESS
    try:
        raise Socks4Error(Socks4Error.ERR_SUCCESS)
    except ProxyError as exc:
        assert exc.msg == 'request rejected or failed'

    # ERR_REJECTED
    try:
        raise Socks4Error(91)
    except ProxyError as exc:
        assert exc.msg == 'request rejected or failed'


# Generated at 2022-06-22 09:35:08.145106
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    def test_case(code, err_msg):
        err = Socks5Error(code, err_msg)
        return True if (err.code == code and err.err_msg == err_msg) else False

    assert test_case(0x01, "general SOCKS server failure")
    assert test_case(0x02, "connection not allowed by ruleset")
    assert test_case(0x03, "Network unreachable")
    assert test_case(0x04, "Host unreachable")
    assert test_case(0x05, "Connection refused")
    assert test_case(0x06, "TTL expired")
    assert test_case(0x07, "Command not supported")
    assert test_case(0x08, "Address type not supported")

# Generated at 2022-06-22 09:36:00.618911
# Unit test for constructor of class Proxy
def test_Proxy():
    from io import StringIO
    import sys

    try:
        savestdout = sys.stdout
        sys.stdout = StringIO()

        p = Proxy(1, "127.0.0.1", 1080, None, None, True)
        print(p)
        assert sys.stdout.getvalue() == "Proxy(type=1, host='127.0.0.1', port=1080, username=None, password=None, remote_dns=True)\n"
    finally:
        sys.stdout = savestdout


# Generated at 2022-06-22 09:36:05.016848
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import select
    import os
    import sys
    import struct
    if sys.version_info[0] < 3:
        def b(x):
            return x
    else:
        def b(x, encoding='latin-1'):
            return bytes(x, encoding)
    socks5_port = None
    if len(sys.argv) > 1:
        socks5_port = int(sys.argv[1])
    socks_addr = '127.0.0.1'
    socks_port = 1080
    http_addr = 'www.cntv.cn'
    http_port = 80
    http_url = '/'

# Generated at 2022-06-22 09:36:09.541426
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import random
    import unittest
    import socks

    class SocksSocketTest(unittest.TestCase):
        def test_recvall(self):
            recv_size = random.randint(1, 5)
            data = ''.join([chr(48 + random.randint(0, 9)) for x in range(recv_size)])

            class FakeSocket(object):
                def __init__(self, data):
                    self.buffer = data

                def recv(self, cnt):
                    read_cnt = min(cnt, len(self.buffer))
                    retval = self.buffer[:read_cnt]
                    self.buffer = self.buffer[read_cnt:]
                    return retval

                def send(self, data):
                    pass


# Generated at 2022-06-22 09:36:15.925933
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-22 09:36:19.997275
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    error = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    assert error.args[0] == Socks5Error.ERR_GENERAL_FAILURE
    assert error.args[1] == 'general SOCKS server failure'


# Generated at 2022-06-22 09:36:28.149630
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    sockssocket().setproxy(ProxyType.SOCKS4, '127.0.0.1', 8080, False, None, None)
    sockssocket().setproxy(ProxyType.SOCKS4A, '127.0.0.1', 8080, False, None, None)
    sockssocket().setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080, False, None, None)



# Generated at 2022-06-22 09:36:31.645192
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    test_code = Socks5Error(code=0)
    assert test_code.code == 0
    assert test_code.msg == 'general SOCKS server failure'

# Generated at 2022-06-22 09:36:33.728583
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    s = sockssocket()
    s.connect(('www.google.com', 80))
    s.close()



# Generated at 2022-06-22 09:36:44.997419
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import random
    # Generate random data
    data = bytearray([random.randint(0, 255) for i in range(random.randint(1, 1000))])
    # Open a socket
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        # Connect it to localhost:http (port 80)
        sock.connect(("localhost", 80))
        # Send the data
        sock.sendall(data)
        # Receive the data with our recvall method
        got_data = sock.recvall(len(data))
    except OSError:
        pass
    finally:
        # Close the socket
        sock.close()
    # Compare the data sent and received
    return data == got_data

# Generated at 2022-06-22 09:36:57.666735
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError()
    except ProxyError as e:
        assert hasattr(e, 'errno')
        assert hasattr(e, 'strerror')
        assert e.args == (None, None)
    else:
        assert False

    try:
        raise ProxyError(code=123)
    except ProxyError as e:
        assert hasattr(e, 'errno')
        assert hasattr(e, 'strerror')
        assert e.args == (123, 'unknown error')
    else:
        assert False

    try:
        raise ProxyError(code=91)
    except ProxyError as e:
        assert hasattr(e, 'errno')
        assert hasattr(e, 'strerror')
        assert e.args == (91, 'request rejected or failed')

# Generated at 2022-06-22 09:38:52.367845
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:38:54.315457
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:39:03.876325
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    socks_ip = '127.0.0.1'
    socks_port = 9150

    # Used by stem.process.launch_tor_with_config:
    # https://stem.torproject.org/api/stem/process.html#stem.process.launch_tor_with_config
    socks5_socket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    socks5_socket.setproxy(ProxyType.SOCKS5, socks_ip, socks_port)

    # Used by requests.sessions.Session.prepare_request:
    # https://github.com/kennethreitz/requests/blob/master/requests/sessions.py#L642
    socks4_socket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    socks

# Generated at 2022-06-22 09:39:09.118302
# Unit test for constructor of class ProxyError
def test_ProxyError():
    error = ProxyError()
    assert error.msg is None
    assert error.code is None
    assert str(error) == ''
    assert error.args == (None, None)

    error = ProxyError(1, 'message')
    assert error.msg == 'message'
    assert error.code == 1
    assert str(error) == 'message'
    assert error.args == (1, 'message')

    error = ProxyError(2)
    assert error.msg == 'unknown error'
    assert error.code == 2
    assert str(error) == 'unknown error'
    assert error.args == (2, 'unknown error')


# Generated at 2022-06-22 09:39:16.589319
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    test_string = 'This is a test string for sockssocket_recvall'
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('localhost', 0))
    server.listen(1)
    client = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(server.getsockname())
    client, _ = server.accept()
    client.send(test_string)
    assert client.recvall(len(test_string)) == test_string

# Generated at 2022-06-22 09:39:23.937147
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    try:
        Socks4Command.CMD_CONNECT == Socks5Command.CMD_CONNECT
    except AssertionError:
        print("Warning: Socks4Command.CMD_CONNECT is not equal Socks5Command.CMD_CONNECT")
    try:
        Socks4Command.CMD_BIND == Socks5Command.CMD_BIND
    except AssertionError:
        print("Warning: Socks4Command.CMD_BIND is not equal Socks5Command.CMD_BIND")


# Generated at 2022-06-22 09:39:28.101607
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    try:
        client = sockssocket()
        client.setproxy(ProxyType.SOCKS5, "127.0.0.1", 1080)
        client.connect(('google.com', 443))
        print(client.recv(128))
    except Exception as e:
        print(e)


# Generated at 2022-06-22 09:39:32.123447
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    except Socks5Error as e:
        assert e.args[0] == Socks5Error.ERR_GENERAL_FAILURE
        assert e.args[1] == 'general SOCKS server failure'


# Generated at 2022-06-22 09:39:38.549432
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(SOCKS4_VERSION, SOCKS5_VERSION)
    except InvalidVersionError as e:
        pass
    msg = str(e)
    assert isinstance(msg, str) is True
    assert 'Invalid response version from server. Expected 04 got 05' in msg


# Generated at 2022-06-22 09:39:41.934369
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sockssocket(socket.AF_INET)
    sockssocket()
