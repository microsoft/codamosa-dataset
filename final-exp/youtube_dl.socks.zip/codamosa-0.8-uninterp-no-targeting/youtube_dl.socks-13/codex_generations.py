

# Generated at 2022-06-22 09:31:51.440555
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS4, '127.0.0.1', 8080, '', '', False)
    assert proxy.username == ''
    assert proxy.password == ''

# Generated at 2022-06-22 09:31:53.357137
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:31:58.311728
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:32:07.523752
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import argparse
    import errno
    import select
    from .compat import (
        compat_struct_pack,
        compat_struct_unpack,
    )

    def recvall(conn, cnt):
        data = b''
        while len(data) < cnt:
            cur = conn.recv(cnt - len(data))
            if not cur:
                raise EOFError('{0} bytes missing'.format(cnt - len(data)))
            data += cur
        return data
    
    def recv_bytes(conn, cnt):
        data = recvall(conn, cnt)
        return compat_struct_unpack('!{0}B'.format(cnt), data)


# Generated at 2022-06-22 09:32:10.077567
# Unit test for constructor of class ProxyType
def test_ProxyType():
    # Test normal construction
    t = ProxyType()
    assert t.SOCKS4 == 0
    assert t.SOCKS4A == 1
    assert t.SOCKS5 == 2

# Generated at 2022-06-22 09:32:16.231433
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import socks
    socks.set_default_proxy(socks.SOCKS5, '127.0.0.1', 1080)
    with socks.socksocket() as s:
        s.connect(('httpbin.org', 80))
        s.sendall(b'GET /ip HTTP/1.0\r\n\r\n')
        for i in range(3):
            print(s.recv(1024).decode('utf-8'))


# Generated at 2022-06-22 09:32:22.956694
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket()
    assert ss.type == socket.SOCK_STREAM
    assert ss.family == socket.AF_INET
    if hasattr(socket, 'AF_INET6'):
        assert ss.proto == 0 or ss.proto == socket.IPPROTO_IPV6


# Generated at 2022-06-22 09:32:26.159696
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    expected_version = 5
    got_version = 3
    try:
        raise InvalidVersionError(expected_version, got_version)
    except InvalidVersionError as e:
        assert e.args[1] == "Invalid response version from server. Expected 05 got 03"


# Generated at 2022-06-22 09:32:32.743147
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError('Code', 'Message')
    except ProxyError as e:
        assert e.args[0] == 'Code'
        assert e.args[1] == 'Message'
    try:
        raise ProxyError('Code')
    except ProxyError as e:
        assert e.args[0] == 'Code'
        assert e.args[1] == 'unknown error'

# Generated at 2022-06-22 09:32:35.228616
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:32:49.846220
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    print('Testing constructor of class Socks5AddressType')
    # Test case 1
    expected = Socks5AddressType.ATYP_IPV4
    actual = Socks5AddressType()
    print('Test case 1: Expected {0}, got {1}'.format(expected, actual))
    assert(expected == actual)

    print('Unit test completed successfully')

# Generated at 2022-06-22 09:32:52.843775
# Unit test for constructor of class ProxyType
def test_ProxyType():
    ptype = ProxyType
    assert ptype.SOCKS4 == 0
    assert ptype.SOCKS4A == 1
    assert ptype.SOCKS5 == 2


# Generated at 2022-06-22 09:32:55.038341
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.close()


if __name__ == '__main__':
    test_sockssocket()

# Generated at 2022-06-22 09:33:01.165833
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    socks5auth = Socks5Auth()
    assert socks5auth.AUTH_NONE == 0x00
    assert socks5auth.AUTH_GSSAPI == 0x01
    assert socks5auth.AUTH_USER_PASS == 0x02
    assert socks5auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:33:09.456764
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import unittest
    import test_utils
    import socks
    import socket

    class SocksSocketTest(unittest.TestCase):
        def setUp(self):
            self.client_socket = socks.socksocket()
            self.mock_socket = test_utils.mock_socket()
            self.client_socket.socket = self.mock_socket

        def test_connect_should_return_true_if_connect_successful(self):
            self.client_socket.connect(('1.1.1.1', '80'))
            self.assertTrue(self.mock_socket.connect.called)


# Generated at 2022-06-22 09:33:10.662810
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    Socks5Auth()

if __name__ == '__main__':
    test_Socks5Auth()

# Generated at 2022-06-22 09:33:17.359719
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    auth = Socks5Auth()
    assert auth.AUTH_NONE == 0x00
    assert auth.AUTH_GSSAPI == 0x01
    assert auth.AUTH_USER_PASS == 0x02
    assert auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:33:20.444065
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    error = InvalidVersionError(expected_version=7, got_version=3)
    assert error[0] == 0
    assert error[1] == 'Invalid response version from server. Expected 07 got 03'



# Generated at 2022-06-22 09:33:26.647566
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # Test for timeout
    def connect_ex(self, address):
        return -1
    socket.socket.connect_ex = connect_ex
    test_sockssocket = sockssocket()
    assert test_sockssocket.connect_ex(('127.0.0.1', '8080')) == -1
    # Test for success
    def connect_ex(self, address):
        return 0
    socket.socket.connect_ex = connect_ex
    test_sockssocket = sockssocket()
    assert test_sockssocket.connect_ex(('127.0.0.1', '8080')) == 0

# Generated at 2022-06-22 09:33:31.972979
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    try:
        s = sockssocket()
        s.setproxy(ProxyType.SOCKS5, 'localhost', 1080)
        s.connect(('www.google.com', 80))
        print('working')
    except ProxyError as e:
        print(e.args)
    except socket.error as e:
        print(e.args)

# Generated at 2022-06-22 09:33:48.726801
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ssock = sockssocket()
    assert isinstance(ssock, sockssocket)


# Generated at 2022-06-22 09:33:50.137201
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    command = Socks4Command()
    assert command.CMD_CONNECT == 0x01
    assert command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:33:53.751832
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(1, 'Invalid')
    except ProxyError as e:
        assert e.args[0] == 1
        assert str(e) == 'Invalid'


# Generated at 2022-06-22 09:33:54.315922
# Unit test for constructor of class sockssocket
def test_sockssocket():
    assert sockssocket

# Generated at 2022-06-22 09:33:57.860345
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    buf = sockssocket()
    buf.setproxy(2, "127.0.0.1", 1080)
    buf.connect(("127.0.0.1", 80))
    print("ok")

# Generated at 2022-06-22 09:33:59.920777
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert type(Socks5Error(1)) == ProxyError


# Generated at 2022-06-22 09:34:06.289388
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    auth = Socks5Auth()
    if not (auth.AUTH_NONE == 0x00 and auth.AUTH_GSSAPI == 0x01 and auth.AUTH_USER_PASS == 0x02 and auth.AUTH_NO_ACCEPTABLE == 0xFF):
        raise Exception('Socks5Auth init failed.')


# Generated at 2022-06-22 09:34:08.667419
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:34:12.762114
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    socks5_auth = Socks5Auth()
    assert socks5_auth.AUTH_NONE == 0x00
    assert socks5_auth.AUTH_GSSAPI == 0x01
    assert socks5_auth.AUTH_USER_PASS == 0x02
    assert socks5_auth.AUTH_NO_ACCEPTABLE == 0xFF
    return socks5_auth


# Generated at 2022-06-22 09:34:17.199495
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_IPV6 == 0x04
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    print('Test %s completed successfully' % __file__)

if __name__ == '__main__':
    test_Socks5AddressType()

# Generated at 2022-06-22 09:34:45.140779
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    # If you want to test sockssocket.connect, set following lines:
    # proxy_host = '127.0.0.1'
    # proxy_port = 1080
    # proxy_username = 'foo'
    # proxy_password = 'bar'
    # target_address = 'example.com'
    # target_port = 80
    # proxy_type = ProxyType.SOCKS5

    if 0:  # Change to 1 if you want to test sockssocket.connect
        s = sockssocket()
        s.setproxy(proxytype=proxy_type,
                   addr=proxy_host,
                   port=proxy_port,
                   rdns=False,  # If you want to use remote dns set to True
                   username=proxy_username,
                   password=proxy_password)

# Generated at 2022-06-22 09:34:47.995171
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:34:54.046772
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    with pytest.raises(ProxyError):
        raise Socks5Error(0x01)

    assert Socks5Error(0x01).strerror == 'general SOCKS server failure'

    with pytest.raises(InvalidVersionError):
        raise InvalidVersionError(0x01, 0x02)

    assert InvalidVersionError(0x01, 0x02).strerror == 'Invalid response version from server. Expected 01 got 02'

# Generated at 2022-06-22 09:34:59.751299
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy_input = Proxy(ProxyType.SOCKS5, '10.0.0.1', 1080, 'joe', 'secret', True)
    assert proxy_input.type == ProxyType.SOCKS5
    assert proxy_input.host == '10.0.0.1'
    assert proxy_input.port == 1080
    assert proxy_input.username == 'joe'
    assert proxy_input.password == 'secret'
    assert proxy_input.remote_dns == True

# Generated at 2022-06-22 09:35:09.032782
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(('localhost', 80))
    sock.sendall(b'GET / HTTP/1.0\r\nConnection: close\r\n\r\n')
    data = b''
    while True:
        data += sock.recvall(1024)
        if data.endswith(b'\r\n\r\n'):
            break
    assert data.startswith(b'HTTP/1.0') and data.endswith(b'\r\n\r\n')


if __name__ == '__main__':
    # Unit test for method recvall of class sockssocket
    test_sockssocket_recvall()

# Generated at 2022-06-22 09:35:14.849635
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    try:
        s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
        s.setproxy(ProxyType.SOCKS5, "127.0.0.1", 1080)
        s.connect_ex(("127.0.0.1", 80))
    except Exception as e:
        print("Exception: {}".format(e))
    while True:
        data = input("<<< ")
        s.sendall(data.encode("utf-8"))
        data = s.recv(4096).decode("utf-8")
        print(">>> ", data)
        if data == "":
            break
    s.close()

if __name__ == "__main__":
    test_sockssocket_connect_ex()

# Generated at 2022-06-22 09:35:21.303695
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    test_sockssocket_connect_ex.error = None

    def test_sockssocket_error_callback(e):
        test_sockssocket_connect_ex.error = e
        return None

    def _test_sockssocket_connect_ex(proxy_type, proxy_host, proxy_port, connect_host, connect_port):
        ss = sockssocket()
        ss.setproxy(proxy_type, proxy_host, proxy_port)
        if ss.connect_ex((connect_host, connect_port)) != 0:
            raise test_sockssocket_connect_ex.error


# Generated at 2022-06-22 09:35:23.304931
# Unit test for constructor of class Proxy
def test_Proxy():
    Proxy(ProxyType.SOCKS4, 'localhost', 3129, 'username', 'password', True)


# Generated at 2022-06-22 09:35:34.077188
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = socket.socket()
    sock.connect(('pymotw.com', 80))
    sock.sendall(b'GET / HTTP/1.0\r\n\r\n')
    socks = sockssocket(sock.family, sock.type, sock.proto)
    socks._sock = sock
    socks.setproxy(ProxyType.SOCKS5, 'localhost', 1080, 'username', 'password')
    socks._setup_socks5(('pymotw.com', 80))
    socks.sendall(b'GET / HTTP/1.0\r\n\r\n')
    resp = socks.recvall(8)
    print(type(resp), resp)
    resp = socks.recvall(80)
    print(type(resp), resp)


# Generated at 2022-06-22 09:35:41.716876
# Unit test for constructor of class ProxyError
def test_ProxyError():
    # Test normal initialization
    try:
        raise ProxyError(1)
    except ProxyError as e:
        assert e.code == 1
        assert e.errno == 1
        assert e.strerror == 'unknown error'

    # Test normal initialization
    try:
        raise ProxyError(1, 'test')
    except ProxyError as e:
        assert e.code == 1
        assert e.errno == 1
        assert e.strerror == 'test'

    # Test normal initialization
    try:
        raise ProxyError(2, 'test2')
    except ProxyError as e:
        assert e.code == 2
        assert e.errno == 2
        assert e.strerror == 'test2'

    # Test no arguments

# Generated at 2022-06-22 09:36:27.125033
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    s = sockssocket()
    assert isinstance(s, socket.socket)
    assert hasattr(s, 'connect')
    assert hasattr(s, 'connect_ex')

# Generated at 2022-06-22 09:36:34.235040
# Unit test for constructor of class sockssocket
def test_sockssocket():
    # Test sockssocket constructor
    import sys
    import random
    socket_family = [socket.AF_INET, socket.AF_INET6]
    socket_type = [socket.SOCK_DGRAM, socket.SOCK_STREAM]

    print("sockssocket: Testing constructor of class sockssocket")

# Generated at 2022-06-22 09:36:38.643229
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert type(Socks5Auth.AUTH_NONE) == int
    assert type(Socks5Auth.AUTH_GSSAPI) == int
    assert type(Socks5Auth.AUTH_USER_PASS) == int
    assert type(Socks5Auth.AUTH_NO_ACCEPTABLE) == int


# Generated at 2022-06-22 09:36:40.856435
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert (Socks5Command.CMD_CONNECT == 0x01)
    assert (Socks5Command.CMD_BIND == 0x02)

# Generated at 2022-06-22 09:36:44.498263
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01, "Error in line 59"
    assert Socks4Command.CMD_BIND == 0x02, "Error in line 60"

# Unit tests for constructor of class Socks5Auth

# Generated at 2022-06-22 09:36:48.503004
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 0)
    except InvalidVersionError as e:
        assert str(e) == 'Invalid response version from server. Expected 00 got 00'


# Generated at 2022-06-22 09:36:57.432401
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    # Test 'normal' case
    exc = Socks5Error(0x01)
    assert isinstance(exc, socket.error)
    assert exc.errno == 0x01
    assert exc.strerror == 'general SOCKS server failure' == Socks5Error.CODES[0x01]

    # Test the case when there is no error code
    exc = Socks5Error()
    assert isinstance(exc, socket.error)
    assert exc.errno == 0
    assert exc.strerror == 'unknown error'

# Generated at 2022-06-22 09:36:59.008083
# Unit test for constructor of class sockssocket
def test_sockssocket():
    server = sockssocket()
    assert server.type == socket.SOCK_STREAM


# Generated at 2022-06-22 09:37:02.462333
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks4Command.CMD_CONNECT == Socks5Command.CMD_CONNECT
    assert Socks4Command.CMD_BIND == Socks5Command.CMD_BIND

# Generated at 2022-06-22 09:37:06.749620
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    # This test does not check the code field of the error; it only checks for the presence of the variable msg
    code = 91
    msg = 'request rejected or failed'
    error = Socks4Error(code, msg)
    assert (error.errno == code) and (error.strerror == msg)

# Generated at 2022-06-22 09:38:37.888033
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    # pylint: disable=protected-access
    proxy = Proxy(ProxyType.SOCKS4, 'anyproxy', 8080, None, None, True)
    with sockssocket() as s:
        s._proxy = proxy
        assert s._setup_socks4(('localhost', 9090)) == (0x7f000001, 9090)

# Generated at 2022-06-22 09:38:39.568036
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 1
    assert Socks5Command.CMD_BIND == 2
    assert Socks5Command.CMD_UDP_ASSOCIATE == 3

# Generated at 2022-06-22 09:38:44.139799
# Unit test for constructor of class ProxyType
def test_ProxyType():
    socks5 = ProxyType.SOCKS5
    socks4 = ProxyType.SOCKS4
    socks4a = ProxyType.SOCKS4A

    assert socks5 == 2
    assert socks4 == 0
    assert socks4a == 1


# Generated at 2022-06-22 09:38:46.789886
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    e = Socks5Error()
    try:
        raise e
    except Socks5Error:
        assert True
    else:
        assert False

# Generated at 2022-06-22 09:38:50.611804
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    cmd = Socks5Command()
    if cmd.CMD_CONNECT != 0x01:
        raise Exception("Socks5 command \"CONNECT\" must be 0x01")
    if cmd.CMD_UDP_ASSOCIATE != 0x03:
        raise Exception("Socks5 command \"UDP ASSOCIATE\" must be 0x03")
    return True

# Generated at 2022-06-22 09:38:58.437649
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    addr = ('192.168.1.1', 80)
    h = sockssocket()
    try:
        h.connect(addr)
    except socket.error:
        pass
    else:
        raise AssertionError('connect to {0} must failed'.format(addr))
    h.setproxy(ProxyType.SOCKS4, 'localhost', 80)
    try:
        h.connect(addr)
    except socket.error:
        pass
    else:
        raise AssertionError('connect to {0} via SOCKS4 must failed'.format(addr))
    h.close()
    h = sockssocket()
    h.setproxy(ProxyType.SOCKS5, 'localhost', 80)
    try:
        h.connect(addr)
    except socket.error:
        pass

# Generated at 2022-06-22 09:39:03.392501
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    ss = sockssocket()
    ss.setproxy(ProxyType.SOCKS5, '127.0.0.1', 9050)
    try:
        ss.connect(('www.google.com', 80))
    except socket.error as e:
        print('Can not connect to the SOCKS5 proxy', e)
    else:
        print('Connected to the SOCKS5 proxy')


# Generated at 2022-06-22 09:39:11.993378
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import random

    sock = sockssocket()

    class FakeSocket(object):
        def recv(self, cnt):
            values = [random.randint(0x00, 0xFF) for i in range(cnt)]
            return b''.join([compat_struct_pack('B', value) for value in values])
    sock.recv = FakeSocket().recv

    assert sock.recvall(2) == b'\x00\x00'
    assert sock.recvall(3) == b'\x11\x22\x33'
    assert sock.recvall(4) == b'\x44\x55\x66\x77'
    assert sock.recvall(5) == b'\x88\x99\xaa\xbb\xcc'
    assert sock.recv

# Generated at 2022-06-22 09:39:13.437157
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error(0x01).strerror == 'general SOCKS server failure'

# Generated at 2022-06-22 09:39:20.613017
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
    assert Socks5Command.CMD_UDP_ASSOCIATE != Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_UDP_ASSOCIATE != Socks4Command.CMD_BIND

if __name__ == '__main__':
    test_Socks5Command()