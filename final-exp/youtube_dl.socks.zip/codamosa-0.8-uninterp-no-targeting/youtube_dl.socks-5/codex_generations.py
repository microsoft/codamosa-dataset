

# Generated at 2022-06-22 09:31:44.544971
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:31:46.153615
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket()
    assert ss._proxy is None


# Generated at 2022-06-22 09:31:54.538156
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError()
    except ProxyError as err:
        assert err.args[0] == None and err.args[1] == None
    try:
        raise ProxyError(1, 'error message')
    except ProxyError as err:
        assert err.args[0] == 1 and err.args[1] == 'error message'
    try:
        raise ProxyError(1)
    except ProxyError as err:
        assert err.args[0] == 1 and err.args[1] == 'unknown error'


# Generated at 2022-06-22 09:31:59.708915
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error(Socks5Error.ERR_GENERAL_FAILURE).args[1] == 'general SOCKS server failure'
    assert Socks5Error(0x01).args[1] == 'general SOCKS server failure'



# Generated at 2022-06-22 09:32:03.276904
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(4, 5)
    except InvalidVersionError as e:
        assert e.args[0] == 4
        assert e.args[1] == 5
        return True
    else:
        assert False

# Generated at 2022-06-22 09:32:06.487630
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error(Socks5Error.ERR_GENERAL_FAILURE).args == (Socks5Error.ERR_GENERAL_FAILURE,
                                                                'general SOCKS server failure')

# Unit tests for constructor of class Socks4Error

# Generated at 2022-06-22 09:32:11.916328
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    try:
        assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
        assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
        assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03
    except AssertionError:
        print('Socks5Command does not work!')


# Generated at 2022-06-22 09:32:21.573676
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    from .socks import PROXY_TYPE_SOCKS5, PROXY_TYPE_HTTP, PROXY_TYPE_SOCKS4
    from .sockshandler import SocksiPyHandler
    from .urllib import request

    urlopen = request.urlopen

    SOCKS_PROXY_HOST = "192.168.10.135"
    SOCKS_PROXY_PORT = 7070

    SOCKS5_PROXY_HOST = "192.168.10.135"
    SOCKS5_PROXY_PORT = 1080

    HTTP_PROXY_HOST = "192.168.10.135"
    HTTP_PROXY_PORT = 8888

    PROXY_USERNAME = "username"
    PROXY_PASSWORD = "password"

    proxy_type = PROXY_TYPE_SOCKS

# Generated at 2022-06-22 09:32:25.987861
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    auth = Socks5Auth()
    assert auth.AUTH_NONE == 0x00
    assert auth.AUTH_GSSAPI == 0x01
    assert auth.AUTH_USER_PASS == 0x02
    assert auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:32:29.405198
# Unit test for constructor of class sockssocket
def test_sockssocket():
    socks = sockssocket()
    assert isinstance(socks, socket.socket)
    return socks


# Generated at 2022-06-22 09:32:41.763688
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    test_auth = Socks5Auth()

# Generated at 2022-06-22 09:32:52.353624
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    ss = sockssocket()

    assert not ss._proxy

    ss.setproxy(ProxyType.SOCKS4, 'localhost', 1080)

    assert isinstance(ss._proxy, Proxy)
    assert ss._proxy.type == ProxyType.SOCKS4
    assert ss._proxy.host == 'localhost'
    assert ss._proxy.port == 1080
    assert ss._proxy.username is None
    assert ss._proxy.password is None
    assert ss._proxy.remote_dns

    ss.setproxy(ProxyType.SOCKS5, 'localhost', 1080, rdns=False, username='test', password='test')

    assert isinstance(ss._proxy, Proxy)
    assert ss._proxy.type == ProxyType.SOCKS5
    assert ss._proxy.host == 'localhost'
    assert ss._proxy.port == 1080


# Generated at 2022-06-22 09:32:57.627760
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-22 09:33:01.562816
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    test_code = 0x01
    test_msg = 'request rejected or failed'
    test_instance = Socks4Error(test_code)
    assert test_instance.errno == test_code
    assert test_instance.strerror == test_msg


# Generated at 2022-06-22 09:33:03.183094
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error(code=91).args == (91, 'request rejected or failed')



# Generated at 2022-06-22 09:33:10.810866
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    sockssocket.setproxy(ProxyType.SOCKS4, '169.254.202.170', 9150, rdns=True, username=None, password=None)
    # sockssocket.setproxy(ProxyType.SOCKS5, '169.254.202.170', 9150, rdns=True, username=None, password=None)
    # sockssocket.setproxy(ProxyType.SOCKS4A, '169.254.202.170', 9150, rdns=True, username=None, password=None)
    # sockssocket.connect_ex(('www.google.com', 80))
    sockssocket.connect_ex(('169.254.202.170', 9150))
    print("connection succeeded: ")
    print("succeeded.")


# s = socket.socket(socket.AF_

# Generated at 2022-06-22 09:33:23.495631
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    import sys
    sys.stderr.write('Testing method setproxy of class sockssocket...\n')
    # Note: currently we are using localhost as the socks server, we were
    # unable to get remoteserver working (it refused all connections).
    # It is possible to test a remote server by setting the environment
    # variable 'REMOTE_SERVER' to it, but you will need to modify the
    # test to use your credentials on that server.
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, 'localhost', 1080)
    s.settimeout(5) # Five seconds timeout
    s.connect(('google.com', 80))
    s.close()
    sys.stderr.write('Finished.\n')

if __name__ == '__main__':
    test_s

# Generated at 2022-06-22 09:33:30.095268
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    invalid_version = InvalidVersionError(0x01, 0x02)
    assert isinstance(invalid_version, InvalidVersionError)
    assert isinstance(invalid_version, ProxyError)
    assert isinstance(invalid_version, socket.error)
    assert invalid_version.errno == 0
    assert invalid_version.strerror == 'Invalid response version from server. Expected 01 got 02'


# Generated at 2022-06-22 09:33:32.916275
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    exc = InvalidVersionError(0, 0xff)
    assert exc.args[0] == 0
    assert exc.args[1] == 'Invalid response version from server. Expected 00 got ff'

# Generated at 2022-06-22 09:33:38.229280
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 1)
    except InvalidVersionError as e:
        assert e.code == 0
        assert e.message == 'Invalid response version from server. Expected 00 got 01'
    else:
        assert False, 'It should raise an exception'


# Generated at 2022-06-22 09:34:14.300466
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError(0, 'msg').strerror == 'msg'
    assert ProxyError(0).strerror == 'unknown error'


# Generated at 2022-06-22 09:34:17.238883
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 1)
    except InvalidVersionError as error:
        assert error.args[0] == 0
        assert error.args[1] == 'Invalid response version from server. Expected 00 got 01'

# Generated at 2022-06-22 09:34:19.804773
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    auth = Socks5Auth()
    assert auth.AUTH_NONE == 0x00
    assert auth.AUTH_GSSAPI == 0x01
    assert auth.AUTH_USER_PASS == 0x02
    assert auth.AUTH_NO_ACCEPTABLE == 0xFF

# Generated at 2022-06-22 09:34:24.006447
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(0x91)
    except Exception as ex:
        assert 'request rejected or failed' == ex.strerror


# Generated at 2022-06-22 09:34:26.225922
# Unit test for constructor of class ProxyError
def test_ProxyError():
    err = ProxyError()
    assert err.args == (None, None)
    err = ProxyError(ProxyError.ERR_SUCCESS)
    assert err.args == (0x00, 'unknown error')
    err = ProxyError(99, 'test')
    assert err.args == (99, 'test')


# Generated at 2022-06-22 09:34:27.394617
# Unit test for constructor of class sockssocket
def test_sockssocket():
    x = sockssocket()
    assert x.__class__ == sockssocket

# Generated at 2022-06-22 09:34:31.143974
# Unit test for constructor of class ProxyError
def test_ProxyError():
    pe = ProxyError(0, 'msg')
    assert pe.errno == 0

    pe = ProxyError(None, None)
    assert pe.errno is None

# Generated at 2022-06-22 09:34:42.800527
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    # Check success
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    assert sock.connect(('127.0.0.1', 8080)) == 0
    assert sock.connect_ex(('127.0.0.1', 8080)) == 0

    # Check failure
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    assert sock.connect(('192.0.2.1', 12345)) == 0
    try:
        sock.recv(1)
        assert False, 'Connection should be closed'
    except socket.error:
        pass
    assert sock.connect_ex(('192.0.2.1', 12345)) == 0

# Generated at 2022-06-22 09:34:47.609914
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    SOCKS4_COMMAND_CMD_CONNECT = Socks4Command.CMD_CONNECT
    SOCKS4_COMMAND_CMD_BIND = Socks4Command.CMD_BIND
    assert SOCKS4_COMMAND_CMD_CONNECT == 0x01
    assert SOCKS4_COMMAND_CMD_BIND == 0x02
    socks4_command = Socks4Command()
    assert socks4_command.CMD_CONNECT == 0x01
    assert socks4_command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:34:49.559755
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sockssocket()


if __name__ == '__main__':
    test_sockssocket()

# Generated at 2022-06-22 09:35:50.582322
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sockssocket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    sock = sockssocket()
    sock.connect(('google.com', 80))


# Generated at 2022-06-22 09:35:53.207392
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError()
    assert ProxyError(msg='test')
    assert ProxyError(1, 'test')


# Generated at 2022-06-22 09:35:56.099443
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    socks_socket = sockssocket()
    socks_socket.setproxy(SOCKS5, 'localhost', 1080)
    assert socks_socket.connect_ex(('localhost', 1080)) == 0

# Generated at 2022-06-22 09:36:00.183227
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS4A, '127.0.0.1', 1080, 'username', 'password', True)

    assert proxy.type == ProxyType.SOCKS4A
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 1080
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns == True

# Generated at 2022-06-22 09:36:01.290573
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket()
    assert ss.getpeername() is None


# Generated at 2022-06-22 09:36:04.459916
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    _proxy_type = ProxyType
    type_defined = {'SOCKS4':0, 'SOCKS4A':1, 'SOCKS5':2}
    assert type_defined == _proxy_type.__dict__


# Generated at 2022-06-22 09:36:11.344669
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    address, port = '192.168.1.1', 1
    proxy_type, proxy_address, proxy_port, _, _, _ = ProxyType.SOCKS5, '192.168.2.2', 2, None, None, None
    connected = False
    sockssocket_ = sockssocket()
    sockssocket_.setproxy(proxy_type, proxy_address, proxy_port)
    sockssocket_.connect = lambda address: connected
    assert sockssocket_.connect_ex((address, port)) == 0

    connected = True
    assert sockssocket_.connect_ex((address, port)) == 0

    proxy_type, proxy_address, proxy_port, _, _, _ = ProxyType.SOCKS5, '192.168.2.2', 2, None, None, None
    connected = True
    sockssocket_ = sockssocket()

# Generated at 2022-06-22 09:36:13.185956
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket()
    assert type(ss) == sockssocket


# Generated at 2022-06-22 09:36:17.076065
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03

# Generated at 2022-06-22 09:36:19.021133
# Unit test for constructor of class sockssocket

# Generated at 2022-06-22 09:37:35.790521
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    proxy_type = Socks4Command()
    print(proxy_type.CMD_CONNECT)
    print(proxy_type.CMD_BIND)


# Generated at 2022-06-22 09:37:38.562127
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS4, 'localhost', 80, 'username', 'password', False)

    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == 'localhost'
    assert proxy.port == 80
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns == False

# Generated at 2022-06-22 09:37:39.823303
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    Socks5Auth().__init__()



# Generated at 2022-06-22 09:37:50.088681
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import socks
    import socket

    socks.set_default_proxy(socks.HTTP, "localhost", 9999)
    s = socks.socksocket()

    # Connect to a TCP server
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 54321))
        sock.listen()

        # Test standard use case
        try:
            s.connect(("127.0.0.1", 54321))
            assert s.connect_ex(("127.0.0.1", 54321)) == 0
        finally:
            s.close()

        # Test second connect

# Generated at 2022-06-22 09:37:54.628146
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert (Socks5Command.CMD_CONNECT == 0x01) and \
           (Socks5Command.CMD_BIND == 0x02) and \
           (Socks5Command.CMD_UDP_ASSOCIATE == 0x03), \
        'Error in socks.py: class Socks5Command'

# Generated at 2022-06-22 09:37:59.293804
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0x01, 0x02)
    except InvalidVersionError as e:
        assert e.args[0] == 0
        assert e.args[1] == 'Invalid response version from server. Expected 01 got 02'
    else:
        raise AssertionErro

# Generated at 2022-06-22 09:38:02.891766
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04

# Generated at 2022-06-22 09:38:07.906894
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02


# Generated at 2022-06-22 09:38:10.451795
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:38:15.088286
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    ss = sockssocket()
    ss.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    ss.connect_ex(('127.0.0.1', 80))
    ss.close()

if __name__ == '__main__':
    test_sockssocket_connect_ex()