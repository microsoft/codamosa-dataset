

# Generated at 2022-06-22 09:31:52.226365
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import random
    import unittest
    import urllib2

    class HTTPProxyTest(unittest.TestCase):
        def setUp(self):
            self.proxy_address = 'localhost:3128'
            self.test_url = 'https://www.python.org/'
            self.test_timeout = 3

        def test_connect_via_httpproxy(self):
            proxy_handler = urllib2.ProxyHandler({
                'http': self.proxy_address,
                'https': self.proxy_address,
            })
            opener = urllib2.build_opener(proxy_handler, sockssocket.HTTPSConnection, sockssocket.HTTPConnection)

# Generated at 2022-06-22 09:31:55.217907
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    addressType = Socks5AddressType()
    assert addressType.ATYP_IPV4 == 0x01
    assert addressType.ATYP_DOMAINNAME == 0x03
    assert addressType.ATYP_IPV6 == 0x04

# Generated at 2022-06-22 09:32:01.737328
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    error = Socks5Error()
    assert error.code == None
    assert error.args[0] == None
    assert error.args[1] == None
    assert error.args[1] == 'unknown error'
    assert error.strerror == None
    assert error.args[0] == None
    assert error.args[1] == None
    assert error.args[1] == 'unknown error'
    assert error.strerror == None

# Generated at 2022-06-22 09:32:03.912924
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert isinstance(ProxyType.SOCKS5, int)

# Unit tests for constructor of class Proxy

# Generated at 2022-06-22 09:32:08.827458
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error
    except ProxyError as e:
        print(type(e))
        print(e.code)
        print(e.msg)


# Generated at 2022-06-22 09:32:11.052652
# Unit test for constructor of class sockssocket
def test_sockssocket():
    print('test_sockssocket() begin')
    ss = sockssocket()
    print('test_sockssocket() end')


# Generated at 2022-06-22 09:32:17.200089
# Unit test for constructor of class Proxy
def test_Proxy():
    try:
        proxy = Proxy(1, 'host', 'port', 'username', 'password', 'remote_dns')
        assert proxy.type == 1
        assert proxy.host == 'host'
        assert proxy.port == 'port'
        assert proxy.username == 'username'
        assert proxy.password == 'password'
        assert proxy.remote_dns == 'remote_dns'

    except Exception as e:
        print(e)


# Generated at 2022-06-22 09:32:18.524572
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    pass


# Generated at 2022-06-22 09:32:22.611127
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()
    assert s
    print('Successfully created sockssocket object')


if __name__ == "__main__":
    test_sockssocket()

# Generated at 2022-06-22 09:32:26.737963
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    s = sockssocket()
    s.setproxy(
        proxytype=ProxyType.SOCKS5,
        addr='127.0.0.1',
        port=1080,
        rdns=False,
        username='username',
        password='password'
    )

    s.connect_ex(('www.google.com', 80))


# Generated at 2022-06-22 09:32:38.235615
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 1
    assert Socks5AddressType.ATYP_DOMAINNAME == 3
    assert Socks5AddressType.ATYP_IPV6 == 4

# Generated at 2022-06-22 09:32:45.107718
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    result = Socks5Auth()
    if result.AUTH_NONE != 0x00 or \
        result.AUTH_GSSAPI != 0x01 or \
        result.AUTH_USER_PASS != 0x02 or \
        result.AUTH_NO_ACCEPTABLE != 0xff:
        print("Socks5Auth() failed")
    else:
        print("Socks5Auth() passed")

# Generated at 2022-06-22 09:32:48.104152
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    error = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    assert str(error) == "SOCKS5Error: 0x01 (general SOCKS server failure)"

# Generated at 2022-06-22 09:32:49.703948
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sockssocket()


# Generated at 2022-06-22 09:32:53.212098
# Unit test for constructor of class ProxyType
def test_ProxyType():
    p = ProxyType()
    assert p.SOCKS4 == 0
    assert p.SOCKS4A == 1
    assert p.SOCKS5 == 2


# Generated at 2022-06-22 09:33:05.146743
# Unit test for constructor of class ProxyType
def test_ProxyType():
    import unittest
    class TestProxyType(unittest.TestCase):
        def test_socks4(self):
            p = Proxy(ProxyType.SOCKS4, '127.0.0.1', 1080, 'username', 'password', True)
            self.assertEqual(p.type, 0)
            self.assertEqual(p.host, '127.0.0.1')
            self.assertEqual(p.port, 1080)
            self.assertEqual(p.username, 'username')
            self.assertEqual(p.password, 'password')
            self.assertEqual(p.remote_dns, True)

# Generated at 2022-06-22 09:33:06.977173
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0xFF, 0x00)
    except InvalidVersionError as e:
        print(e)
        assert(e.code == 0x00)


# Generated at 2022-06-22 09:33:09.900797
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    except Socks5Error as e:
        assert e.args[0] == 1
        assert e.message == 'general SOCKS server failure'


# Generated at 2022-06-22 09:33:19.394237
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 12345)
    s.connect(('www.google.com', 80))
    data = b'GET / HTTP/1.0\r\nHost: www.google.com\r\n\r\n'
    s.sendall(data)
    response = s.recv(1024)
    print(response)
    s.close()

if __name__ == '__main__':
    test_sockssocket_connect()

# Generated at 2022-06-22 09:33:25.897706
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    err = Socks5Error()
    assert err.args[0] != 'Network unreachable'
    err = Socks5Error(0x01)
    assert err.args[0] == 0x01
    err = Socks5Error(0x03)
    assert err.args[0] == 0x03
    assert err.args[1] == 'Network unreachable'

if __name__ == '__main__':
    test_Socks5Error()

# Generated at 2022-06-22 09:33:40.399787
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    e = Socks4Error()
    if str(e) != Socks4Error.CODES[Socks4Error.ERR_SUCCESS]:
        raise Exception('Unexpected default message')

    e = Socks4Error(91)
    if str(e) != Socks4Error.CODES[91]:
        raise AssertionError()

    e = Socks4Error(code=92)
    if str(e) != Socks4Error.CODES[92]:
        raise AssertionError()

    e = Socks4Error(95)
    if str(e) != 'unknown error':
        raise AssertionError()

    try:
        e = Socks4Error('1')
        raise AssertionError("shouldn't get here")
    except TypeError:
        pass

# Unit test

# Generated at 2022-06-22 09:33:45.273047
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 10080)
    assert s._proxy.type == ProxyType.SOCKS4
    s.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 10080)
    assert s._proxy.type == ProxyType.SOCKS4A
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 10080)
    assert s._proxy.type == ProxyType.SOCKS5
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 10080, username='username', password='password')
    assert s._proxy.type == ProxyType.SOCKS5

# Generated at 2022-06-22 09:33:48.445746
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    proxy = Proxy(ProxyType.SOCKS4, 'localhost', 8888)
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setproxy(*proxy)
    sock.connect(('1.1.1.1', 80))

if __name__ == '__main__':
    test_sockssocket_connect()
    print('All test passed.')

# Generated at 2022-06-22 09:33:51.109633
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    s_ = sockssocket()
    s_.setproxy(ProxyType.SOCKS5, '194.85.150.170', 80)
    s_.connect_ex(('203.174.118.10', 80))
    # print('Socket connected via SOCKS.')

# Generated at 2022-06-22 09:33:57.823052
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    if Socks5Command.CMD_CONNECT != 1:
        raise ValueError("Socks5Command test failed")
    if Socks5Command.CMD_BIND != 2:
        raise ValueError("Socks5Command test failed")
    if Socks5Command.CMD_UDP_ASSOCIATE != 3:
        raise ValueError("Socks5Command test failed")
    print("Socks5Command test succeed")


# Generated at 2022-06-22 09:34:09.921205
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    # Test with several IPs
    ips = ["8.8.8.8", "8.8.4.4"]
    ports = [22, 80]

# Generated at 2022-06-22 09:34:10.967881
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    Socks4Command()


# Generated at 2022-06-22 09:34:13.464607
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-22 09:34:18.308318
# Unit test for constructor of class Proxy
def test_Proxy():
    # Test ProxyType.SOCKS4
    proxy1 = Proxy(ProxyType.SOCKS4, 'test_host', 'test_port', 'test_username', 'test_password', False)
    assert proxy1.type == ProxyType.SOCKS4
    assert proxy1.host == 'test_host'
    assert proxy1.port == 'test_port'
    assert proxy1.username == 'test_username'
    assert proxy1.password == 'test_password'
    assert proxy1.remote_dns == False

    # Test ProxyType.SOCKS4A
    proxy2 = Proxy(ProxyType.SOCKS4A, 'test_host', 'test_port', 'test_username', 'test_password', False)
    assert proxy2.type == ProxyType.SOCKS4A
    assert proxy2.host

# Generated at 2022-06-22 09:34:23.692507
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sockssocket_test = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sockssocket_test.settimeout(2)
    sockssocket_test.connect(('google.com', 80))
    sockssocket_test.sendall(b'GET / HTTP/1.1\r\nHost: google.com\r\n\r\n')
    headers = b''
    while not headers.endswith(b'\r\n\r\n') and not headers.endswith(b'\n\n'):
        headers += sockssocket_test.recv(1)

# Generated at 2022-06-22 09:35:02.584412
# Unit test for constructor of class ProxyType
def test_ProxyType():
    p = Proxy(ProxyType.SOCKS5, '172.16.0.1', 8080, 'username', 'password', True)
    assert isinstance(p.type, ProxyType)
    assert p.host == '172.16.0.1'
    assert p.port == 8080
    assert p.username == 'username'
    assert p.password == 'password'
    assert p.remote_dns == True

    # Construct Proxy from tuple
    p = Proxy(**dict(list(zip(list(Proxy._fields), p))))
    assert p.type == ProxyType.SOCKS5
    assert p.host == '172.16.0.1'
    assert p.port == 8080
    assert p.username == 'username'
    assert p.password == 'password'

# Generated at 2022-06-22 09:35:10.974646
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    INPUT_STRING = "abcdef"
    DEFAULT_TIMEOUT = 30
    SOCKET_ADDRESS = "google.com"
    SOCKET_PORT = 80
    SOCKET_ADDRESS_FULL = (SOCKET_ADDRESS, SOCKET_PORT)

    s = sockssocket()

# Generated at 2022-06-22 09:35:12.283841
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 1



# Generated at 2022-06-22 09:35:15.761462
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    # Test connecting to a proxy that doesn't need authentication
    with sockssocket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setproxy(ProxyType.SOCKS4, '127.0.0.1', 12345)
        sock.connect(('www.example.com', 123))


# Generated at 2022-06-22 09:35:18.809600
# Unit test for constructor of class ProxyType
def test_ProxyType():
    f = ProxyType()
    print(f.SOCKS4)
    print(f.SOCKS5)


# Generated at 2022-06-22 09:35:25.748727
# Unit test for constructor of class Proxy
def test_Proxy():
    p1 = Proxy(ProxyType.SOCKS4, '127.0.0.1', 1080)
    assert p1.type == ProxyType.SOCKS4
    assert p1.port == 1080
    assert p1.host == '127.0.0.1'
    assert p1.username is None
    assert p1.password is None
    assert p1.remote_dns is True
    p2 = Proxy(ProxyType.SOCKS5, '127.0.0.1', 1080, 'usr', 'pass', False)
    p3 = p2._replace(host='example.com')
    assert p2.host == '127.0.0.1'
    assert p3.host == 'example.com'


# Generated at 2022-06-22 09:35:36.194819
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    if __name__ == '__main__':
        from binascii import b2a_hex
        from socket import error as SocketError
        from .compatpatch import ClientCompatPatch

        socks = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
        socks.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1080)
        socks.settimeout(3.0)

        try:
            socks.connect(('vimeo.com', 80))
        except SocketError:
            print('sockssocket.connect: SocketError')
            import traceback
            traceback.print_exc()
        else:
            print('Connected to', socks.getpeername())
            print('Reading reponse')
            data = socks.recv(1024)

# Generated at 2022-06-22 09:35:39.614096
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF  # For server response


# Generated at 2022-06-22 09:35:43.532369
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.__init__ == object.__init__
    assert Socks4Command.CMD_BIND == 0x02
    assert Socks4Command.CMD_CONNECT == 0x01


# Generated at 2022-06-22 09:35:53.097792
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    ss.setproxy(
        ProxyType.SOCKS5, '127.0.0.1',
        1080, username='username', password='password')
    try:
        ss.connect(('www.google.com', 80))
        print(ss.recv(32))
        ss.close()
    except ProxyError as ex:
        print('SOCKS ERROR CODE:', ex.errno)
        print(ex)


if __name__ == '__main__':
    test_sockssocket_connect()

# Generated at 2022-06-22 09:36:36.069286
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        assert(sock.recvall(1) == b'\x00')
    except EOFError:
        return 0
    return 1


# Generated at 2022-06-22 09:36:42.445755
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    import ssl
    sockssocket = sockssocket()
    assert(sockssocket._proxy is None)
    sockssocket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    assert(sockssocket._proxy is not None)
    # Test that we can create an SSL object
    ssl.wrap_socket(sockssocket)
    sockssocket.close()

if __name__ == '__main__':
    test_sockssocket_setproxy()

# Generated at 2022-06-22 09:36:48.607487
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS5, '127.0.0.1', 9000, 'bob', 'secret', remote_dns=False)
    assert proxy.type == ProxyType.SOCKS5
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 9000
    assert proxy.username == 'bob'
    assert proxy.password == 'secret'
    assert not proxy.remote_dns

if __name__ == '__main__':
    test_Proxy()

# Generated at 2022-06-22 09:36:51.371882
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error().message == ''
    assert Socks4Error(100).message == 'unknown error'
    assert Socks4Error(91).message == 'request rejected or failed'
    assert Socks4Error(92).message == 'request rejected because SOCKS server cannot connect to identd on the client'
    assert Socks4Error(93).message == 'request rejected because the client program and identd report different user-ids'


# Generated at 2022-06-22 09:37:01.709244
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import sys
    s = sockssocket()
    if sys.version_info[1] < 7:
        # No test for Python < 2.7
        return

    # Connect to local webserver:
    address = ('localhost', 8000)
    s.connect(address)
    # Get status line of HTTP response
    data = b''
    # Receive 9 bytes from socket
    data = s.recv(9)
    # Receive (69 - 9) bytes from socket
    data += s.recvall(60)


# Generated at 2022-06-22 09:37:03.604644
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:37:05.409854
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:37:11.325111
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    # Test 1
    inv_version_err_1 = InvalidVersionError(0x04, 0x06)
    assert inv_version_err_1.strerror == 'Invalid response version from server. Expected 04 got 06'
    # Test 2
    inv_version_err_2 = InvalidVersionError(0x04, 0x06)
    assert inv_version_err_2.strerror == 'Invalid response version from server. Expected 04 got 06'


# Generated at 2022-06-22 09:37:20.404762
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    """Test method recvall of class sockssocket
    """
    test_socks = sockssocket()

    def test_socks_recv(cnt):
        data = b'testdata'
        return data[:cnt]

    test_socks.recv = test_socks_recv

    assert test_socks.recvall(4) == b'test'
    assert test_socks.recvall(0) == b''
    from pytest import raises
    with raises(EOFError):
        test_socks.recvall(100)



# Generated at 2022-06-22 09:37:24.681497
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:38:07.338166
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    proxy = Proxy(ProxyType.SOCKS5, '127.0.0.1', 1080, 'username', 'password', False)
    assert proxy.type == ProxyType.SOCKS5
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 1080
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns == False

    socks = sockssocket()
    socks.setproxy(proxy.type, proxy.host, proxy.port, proxy.remote_dns, proxy.username, proxy.password)
    assert socks._proxy == proxy

    socks.setproxy('socks5', '127.0.0.1', 1080, True, 'username', 'password')
    assert socks._proxy == proxy


# Generated at 2022-06-22 09:38:13.786760
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import time
    import random
    import sys
    import time
    import threading
    from .compat import (
        compat_struct_pack,
        compat_struct_unpack,
        compat_chr,
        compat_ord,
        compat_socket_error,
        )
    import socket

    # Default values
    target_host = 'wikipedia.org'
    target_port = 443
    proxy_host = '127.0.0.1'
    proxy_port = 1080
    logging = False

    # Commandline arguments handling
    if len(sys.argv) > 1:
        target_host = sys.argv[1]
    if len(sys.argv) > 2:
        target_port = int(sys.argv[2])

# Generated at 2022-06-22 09:38:24.523484
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    socks5_proxy_host = '127.0.0.1'
    socks5_proxy_port = 1080
    socks5_proxy_username = "username"
    socks5_proxy_password = "password"
    if have_ipv6:
        testipv6_addr = "2001:0db8:85a3:0042:1000:8a2e:0370:7334"
        server_address = (testipv6_addr, 80, 0, 0)
    else:
        server_address = ('127.0.0.1', 80)
    x = sockssocket()
    x.setproxy(socks.PROXY_TYPE_SOCKS5, socks5_proxy_host, socks5_proxy_port, True, socks5_proxy_username,
               socks5_proxy_password)
    print

# Generated at 2022-06-22 09:38:33.034372
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    Socks4CommandTest = Socks4Command()

    if isinstance(Socks4CommandTest, object) == False:
        raise AssertionError('Socks4Command is not an object')
    if Socks4CommandTest.CMD_CONNECT != 0x01:
        raise AssertionError('Socks4Command: CMD_CONNECT should be 0x01')
    if Socks4CommandTest.CMD_BIND != 0x02:
        raise AssertionError('Socks4Command: CMD_BIND should be 0x02')


# Generated at 2022-06-22 09:38:35.859058
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    err = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    assert err.strerror == 'general SOCKS server failure'

# Generated at 2022-06-22 09:38:38.565307
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    command = Socks4Command()
    print(command)
    print(command.CMD_CONNECT)
    print(command.CMD_BIND)


# Generated at 2022-06-22 09:38:42.069959
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 1)
    except InvalidVersionError as e:
        assert e.args[0] == 0
        assert e.args[1] == 'Invalid response version from server. Expected 00 got 01'

# Generated at 2022-06-22 09:38:43.403794
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    test = InvalidVersionError(0x01, 0x02)

# Generated at 2022-06-22 09:38:46.570361
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    error = Socks4Error(code=0)
    assert error.strerror == 'request rejected or failed'
    assert error.args == (0, 'request rejected or failed')

# Generated at 2022-06-22 09:38:49.393473
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    # Test constructor of Socks5Error
    test_error = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    assert test_error.args == (1, 'general SOCKS server failure')


# Generated at 2022-06-22 09:40:14.338557
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    Socks5Command.CMD_CONNECT = 0x01
    Socks5Command.CMD_BIND = 0x02
    Socks5Command.CMD_UDP_ASSOCIATE = 0x03
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-22 09:40:22.693295
# Unit test for constructor of class ProxyError
def test_ProxyError():
    err = ProxyError()
    assert err.args == (None, 'unknown error')

    err = ProxyError(code=0)
    assert err.args == (0, 'unknown error')

    err = ProxyError(msg='test message')
    assert err.args == (None, 'test message')

    err = ProxyError(code=30, msg='test message')
    assert err.args == (30, 'test message')

# Generated at 2022-06-22 09:40:29.388696
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    print(Socks4Error(92, 'request rejected because SOCKS server cannot connect to identd on the client'))
    print(Socks4Error(93, 'request rejected because the client program and identd report different user-ids'))
    # print(Socks4Error(22))
    print(Socks4Error(None, 'request rejected because the client program and identd report different user-ids'))
    # print(Socks4Error(None))


# Generated at 2022-06-22 09:40:36.450508
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    err = Socks4Error()
    assert err.args == (None, None)
    err = Socks4Error(0)
    assert err.args == (0, 'unknown error')
    err = Socks4Error(91)
    assert err.args == (91, 'request rejected or failed')
    err = Socks4Error(93, 'x')
    assert err.args == (93, 'x')


# Generated at 2022-06-22 09:40:39.926504
# Unit test for constructor of class sockssocket
def test_sockssocket():
    expected_proxy = (
        ProxyType.SOCKS4, 'localhost', 4711, 'username', 'password', True)
    c = sockssocket()
    c.setproxy(*expected_proxy)
    assert c._proxy == expected_proxy

# Generated at 2022-06-22 09:40:42.028856
# Unit test for constructor of class ProxyType
def test_ProxyType():
    def _check(ptype):
        assert ptype.SOCKS4 == 0
        assert ptype.SOCKS4A == 1
        assert ptype.SOCKS5 == 2
    _check(ProxyType)

# Generated at 2022-06-22 09:40:45.529806
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-22 09:40:54.862326
# Unit test for constructor of class sockssocket
def test_sockssocket():
    import sys
    if sys.version_info < (2, 7):
        return
    import unittest
    import socket
    import socket_server

    class TestSocksSocket(unittest.TestCase):
        def setUp(self):
            self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.proxy_server = socket_server.SocketServer(
                family=socket.AF_INET, proto=socket.SOCK_STREAM)
            self.proxy_server.start(0, socket_server.fake_socks)

        def tearDown(self):
            self.proxy_server.stop()

        def test_ctor(self):
            s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)

# Generated at 2022-06-22 09:41:04.662376
# Unit test for constructor of class Proxy
def test_Proxy():
    p = Proxy(ProxyType.SOCKS4, '127.0.0.1', 1080, None, None, False)
    assert p.type == ProxyType.SOCKS4
    assert p.host == '127.0.0.1'
    assert p.port == 1080
    assert p.username == None
    assert p.password == None
    assert p.remote_dns == False
    p = Proxy(ProxyType.SOCKS4A, '127.0.0.1', 1080, 'username', 'password', True)
    assert p.type == ProxyType.SOCKS4A
    assert p.host == '127.0.0.1'
    assert p.port == 1080
    assert p.username == 'username'
    assert p.password == 'password'
    assert p.remote_dns == True

# Generated at 2022-06-22 09:41:09.749551
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 0)
    except InvalidVersionError as e:
        assert 0 == e.args[0]
        assert 'Invalid response version from server. Expected 00 got 00' == e.args[1]