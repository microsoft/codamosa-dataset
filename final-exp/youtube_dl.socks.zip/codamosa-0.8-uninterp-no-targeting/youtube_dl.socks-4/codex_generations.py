

# Generated at 2022-06-22 09:31:49.969629
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    socks5_command = Socks5Command()
    socks5_command.CMD_CONNECT == Socks5Command.CMD_CONNECT
    socks5_command.CMD_UDP_ASSOCIATE == Socks5Command.CMD_UDP_ASSOCIATE
    socks5_command.CMD_BIND == Socks5Command.CMD_BIND
    print('test_Socks5Command succeeded')


# Generated at 2022-06-22 09:31:52.934792
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 9050)
    s.connect(('google.com', 80))

# Generated at 2022-06-22 09:31:55.988158
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 1)
    except InvalidVersionError as e:
        assert e.errno == 0
        assert e.strerror == 'Invalid response version from server. Expected 00 got 01'

if __name__ == '__main__':
    test_InvalidVersionError()

# Generated at 2022-06-22 09:32:01.461857
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(1, 2)
    except InvalidVersionError as e:
        assert str(e) == 'Invalid response version from server. Expected 01 got 02'

    try:
        raise InvalidVersionError(1, 1)
    except InvalidVersionError as e:
        assert str(e) == 'Invalid response version from server. Expected 01 got 01'


# Generated at 2022-06-22 09:32:04.348099
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    command = Socks5Command()
    assert command.CMD_CONNECT == 0x01
    assert command.CMD_UDP_ASSOCIATE == 0x03

# Generated at 2022-06-22 09:32:08.532205
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss=sockssocket(socket.AF_INET,socket.SOCK_STREAM)
    assert isinstance(ss,sockssocket)


# Generated at 2022-06-22 09:32:12.375094
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(Socks4Error.ERR_SUCCESS)
    except Socks4Error as e:
        assert e.code == Socks4Error.ERR_SUCCESS
        assert e.message == 'request rejected or failed'



# Generated at 2022-06-22 09:32:19.168886
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    error = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    msg = 'general SOCKS server failure'
    assert error.__str__() == msg
    error = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE, 'test message')
    assert error.__str__() == 'test message'
    error = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE + 1)
    assert error.__str__() == 'unknown error'



# Generated at 2022-06-22 09:32:28.834639
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import socket

    sock = sockssocket()

    # No proxy
    sock.setproxy(ProxyType.SOCKS5, "127.0.0.1", 1234)
    sock.connect(("127.0.0.1", 9999))

    # SOCKS4 proxy
    sock.setproxy(ProxyType.SOCKS4, "127.0.0.1", 1234)
    sock.connect(("127.0.0.1", 9999))

    # SOCKS4A proxy
    sock.setproxy(ProxyType.SOCKS4A, "127.0.0.1", 1234)
    sock.connect(("127.0.0.1", 9999))

    # SOCKS5 proxy

# Generated at 2022-06-22 09:32:30.974964
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    # Do nothing
    return


# Generated at 2022-06-22 09:32:51.074959
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    error_code = 91
    error_msg = 'request rejected or failed'
    assert Socks4Error(error_code).errno == error_code
    assert Socks4Error(error_code).strerror == error_msg
    assert Socks4Error(error_code) == Socks4Error(error_msg)

# Generated at 2022-06-22 09:32:57.978220
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    from sys import hexversion

    if hexversion < 0x03000000:
        # In Python < 3 int == long
        from test import test_support
        test_support.requires('network')
        import asyncore

    from contextlib import closing

    def _get_port():
        # https://stackoverflow.com/a/18387537
        with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
            s.bind(('', 0))
            return s.getsockname()[1]

    PORT = _get_port()
    ADDR = ('localhost', PORT)


# Generated at 2022-06-22 09:33:00.323864
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:33:04.919058
# Unit test for constructor of class ProxyError
def test_ProxyError():
    proxyerror1 = ProxyError('abc')
    assert proxyerror1.errno == 'abc'
    assert proxyerror1.strerror == 'unknown error'

    proxyerror2 = ProxyError('efg', 'hij')
    assert proxyerror2.errno == 'efg'
    assert proxyerror2.strerror == 'hij'


# Generated at 2022-06-22 09:33:09.158200
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    print(Socks4Error.CODES[93])
    print(Socks4Error())
    print(Socks4Error(92))
    print(Socks4Error(93))
    print(Socks4Error(0, 'error message'))
    print(Socks4Error(1, 'error message'))
    print(Socks4Error(2, 'error message'))
    print(Socks4Error(-1, 'error message'))


# Generated at 2022-06-22 09:33:17.733726
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error(91)
    assert Socks4Error(92)
    assert Socks4Error(93)
    assert Socks4Error(99)
    assert Socks4Error.CODES[91] == 'request rejected or failed'
    assert Socks4Error.CODES[92] == 'request rejected because SOCKS server cannot connect to identd on the client'
    assert Socks4Error.CODES[93] == 'request rejected because the client program and identd report different user-ids'


# Generated at 2022-06-22 09:33:26.500300
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    assert sockssocket._ProxyType == ProxyType
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1080)
    assert s._proxy.username is None
    assert s._proxy.password is None
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1080, username='username')
    assert s._proxy.username == 'username'
    assert s._proxy.password is None
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1080, username=None)
    assert s._proxy.username is None
    assert s._proxy.password is None
    s = sockssocket()

# Generated at 2022-06-22 09:33:31.444436
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    assert s._proxy.host == '127.0.0.1'
    assert s._proxy.port == 1080

# Generated at 2022-06-22 09:33:33.736183
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    s = Socks4Command()
    assert s.CMD_CONNECT == 1
    assert s.CMD_BIND == 2



# Generated at 2022-06-22 09:33:45.556040
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # Original code from github gist https://gist.github.com/bluec0re/cafd3764412967417fd3
    # Modify with proxy arguments (type, host, port, rdns, username, password)
    import sys
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, 'localhost', 1080, username='user', password='password')
    if s.connect_ex(('epic-tools.org', 80)) == 0:
        print('Connected!')
        s.sendall('GET / HTTP/1.1\r\nHost: epic-tools.org\r\n\r\n')
        print(s.recv(4096))

# Generated at 2022-06-22 09:34:09.917972
# Unit test for constructor of class ProxyError
def test_ProxyError():
    pe = ProxyError()
    assert pe.args == (None, None)

# Generated at 2022-06-22 09:34:13.314236
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(1, None)
    except ProxyError as e:
        assert e.args[0] == 1
    try:
        raise ProxyError(None, 'test')
    except ProxyError as e:
        assert e.args[0] == 'test'


# Generated at 2022-06-22 09:34:20.802140
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.setproxy(ProxyType.SOCKS5, "localhost", 1080)
    assert(s._proxy.host == "localhost")
    assert(s._proxy.port == 1080)
    assert(s._proxy.type == ProxyType.SOCKS5)
    assert(s._proxy.username == None)
    assert(s._proxy.password == None)
    assert(s._proxy.remote_dns == True)
    s.setproxy(ProxyType.SOCKS5, "localhost", 1080, False, "username", "password")
    assert(s._proxy.host == "localhost")
    assert(s._proxy.port == 1080)
    assert(s._proxy.type == ProxyType.SOCKS5)

# Generated at 2022-06-22 09:34:30.485084
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import os
    import tempfile
    from .server import TCPServer, TCPServerHandler
    from .common import unquote_header_value
    from .utils import get_filesystem_encoding
    from .compat import (
        compat_cookielib,
        compat_http_client,
        compat_str,
    )
    from .downloader import (
        set_socket_timeout,
        unset_socket_timeout
    )
    from .utils import (
        sanitize_url,
    )
    from .compat import (
        compat_struct_pack,
        compat_struct_unpack,
    )
    from .compatprocess import (
        subprocess_call,
    )


# Generated at 2022-06-22 09:34:34.565646
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    a = Socks5AddressType()
    assert a.ATYP_IPV4 == 0x01
    assert a.ATYP_DOMAINNAME == 0x03
    assert a.ATYP_IPV6 == 0x04

# Generated at 2022-06-22 09:34:36.979458
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2

# Generated at 2022-06-22 09:34:38.219357
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket()
    assert isinstance(ss, sockssocket)
    assert issubclass(sockssocket, socket.socket)


# Generated at 2022-06-22 09:34:40.667214
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    e = Socks4Error(91)
    assert e.errno == 91
    assert e.strerror == 'request rejected or failed'
    e = Socks4Error(91, 'fail')
    assert e.errno == 91
    assert e.strerror == 'fail'


if __name__ == '__main__':
    test_Socks4Error()

# Generated at 2022-06-22 09:34:42.067309
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert type(ProxyType.SOCKS4) == int
    assert type(ProxyType.SOCKS4A) == int
    assert type(ProxyType.SOCKS5) == int


# Generated at 2022-06-22 09:34:44.266615
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    command = Socks4Command()
    assert command.CMD_CONNECT == 0x01
    assert command.CMD_BIND == 0x02



# Generated at 2022-06-22 09:35:11.910165
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    command_test = Socks4Command()
    print(command_test.CMD_CONNECT)
    print(command_test.CMD_BIND)



# Generated at 2022-06-22 09:35:15.129050
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
   assert Socks5Auth.AUTH_NONE == 0x00
   assert Socks5Auth.AUTH_GSSAPI == 0x01
   assert Socks5Auth.AUTH_USER_PASS == 0x02
   assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xff

# Generated at 2022-06-22 09:35:16.453028
# Unit test for constructor of class sockssocket
def test_sockssocket():
    assert sockssocket is not None
    ss = sockssocket()
    assert isinstance(ss, sockssocket)

# Generated at 2022-06-22 09:35:28.472450
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    # test with proxy
    try:
        s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
        s.setproxy(ProxyType.SOCKS5, '192.168.1.1', 1080, False)
        s.connect(('192.168.1.8', 1080))
    except socket.error:
        s.close()
        s = None
        assert s is not None
    assert s is not None

    # test without proxy
    try:
        s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(('192.168.1.8', 1080))
    except socket.error:
        s.close()
        s = None
        assert s is not None
    assert s is not None

# test for method connect_ex of

# Generated at 2022-06-22 09:35:30.841837
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert isinstance(Socks5Auth.AUTH_NO_ACCEPTABLE, int)


# Generated at 2022-06-22 09:35:36.344297
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    p1 = Socks5Command()
    p2 = Socks4Command()
    p3 = Socks4Command()

    assert p1.CMD_CONNECT == p2.CMD_CONNECT
    assert p1.CMD_BIND == p2.CMD_BIND

    assert p1.CMD_UDP_ASSOCIATE == 0x03
    assert p3.CMD_UDP_ASSOCIATE == None

# Generated at 2022-06-22 09:35:37.882146
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-22 09:35:42.658087
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(('localhost', 8000))
    data = sock.recvall(4)
    assert len(data) == 4
    assert data == b'Send'



# Generated at 2022-06-22 09:35:46.000303
# Unit test for constructor of class ProxyError
def test_ProxyError():
    error = ProxyError()
    assert(error.msg.find('unknown error') == 0)


if __name__ == '__main__':
    test_ProxyError()

# Generated at 2022-06-22 09:35:55.277578
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    e = Socks5Error()
    assert e.code == 0
    assert e.args[0] == 0
    assert str(e) == 'unknown error'

    e = Socks5Error(1)
    assert e.code == 1
    assert e.args[0] == 1
    assert str(e) == 'general SOCKS server failure'

    e = Socks5Error(1, 'test')
    assert e.code == 1
    assert e.args[0] == 1
    assert str(e) == 'test'

# Generated at 2022-06-22 09:37:08.671685
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sockssocket.connect(address)

# Generated at 2022-06-22 09:37:10.722706
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:37:18.917643
# Unit test for constructor of class ProxyType
def test_ProxyType():
    ProxyType.SOCKS4 = 0
    ProxyType.SOCKS4A = 1
    ProxyType.SOCKS5 = 2
    if ProxyType.SOCKS4 == 0 and ProxyType.SOCKS4A == 1 and ProxyType.SOCKS5 == 2:
        print('socks: success in constructor of class ProxyType')
    else:
        print('socks: failure in constructor of class ProxyType')



# Generated at 2022-06-22 09:37:21.432894
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    command = Socks4Command()
    print(command)


# Generated at 2022-06-22 09:37:25.605810
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(10, 20)
    except InvalidVersionError as e:
        assert e.args[0] == 0, e.args[0]
        assert e.args[1] == 'Invalid response version from server. Expected 0a got 14', e.args[1]
    else:
        assert False, 'Exception not raised'

# Generated at 2022-06-22 09:37:27.800427
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:37:38.422518
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    assert s._proxy.type == ProxyType.SOCKS5
    assert s._proxy.host == '127.0.0.1'
    assert s._proxy.port == 1080
    assert s._proxy.remote_dns

    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, username='foo', password='bar')
    assert s._proxy.username == 'foo'
    assert s._proxy.password == 'bar'

    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, remote_dns=False)
    assert not s._proxy.remote_dns

# Generated at 2022-06-22 09:37:40.533905
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    sockssocket_inst = sockssocket()
    sockssocket_inst.setproxy(ProxyType.SOCKS4A, '104.31.18.32', 8888)
    assert sockssocket_inst.connect_ex(('spb.sputnik.ru', 80)) == 0

# Generated at 2022-06-22 09:37:52.038102
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import random
    import string
    import unittest

    class TestRecvall(unittest.TestCase):
        def test_len(self):
            for i in range(1, 10):
                # This RNG can't provide 0.
                data = ''.join(random.choice(string.printable) for _ in range(i))
                # Check if all len(data) bytes are received.
                s = sockssocket()
                s.sendall(data)
                received = s.recvall(len(data))
                self.assertEqual(data, received)

        def test_missing_bytes(self):
            # This RNG can't provide 0.
            data = ''.join(random.choice(string.printable) for _ in range(30))
            s = sockssocket()

# Generated at 2022-06-22 09:37:55.362828
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    obj = Socks5AddressType()
    assert obj.ATYP_IPV4 == 0x01
    assert obj.ATYP_DOMAINNAME == 0x03
    assert obj.ATYP_IPV6 == 0x04

# Generated at 2022-06-22 09:41:08.138099
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    socks_ip = "127.0.0.1"
    socks_port = 1080
    socks_name = "local name"
    socks_pwd = "local pwd"
    dest_ip = "1.1.1.1"
    dest_port = 443

    # Test connect_ex with socks socket
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, socks_ip, socks_port)
    ret = s.connect_ex((dest_ip, dest_port))
    s.close()

    # Test connect_ex with socks socket with authentication
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, socks_ip, socks_port, username=socks_name, password=socks_pwd)

# Generated at 2022-06-22 09:41:10.473524
# Unit test for constructor of class Socks4Command
def test_Socks4Command():

    cmd = Socks4Command.CMD_CONNECT

    print(cmd)
    assert cmd == 0x01


# Generated at 2022-06-22 09:41:12.156641
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_UDP_ASSOCIATE == 3

# Generated at 2022-06-22 09:41:20.770253
# Unit test for method connect_ex of class sockssocket

# Generated at 2022-06-22 09:41:22.697220
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(99)
    except ProxyError:
        pass